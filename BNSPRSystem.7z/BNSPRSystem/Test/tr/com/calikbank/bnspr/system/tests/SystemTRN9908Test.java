package tr.com.calikbank.bnspr.system.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class SystemTRN9908Test extends TestCase{
	public void testCanGetCorrectPersonelList(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("TRX_NO", getTransactionNo());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("TARIH",(Date)dateFormat.parse("02-01-2008"));
		}catch (Exception e) {}
		iMap.put("TUR", "V");
		iMap.put("RATING_KODU", "A");
		iMap.put("FAIZ_TUR", "01-08");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN9908_GET_VADELI_SCF_ORAN_BILGI", iMap);
		List<?> list = (List<?>)oMap.get("CBS_VADELI_SCF_ORANLARI_ISL_DE");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			/*HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("",rowData.get("VADE_ARALIGI")); 
			assertEquals("", rowData.get("SCF_URUN_GRUBU_KOD"));
			assertEquals("", rowData.get("TRL_FAIZ_ORANI"));
			assertEquals(new BigDecimal(44), rowData.get("USD_FAIZ_ORANI"));
			assertEquals(new BigDecimal(13), rowData.get("EUR_FAIZ_ORANI"));
			assertEquals("", rowData.get("JPY_FAIZ_ORANI"));
			assertEquals("", rowData.get("CHF_FAIZ_ORANI"));
			assertEquals("", rowData.get("GBP_FAIZ_ORANI"));
			assertEquals("", rowData.get("SEK_FAIZ_ORANI"));
			assertEquals("", rowData.get("DIGER_FAIZ_ORANI"));*/
			//test edilecek
		}
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	//hem guncelleme hem kay�t girisi oldugundan save test edilemio, verileri ezdigi icin
}
