package tr.com.calikbank.bnspr.system.tests;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

import junit.framework.TestCase;

public class LDAPServicesTest extends TestCase {
	
	private GMMap prepareAddLDAPUserServisMap(){
		GMMap servisMap = new GMMap();
		servisMap.put("UID", "testfatih");
		servisMap.put("CN", "testfatih");
		servisMap.put("SN", "Karako�");
		servisMap.put("GIVEN_NAME", "Fatih");
		servisMap.put("MAIL", "fatih.karakoc@aktifbank.com.tr");
		servisMap.put("PASSWORD", "123456");
		
        return servisMap;
	}
	
	public void testAddLDAPUser(){		
		try{
			GMMap servisMap = prepareAddLDAPUserServisMap();
			GMResourceFactory.getInstance().service("BNSPR_SYSTEM_LDAP_ADD_USER", servisMap);
		}catch (Exception e) {
			e.printStackTrace();
			fail("Test Failed: Ldap Kullan�c�s� Olu�turulamad�");
		}

	}

}
