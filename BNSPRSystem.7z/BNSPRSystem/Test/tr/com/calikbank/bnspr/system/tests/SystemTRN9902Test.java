package tr.com.calikbank.bnspr.system.tests;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class SystemTRN9902Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", GetTransactionNo());
		iMap.put("DK_GRUP_KODU", 222);
		iMap.put("ACIKLAMA", "TCMB");
		iMap.put("SIRA_NO", 1000);
		iMap.put("MUSTERI_TIPI", "B");
		iMap.put("YERLESIM_TIPI", "D");
		iMap.put("MKK_KIMLIK_TIPI", "L");
		iMap.put("SERMAYE_YETERLIK_GRUBU", "A");
		
		return iMap;
	}
	public String GetTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}

	/*public void testCanSavePersonelTanimlama(){
		HashMap<String, Object> iMap = setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
		assertTrue(true);	
	}*/
	public void testDKGrupKodNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DK_GRUP_KODU", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testSiraNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SIRA_NO", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testMusteriTipiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("MUSTERI_TIPI", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testYerlesimTipiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("YERLESIM_TIPI", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testMkkKimlikTipiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("MKK_KIMLIK_TIPI", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testSermayeYeterlilikGrubuNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SERMAYE_YETERLIK_GRUBU", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN9902_SAVE", iMap);
			fail("Should raise an SQL Exception");			
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}
