package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class SystemTRN9912Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String,Object>>();
		
		iMap.put("DK_GRUP_KOD", new BigDecimal(1000));
		iMap.put("DK_GRUP_ACIKLAMA", "TCBM");
		iMap.put("MAHSUP_TURU", "REPO");
		iMap.put("STOPAJ_ORANI", new BigDecimal(2));
		
		list.add(iMap);
		
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		oMap.put("CBS_STOPAJ_ORANLARI_ISLEM", list);
		
		return oMap;
	}
	
	public void testCanGetCorrectPersonelList(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN9912_GET_STOPAJ_ORAN", new HashMap<String, Object>());
		List<?> list = (List<?>)oMap.get("CBS_STOPAJ_ORANLARI_ISLEM");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals(new BigDecimal(1000),rowData.get("DK_GRUP_KOD")); 
			assertEquals("TCMB", rowData.get("DK_GRUP_ACIKLAMA"));
			assertEquals("REPO", rowData.get("MAHSUP_TURU"));
			assertEquals(new BigDecimal(4), rowData.get("STOPAJ_ORANI"));
			
		}
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
}
