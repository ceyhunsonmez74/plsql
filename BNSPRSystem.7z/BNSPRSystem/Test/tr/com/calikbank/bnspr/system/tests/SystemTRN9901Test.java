package tr.com.calikbank.bnspr.system.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class SystemTRN9901Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", GetTransactionNo());
		iMap.put("SUBE_KODU", 111);
		iMap.put("SUBE_ADI", "Test �ubesi");
		iMap.put("IL_KODU", "036");
		iMap.put("EFT_KODU", 45);
		iMap.put("SUBE_F", "S");
		iMap.put("SIRA_NO", null);
		iMap.put("TAKAS_KODU", 78);
		iMap.put("KAR_MERKEZI", "E");
		iMap.put("YURT_ICI", "E");	
		iMap.put("MEMZUC_ILCE_KODU", 12);
		iMap.put("MEMZUC_ILCE_SUBE_SIRA", 23);
		iMap.put("KASA_MEVCUT_MU", "E");
		iMap.put("ILCE_KODU", null);
		iMap.put("ULKE_KODU", null);
		iMap.put("VERGI_DAIRE",null);
		iMap.put("VERGI_NO", null);
		iMap.put("DURUMU", null);
		iMap.put("RESMI_DEFTER_BOLUM_KODU", null);
		iMap.put("ADRES", null);
		iMap.put("TELEFON", null);
		iMap.put("FAX", null);
		
		
		ArrayList<HashMap<String, Object>> list1 = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> firstMap = new HashMap<String, Object>();
		
		firstMap.put("TAKAS_BAGLI_BOLUM_KODU", "200");
		list1.add(firstMap);
		
		iMap.put("TAKAS_BAGIMLI_ISLEM", list1);
		
		ArrayList<HashMap<String, Object>> list2 = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> secondMap = new HashMap<String, Object>();
		
		secondMap.put("EFT_BAGLI_BOLUM_KODU", "200");
		list2.add(secondMap);
		
		iMap.put("EFT_BAGIMLI_ISLEM", list2);
		
		
		return iMap;
	}
	public String GetTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}

	/*public void testCanSaveSubeGiris(){
		HashMap<String, Object> iMap = setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN9901_SAVE", iMap);
		assertTrue(true);	
	}*/
	
	public void testSubeKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SUBE_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN9901_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testSubeAdiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SUBE_ADI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN9901_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testIlKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("IL_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN9901_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}
