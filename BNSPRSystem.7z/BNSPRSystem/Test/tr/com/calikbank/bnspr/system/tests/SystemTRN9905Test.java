package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class SystemTRN9905Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String,Object>>();
		
		iMap.put("NUMARA", new BigDecimal(12));
		iMap.put("ACIKLAMA", "asd");
		iMap.put("BASLANGIC", new BigDecimal(13));
		iMap.put("BITIS", new BigDecimal(15));
		list.add(iMap);
		
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		oMap.put("CBS_ZAMAN_ISLEM", list);
		oMap.put("TRX_NO", getTransactionNo());
		
		return oMap;
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	/*public void testCanSave(){
		HashMap<String, Object> iMap = setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN9905_SAVE", iMap);
		assertTrue(true);
	}*/
	public void testNumaraNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("NUMARA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN9905_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testBaslangicNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("BASLANGIC", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN9905_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testBitisNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("BITIS", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN9905_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
}
