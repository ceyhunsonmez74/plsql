package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class SystemTRN9903Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String,Object>>();
		
		iMap.put("KURUM_KODU", "Calikbank");
		iMap.put("BOLUM_KODU", "200");
		iMap.put("PERSONEL_NUMARA", new BigDecimal(13));
		iMap.put("ADI", "ali");
		iMap.put("SOYADI", "veli");
		iMap.put("MUSTERI_NO", new BigDecimal(44));
		iMap.put("UNVAN_KODU", "83");
		list.add(iMap);
		
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		oMap.put("PERSONEL_LIST", list);
		
		return oMap;
	}
	//Base table a kay�t att���ndan dolay� bu ekran�n pakage � yok, zorunlu alanlar ekrandan kontrol edilio

	public void testCanGetCorrectPersonelList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN9903_GET_PERSONEL_BILGI", iMap);
		List<?> list = (List<?>)oMap.get("PERSONEL_LIST");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("ali",rowData.get("ADI")); 
			assertEquals("200", rowData.get("BOLUM_KODU"));
			assertEquals("Calikbank", rowData.get("KURUM_KODU"));
			assertEquals(new BigDecimal(44), rowData.get("MUSTERI_NO"));
			assertEquals(new BigDecimal(13), rowData.get("PERSONEL_NUMARA"));
			assertEquals("veli", rowData.get("SOYADI"));
			assertEquals("83", rowData.get("UNVAN_KODU"));
		}
	}
}
