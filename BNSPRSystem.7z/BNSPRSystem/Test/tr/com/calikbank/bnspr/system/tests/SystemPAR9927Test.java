package tr.com.calikbank.bnspr.system.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class SystemPAR9927Test extends TestCase {
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

		iMap.put("MODUL_TUR_KOD", "KREDI");
		iMap.put("URUN_TUR_KOD", "NOSTRO-TP");
		iMap.put("URUN_SINIF_KOD", "BNK.PARA PIYAS");
		iMap.put("DK_HESABI_1", null);
		iMap.put("DK_HESABI_2", null);
		iMap.put("DK_HESABI_3", null);
		iMap.put("DK_HESABI_4", null);
		iMap.put("DK_HESABI_5", null);
		iMap.put("DK_HESABI_6", null);
		iMap.put("DK_HESABI_7", null);
		iMap.put("DK_HESABI_8", null);
		iMap.put("DK_HESABI_9", null);
		iMap.put("DK_HESABI_10", null);
		iMap.put("DK_HESABI_11", null);
		iMap.put("DK_HESABI_12", null);
		iMap.put("DK_HESABI_13", null);
		iMap.put("DK_HESABI_14", null);
		iMap.put("DK_HESABI_15", null);

		list.add(iMap);

		HashMap<String, Object> oMap = new HashMap<String, Object>();
		oMap.put("GRUP_URUN_SINIF", list);
		oMap.put("DK_GRUP_KODU", "1000");

		return oMap;
	}

	public void testCanGetCorrectGrupUrunSinifList() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DK_GRUP_KODU", "1000");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_PAR9927_GET_GRUP_URUN_SINIF", iMap);
		List<?> list = (List<?>) oMap.get("GRUP_URUN_SINIF");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();

			assertEquals("KREDI", rowData.get("MODUL_TUR_KOD"));
			assertEquals("NOSTRO-TP", rowData.get("URUN_TUR_KOD"));
			assertEquals("BNK.PARA PIYASA", rowData.get("URUN_SINIF_KOD"));
			assertEquals("04001000", rowData.get("DK_HESABI_1"));
			assertEquals("57200000", rowData.get("DK_HESABI_2"));
			assertEquals(null, rowData.get("DK_HESABI_3"));
			assertEquals("22299100", rowData.get("DK_HESABI_4"));
			assertEquals(null, rowData.get("DK_HESABI_5"));
			assertEquals(null, rowData.get("DK_HESABI_6"));
			assertEquals(null, rowData.get("DK_HESABI_7"));
			assertEquals(null, rowData.get("DK_HESABI_8"));
			assertEquals(null, rowData.get("DK_HESABI_9"));
			assertEquals(null, rowData.get("DK_HESABI_10"));
			assertEquals(null, rowData.get("DK_HESABI_11"));
			assertEquals(null, rowData.get("DK_HESABI_12"));
			assertEquals(null, rowData.get("DK_HESABI_13"));
			assertEquals(null, rowData.get("DK_HESABI_14"));
			assertEquals(null, rowData.get("DK_HESABI_15"));
		}
	}
	public void testDkGrupKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DK_GRUP_KODU", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_PAR9927_SAVE", iMap);
			fail("Should raise an SQL Exception");
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testModulTurKodNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("MODUL_TUR_KOD", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_PAR9927_SAVE", iMap);
			fail("Should raise an SQL Exception");
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testUrunTurKodNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("URUN_TUR_KOD", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_PAR9927_SAVE", iMap);
			fail("Should raise an SQL Exception");
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testSinifKodNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("URUN_SINIF_KOD", null);
		try{
			GMResourceFactory.getInstance().service("BNSPR_PAR9927_SAVE", iMap);
			fail("Should raise an SQL Exception");
		}catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
}
