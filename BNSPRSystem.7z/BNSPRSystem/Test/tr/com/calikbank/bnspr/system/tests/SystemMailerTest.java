package tr.com.calikbank.bnspr.system.tests;

import java.util.ArrayList;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class SystemMailerTest extends TestCase{
	private static final String attachmentTableName = "ATTACMENT_FILE_LIST";
	private GMMap prepareEmailServisMap(){
		GMMap servisMap = new GMMap();
		servisMap.put("FROM", "ibrahimt@aktifbank.com.tr");
		ArrayList<String> recipientsList = new ArrayList<String>();
		recipientsList.add("kenan.aydin@obss.com.tr");
		recipientsList.add("k.aydin7@yahoo.com");
		servisMap.put("RECIPIENTS_TO", recipientsList);
		servisMap.put("SUBJECT", "Message Subject");
		
		return servisMap;
	}
	
	private GMMap prepareAttachmentList(GMMap servisMap){
		servisMap.put(attachmentTableName, 0, "FILE_NAME", "logo.jpg");
		servisMap.put(attachmentTableName, 0, "FILE_DIRECTORY", "C:\\attach");
		servisMap.put(attachmentTableName, 1, "FILE_NAME", "rapor.pdf");
		servisMap.put(attachmentTableName, 1, "FILE_DIRECTORY", "C:\\attach");
		return servisMap;
	}
	
	public void testCanSendPlainEMailWithoutAttachment(){
		GMMap servisMap = prepareEmailServisMap();
		servisMap.put("IS_BODY_HTML", false);
		servisMap.put("MESSAGE_BODY", "Message Body");
		servisMap.put(attachmentTableName, new ArrayList<GMMap>());

		try{
			GMResourceFactory.getInstance().service("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
		}catch (Exception e) {
			e.printStackTrace();
			fail("Test Failed: Mail G�nderilemedi");
		}
	}
	
	public void testCanSendHTMLEMailWithoutAttachment(){
		GMMap servisMap = prepareEmailServisMap();
		servisMap.put("IS_BODY_HTML", true);
		servisMap.put("MESSAGE_BODY", "<html><HEAD><TITLE>HTML Message</TITLE></HEAD><body><h1>HTML Message Body</h1></body></html>");
		servisMap.put(attachmentTableName, new ArrayList<GMMap>());

		try{
			GMResourceFactory.getInstance().service("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
		}catch (Exception e) {
			e.printStackTrace();
			fail("Test Failed: Mail G�nderilemedi");
		}
	}
	
	public void testCanSendPlainEMailWithAttachments(){
		GMMap servisMap = prepareEmailServisMap();
		servisMap.put("IS_BODY_HTML", false);
		servisMap.put("MESSAGE_BODY", "Message Body");
		prepareAttachmentList(servisMap);
		
		try{
			GMResourceFactory.getInstance().service("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
		}catch (Exception e) {
			e.printStackTrace();
			fail("Test Failed: Mail G�nderilemedi");
		}
	}
	
	public void testCanSendHTMLEMailWithAttachments(){
		GMMap servisMap = prepareEmailServisMap();
		servisMap.put("IS_BODY_HTML", true);
		servisMap.put("MESSAGE_BODY", "<html><HEAD><TITLE>HTML Message</TITLE></HEAD><body><h1>HTML Message Body</h1></body></html>");
		prepareAttachmentList(servisMap);
		
		try{
			GMResourceFactory.getInstance().service("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
		}catch (Exception e) {
			e.printStackTrace();
			fail("Test Failed: Mail G�nderilemedi");
		}
	}
	
}
