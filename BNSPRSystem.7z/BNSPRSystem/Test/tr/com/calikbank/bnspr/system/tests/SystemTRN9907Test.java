package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class SystemTRN9907Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String,Object>>();
		
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("FAIZ_ORANI", new BigDecimal(2));
		list.add(iMap);
		
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		oMap.put("PERSONEL_LIST", list);
		
		return oMap;
	}
	//hem guncelleme hem kay�t girisi oldugundan save test edilemio, verileri ezdigi icin
	
	public void testCanGetCorrectPersonelList(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", getTransactionNo());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("ISLEM_TARIHI",(Date)dateFormat.parse("02-01-2008"));
		}catch (Exception e) {}
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN9907_GET_SCF_ORAN_BILGI", iMap);
		List<?> list = (List<?>)oMap.get("CBS_SCF_ORANI_GIRIS_DETAY");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("AUD",rowData.get("DOVIZ_KODU")); 
			assertEquals(new BigDecimal(333), rowData.get("FAIZ_ORANI"));
		}
	}

	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
}
