/**
 * 
 */
package tr.com.calikbank.bnspr.sms.services.test;

import java.util.HashMap;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.calikbank.bnspr.sms.services.SmsServices;

import junit.framework.TestCase;

/**
 * @author recepa
 *
 */
public class SmsServicesTest extends TestCase {
	
	/**
	 * Test method for {@link tr.com.calikbank.bnspr.sms.services.SmsServices#sendSMS(com.graymound.util.GMMap)}.
	 */
	public void testSendSMS() {
		GMMap iMap = new GMMap();
		iMap.put("MSISDN"			, "+905353789141");
		iMap.put("SECURE_CONTENT"	, true);
		iMap.put("CONTENT"			, "fsdfasdfa");
		iMap.put("HEADER"			, "");
		iMap.put("FILTER"			, true);
		
		GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap);
	}
	
	/**
	 * Test method for {@link tr.com.calikbank.bnspr.sms.services.SmsServices#sendFastSMS(com.graymound.util.GMMap)}.
	 */
	public void testSendFastSMS() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test method for {@link tr.com.calikbank.bnspr.sms.services.SmsServices#sendOTP(com.graymound.util.GMMap)}.
	 */
	public void testSendOTP() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test method for {@link tr.com.calikbank.bnspr.sms.services.SmsServices#sendOTP2(com.graymound.util.GMMap)}.
	 */
	public void testSendOTP2() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test method for {@link tr.com.calikbank.bnspr.sms.services.SmsServices#send(java.lang.String, java.lang.String)}.
	 */
	public void testSendStringString() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test method for {@link tr.com.calikbank.bnspr.sms.services.SmsServices#convertToEnglishChars(java.lang.String)}.
	 */
	public void testConvertToEnglishChars() {
		String testString 	= "T�RK�E KARAKTER DENEME : ������ ������T�RK�E KARAKTER DENEME : ������ ������T�RK�E KARAKTER DENEME : ������ ������";
		testString = testString + testString + testString;
		testString = testString + testString + testString;
		testString = testString + testString + testString;
		testString = testString + testString + testString;
		testString = testString + testString + testString;
		testString = testString + testString + testString;
		
		String newString = SmsServices.convertToStandartChars(testString);
		
//		assertEquals("TURKCE KARAKTER DENEME : iougsc IOUGSCTURKCE KARAKTER DENEME : iougsc IOUGSCTURKCE KARAKTER DENEME : iougsc IOUGSC", newString);
		System.out.println(newString);
	}
	
	public static String convertToStandartChars(String str) {
		HashMap<Character, Character> map = new HashMap<Character, Character>();
		char[] chr = str.toCharArray();
		// ������ ������
		map.put('�', 'i');	// (char)305
		map.put('�', 'o');	// (char)246
		map.put('�', 'u');	// (char)252
		map.put('�', 'g');	// (char)287
		map.put('�', 's');	// (char)251
		map.put('�', 'c');	// (char)231
		map.put('�', 'I');
		map.put('�', 'O');
		map.put('�', 'U');
		map.put('�', 'G');
		map.put('�', 'S');
		map.put('�', 'C');
		
		for(int i=0; i<chr.length; i++){
			if(map.containsKey(chr[i])) {
				chr[i] = map.get(chr[i]);
			}
		}
		return String.copyValueOf(chr);
	}
}
