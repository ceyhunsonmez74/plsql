package tr.com.aktifbank.bnspr.sap.services;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.SapPersonel;
import tr.com.aktifbank.integration.sap.SAPClient;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.sap.document.sap.rfc.functions.ZHRSTAKUSTIK;
import com.sap.document.sap.rfc.functions.ZHRTTAKUSTIK;

public class SAPServices {

	private static Logger logger = Logger.getLogger(SAPServices.class);
	
	@GraymoundService("BNSPR_SAP_GET_SAP_INFO_JOB")
	public static GMMap getSAPInfoJob(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			session.createQuery("delete SapPersonel").executeUpdate();
			session.flush();
			
			ZHRTTAKUSTIK sapInfo = SAPClient.getSAPInfo();
			List<ZHRSTAKUSTIK> personnelList = sapInfo.getItem();
			for (ZHRSTAKUSTIK zhrstakustik : personnelList) {
				SapPersonel personel = new SapPersonel();
				personel.setSicil(zhrstakustik.getSICIL());
				personel.setAdSoyad(zhrstakustik.getADSOYAD());
				personel.setSirketKodu(zhrstakustik.getSIRKETKODU());
				personel.setSirketMetni(zhrstakustik.getSIRKETMETNI());
				personel.setSubeKodu(zhrstakustik.getSUBEKODU());
				personel.setBolumKodu(zhrstakustik.getBOLUMKODU());
				personel.setBolumMetni(zhrstakustik.getBOLUMMETNI());
				personel.setBirimKodu(zhrstakustik.getBIRIMKODU());
				personel.setBirimMetni(zhrstakustik.getBIRIMMETNI());
				personel.setServisKodu(zhrstakustik.getSERVISKODU());
				personel.setServisMetni(zhrstakustik.getSERVISMETNI());
				personel.setGorevKodu(zhrstakustik.getGOREVKODU());
				personel.setGorevMetni(zhrstakustik.getGOREVMETNI());
				personel.setYonSicil(zhrstakustik.getYONSICIL());
				personel.setYonAdSoyad(zhrstakustik.getYONADSOYAD());	
				
				session.save(personel);
			}
			session.flush();
		}
		catch(Exception e){
			//throw ExceptionHandler.convertException(e);
			logger.error("SAP service error : " + e.getMessage());
			oMap.put("RESPONSE", "0");
		}

		return oMap;
	}
	
	
}
