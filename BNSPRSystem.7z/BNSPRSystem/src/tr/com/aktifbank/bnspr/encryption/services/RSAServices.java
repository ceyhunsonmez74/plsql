package tr.com.aktifbank.bnspr.encryption.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class RSAServices{
	private PrivateKey privateKey;
    private PublicKey publicKey;

    public RSAServices() throws NoSuchAlgorithmException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(512);
        KeyPair pair = keyGen.generateKeyPair();
        this.privateKey = pair.getPrivate();
        this.publicKey = pair.getPublic();
    }

    // https://docs.oracle.com/javase/8/docs/api/java/security/spec/PKCS8EncodedKeySpec.html
    public static PrivateKey getPrivateKey(String base64PrivateKey){
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(base64PrivateKey.getBytes()));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        try {
            privateKey = keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return privateKey;
    }

    // https://docs.oracle.com/javase/8/docs/api/java/security/spec/X509EncodedKeySpec.html
    public static PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
        	 /*BigInteger modulus = new BigInteger("F56D...", 16);
        	 BigInteger pubExp = new BigInteger("010001", 16);
        	 KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        	 RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(modulus, pubExp);
        	 publicKey = keyFactory.generatePublic(pubKeySpec);*/
        	//[B@2acdb06e
        	
           X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.decodeBase64(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
        	 e.printStackTrace();
        }
        return publicKey;
    }

    public static byte[] encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
    	Cipher cipher = Cipher.getInstance("RSA/ECB/NoPadding");
    	cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
    	
    	return cipher.doFinal(data.getBytes());
    }

    public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
        return decrypt(Base64.decodeBase64(data.getBytes()), getPrivateKey(base64PrivateKey));
    }

    public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        Cipher cipher = Cipher.getInstance("RSA/ECB/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        String decryptedString = new String(cipher.doFinal(data));
        return decryptedString.trim();
    }
    public static String sha256(String base) {
        try{
        	MessageDigest sha = MessageDigest.getInstance("SHA-256");
			sha.update(base.getBytes("utf-8"));
			return new String(Hex.encodeHex(sha.digest())); 
        } catch(Exception ex){
           throw new RuntimeException(ex);
        }
    }
 
    @GraymoundService("BNSPR_RSA_GET_HASHED_ENCRYPTED_DATA")
    public static GMMap getHashedEncrytedDate(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		String publicKey = iMap.getString("PUBLIC_KEY");
			String encryptedString =new String(Base64.encodeBase64(encrypt(iMap.getString("CODE"), publicKey)));
			oMap.put("ENCRYPTED_HASH_CODE", sha256(encryptedString));
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_RSA_GET_ENCRYPTED_DATA")
    public static GMMap getEncrytedDate(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		String publicKey = iMap.getString("PUBLIC_KEY");
			String encryptedString =new String(Base64.encodeBase64(encrypt(iMap.getString("CODE"), publicKey)));
			oMap.put("ENCRYPTED_CODE", encryptedString);
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_RSA_GET_DECRYPTED_DATA")
    public static GMMap getDecrytedDate(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		String privateKey = iMap.getString("PRIVATE_KEY");
    		String decryptedString = decrypt(iMap.getString("ENCRYPTED_STRING"), privateKey);
			oMap.put("ENCRYPTED_HASH_CODE", decryptedString);
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
    	return oMap;
    }
  
   

    public void writeToFile(String path, byte[] key) throws IOException {
        File f = new File(path);
        f.getParentFile().mkdirs();

        FileOutputStream fos = new FileOutputStream(f);
        fos.write(key);
        fos.flush();
        fos.close();
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }
    
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
    	RSAServices keyPairGenerator = new RSAServices();
       
        System.out.println(new String(Base64.encodeBase64(keyPairGenerator.getPublicKey().getEncoded())));
        
        System.out.println(new String(Base64.encodeBase64(keyPairGenerator.getPrivateKey().getEncoded())));
        /*String qrCode="9901430000001531013f47c27f8dca8994342efcdabc30f32d48bf43dca9344a4774cd1fc5821779814033";
        	String merchantInfo = qrCode.substring(0, 18);
        	String merchantCode = qrCode.substring(6, 16);
        	String cashId = qrCode.substring(16, 18);
        	System.out.println(merchantInfo);
        	System.out.println(merchantCode);
        	System.out.println(cashId);
        	String hashCode=qrCode.substring(18,82);
        	System.out.println(hashCode);
        	String crcCode= qrCode.substring(82,86);
        	System.out.println(crcCode);
        	String encryptedString = new String(Base64.encodeBase64(encrypt("M"+merchantInfo, PUBLIC_KEY)));
        	System.out.println(encryptedString);
        	System.out.println(sha256(encryptedString));
        	System.out.println(decrypt(encryptedString, PRIVATE_KEY));*/
        
    }
}