package tr.com.calikbank.bnspr.saf;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class SafDashboard {

	
	@GraymoundService("BNSPR_SAF_DB_GET_DOMAIN_LIST")
	public static GMMap getDomainList(GMMap iMap) {
		return callSAFService("BNSPR_SAF_GET_DOMAIN_LIST",iMap);
	}
	
	@GraymoundService("BNSPR_SAF_DB_CHANGE_DOMAIN_STATE")
	public static GMMap changingState(GMMap iMap) {
		return callSAFService("BNSPR_SAF_CHANGE_DOMAIN_STATE",iMap);
	}	
	
	private static GMMap callSAFService(String serviceName,GMMap iMap){
		GMMap oMap=new GMMap();
		GMConnection connection=null;
		try {
			connection = GMConnection.getConnection("SAF");
			oMap.putAll(connection.serviceCall(serviceName, iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
