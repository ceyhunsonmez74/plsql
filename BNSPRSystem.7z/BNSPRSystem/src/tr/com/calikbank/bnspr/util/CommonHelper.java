package tr.com.calikbank.bnspr.util;

import java.util.ArrayList;
import java.util.List;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CommonHelper {
	
	/**
	 * Verilen listeyi, verilen thread say�s� kadar listeciklere b�ler.
	 * @param list
	 * @param threadSize
	 * @return 
	 */
	public static <T> List<List<T>> splitListWithThreadCount(List<T> list, int threadSize) {
		final int listSize = list.size();
		if (threadSize > listSize) {
			threadSize = listSize;
		} 
		boolean hasRemainder = false;
		final int processCountPerThread = listSize / threadSize;
		final int remainder = listSize % threadSize;
		if (remainder != 0) {
			hasRemainder = true;
		}

		List<List<T>> parts = new ArrayList<List<T>>();
		for (int startIndex = 0; startIndex < listSize; startIndex += processCountPerThread) {
			int endIndex = Math.min(listSize, startIndex + processCountPerThread);
			if ((hasRemainder && listSize == endIndex) || parts.size() >= threadSize) {
				parts.get(parts.size() - 1).addAll(list.subList(startIndex, endIndex));
			} else {
				parts.add(new ArrayList<T>(list.subList(startIndex, endIndex)));
			}
		}
		return parts;
	}
	
    public static String getGlobalParameter(String kod) {
        GMMap serviceMap = new GMMap();
        serviceMap.put("KOD", kod);
        serviceMap.put("TRIM_QUOTES", true);
        return GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", serviceMap).getString("DEGER");
    }
}
