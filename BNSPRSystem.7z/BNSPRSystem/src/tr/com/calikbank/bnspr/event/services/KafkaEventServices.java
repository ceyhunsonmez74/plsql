package tr.com.calikbank.bnspr.event.services;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class KafkaEventServices {

	private static Logger logger = Logger.getLogger(KafkaEventServices.class);
	
	private static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-kafka-event-client.properties");
	
	@GraymoundService("BNSPR_EVENT_SEND_TO_NETMERA")
	public static GMMap sendEventToNetmera(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			int statusCode=postJsonMessage(iMap.getString("MESSAGE"), conf.getProperty("endpoint.post.netmera"));
			oMap.put("STATUS_CODE", statusCode);
			
		} catch (Exception exp) {
			logger.error("Netmera Event Sending Exception!", exp);
			throw new GMRuntimeException(0, "Netmera Event Sending Failed!");
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_EVENT_SEND_TO_REWARDACUS")
	public static GMMap sendEventToRewardacus(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			int statusCode=postJsonMessage(iMap.getString("MESSAGE"), conf.getProperty("endpoint.post.rewardacus"));			
			oMap.put("STATUS_CODE", statusCode);
			
		} catch (Exception exp) {
			logger.error("Rewardacus Event Sending Exception!", exp);
			throw new GMRuntimeException(0, "Rewardacus Event Sending Failed!");
		}
		return oMap;
	}
	
	private static int postJsonMessage(String message, String endpoint) throws Exception {
		HttpPost httppost = new HttpPost(endpoint);
		httppost.setConfig(getRequestConfig());
		httppost.setHeader("Content-Type", "application/json");
		httppost.setEntity(new StringEntity(message, "UTF-8"));
		
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			CloseableHttpResponse httpresponse = httpclient.execute(httppost);
			try {
				int statusCode=httpresponse.getStatusLine().getStatusCode();
				if(statusCode!=200){
					logger.error("KafkaEventServices Response StatusCode:"+statusCode+" - Message:"+getResponseString(httpresponse));
				}
				return statusCode;
			} finally {
				httpresponse.close();
			}
		} finally {
			httpclient.close();
		}
	}
	
	private static RequestConfig getRequestConfig(){
		return RequestConfig.custom()
				.setConnectTimeout(Integer.valueOf(conf.getProperty("http.connection.timeout")))
				.setSocketTimeout(Integer.valueOf(conf.getProperty("http.socket.timeout")))
				.build();				
	}
	
	private static String getResponseString(HttpResponse response){
		try {
			HttpEntity entity=response.getEntity();
			if(entity!=null){
				return EntityUtils.toString(entity);
			}
		} catch(Exception exp) {
			logger.error("KafkaEventServices Getting Response String Exception:", exp);
		}
		return null;
	}
	
}
