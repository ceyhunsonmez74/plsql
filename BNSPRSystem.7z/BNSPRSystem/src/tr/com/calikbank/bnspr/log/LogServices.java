package tr.com.calikbank.bnspr.log;

import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.hibernate.Session;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.dao.RestWebservicesLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class LogServices {

	private static Logger logger = Logger.getLogger(LogServices.class);
	
	private static GMMap prepareStartOperationInput(GMMap iMap){
		Calendar cal=Calendar.getInstance();
		iMap.put("BEGIN_DATE", cal.getTime().getTime());
		cal.add(Calendar.MINUTE, iMap.getInt("PERIOD"));
		iMap.put("END_DATE", cal.getTime().getTime());
		
		return iMap;
	}
	
	@GraymoundService("ADC_SERVICE_LOG_START")
	public static GMMap startAdcServiceLog(GMMap iMap) {
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap oMap = new GMMap();
		try {
			iMap=prepareStartOperationInput(iMap);
			
			String[] serviceArray=null;
			if(iMap.getSize("SERVICES")>0){
				int listSize=iMap.getSize("SERVICES");
				serviceArray=new String[listSize];
				for(int row=0;row<listSize;row++){
					serviceArray[row]=iMap.getString("SERVICES", row, "NAME");
				}
			}
			String[] instanceArray=null;
			if(iMap.getSize("INSTANCES")>0){
				int listSize=iMap.getSize("INSTANCES");
				instanceArray=new String[listSize];
				for(int row=0;row<listSize;row++){
					instanceArray[row]=iMap.getString("INSTANCES", row, "NAME");
				}
			}
			
			conn = DALUtil.getGMConnection();
			ArrayDescriptor serviceArrayDesc = ArrayDescriptor.createDescriptor("SERVICE_NAME_LIST", conn.getMetaData().getConnection()); 
			ARRAY arrayOfServices = new ARRAY(serviceArrayDesc, conn.getMetaData().getConnection(), serviceArray);
			ARRAY arrayOfInstance = new ARRAY(serviceArrayDesc, conn.getMetaData().getConnection(), instanceArray);
			
			stmt = conn.prepareCall("{? = call PKG_ADC_SERVICE_LOG.startServiceLogProcess(?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setInt(2, iMap.getInt("LOG_TYPE_ID"));
			stmt.setInt(3, iMap.getInt("REQUEST"));
			stmt.setInt(4, iMap.getInt("RESPONSE"));
			stmt.setTimestamp(5, new Timestamp(iMap.getLong("BEGIN_DATE")));
			stmt.setTimestamp(6, new Timestamp(iMap.getLong("END_DATE")));
			stmt.setString(7, ADCSession.getString("USER_NAME"));
			stmt.setArray(8, arrayOfServices);
			stmt.setArray(9, arrayOfInstance);
			stmt.execute();
			
			oMap.put("RETURN", stmt.getInt(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}

	
	@GraymoundService("ADC_SERVICE_LOG_CANCEL")
	public static GMMap cancelAdcServiceLog(GMMap iMap) {
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_ADC_SERVICE_LOG.cancelServiceLogProcess(?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("CONTROL_ID"));
			stmt.execute();
			
			oMap.put("RETURN", stmt.getInt(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}

	
	@GraymoundService("GET_ADC_SERVICE_LOG")
	public static GMMap getAdcServiceLog(GMMap iMap) {
    	Connection 	conn = null;
    	Statement 	stmt = null;
		ResultSet 	rSet = null;
		GMMap oMap = new GMMap();
		try {
			SimpleDateFormat dateFormat=new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			
			conn = DALUtil.getGMConnection();
			stmt=conn.createStatement();
			rSet=stmt.executeQuery("SELECT OID,LOG_TYPE_OID,REQUEST,RESPONSE,BEGIN_DATE,END_DATE " +
					"FROM ADC_SERVICE_LOG_CONTROL WHERE (SYSDATE BETWEEN BEGIN_DATE AND END_DATE) AND ACTIVE=1");
			
			if(rSet!=null && rSet.next()) {
				oMap.put("REQUEST", rSet.getBoolean("REQUEST"));
				oMap.put("RESPONSE", rSet.getBoolean("RESPONSE"));
				oMap.put("BEGIN_DATE", dateFormat.format(rSet.getTimestamp("BEGIN_DATE").getTime()));
				oMap.put("END_DATE", dateFormat.format(rSet.getTimestamp("END_DATE").getTime()));
				oMap.put("CONTROL_ID", rSet.getString("OID"));
				oMap.put("RETURN", rSet.getInt("LOG_TYPE_OID"));
				oMap=getAdcServiceLogDetailSrv(oMap, conn);
				oMap=getAdcServiceLogDetailIns(oMap, conn);
			} else {
				
				oMap.put("RETURN", "0");
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	private static GMMap getAdcServiceLogDetailSrv(GMMap iMap, Connection conn) throws SQLException{;
		PreparedStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			stmt = conn.prepareStatement("SELECT SERVICE_NAME FROM ADC_SERVICE_LOG_DETAIL_SRV WHERE CONTROL_OID=?");
			stmt.setString(1, iMap.getString("CONTROL_ID"));
			rSet=stmt.executeQuery();
			List<GMMap> serviceList=new ArrayList<GMMap>();
			while(rSet.next()){
				GMMap itemMap=new GMMap();
				itemMap.put("NAME", rSet.getString("SERVICE_NAME"));
				serviceList.add(itemMap);
			}
			iMap.put("SERVICES", serviceList);
			return iMap;
			
		} catch (SQLException exp) {
			throw exp;
			
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
        }		
	}
	
	private static GMMap getAdcServiceLogDetailIns(GMMap iMap, Connection conn) throws SQLException{
		PreparedStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			stmt = conn.prepareStatement("SELECT INSTANCE_ID FROM ADC_SERVICE_LOG_DETAIL_INS WHERE CONTROL_OID=?");
			stmt.setString(1, iMap.getString("CONTROL_ID"));
			rSet=stmt.executeQuery();
			List<GMMap> instanceList=new ArrayList<GMMap>();
			while(rSet.next()){
				GMMap itemMap=new GMMap();
				itemMap.put("NAME", rSet.getString("INSTANCE_ID"));
				instanceList.add(itemMap);
			}
			iMap.put("INSTANCES", instanceList);
			return iMap;
			
		} catch (SQLException exp) {
			throw exp;
			
		} finally {
	        GMServerDatasource.close(rSet);
	        GMServerDatasource.close(stmt);
	    }		
	}
	
	@GraymoundService("GET_SERVICE_LOG_INSTANCE_LIST")
	public static GMMap getServiceLogInstances(GMMap iMap){
    	Connection 	conn = null;
    	Statement 	stmt = null;
		ResultSet 	rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn=DALUtil.getGMConnection();
			stmt=conn.createStatement();
			rSet=stmt.executeQuery("SELECT INSTANCE_ID FROM ADC_SERVICE_LOG_INSTANCE ORDER BY INSTANCE_ID ASC");
			
			List<GMMap> instanceList=new ArrayList<GMMap>();
			while(rSet.next()){
				GMMap itemMap=new GMMap();
				itemMap.put("NAME", rSet.getString("INSTANCE_ID"));
				instanceList.add(itemMap);
			}
			oMap.put("INSTANCES", instanceList);
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }		
	}
	
	@GraymoundService("DETECT_SERVICE_LOG_INSTANCE")
	public static GMMap detectServiceLogInstance(GMMap iMap){
		List<GMMap> instanceList=new ArrayList<GMMap>();
		Object[] instanceArray=(Object[])iMap.get("INSTANCES");
		for(int i=0;i<instanceArray.length;i++){
			instanceList.add((GMMap)instanceArray[i]);
		}
		GMMap oMap=new GMMap();
		oMap.put("SELECTED_INSTANCES", instanceList);
		return oMap;
	}
	
	
	@GraymoundService("ADC_SERVICE_LOG_CALCULATE_DAILY_TREND")
	public static GMMap adcServiceLogCalculateDailyTrend(GMMap iMap) {
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getServiceLogConnection();
			
			stmt = conn.prepareCall("{? = call reCreateServiceLogSummary()}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			
			int result=stmt.getInt(1);
			if(result>0){
				logger.info("Gunluk Service Log Datasi Islendi!");
			}else{
				logger.error("Gunluk Service Log Datasi Islenemedi!");
				throw new GMRuntimeException(0,"Gunluk Service Log Datasi Islenemedi");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }		

		return oMap;
	}
	
	@GraymoundService("ADC_SERVICE_LOG_TRANSFER_TO_CENTRAL")
	public static GMMap adcServiceLogTransferToCentral(GMMap iMap) {
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getServiceLogConnection();
			
			stmt = conn.prepareCall("{? = call reCreateServiceLogCentral()}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			
			int result=stmt.getInt(1);
			if(result>0){
				logger.info("Gunluk Service Log Transfer Islemi Tamamlandi!");
			}else{
				logger.error("Gunluk Service Log Transfer Islemi Tamamlanamdi!");
				throw new GMRuntimeException(0,"Gunluk Service Log Transfer Islemi Tamamlanamdi");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }		

		return oMap;
	}


	
	@GraymoundService("ADC_SERVICE_LOG_EMAIL_NOTIFICATION")
	public static GMMap emailNotification(GMMap iMap) {
    	Connection 	conn = null;
    	Statement 	stmt = null;
		ResultSet 	rSet = null;
		GMMap oMap = new GMMap();
		try {			
			long t = System.currentTimeMillis();
			conn = DALUtil.getServiceLogConnection();
			stmt=conn.createStatement();
			String query = "select l.channel, l.service_name, l.begin_date, l.end_date, l.duration, " +
								  "l.is_error, l.average, l.threshold, l.owner, l.job_flag, l.ws_flag, l.core_session_id, " +
								  "l.server_ip, l.client_ip, l.team_email, l.owner_email, l.request, l.response " +
							" from V_LONG_RUNNING_ALL l ";
			stmt.setQueryTimeout(900);
			rSet = stmt.executeQuery(query);
			logger.info(String.format("Servicelog notification query took %s ms.", (System.currentTimeMillis() - t)));
			while (rSet.next()) {
				GMMap sMap = new GMMap();
				sMap.put("CHANNEL", rSet.getString("CHANNEL"));
				sMap.put("SERVICE_NAME", rSet.getString("SERVICE_NAME"));
				sMap.put("BEGIN_DATE", rSet.getString("BEGIN_DATE"));
				sMap.put("END_DATE", rSet.getString("END_DATE"));
				sMap.put("DURATION", rSet.getString("DURATION"));
				sMap.put("IS_ERROR", rSet.getString("IS_ERROR"));
				sMap.put("AVERAGE", (rSet.getString("AVERAGE") != null) ? rSet.getString("AVERAGE") : "0");
				sMap.put("THRESHOLD", rSet.getString("THRESHOLD"));
				sMap.put("OWNER", rSet.getString("OWNER"));
				sMap.put("JOB_FLAG", rSet.getString("JOB_FLAG"));
				sMap.put("WS_FLAG", rSet.getString("WS_FLAG"));
				sMap.put("CORE_SESSION_ID", rSet.getString("CORE_SESSION_ID"));
				sMap.put("SERVER_IP", rSet.getString("SERVER_IP"));
				sMap.put("CLIENT_IP", rSet.getString("CLIENT_IP"));
				sMap.put("TEAM_EMAIL", rSet.getString("TEAM_EMAIL"));
				sMap.put("REQUEST", rSet.getString("REQUEST"));
				sMap.put("RESPONSE", rSet.getString("RESPONSE"));
				
				//OWNER_EMAIL baz�nda grupla
				int size = oMap.getSize(rSet.getString("OWNER_EMAIL"));
				oMap.put(rSet.getString("OWNER_EMAIL"), size, sMap);
			}
			prepareVelocityEmail(oMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	private static void prepareVelocityEmail(GMMap iMap) {	
		logger.debug("prepareVelocityEmail iMap" + iMap.toString());			
		String mailFrom = "AltyapiveDestekSistemleriUygulamaGelistirmeBirimi@aktifbank.com.tr";
		String encType = "UTF-8";
		
        VelocityEngine ve = new VelocityEngine();
        ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath"); 
        ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        ve.init();

        ArrayList<HashMap<String, String>> list = null;
        HashMap<String, String> map = null;
        
        // iterate over owner_emails
		for (Object key : iMap.keySet()) {
			String teamEmail = null;
			list = new ArrayList<HashMap<String, String>>();
			
			int size = iMap.getSize((String) key);
			for (int i = 0; i < size; i++) {
				map = new HashMap<String, String>();
				map.put("CHANNEL", "".equals(iMap.getString((String) key, i, "CHANNEL")) ? " " : iMap.getString((String) key, i, "CHANNEL"));
				map.put("SERVICE_NAME",iMap.getString((String) key, i, "SERVICE_NAME"));
				map.put("BEGIN_DATE",iMap.getString((String) key, i, "BEGIN_DATE"));
				map.put("END_DATE",iMap.getString((String) key, i, "END_DATE"));
				map.put("DURATION", (iMap.getString((String) key, i, "DURATION").startsWith(".")) ? "0".concat(iMap.getString((String) key, i, "DURATION")) : iMap.getString((String) key, i, "DURATION"));
				map.put("IS_ERROR", (iMap.getString((String) key, i, "IS_ERROR").equals("1")) ? "Evet" : "Hay�r");
				map.put("AVERAGE", (iMap.getString((String) key, i, "AVERAGE").startsWith(".")) ? "0".concat(iMap.getString((String) key, i, "AVERAGE")) : iMap.getString((String) key, i, "AVERAGE"));
				map.put("THRESHOLD",iMap.getString((String) key, i, "THRESHOLD"));
				map.put("OWNER",iMap.getString((String) key, i, "OWNER"));
				map.put("JOB_FLAG", (iMap.getString((String) key, i, "JOB_FLAG").equals("H")) ? "Hay�r" : "Evet" );
				map.put("WS_FLAG", (iMap.getString((String) key, i, "WS_FLAG").equals("H")) ? "Hay�r" : (iMap.getString((String) key, i, "WS_FLAG").equals("W") ? "Web servis" : "D�� Entegrasyon"));
				map.put("CORE_SESSION_ID",iMap.getString((String) key, i, "CORE_SESSION_ID"));
				map.put("SERVER_IP",iMap.getString((String) key, i, "SERVER_IP"));
				map.put("CLIENT_IP",iMap.getString((String) key, i, "CLIENT_IP"));
				map.put("REQUEST",(iMap.getString((String) key, i, "IS_ERROR").equals("1")) ? iMap.getString((String) key, i, "REQUEST") : " ");
				map.put("RESPONSE",(iMap.getString((String) key, i, "IS_ERROR").equals("1")) ? iMap.getString((String) key, i, "RESPONSE") : " ");
				
				teamEmail = iMap.getString((String) key, i, "TEAM_EMAIL");
		        list.add(map);
			}
			logger.debug("prepareVelocityEmail mailBodyVariables list: " + list.toString());
	        VelocityContext context = new VelocityContext();
	        context.put("serviceList", list);

	        Template t = ve.getTemplate("servicelogMailTemplate.vm", encType);

	        StringWriter mailBody = new StringWriter();
	        t.merge(context, mailBody);

	        sendEmail(mailFrom, "Servicelog Bildirim ", mailBody.toString(), key.toString(), teamEmail);
		}
    }
	
	private static void sendEmail(String mailFrom, String mailSubject, String mailBody, String mailTo, String mailCC){
		try {
			GMMap mailServisMap = new GMMap();
			mailServisMap.put("MAIL_FROM", mailFrom);
			mailServisMap.put("MAIL_SUBJECT", mailSubject);
			mailServisMap.put("MAIL_BODY_CLOB", mailBody);
			mailServisMap.put("MAIL_TO", mailTo);
			mailServisMap.put("MAIL_CC", mailCC);
			mailServisMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailServisMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("REST_WEBSERVICES_LOG")
	public static GMMap restWebServicesLog(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			RestWebservicesLog restWebservicesLog = new RestWebservicesLog();
			restWebservicesLog.setSessionId(ADCSession.getSessionID());
			restWebservicesLog.setWebserviceName(iMap.getString("WEBSERVICE_NAME"));
			restWebservicesLog.setIsError(iMap.getBoolean("IS_ERROR"));
			restWebservicesLog.setBeginDate(new Timestamp(iMap.getLong("BEGIN_DATE")));
			restWebservicesLog.setEndDate(new Timestamp(iMap.getLong("END_DATE")));
			restWebservicesLog.setDuration(iMap.getBigDecimal("DURATION"));
			restWebservicesLog.setRequest((iMap.getString("REQUEST") != null ) ? new ClobImpl(iMap.getString("REQUEST")) : new ClobImpl(""));
			restWebservicesLog.setResponse((iMap.getString("RESPONSE") != null ) ? new ClobImpl(iMap.getString("RESPONSE")) : new ClobImpl(""));
			restWebservicesLog.setClientIp(iMap.getString("CLIENT_IP"));
			session.save(restWebservicesLog);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
