package tr.com.calikbank.bnspr.sms.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.integration.SubscriptionClient;
import tr.com.aktifbank.integration.webservices.simcard.SimcardClient;
import tr.com.aktifbank.integration.webservices.sms.OTPClient;
import tr.com.aktifbank.integration.webservices.sms.SMSClient;
import tr.com.aktifbank.integration.webservices.sms.SMSUtil;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.SmsLog;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.sms.Sender;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SmsServices extends Sender{

	private static Logger logger = Logger.getLogger(SmsServices.class);

	private static enum Status {
	    
	    DELIVERED("D"),
	    NOT_DELIVERED("N"),
	    WAITING("W"),
	    UNKNOWN("U");
	    
	    private final String coreValue;
	    
	    Status(String coreValue) {
	        this.coreValue = coreValue;
	    }
	
	}
    
  /**
   * Delivered: Cihaza iletildi
   * Submitted: Operat�re iletildi
   *   Expired: Zaman a��m�na u�rad�
   *   Waiting: Operat�re iletilmek �zere bekliyor
   * Cancelled: �letilemedi
   */
	private static enum OtpStatus {
	    
	    DELIVERED("Delivered", Status.DELIVERED),
	    SUBMITTED("Submitted", Status.WAITING),
	    EXPIRED("Expired", Status.NOT_DELIVERED),
	    WAITING("Waiting", Status.WAITING),
	    CANCELLED("Cancelled", Status.NOT_DELIVERED);
	    
	    private final String status;
	    private Status coreStatus;
	    
	    OtpStatus(String status, Status coreStatus) {
	        this.status = status;
	        this.coreStatus = coreStatus;
	    }
	    
	    static Status from(String status) {
	        for (OtpStatus value : values()) {
	            if (value.status.equals(status)) {
	                return value.coreStatus;
	            }
	        }
	        return Status.UNKNOWN;
	    }
	}
    
  /**
   * 1: ULA�TIRILDI
   * 2: ULA�TIRILAMADI 
   * 3: BEKLEMEDE
   * 4: RAPORLAMA �STENMED�
   * 5: GE�ERS�Z
   * 6: L�M�T YETERS�Z
   */
    private static enum BulkStatus {
        
        DELIVERED("1", Status.DELIVERED),
        NOT_DELIVERED("2", Status.NOT_DELIVERED),
        WAITING("3", Status.WAITING),
        NOT_REPORTED("4", Status.WAITING),
        NOT_VALID("5", Status.NOT_DELIVERED),
        LIMIT_ERROR("6", Status.NOT_DELIVERED);
        
        private final String status;
        private Status coreStatus;
        
        BulkStatus(String status, Status coreStatus) {
            this.status = status;
            this.coreStatus = coreStatus;
        }
        
        static Status from(String status) {
            for (BulkStatus value : values()) {
                if (value.status.equals(status)) {
                    return value.coreStatus;
                }
            }
            return Status.UNKNOWN;
        }
    }
        
	/**
	 * Bulk SMS Servisi
	 * Bu servis bulk sms gonderimleri icindir, erisim oncelikli degil, ayrica yurtdisi gondereim yetenegi yok
	 * 
	 * @author fatih.karakoc
	 * @param iMap
	 * 			MSISDN  - �rnek: 5334441100
	 * 			CONTENT - �rnek: Test123..
	 * 			HEADER	- Default deger Aktifbank
	 * 			FILTER	- Default deger true
	 * 			SECURE_CONTENT - Sms i�eri�inin g�sterilmemesi i�in
	 * 			IYS_MESSAGE_TYPE	 BILGILENDIRME veya TICARI degerlerini alir, gonderilmezse default BILGILENDIRME degeri kullanilir
	 * 			IYS_RECIPIENT_TYPE   BIREYSEL veya TACIR degerlerini alir. IYS_MESSAGE_TYPE TICARI degeri aldiginda gonderilmesi zorunludur
	 * 			IYS_BRAND_CODE  	 IYS_MESSAGE_TYPE TICARI ise zorunludur. Set edilmezse default Aktif Bank iys marka kodu ile gonderilir, diger markalar icin bu alanda ilgili kod gonderilmelidir
	 * @return
	 * 		  oMap
	 * 			RESULT - Codec web servisinden gelen d�n�� kodu
	 */

	@GraymoundService("BNSPR_SMS_SEND_BULK_SMS")
	public static GMMap sendSMS(GMMap iMap){
		GMMap oMap = new GMMap();
		String 		returnCode 	= "";
		long startTimeMillis = 0;
		boolean isRequestValid = false;
		String exceptionMsg = "";
		
		try{
			
			validate(iMap);
			
			isRequestValid = true;
			
			logger.info("Sending sms to " + iMap.getString("MSISDN"));
			
			boolean	secureContent = iMap.getBoolean("SECURE_CONTENT", false) ;
			iMap.put("MSISDN",  convertToInternationalFormat(iMap.getString("MSISDN")));
			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));
			
			String iysMessageType = iMap.getString("IYS_MESSAGE_TYPE");
			if( StringUtil.isEmpty(iysMessageType) ){
				iysMessageType = SMSUtil.IysMessageType.BILGILENDIRME.getValue();
			}
						
			startTimeMillis = System.currentTimeMillis();
			returnCode = SMSClient.sendSMS( iMap.getString("MSISDN"), 
											iMap.getString("CONTENT"), 
											iMap.getString("HEADER"),
											secureContent ? "NODISP_" : "",
											iMap.getBoolean("FILTER", false),
											iysMessageType,
											iMap.getString("IYS_RECIPIENT_TYPE"),
											iMap.getString("IYS_BRAND_CODE") );
			
			logger.info("Result is " + returnCode);
			
			iMap.putAll(oMap);
		}
		catch(Exception e){
			//throw ExceptionHandler.convertException(e);
			exceptionMsg = e.getLocalizedMessage();
			logger.error("SMS Servisinde hata : " + e.getMessage());
			oMap.put("RESPONSE", "0");
		}
		finally{
			long durationInMillis = 0;
			if(isRequestValid)
				durationInMillis = System.currentTimeMillis() - startTimeMillis;
			
			GMMap logMap = new GMMap(iMap);
			logMap.put("MESSAGE_TYPE", "SMS");			
			logMap.put("RESULT", !StringUtils.isEmpty(returnCode) ? returnCode : ("error:" + StringUtils.substring(exceptionMsg, 0, 240)));
			logMap.put("DURATION", durationInMillis);

			// log to db
			BigDecimal idNo = save(logMap);
			oMap.put("BNSPR_LOG_ID", idNo);
			oMap.put("RESULT", returnCode);
		}

		return oMap;
	}
	

	/**
	 * SMSClient ile g�nderilen mesajlar�n durumlar�n� sorgular.
	 *  
	 * @param iMap
	 *         SMS_REF_ID  sendSMS metodundan d�nen returnCode de�eri
	 * @return
	 *         RESPONSE    2: ba�ar�l� servis �a�r�s�
	 *                     0: ba�ar�s�z servis �a�r�s�
	 *         ERROR_CODE    -1: Kullan�c� bilgileri eksik veya hatal�
     *                      -14: Hen�z rapor dosyas� olu�turulmam�� 
     *                      -25: IP tan�ml� degil
     *                     -100: Ge�ersiz pSmsEuId
     *                        0: Hata yok
     *         STATUS       D: Delivered
     *                      N: Not Delivered
     *                      W: Waiting
     *                      U: Unknown
     *         MSISDN      Telefon numaras�
     *         DATE        Durum g�ncelleme tarihi
	 */
	@GraymoundService("BNSPR_SMS_GET_BULK_SMS_STATUS")
	public static GMMap getBulkSmsStatus(GMMap iMap) {
	    GMMap oMap = new GMMap();
	    try {
	        String smsEuId = iMap.getString("SMS_REF_ID") ;
	        String result = SMSClient.getSmsStatus(smsEuId);
	        String[] split = result.split("\\|");

	        if (split.length == 4) {
	            oMap.put("STATUS", BulkStatus.from(split[1]).coreValue);
	            oMap.put("ERROR_CODE", split[3]);
	        } else {
	            oMap.put("ERROR_CODE", result);
	        }
	        oMap.put("RESPONSE", "2");
	    }
	    catch (Exception e) {
	        logger.error("SMS Servisinde hata : " + e.getMessage());
	        oMap.put("RESPONSE", "0");
	    }
	    
	    return oMap;
	}
	
	/**
	 * Asenkron sms servisi, her uc tipte sms gonderim yapabilir(1:Sms,2:Fast Sms,3:Otp)
	 * 
	 * @author fatih.karakoc
	 * @param iMap
	 * 			MSISDN  - �rnek: 5334441100
	 * 			CONTENT - �rnek: Test123..
	 * 			MUSTERI_NO - M��teri Numaras�
	 * 			TRX_NO - ��lem numaras�
	 * 			FILTER	- Default deger false
	 * 			SECURE_CONTENT - Default deger false
	 * 			HEADER - Verilmezse default alfanumerik kullanilir
	 * 			MESSAGE_TYPE - 1:Sms 2:Fast Sms 3:Otp  (Default deger 2)
	 * @return
	 * 		  oMap (empty)
	 */
	@GraymoundService("BNSPR_SMS_SEND_SMS_ASYNC")
	public static GMMap sendSMSAsync(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		try{
			
			validate(iMap);
			
			logger.info("Sending sms to " + iMap.getString("MSISDN"));
			
			iMap.put("MSISDN",  convertToInternationalFormat(iMap.getString("MSISDN")));
			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_SMS.SEND_SMS(?,?,?,?,?,?,?,?)}");
			
			int index = 1;
			stmt.setString(index++,	iMap.getString("MSISDN"));
			stmt.setString(index++,	iMap.getString("CONTENT"));
			stmt.setBigDecimal(index++,	iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(index++,	iMap.getBigDecimal("TRX_NO"));
			stmt.setInt(index++, iMap.getBoolean("FILTER") ? 1 : 0);
			stmt.setInt(index++, iMap.getBoolean("SECURE_CONTENT") ? 1 : 0);
			stmt.setString(index++, iMap.getString("HEADER") );
			stmt.setInt(index++, iMap.getInt("MESSAGE_TYPE", 2)); //Default to fast sms
			stmt.execute();
			
		}
		catch(Exception e){
			logger.error("SMS Servisinde hata : " + e.getMessage());
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	
	/**
	 * Fast SMS Servisi(Cloud OTP altyapisini kullanir, otp servisinde tek farki blacklist/simchange kontrolu yapmamasidir)
	 * Yurtdisi gonderim yetenegi vardir
	 * 
	 * @author fatih.karakoc
	 * @param iMap
	 * 			MSISDN  - �rnek: 5334441100
	 * 			CONTENT - �rnek: Test123..
	 * 			HEADER	- Default deger Aktifbank
	 * 			FILTER	- Default deger true
	 *	 		SECURE_CONTENT - Sms i�eri�inin g�sterilmemesi i�in
	 * @return
	 * 		  oMap
	 * 			RESULT - Codec web servisinden gelen d�n�� kodu
	 */
	@GraymoundService("BNSPR_SMS_SEND_SMS")
	public static GMMap sendFastSMS(GMMap iMap){
		GMMap oMap = new GMMap();
		String[] result = null;
		long startTimeMillis = 0;
		boolean isRequestValid = false;
		String exceptionMsg = "";
		try{
			
			validate(iMap);
			
			isRequestValid = true;
			
			boolean	secureContent 	= iMap.getBoolean("SECURE_CONTENT", false);
			String	channel 		= iMap.getString("CHANNEL", "GNL");
			if(secureContent) {
				channel = "NODISP_" + channel;
			}
			
			iMap.put("MSISDN",  convertToInternationalFormat(iMap.getString("MSISDN")));			
			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));

			startTimeMillis = System.currentTimeMillis();

			result = OTPClient.sendOtpFast( iMap.getString("MSISDN"), iMap.getString("CONTENT"), channel, iMap.getString("HEADER"));

			oMap.put("RESPONSE", "2");
						
		}
		catch(Exception e){
			//throw ExceptionHandler.convertException(e);
			exceptionMsg = e.getLocalizedMessage();
			logger.error("Fast Sms servisinde hata (" + iMap.getString("MSISDN") +  ") : " + e.getMessage());
			oMap.put("RESPONSE", "0");
		}
		finally{
			long durationInMillis = 0;
			if(isRequestValid)
				durationInMillis = System.currentTimeMillis() - startTimeMillis;
			GMMap logMap = new GMMap(iMap);
			logMap.put("MESSAGE_TYPE", "FSMS");
			logMap.put("RESULT", (result != null) ? result[0] : ("error:" + StringUtils.substring(exceptionMsg, 0, 240)));
			logMap.put("SMS_REF_ID", (result != null) ? result[1] : "");
			logMap.put("DURATION", durationInMillis);

			// log to db
			BigDecimal idNo = save(logMap);
			oMap.put("BNSPR_LOG_ID", idNo);
			if(result != null){
				oMap.put("RESULT", result[1]);
				oMap.put("RESULT_CODE", StringUtils.contains(result[0],":") ? StringUtils.substringBefore(result[0],":") : result[0]);
			}else{
				oMap.put("RESULT", "");
				oMap.put("RESULT_CODE", "");				
			}
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_SMS_SEND_OTP")
	public static GMMap sendOTP(GMMap iMap){
		GMMap oMap = new GMMap();
		String[] result = null;
		long startTimeMillis = 0;
		boolean isRequestValid = false;
		String exceptionMsg = "";
		try{
			
			validate(iMap);
			
			isRequestValid = true;
			
			boolean	secureContent 	= iMap.getBoolean("SECURE_CONTENT", false);
			String	channel 		= iMap.getString("CHANNEL", "GNL");
			if(secureContent) {
				channel = "NODISP_" + channel;
			}
			
			iMap.put("MSISDN",  convertToInternationalFormat(iMap.getString("MSISDN")));			
			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));

			startTimeMillis = System.currentTimeMillis();

			result = OTPClient.sendOtp( iMap.getString("MSISDN"), iMap.getString("CONTENT"), channel, iMap.getString("HEADER"));

			oMap.put("RESPONSE", "2");
			
		}
		catch(Exception e){
			//throw ExceptionHandler.convertException(e);
			exceptionMsg = e.getLocalizedMessage();			
			logger.error("OTP servisinde hata (" + iMap.getString("MSISDN") +  ") : " + e.getMessage());
			oMap.put("RESPONSE", "0");
		}
		finally{
			long durationInMillis = 0;
			if(isRequestValid)
				durationInMillis = System.currentTimeMillis() - startTimeMillis;

			GMMap logMap = new GMMap(iMap);
			logMap.put("MESSAGE_TYPE", "OTP");
			logMap.put("RESULT", (result != null) ? result[0] : ("error:" + StringUtils.substring(exceptionMsg, 0, 240)));
			logMap.put("SMS_REF_ID", (result != null) ? result[1] : "");
			logMap.put("DURATION", durationInMillis);

			// log to db
			BigDecimal idNo = save(logMap);
			oMap.put("BNSPR_LOG_ID", idNo);
			if(result != null){
				oMap.put("RESULT", result[1]);
				oMap.put("RESULT_CODE", StringUtils.contains(result[0],":") ? StringUtils.substringBefore(result[0],":") : result[0]);
			}else{
				oMap.put("RESULT", "");
				oMap.put("RESULT_CODE", "");				
			}
		}
		
		return oMap;
	}
	   
    /**
     * OTPClient ile g�nderilen mesajlar�n durumlar�n� sorgular.
     *  
     * @param iMap
     *         SMS_REF_ID  sendOtp metodundan d�nen result[1] de�eri
     * @return
     *         RESPONSE     2: ba�ar�l� servis �a�r�s�
     *                      0: ba�ar�s�z servis �a�r�s�
     *         ERROR_CODE   6002: Raporu sorgulanacak Id bulunamad�
     *                        -1: Genel Sistem hatas� 
     *                      5010: Kullan�c� yetkilendirme hatas�
     *                         0: Hata yok
     *         STATUS       D: Delivered
     *                      N: Not Delivered
     *                      W: Waiting
     *                      U: Unknown
     */
    @GraymoundService("BNSPR_SMS_GET_OTP_SMS_STATUS")
    public static GMMap getOtpSmsStatus(GMMap iMap){
        GMMap oMap = new GMMap();
        try{
            String msgId = iMap.getString("SMS_REF_ID") ;
            String result = OTPClient.getSmsStatus(msgId);
            String[] split = result.split("\\|");
            String errorCode = split[0];
            
            if (errorCode.equals("0")) {
                oMap.put("STATUS", OtpStatus.from(split[1]).coreValue);
            }
            
            oMap.put("ERROR_CODE", errorCode);
            oMap.put("RESPONSE", "2");
        }
        catch(Exception e){
            logger.error("SMS Servisinde hata : " + e.getMessage());
            oMap.put("RESPONSE", "0");
        }
        
        return oMap;
    }

	@GraymoundService("BNSPR_SMS_SEND_OTP1")
	public static GMMap sendOTP1(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			boolean	secureContent 	= iMap.getBoolean("SECURE_CONTENT", false);
			String	channel 		= iMap.getString("CHANNEL", "GNL");
			if(secureContent) {
				channel = "NODISP_" + channel;
			}
			
			iMap.put("MSISDN",  convertToInternationalFormat(iMap.getString("MSISDN")));			
			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));

			OTPClient.sendOtpOp1( iMap.getString("MSISDN"), 
								  iMap.getString("CONTENT"),
								  channel,
								  iMap.getString("HEADER"));

			oMap.put("RESPONSE", "2");
			
		}
		catch(Exception e){
			//throw ExceptionHandler.convertException(e);
			logger.error("OTP servisinde hata : " + e.getMessage());
		}

		iMap.put("MESSAGE_TYPE", "OTP");
		// log to db
		BigDecimal idNo = save(iMap);
		oMap.put("BNSPR_LOG_ID", idNo);

		return oMap;
	}
	
	@GraymoundService("BNSPR_SMS_SEND_OTP2")
	public static GMMap sendOTP2(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			boolean	secureContent 	= iMap.getBoolean("SECURE_CONTENT", false);
			String	channel 		= iMap.getString("CHANNEL", "GNL");
			if(secureContent) {
				channel = "NODISP_" + channel;
			}
			
			iMap.put("MSISDN",  convertToInternationalFormat(iMap.getString("MSISDN")));	

			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));

			OTPClient.sendOtpOp2( iMap.getString("MSISDN"), 
								  iMap.getString("CONTENT"),
								  channel,
								  iMap.getString("HEADER"));
			
			oMap.put("RESPONSE", "2");
			
		}
		catch(Exception e){
			logger.error("OTP servisinde hata : " + e.getMessage());
			//throw ExceptionHandler.convertException(e);
		}

		iMap.put("MESSAGE_TYPE", "OTP");
		save(iMap);

		return oMap; 
	}
	
	/**
	 * This service is not used anymore
	 * 
	 * @param iMap
	 * 			MSISDN  - �rnek: 5334441100
	 * 			CONTENT - �rnek: Test123..
	 * 			LINK	- Mesaja eklenecek link
	 * 			HEADER	- Default deger Aktifbank
	 * 			FILTER	- Default deger true
	 *	 		SECURE_CONTENT - Sms i�eri�inin g�sterilmemesi i�in, true ise g�sterilmez. 
	 *							default degeri false.
	 * @return
	 * 		  oMap
	 * 			RESULT - Codec web servisinden gelen d�n�� kodu
	 */
	@GraymoundService("BNSPR_SEND_WAP_PUSH_MESSAGE")
	public static GMMap wapPush(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String 		returnCode 	= "";
			//This service is not used, so the code was disabled
			/*
			
			boolean	secureContent = iMap.getBoolean("SECURE_CONTENT", false) ;
			iMap.put("CONTENT", convertToStandartChars(iMap.getString("CONTENT")));
			returnCode = SMSClient.sendWapPushMessage(iMap.getString("MSISDN"), 
												iMap.getString("CONTENT"), 
												iMap.getString("HEADER"),
												iMap.getString("LINK"),
												secureContent ? "NODISP_" : "",
												iMap.getBoolean("FILTER", false));
			*/
			oMap.put("RESULT", returnCode);
			
			iMap.putAll(oMap);
			iMap.put("CONTENT", iMap.getString("CONTENT") + " : " + iMap.getString("LINK"));
		}
		catch(Exception e){
			//throw ExceptionHandler.convertException(e);
			logger.error("Wap Push servisinde hata : " + e.getMessage());			
		}

		iMap.put("MESSAGE_TYPE", "WAP");
		save(iMap);
		
		return oMap;
	}	
	
	@Override
	public void send(String phone, String message){
		GMMap iMap=new GMMap()
		.put("MSISDN",phone)
		.put("CONTENT",message);
		sendSMS(iMap);
	}
	
	private static BigDecimal save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SmsLog 	smsLog 	= new SmsLog();
			
			GMMap 	xMap 	= new GMMap().put("TABLE_NAME", "SMS_LOG");
			smsLog.setId( GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID") );
			smsLog.setMesaj(iMap.getString("CONTENT"));
			smsLog.setMesajTuru(iMap.getString("MESSAGE_TYPE"));
			smsLog.setSonuc(iMap.getString("RESULT"));
			smsLog.setTelNo(iMap.getString("MSISDN"));
			smsLog.setKanal(iMap.getString("CHANNEL"));
			smsLog.setBaslik(iMap.getString("HEADER"));
			smsLog.setSmsRefId(iMap.getString("SMS_REF_ID"));
			smsLog.setDuration(iMap.getBigDecimal("DURATION"));
			smsLog.setIysMsgType(iMap.getString("IYS_MESSAGE_TYPE"));
			smsLog.setIysRecipType(iMap.getString("IYS_RECIPIENT_TYPE"));
			smsLog.setIysBrandCode(iMap.getString("IYS_BRAND_CODE"));
			
			session.saveOrUpdate(smsLog);
			session.flush();
			return smsLog.getId();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static String convertToStandartChars(String str) {
		try {
			str = str.replace('�', 'i');	// (char)305
			str = str.replace('�', 'o');	// (char)246
			str = str.replace('�', 'u');	// (char)252
			str = str.replace('�', 'g');	// (char)287
			str = str.replace('�', 's');	// (char)251
			str = str.replace('�', 'c');	// (char)231
			str = str.replace('�', 'I');
			str = str.replace('�', 'O');
			str = str.replace('�', 'U');
			str = str.replace('�', 'G');
			str = str.replace('�', 'S');
			str = str.replace('�', 'C');
			return str;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static String convertToInternationalFormat(String phoneNumber) {
		if(phoneNumber!=null && phoneNumber.startsWith("+"))
			phoneNumber = "00" + phoneNumber.substring(1);
		return phoneNumber;
	}
    
    /**
     * @param iMap
     *          USER_NAME   : CallCenterUser, IVRUser
     *          MSISDN
     * @return
     *        oMap
     *          BLOCKED     : true if blocked, false otherwise
     */
    @GraymoundService("BNSPR_SMS_SIMCARD_GET_BLOCK_STATUS")
    public static GMMap getBlockStatus(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            String userName = iMap.getString("USER_NAME");
            String msisdn = iMap.getString("MSISDN");
            
            boolean simcardBlocked = SimcardClient.isSimcardBlocked(userName, msisdn);
            oMap.put("BLOCKED", simcardBlocked);
            oMap.put("CHANGE_DATE", SimcardClient.getSimcardUpdateDate(userName, msisdn));
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    /**
     * @param iMap
     *          USER_NAME   : CallCenterUser, IVRUser
     *          MSISDN
     *          MAKER       : Maker user
     *          CHECKER     : Checker user
     * @return
     *        oMap
     *          UPDATED     : true if data updated, false otherwise
     */
    @GraymoundService("BNSPR_SMS_SIMCARD_UNBLOCK")
    public static GMMap unblock(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            String userName = iMap.getString("USER_NAME");
            String msisdn = iMap.getString("MSISDN");
            String makerUser = iMap.getString("MAKER", "");
            String checkerUser = iMap.getString("CHECKER", "");
            
            boolean isUpdated = SimcardClient.unblockSimcard(userName, msisdn, makerUser, checkerUser);
            oMap.put("UPDATED", isUpdated);
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
	
    
	private static void validate(GMMap iMap) throws Exception {
		if(StringUtil.isEmpty(iMap.getString("MSISDN"))){
			throw new Exception("MSISDN value null");
		}
		if(StringUtil.isEmpty(iMap.getString("CONTENT"))){
			throw new Exception("CONTENT value null");
		}
		
		
	}
	
	
	@GraymoundService("BNSPR_ADD_SUBSCRIPTION")
	public static GMMap addSubscription(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			String	phone 		= iMap.getString("PHONE");
			String  prefix      = iMap.getString("PREFIX");
			String  tck 		= iMap.getString("TCK");
			String	key 		= iMap.getString("KEY");
			String	serviceCode = iMap.getString("SERVICE_CODE");
			
			String result = SubscriptionClient.addSubscriptionWithServiceCode(key, prefix, tck, phone, serviceCode);
			oMap.put("RESULT", result);
		}
		catch(Exception e){
			logger.error("Subscription servisinde hata : " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}
		return oMap; 
	}
	
}
