package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SchParametre;
import tr.com.aktifbank.bnspr.dao.SchParametreTx;
import tr.com.aktifbank.bnspr.dao.SchParametreTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9910Services {
	
	private static Logger log = Logger.getLogger(SystemTRN9910Services.class);

	@GraymoundService("BNSPR_TRN9910_GET_COMBO")
	public static GMMap getCombo(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("ADD_EMPTY_KEY", "H");
		iMap.put("KOD", "SCH_PARAMETRE_TUR");
		oMap.put("TUR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9910_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			String oldTableName = "OLD_LIST";
			int row = 0, oldRow = 0;
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				/*
				 * tx-e gore mevcut-liste cekilir
				 */
				List<?> list = session.createCriteria(SchParametreTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SchParametreTx schParametre = (SchParametreTx) iterator.next();
					
					oMap.put(tableName, row, "KOD", schParametre.getId().getKod());
					oMap.put(tableName, row, "ACK", schParametre.getAck());
					oMap.put(tableName, row, "TUR", schParametre.getTur());
					oMap.put(tableName, row, "FAIZ_ORANI", schParametre.getFaizOrani());
					oMap.put(tableName, row, "KULLANICI_FAIZ_ORANI", schParametre.getKullaniciFaizOrani());
					
					row++;
				}
				
				/*
				 * Eski tx-no bulunur
				 */
				BigDecimal oldTrxNo = getOncekiTxNo(trxNo);
				
				/*
				 * tx-e gore eski liste cekilir
				 */
				List<?> oldList = session.createCriteria(SchParametreTx.class).add(Restrictions.eq("id.txNo", oldTrxNo)).list();
				
				for (Iterator<?> iterator = oldList.iterator(); iterator.hasNext();) {
					SchParametreTx schParametre = (SchParametreTx) iterator.next();
					
					oMap.put(oldTableName, oldRow, "KOD", schParametre.getId().getKod());
					oMap.put(oldTableName, oldRow, "ACK", schParametre.getAck());
					oMap.put(oldTableName, oldRow, "TUR", schParametre.getTur());
					oMap.put(oldTableName, oldRow, "FAIZ_ORANI", schParametre.getFaizOrani());
					oMap.put(oldTableName, oldRow, "KULLANICI_FAIZ_ORANI", schParametre.getKullaniciFaizOrani());
					
					oldRow++;
				}
				
				/*
				 * eski ve yeni listeler karsilatirilir, renklendirme icin
				 */
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("KOD");
				keyColumns.add("ACK");
				keyColumns.add("TUR");
				keyColumns.add("FAIZ_ORANI");
				keyColumns.add("KULLANICI_FAIZ_ORANI");
				
				oMap.put("COLOR_LIST", BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(oldTableName), (ArrayList<?>) oMap.get(tableName), keyColumns).get("COLOR_DATA"));
				
			} else {//yoksa ana tablo uzerinden gelsin
				
				List<?> list = session.createCriteria(SchParametre.class).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SchParametre schParametre = (SchParametre) iterator.next();
					
					oMap.put(tableName, row, "KOD", schParametre.getKod());
					oMap.put(tableName, row, "ACK", schParametre.getAck());
					oMap.put(tableName, row, "TUR", schParametre.getTur());
					oMap.put(tableName, row, "FAIZ_ORANI", schParametre.getFaizOrani());
					oMap.put(tableName, row, "KULLANICI_FAIZ_ORANI", schParametre.getKullaniciFaizOrani());
					
					row++;
				}
				
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9910_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			
			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete SchParametreTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			/*
			 * tablo insert edilir
			 */
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				SchParametreTx schParametre = new SchParametreTx();
				
				//
				SchParametreTxId id = new SchParametreTxId();
				id.setTxNo(trxNo);
				id.setKod(iMap.getString(tableName, row, "KOD"));
				//
				
				schParametre.setId(id);
				schParametre.setAck(iMap.getString(tableName, row, "ACK"));
				schParametre.setTur(iMap.getString(tableName, row, "TUR"));
				schParametre.setFaizOrani(iMap.getBigDecimal(tableName, row, "FAIZ_ORANI"));
				schParametre.setKullaniciFaizOrani(iMap.getBigDecimal(tableName, row, "KULLANICI_FAIZ_ORANI"));
				
				session.saveOrUpdate(schParametre);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9910");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9910_GET_FAIZ_ORANI")
	public static GMMap getFaizOrani(GMMap iMap) {
		try {
			return iMap.put("FAIZ_ORANI", getFaizOrani(iMap.getString("TUR", "")));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9910_JOB")
	public static GMMap trn9910Job(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			String jobId = UUID.randomUUID().toString();
			log.info(jobId + " nolu job (trn_9910) basladi");

			/*
			 * sch parametre listesi cekiliyor
			 */
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(SchParametre.class).addOrder(Order.asc("kod")).list();

			log.info(jobId +  " nolu job (trn_9910) | islenecek sch parametre sayisi: " + list.size());
			
			/*
			 * sch parametreleri teker teker tur-e gore faiz orani cekilip update yapiliyor
			 */
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				SchParametre schParametre = (SchParametre) iterator.next();
				
				if (!"TC".equals(schParametre.getTur().substring(0, 2))) {//eger tur TCMB ise faiz orani hesaplamayalim, kullan�c� elle giris yapiyor
					schParametre.setFaizOrani(getFaizOrani(schParametre.getTur()));
					
					session.merge(schParametre);	
				}
			}

			log.info(jobId + " nolu job (trn_9910) bitti");
			
			return oMap;
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}
	
	private static BigDecimal getFaizOrani(String tur) {
		if (tur != null && !tur.isEmpty()) {//tur bos degilse
			if ("ON".equals(tur.substring(0, 2))) {//ilk 2 karakter 'ON' ise overnight
				/*
				 * ornek: ONTRYSPOT
				 */
				String dovizKodu = tur.substring(2, 5);//sonraki ilk 3 karakter doviz kodu
				String urunGrubu = tur.substring(5);//5. karakterden sonrasi urun grubu
				urunGrubu = "TRY".equals(dovizKodu) ? urunGrubu + " TL" : urunGrubu + " YP";//doviz koduna gore sonuna TL ve YP
				
				return getFaizOraniForOverNight(dovizKodu, urunGrubu);
				
			} else if ("LB".equals(tur.substring(0, 2))) {//ilk 2 karakter 'LB' ise libor
				/*
				 * ornek: LBTRY
				 */
				String dovizKodu = tur.substring(2, 5);//sonraki ilk 3 karakter doviz kodu
				
				return getFaizOraniForLibor(dovizKodu);
				
			} else if ("TC".equals(tur.substring(0, 2))) {//ilk 2 karakter 'TC' ise tcmb
				/*
				 * hesaplama yapmiyoruz, kullanici elle giris yapacak
				 */
				return BigDecimal.ZERO;
			}
		}
		
		return BigDecimal.ZERO;
	}
	
	private static BigDecimal getFaizOraniForOverNight(String dovizKodu, String urunGrubu) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			String sql = "select nvl(b.sc_faiz_orani, 0) faiz_orani from GNL_VADELI_SCF_ORANLARI b where b.tarih = pkg_global.get_bankatarih and b.vade_araligi = 'ON' and b.doviz_kodu = ? and b.scf_urun_grubu_kod = ? and rownum = 1";
			String listName = "RESULTS";
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(sql);
			stmt.setString(1, dovizKodu);
			stmt.setString(2, urunGrubu);
			
			rSet = stmt.executeQuery();
			GMMap results = DALUtil.rSetResults(rSet, listName);
			
			if (results.getSize(listName) == 1) {
				return results.getBigDecimal(listName, 0, "FAIZ_ORANI");
			} else {
				return BigDecimal.ZERO;
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static BigDecimal getFaizOraniForLibor(String dovizKodu) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			String sql = "select nvl(b.rate, 0) + 1 faiz_orani from gnl_libor_euribor b where b.value_date = pkg_global.get_bankatarih and b.faiz_endeks_kod = 'L' and b.period = 'ON' and b.currency = ? and rownum = 1";
			String listName = "RESULTS";
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(sql);
			stmt.setString(1, dovizKodu);
			
			rSet = stmt.executeQuery();
			GMMap results = DALUtil.rSetResults(rSet, listName);
			
			if (results.getSize(listName) == 1) {
				return results.getBigDecimal(listName, 0, "FAIZ_ORANI");
			} else {
				return BigDecimal.ZERO;
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static BigDecimal getOncekiTxNo(BigDecimal trxNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_9910(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, trxNo);
			stmt.execute();
			
			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
