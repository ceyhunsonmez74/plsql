package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.islBirimKod;
import tr.com.aktifbank.bnspr.dao.islBirimKodId;
import tr.com.aktifbank.bnspr.dao.islBirimKodTx;
import tr.com.aktifbank.bnspr.dao.islBolumKod;

import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * BPM_GROUP_ROLE services
 * 
 * @author samet.erkorkmaz
 *
 */
public class SystemTRN9812Services {
	
	@GraymoundService("BNSPR_TRN9812_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			islBirimKodTx birimKodTx =  (islBirimKodTx) session.createCriteria(islBirimKodTx.class).add(Restrictions.eq("txNo",  iMap.getBigDecimal("TRX_NO"))).uniqueResult();        
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

			if (birimKodTx.getDgs().equals("G")) {
				oMap.put("OPER_TYPE_G_D_S", "G");
				oMap.put("BOLUM_KOD", birimKodTx.getBolumKod());
				oMap.put("BOLUM_ADI", getBolumAdi(birimKodTx.getBolumKod()));
				oMap.put("KOD", birimKodTx.getBolumKod());
				oMap.put("ACIKLAMA", birimKodTx.getAciklama());
				return oMap;

			} else if (birimKodTx.getDgs().equals("S")) {
				oMap.put("OPER_TYPE_G_D_S", "S");
				oMap.put("BOLUM_KOD", "");
				oMap.put("BOLUM_ADI", "");
				oMap.put("KOD", "");
				oMap.put("ACIKLAMA", "");

				islBirimKod birimKod = ((islBirimKod) session.get(islBirimKod.class, new islBirimKodId(birimKodTx.getBolumKod(), birimKodTx.getKod())));
				return putObjToGMMap(birimKod, oMap);
			}
		} finally {
			session.close();
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(List<islBirimKod> birimKodList,GMMap oMap){
		int index=0;
		for(islBirimKod islBirimKod:birimKodList) {
			oMap.put("BIRIM_KOD_LIST", index, "BOLUM_KOD", islBirimKod.getId().getBolumKod());
			oMap.put("BIRIM_KOD_LIST", index, "BOLUM_ADI", getBolumAdi(islBirimKod.getId().getBolumKod()));
			oMap.put("BIRIM_KOD_LIST", index, "KOD", islBirimKod.getId().getKod());
			oMap.put("BIRIM_KOD_LIST", index, "ACIKLAMA", islBirimKod.getAciklama());
			index++;
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(islBirimKod birimKod,GMMap oMap){
		oMap.put("BIRIM_KOD_LIST", 0, "BOLUM_KOD", birimKod.getId().getBolumKod());
		oMap.put("BIRIM_KOD_LIST", 0, "BOLUM_ADI", getBolumAdi(birimKod.getId().getBolumKod()));
		oMap.put("BIRIM_KOD_LIST", 0, "KOD", birimKod.getId().getKod());
		oMap.put("BIRIM_KOD_LIST", 0, "ACIKLAMA", birimKod.getAciklama());
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN9812_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");	
		@SuppressWarnings("unchecked")
		List<islBirimKod> birimKodList = (List<islBirimKod>)session.createCriteria(islBirimKod.class).list();		
		return putObjToGMMap(birimKodList, oMap);
	}
	
	@GraymoundService("BNSPR_TRN9812_FILL_BOLUM_COMBO")
	public static GMMap fillGroupCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBolumKod> bolumKodList = (List<islBolumKod>)session.createCriteria(islBolumKod.class)
													.addOrder(Order.asc("kod")).list();
		for (islBolumKod bolumKod : bolumKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BOLUM", bolumKod.getKod().toString(), bolumKod.getAciklama());
		}
		return oMap;
	}

		
	@GraymoundService("BNSPR_TRN9812_SAVE")
	public static GMMap save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		islBirimKodTx birimKodTx = new islBirimKodTx();
		birimKodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birimKodTx.setAciklama(iMap.getString("ACIKLAMA"));
		birimKodTx.setBolumKod(iMap.getBigDecimal("BOLUM_KOD"));
		birimKodTx.setDgs("G");
		birimKodTx.setKod(BigDecimal.valueOf(Long.valueOf(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "ISL_BIRIM_KOD_TX")).getString("ID"))));
		birimKodTx.setLastModified(date);
		session.save(birimKodTx);
		session.flush();
		return callSendTrn(iMap);
	}
	@GraymoundService("BNSPR_TRN9812_UPDATE")
	public static GMMap update(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		islBirimKodTx birimKodTx = new islBirimKodTx();
		birimKodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birimKodTx.setAciklama(iMap.getString("ACIKLAMA"));
		birimKodTx.setBolumKod(iMap.getBigDecimal("BOLUM_KOD"));
		birimKodTx.setDgs("D");
		birimKodTx.setKod(iMap.getBigDecimal("KOD"));
		birimKodTx.setLastModified(date);
		session.save(birimKodTx);
		session.flush();
		return callSendTrn(iMap);
	}
	@GraymoundService("BNSPR_TRN9812_DELETE")
	public static GMMap delete(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		islBirimKodId id = new islBirimKodId();
		id.setBolumKod(iMap.getBigDecimal("BOLUM_KOD"));
		id.setKod(iMap.getBigDecimal("KOD"));		
		islBirimKod birimKod = (islBirimKod)session.get(islBirimKod.class, id);		

		islBirimKodTx birimKodTx = new islBirimKodTx();
		birimKodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birimKodTx.setBolumKod(birimKod.getId().getBolumKod());
		birimKodTx.setKod(birimKod.getId().getKod());
		birimKodTx.setDgs("S");
		birimKodTx.setAciklama(iMap.getString("BIRIM_ADI"));
		birimKodTx.setLastModified(date);
		session.save(birimKodTx);
		session.flush();
		return callSendTrn(iMap);
	}
	
	private static GMMap callSendTrn(GMMap iMap){
		iMap.put("TRX_NAME" , "9812");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
	
	
	private static String getBolumAdi(BigDecimal bolumKod){
		islBolumKod group = (islBolumKod) DAOSession.getSession("BNSPRDal").get(islBolumKod.class, bolumKod);
		return group.getAciklama();
	}

}
