package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9900Services {
	
	@GraymoundService("BNSPR_QRY9900_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			iMap.put("KOD", "EKRAN_KODLARI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("EKRAN_KODU_ADI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}

	

	
	@GraymoundService("BNSPR_QRY9900_GET_ISLEM_YETKI_KONTROLU")
	public static GMMap getIslemYetkiKontrolu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_rc9900.islem_yetki_kontrolu(?)}");
			int i = 1;
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.execute();
    		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_EKRAN_YETKI_VARMI")
	public static GMMap getEkranYetkiVarmi(GMMap iMap) {
			GMMap oMap = new GMMap();
			oMap.put("F_VAR", DALUtil.callOneParameterFunction("{? = call pkg_rc9900.ekran_yetki_varmi(?)}", Types.VARCHAR, iMap.getString("PROGRAM_KOD")));
			return oMap;
	 } 
		
}