package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.dao.VMlMuhIslemTanimPr;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9916Services {
	
	@GraymoundService("BNSPR_TRN9916_GET_PARAMETRE_TUR_MODEL_DATA")
	public static GMMap getParametreTurModelData(GMMap iMap){
	    String listName = "PARAMETRE_TIP"; 
        //GuimlUtil.wrapMyCombo(iMap, listName, null, " ");
        GuimlUtil.wrapMyCombo(iMap, listName, "V", "Varchar");
        GuimlUtil.wrapMyCombo(iMap, listName, "N", "Number");
        GuimlUtil.wrapMyCombo(iMap, listName, "D", "Date");
        GuimlUtil.wrapMyCombo(iMap, listName, "B", "Boolean");
        
           GuimlUtil.wrapMyCombo(iMap , "RESULTS" , null , " ");
           GuimlUtil.wrapMyCombo(iMap , "RESULTS" , "G" , "Giri�");
           GuimlUtil.wrapMyCombo(iMap , "RESULTS" , "D" , "D�zeltme");
           GuimlUtil.wrapMyCombo(iMap , "RESULTS" , "S" , "Silme");
        
        return iMap;
	}
	
	@GraymoundService("BNSPR_TRN9916_SAVE_ISLEM_TANIM")
	public static Map<?, ?> saveIslemTanim(GMMap iMap){
		/*GMMap xMap = new GMMap();*/
		try{
			checkNotNullField(iMap.getBigDecimal("KOD"), "'Kod' alan� bo� olamaz");
			checkNotNullField(iMap.getString("ACIKLAMA"), "'A��klama' alan� bo� olamaz");
			checkNotNullField(iMap.getString("ISLEM_TIPI"), "'��lem tipi' alan� bo� olamaz");
			checkNotNullField(iMap.getString("GERI_CEVRILEBILIR"), "'Geri �evrilebilir' alan� bo� olamaz");
			//checkNotNullField(iMap.getString("KISA_KOD"), "'K�sa Kod' alan� bo� olamaz");
			
			Session session = DAOSession.getSession("BNSPRDal");
		
			VMlMuhIslemTanimPr definedProcess = (VMlMuhIslemTanimPr)session.createCriteria(VMlMuhIslemTanimPr.class).add(Restrictions.eq("kisaKod", iMap.getString("KISA_KOD"))).uniqueResult();
			if(definedProcess != null){
				iMap.put("HATA_NO", "2303");
				iMap.put("P1", definedProcess.getKod());
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			VMlMuhIslemTanimPr islemTanimPr = new VMlMuhIslemTanimPr();
			islemTanimPr.setKod(iMap.getBigDecimal("KOD"));
			islemTanimPr.setAciklama(iMap.getString("ACIKLAMA"));
			islemTanimPr.setModulKodu(iMap.getString("MODUL_KODU"));
			islemTanimPr.setKisaKod(iMap.getString("KISA_KOD"));
			islemTanimPr.setIptalGunlukKontrol(iMap.getString("IPTAL_GUNLUK_KONTROL"));
			islemTanimPr.setBatchIslemMi(iMap.getString("BATCH_ISLEM_MI"));
			islemTanimPr.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			islemTanimPr.setMenudeListelensinMi(iMap.getString("MENUDE_LISTELENSIN_MI"));
			islemTanimPr.setIptalEdilebilirMi(iMap.getString("IPTAL_EDILEBILIR_MI"));
			islemTanimPr.setKupurKontrolu(iMap.getString("KUPUR_KONTROLU"));
			islemTanimPr.setSwiftMesajiGonderilsinMi(iMap.getString("SWIFT_MESAJI_GONDERILSIN_MI"));
			islemTanimPr.setGeriCevrilebilir(iMap.getString("GERI_CEVRILEBILIR"));
			islemTanimPr.setEkranAdi(iMap.getString("EKRAN_ADI"));

			session.save(islemTanimPr);
			session.flush();
			
        
	        String tableName = "PARAMETRE";
	        for (int row = 0; row < iMap.getSize(tableName); row++) {
	        	checkNotNullField(iMap.get(tableName, row, "KOD"), "Parametre 'Kod' alan� bo� olamaz");
	        	checkNotNullField(iMap.get(tableName, row, "ACIKLAMA"), "Parametre 'A��klama' alan� bo� olamaz");
	        	checkNotNullField(iMap.get(tableName, row, "TIP"), "Parametre 'Tip' alan� bo� olamaz");
	        	checkNotNullField(iMap.get(tableName, row, "DEGER"), "Parametre 'De�er' alan� bo� olamaz");
	        	
	        	GnlParametre parametre = new GnlParametre();
	        	
				iMap.put("TABLE_NAME", "GNL_PARAMETRE_NUMARA");
				parametre.setNumara(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", iMap).getBigDecimal("ID"));
				
	        	parametre.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
	        	parametre.setDeger(iMap.getString(tableName, row, "DEGER"));
	        	parametre.setKod(iMap.getString(tableName, row, "KOD"));
	        	parametre.setSira(iMap.getBigDecimal(tableName, row, "SIRA"));
	        	//parametre.setLastModified(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", xMap).getDate("BANKA_TARIH"));
	        	String strTip = iMap.getString(tableName, row, "TIP");
	        	if(strTip != null){
	        		if(strTip.length() > 1)
	        			parametre.setTip(strTip.charAt(0)+ "");
	        		else
	        			parametre.setTip(strTip);
	        	}
	        	
	        	parametre.setTur("T");
	        	session.save(parametre);
	        }
	        session.flush();
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r");
			
			return oMap;
			
		}catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	public static void checkNotNullField(Object field, String errorMessage){
		if(isEmptyOrNull(field))
			throw new GMRuntimeException(0, errorMessage);
	}
	
	public static boolean isEmptyOrNull(Object obj){
		if(obj == null)
			return true;
		else if(obj instanceof String)
			return obj.equals("");
		return false;
		
	}

	@GraymoundService("BNSPR_TRN9916_TEST_GMAP")
	public static GMMap getGMap(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			BigDecimal bd = iMap.getBigDecimal("NUMBER");
			oMap.put("NUMBER", bd);
		}
		catch(Exception  e){
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
}
