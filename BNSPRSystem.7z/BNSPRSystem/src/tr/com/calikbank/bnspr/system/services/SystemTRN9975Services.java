 package tr.com.calikbank.bnspr.system.services;

 
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.GnlDbyetkiTalepTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9975Services {
	
	@GraymoundService("BNSPR_TRN9975_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlDbyetkiTalepTx gnlDbyetkiTalepTx = (GnlDbyetkiTalepTx) session.get(GnlDbyetkiTalepTx.class, iMap
					.getBigDecimal("TRX_NO"));
			if (gnlDbyetkiTalepTx == null)
				gnlDbyetkiTalepTx = new GnlDbyetkiTalepTx();
			
			if(iMap.getString("KOD") == null || "".equals(iMap.getString("KOD")))
			{
			iMap.put("HATA_NO", new BigDecimal(330));
			      iMap.put("P1", "KOD");
			      return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			gnlDbyetkiTalepTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlDbyetkiTalepTx.setDbuser(iMap.getString("KOD"));
			gnlDbyetkiTalepTx.setEmail(iMap.getString("EMAIL"));
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date dt;
			String saat;
            if (StringUtils.isNotBlank(iMap.getString("BASLANGIC_TAR"))) {
                saat = iMap.getString("BASLANGIC_TAR_SAAT")==null?"000000":iMap.getString("BASLANGIC_TAR_SAAT");
                dt =
                    sdf.parse(sdf.format(iMap.getDate("BASLANGIC_TAR"))
                        .replaceAll("[0-9]{2}:[0-9]{2}:[0-9]{2}", saat.substring(0, 2) + ":" + saat.substring(2, 4) + ":" + saat.substring(4)));
                gnlDbyetkiTalepTx.setBaslangicTarihi(dt);
            }

            if (StringUtils.isNotBlank(iMap.getString("BITIS_TAR"))) {
                saat = iMap.getString("BITIS_TAR_SAAT")==null?"235900":iMap.getString("BITIS_TAR_SAAT");
                dt = sdf.parse(sdf.format(iMap.getDate("BITIS_TAR")).replaceAll("[0-9]{2}:[0-9]{2}:[0-9]{2}", saat.substring(0, 2) + ":" + saat.substring(2, 4) + ":" + saat.substring(4)));
                gnlDbyetkiTalepTx.setBitisTarihi(dt);
            }

            gnlDbyetkiTalepTx.setAciklama(iMap.getString("ACIKLAMA"));
			session.saveOrUpdate(gnlDbyetkiTalepTx);
			session.flush();

			iMap.put("TRX_NAME", "9975");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			 throw new GMRuntimeException(0,e);	
		}
	}
	
	@GraymoundService("BNSPR_TRN9975_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			GnlDbyetkiTalepTx gnlDbyetkiTalepTx = (GnlDbyetkiTalepTx) session.get(GnlDbyetkiTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HHmmss");
			oMap.put("TRX_NO", gnlDbyetkiTalepTx.getTxNo());
			oMap.put("DBUSER", gnlDbyetkiTalepTx.getDbuser());
			// oMap.put("EMAIL",DALUtil.getResult("select email from gnl_kullanici where kod in (select kod from gnl_kullanici_dbuser where dbuser = '"+gnlDbyetkiTalepTx.getDbuser()+"')"));
			oMap.put("BASLANGIC_TARIHI",gnlDbyetkiTalepTx.getBaslangicTarihi());
			oMap.put("BASLANGIC_TARIHI_SAAT", gnlDbyetkiTalepTx.getBaslangicTarihi()==null?null:sdf.format(gnlDbyetkiTalepTx.getBaslangicTarihi()).split(" ")[1]);
			oMap.put("BITIS_TARIHI",gnlDbyetkiTalepTx.getBitisTarihi());
            oMap.put("BITIS_TARIHI_SAAT", gnlDbyetkiTalepTx.getBitisTarihi()==null?null:sdf.format(gnlDbyetkiTalepTx.getBitisTarihi()).split(" ")[1]);
			oMap.put("ACIKLAMA", gnlDbyetkiTalepTx.getAciklama());
			oMap.put("EMAIL", gnlDbyetkiTalepTx.getEmail());
			
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN9975_GET_ISLEM_TARIHI")
	public static GMMap getIslemTarihi(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			String q = "select to_char(trunc(sysdate),'yyyymmdd') TARIH from   dual";

			stmt = conn.prepareCall(q);
			rSet = stmt.executeQuery();
			while (rSet.next()) {
				oMap.put("TARIH", rSet.getString("TARIH"));
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
	
	
}
