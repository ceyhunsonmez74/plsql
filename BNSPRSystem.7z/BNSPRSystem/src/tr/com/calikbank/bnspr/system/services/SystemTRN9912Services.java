package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlStopajOranlariTx;
import tr.com.calikbank.bnspr.dao.GnlStopajOranlariTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9912Services {
	@GraymoundService("BNSPR_TRN9912_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listStopajOran = (List<?>)session.createCriteria(GnlStopajOranlariTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for (Iterator<?> iterator = listStopajOran.iterator(); iterator
					.hasNext();) {
				GnlStopajOranlariTx gnlStopajOranlariTx = (GnlStopajOranlariTx)iterator.next();
				session.delete(gnlStopajOranlariTx);
			}
			session.flush();
			
			String tableName = "CBS_STOPAJ_ORANLARI_ISLEM";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlStopajOranlariTx gnlStopajOranlariTx = new GnlStopajOranlariTx();
				GnlStopajOranlariTxId gnlStopajOranlariTxId = new GnlStopajOranlariTxId();
				gnlStopajOranlariTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlStopajOranlariTxId.setDkGrupKod(iMap.getBigDecimal(tableName, row, "DK_GRUP_KOD"));
				gnlStopajOranlariTxId.setMahsupTuru(iMap.getString(tableName, row, "MAHSUP_TURU"));
				gnlStopajOranlariTx.setId(gnlStopajOranlariTxId);
				gnlStopajOranlariTx.setStopajOrani(iMap.getBigDecimal(tableName, row, "STOPAJ_ORANI"));
				
				session.saveOrUpdate(gnlStopajOranlariTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "9912");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9912_GET_STOPAJ_ORAN")
	public static GMMap getStopajOran(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn9912.mevcudu_yukle(?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

				stmt.execute();
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
				
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> list = session.createCriteria(GnlStopajOranlariTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "CBS_STOPAJ_ORANLARI_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlStopajOranlariTx gnlStopajOranlariTx = (GnlStopajOranlariTx)iterator.next();
				oMap.put(tableName, row, "DK_GRUP_KOD", gnlStopajOranlariTx.getId().getDkGrupKod());
				oMap.put(tableName, row, "MAHSUP_TURU", gnlStopajOranlariTx.getId().getMahsupTuru());
				oMap.put(tableName, row, "DK_GRUP_ACIKLAMA", LovHelper.diLov(gnlStopajOranlariTx.getId().getDkGrupKod(), "9912/LOV_DK_GRUP_KODU", "ACIKLAMA"));
				oMap.put(tableName, row, "STOPAJ_ORANI", gnlStopajOranlariTx.getStopajOrani());		
			}

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN9912_GET_STOPAJ_ORANLARI_LIST")
	public static GMMap getStopajOranlariList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session.createCriteria(GnlStopajOranlariTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			String tableName = "CBS_STOPAJ_ORANLARI_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlStopajOranlariTx gnlStopajOranlariTx = (GnlStopajOranlariTx) iterator.next();
				oMap.put(tableName, row, "DK_GRUP_KOD", gnlStopajOranlariTx.getId().getDkGrupKod());
				oMap.put(tableName, row, "DK_GRUP_ACIKLAMA", LovHelper.diLov(gnlStopajOranlariTx.getId().getDkGrupKod(), "9912/LOV_DK_GRUP_KODU", "ACIKLAMA"));
				oMap.put(tableName, row, "MAHSUP_TURU",  gnlStopajOranlariTx.getId().getMahsupTuru());
				oMap.put(tableName, row, "STOPAJ_ORANI",  gnlStopajOranlariTx.getStopajOrani());
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
