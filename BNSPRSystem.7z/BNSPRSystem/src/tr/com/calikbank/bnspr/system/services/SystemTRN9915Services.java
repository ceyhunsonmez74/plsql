package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlErisim;
import tr.com.calikbank.bnspr.dao.GnlErisimRol;
import tr.com.calikbank.bnspr.dao.GnlErisimRolTx;
import tr.com.calikbank.bnspr.dao.GnlErisimRolTxId;
import tr.com.calikbank.bnspr.dao.GnlErisimTx;
import tr.com.calikbank.bnspr.dao.GnlErisimTxId;
import tr.com.calikbank.bnspr.dao.GnlKullanici;
import tr.com.calikbank.bnspr.dao.GnlKullaniciTx;
import tr.com.calikbank.bnspr.dao.GnlRol;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.cs.aurora.rc.client.RC;
import tr.com.cs.aurora.rc.client.RCBag;
import tr.com.cs.aurora.rc.client.RCException;

import com.graymound.annotation.GraymoundService;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9915Services {
	public static SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
    @GraymoundService("BNSPR_TRN9915_GET_KULLANICI")
    public static Map<?, ?> getKullanici(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            GnlKullanici gnlKullanici = (GnlKullanici) session.createCriteria(GnlKullanici.class).add(Restrictions.eq("kod" , iMap.getString("KULLANICI_KODU"))).uniqueResult();
            
            oMap.put("KULLANICI_KODU" , gnlKullanici.getKod());
            oMap.put("PERSONEL_NUMARA" , gnlKullanici.getPersonelNumara());
            oMap.put("ADI" , gnlKullanici.getAd());
            oMap.put("SOYADI" , gnlKullanici.getSoyad());
            oMap.put("CALISILAN_BOLUM" , gnlKullanici.getBolumKod());
            oMap.put("CALISILAN_SUBE" , gnlKullanici.getSubeKod());
            oMap.put("GOREV_KODU" , gnlKullanici.getGorevKod());
            oMap.put("TUR" , gnlKullanici.getRolKod());
            oMap.put("EMAIL" , gnlKullanici.getEmail());
            oMap.put("KANAL_KODU" , gnlKullanici.getKanalKod());
            oMap.put("KANAL_ALT_KODU" , gnlKullanici.getKanalAltKod());
            oMap.put("KAPANMA_TARIHI" , gnlKullanici.getKapanmaTar());
            
            List<?> erisimList = session.createCriteria(GnlErisim.class).add(Restrictions.eq("id.kullaniciKodu" , iMap.getString("KULLANICI_KODU"))).list();
            String tableName = "ERISIM_LIST";
            int row = 0;
            for (Iterator<?> iterator = erisimList.iterator(); iterator.hasNext(); row++){
                GnlErisim gnlErisim = (GnlErisim) iterator.next();
                oMap.put(tableName , row , "SUBE_KODU" , gnlErisim.getId().getSubeKodu());
                
                GMMap aMap = new GMMap();
                aMap.put("SUBE_KODU" , gnlErisim.getId().getSubeKodu());
                oMap.put(tableName , row , "SUBE_ADI" ,LovHelper.diLov(gnlErisim.getId().getSubeKodu(), "9909/LOV_SUBE", "ADI"));
                oMap.put(tableName , row , "BASLANGIC_TARIHI" , gnlErisim.getBaslangicTarihi());
                oMap.put(tableName , row , "BITIS_TARIHI" , gnlErisim.getBitisTarihi());
            }
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN9915_GET_ERISIM_ROL")
    public static Map<?, ?> getErisimRol(GMMap iMap) {
        try{
            HashMap<String, Object> oMap = new HashMap<String, Object>();
            Object o = GMContext.getCurrentContext().getSession().get("ERR_" + iMap.getString("PAGE_ID") + iMap.getString("SUBE_KODU"));
            if (o != null){
                oMap.put("ERISIM_ROL_LIST" , o);
            } else{
                ArrayList<HashMap<String, Object>> rolOutList = new ArrayList<HashMap<String, Object>>();
                Session session = DAOSession.getSession("BNSPRDal");
                List<?> erisimRolList =
                        session.createCriteria(GnlErisimRol.class).add(Restrictions.eq("id.erisimKullaniciKodu" , iMap.getString("KULLANICI_KODU"))).add(
                                Restrictions.eq("id.subeKodu" , iMap.getString("SUBE_KODU"))).list();
                for (Iterator<?> iterator = erisimRolList.iterator(); iterator.hasNext();){
                    GnlErisimRol gnlErisimRol = (GnlErisimRol) iterator.next();
                    HashMap<String, Object> rowData = new HashMap<String, Object>();
                    rowData.put("ROL_NUMARA" , gnlErisimRol.getId().getRolNumara());
                    HashMap<String, Object> lovResultMap = LOVExecuter.execute("9909/LOV_ROL" , "NUMARA" , gnlErisimRol.getId().getRolNumara() + "" , new ArrayList<Object>());
                    if (lovResultMap != null)
                        rowData.put("ROL_ADI" , lovResultMap.get("TANIM"));
                    else rowData.put("ROL_ADI" , "");
                    rowData.put("BIT_TARIH" , gnlErisimRol.getBitisTarihi());
                    rowData.put("BAS_TARIH" , gnlErisimRol.getBaslangicTarihi());
                    
                    rolOutList.add(rowData);
                }
                oMap.put("ERISIM_ROL_LIST" , rolOutList);
            }
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @SuppressWarnings("null")
    @GraymoundService("BNSPR_TRN9915_GET_ERISIM_ROL_INFO")
    public static Map<?, ?> getErisimRolInfo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            
            Session session = DAOSession.getSession("BNSPRDal");

            Criterion rest1 = Restrictions.ne("GDS", "S");
            Criterion rest2 = Restrictions.isNull("GDS");
            
            List<?> erisimRolList =
                    session.createCriteria(GnlErisimRolTx.class).add(Restrictions.eq("id.erisimKullaniciKodu" , iMap.getString("KULLANICI_KODU"))).add(
                            Restrictions.eq("id.subeKodu" , iMap.getString("SUBE_KODU"))).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(Restrictions.or(rest1, rest2)).list();
            
            BigDecimal oldTx = getPreviousTx(iMap);
            oMap.put("KULLANICI_KODU" , iMap.get("KULLANICI_KODU"));
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_tx.Islem_tamamlanmis_mi(?)}");
            stmt.registerOutParameter(1 , Types.INTEGER);
            stmt.setBigDecimal(2 , oldTx);
            stmt.execute();
            int processCompleted = stmt.getInt(1);
            while (processCompleted != 0){
                oMap.put("TRX_NO" , oldTx);
                oldTx = getPreviousTx(oMap);
                stmt.setBigDecimal(2 , oldTx);
                stmt.execute();
                processCompleted = stmt.getInt(1);
                if("null".equals(String.valueOf(oldTx)))
                    processCompleted=0;
            }


            List<?> oldErisimRolList =
                    session.createCriteria(GnlErisimRolTx.class).add(Restrictions.eq("id.erisimKullaniciKodu" , iMap.getString("KULLANICI_KODU"))).add(
                            Restrictions.eq("id.subeKodu" , iMap.getString("SUBE_KODU"))).add(Restrictions.eq("id.txNo" , oldTx)).add(Restrictions.or(rest1, rest2)).list();
            
            String tableName = "NEW_ERISIM_ROL_LIST";
            int row = 0;
            for (Iterator<?> iterator = erisimRolList.iterator(); iterator.hasNext();){
                GnlErisimRolTx gnlErisimRol = (GnlErisimRolTx) iterator.next();
                oMap.put(tableName , row , "ROL_NUMARA" , gnlErisimRol.getId().getRolNumara());
                HashMap<String, Object> lovResultMap = LOVExecuter.execute("9909/LOV_ROL" , "NUMARA" , gnlErisimRol.getId().getRolNumara() + "" , new ArrayList<Object>());
                if (lovResultMap != null)
                    oMap.put(tableName , row , "ROL_ADI" , lovResultMap.get("TANIM"));
                else oMap.put(tableName , row , "ROL_ADI" , lovResultMap.get(""));
                
                oMap.put(tableName , row , "BAS_TARIH" , gnlErisimRol.getBaslangicTarihi());
                oMap.put(tableName , row , "BIT_TARIH" , gnlErisimRol.getBitisTarihi());
                row++;
            }
            
            String tableName2 = "OLD_ERISIM_ROL_LIST";
            int row2 = 0;
            for (Iterator<?> iterator = oldErisimRolList.iterator(); iterator.hasNext();){
                GnlErisimRolTx gnlErisimRol = (GnlErisimRolTx) iterator.next();
                oMap.put(tableName2 , row2 , "ROL_NUMARA" , gnlErisimRol.getId().getRolNumara());
                HashMap<String, Object> lovResultMap = LOVExecuter.execute("9909/LOV_ROL" , "NUMARA" , gnlErisimRol.getId().getRolNumara() + "" , new ArrayList<Object>());
                if (lovResultMap != null)
                    oMap.put(tableName2 , row2 , "ROL_ADI" , lovResultMap.get("TANIM"));
                else oMap.put(tableName2 , row2 , "ROL_ADI" , lovResultMap.get(""));
                
                oMap.put(tableName2 , row2 , "BAS_TARIH" , gnlErisimRol.getBaslangicTarihi());
                oMap.put(tableName2 , row2 , "BIT_TARIH" , gnlErisimRol.getBitisTarihi());
                row2++;
            }
            
            oMap.put("COLOR_DATA" , BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(tableName2) , (ArrayList<?>) oMap.get(tableName) , "ROL_NUMARA").get("COLOR_DATA"));
            
            mergeTables(oMap , "ERISIM_ROL_LIST" , tableName , tableName2 , "ROL_NUMARA" , "COLOR_DATA" , "ERISIM_ROL_LIST_COLOR_DATA");
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN9915_UPDATE")
    public static GMMap update(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            GnlKullaniciTx gnlKullaniciTx = (GnlKullaniciTx) session.get(GnlKullaniciTx.class , iMap.getBigDecimal("TRX_NO"));
            if (gnlKullaniciTx == null){
                gnlKullaniciTx = new GnlKullaniciTx();
                gnlKullaniciTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            }
            gnlKullaniciTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            gnlKullaniciTx.setKodu(iMap.getString("KULLANICI_KODU"));
            gnlKullaniciTx.setPersonelNumara(GuimlUtil.getTableCellBigDecimal(iMap.get("PERSONEL_NUMARA")));
            gnlKullaniciTx.setAdi(iMap.getString("ADI"));
            gnlKullaniciTx.setSoyadi(iMap.getString("SOYADI"));
            gnlKullaniciTx.setCalisilanBolum(iMap.getString("CALISILAN_BOLUM"));
            gnlKullaniciTx.setCalisilanSube(iMap.getString("CALISILAN_SUBE"));
            gnlKullaniciTx.setGorevKodu(iMap.getString("GOREV_KODU"));
            gnlKullaniciTx.setTur(iMap.getString("TUR"));
            gnlKullaniciTx.setEmail(iMap.getString("EMAIL"));
            gnlKullaniciTx.setKanalKod(iMap.getString("KANAL_KODU"));
            gnlKullaniciTx.setKanalAltKod(iMap.getString("KANAL_ALT_KODU"));
            gnlKullaniciTx.setKapanmaTar(iMap.getDate("KAPANMA_TARIHI"));
            
            session.saveOrUpdate(gnlKullaniciTx);
            
            List<?> erisimPersistenceList = session.createCriteria(GnlErisimTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            for (Iterator<?> iterator = erisimPersistenceList.iterator(); iterator.hasNext();){
                GnlErisimTx gnlErisimTx = (GnlErisimTx) iterator.next();
                session.delete(gnlErisimTx);
            }
            
            List<?> erisimRolPersistenceList = session.createCriteria(GnlErisimRolTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            for (Iterator<?> iterator = erisimRolPersistenceList.iterator(); iterator.hasNext();){
                GnlErisimRolTx gnlErisimRolTx = (GnlErisimRolTx) iterator.next();
                session.delete(gnlErisimRolTx);
            }
            session.flush();
            
            /*
             * List<?> erisimGuiList = (List<?>)iMap.get("CBS_ERISIM_ISLEM"); for (Iterator<?> erisimIterator =
             * erisimGuiList.iterator(); erisimIterator.hasNext();) { HashMap<?, ?> erisimRowData = (HashMap<?, ?>)
             * erisimIterator.next();
             */
            for (int i = 0; i < iMap.getSize("CBS_ERISIM_ISLEM"); i++){
                List<?> erisimRolList = (List<?>) GMContext.getCurrentContext().getSession().get("ERR_" + iMap.getString("PAGE_ID") + iMap.getString("CBS_ERISIM_ISLEM" , i , "SUBE_KODU"));
                if (erisimRolList == null){ // contextde yoksa database den
                    // getir.
                    erisimRolList =
                            session.createCriteria(GnlErisimRol.class).add(Restrictions.eq("id.erisimKullaniciKodu" , iMap.getString("KULLANICI_KODU"))).add(
                                    Restrictions.eq("id.subeKodu" , iMap.getString("CBS_ERISIM_ISLEM" , i , "SUBE_KODU"))).list();
                    for (Iterator<?> iterator = erisimRolList.iterator(); iterator.hasNext();){
                        GnlErisimRol erisimRol = (GnlErisimRol) iterator.next();
                        GnlErisimRolTx gnlErisimRolTx = new GnlErisimRolTx();
                        GnlErisimRolTxId gnlErisimRolTxId = new GnlErisimRolTxId();
                        gnlErisimRolTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                        gnlErisimRolTxId.setErisimKullaniciKodu(iMap.getString("KULLANICI_KODU"));
                        gnlErisimRolTxId.setRolNumara(GuimlUtil.getTableCellBigDecimal(erisimRol.getId().getRolNumara()));
                        gnlErisimRolTxId.setSubeKodu(iMap.getString("CBS_ERISIM_ISLEM" , i , "SUBE_KODU"));
                        gnlErisimRolTx.setId(gnlErisimRolTxId);
                        gnlErisimRolTx.setBaslangicTarihi(erisimRol.getBaslangicTarihi());
                        gnlErisimRolTx.setBitisTarihi(erisimRol.getBitisTarihi());
                        
                        checkRoleStatus(gnlErisimRolTxId.getRolNumara());
                        
                        session.save(gnlErisimRolTx);
                    }
                } else{
                    for (Iterator<?> iterator = erisimRolList.iterator(); iterator.hasNext();){
                        HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
                        GnlErisimRolTx gnlErisimRolTx = new GnlErisimRolTx();
                        GnlErisimRolTxId gnlErisimRolTxId = new GnlErisimRolTxId();
                        gnlErisimRolTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                        gnlErisimRolTxId.setErisimKullaniciKodu(iMap.getString("KULLANICI_KODU"));
                        gnlErisimRolTxId.setRolNumara(GuimlUtil.getTableCellBigDecimal(rowData.get("ROL_NUMARA")));
                        gnlErisimRolTxId.setSubeKodu(iMap.getString("CBS_ERISIM_ISLEM" , i , "SUBE_KODU"));
                        gnlErisimRolTx.setId(gnlErisimRolTxId);
                        gnlErisimRolTx.setBaslangicTarihi((Date) rowData.get("BAS_TARIH"));
                        gnlErisimRolTx.setBitisTarihi((Date) rowData.get("BIT_TARIH"));
                        
                        checkRoleStatus(gnlErisimRolTxId.getRolNumara());
                        
                        session.save(gnlErisimRolTx);
                    }
                }
                
                GnlErisimTx gnlErisimTx = new GnlErisimTx();
                GnlErisimTxId gnlErisimTxId = new GnlErisimTxId();
                
                gnlErisimTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                gnlErisimTxId.setKullaniciKodu(iMap.getString("KULLANICI_KODU"));
                gnlErisimTxId.setSubeKodu(iMap.getString("CBS_ERISIM_ISLEM" , i , "SUBE_KODU"));
                
                gnlErisimTx.setId(gnlErisimTxId);
                gnlErisimTx.setBaslangicTarihi(iMap.getDate("CBS_ERISIM_ISLEM" , i , "BASLANGIC_TARIHI"));
                gnlErisimTx.setBitisTarihi(iMap.getDate("CBS_ERISIM_ISLEM" , i , "BITIS_TARIHI"));
                
                session.save(gnlErisimTx);
            }
            session.flush();
            
            iMap.put("TRX_NAME" , "9915");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN9915_GET_INFO")
    public static Map<?, ?> getInfo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            GnlKullaniciTx gnlKullanici = (GnlKullaniciTx) session.createCriteria(GnlKullaniciTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            
            oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
            oMap.put("KULLANICI_KODU" , gnlKullanici.getKodu());
            oMap.put("PERSONEL_NUMARA" , gnlKullanici.getPersonelNumara());
            oMap.put("ADI" , gnlKullanici.getAdi());
            oMap.put("SOYADI" , gnlKullanici.getSoyadi());
            oMap.put("CALISILAN_BOLUM" , gnlKullanici.getCalisilanBolum());
            oMap.put("CALISILAN_SUBE" , gnlKullanici.getCalisilanSube());
            oMap.put("GOREV_KODU" , gnlKullanici.getGorevKodu());
            oMap.put("TUR" , gnlKullanici.getTur());
            oMap.put("EMAIL" , gnlKullanici.getEmail());
            oMap.put("KANAL_KODU" , gnlKullanici.getKanalKod());
            oMap.put("KANAL_ALT_KODU" , gnlKullanici.getKanalAltKod());
            oMap.put("KAPANMA_TARIHI" , gnlKullanici.getKapanmaTar());
            
             BigDecimal oldTx = getPreviousTx(oMap);
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_tx.Islem_tamamlanmis_mi(?)}");
            stmt.registerOutParameter(1 , Types.INTEGER);
            stmt.setBigDecimal(2 , oldTx);
            stmt.execute();
            int processCompleted = stmt.getInt(1);
            while (processCompleted != 0){
                oMap.put("TRX_NO" , oldTx);
                oldTx = getPreviousTx(oMap);
                stmt.setBigDecimal(2 , oldTx);
                stmt.execute();
                processCompleted = stmt.getInt(1);
                if("null".equals(String.valueOf(oldTx)))
                	processCompleted=0;
            } 
            
           // BigDecimal oldTx = gnlKullanici.getOncekiTxno();
            
            GnlKullaniciTx oldGnlKullanici = (GnlKullaniciTx) session.createCriteria(GnlKullaniciTx.class).add(Restrictions.eq("txNo" , oldTx)).uniqueResult();
            
            oMap.putAll(BeanSetProperties.reflectDifference(oldGnlKullanici , gnlKullanici , null , null));
            
            Criterion rest1 = Restrictions.ne("GDS", "S");
            Criterion rest2 = Restrictions.isNull("GDS");
            
            List<?> erisimList = session.createCriteria(GnlErisimTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(Restrictions.or(rest1, rest2)).list();
            
            List<?> oldErisimList = session.createCriteria(GnlErisimTx.class).add(Restrictions.eq("id.txNo" , oldTx)).add(Restrictions.or(rest1, rest2)).list();
            
            String tableName = "NEW_ERISIM_LIST";
            int row = 0;
            for (Iterator<?> iterator = erisimList.iterator(); iterator.hasNext(); row++){
                GnlErisimTx gnlErisim = (GnlErisimTx) iterator.next();
                oMap.put(tableName , row , "SUBE_KODU" , gnlErisim.getId().getSubeKodu());
                
                GMMap aMap = new GMMap();
                aMap.put("SUBE_KODU" , gnlErisim.getId().getSubeKodu());
                oMap.put(tableName , row , "SUBE_ADI" ,LovHelper.diLov(gnlErisim.getId().getSubeKodu(), "9909/LOV_SUBE", "ADI"));
                oMap.put(tableName , row , "BASLANGIC_TARIHI" , gnlErisim.getBaslangicTarihi());
                oMap.put(tableName , row , "BITIS_TARIHI" , gnlErisim.getBitisTarihi());
            }
            
            String tableName2 = "OLD_ERISIM_LIST";
            int row2 = 0;
            for (Iterator<?> iterator = oldErisimList.iterator(); iterator.hasNext(); row2++){
                GnlErisimTx gnlErisim = (GnlErisimTx) iterator.next();
                oMap.put(tableName2 , row2 , "SUBE_KODU" , gnlErisim.getId().getSubeKodu());
                
                GMMap aMap = new GMMap();
                aMap.put("SUBE_KODU" , gnlErisim.getId().getSubeKodu());
                oMap.put(tableName2 , row2 , "SUBE_ADI" ,LovHelper.diLov(gnlErisim.getId().getSubeKodu(), "9909/LOV_SUBE", "ADI"));
                oMap.put(tableName2 , row2 , "BASLANGIC_TARIHI" , gnlErisim.getBaslangicTarihi());
                oMap.put(tableName2 , row2 , "BITIS_TARIHI" , gnlErisim.getBitisTarihi());
            }
            
            oMap.put("COLOR_DATA" , BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(tableName2) , (ArrayList<?>) oMap.get(tableName) , "SUBE_KODU").get("COLOR_DATA"));
            
            mergeTables(oMap , "ERISIM_LIST" , tableName , tableName2 , "SUBE_KODU" , "COLOR_DATA" , "ERISIM_LIST_COLOR_DATA");
            oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN9915_AFTER_APPROVAL")
    public static GMMap afterApproval(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            List<?> list = (List<?>) session.createCriteria(GnlKullaniciTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("ISLEM_NO"))).list();

            boolean isCallCenterUser = false;

            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
            	GnlKullaniciTx gnlKullaniciTx = (GnlKullaniciTx) iterator.next();

            	if("5".equals(gnlKullaniciTx.getKanalKod())){
					isCallCenterUser = true;
				}
                                
                iMap.put("GIVEN_NAME" , gnlKullaniciTx.getAdi());
                iMap.put("SN" , gnlKullaniciTx.getSoyadi());
                iMap.put("CN" , gnlKullaniciTx.getAdi() + " " + gnlKullaniciTx.getSoyadi());
                iMap.put("UID" , gnlKullaniciTx.getKodu());
                iMap.put("MAIL" , gnlKullaniciTx.getEmail());
                boolean isLdapUser = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_BNSPR" , iMap).getBoolean("LDAP_USER");// LDAP_BNSPR
                if (isLdapUser){
                    GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_BNSPR" , iMap);// LDAP_BNSPR
                }
                                
                                
    			if(isCallCenterUser){
    				GMMap addToVbRequest = new GMMap();
    				addToVbRequest.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
    				
    				GMServiceExecuter.executeNT("NGCC_ADD_UPDATE_VB_AGENT_TASK_TO_SAF", addToVbRequest);
    			}

            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
    
    @GraymoundService("BNSPR_TRN9915_AFTER_APPROVAL_CS")
    public static GMMap afterApprovalCs(GMMap iMap) {
        try{
        	RCBag bag = (RCBag)iMap.get("CS_BAG");
            RC.execute(bag, "configuration/RemoteCaller.properties");
            
        } catch (RCException e){
            throw ExceptionHandler.convertException(e);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } 
        return new GMMap();
    }
    
    public static BigDecimal getPreviousTx(GMMap oMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            BigDecimal oldTx =
                    (BigDecimal) session.createCriteria(GnlKullaniciTx.class).add(Restrictions.lt("txNo" , oMap.getBigDecimal("TRX_NO"))).add(
                            Restrictions.eq("kodu" , oMap.getString("KULLANICI_KODU"))).setProjection(Projections.projectionList().add(Projections.max("txNo"))).uniqueResult();
            return oldTx;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    public static GMMap mergeTables(GMMap oMap, String mergedTable, String newTable, String oldTable, String keyColumn, String colorTable, String newColorTable) {
        
        int oldTableSize = oMap.get(oldTable) != null ? ((ArrayList<?>) oMap.get(oldTable)).size() : 0;
        int newTableSize = oMap.get(newTable) != null ? ((ArrayList<?>) oMap.get(newTable)).size() : 0;
        int oldRowCount = 0;
        int newRowCount = 0;
        int mergedRowCount = 0;
        
        while (oldTableSize != oldRowCount || newTableSize != newRowCount){
            
            if (oldRowCount < oldTableSize && newRowCount < newTableSize){
                GMMap oldRowMap = oMap.getMap(oldTable , oldRowCount);
                GMMap newRowMap = oMap.getMap(newTable , newRowCount);
                GMMap colorRowMap = oMap.getMap(colorTable , newRowCount);
                int compare = newRowMap.getBigDecimal(keyColumn).compareTo(oldRowMap.getBigDecimal(keyColumn));
                
                if (compare == 1){
                    oMap.put(mergedTable , mergedRowCount , oldRowMap);
                    for (Object key : oldRowMap.keySet()){
                        oMap.put(newColorTable , mergedRowCount , key.toString() , getDeletedTableCellColorData());
                    }
                    oldRowCount++;
                } else
                    if (compare == -1){
                        oMap.put(mergedTable , mergedRowCount , newRowMap);
                        oMap.put(newColorTable , mergedRowCount , colorRowMap);
                        newRowCount++;
                    } else{
                        // e�it
                        oMap.put(mergedTable , mergedRowCount , newRowMap);
                        oMap.put(newColorTable , mergedRowCount , colorRowMap);
                        oldRowCount++;
                        newRowCount++;
                    }
                
            } else
                if (oldRowCount == oldTableSize){
                    GMMap newRowMap = oMap.getMap(newTable , newRowCount);
                    GMMap colorRowMap = oMap.getMap(colorTable , newRowCount);
                    oMap.put(mergedTable , mergedRowCount , newRowMap);
                    oMap.put(newColorTable , mergedRowCount , colorRowMap);
                    newRowCount++;
                } else{
                    GMMap oldRowMap = oMap.getMap(oldTable , oldRowCount);
                    oMap.put(mergedTable , mergedRowCount , oldRowMap);
                    for (Object key : oldRowMap.keySet()){
                        oMap.put(newColorTable , mergedRowCount , key.toString() , getDeletedTableCellColorData());
                    }
                    oldRowCount++;
                }
            mergedRowCount++;
        }
        return oMap;
    }

	@GraymoundService("BNSPR_TRN9915_KULLANICI_KONTROL")
    public static Map<?, ?> getKayitKontrol (GMMap iMap){
    Connection conn         = null;
    CallableStatement stmt  = null;
    ResultSet rSet          = null;
    try {
        GMMap oMap = new GMMap();
        conn = DALUtil.getGMConnection();
        
        stmt = conn.prepareCall("{call PKG_TRN9915.sp_kullanici_kodu_kontrol(?) }");
        stmt.setString(1, iMap.getString("KOD"));
        
        stmt.execute();
        
        return oMap;
        
    }     
    
     catch (Exception e) {
        throw ExceptionHandler.convertException(e);
    } finally {
        GMServerDatasource.close(rSet);
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
    }
  }  
    private static GMMap getDeletedTableCellColorData() {
        GMMap oMap = new GMMap();
        oMap.put("setBackground" , new Color(100 , 149 , 237));
        return oMap;
    }
    
	public static Date setDateToStartOfDayDate(Date date) {
		String formatDate = null;
		Date formatedDate = null;
		try {

			if (date != null) {
				formatDate = formatter.format(date);
				if (formatDate != null)
					formatedDate = formatter.parse(formatDate);
				else
					formatedDate=date;
			}

			return formatedDate;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	public static Date getDateOfBank() {
	    GMMap iMap = new GMMap();
	    GMMap oMap = new GMMap();
	    Date dateOfBank;
		try {

			oMap = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap);
			 dateOfBank = oMap.getDate("BANKA_TARIH");

			return dateOfBank;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	public static void checkRoleStatus(BigDecimal roleNumber) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date dateOfBank = setDateToStartOfDayDate(getDateOfBank());
			
			List<GnlRol> roleList = (List<GnlRol>) session.createCriteria(GnlRol.class).add(Restrictions.eq("numara", roleNumber)).list();

			if (roleList.size() > 0) {
					GnlRol gnlRol = roleList.get(0);
					
					Date expireDate =  setDateToStartOfDayDate(gnlRol.getBitisTarihi());
					
					if ((expireDate != null) && (dateOfBank != null)) {
						if (!expireDate.after(dateOfBank)) {
							BigDecimal errCode = new BigDecimal(5640);
							   throw new GMRuntimeException(errCode.intValue(), getErrorText(errCode,roleNumber));
						}
					}
				
					
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static String getErrorText(BigDecimal errorCode,BigDecimal parameter) {
		GMMap errorIMap = new GMMap();
		String errorDescription = parameter.toString();

		errorIMap.put("MESSAGE_NO", errorCode);
		errorDescription =errorDescription.concat(GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", errorIMap).getString("ERROR_MESSAGE"));

		return errorDescription;

	}
}
