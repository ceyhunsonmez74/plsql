package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.islBirimKod;
import tr.com.aktifbank.bnspr.dao.islBirimKodId;
import tr.com.aktifbank.bnspr.dao.islBolumKod;
import tr.com.aktifbank.bnspr.dao.islServisKod;
import tr.com.aktifbank.bnspr.dao.islServisKodId;
import tr.com.aktifbank.bnspr.dao.islUserKod;
import tr.com.aktifbank.bnspr.dao.islUserKodTx;
import tr.com.aktifbank.bnspr.dao.islUserKodTxId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * BPM_GROUP_ROLE services
 * 
 * @author samet.erkorkmaz
 *
 */
public class SystemTRN9814Services {
	
	@GraymoundService("BNSPR_TRN9814_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int i=0;
		try {
			List<islUserKodTx> userKodTxList =  (List<islUserKodTx>) session.createCriteria(islUserKodTx.class).add(Restrictions.eq("id.txNo",  iMap.getBigDecimal("TRX_NO"))).list();        
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			for(islUserKodTx userKodTx: userKodTxList){
				oMap.put("USER_KOD_LIST",i,"KULLANICI_ADI",userKodTx.getAciklama());
				oMap.put("USER_KOD_LIST",i,"GDS",userKodTx.getDgs());
				oMap.put("USER_KOD_LIST",i,"BIRIM_KOD",userKodTx.getId().getBirimKod());
				oMap.put("USER_KOD_LIST",i,"BIRIM_ADI",getBirimAdi(userKodTx.getId().getBolumKod(), userKodTx.getId().getBirimKod()));
				oMap.put("USER_KOD_LIST",i,"BOLUM_KOD",userKodTx.getId().getBolumKod());
				oMap.put("USER_KOD_LIST",i,"BOLUM_ADI",getBolumAdi(userKodTx.getId().getBolumKod()));
				oMap.put("USER_KOD_LIST",i,"KULLANICI_KOD",userKodTx.getId().getUserKod());
				oMap.put("USER_KOD_LIST",i,"SERVIS_KOD",userKodTx.getId().getServisKod());
				oMap.put("USER_KOD_LIST",i,"SERVIS_ADI",getServisAdi(userKodTx.getId().getBolumKod(), userKodTx.getId().getBirimKod(), userKodTx.getId().getServisKod()));
				i=i+1;
			}
		} finally {
			session.close();
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(List<islUserKod> userKodList,GMMap oMap){
		int index=0;
		for(islUserKod userKod:userKodList) {
			oMap.put("USER_KOD_LIST", index, "BOLUM_KOD", userKod.getId().getBolumKod());
			oMap.put("USER_KOD_LIST", index, "BOLUM_ADI", getBolumAdi(userKod.getId().getBolumKod()));
			oMap.put("USER_KOD_LIST", index, "BIRIM_KOD", userKod.getId().getBirimKod());
			oMap.put("USER_KOD_LIST", index, "BIRIM_ADI", getBirimAdi(userKod.getId().getBolumKod(), userKod.getId().getBirimKod()));
			oMap.put("USER_KOD_LIST", index, "SERVIS_KOD", userKod.getId().getServisKod());
			oMap.put("USER_KOD_LIST", index, "SERVIS_ADI", getServisAdi(userKod.getId().getBolumKod(), userKod.getId().getBirimKod(), userKod.getId().getServisKod()));
			oMap.put("USER_KOD_LIST", index, "KULLANICI_KOD", userKod.getId().getUserKod());
			oMap.put("USER_KOD_LIST", index, "KULLANICI_ADI", userKod.getAciklama());
			
			index++;
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(islBirimKod birimKod,GMMap oMap){
		oMap.put("BIRIM_KOD_LIST", 0, "BOLUM_KOD", birimKod.getId().getBolumKod());
		oMap.put("BIRIM_KOD_LIST", 0, "BOLUM_ADI", getBolumAdi(birimKod.getId().getBolumKod()));
		oMap.put("BIRIM_KOD_LIST", 0, "KOD", birimKod.getId().getKod());
		oMap.put("BIRIM_KOD_LIST", 0, "ACIKLAMA", birimKod.getAciklama());
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN9814_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");	
		@SuppressWarnings("unchecked")
		List<islUserKod> islUserKodList = (List<islUserKod>)session.createCriteria(islUserKod.class).list();		
		
		return putObjToGMMap(islUserKodList, oMap);
	}
	
	@GraymoundService("BNSPR_TRN9814_FILL_BOLUM_COMBO")
	public static GMMap fillGroupCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBolumKod> bolumKodList = (List<islBolumKod>)session.createCriteria(islBolumKod.class)
													.addOrder(Order.asc("kod")).list();
		for (islBolumKod bolumKod : bolumKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BOLUM", bolumKod.getKod().toString(), bolumKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9814_FILL_BIRIM_COMBO")
	public static GMMap fillBirimCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBirimKod> birimKodList = (List<islBirimKod>)session.createCriteria(islBirimKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islBirimKod birimKod : birimKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BIRIM", birimKod.getId().getKod().toString(), birimKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9814_FILL_SERVIS_COMBO")
	public static GMMap fillServisCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islServisKod> servisKodList = (List<islServisKod>)session.createCriteria(islServisKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.add(Restrictions.eq("id.birimKod", iMap.getBigDecimal("BIRIM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islServisKod servisKod : servisKodList) {
			GuimlUtil.wrapMyCombo(oMap, "SERVIS", servisKod.getId().getKod().toString(), servisKod.getAciklama());
		}
		return oMap;
	}

		
	@GraymoundService("BNSPR_TRN9814_SAVE")
	public static GMMap save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		BigDecimal kod = BigDecimal.ZERO; 
		GMMap oMap = new GMMap();
		if (iMap.getSize("USER_KOD_LIST")>0){
			for (int i = 0; i < iMap.getSize("USER_KOD_LIST"); i++) {
				if(!StringUtil.isEmpty(iMap.getString("USER_KOD_LIST",i,"GDS"))){
					islUserKodTxId id = new islUserKodTxId();
					id.setUserKod(iMap.getString("USER_KOD_LIST",i,"KULLANICI_KOD"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBirimKod(iMap.getBigDecimal("USER_KOD_LIST",i,"BIRIM_KOD"));
					id.setBolumKod(iMap.getBigDecimal("USER_KOD_LIST",i,"BOLUM_KOD"));
					id.setServisKod(iMap.getBigDecimal("USER_KOD_LIST",i,"SERVIS_KOD"));
					islUserKodTx userKodTx = new islUserKodTx();
					userKodTx.setDgs(iMap.getString("USER_KOD_LIST",i,"GDS"));
					userKodTx.setId(id);
					userKodTx.setAciklama(iMap.getString("USER_KOD_LIST",i,"KULLANICI_ADI"));
					userKodTx.setLastModified(date);
					session.saveOrUpdate(userKodTx);
			}
		}
		
		session.flush();
		oMap = callSendTrn(iMap);
		}
		return oMap;
	}
		
	private static GMMap callSendTrn(GMMap iMap){
		iMap.put("TRX_NAME" , "9814");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
	
	
	private static String getBolumAdi(BigDecimal bolumKod){
		islBolumKod group = (islBolumKod) DAOSession.getSession("BNSPRDal").get(islBolumKod.class, bolumKod);
		return group.getAciklama();
	}
	private static String getBirimAdi(BigDecimal bolumKod, BigDecimal birimKod){
		islBirimKodId id = new  islBirimKodId();
		id.setBolumKod(bolumKod);
		id.setKod(birimKod);
		islBirimKod group = (islBirimKod) DAOSession.getSession("BNSPRDal").get(islBirimKod.class, id);
		return group.getAciklama();
	}
	private static String getServisAdi(BigDecimal bolumKod, BigDecimal birimKod, BigDecimal servisKod){
		islServisKodId id = new  islServisKodId();
		id.setBolumKod(bolumKod);
		id.setBirimKod(birimKod);
		id.setKod(servisKod);
		islServisKod group = (islServisKod) DAOSession.getSession("BNSPRDal").get(islServisKod.class, id);
		return group.getAciklama();
	}
}
