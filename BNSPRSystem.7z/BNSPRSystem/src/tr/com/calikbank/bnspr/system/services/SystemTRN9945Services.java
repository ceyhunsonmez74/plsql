package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlRolProgramTx;
import tr.com.aktifbank.bnspr.dao.GnlRolProgramTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlProgram;
import tr.com.calikbank.bnspr.dao.GnlRol;
import tr.com.calikbank.bnspr.dao.GnlRolProgram;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9945Services {
	
	private static final Color GREEN = new Color(153,255,0);
	
	@GraymoundService("BNSPR_PAR9945_GET_ROL_YETKI_LIST")
	public static GMMap getRolYetkiList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "ROL_YETKI";
			GnlProgram selectedProgram = SystemPAR9924Services.findProgram(iMap.getString("PROGRAM_KOD"));
			if(selectedProgram != null){
				List<?> rolPersistenceList = session.createCriteria(GnlRol.class).list();
				for (int i = 0; i < rolPersistenceList.size(); i++) {
					GnlRol rol = (GnlRol)rolPersistenceList.get(i);
					oMap.put(tableName, i, "ROL_NUMARA", rol.getNumara());
					oMap.put(tableName, i, "ROL_TANIM", rol.getTanim());
					GnlRolProgram rolProgram = SystemPAR9924Services.findRolProgram(rol.getNumara(), iMap.getString("PROGRAM_KOD"));
					if(rolProgram != null)
						oMap.put(tableName, i, "YETKI", GuimlUtil.convertToCheckBoxValue("E"));
					else
						oMap.put(tableName, i, "YETKI", GuimlUtil.convertToCheckBoxValue("H"));
				}
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9945_SAVE_ROL_YETKI")
	public static GMMap saveRolYetki(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "ROL_YETKI";
			List<?> recordList = (List<?>)iMap.get(tableName);
			for(int i = 0; i < recordList.size(); i++) {
				GnlRolProgramTx rolProgramTx = new GnlRolProgramTx();
				GnlRolProgramTxId id = new GnlRolProgramTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setProgramKod(iMap.getString("PROGRAM_KOD"));
				id.setRolNumara(iMap.getBigDecimal(tableName, i, "ROL_NUMARA"));
				rolProgramTx.setId(id);
				GnlRolProgram rolProgram = SystemPAR9924Services.findRolProgram(id.getRolNumara(), id.getProgramKod());
				//Isaretli ve tabloda yoksa -> Eklendi 'E'
				if("1".equals(iMap.getString(tableName, i, "YETKI")) && rolProgram == null) {
					rolProgramTx.setFEklendi("E");
				}
				//Isaretsiz ve tabloda varsa -> Silindi 'E'
				else if("0".equals(iMap.getString(tableName, i, "YETKI")) && rolProgram != null){
						rolProgramTx.setFSilindi("E");
				}
				session.saveOrUpdate(rolProgramTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "9945");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9945_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = (List<?>) session.createCriteria(GnlRolProgramTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "ROL_YETKI";
			String colorTable = "ROL_YETKI_COLOR_DATA";
			String programKodu = "";
			for (int row = 0; row < list.size(); row++){
				GnlRolProgramTx gnlRolProgramTx = (GnlRolProgramTx) list.get(row);
				oMap.put(tableName, row, "ROL_NUMARA", gnlRolProgramTx.getId().getRolNumara());
				oMap.put(tableName, row, "ROL_TANIM", LovHelper.diLov(gnlRolProgramTx.getId().getRolNumara(), "9945P/LOV_ROL", "TANIM"));
				programKodu = gnlRolProgramTx.getId().getProgramKod();
				
				GnlRolProgram rolProgram = SystemPAR9924Services.findRolProgram(gnlRolProgramTx.getId().getRolNumara(), programKodu);
				if(rolProgram != null && !"E".equals(gnlRolProgramTx.getFSilindi())){
					oMap.put(tableName, row, "YETKI", true);
				}else if (("E").equals(gnlRolProgramTx.getFEklendi())){
					oMap.put(tableName, row, "YETKI", true);
				}
				else{
					oMap.put(tableName, row, "YETKI", false);
				}
					
				//Renk tablosu
				oMap.put(colorTable, row, "ROL_NUMARA", getTableCellColorData("setBackground", Color.WHITE));
				oMap.put(colorTable, row, "ROL_TANIM", getTableCellColorData("setBackground", Color.WHITE));
				if(gnlRolProgramTx.getFEklendi() != null || gnlRolProgramTx.getFSilindi() != null){
					oMap.put(colorTable, row, "YETKI", getTableCellColorData("setBackground", GREEN));
				}
				else{
					oMap.put(colorTable, row, "YETKI", getTableCellColorData("setBackground", Color.WHITE));
				}

			}
			oMap.put("TRX_NO",iMap.getBigDecimal("TRX_NO"));
			oMap.put("PROGRAM_KODU",programKodu);
			oMap.put("PROGRAM_ADI",LovHelper.diLov(programKodu, "9945P/LOV_PROGRAM", "ADI"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static GMMap getTableCellColorData(String property, Color color){
		GMMap oMap = new GMMap();
		oMap.put(property, color);
		return oMap;
	}
}
