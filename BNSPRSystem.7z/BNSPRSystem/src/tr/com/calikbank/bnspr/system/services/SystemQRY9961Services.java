package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class SystemQRY9961Services {

	@GraymoundService("BNSPR_PAYGATE_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			String func="{? = call PKG_RC9961.RC_PAYGATE_ISLEMLER(?,?,?,?,?)}";
			Object[] inputValues = new Object[10];
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.get("ARAMA_KAYIT_TARIHI") != null ? iMap.getDate("ARAMA_KAYIT_TARIHI"):null ;
			inputValues[2] = BnsprType.DATE;
			inputValues[3] = iMap.get("ARAMA_KAYIT_TARIHI2") != null ? iMap.getDate("ARAMA_KAYIT_TARIHI2"):null ;
			inputValues[4] = BnsprType.NUMBER;
			inputValues[5] = iMap.getBigDecimal("TRX_NO");
			inputValues[6] = BnsprType.NUMBER;
			inputValues[7] = iMap.getBigDecimal("ISLEM_KODU");
			inputValues[8] = BnsprType.STRING;
			inputValues[9] = iMap.getString("DURUM_KODU");
			String tableName = "RESULTS";
			oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			
			oMap.put("ROW_COUNT", oMap.getSize(tableName));

			return oMap;
		} catch (Exception e) {
			 throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
        }
	}
	
	
	
	
}
