package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.VMlGnlProgram;
import tr.com.calikbank.bnspr.dao.VMlMuhIslemTanimPr;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9923Services {
	@GraymoundService("BNSPR_PAR9923_GET_PROGRAM_TANIM")
	public static Map<?,?> getLimitTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listProgram = (List<?>) session.createCriteria(VMlGnlProgram.class).list();
			String tableName = "PROGRAM_TANIM";
			int row = 0;
			for (Iterator<?> iterator = listProgram.iterator(); iterator.hasNext(); row++) {
				VMlGnlProgram vMlGnlProgram = (VMlGnlProgram) iterator.next();
				oMap.put(tableName, row, "ADI", vMlGnlProgram.getAdi());
				oMap.put(tableName, row, "KISA_KOD", vMlGnlProgram.getKisaKod());
				oMap.put(tableName, row, "KOD", vMlGnlProgram.getKod());
				oMap.put(tableName, row, "MENUDE_LISTELENSIN_MI", GuimlUtil.convertToCheckBoxValue(vMlGnlProgram.getMenudeListelensinMi()));
				oMap.put(tableName, row, "MODUL_TUR_KOD", vMlGnlProgram.getModulTurKod());
				oMap.put(tableName, row, "TUR", vMlGnlProgram.getTur());
				oMap.put(tableName, row, "ICON_NAME", vMlGnlProgram.getIconName());
				oMap.put(tableName, row, "SIRA", vMlGnlProgram.getSira());
				oMap.put(tableName, row, "SHORT_CUT_KEY", vMlGnlProgram.getShortCutKey());
			}

			return oMap;
		}catch(Exception e){
			throw new GMRuntimeException(0,e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR9923_SAVE_PROGRAM_TANIM")
	public static Map<?,?> saveLimitTanim(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "PROGRAM_LIST";
			List<?> listPersistentUlke = (List<?>) session.createCriteria(VMlGnlProgram.class).list();
			for (Iterator<?> iterator = listPersistentUlke.iterator(); iterator.hasNext();) {
				VMlGnlProgram vMlGnlProgram = (VMlGnlProgram) iterator.next();
				if(!GuimlUtil.contains(iMap, tableName, "KOD", vMlGnlProgram.getKod()))
					session.delete(vMlGnlProgram);
			}
			session.flush();
			
			GMMap codeControlMap = new GMMap();
			for(int row = 0; row < iMap.getSize(tableName); row++){
				VMlGnlProgram vMlGnlProgram = findProgram(iMap.getString(tableName, row, "KOD"));
				if(vMlGnlProgram == null){
					vMlGnlProgram = new VMlGnlProgram();
				}
				Validator.checkNull(iMap.getString(tableName, row, "KOD"), "KOD alan� bo� olmaz");
				Validator.checkNull(iMap.getString(tableName, row, "ADI"), "AD alan� bo� olmaz");
				//Validator.checkNull(iMap.getString(tableName, row, "KISA_KOD"), "K�sa kod alan� bo� olmaz");
				
				if( codeControlMap.get(iMap.getString(tableName, row, "KISA_KOD")) == null ){
					codeControlMap.put(iMap.getString(tableName, row, "KISA_KOD"), iMap.getString(tableName, row, "KOD"));
				}else{
					
					List<VMlGnlProgram> controlPrograms = session.createCriteria(VMlGnlProgram.class).add(Restrictions.eq("kisaKod", iMap.getString(tableName, row, "KISA_KOD"))).list();

					for(VMlGnlProgram controlProgram : controlPrograms){
						iMap.put("P1", iMap.getString("P1") != null ? iMap.getString("P1") + "," + controlProgram.getKod() : controlProgram.getKod());
					}

					if(iMap.getString("P1") != null){
						iMap.put("HATA_NO", "2303");
						GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					
				}
				
				List<VMlMuhIslemTanimPr> definedProcesses = session.createCriteria(VMlMuhIslemTanimPr.class).add(Restrictions.eq("kisaKod", iMap.getString(tableName, row, "KISA_KOD"))).list();
				
				for(VMlMuhIslemTanimPr definedProcess : definedProcesses){
					iMap.put("P1", iMap.getString("P1") != null ? iMap.getString("P1") + "," + definedProcess.getKod() : definedProcess.getKod());
				}
				
				if(iMap.getString("P1") != null){
					iMap.put("HATA_NO", "2303");
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				vMlGnlProgram.setAdi(iMap.getString(tableName, row, "ADI"));
				vMlGnlProgram.setKisaKod(iMap.getString(tableName, row, "KISA_KOD"));
				vMlGnlProgram.setKod(iMap.getString(tableName, row, "KOD"));
				vMlGnlProgram.setMenudeListelensinMi(iMap.getString(tableName, row, "MENUDE_LISTELENSIN_MI"));
				vMlGnlProgram.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
				vMlGnlProgram.setTur(iMap.getString(tableName, row, "TUR"));
				vMlGnlProgram.setIconName(iMap.getString(tableName, row, "ICON_NAME"));
				vMlGnlProgram.setShortCutKey(iMap.getString(tableName, row, "SHORT_CUT_KEY"));
				vMlGnlProgram.setSira(iMap.getBigDecimal(tableName, row, "SIRA"));
				session.save(vMlGnlProgram);
			}
			
			session.flush();
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", "��leminiz tamamland�!");
			return oMap;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static VMlGnlProgram findProgram(String kod){
		return (VMlGnlProgram)DAOSession.getSession("BNSPRDal").get(VMlGnlProgram.class, kod);
	}

}
