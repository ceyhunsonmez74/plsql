 package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlScfUrunGrubu;
import tr.com.aktifbank.bnspr.dao.GnlScfUrunGrubuTx;
import tr.com.aktifbank.bnspr.dao.GnlScfUrunGrubuUrunTx;
import tr.com.aktifbank.bnspr.dao.GnlScfUrunGrubuUrunTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisMarkalarTx;
import tr.com.calikbank.bnspr.dao.GnlErisim;
import tr.com.calikbank.bnspr.dao.GnlKullaniciTx;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9942Services {
    
    @GraymoundService("BNSPR_QRY9942_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBoxInitialValues(GMMap iMap){
        try{
            GMMap oMap = new GMMap();
            iMap.put("KOD", "SCH_MODUL_TUR");
            iMap.put("ADD_EMPTY_KEY", "H");
            oMap.put("URUN_GRUP_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
            return oMap;
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } 
    }
    
    
    @GraymoundService("BNSPR_QRY9942_GET_URUN_GRUP_BILGI")
    public static Map<?, ?> getScfOranBilgi(GMMap iMap){
        try{
            GMMap oMap = new GMMap();
            Connection conn = null;
            CallableStatement stmt = null;
            try{
                conn = DALUtil.getGMConnection();
                
                stmt = conn.prepareCall("{? = call PKG_TRN9942.RC_9942_Get_Data(?)}");  
                stmt.registerOutParameter(1, -10);
                stmt.setString(2, iMap.getString("URUN_GRUP_LOV"));
                stmt.execute();
                String tableName = "TBL_URUN_LIST";
                ResultSet rSet = (ResultSet)stmt.getObject(1);
                oMap = DALUtil.rSetResults(rSet, tableName);
                
                    
            }catch (Exception e) {
                throw new GMRuntimeException(0,e);
            }finally{
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }

            return oMap;
            
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }
    }
    
    
    @GraymoundService("BNSPR_TRN9942_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            Object kod = new Object();
            
            if (!iMap.getString("URUN_GRUP_TEXT").isEmpty()) 
                kod = iMap.getString( "URUN_GRUP_TEXT");
            
            if (!iMap.getString("URUN_GRUP_LOV").isEmpty()) 
                kod = iMap.getString( "URUN_GRUP_LOV");
            
            
            if (!saveControlField(kod)) {
                iMap.put("HATA_NO", new BigDecimal(330));
                iMap.put("P1", "Urun grubu kod");
                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
                //throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
                
                
            }
            
            if (!saveControlField(iMap.getString("ACIKLAMA"))) {
                iMap.put("HATA_NO", new BigDecimal(330));
                iMap.put("P1", "Aciklama");
                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            
            
            
            /*List<?> urunGrupList = (List<?>)session.createCriteria(GnlScfUrunGrubu.class).add(Restrictions.eq("kod", iMap.getString("URUN_GRUP_LOV"))).list();
            
            for (Iterator<?> iterator = urunGrupList.iterator(); iterator.hasNext();) {
                GnlScfUrunGrubuTx gnlScfUrunGrubuTx = (GnlScfUrunGrubuTx)iterator.next();
                session.delete(gnlScfUrunGrubuTx);
            }
                        
            session.flush();*/

            
            
            GnlScfUrunGrubuTx gnlScfUrunGrubuTx = new GnlScfUrunGrubuTx();
            
            gnlScfUrunGrubuTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            gnlScfUrunGrubuTx.setKod( kod.toString() );
            gnlScfUrunGrubuTx.setAciklama(iMap.getString( "ACIKLAMA"));
            gnlScfUrunGrubuTx.setTur(iMap.getString("URUN_GRUP_TUR"));
            gnlScfUrunGrubuTx.setIslemTur(iMap.getString("ISLEM_TUR"));
            
            session.saveOrUpdate(gnlScfUrunGrubuTx);
            
            String tableName = "TBL_URUN_LIST";
        
            for (int row = 0; row < iMap.getSize(tableName); row++) {
                
                GnlScfUrunGrubuUrunTx gnlScfUrunGrubuUrun = new GnlScfUrunGrubuUrunTx();
                GnlScfUrunGrubuUrunTxId gnlScfUrunGrubuUrunId = new GnlScfUrunGrubuUrunTxId();
                
                gnlScfUrunGrubuUrunId.setTxNo               (iMap.getBigDecimal("TRX_NO"));
                gnlScfUrunGrubuUrunId.setSiraNo             (new BigDecimal(row));
                
                gnlScfUrunGrubuUrun.setId(gnlScfUrunGrubuUrunId);
                gnlScfUrunGrubuUrun.setKod              (gnlScfUrunGrubuTx.getKod());
                gnlScfUrunGrubuUrun.setModulTurKod      (iMap.getString(tableName, row, "COL_MODUL_TUR"));
                gnlScfUrunGrubuUrun.setUrunTurKod       (iMap.getString(tableName, row, "COL_URUN_TUR"));
                gnlScfUrunGrubuUrun.setUrunSinifKod     (iMap.getString(tableName, row, "COL_URUN_SINIF"));
                
                                            
                session.saveOrUpdate(gnlScfUrunGrubuUrun);
                session.flush();
            }
                    
            session.flush();
            iMap.put("TRX_NAME", "9942");
            
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);           
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }


    @GraymoundService("BNSPR_TRN9942_GET_INFO")
    public static Map<?, ?> getInfo(GMMap iMap){
        try{
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            
            
            GnlScfUrunGrubuTx gnlScfUrunGrubuTx = (GnlScfUrunGrubuTx)session.createCriteria(GnlScfUrunGrubuTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            
            oMap.put("ACIKLAMA", gnlScfUrunGrubuTx.getAciklama());
            oMap.put("URUN_GRUP_TUR", gnlScfUrunGrubuTx.getTur());
            if (gnlScfUrunGrubuTx.getIslemTur().equals("D"))
                oMap.put("ISLEM_TUR", "1");
            else
                oMap.put("ISLEM_TUR", "0");
            
            List<?> urunGrubuUrunList = (List<?>) session.createCriteria(GnlScfUrunGrubuUrunTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
            String tableName = "TBL_URUN_LIST";
            int row = 0;
            
            oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
            
            for (Iterator<?> iterator = urunGrubuUrunList.iterator(); iterator.hasNext();row++) {
                GnlScfUrunGrubuUrunTx gnlScfUrunGrubuUrunTx = (GnlScfUrunGrubuUrunTx) iterator.next();
                oMap.put(tableName, row, "COL_MODUL_TUR", gnlScfUrunGrubuUrunTx.getModulTurKod());
                oMap.put(tableName, row, "COL_URUN_SINIF", gnlScfUrunGrubuUrunTx.getUrunSinifKod());
                oMap.put(tableName, row, "COL_URUN_TUR", gnlScfUrunGrubuUrunTx.getUrunTurKod());
                oMap.put("URUN_GRUP_LOV", gnlScfUrunGrubuUrunTx.getKod());
            }

            return oMap;
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    
    @GraymoundService("BNSPR_TRN9942_GRUP_KOD_KONTROL")
    public static Map<?, ?> grupKodKontrol(GMMap iMap){
        
        try{
        
            GMMap oMap = new GMMap();
            Connection conn =  DALUtil.getGMConnection();
            PreparedStatement stmt = null;
            ResultSet rSet = null;
            
            stmt = conn.prepareStatement("select count(*) from gnl_scf_urun_grubu u where u.kayit_durum = 'G' and u.kod = ? ");
            stmt.setString(1, iMap.getString("GRUP_KOD"));
            rSet = stmt.executeQuery();
            rSet.next();
            oMap.put("RESULT", rSet.getInt(1));
            
            if (rSet.getInt(1) > 0){                
                iMap.put("HATA_NO", new BigDecimal(716));
                return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);             
            }
                
        return oMap;
        
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    public static Boolean saveControlField(Object obj) {
        if (obj != null) {
            if (obj instanceof String)
                if (!obj.toString().equals(""))
                    return true;
        }
        return false;
    }
    
    
}
