package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class SystemQRY9942Services {
	
	
	@GraymoundService("BNSPR_QRY9942_GET_DATA")    
	public static GMMap QRY9942_Get_Data(GMMap iMap) {
		GMMap 				oMap = new GMMap();
		Connection 			conn = null;   
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		
		try {
			conn 				= DALUtil.getGMConnection();
			stmt 				= conn.prepareCall("{? = call PKG_RC9942.RC_9942_Get_Data_With_Grup_No(?)}");
			
			int i	= 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("GRUP_NO"));

			stmt.execute();
			stmt.getMoreResults();

			rSet = (ResultSet)stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "IZLEMETABLOSU");
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
