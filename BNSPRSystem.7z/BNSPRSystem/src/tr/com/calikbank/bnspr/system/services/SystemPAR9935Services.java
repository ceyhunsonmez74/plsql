package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlBatchBilgilendirme;
import tr.com.aktifbank.bnspr.dao.GnlBatchBilgilendirmeDetay;
import tr.com.aktifbank.bnspr.dao.GnlBatchBilgilendirmeDetayId;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPrId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9935Services {
	@GraymoundService("BNSPR_PAR9935_GET_GRUP_MAIL_TNM")
	public static Map<?,?> getGrupMailTnm(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> GrupMailTnm = (List<?>) session.createCriteria(GnlBatchBilgilendirme.class).list();

			String tableName = "MAIL_TNM";
			int row = 0;
			for (Iterator<?> iterator = GrupMailTnm.iterator(); iterator.hasNext(); row++) {
				GnlBatchBilgilendirme gnlGrupNoTnm = (GnlBatchBilgilendirme) iterator.next();
				oMap.put(tableName, row, "KOD", gnlGrupNoTnm.getKod());
				oMap.put(tableName, row, "GRUP_NO", gnlGrupNoTnm.getGrupNo());
				oMap.put(tableName, row, "MAIL_CC", gnlGrupNoTnm.getMailCc());
				oMap.put(tableName, row, "MAIL_TO", gnlGrupNoTnm.getMailTo());
				oMap.put(tableName, row, "F_HATA_DURUMUNDA", gnlGrupNoTnm.getFHataDurumunda() != null &&  gnlGrupNoTnm.getFHataDurumunda().equals("E") ? true : false);
				oMap.put(tableName, row, "F_TUM_LISTE", GuimlUtil.convertToCheckBoxDisplayValue(gnlGrupNoTnm.getFTumListe()));
			}

			return oMap;
		}catch(Exception e){
			throw new GMRuntimeException(0,e);
		}
	}

	@GraymoundService("BNSPR_PAR9935_GET_PROGRAM_TANIM")
	public static Map<?,?> getUrunTanim(GMMap iMap){
		GMMap oMap = new GMMap();
		String tableName = "GRUP_PROGRAM_TNM";
		Object o = GMContext.getCurrentContext().getSession().get("GN_" +iMap.getString("KOD") +"_" +iMap.getString("GRUP_NO"));
		if(o == null){
			try {
				ArrayList<HashMap<String, Object>> PrgOutList = new ArrayList<HashMap<String, Object>>();
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> GrupPrgList = (List<?>) session.createCriteria(GnlBatchBilgilendirmeDetay.class).add(Restrictions.eq("id.kod", iMap.getString("KOD"))).add(Restrictions.eq("id.grupNo",  iMap.getBigDecimal("GRUP_NO"))).list();
				int row = 0;
				for (Iterator<?> iterator2 = GrupPrgList.iterator(); iterator2.hasNext(); row++) {
					GnlBatchBilgilendirmeDetay gnlGrupProgTnm = (GnlBatchBilgilendirmeDetay) iterator2.next();
					oMap.put(tableName, row, "KOD", gnlGrupProgTnm.getId().getKod());
					oMap.put(tableName, row, "GRUP_NO", gnlGrupProgTnm.getId().getGrupNo());
					oMap.put(tableName, row, "PROGRAM_KOD", gnlGrupProgTnm.getId().getProgramKod());
					oMap.put(tableName, row, "SIRA_NO", gnlGrupProgTnm.getSiraNo());
				}
				//oMap.put(tableName, GrupPrgList) ;
			} catch (Exception e) {
				throw new GMRuntimeException(0, e);
			}
		}
		else{
			oMap.put(tableName, GMContext.getCurrentContext().getSession().get("GN_" +iMap.getString("KOD") +"_" +iMap.getString("GRUP_NO")));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_PAR9935_PUT_GRUP_NO_TO_CONTEX")
	public static Map<?,?> getEmptyModulModel(GMMap iMap){
		GMContext.getCurrentContext().getSession().put("GN_" +iMap.getString("KOD") +"_" +iMap.getString("GRUP_NO"), iMap.get("GRUP_PROGRAM_TNM"));
		return new GMMap();
	}


	@GraymoundService("BNSPR_PAR9935_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			for(int i=0;i<iMap.getSize("MAIL_TNM");i++){
				if(GuimlUtil.isDublicateKey((List<?>)iMap.get("MAIL_TNM"), "KOD", iMap.get("MAIL_TNM",i,"KOD")))
					throw new GMRuntimeException(0, iMap.get("MAIL_TNM",i,"KOD") + " kodlu ba�ka bir mail kayd� bulunmaktad�r'");
				GnlBatchBilgilendirme MailTnm = findKod(iMap.getString("MAIL_TNM",i,"KOD"));
				if(MailTnm == null)
					MailTnm = new GnlBatchBilgilendirme();
				MailTnm.setKod(iMap.getString("MAIL_TNM",i,"KOD"));
				MailTnm.setGrupNo(iMap.getBigDecimal("MAIL_TNM",i,"GRUP_NO"));
				MailTnm.setMailCc(iMap.getString("MAIL_TNM",i,"MAIL_CC"));
				MailTnm.setMailTo(iMap.getString("MAIL_TNM",i,"MAIL_TO"));
				MailTnm.setFHataDurumunda(iMap.getBoolean("MAIL_TNM",i,"F_HATA_DURUMUNDA") ? "E" : "H");
				MailTnm.setFTumListe(iMap.getString("MAIL_TNM",i,"F_TUM_LISTE"));
				session.saveOrUpdate(MailTnm);
				session.flush();

				String PrgGUIList = "TEMP";
				GMMap tempMap = new GMMap();
				tempMap.put(PrgGUIList, GMContext.getCurrentContext().getSession().get("GN_" + iMap.getString("MAIL_TNM",i,"KOD") + "_" + iMap.getString("MAIL_TNM",i,"GRUP_NO")));
				
				if(tempMap.get(PrgGUIList) != null ){
					List<?> prgPersistentList = session.createCriteria(GnlBatchBilgilendirmeDetay.class).add(Restrictions.eq("id.kod", iMap.getString("MAIL_TNM",i,"KOD"))).add(Restrictions.eq("id.grupNo",  iMap.getBigDecimal("MAIL_TNM",i,"GRUP_NO"))).list();
					for (Iterator<?> iterator = prgPersistentList.iterator(); iterator.hasNext();) {
						GnlBatchBilgilendirmeDetay prgKodPr = (GnlBatchBilgilendirmeDetay) iterator.next();
						if(!GuimlUtil.contains((List<?>)tempMap.get(PrgGUIList), "PROGRAM_KOD", prgKodPr.getId().getProgramKod()))
							session.delete(prgKodPr);
					}
					
					for(int k=0;k<tempMap.getSize(PrgGUIList);k++){
						Validator.checkNull(tempMap.get(PrgGUIList,k,"PROGRAM_KOD"), "Program Kodu bo� olamaz!");
						GnlBatchBilgilendirmeDetay ProgramPr = findProgram(iMap.getString("MAIL_TNM",i,"KOD"),iMap.getBigDecimal("MAIL_TNM",i,"GRUP_NO"), tempMap.getString(PrgGUIList,k,"PROGRAM_KOD"));
						GnlBatchBilgilendirmeDetayId id = new GnlBatchBilgilendirmeDetayId();
						if(ProgramPr == null){
							ProgramPr = new GnlBatchBilgilendirmeDetay();
							id.setKod(tempMap.getString(PrgGUIList,k,"KOD"));
							id.setGrupNo(tempMap.getBigDecimal(PrgGUIList,k,"GRUP_NO")) ;
							id.setProgramKod(tempMap.getString(PrgGUIList,k,"PROGRAM_KOD")) ; 
							ProgramPr.setId(id);
						}
						ProgramPr.setSiraNo(tempMap.getBigDecimal(PrgGUIList,k,"SIRA_NO"));
						try{
							session.saveOrUpdate(ProgramPr);	
						}
						catch (NonUniqueObjectException e) {
							throw new GMRuntimeException(0, "Ayn� kodlu birden fazla program bulunmaktad�r!");
						}
					}

					GMContext.getCurrentContext().getSession().put("GN_" + iMap.getString("MAIL_TNM",i,"KOD") + "_" + iMap.getString("MAIL_TNM",i,"GRUP_NO"), null);
				}

			}

			List<?> ilPersistentList = (List<?>) session.createCriteria(GnlBatchBilgilendirme.class).addOrder(Order.asc("kod")).list();
			for (Iterator<?> iterator = ilPersistentList.iterator(); iterator.hasNext();) {
				GnlBatchBilgilendirme tempMailTanim = (GnlBatchBilgilendirme) iterator.next();
				if(!GuimlUtil.contains((List<?>)iMap.get("MAIL_TNM"), "KOD", tempMailTanim.getKod())){
					List<GnlBatchBilgilendirmeDetay> prgPersistentList = session.createCriteria(GnlBatchBilgilendirmeDetay.class).add(Restrictions.eq("id.kod", tempMailTanim.getKod())).add(Restrictions.eq("id.grupNo",  tempMailTanim.getGrupNo())).list();
					for(GnlBatchBilgilendirmeDetay detay : prgPersistentList){
						session.delete(detay);
					}
					session.delete(tempMailTanim);
				}
			}

			session.flush();

			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r!");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	public static GnlBatchBilgilendirme findKod(String key){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlBatchBilgilendirme)session.get(GnlBatchBilgilendirme.class, key);
	}

	public static GnlBatchBilgilendirmeDetay findProgram(String kod, BigDecimal grupNo,
			String programKod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlBatchBilgilendirmeDetay)session.get(GnlBatchBilgilendirmeDetay.class, new GnlBatchBilgilendirmeDetayId(kod,grupNo,programKod) );


	}
}
