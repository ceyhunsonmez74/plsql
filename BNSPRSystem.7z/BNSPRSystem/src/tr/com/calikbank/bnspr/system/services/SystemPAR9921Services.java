package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlLimitPr;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class SystemPAR9921Services {
	
	@GraymoundService("BNSPR_PAR9921_GET_ISLEM_LIMIT")
	public static Map<?,?> getLimitTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listLimit = (List<?>) session.createCriteria(GnlLimitPr.class).addOrder(Order.asc("kod")).list();
			
			String tableName = "LIMIT_TANIM";
			int row = 0;
			for (Iterator<?> iterator = listLimit.iterator(); iterator.hasNext(); row++) {
				GnlLimitPr gnlLimitPr = (GnlLimitPr) iterator.next();
				oMap.put(tableName, row, "KOD", gnlLimitPr.getKod());
				oMap.put(tableName, row, "ACIKLAMA", gnlLimitPr.getAciklama());
				oMap.put(tableName, row, "ALT", gnlLimitPr.getAlt());
				oMap.put(tableName, row, "UST", gnlLimitPr.getUst());
				oMap.put(tableName, row, "DOVIZ_KOD", gnlLimitPr.getDovizKod());
				oMap.put(tableName, row, "TUM_DOVIZLER", GuimlUtil.convertToCheckBoxValue(gnlLimitPr.getTumDovizler()));
			}
			
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9921_SAVE_LIMIT_TANIM")
	public static Map<?,?> saveLimitTanim(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listLimit = (List<?>) session.createCriteria(GnlLimitPr.class).list();
			for (Iterator<?> iterator = listLimit.iterator(); iterator.hasNext();) {
				GnlLimitPr gnlLimitPr = (GnlLimitPr) iterator.next();
				if(!findKey(iMap, gnlLimitPr.getKod())){
					session.delete(gnlLimitPr);
				}
			}
			session.flush();

			String tableName = "LIMIT_LIST";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlLimitPr gnlLimitPr = (GnlLimitPr)session.get(GnlLimitPr.class, iMap.getBigDecimal(tableName, row, "KOD"));
				if(gnlLimitPr == null){
					gnlLimitPr = new GnlLimitPr();
					gnlLimitPr.setKod(iMap.getBigDecimal(tableName, row, "KOD"));
				}
				gnlLimitPr.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlLimitPr.setAlt(iMap.getBigDecimal(tableName, row, "ALT"));
				gnlLimitPr.setUst(iMap.getBigDecimal(tableName, row, "UST"));
				gnlLimitPr.setDovizKod(iMap.getString(tableName, row, "DOVIZ_KOD"));
				gnlLimitPr.setKarsilik("F"); //default F at�yoruz
				gnlLimitPr.setTumDovizler(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "TUM_DOVIZLER")));
				session.saveOrUpdate(gnlLimitPr);
			}
			
			session.flush();
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE", "��leminiz tamamland�!");
			return messageMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static boolean findKey(GMMap iMap,Object key){
		String tableName = "LIMIT_LIST";
		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if(iMap.getBigDecimal(tableName, row, "KOD").equals(key)){
				return true;
			}
		}
		return false;
	}
}
