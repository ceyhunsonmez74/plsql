package tr.com.calikbank.bnspr.system.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.Aktivite;
import tr.com.aktifbank.bnspr.dao.AktiviteId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AktiviteGiris {
	@GraymoundService("BNSPR_AKTIVITE_INITIALIZE")  
	public static GMMap initizlize(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			String kullanici =(String) GMContext.getCurrentContext().getSession().get("USER_NAME");
			
			oMap.put("BILGI", DALUtil.callOracleFunction("{? = call pkg_bnspr_aktivite.en_son_bilgi(?)}", BnsprType.STRING,BnsprType.STRING,kullanici));
			
			oMap.put("KULLANICI", kullanici);
			oMap.put("BOLUM", DALUtil.callOracleFunction("{? = call pkg_bnspr_aktivite.Kullanici_Bolum(?)}", BnsprType.STRING, BnsprType.STRING,kullanici));
			
			iMap.put("KOD", "AKT_GIRIS_MODUL");
			oMap.put("MODUL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKT_GIRIS_PROJE");
			oMap.put("PROJE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
			iMap.put("KOD", "AKT_GIRIS_MESAI_YERI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("MESAI_YERI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			iMap.put("KOD", "AKT_GIRIS_MESAI_TIPI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("MESAI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			iMap.put("KOD", "AKT_GIRIS_AKTTIPI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			iMap.put("KOD", "AKT_GIRIS_ISGUCU_TIPI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("ISGUCU_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKT_GIRIS_YONETICI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("YONETICI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKT_TAKIP_ISBIRIMI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("ISBIRIMI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_AKTIVITE_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> activiteList = session.createCriteria(Aktivite.class).add(Restrictions.and(
					Restrictions.eq("id.kullanici", iMap.getString("KULLANICI")), 
					Restrictions.eq("id.tarih", iMap.getDate("TARIH"))))
					.list();
			
			for (Iterator<?> iterator = activiteList.iterator(); iterator.hasNext();) {
				Aktivite aktivite = (Aktivite)iterator.next();
				session.delete(aktivite);
			}
			
			session.flush();
			
			String tableName = "AKTIVITELER";
			List<?> list = (List<?>)iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
				AktiviteId id = new AktiviteId();
				id.setKullanici(iMap.getString(tableName, i, "KULLANICI"));
				id.setTarih(iMap.getDate(tableName, i, "TARIH"));
				id.setSiraNo(new BigDecimal(i+1));

				Aktivite aktivite = new Aktivite();
				
				aktivite.setId(id);
				aktivite.setProje(iMap.getString(tableName, i, "PROJE"));
				aktivite.setModulTurKod(iMap.getString(tableName, i, "MODUL_TUR_KOD"));
				aktivite.setIssueNo(iMap.getString(tableName, i, "ISSUE_NO")!=null?iMap.getString(tableName, i, "ISSUE_NO").trim():null);
				aktivite.setSure(iMap.getBigDecimal(tableName, i, "SURE"));
				aktivite.setKonu(iMap.getString(tableName, i, "KONU"));
				aktivite.setTip(iMap.getString(tableName, i, "TIP"));
				aktivite.setIsgucuTip(iMap.getString(tableName, i, "ISGUCU_TIP"));
				aktivite.setMesaiTur(iMap.getString(tableName, i, "MESAI_TUR"));
				aktivite.setMesaiYer(iMap.getString(tableName, i, "MESAI_YER"));
				aktivite.setMesaiYerAciklama(iMap.getString(tableName, i, "MESAI_YER_ACIKLAMA"));
				aktivite.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				aktivite.setYonetici(iMap.getString(tableName, i, "YONETICI"));
				aktivite.setDestekVerilenBolum(iMap.getString(tableName, i, "ISBIRIMI"));
				
				session.saveOrUpdate(aktivite);
				session.flush();
			}
			return new GMMap().put("MESSAGE", "��leminiz Tamamland�");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_GET_AKTIVITELER")
	public static GMMap getAktiviteler(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			int row = 0;
			String tableName = "AKTIVITELER";
			List<?> list = (List<?>)session.createCriteria(Aktivite.class).add(Restrictions.and(
					Restrictions.eq("id.kullanici", iMap.getString("KULLANICI")), 
					Restrictions.eq("id.tarih", iMap.getDate("TARIH"))))
					.list();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				Aktivite aktivite = (Aktivite) iterator.next();

				oMap.put(tableName, row, "KULLANICI", aktivite.getId().getKullanici());
				oMap.put(tableName, row, "TARIH", aktivite.getId().getTarih());
				oMap.put(tableName, row, "PROJE", aktivite.getProje());
				oMap.put(tableName, row, "MODUL_TUR_KOD", aktivite.getModulTurKod());
				oMap.put(tableName, row, "ISSUE_NO", aktivite.getIssueNo());
				oMap.put(tableName, row, "SURE", aktivite.getSure());
				oMap.put(tableName, row, "KONU", aktivite.getKonu());
				oMap.put(tableName, row, "TIP", aktivite.getTip());
				oMap.put(tableName, row, "ISGUCU_TIP", aktivite.getIsgucuTip());
				oMap.put(tableName, row, "MESAI_TUR", aktivite.getMesaiTur());
				oMap.put(tableName, row, "MESAI_YER", aktivite.getMesaiYer());
				oMap.put(tableName, row, "MESAI_YER_ACIKLAMA", aktivite.getMesaiYerAciklama());
				oMap.put(tableName, row, "ACIKLAMA", aktivite.getAciklama());
				oMap.put(tableName, row, "YONETICI", aktivite.getYonetici());
				oMap.put(tableName, row, "ISBIRIMI", aktivite.getDestekVerilenBolum());
			}

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_TOPLAM_SURE_KONTROL")
	public static GMMap toplamSureKontrol(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try {
			if(iMap.getString("KULLANICI")==null || "".equals(iMap.getString("KULLANICI"))){
				GMMap myMap = new GMMap();
				myMap.put("HATA_NO", "330");
				myMap.put("P1", "Kullan�c�");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
			}
			if(iMap.getString("TARIH")==null){
				GMMap myMap = new GMMap();
				myMap.put("HATA_NO", "330");
				myMap.put("P1", "Tarih");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
			}
			oMap.put("TOPLAM_SURE", DALUtil.callOracleFunction("{? = call pkg_bnspr_aktivite.Toplam_sure(?,?)}", BnsprType.STRING, BnsprType.STRING, iMap.getString("KULLANICI"), BnsprType.DATE, iMap.getDate("TARIH")));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_AKTIVITE_GET_SYSDATE")
	public static GMMap getSysDate(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try {
			oMap.put("SYSDATE", DALUtil.callOracleFunction("{? = call pkg_bnspr_aktivite.Bugun}", BnsprType.DATE));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_AKTIVITE_SATIR_KOPYALA")
	public static GMMap satirKopyala(GMMap iMap) {		
		try {
			String tableName = "MODEL_DATA";
			int size = iMap.getSize("MODEL_DATA");
			int selectedRow = iMap.getInt("SELECTED_ROW");
			
			iMap.put(tableName, size, "ACIKLAMA", iMap.getString(tableName, selectedRow, "ACIKLAMA"));
			iMap.put(tableName, size, "ISBIRIMI", iMap.getString(tableName, selectedRow, "ISBIRIMI"));
			iMap.put(tableName, size, "ISGUCU_TIP", iMap.getString(tableName, selectedRow, "ISGUCU_TIP"));
			iMap.put(tableName, size, "ISSUE_NO", iMap.getString(tableName, selectedRow, "ISSUE_NO"));
			iMap.put(tableName, size, "KONU", iMap.getString(tableName, selectedRow, "KONU"));
			iMap.put(tableName, size, "KULLANICI", iMap.getString(tableName, selectedRow, "KULLANICI"));
			iMap.put(tableName, size, "MESAI_TUR", iMap.getString(tableName, selectedRow, "MESAI_TUR"));
			iMap.put(tableName, size, "MESAI_YER", iMap.getString(tableName, selectedRow, "MESAI_YER"));
			iMap.put(tableName, size, "MESAI_YER_ACIKLAMA", iMap.getString(tableName, selectedRow, "MESAI_YER_ACIKLAMA"));
			iMap.put(tableName, size, "MODUL_TUR_KOD", iMap.getString(tableName, selectedRow, "MODUL_TUR_KOD"));
			iMap.put(tableName, size, "PROJE", iMap.getString(tableName, selectedRow, "PROJE"));
			iMap.put(tableName, size, "SURE", iMap.getString(tableName, selectedRow, "SURE"));
			iMap.put(tableName, size, "TARIH", iMap.getDate(tableName, selectedRow, "TARIH"));
			iMap.put(tableName, size, "TIP", iMap.getString(tableName, selectedRow, "TIP"));
			iMap.put(tableName, size, "YONETICI", iMap.getString(tableName, selectedRow, "YONETICI"));
			
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_AKTIVITE_GET_TOPLAM_SURE")
	public static GMMap getToplamSure(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try {
			
			String tableName = "AKTIVITELER";
			int mesaiDis = 0;
			int mesaiIc  = 0;
			int sure     = 0;
			for(int i=0; i<iMap.getSize(tableName); i++){
				sure = iMap.getInt(tableName, i, "SURE");
				if(iMap.getInt(tableName, i, "MESAI_TUR")==1){
					mesaiIc+=sure;
				}else if(iMap.getInt(tableName, i, "MESAI_TUR")==2){
					mesaiDis+=sure;
				}
			}
			oMap.put("MESAI_IC", mesaiIc);
			oMap.put("MESAI_DIS", mesaiDis);
			oMap.put("FORMATTED_MESAI_IC", getFormatedTime(mesaiIc));
			oMap.put("FORMATTED_MESAI_DIS", getFormatedTime(mesaiDis));
			oMap.put("FORMATTED_SURE", getFormatedTime(mesaiIc+mesaiDis));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	private static String getFormatedTime(int sure){
		int saat = sure/60;
		String toplamSure = "";
		if(saat<10) toplamSure="0"+saat;
		else toplamSure=""+saat;
		toplamSure+=":";
		int dakika = sure % 60;
		if(dakika<10)toplamSure+="0"+dakika;
		else toplamSure+=dakika;
		
		return toplamSure;
	}
	@GraymoundService("BNSPR_AKTIVITE_LOAD_EXCEL")
	public static GMMap loadExcel(GMMap iMap){
		try{
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[])iMap.get("DOSYA")));
			Sheet sheet 		= workbook.getSheet(0);
			String tableName	= "TABLE";
			int tableRow 		= iMap.getSize(tableName);
			String kullanici	= iMap.getString("KULLANICI");
			Date tarih 			= iMap.getDate("TARIH");
			String proje 		= iMap.getString("PROJE");
			String modulTurKod 	= iMap.getString("MODUL_TUR_KOD");
			String isBirimi 	= iMap.getString("ISBIRIMI");
			String tip 			= iMap.getString("TIP");
			String isgucuTip 	= iMap.getString("ISGUCU_TIP");
			String mesaiTur 	= iMap.getString("MESAI_TUR");
			String mesaiYer 	= iMap.getString("MESAI_YER");
			String yonetici 	= iMap.getString("YONETICI");
			String sure 		= null;
			String aciklama		= null;
			String konu			= null;
			String issueNo 		= null;
			
			for (int excelRow = 1; excelRow < sheet.getRows(); excelRow++, tableRow++) {
				int excelCol= 0;
				issueNo		= sheet.getCell(excelCol++, excelRow).getContents();
				sure 		= sheet.getCell(excelCol++, excelRow).getContents();
				konu 		= sheet.getCell(excelCol++, excelRow).getContents();
				aciklama 	= sheet.getCell(excelCol++, excelRow).getContents();
				if((issueNo ==null || "".equals(issueNo)) 	&&
				   (sure    ==null || "".equals(sure)) 		&&	
				   (konu    ==null || "".equals(konu)) 		&&
				   (aciklama==null || "".equals(aciklama)) 	){
					continue;
				}
				
				iMap.put(tableName, tableRow, "ISSUE_NO"	, issueNo);

				if(sure==null || "".equals(sure)){
					GMMap myMap = new GMMap();
					myMap.put("HATA_NO", "330");
					myMap.put("P1", "S�re");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
				}
				try {
					Integer.parseInt(sure);
				} catch (NumberFormatException e) {
					GMMap myMap = new GMMap();
					myMap.put("HATA_NO", "1200");
					myMap.put("P1", "S�re");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
				}
				iMap.put(tableName, tableRow, "SURE"		, sure);
				iMap.put(tableName, tableRow, "KONU"		, konu);
				if(aciklama==null || "".equals(aciklama)){
					GMMap myMap = new GMMap();
					myMap.put("HATA_NO", "330");
					myMap.put("P1", "A��klama");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
				}
				iMap.put(tableName, tableRow, "ACIKLAMA"	, aciklama);
				iMap.put(tableName, tableRow, "KULLANICI"	, kullanici);
				iMap.put(tableName, tableRow, "TARIH"		, tarih);
				iMap.put(tableName, tableRow, "PROJE"		, proje);
				iMap.put(tableName, tableRow, "MODUL_TUR_KOD", modulTurKod);
				iMap.put(tableName, tableRow, "ISBIRIMI"	, isBirimi);
				iMap.put(tableName, tableRow, "TIP"			, tip);
				iMap.put(tableName, tableRow, "ISGUCU_TIP"	, isgucuTip);
				iMap.put(tableName, tableRow, "MESAI_TUR"	, mesaiTur);
				iMap.put(tableName, tableRow, "MESAI_YER"	, mesaiYer);
				iMap.put(tableName, tableRow, "YONETICI"	, yonetici);
		
			}
			workbook.close();
			
			return iMap;
			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
}
