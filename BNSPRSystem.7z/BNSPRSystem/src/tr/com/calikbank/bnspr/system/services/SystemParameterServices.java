package tr.com.calikbank.bnspr.system.services;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemParameterServices {
	
	private final static String PREFIX_KOD = "kod:";
	private final static String PREFIX_NUMARA = "numara:";	
	
	private static class ParameterCache{
		
		private static LoadingCache<String, String> cache;
		
		static{
			CacheLoader<String, String> loader = new CacheLoader<String, String>() {
				@Override
				public String load(String key) {
					String kod = null;
					GMMap iMap = new GMMap();
					if(key.startsWith(PREFIX_KOD)){
						kod = key.substring(PREFIX_KOD.length());
					}
					else if(key.startsWith(PREFIX_NUMARA)){
						kod = key.substring(PREFIX_NUMARA.length());
						iMap.put("IS_VIA_NUMBER", true);
					}
					else
						kod = key;
					
					iMap.put("KOD", kod);
					GMMap oMap = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap);
					return oMap.getString("DEGER");
				}
			};

			cache = CacheBuilder.newBuilder()
								.expireAfterWrite(5, TimeUnit.MINUTES) // 5 dakikada bir cache degeri yenilensin
								.build(loader);
		}
		
		public static String getParameter(String key){
			String paramValue = cache.getUnchecked(key);
			return paramValue;
		}
		
		
	}
	
	
	/**
	 * Her defasinda veritabanina giderek verilen KOD degerine ait son gnl_parametre degerini okur ve doner
	 * Performans adina bu servisin yerine BNSPR_SISTEM_GET_GLOBAL_PARAM_FROM_CACHE servisinin kullanilmasi tavsiye edilir
	 * 
	 * @param iMap (GMMap)
	 *          KOD ("Numara" or "Kod" column)
	 * 			IS_VIA_NUMBER 	(Default->false)
	 * 			TRIM_QUOTES 	(Default->false)
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA
	 *      DEGER
	 *
	 * Company : Aktifbank
	 *
	 */
	@GraymoundService("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE")
	public static GMMap getGlobal(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			boolean isViaNumber = iMap.getBoolean("IS_VIA_NUMBER");
			boolean trimQuotes = iMap.getBoolean("TRIM_QUOTES");

            Session session = DAOSession.getSession("BNSPRDal");
            GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(
            		isViaNumber ? Restrictions.eq("numara", iMap.getBigDecimal("KOD")):Restrictions.eq("kod", iMap.getString("KOD"))
            ).uniqueResult();

    		oMap.put("DEGER", trimQuotes ? StringUtils.strip(parametre.getDeger(), "\""):parametre.getDeger());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", 2);
		oMap.put("RESPONSE_DATA", "");
		return oMap;
	}
	
	/**
	 * Her defasinda ayni parametre degerini almak icin veritabanina gitmez, bir kere okuduktan sonra cacheler ve 5 dakika boyunca degeri cacheten okur.
	 * 5 dakika sonrasinda cache degeri tekrar veritabanindan son deger alinarak yenilenecektir.
	 * 
	 * @param iMap
	 * 			-KOD
	 * 			-IS_VIA_NUMBER (optional)
	 * 			-TRIM_QUOTES (optional)
	 * 		  oMap
	 * 			-DEGER
	 * @return
	 */
	@GraymoundService("BNSPR_SISTEM_GET_GLOBAL_PARAM_FROM_CACHE")
	public static GMMap getGlobalParameterFromCache(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			boolean isViaNumber = iMap.getBoolean("IS_VIA_NUMBER");
			String keyPrefix = isViaNumber ? PREFIX_NUMARA : PREFIX_KOD;
			String key = keyPrefix + iMap.getString("KOD");
			
			String paramValue = ParameterCache.getParameter(key);
			
			boolean trimQuotes = iMap.getBoolean("TRIM_QUOTES");

    		oMap.put("DEGER", trimQuotes ? StringUtils.strip(paramValue, "\"") : paramValue );
    		
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", 2);
		oMap.put("RESPONSE_DATA", "");
		return oMap;
	}

	
}
