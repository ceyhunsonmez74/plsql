package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlSubeEftBagimli;
import tr.com.calikbank.bnspr.dao.GnlSubeEftBagimliTx;
import tr.com.calikbank.bnspr.dao.GnlSubeKodPr;
import tr.com.calikbank.bnspr.dao.GnlSubeKodPrTx;
import tr.com.calikbank.bnspr.dao.GnlSubeTakasBagimli;
import tr.com.calikbank.bnspr.dao.GnlSubeTakasBagimliTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9913Services {
	@GraymoundService("BNSPR_TRN9913_GET_SUBE_BILGI")
	public static GMMap getSubeBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlSubeKodPr gnlSubeKodPr = (GnlSubeKodPr) session.createCriteria(
					GnlSubeKodPr.class).add(
					Restrictions.eq("kod", iMap.getString("SUBE_KODU")))
					.uniqueResult();
			
			oMap.put("KODU" , gnlSubeKodPr.getKod());
	        oMap.put("ADI" , LovHelper.diLov(gnlSubeKodPr.getKod(), "9901/LV_SUBE_KODU", "ADI"));
	        oMap.put("SUBE_ADI_ING" , gnlSubeKodPr.getSubeAdiIng());
	        oMap.put("IL_KODU" , gnlSubeKodPr.getGnlIlKodPr().getKod());
	        oMap.put("IL_ADI",gnlSubeKodPr.getGnlIlKodPr().getIlAdi());
	        oMap.put("EFT_KODU" , gnlSubeKodPr.getEftKodu());
	        oMap.put("SUBE_F" , gnlSubeKodPr.getSubeGm());
	        oMap.put("SIRA_NO" , gnlSubeKodPr.getSiraNo());
	        oMap.put("TAKAS_KODU" , gnlSubeKodPr.getTakasKodu());
	        oMap.put("KAR_MERKEZI" , gnlSubeKodPr.getKarMerkezi());
	        oMap.put("YURT_ICI" , gnlSubeKodPr.getYurtIci());
	        oMap.put("MEMZUC_ILCE_KODU" , gnlSubeKodPr.getMemzucIlceKodu());
	        oMap.put("MEMZUC_ILCE_SUBE_SIRA" , gnlSubeKodPr.getMemzucIlceSubeSira());
	        oMap.put("KASA_MEVCUT_MU" , gnlSubeKodPr.getKasaMevcut());       
	        oMap.put("ILCE_KODU" , gnlSubeKodPr.getIlceKod());
	        oMap.put("ILCE_ADI" ,LovHelper.diLov(gnlSubeKodPr.getIlceKod(),gnlSubeKodPr.getGnlIlKodPr().getKod(),"9901/LV_ILCE_KODU", "ILCE_ADI"));    
	        oMap.put("ULKE_KODU" , gnlSubeKodPr.getGnlUlkeKodPr().getKod());      
	        oMap.put("ULKE_ADI",gnlSubeKodPr.getGnlUlkeKodPr().getUlkeAdi());
	        oMap.put("ADRES" , gnlSubeKodPr.getAdres1());
	        oMap.put("TELEFON" , gnlSubeKodPr.getTelefon());
	        oMap.put("FAX" , gnlSubeKodPr.getFax());
	        oMap.put("RESMI_DEFTER_BOLUM_KODU" , gnlSubeKodPr.getResmiDefterBolumKodu());
	        oMap.put("VERGI_DAIRE" , gnlSubeKodPr.getVergiDaire());
	        oMap.put("VERGI_DAIRESI_ADI" , LovHelper.diLov(gnlSubeKodPr.getVergiDaire(), "9913/LV_VERGI_DAIRESI_ADI", "ADI"));
	        
	    
	        oMap.put("VERGI_NO" , gnlSubeKodPr.getVergiNo());
	        oMap.put("DURUM" , gnlSubeKodPr.getDurumu());
	        oMap.put("KAPAMA_TARIHI" , gnlSubeKodPr.getKapanmaTar());
	        oMap.put("BAGLI_SUBE_KOD" , gnlSubeKodPr.getBagliSubeKodu());
	        oMap.put("BAGLI_SUBE_ADI" , LovHelper.diLov(gnlSubeKodPr.getBagliSubeKodu(), "9901/LV_SUBE_KODU", "ADI"));
	        
	        String nullStr = null;
//	        WebdavClient client = new WebdavClient();
//	        if(gnlSubeKodPr.getKrokiFileName() != null)
//	        	oMap.put("KROKI_FILE_NAME", client.getBaseUrl() + "/" + SystemTRN9901Services.SUBE_KROKI_ROOT_DIR + "/" + gnlSubeKodPr.getKrokiFileName());
//	        else
	        	oMap.put("KROKI_FILE_NAME", nullStr);
	        
	        oMap.put("FILE_NAME", gnlSubeKodPr.getKrokiFileName());
	        
	        List<?> list = session.createCriteria(GnlSubeTakasBagimli.class).add(Restrictions.eq("id.gnlSubeKodPr.kod", iMap.getString("SUBE_KODU"))).list();
	        String tableName = "BOLUM_TAKAS_BAGIMLI_ISLEM";
	        int row = 0;
			for (Iterator<?> iter = list.iterator(); iter.hasNext(); row++) {
				GnlSubeTakasBagimli gnlSubeTakasBagimli = (GnlSubeTakasBagimli) iter.next();
				iMap.put(tableName, row, "BAGLI_SUBE", gnlSubeTakasBagimli.getId()
						.getGnlSubeKodPr_1().getKod());
				iMap.put(tableName, row, "SUBE_ADI", LovHelper.diLov(
						gnlSubeTakasBagimli.getId().getGnlSubeKodPr_1().getKod(),
						"9901/LV_EFT_BOLUM", "ADI"));
			}
	        
			List<?> list1 = session.createCriteria(GnlSubeEftBagimli.class).add(
					Restrictions.eq("id.gnlBolumSubeKodPr.kod", iMap
							.getString("SUBE_KODU"))).list();
			tableName = "BOLUM_EFT_BAGIMLI_ISLEM";
			row = 0;
			for (Iterator<?> iter = list1.iterator(); iter.hasNext();row++) {
				GnlSubeEftBagimli gnlSubeEftBagimli = (GnlSubeEftBagimli) iter
						.next();
				iMap.put(tableName, row, "BAGLI_SUBE", gnlSubeEftBagimli.getId()
						.getGnlBagliBolumSubeKodPr().getKod());
				iMap.put(tableName, row, "SUBE_ADI", LovHelper.diLov(
						gnlSubeEftBagimli.getId().getGnlBagliBolumSubeKodPr()
								.getKod(), "9901/LV_TAKAS_BOLUM", "ADI"));
	
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9913_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GnlSubeKodPrTx gnlSubeKodPrTx = (GnlSubeKodPrTx) session.get(
					GnlSubeKodPrTx.class, iMap.getBigDecimal("TRX_NO"));
			if (gnlSubeKodPrTx == null)
				gnlSubeKodPrTx = new GnlSubeKodPrTx();

			gnlSubeKodPrTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlSubeKodPrTx.setKod(iMap.getString("SUBE_KODU"));
			gnlSubeKodPrTx.setSubeAdi(iMap.getString("SUBE_ADI"));
			gnlSubeKodPrTx.setSubeAdiIng(iMap.getString("SUBE_ADI_ING"));
			gnlSubeKodPrTx.setIlKod(iMap.getString("IL_KODU"));
			gnlSubeKodPrTx.setIlceKod(iMap.getString("ILCE_KODU"));
			gnlSubeKodPrTx.setUlkeKod(iMap.getString("ULKE_KODU"));
			gnlSubeKodPrTx.setEftKodu(iMap.getString("EFT_KODU"));
			gnlSubeKodPrTx.setSubeGm(iMap.getString("SUBE_F"));
			gnlSubeKodPrTx.setSiraNo(iMap.getBigDecimal("SIRA_NO"));
			gnlSubeKodPrTx.setTakasKodu(iMap.getString("TAKAS_KODU"));
			gnlSubeKodPrTx.setKarMerkezi(iMap.getString("KAR_MERKEZI"));
			gnlSubeKodPrTx.setYurtIci(iMap.getString("YURT_ICI"));
			try {
				gnlSubeKodPrTx.setMemzucIlceKodu(new Byte((String) iMap
						.get("MEMZUC_ILCE_KODU")));
			} catch (Exception e) {
				gnlSubeKodPrTx.setMemzucIlceKodu(null);
			}
			try {
				gnlSubeKodPrTx.setMemzucIlceSubeSira(new Byte((String) iMap
						.get("MEMZUC_ILCE_SUBE_SIRA")));
			} catch (Exception e) {
				gnlSubeKodPrTx.setMemzucIlceKodu(null);
			}
			gnlSubeKodPrTx.setKasaMevcut(iMap.getString("KASA_MEVCUT_MU"));

			gnlSubeKodPrTx.setAdres1(iMap.getString("ADRES"));
			gnlSubeKodPrTx.setTelefon(iMap.getString("TELEFON"));
			gnlSubeKodPrTx.setFax(iMap.getString("FAX"));
			gnlSubeKodPrTx.setVergiDaire(iMap.getString("VERGI_DAIRE"));
			gnlSubeKodPrTx.setVergiNo(iMap.getString("VERGI_NO"));
			gnlSubeKodPrTx.setDurumu(iMap.getString("DURUMU"));
			gnlSubeKodPrTx.setBagliSubeKodu(iMap.getString("BAGLI_SUBE_KOD"));
			
			if(iMap.getString("DURUMU").equals("K"))gnlSubeKodPrTx.setKapanmaTar(iMap.getDate("KAPAMA_TARIHI"));
			else gnlSubeKodPrTx.setKapanmaTar(null);
			gnlSubeKodPrTx.setResmiDefterBolumKodu(iMap
					.getString("RESMI_DEFTER_BOLUM_KODU"));

			List<?> listTakasBagimli = session.createCriteria(GnlSubeTakasBagimliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : listTakasBagimli) {
				GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx) name;
				session.delete(gnlSubeTakasBagimliTx);
			}

			session.flush();

			String tableName = "TAKAS_BAGIMLI_ISLEM";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = new GnlSubeTakasBagimliTx();
				gnlSubeTakasBagimliTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlSubeTakasBagimliTx.setBolumKodu(iMap.getString("SUBE_KODU"));
				gnlSubeTakasBagimliTx.setBagliBolumKodu(iMap.getString(tableName, row, "BAGLI_SUBE"));
				session.save(gnlSubeTakasBagimliTx);
			}

			List<?> listEftBagimli = session.createCriteria(GnlSubeEftBagimliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : listEftBagimli) {
				GnlSubeEftBagimliTx gnlSubeEftBagimliTx = (GnlSubeEftBagimliTx) name;
				session.delete(gnlSubeEftBagimliTx);
			}

			session.flush();
	

			tableName = "EFT_BAGIMLI_ISLEM";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlSubeEftBagimliTx gnlSubeEftBagimliTx = new GnlSubeEftBagimliTx();
				gnlSubeEftBagimliTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlSubeEftBagimliTx.setBolumKodu(iMap.getString("SUBE_KODU"));
				gnlSubeEftBagimliTx.setBagliBolumKodu(iMap.getString(tableName, row, "BAGLI_SUBE"));
				session.save(gnlSubeEftBagimliTx);
			}
			
			if(iMap.getBoolean("F_NEW", true)) {
				gnlSubeKodPrTx.setKrokiFileName(SystemTRN9901Services.sendSubeKroki(iMap, gnlSubeKodPrTx));
			}
			else {
				gnlSubeKodPrTx.setKrokiFileName(iMap.getString("FILE_NAME"));
			}
			session.save(gnlSubeKodPrTx);
			session.flush();
			iMap.put("TRX_NAME", "9913");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9913_GET_SUBE_BILGI_WITH_TX_NO")
	public static GMMap getSubeBilgiWithTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	
			GnlSubeKodPrTx gnlSubeKodPrTx = (GnlSubeKodPrTx) session.createCriteria(
					GnlSubeKodPrTx.class).add(
					Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
					.uniqueResult();
			oMap.put("TRX_NO", gnlSubeKodPrTx.getTxNo());
			oMap.put("KODU" , gnlSubeKodPrTx.getKod());
			oMap.put("ADI" , gnlSubeKodPrTx.getSubeAdi());
			oMap.put("SUBE_ADI_ING" , gnlSubeKodPrTx.getSubeAdiIng());
	        oMap.put("IL_KODU" , gnlSubeKodPrTx.getIlKod());
	        oMap.put("IL_ADI",LovHelper.diLov(gnlSubeKodPrTx.getIlKod(), "9901/LV_IL", "IL_ADI"));
	        oMap.put("EFT_KODU" , gnlSubeKodPrTx.getEftKodu());
	        oMap.put("SUBE_F" , gnlSubeKodPrTx.getSubeGm());
	        oMap.put("SIRA_NO" , gnlSubeKodPrTx.getSiraNo());
	        oMap.put("TAKAS_KODU" , gnlSubeKodPrTx.getTakasKodu());
	        oMap.put("KAR_MERKEZI" , gnlSubeKodPrTx.getKarMerkezi());
	        oMap.put("YURT_ICI" , gnlSubeKodPrTx.getYurtIci());
	        oMap.put("MEMZUC_ILCE_KODU" , gnlSubeKodPrTx.getMemzucIlceKodu());
	        oMap.put("MEMZUC_ILCE_SUBE_SIRA" , gnlSubeKodPrTx.getMemzucIlceSubeSira());
	        oMap.put("KASA_MEVCUT_MU" , gnlSubeKodPrTx.getKasaMevcut());       
	        oMap.put("ILCE_KODU" , gnlSubeKodPrTx.getIlceKod());
	        oMap.put("ILCE_ADI" ,LovHelper.diLov(gnlSubeKodPrTx.getIlceKod(),gnlSubeKodPrTx.getIlKod(),"9901/LV_ILCE_KODU", "ILCE_ADI"));    
	        oMap.put("ULKE_KODU" , gnlSubeKodPrTx.getUlkeKod());      
	        oMap.put("ULKE_ADI",LovHelper.diLov(gnlSubeKodPrTx.getUlkeKod(), "9901/LV_ULKE_KODU", "ULKE_ADI"));
	        oMap.put("ADRES" , gnlSubeKodPrTx.getAdres1());
	        oMap.put("TELEFON" , gnlSubeKodPrTx.getTelefon());
	        oMap.put("FAX" , gnlSubeKodPrTx.getFax());
	        oMap.put("RESMI_DEFTER_BOLUM_KODU" , gnlSubeKodPrTx.getResmiDefterBolumKodu());
	        oMap.put("VERGI_DAIRE" , gnlSubeKodPrTx.getVergiDaire());
	        oMap.put("VERGI_DAIRESI_ADI" , LovHelper.diLov(gnlSubeKodPrTx.getVergiDaire(), "9913/LV_VERGI_DAIRESI_ADI", "ADI"));
	        oMap.put("VERGI_NO" , gnlSubeKodPrTx.getVergiNo());
	        oMap.put("DURUM" , gnlSubeKodPrTx.getDurumu());
	        oMap.put("KAPAMA_TARIHI" , gnlSubeKodPrTx.getKapanmaTar());
	        String nullStr = null;
//	        WebdavClient client = new WebdavClient();
//	        if(gnlSubeKodPrTx.getKrokiFileName() != null)
//	        	oMap.put("KROKI_FILE_NAME", client.getBaseUrl() + "/" + SystemTRN9901Services.SUBE_KROKI_ROOT_DIR + "/" + gnlSubeKodPrTx.getKrokiFileName());
//	        else
	        	oMap.put("KROKI_FILE_NAME", nullStr);
	        oMap.put("FILE_NAME", gnlSubeKodPrTx.getKrokiFileName());
	        
	        List<?> list = session.createCriteria(GnlSubeTakasBagimliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        String tableName = "BOLUM_TAKAS_BAGIMLI_ISLEM";
	        int row = 0;
			for (Iterator<?> iter = list.iterator(); iter.hasNext();row++) {
				GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx) iter.next();
				iMap.put(tableName, row, "BAGLI_SUBE", gnlSubeTakasBagimliTx.getBagliBolumKodu());
				iMap.put(tableName, row, "SUBE_ADI", LovHelper.diLov(
						gnlSubeTakasBagimliTx.getBagliBolumKodu(),
						"9901/LV_EFT_BOLUM", "ADI"));
			}
	        
			List<?> list1 = session.createCriteria(GnlSubeEftBagimliTx.class).add(Restrictions.eq("txNo", iMap
							.getBigDecimal("TRX_NO"))).list();

			tableName = "BOLUM_EFT_BAGIMLI_ISLEM";
			row = 0;
			for (Iterator<?> iter = list1.iterator(); iter.hasNext(); row++) {
				GnlSubeEftBagimliTx gnlSubeEftBagimliTx = (GnlSubeEftBagimliTx) iter.next();
				iMap.put(tableName, row, "BAGLI_SUBE", gnlSubeEftBagimliTx.getBagliBolumKodu());
				iMap.put(tableName, row, "SUBE_ADI", LovHelper.diLov(gnlSubeEftBagimliTx.getBagliBolumKodu(), "9901/LV_TAKAS_BOLUM", "ADI"));
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9913_INITIALIZE_TABLES")
	public static GMMap initializeTables(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			String func = "{? = call pkg_trn9913.GET_EFT_BAGLI(?)}";
			Object[] inputValues = new Object[]{BnsprType.NUMBER,iMap.getBigDecimal("SUBE_KODU")};
			oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_BOLUM_EFT_BAGIMLI_ISLEM", inputValues);
			
			String func2 = "{? = call pkg_trn9913.GET_TAKAS_BAGLI(?)}";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func2, "CBS_BOLUM_TAKAS_BAGIMLI_ISLEM", inputValues));
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
