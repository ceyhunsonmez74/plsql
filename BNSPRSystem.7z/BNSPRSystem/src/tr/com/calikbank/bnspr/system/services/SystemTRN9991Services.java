package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlBankaSubeTelefonPrTx;
import tr.com.aktifbank.bnspr.dao.GnlBankaSubeTelefonPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9991Services {
	
	private static Logger logger = Logger.getLogger(SystemTRN9991Services.class);
	
	private enum GDS {
		GIRIS("G"), DUZENLEME("D"), SILME("S");
		
		String code;
		
		private GDS(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}
	}
	
	/**
	 * Banka sube telefon detaylari kayit servisi. Birden cok banka ve sube uzerinde bir veya daha fazla kayit islemi 
	 * yapilmasi icin kullanilabilir. Arkasinda <tt>bnspr.pkg_trn9991</tt> transaction'i tetiklenir.
	 * 
	 * @param iMap {TRX_NO}					Transaction numarasi
	 * @param iMap {DETAILS}				{@code ArrayList<GMMap>} tipinde sube telefon bilgileri
	 * @return
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_TRN9991_SAVE")
	public static GMMap save(GMMap iMap) {
		
		String countryCode = "+90";
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
				
			Map<String, Short> branchRecord = new HashMap<String, Short>();
			
			for(int i=0; i<iMap.getSize("DETAILS"); i++) {
				
				String branch = iMap.getString("DETAILS", i, "BANKA_KODU").concat(
					iMap.getString("DETAILS", i, "SUBE_KODU"));
				String defaultRecord = iMap.get("DETAILS", i, "VARSAYILAN") != null ? iMap.getString("DETAILS", i,
					"VARSAYILAN") : "0";
				branchRecord.put(branch, (short) (branchRecord.get(branch) == null ? 1
					: branchRecord.get(branch) + 1));
				
				Map<String, Object> restrictions = new HashMap<String, Object>();
				restrictions.put("id.txNo", iMap.getBigDecimal("TRX_NO"));
				restrictions.put("id.bankaKod", iMap.getString("DETAILS", i, "BANKA_KODU"));
				restrictions.put("id.subeKodu", iMap.getString("DETAILS", i, "SUBE_KODU"));
				restrictions.put("varsayilan", "1");
				
				if(session.createCriteria(GnlBankaSubeTelefonPrTx.class).add(Restrictions.allEq(restrictions))
					.uniqueResult() != null && "1".equals(defaultRecord)) {
					throw new GMRuntimeException(0, String.format(
						"%s - %s i�in m�kerrer varsay�lan kay�t (%s) tespit edildi. Sat�r: %s", iMap.getString(
							"DETAILS", i, "BANKA_KODU"), iMap.getString("DETAILS", i, "SUBE_KODU"), iMap.getString(
							"DETAILS", i, "ALAN_KOD").concat(iMap.getString("DETAILS", i, "TEL_NO")), i + 2), true);
				}
				
				GnlBankaSubeTelefonPrTx phoneTx = new GnlBankaSubeTelefonPrTx(new GnlBankaSubeTelefonPrTxId(iMap
					.getBigDecimal("TRX_NO"), iMap.getString("DETAILS", i, "BANKA_KODU"), iMap.getString("DETAILS",
					i, "SUBE_KODU"), BigDecimal.valueOf(branchRecord.get(branch))));
				phoneTx.setAlanKod(iMap.getString("DETAILS", i, "ALAN_KOD"));
				phoneTx.setTelNo(iMap.getString("DETAILS", i, "TEL_NO"));
				phoneTx.setDahiliNo(iMap.getString("DETAILS", i, "DAHILI_NO"));
				phoneTx.setVarsayilan(defaultRecord);
				phoneTx.setUlkeKod(countryCode);
				phoneTx.setGDS(GDS.GIRIS.toString());
				session.save(phoneTx);
			}
			session.flush();
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", new GMMap().put("TRX_NAME", "9991").put(
				"TRX_NO", iMap.getBigDecimal("TRX_NO")));

		} catch (Exception e) {
			logger.error("BNSPR_TRN9991_SAVE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Banka sube telefon detaylari kayit onayinda islemi goruntulemek icin cagirilir.
	 * 
	 * @param iMap {TRX_NO}					Transaction numarasi
	 * @return
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_TRN9991_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<GnlBankaSubeTelefonPrTx> phones = session.createCriteria(GnlBankaSubeTelefonPrTx.class).add(
				Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			int index = 0;
			for(GnlBankaSubeTelefonPrTx phone : phones) {
				oMap.put("DETAILS", index, "SIRA_NO", phone.getId().getSiraNo());
				oMap.put("DETAILS", index, "BANKA_KODU", phone.getId().getBankaKod());
				oMap.put("DETAILS", index, "SUBE_KODU", phone.getId().getSubeKodu());
				oMap.put("DETAILS", index, "ALAN_KOD", phone.getAlanKod());
				oMap.put("DETAILS", index, "TEL_NO", phone.getTelNo());
				oMap.put("DETAILS", index, "DAHILI_NO", phone.getDahiliNo());
				oMap.put("DETAILS", index++, "VARSAYILAN", phone.getVarsayilan());
			}

			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_TRN9991_GET_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
