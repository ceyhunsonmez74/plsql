package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlRol;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9920Services {
    
    @GraymoundService("BNSPR_PAR9920_GET_COMBO")
    public static GMMap getCombo(GMMap iMap){
        GMMap oMap = new GMMap();
        
        iMap.put("ADD_EMPTY_KEY", "H");
        iMap.put("KOD", "ROL_TIPI");
        oMap.put("ROL_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
        return oMap;
    }
   
    @GraymoundService("BNSPR_PAR9920_GET_ROL_TANIM")
	public static Map<?,?> getRolTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listRol = session.createCriteria(GnlRol.class).addOrder(Order.asc("numara")).list();
			int row = 0;
			String tableName = "ROL_TANIM";
			for (Iterator<?> iterator = listRol.iterator(); iterator.hasNext(); row++) {
				GnlRol gnlrol = (GnlRol) iterator.next();
				oMap.put(tableName, row, "NUMARA", gnlrol.getNumara());
				oMap.put(tableName, row, "BASLANGIC_TARIHI", gnlrol.getBaslangicTarihi());
				oMap.put(tableName, row, "BITIS_TARIHI", gnlrol.getBitisTarihi());
				oMap.put(tableName, row, "TANIM", gnlrol.getTanim());
				oMap.put(tableName, row, "ROL_TIPI",StringUtil.isEmpty(gnlrol.getSK())?new BigDecimal(1):gnlrol.getSK());
				oMap.put(tableName, row, "BOLUM_KOD",gnlrol.getBolumKod());
				oMap.put(tableName, row, "ACIKLAMA", LovHelper.diLov(gnlrol.getBolumKod(), "9920/LOV_BOLUM_KOD", "ACIKLAMA"));
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9920_SAVE_ROL_TANIM")
	public static Map<?,?> saveRolTanim(GMMap iMap) throws ParseException{
		
		ArrayList<BigDecimal> roleNumberlist = new ArrayList<BigDecimal>();
		
	
		    
		    
		    
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "DEL_LIST";
		
			for(int row = 0; row < iMap.getSize(tableName); row++){
				BigDecimal delNumara = iMap.getBigDecimal(tableName, row, "KEY");
				Object o = findRol(delNumara);
				if(o != null){
					session.delete(o);
	
				}
			}
			
			tableName = "ROL_LIST";
					
			for(int row = 0; row < iMap.getSize(tableName); row++){
				BigDecimal Numara = iMap.getBigDecimal(tableName, row, "NUMARA");
				GnlRol gnlRol;
				gnlRol = findRol(Numara);
				if( gnlRol == null){
				
					gnlRol = new GnlRol(); 
					gnlRol.setNumara(Numara);
					
					if (iMap.getDate(tableName, row, "BASLANGIC_TARIHI") == null){
					    throw new GMRuntimeException(99201,"Ba�lang�� tarihi bo� kay�t tabloya kaydedilemez!. B�t�n ba�lang�� tarihlerini doldurunuz!");
					}else{
						gnlRol.setBaslangicTarihi(iMap.getDate(tableName, row, "BASLANGIC_TARIHI"));
					}
					
					if (StringUtil.isEmpty( iMap.getString(tableName, row, "BOLUM_KOD")))
					{
					    throw new GMRuntimeException(99201,"B�l�m kodlar�n� giriniz! B�l�m kodu bo� kay�t tabloya kaydedilemez!");
					}
					
					gnlRol.setBitisTarihi(iMap.getDate(tableName, row, "BITIS_TARIHI"));
					gnlRol.setTanim(iMap.getString(tableName, row, "TANIM"));
					gnlRol.setSK(iMap.getString(tableName, row, "ROL_TIPI"));
					gnlRol.setBolumKod(iMap.getString(tableName, row, "BOLUM_KOD"));
					
					saveOrNot(gnlRol.getNumara(), roleNumberlist);					
					roleNumberlist.add(gnlRol.getNumara());
					
					session.saveOrUpdate(gnlRol);
				}
				else{
				
					if (iMap.getDate(tableName, row, "BASLANGIC_TARIHI") == null){
					    throw new GMRuntimeException(99201,"Ba�lang�� tarihi bo� kay�t tabloya eklenemez. B�t�n ba�lang�� tarihlerini doldurunuz!");					  
					}else{
						gnlRol.setBaslangicTarihi(iMap.getDate(tableName, row, "BASLANGIC_TARIHI"));
					}
					
					if (StringUtil.isEmpty( iMap.getString(tableName, row, "BOLUM_KOD")))
                    {
                        throw new GMRuntimeException(99201,"B�l�m kodlar�n� giriniz! B�l�m kodu bo� kay�t tabloya kaydedilemez! B�t�n b�l�m kodlar�n� doldurunuz!");
                    }
					gnlRol.setBitisTarihi(iMap.getDate(tableName, row, "BITIS_TARIHI"));
					gnlRol.setTanim(iMap.getString(tableName, row, "TANIM"));
					gnlRol.setSK(iMap.getString(tableName, row, "ROL_TIPI"));
					gnlRol.setBolumKod(iMap.getString(tableName, row, "BOLUM_KOD"));
					
					saveOrNot(gnlRol.getNumara(), roleNumberlist);                 
                    roleNumberlist.add(gnlRol.getNumara());
				
					session.saveOrUpdate(gnlRol);
				}
				
			}
		
			session.flush();
			
			iMap.put("MESSAGE_NO", 1544);
			oMap.put("MESSAGE",GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return oMap;
	}

	
	public static GnlRol findRol(BigDecimal key){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlRol)session.get(GnlRol.class, key);
	}
	
	private static void  saveOrNot(BigDecimal roleNumber, ArrayList<BigDecimal> roleNumberlist) {
	    GMMap iMap = new GMMap();
	    if(roleNumberlist.contains(roleNumber)){
            iMap.put("HATA_NO", new BigDecimal(660));
            iMap.put("P1", "Ayn� Rol Numaras�na sahip birden fazla kay�t girilemez: "+ roleNumber);
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
        }
	    
	}
}
