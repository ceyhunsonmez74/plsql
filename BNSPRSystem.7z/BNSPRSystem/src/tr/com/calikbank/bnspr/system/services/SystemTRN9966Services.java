package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.GnlEkranSahipligiTx;
import tr.com.aktifbank.bnspr.dao.GnlEkranSahipligiTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9966Services {
	
	
	
	@GraymoundService("BNSPR_TRN9966_GET_COMBO_E_H")
	public static GMMap getComboModel(GMMap iMap){
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		

		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL2", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9966_SAVE")
	public static GMMap save(GMMap iMap){
		String emptyField="";
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "ISLEM_LIST";
			List<?> islemList = (List<?>)iMap.get(tableName);
			for(int i = 0; i < islemList.size(); i++)
			{
				GnlEkranSahipligiTx gnlEkranSahipligiTx = new GnlEkranSahipligiTx();
				GnlEkranSahipligiTxId id = new GnlEkranSahipligiTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				if(iMap.getString(tableName, i, "EKRAN_KODU") == null || "".equals(iMap.getString(tableName, i, "EKRAN_KODU"))){
					emptyField =  "EKRAN_KODU"; }
				id.setEkranKod(iMap.getString(tableName, i, "EKRAN_KODU"));
				if(iMap.getString(tableName, i, "MODUL") == null || "".equals(iMap.getString(tableName, i, "MODUL"))){
					emptyField =  "MODUL"; }
				gnlEkranSahipligiTx.setModulTurKod(iMap.getString(tableName, i, "MODUL"));
				
				if(iMap.getString(tableName, i, "BOLUM_KODU") == null || "".equals(iMap.getString(tableName, i, "BOLUM_KODU"))){
					emptyField =  "BOLUM_KODU"; }
				gnlEkranSahipligiTx.setBolumKod(iMap.getString(tableName, i, "BOLUM_KODU"));
				
				if(iMap.getString(tableName, i, "BOLUM_KODU2") == null || "".equals(iMap.getString(tableName, i, "BOLUM_KODU2"))){
					emptyField =  "BOLUM_KODU2"; }
				gnlEkranSahipligiTx.setBolumKod2(iMap.getString(tableName, i, "BOLUM_KODU2"));
				
		/*		if(iMap.getDate(tableName, i, "PROD_TARIHI") == null || "".equals(iMap.getDate(tableName, i, "PROD_TARIHI"))){
					emptyField =  "PROD_TARIHI"; }
				gnlEkranSahipligiTx.setProdTarihi(iMap.getDate(tableName, i, "PROD_TARIHI"));  */
				
				/*if(iMap.get(tableName, i, "SIL")!= null && iMap.getBoolean(tableName, i, "SIL"))
					gnlEkranSahipligiTx.setGDS("S");
				else
					if("E".equals(iMap.getString(tableName, i, "ESKI_KAYIT")))
						gnlEkranSahipligiTx.setGDS("D");
					else
						gnlEkranSahipligiTx.setGDS("G");*/
				
				gnlEkranSahipligiTx.setTur("ISLEM");
				gnlEkranSahipligiTx.setId(id);
				session.saveOrUpdate(gnlEkranSahipligiTx);
			}
			
			tableName = "TIR_LIST";
			List<?> tirList = (List<?>)iMap.get(tableName);
			for(int i = 0; i < tirList.size(); i++)
			{
				GnlEkranSahipligiTx gnlEkranSahipligiTx = new GnlEkranSahipligiTx();
				GnlEkranSahipligiTxId id = new GnlEkranSahipligiTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				if(iMap.getString(tableName, i, "EKRAN_KODU") == null || "".equals(iMap.getString(tableName, i, "EKRAN_KODU"))){
					emptyField =  "EKRAN_KODU"; }
				id.setEkranKod(iMap.getString(tableName, i, "EKRAN_KODU"));
				

               if(iMap.getString(tableName, i, "BOLUM_KODU") == null || "".equals(iMap.getString(tableName, i, "BOLUM_KODU"))){
					emptyField =  "BOLUM_KODU"; }
                gnlEkranSahipligiTx.setBolumKod(iMap.getString(tableName, i, "BOLUM_KODU"));
                
                if(iMap.getString(tableName, i, "BOLUM_KODU2") == null || "".equals(iMap.getString(tableName, i, "BOLUM_KODU2"))){
					emptyField =  "BOLUM_KODU2"; }
                gnlEkranSahipligiTx.setBolumKod2(iMap.getString(tableName, i, "BOLUM_KODU2"));
                
                
             /*   if(iMap.getDate(tableName, i, "PROD_TARIHI") == null || "".equals(iMap.getDate(tableName, i, "PROD_TARIHI"))){
					emptyField =  "PROD_TARIHI"; }
                gnlEkranSahipligiTx.setProdTarihi(iMap.getDate(tableName, i, "PROD_TARIHI"));*/
                
                
				if(iMap.getString(tableName, i, "MODUL") == null || "".equals(iMap.getString(tableName, i, "MODUL"))){
					emptyField =  "MODUL_KODU"; }
				gnlEkranSahipligiTx.setModulTurKod(iMap.getString(tableName, i, "MODUL"));
				
				/*if(iMap.get(tableName, i, "SIL")!= null && iMap.getBoolean(tableName, i, "SIL"))
					gnlEkranSahipligiTx.setGDS("S");
				else
					if("E".equals(iMap.getString(tableName, i, "ESKI_KAYIT")))
						gnlEkranSahipligiTx.setGDS("D");
					else
						gnlEkranSahipligiTx.setGDS("G");*/
				
				gnlEkranSahipligiTx.setTur("DIGER");
				gnlEkranSahipligiTx.setId(id);
				session.saveOrUpdate(gnlEkranSahipligiTx);
			}
			
			tableName = "NOVA_LIST";
            List<?> novaList = (List<?>)iMap.get(tableName);
            for(int i = 0; i < novaList.size(); i++)
            {
                GnlEkranSahipligiTx gnlEkranSahipligiTx = new GnlEkranSahipligiTx();
                GnlEkranSahipligiTxId id = new GnlEkranSahipligiTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                if(iMap.getString(tableName, i, "EKRAN_KODU") == null || "".equals(iMap.getString(tableName, i, "EKRAN_KODU"))){
                    emptyField =  "EKRAN_KODU"; }
                id.setEkranKod(iMap.getString(tableName, i, "EKRAN_KODU"));
                
                if(iMap.getString(tableName, i, "BOLUM_KODU") == null || "".equals(iMap.getString(tableName, i, "BOLUM_KODU"))){
                    emptyField =  "BOLUM_KODU"; }
                gnlEkranSahipligiTx.setBolumKod(iMap.getString(tableName, i, "BOLUM_KODU"));
                
                if(iMap.getString(tableName, i, "BOLUM_KODU2") == null || "".equals(iMap.getString(tableName, i, "BOLUM_KODU2"))){
                    emptyField =  "BOLUM_KODU2"; }
                gnlEkranSahipligiTx.setBolumKod2(iMap.getString(tableName, i, "BOLUM_KODU2"));
                
              /*  if(iMap.getString(tableName, i, "MODUL") == null || "".equals(iMap.getString(tableName, i, "MODUL"))){
                    emptyField =  "MODUL_KODU"; }*/
                gnlEkranSahipligiTx.setModulTurKod("NOVA");
                
                gnlEkranSahipligiTx.setTur("NOVA");
                gnlEkranSahipligiTx.setId(id);
                session.saveOrUpdate(gnlEkranSahipligiTx);
            }
            
	        session.flush();
			iMap.put("TRX_NAME", "9966");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException ex) {
			GMMap myMap = new GMMap();
            myMap.put("MESSAGE_NO", new java.math.BigDecimal(330));
            myMap.put("P1", emptyField );
            throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}catch (org.hibernate.NonUniqueObjectException ex) {
			GMMap myMap = new GMMap();
            myMap.put("MESSAGE_NO", new java.math.BigDecimal(716));
            throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_QRY9966_GET_EKRAN_LIST")
	public static Map<?, ?> getEkranList(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN9966.RC9966_Ekran_Sahipligi(?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("MODUL_TUR_KOD"));
			stmt.setString(3, iMap.getString("PROGRAM_KOD"));
			stmt.setString(4, iMap.getString("BOLUM_KOD"));
			stmt.setString(5, iMap.getString("BOLUM_KOD2"));
			stmt.setString(6, iMap.getString("TUR"));
			
			if(iMap.getDate("PROD_TAR_BAS") != null)
				stmt.setDate(7,  new java.sql.Date(iMap.getDate("PROD_TAR_BAS").getTime()));
			else
				stmt.setDate(7, null);
			if(iMap.getDate("PROD_TAR_BIT") != null)
				stmt.setDate(8,  new java.sql.Date(iMap.getDate("PROD_TAR_BIT").getTime()));
			else
				stmt.setDate(8, null);
			stmt.execute();
			
	
			String tableName = "EKRAN_LIST";
			rSet = (ResultSet)stmt.getObject(1);
			int row = 0;
			while(rSet.next())
			{
				oMap.put(tableName, row, "MODUL", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, row, "EKRAN_KODU", rSet.getString("EKRAN_KOD"));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "BOLUM_KODU", rSet.getString("BOLUM_KOD"));
				oMap.put(tableName, row, "BOLUM_KODU2", rSet.getString("BOLUM_KOD2"));
				oMap.put(tableName, row, "BOLUM_ADI", rSet.getString("BOLUM_ADI"));
				oMap.put(tableName, row, "BOLUM_ADI2", rSet.getString("BOLUM_ADI2"));
				oMap.put(tableName, row, "PROD_TARIHI", rSet.getDate("PROD_TARIHI"));
				oMap.put(tableName, row, "TUR", LovHelper.diLov(rSet.getString("EKRAN_KOD"),"9966/LOV_EKRAN_TUR", "TUR"));
				oMap.put(tableName, row, "MENUDE_LISTELENSIN_MI", rSet.getString("MENUDE_LISTELENSIN_MI"));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString("IPTAL_EDILEBILIR_MI"));
				oMap.put(tableName, row, "BOLUM_KODU_DURUM", rSet.getString("BOLUM_KODU_DURUM"));
				oMap.put(tableName, row, "BOLUM_KODU_DURUM_2", rSet.getString("BOLUM_KODU_DURUM_2"));
				//oMap.put(tableName, row, "ESKI_KAYIT", "E");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_TRN9966_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap){
		Session session = DAOSession.getSession("BNSPRDal");
		try{
			GMMap oMap = new GMMap();
			List<?> recordList = (List<?>)session.createCriteria(GnlEkranSahipligiTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
			.add(Restrictions.eq("tur", "ISLEM"))
			.list();
			
			String tableName = "ISLEM_LIST";
            for (int row = 0; row < recordList.size(); row++) {
                  GnlEkranSahipligiTx gnlEkranSahipligiTx = (GnlEkranSahipligiTx)recordList.get(row);
                  oMap.put(tableName,row, "BOLUM_KODU", gnlEkranSahipligiTx.getBolumKod());
                  oMap.put(tableName,row, "BOLUM_KODU2", gnlEkranSahipligiTx.getBolumKod2());
                  oMap.put(tableName,row, "MODUL", gnlEkranSahipligiTx.getModulTurKod());
                  oMap.put(tableName,row, "EKRAN_KODU", gnlEkranSahipligiTx.getId().getEkranKod());
                  oMap.put(tableName, row, "EKRAN_ADI", LovHelper.diLov(gnlEkranSahipligiTx.getId().getEkranKod(), 
                              gnlEkranSahipligiTx.getModulTurKod(),
                             "9966/LOV_EKRAN_KODU","ACIKLAMA"));
                  oMap.put(tableName, row, "BOLUM_ADI", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod(), 
                             "9966/LOV_BOLUM_KODU","ACIKLAMA"));
                  oMap.put(tableName, row, "BOLUM_ADI2", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod2(), 
                          "9966/LOV_BOLUM_KODU","ACIKLAMA"));
                 // oMap.put(tableName,row, "PROD_TARIHI", gnlEkranSahipligiTx.getProdTarihi());
  				  oMap.put(tableName, row, "TUR", LovHelper.diLov(gnlEkranSahipligiTx.getId().getEkranKod(),"9966/LOV_EKRAN_TUR", "TUR"));
  				  oMap.put(tableName, row, "BOLUM_KODU_DURUM", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod(), 
                         "9966/LOV_BOLUM_KODU","DURUM_KODU"));
  				  oMap.put(tableName, row, "BOLUM_KODU_DURUM_2", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod2(), 
                         "9966/LOV_BOLUM_KODU","DURUM_KODU"));
                 
  				 /* if("S".equals(gnlEkranSahipligiTx.getGDS()))
                  oMap.put(tableName,row, "SIL", true); 
                  oMap.put(tableName, row, "ESKI_KAYIT", "E"); */
            }
            
            recordList = (List<?>)session.createCriteria(GnlEkranSahipligiTx.class)
            .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
            .add(Restrictions.eq("tur", "DIGER"))
            .list();
            
            tableName = "TIR_LIST";
            for (int row = 0; row < recordList.size(); row++) {
                  GnlEkranSahipligiTx gnlEkranSahipligiTx = (GnlEkranSahipligiTx)recordList.get(row);
                  oMap.put("TRX_NO", gnlEkranSahipligiTx.getId().getTxNo());
                  oMap.put(tableName,row, "BOLUM_KODU", gnlEkranSahipligiTx.getBolumKod());
                  oMap.put(tableName,row, "BOLUM_KODU2", gnlEkranSahipligiTx.getBolumKod2());
                  oMap.put(tableName,row, "MODUL", gnlEkranSahipligiTx.getModulTurKod());
                  oMap.put(tableName,row, "EKRAN_KODU", gnlEkranSahipligiTx.getId().getEkranKod());
                  oMap.put(tableName, row, "EKRAN_ADI", LovHelper.diLov(gnlEkranSahipligiTx.getId().getEkranKod(), 
                             gnlEkranSahipligiTx.getModulTurKod(),
                             "9966/LOV_EKRAN_KODU_DIGER","ACIKLAMA"));
                  oMap.put(tableName, row, "BOLUM_ADI", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod(), 
                             "9966/LOV_BOLUM_KODU","ACIKLAMA"));
                  oMap.put(tableName, row, "BOLUM_ADI2", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod2(), 
                          "9966/LOV_BOLUM_KODU","ACIKLAMA"));
               //   oMap.put(tableName,row, "PROD_TARIHI", gnlEkranSahipligiTx.getProdTarihi());
  				  oMap.put(tableName, row, "TUR", LovHelper.diLov(gnlEkranSahipligiTx.getId().getEkranKod(),"9966/LOV_EKRAN_TUR", "TUR"));
  				oMap.put(tableName, row, "BOLUM_KODU_DURUM", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod(), 
                        "9966/LOV_BOLUM_KODU","DURUM_KODU"));
  				oMap.put(tableName, row, "BOLUM_KODU_DURUM_2", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod2(), 
                        "9966/LOV_BOLUM_KODU","DURUM_KODU"));
                  /* if("S".equals(gnlEkranSahipligiTx.getGDS()))
                      oMap.put(tableName,row, "SIL", true);
                  oMap.put(tableName, row, "ESKI_KAYIT", "E"); */
            }
            
            recordList = (List<?>)session.createCriteria(GnlEkranSahipligiTx.class)
                    .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
                    .add(Restrictions.eq("tur", "NOVA"))
                    .list();
                    
                    tableName = "NOVA_LIST";
                    for (int row = 0; row < recordList.size(); row++) {
                          GnlEkranSahipligiTx gnlEkranSahipligiTx = (GnlEkranSahipligiTx)recordList.get(row);
                          oMap.put("TRX_NO", gnlEkranSahipligiTx.getId().getTxNo());
                          oMap.put(tableName,row, "BOLUM_KODU", gnlEkranSahipligiTx.getBolumKod());
                          oMap.put(tableName,row, "BOLUM_KODU2", gnlEkranSahipligiTx.getBolumKod2());
                          //oMap.put(tableName,row, "MODUL", gnlEkranSahipligiTx.getModulTurKod());
                          oMap.put(tableName,row, "EKRAN_KODU", gnlEkranSahipligiTx.getId().getEkranKod());
                          oMap.put(tableName, row, "EKRAN_ADI", LovHelper.diLov(gnlEkranSahipligiTx.getId().getEkranKod(), 
                                    "9966/LOV_EKRAN_KODU_NOVA","ACIKLAMA"));
                          oMap.put(tableName, row, "BOLUM_ADI", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod(), 
                                     "9966/LOV_BOLUM_KODU","ACIKLAMA"));
                          oMap.put(tableName, row, "BOLUM_ADI2", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod2(), 
                                  "9966/LOV_BOLUM_KODU","ACIKLAMA"));
                       //   oMap.put(tableName,row, "PROD_TARIHI", gnlEkranSahipligiTx.getProdTarihi());
                          oMap.put(tableName, row, "TUR", LovHelper.diLov(gnlEkranSahipligiTx.getId().getEkranKod(),"9966/LOV_EKRAN_TUR", "TUR"));
                        oMap.put(tableName, row, "BOLUM_KODU_DURUM", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod(), 
                                "9966/LOV_BOLUM_KODU","DURUM_KODU"));
                        oMap.put(tableName, row, "BOLUM_KODU_DURUM_2", LovHelper.diLov(gnlEkranSahipligiTx.getBolumKod2(), 
                                "9966/LOV_BOLUM_KODU","DURUM_KODU"));
                      
                    }
            return oMap;
      }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
      }
  }	
}
