package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlVadeliScfOraniTx;
import tr.com.aktifbank.bnspr.dao.GnlVadeliScfOraniTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9908Services {
	
	
	@GraymoundService("BNSPR_TRN9908_FILL_COMBOBOX")
	public static GMMap fillCombobox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
		 

		/* ** Islem Kanali ** */
		 DALUtil.fillComboBox(oMap, "ISLEM_KANALI", false,
         		"select null kod,'Hepsi' aciklama from dual union select KOD, ACIKLAMA from v_ml_gnl_kanal_grup_kod_pr where KOD in (1,4,5,6,7,10,40,53,55)");

		 return oMap;
	    } catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }
		}
		
	@GraymoundService("BNSPR_TRN9908_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		BigDecimal sporlu=null;
		
		
		try{
			
			if (iMap.getBoolean("SPORLU"))
				sporlu=new BigDecimal(1);
		 
			conn = DALUtil.getGMConnection();
						
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> listScf = session.createQuery(
					"from GnlVadeliScfOraniTx where id.txNo =:TRX_NO ")
					.setBigDecimal("TRX_NO", iMap.getBigDecimal("TRX_NO"))
					.list();

			for (Object name : listScf) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) name;
				session.delete(gnlVadeliScfOraniTx);
			}
			session.flush();
			
			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				if (iMap.getString(tableName, row, "VADE_ARALIGI") != null) {
					GnlVadeliScfOraniTx gnlVadeliScfOraniTx = new GnlVadeliScfOraniTx();
					GnlVadeliScfOraniTxId gnlVadeliScfOraniTxId = new GnlVadeliScfOraniTxId();
					gnlVadeliScfOraniTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					
					if ( iMap.getBigDecimal(tableName, row, "KOD") == null ) { 
						stmt = conn.prepareCall("{? = call PKG_GENEL_PR.genel_kod_al('GNL_VADELI_SCF_ORANLARI')}"); 
						stmt.registerOutParameter(1, Types.DECIMAL);
						stmt.execute();
						gnlVadeliScfOraniTxId.setKod(stmt.getBigDecimal(1));
					}
					else
						gnlVadeliScfOraniTxId.setKod(iMap.getBigDecimal(tableName, row, "KOD"));
					
					gnlVadeliScfOraniTx.setVadeAraligi(iMap.getString(tableName, row, "VADE_ARALIGI"));
	                gnlVadeliScfOraniTx.setScfUrunGrubuKod(iMap.getString(tableName, row, "SCF_URUN_GRUBU_KOD"));
	                
	                gnlVadeliScfOraniTx.setId(gnlVadeliScfOraniTxId);
	                gnlVadeliScfOraniTx.setScFaizOrani(iMap.getBigDecimal(tableName, row, "SC_FAIZ_ORANI"));
	                
	                gnlVadeliScfOraniTx.setTur(iMap.getString("TUR"));
	                gnlVadeliScfOraniTx.setFaizTur(iMap.getString("FAIZ_TURU"));
	                gnlVadeliScfOraniTx.setTarih(iMap.getDate("TARIH"));
	                gnlVadeliScfOraniTx.setDovizKodu(iMap.getString(tableName, row, "DOVIZ_KODU"));
	                
	                
	                //D delete islemi
	                if (iMap.getString(tableName, row, "SIL") == null || iMap.getString(tableName, row, "SIL").equals("0"))
	                	gnlVadeliScfOraniTx.setIslemTur("S");
	                else
	                	gnlVadeliScfOraniTx.setIslemTur("D");
	                
	                gnlVadeliScfOraniTx.setIslemKanal(iMap.getBigDecimal(tableName, row, "ISLEM_KANAL"));
	                
	                
	                gnlVadeliScfOraniTx.setSporlu(sporlu);
	                
	                session.save(gnlVadeliScfOraniTx);
				}
			}
			session.flush();
			
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				
				List<?> list = session.createCriteria(GnlVadeliScfOraniTx.class)
				.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
			    .add(Restrictions.eq("tarih", iMap.getDate("TARIH")))
				.add(Restrictions.eq("vadeAraligi", iMap.getString(tableName, row, "VADE_ARALIGI")))
			    .add(Restrictions.eq("scfUrunGrubuKod", iMap.getString(tableName, row, "SCF_URUN_GRUBU_KOD")))
			    .add(Restrictions.eq("faizTur", iMap.getString("FAIZ_TURU")))
			    .add(Restrictions.eq("islemKanal", iMap.getBigDecimal(tableName, row, "ISLEM_KANAL")))
			    .add(Restrictions.eq("dovizKodu", iMap.getString(tableName, row, "DOVIZ_KODU")))
			   // .add(Restrictions.eq("sporlu", iMap.getString(tableName, row, "SPORLU")))
				.list();
				
				if (list.size() > 1) {
					iMap.put("HATA_NO", new BigDecimal(716));
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				   
			}
						
			
			iMap.put("TRX_NAME", "9908");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}

	@GraymoundService("BNSPR_TRN9908_GET_VADELI_SCF_ORAN_BILGI")
	public static Map<?, ?> getScfOranBilgi(GMMap iMap){
	
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null; 
		BigDecimal sporlu=new BigDecimal(0);

			try{
				conn = DALUtil.getGMConnection();
 
				if (iMap.getBoolean("SPOR"))
					sporlu=new BigDecimal(1);
				
				stmt = conn.prepareCall("{call PKG_TRN9908.TRN9908_sorgula(?,?,?,?,?,?)}");
				stmt.setString(1, iMap.getString("scfUrunGrubuKod"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_KANAL"));
				stmt.setBigDecimal(3, sporlu);
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH").getTime()));
				stmt.setString(5, iMap.getString("FAIZ_TUR"));
				stmt.registerOutParameter(6, -10);
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(6);
				
				oMap.putAll(DALUtil.rSetResults(rSet, "CBS_VADELI_SCF_ORANLARI_ISL_DE"));
	 

			
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
	@GraymoundService("BNSPR_TRN9908_GET_VADELI_SCF_ORAN_LIST")
	public static GMMap getZamanPrList(GMMap iMap) {
		Date tarih = null;
		String tur = null;
		String faizTur = null;
		String ratingKodu = null;
		boolean flag = true;
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = session.createCriteria(GnlVadeliScfOraniTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.add(Restrictions.eq("id.islemKanal", iMap.getBigDecimal("ISLEM_KANAL")))
					.add(Restrictions.eq("id.scfUrunGrubuKod", iMap.getBigDecimal("scfUrunGrubuKod")))
					.list();

			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) iterator.next();
				/*
				oMap.put(tableName, row, "VADE_ARALIGI", gnlVadeliScfOraniTx.getId().getVadeAraligi());
				oMap.put(tableName, row, "SCF_URUN_GRUBU_KOD", gnlVadeliScfOraniTx.getId().getScfUrunGrubuKod());
				oMap.put(tableName, row, "TRL_FAIZ_ORANI", gnlVadeliScfOraniTx.getTrlFaizOrani());
				oMap.put(tableName, row, "USD_FAIZ_ORANI", gnlVadeliScfOraniTx.getUsdFaizOrani());
				oMap.put(tableName, row, "EUR_FAIZ_ORANI", gnlVadeliScfOraniTx.getEurFaizOrani());
				oMap.put(tableName, row, "JPY_FAIZ_ORANI", gnlVadeliScfOraniTx.getJpyFaizOrani());
				oMap.put(tableName, row, "CHF_FAIZ_ORANI", gnlVadeliScfOraniTx.getChfFaizOrani());
				oMap.put(tableName, row, "GBP_FAIZ_ORANI", gnlVadeliScfOraniTx.getGbpFaizOrani());
				oMap.put(tableName, row, "SEK_FAIZ_ORANI", gnlVadeliScfOraniTx.getSekFaizOrani());
				oMap.put(tableName, row, "DIGER_FAIZ_ORANI", gnlVadeliScfOraniTx.getDigerFaizOrani());
				if (flag) {
					tarih = gnlVadeliScfOraniTx.getTarih();
					tur = gnlVadeliScfOraniTx.getTur();
					faizTur = gnlVadeliScfOraniTx.getFaizTur();
					ratingKodu = gnlVadeliScfOraniTx.getRatingKodu();
					flag = false;
				}
				*/	
			}
			
			oMap.put("TARIH", tarih);
			oMap.put("TUR", tur);
			oMap.put("FAIZ_TUR", faizTur);
			oMap.put("RATING_KODU", ratingKodu);
			
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	
	@GraymoundService("BNSPR_TRN9908_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Connection conn =  null;
		CallableStatement stmt2 = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		
		try{

			//TRN9908_sorgulaGetInfo
				conn = DALUtil.getGMConnection();
				stmt2 = conn.prepareCall("{call PKG_TRN9908.TRN9908_sorgulaGetInfo(?,?)}");
				stmt2.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));	
				stmt2.registerOutParameter(2, -10);
				stmt2.execute();
				rSet = (ResultSet) stmt2.getObject(2);		
				String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
				int row=0;
				while(rSet.next()){
					oMap.put("TARIH", rSet.getDate("TARIH"));
					oMap.put("URUN_GRUBU", rSet.getString("SCF_URUN_GRUBU_KOD"));
					oMap.put("FAIZ_TUR", rSet.getString("faiz_tur"));
					
					
					
					oMap.put(tableName, row, "VADE_ARALIGI", rSet.getString("VADE_ARALIGI"));
					oMap.put(tableName, row, "SCF_URUN_GRUBU_KOD", rSet.getString("SCF_URUN_GRUBU_KOD"));
					oMap.put(tableName, row, "DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
					oMap.put(tableName, row, "SC_FAIZ_ORANI", rSet.getString("SC_FAIZ_ORANI"));
					oMap.put(tableName, row, "ISLEM_KANAL", rSet.getString("ISLEM_KANAL"));
					oMap.put(tableName, row, "SPORLU", rSet.getString("SPORLU"));
					oMap.put("SPORLU", rSet.getString("SPORLU")==null?false:true);
					
					stmt = conn.prepareStatement("select tur from gnl_scf_urun_grubu where kod = ?");
					stmt.setString(1,oMap.getString("URUN_GRUBU") );
					rSet2 = stmt.executeQuery();
					rSet2.next();
					
					oMap.put("TUR", rSet2.getString(1));
					
					
					//D delete islemi
					//S neden koyulmus belli degil
					if (rSet.getString("ISLEM_TUR").equals("D")) 
						oMap.put(tableName, row, "SIL", true);
					else
						oMap.put(tableName, row, "SIL", false);
					row++;
					
					GMServerDatasource.close(rSet2);
					GMServerDatasource.close(stmt);
				}
				
			//	oMap.putAll(DALUtil.rSetResults(rSet, "RC_TUM_LIST"));
			
			//	List<?> list  = (List<?>) oMap.get("RC_TUM_LIST");
//				
//			List<?> list = session.createCriteria(
//					GnlVadeliScfOraniTx.class).add(
//					Restrictions.eq("id.txNo", iMap
//							.getBigDecimal("TRX_NO"))).list();
//			
			
//			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
//			int row = 0;
//			
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			
//			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
//				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) iterator.next();
//				
//				oMap.put("TARIH", gnlVadeliScfOraniTx.getTarih());
//				oMap.put("URUN_GRUBU", gnlVadeliScfOraniTx.getScfUrunGrubuKod());
//				oMap.put("FAIZ_TUR", gnlVadeliScfOraniTx.getFaizTur());
//				
//				
//				stmt = conn.prepareStatement("select tur from gnl_scf_urun_grubu where kod = ?");
//				stmt.setString(1, gnlVadeliScfOraniTx.getScfUrunGrubuKod());
//				rSet = stmt.executeQuery();
//				rSet.next();
//				oMap.put("TUR", rSet.getString(1));
//		
//				
//				
//				
//				oMap.put(tableName, row, "VADE_ARALIGI", gnlVadeliScfOraniTx.getVadeAraligi());
//				oMap.put(tableName, row, "SCF_URUN_GRUBU_KOD", gnlVadeliScfOraniTx.getScfUrunGrubuKod());
//				oMap.put(tableName, row, "DOVIZ_KODU", gnlVadeliScfOraniTx.getDovizKodu());
//				oMap.put(tableName, row, "SC_FAIZ_ORANI", gnlVadeliScfOraniTx.getScFaizOrani());
//				if (gnlVadeliScfOraniTx.getIslemTur().equals("D")) 
//					oMap.put(tableName, row, "SIL", 1);
//				
//
//			}
			
			return oMap;
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
			
		}
	
	}
}
