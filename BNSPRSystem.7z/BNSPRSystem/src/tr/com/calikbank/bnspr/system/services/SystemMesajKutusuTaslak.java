package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class SystemMesajKutusuTaslak {
	@GraymoundService("BNSPR_MESAJ_KUTUSU_TASLAK_GET_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_MESAJ_KUTUSU_TASLAK_RECORD}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1); 
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "T_AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "T_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_ISLEM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_KAYIT_KULLANICI_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "T_KAYIT_KULLANICI_ROL_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_KAYIT_KULLANICI_BOLUM_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "T_KAYIT_TARIH", rSet.getString(j++));
				oMap.put(tableName, row, "T_MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_URUN_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_URUN_SINIF_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_MUSTERI_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_HESAP_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));			
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
        }
	}
}	
/*	@GraymoundService("BNSPR_MESAJ_KUTUSU_TASLAK_GET_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");

			GMMap oMap = new GMMap();
			StringBuffer query  = new StringBuffer();
			query.append("select a.amir_sube_kod,pkg_genel_pr.sube_adi(a.AMIR_SUBE_KOD) AMIR_SUBE_ADI,a.NUMARA,a.ISLEM_KOD,a.KAYIT_KULLANICI_KODU,a.KAYIT_KULLANICI_ROL_NUMARA,a.KAYIT_KULLANICI_BOLUM_KODU,to_char(a.KAYIT_TARIH,'dd/mm/yyyy') KAYIT_TARIH, ");
			query.append("a.MODUL_TUR_KOD,a.URUN_TUR_KOD,a.URUN_SINIF_KOD,a.MUSTERI_NUMARA,a.HESAP_NUMARA,a.TUTAR,a.DOVIZ_KOD,Pkg_genel_pr.islem_ekran_adi(a.ISLEM_KOD),a.kullanici_aciklama, ");
			query.append("a.aciklama, a.durum, a.durum_adi, ");
			query.append("a.kanal_numara, a.kanal_adi, a.kanal_alt_kod, a.kanal_alt_adi ");
			query.append("from v_muh_islem_gecici a ");
			query.append("where PKG_PERSONEL.kullanici_departmani(a.kayit_kullanici_kodu) = PKG_PERSONEL.Kullanici_Departmani(PKG_GLOBAL.GET_KULLANICIKOD) ");
			query.append(" and NVL(a.KAYIT_KULLANICI_ROL_NUMARA,0)=pkg_global.GET_ROLKOD ");
			query.append("order by a.NUMARA");

			stmt = conn.prepareStatement(query.toString());
			rSet = stmt.executeQuery();

			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "T_AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "T_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_ISLEM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_KAYIT_KULLANICI_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "T_KAYIT_KULLANICI_ROL_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_KAYIT_KULLANICI_BOLUM_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "T_KAYIT_TARIH", rSet.getString(j++));
				oMap.put(tableName, row, "T_MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_URUN_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_URUN_SINIF_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "T_MUSTERI_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_HESAP_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "T_DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));			
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));

			}

			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
        }
	}
	
}*/
