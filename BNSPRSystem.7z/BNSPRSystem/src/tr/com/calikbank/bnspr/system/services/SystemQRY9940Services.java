package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

/**
 * @author obss1
 * 
 */
public class SystemQRY9940Services {
	
	@GraymoundService("BNSPR_QRY9940_GET_ISLEM_LIST")
	public static GMMap getRecordMsjIptalKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_QRY9940_GET_RECORD(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			if(iMap.getDate("ISLEM_TARIH_BAS") != null) {
				stmt.setDate	(i++, new Date(iMap.getDate("ISLEM_TARIH_BAS").getTime()));
			}
			else {
				stmt.setDate	(i++, null);
			}
			if(iMap.getDate("ISLEM_TARIH_BIT") != null) {
				stmt.setDate	(i++, new Date(iMap.getDate("ISLEM_TARIH_BIT").getTime()));
			}
			else {
				stmt.setDate	(i++, null);
			}
			stmt.setString(i++, iMap.getString("SUBE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIS_NO"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1); 
    		String tableName = "RESULTS";
    		oMap = DALUtil.rSetResults(rSet, tableName);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY9940_GET_ISLEM_ADI")
	public static GMMap getIslemAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_genel_pr.islem_ekran_adi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, java.sql.Types.VARCHAR); 
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.execute();
    		
    		oMap.put("EKRAN_ADI", stmt.getString(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}

