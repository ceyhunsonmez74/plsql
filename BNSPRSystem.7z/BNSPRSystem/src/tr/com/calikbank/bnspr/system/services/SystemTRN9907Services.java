package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlScfOraniGirisTx;
import tr.com.calikbank.bnspr.dao.GnlScfOraniGirisTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9907Services {
	@GraymoundService("BNSPR_TRN9907_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> listScf = (List<?>) session.createQuery(
					"from GnlScfOraniGirisTx where id.txNo =:TRX_NO ")
					.setBigDecimal("TRX_NO", iMap.getBigDecimal("TRX_NO"))
					.list();
			
			for (Iterator<?> iterator = listScf.iterator(); iterator.hasNext();) {
				GnlScfOraniGirisTx gnlScfOraniGirisTx = (GnlScfOraniGirisTx) iterator.next();
				session.delete(gnlScfOraniGirisTx);
			}
			session.flush();

			String tableName = "CBS_SCF_ORANI_GIRIS_DETAY";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlScfOraniGirisTx gnlScfOraniGirisTx = new GnlScfOraniGirisTx();
				GnlScfOraniGirisTxId gnlScfOraniGirisTxId = new GnlScfOraniGirisTxId();
				gnlScfOraniGirisTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlScfOraniGirisTxId.setDovizKodu(iMap.getString(tableName, row, "DOVIZ_KODU"));		
				gnlScfOraniGirisTx.setId(gnlScfOraniGirisTxId);
				gnlScfOraniGirisTx.setFaizOrani(iMap.getBigDecimal(tableName, row, "FAIZ_ORANI"));
				gnlScfOraniGirisTx.setTarih(iMap.getDate("TARIH"));
				session.save(gnlScfOraniGirisTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "9907");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9907_GET_SCF_ORAN_BILGI")
	public static Map<?, ?> getScfOranBilgi(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_scf.gecerli_orani_kopyala(?,?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
				java.util.Date islem_tarihi = (java.util.Date) iMap.get("ISLEM_TARIHI");
				stmt.setDate(2, new java.sql.Date(islem_tarihi.getTime()));
				
				stmt.execute();
			}catch (Exception e) {
				throw new GMRuntimeException(0,e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlScfOraniGirisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "CBS_SCF_ORANI_GIRIS_DETAY";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlScfOraniGirisTx gnlScfOraniGirisTx = (GnlScfOraniGirisTx) iterator.next();
				oMap.put(tableName, row, "DOVIZ_KODU", gnlScfOraniGirisTx.getId().getDovizKodu());
				oMap.put(tableName, row, "FAIZ_ORANI", gnlScfOraniGirisTx.getFaizOrani());
				row++;
			}
			
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN9907_GET_SCF_ORAN_LIST")
	public static GMMap getScfOranList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			java.util.Date d = null;
			
			List<?> list = (List<?>) session.createCriteria(GnlScfOraniGirisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "CBS_SCF_ORANI_GIRIS_DETAY";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlScfOraniGirisTx gnlScfOraniGirisTx = (GnlScfOraniGirisTx) iterator.next();
			
				oMap.put(tableName, row, "DOVIZ_KODU", gnlScfOraniGirisTx.getId().getDovizKodu());
				oMap.put(tableName, row, "FAIZ_ORANI", gnlScfOraniGirisTx.getFaizOrani());
				d = gnlScfOraniGirisTx.getTarih();
				row++;
			}
			oMap.put("ISLEM_TARIHI",d);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
