package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HesapMailUyari;
import tr.com.aktifbank.bnspr.dao.HesapMailUyariTx;
import tr.com.aktifbank.bnspr.dao.HesapMailUyariTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9906Services {
	
	@GraymoundService("BNSPR_TRN9906_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			
			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete HesapMailUyariTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			/*
			 * tablo insert edilir
			 */
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				HesapMailUyariTx hesapMailUyariTx = new HesapMailUyariTx();
				
				//
				HesapMailUyariTxId id = new HesapMailUyariTxId();
				id.setTxNo(trxNo);
				id.setHesapNo(iMap.getBigDecimal(tableName, row, "HESAP_NO"));
				//
				
				hesapMailUyariTx.setId(id);
				hesapMailUyariTx.setMin(iMap.getBigDecimal(tableName, row, "MIN"));
				hesapMailUyariTx.setMax(iMap.getBigDecimal(tableName, row, "MAX"));
				hesapMailUyariTx.setEmail(iMap.getString(tableName, row, "EMAIL"));
				hesapMailUyariTx.setIslemTipi(iMap.getString(tableName, row, "ISLEM_TIPI"));
				hesapMailUyariTx.setMusteriTuru(iMap.getString(tableName, row, "MUSTERI_TIPI"));
				
				session.saveOrUpdate(hesapMailUyariTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "9906");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9906_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			/*
			 * INITIALIZE
			 */
			GuimlUtil.wrapMyCombo(oMap, "ISLEM_TIPI", "B", "Bakiye");
			GuimlUtil.wrapMyCombo(oMap, "ISLEM_TIPI", "K", "Kull. Bakiye");
			
			GuimlUtil.wrapMyCombo(oMap, "MUSTERI_TIPI", "UPT", "UPT");
			GuimlUtil.wrapMyCombo(oMap, "MUSTERI_TIPI", "AKTIF", "AKTIFBANK");
			
			
			/*
			 * GET INFO
			 */
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			int row = 0;
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				List<?> list = session.createCriteria(HesapMailUyariTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					HesapMailUyariTx hesapMailUyari = (HesapMailUyariTx) iterator.next();
					
					oMap.put(tableName, row, "HESAP_NO", hesapMailUyari.getId().getHesapNo());
					oMap.put(tableName, row, "MIN", hesapMailUyari.getMin());
					oMap.put(tableName, row, "MAX", hesapMailUyari.getMax());
					oMap.put(tableName, row, "EMAIL", hesapMailUyari.getEmail());
					oMap.put(tableName, row, "ISLEM_TIPI", hesapMailUyari.getIslemTipi());
					oMap.put(tableName, row, "MUSTERI_TIPI", hesapMailUyari.getMusteriTuru());
					
					row++;
				}

			} else {//yoksa ana tablo uzerinden gelsin
				
				List<?> list = session.createCriteria(HesapMailUyari.class).list();

				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					HesapMailUyari hesapMailUyari = (HesapMailUyari) iterator.next();
					
					oMap.put(tableName, row, "HESAP_NO", hesapMailUyari.getHesapNo());
					oMap.put(tableName, row, "MIN", hesapMailUyari.getMin());
					oMap.put(tableName, row, "MAX", hesapMailUyari.getMax());
					oMap.put(tableName, row, "EMAIL", hesapMailUyari.getEmail());
					oMap.put(tableName, row, "ISLEM_TIPI", hesapMailUyari.getIslemTipi());
					oMap.put(tableName, row, "MUSTERI_TIPI", hesapMailUyari.getMusteriTuru());
					
					row++;
				}
	
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}