package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9943Services {

	private static final String SCH_CONNECTION = "SCHEDULER";
	
	@GraymoundService("BNSPR_PAR9943_BATCH_ISLEM_YARAT_SCH")
	public static GMMap par9943BatchIslemYaratSch(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(BnsprCommonFunctions.remoteCall(SCH_CONNECTION, "BNSPR_PAR9943_BATCH_ISLEM_YARAT", iMap));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	
	@GraymoundService("BNSPR_PAR9943_BATCH_ISLEM_YARAT")
	public static GMMap par9943BatchIslemYarat(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_batch.Is_Yarat(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("GRUP_NO"));
			stmt.registerOutParameter(2, Types.NUMERIC);
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("LOG_NO", stmt.getBigDecimal(2));
			return oMap;

		} catch (Exception e) {
			//throw new GMRuntimeException(0, e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR9943_BATCH_PROGRAM_LOG")
	public static GMMap par9943BatchProgramLog(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			StringBuffer query = new StringBuffer();
			query.append("SELECT");
			query.append("	P.PROGRAM_KOD,TO_CHAR(P.BASLAMA_ZAMANI,'DD/MM/YYYY HH24:MI:SS') BASLAMA_ZAMANI,P.DURUM,P.GRUP_NO,P.HATA_MESAJI,P.SIRA_NO,P.TX_NO ");
			query.append("FROM");
			query.append("	GNL_BATCH_PROGRAM_LOG P ");
			query.append("WHERE P.LOG_NO = ? ");
			query.append("ORDER BY P.SIRA_NO DESC");

			stmt = conn.prepareStatement(query.toString());

			stmt.setBigDecimal(1, iMap.getBigDecimal("LOG_NO"));

			rSet = stmt.executeQuery();
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int i = 1;
				oMap.put(tableName, row, "PROGRAM_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "BASLAMA_ZAMANI", rSet.getString(i++));
				oMap.put(tableName, row, "DURUM", rSet.getString(i++));
				oMap.put(tableName, row, "GRUP_NO", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "HATA_MESAJI", rSet.getString(i++));
				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "TX_NO", rSet.getBigDecimal(i++));
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR9943_BATCH_CALISAN_PROGRAM_SETI")
	public static GMMap par9943BatchCalisanProgramSeti(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC9943.RC_QRY9943_get_list(?,?,?)}");
			int j = 1;
			stmt.registerOutParameter(j++, -10); //ref cursor
			stmt.setBigDecimal(j++, iMap.getBigDecimal("GRUP_NO"));
			stmt.setBigDecimal(j++, iMap.getBigDecimal("LOG_NO"));
			stmt.setString(j++, iMap.getString("DEGISKEN"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULTS";
			oMap = DALUtil.rSetResults(rSet, tableName);
			/*StringBuffer query = new StringBuffer();
			query.append("SELECT");
			query.append("	C.SIRA_NO,C.PROGRAM_KODU,C.DURUM ");
			query.append("FROM");
			query.append("	GNL_BATCH_CALISAN_PROGRAM_SETI C ");
			query.append("WHERE C.GRUP_NO = ? ");
			query.append("ORDER BY C.SIRA_NO ");
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("GRUP_NO"));
			rSet = stmt.executeQuery();
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int i = 1;
				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "PROGRAM_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "DURUM", rSet.getString(i++));
			}*/
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR9943_CALISAN_PROGRAM_SETI_DURUM")
	public static GMMap getBAKods(GMMap iMap) {
	
		try{
			return DALUtil.fillComboBox(iMap, "DURUM", false, "select key1, text from v_ml_gnl_param_text where kod = 'BATCH_CALISAN_PROGRAM_SETI_DURUM' order by text");

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_PAR9943_UPDATE_BATCH_CALISAN_PROGRAM_SETI")
	public static GMMap par9943UpdateBatchCalisanProgramSeti(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("DELETE GNL_BATCH_CALISAN_PROGRAM_SETI WHERE GRUP_NO = ?");
			stmt.setBigDecimal(1, iMap.getBigDecimal("GRUP_NO"));
			stmt.execute();
			GMServerDatasource.close(stmt);
			
			String tableName = "TBL_DEVAM";

			stmt = conn.prepareStatement("INSERT INTO GNL_BATCH_CALISAN_PROGRAM_SETI (GRUP_NO,SIRA_NO,PROGRAM_KODU,DURUM) VALUES (?,?,?,?)");

			int j;

			tableName = "TBL_DEVAM";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				j = 1;
				stmt.setBigDecimal(j++, iMap.getBigDecimal("GRUP_NO"));
				stmt.setBigDecimal(j++, iMap.getBigDecimal(tableName, row, "SIRA_NO"));
				stmt.setString(j++, iMap.getString(tableName, row, "PROGRAM_KOD"));
				stmt.setString(j++, iMap.getString(tableName, row, "DURUM"));

				stmt.execute();
			}

			oMap.put("MESSAGE", "��lem Tamamlanm��t�r.");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_PAR9943_BATCH_DEVAM_SCH")
	public static GMMap par9943BatchDevamSch(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(BnsprCommonFunctions.remoteCall(SCH_CONNECTION, "BNSPR_PAR9943_BATCH_DEVAM", iMap));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9943_BATCH_DEVAM")
	public static GMMap par9943BatchDevam(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		PreparedStatement stmt1 = null;
		CallableStatement stmt2 = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			String query = new String();
		   // query  = "UPDATE GNL_BATCH_LOG SET DURUM = 'P' WHERE LOG_NO = ? "; Bu kisim buradan degil packagedan update olmali...MHA 151208		 
		    
			query = "{CALL PKG_BATCH.Set_Kaydet_Kontrol(?,?)}";
		    stmt = conn.prepareCall(query.toString());
		    stmt.setBigDecimal(1, iMap.getBigDecimal("GRUP_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("LOG_NO"));
			stmt.execute();
			
			query = "{CALL PKG_BATCH.IS_DURDUR(?,?)}";
		    stmt1 = conn.prepareCall(query.toString());
		    stmt1.setBigDecimal(1, iMap.getBigDecimal("GRUP_NO"));
			stmt1.setBigDecimal(2, iMap.getBigDecimal("LOG_NO"));
			
			stmt1.execute();
			
			query = "{CALL PKG_BATCH.BATCH_YONETICISI(?,?)}";
			
		    stmt2 = conn.prepareCall(query.toString());			
		    stmt2.setBigDecimal(1, iMap.getBigDecimal("GRUP_NO"));
			stmt2.setBigDecimal(2, iMap.getBigDecimal("LOG_NO"));
			
			stmt2.execute();
			
			return oMap;
		} catch (Exception e) {
			//throw new GMRuntimeException(0, e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_PAR9943_EODMESAJ")
	public static GMMap par9943EODMesaj(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{ ? = call PKG_RC9943.RC_QRY9943_EOD_Mesaj(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("GRUP_NO"));
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("MESAJ", stmt.getString(1));
			return oMap;

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}