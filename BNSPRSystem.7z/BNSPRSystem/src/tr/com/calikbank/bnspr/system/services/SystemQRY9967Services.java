package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9967Services {
	
	@GraymoundService("BNSPR_QRY9967_GET_ROL_YETKI")
	public static Map<?, ?> getRolYetki(GMMap iMap){
		GMMap oMap = new GMMap();
		
		oMap.putAll(getItrYetki(iMap));
		oMap.putAll(getIslemGiris(iMap));
 	    oMap.putAll(getDogrulama(iMap));
		oMap.putAll(getOnay(iMap));
	    oMap.putAll(getIptal(iMap));
		oMap.putAll(getIptalOnay(iMap));
		
		return oMap;
	}
	
	public static Map<?, ?> getItrYetki(GMMap iMap){
  	GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9967.RC_RC9967_Izl_Tanim_Rapor(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ROL_NO"));
			stmt.setString(3, iMap.getString("EKRAN_KODU"));
			stmt.setString(4, iMap.getString("KULLANICI_KODU"));
			
			
			stmt.execute();
			String tableName = "ITR_YETKI";
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, tableName);

		return oMap;
		}catch (Exception e) {
		    throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
	public static Map<?, ?> getIslemGiris(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9967.RC_RC9967_Islem(?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ROL_NO"));
			stmt.setString(3, iMap.getString("EKRAN_KODU"));
			stmt.setString(4, iMap.getBoolean("GIRIS") ? "1" : "0");
			stmt.setString(5, iMap.getBoolean("DOGRULAMA") ? "1" : "0");
			stmt.setString(6, iMap.getBoolean("ONAY") ? "1" : "0");
			stmt.setString(7, iMap.getBoolean("IPTAL") ? "1" : "0");
			stmt.setString(8, iMap.getBoolean("IPTAL_ONAY") ? "1" : "0");
			stmt.setString(9, iMap.getString("KULLANICI_KODU"));
			
			//adkKanalBlokeRolTx.setGDS(iMap.getBoolean(tableName, i, "SIL") ? "S" : "D");

			
			
			stmt.execute();
			String tableName = "ISLEM_GIRIS";
			rSet = (ResultSet)stmt.getObject(1);
			
			
			oMap = DALUtil.rSetResults(rSet, tableName);

		return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
	public static Map<?, ?> getDogrulama(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9967.RC_RC9967_Dogrulama(?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ROL_NO"));
			stmt.setString(3, iMap.getString("EKRAN_KODU"));
			stmt.setString(4, iMap.getBoolean("GIRIS") ? "1" : "0");
			stmt.setString(5, iMap.getBoolean("DOGRULAMA") ? "1" : "0");
			stmt.setString(6, iMap.getBoolean("ONAY") ? "1" : "0");
			stmt.setString(7, iMap.getBoolean("IPTAL") ? "1" : "0");
			stmt.setString(8, iMap.getBoolean("IPTAL_ONAY") ? "1" : "0");
			stmt.setString(9, iMap.getString("KULLANICI_KODU"));
			
			stmt.execute();
			String tableName = "DOGRULAMA";
			rSet = (ResultSet)stmt.getObject(1);
			
			
			oMap = DALUtil.rSetResults(rSet, tableName);

		return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
	public static Map<?, ?> getOnay(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9967.RC_RC9967_Onay(?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ROL_NO"));
			stmt.setString(3, iMap.getString("EKRAN_KODU"));
			stmt.setString(4, iMap.getBoolean("GIRIS") ? "1" : "0");
			stmt.setString(5, iMap.getBoolean("DOGRULAMA") ? "1" : "0");
			stmt.setString(6, iMap.getBoolean("ONAY") ? "1" : "0");
			stmt.setString(7, iMap.getBoolean("IPTAL") ? "1" : "0");
			stmt.setString(8, iMap.getBoolean("IPTAL_ONAY") ? "1" : "0");
			stmt.setString(9, iMap.getString("KULLANICI_KODU"));
			
			
			stmt.execute();
			String tableName = "ONAY";
			rSet = (ResultSet)stmt.getObject(1);
		
			
			oMap = DALUtil.rSetResults(rSet, tableName);

		return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
	public static Map<?, ?> getIptal(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9967.RC_RC9967_Iptal(?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ROL_NO"));
			stmt.setString(3, iMap.getString("EKRAN_KODU"));
			stmt.setString(4, iMap.getBoolean("GIRIS") ? "1" : "0");
			stmt.setString(5, iMap.getBoolean("DOGRULAMA") ? "1" : "0");
			stmt.setString(6, iMap.getBoolean("ONAY") ? "1" : "0");
			stmt.setString(7, iMap.getBoolean("IPTAL") ? "1" : "0");
			stmt.setString(8, iMap.getBoolean("IPTAL_ONAY") ? "1" : "0");
			stmt.setString(9, iMap.getString("KULLANICI_KODU"));
			
			stmt.execute();
			String tableName = "IPTAL";
			rSet = (ResultSet)stmt.getObject(1);
			
			
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			GMServerDatasource.close(rSet);
		return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
	public static Map<?, ?> getIptalOnay(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9967.RC_RC9967_Iptal_Onay(?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ROL_NO"));
			stmt.setString(3, iMap.getString("EKRAN_KODU"));
			stmt.setString(4, iMap.getBoolean("GIRIS") ? "1" : "0");
			stmt.setString(5, iMap.getBoolean("DOGRULAMA") ? "1" : "0");
			stmt.setString(6, iMap.getBoolean("ONAY") ? "1" : "0");
			stmt.setString(7, iMap.getBoolean("IPTAL") ? "1" : "0");
			stmt.setString(8, iMap.getBoolean("IPTAL_ONAY") ? "1" : "0");
			stmt.setString(9, iMap.getString("KULLANICI_KODU"));
			
			
			stmt.execute();
			String tableName = "IPTAL_ONAY";
			rSet = (ResultSet)stmt.getObject(1);
			
		
			oMap = DALUtil.rSetResults(rSet, tableName);

		return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
	@GraymoundService("BNSPR_QRY9967_GET_ITR_HISTORY")
   
	public static Map<?, ?> getItrHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9967.RC_QRY9967_YETKI_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ROL_NO"));
            stmt.setString(3, iMap.getString("EKRAN_KODU"));
           
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }
    @GraymoundService("BNSPR_QRY9967_GET_ISLEM_HISTORY")
    
    public static Map<?, ?> getIslemHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9967.RC_QRY9967_ISLEM_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ROL_NO"));
            stmt.setString(3, iMap.getString("EKRAN_KODU"));
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }

    @GraymoundService("BNSPR_QRY9967_GET_DOGRULAMA_HISTORY")
    
    public static Map<?, ?> getDogrulamaHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9967.RC_QRY9967_DOGRULAMA_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ROL_NO"));
            stmt.setString(3, iMap.getString("EKRAN_KODU"));
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }
    

    @GraymoundService("BNSPR_QRY9967_GET_ONAY_HISTORY")
    
    public static Map<?, ?> getOnayHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9967.RC_QRY9967_ONAY_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ROL_NO"));
            stmt.setString(3, iMap.getString("EKRAN_KODU"));
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }


    @GraymoundService("BNSPR_QRY9967_GET_IPTAL_HISTORY")
    
    public static Map<?, ?> getIptalHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9967.RC_QRY9967_IPTAL_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ROL_NO"));
            stmt.setString(3, iMap.getString("EKRAN_KODU"));
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }
    
   @GraymoundService("BNSPR_QRY9967_GET_IPTAL_ONAY_HISTORY")
    
    public static Map<?, ?> getIptalOnayHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9967.RC_QRY9967_IPTAL_ONAY_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ROL_NO"));
            stmt.setString(3, iMap.getString("EKRAN_KODU"));
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }
   
   
   @GraymoundService("BNSPR_QRY9967_GET_COMBO_E_H")
	public static GMMap getComboModel(GMMap iMap){
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL_YETKI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		

		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL_ISLEM_GIRIS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL_DOGRULAMA", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL_ONAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL_IPTAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL_IPTAL_ONAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
}
