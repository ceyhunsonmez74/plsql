package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.aktifbank.bnspr.dao.GnlBatchBilgilendirmeDetayId;
import tr.com.aktifbank.bnspr.dao.MuhGeciciHesapTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlPostaKodPr;
import tr.com.calikbank.bnspr.dao.GnlPostaKodPrId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9932Services {
	@GraymoundService("BNSPR_PAR9932_GET_POSTA_KOD_TANIM")
	public static Map<?,?> getPostaKodTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listPostaKodu = (List<?>) session.createCriteria(GnlPostaKodPr.class).addOrder(Order.asc("id.ilKod")).list();
			String tableName = "POSTA_KOD_TANIM";
			int row = 0;
			for (Iterator<?> iterator = listPostaKodu.iterator(); iterator.hasNext(); row++) {
				GnlPostaKodPr gnlPostaKodPr = (GnlPostaKodPr) iterator.next();
			
				
				oMap.put(tableName, row, "KOD", gnlPostaKodPr.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", gnlPostaKodPr.getAciklama());
				oMap.put(tableName, row, "IL_KOD", gnlPostaKodPr.getId().getIlKod());
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9932_SAVE_POSTA_KOD_TANIM")
	public static Map<?,?> savePostaKodTanim(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> postaKoduPersistentList = (List<?>) session.createCriteria(GnlPostaKodPr.class).addOrder(Order.asc("id.kod")).list();
			String tableName = "POSTA_KOD_TANIM";
			
			for (Iterator<?> iterator = postaKoduPersistentList.iterator(); iterator.hasNext();) {
				GnlPostaKodPr gnlPostaKodPr = (GnlPostaKodPr) iterator.next();
					session.delete(gnlPostaKodPr);
					session.flush();
			}
			
		

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				
				Validator.checkEmpty(iMap.getString(tableName, row, "KOD"), "'Kod' alan� bo� olmaz");
			
				 for (int j = 0; j < iMap.getSize(tableName); j++){
					 if (row != j){
		                    if (iMap.getString(tableName , row , "KOD").equals(iMap.getString(tableName , j , "KOD"))&&iMap.getString(tableName , row , "IL_KOD").equals(iMap.getString(tableName , j , "IL_KOD"))){
		                        iMap.put("HATA_NO" , new BigDecimal(932));
		                        GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
		                    }
					 }
				 }
				
				GnlPostaKodPr gnlPostaKodPr = find(iMap.getString(tableName, row, "IL_KOD"),iMap.getString(tableName, row, "KOD"));
				GnlPostaKodPrId id = new GnlPostaKodPrId();
				
				if(gnlPostaKodPr == null){
					gnlPostaKodPr = new GnlPostaKodPr();
				}
				
				id.setKod(iMap.getString(tableName, row, "KOD"));
				id.setIlKod(iMap.getString(tableName, row, "IL_KOD"));
				gnlPostaKodPr.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlPostaKodPr.setId(id);
				session.saveOrUpdate(gnlPostaKodPr);
			}
		
			
			session.flush();
			HashMap<String, Object> messageMap = new HashMap<String, Object>();
			messageMap.put("MESSAGE", "��leminiz tamamland�!");
			return messageMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static GnlPostaKodPr find(String ilKod, String kod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlPostaKodPr)session.get(GnlPostaKodPr.class,new GnlPostaKodPrId(ilKod,kod));
	}
}
