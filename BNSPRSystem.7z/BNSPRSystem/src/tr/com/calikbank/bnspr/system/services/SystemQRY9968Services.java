package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9968Services {
	
	@GraymoundService("BNSPR_QRY9967_GET_KULL_ROL_TANIM")
	public static Map<?, ?> getKullRolTanim(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC9968.RC_RC9968(?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("SUBE_KOD"));
			stmt.setString(3, iMap.getString("BOLUM_KOD"));
			stmt.setString(4, iMap.getString("KULLANICI_KOD"));
			stmt.setString(5, iMap.getString("ROL_NO"));
			stmt.setString(6, iMap.getString("ERISIM_SUBE_KODU"));
			stmt.execute();
			String tableName = "ROL_TANIM";
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);

		return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
			
		}
	}
	

    
    @GraymoundService("BNSPR_QRY9968_GET_HISTORY")
   
    public static Map<?, ?> getHistory(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9968.RC_RC9968_HISTORY(?,?,?,?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("KULLANICI_KOD"));
            stmt.setString(3, iMap.getString("ROL_NO"));
        //  stmt.setString(4, iMap.getString("ERISIM_SUBE_KOD"));
            
            
           
            if ((iMap.get("TAR_SON") != null)) {
                java.util.Date son_tar = (java.util.Date) iMap
                        .get("TAR_SON");
                stmt.setDate(4, new java.sql.Date(son_tar.getTime()));
            } else {
                stmt.setDate(4, null);
            }

            if ((iMap.get("TAR_BAS") != null)) {
                java.util.Date bas_tar = (java.util.Date) iMap
                        .get("TAR_BAS");
                stmt.setDate(5, new java.sql.Date(bas_tar.getTime()));
            } else {
                stmt.setDate(5, null);
            }
            
            stmt.execute();
            String tableName = "HISTORY_TABLE";
            rSet = (ResultSet)stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tableName);

        return oMap;
        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }
    @GraymoundService("BNSPR_QRY9968_GET_ISLEM_KOD")
    
    public static Map<?, ?> getIslemKod(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_RC9968.RC9968_GET_ISLEM_KOD(?)}");
            stmt.registerOutParameter(1 ,Types.VARCHAR);
            stmt.setBigDecimal(2, iMap.getBigDecimal("TX_NO"));
            stmt.execute();
         
            oMap.put("ISLEM_KOD", stmt.getString(1));
            
            return oMap;

        }catch (Exception e) {
            throw new GMRuntimeException(0,e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }       
    }

}
