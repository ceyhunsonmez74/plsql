package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9977Services {
	
	@GraymoundService("BNSPR_QRY9977_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboboxInitialValue(GMMap iMap) {
		
		try {
			GMMap oMap = new GMMap();
			
			iMap.put("KOD", "TARIH_TIPLERI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("TARIH_TIP", GMServiceExecuter.execute(
					"BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "TATIL_DURUM_KODU");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("TATIL_DURUM", GMServiceExecuter.execute(
					"BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
	      return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	

	@GraymoundService("BNSPR_QRY9977_GET_TATIL_IZLEME_LIST")
	public static Map<?, ?> getEkranList(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC9977.QRY9977_Tatil_Tanim_Izleme(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("KOD"));
		
			if(iMap.getDate("TARIH") != null)
				stmt.setDate(3,  new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(3, null);
			
			
			if(iMap.getDate("TARIH_SON") != null)
				stmt.setDate(4,  new java.sql.Date(iMap.getDate("TARIH_SON").getTime()));
			else
				stmt.setDate(4, null);
			
			
			stmt.execute();
			
			String tableName = "TATIL_LIST";
			rSet = (ResultSet)stmt.getObject(1);
			int row = 0;
			while(rSet.next())
			{
				oMap.put(tableName, row, "KOD", rSet.getString("KOD"));
				oMap.put(tableName, row, "TARIH", rSet.getDate("TARIH"));
				oMap.put(tableName, row, "TARIH_TIP", rSet.getString("TARIH_TIP"));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "DURUM", rSet.getString("DURUM"));
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_QRY9978_GET_DOVIZ_TATIL_LIST")
	public static Map<?, ?> getDovizTatilList(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC9977.Get_Doviz_Tatil_Tanim(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("DOVIZ_KOD"));
		
			if(iMap.getDate("TARIH") != null)
				stmt.setDate(3,  new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(3, null);
			
			
			if(iMap.getDate("TARIH_SON") != null)
				stmt.setDate(4,  new java.sql.Date(iMap.getDate("TARIH_SON").getTime()));
			else
				stmt.setDate(4, null);
			
			
			stmt.execute();
			
			String tableName = "TATIL_LIST";
			rSet = (ResultSet)stmt.getObject(1);
			int row = 0;
			while(rSet.next())
			{
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString("DOVIZ_KOD"));
				oMap.put(tableName, row, "TARIH", rSet.getDate("TARIH"));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "DURUM", rSet.getString("DURUM"));
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}

	
}