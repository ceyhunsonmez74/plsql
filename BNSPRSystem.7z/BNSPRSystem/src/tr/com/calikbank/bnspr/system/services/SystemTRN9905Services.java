package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKullaniciTx;
import tr.com.calikbank.bnspr.dao.GnlZamanPrTx;
import tr.com.calikbank.bnspr.dao.GnlZamanPrTxId;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9905Services {
	
	@GraymoundService("BNSPR_TRN9905_GET_ZAMAN_ARALIGI_TANIM")
	public static GMMap getZamanAraligiTanim(GMMap iMap){
		try{
			GMMap oMap= new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn9905.mevcudu_yukle(?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
				
				stmt.execute();
			}catch (Exception e) {
				throw new GMRuntimeException(0,e.getMessage());
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}		
			Session session = DAOSession.getSession("BNSPRDal");
		
			List<?> list = (List<?>)session.createCriteria(GnlZamanPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "ZAMAN_ISLEM";
			int row = 0;
			for(Iterator<?> iter = list.iterator();iter.hasNext(); row++){
				GnlZamanPrTx gnlZamanPrTx = (GnlZamanPrTx) iter.next();
				oMap.put(tableName, row, "NUMARA", gnlZamanPrTx.getId().getNumara());
				oMap.put(tableName, row, "ACIKLAMA", gnlZamanPrTx.getAciklama());
				oMap.put(tableName, row, "BASLANGIC", gnlZamanPrTx.getBaslangic());
				oMap.put(tableName, row, "BITIS", gnlZamanPrTx.getBitis());

			}
			return oMap;			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9905_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listZamanPr = (List<?>)session.createCriteria(GnlZamanPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for (Iterator<?> iterator = listZamanPr.iterator(); iterator.hasNext();) {
				GnlZamanPrTx gnlZamanPrTx = (GnlZamanPrTx)iterator.next();
				session.delete(gnlZamanPrTx);
			}
			session.flush();
			
			String tableName = "ZAMAN_ISLEM";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlZamanPrTx gnlZamanPrTx = new GnlZamanPrTx();
				
				GnlZamanPrTxId gnlZamanPrTxId = new GnlZamanPrTxId();
				gnlZamanPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlZamanPrTxId.setNumara(iMap.getBigDecimal(tableName, row, "NUMARA"));
				gnlZamanPrTx.setId(gnlZamanPrTxId);
				gnlZamanPrTx.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlZamanPrTx.setBaslangic(iMap.getBigDecimal(tableName, row, "BASLANGIC"));
				gnlZamanPrTx.setBitis(iMap.getBigDecimal(tableName, row, "BITIS"));
				session.saveOrUpdate(gnlZamanPrTx);
			}
			
			session.flush();
			iMap.put("TRX_NAME", "9905");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9905_GET_ZAMAN_PR_LIST")
	public static GMMap getZamanPrList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session.createCriteria(GnlZamanPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			String newTableName = "ZAMAN_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlZamanPrTx gnlZamanPrTx = (GnlZamanPrTx) iterator.next();
				oMap.put(newTableName, row, "NUMARA", gnlZamanPrTx.getId().getNumara());
				oMap.put(newTableName, row, "BASLANGIC", gnlZamanPrTx.getBaslangic());
				oMap.put(newTableName, row, "BITIS", gnlZamanPrTx.getBitis());
				oMap.put(newTableName, row, "ACIKLAMA", gnlZamanPrTx.getAciklama());
			}
			
			if(iMap.getBoolean("VIEWINIT")){
			list = (List<?>) session.createCriteria(GnlZamanPrTx.class).add(Restrictions.eq("id.txNo", getPreviousTx(iMap))).list();
			String oldTableName = "OLD_ZAMAN_ISLEM";
			row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlZamanPrTx gnlZamanPrTx = (GnlZamanPrTx) iterator.next();
				oMap.put(oldTableName, row, "NUMARA", gnlZamanPrTx.getId().getNumara());
				oMap.put(oldTableName, row, "BASLANGIC", gnlZamanPrTx.getBaslangic());
				oMap.put(oldTableName, row, "BITIS", gnlZamanPrTx.getBitis());
				oMap.put(oldTableName, row, "ACIKLAMA", gnlZamanPrTx.getAciklama());
			}
			
			oMap.put("COLOR_DATA",BeanSetProperties.tableDifference((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "NUMARA").get("COLOR_DATA"));
			mergeTables(oMap, "NEW_ZAMAN_ISLEM", newTableName, oldTableName, "NUMARA", "COLOR_DATA", "ZAMAN_ISLEM_COLOR_DATA");
			}
			

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static BigDecimal getPreviousTx(GMMap oMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal oldTx = (BigDecimal) session.createCriteria(GnlZamanPrTx.class)
									.add(Restrictions.lt("id.txNo", oMap.getBigDecimal("TRX_NO")))
									.setProjection(Projections.projectionList().add(Projections.max("id.txNo"))).uniqueResult();
			return oldTx;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static GMMap mergeTables(GMMap oMap, String mergedTable, String newTable, String oldTable, String keyColumn, String colorTable, String newColorTable){
		
		int oldTableSize = oMap.get(oldTable) != null ? ((ArrayList<?>) oMap.get(oldTable)).size() : 0;
		int newTableSize = oMap.get(newTable) != null ? ((ArrayList<?>) oMap.get(newTable)).size() : 0;
		int oldRowCount = 0;
		int newRowCount = 0;
		int mergedRowCount = 0;
		
		while(oldTableSize != oldRowCount || newTableSize != newRowCount){
			
			if(oldRowCount < oldTableSize && newRowCount < newTableSize){
				GMMap oldRowMap		= oMap.getMap(oldTable	, oldRowCount);
				GMMap newRowMap		= oMap.getMap(newTable	, newRowCount);
				GMMap colorRowMap	= oMap.getMap(colorTable, newRowCount);
				int compare = newRowMap.getBigDecimal(keyColumn).compareTo(oldRowMap.getBigDecimal(keyColumn));
				
				if(compare == 1){
					oMap.put(mergedTable, mergedRowCount, oldRowMap);
					for(Object key : oldRowMap.keySet()){
						oMap.put(newColorTable, mergedRowCount, key.toString(), getDeletedTableCellColorData());
					}
					oldRowCount++;
				}else if(compare == -1){
					oMap.put(mergedTable, mergedRowCount, newRowMap);
					oMap.put(newColorTable, mergedRowCount, colorRowMap);
					newRowCount++;	
				}else{
					//e�it
					oMap.put(mergedTable, mergedRowCount, newRowMap);
					oMap.put(newColorTable, mergedRowCount, colorRowMap);
					oldRowCount++;
					newRowCount++;
				}
				
			}else if(oldRowCount == oldTableSize){
				GMMap newRowMap = oMap.getMap(newTable, newRowCount);
				GMMap colorRowMap	= oMap.getMap(colorTable, newRowCount);
				oMap.put(mergedTable, mergedRowCount, newRowMap);
				oMap.put(newColorTable, mergedRowCount, colorRowMap);
				newRowCount++;
			}else{
				GMMap oldRowMap = oMap.getMap(oldTable, oldRowCount);
				oMap.put(mergedTable, mergedRowCount, oldRowMap);
				for(Object key : oldRowMap.keySet()){
					oMap.put(newColorTable, mergedRowCount, key.toString(), getDeletedTableCellColorData());
				}
				oldRowCount++;
			}
			mergedRowCount++;
		}
		return oMap;
	}
	
	private static GMMap getDeletedTableCellColorData(){
		GMMap oMap = new GMMap();
		oMap.put("setBackground", new Color(100,149,237));
		return oMap;
	}
	
}
