package tr.com.calikbank.bnspr.system.services;
 
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import tr.com.aktifbank.bnspr.dao.AktiviteGiris;

public class Aktivite {
	
	@GraymoundService("BNSPR_AKTIVITE_ACILIS_BILGI")
	public static GMMap AcilisBilgi(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		ResultSet			rSet = null;
		try {
			
			GMMap oMap = new GMMap();			
			oMap.put("KULLANICI", KullaniciAdiBul((String)GMContext.getCurrentContext().getSession().get("USER_NAME")));
			oMap.put("BOLUM", KullaniciBolumBul((String)GMContext.getCurrentContext().getSession().get("USER_NAME")));
			oMap.put("YONETICI", YoneticiBul((String)GMContext.getCurrentContext().getSession().get("USER_NAME")));
			oMap.putAll(DALUtil.fillComboBox(iMap, "IS_BIRIMI", false,"select kod, aciklama from gnl_bolum_kod_pr order by 2"));
			iMap.put("KOD", "AKT_GIRIS_AKTTIPI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("AKTIVITE_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			oMap.put("TARIH_BAS", DALUtil.getResult("select to_char(pkg_tarih.haftanin_ilk_is_gunu,'yyyymmdd') from dual"));
			oMap.put("TARIH_BIT", DALUtil.getResult("select to_char(pkg_tarih.haftanin_son_is_gunu,'yyyymmdd') from dual"));
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_aktivite.projeleri_bul(?,?) }");
			stmt.registerOutParameter(2, -10);
			stmt.setDate(1,  new java.sql.Date(oMap.getDate("TARIH_BAS").getTime()));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(2);
			oMap.putAll(DALUtil.fillComboBox(iMap, "PROJE", false, rSet));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}
	
	private static GMMap getProjectCodeMap(){
		GMMap oMap = new GMMap();
		Connection			conn = null;
		CallableStatement	stmt = null;
		ResultSet			rSet = null;
		try
		{
			oMap.put("TARIH_BAS", DALUtil.getResult("select to_char(pkg_tarih.haftanin_ilk_is_gunu,'yyyymmdd') from dual"));
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_aktivite.projeleri_bul(?,?) }");
			int i = 1;
			stmt.setDate(i++,  new java.sql.Date(oMap.getDate("TARIH_BAS").getTime()));
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(2);
			while(rSet.next()){
				oMap.put(rSet.getString("ACIKLAMA"), rSet.getString("KOD"));
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static GMMap getCodeProjectMap(){
		GMMap oMap = new GMMap();
		Connection			conn = null;
		CallableStatement	stmt = null;
		ResultSet			rSet = null;
		try
		{
			oMap.put("TARIH_BAS", DALUtil.getResult("select to_char(pkg_tarih.haftanin_ilk_is_gunu,'yyyymmdd') from dual"));
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_aktivite.projeleri_bul(?,?) }");
			int i = 1;
			stmt.setDate(i++,  new java.sql.Date(oMap.getDate("TARIH_BAS").getTime()));
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(2);
			while(rSet.next()){
				oMap.put(rSet.getString("KOD") , rSet.getString("ACIKLAMA"));
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static String KullaniciAdiBul(String Kullanici){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
	
		String KullaniciAdi;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.kullanici_adi(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, Kullanici);
			stmt.execute();
			
			KullaniciAdi = stmt.getString(1);
			
			return KullaniciAdi;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static String KullaniciBolumBul(String Kullanici){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		String KullaniciBolum;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.bolum_adi_bul(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, Kullanici);
			stmt.execute();
			
			KullaniciBolum = stmt.getString(1);
			
			return KullaniciBolum;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static String YoneticiBul(String Kullanici){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		String Yonetici;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.yonetici_bul(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, Kullanici);
			stmt.execute();
			
			Yonetici = stmt.getString(1);
			
			return Yonetici;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/*
	@GraymoundService("BNSPR_AKTIVITE_IS_BIRIMI_COMBO")
	public static GMMap IsBirimiCombo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			stmt = conn.prepareStatement("select is_birimi, pkg_genel_pr.bolum_adi(is_birimi) from aktivite_proje where kod = ?");
			stmt.setString(1, iMap.getString("PROJE"));

			rSet = stmt.executeQuery();

			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "IS_BIRIMI", rSet.getString(1),rSet.getString(2));
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	*/
	@GraymoundService("BNSPR_AKTIVITE_GETIR")
	public static GMMap aktiviteGetir(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			int row = 0;
			double pazartesi, sali, carsamba, persembe, cuma, toplam;
			double topPazartesi = 0, topSali = 0, topCarsamba = 0, topPersembe = 0, topCuma = 0, topTop = 0;
			String zaman;
			Boolean yaz = true;
			String tableName = "AKTIVITE_GIRIS";
			List<?> list = (List<?>)session.createCriteria(AktiviteGiris.class).add(Restrictions.and(
					Restrictions.eq("kullanici", (String)GMContext.getCurrentContext().getSession().get("USER_NAME")), 
					Restrictions.and(Restrictions.eq("tarih", iMap.getDate("TARIH")),
					Restrictions.or(Restrictions.eq("durum", "GIRIS"),Restrictions.eq("durum", "ONAYLI")))))
					.list();
			
			GMMap codeProjectMap = getCodeProjectMap();
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				AktiviteGiris aktiviteGiris = (AktiviteGiris) iterator.next();

				oMap.put(tableName, row, "PROJE", codeProjectMap.getString(aktiviteGiris.getProje()));
				oMap.put(tableName, row, "AKTIVITE_TIPI", aktiviteGiris.getAktiviteTipi());
				oMap.put(tableName, row, "AKTIVITE", aktiviteGiris.getAktivite());
				oMap.put(tableName, row, "ISSUE_NO", aktiviteGiris.getIssueNo());
				oMap.put(tableName, row, "IS_BIRIMI", aktiviteGiris.getIsBirimi());
				oMap.put(tableName, row, "PAZARTESI", aktiviteGiris.getPazartesi());
				oMap.put(tableName, row, "SALI", aktiviteGiris.getSali());
				oMap.put(tableName, row, "CARSAMBA", aktiviteGiris.getCarsamba());
				oMap.put(tableName, row, "PERSEMBE", aktiviteGiris.getPersembe());
				oMap.put(tableName, row, "CUMA", aktiviteGiris.getCuma());
				oMap.put(tableName, row, "SIRA_NO", aktiviteGiris.getSiraNo());
				if(aktiviteGiris.getPazartesi() == null) pazartesi = 0; 
				else {pazartesi = aktiviteGiris.getPazartesi().doubleValue(); topPazartesi += pazartesi;}
				if(aktiviteGiris.getSali() == null) sali = 0; 
				else {sali = aktiviteGiris.getSali().doubleValue(); topSali += sali;}
				if(aktiviteGiris.getCarsamba() == null) carsamba = 0; 
				else {carsamba = aktiviteGiris.getCarsamba().doubleValue(); topCarsamba += carsamba;}
				if(aktiviteGiris.getPersembe() == null) persembe = 0; 
				else {persembe = aktiviteGiris.getPersembe().doubleValue(); topPersembe += persembe;}
				if(aktiviteGiris.getCuma() == null) cuma = 0; 
				else {cuma = aktiviteGiris.getCuma().doubleValue(); topCuma += cuma;}
				
				toplam = pazartesi + sali + carsamba + persembe + cuma;
				zaman = zamanBul(toplam);
				oMap.put(tableName, row, "TOPLAM", zaman);				
				
				topTop += toplam;
				
				oMap.put(tableName, row, "ACIKLAMA", aktiviteGiris.getAciklama());
				if(yaz){
					oMap.put("ACIKLAMA", aktiviteGiris.getAciklama());
					oMap.put("DURUM", aktiviteGiris.getDurum());
					yaz = false;
				}
			}
			zaman = zamanBul(topPazartesi);
			oMap.put("TOP_PAZARTESI", zaman);
			
			zaman = zamanBul(topSali);
			oMap.put("TOP_SALI", zaman);
			
			zaman = zamanBul(topCarsamba);
			oMap.put("TOP_CARSAMBA", zaman);
			
			zaman = zamanBul(topPersembe);
			oMap.put("TOP_PERSEMBE", zaman);
			
			zaman = zamanBul(topCuma);
			oMap.put("TOP_CUMA", zaman);
			
			zaman = zamanBul(topTop);
			oMap.put("TOP_TOP", zaman);
			
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_TOPLAM_HESAPLA")
	public static GMMap ToplamHesapla(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			double pazartesi, sali, carsamba, persembe, cuma, toplam;
			String zaman;
			
			if(iMap.getBigDecimal("PAZARTESI") == null) pazartesi = 0; else pazartesi = iMap.getBigDecimal("PAZARTESI").doubleValue();
			if(iMap.getBigDecimal("SALI") == null) sali = 0; else sali = iMap.getBigDecimal("SALI").doubleValue();
			if(iMap.getBigDecimal("CARSAMBA") == null) carsamba = 0; else carsamba = iMap.getBigDecimal("CARSAMBA").doubleValue();
			if(iMap.getBigDecimal("PERSEMBE") == null) persembe = 0; else persembe = iMap.getBigDecimal("PERSEMBE").doubleValue();
			if(iMap.getBigDecimal("CUMA") == null) cuma = 0; else cuma = iMap.getBigDecimal("CUMA").doubleValue();
			toplam = pazartesi + sali + carsamba + persembe + cuma;
			zaman = zamanBul(toplam);
			oMap.put("TOPLAM", zaman);
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}	
	}
	
	@GraymoundService("BNSPR_AKTIVITE_GUN_TOPLAM_HESAPLA")
	public static GMMap GunToplamHesapla(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			double toplam, toplamSaat, toplamDakika;
			int intToplamSaat, intToplamDakika;
			String zaman;
			
			if(iMap.getBigDecimal("TOPLAM_DAKIKA") == null) toplam = 0; else toplam = iMap.getBigDecimal("TOPLAM_DAKIKA").doubleValue();
			toplamSaat = (toplam-toplam%60)/60;
			toplamDakika = toplam - toplamSaat * 60;
			intToplamSaat = (int)toplamSaat;
			intToplamDakika = (int)toplamDakika;
			zaman = intToplamSaat + ":" + intToplamDakika;
			oMap.put("TOPLAM_SAAT", zaman);
			oMap.put("TOP_SAAT", intToplamSaat);
			oMap.put("TOP_DAK", intToplamDakika);
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}	
	}

	private static String zamanBul(double toplam){
		double toplamSaat, toplamDakika;
		int intToplamSaat, intToplamDakika;
		String zaman;
		toplamSaat = (toplam-toplam%60)/60;
		toplamDakika = toplam - toplamSaat * 60;
		intToplamSaat = (int)toplamSaat;
		intToplamDakika = (int)toplamDakika;
		zaman = intToplamSaat + ":" + intToplamDakika;
		return zaman;
	}
	
	@GraymoundService("BNSPR_AKTIVITE_TARIH_GERI")
	public static GMMap TarihGeri(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
	
			oMap.put("TARIH_BAS", IlkIsGunuBulGeri(new java.sql.Date(iMap.getDate("TARIH_BAS").getTime())));
			oMap.put("TARIH_BIT", SonIsGunuBulGeri(new java.sql.Date(iMap.getDate("TARIH_BAS").getTime())));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static Date IlkIsGunuBulGeri(Date Tarih){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		Date ilkIsGunu;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.haftanin_ilk_is_gunu_geri(?) }");
			
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, new java.sql.Date(Tarih.getTime()));
			stmt.execute();
			
			ilkIsGunu = stmt.getDate(1);
			
			return ilkIsGunu;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static Date SonIsGunuBulGeri(Date Tarih){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		Date sonIsGunu;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.haftanin_son_is_gunu_geri(?) }");
			
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, new java.sql.Date(Tarih.getTime()));
			stmt.execute();
			
			sonIsGunu = stmt.getDate(1);
			
			return sonIsGunu;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_TARIH_ILERI")
	public static GMMap TarihIleri(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
	
			oMap.put("TARIH_BAS", IlkIsGunuBulIleri(new java.sql.Date(iMap.getDate("TARIH_BAS").getTime())));
			oMap.put("TARIH_BIT", SonIsGunuBulIleri(new java.sql.Date(iMap.getDate("TARIH_BAS").getTime())));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static Date IlkIsGunuBulIleri(Date Tarih){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		Date ilkIsGunu;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.haftanin_ilk_is_gunu_ileri(?) }");
			
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, new java.sql.Date(Tarih.getTime()));
			stmt.execute();
			
			ilkIsGunu = stmt.getDate(1);
			
			return ilkIsGunu;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static Date SonIsGunuBulIleri(Date Tarih){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		Date sonIsGunu;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.haftanin_son_is_gunu_ileri(?) }");
			
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, new java.sql.Date(Tarih.getTime()));
			stmt.execute();
			
			sonIsGunu = stmt.getDate(1);
			
			return sonIsGunu;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_IS_BIRIMI_BUL")
	public static GMMap IsBirimiBul(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;		
		try {
			GMMap oMap = new GMMap();
	
			if(iMap.getString("PROJE") != null && iMap.getString("PROJE").trim().length() > 0){
				
				GMMap projectCodeMap = getProjectCodeMap();
			
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call  pkg_aktivite.is_birimi_bul(?) }");
				
			
				
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, projectCodeMap.getString(iMap.getString("PROJE")));
				stmt.execute();
				
				oMap.put("IS_BIRIMI", stmt.getString(1));
			
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_AKTIVITE_SAKLA")
	public static GMMap sakla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			if ((iMap.getBigDecimal("TOP_SAAT") != null) && (iMap.getBigDecimal("TOP_SAAT").compareTo(new BigDecimal(45)) == 0) && (iMap.getBigDecimal("TOP_DAK").compareTo(new BigDecimal(0)) == 1)){
				iMap.put("HATA_NO", new BigDecimal(2400));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	 			
			}
			
			if ((iMap.getBigDecimal("TOP_SAAT") != null) && (iMap.getBigDecimal("TOP_SAAT").compareTo(new BigDecimal(45)) == 1)){
				iMap.put("HATA_NO", new BigDecimal(2400));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	 			
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
        	conn = DALUtil.getGMConnection();
			
			List<?> activiteList = session.createCriteria(AktiviteGiris.class).add(Restrictions.and(
					Restrictions.eq("kullanici", (String)GMContext.getCurrentContext().getSession().get("USER_NAME")), 
					Restrictions.and(Restrictions.eq("tarih", iMap.getDate("TARIH")),
					Restrictions.eq("durum", "GIRIS"))))
					.list();
			
			for (Iterator<?> iterator = activiteList.iterator(); iterator.hasNext();) {
				AktiviteGiris aktiviteGiris = (AktiviteGiris)iterator.next();
				session.delete(aktiviteGiris);
			}
			
			session.flush();
			
			GMMap projectCodeMap = getProjectCodeMap();
			
			String tableName = "TBL_AKTIVITE";
			List<?> list = (List<?>)iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
                 
				AktiviteGiris aktiviteGiris = new AktiviteGiris();
                aktiviteGiris.setTarih(iMap.getDate("TARIH"));
                aktiviteGiris.setKullanici((String)GMContext.getCurrentContext().getSession().get("USER_NAME"));
                aktiviteGiris.setProje(projectCodeMap.getString(iMap.getString(tableName, i, "PROJE")));
                aktiviteGiris.setAktiviteTipi(iMap.getString(tableName, i, "AKTIVITE_TIPI"));
                aktiviteGiris.setIssueNo(iMap.getString(tableName, i, "ISSUE_NO"));
                aktiviteGiris.setAktivite(iMap.getString(tableName, i, "AKTIVITE"));
				aktiviteGiris.setIsBirimi(iMap.getString(tableName, i, "IS_BIRIMI"));
	            aktiviteGiris.setPazartesi(iMap.getBigDecimal(tableName, i, "PAZARTESI"));
	            aktiviteGiris.setSali(iMap.getBigDecimal(tableName, i, "SALI"));
	            aktiviteGiris.setCarsamba(iMap.getBigDecimal(tableName, i, "CARSAMBA"));
	            aktiviteGiris.setPersembe(iMap.getBigDecimal(tableName, i, "PERSEMBE"));
	            aktiviteGiris.setCuma(iMap.getBigDecimal(tableName, i, "CUMA"));
	            aktiviteGiris.setDurum("GIRIS");
	            aktiviteGiris.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
	            if(iMap.getBigDecimal(tableName, i, "SIRA_NO") == null){
					stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('FARKLILIK')}");
					stmt.registerOutParameter(1, Types.INTEGER);
					stmt.execute();
					aktiviteGiris.setSiraNo(stmt.getBigDecimal(1));
	            }else{
	            	aktiviteGiris.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));
	            }
	            
	            session.saveOrUpdate(aktiviteGiris);
	            session.flush();
				GMServerDatasource.close(stmt);
			}
			return new GMMap().put("MESSAGE", "��leminiz Tamamland�");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_ONAYA_GONDER")
	public static GMMap onayaGonder(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			if ((iMap.getBigDecimal("TOP_SAAT") != null) && (iMap.getBigDecimal("TOP_SAAT").compareTo(new BigDecimal(45)) == 1)){
				iMap.put("HATA_NO", new BigDecimal(2400));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	 			
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> activiteList = session.createCriteria(AktiviteGiris.class).add(Restrictions.and(
					Restrictions.eq("kullanici", (String)GMContext.getCurrentContext().getSession().get("USER_NAME")), 
					Restrictions.and(Restrictions.eq("tarih", iMap.getDate("TARIH")),
					Restrictions.eq("durum", "GIRIS"))))
					.list();
			
			for (Iterator<?> iterator = activiteList.iterator(); iterator.hasNext();) {
				AktiviteGiris aktiviteGiris = (AktiviteGiris)iterator.next();
				session.delete(aktiviteGiris);
			}
			
			session.flush();
			
			GMMap projectCodeMap = getProjectCodeMap();
			
			String tableName = "TBL_AKTIVITE";
			List<?> list = (List<?>)iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
                 
				AktiviteGiris aktiviteGiris = new AktiviteGiris();
                aktiviteGiris.setTarih(iMap.getDate("TARIH"));
                aktiviteGiris.setKullanici((String)GMContext.getCurrentContext().getSession().get("USER_NAME"));
                aktiviteGiris.setProje(projectCodeMap.getString(iMap.getString(tableName, i, "PROJE")));
                aktiviteGiris.setAktiviteTipi(iMap.getString(tableName, i, "AKTIVITE_TIPI"));
                aktiviteGiris.setIssueNo(iMap.getString(tableName, i, "ISSUE_NO"));
                aktiviteGiris.setAktivite(iMap.getString(tableName, i, "AKTIVITE"));
				aktiviteGiris.setIsBirimi(iMap.getString(tableName, i, "IS_BIRIMI"));
	            aktiviteGiris.setPazartesi(iMap.getBigDecimal(tableName, i, "PAZARTESI"));
	            aktiviteGiris.setSali(iMap.getBigDecimal(tableName, i, "SALI"));
	            aktiviteGiris.setCarsamba(iMap.getBigDecimal(tableName, i, "CARSAMBA"));
	            aktiviteGiris.setPersembe(iMap.getBigDecimal(tableName, i, "PERSEMBE"));
	            aktiviteGiris.setCuma(iMap.getBigDecimal(tableName, i, "CUMA"));
	            aktiviteGiris.setDurum("ONAYDA");
	            aktiviteGiris.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
	            if(iMap.getBigDecimal(tableName, i, "SIRA_NO") == null){
	            	conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('FARKLILIK')}");
					stmt.registerOutParameter(1, Types.INTEGER);
					stmt.execute();
					aktiviteGiris.setSiraNo(stmt.getBigDecimal(1));
	            }else{
	            	aktiviteGiris.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));
	            }   
	            session.saveOrUpdate(aktiviteGiris);
	            session.flush();
			}
			
			return new GMMap().put("MESSAGE", "Onaya Gonderildi");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_KONTROL")
	public static GMMap aktiviteKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.haftanin_kacinci_gunu}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			String haftaninKacinciGunu = stmt.getString(1);
			GMServerDatasource.close(stmt);
			
			stmt = conn.prepareCall("{? = call pkg_aktivite.hangi_gun_kac_saat_girilmeli}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			String hangiGunKacSaatGirilmeli = stmt.getString(1);
			GMServerDatasource.close(stmt);
			
			String hangiGunKacSaat[] = hangiGunKacSaatGirilmeli.split("#");
			
            stmt = conn.prepareCall("{? = call pkg_aktivite.aktivite_kontrol}");
	        stmt.registerOutParameter(1, -10); //ref cursor
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			while(rSet.next()){
				String kullanici_mail = rSet.getString("kullanici"); 
				String kullanici_adi = rSet.getString("kullanici_adi");
				String yonetici_mail = rSet.getString("yonetici"); 
				String ust_yonetici_mail = rSet.getString("ust_yonetici");   
				BigDecimal ptesi_saat = rSet.getBigDecimal("pazartesi"); 
				BigDecimal sali_saat = rSet.getBigDecimal("sali"); 
				BigDecimal cars_saat = rSet.getBigDecimal("carsamba"); 
				BigDecimal pers_saat = rSet.getBigDecimal("persembe"); 
				BigDecimal cuma_saat = rSet.getBigDecimal("cuma");
				String mailBody = null;
				
				if(haftaninKacinciGunu.equals("2")&& ptesi_saat.compareTo(new BigDecimal(hangiGunKacSaat[0])) == -1){
					mailBody = "Say�n "+ kullanici_adi+",\r\rAktivite giri�leri tam �al��ma g�nlerinde "
					+"minimum 360 dakika, yar�m �al��ma g�nlerde ise minimum 150 dakika "
                    +"olmal�d�r, sizin kay�tlar�n�z a�a��daki gibidir;\r\r";
					mailBody = mailBody+"Pazartesi: "+ptesi_saat.toString()+" dakika.\r\r";
					mailBody = mailBody+"�yi �al��malar.";
				}
				if(haftaninKacinciGunu.equals("3")&& (ptesi_saat.compareTo(new BigDecimal(hangiGunKacSaat[0])) == -1||
						sali_saat.compareTo(new BigDecimal(hangiGunKacSaat[1])) == -1)){
					mailBody = "Say�n "+ kullanici_adi+",\r\rAktivite giri�leri tam �al��ma g�nlerinde "
					+"minimum 360 dakika, yar�m �al��ma g�nlerde ise minimum 150 dakika "
                    +"olmal�d�r, sizin kay�tlar�n�z a�a��daki gibidir;\r\r";
					if(new BigDecimal(hangiGunKacSaat[0]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Pazartesi: "+ptesi_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[1]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Sal�: "+sali_saat.toString()+" dakika.\r\r";
					mailBody=mailBody+"�yi �al��malar.";			
				}
				if(haftaninKacinciGunu.equals("4")&& (ptesi_saat.compareTo(new BigDecimal(hangiGunKacSaat[0])) == -1||
						sali_saat.compareTo(new BigDecimal(hangiGunKacSaat[1])) == -1||cars_saat.compareTo(new BigDecimal(hangiGunKacSaat[2])) == -1)){
					mailBody = "Say�n "+ kullanici_adi+",\r\rAktivite giri�leri tam �al��ma g�nlerinde "
					+"minimum 360 dakika, yar�m �al��ma g�nlerde ise minimum 150 dakika "
                    +"olmal�d�r, sizin kay�tlar�n�z a�a��daki gibidir;\r\r";
					if(new BigDecimal(hangiGunKacSaat[0]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Pazartesi: "+ptesi_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[1]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Sal�: "+sali_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[2]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"�ar�amba: "+cars_saat.toString()+" dakika.\r\r";
					mailBody=mailBody+"�yi �al��malar.";					
				}
				if(haftaninKacinciGunu.equals("5")&& (ptesi_saat.compareTo(new BigDecimal(hangiGunKacSaat[0])) == -1||
						sali_saat.compareTo(new BigDecimal(hangiGunKacSaat[1])) == -1||cars_saat.compareTo(new BigDecimal(hangiGunKacSaat[2])) == -1||
						pers_saat.compareTo(new BigDecimal(hangiGunKacSaat[3])) == -1)){
					mailBody = "Say�n "+ kullanici_adi+",\r\rAktivite giri�leri tam �al��ma g�nlerinde "
					+"minimum 360 dakika, yar�m �al��ma g�nlerde ise minimum 150 dakika "
                    +"olmal�d�r, sizin kay�tlar�n�z a�a��daki gibidir;\r\r";
					if(new BigDecimal(hangiGunKacSaat[0]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Pazartesi: "+ptesi_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[1]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Sal�: "+sali_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[2]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"�ar�amba: "+cars_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[3]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Per�embe: "+pers_saat.toString()+" dakika.\r\r";
					mailBody=mailBody+"�yi �al��malar.";
				}
				if(haftaninKacinciGunu.equals("1")&& (ptesi_saat.compareTo(new BigDecimal(hangiGunKacSaat[0])) == -1||
						sali_saat.compareTo(new BigDecimal(hangiGunKacSaat[1])) == -1||cars_saat.compareTo(new BigDecimal(hangiGunKacSaat[2])) == -1||
						pers_saat.compareTo(new BigDecimal(hangiGunKacSaat[3])) == -1||cuma_saat.compareTo(new BigDecimal(hangiGunKacSaat[4])) == -1)){
					
					mailBody = "Say�n "+ kullanici_adi+",\r\rAktivite giri�leri tam �al��ma g�nlerinde "
					+"minimum 360 dakika, yar�m �al��ma g�nlerde ise minimum 150 dakika "
                    +"olmal�d�r, sizin kay�tlar�n�z a�a��daki gibidir;\r\r";
					if(new BigDecimal(hangiGunKacSaat[0]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Pazartesi: "+ptesi_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[1]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Sal�: "+sali_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[2]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"�ar�amba: "+cars_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[3]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Per�embe: "+pers_saat.toString()+" dakika.\r";
					if(new BigDecimal(hangiGunKacSaat[4]).compareTo(new BigDecimal(0))==1)
						mailBody=mailBody+"Cuma: "+cuma_saat.toString()+" dakika.\r\r";
                    mailBody=mailBody+"�yi �al��malar.";
				}
				if(mailBody != null){
					String subject="Hat�rlatma: Aktivite Giri�leriniz Eksik.";	
					String mailTo = kullanici_mail;
					String mailCc = null;
					if(!kullanici_mail.equals(yonetici_mail)){
						if(ust_yonetici_mail != null){
							mailCc = yonetici_mail+";"+ust_yonetici_mail;
						}else{
							mailCc = yonetici_mail;
						}
					}
					String mailFrom = "system@aktifbank.com.tr";
					
					sendMail(subject,mailBody,mailTo,mailCc,mailFrom);
				}
			    BigDecimal top_dakika = ptesi_saat.add(sali_saat).add(cars_saat).add(pers_saat).add(cuma_saat);
			    BigDecimal top_saat = top_dakika.divide(new BigDecimal(60),2,RoundingMode.HALF_UP);
			    if(top_saat.compareTo(new BigDecimal(45))==1){
					String subject="Hat�rlatma: Haftal�k Maksimun Aktivite Giri� Saatinizi A�t�n�z.";	
					String mailTo = kullanici_mail;
					String mailCc = null;
					if(!kullanici_mail.equals(yonetici_mail)){
						if(ust_yonetici_mail != null){
							mailCc = yonetici_mail+";"+ust_yonetici_mail;
						}else{
							mailCc = yonetici_mail;
						}
					}
					String mailFrom = "system@aktifbank.com.tr";
					
					sendMail(subject,"Haftal�k Maksimun Aktivite Giri� Saati 45 saattir. Ancak siz toplam "+top_saat+" girmi� bulunuyorsunuz.",
							mailTo,mailCc,mailFrom);
				}
				
			}
			return new GMMap();
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static void sendMail(String subject,String mailBody,String mailTo,String mailCc, String mailFrom){
		GMMap servisMap = new GMMap();
		servisMap.put("MAIL_FROM", mailFrom);
		servisMap.put("MAIL_TO", mailTo); 
		servisMap.put("MAIL_CC", mailCc);
		servisMap.put("MAIL_SUBJECT", subject);
		servisMap.put("MAIL_BODY", mailBody);
		servisMap.put("IS_BODY_HTML", "H");
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
	}
}

