package tr.com.calikbank.bnspr.system.services;

import java.util.List;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlSubeKodPr;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class SystemQRY9939Services {
	@GraymoundService("BNSPR_QRY9939_GET_SUBE_LIST")
	public static GMMap getSubeBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> subeList = session.createCriteria(GnlSubeKodPr.class).list();
			
			String tableName = "SUBE_LIST";
			for (int i = 0; i < subeList.size(); i++) {
				GnlSubeKodPr gnlSubeKodPr = (GnlSubeKodPr)subeList.get(i);
				oMap.put(tableName, i, "KODU" 			, gnlSubeKodPr.getKod());
		        oMap.put(tableName, i, "ADI" 			, gnlSubeKodPr.getSubeAdi());
		        oMap.put(tableName, i, "IL_ADI"			, gnlSubeKodPr.getGnlIlKodPr().getIlAdi());
		        oMap.put(tableName, i, "ILCE_ADI"		, LovHelper.diLov(gnlSubeKodPr.getIlceKod(),
		        						gnlSubeKodPr.getGnlIlKodPr().getKod(),"9901/LV_ILCE_KODU", "ILCE_ADI"));
		        if(gnlSubeKodPr.getAdres1() != null) {
		        	if (gnlSubeKodPr.getAdres2() != null) {
				        oMap.put(tableName, i, "ADRES" 	, gnlSubeKodPr.getAdres1()
																.concat(" " + gnlSubeKodPr.getAdres2()));
					}
		        	else {
		        		oMap.put(tableName, i, "ADRES" 	, gnlSubeKodPr.getAdres1());
					}
		        }
		        oMap.put(tableName, i, "TELEFON" 		, gnlSubeKodPr.getTelefon());
		        oMap.put(tableName, i, "FAKS" 			, gnlSubeKodPr.getFax());
		        oMap.put(tableName, i, "VERGI_DAIRESI" 	, gnlSubeKodPr.getVergiDaire());
		        oMap.put(tableName, i, "VERGI_NO" 		, gnlSubeKodPr.getVergiNo());
		        oMap.put(tableName, i, "TESCIL_TARIHI" 	, gnlSubeKodPr.getTescilTarihi());
		        oMap.put(tableName, i, "ACILIS_TARIHI" 	, gnlSubeKodPr.getAcilisTarihi());
		        oMap.put(tableName, i, "KAPANIS_TARIHI" , gnlSubeKodPr.getKapanmaTar());
		        oMap.put(tableName, i, "SUBE_TIPI" 		, gnlSubeKodPr.getSubeTipi());
		        oMap.put(tableName, i, "DURUMU" 		, gnlSubeKodPr.getDurumu());
		        
		        String nullStr = null;
//		        WebdavClient client = new WebdavClient();
//		        if(gnlSubeKodPr.getKrokiFileName() != null)
//		        	oMap.put(tableName, i, "KROKI_FILE_NAME", client.getBaseUrl() + "/" + SystemTRN9901Services.SUBE_KROKI_ROOT_DIR + "/" + gnlSubeKodPr.getKrokiFileName());
//		        else
		        	oMap.put(tableName, i, "KROKI_FILE_NAME", nullStr);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
