package tr.com.calikbank.bnspr.system.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.GnlProgramFavorite;
import tr.com.aktifbank.bnspr.dao.GnlProgramFavoriteId;
import tr.com.aktifbank.bnspr.dao.GnlProgramFavoriteLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class SystemFavoriteProgramServices {
	
	private static int MAX_FAV_COUNT=5;
	
	@GraymoundService("BNSPR_SYSTEM_FAVORITE_PROGRAMS")
	public static GMMap favoritePrograms(GMMap iMap){
		GMMap oMap  = new GMMap();
		try {
			String pageName=iMap.getString("PAGE_NAME");
			String userName=ADCSession.getString("USER_NAME");
			String command=iMap.getString("COMMAND");
			
			if(command!=null){
				if(command.equals("ADD")){
					int pageCount=iMap.getInt("PAGE_COUNT");
					if(pageCount < getMaxFavoritePageCount()){
						oMap.put("RESULT", addProgram(pageName,userName));
					}else{
						oMap.put("MESSAGE", GMMessageFactory.getMessage("FAVORITE_PRGRM_MAX_MSJ", null));
					}
				}else if(command.equals("REMOVE")){
					oMap.put("RESULT", removeProgram(pageName,userName));
				}
			}
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	private static boolean addProgram(String pageName, String userName){
		Session session=DAOSession.getSession("BNSPRDal");
		GnlProgramFavoriteId favoriteId=new GnlProgramFavoriteId(pageName, userName);
		GnlProgramFavorite favorite=(GnlProgramFavorite) session.get(GnlProgramFavorite.class, favoriteId);
		
		if(favorite==null) {
			session.save(new GnlProgramFavorite(favoriteId));
			session.save(createLog(favoriteId, true));
			return true;
		}
		return false;
	}
	
	private static boolean removeProgram(String pageName, String userName){
		Session session=DAOSession.getSession("BNSPRDal");
		GnlProgramFavoriteId favoriteId=new GnlProgramFavoriteId(pageName, userName);
		GnlProgramFavorite favorite=(GnlProgramFavorite) session.get(GnlProgramFavorite.class, favoriteId);
		if(favorite!=null) {
			session.delete(favorite);
			session.save(createLog(favoriteId, false));
			return true;
		}
		return false;
	}
	
	private static GnlProgramFavoriteLog createLog(GnlProgramFavoriteId favoriteId, boolean state){
		GnlProgramFavoriteLog log=new GnlProgramFavoriteLog();
		log.setKod(favoriteId.getKod());
		log.setKullKod(favoriteId.getKullKod());
		log.setState(state);
		return log;
	}
	
	private static int getMaxFavoritePageCount(){
		String value=GMMessageFactory.getMessage("FAVORITE_PRGRM_MAX", null);
		return value==null?MAX_FAV_COUNT:Integer.valueOf(value);	
	}

}
