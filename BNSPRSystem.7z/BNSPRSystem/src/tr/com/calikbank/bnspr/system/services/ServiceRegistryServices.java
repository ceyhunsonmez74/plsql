package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.sql.rowset.CachedRowSet;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ServiceRegistryService;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.obss.adc.core.pojo.Channel;
import tr.com.obss.adc.core.util.ADCCore;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sun.rowset.CachedRowSetImpl;

public class ServiceRegistryServices {


	@GraymoundService("BNSPR_TRN9997_GET_SERVICE_LIST")
	public static GMMap getServiceList(GMMap iMap) {

		return iMap;

	}

	@GraymoundService("BNSPR_TRN9997_LOAD_SERVICE")
	public static GMMap loadSelectedRow(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			ServiceRegistryService serviceSearchResult = (ServiceRegistryService) session
					.createCriteria(ServiceRegistryService.class)
					.add(Restrictions.eq("name", iMap.getString("SERVICE_ID")))
					.list();

			return oMap;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN9997_SAVE_SERVICE")
	public static GMMap saveNewService(GMMap iMap) {
		String tableName = "SERVICE_REGISTRY_SERVICE";
		Connection conn = null;
		PreparedStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
            String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			StringBuilder sqlQuery = new StringBuilder();
			conn = DALUtil.getServiceRegistryConnection();

			int i = 1;
			if(!isExist(iMap.getString("SERVIS_ISMI"))){
				//create
				sqlQuery.append("INSERT INTO SERVICE_REGISTRY_SERVICE " +
									"(ID, NAME, OWNER_ID, CREATE_USER_ID, CREATE_DATE, PROJECT_ID, DESCRIPTION, STATUS, " +
									"CLASSPATH, METHOD_NAME, SEND_EMAIL_FLAG, ACCOUNTING_FLAG, JOB_FLAG, WS_FLAG, THRESHOLD) ");
				sqlQuery.append("values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				stmt = conn.prepareStatement(sqlQuery.toString());
				oMap.put("TABLE_NAME", tableName);
				stmt.setBigDecimal(i++, GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", oMap).getBigDecimal("ID"));
				stmt.setString(i++, iMap.getString("SERVIS_ISMI"));
				stmt.setBigDecimal(i++, new BigDecimal(iMap.getString("SERVIS_SORUMLUSU")));
				stmt.setString(i++, username);
				stmt.setDate(i++, new java.sql.Date(System.currentTimeMillis()));
				stmt.setBigDecimal(i++, new BigDecimal(iMap.getString("PROJE_ISMI")));
				stmt.setString(i++, iMap.getString("SERVIS_TANIMI"));
				String servisDurumu = iMap.getString("SERVIS_DURUMU");
				if (servisDurumu.equals("false")) {
					servisDurumu = "0";
				} else {
					servisDurumu = "1";
				}
				stmt.setString(i++, servisDurumu);
				stmt.setString(i++, iMap.getString("PAKET_ISMI"));
				stmt.setString(i++, iMap.getString("METHOD_ISMI"));
				stmt.setString(i++, iMap.getString("SEND_EMAIL_FLAG"));
				stmt.setString(i++, iMap.getString("ACCOUNTING_FLAG"));
				stmt.setString(i++, iMap.getString("JOB_FLAG"));
				stmt.setString(i++, iMap.getString("WS_FLAG"));
				stmt.setInt(i++, iMap.getInt("THRESHOLD"));
				stmt.execute();
				oMap.put("MESSAGE", "Kaydetme i�lemi ba�ar�yla ger�ekle�mi�tir.");
			}else{
				//update
				sqlQuery.append("UPDATE SERVICE_REGISTRY_SERVICE SET " +
						"NAME = ?, OWNER_ID = ?, UPDATE_USER_ID = ?, UPDATE_DATE = ?, PROJECT_ID = ?, DESCRIPTION = ?, " +
						"STATUS = ?, CLASSPATH = ?, METHOD_NAME = ?, SEND_EMAIL_FLAG = ?, ACCOUNTING_FLAG = ?, JOB_FLAG = ?, WS_FLAG = ?, THRESHOLD = ? " +
						"where name = ? ");
				
				stmt = conn.prepareStatement(sqlQuery.toString());
				oMap.put("TABLE_NAME", tableName);
				stmt.setString(i++, iMap.getString("SERVIS_ISMI"));
				stmt.setBigDecimal(i++, new BigDecimal(iMap.getString("SERVIS_SORUMLUSU")));
				stmt.setString(i++, username);
				stmt.setDate(i++, new java.sql.Date(System.currentTimeMillis()));
				stmt.setBigDecimal(i++, new BigDecimal(iMap.getString("PROJE_ISMI")));
				stmt.setString(i++, iMap.getString("SERVIS_TANIMI"));
				String servisDurumu = iMap.getString("SERVIS_DURUMU");
				if (servisDurumu.equals("false")) {
					servisDurumu = "0";
				} else {
					servisDurumu = "1";
				}
				stmt.setString(i++, servisDurumu);
				stmt.setString(i++, iMap.getString("PAKET_ISMI"));
				stmt.setString(i++, iMap.getString("METHOD_ISMI"));
				if (iMap.getString("SEND_EMAIL_FLAG").isEmpty()) {
					servisDurumu = "0";
				} else {
					servisDurumu = "1";
				}
				stmt.setString(i++, iMap.getString("SEND_EMAIL_FLAG"));
				stmt.setString(i++, iMap.getString("ACCOUNTING_FLAG"));
				stmt.setString(i++, iMap.getString("JOB_FLAG"));
				stmt.setString(i++, iMap.getString("WS_FLAG"));
				stmt.setInt(i++, iMap.getInt("THRESHOLD"));
				stmt.setString(i++, iMap.getString("SERVIS_ISMI"));
				stmt.executeUpdate();
				oMap.put("MESSAGE", "G�ncelleme i�lemi ba�ar�yla ger�ekle�mi�tir.");
			}
		} catch (Exception e) {
			oMap.put("MESSAGE", "Kaydetme s�ras�nda hata olu�tu.");
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	public static boolean isExist(String serviceName) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("SELECT * FROM " +
										" SERVICE_REGISTRY_SERVICE s " +
										" WHERE s.NAME = '%s'",serviceName);										
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			if (rSet.next()) {
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN9997_GET_SERVICE_INFO")
	public static GMMap getServiceInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("SELECT * FROM " +
										" SERVICE_REGISTRY_SERVICE s " +
										" WHERE s.NAME = '%s'",iMap.getString("SERVICE_NAME"));
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			if (rSet.next()) {
				oMap.put("ID", rSet.getString("ID"));
				oMap.put("NAME", rSet.getString("NAME"));
				oMap.put("OWNER_ID", rSet.getString("OWNER_ID"));
				
			}
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN9997_SEARCH_SERVICE")
	public static GMMap searchService(GMMap iMap) {
		String tableName = "SEARCH_RESULT";
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String query = String.format("select s.id, s.name, s.owner_id, s.project_id, s.description, s.status, " +
											"s.classpath, s.method_name, s.send_email_flag, s.accounting_flag, c.id as COMPONENT_ID, s.job_flag, s.ws_flag, s.threshold" +
											" FROM SERVICE_REGISTRY_SERVICE s, SERVICE_REGISTRY_PROJECT p, SERVICE_REGISTRY_COMPONENT c" +
											" where (s.project_id = p.id) and (p.component_id = c.id) and (s.name like '%%%s%%') ", iMap.getString("SEARCH_CRITERIA"));
			stmt = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rSet = stmt.executeQuery();

			int row = 0;
			int rSetSize = 0;
			rSet.last();
			rSetSize = rSet.getRow();
			rSet.beforeFirst();

			if (rSetSize < 100) {
				while (rSet.next()) {
					oMap.put("SONUC", "false");
					oMap.put("MESSAGE", "");
					oMap.put(tableName, row, "id", rSet.getString("ID"));
					oMap.put(tableName, row, "name", rSet.getString("NAME"));
					oMap.put(tableName, row, "ownerId", rSet.getString("OWNER_ID"));
					oMap.put(tableName, row, "projectId", rSet.getString("PROJECT_ID"));
					oMap.put(tableName, row, "description", rSet.getString("DESCRIPTION"));
					oMap.put(tableName, row, "status", rSet.getString("STATUS"));
					oMap.put(tableName, row, "classpath", rSet.getString("CLASSPATH"));
					oMap.put(tableName, row, "methodName", rSet.getString("METHOD_NAME"));
					oMap.put(tableName, row, "sendEmailFlag", rSet.getString("SEND_EMAIL_FLAG"));
					oMap.put(tableName, row, "accountingFlag", rSet.getString("ACCOUNTING_FLAG"));
					oMap.put(tableName, row, "birimAdi", rSet.getString("COMPONENT_ID"));
					oMap.put(tableName, row, "jobFlag", rSet.getString("JOB_FLAG"));
					oMap.put(tableName, row, "wsFlag", rSet.getString("WS_FLAG"));
					oMap.put(tableName, row, "threshold", rSet.getString("THRESHOLD"));
					row++;
				}
			} else {
				oMap.put("SONUC", "true");
				oMap.put("MESSAGE", "Arama sonucu �ok say�da kay�t d�nmektedir.L�tfen arama kriterinizi �zelle�tiriniz!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN9997_GET_OWNERS")
	public static GMMap getOwners(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "OWNER_LIST";
		oMap.put(tableName, 0, "VALUE", "-1");
		oMap.put(tableName, 0, "NAME", "Se�iniz");
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = "select a.ID, a.NAME " +
						 	" from SERVICE_REGISTRY_OWNER a where a.status='A' order by a.name asc";										
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			int row = 1;
			while (rSet.next()) {
				oMap.put(tableName, row, "VALUE", rSet.getString("ID"));
				oMap.put(tableName, row, "NAME", rSet.getString("NAME"));
				row++;
			}
		} catch (Exception e) {
			//throw ExceptionHandler.convertException(e);
			
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9997_GET_OWNER_INFO")
	public static GMMap getOwnerInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("select a.ID, a.NAME , a.OWNER_EMAIL, a.TEAM_ID" +
						 	" from SERVICE_REGISTRY_OWNER a where a.status='A' and a.ID=%s", iMap.getString("OWNER_ID"));										
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			while (rSet.next()) {
				oMap.put("ID", rSet.getString("ID"));
				oMap.put("NAME", rSet.getString("NAME"));
				oMap.put("OWNER_EMAIL", rSet.getString("OWNER_EMAIL"));
				oMap.put("TEAM_ID", rSet.getString("TEAM_ID"));
			}
			return oMap;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9997_GET_OWNER_TEAM_INFO")
	public static GMMap getOwnerTeamInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("select a.ID, a.TEAM_NAME , a.TEAM_EMAIL" +
						 	" from SERVICE_REGISTRY_OWNER_TEAM a where a.status='A' and a.ID=%s", iMap.getString("TEAM_ID"));										
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			while (rSet.next()) {
				oMap.put("ID", rSet.getString("ID"));
				oMap.put("TEAM_NAME", rSet.getString("TEAM_NAME"));
				oMap.put("TEAM_EMAIL", rSet.getString("TEAM_EMAIL"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	

	@GraymoundService("BNSPR_TRN9997_GET_PROJECT_NAME_LIST")
	public static GMMap getProjectNameList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "PROJECT_LIST";
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("select P.ID, P.NAME " +
										" from SERVICE_REGISTRY_PROJECT P " +
										" WHERE P.COMPONENT_ID = '%s' ORDER BY P.NAME ASC", iMap.getBigDecimal("COMPONENT"));
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "VALUE", rSet.getString("ID"));
				oMap.put(tableName, row, "NAME", rSet.getString("NAME"));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN9997_GET_COMPONENTS")
	public static GMMap getComponents(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = "select S.ID, S.NAME From SERVICE_REGISTRY_COMPONENT S Order By 2";
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			GMMap inputMap = new GMMap();
			inputMap.put("LIST_NAME", "COMPONENT_LIST");
			oMap = DALUtil.fillComboBox(inputMap, rSet);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9997_FILL_COMBO")
    public static GMMap initializeCombo(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            String listName = "MAIL_BILDIRIM";
            GuimlUtil.wrapMyCombo(oMap , listName , "H" , "Hay�r");
//            GuimlUtil.wrapMyCombo(oMap , listName , "S" , "Sadece sistem hatalar�");
            GuimlUtil.wrapMyCombo(oMap , listName , "E" , "Evet");
            
            listName = "MUHASEBE_VARMI";
            GuimlUtil.wrapMyCombo(oMap , listName , "H" , "Hay�r");
            GuimlUtil.wrapMyCombo(oMap , listName , "E" , "Evet");
            
            listName = "JOBMU";
            GuimlUtil.wrapMyCombo(oMap , listName , "H" , "Hay�r");
            GuimlUtil.wrapMyCombo(oMap , listName , "E" , "Evet");
            
            listName = "WEBSERVICE";
            GuimlUtil.wrapMyCombo(oMap , listName , "H" , "Hay�r");
            GuimlUtil.wrapMyCombo(oMap , listName , "W" , "Host etti�imiz webservis(WEBEXT)");
            GuimlUtil.wrapMyCombo(oMap , listName , "D" , "D�� entegrasyon servisi");
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
	
	@GraymoundService("BNSPR_TRN9997_GET_SERVICE_CHNNL_INFO")
	public static GMMap getServiceChannelInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "CHANNEL_LIST";
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("SELECT A.ID,A.SERVICE_ID,A.CHANNEL,A.SOD,A.EOD "
					+ "FROM SERVICE_REGISTRY_ALLOWED_CHNL A WHERE A.SERVICE_ID=%s", iMap.getInt("SERVICE_ID"));
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ID", rSet.getString("ID"));
				oMap.put(tableName, row, "SERVICE_ID", rSet.getString("SERVICE_ID"));
				oMap.put(tableName, row, "CHANNEL", rSet.getString("CHANNEL"));
				oMap.put(tableName, row, "SOD", rSet.getString("SOD"));
				oMap.put(tableName, row, "EOD", rSet.getString("EOD"));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9997_GET_SERVICE_TIME_INFO")
	public static GMMap getServiceTimeInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TIME_LIST";
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("SELECT * FROM SERVICE_REGISTRY_SERVICE_RULES R "
					+ "WHERE R.ALLOW_ID=%s ORDER BY START_TIME", iMap.getInt("ALLOW_ID"));
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ID", rSet.getString("ID"));
				oMap.put(tableName, row, "ALLOW_ID", rSet.getString("ALLOW_ID"));
				oMap.put(tableName, row, "START_TIME", rSet.getString("START_TIME"));
				oMap.put(tableName, row, "END_TIME", rSet.getString("END_TIME"));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN9997_UPDATE_SERVICE_CHNNL_INFO")
	public static GMMap updateServiceChannelInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		
		try {
			conn = DALUtil.getServiceRegistryConnection();
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("UPDATE SERVICE_REGISTRY_ALLOWED_CHNL SET SOD=?,EOD=? WHERE ID=?");
			
			stmt = conn.prepareStatement(sqlQuery.toString());
			stmt.setBoolean(1, iMap.getString("SOD").equals("1")?true:false);
			stmt.setBoolean(2, iMap.getString("EOD").equals("1")?true:false);
			stmt.setInt(3, iMap.getInt("ID"));
			stmt.executeUpdate();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9997_SAVE_SERVICE_CHNNL_INFO")
	public static GMMap saveServiceChannelInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder sb=null;
		CachedRowSet rSet = null;
		try {
			HashMap<String, Object>selectedMap = (HashMap<String, Object>)iMap.get("CHANNEL");

			if(selectedMap.get("VALUE").equals("*")){
				sb=new StringBuilder();
				sb.append("SELECT COUNT(1) FROM SERVICE_REGISTRY_ALLOWED_CHNL A WHERE A.SERVICE_ID=").append(iMap.getInt("SERVICE_ID"));
				rSet=executeQueryGetResultSet(sb.toString());
				rSet.next();
				if(rSet.getInt(1)>0){
					oMap.put("RESULT", 1);
					return oMap;
				}
			}else{
				sb=new StringBuilder();
				sb.append("SELECT COUNT(1) FROM SERVICE_REGISTRY_ALLOWED_CHNL A WHERE A.SERVICE_ID=").append(iMap.getInt("SERVICE_ID"));
				sb.append(" AND A.CHANNEL='*'");
				rSet=executeQueryGetResultSet(sb.toString());
				rSet.next();
				if(rSet.getInt(1)>0){
					oMap.put("RESULT", 2);
					return oMap;
				}
				sb=new StringBuilder();
				sb.append("SELECT COUNT(1) FROM SERVICE_REGISTRY_ALLOWED_CHNL A WHERE A.SERVICE_ID=").append(iMap.getInt("SERVICE_ID"));
				sb.append(" AND A.CHANNEL='").append(selectedMap.get("VALUE")).append("'");
				rSet=executeQueryGetResultSet(sb.toString());
				rSet.next();
				if(rSet.getInt(1)>0){
					oMap.put("RESULT", 3);
					return oMap;
				}
				
			}
			String insertSql=new String("INSERT INTO SERVICE_REGISTRY_ALLOWED_CHNL (ID,SERVICE_ID,CHANNEL,SOD,EOD) VALUES(:id,:serviceId,':channel',:sod,:eod)");
			oMap.put("TABLE_NAME", "SERVICE_REGISTRY_ALLOWED_CHNL");
			insertSql=insertSql.replaceFirst(":id", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", oMap).getString("ID"));
			insertSql=insertSql.replaceFirst(":serviceId", iMap.getString("SERVICE_ID"));
			insertSql=insertSql.replaceFirst(":channel", String.valueOf(selectedMap.get("VALUE")));
			insertSql=insertSql.replaceFirst(":sod", iMap.getBoolean("SOD")?"1":"0");
			insertSql=insertSql.replaceFirst(":eod", iMap.getBoolean("EOD")?"1":"0");
			executeQuery(insertSql);
			oMap.put("RESULT", 0);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_TRN9997_SAVE_SERVICE_TIME_INFO")
	public static GMMap saveServiceTimeInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String insertSql=new String("INSERT INTO SERVICE_REGISTRY_SERVICE_RULES (ID,ALLOW_ID,START_TIME,END_TIME) VALUES (:id,:allow_id,':start_time',':end_time')");
			oMap.put("TABLE_NAME", "SERVICE_REGISTRY_SERVICE_RULES");
			insertSql=insertSql.replaceFirst(":id", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", oMap).getString("ID"));
			insertSql=insertSql.replaceFirst(":allow_id", iMap.getString("ALLOW_ID"));
			insertSql=insertSql.replaceFirst(":start_time", iMap.getString("S_HOUR")+":"+iMap.getString("S_MINUTE"));
			insertSql=insertSql.replaceFirst(":end_time", iMap.getString("E_HOUR")+":"+iMap.getString("E_MINUTE"));
			executeQuery(insertSql);
			oMap.put("RESULT", 0);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	
	
	@GraymoundService("BNSPR_TRN9997_DELETE_SERVICE_TIME_INFO")
	public static GMMap deleteServiceTimeInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder sb=new StringBuilder("DELETE SERVICE_REGISTRY_SERVICE_RULES WHERE ID=");
		sb.append(iMap.getInt("ID"));
		executeQuery(sb.toString());
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN9997_DELETE_SERVICE_CHNNL_INFO")
	public static GMMap deleteServiceChannelInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		CachedRowSet rSet = null;
		StringBuilder sb=new StringBuilder();
		try {
			sb.append("SELECT COUNT(1) FROM SERVICE_REGISTRY_SERVICE_RULES WHERE ALLOW_ID=").append(iMap.getInt("ID"));
			
			rSet=executeQueryGetResultSet(sb.toString());
			rSet.next();
			if(rSet.getInt(1)>0){
				oMap.put("RESULT", 1);
				return oMap;
			}else{
				sb=new StringBuilder("DELETE SERVICE_REGISTRY_ALLOWED_CHNL WHERE ID=");
				sb.append(iMap.getInt("ID"));
				executeQuery(sb.toString());
				oMap.put("RESULT", 0);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	private static CachedRowSet executeQueryGetResultSet(String query){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		CachedRowSet cachedRowSet;
		try{
			conn = DALUtil.getServiceRegistryConnection();
			stmt = conn.prepareStatement(query);
			rSet=stmt.executeQuery();
			cachedRowSet = new CachedRowSetImpl();
			cachedRowSet.populate(rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return cachedRowSet;
	}
	
	private static boolean executeQuery(String query){
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = DALUtil.getServiceRegistryConnection();
			stmt = conn.prepareStatement(query);
			stmt.executeQuery();
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return true;
	}
	
	@GraymoundService("BNSPR_TRN9997_LOAD_CHANNEL_LIST")
	public static GMMap loadChannelList(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GuimlUtil.wrapMyCombo(oMap, "CHANNEL_LIST", "*", "TUMU");
			
			List<?> channelList = (List<?>) session.createCriteria(GnlKanalGrupKodPr.class).addOrder(Order.asc("integrationId")).list();
			
			for (Iterator<?> iterator = channelList.iterator(); iterator.hasNext();) {
				GnlKanalGrupKodPr grupKodPr = (GnlKanalGrupKodPr) iterator.next();
				GuimlUtil.wrapMyCombo(oMap, "CHANNEL_LIST",grupKodPr.getIntegrationId(), grupKodPr.getIntegrationId());
			}
			
			return oMap;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9997_LOAD_ADC_CHANNEL_LIST")
	public static GMMap loadAdcChannelList(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			GuimlUtil.wrapMyCombo(oMap, "CHANNEL_LIST", "*", "TUMU");
			
			List<?> channelList = (List<?>) session.createCriteria(Channel.class).addOrder(Order.asc("code")).list();
			
			for (Iterator<?> iterator = channelList.iterator(); iterator.hasNext();) {
				Channel channel = (Channel) iterator.next();
				GuimlUtil.wrapMyCombo(oMap, "CHANNEL_LIST",channel.getCode(), channel.getCode());
			}
			
			return oMap;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9997_GET_CHANNEL_USER_RESTRICTION_INFO")
	public static GMMap getChannelUserRestrictionInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESTRICTION_LIST";
		try {
			conn = DALUtil.getServiceRegistryConnection();
			String sql = String.format("SELECT U.ID,U.CHANNEL,U.USERNAME,U.CONSTRAIN_MODE "
					+ "FROM SERVICE_REGISTRY_ALLOWED_USER U WHERE U.SERVICE_ID=%s", iMap.getInt("SERVICE_ID"));
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ID", rSet.getString("ID"));
				oMap.put(tableName, row, "CHANNEL", rSet.getString("CHANNEL"));
				oMap.put(tableName, row, "USERNAME", rSet.getString("USERNAME"));
				oMap.put(tableName, row, "TYPE", rSet.getInt("CONSTRAIN_MODE")==0?"Servisi Sadece Bu Kanal Kullanici Cagirir":"Kanal Kullanici Baska Servis Cagiramaz");
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9997_SAVE_CHANNEL_USER_RESTRICTION_INFO")
	public static GMMap saveChannelUserRestrictionInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object>selectedMap = (HashMap<String, Object>)iMap.get("CHANNEL");
			
			StringBuilder sb=new StringBuilder();
			sb.append("SELECT COUNT(1) FROM SERVICE_REGISTRY_ALLOWED_USER U WHERE U.SERVICE_ID=").append(iMap.getInt("SERVICE_ID"));
			sb.append(" AND U.CONSTRAIN_MODE!=").append(iMap.getString("CONSTRAIN_MODE"));
			CachedRowSet rSet=executeQueryGetResultSet(sb.toString());
			rSet.next();
			if(rSet.getInt(1)>0){
				oMap.put("RESULT", 1);
				return oMap;
			}
			sb=new StringBuilder();
			sb.append("SELECT COUNT(1) FROM SERVICE_REGISTRY_ALLOWED_USER U WHERE U.SERVICE_ID=").append(iMap.getInt("SERVICE_ID"));
			sb.append(" AND U.CHANNEL='").append(selectedMap.get("VALUE")).append("'").append(" AND U.USERNAME='").append(iMap.get("USERNAME")).append("'");
			rSet=executeQueryGetResultSet(sb.toString());
			rSet.next();
			if(rSet.getInt(1)>0){
				oMap.put("RESULT", 2);
				return oMap;
			}
			String insertSql=new String("INSERT INTO SERVICE_REGISTRY_ALLOWED_USER (ID,SERVICE_ID,CHANNEL,USERNAME,CONSTRAIN_MODE) VALUES (:id,:service_id,':channel',':username',:costrain_mode)");
			oMap.put("TABLE_NAME", "SERVICE_REGISTRY_ALLOWED_USER");
			insertSql=insertSql.replaceFirst(":id", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", oMap).getString("ID"));
			insertSql=insertSql.replaceFirst(":service_id",  iMap.getString("SERVICE_ID"));
			insertSql=insertSql.replaceFirst(":channel",  String.valueOf(selectedMap.get("VALUE")));
			insertSql=insertSql.replaceFirst(":username",  iMap.getString("USERNAME"));
			insertSql=insertSql.replaceFirst(":costrain_mode",  iMap.getString("CONSTRAIN_MODE"));
			executeQuery(insertSql);

			oMap.put("RESULT", 0);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	
	
	@GraymoundService("BNSPR_TRN9997_DELETE_CHANNEL_USER_RESTRICTION_INFO")
	public static GMMap deleteChannelUserRestrictionInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder sb=new StringBuilder("DELETE SERVICE_REGISTRY_ALLOWED_USER WHERE ID=");
		sb.append(iMap.getInt("ID"));
		executeQuery(sb.toString());
		return oMap;
	}
	
	
}
