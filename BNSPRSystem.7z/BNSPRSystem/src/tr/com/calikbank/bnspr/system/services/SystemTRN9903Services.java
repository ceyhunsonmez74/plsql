package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlPersonelTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlPersonel;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9903Services {
	
    @GraymoundService("BNSPR_TRN9903_SAVE")
    public static Map<?,?> save(GMMap iMap){
    
            Session session = DAOSession.getSession("BNSPRDal");
            GnlPersonelTx gnlPersonelTx = new GnlPersonelTx();
            
            gnlPersonelTx.setAdi(iMap.getString("ADI"));
            gnlPersonelTx.setSoyadi(iMap.getString("SOYADI"));
            gnlPersonelTx.setKurumKodu(iMap.getString("KURUM_KODU"));
            gnlPersonelTx.setSubeKodu(iMap.getString("SUBE_KODU"));
            gnlPersonelTx.setBolumKodu(iMap.getString("BOLUM_KODU"));
            gnlPersonelTx.setBirimKodu(iMap.getString("BIRIM_KODU"));
            gnlPersonelTx.setPersonelNumara(iMap.getBigDecimal("PERSONEL_NUMARA"));  
            gnlPersonelTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            gnlPersonelTx.setUnvan(iMap.getString("UNVAN_KODU"));
            gnlPersonelTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            gnlPersonelTx.setGds(iMap.getString("GDS"));
            
            session.save(gnlPersonelTx);
            session.flush();
            
            iMap.put("TRX_NAME","9903");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
        
        
        
    }
    
    @GraymoundService("BNSPR_TRN9903_CHECK_PERSONEL_PORTYFOY")
    public static GMMap checkPersonelPortfoy(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            
			Integer portfoyCount = (Integer) session
					.createSQLQuery("SELECT count(1) AS CNT FROM BNSPR.GNL_PORTFOY_MUS_TEMSILCI WHERE MUSTERI_TEMSILCISI=:sicilNo")
					.addScalar("CNT", Hibernate.INTEGER)
					.setParameter("sicilNo", iMap.getBigDecimal("SICIL_NO"))
					.uniqueResult();
			
			if(portfoyCount.intValue()>0){
            	oMap.put("PORTFOY", true);
            }else{
            	oMap.put("PORTFOY", false);
            }

            return oMap;
        }catch(Exception e){
            throw new GMRuntimeException(0,e);
        }
    }    
    @GraymoundService("BNSPR_TRN9903_GET_PERSONEL_BILGI")
    public static GMMap getPersonelBilgi(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            
            String func ="{?= call PKG_TRN9903.get_personel_list(?) }";
            String tableName = "PERSONEL_LIST";
            Object[] values = new Object[2];
            if(StringUtils.isEmpty(iMap.getString("SICIL_NO"))){
            	values[0]= BnsprType.NUMBER;
            	values[1]=null;
            }else{
            	values[0]= BnsprType.NUMBER;
            	values[1]= iMap.getBigDecimal("SICIL_NO");
            }
            
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, values));
            return oMap;
        }catch(Exception e){
            throw new GMRuntimeException(0,e);
        }
    }
    
    @GraymoundService("BNSPR_TRN9903_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        try {
         
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");        
            GnlPersonelTx gnlPersonelTx = (GnlPersonelTx) session.createCriteria(GnlPersonelTx.class)
                    .add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
                
			oMap.put("ADI", gnlPersonelTx.getAdi());
			oMap.put("SUBE_KODU", gnlPersonelTx.getSubeKodu());
			oMap.put("BOLUM_KODU", gnlPersonelTx.getBolumKodu());
			oMap.put("BIRIM_KODU", gnlPersonelTx.getBirimKodu());
			oMap.put("KURUM_KODU", gnlPersonelTx.getKurumKodu());
			oMap.put("MUSTERI_NO", gnlPersonelTx.getMusteriNo());
			oMap.put("PERSONEL_NUMARA", gnlPersonelTx.getPersonelNumara());
			oMap.put("SOYADI", gnlPersonelTx.getSoyadi());
			oMap.put("UNVAN_KODU", gnlPersonelTx.getUnvan());
			oMap.put("TRX_NO", gnlPersonelTx.getTxNo().toString());
			oMap.put("KULLANICIKOD", GMServiceExecuter.execute("BNSPR_TRN9903_GET_KULLANICI_KOD", oMap).get("RESULTS"));
                
                String gds = gnlPersonelTx.getGds();
                if (gds.equals("S")) 
                    gds = "Silme ��lemi";
                if (gds.equals("G")) 
                    gds = "Ekleme ��lemi";
                if (gds.equals("D")) 
                    gds = "G�ncelleme ��lemi";
                
                oMap.put("LBLISLEM",gds);

            return oMap;
        }catch(Exception e){
            throw new GMRuntimeException(0,e);
        }
    }
    
    @GraymoundService("BNSPR_TRN9903_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBoxInitialValues(GMMap iMap){
        try{
            GMMap oMap = new GMMap();   
            
            iMap.put("KOD", "PERSONEL_KURUM_KOD");
            oMap.put("PERSONEL_KURUM_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
        return oMap;
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }   
        
    }

	@GraymoundService("BNSPR_TRN9903_GET_KULLANICI_KOD")
	public static GMMap getKullaniciKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			String kullaniciKod = (String) session.createSQLQuery("select KOD from gnl_kullanici where personel_numara=:personelNumara")
			.setParameter("personelNumara", iMap.getBigDecimal("PERSONEL_NUMARA")).uniqueResult();

			if (!StringUtil.isEmpty(kullaniciKod)) {
				oMap.put("KULLANICIKOD", kullaniciKod);
			}
			else {
				oMap.put("KULLANICIKOD", "");
			}

			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
}
