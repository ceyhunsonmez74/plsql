package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.GnlParametreislemTx;
import tr.com.aktifbank.bnspr.dao.GnlParametreislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9929Services {
    
    @GraymoundService("BNSPR_TRN9929_GET_PARAMETER_LIST")
    public static GMMap getList(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            List<?> listParametre = session.createCriteria(GnlParametre.class).addOrder(Order.asc("kod")).list();
            String tableName = "PARAMETRE_TANIM";
            int row = 0;
            for (Iterator<?> iterator = listParametre.iterator(); iterator.hasNext(); row++){
                GnlParametre gnlParametre = (GnlParametre) iterator.next();
                oMap.put(tableName , row , "ACIKLAMA" , gnlParametre.getAciklama());
                oMap.put(tableName , row , "DEGER" , gnlParametre.getDeger());
                oMap.put(tableName , row , "KOD" , gnlParametre.getKod());
                oMap.put(tableName , row , "NUMARA" , gnlParametre.getNumara());
                oMap.put(tableName , row , "MODUL_TUR_KOD" , gnlParametre.getModulTurKod());
                oMap.put(tableName , row , "SIRA" , gnlParametre.getSira());
                oMap.put(tableName , row , "TIP" , gnlParametre.getTip());
                
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN9929_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            int Size = iMap.getSize("LIST");
            for (int i = 0; i < Size; i++){
                
                GnlParametreislemTxId id = new GnlParametreislemTxId();
                GnlParametreislemTx gnlParamTx = new GnlParametreislemTx();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                
                if ("G".equals(iMap.getString("LIST",i,"GDS"))){
                    iMap.put("TABLE_NAME" , "GNL_PARAMETRE_NUMARA");
                    id.setNumara(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID" , iMap).getBigDecimal("ID"));
                } else{
                    id.setNumara(iMap.getBigDecimal("LIST" , i , "NUMARA"));
                }
                
                gnlParamTx.setId(id);
                gnlParamTx.setAciklama(iMap.getString("LIST" , i , "ACIKLAMA"));
                gnlParamTx.setDeger(iMap.getString("LIST" , i , "DEGER"));
                gnlParamTx.setGds(iMap.getString("LIST" , i , "GDS"));
                gnlParamTx.setKod(iMap.getString("LIST" , i , "KOD"));
                
                gnlParamTx.setTip(iMap.getString("LIST" , i , "TIP"));
                gnlParamTx.setModulTurKod(iMap.getString("LIST" , i , "MODUL_TUR_KOD"));
                gnlParamTx.setSira(iMap.getBigDecimal("LIST" , i , "SIRA"));
                gnlParamTx.setTur("G");
                
                session.saveOrUpdate(gnlParamTx);
                
            }
            session.flush();
            iMap.put("TRX_NAME" , "9929");
            
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN9929_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            List<?> list = session.createCriteria(GnlParametreislemTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).addOrder(Order.asc("kod")).list();
            int row = 0;
            String tableName = "LIST";
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++){
                GnlParametreislemTx gnlParamTx = (GnlParametreislemTx) iterator.next();
                
                oMap.put(tableName , row , "ACIKLAMA" , gnlParamTx.getAciklama());
                oMap.put(tableName , row , "GDS" , gnlParamTx.getGds());
                oMap.put(tableName , row , "DEGER" , gnlParamTx.getDeger());
                oMap.put(tableName , row , "KOD" , gnlParamTx.getKod());
                oMap.put(tableName , row , "NUMARA" , gnlParamTx.getId().getNumara());
                oMap.put(tableName , row , "SIRA" , gnlParamTx.getSira());
                oMap.put(tableName , row , "TIP" , gnlParamTx.getTip());
                
            }
            oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
}
