package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlRolProgramTx;
import tr.com.aktifbank.bnspr.dao.GnlRolProgramTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9924Services {
	
	@GraymoundService("BNSPR_TRN9924_GET_YETKI_LIST")
	public static HashMap<String, Object> getAccountList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			
			query.append("select a.level_,a.kodu,a.adi,a.PAR1,( Select max('E') From gnl_rol_program_tx s Where s.program_kod = a.KODU And s.rol_numara = ? and s.tx_no = ? ) Tanim_var ");
			query.append("from V_GNL_PROGRAM_MENU_TREE a");
			
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("ROL_NUMARA"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			
			ArrayList<DefaultMutableTreeNode> level1List = new ArrayList<DefaultMutableTreeNode>();
			ArrayList<DefaultMutableTreeNode> level2List = new ArrayList<DefaultMutableTreeNode>();
			ArrayList<DefaultMutableTreeNode> level3List = new ArrayList<DefaultMutableTreeNode>();
			
			DefaultMutableTreeNode root = new DefaultMutableTreeNode();
			HashMap<String, Object> rootUo = new HashMap<String, Object>();
			rootUo.put("NAME", "Programlar");
			rootUo.put("ADI", "");
			rootUo.put("TANIM_VAR", "0");
			rootUo.put("LEVEL", new BigDecimal(0));
			root.setUserObject(rootUo);
			
			resultSet = stmt.executeQuery();
			while (resultSet.next()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				BigDecimal level = resultSet.getBigDecimal(1);
				DefaultMutableTreeNode node = new DefaultMutableTreeNode();
				node.setUserObject(rowData);
				rowData.put("NAME", resultSet.getString(2));
				rowData.put("ADI", resultSet.getString(3));
				rowData.put("PAR1", resultSet.getString(4));
				rowData.put("TANIM_VAR", GuimlUtil.convertToCheckBoxValue(resultSet.getString(5)));
				rowData.put("LEVEL", level);
				if(level.compareTo(new BigDecimal(1)) == 0){
					level1List.add(node);
					root.add(node);
				}
				else if(level.compareTo(new BigDecimal(2)) == 0){
					level2List.add(node);
				}
				else if(level.compareTo(new BigDecimal(3)) == 0){
					level3List.add(node);
				}
			}
			for (Iterator<?> iterator = level1List.iterator(); iterator.hasNext();) {
				DefaultMutableTreeNode l1node = (DefaultMutableTreeNode) iterator.next();
				HashMap<?, ?> l1uo = (HashMap<?, ?>)l1node.getUserObject();
				for (Iterator<?> iterator2 = level2List.iterator(); iterator2.hasNext();) {
					DefaultMutableTreeNode l2Node = (DefaultMutableTreeNode) iterator2.next();
					HashMap<?, ?> l2uo = (HashMap<?, ?>)l2Node.getUserObject();
					if(l1uo.get("NAME").equals(l2uo.get("PAR1")))
						l1node.add(l2Node);
					for (Iterator<?> iterator3 = level3List.iterator(); iterator3.hasNext();) {
						DefaultMutableTreeNode l3Node = (DefaultMutableTreeNode) iterator3.next();
						HashMap<?, ?> l3uo = (HashMap<?, ?>)l3Node.getUserObject();
						if(l2uo.get("NAME").equals(l3uo.get("PAR1")))
							l2Node.add(l3Node);
					}
				}
			}
			
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("ROL_YETKI_TANIM", root);
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(resultSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9924_SAVE_ROL_YETKI_TANIM")
	public static Map<?,?> saveSinifTurKod(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			 List<?> rolProgramPersistentList = session.createCriteria(GnlRolProgramTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			ArrayList<HashMap<?, ?>> rolProgramGUIList = new ArrayList<HashMap<?,?>>();
			
			DefaultMutableTreeNode root = (DefaultMutableTreeNode)iMap.get("ROL_YETKI_TANIM");
			
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode nodel1 = (DefaultMutableTreeNode)root.getChildAt(i);
				for (int j = 0; j < nodel1.getChildCount(); j++) {
					DefaultMutableTreeNode nodel2 = (DefaultMutableTreeNode)nodel1.getChildAt(j);
					for (int k = 0; k < nodel2.getChildCount(); k++) {
						DefaultMutableTreeNode nodel3 = (DefaultMutableTreeNode)nodel2.getChildAt(k);
						HashMap<?, ?> rowData = (HashMap<?, ?>)nodel3.getUserObject();
						rolProgramGUIList.add(rowData);
					}
				}
			}

			for (Iterator<?> iterator = rolProgramPersistentList.iterator(); iterator.hasNext();) {
				GnlRolProgramTx gnlRolProgramTx = (GnlRolProgramTx) iterator.next();
				gnlRolProgramTx.setFSilindi("E");
				session.update(gnlRolProgramTx);
			}
			session.flush();
			for (Iterator<?> iterator = rolProgramGUIList.iterator(); iterator.hasNext();) {
				HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
				if("1".equals(rowData.get("TANIM_VAR"))){
					GnlRolProgramTxId id = new GnlRolProgramTxId();
					id.setRolNumara(iMap.getBigDecimal("ROL_NUMARA"));
					id.setProgramKod((String)rowData.get("NAME"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					GnlRolProgramTx gnlRolProgramTx = (GnlRolProgramTx)session.get(GnlRolProgramTx.class, id);
					if(gnlRolProgramTx == null){
						gnlRolProgramTx = new GnlRolProgramTx();
						gnlRolProgramTx.setId(id);
					}
					gnlRolProgramTx.setFSilindi(null);
					session.saveOrUpdate(gnlRolProgramTx);
				}
			}
			session.flush();
			
			iMap.put("TRX_NAME", "9924");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9924_GET_INFO")
	public static GMMap getInfo(GMMap iMap) throws SQLException {
		GMMap oMap = new GMMap();
		
	      Object[] inputValues  =  new Object[]
	              {
	                      BnsprType.NUMBER,
	                      iMap.getBigDecimal("TRX_NO")
	                  
	              };
	      
		String func = "{ ? = call PKG_TRN9924.get_info(?) }";
	        
	    oMap = DALUtil.callOracleRefCursorFunction(func , "LIST", inputValues);
		oMap.put("ROL_NUMARA",oMap.getString("LIST" , 0 , "ROL_NUMARA"));
	    return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9924_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN9924.rol_sorgulama(?) }");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ROL_NUMARA"));
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN9924_GET_HISTORY")
	public static GMMap getHistory(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN9924.GET_HISTORY(?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10);
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			rSet1 = (ResultSet)stmt.getObject(1);
			

			String tableName = "TBL_ISLEM_GORUNTULE";

			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet1.next()) {
				oMap.put(tableName, j, "ROL_NUMARA", rSet1.getBigDecimal("ROL_NUMARA"));
				oMap.put(tableName, j, "PROGRAM_KOD", rSet1.getString("PROGRAM_KOD"));
				oMap.put(tableName, j, "PROGRAM_ADI", rSet1.getString("PROGRAM_ADI"));
				oMap.put(tableName, j, "F_EKLENDI", GuimlUtil.convertToCheckBoxValue(rSet1.getString("F_EKLENDI")));
				oMap.put(tableName, j, "F_SILINDI", GuimlUtil.convertToCheckBoxValue(rSet1.getString("F_SILINDI")));
				
				j++;
			}
			
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	

    @GraymoundService("BNSPR_TRN9924_GET_LIST")
    public static GMMap getList(GMMap iMap) throws SQLException {

        GMMap oMap = new GMMap();
        if (StringUtils.isEmpty(iMap.getString("ROL_KODU")))
        {
            throw new GMRuntimeException(99241 ,"Rol bilgisi girilmeden sorgu yap�lamaz! L�tfen rol kodu giriniz!");
        }
        
        Object[] inputValues  =  new Object[]
        {
                BnsprType.NUMBER,
                iMap.getBigDecimal("ROL_KODU"),
                BnsprType.STRING,
                iMap.getString("PROGRAM_KODU")
            
        };
        
        String func = "{ ? = call PKG_TRN9924.GET_ROL_LIST(?,?) }";
        
        oMap = DALUtil.callOracleRefCursorFunction(func , "LIST", inputValues);
       
        return oMap;
    }

    
	
    @GraymoundService("BNSPR_TRN9924_EKLE")
    public static GMMap ekle(GMMap iMap) throws ParseException {
        try{
    	GMMap oMap = new GMMap();
        oMap.put("ROL_LIST" ,iMap.get("ROL_LIST"));
        
        if(StringUtils.isEmpty(iMap.getString("ROL_NUMARA_EKLE")))
        {
            throw new GMRuntimeException(99247,"Tekrar sorgulamal�s�n�z.");
        }
        
        if(StringUtils.isEmpty(iMap.getString("ROL_NUMARA")))
        {
            throw new GMRuntimeException(99248,"Rol Numaras� girip tekrar sorgulamal�s�n�z");
        }
      
        
        String eklenenProgramKodu = iMap.getString("PROGRAM_KODU_EKLE");
        if(StringUtils.isEmpty(eklenenProgramKodu))
        {
            throw new GMRuntimeException(99241,"Eklenecek Program kodu giriniz");
        }
        
        if (!iMap.getString("ROL_NUMARA_EKLE").equals(iMap.getString("ROL_NUMARA")))
        {
            throw new GMRuntimeException(99241,"Eklenecek Rol Numarai le Sorgulanan Rol Numaras� farkl�. L�tfen Rol Numaras�n� Sorgulay�n");
        }
        
        //////////////********Zaten var mi kontrol�*********//////////////////
        for (int i = 0; i < iMap.getSize("ROL_LIST"); i++)
        {
         
             if (eklenenProgramKodu.equals(iMap.getString("ROL_LIST" , i , "PROGRAM_KODU")))
             {
                 throw new GMRuntimeException(99242,"Eklenmek istenen "+eklenenProgramKodu+" Zaten listede var.");
             }
        } 
        //////////////********Zaten var mi kontrol�*********//////////////////
        
        //////***************Yok ise ana listeye ekleme*********////////////////
        GMMap rolListEkleMap = new GMMap(); 
        Object[] inputValues = new Object[] {  BnsprType.STRING, iMap.getString("PROGRAM_KODU_EKLE") };
      
        
       
        String func = "{ ? = call PKG_TRN9924.GET_ADDING_VALUES(?) }";
        
        rolListEkleMap = DALUtil.callOracleRefCursorFunction(func , "LIST" , inputValues);
        
        if(rolListEkleMap.getString("LIST" , 0 , "EKRAN_SAHIPLIGI")==null)
        {
            throw new GMRuntimeException(99242 , ""+(rolListEkleMap.getString("LIST" , 0 , "PROGRAM_KODU"))+" ekran�n�n ekran sahipli�i yoktur. L�tfen sistem kimlik y�netimi b�l�m�yle g�r���n�z");
        }
        int sizeOfRolList = iMap.getSize("ROL_LIST");
        
        oMap.put("ROL_LIST" , sizeOfRolList , "PROGRAM_ADI" , rolListEkleMap.getString("LIST" , 0 , "PROGRAM_ADI"));
        oMap.put("ROL_LIST" , sizeOfRolList , "PROGRAM_KODU" , rolListEkleMap.getString("LIST" , 0 , "PROGRAM_KODU"));
        oMap.put("ROL_LIST" , sizeOfRolList , "MODUL_TUR_KOD" , rolListEkleMap.getString("LIST" , 0 , "MODUL_TUR_KOD"));
        oMap.put("ROL_LIST" , sizeOfRolList , "TUR" , rolListEkleMap.getString("LIST" , 0 , "TUR"));
        oMap.put("ROL_LIST" , sizeOfRolList , "KISA_KOD" , rolListEkleMap.getString("LIST" , 0 , "KISA_KOD"));
        oMap.put("ROL_LIST" , sizeOfRolList , "EKRAN_SAHIPLIGI" , rolListEkleMap.getString("LIST" , 0 , "EKRAN_SAHIPLIGI"));
        oMap.put("ROL_LIST",  sizeOfRolList , "YETKI_BITIS_TARIHI", iMap.getDate("YETKI_BITIS_TARIHI_EKLE"));
            //////***************Yok ise ana listeye ekleme*********////////////////
        
        
        ////////////////****************EKLE LISTESINE EKLEME************//////////
        int j = 0;
        for (int i = 0; i < iMap.getSize("ROL_LIST_EKLE"); i++){
            
            if (!eklenenProgramKodu.equals(iMap.getString(iMap.getString("ROL_LIST_EKLE" , i , "PROGRAM_KODU")))){
                oMap.put("ROL_LIST_EKLE" , j , "PROGRAM_KODU" , iMap.getString("ROL_LIST_EKLE" , i , "PROGRAM_KODU"));
                j++;
            }
            
        }
        
        int sizeOfRolListEkle = oMap.getSize("ROL_LIST_EKLE");
        
        oMap.put("ROL_LIST_EKLE" , sizeOfRolListEkle , "PROGRAM_KODU" ,eklenenProgramKodu);
        oMap.put("ROL_LIST_EKLE" , sizeOfRolListEkle , "YETKI_BITIS_TARIHI" ,iMap.getDate("YETKI_BITIS_TARIHI_EKLE"));
        
        ///////////////************EKLE LISTESINE EKLEME**************////////////////////////
        
        
        //////////////*S�L L�STES�NDE VARSA S�LME************///////////////////////////////
        int k = 0;
        for (int i = 0; i < iMap.getSize("ROL_LIST_SIL"); i++){
            
            if (!eklenenProgramKodu.equals(iMap.getString("ROL_LIST_SIL" , i , "PROGRAM_KODU"))){
                oMap.put("ROL_LIST_SIL" , k , "PROGRAM_KODU" , iMap.getString("ROL_LIST_SIL" , i , "PROGRAM_KODU"));
                k++;
            }
            
        }
        
////////////*S�L L�STES�NDE VARSA S�LME************///////////////////////////////  

        return oMap;
	} catch (SQLException e) {
		throw new GMRuntimeException(1, e);
    }
    }
    

    @GraymoundService("BNSPR_TRN9924_SIL")
    public static GMMap sil(GMMap iMap) {
        GMMap oMap = new GMMap();
        oMap.put("ROL_LIST_SIL",iMap.get("ROL_LIST_SIL"));
        oMap.put("ROL_LIST_EKLE",iMap.get("ROL_LIST_EKLE"));
        int j = 0;
        int sizeOfSil = iMap.getSize("ROL_LIST_SIL");
        boolean isSelected = false;
  
        for (int i = 0; i < iMap.getSize("ROL_LIST"); i++){
            if ("H".equals(GuimlUtil.convertFromCheckBoxValue(iMap.getString("ROL_LIST",i , "SIL"))))
            {
                oMap.put("ROL_LIST" ,  j , "PROGRAM_ADI" , iMap.getString("ROL_LIST" , i, "PROGRAM_ADI"));
                oMap.put("ROL_LIST" ,  j , "PROGRAM_KODU" , iMap.getString("ROL_LIST" , i , "PROGRAM_KODU"));
                oMap.put("ROL_LIST" ,  j , "MODUL_TUR_KOD" , iMap.getString("v" , i , "MODUL_TUR_KOD"));
                oMap.put("ROL_LIST" ,  j , "TUR" , iMap.getString("ROL_LIST" , i , "TUR"));
                oMap.put("ROL_LIST" ,  j , "KISA_KOD" , iMap.getString("ROL_LIST" , i , "KISA_KOD"));
                oMap.put("ROL_LIST" ,  j , "EKRAN_SAHIPLIGI" , iMap.getString("ROL_LIST" , i , "EKRAN_SAHIPLIGI"));
                oMap.put("ROL_LIST" ,  j , "YETKI_BITIS_TARIHI" , iMap.getString("ROL_LIST" , i , "YETKI_BITIS_TARIHI"));
                j++;
            }
            else 
            {
                isSelected = true;
                addDeleteListIfNotExist(oMap,iMap.getString("ROL_LIST" , i , "PROGRAM_KODU"));
                deleteFromAddListIfExist(oMap,iMap.getString("ROL_LIST" , i , "PROGRAM_KODU"));
                
            }
        }
       
        if(!isSelected)
        {
            throw new GMRuntimeException(99248,"Silinecek kay�t i�aretlemediniz!");
        }
        
        
        return oMap;
    }

    private static void addDeleteListIfNotExist(GMMap oMap, String programKodu) {
         int sizeOfDeleteList = oMap.getSize("ROL_LIST_SIL");
         boolean isExistInDeleteList = false;
         
        if (sizeOfDeleteList>0)
        {
            for (int i = 0; i < sizeOfDeleteList; i++){
                
                if (programKodu.equals(oMap.getString("ROL_LIST_SIL" , i , "PROGRAM_KODU") ))
                {
                    isExistInDeleteList = true;
                }
            }
            
        }
        else
        {
            
            oMap.put("ROL_LIST_SIL" , 0 , "PROGRAM_KODU" , programKodu);
            isExistInDeleteList = true;
            
        }
          
        if (!isExistInDeleteList)
        {
            oMap.put("ROL_LIST_SIL" ,sizeOfDeleteList , "PROGRAM_KODU" , programKodu);
        }
        
    }

    private static void  deleteFromAddListIfExist(GMMap oMap, String programKodu) {
        int sizeOfAddList = oMap.getSize("ROL_LIST_EKLE");
        boolean isExistInAddList = false;
        GMMap newAddMap = new GMMap();
        if(sizeOfAddList > 0)
        {
            int j  = 0;
            for (int i = 0; i < oMap.getSize("ROL_LIST_EKLE") ; i++){
                if (programKodu.equals(oMap.getString("ROL_LIST_SIL" , i , "PROGRAM_KODU") ))
                {
                    isExistInAddList = true;
                    
                }
                else
                {
                    newAddMap.put("ROL_LIST_EKLE",j,"PROGRAM_KODU",oMap.getString("ROL_LIST_EKLE" , i, "PROGRAM_KODU"));
                    j++;
                }
            }
            
        }
        else 
        {
            isExistInAddList = false;
        }
        
        if(isExistInAddList)
        {
            oMap.put("ROL_LIST_EKLE" , newAddMap.get("ROL_LIST_EKLE"));
            
        }
    }
    
    

    @GraymoundService("BNSPR_TRN9924_SAVE")
    public static GMMap save(GMMap iMap) throws ParseException {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        if (!StringUtils.isNotEmpty(iMap.getString("ROL_NUMARA"))){
            throw new GMRuntimeException(99243,"ROL NUMARA bo�tur.");
        }
        
        if (StringUtils.isEmpty(iMap.getString("ROL_NUMARA_EKLE"))){
            throw new GMRuntimeException(99243,"Yeni Sorgulama yap�p i�lemleri tekrarlay�n�z");
        }
        
        if(iMap.getSize("ROL_LIST_EKLE") == 0 && iMap.getSize("ROL_LIST_SIL")==0)
        {
            throw new GMRuntimeException(99244 , "Listed eklenecek ve silinecek bir kay�t bulunamad�");
        }
        
        for (int i = 0; i < iMap.getSize("ROL_LIST_EKLE"); i++){
          GnlRolProgramTxId idRol = new GnlRolProgramTxId();
          idRol.setProgramKod(iMap.getString("ROL_LIST_EKLE",i,"PROGRAM_KODU"));
          idRol.setRolNumara(iMap.getBigDecimal("ROL_NUMARA"));
          idRol.setTxNo(iMap.getBigDecimal("TRX_NO"));
          
          GnlRolProgramTx rolProgram = new GnlRolProgramTx();
          rolProgram.setFEklendi("E");
          rolProgram.setId(idRol);
          rolProgram.setYetkiBitisTarihi(iMap.getDate("ROL_LIST_EKLE",i,"YETKI_BITIS_TARIHI"));
          session.save(rolProgram);
        }
        
        session.flush();
        for (int i = 0; i <iMap.getSize("ROL_LIST_SIL"); i++){
            GnlRolProgramTxId idRol = new GnlRolProgramTxId();
            idRol.setProgramKod(iMap.getString("ROL_LIST_SIL",i,"PROGRAM_KODU"));
            idRol.setRolNumara(iMap.getBigDecimal("ROL_NUMARA"));
            idRol.setTxNo(iMap.getBigDecimal("TRX_NO"));
            
            GnlRolProgramTx rolProgram = new GnlRolProgramTx();
            rolProgram.setFSilindi("E");
            rolProgram.setId(idRol);
            session.save(rolProgram);
        }
        session.flush();
        
        iMap.put("TRX_NAME" , "9924");
        oMap =  GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        
        return oMap;
        
    }    
 

}