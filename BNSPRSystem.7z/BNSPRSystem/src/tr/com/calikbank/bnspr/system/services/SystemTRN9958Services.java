package tr.com.calikbank.bnspr.system.services;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.MuhMailonayislemTx;
import tr.com.aktifbank.bnspr.dao.MuhMailonayislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
 
public class SystemTRN9958Services {
	@GraymoundService("BNSPR_TRN9958_GET_LIST")
	public static GMMap getList(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN9958.get_list}";
			Object[] inputValues = new Object[0];
			
			oMap = DALUtil.callOracleRefCursorFunction(func, "TBLISLEMLER", inputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9958_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<MuhMailonayislemTx> list = (List<MuhMailonayislemTx>) session.createCriteria(MuhMailonayislemTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
			int i=0;
			for (MuhMailonayislemTx rec : list){
              oMap.put("TBLISLEMLER",i, "ISLEM_KOD", rec.getId().getIslemKod());
              oMap.put("TBLISLEMLER",i, "DOVIZ_KOD", rec.getDovizKod());
              oMap.put("TBLISLEMLER",i, "GDS", rec.getGds());
              oMap.put("TBLISLEMLER",i, "TUTAR", rec.getTutar());
              oMap.put("TBLISLEMLER", i,"SIL", rec.getGds().equals("S")?true: false);
              i=i+1;
            }
			
			}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9958_SAVE")
	public static GMMap save (GMMap iMap){
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		try {
			for (int i = 0; i < iMap.getSize("TBLISLEMLER"); i++) {
				if(!StringUtil.isEmpty(iMap.getString("TBLISLEMLER",i,"GDS"))){
				MuhMailonayislemTx muhMailonayislemTx = new MuhMailonayislemTx();
				MuhMailonayislemTxId muhMailonayislemTxId = new MuhMailonayislemTxId();
				muhMailonayislemTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				muhMailonayislemTxId.setIslemKod(iMap.getBigDecimal("TBLISLEMLER",i,"ISLEM_KOD"));
				muhMailonayislemTx.setId(muhMailonayislemTxId);
				muhMailonayislemTx.setDovizKod(iMap.getString("TBLISLEMLER",i,"DOVIZ_KOD"));
				muhMailonayislemTx.setGds(iMap.getString("TBLISLEMLER",i,"GDS"));
				muhMailonayislemTx.setTutar(iMap.getBigDecimal("TBLISLEMLER",i,"TUTAR"));
				session.saveOrUpdate(muhMailonayislemTx);
				}
			}
			session.flush();
			iMap.put("TRX_NAME" , "9958");
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
             
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9958_KONTROL")
	public static GMMap kontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			for (int i = 0; i < iMap.getSize("TBLISLEMLER"); i++) {
				if (iMap.getString("ISLEM_KOD").equals(iMap.getString("TBLISLEMLER",i,"ISLEM_KOD"))){
					GMMap hMap = new GMMap();
					hMap.put("P1", "Bu i�lem kodu daha �nce Girilmi�!");
					hMap.put("HATA_NO", "660");
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", hMap);
				}
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

}
