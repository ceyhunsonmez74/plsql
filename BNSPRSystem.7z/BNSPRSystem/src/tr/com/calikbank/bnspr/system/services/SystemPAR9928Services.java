package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.GnlUrunSinifParametre;
import tr.com.aktifbank.bnspr.dao.GnlUrunSinifParametreId;
import tr.com.aktifbank.bnspr.dao.GnlUrunTurParametre;
import tr.com.aktifbank.bnspr.dao.GnlUrunTurParametreId;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9928Services {

	private static final String modulTurKodQuery = "select distinct u.modul_tur_kod from gnl_modul_urun_sinif_kod_pr u order by u.modul_tur_kod";
	private static final String urunTurKodQuery = "select distinct u.urun_tur_kod from gnl_modul_urun_sinif_kod_pr u where u.modul_tur_kod = ? order by u.urun_tur_kod";
	private static final String urunSinifKodQuery = "select distinct u.kod urun_sinif_kod from gnl_modul_urun_sinif_kod_pr u where u.modul_tur_kod = ? and u.urun_tur_kod = ? order by u.kod";
	
	@GraymoundService("BNSPR_PAR9928_GET_MODUL_LIST")
	public static HashMap<String, Object> getModulList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		PreparedStatement stmt2 = null;
		PreparedStatement stmt3 = null;
		ResultSet resultSet = null;
		ResultSet resultSet2 = null;
		ResultSet resultSet3 = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(modulTurKodQuery);

			DefaultMutableTreeNode root = new DefaultMutableTreeNode();
			HashMap<String, Object> rootUo = new HashMap<String, Object>();
			rootUo.put("NAME", "Mod�ller");
			rootUo.put("DETAY", "");
			rootUo.put("LEVEL", new BigDecimal(0));
			root.setUserObject(rootUo);
			resultSet = stmt.executeQuery();
			while (resultSet.next()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				DefaultMutableTreeNode node = new DefaultMutableTreeNode();
				node.setUserObject(rowData);
				rowData.put("MODUL",resultSet.getString(1));
				rowData.put("NAME", resultSet.getString(1));
				rowData.put("LEVEL", new BigDecimal(1));
				rowData.put("MODUL_NAME", resultSet.getString(1));
				stmt2 = conn.prepareStatement(urunTurKodQuery);
				stmt2.setString(1, resultSet.getString(1));
				resultSet2 = stmt2.executeQuery();
				while (resultSet2.next()) {
					HashMap<String, Object> rowData2 = new HashMap<String, Object>();
					DefaultMutableTreeNode node2 = new DefaultMutableTreeNode();
					node2.setUserObject(rowData2);
					rowData2.put("NAME", resultSet2.getString(1));
					rowData2.put("LEVEL", new BigDecimal(2));
					rowData2.put("MODUL_NAME", resultSet.getString(1));
					rowData2.put("URUN_TUR_NAME", resultSet2.getString(1));
				//	rowData2.put("PARAMETRE_MODEL",getUrunTur(resultSet.getString(1),resultSet2.getString(1)).get("URUN_TUR"));
					stmt3 = conn.prepareStatement(urunSinifKodQuery);
					stmt3.setString(1, resultSet.getString(1));
					stmt3.setString(2, resultSet2.getString(1));
					resultSet3 = stmt3.executeQuery();
					while (resultSet3.next()) {
						HashMap<String, Object> rowData3 = new HashMap<String, Object>();
						DefaultMutableTreeNode node3 = new DefaultMutableTreeNode();
						node3.setUserObject(rowData3);
						rowData3.put("NAME", resultSet3.getString(1));
						rowData3.put("LEVEL", new BigDecimal(3));
						rowData3.put("MODUL_NAME", resultSet.getString(1));
						rowData3.put("URUN_TUR_NAME", resultSet2.getString(1));
						rowData3.put("URUN_SINIF_NAME", resultSet3.getString(1));
				//		rowData3.put("PARAMETRE_MODEL",getUrunSinif(resultSet.getString(1),resultSet2.getString(1),resultSet3.getString(1)).get("URUN_SINIF"));
						node2.add(node3);
					}
					GMServerDatasource.close(resultSet3);
					GMServerDatasource.close(stmt3);
					
					node.add(node2);
				}
				GMServerDatasource.close(resultSet2);
				GMServerDatasource.close(stmt2);
				root.add(node);
			}
			
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("MODUL_TANIM", root);
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(resultSet);
			GMServerDatasource.close(resultSet2);
			GMServerDatasource.close(resultSet3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_PAR9928_SAVE_PARAMETRE")
	public static GMMap saveParametre(GMMap iMap){
		try{
			Session session 		= DAOSession.getSession("BNSPRDal");
			DefaultMutableTreeNode root = (DefaultMutableTreeNode)iMap.get("MODUL_TREE");
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)root.getChildAt(i);
			/*	HashMap<?, ?> rowData = (HashMap<?, ?>)node1.getUserObject();
				List<?> modulList 	= (List<?>)session.createCriteria(GnlParametre.class)
											.add(Restrictions.eq("modulTurKod", rowData.get("NAME").toString()))
											.list();*/
				/*Mod�l seviyesinde silme olmayacak*/
			/*	if(rowData.get("PARAMETRE_FLAG")!=null && !rowData.get("PARAMETRE_FLAG").toString().isEmpty())
					for (Iterator<?> iterator = modulList.iterator(); iterator.hasNext();) 
					{
						GnlParametre gnlParametre = (GnlParametre)iterator.next();
						session.delete(gnlParametre);
					}*/
				for (int j = 0; j < node1.getChildCount(); j++) {
					DefaultMutableTreeNode node2 = (DefaultMutableTreeNode)node1.getChildAt(j);
					HashMap<?, ?> rowData2 = (HashMap<?, ?>)node2.getUserObject();
					List<?> urunTurListModel = (List<?>)rowData2.get("PARAMETRE_MODEL");
					if(urunTurListModel != null){
						List<?> urunTurList 	= (List<?>)session.createCriteria(GnlUrunTurParametre.class)
													.add(Restrictions.eq("id.modulTurKod", (String)rowData2.get("MODUL_NAME")))
													.add(Restrictions.eq("id.urunTurKod", (String)rowData2.get("URUN_TUR_NAME")))
													.list();
				//		if(rowData2.get("PARAMETRE_FLAG")!=null && !rowData2.get("PARAMETRE_FLAG").toString().isEmpty())
						for (Iterator<?> iterator = urunTurList.iterator(); iterator.hasNext();) 
						{
							GnlUrunTurParametre gnlUrunTurParametre = (GnlUrunTurParametre)iterator.next();
							session.delete(gnlUrunTurParametre);
						}
					}
					for (int k = 0; k < node2.getChildCount(); k++) {
						DefaultMutableTreeNode node3 = (DefaultMutableTreeNode)node2.getChildAt(k);
						HashMap<?, ?> rowData3 = (HashMap<?, ?>)node3.getUserObject();
						List<?> urunSinifListModel = (List<?>)rowData3.get("PARAMETRE_MODEL");
						if(urunSinifListModel == null ) continue;
						List<?> urunSinifList 	= (List<?>)session.createCriteria(GnlUrunSinifParametre.class)
														.add(Restrictions.eq("id.modulTurKod", (String)rowData3.get("MODUL_NAME")
														 /*(new GMMap((Map<?,?>)urunSinifListModel.get(0)).getString("MODUL_NAME"))*/))
														.add(Restrictions.eq("id.urunTurKod", (String)rowData3.get("URUN_TUR_NAME")
														/* (new GMMap((Map<?,?>)urunSinifListModel.get(0)).getString("URUN_TUR_NAME"))*/))
														.add(Restrictions.eq("id.urunSinifKod", (String)rowData3.get("URUN_SINIF_NAME")
														/* (new GMMap((Map<?,?>)urunSinifListModel.get(0)).getString("URUN_SINIF_NAME"))*/))
														.list();
				//		if(rowData3.get("PARAMETRE_FLAG")!=null && !rowData3.get("PARAMETRE_FLAG").toString().isEmpty())
						for (Iterator<?> iterator2 = urunSinifList.iterator(); iterator2.hasNext();) 
						{
							GnlUrunSinifParametre gnlUrunSinifParametre = (GnlUrunSinifParametre)iterator2.next();
							session.delete(gnlUrunSinifParametre);
						}
					}
				}
			}
			session.flush();
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)root.getChildAt(i);
				HashMap<?, ?> rowData = (HashMap<?, ?>)node1.getUserObject();
				List<?> modulList = (List<?>)rowData.get("PARAMETRE_MODEL");
				if(modulList!=null)
					for (int rowTur = 0; rowTur<modulList.size(); rowTur++) 
					{
						GnlParametre gnlParametre = null;
						if((new GMMap((Map<?,?>)modulList.get(rowTur)).getBigDecimal("NUMARA"))!=null)
							gnlParametre = find((new GMMap((Map<?,?>)modulList.get(rowTur)).getBigDecimal("NUMARA")));
						if(gnlParametre == null) {
							gnlParametre = new GnlParametre();
							iMap.put("TABLE_NAME", "GNL_PARAMETRE_NUMARA");
							gnlParametre.setNumara(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", iMap).getBigDecimal("ID"));							
						}
						if((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("KOD"))== null || 
						   (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("ACIKLAMA")) == null ||
						   (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("TIP")) == null || 
						   (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("DEGER")) == null)
							continue;
						gnlParametre.setKod((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("KOD")));
						gnlParametre.setAciklama((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("ACIKLAMA")));
						gnlParametre.setModulTurKod((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("MODUL_NAME")));
						String tip = (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("TIP"));
						gnlParametre.setTip(tip);
						String deger=(new GMMap((Map<?,?>)modulList.get(rowTur)).getString("DEGER"));
						if(deger != null)
							deger = deger.replace("\"", "");
						if("N".equals(tip)||"B".equals(tip)||"D".equals(tip))
							;
						else
							deger = "\""+deger + "\"";
						gnlParametre.setDeger(deger);
						gnlParametre.setTur("G");
						session.saveOrUpdate(gnlParametre);
						
					}
				for (int j = 0; j < node1.getChildCount(); j++) {
					DefaultMutableTreeNode node2 = (DefaultMutableTreeNode)node1.getChildAt(j);
					HashMap<?, ?> rowData2 = (HashMap<?, ?>)node2.getUserObject();
					
					List<?> urunTurList = (List<?>)rowData2.get("PARAMETRE_MODEL");
					if(urunTurList!=null)
						for (int rowTur = 0; rowTur<urunTurList.size(); rowTur++) 
						{
							GnlUrunTurParametre gnlUrunTurParametre = new GnlUrunTurParametre();
							GnlUrunTurParametreId id = new GnlUrunTurParametreId();
							if( (new GMMap((Map<?,?>)urunTurList.get(rowTur)).getString("URUN_TUR_DEGER")) == null ||
								(new GMMap((Map<?,?>)urunTurList.get(rowTur)).getBigDecimal("URUN_TUR_NUMARA")) == null )
								continue;
							id.setModulTurKod((new GMMap((Map<?,?>)urunTurList.get(rowTur)).getString("MODUL_NAME")));
							id.setUrunTurKod((new GMMap((Map<?,?>)urunTurList.get(rowTur)).getString("URUN_TUR_NAME")));
							id.setParametreNumara((new GMMap((Map<?,?>)urunTurList.get(rowTur)).getBigDecimal("URUN_TUR_NUMARA")));
							gnlUrunTurParametre.setId(id);
							String tipUrunTur = (new GMMap((Map<?,?>)urunTurList.get(rowTur)).getString("TIP"));
							String degerUrunTur = (new GMMap((Map<?,?>)urunTurList.get(rowTur)).getString("URUN_TUR_DEGER"));
							if(degerUrunTur != null)
								degerUrunTur = degerUrunTur.replace("\"", "");
							if("N".equals(tipUrunTur)||"B".equals(tipUrunTur))
								;
							else
								degerUrunTur = "\""+ degerUrunTur + "\"";
							gnlUrunTurParametre.setDeger(degerUrunTur);
							session.saveOrUpdate(gnlUrunTurParametre);
							
						}
					for (int k = 0; k < node2.getChildCount(); k++) {
						DefaultMutableTreeNode node3 = (DefaultMutableTreeNode)node2.getChildAt(k);
						HashMap<?, ?> rowData3 = (HashMap<?, ?>)node3.getUserObject();
						
						List<?> urunSinifList = (List<?>)rowData3.get("PARAMETRE_MODEL");
						if(urunSinifList != null)
							for (int rowSinif = 0; rowSinif < urunSinifList.size(); rowSinif++) 
							{
								GnlUrunSinifParametre gnlUrunSinifParametre = new GnlUrunSinifParametre();
								GnlUrunSinifParametreId id = new GnlUrunSinifParametreId();
								id.setModulTurKod(new GMMap((Map<?,?>)urunSinifList.get(rowSinif)).getString("MODUL_NAME"));
								id.setUrunTurKod(new GMMap((Map<?,?>)urunSinifList.get(rowSinif)).getString("URUN_TUR_NAME"));
								id.setUrunSinifKod(new GMMap((Map<?,?>)urunSinifList.get(rowSinif)).getString("URUN_SINIF_NAME"));
								id.setParametreNumara((new GMMap((Map<?,?>)urunSinifList.get(rowSinif)).getBigDecimal("URUN_SINIF_NUMARA")));
								String tipUrunSinif = (new GMMap((Map<?,?>)urunSinifList.get(rowSinif)).getString("TIP"));
								String degerUrunSinif = (new GMMap((Map<?,?>)urunSinifList.get(rowSinif)).getString("URUN_SINIF_DEGER"));
								if(degerUrunSinif != null)
								degerUrunSinif = degerUrunSinif.replace("\"", "");
								if("N".equals(tipUrunSinif)||"B".equals(tipUrunSinif))
									;
								else
									degerUrunSinif = "\"" + degerUrunSinif + "\"";
								gnlUrunSinifParametre.setDeger(degerUrunSinif);
								gnlUrunSinifParametre.setId(id);
								session.saveOrUpdate(gnlUrunSinifParametre);
							}
					}
				}
			}
			session.flush();
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r!");
			return oMap;
		}
		catch(org.hibernate.NonUniqueObjectException nonEx){
			GMMap myMap = new GMMap();
            myMap.put("MESSAGE_NO", new BigDecimal(716));
            throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9928_SAVE_MODUL")
	public static GMMap saveModul(GMMap iMap){
		try {
			Session session 		= DAOSession.getSession("BNSPRDal");
			DefaultMutableTreeNode root = (DefaultMutableTreeNode)iMap.get("MODUL_TREE");
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode node1 = (DefaultMutableTreeNode)root.getChildAt(i);
				HashMap<?, ?> rowData = (HashMap<?, ?>)node1.getUserObject();
				List<?> modulList = (List<?>)rowData.get("PARAMETRE_MODEL");
				iMap.put("HATA_NO", new BigDecimal(330));
				if(modulList!=null)
					for (int rowTur = 0; rowTur<modulList.size(); rowTur++) 
					{
						GnlParametre gnlParametre = null;
						if((new GMMap((Map<?,?>)modulList.get(rowTur)).getBigDecimal("NUMARA"))!=null)
							gnlParametre = find((new GMMap((Map<?,?>)modulList.get(rowTur)).getBigDecimal("NUMARA")));
						if(gnlParametre == null) {
							gnlParametre = new GnlParametre();
							iMap.put("TABLE_NAME", "GNL_PARAMETRE_NUMARA");
							gnlParametre.setNumara(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", iMap).getBigDecimal("ID"));							
						}
						if((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("KOD"))==null || 
						   (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("TIP"))==null ||
						   (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("DEGER"))==null ||
						   (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("ACIKLAMA"))==null)
							continue;
						if((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("KOD"))==null)
						{
							 iMap.put("P1", "Parametre");
						     GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						gnlParametre.setKod((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("KOD")));
						if((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("ACIKLAMA"))==null)
						{
							 iMap.put("P1", "A��klama");
						     GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						gnlParametre.setAciklama((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("ACIKLAMA")));
						gnlParametre.setModulTurKod((new GMMap((Map<?,?>)modulList.get(rowTur)).getString("MODUL_NAME")));
						String tip = (new GMMap((Map<?,?>)modulList.get(rowTur)).getString("TIP"));
						if(tip == null)
						{
							 iMap.put("P1", "Tip");
						     GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						gnlParametre.setTip(tip);
						String deger=(new GMMap((Map<?,?>)modulList.get(rowTur)).getString("DEGER"));
						if(deger != null)
							deger = deger.replace("\"", "");
						else
						{
							iMap.put("P1", "De�er");
						     GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						if("N".equals(tip)||"B".equals(tip)||"D".equals(tip))
							;
						else
							deger = "\""+deger + "\"";
						gnlParametre.setDeger(deger);
						gnlParametre.setTur("G");
						session.saveOrUpdate(gnlParametre);
						
					}
			}
			
			return new GMMap();
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9928_GET_MODUL")
	public static GMMap getModul(GMMap iMap){
		try {
			Session session 		= DAOSession.getSession("BNSPRDal");
			String modulTurKod = iMap.getString("MODUL_TUR_KOD");
			List<?> modulList 	= (List<?>)session.createCriteria(GnlParametre.class)
											.add(Restrictions.eq("modulTurKod", modulTurKod))
											.addOrder(Order.asc("numara"))
											.list();
			GMMap oMap = new GMMap();
			String tableName = "MODUL";
			for (int row = 0; row < modulList.size(); row++) {
				GnlParametre gnlParametre = (GnlParametre)modulList.get(row);
				oMap.put(tableName,row,"MODUL_NAME", iMap.getString("MODUL_TUR_KOD"));
				oMap.put(tableName,row,"NUMARA", gnlParametre.getNumara());
				oMap.put(tableName,row,"KOD", gnlParametre.getKod());
				String deger = gnlParametre.getDeger();
				if(deger != null)
					deger = deger.replace("\"", "");
				oMap.put(tableName,row,"DEGER", deger);
				oMap.put(tableName,row,"ACIKLAMA", gnlParametre.getAciklama());
				oMap.put(tableName,row,"TIP", gnlParametre.getTip());
				oMap.put(tableName,row,"OLD_RECORD", "E");
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9928_GET_URUN_TUR")
	public static GMMap getUrunTur(GMMap iMap){
		try {
			Session session 		= DAOSession.getSession("BNSPRDal");
			String modulTurKod = iMap.getString("MODUL_TUR_KOD");
			String urunTurKod = iMap.getString("URUN_TUR_NUMARA");
			List<?> urunTurList 	= session.createCriteria(GnlUrunTurParametre.class)
											.add(Restrictions.eq("id.modulTurKod", modulTurKod))
											.add(Restrictions.eq("id.urunTurKod", urunTurKod))
											.addOrder(Order.asc("id.parametreNumara"))
											.list();
			GMMap oMap = new GMMap();
			String tableName = "URUN_TUR";
			for (int row = 0; row < urunTurList.size(); row++) {
				GnlUrunTurParametre gnlUrunTurParametre = (GnlUrunTurParametre)urunTurList.get(row);
				oMap.put(tableName,row,"URUN_TUR_NUMARA", gnlUrunTurParametre.getId().getParametreNumara());
				oMap.put(tableName,row,"MODUL_NAME", iMap.getString("MODUL_TUR_KOD"));
				oMap.put(tableName,row,"URUN_TUR_NAME", iMap.getString("URUN_TUR_NUMARA"));
				String deger = gnlUrunTurParametre.getDeger();
				if(deger != null)
					deger = deger.replace("\"", "");
				oMap.put(tableName,row,"URUN_TUR_DEGER", deger);
				oMap.put(tableName, row, "URUN_TUR_ACIKLAMA", LovHelper.diLov(gnlUrunTurParametre.getId().getParametreNumara(), 
						gnlUrunTurParametre.getId().getModulTurKod(), "9928P/LOV_MODUL_TUR_KOD","ACIKLAMA"));
				oMap.put(tableName, row, "UT_PARAMETRE_KOD", LovHelper.diLov(gnlUrunTurParametre.getId().getParametreNumara(), 
						gnlUrunTurParametre.getId().getModulTurKod(), "9928P/LOV_MODUL_TUR_KOD","KOD"));
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9928_GET_URUN_SINIF")
	public static GMMap getUrunSinif(GMMap iMap){
		try {
			Session session 		= DAOSession.getSession("BNSPRDal");
			String modulTurKod = iMap.getString("MODUL_TUR_KOD");
			String urunTurKod = iMap.getString("URUN_TUR_NUMARA");
			String urunSinifKod = iMap.getString("URUN_SINIF_NUMARA");
			List<?> urunSinifList 	= (List<?>)session.createCriteria(GnlUrunSinifParametre.class)
											.add(Restrictions.eq("id.modulTurKod", modulTurKod))
											.add(Restrictions.eq("id.urunTurKod", urunTurKod))
											.add(Restrictions.eq("id.urunSinifKod", urunSinifKod))
											.addOrder(Order.asc("id.parametreNumara"))
											.list();
			GMMap oMap = new GMMap();
			String tableName = "URUN_SINIF";
			for (int row = 0; row < urunSinifList.size(); row++) {
				GnlUrunSinifParametre gnlUrunSinifParametre = (GnlUrunSinifParametre)urunSinifList.get(row);
				oMap.put(tableName,row,"URUN_SINIF_NUMARA", gnlUrunSinifParametre.getId().getParametreNumara());
				oMap.put(tableName,row,"MODUL_NAME", iMap.getString("MODUL_TUR_KOD"));
				oMap.put(tableName,row,"URUN_TUR_NAME", iMap.getString("URUN_TUR_NUMARA"));
				oMap.put(tableName,row,"URUN_SINIF_NAME", urunSinifKod);
				String deger = gnlUrunSinifParametre.getDeger();
				if(deger != null)
					deger = deger.replace("\"", "");
				oMap.put(tableName,row,"URUN_SINIF_DEGER", deger);
				oMap.put(tableName, row, "URUN_SINIF_ACIKLAMA", LovHelper.diLov(gnlUrunSinifParametre.getId().getParametreNumara(), 
						gnlUrunSinifParametre.getId().getModulTurKod(), "9928P/LOV_MODUL_TUR_KOD","ACIKLAMA"));
				oMap.put(tableName, row, "US_PARAMETRE_KOD", LovHelper.diLov(gnlUrunSinifParametre.getId().getParametreNumara(), 
						gnlUrunSinifParametre.getId().getModulTurKod(), "9928P/LOV_MODUL_TUR_KOD","KOD"));
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	public static GnlParametre find(BigDecimal numara){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlParametre)session.get(GnlParametre.class, numara);
	}

} 




