package tr.com.calikbank.bnspr.system.services;


import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.GnlRolKisiselBilgi;
import tr.com.aktifbank.bnspr.dao.GnlRolKisiselBilgiTx;
import tr.com.aktifbank.bnspr.dao.GnlRolKisiselBilgiTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9955Services {
	@GraymoundService("BNSPR_TRN9955_GET_ROL_REC")
	public static GMMap getRolKisiselBilgi(GMMap iMap){
		try{
			
				GMMap oMap = new GMMap();
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> rolKisiselBilgiList = session.createCriteria(GnlRolKisiselBilgi.class).addOrder(Order.asc("rolNumara")).list();
				int row = 0;
				String tableName = "ROL_KISISEL_BILGI";
				for (Iterator<?> iterator = rolKisiselBilgiList.iterator(); iterator.hasNext(); row++) {
					GnlRolKisiselBilgi rolKisiselBilgi = (GnlRolKisiselBilgi) iterator.next();
					oMap.put(tableName, row, "ROL_NUMARA", rolKisiselBilgi.getRolNumara());
					oMap.put(tableName, row, "TANIM", rolKisiselBilgi.getTanim());
					
				}

				return oMap;
			}catch(Exception e){
				throw ExceptionHandler.convertException(e);
			}
		
	}
	
	@GraymoundService("BNSPR_TRN9955_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> rolKisiselBilgiList = (List<?>)session.createCriteria(GnlRolKisiselBilgiTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = rolKisiselBilgiList.iterator(); iterator.hasNext();) {
				GnlRolKisiselBilgiTx rolKisiselBilgi = (GnlRolKisiselBilgiTx) iterator.next();
				session.delete(rolKisiselBilgi);
			}
	
			String tableName = "ROL_KISISEL_BILGI";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				
				GnlRolKisiselBilgiTx gnlRolKisiselBilgiTx = new GnlRolKisiselBilgiTx();
				GnlRolKisiselBilgiTxId gnlRolKisiselBilgiTxId = new GnlRolKisiselBilgiTxId();
	
				gnlRolKisiselBilgiTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlRolKisiselBilgiTxId.setRolNumara(iMap.getBigDecimal(tableName, row,"ROL_NUMARA"));
				gnlRolKisiselBilgiTx.setId(gnlRolKisiselBilgiTxId);
				gnlRolKisiselBilgiTx.setTanim(iMap.getString(tableName, row,"TANIM"));
				gnlRolKisiselBilgiTx.setGS(iMap.getString(tableName , row , "GDS"));
              
				session.saveOrUpdate(gnlRolKisiselBilgiTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "9955");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

	
	@GraymoundService("BNSPR_TRN9955_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					GnlRolKisiselBilgiTx.class).add(
					Restrictions.eq("id.txNo", iMap
							.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "ROL_KISISEL_BILGI";
	
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlRolKisiselBilgiTx gnlRolKisiselBilgi = (GnlRolKisiselBilgiTx)iterator.next();
				oMap.put(tableName, row, "ROL_NUMARA", gnlRolKisiselBilgi.getId().getRolNumara());
				oMap.put(tableName, row, "TANIM", gnlRolKisiselBilgi.getTanim());
              
                if((gnlRolKisiselBilgi.getGS() != null) && (!StringUtils.isEmpty(gnlRolKisiselBilgi.getGS())))
                    oMap.put(tableName , row , "GDS",gnlRolKisiselBilgi.getGS());
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	

	@GraymoundService("BNSPR_TRN9955_CHECK_EXIST_ROL")
	public static GMMap checkExistRole(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			if((iMap.getBigDecimal("ROL_NUMARA") == null) || (iMap.getBigDecimal("ROL_NUMARA").toString().length()==0))
				throw new GMRuntimeException(10561, "Eklenecek ROL NUMARA  bo� olamaz!");
		

			String tableName = "ROL_KISISEL_BILGI";
			for (int i = 0; i < iMap.getSize(tableName); i++) {

				if (iMap.getBigDecimal(tableName, i, "ROL_NUMARA").equals(iMap.getBigDecimal("ROL_NUMARA")))
					throw new GMRuntimeException(10561, "Bu ROL daha �nce eklenmi�!");

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
