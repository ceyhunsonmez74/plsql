package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemQRY9937Services {
	
	@GraymoundService("BNSPR_QRY9937_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			iMap.put("KOD", "EVET_HAYIR");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("EVET_HAYIR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "ISLEM_DURUM_KOD");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "ISLEM_DURUM_KOD");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("ISLEM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	

	@GraymoundService("BNSPR_QRY9937_GET_LOG_LIST")
	public static GMMap GetLogList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC9937.RC_QRY9937_EOD_Log(?) }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			if (!(iMap.get("TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			stmt.execute();
			String tableName = "EOD_LOG";
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);
		/*	int row = 0;
			while (rSet.next()){
				oMap.put(tableName, row,"KANAL_KOD",rSet.getString("KOD"));
				oMap.put(tableName, row, "KANAL", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "SEC", false);
				row ++;
			}*/
		return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}	
	}
}
