package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.islBirimKod;
import tr.com.aktifbank.bnspr.dao.islBirimKodId;
import tr.com.aktifbank.bnspr.dao.islBirimKodTx;
import tr.com.aktifbank.bnspr.dao.islBolumKod;
import tr.com.aktifbank.bnspr.dao.islServisKod;
import tr.com.aktifbank.bnspr.dao.islServisKodTx;
import tr.com.aktifbank.bnspr.dao.islServisKodTxId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * BPM_GROUP_ROLE services
 * 
 * @author samet.erkorkmaz
 *
 */
public class SystemTRN9813Services {
	
	@GraymoundService("BNSPR_TRN9813_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int i=0;
		try {
			List<islServisKodTx> servisKodTxList =  (List<islServisKodTx>) session.createCriteria(islServisKodTx.class).add(Restrictions.eq("id.txNo",  iMap.getBigDecimal("TRX_NO"))).list();        
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			for(islServisKodTx servisKodTx: servisKodTxList){
				oMap.put("SERVIS_KOD_LIST",i,"ACIKLAMA",servisKodTx.getAciklama());
				oMap.put("SERVIS_KOD_LIST",i,"GDS",servisKodTx.getDgs());
				oMap.put("SERVIS_KOD_LIST",i,"BIRIM_KOD",servisKodTx.getId().getBirimKod());
				oMap.put("SERVIS_KOD_LIST",i,"BIRIM_ADI",getBirimAdi(servisKodTx.getId().getBolumKod(), servisKodTx.getId().getBirimKod()));
				oMap.put("SERVIS_KOD_LIST",i,"BOLUM_KOD",servisKodTx.getId().getBolumKod());
				oMap.put("SERVIS_KOD_LIST",i,"BOLUM_ADI",getBolumAdi(servisKodTx.getId().getBolumKod()));
				oMap.put("SERVIS_KOD_LIST",i,"KOD",servisKodTx.getId().getKod());
			}
		} finally {
			session.close();
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(List<islServisKod> servisKodList,GMMap oMap){
		int index=0;
		for(islServisKod servisKod:servisKodList) {
			oMap.put("SERVIS_KOD_LIST", index, "BOLUM_KOD", servisKod.getId().getBolumKod());
			oMap.put("SERVIS_KOD_LIST", index, "BOLUM_ADI", getBolumAdi(servisKod.getId().getBolumKod()));
			oMap.put("SERVIS_KOD_LIST", index, "BIRIM_KOD", servisKod.getId().getBirimKod());
			oMap.put("SERVIS_KOD_LIST", index, "BIRIM_ADI", getBirimAdi(servisKod.getId().getBolumKod(), servisKod.getId().getBirimKod()));
			oMap.put("SERVIS_KOD_LIST", index, "KOD", servisKod.getId().getKod());
			oMap.put("SERVIS_KOD_LIST", index, "ACIKLAMA", servisKod.getAciklama());
			
			index++;
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(islBirimKod birimKod,GMMap oMap){
		oMap.put("BIRIM_KOD_LIST", 0, "BOLUM_KOD", birimKod.getId().getBolumKod());
		oMap.put("BIRIM_KOD_LIST", 0, "BOLUM_ADI", getBolumAdi(birimKod.getId().getBolumKod()));
		oMap.put("BIRIM_KOD_LIST", 0, "KOD", birimKod.getId().getKod());
		oMap.put("BIRIM_KOD_LIST", 0, "ACIKLAMA", birimKod.getAciklama());
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN9813_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");	
		@SuppressWarnings("unchecked")
		List<islServisKod> servisKodList = (List<islServisKod>)session.createCriteria(islServisKod.class).list();		
		
		return putObjToGMMap(servisKodList, oMap);
	}
	
	@GraymoundService("BNSPR_TRN9813_FILL_BOLUM_COMBO")
	public static GMMap fillGroupCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBolumKod> bolumKodList = (List<islBolumKod>)session.createCriteria(islBolumKod.class)
													.addOrder(Order.asc("kod")).list();
		for (islBolumKod bolumKod : bolumKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BOLUM", bolumKod.getKod().toString(), bolumKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9813_FILL_BIRIM_COMBO")
	public static GMMap fillBirimCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBirimKod> birimKodList = (List<islBirimKod>)session.createCriteria(islBirimKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islBirimKod birimKod : birimKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BIRIM", birimKod.getId().getKod().toString(), birimKod.getAciklama());
		}
		return oMap;
	}

		
	@GraymoundService("BNSPR_TRN9813_SAVE")
	public static GMMap save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		BigDecimal kod = BigDecimal.ZERO; 
		GMMap oMap = new GMMap();
		if (iMap.getSize("SERVIS_KOD_LIST")>0){
			for (int i = 0; i < iMap.getSize("SERVIS_KOD_LIST"); i++) {
				if(!StringUtil.isEmpty(iMap.getString("SERVIS_KOD_LIST",i,"GDS"))){
					islServisKodTxId id = new islServisKodTxId();
					id.setBirimKod(iMap.getBigDecimal("SERVIS_KOD_LIST",i,"BIRIM_KOD"));
					id.setBolumKod(iMap.getBigDecimal("SERVIS_KOD_LIST",i,"BOLUM_KOD"));
					if (iMap.getString("SERVIS_KOD_LIST",i,"GDS").equals("G")){
						kod=BigDecimal.valueOf(Long.valueOf(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "ISL_SERVIS_KOD_TX")).getString("ID")));
					}else{
						kod = iMap.getBigDecimal("SERVIS_KOD_LIST",i,"KOD");
					}
					id.setKod(kod);
					
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					islServisKodTx servisKodTx = new islServisKodTx();
					servisKodTx.setAciklama(iMap.getString("SERVIS_KOD_LIST",i,"ACIKLAMA"));
					servisKodTx.setDgs(iMap.getString("SERVIS_KOD_LIST",i,"GDS"));
					servisKodTx.setId(id);
					servisKodTx.setLastModified(date);
					session.saveOrUpdate(servisKodTx);
			}
		}
		
		session.flush();
		oMap = callSendTrn(iMap);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9813_UPDATE")
	public static GMMap update(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		islBirimKodTx birimKodTx = new islBirimKodTx();
		birimKodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birimKodTx.setAciklama(iMap.getString("ACIKLAMA"));
		birimKodTx.setBolumKod(iMap.getBigDecimal("BOLUM_KOD"));
		birimKodTx.setDgs("D");
		birimKodTx.setKod(iMap.getBigDecimal("KOD"));
		birimKodTx.setLastModified(date);
		session.save(birimKodTx);
		session.flush();
		return callSendTrn(iMap);
	}
	@GraymoundService("BNSPR_TRN9813_DELETE")
	public static GMMap delete(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		islBirimKodId id = new islBirimKodId();
		id.setBolumKod(iMap.getBigDecimal("BOLUM_KOD"));
		id.setKod(iMap.getBigDecimal("KOD"));		
		islBirimKod birimKod = (islBirimKod)session.get(islBirimKod.class, id);		

		islBirimKodTx birimKodTx = new islBirimKodTx();
		birimKodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birimKodTx.setBolumKod(birimKod.getId().getBolumKod());
		birimKodTx.setKod(birimKod.getId().getKod());
		birimKodTx.setDgs("S");
		birimKodTx.setAciklama(iMap.getString("BIRIM_ADI"));
		birimKodTx.setLastModified(date);
		session.save(birimKodTx);
		session.flush();
		return callSendTrn(iMap);
	}
	
	private static GMMap callSendTrn(GMMap iMap){
		iMap.put("TRX_NAME" , "9813");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
	
	
	private static String getBolumAdi(BigDecimal bolumKod){
		islBolumKod group = (islBolumKod) DAOSession.getSession("BNSPRDal").get(islBolumKod.class, bolumKod);
		return group.getAciklama();
	}
	private static String getBirimAdi(BigDecimal bolumKod, BigDecimal birimKod){
		islBirimKodId id = new  islBirimKodId();
		id.setBolumKod(bolumKod);
		id.setKod(birimKod);
		islBirimKod group = (islBirimKod) DAOSession.getSession("BNSPRDal").get(islBirimKod.class, id);
		return group.getAciklama();
	}
}
