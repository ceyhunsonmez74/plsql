package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlSubeEftBagimliTx;
import tr.com.calikbank.bnspr.dao.GnlSubeKodPrTx;
import tr.com.calikbank.bnspr.dao.GnlSubeTakasBagimliTx;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9901Services {
	public static final String SUBE_KROKI_ROOT_DIR = "SUBE_KROKI";
	
	@GraymoundService("BNSPR_TRN9901_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GnlSubeKodPrTx gnlSubeKodPrTx = (GnlSubeKodPrTx)session.get(GnlSubeKodPrTx.class, iMap.getBigDecimal("TRX_NO"));
			if(gnlSubeKodPrTx == null){
				gnlSubeKodPrTx = new GnlSubeKodPrTx();
			}
			
			gnlSubeKodPrTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        gnlSubeKodPrTx.setKod(iMap.getString("SUBE_KODU"));
	        gnlSubeKodPrTx.setSubeAdi(iMap.getString("SUBE_ADI"));
	        gnlSubeKodPrTx.setSubeAdiIng(iMap.getString("SUBE_ADI_ING"));
	        gnlSubeKodPrTx.setIlKod(iMap.getString("IL_KODU"));
	        gnlSubeKodPrTx.setIlceKod(iMap.getString("ILCE_KODU"));
	        gnlSubeKodPrTx.setUlkeKod(iMap.getString("ULKE_KODU"));
	        gnlSubeKodPrTx.setEftKodu(iMap.getString("EFT_KODU"));
	        gnlSubeKodPrTx.setSubeGm(iMap.getString("SUBE_F"));
	        gnlSubeKodPrTx.setSiraNo(iMap.getBigDecimal("SIRA_NO"));
	        gnlSubeKodPrTx.setTakasKodu(iMap.getString("TAKAS_KODU"));
	        gnlSubeKodPrTx.setKarMerkezi(iMap.getString("KAR_MERKEZI"));
	        gnlSubeKodPrTx.setYurtIci(iMap.getString("YURT_ICI"));
	        gnlSubeKodPrTx.setTescilTarihi(iMap.getDate("TESCIL_TARIHI"));
	        gnlSubeKodPrTx.setAcilisTarihi(iMap.getDate("ACILIS_TARIHI"));
	        gnlSubeKodPrTx.setSubeTipi(iMap.getString("SUBE_TIPI"));
	        
	        
	        try {
				gnlSubeKodPrTx.setMemzucIlceKodu(new Byte((String) iMap
						.get("MEMZUC_ILCE_KODU")));
			} catch (Exception e) {
				gnlSubeKodPrTx.setMemzucIlceKodu(null);
			}
			try {
				gnlSubeKodPrTx.setMemzucIlceSubeSira(new Byte((String) iMap
						.get("MEMZUC_ILCE_SUBE_SIRA")));
			} catch (Exception e) {
				gnlSubeKodPrTx.setMemzucIlceKodu(null);
			}
			gnlSubeKodPrTx.setKasaMevcut(iMap.getString("KASA_MEVCUT_MU"));
			
			gnlSubeKodPrTx.setAdres1(iMap.getString("ADRES"));
			gnlSubeKodPrTx.setTelefon(iMap.getString("TELEFON"));
			gnlSubeKodPrTx.setFax(iMap.getString("FAX"));
			gnlSubeKodPrTx.setVergiDaire(iMap.getString("VERGI_DAIRE"));
			gnlSubeKodPrTx.setVergiNo(iMap.getString("VERGI_NO"));
			gnlSubeKodPrTx.setDurumu(iMap.getString("DURUMU"));
			gnlSubeKodPrTx.setResmiDefterBolumKodu(iMap.getString("RESMI_DEFTER_BOLUM_KODU"));
			gnlSubeKodPrTx.setResmiDefterBolumKodu(iMap.getString("RESMI_DEFTER_BOLUM_KODU"));
	        gnlSubeKodPrTx.setKrokiFileName(iMap.getString("FILE_NAME"));
	        
			List<?> listTakasBagimli = (List<?>) session.createCriteria(
					GnlSubeTakasBagimliTx.class).add(
					Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
					.list();
			for (Iterator<?> iterator = listTakasBagimli.iterator(); iterator
					.hasNext();) {
				GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx) iterator
						.next();
				session.delete(gnlSubeTakasBagimliTx);
			}

			session.flush();

	        String tableName = "TAKAS_BAGIMLI_ISLEM";
	        for (int row = 0; row < iMap.getSize(tableName); row++) {
	        	GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = new GnlSubeTakasBagimliTx();
		        gnlSubeTakasBagimliTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		        gnlSubeTakasBagimliTx.setBolumKodu(iMap.getString("SUBE_KODU"));
		        gnlSubeTakasBagimliTx.setBagliBolumKodu(iMap.getString(tableName, row, "TAKAS_BAGLI_BOLUM_KODU"));
		        
	        	session.saveOrUpdate(gnlSubeTakasBagimliTx);
	        }
	        List<?> listEftBagimli = (List<?>) session.createCriteria(GnlSubeEftBagimliTx.class).add(
					Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
					.list();

			for (Iterator<?> iterator = listEftBagimli.iterator(); iterator.hasNext();) {
				GnlSubeEftBagimliTx gnlSubeEftBagimliTx = (GnlSubeEftBagimliTx) iterator
						.next();
				session.delete(gnlSubeEftBagimliTx);
			}

			session.flush();
			
	        tableName = "EFT_BAGIMLI_ISLEM";
	        for (int row = 0; row < iMap.getSize(tableName); row++) {
	        	GnlSubeEftBagimliTx gnlSubeEftBagimliTx =  new GnlSubeEftBagimliTx();
	        	gnlSubeEftBagimliTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        	gnlSubeEftBagimliTx.setBolumKodu(iMap.getString("SUBE_KODU"));
	        	gnlSubeEftBagimliTx.setBagliBolumKodu(iMap.getString(tableName, row, "EFT_BAGLI_BOLUM_KODU"));
		        
	        	session.saveOrUpdate(gnlSubeEftBagimliTx);
	        }
	        
	        gnlSubeKodPrTx.setKrokiFileName(sendSubeKroki(iMap, gnlSubeKodPrTx));
			
			session.saveOrUpdate(gnlSubeKodPrTx);
			session.flush();

			iMap.put("TRX_NAME", "9901");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static String sendSubeKroki(GMMap iMap, GnlSubeKodPrTx gnlSubeKodPrTx) {
		if(iMap.get("FILE_CONTENT") != null && iMap.get("FILE_NAME") != null 
				&& !("".equals(iMap.get("FILE_NAME"))) && !("".equals(iMap.get("FILE_CONTENT")))){ //kroki dokuman y�netim sistemine g�nderilecek
			String orgFileName = iMap.getString("FILE_NAME");
			String extension = orgFileName.substring(orgFileName.lastIndexOf('.')); //.jpg 
			iMap.put("FILE_DIRECTORY", SUBE_KROKI_ROOT_DIR);
			String fileName = gnlSubeKodPrTx.getKod()+ extension;
			iMap.put("FILE_NAME", fileName);
			GMServiceExecuter.execute("BNSPR_TRN1090_SEND_FILE_TO_REPOSITORY", iMap);
			return fileName;
		}
		return null;
	}
	
	@GraymoundService("BNSPR_TRN9901_GET_SUBE_BILGI")
	public static GMMap getSubeBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GnlSubeKodPrTx gnlSubeKodPrTx = (GnlSubeKodPrTx)session.get(GnlSubeKodPrTx.class, iMap.getBigDecimal("TRX_NO"));		
			
			oMap.put("TRX_NO", gnlSubeKodPrTx.getTxNo());
			oMap.put("KODU" , gnlSubeKodPrTx.getKod());
	        oMap.put("ADI" , gnlSubeKodPrTx.getSubeAdi());
	        oMap.put("SUBE_ADI_ING" , gnlSubeKodPrTx.getSubeAdiIng());
	        oMap.put("IL_KODU" , gnlSubeKodPrTx.getIlKod());
	        oMap.put("IL_ADI",LovHelper.diLov(gnlSubeKodPrTx.getIlKod(), "9901/LV_IL", "IL_ADI"));
	        oMap.put("EFT_KODU" , gnlSubeKodPrTx.getEftKodu());
	        oMap.put("SUBE_F" , gnlSubeKodPrTx.getSubeGm());
	        oMap.put("SIRA_NO" , gnlSubeKodPrTx.getSiraNo());
	        oMap.put("TAKAS_KODU" , gnlSubeKodPrTx.getTakasKodu());
	        oMap.put("KAR_MERKEZI" , gnlSubeKodPrTx.getKarMerkezi());
	        oMap.put("YURT_ICI" , gnlSubeKodPrTx.getYurtIci());
	        oMap.put("MEMZUC_ILCE_KODU" , gnlSubeKodPrTx.getMemzucIlceKodu());
	        oMap.put("MEMZUC_ILCE_SUBE_SIRA" , gnlSubeKodPrTx.getMemzucIlceSubeSira());
	        oMap.put("KASA_MEVCUT_MU" , gnlSubeKodPrTx.getKasaMevcut());       
	        oMap.put("ILCE_KODU" , gnlSubeKodPrTx.getIlceKod());
	        oMap.put("ILCE_ADI" ,LovHelper.diLov(gnlSubeKodPrTx.getIlceKod(),gnlSubeKodPrTx.getIlKod(),"9901/LV_ILCE_KODU", "ILCE_ADI"));    
	        oMap.put("ULKE_KODU" , gnlSubeKodPrTx.getUlkeKod());      
	        oMap.put("ULKE_ADI",LovHelper.diLov(gnlSubeKodPrTx.getUlkeKod(), "9901/LV_ULKE_KODU", "ULKE_ADI"));
	        oMap.put("ADRES" , gnlSubeKodPrTx.getAdres1());
	        oMap.put("TELEFON" , gnlSubeKodPrTx.getTelefon());
	        oMap.put("FAX" , gnlSubeKodPrTx.getFax());
	        oMap.put("RESMI_DEFTER_BOLUM_KODU" , gnlSubeKodPrTx.getResmiDefterBolumKodu());
	        oMap.put("VERGI_DAIRE" , gnlSubeKodPrTx.getVergiDaire());
	        oMap.put("VERGI_NO" , gnlSubeKodPrTx.getVergiNo());
	        oMap.put("DURUM" , gnlSubeKodPrTx.getDurumu());
	        oMap.put("TESCIL_TARIHI" , gnlSubeKodPrTx.getTescilTarihi());
	        oMap.put("ACILIS_TARIHI" , gnlSubeKodPrTx.getAcilisTarihi());
	        oMap.put("SUBE_TIPI" , gnlSubeKodPrTx.getSubeTipi());
	        oMap.put("FILE_NAME" , gnlSubeKodPrTx.getKrokiFileName());
	        
	        List<?> list = session.createCriteria(GnlSubeTakasBagimliTx.class).add(Restrictions.eq("txNo", oMap.getBigDecimal("TRX_NO"))).list();
	        
	        String tableName = "BOLUM_TAKAS_BAGIMLI_ISLEM";
	        int row = 0;
			for (Iterator<?> iter = list.iterator(); iter.hasNext();row++) {
				GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx) iter.next();
				oMap.put(tableName, row, "TAKAS_BAGLI_BOLUM_KODU", gnlSubeTakasBagimliTx.getBagliBolumKodu());
				oMap.put(tableName, row, "NDB_TAKAS_BAGLI_BOLUM_ADI", LovHelper.diLov(
						gnlSubeTakasBagimliTx.getBagliBolumKodu(),
						"9901/LV_EFT_BOLUM", "ADI"));
			}
	        
			List<?> list1 = session.createCriteria(GnlSubeEftBagimliTx.class).add(
					Restrictions.eq("txNo", oMap
							.getBigDecimal("TRX_NO"))).list();
			
			tableName = "BOLUM_EFT_BAGIMLI_ISLEM";
			row = 0;
			for (Iterator<?> iter = list1.iterator(); iter.hasNext();row++) {
				GnlSubeEftBagimliTx gnlSubeEftBagimliTx = (GnlSubeEftBagimliTx) iter
						.next();
				oMap.put(tableName, row, "EFT_BAGLI_BOLUM_KODU", gnlSubeEftBagimliTx.getBagliBolumKodu());
				oMap.put(tableName, row, "NDB_EFT_BAGLI_BOLUM_ADI", LovHelper.diLov(
						gnlSubeEftBagimliTx.getBagliBolumKodu(), "9901/LV_TAKAS_BOLUM", "ADI"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
