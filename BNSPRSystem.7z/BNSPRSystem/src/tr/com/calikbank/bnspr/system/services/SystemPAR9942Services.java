package tr.com.calikbank.bnspr.system.services;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;


import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlBatchProgramTanim;
import tr.com.calikbank.bnspr.dao.GnlBatchProgramTanimId;
import tr.com.calikbank.bnspr.util.DALUtil;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9942Services {

	@GraymoundService("BNSPR_PAR9942_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		oMap.put("GECERLI_MI", 0,"VALUE","E");
		oMap.put("GECERLI_MI", 0,"NAME","Evet");
		oMap.put("GECERLI_MI", 1,"VALUE","H");
		oMap.put("GECERLI_MI", 1,"NAME","Hay�r");
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9942_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			StringBuffer query = new StringBuffer();
			query.append(" select * from GNL_BATCH_PROGRAM_TANIM order by grup_no ");

			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();
			String tableName = "GNL_BATCH_PROGRAM_TANIM";
			for (int row = 0; rSet.next(); row++) {
				int i = 1;
				oMap.put(tableName, row, "GRUP_NO", rSet.getString(i++));
				oMap.put(tableName, row, "PROGRAM_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "SIRA_NO", rSet.getString(i++));
				oMap.put(tableName, row, "GECERLI", rSet.getString(i++));
				
			}

			oMap.put("ROW_COUNT", iMap.getSize(tableName));

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR9942_SEARCH")
	public static GMMap search(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();


			String aranacak = iMap.getString("ARANACAK");
			String aramaKriteri = iMap.getString("KRITER");
			String listTableName = "LIST";
			String paramTextTableName = "GNL_BATCH_PROGRAM_TANIM";
			int i = 0;
			for (int row = 0; row < iMap.getSize(paramTextTableName); row++) {
				if (iMap.getString(paramTextTableName, row, aramaKriteri).contains(aranacak)) {
					oMap.put(listTableName, i, "GRUP_NO", iMap.get(paramTextTableName, row, "GRUP_NO"));
					oMap.put(listTableName, i, "PROGRAM_KOD", iMap.get(paramTextTableName, row, "PROGRAM_KOD"));
					oMap.put(listTableName, i, "SIRA_NO", iMap.get(paramTextTableName, row, "SIRA_NO"));
					oMap.put(listTableName, i, "GECERLI", iMap.get(paramTextTableName, row, "GECERLI"));
					i++;
				}
			}

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	@GraymoundService("BNSPR_PAR9942_SAVE")
	public static GMMap save(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> satirPersistenceList = session.createCriteria(GnlBatchProgramTanim.class).list();
			for (Iterator<?> iterator = satirPersistenceList.iterator(); iterator.hasNext();) {  //id.txNo // id.muhSbaFisTx.txNo txNo
				GnlBatchProgramTanim gnlBatchProgTanim = (GnlBatchProgramTanim) iterator.next();
				session.delete(gnlBatchProgTanim);
				session.flush();
			}
			
			GnlBatchProgramTanim gnlBatchProgTanim;
			
			String tableName = "GNL_BATCH_PROGRAM_TANIM";
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlBatchProgramTanimId id = new GnlBatchProgramTanimId();
				
				id.setGrupNo		(iMap.getBigDecimal(tableName, row, "GRUP_NO"));
				id.setProgramKod	(iMap.getString(tableName, row, "PROGRAM_KOD"));
				
				gnlBatchProgTanim = new GnlBatchProgramTanim();
				
				gnlBatchProgTanim.setId(id);
				gnlBatchProgTanim.setGecerli(iMap.getString		(tableName, row, "GECERLI"));
				gnlBatchProgTanim.setSiraNo(iMap.getBigDecimal	(tableName, row, "SIRA_NO"));
				
				session.saveOrUpdate(gnlBatchProgTanim);
				session.flush();
				
			}
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

}