 package tr.com.calikbank.bnspr.system.services;


import java.awt.Color;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.FiLimitTanimlamaTx;
import tr.com.aktifbank.bnspr.dao.GnlTatilPrTx;
import tr.com.aktifbank.bnspr.dao.GnlTatilPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;



import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9976Services {
	
	@GraymoundService("BNSPR_TRN9976_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboboxInitialValue(GMMap iMap) {
		
		try {
			GMMap oMap = new GMMap();
			
			iMap.put("KOD", "TARIH_TIPLERI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("TARIH_TIP", GMServiceExecuter.execute(
					"BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "TATIL_DURUM_KODU");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("TATIL_DURUM", GMServiceExecuter.execute(
					"BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
	      return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9976_GET_RECORDS")
	    public static GMMap getRecords(GMMap iMap) {
	        
	        GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        String tableName = "TBL_TATIL";
	        try{
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN9976.RC9976_get_list}");
	            stmt.registerOutParameter(1 , -10); // ref cursor
	            stmt.execute();
	            rSet = (ResultSet) stmt.getObject(1);
	            oMap = DALUtil.rSetResults(rSet , tableName);
	            
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	            GMServerDatasource.close(rSet);
	        }
	        
	    }
	
	 @GraymoundService("BNSPR_TRN9976_ZORUNLU_ALAN_KONTROLU")
	    public static GMMap getZorunluAlanKontrolu(GMMap iMap) {
	        
	        Connection conn = null;
	        CallableStatement stmt = null;
	        
	        try{
	            
	            conn = DALUtil.getGMConnection();
	            
	            GMMap oMap = new GMMap();
	            
	            if (iMap.getDate("TARIH") == null || "".equals(iMap.getDate("TARIH")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Tarih");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            
	            if (iMap.getString("ULKE_KODU") == null || "".equals(iMap.getString("ULKE_KODU")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Ulke Kodu");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            
	            
	            if (iMap.getString("COMBO_TATIL_TIP") == null || "".equals(iMap.getString("COMBO_TATIL_TIP")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Tatil Tipi");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            
	            if (iMap.getString("DURUM") == null || "".equals(iMap.getString("DURUM")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Durum");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            
	            if (iMap.getString("ACIKLAMA") == null || "".equals(iMap.getString("ACIKLAMA")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "ACIKLAMA");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }   
	    
	    @GraymoundService("BNSPR_TRN9976_SAVE")
	    public static Map<?, ?> save(GMMap iMap) {
	        try{
	            Session session = DAOSession.getSession("BNSPRDal");
	            String tableName = "TBL_TATIL";
	            
	            List<?> recordList = (List<?>) iMap.get(tableName);
	            
	            for (int row = 0; row < recordList.size(); row++){
	                
	                GnlTatilPrTxId id = new GnlTatilPrTxId();
	                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
	                id.setKod(iMap.getString(tableName , row , "KOD"));
	                id.setTarih(iMap.getDate(tableName, row, "TARIH"));
	                
	                GnlTatilPrTx gnlTatilPrTx = (GnlTatilPrTx) session.get(GnlTatilPrTx.class , id);
	                
	                if (gnlTatilPrTx == null){
	                	gnlTatilPrTx = new GnlTatilPrTx();
	                }
	                gnlTatilPrTx.setId(id);
	                
	             /*   if (("S").equals(iMap.getString(tableName , row , "G_S")))
	                	gnlTatilPrTx.setGS("S");
	                else if (("G").equals(iMap.getString(tableName, row, "G_S")))
	                	gnlTatilPrTx.setGS("G");
	                else gnlTatilPrTx.setGS("");*/
	                
	                gnlTatilPrTx.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
	                gnlTatilPrTx.setDurum(iMap.getString(tableName, row, "DURUM"));
	                gnlTatilPrTx.setTarihTip(iMap.getString(tableName, row, "TARIH_TIP"));
	               
	                session.saveOrUpdate(gnlTatilPrTx);
	            }
	            session.flush();
	            iMap.put("TRX_NAME" , "9976");
	            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        }
	    }
	    
	    @GraymoundService("BNSPR_TRN9976_GET_INFO")
	    public static GMMap getInfo(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        
	        try{
	            // Get Master
	            String tableName = "TBL_TATIL";
	            Session session = DAOSession.getSession("BNSPRDal");
	            Criteria criteria = session.createCriteria(GnlTatilPrTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
	            
	            List<?> recordList = (List<?>) criteria.list();
	            
	            for (int row = 0; row < recordList.size(); row++){
	            	GnlTatilPrTx gnlTatilPrTx = (GnlTatilPrTx) recordList.get(row);
	                
	            	oMap.put("TX_NO" , iMap.getBigDecimal("TRX_NO"));
	                oMap.put(tableName , row , "KOD" , gnlTatilPrTx.getId().getKod());
	                oMap.put(tableName , row , "TARIH" ,gnlTatilPrTx.getId().getTarih());
	           //     oMap.put(tableName , row , "SIL" , ("S").equals(gnlTatilPrTx.getGS()) ? true : false);
	                oMap.put(tableName , row , "ACIKLAMA" , gnlTatilPrTx.getAciklama());
	                oMap.put(tableName , row , "DURUM" , gnlTatilPrTx.getDurum());
	                oMap.put(tableName , row , "TARIH_TIP" , gnlTatilPrTx.getTarihTip());
	                
	                
	            }
	            
	            return oMap;
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        }
	    }
	    
	    @GraymoundService("BNSPR_TRN9976_KAYIT_KONTROLU")
	    public static GMMap getTanimliMusteriVarMi(GMMap iMap) {
	        
	        Connection conn = null;
	        CallableStatement stmt = null;

	        
	        try{
	            
	            conn = DALUtil.getGMConnection();
	            
	            stmt = conn.prepareCall("{? = call PKG_TRN9976.tanimli_kayit_kontrolu(?,?)}");
	            stmt.registerOutParameter(1 , Types.VARCHAR);
	            stmt.setString(2 , iMap.getString("KOD"));
	            stmt.setDate(3 , new java.sql.Date(iMap.getDate("TARIH").getTime()));
	            stmt.execute();
	            
	            GMMap oMap = new GMMap();
	            oMap.put("MESSAGE" , stmt.getString(1));
	            
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	        
	    }
	    
	    @GraymoundService("BNSPR_TRN9976_GET_ONCEKI_TX_NO")
		public static GMMap getOncekiTxNo(GMMap iMap) {
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try {
			
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_9976(?)}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.execute();
				
				oMap.put("ONCEKI_TX_NO",stmt.getBigDecimal(1));
				
				
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			return oMap;
		}
		
		private static GMMap getUnchangedTableCellColorData(){
			GMMap oMap = new GMMap();
			oMap.put("setForeground", Color.BLACK);
			oMap.put("setBackground", Color.WHITE);
			return oMap;
		}
		
		
		@GraymoundService("BNSPR_TRN9976_RENKLENDIR")
		public static GMMap renklendirme(GMMap iMap) {
			GMMap oMap = new GMMap();
			try {
				Session session = DAOSession.getSession("BNSPRDal");

				// RENKLENDIRME
				BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
				BigDecimal eskiTxNo = iMap.getBigDecimal("ONCEKI_TX_NO");
			
				List<?> newLimitList = session.createCriteria(GnlTatilPrTx.class)
									.add(Restrictions.eq("id.txNo", txNo))
									.list();
				List<?> oldLimitList = session.createCriteria(GnlTatilPrTx.class)
									.add(Restrictions.eq("id.txNo", eskiTxNo))
									.list();	
				
				String newTableName = "NEW_LIMIT_LIST";
				String oldTableName = "OLD_LIMIT_LIST";
				
				for (int row = 0; row < newLimitList.size(); row++) {
					GnlTatilPrTx gnlTatilPrTx = (GnlTatilPrTx) newLimitList.get(row);

					oMap.put(newTableName, row, "KOD", gnlTatilPrTx.getId().getKod());
					oMap.put(newTableName, row, "TARIH", gnlTatilPrTx.getId().getTarih());
					oMap.put(newTableName, row, "ACIKLAMA", gnlTatilPrTx.getAciklama());
					oMap.put(newTableName, row, "DURUM", gnlTatilPrTx.getDurum());
					oMap.put(newTableName, row, "TARIH_TIP", gnlTatilPrTx.getTarihTip());
					
				}
				for (int row = 0; row < oldLimitList.size(); row++) {
					GnlTatilPrTx gnlTatilPrTx = (GnlTatilPrTx) oldLimitList.get(row);
					
					oMap.put(oldTableName, row, "KOD", gnlTatilPrTx.getId().getKod());
					oMap.put(oldTableName, row, "TARIH", gnlTatilPrTx.getId().getTarih());
					oMap.put(oldTableName, row, "ACIKLAMA", gnlTatilPrTx.getAciklama());
					oMap.put(oldTableName, row, "DURUM", gnlTatilPrTx.getDurum());
					oMap.put(oldTableName, row, "TARIH_TIP", gnlTatilPrTx.getTarihTip());
				
				}
				
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("KOD");
				keyColumns.add("TARIH");
				
				oMap.put("TATIL_COLOR_DATA", BeanSetProperties.tableDifference(
						(ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), keyColumns)
						.get("COLOR_DATA"));
				
			
				
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		

	    /*
		@GraymoundService("BNSPR_TRN9976_RENKLENDIR")
		public static GMMap renklendirme(GMMap iMap) {
			GMMap oMap = new GMMap();
			try {
				Session session = DAOSession.getSession("BNSPRDal");

				// RENKLENDIRME
				BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
				BigDecimal eskiTxNo = iMap.getBigDecimal("ONCEKI_TX_NO");
			
				List<?> newTatilList = session.createCriteria(GnlTatilPrTx.class)
									.add(Restrictions.eq("id.txNo", txNo))
									.list();
				List<?> oldTatilList = session.createCriteria(GnlTatilPrTx.class)
									.add(Restrictions.eq("id.txNo", eskiTxNo))
									.list();	
				
				String newTableName = "NEW_TATIL_LIST";
				String oldTableName = "OLD_TATIL_LIST";
				
				for (int row = 0; row < newTatilList.size(); row++) {
					
					GnlTatilPrTx gnlTatilPrTx = (GnlTatilPrTx) newTatilList.get(row);

					oMap.put(newTableName, row, "KOD", gnlTatilPrTx.getId().getKod());
					oMap.put(newTableName, row, "TARIH", gnlTatilPrTx.getId().getTarih());
					oMap.put(newTableName, row, "ACIKLAMA", gnlTatilPrTx.getAciklama());
					oMap.put(newTableName, row, "DURUM", gnlTatilPrTx.getDurum());
					oMap.put(newTableName, row, "TARIH_TIP", gnlTatilPrTx.getTarihTip());
	
					
				}
				for (int row = 0; row < oldTatilList.size(); row++) {
					GnlTatilPrTx gnlTatilPrTx = (GnlTatilPrTx) oldTatilList.get(row);
					
					oMap.put(oldTableName, row, "KOD", gnlTatilPrTx.getId().getKod());
					oMap.put(oldTableName, row, "TARIH", gnlTatilPrTx.getId().getTarih());
					oMap.put(oldTableName, row, "ACIKLAMA", gnlTatilPrTx.getAciklama());
					oMap.put(oldTableName, row, "DURUM", gnlTatilPrTx.getDurum());
					oMap.put(oldTableName, row, "TARIH_TIP", gnlTatilPrTx.getTarihTip());
				
				}
				
				ArrayList<String> keys = new ArrayList<String>();
				 keys.add("KOD");
				 keys.add("TARIH");
				 
				oMap.put("TATIL_COLOR_DATA", BeanSetProperties.tableDifference(
						(ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName),keys).get("COLOR_DATA"));
				
				
	
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}*/
	}
