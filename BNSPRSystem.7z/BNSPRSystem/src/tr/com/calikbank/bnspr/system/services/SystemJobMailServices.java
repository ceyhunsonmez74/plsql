package tr.com.calikbank.bnspr.system.services;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlJsTanimPr;
import tr.com.calikbank.bnspr.quartz.BnsprConnection;
import tr.com.calikbank.bnspr.quartz.QuartzEnums.Schedulers;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemJobMailServices {
	
	private static final String PAUSE_JOB_MAIL_ENCODING = "UTF-8";
	
    private static final String confFile = "jobScheduler.properties";
	
	private static String getProperty(String property) {
		Configurator configurator = Configurator.createConfiguratorFromProperties(confFile);
		return configurator.getProperty(property);
	}
	
	private static GMConnection getSchedulerConnection(GMMap iMap){
		GMConnection gmConnection=null;
		try {
			int schedId=iMap.getInt("SCHED_ID");
			for (Schedulers scheduler : Schedulers.values()) {
				if(schedId==scheduler.getId()){
					gmConnection=GMConnection.getConnection(scheduler.getConnectionName());
				}
			}
		} catch (IOException e) {
			throw new GMRuntimeException(0, e);
		}
		return gmConnection;
	}
	
	@GraymoundService("BNSPR_SEND_EMAIL_PAUSED_JOB_LIST")
	public static GMMap sendPausedJobDetailMail(GMMap iMap){
		Map<Object,Object> oMap = new HashMap<Object, Object>();
		GMConnection gmCon = null;
		ArrayList<HashMap<String, String>> list = null;
		ArrayList<HashMap<String, String>> mailList = new ArrayList<HashMap<String,String>>();
		HashMap<String, String> map = null;
		StringBuilder mailSubject = new StringBuilder();
		StringWriter mailBody = new StringWriter();
		StringBuilder mailContent = new StringBuilder();
		try {
			gmCon = BnsprConnection.getConnection();
			oMap = (HashMap) gmCon.serviceCall("BNSPR_PAR9949_GET_ALL_JOB", iMap);	
			list = (ArrayList<HashMap<String, String>>) oMap.get("JOB_LIST");
				
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).get("STATUS")!= null && list.get(i).get("STATUS").equals("Paused")){

					map = new HashMap<String, String>();
					map.put("JOB_NAME",list.get(i).get("JOB_NAME"));
					
					HashMap<String, GMMap> serviceMap = (HashMap<String, GMMap>)((Object)list.get(i).get("SERVICE_MAP"));
					Object serviceMapValue = serviceMap.get("value").get("SERVICE_NAME");
					map.put("SERVICE_NAME", serviceMapValue != null ? serviceMapValue.toString() : "-");
					
					
					GMMap mapServiceInfo = GMServiceExecuter.call("BNSPR_TRN9997_GET_SERVICE_INFO", new GMMap()
					.put("SERVICE_NAME", serviceMapValue != null ? serviceMapValue.toString() : "-"));
					
					GMMap mapServiceOwnerInfo = loadServiceOwnerInfo(mapServiceInfo.put("SCHED_ID", iMap.getInt("SCHED_ID")));
					GMMap mapServiceTeamInfo = loadServiceOwnerTeamInfo(mapServiceOwnerInfo.put("SCHED_ID", iMap.getInt("SCHED_ID")));
					map.put("SERVICE_OWNER", mapServiceOwnerInfo.getString("NAME") != null ? mapServiceOwnerInfo.getString("NAME") : "-");
					map.put("SERVICE_TEAM", mapServiceTeamInfo.getString("TEAM_NAME") != null ? mapServiceTeamInfo.getString("TEAM_NAME") : "-");
					mailList.add(map);
				}
				
			}
			
			mailSubject.append("G�nl�k Job Durum Bildirim");
			mailContent.append("Stat�s� Paused durumda olan joblar�n�z a�a��daki gibi;");
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
			ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
			ve.init();
			VelocityContext context = new VelocityContext();
			context.put("mailContent", mailContent);
			context.put("serviceList", mailList);
			Template t = ve.getTemplate("jobPauseListMail.vm", PAUSE_JOB_MAIL_ENCODING);
			t.merge(context, mailBody);
			
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", getProperty("mail.from"));
			servisMap.put("MAIL_TO", getProperty("mail.to"));
			servisMap.put("MAIL_BCC", "");
			servisMap.put("MAIL_SUBJECT", mailSubject);
			servisMap.put("MAIL_BODY_CLOB", mailBody);
			servisMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_SEND_EMAIL_UNCLAIMED_JOB_LIST")
	public static GMMap sendUnclaimedJobDetailMail(GMMap iMap){
		Map<Object,Object> oMap = new HashMap<Object, Object>();
		GMConnection gmCon = null;
		ArrayList<HashMap<String, String>> list = null;
		ArrayList<HashMap<String, String>> mailList = new ArrayList<HashMap<String,String>>();
		HashMap<String, String> map = null;
		StringBuilder mailSubject = new StringBuilder();
		StringWriter mailBody = new StringWriter();
		StringBuilder mailContent = new StringBuilder();
		try {
			gmCon = BnsprConnection.getConnection();
			oMap = (HashMap) gmCon.serviceCall("BNSPR_PAR9949_GET_ALL_JOB", iMap);	
			list = (ArrayList<HashMap<String, String>>) oMap.get("JOB_LIST");
				
			for (int i = 0; i < list.size(); i++) {

					map = new HashMap<String, String>();
					
					HashMap<String, GMMap> serviceMap = (HashMap<String, GMMap>)((Object)list.get(i).get("SERVICE_MAP"));
					Object serviceMapValue = serviceMap != null && serviceMap.get("value")!=null ? serviceMap.get("value").get("SERVICE_NAME") : null;
					if(serviceMapValue!=null){
						GMMap mapServiceInfo = GMServiceExecuter.call("BNSPR_TRN9997_GET_SERVICE_INFO", new GMMap()
						.put("SERVICE_NAME", serviceMapValue != null ? serviceMapValue.toString() : "-"));
						GMMap mapServiceOwnerInfo = loadServiceOwnerInfo(mapServiceInfo.put("SCHED_ID", iMap.getInt("SCHED_ID")));
						if(mapServiceOwnerInfo.getString("NAME") == null){
							map.put("JOB_NAME",list.get(i).get("JOB_NAME"));
							map.put("SERVICE_NAME", serviceMapValue != null ? serviceMapValue.toString() : "-");
							mailList.add(map);
						}else{
							Object ownerId = list.get(i).get("OWNER_ID");
							if(ownerId == null){
								Session session = DAOSession.getSession("BNSPRDal");
								GnlJsTanimPr jobTanim =(GnlJsTanimPr) session.createCriteria(GnlJsTanimPr.class).
										add(Restrictions.eq("jobId", new BigDecimal(list.get(i).get("JOB_ID")))).uniqueResult();
								if(jobTanim != null){
									jobTanim.setJobOwnerId(new BigDecimal(mapServiceOwnerInfo.getString("ID")));
									session.saveOrUpdate(jobTanim);
									session.flush();
								}
							}
						}
						
					}
					if(list.get(i).get("JOB_TUR_KOD") !=null && !list.get(i).get("JOB_TUR_KOD").equals("300")){
						map.put("JOB_NAME",list.get(i).get("JOB_NAME"));
						map.put("SERVICE_NAME", serviceMapValue != null ? serviceMapValue.toString() : "-");
						mailList.add(map);
					}
			}
			
			mailSubject.append("Sahipsiz Job Durum Bildirim");
			mailContent.append("Sahibi olmayan joblar a�a��daki gibi;");
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
			ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
			ve.init();
			VelocityContext context = new VelocityContext();
			context.put("mailContent", mailContent);
			context.put("serviceList", mailList);
			Template t = ve.getTemplate("jobUnclaimedMail.vm", PAUSE_JOB_MAIL_ENCODING);
			t.merge(context, mailBody);
			
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", getProperty("mail.from"));
			servisMap.put("MAIL_TO", iMap.get("MAIL_TO"));
			servisMap.put("MAIL_BCC", "");
			servisMap.put("MAIL_SUBJECT", mailSubject);
			servisMap.put("MAIL_BODY_CLOB", mailBody);
			servisMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	
	
	@GraymoundService("BNSPR_SEND_PAUSED_NOTIFICATION_EMAIL")
	public static GMMap sendPausedNotificationMail(GMMap iMap){
		StringBuilder mailSubject = new StringBuilder();
		StringWriter mailBody = new StringWriter();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlJsTanimPr jobTanim=(GnlJsTanimPr) session.createCriteria(GnlJsTanimPr.class).
					add(Restrictions.eq("jobId", iMap.getBigDecimal("JOB_ID"))).uniqueResult();
			if(jobTanim!=null && jobTanim.getJobOwnerId()!=null){
				iMap.put("OWNER_ID", jobTanim.getJobOwnerId().toString());
		        GMMap servisOwnerInfoMap = loadServiceOwnerInfo(iMap);
		        GMMap inputMapOwnerTeam = new GMMap();
		        inputMapOwnerTeam.put("SCHED_ID", iMap.getInt("SCHED_ID"));
		        inputMapOwnerTeam.put("TEAM_ID", servisOwnerInfoMap.get("TEAM_ID"));
		        GMMap servisOwnerTeamInfoMap = loadServiceOwnerTeamInfo(inputMapOwnerTeam);
		        
		        VelocityEngine ve = new VelocityEngine();
				ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
				ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
				ve.init();
				VelocityContext context = new VelocityContext();
				StringBuilder mail = new StringBuilder();
				mail.append(iMap.getString("JOB_NAME")+ " job� durduruldu.");
				
				context.put("mailContent", mail);
				Template t = ve.getTemplate("jobPauseInfoMail.vm", PAUSE_JOB_MAIL_ENCODING);
				t.merge(context, mailBody);
		        
		        mailSubject.append("Job Durum Bildirim");
		        GMMap servisMap = new GMMap();
				servisMap.put("MAIL_FROM", getProperty("mail.from"));
				servisMap.put("MAIL_TO", servisOwnerInfoMap.get("OWNER_EMAIL"));
				servisMap.put("MAIL_BCC", "");
			    servisMap.put("MAIL_CC", servisOwnerTeamInfoMap.get("TEAM_EMAIL"));
			    servisMap.put("MAIL_SUBJECT", mailSubject);
				servisMap.put("MAIL_BODY", mail);
				servisMap.put("IS_BODY_HTML", "E");
				GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
		
	}

	
	public static GMMap loadServiceOwnerInfo(GMMap iMap) throws IOException {
		GMMap oMap = new GMMap(getSchedulerConnection(iMap).serviceCall("BNSPR_TRN9997_GET_OWNER_INFO", iMap));
		return oMap;
	}
	
	public static GMMap loadServiceOwnerTeamInfo(GMMap iMap) throws IOException {
		GMMap oMap = new GMMap(getSchedulerConnection(iMap).serviceCall("BNSPR_TRN9997_GET_OWNER_TEAM_INFO", iMap));
		return oMap;
	}
	
	@GraymoundService("BNSPR_SEND_BLOCKED_JOBS_NOTIFICATION_EMAIL")	
	public static GMMap sendBlockedJobNotificationMail(GMMap iMap){
		GMMap oMap=new GMMap();
		StringBuilder mailSubject = new StringBuilder();
		StringWriter mailBody = new StringWriter();
		StringBuilder mailContent = new StringBuilder();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<String> blockedJobNames = (List<String>)session.createSQLQuery("SELECT T.JOB_NAME FROM BNSPR.QRTZ_TRIGGERS T WHERE T.TRIGGER_STATE='BLOCKED' "
					+ "AND NOT EXISTS(SELECT F.JOB_NAME FROM BNSPR.QRTZ_FIRED_TRIGGERS F WHERE T.JOB_NAME=F.JOB_NAME)").list();
			
			if(blockedJobNames.size() == 0){
				return oMap;
			}
			
			ArrayList<HashMap<String, String>> mailList = new ArrayList<HashMap<String,String>>();
			for(String jobName:blockedJobNames) {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("JOB_NAME", jobName);
				map.put("SERVICE_OWNER", "-");
				map.put("SERVICE_TEAM", "-");
				
				GnlJsTanimPr jobTanim=(GnlJsTanimPr) session.createCriteria(GnlJsTanimPr.class).
						add(Restrictions.eq("jobAdi", jobName)).uniqueResult();
				
				if(jobTanim!=null && jobTanim.getJobOwnerId()!=null){
					GMMap inputMapServiceOwner = new GMMap();
					inputMapServiceOwner.put("OWNER_ID", jobTanim.getJobOwnerId().toString());
			        GMMap servisOwner = GMServiceExecuter.call("BNSPR_TRN9997_GET_OWNER_INFO", inputMapServiceOwner);
			        
			        if(servisOwner.containsKey("NAME")){
				        GMMap inputMapOwnerTeam = new GMMap();
				        inputMapOwnerTeam.put("TEAM_ID", servisOwner.get("TEAM_ID"));	
						GMMap servisOwnerTeam = GMServiceExecuter.call("BNSPR_TRN9997_GET_OWNER_TEAM_INFO", inputMapOwnerTeam);
						
						map.put("SERVICE_OWNER", servisOwner.getString("NAME") != null ? servisOwner.getString("NAME") : "-");
						map.put("SERVICE_TEAM", servisOwnerTeam.getString("TEAM_NAME") != null ? servisOwnerTeam.getString("TEAM_NAME") : "-");
				    }
				}
				mailList.add(map);
			}
			
			mailSubject.append("Blocked Job Durum Bildirim");
			mailContent.append("Blocked durumda olan joblar�n�z a�a��daki gibi;");
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
			ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
			ve.init();
			VelocityContext context = new VelocityContext();
			context.put("mailContent", mailContent);
			context.put("serviceList", mailList);
			Template t = ve.getTemplate("jobBlockedListMail.vm", PAUSE_JOB_MAIL_ENCODING);
			t.merge(context, mailBody);
			
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", getProperty("mail.from"));
			servisMap.put("MAIL_TO", getProperty("mail.to"));
			servisMap.put("MAIL_BCC", "");
			servisMap.put("MAIL_SUBJECT", mailSubject);
			servisMap.put("MAIL_BODY_CLOB", mailBody);
			servisMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0 ,e);
		}
	}
	
}
