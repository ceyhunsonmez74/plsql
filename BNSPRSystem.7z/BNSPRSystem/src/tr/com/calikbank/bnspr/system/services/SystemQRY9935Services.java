package tr.com.calikbank.bnspr.system.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9935Services {

	@GraymoundService("BNSPR_QRY9935_GET_INFO")
	public static GMMap qry9935GetInfo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			StringBuffer query = new StringBuffer();
			
			if (iMap.getString("KRITER").equals("KOD")) {
			    
			    query.append("SELECT");
	            query.append("  t.KOD,g.ACIKLAMA,t.KEY1,t.KEY2,t.KEY3,t.TEXT,t.SAYI,to_char(t.TARIH,'dd.mm.yyyy') TARIH,t.SIRA_NO SIRA ");
	            query.append("FROM");
	            query.append("  V_ML_GNL_PARAM_TEXT t, GNL_PARAM_TEXT_TANIM g ");
	            query.append("WHERE t.KOD = g.KOD ");
	            query.append("and t.KOD like '%' || ? || '%' ");
	            query.append("ORDER BY KOD,SIRA_NO");

			    
			}
			else if (iMap.getString("KRITER").equals("ACIKLAMA")) {
			    

                query.append("SELECT");
                query.append("  t.KOD,g.ACIKLAMA,t.KEY1,t.KEY2,t.KEY3,t.TEXT,t.SAYI,to_char(t.TARIH,'dd.mm.yyyy') TARIH,t.SIRA_NO ");
                query.append("FROM");
                query.append("  V_ML_GNL_PARAM_TEXT t, GNL_PARAM_TEXT_TANIM g ");
                query.append("WHERE t.KOD = g.KOD ");
                query.append("and g.ACIKLAMA like '%' || ? || '%' ");
                query.append("ORDER BY KOD,SIRA_NO");
			    
			}
			else if (iMap.getString("KRITER").equals("TEXT")) {
			    
			     query.append("SELECT");
	                query.append("  t.KOD,g.ACIKLAMA,t.KEY1,t.KEY2,t.KEY3,t.TEXT,t.SAYI,to_char(t.TARIH,'dd.mm.yyyy') TARIH,t.SIRA_NO ");
	                query.append("FROM");
	                query.append("  V_ML_GNL_PARAM_TEXT t, GNL_PARAM_TEXT_TANIM g ");
	                query.append("WHERE t.KOD = g.KOD ");
	                query.append("and t.TEXT like '%' || ? || '%' ");
	                query.append("ORDER BY KOD,SIRA_NO");
			
			}
			
			
			stmt = conn.prepareStatement(query.toString());
			
			stmt.setString(1, iMap.getString("ARANACAK"));

			rSet = stmt.executeQuery();
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int i = 1;
				oMap.put(tableName, row, "KOD", rSet.getString(i++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(i++));
				oMap.put(tableName, row, "KEY1", rSet.getString(i++));
				oMap.put(tableName, row, "KEY2", rSet.getString(i++));
				oMap.put(tableName, row, "KEY3", rSet.getString(i++));
				oMap.put(tableName, row, "TEXT", rSet.getString(i++));
				oMap.put(tableName, row, "SAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "TARIH", rSet.getString(i++));
				oMap.put(tableName, row, "SIRA", rSet.getBigDecimal(i++));
			}

			oMap.put("ROW_COUNT", iMap.getSize(tableName));

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}

	/*@GraymoundService("BNSPR_QRY9935_SEARCH")
	public static GMMap searchQRY9935(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();


			String aranacak = iMap.getString("ARANACAK");
			String aramaKriteri = iMap.getString("KRITER");
			String listTableName = "LIST";
			String paramTextTableName = "V_ML_GNL_PARAM_TEXT";
			int i = 0;
			for (int row = 0; row < iMap.getSize(paramTextTableName); row++) {
				if (iMap.getString(paramTextTableName, row, aramaKriteri).startsWith(aranacak)) {
					oMap.put(listTableName, i, "KOD", iMap.get(paramTextTableName, row, "KOD"));
					oMap.put(listTableName, i, "ACIKLAMA", iMap.get(paramTextTableName, row, "ACIKLAMA"));
					oMap.put(listTableName, i, "KEY1", iMap.get(paramTextTableName, row, "KEY1"));
					oMap.put(listTableName, i, "KEY2", iMap.get(paramTextTableName, row, "KEY2"));
					oMap.put(listTableName, i, "KEY3", iMap.get(paramTextTableName, row, "KEY3"));
					oMap.put(listTableName, i, "TEXT", iMap.get(paramTextTableName, row, "TEXT"));
					oMap.put(listTableName, i, "SAYI", iMap.get(paramTextTableName, row, "SAYI"));
					oMap.put(listTableName, i, "TARIH", iMap.get(paramTextTableName, row, "TARIH"));
					oMap.put(listTableName, i, "SIRA", iMap.get(paramTextTableName, row, "SIRA"));
					i++;
				}
			}

			oMap.put("ROW_COUNT", oMap.getSize(listTableName));
			return oMap;

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}*/

