package tr.com.calikbank.bnspr.system.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPrId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9930Services {
	@GraymoundService("BNSPR_PAR9930_GET_IL_TANIM")
	public static Map<?,?> getIlTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> ilList = (List<?>) session.createCriteria(GnlilKodPr.class).addOrder(Order.asc("kod")).list();
			String tableName = "IL_TANIM";
			int row = 0;
			for (Iterator<?> iterator = ilList.iterator(); iterator.hasNext();row++) {
				GnlilKodPr gnlilKodPr = (GnlilKodPr) iterator.next();
				oMap.put(tableName, row, "KOD", gnlilKodPr.getKod());
				oMap.put(tableName, row, "IL_ADI", gnlilKodPr.getIlAdi());
				oMap.put(tableName, row, "BAGLI_OLD_BOLGE_KOD", gnlilKodPr.getBolgeKod());
				oMap.put(tableName, row, "BAGLI_OLD_BOLGE_ADI", LovHelper.diLov(gnlilKodPr.getBolgeKod(), "9930P/LOV_BAGLI_OLD_BOLGE", "ADI"));
				oMap.put(tableName, row, "YENI", "0");
			}
			
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9930_GET_ILCE_TANIM")
	public static Map<?,?> getIlceTanim(GMMap iMap){
		GMMap oMap = new GMMap();
		Object o = GMContext.getCurrentContext().getSession().get("ILK_" + iMap.getString("IL_KOD"));
		if(o == null){
			try {
				ArrayList<HashMap<String, Object>> ilceOutList = new ArrayList<HashMap<String, Object>>();
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> ilceList = session.createCriteria(GnlilceKodPr.class).add(Restrictions.eq("id.gnlilKodPr.kod", iMap.getString("IL_KOD"))).addOrder(Order.asc("id.ilceKod")) .list();
				for (Iterator<?> iterator2 = ilceList.iterator(); iterator2.hasNext();) {
					GnlilceKodPr gnlilceKodPr = (GnlilceKodPr) iterator2.next();
					HashMap<String, Object> rowData = new HashMap<String, Object>();
					rowData.put("IL_KOD", gnlilceKodPr.getId().getGnlilKodPr().getKod());
					rowData.put("ILCE_KOD", gnlilceKodPr.getId().getIlceKod());
					rowData.put("ILCE_ADI", gnlilceKodPr.getIlceAdi());
					rowData.put("TCMB_ILCE_KOD", gnlilceKodPr.getTcmbIlceKod());
					ilceOutList.add(rowData);
				}
				oMap.put("ILCE_TANIM", ilceOutList);
			} catch (Exception e) {
				throw new GMRuntimeException(0, e);
			}
		}
		else{
			oMap.put("ILCE_TANIM", GMContext.getCurrentContext().getSession().get("ILK_" + iMap.getString("IL_KOD")));
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9930_PUT_ILCE_TANIM_TO_CONTEX")
	public static Map<?,?> getEmptyModulModel(GMMap iMap){
		GMContext.getCurrentContext().getSession().put("ILK_" + iMap.getString("IL_KOD"), iMap.get("ILCE_TANIM"));
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_PAR9930_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> ilKodlariGUIList = (List<?>) iMap.get("IL_TANIM");
			for (Iterator<?> iteratorModul = ilKodlariGUIList.iterator(); iteratorModul.hasNext();) {
				HashMap<?, ?> ilRowData = (HashMap<?, ?>) iteratorModul.next();
				if(GuimlUtil.isDublicateKey(ilKodlariGUIList, "KOD", ilRowData.get("KOD")))
					throw new GMRuntimeException(0, ilRowData.get("KOD") + " kodlu ba�ka bir il kayd� bulunmaktad�r'");
				GnlilKodPr gnlilKodPr = findIl((String)ilRowData.get("KOD"));
				if(gnlilKodPr == null)
					gnlilKodPr = new GnlilKodPr();
				
				gnlilKodPr.setKod((String)ilRowData.get("KOD"));
				gnlilKodPr.setIlAdi((String)ilRowData.get("IL_ADI"));
				gnlilKodPr.setBolgeKod((String)ilRowData.get("BAGLI_OLD_BOLGE_KOD"));
				session.saveOrUpdate(gnlilKodPr);
				session.flush();
				
				ArrayList<?> ilceGUIList = (ArrayList<?>) GMContext.getCurrentContext().getSession().get("ILK_" + (String)ilRowData.get("KOD"));
				if(ilceGUIList != null ){
					List<?> ilcePersistentList = session.createCriteria(GnlilceKodPr.class).add(Restrictions.eq("id.gnlilKodPr.kod", ilRowData.get("KOD"))).addOrder(Order.asc("id.ilceKod")).list();
					for (Iterator<?> iterator = ilcePersistentList.iterator(); iterator.hasNext();) {
						GnlilceKodPr gnlilceKodPr = (GnlilceKodPr) iterator.next();
						if(!GuimlUtil.contains(ilceGUIList, "ILCE_KOD", gnlilceKodPr.getId().getIlceKod()))
							session.delete(gnlilceKodPr);
					}
					
					for (Iterator<?> iteratorIlce = ilceGUIList.iterator(); iteratorIlce.hasNext();) {
						HashMap<?, ?> ilceRowData = (HashMap<?, ?>) iteratorIlce.next();
						Validator.checkNull(ilceRowData.get("ILCE_KOD"), "�l�e Kodu bo� olamaz!");
						GnlilceKodPr gnlilceKodPr = findIlce((String)ilRowData.get("KOD"), (String)ilceRowData.get("ILCE_KOD"));
						GnlilceKodPrId id = new GnlilceKodPrId();
						if(gnlilceKodPr == null){
							gnlilceKodPr = new GnlilceKodPr();
							id.setGnlilKodPr(gnlilKodPr);
							id.setIlceKod((String)ilceRowData.get("ILCE_KOD"));
							gnlilceKodPr.setId(id);
						}
						gnlilceKodPr.setIlceAdi((String)ilceRowData.get("ILCE_ADI"));
						gnlilceKodPr.setTcmbIlceKod((String)ilceRowData.get("TCMB_ILCE_KOD"));
						try{
							session.saveOrUpdate(gnlilceKodPr);	
						}
						catch (NonUniqueObjectException e) {
							throw new GMRuntimeException(0, "Ayn� kodlu birden fazla il�e bulunmaktad�r!");
						}
					}
					
					//cache'i sil
					GMContext.getCurrentContext().getSession().put("ILK_" + (String)ilRowData.get("KOD"), null);
				}
				session.saveOrUpdate(gnlilKodPr);
			}
			
			List<?> ilPersistentList = (List<?>) session.createCriteria(GnlilKodPr.class).addOrder(Order.asc("kod")).list();
			for (Iterator<?> iterator = ilPersistentList.iterator(); iterator.hasNext();) {
				GnlilKodPr gnlilKodPr = (GnlilKodPr) iterator.next();
				if(!GuimlUtil.contains(ilKodlariGUIList, "KOD", gnlilKodPr.getKod())){
					if(gnlilKodPr.getGnlilceKodPrs().size() > 0)
						throw new GMRuntimeException(0, gnlilKodPr.getKod() + " iline ba�l� il�e tan�mlar� bulunuyor. Bu ili silmek i�in �nce bu il�e kay�tlar� siliniz!");	
					session.delete(gnlilKodPr);
				}
			}

			session.flush();
			
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r!");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	public static GnlilKodPr findIl(String kod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlilKodPr)session.get(GnlilKodPr.class, kod);
	}
	
	public static GnlilceKodPr findIlce(String ilKod, String ilceKod){
		Session session = DAOSession.getSession("BNSPRDal");
		GnlilKodPr il = findIl(ilKod);
		return (GnlilceKodPr)session.get(GnlilceKodPr.class, new GnlilceKodPrId(il, ilceKod));
	}
}
