package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlErisimRolTx;
import tr.com.calikbank.bnspr.dao.GnlErisimRolTxId;
import tr.com.calikbank.bnspr.dao.GnlErisimTx;
import tr.com.calikbank.bnspr.dao.GnlErisimTxId;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.dao.GnlKullaniciTx;
import tr.com.calikbank.bnspr.dao.GnlRol;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.cs.aurora.rc.client.RC;
import tr.com.cs.aurora.rc.client.RCBag;
import tr.com.cs.aurora.rc.client.RCException;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
@SuppressWarnings("deprecation")
public class SystemTRN9909Services {
	
	public static SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
	
	@GraymoundService("BNSPR_TRN9909_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlKullaniciTx gnlKullaniciTx = (GnlKullaniciTx)session.get(GnlKullaniciTx.class, iMap.getBigDecimal("TRX_NO"));
			if(gnlKullaniciTx == null){
				gnlKullaniciTx = new GnlKullaniciTx();
				gnlKullaniciTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}

	        gnlKullaniciTx.setKodu(iMap.getString("KULLANICI_KODU"));
	        gnlKullaniciTx.setPersonelNumara(iMap.getBigDecimal("PERSONEL_NUMARA"));
	        gnlKullaniciTx.setAdi(iMap.getString("ADI"));
	        gnlKullaniciTx.setSoyadi(iMap.getString("SOYADI"));
	        gnlKullaniciTx.setCalisilanBolum(iMap.getString("CALISILAN_BOLUM"));
	        gnlKullaniciTx.setCalisilanSube(iMap.getString("CALISILAN_SUBE"));
	        gnlKullaniciTx.setGorevKodu(iMap.getString("GOREV_KODU"));
	        gnlKullaniciTx.setTur(iMap.getString("TUR"));
	        gnlKullaniciTx.setEmail(iMap.getString("EMAIL"));
	        gnlKullaniciTx.setKanalKod(iMap.getString("KANAL_KODU"));
	        gnlKullaniciTx.setKanalAltKod(iMap.getString("KANAL_ALT_KODU"));
	        
	        session.saveOrUpdate(gnlKullaniciTx);
	        session.flush();

	        List<?> erisimPersistenceList = session.createCriteria(GnlErisimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        for (Iterator<?> iterator = erisimPersistenceList.iterator(); iterator.hasNext();) {
				GnlErisimTx gnlErisimTx = (GnlErisimTx) iterator.next();
				session.delete(gnlErisimTx);
			}
	        
	        List<?> erisimRolPersistenceList = session.createCriteria(GnlErisimRolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        for (Iterator<?> iterator = erisimRolPersistenceList.iterator(); iterator.hasNext();) {
				GnlErisimRolTx gnlErisimRolTx = (GnlErisimRolTx) iterator.next();
				session.delete(gnlErisimRolTx);
			}
	        session.flush();
	        
	        String tableName = "CBS_ERISIM_ISLEM";
	        for (int row = 0; row < iMap.getSize(tableName); row++) {
	        	ArrayList<?> erisimRolGUIList = (ArrayList<?>) GMContext.getCurrentContext().getSession().get("ERR_" + iMap.getString("PAGE_ID") + iMap.getString(tableName, row, "SUBE_KODU"));
	        	if(erisimRolGUIList != null ){
			        for (int i=0; i < erisimRolGUIList.size(); i++) {
			        	GnlErisimRolTx gnlErisimRolTx = new GnlErisimRolTx();
						GnlErisimRolTxId gnlErisimRolTxId = new GnlErisimRolTxId();
						gnlErisimRolTxId.setTxNo				(iMap.getBigDecimal("TRX_NO"));
						gnlErisimRolTxId.setErisimKullaniciKodu	(iMap.getString("KULLANICI_KODU"));
						gnlErisimRolTxId.setRolNumara			(new GMMap((Map<?, ?>) erisimRolGUIList.get(i)).getBigDecimal("ROL_NUMARA"));
						gnlErisimRolTxId.setSubeKodu			(iMap.getString(tableName, row, "SUBE_KODU"));
						gnlErisimRolTx.setId(gnlErisimRolTxId);
                        gnlErisimRolTx.setBaslangicTarihi((new GMMap((Map<?, ?>) erisimRolGUIList.get(i)).getDate("BAS_TARIH")));
                        gnlErisimRolTx.setBitisTarihi((new GMMap((Map<?, ?>) erisimRolGUIList.get(i)).getDate("BIT_TARIH")));
                        checkRoleStatus(gnlErisimRolTxId.getRolNumara());
						
						session.save(gnlErisimRolTx);
						session.flush();
					}					
				}
	        	
	        	GnlErisimTx gnlErisimTx = new GnlErisimTx();
	        	GnlErisimTxId gnlErisimTxId = new GnlErisimTxId();
	        	
	        	gnlErisimTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        	gnlErisimTxId.setKullaniciKodu(iMap.getString("KULLANICI_KODU"));
	        	gnlErisimTxId.setSubeKodu(iMap.getString(tableName, row, ("SUBE_KODU")));
				
	        	gnlErisimTx.setId(gnlErisimTxId);
	        	gnlErisimTx.setBaslangicTarihi(iMap.getDate(tableName, row, "BASLANGIC_TARIHI"));
	        	gnlErisimTx.setBitisTarihi(iMap.getDate(tableName, row, "BITIS_TARIHI"));
	        	
	        	session.save(gnlErisimTx);
	        }
   
	        session.flush();
	        
			iMap.put("TRX_NAME", "9909");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN9909_GET_KULLANICI")
	public static Map<?, ?> getKullanici(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlKullaniciTx gnlKullaniciTx = (GnlKullaniciTx)session.get(GnlKullaniciTx.class, iMap.getBigDecimal("TRX_NO"));
			GMMap oMap = new GMMap();
			
			oMap.put("KULLANICI_KODU", gnlKullaniciTx.getKodu());
			oMap.put("PERSONEL_NUMARA", gnlKullaniciTx.getPersonelNumara());
			oMap.put("ADI", gnlKullaniciTx.getAdi());
			oMap.put("SOYADI", gnlKullaniciTx.getSoyadi());
			oMap.put("CALISILAN_BOLUM", gnlKullaniciTx.getCalisilanBolum());
			oMap.put("CALISILAN_SUBE", gnlKullaniciTx.getCalisilanSube());
			oMap.put("GOREV_KODU", gnlKullaniciTx.getGorevKodu());
			oMap.put("TUR", gnlKullaniciTx.getTur());
			oMap.put("EMAIL", gnlKullaniciTx.getEmail());
			oMap.put("KANAL_KODU", gnlKullaniciTx.getKanalKod());
			oMap.put("KANAL_ALT_KODU", gnlKullaniciTx.getKanalAltKod());

			
	        List<?> erisimPersistenceList = session.createCriteria(GnlErisimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        String tableName = "CBS_ERISIM_ISLEM";
	        int row = 0;
	        for (Iterator<?> iterator = erisimPersistenceList.iterator(); iterator.hasNext();row++) {
	        	GnlErisimTx gnlErisimTx = (GnlErisimTx) iterator.next();
	        	oMap.put(tableName, row, "SUBE_KODU", gnlErisimTx.getId().getSubeKodu());
	        	oMap.put(tableName, row, "SUBE_ADI", LovHelper.diLov(gnlErisimTx.getId().getSubeKodu(), "9909/LOV_SUBE", "ADI"));
	        	oMap.put(tableName, row, "KULLANICI_KODU", gnlErisimTx.getId().getKullaniciKodu());
	        	oMap.put(tableName, row, "BASLANGIC_TARIHI", gnlErisimTx.getBaslangicTarihi());
	        	oMap.put(tableName, row, "BITIS_TARIHI", gnlErisimTx.getBitisTarihi());
	        }
	        
	        List<?> erisimRolPersistenceList = session.createCriteria(GnlErisimRolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        tableName = "ERISIM_ROL_LIST";
	        String tempTable = "CBS_ERISIM_ROL_ISLEM";
	        String tempSubeKodu = null;
	        row = 0;
	        int tempRow2 = 0;
	        for (Iterator<?> iterator = erisimRolPersistenceList.iterator(); iterator.hasNext(); row++) {
	        	GnlErisimRolTx gnlErisimRolTx = (GnlErisimRolTx) iterator.next();
	        	
	        	GMMap contextMap = new GMMap();
	        	contextMap.put("PAGE_ID", iMap.getString("PAGE_ID"));
	        	contextMap.put("SUBE_KODU", gnlErisimRolTx.getId().getSubeKodu());
	        	
	        	if(row == 0){
	        		tempSubeKodu = gnlErisimRolTx.getId().getSubeKodu();
	        	}
	        	
	        	
	        	contextMap.putAll(GMServiceExecuter.execute("BNSPR_PAR9909_GET_ERISIM_ROL", contextMap));
	        	
	        	
	        	if(tempSubeKodu != null && tempSubeKodu.equals(gnlErisimRolTx.getId().getSubeKodu())){
	        		
	        		oMap.put(tempTable, tempRow2, "ROL_SUBE_KODU", gnlErisimRolTx.getId().getSubeKodu());
	        		oMap.put(tempTable, tempRow2, "KULLANICI_KODU", gnlErisimRolTx.getId().getErisimKullaniciKodu());
	        		oMap.put(tempTable, tempRow2, "ROL_NUMARA", gnlErisimRolTx.getId().getRolNumara());
	        		oMap.put(tempTable, tempRow2, "ROL_ADI", LovHelper.diLov(gnlErisimRolTx.getId().getRolNumara(), "9909/LOV_ROL", "TANIM"));
	        		tempRow2++;
	        		
	        	}
	        	
	        	if(contextMap.get("ERISIM_ROL_LIST")!= null){
	        		
	        		int tempRow =  contextMap.getSize("ERISIM_ROL_LIST");
	        		
	        		contextMap.put(tableName, tempRow, "ROL_SUBE_KODU", gnlErisimRolTx.getId().getSubeKodu());
	        		contextMap.put(tableName, tempRow, "KULLANICI_KODU", gnlErisimRolTx.getId().getErisimKullaniciKodu());
	        		contextMap.put(tableName, tempRow, "ROL_NUMARA", gnlErisimRolTx.getId().getRolNumara());
	        		contextMap.put(tableName, tempRow, "ROL_ADI", LovHelper.diLov(gnlErisimRolTx.getId().getRolNumara(), "9909/LOV_ROL", "TANIM"));
	        		
	        	}else{
	        		contextMap.put(tableName, 0, "ROL_SUBE_KODU", gnlErisimRolTx.getId().getSubeKodu());
	        		contextMap.put(tableName, 0, "KULLANICI_KODU", gnlErisimRolTx.getId().getErisimKullaniciKodu());
	        		contextMap.put(tableName, 0, "ROL_NUMARA", gnlErisimRolTx.getId().getRolNumara());
	        		contextMap.put(tableName, 0, "ROL_ADI", LovHelper.diLov(gnlErisimRolTx.getId().getRolNumara(), "9909/LOV_ROL", "TANIM"));
	        	}
	        	
	        	GMServiceExecuter.execute("BNSPR_PAR9909_PUT_ERISIM_ROL_TO_CONTEX", contextMap);
	        	contextMap.clear();
			}
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9909_GET_ERISIM_ROL")
	public static Map<?,?> getIlceTanim(GMMap iMap){
		GMMap oMap = new GMMap();
		Object o = GMContext.getCurrentContext().getSession().get("ERR_" + iMap.getString("PAGE_ID") + iMap.getString("SUBE_KODU"));
		if(o != null){
			oMap.put("ERISIM_ROL_LIST", o);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9909_PUT_ERISIM_ROL_TO_CONTEX")
	public static Map<?,?> getEmptyModulModel(GMMap iMap){
		GMContext.getCurrentContext().getSession().put("ERR_" + iMap.getString("PAGE_ID") + iMap.getString("SUBE_KODU"), iMap.get("ERISIM_ROL_LIST"));
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_PAR9909_GET_NEW_PAGE_ID")
	public static Map<?,?> getNewPageID(GMMap iMap){
		GMMap oMap = new GMMap();
		oMap.put("PAGE_ID", System.currentTimeMillis() + "");
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9909_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		JGMPasswordField passwordField = new JGMPasswordField();

		try{
			//Integer pass = (new Random().nextInt(90000000)+10000000);
			GMMap map = new GMMap();
			String tableName = "CHARACTER_SETS";
			map.put("PASSWORD_LENGTH", 8);
			map.put(tableName, 0, "CHARACTER_SET", UtilServices.ALL_DIGITS);
			map.put(tableName, 0, "MIN_COUNT", 3);
			map.put(tableName, 1, "CHARACTER_SET", UtilServices.ALL_LETTERS);
			map.put(tableName, 1, "MIN_COUNT", 2);
			String pass = GMServiceExecuter.call("BNSPR_COMMON_GENERATE_PSWD", map).getString("PASSWORD"); 
			passwordField.setText(pass);
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(GnlKullaniciTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			boolean isCallCenterUser = false;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlKullaniciTx gnlKullaniciTx = (GnlKullaniciTx) iterator.next();
				
				if(gnlKullaniciTx.getKanalKod().equals("5")){
					isCallCenterUser = true;
				}
				
				iMap.put("KULLANICI_KOD", gnlKullaniciTx.getKodu());
				iMap.put("YENI_SIFRE_HASHED",   new String(passwordField.getPassword()));
				iMap.put("YENI_SIFRE_TEKRAR_HASHED",   new String(passwordField.getPassword()));
				iMap.put("YENI_SIFRE",   pass);
				iMap.put("YENI_SIFRE_TEKRAR",   pass);
				iMap.put("YENI_SIFRE_TEKRAR",   pass);
				iMap.put("DURUM",   "I");
				GMServiceExecuter.call("BNSPR_CORE_SIFRE_DEGISTIR", iMap);	
			
				iMap.put("GIVEN_NAME", gnlKullaniciTx.getAdi());
				iMap.put("SN", gnlKullaniciTx.getSoyadi());
				iMap.put("CN", gnlKullaniciTx.getAdi() +" "+gnlKullaniciTx.getSoyadi());
				iMap.put("UID", gnlKullaniciTx.getKodu());
				iMap.put("MAIL", gnlKullaniciTx.getEmail());
				iMap.put("PASSWORD", pass);
				iMap.put("AKUSTIK_ACCOUNT_CLOSE_DATE", "1970-01-01");
				GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_BNSPR", iMap);// LDAP_BNSPR				
	            
			}	
			
			if(isCallCenterUser){
				GMMap addToVbRequest = new GMMap();
				addToVbRequest.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
				
				GMServiceExecuter.executeNT("NGCC_ADD_CREATE_VB_AGENT_TASK_TO_SAF", addToVbRequest);
			}
			
		}
		catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}	
	
	@GraymoundService("BNSPR_TRN9909_AFTER_APPROVAL_CS")
	public static GMMap afterApprovalCs(GMMap iMap) {
		try{
			RCBag bag1 = (RCBag)iMap.get("CS_BAG1");
			RCBag bag2 = (RCBag)iMap.get("CS_BAG2");
			RC.execute(bag1, "configuration/RemoteCaller.properties"); 
			RC.execute(bag2, "configuration/RemoteCaller.properties"); 
		}
		catch (RCException e) {
			//throw ExceptionHandler.convertException(e);
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally{
		}
		return new GMMap();
	}	

	
	@GraymoundService("BNSPR_COMMON_CHANEL_INTEGRATIONID")
	public static String getIntegrationId(String kanalKod) {
	    Session session = DAOSession.getSession("BNSPRDal");
		GnlKanalGrupKodPr gnlKanalGrupKodPr = (GnlKanalGrupKodPr) session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", kanalKod)).uniqueResult();
		return gnlKanalGrupKodPr.getIntegrationId();
	}

	@GraymoundService("BNSPR_CORE_ADMIN_SIFRE_DEGISTIR")
	public static GMMap adminSifreDegistir(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		JGMPasswordField passwordField = new JGMPasswordField();
		try{
			//Integer pass = (new Random().nextInt(90000000)+10000000);
			GMMap map = new GMMap();
			String tableName = "CHARACTER_SETS";
			map.put("PASSWORD_LENGTH", 8);
			map.put(tableName, 0, "CHARACTER_SET", UtilServices.ALL_DIGITS);
			map.put(tableName, 0, "MIN_COUNT", 3);
			map.put(tableName, 1, "CHARACTER_SET", UtilServices.ALL_LETTERS);
			map.put(tableName, 1, "MIN_COUNT", 2);
			String pass = GMServiceExecuter.call("BNSPR_COMMON_GENERATE_PSWD", map).getString("PASSWORD"); 
			passwordField.setText(pass);
			
			iMap.put("KULLANICI_KOD", iMap.getString("KULLANICI_KOD"));
			iMap.put("YENI_SIFRE_HASHED",   new String(passwordField.getPassword()));
			iMap.put("YENI_SIFRE_TEKRAR_HASHED",   new String(passwordField.getPassword()));
			iMap.put("YENI_SIFRE",   pass);
			iMap.put("YENI_SIFRE_TEKRAR",   pass);
			iMap.put("YENI_SIFRE_TEKRAR",   pass);
			iMap.put("DURUM",   "I");
			GMServiceExecuter.call("BNSPR_CORE_SIFRE_DEGISTIR", iMap);	
			//oMap.put("MESSAGE", "��leminiz tamamlanm��t�r.");
	        conn = DALUtil.getGMConnection();
	        
	        stmt = conn.prepareCall("{?=call PKG_TRN9909.infomesaj(?,?) }");
	        stmt.registerOutParameter(1,Types.VARCHAR);
	        stmt.setString(2, iMap.getString("KULLANICI_KOD"));
	        stmt.setString(3, iMap.getString("SIFRE_UNUTMA"));
	        
	        stmt.execute();
	        
	        oMap.put("MESSAGE",stmt.getString(1));

		return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	@GraymoundService("BNSPR_TRN909_KAYIT_KONTROL")
    public static Map<?, ?> getKayitKontrol (GMMap iMap){
    Connection conn         = null;
    CallableStatement stmt  = null;
    ResultSet rSet          = null;
    try {
        GMMap oMap = new GMMap();
        conn = DALUtil.getGMConnection();
        
        stmt = conn.prepareCall("{?=call PKG_TRN9909.KAYIT_KONTROL(?) }");
        stmt.registerOutParameter(1,Types.VARCHAR);
        stmt.setString(2, iMap.getString("KOD"));
        
        stmt.execute();
        
        oMap.put("KAYIT_VAR_MI", stmt.getString(1));
        
        return oMap;  
        
    }     
    
     catch (Exception e) {
        throw ExceptionHandler.convertException(e);
    } finally {
        GMServerDatasource.close(rSet);
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
    }
}

	public static Date setDateToStartOfDayDate(Date date) {
		String formatDate = null;
		Date formatedDate = null;
		try {

			if (date != null) {
				formatDate = formatter.format(date);
				if (formatDate != null)
					formatedDate = formatter.parse(formatDate);
				else
					formatedDate=date;
			}

			return formatedDate;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	public static Date getDateOfBank() {
	    GMMap iMap = new GMMap();
	    GMMap oMap = new GMMap();
	    Date dateOfBank;
		try {

			oMap = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap);
			 dateOfBank = oMap.getDate("BANKA_TARIH");

			return dateOfBank;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	public static void checkRoleStatus(BigDecimal roleNumber) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date dateOfBank = setDateToStartOfDayDate(getDateOfBank());
			
			List<GnlRol> roleList = (List<GnlRol>) session.createCriteria(GnlRol.class).add(Restrictions.eq("numara", roleNumber)).list();

			if (roleList.size() > 0) {
					GnlRol gnlRol = roleList.get(0);
					
					Date expireDate =  setDateToStartOfDayDate(gnlRol.getBitisTarihi());
					
					if ((expireDate != null) && (dateOfBank != null)) {
						if (!expireDate.after(dateOfBank)) {
							BigDecimal errCode = new BigDecimal(5640);
							   throw new GMRuntimeException(errCode.intValue(), getErrorText(errCode,roleNumber));
						}
					}
				
					
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}


	public static String getErrorText(BigDecimal errorCode,BigDecimal parameter) {
		GMMap errorIMap = new GMMap();
		String errorDescription = parameter.toString();

		errorIMap.put("MESSAGE_NO", errorCode);
		errorDescription =errorDescription.concat(GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", errorIMap).getString("ERROR_MESSAGE"));

		return errorDescription;

	}
		
}
