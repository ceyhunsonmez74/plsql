package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.VMlGnlMesajTextPr;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR5300Services {

@GraymoundService("BNSPR_PAR5300_MESAJ_TEXT")
public static GMMap getMesajText(GMMap iMap)throws ParseException{
	Connection conn = null;
	CallableStatement stmt = null;
	GMMap oMap = new GMMap();
	ResultSet rSet = null;
	
	try{
		conn = DALUtil.getGMConnection();

		stmt = conn.prepareCall("{? = call  pkg_rc5300.rc_qry5300_mesaj_text(?)}");
		int i = 1;	
		stmt.registerOutParameter(i++, -10); //ref cursor
		stmt.setString(i++, iMap.getString("KOD"));
		stmt.execute();
		rSet = (ResultSet)stmt.getObject(1);
		oMap.putAll(DALUtil.rSetResults(rSet, "MESAJ_TEXT"));
		for (int row = 0;row < oMap.getSize("MESAJ_TEXT");row++) {
		oMap.put("MESAJ_TEXT", row, "DURUM", "E");
		}
		

		return oMap;
	}catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} finally {
		GMServerDatasource.close(conn);
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(rSet);
	}
}
public static String translate(String value){
 char[] vchar = new char[value.length()];
	for (int i  = 0; i< value.length();i++){
	 char ch = value.charAt(i);
		  if (ch  == '�'){
		  vchar[i] = 'S';
		  }else if (ch  == '�'){
			  vchar[i] = 'G';
		  }else if (ch  == '�'){
			  vchar[i] = 'C';
		  }else if (ch  == '�'){
			  vchar[i] = 'I';
		  }else if (ch  == '�'){
			  vchar[i] = 'U';
		  }else if (ch == '�'){
			  vchar[i] = 'O';
		 }else vchar[i] = ch;
   }
	return new String (vchar);	
}

@GraymoundService("SAVE_PAR5300_MESAJ_TEXT")
public static Map<?, ?> save(GMMap iMap) {
	try {
		Session session = DAOSession.getSession("BNSPRDal");
	    String tableName = "MESAJ_TEXT";
		
		List<?> list = (List<?>) iMap.get(tableName);
		for(int i=0; i<list.size();i++) {
			//if(iMap.getString(tableName, i, "ID")==null)continue;
			VMlGnlMesajTextPr vmlGnlMesajTextPr = (VMlGnlMesajTextPr) session.get(VMlGnlMesajTextPr.class, iMap.getBigDecimal(tableName, i,"ID"));
			if (vmlGnlMesajTextPr == null){
				vmlGnlMesajTextPr = new VMlGnlMesajTextPr();
				vmlGnlMesajTextPr.setId(iMap.getBigDecimal(tableName, i, "ID"));
			}
		    vmlGnlMesajTextPr.setKanalKod(iMap.getString(tableName, i,"KANAL_KOD"));
		    String key = translate(iMap.getString(tableName, i,"KEY"));
		    String kod = translate(iMap.getString(tableName, i,"KOD"));
		    vmlGnlMesajTextPr.setKey(key);
		    vmlGnlMesajTextPr.setKod(kod);
		    vmlGnlMesajTextPr.setText(iMap.getString(tableName, i,"TEXT"));
			session.saveOrUpdate(vmlGnlMesajTextPr);
			session.flush();
		}
		return new GMMap();
		}catch (ConstraintViolationException e) {
		throw new GMRuntimeException(0,e.getCause().getMessage());
	} catch (Exception e) {
		 throw new GMRuntimeException(0,e);	
	}
}
@GraymoundService("DELETE_PAR5300_MESAJ_TEXT")
public static Map<?, ?> delete(GMMap iMap) {
	try {
		Session session = DAOSession.getSession("BNSPRDal");
    	VMlGnlMesajTextPr vmlGnlMesajTextPr = (VMlGnlMesajTextPr) session.get(VMlGnlMesajTextPr.class, iMap.getBigDecimal("ID"));
		session.delete(vmlGnlMesajTextPr);
		session.flush();
		return new GMMap();
		}catch (ConstraintViolationException e) {
		throw new GMRuntimeException(0,e.getCause().getMessage());
	} catch (Exception e) {
		 throw new GMRuntimeException(0,e);	
	}
}
	
}
