package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.MuhislemBilgilendirmePr;
import tr.com.aktifbank.bnspr.dao.MuhislemBilgilendirmePrId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9965Services {
	
	@GraymoundService("BNSPR_PAR9965_GET_RECORDS")
	public static Map<?,?> getRecords(GMMap iMap){
		try{
			GMMap 	oMap 		= new GMMap();
			Session session 	= DAOSession.getSession("BNSPRDal");
			List<?> list 		= (List<?>) session.createCriteria(MuhislemBilgilendirmePr.class).list();
			
			String 	tableName 	= "ISLEM_BILGILENDIRME";
			int 	row 		= 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				MuhislemBilgilendirmePr muhislemBilgilendirmePr = (MuhislemBilgilendirmePr) iterator.next();
				oMap.put(tableName, row, "KOD"			, muhislemBilgilendirmePr.getId().getKod());
				oMap.put(tableName, row, "ISLEM_KODU"	, muhislemBilgilendirmePr.getId().getIslemKodu());
				oMap.put(tableName, row, "MAIL_TO"		, muhislemBilgilendirmePr.getMailTo());
				oMap.put(tableName, row, "MAIL_CC"		, muhislemBilgilendirmePr.getMailCc());
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9965_SAVE")
	public static Map<?,?> saveLimitTanim(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listLimit = (List<?>) session.createCriteria(MuhislemBilgilendirmePr.class).list();
			for (Iterator<?> iterator = listLimit.iterator(); iterator.hasNext();) {
				MuhislemBilgilendirmePr deletedRecord = (MuhislemBilgilendirmePr) iterator.next();
				if(!findKey(iMap, deletedRecord.getId())){
					session.delete(deletedRecord);
				}
			}
			session.flush();

			String tableName = "ISLEM_BILGILENDIRME";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				MuhislemBilgilendirmePrId id = new MuhislemBilgilendirmePrId();
				id.setIslemKodu(iMap.getString(tableName, row, "ISLEM_KODU"));
				id.setKod(iMap.getBigDecimal(tableName, row, "KOD"));
				
				MuhislemBilgilendirmePr muhIslemBilgilendirmePr = (MuhislemBilgilendirmePr)session.
															get(MuhislemBilgilendirmePr.class, id);
				if(muhIslemBilgilendirmePr == null){
					muhIslemBilgilendirmePr = new MuhislemBilgilendirmePr(id);
				}
				muhIslemBilgilendirmePr.setMailCc(iMap.getString(tableName, row, "MAIL_CC"));
				muhIslemBilgilendirmePr.setMailTo(iMap.getString(tableName, row, "MAIL_TO"));
				session.saveOrUpdate(muhIslemBilgilendirmePr);
			}
			
			session.flush();
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE", "��leminiz tamamland�!");
			return messageMap;
		}
		catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(1550));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
		catch (NonUniqueObjectException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static boolean findKey(GMMap iMap, Object key){
		String tableName = "ISLEM_BILGILENDIRME";
		for (int row = 0; row < iMap.getSize(tableName); row++) {
			MuhislemBilgilendirmePrId id = new MuhislemBilgilendirmePrId();
			id.setIslemKodu(iMap.getString(tableName, row, "ISLEM_KODU"));
			id.setKod(iMap.getBigDecimal(tableName, row, "KOD"));
			
			if(id.equals(key)){
				return true;
			}
		}
		return false;
	}
	
}
