package tr.com.calikbank.bnspr.system.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.VMlGnlModulKodPr;
import tr.com.aktifbank.bnspr.dao.VMlGnlModulUrunKodPr;
import tr.com.aktifbank.bnspr.dao.VMlGnlModulUrunKodPrId;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9925Services {
	@GraymoundService("BNSPR_PAR9925_GET_MODUL_TUR_KOD")
	public static Map<?,?> getModulTurKodTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> modulTurKod = (List<?>) session.createCriteria(VMlGnlModulKodPr.class).list();
			String tableName = "MODUL_TANIM";
			int row = 0;
			for (Iterator<?> iterator = modulTurKod.iterator(); iterator.hasNext(); row++) {
				VMlGnlModulKodPr gnlModulKodPr = (VMlGnlModulKodPr) iterator.next();
				oMap.put(tableName, row, "KOD", gnlModulKodPr.getKod());
				oMap.put(tableName, row, "ACIKLAMA", gnlModulKodPr.getAciklama());
				oMap.put(tableName, row, "SIRA_NO", gnlModulKodPr.getSiraNo());
				oMap.put(tableName, row, "MUSTERI_URUNU", GuimlUtil.convertToCheckBoxDisplayValue(gnlModulKodPr.getMusteriUrunu()));
			}
			
			return oMap;
		}catch(Exception e){
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9925_GET_URUN_TANIM")
	public static Map<?,?> getUrunTanim(GMMap iMap){
		GMMap oMap = new GMMap();
		String tableName = "URUN_TANIM";
		Object o = GMContext.getCurrentContext().getSession().get("MK_" + iMap.getString("MODUL_KOD"));
		if(o == null){
			try {
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> modulTurKodList = (List<?>) session.createCriteria(VMlGnlModulUrunKodPr.class).add(Restrictions.eq("id.modulTurKod", iMap.getString("MODUL_KOD"))).list();
				
				int row = 0;
				for (Iterator<?> iterator2 = modulTurKodList.iterator(); iterator2.hasNext(); row++) {
					VMlGnlModulUrunKodPr gnlModulUrunKodPr = (VMlGnlModulUrunKodPr) iterator2.next();
					oMap.put(tableName, row, "KOD", gnlModulUrunKodPr.getId().getKod());
					oMap.put(tableName, row, "ACIKLAMA", gnlModulUrunKodPr.getAciklama());
					oMap.put(tableName, row, "MUSTERI_URUNU", GuimlUtil.convertToCheckBoxDisplayValue(gnlModulUrunKodPr.getMusteriUrunu()));
					oMap.put(tableName, row, "VADE_TIPI", gnlModulUrunKodPr.getVadeTipi());
				}
			} catch (Exception e) {
				throw new GMRuntimeException(0, e);
			}
		}
		else{
			oMap.put(tableName, GMContext.getCurrentContext().getSession().get("MK_" + iMap.getString("MODUL_KOD")));
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9925_PUT_MODUL_TUR_KOD_TO_CONTEX")
	public static Map<?,?> getEmptyModulModel(GMMap iMap){
		GMContext.getCurrentContext().getSession().put("MK_" + iMap.getString("MODUL_KOD"), iMap.get("URUN_TANIM"));
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_PAR9925_GET_COMBO_E_H")
	public static GMMap getComboLimit(GMMap iMap){
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL2", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BEKLEYEN_ISLEM_KONTROL");
		oMap.put("BEKLEYEN_ISLEM_KONTROL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		GuimlUtil.wrapMyCombo(oMap, "VADE_TIPI", 0, "K", "KISA VADELI");
		GuimlUtil.wrapMyCombo(oMap, "VADE_TIPI", 1, "U", "UZUN VADELI");
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9925_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String delUrunTableName = "DEL_URUN_LIST";
			for (int row = 0; row < iMap.getSize(delUrunTableName); row++) {
				VMlGnlModulUrunKodPr delUrun = findUrun(iMap.getString(delUrunTableName, row, "KEYP"), iMap.getString(delUrunTableName, row, "KEY"));
				if(delUrun != null && delUrun.getGnlModulUrunSinifKodPrs().size() > 0)
					throw new GMRuntimeException(0, delUrun.getId().getKod() + " �r�n�ne ba�l� s�n�f tan�mlaro� bulunuyor. Bu �r�n� silmek i�in �nce bu kay�tlar� siliniz!");
				if(delUrun != null)
					session.delete(delUrun);
			}
			session.flush();

			String modulTanimTableName = "MODUL_TANIM";
			for (int row = 0; row < iMap.getSize(modulTanimTableName); row++) {
				VMlGnlModulKodPr gnlModulKodPr = findModul(iMap.getString(modulTanimTableName, row, "KOD"));
				if(gnlModulKodPr == null)
					gnlModulKodPr = new VMlGnlModulKodPr();
				gnlModulKodPr.setKod(iMap.getString(modulTanimTableName, row, "KOD"));
				gnlModulKodPr.setAciklama(iMap.getString(modulTanimTableName, row, "ACIKLAMA"));
				gnlModulKodPr.setSiraNo(iMap.getBigDecimal(modulTanimTableName, row, "SIRA_NO"));
				gnlModulKodPr.setMusteriUrunu(GuimlUtil.convertFromCheckBoxDisplay(iMap.getString(modulTanimTableName, row, "MUSTERI_URUNU")));
				
				ArrayList<?> urunInList = (ArrayList<?>) GMContext.getCurrentContext().getSession().get("MK_" + iMap.getString(modulTanimTableName, row, "KOD"));
				Object o = GMContext.getCurrentContext().getSession().get("MK_" + iMap.getString(modulTanimTableName, row, "KOD"));
				
				session.saveOrUpdate(gnlModulKodPr);
				session.flush();
				if(o != null ){
					for (Iterator<?> iteratorUrun = urunInList.iterator(); iteratorUrun.hasNext();) {
						HashMap<?, ?> urunRowData = (HashMap<?, ?>) iteratorUrun.next();
						VMlGnlModulUrunKodPr gnlModulUrunKodPr = findUrun(iMap.getString(modulTanimTableName, row, "KOD"), (String)urunRowData.get("KOD"));
						VMlGnlModulUrunKodPrId id = new VMlGnlModulUrunKodPrId();
						if(gnlModulUrunKodPr == null){
							gnlModulUrunKodPr = new VMlGnlModulUrunKodPr();
							id.setKod((String)urunRowData.get("KOD"));
							id.setModulTurKod(iMap.getString(modulTanimTableName, row, "KOD"));
							gnlModulUrunKodPr.setId(id);
						}
						gnlModulUrunKodPr.setAciklama((String)urunRowData.get("ACIKLAMA"));
						gnlModulUrunKodPr.setMusteriUrunu((GuimlUtil.convertFromCheckBoxDisplay((String)urunRowData.get("MUSTERI_URUNU"))));
						gnlModulUrunKodPr.setVadeTipi((String)urunRowData.get("VADE_TIPI"));
						session.saveOrUpdate(gnlModulUrunKodPr);
					}
					session.flush();
				}
			}


			String delModulTableName = "DEL_MODUL_LIST";
			for (int row = 0; row < iMap.getSize(delModulTableName); row++) {
				VMlGnlModulKodPr modulDel = findModul(iMap.getString(delModulTableName, row, "KEY"));
				if(session.createCriteria(VMlGnlModulUrunKodPr.class).add(Restrictions.eq("id.modulTurKod", iMap.getString(delModulTableName, row, "KEY"))).list().size() > 0)
					throw new GMRuntimeException(0, modulDel.getKod() + " mod�l�ne ba�l� �r�n tan�mlar� bulunuyor. Bu mod�l� silmek i�in �nce bu kay�tlar� siliniz!");
				if(modulDel != null)
					session.delete(modulDel);
			}
			session.flush();
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", "i�leminiz Tamamlanm��t�r!");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	public static VMlGnlModulKodPr findModul(String key){
		Session session = DAOSession.getSession("BNSPRDal");
		return (VMlGnlModulKodPr)session.get(VMlGnlModulKodPr.class, key);
	}
	
	public static VMlGnlModulUrunKodPr findUrun(String modulKod, String urunKod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (VMlGnlModulUrunKodPr)session.get(VMlGnlModulUrunKodPr.class, new VMlGnlModulUrunKodPrId(modulKod, urunKod));
	}
}
