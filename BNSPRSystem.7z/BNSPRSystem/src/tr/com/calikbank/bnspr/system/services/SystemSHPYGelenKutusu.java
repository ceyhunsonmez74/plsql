package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlIslemServisPr;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * @author obss1
 * 
 */
public class SystemSHPYGelenKutusu {

	private static final Logger logger = Logger.getLogger(SystemPFTGelenKutusu.class);
	
	@GraymoundService("BNSPR_SHPY_GELEN_KUTUSU_GET_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_MESAJKUTUSU_GELEN_SHPY}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor,
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "REFERANS", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TARIHI", rSet.getDate(j++));
				oMap.put(tableName, row, "BORC_HESAP_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "BORC_MUSTERI_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ALICI_HESAP_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ALICI_MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ALICI_MUSTERI_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DOVIZ_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR", rSet.getString(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	/*
	 * (BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA)Servisinde i�lemin
	 * do�rulanmas�, onaylanmas�, iptali ve iptal onaylanmas� yap�lmaktad�r. �ki
	 * parametresi vard�r.Ald��� parametreler i�lem numaras� ve statik bir
	 * texttir. Statik text => 'D' = Do�rulama, 'O' = Onaylama, 'I' = �ptal,
	 * 'IO' = �ptal Onay i�indir.
	 */

	@GraymoundService("BNSPR_SHPY_GELEN_KUTUSU_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA")
	public static GMMap islemDogrulaOnayIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String islemTuru = iMap.getString("ISLEM_TURU");
		List<?> list = (List<?>)iMap.get("ISLEM_LIST");
		try {
			conn = DALUtil.getGMConnection();
			for(int i = 0; i<list.size(); i++)
			{
				if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
				{
					if ("D".equals(islemTuru)) {
						stmt = conn.prepareCall("{call PKG_TX.DOGRULA_ISLEM_YURUT(?,true,?)}");
					} else if ("O".equals(islemTuru)) {
						stmt = conn.prepareCall("{call PKG_TX.ONAYLA_ISLEM_YURUT(?,true,?)}");
					} else if ("I".equals(islemTuru)) {
						stmt = conn.prepareCall("{call pkg_tx.iptal_islem_yurut(?,?)}");
					} else if ("IO".equals(islemTuru)) {
						stmt = conn.prepareCall("{call pkg_tx.iptal_onay(?,true,?)}");
					} else if ("DR".equals(islemTuru)) {
						stmt = conn.prepareCall("{call PKG_TX.DOGRULA(?,false,?)}");
					} else if ("OR".equals(islemTuru)) {
						stmt = conn.prepareCall("{call PKG_TX.ONAY(?,false,?)}");
					} else if ("IOR".equals(islemTuru)) {
						stmt = conn.prepareCall("{call pkg_tx.iptal_onay(?,false,?)}");
					} else if ("IG".equals(islemTuru)) {
						stmt = conn.prepareCall("{call pkg_tx.islem_geri_gonder(?,?)}");
					} 
					
					stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
					stmt.setString(2, iMap.getString("ACIKLAMA"));
		
					stmt.execute();
		
					//e�er varsa i�lem sonras� servisi �a��r�r
					iMap.put("ISLEM_KODU", iMap.getBigDecimal("ISLEM_LIST",i,"KOD"));
					executePostService(iMap);
					iMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
					//GMServiceExecuter.execute("BNSPR_ISLEM_EXECUTE_POST_SERVICE", iMap);
					//oMap = getMessage(iMap);
					oMap.put("MESSAGE", "��leminiz Ba�ar�yla Tamamlanm��t�r.");
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			if(iMap.getString("ANA_SUBE")!= null && !iMap.getString("ANA_SUBE").isEmpty())
			{
				GMMap tempMap = new GMMap();
				tempMap.put("BRANCH_ID", iMap.getString("ANA_SUBE"));
				tempMap.put("GUIML_NAME", iMap.getString("GUIML_NAME"));
				GMServiceExecuter.execute("BNSPR_CORE_SET_USER_BRANCH", tempMap);
			}
		}
		return oMap;
	}
	
	public static GMMap executePostService(GMMap iMap){
		String postServiceName = null;
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = session.createCriteria(GnlIslemServisPr.class).add(Restrictions.eq("id.islemKodu", iMap.getBigDecimal("ISLEM_KODU"))).add(Restrictions.eq("id.islemTuru", iMap.getString("ISLEM_TURU"))).list();
		if(list.size()>0)
			postServiceName = ((GnlIslemServisPr)list.get(0)).getServisAdi();
		if(postServiceName!=null){
			if(logger.isDebugEnabled())
				logger.debug("��lemin onay sonras� servisi var:" + postServiceName);
			GMServiceExecuter.execute(postServiceName, iMap);
			if(logger.isDebugEnabled())
				logger.debug("��lemin onay sonras� servisi " + postServiceName + " �a�r�ld�");
		}
		else{
			logger.debug("��lemin onay sonras� servisi yok");			
		}
		return new GMMap();
	}

	public static GMMap getMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tx.msj_islem_durum(?)}");
			stmt.registerOutParameter(1, Types.CHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));

			stmt.execute();

			oMap.put("MESSAGE", stmt.getString(1));

		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
		

	@GraymoundService("BNSPR_SHPY_GELEN_KUTUSU_TUMUNU_SEC")
	public static GMMap tumunuSec(GMMap iMap){
		
		try{
			String tableName = "LIST";
			List<?> list = (List<?>)iMap.get(tableName);
			for(int i=0;i<list.size();i++)
			{
				iMap.put(tableName, i,"SEC",iMap.getBoolean("TUMUNU_SEC"));
			}
        	return iMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}

