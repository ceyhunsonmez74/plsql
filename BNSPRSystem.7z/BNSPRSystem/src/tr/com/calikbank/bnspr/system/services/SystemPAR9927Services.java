package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPr;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPrId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9927Services {
	@GraymoundService("BNSPR_PAR9927_GET_GRUP_URUN_SINIF")
	public static GMMap getGrupUrunSinif(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					GnlDkGrupUrunSinifPr.class).add(
					Restrictions.eq("id.grupKod", iMap
							.getBigDecimal("DK_GRUP_KODU"))).addOrder(
					Order.asc("id.modulTurKod")).addOrder(
					Order.asc("id.urunTurKod")).addOrder(
					Order.asc("id.urunSinifKod")).list();

			String tableName = "GRUP_URUN_SINIF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlDkGrupUrunSinifPr dkGrupUrunSinifPr = (GnlDkGrupUrunSinifPr)iterator.next();
				oMap.put(tableName, row, "MODUL_TUR_KOD", dkGrupUrunSinifPr.getId().getModulTurKod());
                oMap.put(tableName, row, "URUN_TUR_KOD", dkGrupUrunSinifPr.getId().getUrunTurKod());
                oMap.put(tableName, row, "URUN_SINIF_KOD", dkGrupUrunSinifPr.getId().getUrunSinifKod());
                oMap.put(tableName, row, "DK_HESABI_1", dkGrupUrunSinifPr.getDkAna());
                oMap.put(tableName, row, "DK_HESABI_2", dkGrupUrunSinifPr.getDkFaizGelir());
                oMap.put(tableName, row, "DK_HESABI_3", dkGrupUrunSinifPr.getDkFaizGider());
                oMap.put(tableName, row, "DK_HESABI_4", dkGrupUrunSinifPr.getDkReeskont());
                oMap.put(tableName, row, "DK_HESABI_5", dkGrupUrunSinifPr.getDkKomGelir());
                oMap.put(tableName, row, "DK_HESABI_6", dkGrupUrunSinifPr.getDkKomReeskont());
                oMap.put(tableName, row, "DK_HESABI_7", dkGrupUrunSinifPr.getDkEkhesap7());
                oMap.put(tableName, row, "DK_HESABI_8", dkGrupUrunSinifPr.getDkEkhesap8());
                oMap.put(tableName, row, "DK_HESABI_9", dkGrupUrunSinifPr.getDkEkhesap9());
                oMap.put(tableName, row, "DK_HESABI_10", dkGrupUrunSinifPr.getDkEkhesap10());
                oMap.put(tableName, row, "DK_HESABI_11", dkGrupUrunSinifPr.getDkEkhesap11());
                oMap.put(tableName, row, "DK_HESABI_12", dkGrupUrunSinifPr.getDkEkhesap12());
                oMap.put(tableName, row, "DK_HESABI_13", dkGrupUrunSinifPr.getDkEkhesap13());
                oMap.put(tableName, row, "DK_HESABI_14", dkGrupUrunSinifPr.getDkEkhesap14());
                oMap.put(tableName, row, "DK_HESABI_15", dkGrupUrunSinifPr.getDkEkhesap15());
                //oMap.put(tableName, row, "SPOT_ROTATIF", dkGrupUrunSinifPr.getSpotRotatif());
                oMap.put(tableName, row, "INT_BANK_GORUNTU_F", dkGrupUrunSinifPr.getIntBankGoruntuF());
                oMap.put(tableName, row, "INT_BANK_ISLEM_YAPILSIN_F", dkGrupUrunSinifPr.getIntBankIslemYapilsinF());
                
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9927_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> urunGrupList = (List<?>)session.createCriteria(GnlDkGrupUrunSinifPr.class).add(Restrictions.eq("id.grupKod",iMap.getBigDecimal("DK_GRUP_KODU"))).list();
			for (Iterator<?> iterator = urunGrupList.iterator(); iterator.hasNext();) {
				GnlDkGrupUrunSinifPr dkGrupUrunSinifPr = (GnlDkGrupUrunSinifPr) iterator.next();
				session.delete(dkGrupUrunSinifPr);
			}
			
			String tableName = "GRUP_URUN_SINIF";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				
				GnlDkGrupUrunSinifPr dkGrupUrunSinifPr = new GnlDkGrupUrunSinifPr();
				GnlDkGrupUrunSinifPrId dkGrupUrunSinifPrId = new GnlDkGrupUrunSinifPrId();
				
				dkGrupUrunSinifPrId.setGrupKod(iMap.getBigDecimal("DK_GRUP_KODU"));
				dkGrupUrunSinifPrId.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
				dkGrupUrunSinifPrId.setUrunTurKod(iMap.getString(tableName, row, "URUN_TUR_KOD"));
				dkGrupUrunSinifPrId.setUrunSinifKod(iMap.getString(tableName, row, "URUN_SINIF_KOD"));
				dkGrupUrunSinifPr.setId(dkGrupUrunSinifPrId);
				dkGrupUrunSinifPr.setDkAna(iMap.getString(tableName, row, "DK_HESABI_1"));
				dkGrupUrunSinifPr.setDkFaizGelir(iMap.getString(tableName, row, "DK_HESABI_2"));
				dkGrupUrunSinifPr.setDkFaizGider(iMap.getString(tableName, row, "DK_HESABI_3"));
				dkGrupUrunSinifPr.setDkReeskont(iMap.getString(tableName, row, "DK_HESABI_4"));
				dkGrupUrunSinifPr.setDkKomGelir(iMap.getString(tableName, row, "DK_HESABI_5"));
				dkGrupUrunSinifPr.setDkKomReeskont(iMap.getString(tableName, row, "DK_HESABI_6"));
				dkGrupUrunSinifPr.setDkEkhesap7(iMap.getString(tableName, row, "DK_HESABI_7"));
				dkGrupUrunSinifPr.setDkEkhesap8(iMap.getString(tableName, row, "DK_HESABI_8"));
				dkGrupUrunSinifPr.setDkEkhesap9(iMap.getString(tableName, row, "DK_HESABI_9"));
				dkGrupUrunSinifPr.setDkEkhesap10(iMap.getString(tableName, row, "DK_HESABI_10"));
				dkGrupUrunSinifPr.setDkEkhesap11(iMap.getString(tableName, row, "DK_HESABI_11"));
				dkGrupUrunSinifPr.setDkEkhesap12(iMap.getString(tableName, row, "DK_HESABI_12"));
				dkGrupUrunSinifPr.setDkEkhesap13(iMap.getString(tableName, row, "DK_HESABI_13"));
				dkGrupUrunSinifPr.setDkEkhesap14(iMap.getString(tableName, row, "DK_HESABI_14"));
				dkGrupUrunSinifPr.setDkEkhesap15(iMap.getString(tableName, row, "DK_HESABI_15"));
				//dkGrupUrunSinifPr.setSpotRotatif(iMap.getString(tableName, row, "SPOT_ROTATIF"));
				dkGrupUrunSinifPr.setIntBankGoruntuF(iMap.getString(tableName, row, "INT_BANK_GORUNTU_F"));
				dkGrupUrunSinifPr.setIntBankIslemYapilsinF(iMap.getString(tableName, row, "INT_BANK_ISLEM_YAPILSIN_F"));
				session.save(dkGrupUrunSinifPr);
				
			}
			session.flush();
			GMMap messageMap = new GMMap();  
			messageMap.put("MESSAGE_NO", new BigDecimal(711));
			messageMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE"));
			
			return messageMap;
			
		}catch (NonUniqueObjectException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(710));
			throw new GMRuntimeException(0,(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}catch (Exception e) {
			throw new GMRuntimeException(0,e.getCause().getMessage());
		}
	}
	
	
	
	@GraymoundService("BNSPR_PAR9927_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();  
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "9927_SPOT_ROTATIF");
			oMap.put("SPOT_ROTATIF", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
	
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
		
	}
	
	
	
	
	
	
	
	
	
	
}
