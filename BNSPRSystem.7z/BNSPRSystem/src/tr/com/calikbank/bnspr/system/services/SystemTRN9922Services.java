package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.axis.utils.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlLimitPr;
import tr.com.calikbank.bnspr.dao.GnlRol;
import tr.com.calikbank.bnspr.dao.GnlRolIslemDogruTxId;
import tr.com.calikbank.bnspr.dao.GnlRolIslemIptalOnayTxId;
import tr.com.calikbank.bnspr.dao.GnlRolIslemIptalTxId;
import tr.com.calikbank.bnspr.dao.GnlRolIslemOnayTxId;
import tr.com.calikbank.bnspr.dao.GnlRolIslemTxId;
import tr.com.calikbank.bnspr.dao.GnlRolislemDogruTx;
import tr.com.calikbank.bnspr.dao.GnlRolislemOnayTx;
import tr.com.calikbank.bnspr.dao.GnlRolislemTx;
import tr.com.calikbank.bnspr.dao.GnlRolislemiptalOnayTx;
import tr.com.calikbank.bnspr.dao.GnlRolislemiptalTx;
import tr.com.calikbank.bnspr.dao.GnlZamanPr;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9922Services {
	
	private static final Color BLUE = new Color(100,149,237);
	private static final Color GREEN = new Color(153,255,0);
	private static final Color YELLOW = new Color(238,230,133);
	
	@GraymoundService("BNSPR_TRN9922_GET_COMBO_LIMIT")
	public static GMMap getComboLimit(GMMap iMap){
		GMMap oMap = new GMMap();
		String listName = "LIMIT_COMBO_MODEL";
		GuimlUtil.wrapMyCombo(oMap, listName, "0", "0");
		GuimlUtil.wrapMyCombo(oMap, listName, "1", "1");
		GuimlUtil.wrapMyCombo(oMap, listName, "2", "2");
		GuimlUtil.wrapMyCombo(oMap, listName, "3", "3");
		GuimlUtil.wrapMyCombo(oMap, listName, "4", "4");
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9922_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN9922.rol_sorgulama(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ROL_NUMARA"));

			stmt.execute();
			
			GMMap oMap = new GMMap();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9922_GET_ROL_DETAILS")
	public static Map<?,?> getRolDetails(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
		
			List<?> list = session.createCriteria(GnlRolislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																				.addOrder(Order.asc("id.islemTanimKod")).list();
			BigDecimal rolNumara = null;
			String tableName = "ROL_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemTx gnlRolIslemTx = (GnlRolislemTx) iterator.next();
				rolNumara 					= gnlRolIslemTx.getId().getRolNumara();
				BigDecimal zamanNumara 		= gnlRolIslemTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 		= gnlRolIslemTx.getId().getLimitNumara();
				GnlZamanPr gnlZamanPr		= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr		= getLimit(limitNumara);
				
				oMap.put(tableName, row, "Y_ISLEM_TANIM_KOD"	, gnlRolIslemTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "Y_ZAMAN_NUMARA"		, zamanNumara);
				oMap.put(tableName, row, "Y_BASLANGIC"			, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "Y_BITIS"				, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "Y_LIMIT_NUMARA"		, limitNumara);
				oMap.put(tableName, row, "Y_ALT"				, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "Y_UST"				, gnlLimitPr.getUst());
				oMap.put(tableName, row, "Y_DOVIZ_KOD"			, gnlRolIslemTx.getDovizKod());
				oMap.put(tableName, row, "Y_DOGRULAMA"			, gnlRolIslemTx.getDogrulama());
				oMap.put(tableName, row, "Y_ONAY"				, gnlRolIslemTx.getOnay());
				oMap.put(tableName, row, "Y_IPTAL_ONAY"			, gnlRolIslemTx.getIptalOnay());
			    oMap.put(tableName, row, "Y_ZAMAN_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "Y_LIMIT_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "Y_EKRAN_ACIKLAMA", DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "Y_EKRAN_SAHIPLIGI", DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
				oMap.put(tableName, row, "F_MENUDE_GORUNTULENMESIN"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemTx.getFMenudeGoruntulenmesin()));
				oMap.put(tableName, row, "Y_YETKI_BITIS_TARIHI"			, gnlRolIslemTx.getYetkiBitisTarihi());
                
			}
			
			list = session.createCriteria(GnlRolislemDogruTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																			 .addOrder(Order.asc("id.islemTanimKod")).list();
			tableName = "ROL_DOGRULAMA";
			row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlRolislemDogruTx gnlRolIslemDogruTx 	= (GnlRolislemDogruTx) iterator.next();
				rolNumara 								= gnlRolIslemDogruTx.getId().getRolNumara();
				BigDecimal zamanNumara 					= gnlRolIslemDogruTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 					= gnlRolIslemDogruTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr					= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr					= getLimit(limitNumara);
				
				oMap.put(tableName, row, "D_ISLEM_TANIM_KOD"	, gnlRolIslemDogruTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "D_ZAMAN_NUMARA"		, zamanNumara);
				oMap.put(tableName, row, "D_BASLANGIC"			, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "D_BITIS"				, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "D_LIMIT_NUMARA"		, limitNumara);
				oMap.put(tableName, row, "D_ALT"				, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "D_UST"				, gnlLimitPr.getUst());
				oMap.put(tableName, row, "D_KARSILIK"			, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "D_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniBolum()));
				oMap.put(tableName, row, "D_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniKullanici()));
				oMap.put(tableName, row, "D_AYNI_ROL"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniRol()));
			    oMap.put(tableName, row, "D_ZAMAN_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "D_LIMIT_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "D_EKRAN_ACIKLAMA", DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "D_EKRAN_SAHIPLIGI", DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "D_YETKI_BITIS_TARIHI" , gnlRolIslemDogruTx.getYetkiBitisTarihi());
			}

			
			list = session.createCriteria(GnlRolislemOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
			 																.addOrder(Order.asc("id.islemTanimKod")).list();
			tableName = "ROL_ONAY";
			row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemOnayTx gnlRolIslemOnayTx = (GnlRolislemOnayTx) iterator.next();
				rolNumara 							= gnlRolIslemOnayTx.getId().getRolNumara();
				BigDecimal zamanNumara 				= gnlRolIslemOnayTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 				= gnlRolIslemOnayTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr				= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr				= getLimit(limitNumara);
				
				oMap.put(tableName, row, "O_ISLEM_TANIM_KOD"		, gnlRolIslemOnayTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "O_ZAMAN_NUMARA"			, zamanNumara);
				oMap.put(tableName, row, "O_BASLANGIC"				, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "O_BITIS"					, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "O_LIMIT_NUMARA"			, limitNumara);
				oMap.put(tableName, row, "O_ALT"					, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "O_UST"					, gnlLimitPr.getUst());
				oMap.put(tableName, row, "O_KARSILIK"				, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "O_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniBolum()));
				oMap.put(tableName, row, "O_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniKullanici()));
				oMap.put(tableName, row, "O_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniRol()));
			    oMap.put(tableName, row, "O_ZAMAN_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "O_LIMIT_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "O_EKRAN_ACIKLAMA", DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "O_EKRAN_SAHIPLIGI", DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));                
                oMap.put(tableName, row, "O_YETKI_BITIS_TARIHI" , gnlRolIslemOnayTx.getYetkiBitisTarihi());
			}

			
			list = session.createCriteria(GnlRolislemiptalTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																			 .addOrder(Order.asc("id.islemTanimKod")).list();
			tableName = "ROL_IPTAL";
			row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemiptalTx gnlRolIslemIptalTx 	= (GnlRolislemiptalTx) iterator.next();
				rolNumara 								= gnlRolIslemIptalTx.getId().getRolNumara();
				BigDecimal zamanNumara 					= gnlRolIslemIptalTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 					= gnlRolIslemIptalTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr					= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr					= getLimit(limitNumara);
				
				oMap.put(tableName, row, "I_ISLEM_TANIM_KOD"		, gnlRolIslemIptalTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "I_ZAMAN_NUMARA"			, zamanNumara);
				oMap.put(tableName, row, "I_BASLANGIC"				, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "I_BITIS"					, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "I_LIMIT_NUMARA"			, limitNumara);
				oMap.put(tableName, row, "I_ALT"					, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "I_UST"					, gnlLimitPr.getUst());
				oMap.put(tableName, row, "I_KARSILIK"				, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "I_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniBolum()));
				oMap.put(tableName, row, "I_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniKullanici()));
				oMap.put(tableName, row, "I_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniRol()));
			    oMap.put(tableName, row, "I_ZAMAN_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "I_LIMIT_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "I_EKRAN_ACIKLAMA", DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "I_EKRAN_SAHIPLIGI", DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "I_YETKI_BITIS_TARIHI" , gnlRolIslemIptalTx.getYetkiBitisTarihi());
              
			}
			
			list = session.createCriteria(GnlRolislemiptalOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																				 .addOrder(Order.asc("id.islemTanimKod")).list();
			tableName = "ROL_IPTAL_ONAY";
			row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemiptalOnayTx gnlRolIslemIptalOnayTx 	= (GnlRolislemiptalOnayTx) iterator.next();
				rolNumara 										= gnlRolIslemIptalOnayTx.getId().getRolNumara();
				BigDecimal zamanNumara 							= gnlRolIslemIptalOnayTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 							= gnlRolIslemIptalOnayTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr							= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr							= getLimit(limitNumara);
				
				oMap.put(tableName, row, "IO_ISLEM_TANIM_KOD"		, gnlRolIslemIptalOnayTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "IO_ZAMAN_NUMARA"			, zamanNumara);
				oMap.put(tableName, row, "IO_BASLANGIC"				, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "IO_BITIS"					, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "IO_LIMIT_NUMARA"			, limitNumara);
				oMap.put(tableName, row, "IO_ALT"					, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "IO_UST"					, gnlLimitPr.getUst());
				oMap.put(tableName, row, "IO_KARSILIK"				, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "IO_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniBolum()));
				oMap.put(tableName, row, "IO_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniKullanici()));
				oMap.put(tableName, row, "IO_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniRol()));
			    oMap.put(tableName, row, "IO_ZAMAN_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "IO_LIMIT_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "IO_EKRAN_ACIKLAMA", DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "IO_EKRAN_SAHIPLIGI", DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "IO_YETKI_BITIS_TARIHI" , gnlRolIslemIptalOnayTx.getYetkiBitisTarihi());

			}

			//ilk defa kayit giriliyorsa, ekrandan girilen rolNumarayi ata
			if(rolNumara == null) {
				rolNumara = iMap.getBigDecimal("ROL_NUMARA");
			}
			
			oMap.put("ROL_NUMARA"		,  rolNumara);
			oMap.put("DI_ROL_NUMARA"	,  LovHelper.diLovF(rolNumara, "9922/LOV_ROL", "TANIM", "NUMARA"));
			oMap.put("C", new Color(255,0,0));
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9922_SAVE_ROL_DETAILS")
	public static Map<?,?> saveRolDetails(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			//GnlRolislem
			List<?> list = session.createCriteria(GnlRolislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
				 																.addOrder(Order.asc("id.islemTanimKod")).list();

			Object[] array = list.toArray();
			for (int i = 0; i < array.length; i++) {
				list.remove		(array[i]);
				
				session.delete	(array[i]);
			}
			session.flush();
			
			String tableName = "ROL_ISLEM";
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlRolIslemTxId id = new GnlRolIslemTxId();
				id.setTxNo			(iMap.getBigDecimal("TRX_NO"));
				id.setRolNumara		(iMap.getBigDecimal("ROL_NUMARA"));
				id.setIslemTanimKod	(iMap.getBigDecimal(tableName, row, "Y_ISLEM_TANIM_KOD"));
				id.setZamanNumara	(iMap.getBigDecimal(tableName, row, "Y_ZAMAN_NUMARA"));
				id.setLimitNumara	(iMap.getBigDecimal(tableName, row, "Y_LIMIT_NUMARA"));
				
				//GnlRolislemTx gnlRolIslemTx = (GnlRolislemTx) session.get(GnlRolislemTx.class, id);
				// if (gnlRolIslemTx == null ){
				GnlRolislemTx gnlRolIslemTx = new GnlRolislemTx();
					gnlRolIslemTx.setId(id);
				//}
				
				gnlRolIslemTx.setDovizKod		(iMap.getString		(tableName, row, "Y_DOVIZ_KODU"));
				gnlRolIslemTx.setDogrulama  	(iMap.getBigDecimal	(tableName, row, "Y_DOGRULAMA"));
				gnlRolIslemTx.setOnay			(iMap.getBigDecimal	(tableName, row, "Y_ONAY"));
				gnlRolIslemTx.setIptalOnay		(iMap.getBigDecimal	(tableName, row, "Y_IPTAL_ONAY"));
				gnlRolIslemTx.setGDS			(iMap.getString		(tableName, row, "G_D_S"));
				gnlRolIslemTx.setYetkiBitisTarihi(iMap.getDate      (tableName, row ,"Y_YETKI_BITIS_TARIHI"));
				gnlRolIslemTx.setDogrulaGuncelle(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "Y_DOGRULA_GUNCELLE")));
				gnlRolIslemTx.setOnaylaGuncelle	(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "Y_ONAYLA_GUNCELLE")));
				gnlRolIslemTx.setFMenudeGoruntulenmesin	(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "F_MENUDE_GORUNTULENMESIN")));
				if(StringUtils.isEmpty(DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+id.getIslemTanimKod()+"")))
				{
				    throw new GMRuntimeException(1 , id.getIslemTanimKod()+"  nolu i�lemin Ekran sahipli�i tan�ml� olmad���ndan i�leme devam edemezsiniz. Sistem Kimlik Y�netimi b�l�m� ile g�r���lmesini gerekmektedir.");
				}
				session.save(gnlRolIslemTx);
			}			
			
			//GnlRolIslemDogru
			list = session.createCriteria(GnlRolislemDogruTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																			 .addOrder(Order.asc("id.islemTanimKod")).list();

			array = list.toArray();
			for (int i = 0; i < array.length; i++) {
				list.remove		(array[i]);
				session.delete	(array[i]);
			}
			session.flush();
			
			tableName = "ROL_DOGRULAMA";
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlRolIslemDogruTxId id = new GnlRolIslemDogruTxId();
				id.setTxNo			(iMap.getBigDecimal("TRX_NO"));
				id.setRolNumara		(iMap.getBigDecimal("ROL_NUMARA"));
				id.setIslemTanimKod	(iMap.getBigDecimal(tableName, row, "D_ISLEM_TANIM_KOD"));
				id.setZamanNumara	(iMap.getBigDecimal(tableName, row, "D_ZAMAN_NUMARA"));
				id.setLimitNumara	(iMap.getBigDecimal(tableName, row, "D_LIMIT_NUMARA"));
				
				// GnlRolislemDogruTx gnlRolIslemDogruTx = (GnlRolislemDogruTx)session.get(GnlRolislemDogruTx.class, id);
				//if (gnlRolIslemDogruTx == null){
				GnlRolislemDogruTx 	gnlRolIslemDogruTx = new GnlRolislemDogruTx();
					gnlRolIslemDogruTx.setId(id);
				// }

				gnlRolIslemDogruTx.setDogruRolNumara(id.getRolNumara()); //Rol Numara ile ayn� olmas� istendi. 
				gnlRolIslemDogruTx.setAyniBolum		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "D_AYNI_BOLUM")));
				gnlRolIslemDogruTx.setAyniKullanici	(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "D_AYNI_KULLANICI")));
				gnlRolIslemDogruTx.setAyniRol		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "D_AYNI_ROL")));
				gnlRolIslemDogruTx.setGDS			(iMap.getString(tableName, row, "G_D_S"));
				gnlRolIslemDogruTx.setYetkiBitisTarihi(iMap.getDate(tableName, row ,"D_YETKI_BITIS_TARIHI"));
				if(StringUtils.isEmpty(DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+id.getIslemTanimKod()+"")))
                {
                    throw new GMRuntimeException(2 , id.getIslemTanimKod()+"  nolu i�lemin Ekran sahipli�i tan�ml� olmad���ndan i�leme devam edemezsiniz. Sistem Kimlik Y�netimi b�l�m� ile g�r���lmesini gerekmektedir.");
                }
				session.save(gnlRolIslemDogruTx);
			}			
			
			//GnlRolIslemOnay
			list = session.createCriteria(GnlRolislemOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
			 																.addOrder(Order.asc("id.islemTanimKod")).list();

			array = list.toArray();
			for (int i = 0; i < array.length; i++) {
				list.remove		(array[i]);
				session.delete	(array[i]);
			}
			session.flush();

			tableName = "ROL_ONAY";
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlRolIslemOnayTxId id = new GnlRolIslemOnayTxId();
				id.setTxNo			(iMap.getBigDecimal("TRX_NO"));
				id.setRolNumara		(iMap.getBigDecimal("ROL_NUMARA"));
				id.setIslemTanimKod	(iMap.getBigDecimal(tableName, row, "O_ISLEM_TANIM_KOD"));
				id.setZamanNumara	(iMap.getBigDecimal(tableName, row, "O_ZAMAN_NUMARA"));
				id.setLimitNumara	(iMap.getBigDecimal(tableName, row, "O_LIMIT_NUMARA"));
				
				// GnlRolislemOnayTx gnlRolIslemOnayTx = (GnlRolislemOnayTx)session.get(GnlRolislemOnayTx.class, id);
				//if (gnlRolIslemOnayTx == null){
				GnlRolislemOnayTx gnlRolIslemOnayTx = new GnlRolislemOnayTx();
					gnlRolIslemOnayTx.setId(id);
				//}
			
				gnlRolIslemOnayTx.setOnayRolNumara(	id.getRolNumara()); //Rol Numara ile ayn� olmas� istendi.
				gnlRolIslemOnayTx.setAyniBolum		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "O_AYNI_BOLUM")));
				gnlRolIslemOnayTx.setAyniKullanici	(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "O_AYNI_KULLANICI")));
				gnlRolIslemOnayTx.setAyniRol		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "O_AYNI_ROL")));
				gnlRolIslemOnayTx.setGDS			(iMap.getString(tableName, row, "G_D_S"));
				gnlRolIslemOnayTx.setYetkiBitisTarihi(iMap.getDate(tableName, row ,"O_YETKI_BITIS_TARIHI"));
		        if(StringUtils.isEmpty(DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+id.getIslemTanimKod()+"")))
                {
                    throw new GMRuntimeException(3 , id.getIslemTanimKod()+"  nolu i�lemin Ekran sahipli�i tan�ml� olmad���ndan i�leme devam edemezsiniz. Sistem Kimlik Y�netimi b�l�m� ile g�r���lmesini gerekmektedir.");
                }
				session.save(gnlRolIslemOnayTx);
			}
						
			//GnlRolIslemIptal
			list = session.createCriteria(GnlRolislemiptalTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																			 .addOrder(Order.asc("id.islemTanimKod")).list();

			array = list.toArray();
			for (int i = 0; i < array.length; i++) {
				list.remove		(array[i]);
				session.delete	(array[i]);
			}
			session.flush();

			tableName = "ROL_IPTAL";
						
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlRolIslemIptalTxId id = new GnlRolIslemIptalTxId();
				id.setTxNo			(iMap.getBigDecimal("TRX_NO"));
				id.setRolNumara		(iMap.getBigDecimal("ROL_NUMARA"));
				id.setIslemTanimKod	(iMap.getBigDecimal(tableName, row, "I_ISLEM_TANIM_KOD"));
				id.setZamanNumara	(iMap.getBigDecimal(tableName, row, "I_ZAMAN_NUMARA"));
				id.setLimitNumara	(iMap.getBigDecimal(tableName, row, "I_LIMIT_NUMARA"));
				
				// GnlRolislemiptalTx gnlRolIslemIptalTx = (GnlRolislemiptalTx) session.get(GnlRolislemiptalTx.class, id);
				// if (gnlRolIslemIptalTx == null){
				GnlRolislemiptalTx gnlRolIslemIptalTx = new GnlRolislemiptalTx();
					gnlRolIslemIptalTx.setId(id);
				//}
				
				gnlRolIslemIptalTx.setAyniBolum		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "I_AYNI_BOLUM")));
				gnlRolIslemIptalTx.setAyniKullanici	(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "I_AYNI_KULLANICI")));
				gnlRolIslemIptalTx.setAyniRol		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "I_AYNI_ROL")));
				gnlRolIslemIptalTx.setGDS			(iMap.getString(tableName, row, "G_D_S"));
				gnlRolIslemIptalTx.setYetkiBitisTarihi(iMap.getDate(tableName, row ,"I_YETKI_BITIS_TARIHI"));
		        if(StringUtils.isEmpty(DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+id.getIslemTanimKod()+"")))
                {
                    throw new GMRuntimeException(4 , id.getIslemTanimKod()+"  nolu i�lemin Ekran sahipli�i tan�ml� olmad���ndan i�leme devam edemezsiniz. Sistem Kimlik Y�netimi b�l�m� ile g�r���lmesini gerekmektedir.");
                }
				session.save(gnlRolIslemIptalTx);
			}			
			
			//GnlRolIslemIptalOnay
			list = session.createCriteria(GnlRolislemiptalOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
		  																	 	 .addOrder(Order.asc("id.islemTanimKod")).list();

			array = list.toArray();
			for (int i = 0; i < array.length; i++) {
				list.remove		(array[i]);
				session.delete	(array[i]);
			}
			session.flush();
			
			tableName = "ROL_IPTAL_ONAY";
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlRolIslemIptalOnayTxId id = new GnlRolIslemIptalOnayTxId();
				id.setTxNo			(iMap.getBigDecimal("TRX_NO"));
				id.setRolNumara		(iMap.getBigDecimal("ROL_NUMARA"));
				id.setIslemTanimKod	(iMap.getBigDecimal(tableName, row, "IO_ISLEM_TANIM_KOD"));
				id.setZamanNumara	(iMap.getBigDecimal(tableName, row, "IO_ZAMAN_NUMARA"));
				id.setLimitNumara	(iMap.getBigDecimal(tableName, row, "IO_LIMIT_NUMARA"));
				//GnlRolislemiptalOnayTx gnlRolIslemIptalOnayTx = (GnlRolislemiptalOnayTx)session.get(GnlRolislemiptalOnayTx.class, id);
				//if (gnlRolIslemIptalOnayTx == null){
				GnlRolislemiptalOnayTx gnlRolIslemIptalOnayTx = new GnlRolislemiptalOnayTx();
					gnlRolIslemIptalOnayTx.setId(id);
				//}
				
				gnlRolIslemIptalOnayTx.setAyniBolum		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "IO_AYNI_BOLUM")));
				gnlRolIslemIptalOnayTx.setAyniKullanici	(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "IO_AYNI_KULLANICI")));
				gnlRolIslemIptalOnayTx.setAyniRol		(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "IO_AYNI_ROL")));
				gnlRolIslemIptalOnayTx.setGDS			(iMap.getString(tableName, row, "G_D_S"));
				gnlRolIslemIptalOnayTx.setYetkiBitisTarihi(iMap.getDate(tableName, row ,"IO_YETKI_BITIS_TARIHI"));
		        if(StringUtils.isEmpty(DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+id.getIslemTanimKod()+"")))
                {
                    throw new GMRuntimeException(5 , id.getIslemTanimKod()+"  nolu i�lemin Ekran sahipli�i tan�ml� olmad���ndan i�leme devam edemezsiniz. Sistem Kimlik Y�netimi b�l�m� ile g�r���lmesini gerekmektedir.");
                }
				session.save(gnlRolIslemIptalOnayTx);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9922");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static GnlRol getRol(BigDecimal rolNumara){
		try{
			return (GnlRol) DAOSession.getSession("BNSPRDal").get(GnlRol.class, rolNumara);
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GnlZamanPr getZaman(BigDecimal numara){
		try{
			return (GnlZamanPr) DAOSession.getSession("BNSPRDal").get(GnlZamanPr.class, numara);
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GnlLimitPr getLimit(BigDecimal kod){
		try{
			return (GnlLimitPr) DAOSession.getSession("BNSPRDal").get(GnlLimitPr.class, kod);
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9922_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
		
			List<?> list = session.createCriteria(GnlRolislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																				.addOrder(Order.asc("id.islemTanimKod")).list();
			BigDecimal rolNumara = null;
			BigDecimal tempIslemTanimKod = null;
			String tableName = "ROL_ISLEM";
			String tempTableName = "TEMP_ROL_ISLEM";
			String colorTableName ="ROL_ISLEM_COLOR_DATA";
			int row = 0;
			int tempRow = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemTx gnlRolIslemTx = (GnlRolislemTx) iterator.next();
				rolNumara 					= gnlRolIslemTx.getId().getRolNumara();
				iMap.put("ROL_NUMARA", rolNumara);
				BigDecimal zamanNumara 		= gnlRolIslemTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 		= gnlRolIslemTx.getId().getLimitNumara();
				GnlZamanPr gnlZamanPr		= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr		= getLimit(limitNumara);
				
				oMap.put(tableName, row, "Y_ISLEM_TANIM_KOD"	, gnlRolIslemTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "Y_ZAMAN_NUMARA"		, zamanNumara);
				oMap.put(tableName, row, "Y_BASLANGIC"			, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "Y_BITIS"				, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "Y_LIMIT_NUMARA"		, limitNumara);
				oMap.put(tableName, row, "Y_ALT"				, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "Y_UST"				, gnlLimitPr.getUst());
				oMap.put(tableName, row, "Y_DOVIZ_KOD"			, gnlRolIslemTx.getDovizKod());
				oMap.put(tableName, row, "Y_DOGRULAMA"			, gnlRolIslemTx.getDogrulama());
				oMap.put(tableName, row, "Y_ONAY"				, gnlRolIslemTx.getOnay());
				oMap.put(tableName, row, "Y_IPTAL_ONAY"			, gnlRolIslemTx.getIptalOnay());
				oMap.put(tableName, row, "GDS"					, gnlRolIslemTx.getGDS());
				oMap.put(tableName, row, "GDS"					, gnlRolIslemTx.getGDS());
				oMap.put(tableName, row, "Y_YETKI_BITIS_TARIHI"	, gnlRolIslemTx.getYetkiBitisTarihi());
				oMap.put(tableName, row, "DEL"					, "");
				oMap.put(tableName, row, "Y_ZAMAN_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
				oMap.put(tableName, row, "Y_LIMIT_ACIKLAMA", DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
				oMap.put(tableName, row, "Y_EKRAN_ACIKLAMA", DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
				oMap.put(tableName, row, "Y_EKRAN_SAHIPLIGI", DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "F_MENUDE_GORUNTULENMESIN", GuimlUtil.convertToCheckBoxValue(gnlRolIslemTx.getFMenudeGoruntulenmesin()));

                Map<?, ?> map = oMap.getMap(tableName, row);
				
				if(map.get("GDS") != null && map.get("GDS").equals("D")){
					
					GnlRolIslemTxId id = new GnlRolIslemTxId();
					iMap.put("CLASS", GnlRolislemTx.class);
					id.setTxNo			(getPreviousTx(iMap));
					id.setRolNumara		(gnlRolIslemTx.getId().getRolNumara());
					id.setIslemTanimKod	(gnlRolIslemTx.getId().getIslemTanimKod());
					id.setZamanNumara	(gnlRolIslemTx.getId().getZamanNumara());
					id.setLimitNumara	(gnlRolIslemTx.getId().getLimitNumara());
					
					GnlRolislemTx oldGnlRolIslemTx = (GnlRolislemTx) session.get(GnlRolislemTx.class, id);
					rolNumara 							= oldGnlRolIslemTx.getId().getRolNumara();
					BigDecimal oldZamanNumara 			= oldGnlRolIslemTx.getId().getZamanNumara();
					BigDecimal oldLimitNumara 			= oldGnlRolIslemTx.getId().getLimitNumara();
					GnlZamanPr oldGnlZamanPr			= getZaman(zamanNumara);
					GnlLimitPr oldGnlLimitPr			= getLimit(limitNumara);
					
					oMap.put(tempTableName, tempRow, "Y_ISLEM_TANIM_KOD"	, oldGnlRolIslemTx.getId().getIslemTanimKod());
					oMap.put(tempTableName, tempRow, "Y_ZAMAN_NUMARA"		, oldZamanNumara);
					oMap.put(tempTableName, tempRow, "Y_BASLANGIC"			, oldGnlZamanPr.getBaslangic());
					oMap.put(tempTableName, tempRow, "Y_BITIS"				, oldGnlZamanPr.getBitis());
					oMap.put(tempTableName, tempRow, "Y_LIMIT_NUMARA"		, oldLimitNumara);
					oMap.put(tempTableName, tempRow, "Y_ALT"				, oldGnlLimitPr.getAlt());
					oMap.put(tempTableName, tempRow, "Y_UST"				, oldGnlLimitPr.getUst());
					oMap.put(tempTableName, tempRow, "Y_DOVIZ_KOD"			, oldGnlRolIslemTx.getDovizKod());
					oMap.put(tempTableName, tempRow, "Y_DOGRULAMA"			, oldGnlRolIslemTx.getDogrulama());
					oMap.put(tempTableName, tempRow, "Y_ONAY"				, oldGnlRolIslemTx.getOnay());
					oMap.put(tempTableName, tempRow, "Y_IPTAL_ONAY"			, oldGnlRolIslemTx.getIptalOnay());
					oMap.put(tempTableName, tempRow, "GDS"					, oldGnlRolIslemTx.getGDS());
					oMap.put(tempTableName, tempRow, "Y_YETKI_BITIS_TARIHI"	, oldGnlRolIslemTx.getYetkiBitisTarihi());
					oMap.put(tempTableName, tempRow, "DEL"					, "");
					oMap.put(tempTableName, tempRow, "Y_ZAMAN_ACIKLAMA",    DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+oldZamanNumara+""));
	                oMap.put(tempTableName, tempRow, "Y_LIMIT_ACIKLAMA",    DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+oldLimitNumara+""));
	                oMap.put(tempTableName, tempRow, "Y_EKRAN_ACIKLAMA",    DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+oldGnlRolIslemTx.getId().getIslemTanimKod()+""));
	                oMap.put(tempTableName, tempRow, "Y_EKRAN_SAHIPLIGI",    DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+oldGnlRolIslemTx.getId().getIslemTanimKod()+""));
	                oMap.put(tempTableName, tempRow, "F_MENUDE_GORUNTULENMESIN", GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemTx.getFMenudeGoruntulenmesin()));
					
					compareTables(oMap, oMap.getMap(tempTableName, tempRow), map, row, colorTableName, YELLOW);
					tempRow++;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S") && tempIslemTanimKod != null && gnlRolIslemTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "Y_ISLEM_TANIM_KOD"	, gnlRolIslemTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "Y_ZAMAN_NUMARA"		, zamanNumara);
					oMap.put(tableName, row, "Y_BASLANGIC"			, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "Y_BITIS"				, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "Y_LIMIT_NUMARA"		, limitNumara);
					oMap.put(tableName, row, "Y_ALT"				, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "Y_UST"				, gnlLimitPr.getUst());
					oMap.put(tableName, row, "Y_DOVIZ_KOD"			, gnlRolIslemTx.getDovizKod());
					oMap.put(tableName, row, "Y_DOGRULAMA"			, gnlRolIslemTx.getDogrulama());
					oMap.put(tableName, row, "Y_ONAY"				, gnlRolIslemTx.getOnay());
					oMap.put(tableName, row, "Y_IPTAL_ONAY"			, gnlRolIslemTx.getIptalOnay());
					oMap.put(tableName, row, "GDS"					, gnlRolIslemTx.getGDS());
					oMap.put(tableName, row, "Y_YETKI_BITIS_TARIHI"	, gnlRolIslemTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"					, "");
					oMap.put(tableName, row, "Y_ZAMAN_ACIKLAMA",    DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "Y_LIMIT_ACIKLAMA",    DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "Y_EKRAN_ACIKLAMA",    DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "Y_EKRAN_SAHIPLIGI",    DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "F_MENUDE_GORUNTULENMESIN", GuimlUtil.convertToCheckBoxValue(gnlRolIslemTx.getFMenudeGoruntulenmesin()));
					
	                for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
					tempIslemTanimKod = null;
				}else if(map.get("GDS") != null && map.get("GDS").equals("G") && tempIslemTanimKod != null && gnlRolIslemTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "Y_ISLEM_TANIM_KOD"	, gnlRolIslemTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "Y_ZAMAN_NUMARA"		, zamanNumara);
					oMap.put(tableName, row, "Y_BASLANGIC"			, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "Y_BITIS"				, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "Y_LIMIT_NUMARA"		, limitNumara);
					oMap.put(tableName, row, "Y_ALT"				, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "Y_UST"				, gnlLimitPr.getUst());
					oMap.put(tableName, row, "Y_DOVIZ_KOD"			, gnlRolIslemTx.getDovizKod());
					oMap.put(tableName, row, "Y_DOGRULAMA"			, gnlRolIslemTx.getDogrulama());
					oMap.put(tableName, row, "Y_ONAY"				, gnlRolIslemTx.getOnay());
					oMap.put(tableName, row, "Y_IPTAL_ONAY"			, gnlRolIslemTx.getIptalOnay());
					oMap.put(tableName, row, "GDS"					, gnlRolIslemTx.getGDS());
					oMap.put(tableName, row, "Y_YETKI_BITIS_TARIHI" , gnlRolIslemTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"					, "");
					oMap.put(tableName, row, "Y_ZAMAN_ACIKLAMA"     ,  DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "Y_LIMIT_ACIKLAMA",    DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "Y_EKRAN_ACIKLAMA",    DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "Y_EKRAN_SAHIPLIGI",    DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "F_MENUDE_GORUNTULENMESIN", GuimlUtil.convertToCheckBoxValue(gnlRolIslemTx.getFMenudeGoruntulenmesin()));
	                
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
					
					tempIslemTanimKod = null;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S")){
					tempIslemTanimKod = gnlRolIslemTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("G")){
					tempIslemTanimKod = gnlRolIslemTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
				}else{
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", Color.WHITE));
					}					
				}
				
			}
			
			list = session.createCriteria(GnlRolislemDogruTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																			 .addOrder(Order.asc("id.islemTanimKod")).list();
			tempIslemTanimKod = null;
			tableName = "ROL_DOGRULAMA";
			tempTableName = "TEMP_ROL_DOGRULAMA";
			colorTableName ="ROL_DOGRULAMA_COLOR_DATA";
			row = 0;
			tempRow = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlRolislemDogruTx gnlRolIslemDogruTx 	= (GnlRolislemDogruTx) iterator.next();
				rolNumara 								= gnlRolIslemDogruTx.getId().getRolNumara();
				iMap.put("ROL_NUMARA", rolNumara);
				BigDecimal zamanNumara 					= gnlRolIslemDogruTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 					= gnlRolIslemDogruTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr					= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr					= getLimit(limitNumara);
				
				oMap.put(tableName, row, "D_ISLEM_TANIM_KOD"	, gnlRolIslemDogruTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "D_ZAMAN_NUMARA"		, zamanNumara);
				oMap.put(tableName, row, "D_BASLANGIC"			, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "D_BITIS"				, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "D_LIMIT_NUMARA"		, limitNumara);
				oMap.put(tableName, row, "D_ALT"				, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "D_UST"				, gnlLimitPr.getUst());
				oMap.put(tableName, row, "D_KARSILIK"			, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "D_DOVIZ_KOD"			, gnlLimitPr.getDovizKod());
				oMap.put(tableName, row, "D_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniBolum()));
				oMap.put(tableName, row, "D_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniKullanici()));
				oMap.put(tableName, row, "D_AYNI_ROL"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniRol()));
				oMap.put(tableName, row, "GDS"					, gnlRolIslemDogruTx.getGDS());
				oMap.put(tableName, row, "D_YETKI_BITIS_TARIHI" , gnlRolIslemDogruTx.getYetkiBitisTarihi());
				oMap.put(tableName, row, "DEL"					, "");
				oMap.put(tableName, row, "D_ZAMAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "D_LIMIT_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "D_EKRAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "D_EKRAN_SAHIPLIGI"     , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
				Map<?, ?> map = oMap.getMap(tableName, row);
				
				if(map.get("GDS") != null && map.get("GDS").equals("D")){
					
					GnlRolIslemDogruTxId id = new GnlRolIslemDogruTxId();
					iMap.put("CLASS", GnlRolislemDogruTx.class);
					id.setTxNo			(getPreviousTx(iMap));
					id.setRolNumara		(gnlRolIslemDogruTx.getId().getRolNumara());
					id.setIslemTanimKod	(gnlRolIslemDogruTx.getId().getIslemTanimKod());
					id.setZamanNumara	(gnlRolIslemDogruTx.getId().getZamanNumara());
					id.setLimitNumara	(gnlRolIslemDogruTx.getId().getLimitNumara());
					
					GnlRolislemDogruTx oldGnlRolIslemDogruTx = (GnlRolislemDogruTx)session.get(GnlRolislemDogruTx.class, id);
					rolNumara 							= oldGnlRolIslemDogruTx.getId().getRolNumara();
					BigDecimal oldZamanNumara 			= oldGnlRolIslemDogruTx.getId().getZamanNumara();
					BigDecimal oldLimitNumara 			= oldGnlRolIslemDogruTx.getId().getLimitNumara();
					GnlZamanPr oldGnlZamanPr			= getZaman(zamanNumara);
					GnlLimitPr oldGnlLimitPr			= getLimit(limitNumara);
					
					oMap.put(tempTableName, tempRow, "D_ISLEM_TANIM_KOD"	, oldGnlRolIslemDogruTx.getId().getIslemTanimKod());
					oMap.put(tempTableName, tempRow, "D_ZAMAN_NUMARA"		, oldZamanNumara);
					oMap.put(tempTableName, tempRow, "D_BASLANGIC"			, oldGnlZamanPr.getBaslangic());
					oMap.put(tempTableName, tempRow, "D_BITIS"				, oldGnlZamanPr.getBitis());
					oMap.put(tempTableName, tempRow, "D_LIMIT_NUMARA"		, oldLimitNumara);
					oMap.put(tempTableName, tempRow, "D_ALT"				, oldGnlLimitPr.getAlt());
					oMap.put(tempTableName, tempRow, "D_UST"				, oldGnlLimitPr.getUst());
					oMap.put(tempTableName, tempRow, "D_KARSILIK"			, oldGnlLimitPr.getKarsilik());
					oMap.put(tempTableName, tempRow, "D_DOVIZ_KOD"			, oldGnlLimitPr.getDovizKod());
					oMap.put(tempTableName, tempRow, "D_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemDogruTx.getAyniBolum()));
					oMap.put(tempTableName, tempRow, "D_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemDogruTx.getAyniKullanici()));
					oMap.put(tempTableName, tempRow, "D_AYNI_ROL"			, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemDogruTx.getAyniRol()));
					oMap.put(tempTableName, tempRow, "GDS"					, oldGnlRolIslemDogruTx.getGDS());
					oMap.put(tempTableName, tempRow, "D_YETKI_BITIS_TARIHI" , oldGnlRolIslemDogruTx.getYetkiBitisTarihi());
					oMap.put(tempTableName, tempRow, "DEL"					, "");
					oMap.put(tempTableName, tempRow, "D_ZAMAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+oldZamanNumara+""));
	                oMap.put(tempTableName, tempRow, "D_LIMIT_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+oldLimitNumara+""));
	                oMap.put(tempTableName, tempRow, "D_EKRAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+oldGnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
	                oMap.put(tempTableName, tempRow, "D_EKRAN_SAHIPLIGI"     , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+oldGnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
					compareTables(oMap, oMap.getMap(tempTableName, tempRow), map, row, colorTableName, YELLOW);
					tempRow++;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S") && tempIslemTanimKod != null && gnlRolIslemDogruTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "D_ISLEM_TANIM_KOD"	, gnlRolIslemDogruTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "D_ZAMAN_NUMARA"		, zamanNumara);
					oMap.put(tableName, row, "D_BASLANGIC"			, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "D_BITIS"				, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "D_LIMIT_NUMARA"		, limitNumara);
					oMap.put(tableName, row, "D_ALT"				, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "D_UST"				, gnlLimitPr.getUst());
					oMap.put(tableName, row, "D_KARSILIK"			, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "D_DOVIZ_KOD"			, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "D_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniBolum()));
					oMap.put(tableName, row, "D_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniKullanici()));
					oMap.put(tableName, row, "D_AYNI_ROL"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"					, gnlRolIslemDogruTx.getGDS());
					oMap.put(tableName, row, "D_YETKI_BITIS_TARIHI" , gnlRolIslemDogruTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"					, "");
					oMap.put(tableName, row, "D_ZAMAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                    oMap.put(tableName, row, "D_LIMIT_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                    oMap.put(tableName, row, "D_EKRAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
                    oMap.put(tableName, row, "D_EKRAN_SAHIPLIGI"     , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =   "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
					tempIslemTanimKod = null;
				}else if(map.get("GDS") != null && map.get("GDS").equals("G") && tempIslemTanimKod != null && gnlRolIslemDogruTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "D_ISLEM_TANIM_KOD"	, gnlRolIslemDogruTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "D_ZAMAN_NUMARA"		, zamanNumara);
					oMap.put(tableName, row, "D_BASLANGIC"			, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "D_BITIS"				, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "D_LIMIT_NUMARA"		, limitNumara);
					oMap.put(tableName, row, "D_ALT"				, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "D_UST"				, gnlLimitPr.getUst());
					oMap.put(tableName, row, "D_KARSILIK"			, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "D_DOVIZ_KOD"			, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "D_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniBolum()));
					oMap.put(tableName, row, "D_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniKullanici()));
					oMap.put(tableName, row, "D_AYNI_ROL"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemDogruTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"					, gnlRolIslemDogruTx.getGDS());
					oMap.put(tableName, row, "D_YETKI_BITIS_TARIHI" , gnlRolIslemDogruTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"					, "");
					oMap.put(tableName, row, "D_ZAMAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                    oMap.put(tableName, row, "D_LIMIT_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                    oMap.put(tableName, row, "D_EKRAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
                    oMap.put(tableName, row, "D_EKRAN_SAHIPLIGI"     , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemDogruTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
					
					tempIslemTanimKod = null;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S")){
					tempIslemTanimKod = gnlRolIslemDogruTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("G")){
					tempIslemTanimKod = gnlRolIslemDogruTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
				}else{
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", Color.WHITE));
					}					
				}
				
			}

			
			list = session.createCriteria(GnlRolislemOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
			 																.addOrder(Order.asc("id.islemTanimKod")).list();
			tempIslemTanimKod = null;
			tableName = "ROL_ONAY";
			tempTableName = "TEMP_ROL_ONAY";
			colorTableName ="ROL_ONAY_COLOR_DATA";
			row = 0;
			tempRow = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemOnayTx gnlRolIslemOnayTx = (GnlRolislemOnayTx) iterator.next();
				rolNumara 							= gnlRolIslemOnayTx.getId().getRolNumara();
				iMap.put("ROL_NUMARA", rolNumara);
				BigDecimal zamanNumara 				= gnlRolIslemOnayTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 				= gnlRolIslemOnayTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr				= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr				= getLimit(limitNumara);
				
				oMap.put(tableName, row, "O_ISLEM_TANIM_KOD"		, gnlRolIslemOnayTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "O_ZAMAN_NUMARA"			, zamanNumara);
				oMap.put(tableName, row, "O_BASLANGIC"				, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "O_BITIS"					, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "O_LIMIT_NUMARA"			, limitNumara);
				oMap.put(tableName, row, "O_ALT"					, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "O_UST"					, gnlLimitPr.getUst());
				oMap.put(tableName, row, "O_KARSILIK"				, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "O_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
				oMap.put(tableName, row, "O_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniBolum()));
				oMap.put(tableName, row, "O_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniKullanici()));
				oMap.put(tableName, row, "O_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniRol()));
				oMap.put(tableName, row, "GDS"						, gnlRolIslemOnayTx.getGDS());
				oMap.put(tableName, row, "O_YETKI_BITIS_TARIHI"     , gnlRolIslemOnayTx.getYetkiBitisTarihi());
				oMap.put(tableName, row, "DEL"						, "");
				oMap.put(tableName, row, "O_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "O_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "O_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+ gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "O_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+ gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
				Map<?, ?> map = oMap.getMap(tableName, row);
				
				if(map.get("GDS") != null && map.get("GDS").equals("D")){
					
					GnlRolIslemOnayTxId id = new GnlRolIslemOnayTxId();
					iMap.put("CLASS", GnlRolislemOnayTx.class);
					id.setTxNo			(getPreviousTx(iMap));
					id.setRolNumara		(gnlRolIslemOnayTx.getId().getRolNumara());
					id.setIslemTanimKod	(gnlRolIslemOnayTx.getId().getIslemTanimKod());
					id.setZamanNumara	(gnlRolIslemOnayTx.getId().getZamanNumara());
					id.setLimitNumara	(gnlRolIslemOnayTx.getId().getLimitNumara());
					
					GnlRolislemOnayTx oldGnlRolIslemOnayTx = (GnlRolislemOnayTx)session.get(GnlRolislemOnayTx.class, id);
					rolNumara 							= oldGnlRolIslemOnayTx.getId().getRolNumara();
					BigDecimal oldZamanNumara 			= oldGnlRolIslemOnayTx.getId().getZamanNumara();
					BigDecimal oldLimitNumara 			= oldGnlRolIslemOnayTx.getId().getLimitNumara();
					GnlZamanPr oldGnlZamanPr			= getZaman(zamanNumara);
					GnlLimitPr oldGnlLimitPr			= getLimit(limitNumara);
					
					oMap.put(tempTableName, tempRow, "O_ISLEM_TANIM_KOD"		, oldGnlRolIslemOnayTx.getId().getIslemTanimKod());
					oMap.put(tempTableName, tempRow, "O_ZAMAN_NUMARA"			, oldZamanNumara);
					oMap.put(tempTableName, tempRow, "O_BASLANGIC"				, oldGnlZamanPr.getBaslangic());
					oMap.put(tempTableName, tempRow, "O_BITIS"					, oldGnlZamanPr.getBitis());
					oMap.put(tempTableName, tempRow, "O_LIMIT_NUMARA"			, oldLimitNumara);
					oMap.put(tempTableName, tempRow, "O_ALT"					, oldGnlLimitPr.getAlt());
					oMap.put(tempTableName, tempRow, "O_UST"					, oldGnlLimitPr.getUst());
					oMap.put(tempTableName, tempRow, "O_KARSILIK"				, oldGnlLimitPr.getKarsilik());
					oMap.put(tempTableName, tempRow, "O_DOVIZ_KOD"				, oldGnlLimitPr.getDovizKod());
					oMap.put(tempTableName, tempRow, "O_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemOnayTx.getAyniBolum()));
					oMap.put(tempTableName, tempRow, "O_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemOnayTx.getAyniKullanici()));
					oMap.put(tempTableName, tempRow, "O_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemOnayTx.getAyniRol()));
					oMap.put(tempTableName, tempRow, "GDS"						, oldGnlRolIslemOnayTx.getGDS());
					oMap.put(tempTableName, tempRow, "O_YETKI_BITIS_TARIHI"     , oldGnlRolIslemOnayTx.getYetkiBitisTarihi());
					oMap.put(tempTableName, tempRow, "DEL"						, "");
					oMap.put(tempTableName, tempRow, "O_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+oldZamanNumara+""));
	                oMap.put(tempTableName, tempRow, "O_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+oldLimitNumara+""));
	                oMap.put(tempTableName, tempRow, "O_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+ oldGnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
	                oMap.put(tempTableName, tempRow, "O_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+ oldGnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
					compareTables(oMap, oMap.getMap(tempTableName, tempRow), map, row, colorTableName, YELLOW);
					tempRow++;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S") && tempIslemTanimKod != null && gnlRolIslemOnayTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "O_ISLEM_TANIM_KOD"		, gnlRolIslemOnayTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "O_ZAMAN_NUMARA"			, zamanNumara);
					oMap.put(tableName, row, "O_BASLANGIC"				, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "O_BITIS"					, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "O_LIMIT_NUMARA"			, limitNumara);
					oMap.put(tableName, row, "O_ALT"					, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "O_UST"					, gnlLimitPr.getUst());
					oMap.put(tableName, row, "O_KARSILIK"				, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "O_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "O_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniBolum()));
					oMap.put(tableName, row, "O_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniKullanici()));
					oMap.put(tableName, row, "O_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"						, gnlRolIslemOnayTx.getGDS());
					oMap.put(tableName, row, "O_YETKI_BITIS_TARIHI"     , gnlRolIslemOnayTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"						, "");
					oMap.put(tableName, row, "O_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "O_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "O_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+ gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "O_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+ gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
					tempIslemTanimKod = null;
				}else if(map.get("GDS") != null && map.get("GDS").equals("G") && tempIslemTanimKod != null && gnlRolIslemOnayTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "O_ISLEM_TANIM_KOD"		, gnlRolIslemOnayTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "O_ZAMAN_NUMARA"			, zamanNumara);
					oMap.put(tableName, row, "O_BASLANGIC"				, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "O_BITIS"					, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "O_LIMIT_NUMARA"			, limitNumara);
					oMap.put(tableName, row, "O_ALT"					, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "O_UST"					, gnlLimitPr.getUst());
					oMap.put(tableName, row, "O_KARSILIK"				, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "O_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "O_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniBolum()));
					oMap.put(tableName, row, "O_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniKullanici()));
					oMap.put(tableName, row, "O_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemOnayTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"						, gnlRolIslemOnayTx.getGDS());
					oMap.put(tableName, row, "O_YETKI_BITIS_TARIHI"     , gnlRolIslemOnayTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"						, "");
					oMap.put(tableName, row, "O_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "O_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "O_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+ gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "O_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+ gnlRolIslemOnayTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
					
					tempIslemTanimKod = null;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S")){
					tempIslemTanimKod = gnlRolIslemOnayTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("G")){
					tempIslemTanimKod = gnlRolIslemOnayTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
				}else{
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", Color.WHITE));
					}					
				}
				
			}

			
			list = session.createCriteria(GnlRolislemiptalTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																			 .addOrder(Order.asc("id.islemTanimKod")).list();
			tempIslemTanimKod = null;
			tableName = "ROL_IPTAL";
			tempTableName = "TEMP_ROL_IPTAL";
			colorTableName ="ROL_IPTAL_COLOR_DATA";
			row = 0;
			tempRow = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemiptalTx gnlRolIslemIptalTx 	= (GnlRolislemiptalTx) iterator.next();
				rolNumara 								= gnlRolIslemIptalTx.getId().getRolNumara();
				iMap.put("ROL_NUMARA", rolNumara);
				BigDecimal zamanNumara 					= gnlRolIslemIptalTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 					= gnlRolIslemIptalTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr					= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr					= getLimit(limitNumara);
				
				oMap.put(tableName, row, "I_ISLEM_TANIM_KOD"		, gnlRolIslemIptalTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "I_ZAMAN_NUMARA"			, zamanNumara);
				oMap.put(tableName, row, "I_BASLANGIC"				, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "I_BITIS"					, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "I_LIMIT_NUMARA"			, limitNumara);
				oMap.put(tableName, row, "I_ALT"					, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "I_UST"					, gnlLimitPr.getUst());
				oMap.put(tableName, row, "I_KARSILIK"				, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "I_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
				oMap.put(tableName, row, "I_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniBolum()));
				oMap.put(tableName, row, "I_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniKullanici()));
				oMap.put(tableName, row, "I_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniRol()));
				oMap.put(tableName, row, "GDS"						, gnlRolIslemIptalTx.getGDS());
				oMap.put(tableName, row, "I_YETKI_BITIS_TARIHI"     , gnlRolIslemIptalTx.getYetkiBitisTarihi());
				oMap.put(tableName, row, "DEL"						, "");
				oMap.put(tableName, row, "I_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "I_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "I_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "I_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
				Map<?, ?> map = oMap.getMap(tableName, row);
				
				if(map.get("GDS") != null && map.get("GDS").equals("D")){
					
					GnlRolIslemIptalTxId id = new GnlRolIslemIptalTxId();
					iMap.put("CLASS", GnlRolislemiptalTx.class);
					id.setTxNo			(getPreviousTx(iMap));
					id.setRolNumara		(gnlRolIslemIptalTx.getId().getRolNumara());
					id.setIslemTanimKod	(gnlRolIslemIptalTx.getId().getIslemTanimKod());
					id.setZamanNumara	(gnlRolIslemIptalTx.getId().getZamanNumara());
					id.setLimitNumara	(gnlRolIslemIptalTx.getId().getLimitNumara());
					
					GnlRolislemiptalTx oldGnlRolIslemIptalTx = (GnlRolislemiptalTx) session.get(GnlRolislemiptalTx.class, id);
					rolNumara 							= oldGnlRolIslemIptalTx.getId().getRolNumara();
					BigDecimal oldZamanNumara 			= oldGnlRolIslemIptalTx.getId().getZamanNumara();
					BigDecimal oldLimitNumara 			= oldGnlRolIslemIptalTx.getId().getLimitNumara();
					GnlZamanPr oldGnlZamanPr			= getZaman(zamanNumara);
					GnlLimitPr oldGnlLimitPr			= getLimit(limitNumara);
					
					oMap.put(tempTableName, tempRow, "I_ISLEM_TANIM_KOD"		, oldGnlRolIslemIptalTx.getId().getIslemTanimKod());
					oMap.put(tempTableName, tempRow, "I_ZAMAN_NUMARA"			, oldZamanNumara);
					oMap.put(tempTableName, tempRow, "I_BASLANGIC"				, oldGnlZamanPr.getBaslangic());
					oMap.put(tempTableName, tempRow, "I_BITIS"					, oldGnlZamanPr.getBitis());
					oMap.put(tempTableName, tempRow, "I_LIMIT_NUMARA"			, oldLimitNumara);
					oMap.put(tempTableName, tempRow, "I_ALT"					, oldGnlLimitPr.getAlt());
					oMap.put(tempTableName, tempRow, "I_UST"					, oldGnlLimitPr.getUst());
					oMap.put(tempTableName, tempRow, "I_KARSILIK"				, oldGnlLimitPr.getKarsilik());
					oMap.put(tempTableName, tempRow, "I_DOVIZ_KOD"				, oldGnlLimitPr.getDovizKod());
					oMap.put(tempTableName, tempRow, "I_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemIptalTx.getAyniBolum()));
					oMap.put(tempTableName, tempRow, "I_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemIptalTx.getAyniKullanici()));
					oMap.put(tempTableName, tempRow, "I_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemIptalTx.getAyniRol()));
					oMap.put(tempTableName, tempRow, "GDS"						, oldGnlRolIslemIptalTx.getGDS());
					oMap.put(tempTableName, tempRow, "I_YETKI_BITIS_TARIHI"     , oldGnlRolIslemIptalTx.getYetkiBitisTarihi());
					oMap.put(tempTableName, tempRow, "DEL"						, "");
					oMap.put(tempTableName, tempRow, "I_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+oldZamanNumara+""));
	                oMap.put(tempTableName, tempRow, "I_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+oldLimitNumara+""));
	                oMap.put(tempTableName, tempRow, "I_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+oldGnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
	                oMap.put(tempTableName, tempRow, "I_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+oldGnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
					compareTables(oMap, oMap.getMap(tempTableName, tempRow), map, row, colorTableName, YELLOW);
					tempRow++;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S") && tempIslemTanimKod != null && gnlRolIslemIptalTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "I_ISLEM_TANIM_KOD"		, gnlRolIslemIptalTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "I_ZAMAN_NUMARA"			, zamanNumara);
					oMap.put(tableName, row, "I_BASLANGIC"				, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "I_BITIS"					, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "I_LIMIT_NUMARA"			, limitNumara);
					oMap.put(tableName, row, "I_ALT"					, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "I_UST"					, gnlLimitPr.getUst());
					oMap.put(tableName, row, "I_KARSILIK"				, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "I_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "I_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniBolum()));
					oMap.put(tableName, row, "I_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniKullanici()));
					oMap.put(tableName, row, "I_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"						, gnlRolIslemIptalTx.getGDS());
					oMap.put(tableName, row, "I_YETKI_BITIS_TARIHI"     , gnlRolIslemIptalTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"						, "");
					oMap.put(tableName, row, "I_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "I_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "I_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "I_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
					tempIslemTanimKod = null;
				}else if(map.get("GDS") != null && map.get("GDS").equals("G") && tempIslemTanimKod != null && gnlRolIslemIptalTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "I_ISLEM_TANIM_KOD"		, gnlRolIslemIptalTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "I_ZAMAN_NUMARA"			, zamanNumara);
					oMap.put(tableName, row, "I_BASLANGIC"				, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "I_BITIS"					, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "I_LIMIT_NUMARA"			, limitNumara);
					oMap.put(tableName, row, "I_ALT"					, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "I_UST"					, gnlLimitPr.getUst());
					oMap.put(tableName, row, "I_KARSILIK"				, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "I_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "I_AYNI_BOLUM"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniBolum()));
					oMap.put(tableName, row, "I_AYNI_KULLANICI"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniKullanici()));
					oMap.put(tableName, row, "I_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"						, gnlRolIslemIptalTx.getGDS());
					oMap.put(tableName, row, "I_YETKI_BITIS_TARIHI"     , gnlRolIslemIptalTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"						, "");
					oMap.put(tableName, row, "I_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "I_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "I_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "I_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
					
					tempIslemTanimKod = null;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S")){
					tempIslemTanimKod = gnlRolIslemIptalTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("G")){
					tempIslemTanimKod = gnlRolIslemIptalTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
				}else{
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", Color.WHITE));
					}					
				}
				
			}
			
			list = session.createCriteria(GnlRolislemiptalOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																				 .addOrder(Order.asc("id.islemTanimKod")).list();
			tempIslemTanimKod = null;
			tableName = "ROL_IPTAL_ONAY";
			tempTableName = "TEMP_ROL_IPTAL_ONAY";
			colorTableName ="ROL_IPTAL_ONAY_COLOR_DATA";
			row = 0;
			tempRow = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlRolislemiptalOnayTx gnlRolIslemIptalOnayTx 	= (GnlRolislemiptalOnayTx) iterator.next();
				rolNumara 										= gnlRolIslemIptalOnayTx.getId().getRolNumara();
				iMap.put("ROL_NUMARA", rolNumara);
				BigDecimal zamanNumara 							= gnlRolIslemIptalOnayTx.getId().getZamanNumara(); 
				BigDecimal limitNumara 							= gnlRolIslemIptalOnayTx.getId().getLimitNumara(); 
				GnlZamanPr gnlZamanPr							= getZaman(zamanNumara);
				GnlLimitPr gnlLimitPr							= getLimit(limitNumara);
				
				oMap.put(tableName, row, "IO_ISLEM_TANIM_KOD"		, gnlRolIslemIptalOnayTx.getId().getIslemTanimKod());
				oMap.put(tableName, row, "IO_ZAMAN_NUMARA"			, zamanNumara);
				oMap.put(tableName, row, "IO_BASLANGIC"				, gnlZamanPr.getBaslangic());
				oMap.put(tableName, row, "IO_BITIS"					, gnlZamanPr.getBitis());
				oMap.put(tableName, row, "IO_LIMIT_NUMARA"			, limitNumara);
				oMap.put(tableName, row, "IO_ALT"					, gnlLimitPr.getAlt());
				oMap.put(tableName, row, "IO_UST"					, gnlLimitPr.getUst());
				oMap.put(tableName, row, "IO_KARSILIK"				, gnlLimitPr.getKarsilik());
				oMap.put(tableName, row, "IO_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
				oMap.put(tableName, row, "IO_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniBolum()));
				oMap.put(tableName, row, "IO_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniKullanici()));
				oMap.put(tableName, row, "IO_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniRol()));
				oMap.put(tableName, row, "GDS"						, gnlRolIslemIptalOnayTx.getGDS());
				oMap.put(tableName, row, "IO_YETKI_BITIS_TARIHI"    , gnlRolIslemIptalOnayTx.getYetkiBitisTarihi());
				oMap.put(tableName, row, "DEL"						, "");
				oMap.put(tableName, row, "IO_ZAMAN_ACIKLAMA"        , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
                oMap.put(tableName, row, "IO_LIMIT_ACIKLAMA"        , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
                oMap.put(tableName, row, "IO_EKRAN_ACIKLAMA"        , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
                oMap.put(tableName, row, "IO_EKRAN_SAHIPLIGI"        ,DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
				Map<?, ?> map = oMap.getMap(tableName, row);
				
				if(map.get("GDS") != null && map.get("GDS").equals("D")){
					
					GnlRolIslemIptalOnayTxId id = new GnlRolIslemIptalOnayTxId();
					iMap.put("CLASS", GnlRolislemiptalOnayTx.class);
					id.setTxNo			(getPreviousTx(iMap));
					id.setRolNumara		(gnlRolIslemIptalOnayTx.getId().getRolNumara());
					id.setIslemTanimKod	(gnlRolIslemIptalOnayTx.getId().getIslemTanimKod());
					id.setZamanNumara	(gnlRolIslemIptalOnayTx.getId().getZamanNumara());
					id.setLimitNumara	(gnlRolIslemIptalOnayTx.getId().getLimitNumara());
					
					GnlRolislemiptalOnayTx oldGnlRolIslemIptalOnayTx = (GnlRolislemiptalOnayTx)session.get(GnlRolislemiptalOnayTx.class, id);
					rolNumara 							= oldGnlRolIslemIptalOnayTx.getId().getRolNumara();
					BigDecimal oldZamanNumara 			= oldGnlRolIslemIptalOnayTx.getId().getZamanNumara();
					BigDecimal oldLimitNumara 			= oldGnlRolIslemIptalOnayTx.getId().getLimitNumara();
					GnlZamanPr oldGnlZamanPr			= getZaman(zamanNumara);
					GnlLimitPr oldGnlLimitPr			= getLimit(limitNumara);
					
					oMap.put(tempTableName, tempRow, "IO_ISLEM_TANIM_KOD"		, oldGnlRolIslemIptalOnayTx.getId().getIslemTanimKod());
					oMap.put(tempTableName, tempRow, "IO_ZAMAN_NUMARA"			, oldZamanNumara);
					oMap.put(tempTableName, tempRow, "IO_BASLANGIC"				, oldGnlZamanPr.getBaslangic());
					oMap.put(tempTableName, tempRow, "IO_BITIS"					, oldGnlZamanPr.getBitis());
					oMap.put(tempTableName, tempRow, "IO_LIMIT_NUMARA"			, oldLimitNumara);
					oMap.put(tempTableName, tempRow, "IO_ALT"					, oldGnlLimitPr.getAlt());
					oMap.put(tempTableName, tempRow, "IO_UST"					, oldGnlLimitPr.getUst());
					oMap.put(tempTableName, tempRow, "IO_KARSILIK"				, oldGnlLimitPr.getKarsilik());
					oMap.put(tempTableName, tempRow, "IO_DOVIZ_KOD"				, oldGnlLimitPr.getDovizKod());
					oMap.put(tempTableName, tempRow, "IO_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemIptalOnayTx.getAyniBolum()));
					oMap.put(tempTableName, tempRow, "IO_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemIptalOnayTx.getAyniKullanici()));
					oMap.put(tempTableName, tempRow, "IO_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemIptalOnayTx.getAyniRol()));
					oMap.put(tempTableName, tempRow, "GDS"						, oldGnlRolIslemIptalOnayTx.getGDS());
					oMap.put(tempTableName, tempRow, "IO_YETKI_BITIS_TARIHI"    , oldGnlRolIslemIptalOnayTx.getYetkiBitisTarihi());
					oMap.put(tempTableName, tempRow, "DEL"						, "");
					oMap.put(tempTableName, tempRow, "IO_ZAMAN_ACIKLAMA"        , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+oldZamanNumara+""));
	                oMap.put(tempTableName, tempRow, "IO_LIMIT_ACIKLAMA"        , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+oldLimitNumara+""));
	                oMap.put(tempTableName, tempRow, "IO_EKRAN_ACIKLAMA"        , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+oldGnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
	                oMap.put(tempTableName, tempRow, "IO_EKRAN_SAHIPLIGI"        , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+oldGnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
					compareTables(oMap, oMap.getMap(tempTableName, tempRow), map, row, colorTableName, YELLOW);
					tempRow++;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S") && tempIslemTanimKod != null && gnlRolIslemIptalOnayTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "IO_ISLEM_TANIM_KOD"		, gnlRolIslemIptalOnayTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "IO_ZAMAN_NUMARA"			, zamanNumara);
					oMap.put(tableName, row, "IO_BASLANGIC"				, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "IO_BITIS"					, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "IO_LIMIT_NUMARA"			, limitNumara);
					oMap.put(tableName, row, "IO_ALT"					, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "IO_UST"					, gnlLimitPr.getUst());
					oMap.put(tableName, row, "IO_KARSILIK"				, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "IO_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "IO_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniBolum()));
					oMap.put(tableName, row, "IO_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniKullanici()));
					oMap.put(tableName, row, "IO_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"						, gnlRolIslemIptalOnayTx.getGDS());
					oMap.put(tableName, row, "IO_YETKI_BITIS_TARIHI"    , gnlRolIslemIptalOnayTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"						, "");
					oMap.put(tableName, row, "IO_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "IO_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "IO_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "IO_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
					tempIslemTanimKod = null;
				}else if(map.get("GDS") != null && map.get("GDS").equals("G") && tempIslemTanimKod != null && gnlRolIslemIptalOnayTx.getId().getIslemTanimKod().equals(tempIslemTanimKod)){
					
					oMap.put(tableName, row, "IO_ISLEM_TANIM_KOD"		, gnlRolIslemIptalOnayTx.getId().getIslemTanimKod());
					oMap.put(tableName, row, "IO_ZAMAN_NUMARA"			, zamanNumara);
					oMap.put(tableName, row, "IO_BASLANGIC"				, gnlZamanPr.getBaslangic());
					oMap.put(tableName, row, "IO_BITIS"					, gnlZamanPr.getBitis());
					oMap.put(tableName, row, "IO_LIMIT_NUMARA"			, limitNumara);
					oMap.put(tableName, row, "IO_ALT"					, gnlLimitPr.getAlt());
					oMap.put(tableName, row, "IO_UST"					, gnlLimitPr.getUst());
					oMap.put(tableName, row, "IO_KARSILIK"				, gnlLimitPr.getKarsilik());
					oMap.put(tableName, row, "IO_DOVIZ_KOD"				, gnlLimitPr.getDovizKod());
					oMap.put(tableName, row, "IO_AYNI_BOLUM"			, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniBolum()));
					oMap.put(tableName, row, "IO_AYNI_KULLANICI"		, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniKullanici()));
					oMap.put(tableName, row, "IO_AYNI_ROL"				, GuimlUtil.convertToCheckBoxValue(gnlRolIslemIptalOnayTx.getAyniRol()));
					oMap.put(tableName, row, "GDS"						, gnlRolIslemIptalOnayTx.getGDS());
					oMap.put(tableName, row, "IO_YETKI_BITIS_TARIHI"    , gnlRolIslemIptalOnayTx.getYetkiBitisTarihi());
					oMap.put(tableName, row, "DEL"						, "");
					oMap.put(tableName, row, "IO_ZAMAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+zamanNumara+""));
	                oMap.put(tableName, row, "IO_LIMIT_ACIKLAMA"         , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+limitNumara+""));
	                oMap.put(tableName, row, "IO_EKRAN_ACIKLAMA"         , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
	                oMap.put(tableName, row, "IO_EKRAN_SAHIPLIGI"         , DALUtil.getResult("SELECT c.aciklama FROM bnspr.muh_islem_tanim_pr a LEFT OUTER JOIN gnl_ekran_sahipligi b ON to_char (a.kod) = b.ekran_kod LEFT OUTER JOIN gnl_bolum_kod_pr c ON b.bolum_kod = c.kod WHERE a.kod =  "+gnlRolIslemIptalOnayTx.getId().getIslemTanimKod()+""));
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
					
					tempIslemTanimKod = null;
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("S")){
					tempIslemTanimKod = gnlRolIslemIptalOnayTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", BLUE));
					}
					
				}else if(map.get("GDS") != null && map.get("GDS").equals("G")){
					tempIslemTanimKod = gnlRolIslemIptalOnayTx.getId().getIslemTanimKod();
					
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", GREEN));
					}
				}else{
					for (Object key : map.keySet()) {
						oMap.put(colorTableName, row, key.toString(), getTableCellColorData("setBackground", Color.WHITE));
					}					
				}
				
			}

			//ilk defa kayit giriliyorsa, ekrandan girilen rolNumarayi ata
			if(rolNumara == null) {
				rolNumara = iMap.getBigDecimal("ROL_NUMARA");
			}
			
			oMap.put("ROL_NUMARA"		,  rolNumara);
			oMap.put("DI_ROL_NUMARA"	,  LovHelper.diLovF(rolNumara, "9922/LOV_ROL", "TANIM", "NUMARA"));
			oMap.put("C", new Color(255,0,0));
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static GMMap getTableCellColorData(String property, Color color){
		GMMap oMap = new GMMap();
		oMap.put(property, color);
		return oMap;
	}
	
	private static BigDecimal getPreviousTx(GMMap oMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal oldTx = (BigDecimal) session.createCriteria((oMap.get("CLASS")== null ? GnlRolislemTx.class : (Class) oMap.get("CLASS")))
									.add(Restrictions.lt("id.txNo", oMap.getBigDecimal("TRX_NO")))
									.add(Restrictions.eq("id.rolNumara", oMap.getBigDecimal("ROL_NUMARA")))
									.setProjection(Projections.projectionList().add(Projections.max("id.txNo"))).uniqueResult();
			return oldTx;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static void compareTables(GMMap oMap, Map<?,?> oldTable, Map<?,?> newTable, int newTableRow, String colorTableName, Color color){
		
		for(Object key : newTable.keySet()){
			if(compareTwoStringForTable(oldTable.get(key), newTable.get(key))){
				oMap.put(colorTableName, newTableRow, key.toString(), getTableCellColorData("setBackground", color));		
			}
			else{
				oMap.put(colorTableName, newTableRow, key.toString(), getTableCellColorData("setBackground", Color.WHITE));
			}
		}
		
	}
	
	private static boolean compareTwoStringForTable(Object oldString, Object newString){
		if(oldString == null && newString != null)
			return true;
		else if(oldString != null && !oldString.equals(newString))
			return true;
		else
			return false;
	}
	@GraymoundService("BNSPR_TRN9922_GET_PREVIOUS_INFO")
	public static GMMap getPreviousInfo(GMMap iMap) {
		try{
			
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String gds = iMap.getString("GDS")!= null ? iMap.getString("GDS") : "";
				
			if(gds.equals("D") ){
				
				String tempTableName = "ROL_URUN_ISLEM_VIEW";
				int tempRow = 0;
				
				GnlRolIslemTxId id = new GnlRolIslemTxId();
				id.setTxNo			(getPreviousTx(iMap));
				id.setRolNumara		(iMap.getBigDecimal("ROL_NUMARA"));
				id.setIslemTanimKod	(iMap.getBigDecimal("ISLEM_TANIM_KOD"));
				id.setZamanNumara	(iMap.getBigDecimal("ZAMAN_NUMARA"));
				id.setLimitNumara	(iMap.getBigDecimal("LIMIT_NUMARA"));
				
				GnlRolislemTx oldGnlRolIslemTx = (GnlRolislemTx) session.get(GnlRolislemTx.class, id);
				BigDecimal oldZamanNumara 			= oldGnlRolIslemTx.getId().getZamanNumara();
				BigDecimal oldLimitNumara 			= oldGnlRolIslemTx.getId().getLimitNumara();
				GnlZamanPr oldGnlZamanPr			= getZaman(iMap.getBigDecimal("ZAMAN_NUMARA"));
				GnlLimitPr oldGnlLimitPr			= getLimit(iMap.getBigDecimal("LIMIT_NUMARA"));
				
				oMap.put(tempTableName, tempRow, "Y_ISLEM_TANIM_KOD"	, oldGnlRolIslemTx.getId().getIslemTanimKod());
				oMap.put(tempTableName, tempRow, "Y_ZAMAN_NUMARA"		, oldZamanNumara);
				oMap.put(tempTableName, tempRow, "Y_BASLANGIC"			, oldGnlZamanPr.getBaslangic());
				oMap.put(tempTableName, tempRow, "Y_BITIS"				, oldGnlZamanPr.getBitis());
				oMap.put(tempTableName, tempRow, "Y_LIMIT_NUMARA"		, oldLimitNumara);
				oMap.put(tempTableName, tempRow, "Y_ALT"				, oldGnlLimitPr.getAlt());
				oMap.put(tempTableName, tempRow, "Y_UST"				, oldGnlLimitPr.getUst());
				oMap.put(tempTableName, tempRow, "Y_DOVIZ_KOD"			, oldGnlRolIslemTx.getDovizKod());
				oMap.put(tempTableName, tempRow, "Y_DOGRULAMA"			, oldGnlRolIslemTx.getDogrulama());
				oMap.put(tempTableName, tempRow, "Y_ONAY"				, oldGnlRolIslemTx.getOnay());
				oMap.put(tempTableName, tempRow, "Y_IPTAL_ONAY"			, oldGnlRolIslemTx.getIptalOnay());
				oMap.put(tempTableName, tempRow, "GDS"					, oldGnlRolIslemTx.getGDS());
				oMap.put(tempTableName, tempRow, "Y_YETKI_BITIS_TARIHI" , oldGnlRolIslemTx.getYetkiBitisTarihi());
				oMap.put(tempTableName, tempRow, "DEL"					, "");
				oMap.put(tempTableName, tempRow, "O_ZAMAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_zaman_pr where numara = "+oldZamanNumara+""));
                oMap.put(tempTableName, tempRow, "O_LIMIT_ACIKLAMA"     , DALUtil.getResult("select aciklama from gnl_limit_pr where kod = "+oldLimitNumara+""));
                oMap.put(tempTableName, tempRow, "O_EKRAN_ACIKLAMA"     , DALUtil.getResult("select aciklama from muh_islem_tanim_pr where kod = "+oldGnlRolIslemTx.getId().getRolNumara()+""));
                oMap.put(tempTableName, tempRow, "F_MENUDE_GORUNTULENMESIN", GuimlUtil.convertToCheckBoxValue(oldGnlRolIslemTx.getFMenudeGoruntulenmesin()));
			}
			
		return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
