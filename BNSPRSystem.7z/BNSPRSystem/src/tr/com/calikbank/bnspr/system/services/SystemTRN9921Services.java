package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlErisimRol;
import tr.com.calikbank.bnspr.dao.GnlErisimRolTx;
import tr.com.calikbank.bnspr.dao.GnlErisimRolTxId;
import tr.com.calikbank.bnspr.dao.GnlErisimTx;
import tr.com.calikbank.bnspr.dao.GnlErisimTxId;
import tr.com.calikbank.bnspr.dao.GnlKullaniciTx;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9921Services {
  @GraymoundService("BNSPR_TRN9921_SAVE")
    public static GMMap update(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            GnlKullaniciTx gnlKullaniciTx = (GnlKullaniciTx) session.get(GnlKullaniciTx.class , iMap.getBigDecimal("TRX_NO"));
            if (gnlKullaniciTx == null){
                gnlKullaniciTx = new GnlKullaniciTx();
                gnlKullaniciTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            }
            gnlKullaniciTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            gnlKullaniciTx.setKodu(iMap.getString("KULLANICI_KODU"));
            gnlKullaniciTx.setPersonelNumara(GuimlUtil.getTableCellBigDecimal(iMap.get("PERSONEL_NUMARA")));
            gnlKullaniciTx.setAdi(iMap.getString("ADI"));
            gnlKullaniciTx.setSoyadi(iMap.getString("SOYADI"));
            gnlKullaniciTx.setCalisilanBolum(iMap.getString("CALISILAN_BOLUM"));
            gnlKullaniciTx.setCalisilanSube(iMap.getString("CALISILAN_SUBE"));
            gnlKullaniciTx.setGorevKodu(iMap.getString("GOREV_KODU"));
            gnlKullaniciTx.setTur(iMap.getString("TUR"));
            gnlKullaniciTx.setEmail(iMap.getString("EMAIL"));
            gnlKullaniciTx.setKanalKod(iMap.getString("KANAL_KODU"));
            gnlKullaniciTx.setKanalAltKod(iMap.getString("KANAL_ALT_KODU"));
            gnlKullaniciTx.setKapanmaTar(iMap.getDate("KAPANMA_TARIHI"));
            
            session.saveOrUpdate(gnlKullaniciTx);
            
            session.flush();
            iMap.put("TRX_NAME" , "9921");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
  @GraymoundService("BNSPR_TRN9921_GET_INFO")
  public static Map<?, ?> getInfo(GMMap iMap) {
      Connection conn = null;
      CallableStatement stmt = null;
      ResultSet rSet = null;
      try{
          GMMap oMap = new GMMap();
          Session session = DAOSession.getSession("BNSPRDal");
          GnlKullaniciTx gnlKullanici = (GnlKullaniciTx) session.createCriteria(GnlKullaniciTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
          
          oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
          oMap.put("KULLANICI_KODU" , gnlKullanici.getKodu());
          oMap.put("PERSONEL_NUMARA" , gnlKullanici.getPersonelNumara());
          oMap.put("ADI" , gnlKullanici.getAdi());
          oMap.put("SOYADI" , gnlKullanici.getSoyadi());
          oMap.put("CALISILAN_BOLUM" , gnlKullanici.getCalisilanBolum());
          oMap.put("CALISILAN_SUBE" , gnlKullanici.getCalisilanSube());
          oMap.put("GOREV_KODU" , gnlKullanici.getGorevKodu());
          oMap.put("TUR" , gnlKullanici.getTur());
          oMap.put("EMAIL" , gnlKullanici.getEmail());
          oMap.put("KANAL_KODU" , gnlKullanici.getKanalKod());
          oMap.put("KANAL_ALT_KODU" , gnlKullanici.getKanalAltKod());
          oMap.put("KAPANMA_TARIHI" , gnlKullanici.getKapanmaTar());
          oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
          return oMap;
      } catch (Exception e){
          throw ExceptionHandler.convertException(e);
      } finally{
          GMServerDatasource.close(rSet);
          GMServerDatasource.close(stmt);
          GMServerDatasource.close(conn);
      }
  }
  
  }
