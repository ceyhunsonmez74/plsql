package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.GnlGrupKodlariTx;
import tr.com.aktifbank.bnspr.dao.GnlGrupKodlariTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
@SuppressWarnings("deprecation")
public class SystemTRN9971Services {
 
	@GraymoundService("BNSPR_TRN9971_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName="TABLE_MODEL";
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", oMap));
		oMap.put("MODEL_DATA", 0, "VALUE", "A��k");
		oMap.put("MODEL_DATA", 0, "NAME" , "A");
		oMap.put("MODEL_DATA", 1, "VALUE", "Kapal�");
		oMap.put("MODEL_DATA", 1, "NAME" , "K");
		oMap.put(tableName, iMap.get(tableName));
		oMap.putAll(getRecords(iMap));
		int i=0;
		while(i<oMap.getSize(tableName)){
			String kod= oMap.getString(tableName,i,"SEKTOR_KODU");
			oMap.put(tableName, i,"SEKTOR",LovHelper.diLov(kod,"9971/LOV_SEKTOR", "SEKTOR_ADI"));
			i++;
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9971_GET_RECORDS")
	public static GMMap getRecords(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE_MODEL";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN9971.grup_kodlari_liste}");
			stmt.registerOutParameter(1, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_TRN9971_GET_GRUP_KOD")
	public static GMMap getGrupKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal kod;
		GMMap idMap = new GMMap();
		try {

			String tableName = "GRUP_KODLARI";
			idMap.put("TABLE_NAME", tableName);
			kod = (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", idMap).get("ID");

			int tableSize = iMap.getSize(tableName);
			for (int i = 0; i < tableSize-1; i++) {
				if (iMap.getBigDecimal(tableName, i, "KOD").equals(kod)) {
					kod = (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", idMap).get("ID");
				}
			}
			oMap.put("GRUP_KOD", kod);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9971_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		String tableName="TABLE_MODEL";
		try {
			Session session= DAOSession.getSession("BNSPRDal");
			int row = 0;
			while(row<iMap.getSize(tableName)){
				GnlGrupKodlariTxId gnlGrupKodlariTxId= new GnlGrupKodlariTxId();
				gnlGrupKodlariTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlGrupKodlariTxId.setKod(iMap.getString(tableName, row, "KOD"));
				GnlGrupKodlariTx gnlGrupKodlariTx= new GnlGrupKodlariTx();
				
				gnlGrupKodlariTx.setId(gnlGrupKodlariTxId);
				gnlGrupKodlariTx.setAciklama(iMap.getString(tableName,row,"ACIKLAMA"));
				gnlGrupKodlariTx.setDurumKodu(iMap.getString(tableName,row,"DURUM_KODU"));
				gnlGrupKodlariTx.setSektorKodu(iMap.getString(tableName, row, "SEKTOR_KODU"));
				session.saveOrUpdate(gnlGrupKodlariTx);
				row++;
			}
			session.flush();
			iMap.put("TRX_NAME", "9971");
			
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN9971_KONTROL_GRUP_KOD")
	public static GMMap kontrolGrupKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tableName = "GRUP_KODLARI";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {

				if (iMap.getString(tableName, i, "KOD") == null || iMap.getString(tableName, i, "KOD").isEmpty()) {
					oMap.put("MESSAGE_NO", new java.math.BigDecimal(330));
					oMap.put("P1", "Kod");
					throw new GMRuntimeException(0, (String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_ERROR_MESSAGE", oMap).get("ERROR_MESSAGE"));
				}

				if (iMap.getString(tableName, i, "ACIKLAMA") == null
						|| iMap.getString(tableName, i, "ACIKLAMA").isEmpty()) {
					oMap.put("MESSAGE_NO", new java.math.BigDecimal(330));
					oMap.put("P1", "Aciklama");
					throw new GMRuntimeException(0, (String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_ERROR_MESSAGE", oMap).get("ERROR_MESSAGE"));
				}

				for (int j = 0; j < list.size(); j++) {
					if (iMap.getString(tableName, i, "KOD").equals(iMap.getString(tableName, j, "KOD")) & i != j) {
						throw new ConstraintViolationException(null, null, null);
					}
				}
			}
			return oMap;
		} catch (ConstraintViolationException ex) {

			oMap.put("MESSAGE_NO", new java.math.BigDecimal(1720));
			throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", oMap)
					.get("ERROR_MESSAGE"));
		}
	}
}
