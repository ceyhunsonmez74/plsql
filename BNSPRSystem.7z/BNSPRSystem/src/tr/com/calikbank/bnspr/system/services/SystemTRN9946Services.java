 package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;


import tr.com.aktifbank.bnspr.dao.GnlScfUrunAltGrubuTx;
import tr.com.aktifbank.bnspr.dao.GnlScfUrunAltGrubuTxId;
import tr.com.aktifbank.bnspr.dao.GnlVadeliScfOraniTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;


import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9946Services {
	
	@GraymoundService("BNSPR_TRN9946_ALT_URUN_GRUP_LISTE")
	public static Map<?, ?> getScfOranBilgi(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
		    conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN9946.TRN9946_sorgula(?)}");	
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("URUN_GRUP_KOD"));
			stmt.execute();
			String tableName = "TBL_LIST";
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);
			return oMap;
			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN9946_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
	        List<?> list = (List<?>)session.createCriteria(GnlScfUrunAltGrubuTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlScfUrunAltGrubuTx gnlScfUrunAltGrubuTx = (GnlScfUrunAltGrubuTx)iterator.next();
				session.delete(gnlScfUrunAltGrubuTx);
			}
						
			session.flush();
			
			String tableName = "TBL_LIST";
			for (int row = 0; row < iMap.getSize(tableName); row++) {		
						
				GnlScfUrunAltGrubuTx gnlScfUrunAltGrubuTx = new GnlScfUrunAltGrubuTx();
				GnlScfUrunAltGrubuTxId gnlScfUrunAltGrubuTxId = new GnlScfUrunAltGrubuTxId();
				gnlScfUrunAltGrubuTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlScfUrunAltGrubuTxId.setKod(iMap.getString(tableName, row, "KOD"));
				gnlScfUrunAltGrubuTx.setId(gnlScfUrunAltGrubuTxId);
				
				gnlScfUrunAltGrubuTx.setUrunGrupKod(iMap.getString("URUN_GRUP_KOD"));
				gnlScfUrunAltGrubuTx.setAciklama(iMap.getString(tableName, row,"ACIKLAMA"));
				if (iMap.getString(tableName, row, "UST_GRUP_MU") == null || iMap.getString(tableName, row, "UST_GRUP_MU").equals("0"))
					gnlScfUrunAltGrubuTx.setUstGrupMu("H");
				else
					gnlScfUrunAltGrubuTx.setUstGrupMu("E");
				gnlScfUrunAltGrubuTx.setUstGrupKod(iMap.getString(tableName, row, "UST_GRUP_KOD"));
				session.save(gnlScfUrunAltGrubuTx);		
				
			}
		   
			session.flush();
			iMap.put("TRX_NAME", "9946");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		} catch (NonUniqueObjectException e) {
			iMap.put("HATA_NO", new BigDecimal(716));
			iMap.put("P1", "Kod");
			return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}


	@GraymoundService("BNSPR_TRN9946_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TBL_LIST";
			List<?> gnlScfUrunAltGrubuList = (List<?>) session.createCriteria(GnlScfUrunAltGrubuTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int row = 0;
			
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			
			for (Iterator<?> iterator = gnlScfUrunAltGrubuList.iterator(); iterator.hasNext();row++) {
				GnlScfUrunAltGrubuTx gnlScfUrunAltGrubuTx = (GnlScfUrunAltGrubuTx) iterator.next();
				GnlScfUrunAltGrubuTxId gnlScfUrunAltGrubuTxId = gnlScfUrunAltGrubuTx.getId();
				oMap.put(tableName, row, "KOD", gnlScfUrunAltGrubuTxId.getKod());
				oMap.put(tableName, row, "ACIKLAMA", gnlScfUrunAltGrubuTx.getAciklama());
				oMap.put("URUN_GRUP_KOD", gnlScfUrunAltGrubuTx.getUrunGrupKod());
				if (gnlScfUrunAltGrubuTx.getUstGrupMu().equals("E"))
					oMap.put(tableName, row, "UST_GRUP_MU", 1);
				else
					oMap.put(tableName, row, "UST_GRUP_MU", 0);
				oMap.put(tableName, row, "UST_GRUP_KOD", gnlScfUrunAltGrubuTx.getUstGrupKod());
			}
			oMap.put("ACIKLAMA", LovHelper.diLov(oMap.getString("URUN_GRUP_KOD"), "9946/LOV_URUN_GRUP_KOD", "ACIKLAMA"));
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	
	
}
