package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AktiviteIzleme {
	@GraymoundService("BNSPR_AKTIVITE_IZLEME_INITIALIZE")  
	public static GMMap initialize(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			iMap.put("KOD", "AKT_TAKIP_BOLUM");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BOLUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKT_GIRIS_MODUL");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("MODUL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKT_GIRIS_PROJE");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("PROJE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
			iMap.put("KOD", "AKT_GIRIS_MESAI_YERI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("MESAI_YERI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			iMap.put("KOD", "AKT_GIRIS_MESAI_TIPI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("MESAI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			iMap.put("KOD", "AKT_GIRIS_AKTTIPI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			 
			iMap.put("KOD", "AKT_GIRIS_ISGUCU_TIPI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("ISGUCU_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKT_GIRIS_YONETICI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("YONETICI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_AKTIVITE_IZLEME_GET_KULLANICI", iMap.put("BOLUM", "")));
			
			iMap.put("KOD", "AKT_TAKIP_ISBIRIMI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("ISBIRIMI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			Calendar cal = GregorianCalendar.getInstance();
			
			cal.setTime(new java.util.Date());
			cal.set(Calendar.WEEK_OF_MONTH,cal.get(Calendar.WEEK_OF_MONTH));
			cal.set(Calendar.DAY_OF_WEEK,2);
			
			oMap.put("BAS_TARIH", cal.getTime());
			cal.add(Calendar.DAY_OF_MONTH, 6);
			oMap.put("SON_TARIH",cal.getTime()) ;
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_IZLEME_GET_KULLANICI")
	public static GMMap getKullanici(GMMap iMap){
		GMMap oMap = new GMMap();
		
		StringBuilder query = new StringBuilder();
		
		query.append("Select k.kod kullanici,").
			  append(" k.ad ||' '|| k.soyad adi_soyadi,").
			  append("Pkg_Genel_Pr.bolum_adi ( k.bolum_kod ) bolum ").
			  append("From gnl_kullanici k ").
			  append("Where Exists ( Select 1 ").
			  append("From gnl_param_text t ").
			  append("where t.kod = 'AKT_TAKIP_BOLUM' ").
			  append("And t.key1 = k.bolum_kod ) ").
			  append("And k.bolum_kod = Nvl (").
			  append("".equals(iMap.getString("BOLUM"))?null:iMap.getString("BOLUM")).
			  append(", k.bolum_kod )").
			  append("Order By 1");

		return DALUtil.fillComboBox(oMap, "KULLANICI", true, query.toString());
	}
	
	@GraymoundService("BNSPR_AKTIVITE_IZLEME_GET_AKTIVITE_TOPLAM")
	public static GMMap getAktiviteToplam(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_bnspr_aktivite.RC_Aktivite_Toplam(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }");
			
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KULLANICI"));
			stmt.setDate(i++,iMap.get("BAS_TARIH")!=null?new Date(iMap.getDate("BAS_TARIH").getTime()):null);
			stmt.setDate(i++,iMap.get("SON_TARIH")!=null?new Date(iMap.getDate("SON_TARIH").getTime()):null);
			stmt.setString(i++, iMap.getString("BOLUM"));
			stmt.setString(i++, iMap.getString("YONETICI"));
			stmt.setString(i++, iMap.getString("PROJE"));
			stmt.setString(i++, iMap.getString("MODUL_TUR_KOD"));
			stmt.setString(i++, iMap.getString("ISSUE_NO"));
			stmt.setString(i++, iMap.getString("TIP"));
			stmt.setString(i++, iMap.getString("ISGUCU_TIP"));
			stmt.setString(i++, iMap.getString("MESAI_TUR"));
			stmt.setString(i++, iMap.getString("MESAI_YER"));
			stmt.setString(i++, iMap.getString("ISBIRIMI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAS_SURE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SON_SURE"));
			
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "TOPLAMLAR");
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_IZLEME_GET_AKTIVITE_DETAY")
	public static GMMap getAktiviteDetay(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_bnspr_aktivite.RC_Aktivite_Detay(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }");
			
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KULLANICI"));
			stmt.setDate(i++,iMap.get("TARIH")!=null?new Date(iMap.getDate("TARIH").getTime()):null);
			stmt.setString(i++, iMap.getString("BOLUM"));
			stmt.setString(i++, iMap.getString("YONETICI"));
			stmt.setString(i++, iMap.getString("PROJE"));
			stmt.setString(i++, iMap.getString("MODUL"));
			stmt.setString(i++, iMap.getString("ISSUE_NO"));
			stmt.setString(i++, iMap.getString("TIP"));
			stmt.setString(i++, iMap.getString("ISGUCU_TIP"));
			stmt.setString(i++, iMap.getString("MESAI_TUR"));
			stmt.setString(i++, iMap.getString("MESAI_YER"));
			stmt.setString(i++, iMap.getString("TAKIP_BOLUM"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAS_SURE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SON_SURE"));
			
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "DETAY");
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIVITE_IZLEME_GET_PREVIOUS_WEEK")
	public static GMMap getPreviousWeek(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			Calendar cal = GregorianCalendar.getInstance();
			
			cal.setTime(iMap.getDate("BAS_TARIH"));
			cal.set(Calendar.WEEK_OF_MONTH,cal.get(Calendar.WEEK_OF_MONTH)-1);
			cal.set(Calendar.DAY_OF_WEEK,2);
			
			oMap.put("BAS_TARIH", cal.getTime());
			cal.add(Calendar.DAY_OF_MONTH, 6);
			oMap.put("SON_TARIH",cal.getTime()) ;
			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_AKTIVITE_IZLEME_GET_NEXT_WEEK")
	public static GMMap getNextWeek(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			Calendar cal = GregorianCalendar.getInstance();
			
			cal.setTime(iMap.getDate("SON_TARIH"));
			cal.set(Calendar.WEEK_OF_MONTH,cal.get(Calendar.WEEK_OF_MONTH)+1);
			cal.set(Calendar.DAY_OF_WEEK,2);

			oMap.put("BAS_TARIH", cal.getTime());
			cal.add(Calendar.DAY_OF_MONTH, 6);
			oMap.put("SON_TARIH",cal.getTime()) ;
			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		return oMap;
	}

}
