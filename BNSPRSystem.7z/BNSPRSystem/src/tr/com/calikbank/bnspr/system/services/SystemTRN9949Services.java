package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.quartz.CronExpression;

import tr.com.aktifbank.bnspr.dao.GnlJsTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlJsTanimPr;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9949Services {
	
	@GraymoundService("BNSPR_TRN9949_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			controlCronExpression(iMap.getString("CRON_EXPRESSION"));
			controlSchedulerInstance(iMap);
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlJsTanimTx jobTanimTx = (GnlJsTanimTx) session.get(GnlJsTanimTx.class, trxNo);
			
			if(jobTanimTx == null){
				jobTanimTx = new GnlJsTanimTx();
				jobTanimTx.setTxNo(trxNo);
			}
			
			jobTanimTx.setJobId(iMap.getBigDecimal("JOB_ID"));
			jobTanimTx.setJobAdi(iMap.getString("JOB_NAME"));
			jobTanimTx.setTatilGunuCalissin(iMap.getString("TATIL_GUNU"));
			jobTanimTx.setConcurrencyAllowed(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CONCURRENCY_ALLOWED")));
			jobTanimTx.setAciklama(iMap.getString("DESCRIPTION"));
			jobTanimTx.setCronExpression(iMap.getString("CRON_EXPRESSION"));
			
			if("NEW".equals(iMap.getString("MODE"))){
				jobTanimTx.setGDS("G");
			}else if("EDIT".equals(iMap.getString("MODE"))){
				jobTanimTx.setGDS("D");
			}else if("DELETE".equals(iMap.getString("MODE"))){
				jobTanimTx.setGDS("S");
			}
			
			String jobTurKod = iMap.getString("JOB_TUR_KOD");
			jobTanimTx.setJobTurKod(jobTurKod);
			
			GMMap serviceMap = (GMMap) iMap.get("SERVICE_MAP");
			if(serviceMap != null){
				if("1".equals(jobTurKod)){
					jobTanimTx.setBatchGrupKod(serviceMap.getBigDecimal("BATCH_NUM"));
				}else if("300".equals(jobTurKod)){
					jobTanimTx.setServiceName(serviceMap.getString("SERVICE_NAME"));
				}
				jobTanimTx.setAfterAction(serviceMap.getString("AFTER_ACTION_NAME"));
			}
				
			jobTanimTx.setSchedId((short)iMap.getInt("SCHED_ID"));
			jobTanimTx.setOldSchedId((short)iMap.getInt("OLD_SCHED_ID"));
			jobTanimTx.setMisfirePolicy((short)iMap.getInt("MISFIRE_POLICY"));
			jobTanimTx.setRecovery(iMap.getBoolean("RECOVERY"));
			jobTanimTx.setJobOwnerId(iMap.getString("JOB_OWNER_ID")!= null && !iMap.getString("JOB_OWNER_ID").equals("") 
					? new BigDecimal(iMap.getString("JOB_OWNER_ID")) : null);
			session.saveOrUpdate(jobTanimTx);
			session.flush();
			
			iMap.put("TRX_NAME", "9949");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static void  controlSchedulerInstance(GMMap iMap) {
		if("EDIT".equals(iMap.getString("MODE"))){
			Session session = DAOSession.getSession("BNSPRDal");
			GnlJsTanimPr gnlJsTanimPr=(GnlJsTanimPr) session.createCriteria(GnlJsTanimPr.class).add(Restrictions.eq("jobAdi", iMap.getString("JOB_NAME"))).uniqueResult();
			if(gnlJsTanimPr.getSchedId()!=iMap.getInt("OLD_SCHED_ID")){
				throw new GMRuntimeException(0, "Old Scheduler ID bilgisi guncel degil!");
			}			
		}
	}
	
	private static void controlCronExpression(String cronExpression){
		if(cronExpression==null || !CronExpression.isValidExpression(cronExpression)) {
			throw new GMRuntimeException(0, "Cron Ifadesi Gecerli Degil!");
		}
	}
	
	@GraymoundService("BNSPR_TRN9949_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			GnlJsTanimTx jobTanimTx = (GnlJsTanimTx) session.get(GnlJsTanimTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("REMOVE_JOB", false);
			
			if("G".equals(jobTanimTx.getGDS())){
				oMap.put("MODE", "NEW");
			}else if("D".equals(jobTanimTx.getGDS())){
				oMap.put("MODE", "EDIT");
			}else if("S".equals(jobTanimTx.getGDS())){
				oMap.put("MODE", "DELETE");
				oMap.put("REMOVE_JOB", true);
			}
			
			oMap.put("JOB_NAME", jobTanimTx.getJobAdi());
			oMap.put("CRON_EXPRESSION", jobTanimTx.getCronExpression());
			oMap.put("TATIL_GUNU", jobTanimTx.getTatilGunuCalissin());
			oMap.put("CONCURRENCY_ALLOWED", GuimlUtil.convertToCheckBoxSelected(jobTanimTx.getConcurrencyAllowed()));
			oMap.put("DESCRIPTION", jobTanimTx.getAciklama());
			
			String jobTurKod = jobTanimTx.getJobTurKod();
			oMap.put("JOB_TUR_KOD", jobTurKod);
			
			GMMap serviceMap = new GMMap();
			if("1".equals(jobTurKod)){
				serviceMap.put("BATCH_NUM", jobTanimTx.getBatchGrupKod());
			}else if("300".equals(jobTurKod)){
				serviceMap.put("SERVICE_NAME", jobTanimTx.getServiceName());
			}
			serviceMap.put("AFTER_ACTION_NAME", jobTanimTx.getAfterAction());
			oMap.put("SERVICE_MAP", serviceMap);
			
			oMap.put("SCHED_ID", String.valueOf(jobTanimTx.getSchedId()));
			oMap.put("OLD_SCHED_ID", String.valueOf(jobTanimTx.getOldSchedId()));
			oMap.put("MISFIRE_POLICY", String.valueOf(jobTanimTx.getMisfirePolicy()));
			oMap.put("RECOVERY", jobTanimTx.getRecovery().booleanValue());
			oMap.put("JOB_OWNER_ID", String.valueOf(jobTanimTx.getJobOwnerId()));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9949_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
			GMMap infoMap = getInfo(iMap);
			
			GMMap jobMap = new GMMap();
			jobMap.put("JOB_NAME", infoMap.getString("JOB_NAME"));
			jobMap.put("SCHED_ID", infoMap.getInt("SCHED_ID"));
			
			if(!"DELETE".equals(infoMap.getString("MODE"))){
				
				jobMap.put("CRON_EXPRESSION", infoMap.getString("CRON_EXPRESSION"));
				jobMap.put("TATIL_GUNU", infoMap.getString("TATIL_GUNU_CALISSIN"));
				jobMap.put("CONCURRENCY_ALLOWED", infoMap.getBoolean("CONCURRENCY_ALLOWED"));
				jobMap.put("DESCRIPTION", infoMap.getString("DESCRIPTION"));
				jobMap.put("JOB_TUR_KOD", infoMap.getString("JOB_TUR_KOD"));
				jobMap.put("SERVICE_MAP", infoMap.get("SERVICE_MAP"));
				jobMap.put("MISFIRE_POLICY", infoMap.getInt("MISFIRE_POLICY"));
				jobMap.put("RECOVERY", infoMap.getBoolean("RECOVERY"));
				jobMap.put("JOB_OWNER_ID", infoMap.getBigDecimal("JOB_OWNER_ID"));
 				if("NEW".equals(infoMap.getString("MODE"))){
					GMServiceExecuter.execute("BNSPR_PAR9949_CREATE_JOB", jobMap);
					GMServiceExecuter.execute("BNSPR_PAR9949_PAUSE_JOB", jobMap);
				}else if("EDIT".equals(infoMap.getString("MODE"))){
					jobMap.put("OLD_SCHED_ID", infoMap.getInt("OLD_SCHED_ID"));
					GMServiceExecuter.execute("BNSPR_PAR9949_UPDATE_JOB", jobMap);
					GMServiceExecuter.execute("BNSPR_PAR9949_PAUSE_JOB", jobMap);
				}
				
			}else{
				GMServiceExecuter.execute("BNSPR_PAR9949_DELETE_JOB", jobMap);
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
