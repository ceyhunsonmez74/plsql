package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.biff.drawing.ComboBox;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.OpsBiRaporParam;
import tr.com.aktifbank.bnspr.dao.OpsBiRaporParamTx;
import tr.com.aktifbank.bnspr.dao.OpsBiRaporParamTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9950Services {

	@GraymoundService("BNSPR_TRN9950_GET_COMBO_PARAMETERS")
	public static GMMap initiazlize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			iMap.put("KOD", "OPS_RAPOR_AKTIF_PASIF");
			iMap.put("KEY2", "A");
			oMap.put("AKTIF_PASIF_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_ISLEM_GONDERIM_KODU");
			iMap.put("KEY2", "A");
			oMap.put("ISLEM_GONDERIM_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_IUD_ACTION");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_IUD_ACTION", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_GLOBAL_RAPOR");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_GLOBAL_RAPOR_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_KAPASITE_RAPOR");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_KAPASITE_RAPOR_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_OTOMATIK");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_OTOMATIK_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_KANAL");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_KANAL_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_ALT_KANAL");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_ALT_KANAL_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "OPS_RAPOR_ISLEM_TIPI");
			iMap.put("KEY2", "A");
			oMap.put("OPS_RAPOR_ISLEM_TIPI_DETAY", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			oMap.put("AKTIF_PASIF_FILTRE", oMap.get("AKTIF_PASIF_DETAY"));
			oMap.put("AKTIF_PASIF_TABLE", oMap.get("AKTIF_PASIF_DETAY"));
			oMap.put("KAPASITE_RAPOR_TABLE", oMap.get("OPS_RAPOR_KAPASITE_RAPOR_DETAY"));
			oMap.put("GLOBAL_RAPOR_TABLE", oMap.get("OPS_RAPOR_GLOBAL_RAPOR_DETAY"));
			oMap.put("RAPOR_OTOMATIK_TABLE", oMap.get("OPS_RAPOR_OTOMATIK_DETAY"));
			oMap.put("RAPOR_KANAL_TABLE", oMap.get("OPS_RAPOR_KANAL_DETAY"));

			oMap.put("RAPOR_ALT_KANAL_TABLE", oMap.get("OPS_RAPOR_ALT_KANAL_DETAY"));
			oMap.put("RAPOR_ISLEM_TIPI_TABLE", oMap.get("OPS_RAPOR_ISLEM_TIPI_DETAY"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN9950_GET_REC")
	public static GMMap getRec(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria crteria = session.createCriteria(OpsBiRaporParam.class);

			if (isNotExistAndNull(iMap, "DEP_TXT"))
				crteria.add(Restrictions.ilike("depTxt", addLike(iMap.getString("DEP_TXT"))));
			if (isNotExistAndNull(iMap, "UNIT_TXT"))
				crteria.add(Restrictions.ilike("unitTxt", addLike(iMap.getString("UNIT_TXT"))));
			if (isNotExistAndNull(iMap, "SERV_TXT"))
				crteria.add(Restrictions.ilike("servTxt", addLike(iMap.getString("SERV_TXT"))));
			if (isNotExistAndNull(iMap, "IND_TXT"))
				crteria.add(Restrictions.ilike("indTxt", addLike(iMap.getString("IND_TXT"))));
			if (isNotExistAndNull(iMap, "IND_TXT_RANK"))
				crteria.add(Restrictions.eq("indTxtRank", iMap.getBigDecimal("IND_TXT_RANK")));
			if (isNotExistAndNull(iMap, "AKTIF_PASIF_FILTRE"))
				crteria.add(Restrictions.eq("aktifPasif", iMap.getString("AKTIF_PASIF_FILTRE")));
			if (isNotExistAndNull(iMap, "ISLEM_GONDERIM_KODU"))
				crteria.add(Restrictions.eq("islemGonderimKodu", iMap.getBigDecimal("ISLEM_GONDERIM_KODU")));

			if ("DOLU".equals(iMap.getString("ISLEM_GONDERIM_DOLU_BOS")))
				crteria.add(Restrictions.isNotNull("islemGonderimKodu"));

			if ("BOS".equals(iMap.getString("ISLEM_GONDERIM_DOLU_BOS")))
				crteria.add(Restrictions.isNull("islemGonderimKodu"));

			List<?> list = (List<?>) crteria.list();

			String tableName = "RESULTS";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				OpsBiRaporParam opsBiRaporParam = (OpsBiRaporParam) iterator.next();
				oMap.put(tableName, row, "DEP_TXT", opsBiRaporParam.getDepTxt());
				oMap.put(tableName, row, "DEP_TXT_RANK", opsBiRaporParam.getDepTxtRank());
				oMap.put(tableName, row, "UNIT_TXT", opsBiRaporParam.getUnitTxt());
				oMap.put(tableName, row, "UNIT_TXT_RANK", opsBiRaporParam.getUnitTxtRank());
				oMap.put(tableName, row, "SERV_TXT", opsBiRaporParam.getServTxt());
				oMap.put(tableName, row, "SERV_TXT_RANK", opsBiRaporParam.getServTxtRank());
				oMap.put(tableName, row, "CAT_TXT", opsBiRaporParam.getCatTxt());
				oMap.put(tableName, row, "CAT_TXT_RANK", opsBiRaporParam.getCatTxtRank());
				oMap.put(tableName, row, "SUBCAT_L1_TXT", opsBiRaporParam.getSubcatL1Txt());
				oMap.put(tableName, row, "SUBCAT_L1_TXT_RANK", opsBiRaporParam.getSubcatL1TxtRank());
				oMap.put(tableName, row, "SUBCAT_L2_TXT", opsBiRaporParam.getSubcatL2Txt());
				oMap.put(tableName, row, "SUBCAT_L2_TXT_RANK", opsBiRaporParam.getSubcatL2TxtRank());
				oMap.put(tableName, row, "IND_TXT", opsBiRaporParam.getIndTxt());
				oMap.put(tableName, row, "IND_TXT_RANK", opsBiRaporParam.getIndTxtRank());
				oMap.put(tableName, row, "ISLEM_SURELERI", opsBiRaporParam.getIslemSureleri());
				oMap.put(tableName, row, "GLOBAL", opsBiRaporParam.getGlobal());
				oMap.put(tableName, row, "KAPASITE", opsBiRaporParam.getKapasite());
				oMap.put(tableName, row, "OTOMATIK", opsBiRaporParam.getOtomatik());
				oMap.put(tableName, row, "AKTIF_PASIF", opsBiRaporParam.getAktifPasif());
				oMap.put(tableName, row, "KANAL", opsBiRaporParam.getKanal());
				oMap.put(tableName, row, "ALT_KANAL", opsBiRaporParam.getAltKanal());
				oMap.put(tableName, row, "ISLEM_TIPI", opsBiRaporParam.getIslemTipi());
				oMap.put(tableName, row, "ONAY_SURELERI", opsBiRaporParam.getOnaySureleri());
				oMap.put(tableName, row, "ISLEM_GONDERIM_KODU", opsBiRaporParam.getIslemGonderimKodu());

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9950_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> opsBiRaporList = (List<?>) session.createCriteria(OpsBiRaporParamTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = opsBiRaporList.iterator(); iterator.hasNext();) {
				OpsBiRaporParamTx opsBiRaporParamTx = (OpsBiRaporParamTx) iterator.next();
				session.delete(opsBiRaporParamTx);
			}

			String tableName = "TBL";
			for (int row = 0; row < iMap.getSize(tableName); row++) {

				OpsBiRaporParamTx opsBiRaporParamTx = new OpsBiRaporParamTx();
				OpsBiRaporParamTxId opsBiRaporParamTxId = new OpsBiRaporParamTxId();

				opsBiRaporParamTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				opsBiRaporParamTxId.setIndTxtRank(iMap.getBigDecimal(tableName, row, "IND_TXT_RANK"));

				opsBiRaporParamTx.setId(opsBiRaporParamTxId);
				opsBiRaporParamTx.setDepTxt(iMap.getString(tableName, row, "DEP_TXT"));
				opsBiRaporParamTx.setDepTxtRank(iMap.getBigDecimal(tableName, row, "DEP_TXT_RANK"));
				opsBiRaporParamTx.setUnitTxt(iMap.getString(tableName, row, "UNIT_TXT"));
				opsBiRaporParamTx.setUnitTxtRank(iMap.getBigDecimal(tableName, row, "UNIT_TXT_RANK"));
				opsBiRaporParamTx.setServTxt(iMap.getString(tableName, row, "SERV_TXT"));
				opsBiRaporParamTx.setServTxtRank(iMap.getBigDecimal(tableName, row, "SERV_TXT_RANK"));
				opsBiRaporParamTx.setCatTxt(iMap.getString(tableName, row, "CAT_TXT"));
				opsBiRaporParamTx.setCatTxtRank(iMap.getBigDecimal(tableName, row, "CAT_TXT_RANK"));
				opsBiRaporParamTx.setSubcatL1Txt(iMap.getString(tableName, row, "SUBCAT_L1_TXT"));
				opsBiRaporParamTx.setSubcatL1TxtRank(iMap.getBigDecimal(tableName, row, "SUBCAT_L1_TXT_RANK"));
				opsBiRaporParamTx.setSubcatL2Txt(iMap.getString(tableName, row, "SUBCAT_L2_TXT"));
				opsBiRaporParamTx.setSubcatL2TxtRank(iMap.getBigDecimal(tableName, row, "SUBCAT_L2_TXT_RANK"));
				opsBiRaporParamTx.setIndTxt(iMap.getString(tableName, row, "IND_TXT"));
				opsBiRaporParamTx.setIslemSureleri(iMap.getBigDecimal(tableName, row, "ISLEM_SURELERI"));
				opsBiRaporParamTx.setGlobal(iMap.getString(tableName, row, "GLOBAL"));
				opsBiRaporParamTx.setKapasite(iMap.getString(tableName, row, "KAPASITE"));
				opsBiRaporParamTx.setOtomatik(iMap.getString(tableName, row, "OTOMATIK"));
				opsBiRaporParamTx.setAktifPasif(iMap.getString(tableName, row, "AKTIF_PASIF"));
				opsBiRaporParamTx.setKanal(iMap.getString(tableName, row, "KANAL"));
				opsBiRaporParamTx.setAltKanal(iMap.getString(tableName, row, "ALT_KANAL"));
				opsBiRaporParamTx.setIslemTipi(iMap.getString(tableName, row, "ISLEM_TIPI"));
				opsBiRaporParamTx.setOnaySureleri(iMap.getBigDecimal(tableName, row, "ONAY_SURELERI"));
				opsBiRaporParamTx.setIslemGonderimKodu(iMap.getBigDecimal(tableName, row, "ISLEM_GONDERIM_KODU"));
				opsBiRaporParamTx.setIud(iMap.getString(tableName, row, "IUD"));

				session.saveOrUpdate(opsBiRaporParamTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "9950");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9950_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			String iudAction = "U";
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(OpsBiRaporParamTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("iud", iudAction)).list();

			int row = 0;
			String tableName = "RESULTS";

			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				OpsBiRaporParamTx opsBiRaporParam = (OpsBiRaporParamTx) iterator.next();
				oMap.put(tableName, row, "DEP_TXT", opsBiRaporParam.getDepTxt());
				oMap.put(tableName, row, "DEP_TXT_RANK", opsBiRaporParam.getDepTxtRank());
				oMap.put(tableName, row, "UNIT_TXT", opsBiRaporParam.getUnitTxt());
				oMap.put(tableName, row, "UNIT_TXT_RANK", opsBiRaporParam.getUnitTxtRank());
				oMap.put(tableName, row, "SERV_TXT", opsBiRaporParam.getServTxt());
				oMap.put(tableName, row, "SERV_TXT_RANK", opsBiRaporParam.getServTxtRank());
				oMap.put(tableName, row, "CAT_TXT", opsBiRaporParam.getCatTxt());
				oMap.put(tableName, row, "CAT_TXT_RANK", opsBiRaporParam.getCatTxtRank());
				oMap.put(tableName, row, "SUBCAT_L1_TXT", opsBiRaporParam.getSubcatL1Txt());
				oMap.put(tableName, row, "SUBCAT_L1_TXT_RANK", opsBiRaporParam.getSubcatL1TxtRank());
				oMap.put(tableName, row, "SUBCAT_L2_TXT", opsBiRaporParam.getSubcatL2Txt());
				oMap.put(tableName, row, "SUBCAT_L2_TXT_RANK", opsBiRaporParam.getSubcatL2TxtRank());
				oMap.put(tableName, row, "IND_TXT", opsBiRaporParam.getIndTxt());
				oMap.put(tableName, row, "IND_TXT_RANK", opsBiRaporParam.getId().getIndTxtRank());
				oMap.put(tableName, row, "ISLEM_SURELERI", opsBiRaporParam.getIslemSureleri());
				oMap.put(tableName, row, "ONAY_SURELERI", opsBiRaporParam.getOnaySureleri());
				oMap.put(tableName, row, "GLOBAL", opsBiRaporParam.getGlobal());
				oMap.put(tableName, row, "KAPASITE", opsBiRaporParam.getKapasite());
				oMap.put(tableName, row, "OTOMATIK", opsBiRaporParam.getOtomatik());
				oMap.put(tableName, row, "AKTIF_PASIF", opsBiRaporParam.getAktifPasif());
				oMap.put(tableName, row, "KANAL", opsBiRaporParam.getKanal());
				oMap.put(tableName, row, "ALT_KANAL", opsBiRaporParam.getAltKanal());
				oMap.put(tableName, row, "ISLEM_TIPI", opsBiRaporParam.getIslemTipi());
				oMap.put(tableName, row, "ISLEM_GONDERIM_KODU", opsBiRaporParam.getIslemGonderimKodu());
				oMap.put(tableName, row, "IUD", opsBiRaporParam.getIud());

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static boolean isNotExistAndNull(GMMap iMap, String key) {

		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0) {
			return true;
		}
		else {
			return false;
		}

	}

	public static String addLike(String value) {
		String paramValue = "%";
		if (value != null) {
			paramValue = paramValue.concat(value).concat(paramValue);
			return paramValue;
		}
		else {
			return "";
		}

	}

	@GraymoundService("BNSPR_TRN9950_RENKLENDIR")
	public static GMMap renklendirme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			// RENKLENDIRME
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			BigDecimal eskiTxNo = GMServiceExecuter.call("BNSPR_TRN9950_GET_ONCEKI_TX_NO", iMap).getBigDecimal("OLD_TRX_NO");

			List<?> newLimitList = session.createCriteria(OpsBiRaporParamTx.class).add(Restrictions.eq("id.txNo", txNo)).add(Restrictions.eq("id.indTxtRank", iMap.getBigDecimal("IND_TXT_RANK"))).list();
			List<?> oldLimitList = session.createCriteria(OpsBiRaporParamTx.class).add(Restrictions.eq("id.txNo", eskiTxNo)).add(Restrictions.eq("id.indTxtRank", iMap.getBigDecimal("IND_TXT_RANK"))).list();

			String newTableName = "NEW_LIST";
			String oldTableName = "OLD_LIST";

			for (int row = 0; row < newLimitList.size(); row++) {
				OpsBiRaporParamTx opsBiRaporParam = (OpsBiRaporParamTx) newLimitList.get(row);

				oMap.put(newTableName, row, "DEP_TXT", opsBiRaporParam.getDepTxt());
				oMap.put(newTableName, row, "DEP_TXT_RANK", opsBiRaporParam.getDepTxtRank());
				oMap.put(newTableName, row, "UNIT_TXT", opsBiRaporParam.getUnitTxt());
				oMap.put(newTableName, row, "UNIT_TXT_RANK", opsBiRaporParam.getUnitTxtRank());
				oMap.put(newTableName, row, "SERV_TXT", opsBiRaporParam.getServTxt());
				oMap.put(newTableName, row, "SERV_TXT_RANK", opsBiRaporParam.getServTxtRank());
				oMap.put(newTableName, row, "CAT_TXT", opsBiRaporParam.getCatTxt());
				oMap.put(newTableName, row, "CAT_TXT_RANK", opsBiRaporParam.getCatTxtRank());
				oMap.put(newTableName, row, "SUBCAT_L1_TXT", opsBiRaporParam.getSubcatL1Txt());
				oMap.put(newTableName, row, "SUBCAT_L1_TXT_RANK", opsBiRaporParam.getSubcatL1TxtRank());
				oMap.put(newTableName, row, "SUBCAT_L2_TXT", opsBiRaporParam.getSubcatL2Txt());
				oMap.put(newTableName, row, "SUBCAT_L2_TXT_RANK", opsBiRaporParam.getSubcatL2TxtRank());
				oMap.put(newTableName, row, "IND_TXT", opsBiRaporParam.getIndTxt());
				oMap.put(newTableName, row, "IND_TXT_RANK", opsBiRaporParam.getId().getIndTxtRank());
				oMap.put(newTableName, row, "ISLEM_SURELERI", opsBiRaporParam.getIslemSureleri());
				oMap.put(newTableName, row, "ONAY_SURELERI", opsBiRaporParam.getOnaySureleri());
				oMap.put(newTableName, row, "GLOBAL", opsBiRaporParam.getGlobal());
				oMap.put(newTableName, row, "KAPASITE", opsBiRaporParam.getKapasite());
				oMap.put(newTableName, row, "OTOMATIK", opsBiRaporParam.getOtomatik());
				oMap.put(newTableName, row, "AKTIF_PASIF", opsBiRaporParam.getAktifPasif());
				oMap.put(newTableName, row, "KANAL", opsBiRaporParam.getKanal());
				oMap.put(newTableName, row, "ALT_KANAL", opsBiRaporParam.getAltKanal());
				oMap.put(newTableName, row, "ISLEM_TIPI", opsBiRaporParam.getIslemTipi());
				oMap.put(newTableName, row, "ISLEM_GONDERIM_KODU", opsBiRaporParam.getIslemGonderimKodu());
				oMap.put(newTableName, row, "IUD", opsBiRaporParam.getIud());
			}
			for (int row = 0; row < oldLimitList.size(); row++) {
				OpsBiRaporParamTx opsBiRaporParam = (OpsBiRaporParamTx) oldLimitList.get(row);

				oMap.put(oldTableName, row, "DEP_TXT", opsBiRaporParam.getDepTxt());
				oMap.put(oldTableName, row, "DEP_TXT_RANK", opsBiRaporParam.getDepTxtRank());
				oMap.put(oldTableName, row, "UNIT_TXT", opsBiRaporParam.getUnitTxt());
				oMap.put(oldTableName, row, "UNIT_TXT_RANK", opsBiRaporParam.getUnitTxtRank());
				oMap.put(oldTableName, row, "SERV_TXT", opsBiRaporParam.getServTxt());
				oMap.put(oldTableName, row, "SERV_TXT_RANK", opsBiRaporParam.getServTxtRank());
				oMap.put(oldTableName, row, "CAT_TXT", opsBiRaporParam.getCatTxt());
				oMap.put(oldTableName, row, "CAT_TXT_RANK", opsBiRaporParam.getCatTxtRank());
				oMap.put(oldTableName, row, "SUBCAT_L1_TXT", opsBiRaporParam.getSubcatL1Txt());
				oMap.put(oldTableName, row, "SUBCAT_L1_TXT_RANK", opsBiRaporParam.getSubcatL1TxtRank());
				oMap.put(oldTableName, row, "SUBCAT_L2_TXT", opsBiRaporParam.getSubcatL2Txt());
				oMap.put(oldTableName, row, "SUBCAT_L2_TXT_RANK", opsBiRaporParam.getSubcatL2TxtRank());
				oMap.put(oldTableName, row, "IND_TXT", opsBiRaporParam.getIndTxt());
				oMap.put(oldTableName, row, "IND_TXT_RANK", opsBiRaporParam.getId().getIndTxtRank());
				oMap.put(oldTableName, row, "ISLEM_SURELERI", opsBiRaporParam.getIslemSureleri());
				oMap.put(oldTableName, row, "ONAY_SURELERI", opsBiRaporParam.getOnaySureleri());
				oMap.put(oldTableName, row, "GLOBAL", opsBiRaporParam.getGlobal());
				oMap.put(oldTableName, row, "KAPASITE", opsBiRaporParam.getKapasite());
				oMap.put(oldTableName, row, "OTOMATIK", opsBiRaporParam.getOtomatik());
				oMap.put(oldTableName, row, "AKTIF_PASIF", opsBiRaporParam.getAktifPasif());
				oMap.put(oldTableName, row, "KANAL", opsBiRaporParam.getKanal());
				oMap.put(oldTableName, row, "ALT_KANAL", opsBiRaporParam.getAltKanal());
				oMap.put(oldTableName, row, "ISLEM_TIPI", opsBiRaporParam.getIslemTipi());
				oMap.put(oldTableName, row, "ISLEM_GONDERIM_KODU", opsBiRaporParam.getIslemGonderimKodu());
				oMap.put(oldTableName, row, "IUD", opsBiRaporParam.getIud());
			}
			Color color = Color.RED;

			if (!StringUtils.equals(oMap.getString(oldTableName, 0, "ISLEM_SURELERI"), oMap.getString(newTableName, 0, "ISLEM_SURELERI")))
				oMap.put("C_ISLEM_SURELERI", color);

			if (!StringUtils.equals(oMap.getString(oldTableName, 0, "ONAY_SURELERI"), oMap.getString(newTableName, 0, "ONAY_SURELERI")))
				oMap.put("C_ONAY_SURELERI", color);

			oMap.put("C_GLOBAL", !StringUtils.equals(oMap.getString(oldTableName, 0, "GLOBAL"), oMap.getString(newTableName, 0, "GLOBAL")) ? Boolean.TRUE : Boolean.FALSE);
			oMap.put("C_KAPASITE", !StringUtils.equals(oMap.getString(oldTableName, 0, "KAPASITE"), oMap.getString(newTableName, 0, "KAPASITE")) ? Boolean.TRUE : Boolean.FALSE);
			oMap.put("C_OTOMATIK", !StringUtils.equals(oMap.getString(oldTableName, 0, "OTOMATIK"), oMap.getString(newTableName, 0, "OTOMATIK")) ? Boolean.TRUE : Boolean.FALSE);
			oMap.put("C_AKTIF_PASIF", !StringUtils.equals(oMap.getString(oldTableName, 0, "AKTIF_PASIF"), oMap.getString(newTableName, 0, "AKTIF_PASIF")) ? Boolean.TRUE : Boolean.FALSE);
			oMap.put("C_KANAL", !StringUtils.equals(oMap.getString(oldTableName, 0, "KANAL"), oMap.getString(newTableName, 0, "KANAL")) ? Boolean.TRUE : Boolean.FALSE);
			oMap.put("C_ALT_KANAL", !StringUtils.equals(oMap.getString(oldTableName, 0, "ALT_KANAL"), oMap.getString(newTableName, 0, "ALT_KANAL")) ? Boolean.TRUE : Boolean.FALSE);
			oMap.put("C_ISLEM_TIPI", !StringUtils.equals(oMap.getString(oldTableName, 0, "ISLEM_TIPI"), oMap.getString(newTableName, 0, "ISLEM_TIPI")) ? Boolean.TRUE : Boolean.FALSE);

			if (!StringUtils.equals(oMap.getString(oldTableName, 0, "ISLEM_GONDERIM_KODU"), oMap.getString(newTableName, 0, "ISLEM_GONDERIM_KODU")))
				oMap.put("C_ISLEM_GONDERIM_KODU", color);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN9950_GET_ONCEKI_TX_NO")
	public static GMMap getOncekiTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_Trn9950.Onceki_Tx(?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("IND_TXT_RANK"));
			stmt.execute();

			oMap.put("OLD_TRX_NO", stmt.getBigDecimal(1));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

}
