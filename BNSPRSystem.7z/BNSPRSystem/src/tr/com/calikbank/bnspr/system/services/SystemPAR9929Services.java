package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9929Services {
	@GraymoundService("BNSPR_PAR929_GET_PARAMETRE_TANIM")
	public static Map<?, ?> getParametreTanim(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listParametre = (List<?>) session.createCriteria(GnlParametre.class).addOrder(Order.asc("kod")).list();
			String tableName = "PARAMETRE_TANIM";
			int row = 0;
			for (Iterator<?> iterator = listParametre.iterator(); iterator.hasNext(); row++) {
				GnlParametre gnlParametre = (GnlParametre) iterator.next();
				oMap.put(tableName, row, "ACIKLAMA", gnlParametre.getAciklama());
				oMap.put(tableName, row, "DEGER", gnlParametre.getDeger());
				oMap.put(tableName, row, "KOD", gnlParametre.getKod());
				oMap.put(tableName, row, "NUMARA", gnlParametre.getNumara());
				oMap.put(tableName, row, "MODUL_TUR_KOD", gnlParametre.getModulTurKod());
				oMap.put(tableName, row, "SIRA", gnlParametre.getSira());
				if (gnlParametre.getTip().equals("V"))
					oMap.put(tableName, row, "TIP", "Varchar");
				else if (gnlParametre.getTip().equals("D"))
					oMap.put(tableName, row, "TIP", "Date");
				else if (gnlParametre.getTip().equals("N"))
					oMap.put(tableName, row, "TIP", "Number");
				else if (gnlParametre.getTip().equals("B"))
					oMap.put(tableName, row, "TIP", "Boolean");
			}

			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_PAR9929_SAVE_PARAMETRE_TANIM")
	public static Map<?, ?> saveParametreTanim(GMMap iMap) {
		/*GMMap xMap = new GMMap();
		Boolean eski = false;
		Boolean degismis = false;*/
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "PARAMETRE_TANIM";
			List<?> parametrePersistentList = (List<?>) session.createCriteria(GnlParametre.class).addOrder(Order.asc("kod")).list();
			for (Iterator<?> iterator = parametrePersistentList.iterator(); iterator.hasNext();) {
				GnlParametre gnlParametre = (GnlParametre) iterator.next();
				if (!GuimlUtil.contains(iMap, tableName, "KOD", gnlParametre.getKod()))
					session.delete(gnlParametre);
			}

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				Validator.checkEmpty(iMap.getString(tableName, row, "KOD"), "'Kod' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row, "ACIKLAMA"), "'A��kklama' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row, "TIP"), "'Tip' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row, "DEGER"), "'De�er' alan� bo� olmaz");

				GnlParametre gnlParametre = null;
				if (iMap.getBigDecimal(tableName, row, "NUMARA") != null) {
					gnlParametre = find(iMap.getBigDecimal(tableName, row, "NUMARA"));
					/*eski = true;*/
				}
				if (gnlParametre == null) {
					gnlParametre = new GnlParametre();

					iMap.put("TABLE_NAME", "GNL_PARAMETRE_NUMARA");
					gnlParametre.setNumara(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", iMap).getBigDecimal("ID"));
				}

				// kayirlarin herhangi bir yerinde degisiklik var ise last modified alani banka tarihi atanacak.
				/*if (eski == true){
					if(!gnlParametre.getKod().equals(iMap.getString(tableName, row, "KOD")))
						degismis = true;
					if(!gnlParametre.getAciklama().equals(iMap.getString(tableName, row, "ACIKLAMA")))
						degismis = true;
					if(!gnlParametre.getDeger().equals(iMap.getString(tableName, row, "DEGER")))
						degismis = true;
					if(iMap.getString(tableName, row, "MODUL_TUR_KOD") != null && gnlParametre.getModulTurKod() != null)
						if(!gnlParametre.getModulTurKod().equals(iMap.getString(tableName, row, "MODUL_TUR_KOD")))
							degismis = true;
					if((iMap.getString(tableName, row, "MODUL_TUR_KOD") == null && gnlParametre.getModulTurKod() != null)
							||(iMap.getString(tableName, row, "MODUL_TUR_KOD") != null && gnlParametre.getModulTurKod() == null))
						degismis = true;
					if(!gnlParametre.getTip().equals(iMap.getString(tableName, row, "TIP").substring(0, 1)))
						degismis = true;
				}*/
				gnlParametre.setKod(iMap.getString(tableName, row, "KOD"));
				gnlParametre.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlParametre.setDeger(iMap.getString(tableName, row, "DEGER"));
				gnlParametre.setSira(iMap.getBigDecimal(tableName, row, "SIRA"));
				gnlParametre.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
				String strTip = iMap.getString(tableName, row, "TIP");
				if (strTip != null) {
					if (strTip.length() > 1)
						gnlParametre.setTip(strTip.charAt(0) + "");
					else
						gnlParametre.setTip(strTip);
				}
				gnlParametre.setTur("G");
				/*if((eski == true && degismis == true)||eski == false)
					gnlParametre.setLastModified(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", xMap).getDate("BANKA_TARIH"));
				eski = false;
				degismis = false;*/
				session.saveOrUpdate(gnlParametre);
			}

			session.flush();
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE", "��leminiz tamamland�!");
			return messageMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	public static GnlParametre find(BigDecimal numara) {
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlParametre) session.get(GnlParametre.class, numara);
	}

	@GraymoundService("BNSPR_PAR9929_PARAMETRE_URUN_KONTROL")
	public static Map<?, ?> parametreUrunKontrol(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_parametre.Parametre_Urun_Kontrol(?)}");
			stmt.setString(1, iMap.getString("KOD"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}

	@GraymoundService("BNSPR_PAR9929S_GET_COMBO_PARAM")
	public static GMMap getComboParam(GMMap iMap) {
		GMMap oMap = new GMMap(), tMap = new GMMap(), iMap2 = new GMMap();
		try {
			iMap2.put("KOD", "T9929S_PARAMETRE");
			iMap2.put("KEY2", "BBS_TIP");
			tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap2);
			oMap.put("BBS_TIP_LISTE", tMap.get("RESULTS"));

			iMap2.put("KOD", "T9929S_PARAMETRE");
			iMap2.put("KEY2", "BBS_HOST");
			tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap2);
			oMap.put("BBS_HOST_LISTE", tMap.get("RESULTS"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_PAR9929S_GET_PARAMETRE_TANIM")
	public static GMMap getSistemTanimParametre(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String func = "{? = call PKG_TRN9929.get_sistem_izleme_parametre }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "SISTEM_IZLEME_PARAMETRE");

			String tableName = "PARAMETRE_TANIM";

			for (int i = 0; i < oMap.getSize("SISTEM_IZLEME_PARAMETRE"); i++) {
				Session session = DAOSession.getSession("BNSPRDal");
				GnlParametre gnlParametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", oMap.getString("SISTEM_IZLEME_PARAMETRE", i, "KOD"))).uniqueResult();
				if (gnlParametre != null) {
					oMap.put(tableName, i, "ACIKLAMA", gnlParametre.getAciklama());
					oMap.put(tableName, i, "DEGER", gnlParametre.getDeger());
					oMap.put(tableName, i, "KOD", gnlParametre.getKod());
					oMap.put(tableName, i, "NUMARA", gnlParametre.getNumara());
					oMap.put(tableName, i, "MODUL_TUR_KOD", gnlParametre.getModulTurKod());
					oMap.put(tableName, i, "SIRA", gnlParametre.getSira());
					if (gnlParametre.getTip().equals("V"))
						oMap.put(tableName, i, "TIP", "Varchar");
					else if (gnlParametre.getTip().equals("D"))
						oMap.put(tableName, i, "TIP", "Date");
					else if (gnlParametre.getTip().equals("N"))
						oMap.put(tableName, i, "TIP", "Number");
					else if (gnlParametre.getTip().equals("B"))
						oMap.put(tableName, i, "TIP", "Boolean");
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_PAR9929S_GET_BBS_TANIM")
	public static GMMap getBSSParameterList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN9929.get_bbs_tanim }";

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BBS_PARAMETRE_LISTE"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_PAR9929S_SAVE_PARAMETRE_TANIM")
	public static GMMap saveSistemIzlemeParametreTanim(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "SISTEM_IZLEME_PARAMETRE";
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			tableName = "PARAMETRE_TANIM";

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				Validator.checkEmpty(iMap.getString(tableName, row, "KOD"), "'Kod' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row, "ACIKLAMA"), "'A��kklama' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row, "TIP"), "'Tip' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row, "DEGER"), "'De�er' alan� bo� olmaz");

				GnlParametre gnlParametre = null;
				if (iMap.getBigDecimal(tableName, row, "NUMARA") != null) {
					gnlParametre = find(iMap.getBigDecimal(tableName, row, "NUMARA"));
					/*eski = true;*/
				}
				if (gnlParametre == null) {
					gnlParametre = new GnlParametre();

					iMap.put("TABLE_NAME", "GNL_PARAMETRE_NUMARA");
					gnlParametre.setNumara(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", iMap).getBigDecimal("ID"));
				}
				gnlParametre.setKod(iMap.getString(tableName, row, "KOD"));
				gnlParametre.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlParametre.setDeger(iMap.getString(tableName, row, "DEGER"));
				gnlParametre.setSira(iMap.getBigDecimal(tableName, row, "SIRA"));
				gnlParametre.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
				String strTip = iMap.getString(tableName, row, "TIP");
				if (strTip != null) {
					if (strTip.length() > 1)
						gnlParametre.setTip(strTip.charAt(0) + "");
					else
						gnlParametre.setTip(strTip);
				}
				gnlParametre.setTur("G");
				session.saveOrUpdate(gnlParametre);
			}

			session.flush();

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		tableName = "BBS_PARAMETRE_LISTE";
		for (int row = 0; row < iMap.getSize(tableName); row++) {
			try {
				String func = "{ call PKG_TRN9929.update_bbs_tanim(?,?) }";

				Object[] inputValues = new Object[4];
				Object[] outputValues = new Object[0];
				int i = 0;
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getString(tableName, row, "BBS_TYPE");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getString(tableName, row, "BBS_HOST");
				DALUtil.callOracleProcedure(func, inputValues, outputValues);
				
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		oMap.put("MESSAGE", "��leminiz tamamland�!");
		return oMap;

	}
}
