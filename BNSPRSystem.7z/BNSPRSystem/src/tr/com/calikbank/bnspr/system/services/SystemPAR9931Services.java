package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlUlkeKodPr;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9931Services {
	@GraymoundService("BNSPR_PAR9931_GET_ULKE_TANIM")
	public static Map<?,?> getUlkeTanim(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listUlke = (List<?>) session.createCriteria(GnlUlkeKodPr.class).addOrder(Order.asc("kod")).list();
			String tableName = "ULKE_TANIM";
			int row = 0;
			for (Iterator<?> iterator = listUlke.iterator(); iterator.hasNext();row++) {
				GnlUlkeKodPr gnlUlkeKodPr = (GnlUlkeKodPr) iterator.next();
				oMap.put(tableName, row, "KOD", gnlUlkeKodPr.getKod());
				oMap.put(tableName, row, "ULKE_ADI", gnlUlkeKodPr.getUlkeAdi());
				oMap.put(tableName, row, "OECD", GuimlUtil.convertToCheckBoxValue(gnlUlkeKodPr.getOecd()));
				oMap.put(tableName, row, "DOVIZ_GETIRME_SURESI", gnlUlkeKodPr.getDovizGetirmeSuresi());
				oMap.put(tableName, row, "TCMB_ULKE_KOD", gnlUlkeKodPr.getTcmbUlkeKod());
				oMap.put(tableName, row, "BIC_KOD", gnlUlkeKodPr.getBicKod());
				oMap.put(tableName, row, "SUPHELI", GuimlUtil.convertToCheckBoxValue(gnlUlkeKodPr.getSupheli()));
				oMap.put(tableName, row, "SEPA", GuimlUtil.convertToCheckBoxValue(gnlUlkeKodPr.getSepa()));
				oMap.put(tableName, row, "CRS", GuimlUtil.convertToCheckBoxValue(gnlUlkeKodPr.getCrs()));
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9931_SAVE_ULKE_TANIM")
	public static Map<?,?> saveUlkeTanim(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> ulkeGUIlist = (List<?>) iMap.get("ULKE_TANIM");
			List<?> listPersistentUlke = (List<?>) session.createCriteria(GnlUlkeKodPr.class).addOrder(Order.asc("kod")).list();
			String tableName = "ULKE_TANIM";

			for (Iterator<?> iterator = listPersistentUlke.iterator(); iterator.hasNext();) {
				GnlUlkeKodPr gnlUlkeKodPr = (GnlUlkeKodPr) iterator.next();
				if(!GuimlUtil.contains(iMap, tableName, "KOD", gnlUlkeKodPr.getKod()))
					session.delete(gnlUlkeKodPr);
			}
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				Validator.checkNull(iMap.getString(tableName, row, "KOD"), "'Kod' alan� bo� olmaz");
				Validator.checkEmpty(iMap.getString(tableName, row,"KOD"), "'Kod' alan� bo� olmaz");				
				if(GuimlUtil.isDublicateKey(ulkeGUIlist, "KOD", iMap.getString(tableName, row, "KOD")))
					throw new GMRuntimeException(0, iMap.getString(tableName, row, "KOD") + " Kodlu ba�ka bir kay�t bulunmaktad�r");

				GnlUlkeKodPr gnlUlkeKodPr = find(iMap.getString(tableName, row,"KOD"));
				if(gnlUlkeKodPr == null)
					gnlUlkeKodPr = new	GnlUlkeKodPr();
				
				gnlUlkeKodPr.setKod(iMap.getString(tableName, row, "KOD"));
				Validator.checkNull(iMap.getString(tableName, row, "ULKE_ADI"), "�lke Ad� alan� bo� olmaz");
				gnlUlkeKodPr.setUlkeAdi(iMap.getString(tableName, row,"ULKE_ADI"));
				gnlUlkeKodPr.setDovizGetirmeSuresi(iMap.getBigDecimal(tableName, row, "DOVIZ_GETIRME_SURESI"));
				gnlUlkeKodPr.setOecd(iMap.getString(tableName, row, "OECD"));
				gnlUlkeKodPr.setTcmbUlkeKod(iMap.getString(tableName, row, "TCMB_ULKE_KOD"));
				gnlUlkeKodPr.setBicKod(iMap.getString(tableName, row, "BIC_KOD"));
				gnlUlkeKodPr.setSupheli(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "SUPHELI")));
				gnlUlkeKodPr.setSepa(convertFromCheckBoxValue(iMap.getString(tableName, row, "SEPA")));
				gnlUlkeKodPr.setCrs(convertFromCheckBoxValue(iMap.getString(tableName, row, "CRS")));
				session.saveOrUpdate(gnlUlkeKodPr);
			}
			
			session.flush();
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE", "��leminiz tamamland�!");
			return messageMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static GnlUlkeKodPr find(String kod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlUlkeKodPr)session.get(GnlUlkeKodPr.class, kod);
	}
	
	public static String convertFromCheckBoxValue(String chbValue) {
	if(chbValue == null || chbValue.equals("0"))
        return null;
    else if(chbValue.equals("1"))
        return "E";
    return chbValue;
}
}
