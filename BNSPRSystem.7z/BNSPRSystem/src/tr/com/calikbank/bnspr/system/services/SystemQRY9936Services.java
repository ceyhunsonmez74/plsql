package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemQRY9936Services {
	@GraymoundService("BNSPR_QRY9936_QUERY_KAYIP_ISLEM")
	public static GMMap queryKayipIslem(GMMap iMap) {
		iMap.put("PREFIX", "DBI");
		iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY9936_GET_KAYIP_ISLEM_LIST", iMap));
		iMap.put("PREFIX", "OBI");
		iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY9936_GET_KAYIP_ISLEM_LIST", iMap));
		iMap.put("PREFIX", "IOBI");
		iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY9936_GET_KAYIP_ISLEM_LIST", iMap));
		return iMap;
	}
	
	@GraymoundService("BNSPR_QRY9936_GET_KAYIP_ISLEM_LIST")
	public static GMMap getKayipIslemList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_RC_MESAJKUTUSU.RC_GET_KAYIP_ISLEM_LIST(?,?,?)}");
			int k = 1;	
			stmt.registerOutParameter(k++, -10); //ref cursor
			String  prefix= iMap.getString("PREFIX");
			stmt.setString(k++, prefix);
			if(iMap.getDate("ISLEM_TARIHI") != null)
				stmt.setDate(k++, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			else
				stmt.setDate(k++, null);
			stmt.setString(k++,iMap.getString("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			int i = 0;
			String tableName = prefix;
			while(rSet.next()){
				int j = 1;
				oMap.put(tableName, i, prefix + "_ISLEM_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ISLEM_KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ISLEM_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ROL_NUMARA", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ROL_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_BOLUM_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KAYIT_TARIHI", rSet.getDate(j++));
				oMap.put(tableName, i, prefix + "_ACIKLAMA", rSet.getString(j++));
				i++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY9936_GET_KULLANICI_LIST")
	public static GMMap getKullaniciList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_RC_MESAJKUTUSU.RC_GET_KULLANICI_LIST(?,?,?)}");
			int k = 1;	
			stmt.registerOutParameter(k++, -10); //ref cursor
			String  prefix= iMap.getString("PREFIX");
			stmt.setString(k++, prefix);
			if(iMap.getDate("ISLEM_TARIHI") != null)
				stmt.setDate(k++, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			else
				stmt.setDate(k++, null);
			stmt.setBigDecimal(k++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			int i = 0;
			String tableName = "KULLANICI_LIST";
			while(rSet.next()){
				int j = 1;
				oMap.put(tableName, i, prefix + "_ROL_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ROL_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_SUBE_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ISLEM_TARIHI", rSet.getDate(j++));
				oMap.put(tableName, i, prefix + "_ZAMAN_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_ZAMAN_BAS", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_ZAMAN_BIT", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_LIMIT_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_LIMIT_ALT", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_LIMIT_UST", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_AYNI_BOLUM", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_AYNI_KULLANICI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_BOLUM_KODU", rSet.getString(j++));
				
				i++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}


 /*
 @GraymoundService("BNSPR_QRY9936_GET_KAYIP_ISLEM_LIST")
	public static GMMap getKayipIslemList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			StringBuilder sb = new StringBuilder();
			sb.append("select i.numara,i.islem_kod,pkg_genel_pr.islem_adi(islem_kod) ISLEM_ADI, ");
			sb.append("i.amir_sube_kod SUBE_KOD,i.kayit_kullanici_kodu, b.ad||' '||b.soyad  KULLANICI_ADI, ");
			sb.append("i.kayit_kullanici_rol_numara, r.tanim ROL_ADI, ");
			sb.append("PKG_PERSONEL.Kullanici_Departmani(i.kayit_kullanici_kodu) KULLANICI_BOLUM_KOD, i.kayit_tarih ");
			sb.append("from muh_islem i,gnl_kullanici b, Gnl_Rol r ");
			String prefix = iMap.getString("PREFIX");
			if(prefix.equals("DBI")){
				sb.append("where durum = 'C' and dogrulanmali_mi = 'E'");
			}
			else if(prefix.equals("OBI")){
				sb.append("Where((i.durum = 'C' and dogrulanmali_mi = 'H') or ");
				sb.append("(i.durum = 'V' and dogrulanmali_mi = 'E')) ");
			}
			else if(prefix.equals("IOBI")){
				sb.append("Where durum in ('1') ");
			}
			sb.append("and i.kayit_kullanici_rol_numara = r.numara ");
			sb.append("and i.kayit_kullanici_kodu = b.kod ");
			sb.append("and TRUNC(i.kayit_tarih) = TRUNC(?)");

			stmt = conn.prepareCall(sb.toString());
			if(iMap.getDate("ISLEM_TARIHI") != null)
				stmt.setDate(1, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			else
				stmt.setDate(1, null);
			
			rSet = stmt.executeQuery();
			GMMap oMap = new GMMap();
			int i = 0;
			String tableName = prefix;
			while(rSet.next()){
				int j = 1;
				oMap.put(tableName, i, prefix + "_ISLEM_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ISLEM_KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ISLEM_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ROL_NUMARA", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ROL_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_BOLUM_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KAYIT_TARIHI", rSet.getDate(j++));
				i++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY9936_GET_KULLANICI_LIST")
	public static GMMap getKullan�c�List(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			StringBuilder sb = new StringBuilder();
			sb.append("select a.rol_numara,r.tanim,c.erisim_kullanici_kodu ,b.ad||' '||b.soyad ADI, c.sube_kodu, ? islem_tar, ");
			sb.append("zaman.numara,zaman.baslangic,zaman.bitis,lim.kod, lim.alt, lim.ust, a.ayni_bolum, a.ayni_kullanici, ");
			sb.append("PKG_PERSONEL.Kullanici_Departmani(b.kod) KULLANICI_BOLUM_KOD ");
			if(iMap.getString("PREFIX").equals("DBI"))
				sb.append("from gnl_rol_islem_dogru ");
			else if(iMap.getString("PREFIX").equals("OBI"))
				sb.append("from gnl_rol_islem_onay ");
			else if(iMap.getString("PREFIX").equals("IOBI"))
				sb.append("from gnl_rol_islem_iptal_onay ");
			sb.append(" a,gnl_erisim_rol c,gnl_kullanici b,Gnl_Rol r,gnl_zaman_pr zaman,gnl_limit_pr lim, muh_islem  i ");
			sb.append("where a.islem_tanim_kod = i.islem_kod ");
			sb.append("and c.sube_kodu = i.amir_sube_kod ");
			sb.append("and c.rol_numara = a.rol_numara ");
			sb.append("and c.erisim_kullanici_kodu = b.kod ");
			sb.append("And r.numara = a.rol_numara ");
			sb.append("AND a.zaman_numara = zaman.numara ");
			sb.append("And a.limit_numara = lim.kod ");
			sb.append("and  ((a.ayni_kullanici='H' and b.kod != i.kayit_kullanici_kodu ) or (a.ayni_kullanici='E'))");
			sb.append("and  (( nvl(a.ayni_bolum,'H') = 'H') or  "); 
			sb.append("  ( nvl(a.ayni_bolum,'H') = 'E' and PKG_PERSONEL.kullanici_departmani(i.kayit_kullanici_kodu) = PKG_PERSONEL.Kullanici_Departmani(b.kod) ) ) ");
			
			sb.append("and i.numara = ? ");
			sb.append("and a.zaman_numara = zaman.numara ");
			sb.append("and to_number(to_char(sysdate,'HH24')) between baslangic and bitis ");
			sb.append("and a.limit_numara = lim.kod ");
			
			sb.append("and ( ( lim.tum_dovizler ='H' and lim.karsilik = 'F' and nvl(i.doviz_kod,pkg_genel_pr.lc_al) = lim.doviz_kod ");
			sb.append("and nvl(i.tutar,0) between Alt And Ust ) OR ");
			sb.append("( lim.tum_dovizler ='E' and lim.karsilik = 'F' ");
			sb.append("and nvl(i.tutar,0) between ");
			sb.append("pkg_kur.doviz_cevir(pkg_genel_pr.fc_al,nvl(i.doviz_kod,pkg_genel_pr.lc_al),null,alt) and ");
			sb.append("pkg_kur.doviz_cevir(pkg_genel_pr.fc_al,nvl(i.doviz_kod,pkg_genel_pr.lc_al),null,ust) ) or ");
			sb.append("( lim.karsilik = 'N' ) ");
			sb.append(") ");
			sb.append("and ((ayni_rol='H' and PKG_GLOBAL.GET_ROLKOD not in (select o.onay_kullanici_rol_numara ");
			sb.append("        from muh_islem_onay o  where o.numara = i.numara and o.onay_kullanici_kodu is not null) ");
			sb.append(" and pkg_global.GET_ROLKOD != i.kayit_kullanici_rol_numara) or ayni_rol='E') ");
			
	
			String prefix = iMap.getString("PREFIX");
			
			stmt = conn.prepareCall(sb.toString());
			if(iMap.getDate("ISLEM_TARIHI") != null)
				stmt.setDate(1, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			else
				stmt.setDate(1, null);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));
			
			rSet = stmt.executeQuery();
			GMMap oMap = new GMMap();
			int i = 0;
			String tableName = "KULLANICI_LIST";
			while(rSet.next()){
				int j = 1;
				oMap.put(tableName, i, prefix + "_ROL_NUMARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ROL_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_ADI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_SUBE_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_ISLEM_TARIHI", rSet.getDate(j++));
				oMap.put(tableName, i, prefix + "_ZAMAN_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_ZAMAN_BAS", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_ZAMAN_BIT", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_LIMIT_KODU", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_LIMIT_ALT", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_LIMIT_UST", rSet.getBigDecimal(j++));
				oMap.put(tableName, i, prefix + "_AYNI_BOLUM", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_AYNI_KULLANICI", rSet.getString(j++));
				oMap.put(tableName, i, prefix + "_KULLANICI_BOLUM_KODU", rSet.getString(j++));
				
				i++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
 */