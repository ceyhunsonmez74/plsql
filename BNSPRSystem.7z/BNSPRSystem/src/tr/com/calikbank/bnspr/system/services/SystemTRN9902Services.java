package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDkGrupKodPrTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9902Services {
	@GraymoundService("BNSPR_TRN9902_FILL_COMBOBOX_INITIAL_VALUE")  
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		
			oMap.putAll(DALUtil.fillComboBox(iMap, "MUSTERI_TIPI", false, "select KOD,ACIKLAMA from v_ml_gnl_must_tur_kod_pr"));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN9902_SAVE")
	public static Map<?,?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GnlDkGrupKodPrTx gnlDkGrupKodPrTx = (GnlDkGrupKodPrTx)session.get(GnlDkGrupKodPrTx.class, iMap.getBigDecimal("TRX_NO"));
			if(gnlDkGrupKodPrTx == null)gnlDkGrupKodPrTx = new GnlDkGrupKodPrTx();
			
			gnlDkGrupKodPrTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        gnlDkGrupKodPrTx.setKod(iMap.getBigDecimal("DK_GRUP_KODU"));
	        gnlDkGrupKodPrTx.setAciklama(iMap.getString("ACIKLAMA"));
	        gnlDkGrupKodPrTx.setSiraNo(iMap.getBigDecimal("SIRA_NO"));
	        gnlDkGrupKodPrTx.setMusteriTurKod(iMap.getString("MUSTERI_TIPI"));
	        gnlDkGrupKodPrTx.setYurtIciDisi(iMap.getString("YERLESIM_TIPI"));
	        gnlDkGrupKodPrTx.setMkkKimlikTipi(iMap.getString("MKK_KIMLIK_TIPI"));
	        gnlDkGrupKodPrTx.setSermayeYeterlikGrubu(iMap.getString("SERMAYE_YETERLIK_GRUBU"));
	        gnlDkGrupKodPrTx.setMusteriStat1(iMap.getString("PROFIL_KODU"));
	        gnlDkGrupKodPrTx.setMusteriStat2(iMap.getString("PROFIL_ALT1_KODU"));
	        gnlDkGrupKodPrTx.setMusteriStat3(iMap.getString("PROFIL_ALT2_KODU"));
	        
	        session.saveOrUpdate(gnlDkGrupKodPrTx);
			session.flush();
			
			iMap.put("TRX_NAME", "9902");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch(Exception e){
			throw new GMRuntimeException(0,e);
		}		
	}
	@GraymoundService("BNSPR_TRN9902_GET_DK_INFO")
	public static GMMap getDkInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			GnlDkGrupKodPrTx gnlDkGrupKodPrTx = (GnlDkGrupKodPrTx) session.get(
					GnlDkGrupKodPrTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", gnlDkGrupKodPrTx.getTxNo());
			oMap.put("DK_GRUP_KODU", gnlDkGrupKodPrTx.getKod());
			oMap.put("ACIKLAMA", gnlDkGrupKodPrTx.getAciklama());
			oMap.put("SIRA_NO", gnlDkGrupKodPrTx.getSiraNo());
			oMap.put("PROFIL_KODU", gnlDkGrupKodPrTx.getMusteriStat1());
			oMap.put("PROFIL_ALT1_KODU", gnlDkGrupKodPrTx.getMusteriStat2());
			oMap.put("PROFIL_ALT2_KODU", gnlDkGrupKodPrTx.getMusteriStat3());
			oMap.put("DI_PROFIL_KODU", LovHelper.diLov(gnlDkGrupKodPrTx.getMusteriStat1(),gnlDkGrupKodPrTx.getMusteriTurKod(), "9902/LOV_STAT", "ACIKLAMA"));
			oMap.put("DI_PROFIL_ALT1_KODU", LovHelper.diLov(gnlDkGrupKodPrTx.getMusteriStat2(),gnlDkGrupKodPrTx.getMusteriTurKod(), gnlDkGrupKodPrTx.getMusteriStat1(),"9902/LOV_STAT1", "ACIKLAMA"));
			oMap.put("DI_PROFIL_ALT2_KODU", LovHelper.diLov(gnlDkGrupKodPrTx.getMusteriStat3(),gnlDkGrupKodPrTx.getMusteriTurKod(),gnlDkGrupKodPrTx.getMusteriStat1(),gnlDkGrupKodPrTx.getMusteriStat2(), "9902/LOV_STAT2" , "ACIKLAMA"));
			oMap.put("MUSTERI_TIPI", gnlDkGrupKodPrTx.getMusteriTurKod());
			oMap.put("YERLESIM_TIPI", gnlDkGrupKodPrTx.getYurtIciDisi());
			oMap.put("MKK_KIMLIK_TIPI", gnlDkGrupKodPrTx.getMkkKimlikTipi());
			oMap.put("SERMAYE_YETERLIK_GRUBU", gnlDkGrupKodPrTx.getSermayeYeterlikGrubu());

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9902_GET_SIRA_NO")
	public static GMMap getSiraNo(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN9902.SiraNoAl(?)}");			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("DK_GRUP_KODU"));
			
			stmt.execute();
			oMap.put("SIRA_NO", stmt.getBigDecimal(1));
			return oMap;
			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
