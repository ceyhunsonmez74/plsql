package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.islBirimKod;
import tr.com.aktifbank.bnspr.dao.islBolumKod;
import tr.com.aktifbank.bnspr.dao.islServisKod;
import tr.com.aktifbank.bnspr.dao.islislemSureleriTx;
import tr.com.aktifbank.bnspr.dao.islislemSureleriTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * BPM_GROUP_ROLE services
 * 
 * @author samet.erkorkmaz
 *
 */
public class SystemTRN9816Services {
	
	@GraymoundService("BNSPR_TRN9816_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int i=0;
		try {
			@SuppressWarnings("unchecked")
			List<islislemSureleriTx> islemSureList =  (List<islislemSureleriTx>) session.createCriteria(islislemSureleriTx.class).add(Restrictions.eq("id.txNo",  iMap.getBigDecimal("TRX_NO"))).list();        
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			BigDecimal toplamFte = BigDecimal.ZERO;
			for(islislemSureleriTx islemSureTx: islemSureList){
				oMap.put("ISLEM_LISTESI",i,"KATEGORI",islemSureTx.getKategori());
				oMap.put("ISLEM_LISTESI",i,"PERIYOT_KOD",islemSureTx.getPeriyot());
				oMap.put("ISLEM_LISTESI",i,"PERIYOT",getParamText("9815_ISLEM_PERIYOTLARI", islemSureTx.getPeriyot()));
				oMap.put("ISLEM_LISTESI",i,"ISLEM_ID",islemSureTx.getId().getIsKodu());
				oMap.put("ISLEM_LISTESI",i,"IS_TANIMI",islemSureTx.getIsTanimi());
				oMap.put("ISLEM_LISTESI",i,"SURE",islemSureTx.getSure());
				oMap.put("ISLEM_LISTESI",i,"EK_SURE",islemSureTx.getEkSure());
				oMap.put("ISLEM_LISTESI", i, "ADET", islemSureTx.getAdet());
				oMap.put("ISLEM_LISTESI", i, "ACIKLAMA", islemSureTx.getAciklama());
				oMap.put("ISLEM_LISTESI", i, "TOPLAM_SURE", islemSureTx.getToplamSure());
				oMap.put("ISLEM_LISTESI", i, "FTE", islemSureTx.getFte());
				oMap.put("TARIH", islemSureTx.getIslemTarihi());
				oMap.put("KULLANICI_KOD", islemSureTx.getUserCode());
				toplamFte = toplamFte.add( islemSureTx.getFte());
				i=i+1;
			}
			oMap.put("TOPLAM_FTE", toplamFte);
			
		} finally {
			session.close();
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN9816_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
		String func = "{ ? = call PKG_TRN9816.get_islem_list(?)}";
		Object[] inputValues = new Object[2];
		int i = 0;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("KULLANICI_KOD");
		GMMap sMap = new GMMap(); 
		sMap = DALUtil.callOracleRefCursorFunction(func, "ISLEM_LIST", inputValues);
		for (int j = 0; j < sMap.getSize("ISLEM_LIST"); j++) {
			oMap.put("ISLEM_LISTESI",j,"KATEGORI",sMap.getString("ISLEM_LIST",j,"KATEGORI"));
			oMap.put("ISLEM_LISTESI",j,"PERIYOT_KOD",sMap.getString("ISLEM_LIST",j,"PERIYOT"));
			oMap.put("ISLEM_LISTESI",j,"PERIYOT", getParamText("9815_ISLEM_PERIYOTLARI", sMap.getString("ISLEM_LIST",j,"PERIYOT")));
			oMap.put("ISLEM_LISTESI",j,"ISLEM_ID",sMap.getString("ISLEM_LIST",j,"IS_KODU"));
			oMap.put("ISLEM_LISTESI",j,"IS_TANIMI",sMap.getString("ISLEM_LIST",j,"IS_TANIMI"));
			oMap.put("ISLEM_LISTESI",j,"SURE",sMap.getString("ISLEM_LIST",j,"SURE"));
			oMap.put("ISLEM_LISTESI",j,"ADET", 0);
		}
				
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9816_FILL_BOLUM_COMBO")
	public static GMMap fillGroupCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBolumKod> bolumKodList = (List<islBolumKod>)session.createCriteria(islBolumKod.class)
													.addOrder(Order.asc("kod")).list();
		for (islBolumKod bolumKod : bolumKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BOLUM", bolumKod.getKod().toString(), bolumKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9816_FILL_BIRIM_COMBO")
	public static GMMap fillBirimCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBirimKod> birimKodList = (List<islBirimKod>)session.createCriteria(islBirimKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islBirimKod birimKod : birimKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BIRIM", birimKod.getId().getKod().toString(), birimKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9816_FILL_SERVIS_COMBO")
	public static GMMap fillServisCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islServisKod> servisKodList = (List<islServisKod>)session.createCriteria(islServisKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.add(Restrictions.eq("id.birimKod", iMap.getBigDecimal("BIRIM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islServisKod servisKod : servisKodList) {
			GuimlUtil.wrapMyCombo(oMap, "SERVIS", servisKod.getId().getKod().toString(), servisKod.getAciklama());
		}
		return oMap;
	}

		
	@GraymoundService("BNSPR_TRN9816_SAVE")
	public static GMMap save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		GMMap oMap = new GMMap();
		try{
		if (iMap.getSize("ISLEM_LIST")>0){
			for (int i = 0; i < iMap.getSize("ISLEM_LIST"); i++) {
				islislemSureleriTxId id = new islislemSureleriTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setIsKodu(iMap.getBigDecimal("ISLEM_LIST",i,"ISLEM_ID"));
					islislemSureleriTx islemSureTx = new islislemSureleriTx();
					islemSureTx.setId(id);
					islemSureTx.setAciklama(iMap.getString("ISLEM_LIST",i,"ACIKLAMA"));
					islemSureTx.setAdet(iMap.getBigDecimal("ISLEM_LIST",i,"ADET"));
					islemSureTx.setEkSure(iMap.getBigDecimal("ISLEM_LIST",i,"EK_SURE"));
					islemSureTx.setIslemTarihi(iMap.getDate("TARIH"));
					islemSureTx.setIsTanimi(iMap.getString("ISLEM_LIST",i,"IS_TANIMI"));
					islemSureTx.setKategori(iMap.getString("ISLEM_LIST",i,"KATEGORI"));
					islemSureTx.setPeriyot(iMap.getString("ISLEM_LIST",i,"PERIYOT_KOD"));
					islemSureTx.setLastModified(date);
					islemSureTx.setSure(iMap.getBigDecimal("ISLEM_LIST",i,"SURE"));
					islemSureTx.setUserCode(iMap.getString("KULLANICI_KOD"));
					islemSureTx.setFte(iMap.getBigDecimal("ISLEM_LIST",i,"FTE"));
					islemSureTx.setToplamSure(iMap.getBigDecimal("ISLEM_LIST",i,"TOPLAM_SURE"));
					session.saveOrUpdate(islemSureTx);
		}
		
		session.flush();
		oMap = callSendTrn(iMap);
		}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9816_KONTROL_HESAPLA")
	public static GMMap kontrolHesapla(GMMap iMap){
		BigDecimal toplamFte = BigDecimal.ZERO;
		for (int i = 0; i < iMap.getSize("ISLEM_LIST"); i++) {
			if(iMap.getBigDecimal("ISLEM_LIST",i,"SURE")==null || iMap.getBigDecimal("ISLEM_LIST",i,"ADET")==null){
				iMap.put("HATA_NO", new BigDecimal(660));
	            iMap.put("P1", i+1 + ". sat�rda adet ve s�re girilmemi�");
	            return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			BigDecimal ekSure = iMap.getBigDecimal("ISLEM_LIST",i,"EK_SURE")==null?BigDecimal.ZERO:iMap.getBigDecimal("ISLEM_LIST",i,"EK_SURE");
			String aciklama = iMap.getString("ISLEM_LIST",i,"ACIKLAMA")==null?"":iMap.getString("ISLEM_LIST",i,"ACIKLAMA");
			if(ekSure.compareTo(BigDecimal.ZERO)!=0 && aciklama.length()<25){
			iMap.put("HATA_NO", new BigDecimal(660));
            iMap.put("P1", i+1 + ". sat�rda en az 25 karakter a��klama girmelisiniz.");
            	return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			BigDecimal toplamSure = iMap.getBigDecimal("ISLEM_LIST",i,"SURE").multiply(iMap.getBigDecimal("ISLEM_LIST",i,"ADET")).add(ekSure);
			BigDecimal fte = toplamSure.divide(BigDecimal.valueOf(Long.valueOf(getGlobalParam("9815_FTE_SANIYE"))), 2, BigDecimal.ROUND_HALF_UP);
			iMap.put("ISLEM_LIST",i,"TOPLAM_SURE", toplamSure);
			iMap.put("ISLEM_LIST",i,"FTE", fte);
			toplamFte=toplamFte.add(fte);
		}
		iMap.put("TOPLAM_FTE", toplamFte);
		return iMap;
	}
	private static GMMap callSendTrn(GMMap iMap){
		iMap.put("TRX_NAME" , "9816");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
	
	
	private static String getParamText(String kod,String key){
		GMMap iMap = new GMMap();
		iMap.put("KOD", kod);
		iMap.put("KEY", key);
		String deger =  GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap).getString("TEXT");
		return deger;
	}
	public static String getGlobalParam(String batchParamCode) {
        GMMap iMapG = new GMMap();
        iMapG.put("KOD" , batchParamCode);
        iMapG.put("TRIM_QUOTES" , true);
        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
        return batchNo;
    }
}
