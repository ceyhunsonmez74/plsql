package tr.com.calikbank.bnspr.system.services;

import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GonislemDetayTx;
import tr.com.aktifbank.bnspr.dao.MuhislemClientinfo;
import tr.com.aktifbank.bnspr.dao.MuhislemAssignee;
import tr.com.aktifbank.bnspr.dao.MuhislemAssigneeDetail;
import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlIslemServisPr;
import tr.com.calikbank.bnspr.dao.GonislemDosyaTx;
import tr.com.calikbank.bnspr.dao.GonislemTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * @author obss1
 * 
 */
public class SystemMesajKutusuGelen {

	private static final Logger logger = Logger.getLogger(SystemMesajKutusuGelen.class);
	
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_GET_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_MESAJ_KUTUSU_GELEN_RECORD(?,?,?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor,
			stmt.setBigDecimal(i++,iMap.getBigDecimal("EKRAN_KOD"));
			stmt.setString(i++,iMap.getString("KANAL_KOD"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++,iMap.getString("HESAP_NO"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++,iMap.getString("KULLANICI_KOD"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++,iMap.getString("IS_SAHIBI"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MUSTERI_UNVANI", rSet.getString(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ASSIGNEE", rSet.getString(j++));
			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	/*@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_GET_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");

			GMMap oMap = new GMMap();
			StringBuffer query = new StringBuffer();
			query.append("select ");
			query.append("k.amir_sube_kod,pkg_genel_pr.sube_adi(k.AMIR_SUBE_KOD) AMIR_SUBE_ADI,k.NUMARA,k.ISLEM_KOD,k.DURUM_ADI,k.DURUM,to_char(k.KAYIT_TARIH,'dd/mm/yyyy') KAYIT_TARIH,");
			query.append("k.MUSTERI_NUMARA,pkg_musteri.unvan(k.MUSTERI_NUMARA) MUSTERI_UNVANI,k.HESAP_NUMARA,k.TUTAR,k.DOVIZ_KOD, ");
			query.append(" k.FIS_NUMARA,k.MODUL_TUR_KOD,k.URUN_TUR_KOD,k.URUN_SINIF_KOD, ");
			query.append("k.DOGRULANABILIR_MI,k.ONAYLANABILIR_MI,k.IPTAL_ONAYLANABILIR_MI,k.IPTAL_EDILEBILIR_MI,k.GERI_CEVRILEBILIR, ");
			query.append(" k.ACIKLAMA,k.KAYIT_KULLANICI_KODU,to_char(k.KAYIT_SISTEM_TARIHI,'dd/mm/yyyy hh24:mi:ss') KAYIT_TARIH,");
			query.append("k.DOGRU_KULL_KODU,to_char(k.DOGRULAMA_SISTEM_TARIH,'dd/mm/yyyy hh24:mi:ss') DOGRU_TARIH, ");
			query.append("k.ONAY_KULL_KODU ,to_char(k.ONAYLAMA_SISTEM_TARIH,'dd/mm/yyyy hh24:mi:ss') ONAY_TARIH, ");
			query.append("k.IPTAL_KULLANICI_KODU,to_char(k.IPTAL_SISTEM_TARIHI,'dd/mm/yyyy hh24:mi:ss') IPTAL_TARIH, ");
			query.append("k.IPTAL_ONAY_KULL_KODU,k.iptal_onay_tarih,Pkg_genel_pr.islem_ekran_adi(k.ISLEM_KOD), ");
			query.append("k.kanal_numara, k.kanal_adi, k.kanal_alt_kod, k.kanal_alt_adi,k.kullanici_aciklama, ");
			query.append("k.fis_izlenebilir_mi ");
			query.append("from v_muh_islem_dog_on_ip k ");
			query.append("where k.durum not in ('P','R') ");
			query.append("order by k.NUMARA desc ");

			stmt = conn.prepareStatement(query.toString());
			rSet = stmt.executeQuery();

			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MUSTERI_UNVANI", rSet.getString(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));

			}

			oMap.put("ROW_COUNT", oMap.getSize(tableName));

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}*/

	/*
	 * (BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA)Servisinde i�lemin
	 * do�rulanmas�, onaylanmas�, iptali ve iptal onaylanmas� yap�lmaktad�r. �ki
	 * parametresi vard�r.Ald��� parametreler i�lem numaras� ve statik bir
	 * texttir. Statik text => 'D' = Do�rulama, 'O' = Onaylama, 'I' = �ptal,
	 * 'IO' = �ptal Onay i�indir.
	 */

	@GraymoundService("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA")
	public static GMMap islemDogrulaOnayIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		String islemTuru = iMap.getString("ISLEM_TURU");
		boolean isBpm = iMap.get("IS_BPM")==null? false: iMap.getBoolean("IS_BPM");
		boolean executePostService = false;

		try {
			conn = DALUtil.getGMConnection();
			if(!isBpm){
			if ("D".equals(islemTuru)) {
				stmt = conn.prepareCall("{call PKG_TX.DOGRULA_ISLEM_YURUT(?,true,?)}");
			} else if ("O".equals(islemTuru)) {
				stmt = conn.prepareCall("{call PKG_TX.ONAYLA_ISLEM_YURUT(?,true,?)}");
			} else if ("I".equals(islemTuru)) {
				stmt = conn.prepareCall("{call pkg_tx.iptal_islem_yurut(?,?)}");
			} else if ("IO".equals(islemTuru)) {
				stmt = conn.prepareCall("{call pkg_tx.iptal_onay(?,true,?)}");
			} else if ("DR".equals(islemTuru)) {
				stmt = conn.prepareCall("{call PKG_TX.DOGRULA(?,false,?)}");
			} else if ("OR".equals(islemTuru)) {
				stmt = conn.prepareCall("{call PKG_TX.ONAY(?,false,?)}");
			} else if ("IOR".equals(islemTuru)) {
				stmt = conn.prepareCall("{call pkg_tx.iptal_onay(?,false,?)}");
			} else if ("IG".equals(islemTuru)) {
				stmt = conn.prepareCall("{call pkg_tx.islem_geri_gonder(?,?)}");
			} 
			
			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(2, iMap.getString("ACIKLAMA"));

			stmt.execute();
			GMServerDatasource.close(stmt);
			
            if (iMap.getBigDecimal("ISLEM_KODU") == null) {
            	stmt = conn.prepareCall("{? = call PKG_TX.Islem_kod(?)}");
            	int i = 1;
            	stmt.registerOutParameter(i++, Types.NUMERIC);
            	stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
            	stmt.execute();
            	iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
            }

			executePostService = false;

			if ("OR".equals(islemTuru) || "IG".equals(islemTuru) || "DR".equals(islemTuru) ) {
				executePostService = true;
			} else if ("O".equals(islemTuru)) {
				stmt2 = conn.prepareCall("{? = call pkg_tx.kalan_onay_sayisi(?) }");
			} else if ("D".equals(islemTuru)) {
				stmt2 = conn.prepareCall("{? = call pkg_tx.kalan_dogrulama_sayisi(?)}");
			} else if ("IO".equals(islemTuru) || "I".equals(islemTuru)) {
				stmt2 = conn.prepareCall("{? = call pkg_tx.kalan_iptal_onay_sayisi(?)}");
			}

			if (stmt2 != null) {
				stmt2.registerOutParameter(1, Types.INTEGER);
				stmt2.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));

				stmt2.execute();

				executePostService = stmt2.getInt(1) == 0;
			}
			}
			else{
				if(islemTuru.equals("O")){
					stmt = conn.prepareCall("{call PKG_TX.ONAYLA_ISLEM_YURUT(?,true,?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
					stmt.setString(2, iMap.getString("ACIKLAMA"));

					stmt.execute();
					GMServerDatasource.close(stmt);
				
				}
				executePostService = true;
			}
			if (executePostService) {
				 if (iMap.getBigDecimal("ISLEM_KODU") == null) {
		            	stmt = conn.prepareCall("{? = call PKG_TX.Islem_kod(?)}");
		            	int i = 1;
		            	stmt.registerOutParameter(i++, Types.NUMERIC);
		            	stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
		            	stmt.execute();
		            	iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
		            }
				oMap.putAll(GMServiceExecuter.execute("BNSPR_ISLEM_EXECUTE_POST_SERVICE", iMap)); // e�er varsa i�lem sonras� servisi �a��r�r
			}

            iMap.put("MESSAGE", oMap.getString("MESSAGE"));
            oMap = getMessage(iMap);
            
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);	
			if(iMap.getString("ANA_SUBE")!= null && !iMap.getString("ANA_SUBE").isEmpty())
			{
				GMMap tempMap = new GMMap();
				tempMap.put("BRANCH_ID", iMap.getString("ANA_SUBE"));
				tempMap.put("GUIML_NAME", iMap.getString("GUIML_NAME"));
				GMServiceExecuter.execute("BNSPR_CORE_SET_USER_BRANCH", tempMap);
			}
		}
		return oMap;
	}

	public static GMMap getMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tx.msj_islem_durum(?)}");
			stmt.registerOutParameter(1, Types.CHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));

			stmt.execute();

			if(iMap.getString("MESSAGE") != null)
				oMap.put("MESSAGE", stmt.getString(1) + " "+ iMap.getString("MESSAGE"));
			else
				oMap.put("MESSAGE", stmt.getString(1));

		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_ISLEM_EXECUTE_POST_SERVICE")
	public static GMMap executePostService(GMMap iMap){
		GMMap oMap = new GMMap();
		String postServiceName = null;
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = session.createCriteria(GnlIslemServisPr.class).add(Restrictions.eq("id.islemKodu", iMap.getBigDecimal("ISLEM_KODU"))).add(Restrictions.eq("id.islemTuru", iMap.getString("ISLEM_TURU"))).list();
		if(list.size()>0)
			postServiceName = ((GnlIslemServisPr)list.get(0)).getServisAdi();
		else if("I".equals(iMap.getString("ISLEM_TURU"))){
			list = session.createCriteria(GnlIslemServisPr.class).add(Restrictions.eq("id.islemKodu", iMap.getBigDecimal("ISLEM_KODU"))).add(Restrictions.eq("id.islemTuru", "IO")).list();			
			if(list.size()>0)
				postServiceName = ((GnlIslemServisPr)list.get(0)).getServisAdi();
		}
		
		if(postServiceName!=null){
			if(logger.isDebugEnabled())
				logger.debug("��lemin onay sonras� servisi var:" + postServiceName);
			oMap.putAll(GMServiceExecuter.execute(postServiceName, iMap));
			if(logger.isDebugEnabled())
				logger.debug("��lemin onay sonras� servisi " + postServiceName + " �a�r�ld�");
		}
		else{
			logger.debug("��lemin onay sonras� servisi yok");			
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_4001")
	public static GMMap getRecordMsjGlnKutusu4001(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_MESAJ_KUTUSU_GELEN_4001(?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("OPER_BOLUM_KOD"));
			stmt.setString(i++, iMap.getString("KULLANICI_KOD"));
			stmt.setString(i++, iMap.getString("ISLEM_GONDERIM_GELEN_CLAIM_USER"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MUSTERI_UNVANI", rSet.getString(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TURU",rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ONCELIGI",rSet.getString(j++));
				oMap.put(tableName, row, "CLAIM_USER",rSet.getString(j++));
				oMap.put(tableName, row, "CLAIM_DATE",rSet.getDate(j++));
				oMap.put(tableName, row, "PENDING_USER",rSet.getString(j++));
				oMap.put(tableName, row, "PENDING_DATE",rSet.getDate(j++));
				oMap.put(tableName, row, "PENDING_DESC",rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ADEDI",rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "IMZA_DOGRULANDI_MI","E".equals(rSet.getString(j++))?"Evet":"Hay�r");
				oMap.put(tableName, row, "TEKLIF_TEYIT_ALINDI_MI_EH", "E".equals(rSet.getString(j++))?"Evet":"Hay�r");
				oMap.put(tableName, row, "FIRMA_YETKILISI",rSet.getString(j++));
				oMap.put(tableName, row, "TEYIDI_ALAN",rSet.getString(j++));
				oMap.put(tableName, row, "SAAT",rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA",rSet.getString(j++));
				oMap.put(tableName, row, "PORTFOY_BILGISI",rSet.getString(j++));
				oMap.put(tableName, row, "MASRAF_TUT",rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOMISYON_TUT",rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MASRAF_KOMISYON_ORAN",rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MASRAF_KOMISYON_EKNO",rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "PORTFOY_KOD",rSet.getString(j++));
				oMap.put(tableName, row, "IS_ILISKISI_AMAC_KOD",rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KULLANICIAD",rSet.getString(j++));
			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_4001_GET_DOSYA_TX")
	public static GMMap gonDosyaTxMap(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GonislemDosyaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			String tableName = "DOSYALAR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GonislemDosyaTx GonislemDosyaTx = (GonislemDosyaTx) iterator.next();
				oMap.put(tableName, row, "FILE_NAME", GonislemDosyaTx.getId().getDosyaAdi());
				oMap.put(tableName, row, "FILE_TYPE", StringUtils.lowerCase(FilenameUtils.getExtension(GonislemDosyaTx.getId().getDosyaAdi())));
				oMap.put(tableName, row, "DYS_FILE_NAME", GonislemDosyaTx.getDosyaPath());
				row++;
			}			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
		
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_4001_GET_CLICKED_ISLEM_DOKUMAN")
	public static GMMap getIslemDokuman(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String dosyaPath = iMap.getString("DYS_FILE_NAME");
			GMMap dMap = GMServiceExecuter.call("DYS_CMIS_GET_DOKUMAN_LINK_BY_FILENAME_V2", new GMMap().put("DOKUMAN_ADI", dosyaPath).put("DOKUMAN_CLASS", "Islem").put("DOKUMAN_BYTE_ARRAY_NEEDED", true));
			ByteArrayType data = new ByteArrayType();
			data.setData((byte[]) dMap.get("DOKUMAN_BYTE_ARRAY"));
			oMap.put("DOKUMAN_BYTE_ARRAY", data);
			oMap.put("DOKUMAN_LINK", dMap.getString("DOKUMAN_LINK"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_GELEN_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValuesGelen(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KANAL_KOD", true, "SELECT KOD ,ACIKLAMA FROM V_ML_GNL_KANAL_GRUP_KOD_PR ORDER BY TO_NUMBER(KOD)"); 
        	return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_CLAIM_TRANSACTION")
	public static GMMap claimTransaction(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap lMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int s = iMap.getSize("ISLEM_LIST");
		for (int i = 0; i < s; i++) {
			if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
			{
			GonislemTx gonIslemTx = (GonislemTx) session.createCriteria(GonislemTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_LIST",i,"NO"))).uniqueResult();
					//new GonislemTx(iMap.getBigDecimal("ISLEM_LIST",i,"NO"));
			if (iMap.getString("CLAIM").equals("E")){
				gonIslemTx.setClaimUser(iMap.getString("USER"));
				gonIslemTx.setClaimDate(new Date());
				lMap.put("ACTION", "CT");
			}
			else{
				gonIslemTx.setClaimUser("");
				gonIslemTx.setClaimDate(null);
				lMap.put("ACTION", "CB");
			}
			session.saveOrUpdate(gonIslemTx);
			lMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_LIST",i,"NO"));
			lMap.put("CLAIM_USER", iMap.getString("USER"));
			lMap.put("CLAIM_DATE", new Date());
			GMServiceExecuter.executeAsync("BNSPR_SEND_TRANSACTION_LOG", lMap);
			}
		}
		session.flush();
		return oMap;
	}
	@GraymoundService("BNSPR_PEND_TRANSACTION")
	public static GMMap pendTransaction(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap lMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int s = iMap.getSize("ISLEM_LIST");
		for (int i = 0; i < s; i++) {
		if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
		{
			GonislemTx gonIslemTx = (GonislemTx) session.createCriteria(GonislemTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_LIST",i,"NO"))).uniqueResult();
		if (iMap.getString("PEND").equals("E")){
			gonIslemTx.setPendingUser(iMap.getString("USER"));
			gonIslemTx.setPendingDate(new Date());
			gonIslemTx.setPendingDesc(iMap.getString("PENDING_DESC"));
			lMap.put("ACTION", "PT");
		}
		else{
			gonIslemTx.setPendingUser("");
			gonIslemTx.setPendingDate(null);
			gonIslemTx.setPendingDesc(null);
			lMap.put("ACTION", "PB");
		}
		session.saveOrUpdate(gonIslemTx);
		lMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_LIST",i,"NO"));
		lMap.put("PENDING_USER", iMap.getString("USER"));
		lMap.put("PENDING_DATE", new Date());
		lMap.put("PENDING_DESC", iMap.getString("PENDING_DESC"));
		GMServiceExecuter.executeAsync("BNSPR_SEND_TRANSACTION_LOG", lMap);
		}
		}
		session.flush();
		return oMap;
	}
	@GraymoundService("BNSPR_SEND_TRANSACTION_LOG")
	public static GMMap sendTransactionLog(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try{
		GonislemDetayTx gonislemDetayTx = new GonislemDetayTx();
		gonislemDetayTx.setAction(iMap.getString("ACTION"));
		gonislemDetayTx.setClaimDate(StringUtil.isEmpty(iMap.getString("CLAIM_DATE"))?null:iMap.getDate("CLAIM_DATE"));
		gonislemDetayTx.setClaimUser(StringUtil.isEmpty(iMap.getString("CLAIM_USER"))?null:iMap.getString("CLAIM_USER"));
		gonislemDetayTx.setPendingDate(StringUtil.isEmpty(iMap.getString("PENDING_DATE"))?null:iMap.getDate("PENDING_DATE"));
		gonislemDetayTx.setPendingUser(StringUtil.isEmpty(iMap.getString("PENDING_USER"))?null:iMap.getString("PENDING_USER"));
		gonislemDetayTx.setPendingDesc(StringUtil.isEmpty(iMap.getString("PENDING_DESC"))?null:iMap.getString("PENDING_DESC"));
		gonislemDetayTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		session.saveOrUpdate(gonislemDetayTx);
		session.flush();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_CHECKED_TRANSACTION_CONTROL")
	public static GMMap checkedTransactionControl(GMMap iMap){
		GMMap oMap = new GMMap();
		oMap.put("ISLEM_VAR", "H");
		int s = iMap.getSize("ISLEM_LIST");
		for (int i = 0; i < s; i++) {
			if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
			{
				oMap.put("ISLEM_VAR", "E");
				break;
			}
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_4001_SAVE_TO_GMROOT_FILES")
	public static GMMap saveDoc(GMMap iMap) {
	    final String GMROOT_FILES = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root" + File.separator + "files";
		String filepath = null;
		try {
		    String filename = iMap.getString("FILE_NAME");
		    ByteArrayType fileAsByteArr = (ByteArrayType) iMap.get("DOKUMAN_BYTE_ARRAY");

		    filepath = GMROOT_FILES + File.separator + filename;
            File document = new File(filepath);
            FileUtils.writeByteArrayToFile(document, fileAsByteArr.getData());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_OTP_KONTROL")
	public static GMMap otpKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? =call PKG_TRN9957.otp_gitsin(?) }";
			oMap.put("OTP_GITSIN", DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getBigDecimal("ISLEM_NO")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_MESAJ_KUTUSU_CLIENT_INFO")
	public static GMMap mesajKutusuClientInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap=new GMMap();
	        
	        MuhislemClientinfo muhislemClientinfo = (MuhislemClientinfo) session.createCriteria(MuhislemClientinfo.class).add(Restrictions.eq("numara", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
	      
	      if (muhislemClientinfo != null)  {
            oMap.put("NUMARA", muhislemClientinfo.getNumara());
            oMap.put("IP_ADRES", muhislemClientinfo.getIpAdres());
            oMap.put("PORT", muhislemClientinfo.getPort());
            oMap.put("OTP_DEVICE_ID", muhislemClientinfo.getOtpDeviceId());
            oMap.put("CITY", muhislemClientinfo.getCity());
            oMap.put("COUNTRY", muhislemClientinfo.getCountry());
            oMap.put("STATE", muhislemClientinfo.getState());
            oMap.put("LATITUDE", muhislemClientinfo.getLatitude());
            oMap.put("LONGITUDE", muhislemClientinfo.getLongitude());
	      }
    		return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

	   @GraymoundService("BNSPR_CUSTOMER_FRAUD_EK_KONTROL_LIST")
		public static GMMap fraudEkKontrolList(GMMap iMap) {
		    ResultSet rSet = null;   
		    CallableStatement stmt = null;
		    Connection conn = null;
		    
		    try{
		        conn = DALUtil.getGMConnection();	            
		        stmt = conn.prepareCall("{? = call pkg_fraud_kontrol.RC_Ek_Kontrol(?) }");
		        int i = 1;
		        stmt.registerOutParameter(i++, -10);
		        stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));	
		        stmt.execute();     
		        
		        rSet = (ResultSet) stmt.getObject(1);		        
		        return DALUtil.rSetResults(rSet, "RESULT");
		    }catch (Exception e) {
		        throw ExceptionHandler.convertException(e);
		    }finally{
		        GMServerDatasource.close(rSet);
		        GMServerDatasource.close(stmt);
		        GMServerDatasource.close(conn);
		    }
		}	
	
	   @GraymoundService("BNSPR_MESAJ_KUTUSU_SAVE_ASSIGNEE")
	 		public static GMMap mesajKutusuSaveAssignee(GMMap iMap) {
	 		   try {
	 	           Session session = DAOSession.getSession("BNSPRDal");	         
	              
	 	           MuhislemAssignee assignee =  new MuhislemAssignee(); 
	 	           MuhislemAssigneeDetail assigneeDetail =  new MuhislemAssigneeDetail();     
	                    
	 	           assignee.setNumara(iMap.getBigDecimal("TRX_NO"));
	 	           assignee.setAssignee(iMap.getString("ASSIGNEE"));

		           assigneeDetail.setNumara(iMap.getBigDecimal("TRX_NO"));
		           assigneeDetail.setAssignee(iMap.getString("ASSIGNEE"));
		           assigneeDetail.setAciklama(iMap.getString("ACIKLAMA"));
	                                         
	               session.saveOrUpdate(assignee);
	               session.saveOrUpdate(assigneeDetail);
	               session.flush();

	 	           return new GMMap();
	 	        } catch (Exception e) {
	 	            throw ExceptionHandler.convertException(e);
	 	        }

	 		}
	   
	   @GraymoundService("BNSPR_MESAJ_KUTUSU_GET_ASSIGNEE_DETAIL")
		public static GMMap mesajKutusuGetAssigneeDetail(GMMap iMap) {
		    ResultSet rSet = null;   
		    CallableStatement stmt = null;
		    Connection conn = null;
		    
		    try{
		        conn = DALUtil.getGMConnection();	            
		        stmt = conn.prepareCall("{? = call pkg_rc_mesajkutusu.rc_assignee_detail(?) }");
		        int i = 1;
		        stmt.registerOutParameter(i++, -10);
		        stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));	
		        stmt.execute();     
		        
		        rSet = (ResultSet) stmt.getObject(1);		        
		        return DALUtil.rSetResults(rSet, "RESULT");
		    }catch (Exception e) {
		        throw ExceptionHandler.convertException(e);
		    }finally{
		        GMServerDatasource.close(rSet);
		        GMServerDatasource.close(stmt);
		        GMServerDatasource.close(conn);
		    }
		}	
	   
		@GraymoundService("BNSPR_MESAJ_KUTUSU_GET_ASSIGNEE")
		public static GMMap mesajKutusuGetAssignee(GMMap iMap){
			GMMap oMap = new GMMap();
			try{
				Session session = DAOSession.getSession("BNSPRDal");
				
				MuhislemAssignee muhIslemAssignee = (MuhislemAssignee) session.createCriteria(MuhislemAssignee.class)
																  .add(Restrictions.eq("numara", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				
				if (muhIslemAssignee != null) {
					oMap.put("ASSIGNEE", muhIslemAssignee.getAssignee());
				}
						
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		    }
			return oMap;
		}
}

