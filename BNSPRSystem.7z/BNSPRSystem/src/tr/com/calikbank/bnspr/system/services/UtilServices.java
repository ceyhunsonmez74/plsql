package tr.com.calikbank.bnspr.system.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class UtilServices {

	public static final String ALL_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; 
	public static final String UPPERCASE_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";	
	public static final String LOWERCASE_LETTER = "abcdefghijklmnopqrstuvwxyz";	
	public static final String ALL_DIGITS = "0123456789";

	/**
	 * @author fatih.karakoc
	 * @param iMap
	 * 			PASSWORD_LENGTH  - �stenilen �ifre uzunlu�u
	 * 			CHARACTER_SETS   - �ifre �retmede kullan�c�lacak karakter k�melerini i�eren tablo 
	 * 				- CHARACTER_SET  : karakter k�mesi
	 * 				- MIN_COUNT      : zorunlu de�il, sadece gerekli durumlarda beslenmeli	
	 * @return
	 * 		  oMap
	 * 			PASSWORD
	 */	
	@GraymoundService("BNSPR_COMMON_GENERATE_PSWD")
	public static GMMap generatePassword(GMMap iMap){
		GMMap oMap  = new GMMap();
		try{
			int length = iMap.getInt("PASSWORD_LENGTH");
			List<Character> charList = new ArrayList<Character>();
			Random generator = new Random();
			StringBuilder allCharSets = new StringBuilder("");
			
			boolean exitLoop = false;
			
			String tableName = "CHARACTER_SETS";
			for(int i=0; i<iMap.getSize(tableName) && !exitLoop; i++){
				String charSet = iMap.getString(tableName,i,"CHARACTER_SET");
				allCharSets.append(charSet);
				int minCount = iMap.getInt(tableName, i, "MIN_COUNT");
				for(int j=0; j<minCount && !exitLoop ;j++){
					int index = generator.nextInt(charSet.length());
					charList.add( new Character(charSet.charAt(index)) );
					if(charList.size()>=length)
						exitLoop = true;
				}	
			}
			
			int remainingSize = length - charList.size();
	
			for(int i=0; i<remainingSize ;i++){
				int index = generator.nextInt(allCharSets.length());
				charList.add( new Character(allCharSets.charAt(index)) );
			}
	
			Collections.shuffle(charList);
			
			StringBuilder password = new StringBuilder("");
			for(int i=0; i<charList.size(); i++){
				password.append( ((Character)charList.get(i)).toString() );
			}
		
			oMap.put("PASSWORD", password.toString());

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	} 
	
	/*
	public static void main(String args[]){		
		GMMap map = new GMMap();
		String tableName = "CHARACTER_SETS";
		map.put("PASSWORD_LENGTH", 20);
		map.put(tableName, 0, "CHARACTER_SET", UtilServices.ALL_DIGITS);
		map.put(tableName, 0, "MIN_COUNT", 10);
		map.put(tableName, 1, "CHARACTER_SET", UtilServices.UPPERCASE_LETTERS);
		map.put(tableName, 1, "MIN_COUNT", 5);
		System.out.println(new UtilServices().generatePassword(map).getString("PASSWORD"));
	}
	*/
	
	
}
