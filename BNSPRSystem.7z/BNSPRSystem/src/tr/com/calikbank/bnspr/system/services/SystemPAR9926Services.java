package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlUrunSinifAltHesapPr;
import tr.com.aktifbank.bnspr.dao.VMlGnlModulUrunKodPr;
import tr.com.aktifbank.bnspr.dao.VMlGnlModulUrunKodPrId;
import tr.com.aktifbank.bnspr.dao.VMlModulUrunSinifKodPr;
import tr.com.aktifbank.bnspr.dao.VMlModulUrunSinifKodPrId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9926Services {
	@GraymoundService("BNSPR_PAR9926_GET_SINIF_TUR_KOD")
	public static Map<?,?> getSinifTurKod(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			VMlGnlModulUrunKodPr gnlModulUrunKodPr = (VMlGnlModulUrunKodPr) session.get(VMlGnlModulUrunKodPr.class, new VMlGnlModulUrunKodPrId(iMap.getString("MODUL_TUR_KOD"), iMap.getString("URUN_TUR_KOD")));
			String tableName = "SINIF_TANIM";
			int row = 0;
			for (Iterator<?> iterator = gnlModulUrunKodPr.getGnlModulUrunSinifKodPrs().iterator(); iterator.hasNext(); row++) {
				VMlModulUrunSinifKodPr gnlModulUrunSinifKodPr = (VMlModulUrunSinifKodPr) iterator.next();
				oMap.put(tableName, row, "KOD", gnlModulUrunSinifKodPr.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", gnlModulUrunSinifKodPr.getAciklama());
				oMap.put(tableName, row, "MUSTERI_URUNU", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getMusteriUrunu()));
				oMap.put(tableName, row, "MUSTERI_TIPINE_BAGIMLI", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getMusteriTipineBagimli()));
				oMap.put(tableName, row, "LC", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getLc()));
				oMap.put(tableName, row, "RISK_YARAT", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getRiskYarat()));
				oMap.put(tableName, row, "NAKDI", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getNakdi()));
				oMap.put(tableName, row, "REF_KOD", gnlModulUrunSinifKodPr.getRefKod());
				oMap.put(tableName, row, "RISK_KODU", gnlModulUrunSinifKodPr.getRiskKodu());
				oMap.put(tableName, row, "URUN_TUR_KOD", gnlModulUrunSinifKodPr.getId().getUrunTurKod());
				oMap.put(tableName, row, "MODUL_TUR_KOD", gnlModulUrunSinifKodPr.getId().getModulTurKod());
				oMap.put(tableName, row, "DEK", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getDek()));
				oMap.put(tableName, row, "SPOT_ROTATIF", gnlModulUrunSinifKodPr.getSpotRotatif());
				oMap.put(tableName, row, "ALT_HESAP", GuimlUtil.convertToCheckBoxValue(gnlModulUrunSinifKodPr.getAltHesap()));
				
			}
			
		
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9926_GET_ALT_HESAP_SINIF_KOD")
	public static Map<?,?> getAltHesapSinifTurKod(GMMap iMap){
		try{
			
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?>  list = (List<?>) session.createCriteria(GnlUrunSinifAltHesapPr.class)
			 	.add(Restrictions.eq("modulTurKod",iMap.getString("MODUL_TUR_KOD")))
			    .add(Restrictions.eq("urunTurKod", iMap.getString("URUN_TUR_KOD")))
			    .add(Restrictions.eq("urunSinifKod", iMap.getString("URUN_SINIF_KOD"))).list();
			
			String tableName = "ALT_HESAP";
			int row = 0;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlUrunSinifAltHesapPr gnlUrunSinifAltHesapPr = (GnlUrunSinifAltHesapPr) iterator.next();
				GMMap xMap = new GMMap();
				xMap.put(tableName, row, "TABLE_NAME", 	"GNL_URUN_SINIF_ALT_HESAP_PR");   
				oMap.put(tableName, row, "KOD",	gnlUrunSinifAltHesapPr.getKod());
				oMap.put(tableName, row, "MODUL_TUR_KOD", gnlUrunSinifAltHesapPr.getModulTurKod());
				oMap.put(tableName, row, "URUN_TUR_KOD", gnlUrunSinifAltHesapPr.getUrunTurKod());
				oMap.put(tableName, row, "URUN_SINIF_KOD", gnlUrunSinifAltHesapPr.getUrunSinifKod());
				oMap.put(tableName, row, "TAHAKKUK_MODUL_KOD", gnlUrunSinifAltHesapPr.getTahakkukModulKod());
				oMap.put(tableName, row, "TAHAKKUK_URUN_TUR_KOD", gnlUrunSinifAltHesapPr.getTahakkukUrunTurKod());
				oMap.put(tableName, row, "FAIZ_TAHAKKUK_URUN_SINIF", gnlUrunSinifAltHesapPr.getFaizTahakkukUrunSinif());
				oMap.put(tableName, row, "KOM_TAHAKKUK_URUN_SINIF", gnlUrunSinifAltHesapPr.getKomTahakkukUrunSinif());
				
			}
			
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR9926_SAVE_SINIF_TUR_KOD")
	public static Map<?,?> saveSinifTurKod(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "DEL_LIST";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				Object o = find(iMap.getString("MODUL_KOD"), iMap.getString("URUN_KOD"), iMap.getString(tableName, row, "KEY"));
				if(o != null)
					session.delete(o);
			}
			
			tableName = "SINIF_TANIM";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				VMlModulUrunSinifKodPr gnlModulUrunSinifKodPr = new VMlModulUrunSinifKodPr();
				Validator.checkNull(iMap.getString(tableName, row, "ACIKLAMA"), "'A��klama' zorunlu bir aland�r");
				gnlModulUrunSinifKodPr.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlModulUrunSinifKodPr.setMusteriUrunu(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "MUSTERI_URUNU")));
				gnlModulUrunSinifKodPr.setMusteriTipineBagimli(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "MUSTERI_TIPINE_BAGIMLI")));
				gnlModulUrunSinifKodPr.setRiskYarat(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "RISK_YARAT")));
				gnlModulUrunSinifKodPr.setNakdi(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "NAKDI")));
				gnlModulUrunSinifKodPr.setLc(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "LC")));
				gnlModulUrunSinifKodPr.setRefKod(iMap.getString(tableName, row, "REF_KOD"));
				gnlModulUrunSinifKodPr.setSpotRotatif(iMap.getString(tableName, row, "SPOT_ROTATIF"));
				gnlModulUrunSinifKodPr.setAltHesap(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "ALT_HESAP")));
				gnlModulUrunSinifKodPr.setDek(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, row, "DEK")));
				
				BigDecimal riskKodu = GuimlUtil.getTableCellBigDecimal(iMap.getString(tableName, row, "RISK_KODU"));
				if(riskKodu!=null)
					gnlModulUrunSinifKodPr.setRiskKodu(riskKodu.shortValue());
				VMlModulUrunSinifKodPrId id = new VMlModulUrunSinifKodPrId();
				Validator.checkNull(iMap.getString(tableName, row, "KOD"), "'Kod' zorunlu bir aland�r");
				id.setKod(iMap.getString(tableName, row, "KOD"));
				id.setModulTurKod(iMap.getString("MODUL_KOD"));
				id.setUrunTurKod(iMap.getString("URUN_KOD"));
				gnlModulUrunSinifKodPr.setId(id);
				session.saveOrUpdate(gnlModulUrunSinifKodPr);
				
			}
			
			tableName = "ALT_HESAP_TANIM";
			
			 
			if (iMap.getSize(tableName) > 1) {
				iMap.put("HATA_NO", new BigDecimal(1793));
				return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

			}
			if (iMap.getSize(tableName) > 0) {
				List<?>  list = (List<?>) session.createCriteria(GnlUrunSinifAltHesapPr.class)
				 	.add(Restrictions.eq("modulTurKod",iMap.getString(tableName, 0, "MODUL_TUR_KOD")))
				    .add(Restrictions.eq("urunTurKod", iMap.getString(tableName, 0,"URUN_TUR_KOD")))
				    .add(Restrictions.eq("urunSinifKod", iMap.getString(tableName, 0,"URUN_SINIF_KOD"))).list();
		
				int i = 0;
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); i++) {
					GnlUrunSinifAltHesapPr gnlUrunSinifAltHesapPr = (GnlUrunSinifAltHesapPr) iterator.next();
					session.delete(gnlUrunSinifAltHesapPr);
				}
		
				
				for (int row = 0; row < iMap.getSize(tableName); row++) {
					GnlUrunSinifAltHesapPr gnlUrunSinifAltHesapPr = new GnlUrunSinifAltHesapPr();
					Validator.checkNull(iMap.getString(tableName, row, "FAIZ_TAHAKKUK_URUN_SINIF"), "'Faiz tahakkuk �r�n S�n�f' zorunlu bir aland�r");
					Validator.checkNull(iMap.getString(tableName, row, "KOM_TAHAKKUK_URUN_SINIF"), "'Komisyon tahakkuk �r�n S�n�f' zorunlu bir aland�r");
					
					GMMap xMap = new GMMap();
					xMap.put("TABLE_NAME", 	"GNL_URUN_SINIF_ALT_HESAP_PR");   
					gnlUrunSinifAltHesapPr.setKod((BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID"));
					
					gnlUrunSinifAltHesapPr.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
					gnlUrunSinifAltHesapPr.setUrunTurKod(iMap.getString(tableName, row, "URUN_TUR_KOD"));
					gnlUrunSinifAltHesapPr.setUrunSinifKod(iMap.getString(tableName, row, "URUN_SINIF_KOD"));
					gnlUrunSinifAltHesapPr.setTahakkukModulKod(iMap.getString(tableName, row, "TAHAKKUK_MODUL_KOD"));
					gnlUrunSinifAltHesapPr.setTahakkukUrunTurKod(iMap.getString(tableName, row, "TAHAKKUK_URUN_TUR_KOD"));
					gnlUrunSinifAltHesapPr.setFaizTahakkukUrunSinif(iMap.getString(tableName, row, "FAIZ_TAHAKKUK_URUN_SINIF"));
					gnlUrunSinifAltHesapPr.setKomTahakkukUrunSinif(iMap.getString(tableName, row, "KOM_TAHAKKUK_URUN_SINIF"));
					
					session.save(gnlUrunSinifAltHesapPr);
				}
			}
			
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r!");
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}

	public static Object find(String modulKod, String urunKod, String kod) {
		Session session = DAOSession.getSession("BNSPRDal");
		return session.get(VMlModulUrunSinifKodPr.class, new VMlModulUrunSinifKodPrId(modulKod, urunKod, kod));
	}
}
  