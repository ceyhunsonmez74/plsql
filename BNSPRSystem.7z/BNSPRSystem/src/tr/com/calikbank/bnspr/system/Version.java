package tr.com.calikbank.bnspr.system;

public class Version {

}
