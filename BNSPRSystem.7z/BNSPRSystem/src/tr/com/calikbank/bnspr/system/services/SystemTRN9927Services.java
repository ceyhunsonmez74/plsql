package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPr;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.FomBayiTahsilatHesapPrTx;
import tr.com.aktifbank.bnspr.dao.GnlDkGrupUrunSinifTx;
import tr.com.aktifbank.bnspr.dao.GnlDkGrupUrunSinifTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemTRN9927Services {
	@GraymoundService("BNSPR_TRN9927_GET_GRUP_URUN_SINIF")
	public static GMMap getGrupUrunSinif(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					GnlDkGrupUrunSinifPr.class).add(
					Restrictions.eq("id.grupKod", iMap
							.getBigDecimal("DK_GRUP_KODU"))).addOrder(
					Order.asc("id.modulTurKod")).addOrder(
					Order.asc("id.urunTurKod")).addOrder(
					Order.asc("id.urunSinifKod")).list();

			String tableName = "GRUP_URUN_SINIF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlDkGrupUrunSinifPr dkGrupUrunSinifPr = (GnlDkGrupUrunSinifPr)iterator.next();
				oMap.put(tableName, row, "MODUL_TUR_KOD", dkGrupUrunSinifPr.getId().getModulTurKod());
                oMap.put(tableName, row, "URUN_TUR_KOD", dkGrupUrunSinifPr.getId().getUrunTurKod());
                oMap.put(tableName, row, "URUN_SINIF_KOD", dkGrupUrunSinifPr.getId().getUrunSinifKod());
                oMap.put(tableName, row, "DK_HESABI_1", dkGrupUrunSinifPr.getDkAna());
                oMap.put(tableName, row, "DK_HESABI_2", dkGrupUrunSinifPr.getDkFaizGelir());
                oMap.put(tableName, row, "DK_HESABI_3", dkGrupUrunSinifPr.getDkFaizGider());
                oMap.put(tableName, row, "DK_HESABI_4", dkGrupUrunSinifPr.getDkReeskont());
                oMap.put(tableName, row, "DK_HESABI_5", dkGrupUrunSinifPr.getDkKomGelir());
                oMap.put(tableName, row, "DK_HESABI_6", dkGrupUrunSinifPr.getDkKomReeskont());
                oMap.put(tableName, row, "DK_HESABI_7", dkGrupUrunSinifPr.getDkEkhesap7());
                oMap.put(tableName, row, "DK_HESABI_8", dkGrupUrunSinifPr.getDkEkhesap8());
                oMap.put(tableName, row, "DK_HESABI_9", dkGrupUrunSinifPr.getDkEkhesap9());
                oMap.put(tableName, row, "DK_HESABI_10", dkGrupUrunSinifPr.getDkEkhesap10());
                oMap.put(tableName, row, "DK_HESABI_11", dkGrupUrunSinifPr.getDkEkhesap11());
                oMap.put(tableName, row, "DK_HESABI_12", dkGrupUrunSinifPr.getDkEkhesap12());
                oMap.put(tableName, row, "DK_HESABI_13", dkGrupUrunSinifPr.getDkEkhesap13());
                oMap.put(tableName, row, "DK_HESABI_14", dkGrupUrunSinifPr.getDkEkhesap14());
                oMap.put(tableName, row, "DK_HESABI_15", dkGrupUrunSinifPr.getDkEkhesap15());
                oMap.put(tableName, row, "DK_HESABI_16", dkGrupUrunSinifPr.getDkEkhesap16());
                oMap.put(tableName, row, "DK_HESABI_17", dkGrupUrunSinifPr.getDkEkhesap17());
                oMap.put(tableName, row, "DK_HESABI_18", dkGrupUrunSinifPr.getDkEkhesap18());
                oMap.put(tableName, row, "DK_HESABI_19", dkGrupUrunSinifPr.getDkEkhesap19());
                oMap.put(tableName, row, "DK_HESABI_20", dkGrupUrunSinifPr.getDkEkhesap20());
                oMap.put(tableName, row, "INT_BANK_GORUNTU_F", dkGrupUrunSinifPr.getIntBankGoruntuF());
                oMap.put(tableName, row, "INT_BANK_ISLEM_YAPILSIN_F", dkGrupUrunSinifPr.getIntBankIslemYapilsinF());
                
               

			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9927_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> urunGrupList = (List<?>)session.createCriteria(GnlDkGrupUrunSinifTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = urunGrupList.iterator(); iterator.hasNext();) {
				GnlDkGrupUrunSinifTx dkGrupUrunSinifPr = (GnlDkGrupUrunSinifTx) iterator.next();
				session.delete(dkGrupUrunSinifPr);
			}
			
			String tableName = "GRUP_URUN_SINIF";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				
				GnlDkGrupUrunSinifTx dkGrupUrunSinifPr = new GnlDkGrupUrunSinifTx();
				GnlDkGrupUrunSinifTxId dkGrupUrunSinifPrId = new GnlDkGrupUrunSinifTxId();
				
				dkGrupUrunSinifPrId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				dkGrupUrunSinifPrId.setGrupKod(iMap.getBigDecimal("DK_GRUP_KODU"));
				dkGrupUrunSinifPrId.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
				dkGrupUrunSinifPrId.setUrunTurKod(iMap.getString(tableName, row, "URUN_TUR_KOD"));
				dkGrupUrunSinifPrId.setUrunSinifKod(iMap.getString(tableName, row, "URUN_SINIF_KOD"));
				dkGrupUrunSinifPr.setId(dkGrupUrunSinifPrId);
				dkGrupUrunSinifPr.setDkAna(iMap.getString(tableName, row, "DK_HESABI_1"));
				dkGrupUrunSinifPr.setDkFaizGelir(iMap.getString(tableName, row, "DK_HESABI_2"));
				dkGrupUrunSinifPr.setDkFaizGider(iMap.getString(tableName, row, "DK_HESABI_3"));
				dkGrupUrunSinifPr.setDkReeskont(iMap.getString(tableName, row, "DK_HESABI_4"));
				dkGrupUrunSinifPr.setDkKomGelir(iMap.getString(tableName, row, "DK_HESABI_5"));
				dkGrupUrunSinifPr.setDkKomReeskont(iMap.getString(tableName, row, "DK_HESABI_6"));
				dkGrupUrunSinifPr.setDkEkhesap7(iMap.getString(tableName, row, "DK_HESABI_7"));
				dkGrupUrunSinifPr.setDkEkhesap8(iMap.getString(tableName, row, "DK_HESABI_8"));
				dkGrupUrunSinifPr.setDkEkhesap9(iMap.getString(tableName, row, "DK_HESABI_9"));
				dkGrupUrunSinifPr.setDkEkhesap10(iMap.getString(tableName, row, "DK_HESABI_10"));
				dkGrupUrunSinifPr.setDkEkhesap11(iMap.getString(tableName, row, "DK_HESABI_11"));
				dkGrupUrunSinifPr.setDkEkhesap12(iMap.getString(tableName, row, "DK_HESABI_12"));
				dkGrupUrunSinifPr.setDkEkhesap13(iMap.getString(tableName, row, "DK_HESABI_13"));
				dkGrupUrunSinifPr.setDkEkhesap14(iMap.getString(tableName, row, "DK_HESABI_14"));
				dkGrupUrunSinifPr.setDkEkhesap15(iMap.getString(tableName, row, "DK_HESABI_15"));
				dkGrupUrunSinifPr.setDkEkhesap16(iMap.getString(tableName, row, "DK_HESABI_16"));
				dkGrupUrunSinifPr.setDkEkhesap17(iMap.getString(tableName, row, "DK_HESABI_17"));
				dkGrupUrunSinifPr.setDkEkhesap18(iMap.getString(tableName, row, "DK_HESABI_18"));
				dkGrupUrunSinifPr.setDkEkhesap19(iMap.getString(tableName, row, "DK_HESABI_19"));
				dkGrupUrunSinifPr.setDkEkhesap20(iMap.getString(tableName, row, "DK_HESABI_20"));

				dkGrupUrunSinifPr.setIntBankGoruntuF(iMap.getString(tableName, row, "INT_BANK_GORUNTU_F"));
				dkGrupUrunSinifPr.setIntBankIslemYapilsinF(iMap.getString(tableName, row, "INT_BANK_ISLEM_YAPILSIN_F"));
				
                	dkGrupUrunSinifPr.setGS(iMap.getString(tableName , row , "GDS"));
              
				session.saveOrUpdate(dkGrupUrunSinifPr);
			}
			session.flush();

			iMap.put("TRX_NAME", "9927");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}catch (NonUniqueObjectException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(710));
			throw new GMRuntimeException(0,(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9927_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();  
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "9927_SPOT_ROTATIF");
			oMap.put("SPOT_ROTATIF", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
	
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
		
	}
	
	@GraymoundService("BNSPR_TRN9927_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					GnlDkGrupUrunSinifTx.class).add(
					Restrictions.eq("id.txNo", iMap
							.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "GRUP_URUN_SINIF";
	
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlDkGrupUrunSinifTx dkGrupUrunSinifPr = (GnlDkGrupUrunSinifTx)iterator.next();
				oMap.put("DK_GRUP_KODU", dkGrupUrunSinifPr.getId().getGrupKod());
				oMap.put(tableName, row, "MODUL_TUR_KOD", dkGrupUrunSinifPr.getId().getModulTurKod());
                oMap.put(tableName, row, "URUN_TUR_KOD", dkGrupUrunSinifPr.getId().getUrunTurKod());
                oMap.put(tableName, row, "URUN_SINIF_KOD", dkGrupUrunSinifPr.getId().getUrunSinifKod());
                oMap.put(tableName, row, "DK_HESABI_1", dkGrupUrunSinifPr.getDkAna());
                oMap.put(tableName, row, "DK_HESABI_2", dkGrupUrunSinifPr.getDkFaizGelir());
                oMap.put(tableName, row, "DK_HESABI_3", dkGrupUrunSinifPr.getDkFaizGider());
                oMap.put(tableName, row, "DK_HESABI_4", dkGrupUrunSinifPr.getDkReeskont());
                oMap.put(tableName, row, "DK_HESABI_5", dkGrupUrunSinifPr.getDkKomGelir());
                oMap.put(tableName, row, "DK_HESABI_6", dkGrupUrunSinifPr.getDkKomReeskont());
                oMap.put(tableName, row, "DK_HESABI_7", dkGrupUrunSinifPr.getDkEkhesap7());
                oMap.put(tableName, row, "DK_HESABI_8", dkGrupUrunSinifPr.getDkEkhesap8());
                oMap.put(tableName, row, "DK_HESABI_9", dkGrupUrunSinifPr.getDkEkhesap9());
                oMap.put(tableName, row, "DK_HESABI_10", dkGrupUrunSinifPr.getDkEkhesap10());
                oMap.put(tableName, row, "DK_HESABI_11", dkGrupUrunSinifPr.getDkEkhesap11());
                oMap.put(tableName, row, "DK_HESABI_12", dkGrupUrunSinifPr.getDkEkhesap12());
                oMap.put(tableName, row, "DK_HESABI_13", dkGrupUrunSinifPr.getDkEkhesap13());
                oMap.put(tableName, row, "DK_HESABI_14", dkGrupUrunSinifPr.getDkEkhesap14());
                oMap.put(tableName, row, "DK_HESABI_15", dkGrupUrunSinifPr.getDkEkhesap15());
                oMap.put(tableName, row, "DK_HESABI_16", dkGrupUrunSinifPr.getDkEkhesap16());
                oMap.put(tableName, row, "DK_HESABI_17", dkGrupUrunSinifPr.getDkEkhesap17());
                oMap.put(tableName, row, "DK_HESABI_18", dkGrupUrunSinifPr.getDkEkhesap18());
                oMap.put(tableName, row, "DK_HESABI_19", dkGrupUrunSinifPr.getDkEkhesap19());
                oMap.put(tableName, row, "DK_HESABI_20", dkGrupUrunSinifPr.getDkEkhesap20());
                
                oMap.put(tableName, row, "INT_BANK_GORUNTU_F", dkGrupUrunSinifPr.getIntBankGoruntuF());
                oMap.put(tableName, row, "INT_BANK_ISLEM_YAPILSIN_F", dkGrupUrunSinifPr.getIntBankIslemYapilsinF());
              
                if((dkGrupUrunSinifPr.getGS() != null) && (!StringUtils.isEmpty(dkGrupUrunSinifPr.getGS())))
                    oMap.put(tableName , row , "GDS",dkGrupUrunSinifPr.getGS());
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	

	
	@GraymoundService("BNSPR_TRN9927_VALIDATE_MANDATORY_FIELD")
	public static GMMap validateField(GMMap iMap) {
		try{
			validateReguest(iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	
	public static boolean isNotExistAndNull(GMMap iMap, String key) {

		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0) {
			return true;
		}
		else {
			return false;
		}

	}
	public static void validateReguest(GMMap iMap)
	{
		if (!isNotExistAndNull(iMap, "MODUL_TUR_KOD_A")) {
			throw new GMRuntimeException(10561, "MODUL_TUR_KOD Alan� dolu olmal�d�r!");

		}
		
		if (!isNotExistAndNull(iMap, "URUN_TUR_KOD_A")) {
			throw new GMRuntimeException(10561, "URUN_TUR_KOD  Alan� dolu olmal�d�r!");

		}
		
		if (!isNotExistAndNull(iMap, "URUN_SINIF_KOD_A")) {
			throw new GMRuntimeException(10561, "URUN_SINIF_KOD  Alan� dolu olmal�d�r!");

		}
		
		if (!isNotExistAndNull(iMap, "DK_HESABI_1A")) {
			throw new GMRuntimeException(10561, "Ana DK_HESABI  Alan� dolu olmal�d�r!");

		}
	}
	
}
