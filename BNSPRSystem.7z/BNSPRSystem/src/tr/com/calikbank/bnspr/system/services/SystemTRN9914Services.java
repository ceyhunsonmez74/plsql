package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlBankaKodPrTx;
import tr.com.aktifbank.bnspr.dao.GnlBankaKodPrTxId;
import tr.com.aktifbank.bnspr.dao.GnlBankaSubeKodPrTx;
import tr.com.aktifbank.bnspr.dao.GnlBankaSubeKodPrTxId;
import tr.com.calikbank.bnspr.dao.GnlBankaKodPr;
import tr.com.calikbank.bnspr.dao.GnlBankaSubeKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9914Services {
	@GraymoundService("BNSPR_TRN9914_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "BANKA_KODLARI";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlBankaKodPrTx gnlBankaKodPrTx = new GnlBankaKodPrTx();
				GnlBankaKodPrTxId bankaKodPrTxId = new GnlBankaKodPrTxId();
				bankaKodPrTxId.setKod(iMap.getString(tableName, row, "BK_BANKA_KODU"));
				bankaKodPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				gnlBankaKodPrTx.setId(bankaKodPrTxId);
				gnlBankaKodPrTx.setBankaAdi(iMap.getString(tableName, row, "BK_BANKA_ADI"));
				gnlBankaKodPrTx.setSwiftBicCode(iMap.getString(tableName,row,"BIC_CODE"));
				String tcmbKodu = iMap.getString(tableName, row, "BK_BANKA_TCMB_KODU");
				if(tcmbKodu.length() > 5)
					throw new GMRuntimeException(0, "TCMB Kodlar� 4 karakter olmal�d�r");
				gnlBankaKodPrTx.setBankaTcmbKod(iMap.getString(tableName, row, "BK_BANKA_TCMB_KODU"));
				gnlBankaKodPrTx.setKapanmaTarihi(iMap.getDate(tableName, row, "BK_KAPANMA_TARIHI"));
				
				if(iMap.getBoolean(tableName, row, "F_NEW"))
					gnlBankaKodPrTx.setGDS("G");
				else{
					if(iMap.getBoolean(tableName, row, "SIL")){
						gnlBankaKodPrTx.setGDS("S");
					}
					else
						gnlBankaKodPrTx.setGDS("");
				}

				ArrayList<?> bankaSubeKodlariInList = (ArrayList<?>) GMContext.getCurrentContext().getSession().get(iMap.getString(tableName, row, "BK_BANKA_KODU"));
				Object o = GMContext.getCurrentContext().getSession().get(iMap.getString(tableName, row, "BK_BANKA_KODU"));
				if(o != null ){
					boolean flag = true;
					for (Iterator<?> iterator2 = bankaSubeKodlariInList.iterator(); iterator2.hasNext();) {
						HashMap<?, ?> rowData2 = (HashMap<?, ?>) iterator2.next();
						
						GnlBankaSubeKodPrTx gnlBankaSubeKodPrTx = new GnlBankaSubeKodPrTx();
						GnlBankaSubeKodPrTxId bankaSubeKodPrTxId = new GnlBankaSubeKodPrTxId();
						
						bankaSubeKodPrTxId.setBankaKod((String)rowData2.get("BANKA_KODU"));
						bankaSubeKodPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						String subeKod = (String)rowData2.get("SUBE_KODU");
						bankaSubeKodPrTxId.setSubeKod(subeKod);
						
						if(subeKod.length() > 5)
							throw new GMRuntimeException(0, "�ube Kodlar� 4 karakter olmal�d�r");
						gnlBankaSubeKodPrTx.setId(bankaSubeKodPrTxId);
						
						gnlBankaSubeKodPrTx.setIlKod((String)rowData2.get("IL_KODU"));
						gnlBankaSubeKodPrTx.setKapanmaTarihi((Date)rowData2.get("KAPANMA_TARIHI"));
						gnlBankaSubeKodPrTx.setSubeAdi((String)rowData2.get("SUBE_ADI"));
						if(rowData2.get("F_NEW").toString().equals("true"))
							gnlBankaSubeKodPrTx.setGDS("G");
						else{
							if(rowData2.get("SIL").toString().equals("true") || rowData2.get("SIL").toString().equals("1")){
								gnlBankaSubeKodPrTx.setGDS("S");
							}
							else
								gnlBankaSubeKodPrTx.setGDS("");
						}
						
						session.save(gnlBankaSubeKodPrTx);
						session.flush();
						if(flag){
							GMContext.getCurrentContext().getSession().remove((String)rowData2.get("BANKA_KODU"));
							flag=false;
						}
					}
				}
				session.save(gnlBankaKodPrTx);
			}

			session.flush();
			iMap.put("TRX_NAME", "9914");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9914_GET_BANKALAR")
	public static Map<?, ?> getBankalar(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			ArrayList<?> bankalar = (ArrayList<?>) session.createCriteria(GnlBankaKodPr.class).list();

			String tableName = "BANKALAR";
			int row = 0;
			for (Iterator<?> iterator = bankalar.iterator(); iterator.hasNext();row++) {
				GnlBankaKodPr gnlBankaKodPr = (GnlBankaKodPr)iterator.next();
				oMap.put(tableName, row, "BK_BANKA_KODU", gnlBankaKodPr.getKod());
				oMap.put(tableName, row, "BK_BANKA_ADI", gnlBankaKodPr.getBankaAdi());
				oMap.put(tableName, row, "BK_BANKA_TCMB_KODU", gnlBankaKodPr.getBankaTcmbKod());
				oMap.put(tableName, row, "BK_KAPANMA_TARIHI", gnlBankaKodPr.getKapanmaTarihi());
				oMap.put(tableName, row, "BIC_CODE", gnlBankaKodPr.getSwiftBicCode());
				oMap.put(tableName, row, "F_NEW", false);
				oMap.put(tableName, row, "SIL", false);
			}
			
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9914_GET_SUBELER")
	public static Map<?, ?> getSubeler(GMMap iMap) {
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		Object o = GMContext.getCurrentContext().getSession().get(iMap.getString("BANKA_KOD"));
		if(o == null){
			try {
				ArrayList<HashMap<String, Object>> subelerOutList = new ArrayList<HashMap<String, Object>>();
				Session session = DAOSession.getSession("BNSPRDal");
				ArrayList<?> subeler = (ArrayList<?>) session.createCriteria(GnlBankaSubeKodPr.class).add(Restrictions.eq("id.bankaKod", iMap.getString("BANKA_KOD"))).list();
				for (Iterator<?> iterator = subeler.iterator(); iterator.hasNext();) {
					GnlBankaSubeKodPr gnlBankaSubeKodPr = (GnlBankaSubeKodPr)iterator.next();
					HashMap<String, Object> rowData = new HashMap<String, Object>();
					rowData.put("BANKA_KODU", gnlBankaSubeKodPr.getId().getBankaKod());
					rowData.put("IL_KODU", gnlBankaSubeKodPr.getIlKod());
					rowData.put("KAPANMA_TARIHI", gnlBankaSubeKodPr.getKapanmaTarihi());
					rowData.put("SUBE_ADI", gnlBankaSubeKodPr.getSubeAdi());
					rowData.put("SUBE_KODU", gnlBankaSubeKodPr.getId().getSubeKod());
					rowData.put("F_NEW", false);
					rowData.put("SIL", false);
					subelerOutList.add(rowData);
				}
				oMap.put("SUBELER", subelerOutList);
			} catch (Exception e) {
				throw new GMRuntimeException(0, e);
			}
		}
		else{
			oMap.put("SUBELER", GMContext.getCurrentContext().getSession().get(iMap.getString("BANKA_KOD")));
		}
		return oMap; 
	}
	
	@GraymoundService("BNSPR_TRN9914_PUT_SUBELER_TO_CONTEX")
	public static Map<?, ?> putSubelerToContext(GMMap iMap) {
		GMContext.getCurrentContext().getSession().put(iMap.getString("BANKA_KOD"), iMap.get("SUBELER"));
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_SQL_SERVER_TRANSFER_GERCEK")
	public static HashMap<String, Object> transferGercek(GMMap iMap){
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		Connection connSql = null;
		Connection connOracle = null;
		CallableStatement stmtSql = null;
		CallableStatement stmtOracle = null;
		ResultSet rset = null;
		try{
			Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
			connOracle = DALUtil.getGMConnection();		
			connSql = DriverManager.getConnection("jdbc:microsoft:sqlserver://192.168.0.147:1433;databaseName=dbtcmb","obss","obss!123"); 
			StringBuffer sb = new StringBuffer();
			sb.append("select top 1000000 id, bildirimyili, donemno, ad1, ad2, soyadi, babaadi, dogumyeri, dogumili, dogumyili, ncserino, ncsirano, ticsicil, ticsicmemkod, ticsicmemilce," );
			sb.append("adres, adresilkodu, durumkodu, cekhesapno, kesidetar, ibraztar, cekserino, ceksirano, tutar, odemetur, duzeltmetar, bankaadi, subeadi, ortakhes, vergikimlikno, kayittarihi,");
			sb.append("indirimtarihi, anneadi, dogumtarihi, tckimlikno FROM karsiliksizcekgercek");
			stmtSql = connSql.prepareCall(sb.toString());
			rset = stmtSql.executeQuery();
			
			StringBuffer sb2 = new StringBuffer();
			sb2.append("INSERT INTO karsiliksizcekgercek (id, bildirimyili, donemno, ad1, ad2, soyadi, babaadi, dogumyeri, dogumili, dogumyili, ncserino, ncsirano, ticsicil, ticsicmemkod, ticsicmemilce,");
			sb2.append("adres, adresilkodu,durumkodu, cekhesapno, kesidetar, ibraztar, cekserino, ceksirano, tutar, odemetur, duzeltmetar, bankaadi, subeadi, ortakhes, vergikimlikno, kayittarihi,");
			sb2.append("indirimtarihi, anneadi, dogumtarihi, tckimlikno) VALUES");
			sb2.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			stmtOracle = connOracle.prepareCall(sb2.toString());
			int j = 1;
			while(rset.next()){
				int i = 1;
				stmtOracle.setInt(i, rset.getInt(i++));//id 
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++));//bildirimyili
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++));//donemno
				stmtOracle.setString(i, rset.getString(i++));//ad1
				stmtOracle.setString(i, rset.getString(i++));//ad2
				stmtOracle.setString(i, rset.getString(i++));//soyadi
				stmtOracle.setString(i, rset.getString(i++)); //babaadi
				stmtOracle.setString(i, rset.getString(i++)); //dogumyeri
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //dogumili
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //dogumyili
				stmtOracle.setString(i, rset.getString(i++)); //ncserino
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //ncsirano
				stmtOracle.setString(i, rset.getString(i++)); //ticsicil
				stmtOracle.setString(i, rset.getString(i++)); //ticsicmemkod
				stmtOracle.setString(i, rset.getString(i++)); //ticsicmemilce
				stmtOracle.setString(i, rset.getString(i++)); //adres
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //adresilkodu
				stmtOracle.setString(i, rset.getString(i++)); //durumkodu
				stmtOracle.setString(i, rset.getString(i++)); //cekhesapno
				stmtOracle.setDate(i, rset.getDate(i++)); //kesidetar
				stmtOracle.setDate(i, rset.getDate(i++)); //ibraztar
				stmtOracle.setString(i, rset.getString(i++)); //cekserino
				stmtOracle.setString(i, rset.getString(i++)); //ceksirano
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //tutar
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //odemetur
				stmtOracle.setDate(i, rset.getDate(i++)); //duzeltmetar
				stmtOracle.setString(i, rset.getString(i++)); //bankaadi
				stmtOracle.setString(i, rset.getString(i++)); //subeadi
				stmtOracle.setString(i, rset.getString(i++)); //ortakhes
				stmtOracle.setBigDecimal(i, rset.getBigDecimal(i++)); //vergikimlikno
				stmtOracle.setDate(i, rset.getDate(i++)); //kayittarihi
				stmtOracle.setDate(i, rset.getDate(i++)); //indirimtarihi
				stmtOracle.setString(i, rset.getString(i++)); //anneadi
				stmtOracle.setDate(i, rset.getDate(i++)); //dogumtarihi
				stmtOracle.setString(i, rset.getString(i++)); //tckimlikno
				
				stmtOracle.execute();
				System.out.println(j++);
			}
			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}finally{
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(stmtOracle);
			GMServerDatasource.close(connSql);
			GMServerDatasource.close(connOracle);
			GMServerDatasource.close(rset);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9914_DELETED_SUBE_ROW_COUNT")
	public static GMMap deletedSubeRowCount(GMMap iMap) {
		String tableName  = "SUBELER";
		int count = 0;
		int tableRowCount = iMap.getSize("SUBELER"); 
		for(int i=0; i<tableRowCount; i++){
			if(iMap.getString(tableName, i, "SIL").equals("true"))
				count++;
			else break;
		}
		return new GMMap().put("IS_DELETE", count==tableRowCount?true:false);
	}
	@GraymoundService("BNSPR_TRN9914_GET_BANKALAR_BY_TX_NO")
	public static GMMap getBankalarByTxNo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			ArrayList<?> bankalar = (ArrayList<?>) session.createCriteria(GnlBankaKodPrTx.class).
				add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
				list();

			String tableName = "BANKALAR";
			int row = 0;
			for (Iterator<?> iterator = bankalar.iterator(); iterator.hasNext();row++) {
				GnlBankaKodPrTx gnlBankaKodPrTx = (GnlBankaKodPrTx)iterator.next();
				oMap.put(tableName, row, "BK_BANKA_KODU", gnlBankaKodPrTx.getId().getKod());
				oMap.put(tableName, row, "BK_BANKA_ADI", gnlBankaKodPrTx.getBankaAdi());
				oMap.put(tableName, row, "BK_BANKA_TCMB_KODU", gnlBankaKodPrTx.getBankaTcmbKod());
				oMap.put(tableName, row, "BK_KAPANMA_TARIHI", gnlBankaKodPrTx.getKapanmaTarihi());
				oMap.put(tableName, row, "BIC_CODE", gnlBankaKodPrTx.getSwiftBicCode());
				oMap.put(tableName, row, "SIL", "S".equals(gnlBankaKodPrTx.getGDS())?"true":false);
			}
			
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	@GraymoundService("BNSPR_TRN9914_GET_SUBELER_BY_TX_NO")
	public static GMMap getSubelerByTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			ArrayList<?> subeler = (ArrayList<?>) session.createCriteria(GnlBankaSubeKodPrTx.class).add(Restrictions.and(Restrictions.eq("id.bankaKod", iMap.getString("BANKA_KOD")),Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))).list();
			String tableName = "SUBELER";
			int row=0;
			for (Iterator<?> iterator = subeler.iterator(); iterator.hasNext();row++) {
				GnlBankaSubeKodPrTx gnlBankaSubeKodPrTx = (GnlBankaSubeKodPrTx)iterator.next();
				
				oMap.put(tableName, row, "BANKA_KODU", gnlBankaSubeKodPrTx.getId().getBankaKod());
				oMap.put(tableName, row, "IL_KODU", gnlBankaSubeKodPrTx.getIlKod());
				oMap.put(tableName, row, "KAPANMA_TARIHI", gnlBankaSubeKodPrTx.getKapanmaTarihi());
				oMap.put(tableName, row, "SUBE_ADI", gnlBankaSubeKodPrTx.getSubeAdi());
				oMap.put(tableName, row, "SUBE_KODU", gnlBankaSubeKodPrTx.getId().getSubeKod());
				oMap.put(tableName, row, "SIL", "S".equals(gnlBankaSubeKodPrTx.getGDS())?"true":false);
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap; 
	}
}
