package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

/**
 * @author obss1
 * 
 */
public class SystemBaseTableHistory {

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_BASE_TABLE_HISTORY_GET_RECORDS")
	public static GMMap getHistoryRecords(GMMap iMap) {
		Connection 			conn 		= null;
		PreparedStatement 	stmt 		= null;
		ResultSet 			rSet 		= null;
		GMMap 				oMap 		= new GMMap();
		List<BigDecimal>	txNoList 	= null;
		try {
			conn = DALUtil.getGMConnection();

			StringBuilder query = new StringBuilder();
			query.append("select ");
			query.append("  k.amir_sube_kod,pkg_genel_pr.sube_adi(k.AMIR_SUBE_KOD) AMIR_SUBE_ADI,k.NUMARA,k.ISLEM_KOD,k.DURUM_ADI,k.DURUM,to_char(k.KAYIT_TARIH,'dd/mm/yyyy') KAYIT_TARIH,k.MUSTERI_NUMARA,k.HESAP_NUMARA,k.TUTAR,k.DOVIZ_KOD,");
			query.append("  k.FIS_NUMARA,k.MODUL_TUR_KOD,k.URUN_TUR_KOD,k.URUN_SINIF_KOD,");
			query.append("  k.DOGRULANABILIR_MI,k.ONAYLANABILIR_MI,k.IPTAL_ONAYLANABILIR_MI,k.IPTAL_EDILEBILIR_MI,k.GERI_CEVRILEBILIR,");
			query.append("  k.ACIKLAMA,k.KAYIT_KULLANICI_KODU,to_char(k.KAYIT_SISTEM_TARIHI,'dd/mm/yyyy hh24:mi:ss') KAYIT_TARIH,");
			query.append("  k.DOGRU_KULL_KODU,to_char(k.DOGRULAMA_SISTEM_TARIH,'dd/mm/yyyy hh24:mi:ss') DOGRU_TARIH, ");
			query.append("  k.ONAY_KULL_KODU ,to_char(k.ONAYLAMA_SISTEM_TARIH,'dd/mm/yyyy hh24:mi:ss') ONAY_TARIH, ");
			query.append("  k.IPTAL_KULLANICI_KODU,to_char(k.IPTAL_SISTEM_TARIHI,'dd/mm/yyyy hh24:mi:ss') IPTAL_TARIH,");
			query.append("  k.IPTAL_ONAY_KULL_KODU,k.iptal_onay_tarih,Pkg_genel_pr.islem_ekran_adi(k.ISLEM_KOD), ");
			query.append("k.kanal_numara, k.kanal_adi, k.kanal_alt_kod, k.kanal_alt_adi,k.kullanici_aciklama, ");
			query.append("k.fis_izlenebilir_mi ");
			query.append("from v_muh_islem_history k ");
			query.append("where 1=1 ");
			
			if (iMap.get("TX_NO_LIST") != null) {
				query.append("and k.NUMARA in ( ");
				
				txNoList = (List<BigDecimal>)iMap.get("TX_NO_LIST");
				for (Iterator iterator = txNoList.iterator(); iterator.hasNext();) {
					BigDecimal txNo = (BigDecimal) iterator.next();
					query.append(txNo + ", " );
				}

				query.append("0) ");
			}
			
			query.append("order by k.NUMARA desc ");
			
			

			stmt = conn.prepareStatement(query.toString());
			rSet = stmt.executeQuery();

			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;

				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KULLANICI_ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));
			}

			oMap.put("ROW_COUNT", oMap.getSize(tableName));

			
		} catch (Exception e) {
			 throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
        }
		return oMap;
	}
}

