package tr.com.calikbank.bnspr.system.services;

import java.io.IOException;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlJsJobTurTanim;
import tr.com.calikbank.bnspr.quartz.BnsprJobFactory;
import tr.com.calikbank.bnspr.quartz.QuartzEnums.JobHolidayOptions;
import tr.com.calikbank.bnspr.quartz.QuartzEnums.Schedulers;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9949Services {
	
	private static Log logger = LogFactory.getLog(SystemPAR9949Services.class);
	
	private static final String confFile = "jobScheduler.properties";
	
	private static String getProperty(String property) {
		Configurator configurator = Configurator.createConfiguratorFromProperties(confFile);
		return configurator.getProperty(property);
	}
	
	private static GMConnection getSchedulerConnection(GMMap iMap){
		GMConnection gmConnection=null;
		try {
			int schedId=iMap.getInt("SCHED_ID");
			for (Schedulers scheduler : Schedulers.values()) {
				if(schedId==scheduler.getId()){
					gmConnection=GMConnection.getConnection(scheduler.getConnectionName());
				}
			}
		} catch (IOException e) {
			throw new GMRuntimeException(0, e);
		}
		return gmConnection;
	}
	
	@GraymoundService("BNSPR_PAR9949_CREATE_JOB")
	public static Map<?,?> createJob(GMMap iMap){			
		try {
			GMConnection schConnection = getSchedulerConnection(iMap);
			return schConnection.serviceCall("BNSPR_PAR9949_CREATE_REMOTE_JOB", iMap);
		} catch (IOException e) {
			logger.error(e);
		}
		return new GMMap();
		
	}
	@GraymoundService("BNSPR_PAR9949_CREATE_REMOTE_JOB")
	public static Map<?,?> createRemoteJob(GMMap iMap){
		try {
			new BnsprJobFactory().scheduleJob(iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}	
	@GraymoundService("BNSPR_PAR9949_DELETE_JOB")
	public static Map<?,?> deleteJob(GMMap iMap){
		try {
			GMConnection schConnection = getSchedulerConnection(iMap);
			return schConnection.serviceCall("BNSPR_PAR9949_DELETE_REMOTE_JOB", iMap);
		} catch (IOException e) {
			logger.error(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_DELETE_REMOTE_JOB")
	public static Map<?,?> deleteRemoteJob(GMMap iMap){
		try {
			new BnsprJobFactory().deleteJob(iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}	
	@GraymoundService("BNSPR_PAR9949_UPDATE_JOB")
	public static Map<?,?> updateJob(GMMap iMap){
		int schedId=iMap.getInt("SCHED_ID");
		iMap.put("SCHED_ID", iMap.getInt("OLD_SCHED_ID"));
		GMServiceExecuter.execute("BNSPR_PAR9949_DELETE_JOB", iMap);
		
		iMap.put("SCHED_ID", schedId);
		GMServiceExecuter.execute("BNSPR_PAR9949_CREATE_JOB", iMap);
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_PAR9949_PAUSE_JOB")
	public static Map<?,?> pauseJob(GMMap iMap){
		try {
			GMConnection schConnection = getSchedulerConnection(iMap);
			return schConnection.serviceCall("BNSPR_PAR9949_PAUSE_REMOTE_JOB", iMap);
		} catch (IOException e) {
			logger.error(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_PAUSE_REMOTE_JOB")
	public static Map<?,?> pauseRemoteJob(GMMap iMap){
		try {
			
			new BnsprJobFactory().pauseJob(iMap);
			if(Boolean.valueOf(iMap.getBoolean("PAUSE")) && 
					Boolean.valueOf(getProperty("scheduler.status.send.email"))){
				getSchedulerConnection(iMap).serviceCall("BNSPR_SEND_PAUSED_NOTIFICATION_EMAIL", iMap);
			}
				
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_TRIGGER_JOB")
	public static Map<?,?> triggerJob(GMMap iMap){
		try {
			GMConnection schConnection = getSchedulerConnection(iMap);
			return schConnection.serviceCall("BNSPR_PAR9949_TRIGGER_REMOTE_JOB", iMap);
		} catch (IOException e) {
			logger.error(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_TRIGGER_REMOTE_JOB")
	public static Map<?,?> triggerRemoteJob(GMMap iMap){
		try {
			new BnsprJobFactory().triggerJob(iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}	
	@GraymoundService("BNSPR_PAR9949_TRIGGER_JOB_WITH_DATA")
	public static Map<?,?> triggerJobWithData(GMMap iMap){
		try {
			GMConnection schConnection = getSchedulerConnection(iMap);
			return schConnection.serviceCall("BNSPR_PAR9949_TRIGGER_REMOTE_JOB_WITH_DATA", iMap);
		} catch (IOException e) {
			logger.error(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_TRIGGER_REMOTE_JOB_WITH_DATA")
	public static Map<?,?> triggerRemoteJobWithData(GMMap iMap){
		try {
			new BnsprJobFactory().triggerJobWithData(iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
		
	@GraymoundService("BNSPR_PAR9949_RESUME_JOB")
	public static Map<?,?> resumeJob(GMMap iMap){
		try {
			GMConnection schConnection = getSchedulerConnection(iMap);
			return schConnection.serviceCall("BNSPR_PAR9949_RESUME_REMOTE_JOB", iMap);
		} catch (IOException e) {
			logger.error(e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_RESUME_REMOTE_JOB")
	public static Map<?,?> resumeRemoteJob(GMMap iMap){
		try {
			new BnsprJobFactory().resumeJob(iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_PAR9949_GET_ALL_JOB")
	public static Map<?,?> getAllJob(GMMap iMap){
		GMMap oMap=new GMMap();
		try {
			GMConnection schConnection=null;
			for (Schedulers scheduler : Schedulers.values()) {
				schConnection=GMConnection.getConnection(scheduler.getConnectionName());
				oMap.putAll(schConnection.serviceCall("BNSPR_PAR9949_GET_ALL_REMOTE_JOB", oMap));
			}
		} catch (IOException e) {
			logger.error(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9949_GET_ALL_REMOTE_JOB")
	public static Map<?,?> getAllRemoteJob(GMMap iMap){
		return new BnsprJobFactory().getAllJob("JOB_LIST",iMap);
	}
	@GraymoundService("BNSPR_PAR9949_GET_CRON_SUB_EXPRESSION")
	public static GMMap getConSubExpression(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		StringBuilder sb = new StringBuilder(); 
		try {
			if (iMap.getString("CRON_PART").equals("SECOND")){
				if (iMap.getBoolean("TUMU"))
					sb.append("*");
				else {
					for (int i = 0; i < 60; i++) {
						if(iMap.getBoolean("CHB" + i)){
							sb.append(i + ",");
						}
					}
					if (sb.length()>1)
						sb.delete(sb.length()-1, sb.length());
				}
			}
			else if(iMap.getString("CRON_PART").equals("MINUTE")){
				if(iMap.getBoolean("TUMU"))
					sb.append("*");
				else{
					for (int i = 0; i < 60; i++) {
						if(iMap.getBoolean("MIN" + i)){
							sb.append(i + ",");
						}
					}
					if(sb.length()>1)
						sb.delete(sb.length()-1, sb.length());
				}
			}
			else if(iMap.getString("CRON_PART").equals("HOUR")){
				if(iMap.getBoolean("TUMU"))
					sb.append("*");
				else{
					for (int i = 0; i < 24; i++) {
						if(iMap.getBoolean("HOUR" + i)){
							sb.append(i + ",");
						}
					}
					if(sb.length()>1)
						sb.delete(sb.length()-1, sb.length());
				}
			}
			else if(iMap.getString("CRON_PART").equals("DAY_OF_MONTH")){
				if(iMap.getBoolean("DAY_OF_MONTH")){
					if(iMap.getBoolean("TUMU"))
						sb.append("*");
					else{
						for (int i = 1; i <= 31; i++) {
							if(iMap.getBoolean("DAY" + i)){
								sb.append(i + ",");
							}
						}
						if(sb.length()>1)
							sb.delete(sb.length()-1, sb.length());
					}
				}
				else if(iMap.getBoolean("LAST_DAY_OF_MONTH")){
					int lastDay = iMap.getInt("LAST_DAY");
					if(lastDay == 0)
						sb.append("L");
					else
						sb.append(lastDay + "L");
				}
				else if(iMap.getBoolean("WORKING_DAY")){
					int closestDay = iMap.getInt("CLOSEST_DAY");
					sb.append(closestDay + "W");
				}
				else if(iMap.getBoolean("LAST_WORK_DAY_OF_MONTH")){
					sb.append("LW");
				}
			}
			else if(iMap.getString("CRON_PART").equals("MONTH")){
				if(iMap.getBoolean("TUMU"))
					sb.append("*");
				else{
					for (int i = 1; i <= 12; i++) {
						if(iMap.getBoolean("MONTH" + i)){
							sb.append(i + ",");
						}
					}
					if(sb.length()>1)
						sb.delete(sb.length()-1, sb.length());
				}
			}
			else if(iMap.getString("CRON_PART").equals("DAY_OF_WEEK")){
				if(iMap.getBoolean("DAY_OF_WEEK")){
					if(iMap.getBoolean("TUMU"))
						sb.append("*");
					else{
						for (int i = 1; i <= 7; i++) {
							if(iMap.getBoolean("DAY" + i)){
								sb.append(i + ",");
							}
						}
						if(sb.length()>1)
							sb.delete(sb.length()-1, sb.length());
					}
				}
				else if(iMap.getBoolean("X_DAY_OF_MONTH")){
					int weekNumber = iMap.getInt("WEEK_NUMBER");
					int weekDay = iMap.getInt("WEEK_DAY");
					sb.append(weekDay + "#" + weekNumber);
				}
			}
			oMap.put("SUB_EXPRESSION", sb.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9949_DECODE_CRON_EXPRESSION")
	public static GMMap decodeCronExpression(GMMap iMap) {
		GMMap oMap = new GMMap();
		String expression = iMap.getString("EXPRESSSION");
		try {
			if (iMap.getString("CRON_PART").equals("SECOND")){
				for (int i = 0; i < 60; i++) {
					oMap.put("CHB" + i, false);
				}
				oMap.put("TUMU", false);
				if (expression.equals("*")){
					oMap.put("TUMU", true);
					for (int i = 0; i < 60; i++) {
						oMap.put("CHB" + i, true);
					}
				}
				else {
					StringTokenizer tokinezer = new StringTokenizer(expression, ",");
					while (tokinezer.hasMoreTokens()) {
						oMap.put("CHB" + tokinezer.nextToken(), true);
					}
				}
			}
			else if(iMap.getString("CRON_PART").equals("MINUTE")){
				for (int i = 0; i < 60; i++) {
					oMap.put("MIN" + i, false);
				}
				oMap.put("TUMU", false);
				if ("*".equals(expression)){
					oMap.put("TUMU", true);
					for (int i = 0; i < 60; i++) {
						oMap.put("MIN" + i, true);
					}
				}
				else {
					StringTokenizer tokinezer = new StringTokenizer(expression, ",");
					while (tokinezer.hasMoreTokens()) {
						oMap.put("MIN" + tokinezer.nextToken(), true);
					}
				}
			}
			else if(iMap.getString("CRON_PART").equals("HOUR")){
				for (int i = 0; i < 24; i++) {
					oMap.put("HOUR" + i, false);
				}
				oMap.put("TUMU", false);
				if ("*".equals(expression)){
					oMap.put("TUMU", true);
					for (int i = 0; i < 24; i++) {
						oMap.put("HOUR" + i, true);
					}
				}
				else {
					StringTokenizer tokinezer = new StringTokenizer(expression, ",");
					while (tokinezer.hasMoreTokens()) {
						oMap.put("HOUR" + tokinezer.nextToken(), true);
					}
				}
			}
			else if(iMap.getString("CRON_PART").equals("DAY_OF_MONTH")){
				oMap.put("TUMU", false);
				oMap.put("DAY_OF_MONTH", false);
				oMap.put("WORKING_DAY", false);
				oMap.put("LAST_DAY_OF_MONTH", false);
				oMap.put("LAST_WORK_DAY_OF_MONTH", false);
				oMap.put("LAST_DAY", "0");
				oMap.put("CLOSEST_DAY", "1");
				
				for (int i = 1; i <= 31; i++) {
					oMap.put("DAY" + i, false);
				}
				if(expression.indexOf("LW") == 0){ // LAST WORK DAY OF MONTH
					oMap.put("LAST_WORK_DAY_OF_MONTH", true);
				}
				else if(expression.indexOf('L') == 0){ 	// LAST_DAY_OF_MONTH
					oMap.put("LAST_DAY", "0");
					oMap.put("LAST_DAY_OF_MONTH", true);
				}
				else if(expression.indexOf('L') > 0){ 
					oMap.put("LAST_DAY", expression.substring(0, expression.indexOf('L')));
					oMap.put("LAST_DAY_OF_MONTH", true);
				}
				else if(expression.indexOf('W') > 0){ // . g�n�ne en yak�n i� g�n�
					oMap.put("CLOSEST_DAY", expression.substring(0, expression.indexOf('W')));
					oMap.put("WORKING_DAY", true);
				}
				else if ("*".equals(expression)){
					oMap.put("TUMU", true);
					for (int i = 1; i <= 31; i++) {
						oMap.put("DAY" + i, true);
					}
				}
				else if (expression.equals("?")){ //any value
					oMap.put("DAY0", true);
				}
				else {
					StringTokenizer tokinezer = new StringTokenizer(expression, ",");
					while (tokinezer.hasMoreTokens()) {
						oMap.put("DAY" + tokinezer.nextToken(), true);
					}
				}
			}
			else if(iMap.getString("CRON_PART").equals("MONTH")){
				for (int i = 1; i <= 12; i++) {
					oMap.put("MONTH" + i, false);
				}
				oMap.put("TUMU", false);
				if ("*".equals(expression)){
					oMap.put("TUMU", true);
					for (int i = 0; i < 24; i++) {
						oMap.put("MONTH" + i, true);
					}
				}
				else {
					StringTokenizer tokinezer = new StringTokenizer(expression, ",");
					while (tokinezer.hasMoreTokens()) {
						oMap.put("MONTH" + tokinezer.nextToken(), true);
					}
				}
				
			}
			else if(iMap.getString("CRON_PART").equals("DAY_OF_WEEK")){
				oMap.put("TUMU", false);
				oMap.put("DAY_OF_WEEK", false);
				oMap.put("XXX_DAY_OF_MONTH", false);
				oMap.put("WEEK_DAY", "2");
				oMap.put("WEEK_NUMBER", "1");
				for (int i = 1; i <= 7; i++) {
					oMap.put("DAY" + i, false);
				}
				if(expression.indexOf('#') > 0){ 	// n. day of x. month n#x
					oMap.put("XXX_DAY_OF_MONTH", true);
					oMap.put("WEEK_DAY", expression.substring(0, expression.indexOf('#')));
					oMap.put("WEEK_NUMBER", expression.substring(expression.indexOf('#') + 1, expression.length()));
				}
				else if (expression.equals("*")){
					oMap.put("TUMU", true);
					oMap.put("DAY_OF_WEEK", true);
					for (int i = 1; i <= 7; i++) {
						oMap.put("DAY" + i, true);
					}
				}
				else {
					oMap.put("DAY_OF_WEEK", true);
					StringTokenizer tokinezer = new StringTokenizer(expression, ",");
					while (tokinezer.hasMoreTokens()) {
						oMap.put("DAY" + tokinezer.nextToken(), true);
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9949_PARSE_CRON_EXPRESSION")
	public static GMMap parseCronExpression(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			StringTokenizer tokinezer = new StringTokenizer(iMap.getString("EXPRESSION"), " ");
			String [] cronPartNames = {"SECOND", "MINUTE", "HOUR", "DAY_OF_MONTH", "MONTH", "DAY_OF_WEEK"};
			int i = 0;
			while (tokinezer.hasMoreTokens()) {
				oMap.put(cronPartNames[i++], tokinezer.nextToken());
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static final String JOB_TUR_QUERY = "select a.job_tur_kod, a.job_tur_ad from gnl_js_job_tur_tanim a";

	@GraymoundService("BNSPR_PAR9949_GET_JOB_TUR")
	public static GMMap getJobTur(GMMap iMap) {
		return DALUtil.fillComboBox(new GMMap(), "JOB_TUR", false, JOB_TUR_QUERY);
	}
	
	@GraymoundService("BNSPR_PAR9949_GET_JOB_PRIORITY")
	public static GMMap getJobPriority(GMMap iMap) {
		GMMap oMap=new GMMap();
		GuimlUtil.wrapMyCombo(oMap, "JOB_PRIORITY", "1", "High");
		GuimlUtil.wrapMyCombo(oMap, "JOB_PRIORITY", "2", "Normal");
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9949_GET_JOB_MISFIRE_POLICIES")
	public static GMMap getJobMisfirePolicies(GMMap iMap) {
		GMMap oMap=new GMMap();
		GuimlUtil.wrapMyCombo(oMap, "MISFIRE_POLICY", "1", "Birkez");
		GuimlUtil.wrapMyCombo(oMap, "MISFIRE_POLICY", "2", "Yok");
		GuimlUtil.wrapMyCombo(oMap, "MISFIRE_POLICY", "-1", "Hepsi");
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9949_GET_JOB_HOLIDAY_OPTIONS")
	public static GMMap getJobHolidayOptions(GMMap iMap) {
		GMMap oMap=new GMMap();
		GuimlUtil.wrapMyCombo(oMap, "TATIL_GUNU", "E", JobHolidayOptions.E.getOptionName());
		GuimlUtil.wrapMyCombo(oMap, "TATIL_GUNU", "H", JobHolidayOptions.H.getOptionName());
		GuimlUtil.wrapMyCombo(oMap, "TATIL_GUNU", "S", JobHolidayOptions.S.getOptionName());
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR9949_GET_JOB_NAMES")
	public static GMMap getJobNames(GMMap iMap) {
		return DALUtil.fillComboBox(new GMMap(), "JOB_LIST", true, "SELECT JOB_ADI, JOB_ADI FROM GNL_JS_TANIM_PR ORDER BY 2");
	}
	
	@GraymoundService("BNSPR_PAR9949_GET_GUIML_NAME")
	public static GMMap getGUIMLName(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlJsJobTurTanim jobTurTanim = (GnlJsJobTurTanim)session.get(GnlJsJobTurTanim.class, iMap.getBigDecimal("JOB_TUR_KOD"));
			oMap.put("GUIML_NAME", jobTurTanim.getParameterGuimlName());
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	
	

}


