package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.core.transaction.services.BnsprPojoLoader;
import tr.com.calikbank.bnspr.core.transaction.services.MappingStrategy;
import tr.com.calikbank.bnspr.dao.GnlSubeEftBagimliTx;
import tr.com.calikbank.bnspr.dao.GnlSubeKodPrTx;
import tr.com.calikbank.bnspr.dao.GnlSubeTakasBagimliTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TemplateServices {
	@GraymoundService("TEMPLATE_SAVE_SERVICE")
	public static HashMap<String, Object> getDummySaveMessages(GMMap iMap){
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r");
		
		return oMap;
	}
	
	@GraymoundService("DATE_TEST_SAVE_DATE")
	public static HashMap<String, Object> saveADate(GMMap iMap){
		try {
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			//Date date1 = iMap.getDate("TARIH");
			//Date date2 = iMap.getDate("TARIH");
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("EXT_JDBC_TEST")
	public static HashMap<String, Object> extJDBCTest(GMMap iMap){
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {
			//
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_types.Deneme(102)}");
			stmt.registerOutParameter(1, -10);
			// execute and retrieve the result set
			
			stmt.execute();
			
			stmt.getMoreResults();
			rs = (ResultSet)stmt.getObject(1);

			// print the results
			while (rs.next()) {
			    System.out.println(rs.getObject(1));
			}

		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rs);
		}
		return oMap;
	}
	
	@GraymoundService("TEST_BNSPR_DAL_GET_LOV")
	public static Map<?, ?>  testBnsprDalGetLov(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("LOV_NAME", "/2010/LOV_DOVIZ");
			oMap.put("INPUT_PARAMETERS", new ArrayList<String>(0));
			oMap.put("KEY", "%");
			return GMServiceExecuter.execute("BNSPR_DAL_GET_LOV", oMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("TEST_QUARTZ")
	public static HashMap<String, Object> testQuartz(GMMap iMap){
		
		try {
			/*
			InitialContext iniCtx = new InitialContext();
			StdScheduler sched = (StdScheduler)iniCtx.lookup("Quartz");
			String x = sched.getSchedulerName();
			
			sched.deleteJob("ScanDirectory", Scheduler.DEFAULT_GROUP);
			
			System.out.println(x);
			// Create a JobDetail for the Job
	         JobDetail jobDetail =
	                       new JobDetail("ScanDirectory", Scheduler.DEFAULT_GROUP, tr.com.calikbank.bnspr.quartz.ScanDirectoryJob.class);

	         jobDetail.getJobDataMap().put("SCAN_DIR", "C:\\GMDevelopment\\Graymound\\Server\\Content\\Root\\data\\1000");

	         // Create a trigger that fires every 10 seconds, forever
	         Trigger trigger = org.quartz.TriggerUtils.makeSecondlyTrigger(10);
	         trigger.setName("scanTrigger");
	         // Start the trigger firing from now
	         trigger.setStartTime(new Date());
	         // Associate the trigger with the job in the scheduler
	         // sched.addJob(jobDetail, true);
	         
	         // Date ft = sched.scheduleJob(trigger);
	         // System.out.println(ft);
	         
	         sched.scheduleJob(jobDetail, trigger);

	         */
		} catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0, e);
		} finally {

		}
		return new HashMap<String, Object>();
	}
	
	@GraymoundService("BNSPR_TEST_GMSERVER_GETPROPERTY")
	public static GMMap serviceMethodName(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("GM_HOME", GMServer.getProperty("graymound.home", ""));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TEST_GET_TEMP_IO_DIRECTORY")
	public static GMMap getTempIoDirectory(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("TEMP_DIRECTORY", System.getProperty("java.io.tmpdir"));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_DUMMY_SERVICE")
	public static GMMap dummyService(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try {
			System.out.println(DALUtil.callOracleFunction("{? = call pkg_genel_pr.lc_al}", BnsprType.STRING));
			System.out.println(DALUtil.callOracleFunction("{? = call vergino_checkdigit(?)}", BnsprType.STRING, BnsprType.STRING, "234123123"));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_SYSTEM_COMBO_TEST_LIST")
	public static GMMap getOnayStatuList(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1, key1 from gnl_param_text where kod = 'ONAY_STATU_KOD' order by sira_no");
			rSet = stmt.executeQuery();

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("LIST_NAME", "DURUM");
			return DALUtil.fillComboBox(iMap, rSet);
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
/*	
	@GraymoundService("BNSPR_TEMPLATE_PLAIN_SAVE")
	public static Map<?, ?> plainSave(GMMap iMap){
		Monitor monitor = null;
		try{
			monitor = MonitorFactory.start("BNSPR_TEMPLATE_PLAIN_SAVE");
			Session session = DAOSession.getSession("BNSPRDal");
			TestPojo pojo = new TestPojo();
			pojo.setStr(iMap.getString("str"));
			pojo.setBd(iMap.getBigDecimal("bd"));
			pojo.setDate(iMap.getDate("date"));
			
			pojo.setStr2(iMap.getString("str2"));
			pojo.setBd2(iMap.getBigDecimal("bd2"));
			pojo.setDate2(iMap.getDate("date2"));
			
			pojo.setStr3(iMap.getString("str3"));
			pojo.setBd3(iMap.getBigDecimal("bd3"));
			pojo.setDate3(iMap.getDate("date3"));
			
			pojo.setStr4(iMap.getString("str4"));
			pojo.setBd4(iMap.getBigDecimal("bd4"));
			pojo.setDate4(iMap.getDate("date4"));
			
			pojo.setStr5(iMap.getString("str5"));
			pojo.setBd5(iMap.getBigDecimal("bd5"));
			pojo.setDate5(iMap.getDate("date5"));
			
			pojo.setStr6(iMap.getString("str6"));
			pojo.setBd6(iMap.getBigDecimal("bd6"));
			pojo.setDate6(iMap.getDate("date6"));
			
			pojo.setStr7(iMap.getString("str7"));
			pojo.setBd7(iMap.getBigDecimal("bd7"));
			pojo.setDate7(iMap.getDate("date7"));
			
			pojo.setStr8(iMap.getString("str8"));
			pojo.setBd8(iMap.getBigDecimal("bd8"));
			pojo.setDate8(iMap.getDate("date8"));
			
			pojo.setStr9(iMap.getString("str9"));
			pojo.setBd9(iMap.getBigDecimal("bd9"));
			pojo.setDate9(iMap.getDate("date9"));
			
			pojo.setStr10(iMap.getString("str10"));
			pojo.setBd10(iMap.getBigDecimal("bd10"));
			pojo.setDate10(iMap.getDate("date10"));
			
			pojo.setStr11(iMap.getString("str11"));
			pojo.setBd11(iMap.getBigDecimal("bd11"));
			pojo.setDate11(iMap.getDate("date11"));
			
			pojo.setStr12(iMap.getString("str12"));
			pojo.setBd12(iMap.getBigDecimal("bd12"));
			pojo.setDate12(iMap.getDate("date12"));
			
			pojo.setStr13(iMap.getString("str13"));
			pojo.setBd13(iMap.getBigDecimal("bd13"));
			pojo.setDate13(iMap.getDate("date13"));
			
			TestPojoId id = new TestPojoId();
			id.setStrId(iMap.getString("strId") + "1");
			id.setBdId(iMap.getBigDecimal("bdId").add(new BigDecimal(1)));
			id.setDateId(iMap.getDate("dateId"));
			pojo.setId(id);
			
			String tableName = "DETAIL";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				TestDetailPojo detail = new TestDetailPojo();
				detail.setStrDetail(iMap.getString(tableName, row, "strDetail"));
				detail.setBdDetail(iMap.getBigDecimal(tableName, row, "bdDetail"));
				detail.setDateDetail(iMap.getDate(tableName, row, "dateDetail"));
				
				detail.setStr2Detail(iMap.getString(tableName, row, "str2Detail"));
				detail.setBd2Detail(iMap.getBigDecimal(tableName, row, "bd2Detail"));
				detail.setDate2Detail(iMap.getDate(tableName, row, "date2Detail"));
				
				detail.setStr3Detail(iMap.getString(tableName, row, "str3Detail"));
				detail.setBd3Detail(iMap.getBigDecimal(tableName, row, "bd3Detail"));
				detail.setDate3Detail(iMap.getDate(tableName, row, "date3Detail"));
				
				detail.setStr4Detail(iMap.getString(tableName, row, "str4Detail"));
				detail.setBd4Detail(iMap.getBigDecimal(tableName, row, "bd4Detail"));
				detail.setDate4Detail(iMap.getDate(tableName, row, "date4Detail"));
				
				detail.setStr5Detail(iMap.getString(tableName, row, "str5Detail"));
				detail.setBd5Detail(iMap.getBigDecimal(tableName, row, "bd5Detail"));
				detail.setDate5Detail(iMap.getDate(tableName, row, "date5Detail"));
				
				detail.setStr6Detail(iMap.getString(tableName, row, "str6Detail"));
				detail.setBd6Detail(iMap.getBigDecimal(tableName, row, "bd6Detail"));
				detail.setDate6Detail(iMap.getDate(tableName, row, "date6Detail"));
				
				detail.setStr7Detail(iMap.getString(tableName, row, "str7Detail"));
				detail.setBd7Detail(iMap.getBigDecimal(tableName, row, "bd7Detail"));
				detail.setDate7Detail(iMap.getDate(tableName, row, "date7Detail"));
				
				detail.setStr8Detail(iMap.getString(tableName, row, "str8Detail"));
				detail.setBd8Detail(iMap.getBigDecimal(tableName, row, "bd8Detail"));
				detail.setDate8Detail(iMap.getDate(tableName, row, "date8Detail"));
				
				detail.setStr9Detail(iMap.getString(tableName, row, "str9Detail"));
				detail.setBd9Detail(iMap.getBigDecimal(tableName, row, "bd9Detail"));
				detail.setDate9Detail(iMap.getDate(tableName, row, "date9Detail"));
				
				detail.setStr10Detail(iMap.getString(tableName, row, "str10Detail"));
				detail.setBd10Detail(iMap.getBigDecimal(tableName, row, "bd10Detail"));
				detail.setDate10Detail(iMap.getDate(tableName, row, "date10Detail"));
				
				detail.setStr11Detail(iMap.getString(tableName, row, "str11Detail"));
				detail.setBd11Detail(iMap.getBigDecimal(tableName, row, "bd11Detail"));
				detail.setDate11Detail(iMap.getDate(tableName, row, "date11Detail"));
				
				detail.setStr12Detail(iMap.getString(tableName, row, "str12Detail"));
				detail.setBd12Detail(iMap.getBigDecimal(tableName, row, "bd12Detail"));
				detail.setDate12Detail(iMap.getDate(tableName, row, "date12Detail"));
				
				detail.setStr13Detail(iMap.getString(tableName, row, "str13Detail"));
				detail.setBd13Detail(iMap.getBigDecimal(tableName, row, "bd13Detail"));
				detail.setDate13Detail(iMap.getDate(tableName, row, "date13Detail"));
				
				TestDetailPojoId detailId = new TestDetailPojoId();
				detailId.setStrDetailId(iMap.getString(tableName, row, "strDetailId") + "4");
				detailId.setBdDetailId(iMap.getBigDecimal(tableName, row, "bdDetailId").add(new BigDecimal(1)));
				detailId.setDateDetailId(iMap.getDate(tableName, row, "dateDetailId"));
				
				detail.setId(detailId);
				session.save(detail);
			}
			
			session.save(pojo);
			session.flush();
			monitor.stop();
			System.out.println(monitor);
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TEMPLATE_PERSISTER_SAVE")
	public static Map<?, ?> persisterSave(GMMap iMap){
		Monitor monitor = null;
		monitor = MonitorFactory.start("BNSPR_TEMPLATE_PERSISTER_SAVE");
		Map<?, ?> oMap = new BnsprTxPersister(iMap, TestPojo.class, TestPojoId.class, null, "TRX_TEMPLATE")
		.addDetailPojoClass(TestDetailPojo.class, TestDetailPojoId.class, "DETAIL", null)
		.persist();
		monitor.stop();
		System.out.println(monitor);
		return oMap;
	}
	
	@GraymoundService("BNSPR_TEMPLATE_GET_DETAIL_MODEL_DATA")
	public static GMMap getExDetaiRow(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tableName = "DETAIL";
			for (int row = 0; row < 40; row++) {
				oMap.put(tableName, row, "strDetail", "this is not a long string");
				oMap.put(tableName, row, "bdDetail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "dateDetail", new Date());
				
				oMap.put(tableName, row, "str2Detail", "this is not a long string");
				oMap.put(tableName, row, "bd2Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date2Detail", new Date());

				oMap.put(tableName, row, "str3Detail", "this is not a long string");
				oMap.put(tableName, row, "bd3Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date3Detail", new Date());

				oMap.put(tableName, row, "str4Detail", "this is not a long string");
				oMap.put(tableName, row, "bd4Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date4Detail", new Date());

				oMap.put(tableName, row, "str5Detail", "this is not a long string");
				oMap.put(tableName, row, "bd5Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date5Detail", new Date());
				
				oMap.put(tableName, row, "str6Detail", "this is not a long string");
				oMap.put(tableName, row, "bd6Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date6Detail", new Date());
				
				oMap.put(tableName, row, "str7Detail", "this is not a long string");
				oMap.put(tableName, row, "bd7Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date7Detail", new Date());
				
				oMap.put(tableName, row, "str8Detail", "this is not a long string");
				oMap.put(tableName, row, "bd8Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date8Detail", new Date());
				
				oMap.put(tableName, row, "str9Detail", "this is not a long string");
				oMap.put(tableName, row, "bd9Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date9Detail", new Date());
				
				oMap.put(tableName, row, "str10Detail", "this is not a long string");
				oMap.put(tableName, row, "bd10Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date10Detail", new Date());
				
				oMap.put(tableName, row, "str11Detail", "this is not a long string");
				oMap.put(tableName, row, "bd11Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date11Detail", new Date());
				
				oMap.put(tableName, row, "str12Detail", "this is not a long string");
				oMap.put(tableName, row, "bd12Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date12Detail", new Date());
				
				oMap.put(tableName, row, "str13Detail", "this is not a long string");
				oMap.put(tableName, row, "bd13Detail", new BigDecimal(123456789.12));
				oMap.put(tableName, row, "date13Detail", new Date());
				
				oMap.put(tableName, row, "strDetailId", "this is not a long string" + new Random().nextInt(10000000));
				oMap.put(tableName, row, "bdDetailId", new BigDecimal(new Random().nextInt(10000000)));
				oMap.put(tableName, row, "dateDetailId", new Date());
			}
			
			oMap.put("ID", new BigDecimal(new Random().nextInt(10000000)));
			return oMap;	
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}*/
	
	@GraymoundService("BNSPR_TRN9901_GET_INFO_PLAIN")
	public static GMMap getInfoPlain(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GnlSubeKodPrTx gnlSubeKodPrTx = (GnlSubeKodPrTx)session.get(GnlSubeKodPrTx.class, iMap.getBigDecimal("TRX_NO"));		
			
			oMap.put("TRX_NO", gnlSubeKodPrTx.getTxNo());
			oMap.put("KODU" , gnlSubeKodPrTx.getKod());
	        oMap.put("ADI" , gnlSubeKodPrTx.getSubeAdi());
	        oMap.put("IL_KODU" , gnlSubeKodPrTx.getIlKod());
	        oMap.put("IL_ADI",LovHelper.diLov(gnlSubeKodPrTx.getIlKod(), "9901/LV_IL", "IL_ADI"));
	        oMap.put("EFT_KODU" , gnlSubeKodPrTx.getEftKodu());
	        oMap.put("SUBE_F" , gnlSubeKodPrTx.getSubeGm());
	        oMap.put("SIRA_NO" , gnlSubeKodPrTx.getSiraNo());
	        oMap.put("TAKAS_KODU" , gnlSubeKodPrTx.getTakasKodu());
	        oMap.put("KAR_MERKEZI" , gnlSubeKodPrTx.getKarMerkezi());
	        oMap.put("YURT_ICI" , gnlSubeKodPrTx.getYurtIci());
	        oMap.put("MEMZUC_ILCE_KODU" , gnlSubeKodPrTx.getMemzucIlceKodu());
	        oMap.put("MEMZUC_ILCE_SUBE_SIRA" , gnlSubeKodPrTx.getMemzucIlceSubeSira());
	        oMap.put("KASA_MEVCUT_MU" , gnlSubeKodPrTx.getKasaMevcut());       
	        oMap.put("ILCE_KODU" , gnlSubeKodPrTx.getIlceKod());
	        oMap.put("ILCE_ADI" ,LovHelper.diLov(gnlSubeKodPrTx.getIlceKod(),gnlSubeKodPrTx.getIlKod(),"9901/LV_ILCE_KODU", "ILCE_ADI"));    
	        oMap.put("ULKE_KODU" , gnlSubeKodPrTx.getUlkeKod());      
	        oMap.put("ULKE_ADI",LovHelper.diLov(gnlSubeKodPrTx.getUlkeKod(), "9901/LV_ULKE_KODU", "ULKE_ADI"));
	        oMap.put("ADRES" , gnlSubeKodPrTx.getAdres1());
	        oMap.put("TELEFON" , gnlSubeKodPrTx.getTelefon());
	        oMap.put("FAX" , gnlSubeKodPrTx.getFax());
	        oMap.put("RESMI_DEFTER_BOLUM_KODU" , gnlSubeKodPrTx.getResmiDefterBolumKodu());
	        oMap.put("VERGI_DAIRE" , gnlSubeKodPrTx.getVergiDaire());
	        oMap.put("VERGI_NO" , gnlSubeKodPrTx.getVergiNo());
	        oMap.put("DURUM" , gnlSubeKodPrTx.getDurumu());
	        oMap.put("TESCIL_TARIHI" , gnlSubeKodPrTx.getTescilTarihi());
	        oMap.put("ACILIS_TARIHI" , gnlSubeKodPrTx.getAcilisTarihi());
	        oMap.put("SUBE_TIPI" , gnlSubeKodPrTx.getSubeTipi());
	        
	        List<?> list = session.createCriteria(GnlSubeTakasBagimliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        
	        String tableName = "BOLUM_TAKAS_BAGIMLI_ISLEM";
	        int row = 0;
			for (Iterator<?> iter = list.iterator(); iter.hasNext();row++) {
				GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx) iter.next();
				iMap.put(tableName, row, "TAKAS_BAGLI_BOLUM_KODU", gnlSubeTakasBagimliTx.getBagliBolumKodu());
				iMap.put(tableName, row, "NDB_TAKAS_BAGLI_BOLUM_ADI", LovHelper.diLov(
						gnlSubeTakasBagimliTx.getBagliBolumKodu(),
						"9901/LV_EFT_BOLUM", "ADI"));
			}
	        
			List<?> list1 = session.createCriteria(GnlSubeEftBagimliTx.class).add(
					Restrictions.eq("txNo", iMap
							.getBigDecimal("TRX_NO"))).list();
			
			tableName = "BOLUM_EFT_BAGIMLI_ISLEM";
			row = 0;
			for (Iterator<?> iter = list1.iterator(); iter.hasNext();row++) {
				GnlSubeEftBagimliTx gnlSubeEftBagimliTx = (GnlSubeEftBagimliTx) iter
						.next();
				iMap.put(tableName, row, "EFT_BAGLI_BOLUM_KODU", gnlSubeEftBagimliTx.getBagliBolumKodu());
				iMap.put(tableName, row, "NDB_EFT_BAGLI_BOLUM_ADI", LovHelper.diLov(
						gnlSubeEftBagimliTx.getBagliBolumKodu(), "9901/LV_TAKAS_BOLUM", "ADI"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9901_GET_INFO_WITH_LOADER")
	public static GMMap getInfoWithLoader(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new BnsprPojoLoader(new GMMap(), session.get(GnlSubeKodPrTx.class, iMap.getBigDecimal("TRX_NO")), new Bnspr9901MasterStrategy())
		.addDetailPojoList(session.createCriteria(GnlSubeTakasBagimliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list(), "BOLUM_TAKAS_BAGIMLI_ISLEM", new Bnspr9901TakasStrategy())
		.addDetailPojoList(session.createCriteria(GnlSubeEftBagimliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list(), "BOLUM_EFT_BAGIMLI_ISLEM", new Bnspr9901EftStrategy())
		.load();
		return oMap;
	}
	
	@GraymoundService("BNSPR_ASC_MAIL_TEST")
	public static GMMap ascMailTest(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", iMap.getString("FROM"));
			servisMap.put("MAIL_TO", iMap.getString("TO"));
			servisMap.put("MAIL_BCC", iMap.getString("BCC"));
			servisMap.put("MAIL_SUBJECT", iMap.getString("SUBJECT"));
			servisMap.put("MAIL_CC", iMap.getString("CC"));
			servisMap.put("MAIL_BODY", iMap.getString("MAIL_CONTENT"));
			servisMap.put("IS_BODY_HTML", iMap.getBoolean("IS_HTML") ? "E" : "H");
			String ATTACHMENT_KEY = "MAIL_ATTACHMENT_LIST";
			servisMap.put(ATTACHMENT_KEY, 0, "FILE_CONTENT", iMap.get("ATTACHMENT1_CONTENT"));
			servisMap.put(ATTACHMENT_KEY, 0, "FILE_NAME", iMap.getString("ATTACHMENT1_FILENAME"));
			servisMap.put(ATTACHMENT_KEY, 1, "FILE_CONTENT", iMap.get("ATTACHMENT2_CONTENT"));
			servisMap.put(ATTACHMENT_KEY, 1, "FILE_NAME", iMap.getString("ATTACHMENT2_FILENAME"));
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			oMap.put("MESSAGE", "OK");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_SYSTEM_SEND_MAIL_TEST")
	public static GMMap sendMailTest(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap servisMap = new GMMap();
			servisMap.put("FROM", "bnspr@aktifbank.com.tr");
			ArrayList<String> toList = new ArrayList<String>();
			toList.add("kenan.aydin@obss.com.tr");
			servisMap.put("RECIPIENTS_TO", toList);
			servisMap.put("IS_BODY_HTML", false);
			servisMap.put("SUBJECT", "test message");
			servisMap.put("MESSAGE_BODY", "message body");
			servisMap.put("IS_BODY_HTML", iMap.getBoolean("IS_HTML") ? "E" : "H");
			servisMap.put("DMS_FOLDER_NAME", "SUBE_KROKI");

			String ATTACHMENT_KEY = "ATTACMENT_FILE_LIST";
			servisMap.put(ATTACHMENT_KEY, 0, "DMS_FILE_NAME", "kroki_test.jpg");
			GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
			//servisMap.put(ATTACHMENT_KEY, 1, "DMS_FILE_NAME", "senin.jpg");
			oMap.put("MESSAGE", "OK");
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
} 

class Bnspr9901MasterStrategy implements MappingStrategy{
	@Override
	public void doMapping(GMMap oMap, Object pojo, String tableName, int row) {
		GnlSubeKodPrTx gnlSubeKodPrTx = (GnlSubeKodPrTx)pojo;
		oMap.put("ilAdi",LovHelper.diLov(gnlSubeKodPrTx.getIlKod(), "9901/LV_IL", "IL_ADI"));
        oMap.put("ilceAdi" ,LovHelper.diLov(gnlSubeKodPrTx.getIlceKod(),gnlSubeKodPrTx.getIlKod(),"9901/LV_ILCE_KODU", "ILCE_ADI"));    
        oMap.put("ulkeAdi",LovHelper.diLov(gnlSubeKodPrTx.getUlkeKod(), "9901/LV_ULKE_KODU", "ULKE_ADI"));
	}
}

class Bnspr9901EftStrategy implements MappingStrategy{
	@Override
	public void doMapping(GMMap oMap, Object pojo, String tableName, int row) {
		GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx)pojo;
		oMap.put(tableName, row, "bagliBolumAdi", LovHelper.diLov(gnlSubeTakasBagimliTx.getBagliBolumKodu(), "9901/LV_EFT_BOLUM", "ADI"));
	}
}

class Bnspr9901TakasStrategy implements MappingStrategy{
	@Override
	public void doMapping(GMMap oMap, Object pojo, String tableName, int row) {
		GnlSubeTakasBagimliTx gnlSubeTakasBagimliTx = (GnlSubeTakasBagimliTx)pojo;
		oMap.put(tableName, row, "bagliBolumAdi", LovHelper.diLov(gnlSubeTakasBagimliTx.getBagliBolumKodu(), "9901/LV_TAKAS_BOLUM", "ADI"));
	}
}
