package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.islBirimKod;
import tr.com.aktifbank.bnspr.dao.islBirimKodId;
import tr.com.aktifbank.bnspr.dao.islBolumKod;
import tr.com.aktifbank.bnspr.dao.islServisKod;
import tr.com.aktifbank.bnspr.dao.islServisKodId;
import tr.com.aktifbank.bnspr.dao.islislemListesi;
import tr.com.aktifbank.bnspr.dao.islislemListesiTx;
import tr.com.aktifbank.bnspr.dao.islislemListesiTxId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * BPM_GROUP_ROLE services
 * 
 * @author samet.erkorkmaz
 *
 */
public class SystemTRN9815Services {
	
	@GraymoundService("BNSPR_TRN9815_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int i=0;
		try {
			List<islislemListesiTx> islemTxList =  (List<islislemListesiTx>) session.createCriteria(islislemListesiTx.class).add(Restrictions.eq("id.txNo",  iMap.getBigDecimal("TRX_NO"))).list();        
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			for(islislemListesiTx islemTx: islemTxList){
				oMap.put("ISLEM_LIST",i,"GDS",islemTx.getDgs());
				oMap.put("ISLEM_LIST",i,"BIRIM_KOD",islemTx.getBirimKod());
				oMap.put("ISLEM_LIST",i,"BIRIM_ADI",getBirimAdi(islemTx.getBolumKod(), islemTx.getBirimKod()));
				oMap.put("ISLEM_LIST",i,"BOLUM_KOD",islemTx.getBolumKod());
				oMap.put("ISLEM_LIST",i,"BOLUM_ADI",getBolumAdi(islemTx.getBolumKod()));
				oMap.put("ISLEM_LIST",i,"SERVIS_KOD",islemTx.getServisKod());
				oMap.put("ISLEM_LIST",i,"SERVIS_ADI",getServisAdi(islemTx.getBolumKod(), islemTx.getBirimKod(), islemTx.getServisKod()));
				oMap.put("ISLEM_LIST", i, "ISLEM_ID", islemTx.getId().getIsKodu());
				oMap.put("ISLEM_LIST", i, "IS_TANIMI", islemTx.getIsTanimi());
				oMap.put("ISLEM_LIST", i, "KATEGORI", islemTx.getKategori());
				oMap.put("ISLEM_LIST", i, "PERIYOT_KOD", islemTx.getPeriyot());
				oMap.put("ISLEM_LIST", i, "PERIYOT", getParamText("9815_ISLEM_PERIYOTLARI", islemTx.getPeriyot()));
				oMap.put("ISLEM_LIST", i, "SURE", islemTx.getSure());
			}
		} finally {
			session.close();
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(List<islislemListesi> islemList,GMMap oMap){
		int index=0;
		for(islislemListesi islem:islemList) {
			oMap.put("ISLEM_LIST", index, "BOLUM_KOD", islem.getId().getBolumKod());
			oMap.put("ISLEM_LIST", index, "BOLUM_ADI", getBolumAdi(islem.getId().getBolumKod()));
			oMap.put("ISLEM_LIST", index, "BIRIM_KOD", islem.getId().getBirimKod());
			oMap.put("ISLEM_LIST", index, "BIRIM_ADI", getBirimAdi(islem.getId().getBolumKod(), islem.getId().getBirimKod()));
			oMap.put("ISLEM_LIST", index, "SERVIS_KOD", islem.getId().getServisKod());
			oMap.put("ISLEM_LIST", index, "SERVIS_ADI", getServisAdi(islem.getId().getBolumKod(), islem.getId().getBirimKod(), islem.getId().getServisKod()));
			oMap.put("ISLEM_LIST", index, "ISLEM_ID", islem.getId().getIsKodu());
			oMap.put("ISLEM_LIST", index, "IS_TANIMI", islem.getIsTanimi());
			oMap.put("ISLEM_LIST", index, "KATEGORI", islem.getKategori());
			oMap.put("ISLEM_LIST", index, "PERIYOT_KOD", islem.getPeriyot());
			oMap.put("ISLEM_LIST", index, "PERIYOT", getParamText("9815_ISLEM_PERIYOTLARI", islem.getPeriyot()));
			oMap.put("ISLEM_LIST", index, "SURE", islem.getSure());
			
			index++;
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9815_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");	
		@SuppressWarnings("unchecked")
		List<islislemListesi> islemList = (List<islislemListesi>)session.createCriteria(islislemListesi.class).list();		
		
		return putObjToGMMap(islemList, oMap);
	}
	
	@GraymoundService("BNSPR_TRN9815_FILL_BOLUM_COMBO")
	public static GMMap fillGroupCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBolumKod> bolumKodList = (List<islBolumKod>)session.createCriteria(islBolumKod.class)
													.addOrder(Order.asc("kod")).list();
		for (islBolumKod bolumKod : bolumKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BOLUM", bolumKod.getKod().toString(), bolumKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9815_FILL_BIRIM_COMBO")
	public static GMMap fillBirimCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBirimKod> birimKodList = (List<islBirimKod>)session.createCriteria(islBirimKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islBirimKod birimKod : birimKodList) {
			GuimlUtil.wrapMyCombo(oMap, "BIRIM", birimKod.getId().getKod().toString(), birimKod.getAciklama());
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9815_FILL_SERVIS_COMBO")
	public static GMMap fillServisCombo(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islServisKod> servisKodList = (List<islServisKod>)session.createCriteria(islServisKod.class).add(Restrictions.eq("id.bolumKod", iMap.getBigDecimal("BOLUM_KOD")))
													.add(Restrictions.eq("id.birimKod", iMap.getBigDecimal("BIRIM_KOD")))
													.addOrder(Order.asc("id.kod")).list();
		for (islServisKod servisKod : servisKodList) {
			GuimlUtil.wrapMyCombo(oMap, "SERVIS", servisKod.getId().getKod().toString(), servisKod.getAciklama());
		}
		return oMap;
	}

		
	@GraymoundService("BNSPR_TRN9815_SAVE")
	public static GMMap save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date = new Date();
		GMMap oMap = new GMMap();
		if (iMap.getSize("ISLEM_LIST")>0){
			for (int i = 0; i < iMap.getSize("ISLEM_LIST"); i++) {
				if(!StringUtil.isEmpty(iMap.getString("ISLEM_LIST",i,"GDS"))){
					islislemListesiTxId id = new islislemListesiTxId();
					if(iMap.getString("ISLEM_LIST",i,"GDS").equals("G")){
						id.setIsKodu(BigDecimal.valueOf(Long.valueOf(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "ISL_ISLEM_LISTESI_TX")).getString("ID"))));
					}else{
						id.setIsKodu(iMap.getBigDecimal("ISLEM_LIST",i,"ISLEM_ID"));	
					}
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					
					islislemListesiTx islemListTx = new islislemListesiTx();
					islemListTx.setBolumKod(iMap.getBigDecimal("ISLEM_LIST",i,"BOLUM_KOD"));
					islemListTx.setBirimKod(iMap.getBigDecimal("ISLEM_LIST",i,"BIRIM_KOD"));
					islemListTx.setServisKod(iMap.getBigDecimal("ISLEM_LIST",i,"SERVIS_KOD"));
					islemListTx.setDgs(iMap.getString("ISLEM_LIST",i,"GDS"));
					islemListTx.setId(id);
					islemListTx.setIsTanimi(iMap.getString("ISLEM_LIST",i,"IS_TANIMI"));
					islemListTx.setKategori(iMap.getString("ISLEM_LIST",i,"KATEGORI"));
					islemListTx.setPeriyot(iMap.getString("ISLEM_LIST",i,"PERIYOT_KOD"));
					islemListTx.setSure(iMap.getBigDecimal("ISLEM_LIST",i,"SURE"));
					islemListTx.setLastModified(date);
					session.saveOrUpdate(islemListTx);
			}
		}
		
		session.flush();
		oMap = callSendTrn(iMap);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN9815_FILL_COMBO_PERIYOD")
	public static GMMap fillComboPeriod(GMMap iMap){
		GMMap oMap = new GMMap();
		iMap.put("KOD" , "9815_ISLEM_PERIYOTLARI");
        iMap.put("ADD_EMPTY_KEY" , "H");
        oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));
		return oMap;
	}
	private static GMMap callSendTrn(GMMap iMap){
		iMap.put("TRX_NAME" , "9815");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
	
	
	private static String getBolumAdi(BigDecimal bolumKod){
		islBolumKod group = (islBolumKod) DAOSession.getSession("BNSPRDal").get(islBolumKod.class, bolumKod);
		return group.getAciklama();
	}
	private static String getBirimAdi(BigDecimal bolumKod, BigDecimal birimKod){
		islBirimKodId id = new  islBirimKodId();
		id.setBolumKod(bolumKod);
		id.setKod(birimKod);
		islBirimKod group = (islBirimKod) DAOSession.getSession("BNSPRDal").get(islBirimKod.class, id);
		return group.getAciklama();
	}
	private static String getServisAdi(BigDecimal bolumKod, BigDecimal birimKod, BigDecimal servisKod){
		islServisKodId id = new  islServisKodId();
		id.setBolumKod(bolumKod);
		id.setBirimKod(birimKod);
		id.setKod(servisKod);
		islServisKod group = (islServisKod) DAOSession.getSession("BNSPRDal").get(islServisKod.class, id);
		return group.getAciklama();
	}
	private static String getParamText(String kod,String key){
		GMMap iMap = new GMMap();
		iMap.put("KOD", kod);
		iMap.put("KEY", key);
		String deger =  GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap).getString("TEXT");
		return deger;
	}
}
