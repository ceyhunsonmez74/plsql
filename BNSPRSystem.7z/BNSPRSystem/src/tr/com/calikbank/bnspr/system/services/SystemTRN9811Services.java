package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.aktifbank.bnspr.dao.islBolumKod;
import tr.com.aktifbank.bnspr.dao.islBolumKodTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * BPM_GROUP services
 * 
 * @author samet.erkorkmaz
 *
 */
public class SystemTRN9811Services {
	
	@GraymoundService("BNSPR_TRN9811_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			islBolumKodTx bolumkodTx = (islBolumKodTx) session.get(islBolumKodTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

			if (bolumkodTx.getGds().equals("G")) {
				oMap.put("OPER_TYPE_G_D_S", "G");
				oMap.put("KOD", bolumkodTx.getKod());
				oMap.put("ACIKLAMA", bolumkodTx.getAciklama());
				return oMap;

			} else if (bolumkodTx.getGds().equals("D")) {
				oMap.put("OPER_TYPE_G_D_S", "D");
				oMap.put("KOD", bolumkodTx.getKod());
				oMap.put("ACIKLAMA", bolumkodTx.getAciklama());

				islBolumKod bolumKod = ((islBolumKod) session.get(islBolumKod.class, bolumkodTx.getKod()));
				return putObjToGMMap(bolumKod, oMap);

			} else if (bolumkodTx.getGds().equals("S")) {
				oMap.put("OPER_TYPE_G_D_S", "S");
				oMap.put("KOD", bolumkodTx.getKod());
				oMap.put("ACIKLAMA", bolumkodTx.getAciklama());

				islBolumKod bolumKod = ((islBolumKod) session.get(islBolumKod.class, bolumkodTx.getKod()));
				return putObjToGMMap(bolumKod, oMap);
			}
		} finally {
			session.close();
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(List<islBolumKod> bolumKodList, GMMap oMap){
		int index=0;
		for(islBolumKod bolumKod:bolumKodList) {
			oMap.put("GROUP_LIST", index, "KOD", bolumKod.getKod());
			oMap.put("GROUP_LIST", index, "ACIKLAMA", bolumKod.getAciklama());
			index++;
		}
		return oMap;
	}
	
	private static GMMap putObjToGMMap(islBolumKod bolumKod, GMMap oMap){
		oMap.put("GROUP_LIST", 0, "KOD", bolumKod.getKod());
		oMap.put("GROUP_LIST", 0, "ACIKLAMA", bolumKod.getAciklama());
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN9811_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<islBolumKod> islBolumKodList=(List<islBolumKod>)session.createCriteria(islBolumKod.class)
												.addOrder(Order.asc("kod")).list();
		
		return putObjToGMMap(islBolumKodList, oMap);
	}
		
	@GraymoundService("BNSPR_TRN9811_SAVE")
	public static GMMap save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date= new Date();
		islBolumKodTx bolumkodTx = new islBolumKodTx();
		bolumkodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		bolumkodTx.setKod(BigDecimal.valueOf(Long.valueOf(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "ISL_BOLUM_KOD_TX")).getString("ID"))));
		bolumkodTx.setAciklama(iMap.getString("ACIKLAMA"));
		bolumkodTx.setGds("G");
		bolumkodTx.setLastModified(date);
		session.save(bolumkodTx);
		session.flush();
		return callTrn9811(iMap);
	}
	
	@GraymoundService("BNSPR_TRN9811_UPDATE")
	public static GMMap update(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Date date= new Date();
		islBolumKodTx bolumkodTx = new islBolumKodTx();
		bolumkodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		bolumkodTx.setKod(iMap.getBigDecimal("KOD"));
		bolumkodTx.setAciklama(iMap.getString("ACIKLAMA"));
		bolumkodTx.setLastModified(date);
		bolumkodTx.setGds("D");
		session.save(bolumkodTx);
		session.flush();
		return callTrn9811(iMap);

	}
	
	@GraymoundService("BNSPR_TRN9811_DELETE")
	public static GMMap delete(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		islBolumKod bolumKod = (islBolumKod)session.get(islBolumKod.class,iMap.getString("KOD"));

		islBolumKodTx bolumkodTx = new islBolumKodTx();
		bolumkodTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		bolumkodTx.setKod(bolumKod.getKod());
		bolumkodTx.setAciklama(iMap.getString("ACIKLAMA"));
		bolumkodTx.setGds("S");
		session.save(bolumkodTx);
		session.flush();
		return callTrn9811(iMap);
	}
	
	private static GMMap callTrn9811(GMMap iMap){
		iMap.put("TRX_NAME" , "9811");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
}
