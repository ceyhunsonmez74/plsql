 package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlSifreTx;
import tr.com.aktifbank.bnspr.dao.GnlSifreTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
 
public class SystemTRN9974Services {
     
    @GraymoundService("BNSPR_TRN9974_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboboxInitialValue(GMMap iMap) {
        
        try {
            GMMap oMap = new GMMap();
            
            DALUtil.fillComboBox(oMap, "FTP_TURU", false, "SELECT KEY1 ,TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'FTP_TURU' ORDER BY KEY1 ");
          
            return oMap;
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

	  @GraymoundService("BNSPR_TRN9974_GET_LIST")
	    public static GMMap getTransactionNo(GMMap iMap) {
	        
	        GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        String tableName = "TBL_FTP_SIFRE_TANIMLAMA";
	        try{
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN9974.GET_SIFRE_LIST}");
	            stmt.registerOutParameter(1 , -10); // ref cursor
	            stmt.execute();
	            rSet = (ResultSet) stmt.getObject(1);
	            oMap = DALUtil.rSetResults(rSet , tableName);
	      
	            
	            
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	            GMServerDatasource.close(rSet);
	        }
	        
	    }
	    
	    @GraymoundService("BNSPR_TRN9974_SAVE")
	    public static Map<?, ?> save(GMMap iMap) {
	        try{
	            Session session = DAOSession.getSession("BNSPRDal");
	            String tableName = "TBL_FTP_SIFRE_TANIMLAMA";
	            
	            List<?> recordList = (List<?>) iMap.get(tableName);
	            
	            for (int row = 0; row < recordList.size(); row++){
	                
	                GnlSifreTxId id = new GnlSifreTxId();
	                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
	                id.setKod(iMap.getString(tableName , row , "KOD"));
	                
	                GnlSifreTx gnlSifreTx = (GnlSifreTx) session.get(GnlSifreTx.class , id);
	                if (gnlSifreTx == null){
	                	gnlSifreTx = new GnlSifreTx();
	                }
	                      
	                gnlSifreTx.setId(id);
	                
	               String mevcutSifre = DALUtil.getResult("select deger from gnl_sifre where kod = '"+iMap.getString(tableName, row, "KOD")+"'");
	               
	                if (("S").equals(iMap.getString(tableName , row , "G_S")))
	                	 gnlSifreTx.setGS("S");
	                else if (("G").equals(iMap.getString(tableName, row, "G_S")))
	                     gnlSifreTx.setGS("G");
	                else gnlSifreTx.setGS("");
	                
	                gnlSifreTx.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
	                gnlSifreTx.setUserName(iMap.getString(tableName , row , "KULLANICI_ADI"));
	                gnlSifreTx.setIp(iMap.getString(tableName , row , "IP"));
                    gnlSifreTx.setPath(iMap.getString(tableName , row , "PATH"));
                    gnlSifreTx.setFtpTuru(iMap.getString(tableName , row , "FTP_TURU"));
                    gnlSifreTx.setPort(iMap.getBigDecimal(tableName , row , "PORT"));
	                if (mevcutSifre == null || "".equals(mevcutSifre)) 
	                {
	                	gnlSifreTx.setDeger(iMap.getString(tableName, row, "YENI_SIFRE"));
	                }
	                else {
	                	gnlSifreTx.setDeger(mevcutSifre);	
	                }
	                
	                gnlSifreTx.setYeniSifre(iMap.getString(tableName, row, "YENI_SIFRE"));
	               
	                session.saveOrUpdate(gnlSifreTx);
	            }
	            session.flush();
	            iMap.put("TRX_NAME" , "9974");
	            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        }
	    }
	    
	    @GraymoundService("BNSPR_TRN9974_GET_INFO")
	    public static GMMap getInfo(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        
	        try {
	            // Get Master
	            String tableName = "TBL_FTP_SIFRE_TANIMLAMA";
	            Session session = DAOSession.getSession("BNSPRDal");
	            Criteria criteria = session.createCriteria(GnlSifreTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
	            
	            List<?> recordList = (List<?>) criteria.list();
	            
	            for (int row = 0; row < recordList.size(); row++){
	            	GnlSifreTx gnlSifreTx = (GnlSifreTx) recordList.get(row);
	            	
	                oMap.put("TX_NO" , iMap.getBigDecimal("TRX_NO"));
	                oMap.put(tableName , row , "KOD" , gnlSifreTx.getId().getKod());
	                oMap.put(tableName , row , "ACIKLAMA" , gnlSifreTx.getAciklama());
	                oMap.put(tableName , row , "IP" , gnlSifreTx.getIp());
	                oMap.put(tableName , row , "G_S" , gnlSifreTx.getGS());
	                oMap.put(tableName , row , "SIL" , ("S").equals(gnlSifreTx.getGS()) ? true : false);
                    oMap.put(tableName , row , "PATH" , gnlSifreTx.getPath());
                    oMap.put(tableName , row , "KULLANICI_ADI" , gnlSifreTx.getUserName());
                    oMap.put(tableName , row , "PORT" , gnlSifreTx.getPort());
                    oMap.put(tableName , row , "FTP_TURU" , gnlSifreTx.getFtpTuru());
	                
	            }
	            
	            return oMap;
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        }
	    }
	    
	    @GraymoundService("BNSPR_TRN9974_KAYIT_KONTROLU")
	    public static GMMap getTanimliMusteriVarMi(GMMap iMap) {
	        
	        Connection conn = null;
	        CallableStatement stmt = null;
	        
	        try{
	            
	            conn = DALUtil.getGMConnection();
	            
	            stmt = conn.prepareCall("{? = call PKG_TRN9974.tanimli_kayit_kontrolu(?)}");
	            stmt.registerOutParameter(1 , Types.VARCHAR);
	            stmt.setString(2 , iMap.getString("KOD"));
	            stmt.execute();
	            
	            GMMap oMap = new GMMap();
	            oMap.put("MESSAGE" , stmt.getString(1));
	            
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }   
	    
	    @GraymoundService("BNSPR_TRN9974_SIFRE_KONTROLU")
	    public static GMMap getSifreKontrolu(GMMap iMap) {
	        
	        Connection conn = null;
	        CallableStatement stmt = null;
	        
	        try{
	            
	            conn = DALUtil.getGMConnection();
	            
	            stmt = conn.prepareCall("{? = call PKG_TRN9974.MEVCUT_SIFRE_KONTROLU(?,?)}");
	            stmt.registerOutParameter(1 , Types.VARCHAR);
	            stmt.setString(2 , iMap.getString("KOD"));
	            stmt.setString(3 , iMap.getString("MEVCUT_SIFRE"));
	            stmt.execute();
	            
	            GMMap oMap = new GMMap();
	            oMap.put("FLAG" , stmt.getString(1));
	           
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }   
	    
	    
	    @GraymoundService("BNSPR_TRN9974_ZORUNLU_ALAN_KONTROLU")
	    public static GMMap getZorunluAlanKontrolu(GMMap iMap) {
	        
	        Connection conn = null;
	        CallableStatement stmt = null;
	        
	        try{
	            
	            conn = DALUtil.getGMConnection();
	            
	            GMMap oMap = new GMMap();
	            
	            if (iMap.getString("KOD") == null || "".equals(iMap.getString("KOD")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "KOD");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            
	            if (iMap.getString("PATH") == null || "".equals(iMap.getString("PATH")))
	            {
	            	iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "PATH");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
	            }
	            
	            

                if (iMap.getString("IP") == null || "".equals(iMap.getString("IP")))
                {
                    iMap.put("HATA_NO", new BigDecimal(330));
                    iMap.put("P1", "IP");
                    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);   
                }
                
                
                if (iMap.getString("KULLANICI_ADI") == null || "".equals(iMap.getString("KULLANICI_ADI")))
                {
                    iMap.put("HATA_NO", new BigDecimal(330));
                    iMap.put("P1", "KULLANICI ADI");
                    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);   
                }
/*
                if (StringUtils.isBlank(iMap.getString("PORT")))
                {
                    iMap.put("HATA_NO", new BigDecimal(330));
                    iMap.put("P1", "Port");
                    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);   
                }
                */
                
                if (StringUtils.isBlank(iMap.getString("FTP_TURU")))
                {
                    iMap.put("HATA_NO", new BigDecimal(330));
                    iMap.put("P1", "FTP T�r�");
                    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);   
                }
	            
	            return oMap;
	            
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }   
		@GraymoundService("BNSPR_TRN9974_RENKLENDIRME")
		public static GMMap Renklendir(GMMap iMap) {	
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				List<?> list = (List<?>) iMap.get("TBL_FTP_SIFRE_TANIMLAMA");	
				if(list != null)
				{
					for (int i = 0; i < list.size(); i++) {

						if( "G".equals(iMap.getString("TBL_FTP_SIFRE_TANIMLAMA", i, "G_S")))
						{		
						  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "KOD", getUnchangedTableCellColorData(Color.GREEN));
						  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "ACIKLAMA", getUnchangedTableCellColorData(Color.GREEN));
						  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "KULLANICI_ADI", getUnchangedTableCellColorData(Color.GREEN));
                          oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "IP", getUnchangedTableCellColorData(Color.GREEN));
                          oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "PATH", getUnchangedTableCellColorData(Color.GREEN));
                          oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "PORT", getUnchangedTableCellColorData(Color.GREEN));
                          oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "FTP_TURU", getUnchangedTableCellColorData(Color.GREEN));
						}
						else if ("S".equals(iMap.getString("TBL_FTP_SIFRE_TANIMLAMA", i, "G_S")))
						{
							
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "KOD", getUnchangedTableCellColorData(Color.RED));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "ACIKLAMA", getUnchangedTableCellColorData(Color.RED));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "KULLANICI_ADI", getUnchangedTableCellColorData(Color.RED));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "IP", getUnchangedTableCellColorData(Color.RED));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "PATH", getUnchangedTableCellColorData(Color.RED));
	                          oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "PORT", getUnchangedTableCellColorData(Color.RED));
	                          oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "FTP_TURU", getUnchangedTableCellColorData(Color.RED));
						}
						else
						{
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "KOD", getUnchangedTableCellColorData(Color.WHITE));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "ACIKLAMA", getUnchangedTableCellColorData(Color.WHITE));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "KULLANICI_ADI", getUnchangedTableCellColorData(Color.WHITE));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "IP", getUnchangedTableCellColorData(Color.WHITE));
							  oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "PATH", getUnchangedTableCellColorData(Color.WHITE));
                              oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "PORT", getUnchangedTableCellColorData(Color.WHITE));
                              oMap.put("TBL_FTP_SIFRE_TANIMLAMA", i, "FTP_TURU", getUnchangedTableCellColorData(Color.WHITE));
						}
					}
				}  
			return oMap;			
			}catch (Exception e){
				throw ExceptionHandler.convertException(e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}	
		}
		private static GMMap getUnchangedTableCellColorData(Color backgroundColor){
			GMMap oMap = new GMMap();
			oMap.put("setBackground", backgroundColor);
			return oMap;
		}
	}
