package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemQRY9938Services {
    
    public static GMMap getServiceResults(String query, String tableName) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getServiceLogConnection();
            stmt = conn.prepareStatement(query);
            rSet = stmt.executeQuery();
            GMMap oMap = DALUtil.rSetResults(rSet , tableName);
            return oMap;
        } catch (Exception e){
            throw DALUtil.dalUtilConvertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_QRY9938_GET_TRANSACTION")
    public static GMMap getTransactionList(GMMap iMap) {
        if (iMap.get("USERCODE") == null || iMap.getString("USERCODE").isEmpty()){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Kullan�c� Kodu bo� olamaz!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (iMap.get("INTERVAL") == null || iMap.getString("INTERVAL").isEmpty()){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Tarih Aral���!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            
            String tableName = "EKRAN_TABLE";
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC9938.get_screen_transactions(?,?,?)}");
            stmt.setString(1 , iMap.getString("USERCODE"));
            stmt.setString(2 , iMap.getString("INTERVAL"));
            stmt.registerOutParameter(3 , -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(3);
            int row = 0;
            List<String> sessionIDList = new ArrayList<String>();
            String tempsessionId = "E";
            
            while (rSet.next()){
                
                oMap.put(tableName , row , "SESSIONID" , rSet.getObject("SESSIONID"));
                if ("E".equals(tempsessionId)){
                    tempsessionId = (String) rSet.getObject("SESSIONID");
                    sessionIDList.add(tempsessionId);
                }
                if (!tempsessionId.equals(rSet.getObject("SESSIONID"))){
                    tempsessionId = (String) rSet.getObject("SESSIONID");
                    sessionIDList.add(tempsessionId);
                }
                
               
                oMap.put(tableName , row , "GUIML" , rSet.getObject("GUIML"));
                oMap.put(tableName , row , "ENTRYDATE" , rSet.getObject("ENTRYDATE"));
    
                
                row++;
                
            }
            int sessionIDSize = sessionIDList.size();
            StringBuilder builder = new StringBuilder();
            builder =
                    builder.append("SELECT   a.core_session_id,a.server_ip,a.service_name,a.duration,DATE_FORMAT(a.begin_date, '%d-%m-%Y %H:%i:%s') begin_date ,DATE_FORMAT(a.end_date, '%d-%m-%Y %H:%i:%s') end_date,c.name FROM ADC_SERVICE_LOG a,SERVICE_REGISTRY_SERVICE b,");
            builder = builder.append(" SERVICE_REGISTRY_OWNER c WHERE  a.service_name = b.name   AND b.owner_id = c.id AND ");
            int trnInterval = iMap.getInt("INTERVAL") + 10;
            builder = builder.append(" a.BEGIN_DATE > DATE_SUB(SYSDATE(), INTERVAL " + trnInterval + " MINUTE )");
            oMap.put("INTERVAL_EKRAN" , "Son " + iMap.getInt("INTERVAL") + " dakikadaki ekran hareketleri");
            oMap.put("INTERVAL_TRANSACTION" , "Son " + trnInterval + " dakikadaki transaction hareketleri");
            if (sessionIDSize > 0){
                builder.append("and a.core_session_id IN (");
            }
            for (int i = 0; i < sessionIDSize; i++){
                
                builder.append("'");
                builder.append(sessionIDList.get(i));
                if (i != sessionIDSize - 1)
                    builder.append("',");
                else builder.append("'");
                
            }
            
            if (sessionIDSize > 0){
                builder.append(")");
            } else{
                return oMap;
            }
            
            builder.append(" order by a.begin_date desc ");
            
            oMap.putAll(getServiceResults(builder.toString() , "TRANSACTION_TABLE"));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            
        }
        
        return oMap;
    }
}
