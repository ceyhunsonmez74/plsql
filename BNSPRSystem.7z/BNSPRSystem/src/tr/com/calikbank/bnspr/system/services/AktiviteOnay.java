package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AktiviteGiris;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AktiviteOnay {

	@GraymoundService("BNSPR_AKTIVITE_ONAY_ACILIS_BILGI")
	public static GMMap AcilisBilgi(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			oMap.put("YONETICI", YoneticiBul((String) GMContext.getCurrentContext().getSession().get("USER_NAME")));
			oMap.put("BOLUM", YoneticiBolumBul((String) GMContext.getCurrentContext().getSession().get("USER_NAME")));
			oMap.put("TARIH_BAS",DALUtil.getResult("select to_char(pkg_tarih.haftanin_ilk_is_gunu,'yyyymmdd') from dual"));
			oMap.put("TARIH_BIT",DALUtil.getResult("select to_char(pkg_tarih.haftanin_son_is_gunu(pkg_tarih.haftanin_ilk_is_gunu),'yyyymmdd') from dual"));
			oMap.putAll(DALUtil.fillComboBox(iMap, "PROJE", false,"select kod, adi aciklama from bnspr.aktivite_proje order by 2"));
			iMap.put("KOD", "AKT_GIRIS_AKTTIPI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("AKTIVITE_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			oMap.putAll(DALUtil.fillComboBox(iMap, "IS_BIRIMI", false,"select kod, aciklama from gnl_bolum_kod_pr order by 2"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static String YoneticiBul(String Kullanici) {
		Connection conn = null;
		CallableStatement stmt = null;
		String Yonetici;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.yonetici_bul(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, Kullanici);
			stmt.execute();

			Yonetici = stmt.getString(1);

			return Yonetici;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static String YoneticiBolumBul(String Kullanici) {
		Connection conn = null;
		CallableStatement stmt = null;
		String KullaniciBolum;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_aktivite.bolum_adi_bul(?) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, Kullanici);
			stmt.execute();

			KullaniciBolum = stmt.getString(1);

			return KullaniciBolum;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


	@GraymoundService("BNSPR_AKTIVITE_ONAY_KULLANICI_COMBO")
	public static GMMap KullaniciCombo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select kullanici, pkg_genel_pr.kullanici_adi(kullanici) from aktivite_kullanici where yonetici = ?");
			stmt.setString(1, (String) GMContext.getCurrentContext().getSession().get("USER_NAME"));

			rSet = stmt.executeQuery();

			//GuimlUtil.wrapMyCombo(oMap, "KULLANICI", " ", " ");
			GuimlUtil.wrapMyCombo(oMap, "KULLANICI", "TUM", "TUM");
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "KULLANICI", rSet.getString(1),rSet.getString(2));
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static String[] kullaniciBul(String yonetici){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select kullanici from aktivite_kullanici where yonetici = ?");
			stmt.setString(1, yonetici);

			rSet = stmt.executeQuery();

			String[] kullanicilar = new String[100];
			int i = 0;
			
			while (rSet.next()) {
				kullanicilar[i++] = rSet.getString(1);
			}

			return kullanicilar;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_AKTIVITE_ONAY_SORGULA")
	public static GMMap Sorgula(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			int row = 0;
			double pazartesi, sali, carsamba, persembe, cuma, toplam;
			double topPazartesi = 0, topSali = 0, topCarsamba = 0, topPersembe = 0, topCuma = 0, topTop = 0;
			String zaman;
			Boolean yaz = true;
			String tableName = "AKTIVITE_GIRIS";
			List<?> list = null;
			if(iMap.getString("KULLANICI").equals("TUM")){
				String[] kullanicilar = kullaniciBul((String) GMContext.getCurrentContext().getSession().get("USER_NAME"));
				list = (List<?>) session.createCriteria(AktiviteGiris.class)
				.add(Restrictions
				.and(Restrictions.in("kullanici",kullanicilar),
					Restrictions.and(Restrictions.eq("tarih", iMap.getDate("TARIH")),
							Restrictions.or(Restrictions.eq("durum", "ONAYDA"), Restrictions.eq("durum", "ONAYLI")))))
				.list();
			}else{
				list = (List<?>) session.createCriteria(AktiviteGiris.class)
				.add(Restrictions
				.and(Restrictions.eq("kullanici",iMap.getString("KULLANICI")),
					Restrictions.and(Restrictions.eq("tarih", iMap.getDate("TARIH")),
							Restrictions.or(Restrictions.eq("durum", "ONAYDA"), Restrictions.eq("durum", "ONAYLI")))))
				.list();
			}
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				AktiviteGiris aktiviteGiris = (AktiviteGiris) iterator.next();

				oMap.put(tableName, row, "PROJE", aktiviteGiris.getProje());
				oMap.put(tableName, row, "AKTIVITE_TIPI", aktiviteGiris.getAktiviteTipi());
				oMap.put(tableName, row, "AKTIVITE", aktiviteGiris.getAktivite());
				oMap.put(tableName, row, "ISSUE_NO", aktiviteGiris.getIssueNo());
				oMap.put(tableName, row, "IS_BIRIMI", aktiviteGiris.getIsBirimi());
				oMap.put(tableName, row, "PAZARTESI", aktiviteGiris.getPazartesi());
				oMap.put(tableName, row, "SALI", aktiviteGiris.getSali());
				oMap.put(tableName, row, "CARSAMBA", aktiviteGiris.getCarsamba());
				oMap.put(tableName, row, "PERSEMBE", aktiviteGiris.getPersembe());
				oMap.put(tableName, row, "CUMA", aktiviteGiris.getCuma());
				oMap.put(tableName, row, "SIRA_NO", aktiviteGiris.getSiraNo());
				if(aktiviteGiris.getDurum().equals("ONAYLI")){
					oMap.put(tableName, row, "ONAYLI_MI", "1");
				}else{
					oMap.put(tableName, row, "ONAYLI_MI", "0");
				}
				oMap.put(tableName, row, "KULLANICI_KODU", aktiviteGiris.getKullanici());
				if(aktiviteGiris.getPazartesi() == null) pazartesi = 0; 
				else {pazartesi = aktiviteGiris.getPazartesi().doubleValue(); topPazartesi += pazartesi;}
				if(aktiviteGiris.getSali() == null) sali = 0; 
				else {sali = aktiviteGiris.getSali().doubleValue(); topSali += sali;}
				if(aktiviteGiris.getCarsamba() == null) carsamba = 0; 
				else {carsamba = aktiviteGiris.getCarsamba().doubleValue(); topCarsamba += carsamba;}
				if(aktiviteGiris.getPersembe() == null) persembe = 0; 
				else {persembe = aktiviteGiris.getPersembe().doubleValue(); topPersembe += persembe;}
				if(aktiviteGiris.getCuma() == null) cuma = 0; 
				else {cuma = aktiviteGiris.getCuma().doubleValue(); topCuma += cuma;}
				
				toplam = pazartesi + sali + carsamba + persembe + cuma;
				zaman = zamanBul(toplam);
				oMap.put(tableName, row, "TOPLAM", zaman);				
				
				topTop += toplam;
				
				oMap.put(tableName, row, "ACIKLAMA", aktiviteGiris.getAciklama());
				if(yaz){
					oMap.put("ACIKLAMA", aktiviteGiris.getAciklama());
					yaz = false;
				}
			}
			zaman = zamanBul(topPazartesi);
			oMap.put("TOP_PAZARTESI", zaman);
			
			zaman = zamanBul(topSali);
			oMap.put("TOP_SALI", zaman);
			
			zaman = zamanBul(topCarsamba);
			oMap.put("TOP_CARSAMBA", zaman);
			
			zaman = zamanBul(topPersembe);
			oMap.put("TOP_PERSEMBE", zaman);
			
			zaman = zamanBul(topCuma);
			oMap.put("TOP_CUMA", zaman);
			
			zaman = zamanBul(topTop);
			oMap.put("TOP_TOP", zaman);

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	private static String zamanBul(double toplam){
		double toplamSaat, toplamDakika;
		int intToplamSaat, intToplamDakika;
		String zaman;
		toplamSaat = (toplam-toplam%60)/60;
		toplamDakika = toplam - toplamSaat * 60;
		intToplamSaat = (int)toplamSaat;
		intToplamDakika = (int)toplamDakika;
		zaman = intToplamSaat + ":" + intToplamDakika;
		return zaman;
	}

	@GraymoundService("BNSPR_AKTIVITE_ONAY_ONAYLA")
	public static GMMap sakla(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "TBL_AKTIVITE";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {

				AktiviteGiris aktiviteGiris = (AktiviteGiris)session.get(AktiviteGiris.class,iMap.getBigDecimal(tableName, i, "SIRA_NO"));
				
				aktiviteGiris.setTarih(iMap.getDate("TARIH"));
				aktiviteGiris.setProje(iMap.getString(tableName, i, "PROJE"));
				aktiviteGiris.setAktiviteTipi(iMap.getString(tableName, i, "AKTIVITE_TIPI"));
				aktiviteGiris.setIssueNo(iMap.getString(tableName, i,"ISSUE_NO"));
				aktiviteGiris.setAktivite(iMap.getString(tableName, i,"AKTIVITE"));
				aktiviteGiris.setIsBirimi(iMap.getString(tableName, i,"IS_BIRIMI"));
				aktiviteGiris.setPazartesi(iMap.getBigDecimal(tableName, i,"PAZARTESI"));
				aktiviteGiris.setSali(iMap.getBigDecimal(tableName, i, "SALI"));
				aktiviteGiris.setCarsamba(iMap.getBigDecimal(tableName, i,"CARSAMBA"));
				aktiviteGiris.setPersembe(iMap.getBigDecimal(tableName, i,"PERSEMBE"));
				aktiviteGiris.setCuma(iMap.getBigDecimal(tableName, i, "CUMA"));
				aktiviteGiris.setDurum("ONAYLI");
				aktiviteGiris.setAciklama(iMap.getString("ACIKLAMA"));
				
				session.saveOrUpdate(aktiviteGiris);
				session.flush();
			}

			return new GMMap().put("MESSAGE", "Onaylandi");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
  
	@GraymoundService("BNSPR_AKTIVITE_ONAY_GERI")
	public static GMMap geri(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "TBL_AKTIVITE";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {

				AktiviteGiris aktiviteGiris = (AktiviteGiris)session.get(AktiviteGiris.class,iMap.getBigDecimal(tableName, i, "SIRA_NO"));

				aktiviteGiris.setTarih(iMap.getDate("TARIH"));
				aktiviteGiris.setProje(iMap.getString(tableName, i, "PROJE"));
				aktiviteGiris.setAktiviteTipi(iMap.getString(tableName, i, "AKTIVITE_TIPI"));
				aktiviteGiris.setIssueNo(iMap.getString(tableName, i,"ISSUE_NO"));
				aktiviteGiris.setAktivite(iMap.getString(tableName, i,"AKTIVITE"));
				aktiviteGiris.setIsBirimi(iMap.getString(tableName, i,"IS_BIRIMI"));
				aktiviteGiris.setPazartesi(iMap.getBigDecimal(tableName, i,"PAZARTESI"));
				aktiviteGiris.setSali(iMap.getBigDecimal(tableName, i, "SALI"));
				aktiviteGiris.setCarsamba(iMap.getBigDecimal(tableName, i,"CARSAMBA"));
				aktiviteGiris.setPersembe(iMap.getBigDecimal(tableName, i,"PERSEMBE"));
				aktiviteGiris.setCuma(iMap.getBigDecimal(tableName, i, "CUMA"));
				aktiviteGiris.setDurum("GIRIS");
				aktiviteGiris.setAciklama(iMap.getString("ACIKLAMA"));

				session.saveOrUpdate(aktiviteGiris);
				session.flush();
			}

			return new GMMap().put("MESSAGE", "Geri Cevrildi");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}	
}
