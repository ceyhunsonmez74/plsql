package tr.com.calikbank.bnspr.system.services;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;

import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.calikbank.bnspr.util.DALUtil;

public class BatchHataMail {

	

	
	@GraymoundService("GUNSONU_BATCH_HATA_MAIL_GONDER")
	public static GMMap GunSonuBatchHataMail(GMMap iMap) {
		Connection conn = null;
		
		CallableStatement stmt = null;
		CallableStatement stmt1 = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSetInner = null;
		ResultSet rSetOuter = null;

		String FileName = "";
		try {
			conn = DALUtil.getGMConnection();
			//FileName ="GUNSONU_BATCH_HATA_MAIL_" +  GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH").toString()+ ".xls";
			
			/////////////////////////////////////////////////////////////777
			/// MAIL GRUPLARIN ALINMASI

			stmt1 = conn.prepareCall("{ ?=call PKG_RC_BATCH.RC_GUNSONU_MAIL_LIST }"); 
			
			int i = 1;
			stmt1.registerOutParameter(i++, -10); //ref cursor
			
			stmt1.execute();

			rSetOuter = (ResultSet)stmt1.getObject(1);
	
			int row2 = 0;
			row2++;
			while(rSetOuter.next()){
			
				    GMMap servisMap = new GMMap();
				
				    FileName =rSetOuter.getString("KOD")+ "_" +  GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getString("BANKA_TARIH")+ ".xls";
				
				    servisMap.put("MAIL_FROM", "akustik@aktifbank.com.tr");
					servisMap.put("MAIL_TO", rSetOuter.getString("MAIL_TO")); //////////////////////////////////////
					servisMap.put("MAIL_CC", rSetOuter.getString("MAIL_CC"));
				  	
					servisMap.put("MAIL_SUBJECT", rSetOuter.getString("KOD"));
					servisMap.put("MAIL_BODY", rSetOuter.getString("KOD")); // mail_body bos gonderilemez.
					servisMap.put("IS_BODY_HTML", "H");
				
					servisMap.put("FILE_NAME", FileName);
				    
				    /////
					stmt = conn.prepareCall("{ ? =call PKG_RC_BATCH.RC_GUNSONU_PROGRAM_LIST(?,?,?) }"); 
					
					int j = 1;
					stmt.registerOutParameter(j++, -10); //ref cursor
					stmt.setBigDecimal(j++, rSetOuter.getBigDecimal("GRUP_NO"));
					stmt.setString(j++, rSetOuter.getString("KOD"));
					stmt.setString(j++, rSetOuter.getString("F_TUM_LISTE"));
					stmt.execute();

					rSetInner = (ResultSet)stmt.getObject(1);
				    

					
					File tempExcelFile = FileUtil.createTempDirFile(FileName);
					WritableWorkbook workbook = Workbook.createWorkbook(tempExcelFile); 
					WritableSheet sheet = workbook.createSheet("BATCH HATA", 0);
					int row = 0;
					
					//create excel column headers
					int col = 0;
					sheet.addCell(new Label(col++, row, "LOG NO"));
					sheet.addCell(new Label(col++, row, "PROGRAM KOD"));
					sheet.addCell(new Label(col++, row, "BA�LAMA ZAMANI"));
					sheet.addCell(new Label(col++, row, "DURUM"));
					sheet.addCell(new Label(col++, row, "GRUP NO"));
					sheet.addCell(new Label(col++, row, "HATA MESAJI"));
					sheet.addCell(new Label(col++, row, "SIRA NO"));
					sheet.addCell(new Label(col++, row, "TX NO"));
					sheet.addCell(new Label(col++, row, "BANKA TAR�H�"));
					row++;
					
					while(rSetInner.next()){
						col = 0;
						sheet.addCell(new Label(col++, row, rSetInner.getString("LOG_NO")));
						sheet.addCell(new Label(col++, row, rSetInner.getString("PROGRAM_KOD")));
						sheet.addCell(new Label(col++, row, rSetInner.getString("BASLAMA_ZAMANI")));
						sheet.addCell(new Label(col++, row, rSetInner.getString("DURUM")));
						sheet.addCell(new Label(col++, row, rSetInner.getString("GRUP_NO")));
						sheet.addCell(new Label(col++, row, rSetInner.getString("HATA_MESAJI")));
					    sheet.addCell(new Label(col++, row, rSetInner.getString("SIRA_NO")));
						sheet.addCell(new Label(col++, row, rSetInner.getString("TX_NO")));
						sheet.addCell(new Label(col++, row, rSetInner.getDate("BANKA_TARIHI").toString()));
					    row++;
					}
					
					
					workbook.write();
					workbook.close();
					
					int size = (int)tempExcelFile.length(); 
					byte[] fileContent = new byte[size];
					DataInputStream dis = new DataInputStream(new FileInputStream(
							tempExcelFile));
					int read = 0;
					int numRead = 0;
					while (read < fileContent.length
							&& (numRead = dis.read(fileContent, read,
									fileContent.length - read)) >= 0) {
						read = read + numRead;
					}
					System.out.println("File size: " + read);
					if (read < fileContent.length) {
						System.out.println("Could not completely read: " + tempExcelFile.getName());
					}
					servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", FileName);
					servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", fileContent);
					GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
									
				
					
	
					GMServerDatasource.close(rSetInner);
					GMServerDatasource.close(stmt);
				

					
					
			    row2++;
			}	
				
			stmt2 = conn.prepareCall("{call PKG_RC_BATCH.mail_gonderdi}"); 
			stmt2.execute();			
			//////////////////////////////////////////////////////77
			

		
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSetInner);
			GMServerDatasource.close(rSetOuter);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}

	
	

@GraymoundService("GUNBASI_BATCH_HATA_MAIL_GONDER")
public static GMMap GunBasiBatchHataMail(GMMap iMap) {
	Connection conn = null;
	CallableStatement stmt = null;
	ResultSet rSetInner = null;
	String FileName = "";
	try {
		StringBuilder islemQuerySb = new StringBuilder()
		
	
		.append("select * from gnl_batch_program_log  ")
		.append("where grup_no=1 and log_no=(select max(log_no) from gnl_batch_program_log where grup_no=2) ")
		.append("and durum='N' order by sira_no ");
		
		conn = DALUtil.getGMConnection();
		FileName ="GUNBASI_BATCH_HATA_MAIL_" +  GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH").toString()+ ".xls";
	
		
		GMMap servisMap = new GMMap();
		
		
		servisMap.put("MAIL_FROM", "akustik@aktifbank.com.tr");
		servisMap.put("MAIL_TO", DALUtil.getResult("select DEGER from gnl_parametre where kod = 'BATCH_HATA_MAIL'")); 
	
		
		servisMap.put("MAIL_SUBJECT", "G�nba�� Hata");
		servisMap.put("MAIL_BODY", "G�nba�� Hata"); //mail_body bos gonderilemez.
		
		servisMap.put("IS_BODY_HTML", "H");
	
		servisMap.put("FILE_NAME", FileName);
		
		stmt = conn.prepareCall(islemQuerySb.toString());
		rSetInner = stmt.executeQuery();
		File tempExcelFile = FileUtil.createTempDirFile(FileName);
		WritableWorkbook workbook = Workbook.createWorkbook(tempExcelFile); 
		WritableSheet sheet = workbook.createSheet("BATCH HATA", 0);
		int row = 0;
		
		//create excel column headers
		int col = 0;
		sheet.addCell(new Label(col++, row, "LOG NO"));
		sheet.addCell(new Label(col++, row, "PROGRAM KOD"));
		sheet.addCell(new Label(col++, row, "BA�LAMA ZAMANI"));
		sheet.addCell(new Label(col++, row, "DURUM"));
		sheet.addCell(new Label(col++, row, "GRUP NO"));
		sheet.addCell(new Label(col++, row, "HATA MESAJI"));
		sheet.addCell(new Label(col++, row, "SIRA NO"));
		sheet.addCell(new Label(col++, row, "TX NO"));
		sheet.addCell(new Label(col++, row, "BANKA TAR�H�"));
		row++;
		
		while(rSetInner.next()){
			col = 0;
			sheet.addCell(new Label(col++, row, rSetInner.getString("LOG_NO")));
			sheet.addCell(new Label(col++, row, rSetInner.getString("PROGRAM_KOD")));
 		    sheet.addCell(new Label(col++, row, rSetInner.getString("BASLAMA_ZAMANI")));
			sheet.addCell(new Label(col++, row, rSetInner.getString("DURUM")));
			sheet.addCell(new Label(col++, row, rSetInner.getString("GRUP_NO")));
			sheet.addCell(new Label(col++, row, rSetInner.getString("HATA_MESAJI")));
			sheet.addCell(new Label(col++, row, rSetInner.getString("SIRA_NO")));
			sheet.addCell(new Label(col++, row, rSetInner.getString("TX_NO")));
			sheet.addCell(new Label(col++, row, rSetInner.getDate("BANKA_TARIHI").toString()));
			row++;
		}
		
		workbook.write();
		workbook.close();
		
		int size = (int)tempExcelFile.length(); 
		byte[] fileContent = new byte[size];
		DataInputStream dis = new DataInputStream(new FileInputStream(
				tempExcelFile));
		int read = 0;
		int numRead = 0;
		while (read < fileContent.length
				&& (numRead = dis.read(fileContent, read,
						fileContent.length - read)) >= 0) {
			read = read + numRead;
		}
		System.out.println("File size: " + read);
		if (read < fileContent.length) {
			System.out.println("Could not completely read: " + tempExcelFile.getName());
		}
		servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", FileName);
		servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", fileContent);
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
	//	updateMailStatus(conn, txNo, "E");
	
		return new GMMap();
	}catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}finally {
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
		GMServerDatasource.close(rSetInner);
	}
}


}

