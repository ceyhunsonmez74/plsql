package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9966Services {
	
	@GraymoundService("BNSPR_QRY9966_GET_COMBO_E_H")
	public static GMMap getComboModel(GMMap iMap){
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		

		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("E_H_COMBO_MODEL2", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
		return oMap;
	}
	@GraymoundService("BNSPR_QRY9966_GET_EKRAN_IZLEME_LIST")
	public static Map<?, ?> getEkranList(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC9966.QRY9966_Ekran_Sahipligi(?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("MODUL_TUR_KOD"));
			stmt.setString(3, iMap.getString("PROGRAM_KOD"));
			stmt.setString(4, iMap.getString("BOLUM_KOD"));
			stmt.setString(5, iMap.getString("BOLUM_KOD2"));
			stmt.setString(6, iMap.getString("TUR"));
			
			if(iMap.getDate("PROD_TAR_BAS") != null)
				stmt.setDate(7,  new java.sql.Date(iMap.getDate("PROD_TAR_BAS").getTime()));
			else
				stmt.setDate(7, null);
			if(iMap.getDate("PROD_TAR_BIT") != null)
				stmt.setDate(8,  new java.sql.Date(iMap.getDate("PROD_TAR_BIT").getTime()));
			else
				stmt.setDate(8, null);
			stmt.execute();
			
	
			String tableName = "EKRAN_LIST";
			rSet = (ResultSet)stmt.getObject(1);
			int row = 0;
			while(rSet.next())
			{
				oMap.put(tableName, row, "MODUL", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, row, "EKRAN_KODU", rSet.getString("EKRAN_KOD"));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "BOLUM_KODU", rSet.getString("BOLUM_KOD"));
				oMap.put(tableName, row, "BOLUM_KODU2", rSet.getString("BOLUM_KOD2"));
				oMap.put(tableName, row, "BOLUM_ADI", rSet.getString("BOLUM_ADI"));
				oMap.put(tableName, row, "BOLUM_ADI2", rSet.getString("BOLUM_ADI2"));
				oMap.put(tableName, row, "PROD_TARIHI", rSet.getDate("PROD_TARIHI"));
				oMap.put(tableName, row, "TUR", LovHelper.diLov(rSet.getString("EKRAN_KOD"),"9966/LOV_EKRAN_TUR", "TUR"));
				oMap.put(tableName, row, "MENUDE_LISTELENSIN_MI", rSet.getString("MENUDE_LISTELENSIN_MI"));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString("IPTAL_EDILEBILIR_MI"));
				oMap.put(tableName, row, "BOLUM_KODU_DURUM", rSet.getString("BOLUM_KODU_DURUM"));
				oMap.put(tableName, row, "BOLUM_KODU_DURUM_2", rSet.getString("BOLUM_KODU_DURUM_2"));
	
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
}