package tr.com.calikbank.bnspr.system.services;

import java.net.InetAddress;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class HataBildir {

	/**
	 * Project : System
	 * Used In : Hata bildirmek i�in
	 *
	 * DESC    : Al�nan hatay� emposta gerekli yerlere bildirir.
	 *
	 * @param iMap (GMMap)
	 *      SORUN_ACIKLAMASI
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA
	 *
	 * Company : Aktifbank
	 *
	 */
	@GraymoundService("BNSPR_SISTEM_SORUN_BILDIR")
	public static GMMap hataBildir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("KOD", "SYSTEM_SORUN_BILDIR_MAIL");
			iMap.put("TRIM_QUOTES", true);
			
			String to = iMap.getString("SORUMLU_MAIL");
			if (to.isEmpty() || to == "")
				to = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getString("DEGER");
			
			//String databaseAdi = GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", iMap).getString("DATABASE_ADI");
			String sistemAdi = GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", iMap).getString("SISTEM_ADI");

			String kullaniciKod = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", iMap).getString("KULLANICI_KOD");

			iMap.put("MAIL_FROM", "system@aktifbank.com.tr");
			iMap.put("IS_BODY_HTML", "E");
			iMap.put("MAIL_TO", to);
			iMap.put("MAIL_SUBJECT", "Akustik Hata Bildirimi ");
			
			String mailBody = 
					"<br /><b>SESSION_ID: </b>"				+ BnsprCommonFunctions.maskSessionId(ADCSession.getSessionID()) +
					"<br /><b>CLIENT IP: </b>"				+ ADCSession.getString("CLIENT_IP") +
					"<br /><b>SERVER : </b>"				+ InetAddress.getLocalHost().getHostAddress() +
					"<br />" +
					"<br /><b>Sistem Ad�: </b>"				+ sistemAdi +
					"<br /><b>Kullan�c� Kodu: </b>"			+ kullaniciKod +
					"<hr />" +
					"<br /><u><b>Sorun A��klamas�</b></u>"+"<br /><br />"	+ iMap.getString("SORUN_ACIKLAMASI").replaceAll(" ", "&nbsp;").replaceAll("\n", "<br />");
			
			
			String lastException = ADCSession.getString("LAST_EXCEPTION"); 
			if(lastException!=null){
				mailBody += "<br /><br /><b>Son Hata Zaman�: </b>"					+ ADCSession.getString("LAST_EXCEPTION_DATE") +
							"<br /><b>Son Hata: </b>";

				lastException = lastException.replaceAll(" ", "&nbsp;").replaceAll("\n", "<br />");
				mailBody += lastException;
			}
			
			iMap.put("MAIL_BODY_CLOB", mailBody );

			oMap.putAll(GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", iMap));

			oMap.put("RESPONSE", 2);
			oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("OPSUCC", null));
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

}
