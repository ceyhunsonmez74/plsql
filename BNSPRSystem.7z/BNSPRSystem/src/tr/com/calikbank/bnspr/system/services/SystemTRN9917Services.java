package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlKullaniciEsZamanizinTx;
import tr.com.aktifbank.bnspr.dao.GnlKullaniciEsZamanizinTxId;
import tr.com.aktifbank.bnspr.dao.KrlKasaTipPrTx;
import tr.com.aktifbank.bnspr.dao.KrlKasaTipPrTxId;
import tr.com.aktifbank.bnspr.dao.SchParametreDk;
import tr.com.aktifbank.bnspr.dao.SchParametreDkTx;
import tr.com.aktifbank.bnspr.dao.SchParametreDkTxId;
import tr.com.aktifbank.bnspr.dao.SchParametreTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9917Services {
	private static final Color BLUE = new Color(100,149,237);
	private static final Color GREEN = new Color(153,255,0);
	private static final Color YELLOW = new Color(238,230,133);
	
	@GraymoundService("BNSPR_TRN9917_GET_KULLANICI_LIST")
	public static GMMap GET_KULLANICI_LIST(GMMap iMap) {
	    Connection conn = null;
	    CallableStatement stmt = null;
	    ResultSet rSet = null;
	    String colorTableName ="ROL_ISLEM_COLOR_DATA";
	    try{
	        conn = DALUtil.getGMConnection();	            
	        stmt = conn.prepareCall("{? = call pkg_trn9917.RC_9917 }");
	        int i = 1;
	        stmt.registerOutParameter(i++, -10);
	        stmt.execute();            
	       rSet = (ResultSet) stmt.getObject(1);
	        
	       return DALUtil.rSetResults(rSet, "RECORD_LIST");
	    }catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }finally{
	        GMServerDatasource.close(rSet);
	        GMServerDatasource.close(stmt);
	        GMServerDatasource.close(conn);
	    }
	}
	public static String getTableName(GMMap iMap){
		String tableName = "RESULTS";
		if (iMap.containsKey("TABLE_NAME"))
			tableName = iMap.getString("TABLE_NAME");
		return tableName;
	}
	
	@GraymoundService("BNSPR_TRN9917_SAVE_RECORDS")
	public static Map<?, ?> save(GMMap iMap) {
 		
	  String  b="";
	    try {
	        Session session = DAOSession.getSession("BNSPRDal");	         
	        
	        String tableName = "GNL_KULLANICI_ES_ZAMAN_IZIN";
	        List<?>  eszamanlikullaniciList = (List<?>)iMap.get(tableName);
	       
	        GnlKullaniciEsZamanizinTx gnlKullaniciEsZamanizinTx;
	        GnlKullaniciEsZamanizinTxId gnlKullaniciEsZamanizinTxId;
	        
	        for (int i = 0; i < eszamanlikullaniciList.size(); i++) {
	        
	        	gnlKullaniciEsZamanizinTx = new GnlKullaniciEsZamanizinTx();
				gnlKullaniciEsZamanizinTxId = new GnlKullaniciEsZamanizinTxId(); 	
	        					
		        gnlKullaniciEsZamanizinTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
		        gnlKullaniciEsZamanizinTxId.setKullanicikod(iMap.getString(tableName, i, "KULLANICI_KOD")); 		            		        
		        gnlKullaniciEsZamanizinTx.setDurum(iMap.getString(tableName, i , "DURUM"));
		        
		        gnlKullaniciEsZamanizinTx.setId(gnlKullaniciEsZamanizinTxId);
		        b = iMap.getString(tableName, i, "KULLANICI_KOD");
		        session.saveOrUpdate(gnlKullaniciEsZamanizinTx);
		      
	        }
	        session.flush();
	
	        iMap.put("TRX_NAME", "9917");
	
	       return GMServiceExecuter
	                .execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	        
	    } 
	    
	    catch (NonUniqueObjectException e) {
	    	 
	    	iMap.put("HATA_NO", new BigDecimal(4263));
			iMap.put("P1", b+" nolu kullan�c� kodu listede mevcut!"); 
	    	return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	    	
	    }
	    catch (Exception e) { 
	        throw ExceptionHandler.convertException(e );
	    }
	     
	  }
	
	@GraymoundService("BNSPR_TRN9917_GET_KULLANICIESZAMANIZIN_BILGI")
	public static GMMap getEsZamanliKullaniciBilgi(GMMap iMap) {
	 //  Connection conn = null;
	   //CallableStatement stmt = null;;
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
	                  
	    try {
	        Session session = DAOSession.getSession("BNSPRDal");
	        GMMap oMap = new GMMap();
	        List<?> gnlKullaniciEsZamanizinTxList =  session
	                .createCriteria(GnlKullaniciEsZamanizinTx.class).add(Restrictions.eq("id.txNo", trxNo)).list(); 
	        
	        String tableName = "GNL_KULLANICI_ES_ZAMAN_IZIN_LIST";
	        String colorTableName ="GNL_KULLANICI_ES_ZAMAN_IZIN_LIST_COLOR";
	        
	        //conn = DALUtil.getGMConnection();       
	        int row = 0;
	        int tempRow = 0;
	        if(gnlKullaniciEsZamanizinTxList != null){
	            
	            for(Iterator<?> iterator = gnlKullaniciEsZamanizinTxList.iterator() ; iterator!=null ? iterator.hasNext() : false; row++ ){
	                
	            	GnlKullaniciEsZamanizinTx gnlKullaniciEsZamanizinTx = (GnlKullaniciEsZamanizinTx) iterator.next(); 
	                GMMap mMap = new GMMap();
	                mMap.put("KULLANICI_KOD", gnlKullaniciEsZamanizinTx.getId().getKullanicikod());
	                oMap.put(tableName, row , "KULLANICIADSOYAD" , LovHelper.diLov(gnlKullaniciEsZamanizinTx.getId().getKullanicikod() , "9917/LOV_KULLANICI" , "ADSOYAD")); 
	                mMap.put("DURUM", gnlKullaniciEsZamanizinTx.getDurum()); 
	                
	                oMap.put(tableName, row , "KULLANICI_KOD", gnlKullaniciEsZamanizinTx.getId().getKullanicikod());
	                oMap.put(tableName, row , "DURUM", gnlKullaniciEsZamanizinTx.getDurum());
	               
	                GMMap colorChangedD = new GMMap();
	    			colorChangedD.put("setBackground", Color.YELLOW);
	    			colorChangedD.put("setForeground", Color.RED);
	    			GMMap colorCase = new GMMap();
	                
	    			GMMap colorNotChanged  = new GMMap();
	    			colorNotChanged.put("setBackground", Color.WHITE);
	    			colorNotChanged.put("setForeground", Color.BLACK);
	    		 
	    				
		            if( "I".equals(gnlKullaniciEsZamanizinTx.getDurum()))
                       oMap.put(tableName, row , "SIL", true);
                    else
                       oMap.put(tableName, row , "SIL", false); 
	            
		            if( "I".equals(gnlKullaniciEsZamanizinTx.getDurum())  )
		            	colorCase = colorChangedD;
		            else if ( "G".equals(gnlKullaniciEsZamanizinTx.getDurum())  ) 
		            	colorCase = colorChangedD;
		            else
		            	colorCase = colorNotChanged;
				   
		            
		            oMap.put("TABLE_COLOR", row,"KULLANICI_KOD", colorCase);
		            oMap.put("TABLE_COLOR", row,"KULLANICIADSOYAD", colorCase);
		            oMap.put("TABLE_COLOR", row,"SIL", colorCase);
		            //oMap.put("TABLE_COLOR", row, colorCase); 
		            
	    			 
	            }
	        }
	        return oMap;
		    } catch (Exception e) {
		        throw ExceptionHandler.convertException(e);
		    }
	
	   }

		private static void compareTables(GMMap oMap, Map<?,?> oldTable, Map<?,?> newTable, int newTableRow, String colorTableName, Color color){
			
			for(Object key : newTable.keySet()){
				if(compareTwoStringForTable(oldTable.get(key), newTable.get(key))){
					oMap.put(colorTableName, newTableRow, key.toString(), getTableCellColorData("setBackground", color));		
				}
				else{
					oMap.put(colorTableName, newTableRow, key.toString(), getTableCellColorData("setBackground", Color.BLUE));
				}
			}
			
		}
		private static GMMap getTableCellColorData(String property, Color color){
			GMMap oMap = new GMMap();
			oMap.put(property, color);
			return oMap;
		}
		private static boolean compareTwoStringForTable(Object object, Object object2) {
			// TODO Auto-generated method stub
			return false;
		}
	
	

}