package tr.com.calikbank.bnspr.system.services;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SwiftMesajDetailMap;
import tr.com.aktifbank.bnspr.dao.SwiftMesajDetailMapId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9956Services {
    
    @GraymoundService("BNSPR_PAR9956_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        GMMap oMap = new GMMap();
        oMap.put("T_S_H" , 0 , "VALUE" , "T");
        oMap.put("T_S_H" , 0 , "NAME" , "Tablodan");
        oMap.put("T_S_H" , 1 , "VALUE" , "S");
        oMap.put("T_S_H" , 1 , "NAME" , "Sabit");
        oMap.put("T_S_H" , 2 , "VALUE" , "H");
        oMap.put("T_S_H" , 2 , "NAME" , "Hesapla");
        
        oMap.put("ALAN_TIPI" , 0 , "VALUE" , " ");
        oMap.put("ALAN_TIPI" , 0 , "NAME" , " ");
        oMap.put("ALAN_TIPI" , 1 , "VALUE" , "T");
        oMap.put("ALAN_TIPI" , 1 , "NAME" , "Tarih");
        oMap.put("ALAN_TIPI" , 2 , "VALUE" , "S");
        oMap.put("ALAN_TIPI" , 2 , "NAME" , "Say�sal");
        oMap.put("ALAN_TIPI" , 3 , "VALUE" , "K");
        oMap.put("ALAN_TIPI" , 3 , "NAME" , "Karakter");
        
        oMap.put("ZORUNLU" , 0 , "VALUE" , "E");
        oMap.put("ZORUNLU" , 0 , "NAME" , "Evet");
        oMap.put("ZORUNLU" , 1 , "VALUE" , "O");
        oMap.put("ZORUNLU" , 1 , "NAME" , "Opsiyonel");
        return oMap;
    }
    
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_PAR9956_SEARCH_INFO")
    public static GMMap getInfo(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(SwiftMesajDetailMap.class);
            if (!iMap.getString("ISLEM_KOD").isEmpty()){
                criteria.add(Restrictions.eq("id.islemKod" , iMap.getBigDecimal("ISLEM_KOD")));
            }
            if (!iMap.getString("MESAJ_KOD").isEmpty()){
                criteria.add(Restrictions.eq("id.mesajKod" , iMap.get("MESAJ_KOD")));
            }
            criteria.addOrder(Order.asc("id.islemKod")).addOrder(Order.asc("id.mesajKod"))
            .addOrder(Order.asc("id.satirNo")).addOrder(Order.asc("id.sutunNo"));
            List<SwiftMesajDetailMap> list = (List<SwiftMesajDetailMap>) criteria.list();
            Iterator iter = list.iterator();
            int i = 0;
            while (iter.hasNext()){
                SwiftMesajDetailMap swiftMesajDetailMap = (SwiftMesajDetailMap) iter.next();
                oMap.put("MESAJ_DETAY" , i , "T_S_H"        , swiftMesajDetailMap.getTSH()      );
                oMap.put("MESAJ_DETAY" , i , "ALAN_TIPI"    , swiftMesajDetailMap.getAlanTipi() );
                oMap.put("MESAJ_DETAY" , i , "FORMAT"       , swiftMesajDetailMap.getFormat()   );
                oMap.put("MESAJ_DETAY" , i , "FIELD"        , swiftMesajDetailMap.getField()    );
                oMap.put("MESAJ_DETAY" , i , "KOSUL"        , swiftMesajDetailMap.getKosul()    );
                oMap.put("MESAJ_DETAY" , i , "ZORUNLU"      , swiftMesajDetailMap.getZorunlu()  );
                oMap.put("MESAJ_DETAY" , i , "TABLE_NAME"   , swiftMesajDetailMap.getTableName());
                //ISLEM_KOD, MESAJ_KOD, MESAJ_TAG, SATIR_NO, SUTUN_NO primary_keys
                oMap.put("MESAJ_DETAY" , i , "ISLEM_KOD"      , swiftMesajDetailMap.getId().getIslemKod());
                oMap.put("MESAJ_DETAY" , i , "MESAJ_KOD"      , swiftMesajDetailMap.getId().getMesajKod());
                oMap.put("MESAJ_DETAY" , i , "MESAJ_TAG"      , swiftMesajDetailMap.getId().getMesajTag());
                oMap.put("MESAJ_DETAY" , i , "SATIR_NO"       , swiftMesajDetailMap.getId().getSatirNo() );
                oMap.put("MESAJ_DETAY" , i , "SUTUN_NO"       , swiftMesajDetailMap.getId().getSutunNo() );
                i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_PAR9956_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "SWIFT_MESSAGE_DETAIL_MAP";
            
            int i=0;
            Criteria criteria = session.createCriteria(SwiftMesajDetailMap.class);
            if (!iMap.getString("ISLEM_KOD").isEmpty()){
                criteria.add(Restrictions.eq("id.islemKod" , iMap.getBigDecimal("ISLEM_KOD")));
            }
            if (!iMap.getString("MESAJ_KOD").isEmpty()){
                criteria.add(Restrictions.eq("id.mesajKod" , iMap.get("MESAJ_KOD")));
            }
            List<SwiftMesajDetailMap> list = (List<SwiftMesajDetailMap>) criteria.list();
            Iterator iter = list.iterator();
            while(iter.hasNext()){
                SwiftMesajDetailMap swiftMesajDetailMapDelete= (SwiftMesajDetailMap) iter.next();
                session.delete(swiftMesajDetailMapDelete);
                session.flush();
                
            }
            
            while(i<iMap.getSize(tableName)){
                SwiftMesajDetailMapId id = new SwiftMesajDetailMapId();
                SwiftMesajDetailMap swiftMesajDetailMap= new SwiftMesajDetailMap();
                
                id.setIslemKod( iMap.getBigDecimal(tableName,    i, "ISLEM_KOD")  );
                id.setMesajKod( iMap.getString(tableName,        i, "MESAJ_KOD")  );
                id.setMesajTag( iMap.getString(tableName,        i, "MESAJ_TAG")  );
                id.setSatirNo(  iMap.getBigDecimal(tableName,    i, "SATIR_NO")   );
                id.setSutunNo(  iMap.getBigDecimal(tableName,    i, "SUTUN_NO")   );
                
                swiftMesajDetailMap.setId(id);
                swiftMesajDetailMap.setAlanTipi(iMap.getString(tableName,   i, "ALAN_TIPI"));
                swiftMesajDetailMap.setField(iMap.getString(tableName,      i, "FIELD"));
                swiftMesajDetailMap.setFormat(iMap.getString(tableName,     i, "FORMAT"));
                swiftMesajDetailMap.setKosul(iMap.getString(tableName,      i, "KOSUL"));
                swiftMesajDetailMap.setTSH(iMap.getString(tableName,        i, "T_S_H"));
                swiftMesajDetailMap.setZorunlu(iMap.getString(tableName,    i, "ZORUNLU"));
                swiftMesajDetailMap.setTableName(iMap.getString(tableName,  i, "TABLE_NAME"));

                session.saveOrUpdate(swiftMesajDetailMap);
                session.flush();
                i++;
            }    
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
}