package tr.com.calikbank.bnspr.system.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AktiviteGiris;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AktiviteIzle {

	
	private static String[] kullaniciBul(String yonetici){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select kullanici from aktivite_kullanici where yonetici = ?");
			stmt.setString(1, yonetici);

			rSet = stmt.executeQuery();

			String[] kullanicilar = new String[100];
			int i = 0;
			
			while (rSet.next()) {
				kullanicilar[i++] = rSet.getString(1);
			}

			return kullanicilar;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_AKTIVITE_IZLE_SORGULA")
	public static GMMap Sorgula(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			int row = 0;
			double pazartesi, sali, carsamba, persembe, cuma, toplam;
			double topPazartesi = 0, topSali = 0, topCarsamba = 0, topPersembe = 0, topCuma = 0, topTop = 0;
			String zaman;
			Boolean yaz = true;
			String tableName = "AKTIVITE_GIRIS";
			List<?> list = null;
			if(iMap.getString("PROJE").equals("TUM")){
				if(iMap.getString("KULLANICI").equals("TUM")){
					String[] kullanicilar = kullaniciBul((String) GMContext.getCurrentContext().getSession().get("USER_NAME"));
					list = (List<?>) session.createCriteria(AktiviteGiris.class)
					.add(Restrictions
					.and(Restrictions.in("kullanici",kullanicilar),Restrictions.eq("tarih", iMap.getDate("TARIH")))).list();
				}else{
					list = (List<?>) session.createCriteria(AktiviteGiris.class)
					.add(Restrictions
					.and(Restrictions.eq("kullanici",iMap.getString("KULLANICI")),Restrictions.eq("tarih", iMap.getDate("TARIH")))).list();
				}
			}else{
				if(iMap.getString("KULLANICI").equals("TUM")){
					String[] kullanicilar = kullaniciBul((String) GMContext.getCurrentContext().getSession().get("USER_NAME"));
					list = (List<?>) session.createCriteria(AktiviteGiris.class)
					.add(Restrictions
					.and(Restrictions.in("kullanici",kullanicilar),Restrictions.
							and(Restrictions.eq("tarih", iMap.getDate("TARIH")), Restrictions.eq("proje", iMap.getString("PROJE"))))).list();
				}else{
					list = (List<?>) session.createCriteria(AktiviteGiris.class)
					.add(Restrictions
					.and(Restrictions.eq("kullanici",iMap.getString("KULLANICI")),Restrictions.
							and(Restrictions.eq("tarih", iMap.getDate("TARIH")), Restrictions.eq("proje", iMap.getString("PROJE"))))).list();
				}
			}
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				AktiviteGiris aktiviteGiris = (AktiviteGiris) iterator.next();

				oMap.put(tableName, row, "PROJE", aktiviteGiris.getProje());
				oMap.put(tableName, row, "AKTIVITE_TIPI", aktiviteGiris.getAktiviteTipi());
				oMap.put(tableName, row, "AKTIVITE", aktiviteGiris.getAktivite());
				oMap.put(tableName, row, "ISSUE_NO", aktiviteGiris.getIssueNo());
				oMap.put(tableName, row, "IS_BIRIMI", aktiviteGiris.getIsBirimi());
				oMap.put(tableName, row, "PAZARTESI", aktiviteGiris.getPazartesi());
				oMap.put(tableName, row, "SALI", aktiviteGiris.getSali());
				oMap.put(tableName, row, "CARSAMBA", aktiviteGiris.getCarsamba());
				oMap.put(tableName, row, "PERSEMBE", aktiviteGiris.getPersembe());
				oMap.put(tableName, row, "CUMA", aktiviteGiris.getCuma());
				oMap.put(tableName, row, "SIRA_NO", aktiviteGiris.getSiraNo());
				if(aktiviteGiris.getDurum().equals("ONAYLI")){
					oMap.put(tableName, row, "ONAYLI_MI", "1");
				}else{
					oMap.put(tableName, row, "ONAYLI_MI", "0");
				}
				oMap.put(tableName, row, "KULLANICI_KODU", aktiviteGiris.getKullanici());
				if(aktiviteGiris.getPazartesi() == null) pazartesi = 0; 
				else {pazartesi = aktiviteGiris.getPazartesi().doubleValue(); topPazartesi += pazartesi;}
				if(aktiviteGiris.getSali() == null) sali = 0; 
				else {sali = aktiviteGiris.getSali().doubleValue(); topSali += sali;}
				if(aktiviteGiris.getCarsamba() == null) carsamba = 0; 
				else {carsamba = aktiviteGiris.getCarsamba().doubleValue(); topCarsamba += carsamba;}
				if(aktiviteGiris.getPersembe() == null) persembe = 0; 
				else {persembe = aktiviteGiris.getPersembe().doubleValue(); topPersembe += persembe;}
				if(aktiviteGiris.getCuma() == null) cuma = 0; 
				else {cuma = aktiviteGiris.getCuma().doubleValue(); topCuma += cuma;}
				
				toplam = pazartesi + sali + carsamba + persembe + cuma;
				zaman = zamanBul(toplam);
				oMap.put(tableName, row, "TOPLAM", zaman);				
				
				topTop += toplam;
				
				oMap.put(tableName, row, "ACIKLAMA", aktiviteGiris.getAciklama());
				if(yaz){
					oMap.put("ACIKLAMA", aktiviteGiris.getAciklama());
					yaz = false;
				}
			}
			zaman = zamanBul(topPazartesi);
			oMap.put("TOP_PAZARTESI", zaman);
			
			zaman = zamanBul(topSali);
			oMap.put("TOP_SALI", zaman);
			
			zaman = zamanBul(topCarsamba);
			oMap.put("TOP_CARSAMBA", zaman);
			
			zaman = zamanBul(topPersembe);
			oMap.put("TOP_PERSEMBE", zaman);
			
			zaman = zamanBul(topCuma);
			oMap.put("TOP_CUMA", zaman);
			
			zaman = zamanBul(topTop);
			oMap.put("TOP_TOP", zaman);

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	 
	private static String zamanBul(double toplam){
		double toplamSaat, toplamDakika;
		int intToplamSaat, intToplamDakika;
		String zaman;
		toplamSaat = (toplam-toplam%60)/60;
		toplamDakika = toplam - toplamSaat * 60;
		intToplamSaat = (int)toplamSaat;
		intToplamDakika = (int)toplamDakika;
		zaman = intToplamSaat + ":" + intToplamDakika;
		return zaman;
	}
}
