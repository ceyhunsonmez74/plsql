package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlVadeliScfDegisiklikTx;
import tr.com.aktifbank.bnspr.dao.GnlVadeliScfDegisiklikTxId;
import tr.com.aktifbank.bnspr.dao.MuhHesapKredi;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
 
public class SystemTRN9948Services {
	
	@GraymoundService("BNSPR_TRN9948_GET_SCH_ORAN_LIST")
	public static GMMap getList(GMMap iMap){
		GMMap 				oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN9948.RC_9948_sorgula(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("HESAP_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setInt(i++, iMap.getBoolean("SCH_FAIZ_CHECK") ? 1 : 0);
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "SCH_ORAN_LIST";
			int row = 0;
			while(rSet.next()){	
				oMap.put(tableName, row, "HESAP_NO", rSet.getBigDecimal("HESAP_NO"));
				oMap.put(tableName, row, "HESAP_TIPI", rSet.getString("HESAP_TIPI"));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, row, "URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put(tableName, row, "URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
				oMap.put(tableName, row, "VADE", rSet.getDate("VADE"));
				oMap.put(tableName, row, "SCH_FAIZ_ORANI_ESKI", rSet.getBigDecimal("SCH_FAIZ_ORANI"));
				oMap.put(tableName, row, "SCH_FAIZ_ORANI", rSet.getBigDecimal("SCH_FAIZ_ORANI"));
				oMap.put(tableName, row, "FAIZ_ORANI", rSet.getBigDecimal("FAIZ_ORANI"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));                
				oMap.put(tableName, row, "MUSTERI_ADI", rSet.getString("MUSTERI_ADI"));                
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9948_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			
			String tableName = "SCH_ORAN_LIST";
			Session session = DAOSession.getSession("BNSPRDal");
			
			for(int i=0; i<iMap.getSize(tableName); i++){
				
				GnlVadeliScfDegisiklikTxId id = new GnlVadeliScfDegisiklikTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
				
				GnlVadeliScfDegisiklikTx record = (GnlVadeliScfDegisiklikTx) session.get(GnlVadeliScfDegisiklikTx.class, id);
				
				if(record == null){
					record = new GnlVadeliScfDegisiklikTx();
					record.setId(id);
				}
				
				record.setHesapTipi(iMap.getString(tableName, i, "HESAP_TIPI"));
				record.setSchFaizOrani(iMap.getBigDecimal(tableName, i, "SCH_FAIZ_ORANI_ESKI"));
				record.setSchFaizOraniYeni(iMap.getBigDecimal(tableName, i, "SCH_FAIZ_ORANI"));
				session.saveOrUpdate(record);
				
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9948");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN9948_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			String tableName = "SCH_ORAN_LIST";
			Session session = DAOSession.getSession("BNSPRDal");
			int row = 0;
			
			List<GnlVadeliScfDegisiklikTx> recordList = session.createCriteria(GnlVadeliScfDegisiklikTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for(GnlVadeliScfDegisiklikTx record : recordList){

				oMap.put(tableName, row, "HESAP_NO", record.getId().getHesapNo());
				oMap.put(tableName, row, "HESAP_TIPI", record.getHesapTipi());
                MuhHesapKredi muhHesapKredi = (MuhHesapKredi) session.createCriteria(MuhHesapKredi.class).add(Restrictions.eq("hesapNo", record.getId().getHesapNo()));
				oMap.put(tableName, row, "MUSTERI_NO", muhHesapKredi.getMusteriNo());                
    			String adSoyad = (String) GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_INFO", new GMMap().put("MUSTERI_NO", muhHesapKredi.getMusteriNo())).get("KISA_AD");
				oMap.put(tableName, row, "MUSTERI_ADI", adSoyad);                
                
				GMMap lovMap = new GMMap();
				lovMap.putAll(LovHelper.diLovAll(record.getId().getHesapNo(), "9948/LOV_HESAP_NO_"+record.getHesapTipi()));
				oMap.put(tableName, row, "MODUL_TUR_KOD", lovMap.getString("MODUL_TUR_KOD"));			
				oMap.put(tableName, row, "URUN_TUR_KOD", lovMap.getString("URUN_TUR_KOD"));
				oMap.put(tableName, row, "URUN_SINIF_KOD", lovMap.getString("URUN_SINIF_KOD"));
				oMap.put(tableName, row, "VADE", lovMap.getDate("VADE"));
				oMap.put(tableName, row, "SCH_FAIZ_ORANI", record.getSchFaizOraniYeni());
				
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9948_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			String tableName = "HESAP_TIPI_LIST";
			int row = 0;
			
			oMap.put(tableName, row, "NAME", "Kredi");
			oMap.put(tableName, row++, "VALUE", "KR");
			
			oMap.put(tableName, row, "NAME", "Vadeli");
			oMap.put(tableName, row++, "VALUE", "VD");
			
			oMap.put(tableName, row, "NAME", "Vadesiz");
			oMap.put(tableName, row++, "VALUE", "VS");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
