package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * @author obss1
 * 
 */
public class SystemMesajKutusuIptal {
	@GraymoundService("BNSPR_MESAJ_KUTUSU_IPTAL_GET_RECORD")
	public static GMMap getRecordMsjIptalKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_MESAJ_KUTUSU_IPTAL_RECORD(?,?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(1, -10); //ref cursor
			stmt.setBigDecimal(2,iMap.getBigDecimal("EKRAN_KOD"));
			stmt.setString(3,iMap.getString("KANAL_KOD"));
			stmt.setBigDecimal(4,iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(5,iMap.getString("HESAP_NO"));
			stmt.setBigDecimal(6,iMap.getBigDecimal("TUTAR"));
			stmt.setString(7,iMap.getString("KULLANICI_KOD"));
			stmt.setBigDecimal(8,iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1); 
    		String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));
			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static String isSetParamValue(GMMap iMap, String key) {

		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0) {
			return "T";
		}
		else {
			return "F";
		}

	}

	@GraymoundService("BNSPR_VALIDATE_MESAJ_INPUT_IPTAL")
	public static GMMap validatMesajInputIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		String iMapValue = "";

		if ("T".equals(isSetParamValue(iMap, "TUTAR"))) {
			 if (iMap.getBigDecimal("TUTAR").compareTo(BigDecimal.ZERO) > 0)
				  iMapValue = "T";
			 else
				iMap.remove("TUTAR");
		}

		for (Object key : iMap.keySet()) {
			iMapValue += isSetParamValue(iMap, key.toString());
		}

		if (!iMapValue.contains("T"))
			throw new GMRuntimeException(10561, "Sorgulama i�in enaz bir kriter girilmelidir!");
		else
			oMap.put("VALIDATE_MESSAGE", "OK");

		return oMap;

	}

}

/*	@GraymoundService("BNSPR_MESAJ_KUTUSU_IPTAL_GET_RECORD")
	public static GMMap getRecordMsjIptalKutusu(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");

			GMMap oMap = new GMMap();
			StringBuffer query = new StringBuffer();
			query.append("select ");
			query.append("k.amir_sube_kod,pkg_genel_pr.sube_adi(k.AMIR_SUBE_KOD) AMIR_SUBE_ADI,k.NUMARA,k.ISLEM_KOD,k.DURUM_ADI,k.DURUM,to_char(k.KAYIT_TARIH,'dd/mm/yyyy') KAYIT_TARIH,k.MUSTERI_NUMARA,k.HESAP_NUMARA,k.TUTAR,k.DOVIZ_KOD, ");
			query.append(" k.FIS_NUMARA,k.MODUL_TUR_KOD,k.URUN_TUR_KOD,k.URUN_SINIF_KOD, ");
			query.append("k.DOGRULANABILIR_MI,k.ONAYLANABILIR_MI,k.IPTAL_ONAYLANABILIR_MI,k.IPTAL_EDILEBILIR_MI,k.GERI_CEVRILEBILIR, ");
			query.append(" k.ACIKLAMA,k.KAYIT_KULLANICI_KODU,to_char(k.KAYIT_SISTEM_TARIHI,'dd/mm/yyyy hh24:mi:ss') KAYIT_TARIH,");
			query.append(" k.DOGRU_KULL_KODU,to_char(k.DOGRULAMA_SISTEM_TARIH,'dd/mm/yyyy hh24:mi:ss') DOGRU_TARIH, ");
			query.append(" k.ONAY_KULL_KODU ,to_char(k.ONAYLAMA_SISTEM_TARIH,'dd/mm/yyyy hh24:mi:ss') ONAY_TARIH, ");
			query.append("k.IPTAL_KULLANICI_KODU,to_char(k.IPTAL_SISTEM_TARIHI,'dd/mm/yyyy hh24:mi:ss') IPTAL_TARIH, ");
			query.append("k.IPTAL_ONAY_KULL_KODU,k.iptal_onay_tarih,Pkg_genel_pr.islem_ekran_adi(k.ISLEM_KOD), ");
			query.append("k.kanal_numara, k.kanal_adi, k.kanal_alt_kod, k.kanal_alt_adi,k.kullanici_aciklama, ");
			query.append("k.fis_izlenebilir_mi ");
			query.append("from v_muh_islem_dog_on_ip k ");
			query.append("where k.durum in  ('P','3') ");
			query.append("order by k.NUMARA desc ");


			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();

			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;

				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));
			}

			oMap.put("ROW_COUNT", oMap.getSize(tableName));

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

}*/

