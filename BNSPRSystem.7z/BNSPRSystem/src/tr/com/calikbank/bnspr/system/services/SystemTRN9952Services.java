package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.GnlBatchProgramTanimTx;
import tr.com.aktifbank.bnspr.dao.GnlBatchProgramTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9952Services {
	
	
	@GraymoundService("BNSPR_TRN9952_SAVE")
	public static Map<?, ?>  Save(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		boolean  lackOfRequiredArea = false;  
		
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "KAYIT_LISTESI";
			List<?> list = (List<?>)iMap.get(tableName);
			
			for(int j=0 ; j<list.size() ; j++){
			    
                if( iMap.getString(tableName, j, "PROGRAM_KOD")==null  ||  iMap.getBigDecimal(tableName, j, "SIRA_NO")==null){
                    lackOfRequiredArea = true;
                    break;
                }
			}
			
			if(!lackOfRequiredArea){
			    
    			for (int i = 0; i < list.size(); i++) {
    			    
    				GnlBatchProgramTanimTx   gnlBatchProgramTanimTx =(GnlBatchProgramTanimTx)session.createCriteria(GnlBatchProgramTanimTx.class).
    				                                                                add(Restrictions.eq("id.programKod", iMap.getString(tableName, i, "PROGRAM_KOD"))).
    				                                                                add(Restrictions.eq("id.grupNo", iMap.getBigDecimal(tableName, i, "GRUP_NO"))).
    				                                                                add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
    				                                                                add(Restrictions.eq("id.siraNo", iMap.getBigDecimal(tableName, i, "SIRA_NO"))).uniqueResult();						
    				
    				if(gnlBatchProgramTanimTx == null){
    					gnlBatchProgramTanimTx = new GnlBatchProgramTanimTx();
    				}
    				
    				GnlBatchProgramTanimTxId idTx = new GnlBatchProgramTanimTxId();
    				
    				idTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
    				idTx.setGrupNo(iMap.getBigDecimal(tableName, i, "GRUP_NO"))  ;   
    				idTx.setProgramKod(iMap.getString(tableName, i, "PROGRAM_KOD")) ; 
                    idTx.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));  
                    
    				gnlBatchProgramTanimTx.setId(idTx);				
    				gnlBatchProgramTanimTx.setGecerli(iMap.getString(tableName, i, "GECERLI"));
    				
    				if(iMap.getString(tableName, i, "GIRIS")==null && iMap.getString(tableName, i, "SIL")==null)
    				    gnlBatchProgramTanimTx.setGDS("D");
    				else if(iMap.getString(tableName, i, "GIRIS")!=null && iMap.getString(tableName, i, "GIRIS").equals("true"))
                        gnlBatchProgramTanimTx.setGDS("G");
    				else if(iMap.getString(tableName, i, "SIL")!=null && iMap.getString(tableName, i, "SIL").equals("true"))
                        gnlBatchProgramTanimTx.setGDS("S");
    				
    				session.saveOrUpdate(gnlBatchProgramTanimTx);
    			}
    			 session.flush();

                 iMap.put("TRX_NAME", "9952");
                 return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			
			else{
			    return new GMMap().put("MESSAGE", "Kay�t i�lemi i�in PROGRAM_KOD ve SIRA_NO alanlar� doldurulmal�").put("ERROR", "true");			    
			}
			    
	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_TRN9952_GET_INFO")
    public static GMMap getInfo(GMMap iMap){
        GMMap oMap = new GMMap();

        try{

            Session session = DAOSession.getSession("BNSPRDal");
            List<GnlBatchProgramTanimTx> gnlBatchProgramTanimTxList = (List<GnlBatchProgramTanimTx>) session.createCriteria(GnlBatchProgramTanimTx.class)
                                                                                                .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

            int i = 0;
            String tableName = "IZLEMETABLOSU";
            for(GnlBatchProgramTanimTx gnlBatchProgramTanimTx : gnlBatchProgramTanimTxList){

                oMap.put(tableName, i, "GRUP_NO", gnlBatchProgramTanimTx.getId().getGrupNo());
                oMap.put(tableName, i, "PROGRAM_KOD", gnlBatchProgramTanimTx.getId().getProgramKod());
                oMap.put(tableName, i, "SIRA_NO", gnlBatchProgramTanimTx.getId().getSiraNo());
                oMap.put(tableName, i, "GECERLI", gnlBatchProgramTanimTx.getGecerli());
                if(gnlBatchProgramTanimTx.getGDS().equals("S"))
                    oMap.put(tableName, i, "SIL", "true");
                i++;
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }
    
}
