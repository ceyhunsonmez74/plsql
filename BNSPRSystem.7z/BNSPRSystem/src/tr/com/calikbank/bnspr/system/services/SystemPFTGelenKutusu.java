package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * @author obss1
 * 
 */
public class SystemPFTGelenKutusu {

	//private static final Logger logger = Logger.getLogger(SystemPFTGelenKutusu.class);
	
	@GraymoundService("BNSPR_PFT_GELEN_KUTUSU_GET_RECORD")
	public static GMMap getRecordMsjGlnKutusu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_MESAJKUTUSU.RC_MESAJKUTUSU_GELENRECORD_PFT(?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor,
			stmt.setBigDecimal(i++,iMap.getBigDecimal("EKRAN_KOD"));
			stmt.setString(i++,iMap.getString("KANAL_KOD"));
			stmt.setString(i++,iMap.getString("KRITER"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "SORGU_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "EFT_TIPI", rSet.getString(j++));
				oMap.put(tableName, row, "GON_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "GON_TCKN", rSet.getString(j++));
				oMap.put(tableName, row, "ALICI_BANKA", rSet.getString(j++));
				oMap.put(tableName, row, "ALICI_SUBE", rSet.getString(j++));
				oMap.put(tableName, row, "ALICI_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "GON_PTT_SUBE", rSet.getString(j++));
				oMap.put(tableName, row, "GON_PTT_SICIL", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TIPI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR", rSet.getString(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "PFT_ISLEM_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "REFERANS", rSet.getString(j++));
			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	/*
	 * (BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA)Servisinde i�lemin
	 * do�rulanmas�, onaylanmas�, iptali ve iptal onaylanmas� yap�lmaktad�r. �ki
	 * parametresi vard�r.Ald��� parametreler i�lem numaras� ve statik bir
	 * texttir. Statik text => 'D' = Do�rulama, 'O' = Onaylama, 'I' = �ptal,
	 * 'IO' = �ptal Onay i�indir.
	 */

	@GraymoundService("BNSPR_PFT_GELEN_KUTUSU_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA")
	public static GMMap islemDogrulaOnayIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap eMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String islemTuru = iMap.getString("ISLEM_TURU");
		String kulEmail= "";
		List<?> list = (List<?>)iMap.get("ISLEM_LIST");
		try {

	        GMMap i1Map = new GMMap();
	        GMMap o1Map = new GMMap();
			i1Map.put("ISLEM_LIST",iMap.get("ISLEM_LIST"));
			i1Map.put("CLAIM", "H");
			o1Map = GMServiceExecuter.call("BNSPR_CLAIM_TRANSACTION", i1Map);
			
			conn = DALUtil.getGMConnection();
			for(int i = 0; i<list.size(); i++)
			{
				if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
				{
                    GMMap tmpMap = new GMMap();
                    tmpMap.put("ISLEM_NO" , iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
                    tmpMap.put("ACIKLAMA" , iMap.getString("ACIKLAMA"));
                    tmpMap.put("ISLEM_TURU" , islemTuru);
                    tmpMap.put("ISLEM_KODU" , iMap.getBigDecimal("ISLEM_LIST", i, "KOD"));
                    
                    oMap = GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", tmpMap);
                    if(islemTuru.equals("DR") || islemTuru.equals("OR") || islemTuru.equals("IG")){
                    	eMap.clear();
                    	eMap.put("KULL_KOD", iMap.getString("ISLEM_LIST",i,"KAYIT_KUL_KOD"));
                    	eMap = GMServiceExecuter.call("BNSPR_GET_KULL_EMAIL", eMap);
                    	kulEmail = eMap.getString("EMAIL");
                    	eMap.clear();
                    	eMap.put("TO_LIST", kulEmail);
                    	eMap.put("SUBJECT", "Geri �evrilen-Reddedilen ��lem G�nderim Talebi");
                    	eMap.put("MESSAGE_BODY", iMap.getString("ISLEM_LIST",i, "NO")+" nolu i�lem g�nderim ekran�ndan iletti�iniz i�lem geri �evrilmi� veya reddedilmi�tir.\n A��klama: "+iMap.getString("ACIKLAMA"));
                    	GMServiceExecuter.call("BNSPR_4001_SEND_MAIL", eMap);
                    }
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			if(iMap.getString("ANA_SUBE")!= null && !iMap.getString("ANA_SUBE").isEmpty())
			{
				GMMap tempMap = new GMMap();
				tempMap.put("BRANCH_ID", iMap.getString("ANA_SUBE"));
				tempMap.put("GUIML_NAME", iMap.getString("GUIML_NAME"));
				GMServiceExecuter.execute("BNSPR_CORE_SET_USER_BRANCH", tempMap);
			}
		}
		return oMap;
	}

	public static GMMap getMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tx.msj_islem_durum(?)}");
			stmt.registerOutParameter(1, Types.CHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));

			stmt.execute();

			oMap.put("MESSAGE", stmt.getString(1));

		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
		
	@GraymoundService("BNSPR_PFT_GELEN_KUTUSU_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValuesGelen(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KANAL_KOD", true, "SELECT KOD ,ACIKLAMA FROM V_ML_GNL_KANAL_GRUP_KOD_PR g WHere exists (select 1 from gnl_param_text t where t.kod='TOPLU_EFT_ONAY_KANAL' and t.key1=g.KOD) ORDER BY TO_NUMBER(KOD)"); 
			
			iMap.put("KOD", "PFT_TOPLU_ONAY_KRITER"); 
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("KRITER", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        	return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PFT_GELEN_KUTUSU_TUMUNU_SEC")
	public static GMMap tumunuSec(GMMap iMap){
		
		try{
			String tableName = "LIST";
			List<?> list = (List<?>)iMap.get(tableName);
			for(int i=0;i<list.size();i++)
			{
				iMap.put(tableName, i,"SEC",iMap.getBoolean("TUMUNU_SEC"));
			}
        	return iMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}

