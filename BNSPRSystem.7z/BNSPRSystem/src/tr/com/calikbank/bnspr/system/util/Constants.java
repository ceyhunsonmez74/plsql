package tr.com.calikbank.bnspr.system.util;

public class Constants {

	public static final String AFTER_ACTION_STATE			=	"AFTER_ACTION_STATE";
	public static final String AFTER_ACTION_NAME			=	"AFTER_ACTION_NAME";
	public static final String DEFAULT_BNSPR_JOB_GROUB_NAME = 	"QUARTZ DATABASE BATCH JOB";
	
}
