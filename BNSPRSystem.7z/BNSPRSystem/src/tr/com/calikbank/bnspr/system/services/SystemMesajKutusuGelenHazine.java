package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlIslemServisPr;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class SystemMesajKutusuGelenHazine {

	private static final Logger logger = Logger.getLogger(SystemMesajKutusuGelenHazine.class);
	
	@GraymoundService("BNSPR_MESAJ_KUTUSU_GELEN_GET_RECORD_HAZINE")
	public static GMMap getRecordMsjGlnKutusuHazine(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_HZNMESAJKUTUSU.RC_HZNMESAJ_KUTUSU_GELEN_REC(?,?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor,
			stmt.setBigDecimal(i++,iMap.getBigDecimal("EKRAN_KOD"));
			stmt.setString(i++,iMap.getString("KANAL_KOD"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++,iMap.getString("HESAP_NO"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++,iMap.getString("KULLANICI_KOD"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int j = 1;
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "AMIR_SUBE_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MUSTERI_UNVANI", rSet.getString(j++));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_TUR", rSet.getString(j++));
				oMap.put(tableName, row, "URUN_SINIFI", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAYLANABILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ACIKLM", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KAYIT_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "DOGRULAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ONAYLAMA_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_TALEP_TRH", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_KUL_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "IPTAL_ONAY_TRH", rSet.getDate(j++));
				oMap.put(tableName, row, "EKRAN_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ALT_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_IZLENEBILIR_MI", rSet.getString(j++));
				oMap.put(tableName, row, "VALOR_TARIH", rSet.getString(j++));
				oMap.put(tableName, row, "REFERANS", rSet.getString(j++));
				oMap.put(tableName, row, "KARSI_BANKA_ADI", rSet.getString(j++));

			}
			oMap.put("ROW_COUNT", oMap.getSize(tableName));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}

