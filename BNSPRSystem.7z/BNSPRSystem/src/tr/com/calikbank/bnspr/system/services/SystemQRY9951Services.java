package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;


public class SystemQRY9951Services {
	
    @GraymoundService("BNSPR_QRY9951_GET_YETKI_LIST")
    public static Map<?, ?> getYetkiList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC9951.GET_YETKI_LISTE(?,?)}");
            int i = 1;

            stmt.registerOutParameter(i++, -10);
            stmt.setString(i++ , iMap.getString("KULLANICI_KOD"));
            stmt.setString(i++ , iMap.getString("SUBE_KOD"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName1 = "TBL_GNL_KULL_GM_SUBE_PR";
            for (int row = 0; rSet.next(); row++) {
                oMap.put(tableName1, row, "KULLANICI_KODU", rSet.getString("KULLANICI_KODU"));
                oMap.put(tableName1, row, "SUBE_KODU", rSet.getString("SUBE_KODU"));
                oMap.put(tableName1, row, "BASLANGIC_TARIHI", rSet.getDate("BASLANGIC_TARIHI"));
                oMap.put(tableName1, row, "BITIS_TARIHI", rSet.getDate("BITIS_TARIHI"));
            }
                
            return oMap;
        }
            catch (Exception e) {
                
                throw ExceptionHandler.convertException(e);
            
            } finally {
                
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            
            }
        }
}
