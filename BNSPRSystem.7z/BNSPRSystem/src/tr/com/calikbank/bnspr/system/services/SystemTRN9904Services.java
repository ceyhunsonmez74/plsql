package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.StopajOran;
import tr.com.aktifbank.bnspr.dao.StopajOranTx;
import tr.com.aktifbank.bnspr.dao.StopajOranTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SystemTRN9904Services {
	
	
	@GraymoundService("BNSPR_TRN9904_GET_COMBO")
	public static GMMap getCombo(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("ADD_EMPTY_KEY", "H");
		iMap.put("KOD", "STOPAJ_ISLEM_TURU");
		oMap.put("ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9904_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			String oldTableName = "OLD_LIST";
			int row = 0, oldRow = 0;
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				/*
				 * tx-e gore mevcut-liste cekilir
				 */
				List<?> list = session.createCriteria(StopajOranTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					StopajOranTx sot = (StopajOranTx) iterator.next();
					
					oMap.put(tableName, row, "HESAP_NO", sot.getId().getHesapNo());
					oMap.put(tableName, row, "ISLEM_KODU", sot.getId().getIslemKodu());
					oMap.put(tableName, row, "ISLEM_TURU", sot.getIslemTuru());
					oMap.put(tableName, row, "STOPAJ_ORANI", sot.getStopajOrani());
					
					row++;
				}
				
				/*
				 * Eski tx-no bulunur
				 */
				BigDecimal oldTrxNo = getOncekiTxNo(trxNo);
				
				/*
				 * tx-e gore eski liste cekilir
				 */
				List<?> oldList = session.createCriteria(StopajOranTx.class).add(Restrictions.eq("id.txNo", oldTrxNo)).list();
				
				for (Iterator<?> iterator = oldList.iterator(); iterator.hasNext();) {
					StopajOranTx sot = (StopajOranTx) iterator.next();
					
					oMap.put(oldTableName, oldRow, "HESAP_NO", sot.getId().getHesapNo());
					oMap.put(oldTableName, oldRow, "ISLEM_KODU", sot.getId().getIslemKodu());
					oMap.put(oldTableName, oldRow, "ISLEM_TURU", sot.getIslemTuru());
					oMap.put(oldTableName, oldRow, "STOPAJ_ORANI", sot.getStopajOrani());
					
					oldRow++;
				}
				
				/*
				 * eski ve yeni listeler karsilatirilir, renklendirme icin
				 */
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("HESAP_NO");
				keyColumns.add("ISLEM_KODU");
				keyColumns.add("ISLEM_TURU");
				keyColumns.add("STOPAJ_ORANI");
				
				oMap.put("COLOR_LIST", BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(oldTableName), (ArrayList<?>) oMap.get(tableName), keyColumns).get("COLOR_DATA"));
				
			} else {//yoksa ana tablo uzerinden gelsin
				
				List<?> list = session.createCriteria(StopajOran.class).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					StopajOran so = (StopajOran) iterator.next();
					
					oMap.put(tableName, row, "HESAP_NO", so.getId().getHesapNo());
					oMap.put(tableName, row, "ISLEM_KODU", so.getId().getIslemKodu());
					oMap.put(tableName, row, "ISLEM_TURU", so.getIslemTuru());
					oMap.put(tableName, row, "STOPAJ_ORANI", so.getStopajOrani());
					
					row++;
				}
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9904_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			
			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete StopajOranTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			
			/*
			 * tablo insert edilir
			 */
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				StopajOranTx sot = new StopajOranTx();
				
				//
				StopajOranTxId id = new StopajOranTxId();
				id.setTxNo(trxNo);
				id.setHesapNo(iMap.getString(tableName, row, "HESAP_NO"));
				id.setIslemKodu(iMap.getString(tableName, row, "ISLEM_KODU"));
				//
				
				sot.setId(id);
				sot.setIslemTuru(iMap.getString(tableName, row, "ISLEM_TURU"));
				sot.setStopajOrani(iMap.getBigDecimal(tableName, row, "STOPAJ_ORANI"));
				
				session.saveOrUpdate(sot);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9904");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static BigDecimal getOncekiTxNo(BigDecimal trxNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_9904(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, trxNo);
			stmt.execute();
			
			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}