package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.nuevo.kibele.NameCode;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.CariNakitCekilenTx;
import tr.com.calikbank.bnspr.dao.GnlLimitPr;
import tr.com.calikbank.bnspr.dao.GnlSubeKodPr;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.aktifbank.NuevoKibele.NuevoKibeleClient;
import tr.com.aktifbank.bnspr.dao.GnlBolumKodlariTx;
import tr.com.aktifbank.bnspr.dao.GnlBolumKodlariTxId;
import tr.com.aktifbank.bnspr.dao.GnlBolumKodPr;
import tr.com.aktifbank.bnspr.dao.MuhKasaKupurBozmaDetayTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9970Services {
	@GraymoundService("BNSPR_TRN9970_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(GnlBolumKodlariTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for (Iterator<?> iterator = list.iterator(); iterator
					.hasNext();) {
				GnlBolumKodlariTx gnlBolumKodlariTx = (GnlBolumKodlariTx)iterator.next();
				session.delete(gnlBolumKodlariTx);
			}
			session.flush();
			
			String tableName = "BOLUM_KODLARI_LIST";
			
			List<?> list2 = (List<?>)iMap.get("BOLUM_KODLARI_LIST");
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				
                for (int j = row+1; j < list2.size(); j++) {
                	
                int l = 0;
                
                    l = iMap.getString(tableName, j, "KOD").compareTo(iMap.getString(tableName, row, "KOD") );
                    
                    if ( l==0){         
                          iMap.put("HATA_NO", new BigDecimal(2125));
                          iMap.put("P1", row+1);
                          iMap.put("P2", j+1);
                          GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);      
                    }

               }   

                GnlBolumKodlariTx gnlBolumKodlariTx = new GnlBolumKodlariTx();
				GnlBolumKodlariTxId gnlBolumKodlariTxId = new GnlBolumKodlariTxId();
				gnlBolumKodlariTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlBolumKodlariTxId.setKod(iMap.getString(tableName, row, "KOD"));
				gnlBolumKodlariTx.setId(gnlBolumKodlariTxId);
				gnlBolumKodlariTx.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				gnlBolumKodlariTx.setDurumKodu(iMap.getString(tableName, row, "DURUM_KODU"));
				gnlBolumKodlariTx.setSapKodu(iMap.getString(tableName, row, "SAP_KODU"));
				session.saveOrUpdate(gnlBolumKodlariTx);
				
				
			}
			session.flush();
			
			
			iMap.put("TRX_NAME", "9970");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9970_GET_SEGMENT_CODE_LIST")
	public static Map<?, ?> getSegmentCodeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues = new Object[6];
		int i = 0;
			try {
				String func = "{? = call PKG_TRN9970.getSegmentList(?,?,?)}";
			
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getString("KOD");

				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getString("DURUM_KODU");
				
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getString("SAP_KODU");

				String tableName = "BOLUM_KODLARI_LIST";
				oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

				return oMap;
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}

	}
	
	
	
	@GraymoundService("BNSPR_TRN9970_GET_BOLUM_KODLARI_LIST")
	public static Map<?, ?> getBolumKodlariList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN9970.GET_BOLUM_LIST(?)}");
			int i = 1;
	
			stmt.registerOutParameter(i++, -10); //BOLUM KODLARI L�STES�
			stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
			String tableName1 = "BOLUM_KODLARI_LIST";
			for (int row = 0; rSet.next(); row++) {
				oMap.put(tableName1, row, "KOD", rSet.getString("KOD"));
				oMap.put(tableName1, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName1, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName1, row, "SAP_KODU", rSet.getString("SAP_KODU"));
			}
				
			return oMap;
		}   
			
		
		
		catch (Exception e) {
			
			throw ExceptionHandler.convertException(e);
		
		} finally {
			
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		
		}
	}
	
	

	@GraymoundService("BNSPR_TRN9970_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
			try{
				GMMap oMap = new GMMap();
				iMap.put("KOD", "BOLUM_DURUM_KODU");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("DURUM_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				oMap.put("BOLUM_DURUM_KODU",oMap.get("DURUM_KODU"));
				
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

	@GraymoundService("BNSPR_TRN9970_GET_INFO")
	public static GMMap getTRN9970Info(GMMap iMap) {
		try{	                                                                
	        Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
	        GMMap oMap=new GMMap();
	                                                                  
	    	List<?> list = (List<?>) session.createCriteria(
	    			GnlBolumKodlariTx.class).add(Restrictions.eq("id.txNo", iMap
							.getBigDecimal("TRX_NO"))).list();

			String tableName = "BOLUM_KODLARI_LIST";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlBolumKodlariTx gnlBolumKodlariTx = (GnlBolumKodlariTx) iterator
						.next();

				oMap.put(tableName, row, "KOD", gnlBolumKodlariTx.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", gnlBolumKodlariTx.getAciklama());
				oMap.put(tableName, row, "DURUM_KODU", gnlBolumKodlariTx.getDurumKodu());
				oMap.put(tableName, row, "SAP_KODU", gnlBolumKodlariTx.getSapKodu());
			}
			
	        return oMap;
	        
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}	      

	@GraymoundService("BNSPR_TRN9970_KAYIT_KONTROL")
	public static Map<?, ?> getKayitSilKontrol (GMMap iMap){
	Connection conn 		= null;
	CallableStatement stmt 	= null;
	ResultSet rSet 			= null;
	try {
		GMMap oMap = new GMMap();
		conn = DALUtil.getGMConnection();
		
		stmt = conn.prepareCall("{?=call PKG_TRN9970.KAYIT_KONTROL(?) }");
		stmt.registerOutParameter(1,Types.VARCHAR);
		stmt.setBigDecimal(2, iMap.getBigDecimal("KOD"));
		
		stmt.execute();
		
		oMap.put("KAYIT_VAR_MI", stmt.getBigDecimal(1));
		
		return oMap;  
		
	}
		catch (NumberFormatException e)
		{
			iMap.put("HATA_NO", new BigDecimal(2187));
			return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		} 
	
	 catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} finally {
		GMServerDatasource.close(rSet);
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	}
}
	@GraymoundService("BNSPR_TRN9970_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		try {
			List<?> bolumKodlari = session.createCriteria(GnlBolumKodlariTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			NameCode[] kodlar = new NameCode[bolumKodlari.size()];
			int i=0;
			for(Object name : bolumKodlari){
				GnlBolumKodlariTx blmKodlari = (GnlBolumKodlariTx) name;
				if (blmKodlari.getDurumKodu() !=null && blmKodlari.getDurumKodu().equals("A")){
					NameCode kod= new NameCode();
					kod.setCode(blmKodlari.getId().getKod());
					kod.setName(blmKodlari.getAciklama());
					kod.setSAPCode(blmKodlari.getSapKodu());
					kodlar[i]= kod;
					i=i+1;
				}
			}
			//NuevoKibeleClient.setBolumKod(kodlar);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
		
	}
	@GraymoundService("BNSPR_TRN9970_SCHEDULER")
	public static GMMap scheduler(GMMap iMap){
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		try {
			List<?> bolumKodlari = session.createCriteria(GnlBolumKodPr.class).add(Restrictions.eq("durumKodu", "A")).list();
			NameCode[] kodlar = new NameCode[bolumKodlari.size()];
			int i=0;
			for(Object name : bolumKodlari){
				GnlBolumKodPr blmKodlari = (GnlBolumKodPr) name;
				
				NameCode kod= new NameCode();
				kod.setCode(blmKodlari.getKod());
				kod.setName(blmKodlari.getAciklama());
				kod.setSAPCode(blmKodlari.getSapKodu());
				kodlar[i]= kod;
				i=i+1;
				
			}
			NuevoKibeleClient.setBolumKod(kodlar);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return oMap;
	}


}


