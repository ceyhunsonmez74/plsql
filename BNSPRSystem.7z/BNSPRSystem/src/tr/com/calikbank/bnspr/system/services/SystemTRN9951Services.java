package tr.com.calikbank.bnspr.system.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;


import tr.com.aktifbank.bnspr.dao.GnlKullGmSubePrTx;
import tr.com.aktifbank.bnspr.dao.GnlKullGmSubePrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9951Services {
     
    
    @GraymoundService("BNSPR_TRN9951_SAVE")
    public static Map<?, ?> saveAccounts(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String tableName = "TBL_GNL_KULL_GM_SUBE_PR";
      
            try{
                
                conn = DALUtil.getGMConnection();
                Session session = DAOSession.getSession("BNSPRDal");
                
                ArrayList<?> list = (ArrayList<?>) session.createCriteria(GnlKullGmSubePrTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();
                for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                    GnlKullGmSubePrTx gnlKullGmSubePrTx = (GnlKullGmSubePrTx) iterator.next();
                    session.delete(gnlKullGmSubePrTx);
                }
                session.flush();
                
                int rowCount = iMap.getSize(tableName);
                for (int i = 0; i < rowCount; i++){
                   
                    GnlKullGmSubePrTx gnlKullGmSubePrTx = new GnlKullGmSubePrTx();
                    GnlKullGmSubePrTxId gnlKullGmSubePrTxId = new GnlKullGmSubePrTxId();
                    
                    
                    gnlKullGmSubePrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    gnlKullGmSubePrTxId.setKullaniciKodu(iMap.getString(tableName, i, "KULLANICI_KODU"));
                    gnlKullGmSubePrTxId.setSubeKodu(iMap.getString(tableName, i, "SUBE_KODU"));
                    gnlKullGmSubePrTx.setId(gnlKullGmSubePrTxId);
                    gnlKullGmSubePrTx.setBaslangicTarihi(iMap.getDate(tableName, i, "BASLANGIC_TARIHI"));
                    gnlKullGmSubePrTx.setBitisTarihi(iMap.getDate(tableName, i, "BITIS_TARIHI"));
                    
                    
                    if(("S").equals(iMap.getString(tableName,i,"G_D_S")))
                        gnlKullGmSubePrTx.setGDS("S");
                    else if (("G").equals(iMap.getString(tableName, i, "G_D_S")))
                        gnlKullGmSubePrTx.setGDS("G");
                    else gnlKullGmSubePrTx.setGDS("");
                    
                  
                    session.saveOrUpdate(gnlKullGmSubePrTx);
                }
                session.flush();
                
               iMap.put("TRX_NAME","9951");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
    }
            @GraymoundService("BNSPR_TRN9951_IS_RECORDS_UNIQUE")
            public static GMMap isRecordsUnique(GMMap iMap) {
                
                GMMap oMap = new GMMap();
                
                String tableName = "TBL_GNL_KULL_GM_SUBE_PR";
                int rowCount = iMap.getSize(tableName);
                
                for (int i = 0; i < rowCount; i++){
                    for (int j = 0; j < rowCount; j++){
                     
                        if (iMap.getString(tableName , i , "KULLANICI_KODU") == (null) || iMap.getString(tableName , i , "KULLANICI_KODU").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "KULLANICI_KODU");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
                        if (iMap.getString(tableName , i , "SUBE_KODU") == (null) || iMap.getString(tableName , i , "SUBE_KODU").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "SUBE_KODU");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
                      
                        if (i != j){
                            if (iMap.getString(tableName , i , "KULLANICI_KODU").equals(iMap.getString(tableName , j , "KULLANICI_KODU"))&&iMap.getString(tableName , i , "SUBE_KODU").equals(iMap.getString(tableName , j , "SUBE_KODU"))){
                                iMap.put("HATA_NO" , new BigDecimal(932));
                                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                            }
                        }
                    }
                }
                    
                return oMap;
            }
    

@GraymoundService("BNSPR_TRN9951_GET_YETKI_LIST")
public static Map<?, ?> getYetkiList(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{? = call PKG_TRN9951.GET_YETKI_LISTE(?)}");
        int i = 1;
        
        stmt.registerOutParameter(i++, -10);
        stmt.setString(i , iMap.getString("KULLANICI_KOD"));
        stmt.execute();
        rSet = (ResultSet) stmt.getObject(1);
        String tableName1 = "TBL_GNL_KULL_GM_SUBE_PR";
        for (int row = 0; rSet.next(); row++) {
            oMap.put(tableName1, row, "KULLANICI_KODU", rSet.getString("KULLANICI_KODU"));
            oMap.put(tableName1, row, "SUBE_KODU", rSet.getString("SUBE_KODU"));
            oMap.put(tableName1, row, "BASLANGIC_TARIHI", rSet.getDate("BASLANGIC_TARIHI"));
            oMap.put(tableName1, row, "BITIS_TARIHI", rSet.getDate("BITIS_TARIHI"));
            oMap.put(tableName1, row, "G_D_S", rSet.getString("G_D_S"));
            oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
        }
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }
@GraymoundService("BNSPR_TRN9951_GET_INFO")
public static GMMap getTransactionNo(GMMap iMap) {
    
    Connection conn = null;
    ResultSet rSet = null;
    
    try{
        
    GMMap oMap = new GMMap();
    conn = DALUtil.getGMConnection();
    Session session = DAOSession.getSession("BNSPRDal");
    String tableName    = "TBL_GNL_KULL_GM_SUBE_PR";
    String colorTableName = "TBL_COLOR";
    

    List<?> list = (List<?>) session.createCriteria(GnlKullGmSubePrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
        .list();
    
     for (int row = 0; row < list.size(); row++){
        GnlKullGmSubePrTx gnlKullGmSubePrTx = (GnlKullGmSubePrTx) list.get(row);
       
        oMap.put("TRX_NO", gnlKullGmSubePrTx.getId().getTxNo());
        oMap.put("KULLANICI_KODU",gnlKullGmSubePrTx.getId().getKullaniciKodu());
        oMap.put(tableName, row, "KULLANICI_KODU", gnlKullGmSubePrTx.getId().getKullaniciKodu());
        oMap.put(tableName, row, "SUBE_KODU", gnlKullGmSubePrTx.getId().getSubeKodu());
        oMap.put(tableName, row, "BASLANGIC_TARIHI", gnlKullGmSubePrTx.getBaslangicTarihi());
        oMap.put(tableName, row, "BITIS_TARIHI", gnlKullGmSubePrTx.getBitisTarihi());
        oMap.put(tableName, row, "SIL", ("S").equals(gnlKullGmSubePrTx.getGDS()) ? true : false);
    
      if ("G".equals(gnlKullGmSubePrTx.getGDS()) ) {
         
          oMap.put(colorTableName, row, "KULLANICI_KODU",getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "SUBE_KODU", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BASLANGIC_TARIHI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BITIS_TARIHI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.GREEN));
          
      }
      else if ("S".equals(gnlKullGmSubePrTx.getGDS())) {
          
          
          oMap.put(colorTableName, row, "KULLANICI_KODU",getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "SUBE_KODU", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BASLANGIC_TARIHI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BITIS_TARIHI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
      }
      else
      {
          
          oMap.put(colorTableName, row, "KULLANICI_KODU",getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "SUBE_KODU", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BASLANGIC_TARIHI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BITIS_TARIHI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
      }
    
    }
        
    return oMap;
        
    }catch (Exception e){
        throw ExceptionHandler.convertException(e);
    }finally{
        
        GMServerDatasource.close(conn);
        GMServerDatasource.close(rSet);
    }
    
}
 private static GMMap getTableCellColorData(Color backgroundColor){
        GMMap oMap = new GMMap();
        oMap.put("setBackground", backgroundColor);
        return oMap;
    }
}

    
	

