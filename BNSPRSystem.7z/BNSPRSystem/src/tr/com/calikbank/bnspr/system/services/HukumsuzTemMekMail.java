package tr.com.calikbank.bnspr.system.services;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import tr.com.calikbank.bnspr.util.DALUtil;

public class HukumsuzTemMekMail {
	
	@GraymoundService("GUNSONU_HUKUMSUZ_TEM_MEK_MAIL")
	public static GMMap GunSonuHukumsuzTemMekMail(GMMap iMap) {
		Connection conn = null;
		
		CallableStatement stmt1 = null;
		ResultSet rSetOuter = null;
		String FileName = "";
		try {
			conn = DALUtil.getGMConnection();
			FileName ="GUNSONU_TEM_MEK_MAIL_" +  GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH").toString()+ ".xls";
			
	
		    stmt1 = conn.prepareCall("{ ?=call PKG_RC2611.RC_HUKUMSUZ_TEMMEK_LIST }"); 
			
			int i = 1;
			stmt1.registerOutParameter(i++, -10); //ref cursor
		
			stmt1.execute();
			
			rSetOuter = (ResultSet)stmt1.getObject(1);
			
			GMMap servisMap = new GMMap();
			
			
			servisMap.put("MAIL_FROM", "akustik@aktifbank.com.tr");
			servisMap.put("MAIL_TO", DALUtil.getResult("select pkg_parametre.Deger_Al_K('HUKUMSUZ_TEMMEK') from dual")); 		
			
			servisMap.put("MAIL_SUBJECT", "H�k�ms�z Teminat Mektuplar�");
			
			//mail_body alan� bo� ge�ilemez.
			servisMap.put("MAIL_BODY", GMServiceExecuter.execute("BNSPR_CORE_GET_SISTEM_ADI", iMap).get("SISTEM_ADI")+"ortam�ndaki h�k�ms�z teminat mektuplar� ektedir.");

			servisMap.put("IS_BODY_HTML", "H");
		
			servisMap.put("FILE_NAME", FileName);
			
		
			File tempExcelFile = FileUtil.createTempDirFile(FileName);
			WritableWorkbook workbook = Workbook.createWorkbook(tempExcelFile); 
			WritableSheet sheet = workbook.createSheet("HUKUMSUZ TEM MEK", 0);
			int row = 0;
			
			//create excel column headers
			int col = 0;
			sheet.addCell(new Label(col++, row, "REFERANS"));
			sheet.addCell(new Label(col++, row, "VADE TARIHI"));
			sheet.addCell(new Label(col++, row, "LEHTAR MUSTERI NO"));
			sheet.addCell(new Label(col++, row, "DOVIZ KODU"));
			sheet.addCell(new Label(col++, row, "TUTAR"));
			row++;
			
			while(rSetOuter.next()){
				col = 0;
				sheet.addCell(new Label(col++, row, rSetOuter.getString("REFERANS")));
				sheet.addCell(new Label(col++, row, rSetOuter.getString("VADE_TARIHI")));
				sheet.addCell(new Label(col++, row, rSetOuter.getString("LEHTAR_MUSTERI_NO")));
				sheet.addCell(new Label(col++, row, rSetOuter.getString("DOVIZ_KODU")));
				sheet.addCell(new Label(col++, row, rSetOuter.getString("TUTAR")));
				row++;
			}
			
			
			workbook.write();
			workbook.close();
			
			int size = (int)tempExcelFile.length(); 
			byte[] fileContent = new byte[size];
			DataInputStream dis = new DataInputStream(new FileInputStream(
					tempExcelFile));
			int read = 0;
			int numRead = 0;
			while (read < fileContent.length
					&& (numRead = dis.read(fileContent, read,
							fileContent.length - read)) >= 0) {
				read = read + numRead;
			}
			System.out.println("File size: " + read);
			if (read < fileContent.length) {
				System.out.println("Could not completely read: " + tempExcelFile.getName());
			}
			servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", FileName);
			servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", fileContent);
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			
		
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSetOuter);
		}
	}
}
