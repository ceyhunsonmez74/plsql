package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemQRY9941Services {
	
	@GraymoundService("BNSPR_QRY9941_GET_VADELI_SCF_ORAN_BILGI")
	public static Map<?, ?> getScfOranBilgi(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			try{
				conn = DALUtil.getGMConnection();
				
				stmt = conn.prepareCall("{? = call pkg_RC9941.RC_QRY9941_Get_Data(?,?,?,?)}");	
				java.util.Date islem_tarihi = (java.util.Date) iMap.get("TARIH");
				stmt.registerOutParameter(1, -10);
				stmt.setDate(2, new java.sql.Date(islem_tarihi.getTime()));
				stmt.setString(3, iMap.getString("TUR"));
				stmt.setString(4, iMap.getString("RATING_KODU"));
				stmt.setString(5, iMap.getString("FAIZ_TUR"));
				
				stmt.execute();
				String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
				rSet = (ResultSet)stmt.getObject(1);
				oMap = DALUtil.rSetResults(rSet, tableName);

			return oMap;
				
			}catch (Exception e) {
				throw new GMRuntimeException(0,e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				GMServerDatasource.close(rSet);
			}

		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
}
