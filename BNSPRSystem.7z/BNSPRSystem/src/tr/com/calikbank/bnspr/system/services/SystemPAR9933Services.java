package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SystemPAR9933Services {

	@GraymoundService("BNSPR_PAR9933_FILL_GNL_PARAM_TEXT")
	public static GMMap par9933FillGnlParamText(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			String orderStmt = iMap.getString("ORDERBY_STMT", " ORDER BY SIRA_NO,KEY1,KEY2,KEY3");

			StringBuffer query = new StringBuffer();
			query.append("SELECT");
			query.append("	KEY1,KEY2,KEY3,TEXT,SAYI,TARIH,SIRA_NO,ID ");
			query.append("FROM");
			query.append("	V_ML_GNL_PARAM_TEXT ");
			query.append(" WHERE KOD = ? ");
			query.append(orderStmt);

			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, iMap.getString("KOD"));
			rSet = stmt.executeQuery();
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				int i = 1;
				oMap.put(tableName, row, "KRITER1", rSet.getString(i++));
				oMap.put(tableName, row, "KRITER2", rSet.getString(i++));
				oMap.put(tableName, row, "KRITER3", rSet.getString(i++));
				oMap.put(tableName, row, "S_DEGER", rSet.getString(i++));
				oMap.put(tableName, row, "N_DEGER", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "D_DEGER", rSet.getDate(i++));
				oMap.put(tableName, row, "SIRA", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "ID", rSet.getBigDecimal(i++));
			}

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR9933_IS_KOD_CONTROL")
	public static GMMap par9933IsKodControl(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select count(*) from gnl_param_text_tanim where kod= ? ");
			stmt.setString(1, iMap.getString("KOD"));
			rSet = stmt.executeQuery();
			BigDecimal count = new BigDecimal(0);
			if (rSet.next())
				count = rSet.getBigDecimal(1);

			if (count.compareTo(new BigDecimal(0)) != 0) {
				iMap.put("HATA_NO", new BigDecimal(716));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR9933_SAVE")
	public static Map<?, ?> par9933Save(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		PreparedStatement stmt2 = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			if (!saveControlField(iMap.getString("KOD"))) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kod");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("N_OR_E").equals("E")) {

				stmt = conn.prepareStatement("DELETE GNL_PARAM_TEXT_TANIM WHERE KOD = ?");
				stmt.setString(1, iMap.getString("KOD"));
				stmt.execute();
				if(iMap.getString("DEL_LIST")!= null){
					String delList[] = iMap.getString("DEL_LIST").split("-");
					for(int count = 0; count < delList.length; count++)
					{
						stmt = conn.prepareStatement("DELETE V_ML_GNL_PARAM_TEXT WHERE ID = ?");
						stmt.setString(1, delList[count]);
						stmt.execute();
					}
				}

			}
			int i = 1;

			stmt = conn.prepareStatement("INSERT INTO GNL_PARAM_TEXT_TANIM (KOD,ACIKLAMA,KEY1_ACIKLAMA,KEY2_ACIKLAMA,KEY3_ACIKLAMA,DEGER_TIPI) VALUES (?,?,?,?,?,?)");

			stmt.setString(i++, iMap.getString("KOD").toUpperCase());

			if (!saveControlField(iMap.getString("ACIKLAMA"))) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "A��klama");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			stmt.setString(i++, iMap.getString("ACIKLAMA"));
			stmt.setString(i++, iMap.getString("KRITER1_KUL_AMAC"));
			stmt.setString(i++, iMap.getString("KRITER2_KUL_AMAC"));
			stmt.setString(i++, iMap.getString("KRITER3_KUL_AMAC"));
			stmt.setString(i++, iMap.getString("DEGER_TIP"));

			stmt.execute();
			
			ArrayList<?> gnlParamText = (ArrayList<?>) iMap.get("V_ML_GNL_PARAM_TEXT");
			String tableName = "V_ML_GNL_PARAM_TEXT";
			
			stmt = conn.prepareStatement("INSERT INTO V_ML_GNL_PARAM_TEXT (ID,KOD,KEY1,KEY2,KEY3,TEXT,SAYI,TARIH,SIRA_NO) VALUES (?,?,?,?,?,?,?,?,?)");
			stmt2 = conn.prepareStatement("UPDATE V_ML_GNL_PARAM_TEXT SET KOD=?,KEY1=?,KEY2=?,KEY3=?,TEXT=?,SAYI=?,TARIH=?,SIRA_NO=? where ID=?");

			GMMap xMap = new GMMap();
			xMap.put("TABLE_NAME", "GNL_PARAM_TEXT");

			for (int j = 0; j < gnlParamText.size(); j++) {
				i = 1;
				if(iMap.getString(tableName, j, "ID") != null && !iMap.getString(tableName, j, "ID").isEmpty())
				{
					stmt2.setString(i++, iMap.getString("KOD").toUpperCase());
					stmt2.setString(i++, iMap.getString(tableName, j, "KRITER1"));
					stmt2.setString(i++, iMap.getString(tableName, j, "KRITER2"));
					stmt2.setString(i++, iMap.getString(tableName, j, "KRITER3"));
	
					if (iMap.getString("DEGER_TIP").equals("V")) {
						stmt2.setString(i++, iMap.getString(tableName, j, "S_DEGER"));
						stmt2.setBigDecimal(i++, null);
						stmt2.setDate(i++, null);
					} else if (iMap.getString("DEGER_TIP").equals("N")) {
						stmt2.setString(i++, null);
						stmt2.setBigDecimal(i++, iMap.getBigDecimal(tableName, j, "N_DEGER"));
						stmt2.setDate(i++, null);
					} else if (iMap.getString("DEGER_TIP").equals("D")) {
						stmt2.setString(i++, null);
						stmt2.setBigDecimal(i++, null);
						stmt2.setDate(i++, new Date(iMap.getDate(tableName, j, "D_DEGER").getTime()));
					}
					stmt2.setBigDecimal(i++, iMap.getBigDecimal(tableName, j, "SIRA"));
					stmt2.setBigDecimal(i++, iMap.getBigDecimal(tableName, j, "ID"));
					
					stmt2.execute();
				}
				else
				{
					stmt.setBigDecimal(i++, new BigDecimal(GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID").toString()));
					stmt.setString(i++, iMap.getString("KOD").toUpperCase());
					stmt.setString(i++, iMap.getString(tableName, j, "KRITER1"));
					stmt.setString(i++, iMap.getString(tableName, j, "KRITER2"));
					stmt.setString(i++, iMap.getString(tableName, j, "KRITER3"));
	
					if (iMap.getString("DEGER_TIP").equals("V")) {
						stmt.setString(i++, iMap.getString(tableName, j, "S_DEGER"));
						stmt.setBigDecimal(i++, null);
						stmt.setDate(i++, null);
					} else if (iMap.getString("DEGER_TIP").equals("N")) {
						stmt.setString(i++, null);
						stmt.setBigDecimal(i++, iMap.getBigDecimal(tableName, j, "N_DEGER"));
						stmt.setDate(i++, null);
					} else if (iMap.getString("DEGER_TIP").equals("D")) {
						stmt.setString(i++, null);
						stmt.setBigDecimal(i++, null);
						stmt.setDate(i++, new Date(iMap.getDate(tableName, j, "D_DEGER").getTime()));
					}
					stmt.setBigDecimal(i++, iMap.getBigDecimal(tableName, j, "SIRA"));
	
					stmt.execute();
				}
			}
			iMap.put("MESSAGE_NO", new BigDecimal(711));
			oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}

	public static Boolean saveControlField(Object obj) {
		if (obj != null) {
			if (obj instanceof String)
				if (!obj.toString().equals(""))
					return true;
		}
		return false;
	}

}