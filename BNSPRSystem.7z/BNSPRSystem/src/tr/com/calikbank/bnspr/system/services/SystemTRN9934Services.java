package tr.com.calikbank.bnspr.system.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.sql.Types;
import java.math.BigDecimal;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlVadeliScfOranlari;
import tr.com.aktifbank.bnspr.dao.GnlVadeliScfOraniTx;
import tr.com.aktifbank.bnspr.dao.GnlVadeliScfOraniTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.message.GMMessageFactory;
 
public class SystemTRN9934Services {
	@GraymoundService("BNSPR_TRN9934_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> listScf = (List<?>) session.createQuery(
					"from GnlVadeliScfOraniTx where id.txNo =:TRX_NO ")
					.setBigDecimal("TRX_NO", iMap.getBigDecimal("TRX_NO"))
					.list();

			for (Iterator<?> iterator = listScf.iterator(); iterator.hasNext();) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) iterator.next();
				session.delete(gnlVadeliScfOraniTx);
			}
			session.flush();
			
			
			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = new GnlVadeliScfOraniTx();
				GnlVadeliScfOraniTxId gnlVadeliScfOraniTxId = new GnlVadeliScfOraniTxId();
				gnlVadeliScfOraniTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlVadeliScfOraniTxId.setKod(iMap.getBigDecimal(tableName, row, "KOD"));
				
				gnlVadeliScfOraniTx.setVadeAraligi(iMap.getString(tableName, row, "VADE_ARALIGI"));
                gnlVadeliScfOraniTx.setScfUrunGrubuKod(iMap.getString(tableName, row, "SCF_URUN_GRUBU_KOD"));
                
                gnlVadeliScfOraniTx.setId(gnlVadeliScfOraniTxId);
                gnlVadeliScfOraniTx.setScFaizOrani(iMap.getBigDecimal(tableName, row, "SC_FAIZ_ORANI"));
                
                gnlVadeliScfOraniTx.setTur(iMap.getString("TUR"));
                gnlVadeliScfOraniTx.setFaizTur(iMap.getString("FAIZ_TURU"));
                gnlVadeliScfOraniTx.setTarih(iMap.getDate("TARIH"));
                gnlVadeliScfOraniTx.setDovizKodu(iMap.getString(tableName, row, "DOVIZ_KODU"));
                gnlVadeliScfOraniTx.setMarj(iMap.getBigDecimal(tableName, row, "MARJ"));
                
				session.save(gnlVadeliScfOraniTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "9934");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}

		
	}

	@GraymoundService("BNSPR_TRN9934_GET_VADELI_SCF_ORAN_BILGI")
	public static Map<?, ?> getScfOranBilgi(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> listScf = (List<?>) session.createQuery(
					"from GnlVadeliScfOraniTx where id.txNo =:TRX_NO ")
					.setBigDecimal("TRX_NO", iMap.getBigDecimal("TRX_NO"))
					.list();

			for (Iterator<?> iterator = listScf.iterator(); iterator.hasNext();) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) iterator.next();
				session.delete(gnlVadeliScfOraniTx);
			}
			session.flush();
			
			stmt = conn.prepareCall("{call pkg_scf.vadeli_scf_gec_orani_kopyala(?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));	
			java.util.Date islem_tarihi = (java.util.Date) iMap.get("TARIH");
			stmt.setDate(2, new java.sql.Date(islem_tarihi.getTime()));
			stmt.setString(3, iMap.getString("FAIZ_TUR"));
			stmt.setString(4, iMap.getString("URUN_GRUP_LOV"));
			stmt.setString(5, iMap.getString("TUR"));
			stmt.setString(6, iMap.getString("VADE_ARALIK"));
			
			stmt.execute();
			
					
			stmt = conn.prepareCall("{? = call PKG_TRN9934.RC_QRY9934_Get_Data(?,?,?,?,?)}");	
			islem_tarihi = (java.util.Date) iMap.get("TARIH");
			stmt.registerOutParameter(1, -10);
			stmt.setDate(2, new java.sql.Date(islem_tarihi.getTime()));
			
			stmt.setString(3, iMap.getString("FAIZ_TUR"));
			stmt.setString(4, iMap.getString("URUN_GRUP_LOV"));
			stmt.setString(5, iMap.getString("VADE_ARALIK"));
			stmt.setString(6, iMap.getString("TUR"));
			
			stmt.execute();
			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);

				
			if (oMap.get(tableName)==null || oMap.getSize(tableName)==0) { 
				throw new GMRuntimeException(1, GMMessageFactory.getMessage("NODATAFOUND", null)); 
			} 
			
			return oMap;
			
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	
	
	@GraymoundService("BNSPR_TRN9934_GET_VADELI_SCF_ORAN_LIST")
	public static GMMap getZamanPrList(GMMap iMap) {
		Date tarih = null;
		String tur = null;
		String faizTur = null;
		String ratingKodu = null;
		boolean flag = true;
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session.createCriteria(GnlVadeliScfOraniTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) iterator.next();
				/*
				oMap.put(tableName, row, "VADE_ARALIGI", gnlVadeliScfOraniTx.getId().getVadeAraligi());
				oMap.put(tableName, row, "SCF_URUN_GRUBU_KOD", gnlVadeliScfOraniTx.getId().getScfUrunGrubuKod());
				oMap.put(tableName, row, "TRL_FAIZ_ORANI", gnlVadeliScfOraniTx.getTrlFaizOrani());
				oMap.put(tableName, row, "USD_FAIZ_ORANI", gnlVadeliScfOraniTx.getUsdFaizOrani());
				oMap.put(tableName, row, "EUR_FAIZ_ORANI", gnlVadeliScfOraniTx.getEurFaizOrani());
				oMap.put(tableName, row, "JPY_FAIZ_ORANI", gnlVadeliScfOraniTx.getJpyFaizOrani());
				oMap.put(tableName, row, "CHF_FAIZ_ORANI", gnlVadeliScfOraniTx.getChfFaizOrani());
				oMap.put(tableName, row, "GBP_FAIZ_ORANI", gnlVadeliScfOraniTx.getGbpFaizOrani());
				oMap.put(tableName, row, "SEK_FAIZ_ORANI", gnlVadeliScfOraniTx.getSekFaizOrani());
				oMap.put(tableName, row, "DIGER_FAIZ_ORANI", gnlVadeliScfOraniTx.getDigerFaizOrani());
				if (flag) {
					tarih = gnlVadeliScfOraniTx.getTarih();
					tur = gnlVadeliScfOraniTx.getTur();
					faizTur = gnlVadeliScfOraniTx.getFaizTur();
					ratingKodu = gnlVadeliScfOraniTx.getRatingKodu();
					flag = false;
				}
				*/	
			}
			
			oMap.put("TARIH", tarih);
			oMap.put("TUR", tur);
			oMap.put("FAIZ_TUR", faizTur);
			oMap.put("RATING_KODU", ratingKodu);
			
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	

	
	
	@GraymoundService("BNSPR_TRN9934_GET_VADELI_SCF_ORAN_LISTELE")
	public static Map<?, ?> getScfOranList(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_TRN9934.RC_QRY9934_Get_Data(?,?,?,?,?)}");	
			java.util.Date islem_tarihi = (java.util.Date) iMap.get("TARIH");
			stmt.registerOutParameter(1, -10);
			stmt.setDate(2, new java.sql.Date(islem_tarihi.getTime()));
			
			stmt.setString(3, iMap.getString("FAIZ_TUR"));
			stmt.setString(4, iMap.getString("URUN_GRUP_LOV"));
			stmt.setString(5, iMap.getString("VADE_ARALIK"));
			stmt.setString(6, iMap.getString("TUR"));
			
			stmt.execute();
			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);

			if (oMap.get(tableName)==null || oMap.getSize(tableName)==0) { 
				throw new GMRuntimeException(1, GMMessageFactory.getMessage("NODATAFOUND", null)); 
			} 
				
			return oMap;
				
			}catch (Exception e) { 
				throw new GMRuntimeException(1,e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				GMServerDatasource.close(rSet);
			}
		
	}
	
	@GraymoundService("BNSPR_TRN9934_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap){
		Connection conn =  null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			conn =  DALUtil.getGMConnection();
			
			
			List<?> list = (List<?>) session.createCriteria(
					GnlVadeliScfOraniTx.class).add(
					Restrictions.eq("id.txNo", iMap
							.getBigDecimal("TRX_NO"))).list();
			
			
			String tableName = "CBS_VADELI_SCF_ORANLARI_ISL_DE";
			int row = 0;
			
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlVadeliScfOraniTx gnlVadeliScfOraniTx = (GnlVadeliScfOraniTx) iterator.next();
				oMap.put("TARIH", gnlVadeliScfOraniTx.getTarih());
				oMap.put("URUN_GRUBU", gnlVadeliScfOraniTx.getScfUrunGrubuKod());
				oMap.put("FAIZ_TUR", gnlVadeliScfOraniTx.getFaizTur());
				
				stmt = conn.prepareStatement("select tur from gnl_scf_urun_grubu where kod = ?");
				stmt.setString(1, gnlVadeliScfOraniTx.getScfUrunGrubuKod());
				rSet = stmt.executeQuery();
				rSet.next();
				oMap.put("TUR", rSet.getString(1));
			
				oMap.put(tableName, row, "VADE_ARALIGI", gnlVadeliScfOraniTx.getVadeAraligi());
				oMap.put(tableName, row, "SCF_URUN_GRUBU_KOD", gnlVadeliScfOraniTx.getScfUrunGrubuKod());
				oMap.put(tableName, row, "DOVIZ_KODU", gnlVadeliScfOraniTx.getDovizKodu());
				oMap.put(tableName, row, "SC_FAIZ_ORANI", gnlVadeliScfOraniTx.getScFaizOrani());
				oMap.put(tableName, row, "MARJ", gnlVadeliScfOraniTx.getMarj());
				if (gnlVadeliScfOraniTx.getMarj() == null)
					oMap.put(tableName, row, "TOPLAM_FAIZ", gnlVadeliScfOraniTx.getScFaizOrani());
				else
					oMap.put(tableName, row, "TOPLAM_FAIZ", gnlVadeliScfOraniTx.getScFaizOrani().add(gnlVadeliScfOraniTx.getMarj()));
				
			}

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			 	GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
		}
	}

	
}
