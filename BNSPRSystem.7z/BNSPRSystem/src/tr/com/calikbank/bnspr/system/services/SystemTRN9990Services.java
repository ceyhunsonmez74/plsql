package tr.com.calikbank.bnspr.system.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlBankaSubeTelefonPr;
import tr.com.aktifbank.bnspr.dao.GnlBankaSubeTelefonPrTx;
import tr.com.aktifbank.bnspr.dao.GnlBankaSubeTelefonPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class SystemTRN9990Services {
	
	private static Logger logger = Logger.getLogger(SystemTRN9990Services.class);
	
	private enum GDS {
		GIRIS("G"), DUZENLEME("D"), SILME("S");
		
		String code;
		
		private GDS(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}
	}
	
	/**
	 * Banka sube telefon detaylari kayit servisi. Tek bir sube uzerinde bir veya daha fazla kayit islemi yapilmasi 
	 * icin kullanilabilir.
	 * 
	 * @param iMap {TRX_NO}					Transaction numarasi
	 * @param iMap {BANK_CODE}				Banka kodu - <tt>bnspr.gnl_banka_kod_pr</tt>
	 * @param iMap {BANK_BRANCH_CODE}		Banka sube kodu - <tt>bnspr.gnl_banka_sube_kod_pr</tt>
	 * @param iMap {DETAILS}				{@code ArrayList<GMMap>} tipinde sube telefon bilgileri
	 * @return
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_TRN9990_SAVE")
	public static GMMap save(GMMap iMap) {
		
		GDS gds;
		String countryCode = "+90";
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			Map<String, String> restrictions = new HashMap<String, String>();
			restrictions.put("id.bankaKod", iMap.getString("BANK_CODE"));
			restrictions.put("id.subeKodu", iMap.getString("BANK_BRANCH_CODE"));
			
			@SuppressWarnings("unchecked")
			List<GnlBankaSubeTelefonPr> phones = session.createCriteria(GnlBankaSubeTelefonPr.class).add(
				Restrictions.allEq(restrictions)).addOrder(Order.asc("id.siraNo")).list();
			
			BigDecimal maxOrderNo = !phones.isEmpty() ? phones.get(phones.size() - 1).getId().getSiraNo()
				: BigDecimal.ZERO;
			
			for(Iterator<GnlBankaSubeTelefonPr> iterPhone = phones.iterator(); iterPhone.hasNext();) {
				
				GnlBankaSubeTelefonPr phone = iterPhone.next();
				
				boolean phoneExistsInput = false;
				gds = null;
				
				for(int i=0; i<iMap.getSize("DETAILS"); i++) {
					
					if(iMap.get("DETAILS", i, "SIRA_NO") == null)
						continue;
					
					if(iMap.getBigDecimal("DETAILS", i, "SIRA_NO").compareTo(phone.getId().getSiraNo()) == 0) {

						if((phone.getAlanKod() != null && !phone.getAlanKod().equals(
							iMap.getString("DETAILS", i, "ALAN_KOD")))
							|| (phone.getTelNo() != null && !phone.getTelNo().equals(
								iMap.getString("DETAILS", i, "TEL_NO")))
							|| (phone.getDahiliNo() != null && !phone.getDahiliNo().equals(
								iMap.getString("DETAILS", i, "DAHILI_NO")))
							|| (phone.getVarsayilan() != null && !phone.getVarsayilan().equals(
								iMap.getString("DETAILS", i, "VARSAYILAN")))) {
							gds = GDS.DUZENLEME;
							phone.setAlanKod(iMap.getString("DETAILS", i, "ALAN_KOD"));
							phone.setTelNo(iMap.getString("DETAILS", i, "TEL_NO"));
							phone.setDahiliNo(iMap.getString("DETAILS", i, "DAHILI_NO"));
							phone.setVarsayilan(iMap.getString("DETAILS", i, "VARSAYILAN"));
						}
						
						phoneExistsInput = true;
						break;
					}
				}
				
				if(!phoneExistsInput)
					gds = GDS.SILME;
				
				GnlBankaSubeTelefonPrTx phoneTx = new GnlBankaSubeTelefonPrTx(new GnlBankaSubeTelefonPrTxId(iMap
					.getBigDecimal("TRX_NO"), phone.getId().getBankaKod(), phone.getId().getSubeKodu(),
					phone.getId().getSiraNo()));
				phoneTx.setAlanKod(phone.getAlanKod());
				phoneTx.setTelNo(phone.getTelNo());
				phoneTx.setDahiliNo(phone.getDahiliNo());
				phoneTx.setVarsayilan(phone.getVarsayilan() != null ? phone.getVarsayilan() : "0");
				phoneTx.setUlkeKod(countryCode);
				phoneTx.setGDS(gds != null ? gds.toString() : null);
				session.save(phoneTx);
			}
			
			for(int i=0; i<iMap.getSize("DETAILS"); i++) {
				
				if(iMap.get("DETAILS", i, "SIRA_NO") == null) {
					
					maxOrderNo = maxOrderNo.add(BigDecimal.ONE);
					
					GnlBankaSubeTelefonPrTx phoneTx = new GnlBankaSubeTelefonPrTx(new GnlBankaSubeTelefonPrTxId(iMap
						.getBigDecimal("TRX_NO"), iMap.getString("BANK_CODE"), iMap.getString("BANK_BRANCH_CODE"),
						maxOrderNo));
					phoneTx.setAlanKod(iMap.getString("DETAILS", i, "ALAN_KOD"));
					phoneTx.setTelNo(iMap.getString("DETAILS", i, "TEL_NO"));
					phoneTx.setDahiliNo(iMap.getString("DETAILS", i, "DAHILI_NO"));
					phoneTx.setVarsayilan(iMap.get("DETAILS", i, "VARSAYILAN") != null ? iMap.getString("DETAILS", i,
						"VARSAYILAN") : "0");
					phoneTx.setUlkeKod(countryCode);
					phoneTx.setGDS(GDS.GIRIS.toString());
					session.save(phoneTx);
				}	
			}
			session.flush();
				
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", new GMMap().put("TRX_NAME", "9990").put(
				"TRX_NO", iMap.getBigDecimal("TRX_NO")));

		} catch (Exception e) {
			logger.error("BNSPR_TRN9990_SAVE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * 
	 * @param iMap {BANK_CODE}				Banka kodu - <tt>bnspr.gnl_banka_kod_pr</tt>
	 * @param iMap {BANK_BRANCH_CODE}		Banka sube kodu - <tt>bnspr.gnl_banka_sube_kod_pr</tt>
	 * @return
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_TRN9990_GET_DETAILS")
	public static GMMap getDetails(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {

			if(GMContext.getCurrentContext().getSession().get("TRN9990") instanceof GMMap) {
				
				GMMap sessionMap = (GMMap) GMContext.getCurrentContext().getSession().get("TRN9990");
				
				if(sessionMap.get("BANK_CODE") != null
					&& sessionMap.getMap(iMap.getString("BANK_CODE")).get(iMap.getString("BANK_BRANCH_CODE")) != null) {
		
					oMap.put("DETAILS", sessionMap.getMap(iMap.getString("BANK_CODE")).get(
						iMap.getString("BANK_BRANCH_CODE")));
				}
			}
			
			if(!oMap.containsKey("DETAILS")) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				
				Map<String, String> restrictions = new HashMap<String, String>();
				restrictions.put("id.bankaKod", iMap.getString("BANK_CODE"));
				restrictions.put("id.subeKodu", iMap.getString("BANK_BRANCH_CODE"));
				
				@SuppressWarnings("unchecked")
				List<GnlBankaSubeTelefonPr> phones = session.createCriteria(GnlBankaSubeTelefonPr.class).add(
					Restrictions.allEq(restrictions)).addOrder(Order.asc("id.siraNo")).list();
				
				int index = 0;
				for(GnlBankaSubeTelefonPr phone : phones) {
					oMap.put("DETAILS", index, "SIRA_NO", phone.getId().getSiraNo());
					oMap.put("DETAILS", index, "ALAN_KOD", phone.getAlanKod());
					oMap.put("DETAILS", index, "TEL_NO", phone.getTelNo());
					oMap.put("DETAILS", index, "DAHILI_NO", phone.getDahiliNo());
					oMap.put("DETAILS", index, "VARSAYILAN", phone.getVarsayilan());
					oMap.put("DETAILS", index++, "LAST_MODIFIED", phone.getLastModified());
				}
			}
			
			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_TRN9990_GET_DETAILS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	

	/**
	 * Banka sube telefon detaylari kayit onayinda islemi goruntulemek icin cagirilir.
	 * 
	 * @param iMap {TRX_NO}					Transaction numarasi
	 * @return
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_TRN9990_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<GnlBankaSubeTelefonPrTx> phones = session.createCriteria(GnlBankaSubeTelefonPrTx.class).add(
				Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			int index = 0;
			for(GnlBankaSubeTelefonPrTx phone : phones) {
				if(index == 0) {
					oMap.put("BANK_CODE", phone.getId().getBankaKod());
					oMap.put("BANK_BRANCH_CODE", phone.getId().getSubeKodu());
				}
				oMap.put("DETAILS", index, "SIRA_NO", phone.getId().getSiraNo());
				oMap.put("DETAILS", index, "ALAN_KOD", phone.getAlanKod());
				oMap.put("DETAILS", index, "TEL_NO", phone.getTelNo());
				oMap.put("DETAILS", index, "DAHILI", phone.getDahiliNo());
				oMap.put("DETAILS", index++, "VARSAYILAN", phone.getVarsayilan());
			}

			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_TRN9990_GET_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Birden cok banka ve sube telefon kaydi guncellenmek amaci ile dosya yukleme adiminda cagirilir.
	 * 
	 * @param iMap {FILE}
	 * @return
	 */
	@GraymoundService("BNSPR_TRN9990_UPLOAD")
	public static GMMap upload(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			String tableName = "DETAILS";
			
			WorkbookSettings ws = new WorkbookSettings();
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("FILE")),ws);
			Sheet dataSheet1 = workbook.getSheet(0);
			
			int row = 0;
			for(int i=1; i<dataSheet1.getRows(); i++){
				
				if (dataSheet1.getCell(0, i).getContents().trim().equals("")) {
					break;
				}
				
				String bankCode = dataSheet1.getCell(0, i).getContents().trim();
				String bankBrancCode = dataSheet1.getCell(1, i).getContents().trim();
				String areaCode = dataSheet1.getCell(2, i).getContents().trim();
				String phoneNumber = dataSheet1.getCell(3, i).getContents().trim();
				String intercom = dataSheet1.getCell(4, i).getContents().trim();
				String defaultRecord = dataSheet1.getCell(5, i).getContents().trim();
				
				oMap.put(tableName, row, "BANKA_KODU", bankCode);
				oMap.put(tableName, row, "SUBE_KODU", bankBrancCode);
				oMap.put(tableName, row, "ALAN_KOD", areaCode);
				oMap.put(tableName, row, "TEL_NO", phoneNumber);
				oMap.put(tableName, row, "DAHILI_NO", intercom);
				oMap.put(tableName, row++, "VARSAYILAN", defaultRecord);
			}
			
			return oMap;
			
		} catch(BiffException e) {
			logger.error("BNSPR_TRN9990_UPLOAD err:", e);
			throw new GMRuntimeException(0,
				"L�tfen dosya format�n� kontrol ederek tekrar deneyin. \".xls\" uzantili dosya y�kleyebilirsiniz.",
				true);
		} catch(Exception e) {
			logger.error("BNSPR_TRN9990_UPLOAD err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
	}
}
