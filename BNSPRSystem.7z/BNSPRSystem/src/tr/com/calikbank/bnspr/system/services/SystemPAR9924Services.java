package tr.com.calikbank.bnspr.system.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlProgram;
import tr.com.calikbank.bnspr.dao.GnlRolProgram;
import tr.com.calikbank.bnspr.dao.GnlRolProgramId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class SystemPAR9924Services {
	
	@GraymoundService("BNSPR_PAR9924_GET_YETKI_LIST")
	public static HashMap<String, Object> getAccountList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			
			query.append("select a.level_,a.kodu,a.adi,a.PAR1,( Select max('E') From gnl_rol_program s Where s.program_kod = a.KODU And s.rol_numara = ? ) Tanim_var ");
			query.append("from V_GNL_PROGRAM_MENU_TREE a");
			
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("ROL_NUMARA"));
			
			ArrayList<DefaultMutableTreeNode> level1List = new ArrayList<DefaultMutableTreeNode>();
			ArrayList<DefaultMutableTreeNode> level2List = new ArrayList<DefaultMutableTreeNode>();
			ArrayList<DefaultMutableTreeNode> level3List = new ArrayList<DefaultMutableTreeNode>();
			
			DefaultMutableTreeNode root = new DefaultMutableTreeNode();
			HashMap<String, Object> rootUo = new HashMap<String, Object>();
			rootUo.put("NAME", "Programlar");
			rootUo.put("ADI", "");
			rootUo.put("TANIM_VAR", "0");
			rootUo.put("LEVEL", new BigDecimal(0));
			root.setUserObject(rootUo);
			
			resultSet = stmt.executeQuery();
			while (resultSet.next()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				BigDecimal level = resultSet.getBigDecimal(1);
				DefaultMutableTreeNode node = new DefaultMutableTreeNode();
				node.setUserObject(rowData);
				rowData.put("NAME", resultSet.getString(2));
				rowData.put("ADI", resultSet.getString(3));
				rowData.put("PAR1", resultSet.getString(4));
				rowData.put("TANIM_VAR", GuimlUtil.convertToCheckBoxValue(resultSet.getString(5)));
				rowData.put("LEVEL", level);
				if(level.compareTo(new BigDecimal(1)) == 0){
					level1List.add(node);
					root.add(node);
				}
				else if(level.compareTo(new BigDecimal(2)) == 0){
					level2List.add(node);
				}
				else if(level.compareTo(new BigDecimal(3)) == 0){
					level3List.add(node);
				}
			}
			for (Iterator<?> iterator = level1List.iterator(); iterator.hasNext();) {
				DefaultMutableTreeNode l1node = (DefaultMutableTreeNode) iterator.next();
				HashMap<?, ?> l1uo = (HashMap<?, ?>)l1node.getUserObject();
				for (Iterator<?> iterator2 = level2List.iterator(); iterator2.hasNext();) {
					DefaultMutableTreeNode l2Node = (DefaultMutableTreeNode) iterator2.next();
					HashMap<?, ?> l2uo = (HashMap<?, ?>)l2Node.getUserObject();
					if(l1uo.get("NAME").equals(l2uo.get("PAR1")))
						l1node.add(l2Node);
					for (Iterator<?> iterator3 = level3List.iterator(); iterator3.hasNext();) {
						DefaultMutableTreeNode l3Node = (DefaultMutableTreeNode) iterator3.next();
						HashMap<?, ?> l3uo = (HashMap<?, ?>)l3Node.getUserObject();
						if(l2uo.get("NAME").equals(l3uo.get("PAR1")))
							l2Node.add(l3Node);
					}
				}
			}
			
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("ROL_YETKI_TANIM", root);
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(resultSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_PAR9925_SAVE_ROL_YETKI_TANIM")
	public static Map<?,?> saveSinifTurKod(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> rolProgramPersistentList = (List<?>)session.createCriteria(GnlRolProgram.class).add(Restrictions.eq("id.rolNumara", iMap.getBigDecimal("ROL_NUMARA"))).list();
			ArrayList<HashMap<?, ?>> rolProgramGUIList = new ArrayList<HashMap<?,?>>();
			
			DefaultMutableTreeNode root = (DefaultMutableTreeNode)iMap.get("ROL_YETKI_TANIM");
			
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode nodel1 = (DefaultMutableTreeNode)root.getChildAt(i);
				for (int j = 0; j < nodel1.getChildCount(); j++) {
					DefaultMutableTreeNode nodel2 = (DefaultMutableTreeNode)nodel1.getChildAt(j);
					for (int k = 0; k < nodel2.getChildCount(); k++) {
						DefaultMutableTreeNode nodel3 = (DefaultMutableTreeNode)nodel2.getChildAt(k);
						HashMap<?, ?> rowData = (HashMap<?, ?>)nodel3.getUserObject();
						rolProgramGUIList.add(rowData);
					}
				}
			}
					
			for (Iterator<?> iterator = rolProgramPersistentList.iterator(); iterator.hasNext();) {
				GnlRolProgram gnlRolProgram = (GnlRolProgram) iterator.next();
				for (Iterator<?> iterator2 = rolProgramGUIList.iterator(); iterator2.hasNext();) {
					HashMap<?, ?> rowData = (HashMap<?, ?>)iterator2.next();
					if(rowData.get("NAME").equals(gnlRolProgram.getId().getGnlProgram().getKod()) && "0".equals(rowData.get("TANIM_VAR")))
						session.delete(gnlRolProgram);	
				}
			}

			for (Iterator<?> iterator = rolProgramGUIList.iterator(); iterator.hasNext();) {
				HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
				if("1".equals(rowData.get("TANIM_VAR"))){
					GnlRolProgram gnlRolProgram = findRolProgram(iMap.getBigDecimal("ROL_NUMARA"), (String)rowData.get("NAME"));
					if(gnlRolProgram == null){
						gnlRolProgram = new GnlRolProgram();
						GnlRolProgramId id = new GnlRolProgramId();
						id.setRolNumara(iMap.getBigDecimal("ROL_NUMARA"));
						id.setGnlProgram(findProgram((String)rowData.get("NAME")));
						gnlRolProgram.setId(id);
						session.saveOrUpdate(gnlRolProgram);
					}
				}
			}
			
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r!");
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static GnlProgram findProgram(String kod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlProgram)session.get(GnlProgram.class, kod);
	}
	
	public static GnlRolProgram findRolProgram(BigDecimal rolNumara, String programKod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlRolProgram)session.get(GnlRolProgram.class, new GnlRolProgramId(rolNumara, findProgram(programKod)));
	}

}
