package tr.com.calikbank.bnspr.hsm.message.clearpin;

import tr.com.calikbank.bnspr.hsm.HsmUtil;
import tr.com.calikbank.bnspr.hsm.message.HsmResponse;
import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;

public class HsmDecryptPinResponse extends HsmResponse {

	private String pin;
	private String accountNumber;
	
	public HsmDecryptPinResponse(int pinLength) {
		setPinLength(pinLength);
	}
	
	@Override
	public void parseTcpMessage(HsmSocketData socketData) {
		parseHeader(socketData.getData());
		if(getErrorCode().equals(HsmUtil.HSM_NO_ERROR)){
			setPin(getMessagePart(socketData.getData(),getPinLength()).toString());
			increseParserIndex();
			setAccountNumber(getMessagePart(socketData.getData(),12).toString());
		}
	}

	public String getPin() {
		return pin;
	}

	private void setPin(String pin) {
		this.pin = pin;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
}
