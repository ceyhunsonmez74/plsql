package tr.com.calikbank.bnspr.hsm.message.encrypt;

import tr.com.calikbank.bnspr.hsm.message.HsmRequest;



public class HsmTransPinFromLMKtoZPKRequest extends HsmRequest {

	private String zpk;
	private String pinBlockFormat;
	private String accountNumber;
	private String pin;
	
	public HsmTransPinFromLMKtoZPKRequest() {
		this.command="JG";
	}

	public String getZpk() {
		return zpk;
	}

	public void setZpk(String zpk) {
		this.zpk = zpk;
	}

	public String getPinBlockFormat() {
		return pinBlockFormat;
	}

	public void setPinBlockFormat(String pinBlockFormat) {
		this.pinBlockFormat = pinBlockFormat;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}
	
	@Override
	public String getMessageData() {
		StringBuffer sb=new StringBuffer();
		sb.append(formatMessageId()).append(getCommand()).append(getZpk()).append(getPinBlockFormat()).append(getAccountNumber()).append(getPin());
		return sb.toString();
	}
	
}
