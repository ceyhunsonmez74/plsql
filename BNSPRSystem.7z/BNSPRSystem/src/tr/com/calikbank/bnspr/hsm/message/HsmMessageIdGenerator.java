package tr.com.calikbank.bnspr.hsm.message;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class HsmMessageIdGenerator {
	
	private ConcurrentHashMap<Integer, Boolean> messageHeaderIdMap;

	public HsmMessageIdGenerator(int size) {
		messageHeaderIdMap=new ConcurrentHashMap<Integer, Boolean>();
		for(int index=1;index<=size;index++) {
			messageHeaderIdMap.put(index, false);
		}
	}
	
	public synchronized int getMessageId() {
		for(Entry<Integer, Boolean> entry:messageHeaderIdMap.entrySet()){
			if(!entry.getValue()){
				entry.setValue(true);
				return entry.getKey().intValue();
			}
		}
		throw new RuntimeException("Not Found Usable Message Header Id");
	}
	
	public void releaseId(int messageId){
		messageHeaderIdMap.put(messageId, false);
	} 
	
}