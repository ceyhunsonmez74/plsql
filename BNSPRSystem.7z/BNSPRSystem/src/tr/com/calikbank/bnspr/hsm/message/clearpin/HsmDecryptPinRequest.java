package tr.com.calikbank.bnspr.hsm.message.clearpin;

import tr.com.calikbank.bnspr.hsm.message.HsmRequest;



public class HsmDecryptPinRequest extends HsmRequest {

	private String accountNumber;
	private String pin;
	
	public HsmDecryptPinRequest() {
		this.command="NG";
	}
	
	public String getPin() {
		return pin;
	}
	
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	@Override
	public String getMessageData() {
		StringBuffer sb=new StringBuffer();
		sb.append(formatMessageId()).append(getCommand()).append(getAccountNumber()).append(getPin());
		return sb.toString();
	}
	
}
