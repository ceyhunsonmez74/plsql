package tr.com.calikbank.bnspr.hsm;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.apache.log4j.Logger;


public class HsmCrypt {

	private static Logger logger = Logger.getLogger(HsmCrypt.class);
	
	private Cipher cipher;
	private SecretKey key;

	public HsmCrypt(byte[] clearKey) {
		try {
			if(clearKey.length==16){
				byte[] partofClearKey = Arrays.copyOfRange(clearKey, 0, 8);
				byte[] newClearKey=new byte[clearKey.length+partofClearKey.length];
				System.arraycopy(clearKey, 0, newClearKey, 0, clearKey.length);
				System.arraycopy(partofClearKey, 0, newClearKey, clearKey.length, partofClearKey.length);
				clearKey=newClearKey;
			}
			cipher = Cipher.getInstance("DESede/ECB/NoPadding");
	        DESedeKeySpec keyspec = new DESedeKeySpec(clearKey);
			key = SecretKeyFactory.getInstance("DESede").generateSecret(keyspec);  
			
		} catch (NoSuchAlgorithmException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (NoSuchPaddingException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (InvalidKeySpecException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (InvalidKeyException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
		}
	}
	
	
	public byte[] encrypt(byte[] plainText) {
		try {
			cipher.init(Cipher.ENCRYPT_MODE, key);
			return cipher.doFinal(plainText);
			
		} catch (InvalidKeyException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (IllegalBlockSizeException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (BadPaddingException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
		}
	}
	
	public byte[] decrypt(byte[] encryptedText) {
		try {
			cipher.init(Cipher.DECRYPT_MODE, key);
			return cipher.doFinal(encryptedText);
			
		} catch (InvalidKeyException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (IllegalBlockSizeException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
			
		} catch (BadPaddingException exp) {
			logger.error(exp);
			throw new RuntimeException(exp);
		}
	}
	
}
