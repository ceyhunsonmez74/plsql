package tr.com.calikbank.bnspr.hsm.message.clearpin;

import tr.com.calikbank.bnspr.hsm.HsmUtil;
import tr.com.calikbank.bnspr.hsm.message.HsmResponse;
import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;

public class HsmEncryptPinResponse extends HsmResponse {

	private String pin;
	
	public HsmEncryptPinResponse(int pinLength) {
		setPinLength(pinLength);
	}
	
	@Override
	public void parseTcpMessage(HsmSocketData socketData) {
		parseHeader(socketData.getData());
		if(getErrorCode().equals(HsmUtil.HSM_NO_ERROR)){
			setPin(getMessagePart(socketData.getData(),getPinLength()).toString());			
		}
	}

	public String getPin() {
		return pin;
	}

	private void setPin(String pin) {
		this.pin = pin;
	}
	
	
	
}
