package tr.com.calikbank.bnspr.hsm.message.encrypt;

import tr.com.calikbank.bnspr.hsm.HsmUtil;
import tr.com.calikbank.bnspr.hsm.message.HsmResponse;
import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;

public class HsmTransPinFromLMKtoZPKResponse extends HsmResponse {

	private String pinBlock;
	
	@Override
	public void parseTcpMessage(HsmSocketData socketData) {
		parseHeader(socketData.getData());
		if(getErrorCode().equals(HsmUtil.HSM_NO_ERROR)){
			setPinBlock(getMessagePart(socketData.getData(),16).toString());
		}
	}

	public String getPinBlock() {
		return pinBlock;
	}

	public void setPinBlock(String pinBlock) {
		this.pinBlock = pinBlock;
	}

}
