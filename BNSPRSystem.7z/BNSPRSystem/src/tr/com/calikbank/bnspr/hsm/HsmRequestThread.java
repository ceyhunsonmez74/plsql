package tr.com.calikbank.bnspr.hsm;

import java.util.concurrent.Callable;

import tr.com.calikbank.bnspr.hsm.message.HsmRequest;
import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;

public class HsmRequestThread implements Callable<HsmSocketData> {

	private HsmRequest hsmRequest;
	
	public HsmRequestThread(HsmRequest hsmRequest){
		this.hsmRequest=hsmRequest;
	}
	
	@Override
	public HsmSocketData call() throws Exception {
		try {
			hsmRequest.beforeExecute();
			return TcpMessageSender.socketCommunication(getHsmRequest().getMessageData());
		} finally {
			hsmRequest.afterExecute();
		}
	}

	public HsmRequest getHsmRequest() {
		return hsmRequest;
	}

	public void setHsmRequest(HsmRequest hsmRequest) {
		this.hsmRequest = hsmRequest;
	}

	
}
