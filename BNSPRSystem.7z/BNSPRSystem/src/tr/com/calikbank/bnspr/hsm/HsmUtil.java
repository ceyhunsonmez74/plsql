package tr.com.calikbank.bnspr.hsm;

import java.util.ResourceBundle;

public class HsmUtil {

	public static String  HSM_PIN_SECURE_KEY;
	
	public static String	HSM_IP;
	public static int  		HSM_PORT;
	
	public static String  HSM_NO_ERROR;
	public static String  HSM_ZPK;
	public static String  HSM_PIN_BLOCK_FORMAT;
	
	public static int  POOL_SIZE;
	public static int  POOL_MAX_SIZE;
	public static long POOL_KEEP_ALIVE_TIME;  //seconds
	public static int  HSM_REQUEST_TIMEOUT;   //seconds
	
	static {
		ResourceBundle hsmProperties = ResourceBundle.getBundle("hsm_parameters");
		
		HSM_PIN_SECURE_KEY=hsmProperties.getString("hsm.pinSecureKey");
		/*
		HSM_IP=hsmProperties.getString("hsm.ip");
		HSM_PORT=Integer.valueOf(hsmProperties.getString("hsm.port"));
		
		HSM_NO_ERROR=hsmProperties.getString("hsm.no_error");
		HSM_ZPK=hsmProperties.getString("hsm.zpk");
		HSM_PIN_BLOCK_FORMAT=hsmProperties.getString("hsm.pin_block_format");
		
		POOL_SIZE=Integer.valueOf(hsmProperties.getString("hsm.pool_size"));
		POOL_MAX_SIZE=Integer.valueOf(hsmProperties.getString("hsm.pool_max_size"));
		POOL_KEEP_ALIVE_TIME=Long.valueOf(hsmProperties.getString("hsm.pool_keep_alive_time"));
		HSM_REQUEST_TIMEOUT=Integer.valueOf(hsmProperties.getString("hsm.request_timeout"));
		*/
	}
	
	public static byte[] convertIntToHex(int value){
	    byte[] hex = new byte[2];
	    hex[0] = ((byte)(value / 256));
	    hex[1] = ((byte)(value % 256));
	    return hex;
	}
	
	public static int convertHexToInt(byte[] value){
		int newValue=0;
		newValue+= (int)(value[0] & 0xFF) * 256;
		newValue+= (int)(value[1] & 0xFF); 
		return newValue;
	}
	
	public static byte[] xor(byte[] a, byte[] b) {
		byte[] out = new byte[a.length];
		for (int i = 0; i < a.length; i++) {
			out[i] = (byte) (a[i] ^ b[i]);
		}
		return out;
	}

	public static String toHex(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		for (byte b : bytes) {
			sb.append(String.format("%02X", b & 0xff));
		}
		return sb.toString();
	}
	
	public static String convertByteToString(byte[] value) {
	    int b;
	    StringBuffer newValue = new StringBuffer();	
	    for (int i = 0; i < value.length; i++) {
	      b = value[i];
	      newValue.append((char)b);
	    }
	    return newValue.toString();
	 }
	
}
