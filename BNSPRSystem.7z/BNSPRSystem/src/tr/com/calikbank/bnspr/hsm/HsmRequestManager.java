package tr.com.calikbank.bnspr.hsm;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import tr.com.calikbank.bnspr.hsm.message.HsmMessageIdGenerator;
import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;

public class HsmRequestManager {

	private static HsmRequestManager instance;

	private HsmMessageIdGenerator hsmMessageIdGenerator;
	private ExecutorService executorService;
	
	public static synchronized HsmRequestManager getInstance() {
		if(instance == null) {
			instance = new HsmRequestManager();
		}
		return instance;
	}
	
	public HsmRequestManager(){
		hsmMessageIdGenerator=new HsmMessageIdGenerator(HsmUtil.POOL_MAX_SIZE);
		executorService = new HsmThreadPool(HsmUtil.POOL_SIZE,HsmUtil.POOL_MAX_SIZE,HsmUtil.POOL_KEEP_ALIVE_TIME);
	}

	public HsmMessageIdGenerator getHsmMessageIdGenerator() {
		return hsmMessageIdGenerator;
	}

	public HsmSocketData sendTcpMessage(HsmRequestThread hsmRequestThread) {
		try {
			Future<HsmSocketData> future=executorService.submit(hsmRequestThread);
			return future.get(HsmUtil.HSM_REQUEST_TIMEOUT, TimeUnit.SECONDS);
		} catch (InterruptedException exp) {
			throw new RuntimeException(exp);
		} catch (ExecutionException exp) {
			throw new RuntimeException(exp);
		} catch (TimeoutException exp) {
			throw new RuntimeException(exp);
		}
	}

}