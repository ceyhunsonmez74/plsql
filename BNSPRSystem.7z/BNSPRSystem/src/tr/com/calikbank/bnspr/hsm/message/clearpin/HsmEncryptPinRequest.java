package tr.com.calikbank.bnspr.hsm.message.clearpin;

import tr.com.calikbank.bnspr.hsm.message.HsmRequest;



public class HsmEncryptPinRequest extends HsmRequest {

	private String pin;
	private String accountNumber;
	
	public HsmEncryptPinRequest() {
		this.command="BA";
	}
	
	public String getPin() {
		return pin;
	}
	
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	@Override
	public String getMessageData() {
		StringBuffer sb=new StringBuffer();
		sb.append(formatMessageId()).append(getCommand()).append(getPin()).append("F").append(getAccountNumber());
		return sb.toString();
	}
	
}
