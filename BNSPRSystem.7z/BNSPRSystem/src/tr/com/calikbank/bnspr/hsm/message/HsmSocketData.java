package tr.com.calikbank.bnspr.hsm.message;

public class HsmSocketData {

	private byte[] data;

	public HsmSocketData(byte[] data){
		this.data=data;
	}
	
	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}
	
}
