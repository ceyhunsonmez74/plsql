package tr.com.calikbank.bnspr.hsm.message;

import tr.com.calikbank.bnspr.hsm.HsmRequestManager;


public abstract class HsmRequest {

	protected int messageId;
	protected String command;
	
	public abstract String getMessageData();
	
	protected int getMessageId() {
		return messageId;
	}
	
	protected void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	protected String getCommand() {
		return command;
	}
	
	protected void setCommand(String command) {
		this.command = command;
	}
	
    public String formatMessageId(){
    	return String.format("%04d",this.messageId);
    } 
    
    public void beforeExecute(){
    	this.messageId=HsmRequestManager.getInstance().getHsmMessageIdGenerator().getMessageId();
    }
    
    public void afterExecute(){
    	if(this.messageId>0){
    		HsmRequestManager.getInstance().getHsmMessageIdGenerator().releaseId(this.messageId);
    	}
    }

}
