package tr.com.calikbank.bnspr.hsm;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;
import tr.com.calikbank.bnspr.hsm.message.clearpin.HsmDecryptPinRequest;
import tr.com.calikbank.bnspr.hsm.message.clearpin.HsmDecryptPinResponse;
import tr.com.calikbank.bnspr.hsm.message.clearpin.HsmEncryptPinRequest;
import tr.com.calikbank.bnspr.hsm.message.clearpin.HsmEncryptPinResponse;
import tr.com.calikbank.bnspr.hsm.message.encrypt.HsmTransPinFromLMKtoZPKRequest;
import tr.com.calikbank.bnspr.hsm.message.encrypt.HsmTransPinFromLMKtoZPKResponse;
import tr.com.calikbank.bnspr.hsm.message.encrypt.HsmTransPinFromZPKToLMKRequest;
import tr.com.calikbank.bnspr.hsm.message.encrypt.HsmTransPinFromZPKToLMKResponse;
import tr.com.obss.adc.core.util.ADCParameters;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class HsmServices {

	private static Logger logger = Logger.getLogger(HsmServices.class);
	
	/***
	 * HSM Encryption Service
	 * 
	 */
	@GraymoundService("BNSPR_SYSTEM_GET_PIN_BLOCK_HSM")
	public static GMMap encryptClearPinHsm(GMMap iMap) {
		try {
			String accountNumber=iMap.getString("CARD_NO").substring(3, 15);
			HsmEncryptPinResponse encryptPinResponse=getEncryptPin(iMap.getString("PIN"),accountNumber);
			HsmTransPinFromLMKtoZPKResponse transPinFromLMKtoZPKResponse=getZPK(encryptPinResponse.getPin(),accountNumber);
			GMMap oMap = new GMMap();
			oMap.put("PIN_BLOCK", transPinFromLMKtoZPKResponse.getPinBlock());
			return oMap;
		} catch(Exception exp) {
			logger.error(exp);
			throw new GMRuntimeException(0,"HSM Encryption Exception: "+exp.getMessage());
		}
	}
	
	private static HsmEncryptPinResponse getEncryptPin(String pin, String accountNumber){
		HsmEncryptPinRequest encryptPinRequest=new HsmEncryptPinRequest();
		encryptPinRequest.setAccountNumber(accountNumber);
		encryptPinRequest.setPin(pin);
		HsmSocketData socketData = HsmRequestManager.getInstance().sendTcpMessage(new HsmRequestThread(encryptPinRequest));	
		HsmEncryptPinResponse encryptPinResponse=new HsmEncryptPinResponse(pin.length()+1);
		encryptPinResponse.parseTcpMessage(socketData);
		return encryptPinResponse;
	}
	
	private static HsmTransPinFromLMKtoZPKResponse getZPK(String pinBlock, String accountNumber){
		HsmTransPinFromLMKtoZPKRequest transPinFromLMKtoZPKRequest=new HsmTransPinFromLMKtoZPKRequest();
		transPinFromLMKtoZPKRequest.setZpk(HsmUtil.HSM_ZPK);
		transPinFromLMKtoZPKRequest.setPin(pinBlock);
		transPinFromLMKtoZPKRequest.setAccountNumber(accountNumber);
		transPinFromLMKtoZPKRequest.setPinBlockFormat(HsmUtil.HSM_PIN_BLOCK_FORMAT);
		
		HsmSocketData socketData = HsmRequestManager.getInstance().sendTcpMessage(new HsmRequestThread(transPinFromLMKtoZPKRequest));	
		HsmTransPinFromLMKtoZPKResponse transPinFromLMKtoZPKResponse=new HsmTransPinFromLMKtoZPKResponse();
		transPinFromLMKtoZPKResponse.parseTcpMessage(socketData);
		return transPinFromLMKtoZPKResponse;
	}
	
	private static HsmTransPinFromZPKToLMKResponse getPinFromZPKToLMK(String pinBlock, String accountNumber, int pinLength){
		HsmTransPinFromZPKToLMKRequest transPinFromZPKToLMKRequest=new HsmTransPinFromZPKToLMKRequest();
		transPinFromZPKToLMKRequest.setZpk(HsmUtil.HSM_ZPK);
		transPinFromZPKToLMKRequest.setPin(pinBlock);
		transPinFromZPKToLMKRequest.setAccountNumber(accountNumber);
		transPinFromZPKToLMKRequest.setPinBlockFormat(HsmUtil.HSM_PIN_BLOCK_FORMAT);
		
		HsmSocketData socketData = HsmRequestManager.getInstance().sendTcpMessage(new HsmRequestThread(transPinFromZPKToLMKRequest));	
		HsmTransPinFromZPKToLMKResponse transPinFromZPKToLMKResponse=new HsmTransPinFromZPKToLMKResponse(pinLength+1);
		transPinFromZPKToLMKResponse.parseTcpMessage(socketData);
		return transPinFromZPKToLMKResponse;
	}
	
	/**
	 * HSM Decryption Service
	 * 
	 */
	@GraymoundService("BNSPR_SYSTEM_GET_DECRYPT_PIN_BLOCK_HSM")
	public static GMMap decryptPinBlockHsm(GMMap iMap) {
		try {
			String pinBlock=iMap.getString("PIN_BLOCK");
			String accountNumber=iMap.getString("CARD_NO").substring(3, 15);
			int pinLength=iMap.getInt("LENGTH");
			HsmTransPinFromZPKToLMKResponse hsmTransPinFromZPKToLMKResponse=getPinFromZPKToLMK(pinBlock, accountNumber, pinLength);
			HsmDecryptPinResponse decryptPinResponse=getDecryptedPin(hsmTransPinFromZPKToLMKResponse.getPinBlock(), accountNumber);
			GMMap oMap = new GMMap();
			oMap.put("PIN", decryptPinResponse.getPin());
			return oMap;
		} catch(Exception exp) {
			logger.error(exp);
			throw new GMRuntimeException(0,"HSM Decryption Exception :"+exp.getMessage());
		}
	}
	
	private static HsmDecryptPinResponse getDecryptedPin(String pin, String accountNumber){
		HsmDecryptPinRequest decryptPinRequest=new HsmDecryptPinRequest();
		decryptPinRequest.setPin(pin);
		decryptPinRequest.setAccountNumber(accountNumber);
		HsmSocketData socketData = HsmRequestManager.getInstance().sendTcpMessage(new HsmRequestThread(decryptPinRequest));	
		HsmDecryptPinResponse decryptPinResponse=new HsmDecryptPinResponse(pin.length()-1);
		decryptPinResponse.parseTcpMessage(socketData);
		return decryptPinResponse;
	}
	
	/**
	 * PIN Block Encryption Service
	 * 
	 */
	@GraymoundService("BNSPR_SYSTEM_GET_PIN_BLOCK")
	public static GMMap encryptClearPin(GMMap iMap) {
		try {
			StringBuilder strBuilder = new StringBuilder();
	
			String pin = iMap.getString("PIN");
			String cardNo = iMap.getString("CARD_NO");
			
			strBuilder.append(StringUtils.leftPad(String.valueOf(pin.length()), 2, "0")).append(pin);
			
			String firstDigit = StringUtils.rightPad(strBuilder.toString(), 16, "F");
	
			strBuilder = new StringBuilder("0000");
			strBuilder.append((cardNo.length()==12)?cardNo:cardNo.substring(3, 15));
			String secondDigit = strBuilder.toString();

			byte[] xorResult = HsmUtil.xor(Hex.decodeHex(firstDigit.toCharArray()), Hex.decodeHex(secondDigit.toCharArray()));
			HsmCrypt crypt = new HsmCrypt(getHsmZpkKey());
	
			GMMap oMap = new GMMap();
			oMap.put("PIN_BLOCK", HsmUtil.toHex(crypt.encrypt(xorResult)));
			
			return oMap;
			
		} catch(Exception exp) {
			logger.error(exp);
			throw new GMRuntimeException(0,"PIN Block Encryption Exception: "+exp.getMessage());
		}
	}
	
	/**
	 * PIN Block Decryption Service
	 * 
	 */
	@GraymoundService("BNSPR_SYSTEM_GET_DECRYPT_PIN_BLOCK")
	public static GMMap decryptPinBlock(GMMap iMap) {
		try {
			String pinBlock=iMap.getString("PIN_BLOCK");
			String cardNo=iMap.getString("CARD_NO");

			StringBuilder firstDigit = new StringBuilder("0000");
			firstDigit.append((cardNo.length()==12)?cardNo:cardNo.substring(3, 15));
			
			HsmCrypt crypt = new HsmCrypt(getHsmZpkKey());
			byte[] secondDigit = crypt.decrypt(Hex.decodeHex(pinBlock.toCharArray()));
			
			byte[] xorResult = HsmUtil.xor(Hex.decodeHex(firstDigit.toString().toCharArray()), secondDigit);
			String pin = HsmUtil.toHex(xorResult);
			
			GMMap oMap = new GMMap();
			oMap.put("PIN", pin.substring(2, Integer.valueOf(pin.substring(0,2))+2));
			return oMap;
		} catch(Exception exp) {
			logger.error(exp);
			throw new GMRuntimeException(0,"PIN Block Decryption Exception: "+exp.getMessage());
		}
	}

	private static byte[] getHsmZpkKey() throws DecoderException {
		String encSecretKey = ADCParameters.getString("HSM_PIN_BLOCK_SECRET_KEY");
		HsmCrypt crypt = new HsmCrypt(Hex.decodeHex(HsmUtil.HSM_PIN_SECURE_KEY.toCharArray()));
		return crypt.decrypt(Hex.decodeHex(encSecretKey.toCharArray()));
	}
	
}
