package tr.com.calikbank.bnspr.hsm;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;


public class TcpMessageSender {

	public static HsmSocketData socketCommunication(String messageData) throws IOException {
		Socket socket=null;
		try {
			socket=new Socket(HsmUtil.HSM_IP,HsmUtil.HSM_PORT);
			
			InputStream input = socket.getInputStream();
			OutputStream output = socket.getOutputStream();
	
			ByteArrayOutputStream message=new ByteArrayOutputStream();
		    message.write(HsmUtil.convertIntToHex(messageData.length()));
			message.write(messageData.getBytes());
		    output.write(message.toByteArray());
		    output.flush();
			
	        ByteArrayOutputStream response = new ByteArrayOutputStream();
	        byte[] length=new byte[2];
			int dataLength=0;
			if(input.read(length,0,length.length)!=-1){
				dataLength=HsmUtil.convertHexToInt(length);
			} else {
				throw new RuntimeException("No Socket Data To Read");
			}
	
			for(int index=0;index<dataLength;index++) {
				int value=input.read();
				response.write(value);
			} 
			
	    	return new HsmSocketData(response.toByteArray());
			
		} finally{
			if(socket!=null && socket.isConnected()){
				socket.close();
			}
		}
	}

}
