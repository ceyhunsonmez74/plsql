package tr.com.calikbank.bnspr.hsm.message;

import tr.com.calikbank.bnspr.hsm.HsmUtil;

public abstract class HsmResponse {

	private String header;
	private String responseCode;
	private String errorCode;
	
	private int parseIndex=0;
	
	private int pinLength;
	
	public abstract void parseTcpMessage(HsmSocketData socketData);

	protected void parseHeader(byte[] data){
		setHeader(getMessagePart(data,4));
		setResponseCode(getMessagePart(data,2));
		setErrorCode(getMessagePart(data,2));
	}

	protected String getMessagePart(byte[] data, int length){
		byte[] temp=new byte[length];
		System.arraycopy(data, parseIndex, temp, 0, temp.length);
		parseIndex+=length;
		return HsmUtil.convertByteToString(temp);
	}
	
	protected void increseParserIndex(){
		this.parseIndex++;
	}
	
	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	protected int getPinLength() {
		return pinLength;
	}

	protected void setPinLength(int pinLength) {
		this.pinLength = pinLength;
	}
	
}
