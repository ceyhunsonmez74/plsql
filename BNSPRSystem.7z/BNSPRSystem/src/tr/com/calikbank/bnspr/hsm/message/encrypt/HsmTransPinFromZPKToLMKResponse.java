package tr.com.calikbank.bnspr.hsm.message.encrypt;

import tr.com.calikbank.bnspr.hsm.HsmUtil;
import tr.com.calikbank.bnspr.hsm.message.HsmResponse;
import tr.com.calikbank.bnspr.hsm.message.HsmSocketData;

public class HsmTransPinFromZPKToLMKResponse extends HsmResponse {

	private String pinBlock;
	
	public HsmTransPinFromZPKToLMKResponse(int pinLength) {
		setPinLength(pinLength);
	}
	
	@Override
	public void parseTcpMessage(HsmSocketData socketData) {
		parseHeader(socketData.getData());
		if(getErrorCode().equals(HsmUtil.HSM_NO_ERROR)){
			setPinBlock(getMessagePart(socketData.getData(),getPinLength()).toString());
		}
	}

	public String getPinBlock() {
		return pinBlock;
	}

	public void setPinBlock(String pinBlock) {
		this.pinBlock = pinBlock;
	}

}
