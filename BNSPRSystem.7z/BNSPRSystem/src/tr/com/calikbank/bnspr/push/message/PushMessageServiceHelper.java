package tr.com.calikbank.bnspr.push.message;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.obss.adc.core.util.ADCSession;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public abstract class PushMessageServiceHelper {

	protected static Logger logger = Logger.getLogger(PushMessageServiceHelper.class);
	
	protected static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-push.properties");
	
	private static int errorCodeTryAgain=1;
	private static int errorCodeNotTryAgain=2;
	private static int httpOK=200;
	
	protected static GMMap messageSender(String url,GMMap iMap) {
		GMMap oMap=new GMMap();
		try{
			String apiKey=getApiKey(iMap.getString("APP"));
			JsonElement element=convertStringToJson(iMap.getString("JSON_DATA"));
			
			String disabledKeys=conf.getProperty("disabled.json.message.keys");
			if(!StringUtils.isEmpty(disabledKeys)){
				hideSpecialKeys(disabledKeys, element);
			}
			
			String responseString=null;
			boolean logState=Boolean.valueOf(conf.getProperty("log.message.state"));
			HttpResponse response=callRestApi(apiKey, url, element.toString(), logState);
			int responseCode=response.getStatusLine().getStatusCode();
			if(logState){
				responseString=getResponseString(response);
				logResponseMessage(responseCode, responseString);
			}	
			if(responseCode==httpOK) {
				oMap.put("ERROR_CODE", "0");
			} else {
				oMap.put("ERROR_CODE", String.valueOf(responseCode));
				oMap.put("ERROR_DESC", (logState ? responseString : getResponseString(response)));
				oMap.put("NOT_NECESSARY_TO_CONTINUE", true);
			}
		} catch(GMRuntimeException ge) {
			oMap.put("ERROR_CODE", ge.getCode());
			oMap.put("ERROR_DESC", ge.getMessage());		
			oMap.put("NOT_NECESSARY_TO_CONTINUE", (ge.getCode()==errorCodeNotTryAgain));
		}
		return oMap;
	}
	private static String getResponseString(HttpResponse response){
		try {
			if(response!=null){
				HttpEntity entity=response.getEntity();
				if(entity!=null){
					return EntityUtils.toString(entity);
				}
			}
		} catch(Exception exp) {
			logger.error("Getting Response String Exception:",exp);
		}
		return null;
	}
	
	private static HttpResponse callRestApi(String apiKey, String url, String message, boolean logState) {
		try {
			HttpClient client = new DefaultHttpClient();
			setHttpParams(client.getParams());
			HttpPost post = new HttpPost(url);
			post.setHeader("X-netmera-api-key", apiKey);
			post.setHeader("Content-Type", "application/json");
			post.setEntity(new StringEntity(message, "UTF-8"));
			HttpResponse response=client.execute(post);
			if(logState){
				logRequestMessage(post);
			}
			return response;
		} catch (ClientProtocolException exp) {
			logger.error("callRestApi ClientProtocolException:", exp);
			throw new GMRuntimeException(errorCodeNotTryAgain, exp);
		} catch (IOException exp) {
			logger.error("callRestApi IOException:", exp);
			throw new GMRuntimeException(errorCodeTryAgain, exp);
		}
	}
	
	private static void setHttpParams(HttpParams httpParams){
		HttpConnectionParams.setConnectionTimeout(httpParams, Integer.valueOf(conf.getProperty("http.connection.timeout")));
		HttpConnectionParams.setSoTimeout(httpParams, Integer.valueOf(conf.getProperty("http.socket.timeout")));		
	}
	
	private static void logRequestMessage(HttpPost post){
		try {
			if(post!=null){
				StringBuilder sb=new StringBuilder("Request:");
				sb.append(" URL: ").append(post.getURI().toString());
				sb.append(" HEADERS: ");
				for(Header header:post.getAllHeaders()){
					sb.append(header.getName()).append(":").append(header.getValue()).append(" ");
				}
				sb.append("CONTENT: ");
				if(post.getEntity()!=null){
					sb.append(EntityUtils.toString(post.getEntity()));
				}
				logger.info(sb.toString());
			}
		} catch(Exception exp) {
			logger.error("RequestMessage Logger Exception!",exp);
		}
	}
	
	private static void logResponseMessage(int responseCode, String responseString){
		try {
			StringBuilder sb=new StringBuilder("Response:");
			sb.append(" STATUS CODE: ").append(responseCode);
			sb.append(" CONTENT: ").append(responseString);
			logger.info(sb.toString());
		} catch(Exception exp) {
			logger.error("ResponseMessage Logger Exception!",exp);
		}
	}
	
	private static void hideSpecialKeys(String disabledKeys,JsonElement jsonElement){

        if (jsonElement.isJsonArray()) {
            for (JsonElement jsonSubElement : jsonElement.getAsJsonArray()) {
            	hideSpecialKeys(disabledKeys, jsonSubElement);
            }
        } else {
            if (jsonElement.isJsonObject()) {
                Set<Map.Entry<String, JsonElement>> entrySet = jsonElement.getAsJsonObject().entrySet();
                for (Map.Entry<String, JsonElement> entry : entrySet) {
                    if (disabledKeys.contains(entry.getKey())) {
                    	String hashedValue=sha256Text(entry.getValue().getAsString());
                    	entry.setValue(new JsonPrimitive(hashedValue));
                    }
                    hideSpecialKeys(disabledKeys, entry.getValue());
                }
            }
        }
	}
	
	private static String getApiKey(String appName){
		StringBuilder sb=new StringBuilder(appName);
		sb.append(".api.key");
		String apiKey=conf.getProperty(sb.toString());
		if(StringUtils.isEmpty(apiKey)){
			throw new GMRuntimeException(errorCodeNotTryAgain, "Invalid Application Name!");
		}
		return apiKey;
	}
	
	private static JsonElement convertStringToJson(String jsonString) {
		try{
			if(StringUtils.isEmpty(jsonString)){
				throw new GMRuntimeException(errorCodeNotTryAgain, "Invalid Json Syntax!");
			} else {
				return new Gson().fromJson(jsonString, JsonElement.class);
			}
		}catch(JsonSyntaxException exp){
			logger.error(exp);
			throw new GMRuntimeException(errorCodeNotTryAgain, "Invalid Json Syntax!");
		}
	}
	
	protected static String getChannelName(GMMap iMap){
		if(StringUtils.isEmpty(iMap.getString("WEBEXT_CHANNEL"))){
			return ADCSession.getString("CHANNEL");
		}else{
			return iMap.getString("WEBEXT_CHANNEL");
		}
	}
	
	protected static long getLongDateTime(Date date) {
		DateFormat longDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		return Long.parseLong(longDateTimeFormat.format(date));
	}
	
	private static String sha256Text(String value) {
		try {
			StringBuilder sb=new StringBuilder();
			if (value.length()>=3) {
				sb.append(value.substring(value.length()-3, value.length()));
				sb.append(value);
				sb.append(value.substring(0, 3));
			} else {
				sb.append(value);
			}
			
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedhash = digest.digest(sb.toString().getBytes());
			return bytesToHex(encodedhash);
			
		} catch (NoSuchAlgorithmException exp) {
			logger.error(exp);
			throw new GMRuntimeException(0, exp);
		}
	}

	private static String bytesToHex(byte[] hash) {
	    StringBuffer hexString = new StringBuffer();
	    for (int i = 0; i < hash.length; i++) {
	    	String hex = Integer.toHexString(0xff & hash[i]);
		    if(hex.length() == 1) {
		    	hexString.append('0');
		    }
		    hexString.append(hex);
	    }
	    return hexString.toString();
	}
}
