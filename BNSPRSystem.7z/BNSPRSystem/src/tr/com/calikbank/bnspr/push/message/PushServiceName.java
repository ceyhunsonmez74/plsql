package tr.com.calikbank.bnspr.push.message;

public enum PushServiceName {

	SET_ATTRIBUTE(1,"BNSPR_PUSH_SET_PROFILE_ATTRIBUTES"),
	SEND_NOTIFICATION(2,"BNSPR_PUSH_SEND_NOTIFICATION"),
	FIRE_EVENTS(3,"BNSPR_PUSH_FIRE_EVENTS"),
	SEND_BULK_NOTIFICATION(4,"BNSPR_PUSH_SEND_BULK_NOTIFICATION");
	
	private int id;
	private String value;
	
	PushServiceName(int id, String value){
		this.id=id;
		this.value=value;
	}

	public String getValue() {
		return value;
	}

	public int getId() {
		return id;
	}

    public static PushServiceName fromId(int value) {
    	switch(value) {
	    	case 1:
	    		return PushServiceName.SET_ATTRIBUTE;
	    	case 2:
	    		return PushServiceName.SEND_NOTIFICATION;
	    	case 3:
	    		return PushServiceName.FIRE_EVENTS;
	    	case 4:
	    		return PushServiceName.SEND_BULK_NOTIFICATION;
    	}
    	return null;
    }
}
