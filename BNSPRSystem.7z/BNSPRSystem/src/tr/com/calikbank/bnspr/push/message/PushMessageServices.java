package tr.com.calikbank.bnspr.push.message;

import java.io.IOException;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.dao.PushMessageSaf;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.util.GMToolkit;

public class PushMessageServices extends PushMessageServiceHelper {

	/**
	 * APP
	 * APP_LIST
	 * JSON_DATA
	 * PRIORITY
	 * SERVICE_ID
	 * @return
	 */
	@GraymoundService("BNSPR_PUSH_MESSAGE_INSERT_INTO_SAF")
	public static GMMap insertPushMessageIntoSaf(GMMap iMap) {
		try {
			PushServiceName pushServiceName=checkInputData(iMap);
			
			GMMap inputMap=generateInputMap(iMap);
			byte priority=getPriority(iMap);
			String channelName=getChannelName(iMap);
			
			String appName=iMap.getString("APP");
			if(!StringUtils.isEmpty(appName)){
				inputMap.put("APP", appName);
				savePushMessageSaf(priority, channelName, pushServiceName, inputMap);
				
			} else {
				int appListSize=iMap.getSize("APP_LIST");
				for(int index=0;index<appListSize;index++){
					appName=iMap.getString("APP_LIST", index, "NAME");
					if(!StringUtils.isEmpty(appName)){
						inputMap.put("APP", appName);
						savePushMessageSaf(priority, channelName, pushServiceName, inputMap);
					}
				}
			}
			return new GMMap();
		} catch (GMRuntimeException exp) {
			throw exp;
		} catch (Exception exp) {
			logger.error(exp);
			throw new GMRuntimeException(0, "Push Notification Message SAF Exception!");
		}
	}
	
	private static PushServiceName checkInputData(GMMap iMap){
		PushServiceName pushServiceName=PushServiceName.fromId(iMap.getInt("SERVICE_ID"));
		if(pushServiceName==null  
				|| (StringUtils.isEmpty(iMap.getString("APP")) && iMap.getSize("APP_LIST")==0)
				|| StringUtils.isEmpty(iMap.getString("JSON_DATA"))){
			logger.error("Invalid Input Data!");
			throw new GMRuntimeException(0, "Invalid Input Data Exception!");
		}
		return pushServiceName;
	}
	
	private static GMMap generateInputMap(GMMap iMap){
		GMMap inputMap=new GMMap();
		inputMap.put("JSON_DATA", iMap.getString("JSON_DATA"));
		inputMap.put("CHANNEL", getChannelName(iMap));
		return inputMap;
	}
	
	private static byte getPriority(GMMap iMap){
		try {
			if(iMap.containsKey("PRIORITY")){
				byte value=Byte.parseByte(iMap.getString("PRIORITY"));
				if(value>=0 && value<100){
					return value;
				}
			}	
		} catch (NumberFormatException nfe) {
		}
		return 0;
	}
	
	private static void savePushMessageSaf(byte priority, String channelName, PushServiceName pushServiceName, GMMap inputMap) throws IOException{
		PushMessageSaf pushMessageSaf=new PushMessageSaf();
		pushMessageSaf.setNextSendDate(0L);
		pushMessageSaf.setFirstSendDate(getLongDateTime(new Date()));
		pushMessageSaf.setFirstSendUser(ADCSession.getString("USER_NAME"));
		pushMessageSaf.setSendStatus("10");
		pushMessageSaf.setStatus(true);
		pushMessageSaf.setWebServiceName(pushServiceName.getValue());
		pushMessageSaf.setTryCount(Short.valueOf(conf.getProperty("saf.tryCount")));
		pushMessageSaf.setRunning((byte)0);
		pushMessageSaf.setPriority(priority);
		pushMessageSaf.setWaitTime(Long.valueOf(conf.getProperty("saf.waitTime")));
		pushMessageSaf.setChannel(channelName);
		pushMessageSaf.setParameters(new ClobImpl(new String(Base64.encodeBase64(GMToolkit.serialize(inputMap)))));
		pushMessageSaf.setParametersString(new ClobImpl(inputMap.toString()));
		
		DAOSession.getSession("BNSPRDal").save(pushMessageSaf);
	}
	
	/**
	 * APP -> Mobile AppName
	 * JSON_DATA -> JSON Request Data
	 * @return
	 * RESPONSE_CODE -> HTTP Response Code
	 * RESPONSE -> Response JSON Data
	 */
	@GraymoundService("BNSPR_PUSH_SET_PROFILE_ATTRIBUTES")
	public static GMMap setProfileAttributes(GMMap iMap) {
		return messageSender(conf.getProperty("url.setProfileAttributes"),iMap);
	}
	
	@GraymoundService("BNSPR_PUSH_SEND_NOTIFICATION")
	public static GMMap sendNotification(GMMap iMap) {
		return messageSender(conf.getProperty("url.sendNotification"), iMap);
	}

	@GraymoundService("BNSPR_PUSH_FIRE_EVENTS")
	public static GMMap fireEvents(GMMap iMap) {
		return messageSender(conf.getProperty("url.fireEvents"), iMap);
	}
	
	@GraymoundService("BNSPR_PUSH_SEND_BULK_NOTIFICATION")
	public static GMMap sendBulkNotification(GMMap iMap) {
		return messageSender(conf.getProperty("url.sendBulkNotification"), iMap);
	}
	
}
