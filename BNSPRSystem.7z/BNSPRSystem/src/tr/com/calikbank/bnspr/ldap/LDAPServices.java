package tr.com.calikbank.bnspr.ldap;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.novell.ldap.LDAPAttribute;
import com.novell.ldap.LDAPAttributeSet;
import com.novell.ldap.LDAPConnection;
import com.novell.ldap.LDAPEntry;
import com.novell.ldap.LDAPModification;
import com.novell.ldap.LDAPModifyDNRequest;
import com.novell.ldap.LDAPSearchResults;

public class LDAPServices {

	private static Logger logger = Logger.getLogger(LDAPServices.class);

	public static final DateFormat LDAP_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

	/**
	 * LDAP kullanicisi varsa gunceller, yoksa ekler 
	 */

	@GraymoundService(value="BNSPR_SYSTEM_LDAP_ADD_USER",authenticationRequired=false)
	public static GMMap addLDAPUser(GMMap iMap){
		logger.debug("[BNSPR_SYSTEM_LDAP_ADD_USER] starts..");
		GMMap oMap = new GMMap();
		try{

			ResourceBundle ldapProperties = ResourceBundle.getBundle(iMap.getString("LDAP_PROPERTY_FILE"));
			String oldUid = iMap.getString("OLD_UID");
			if(oldUid != null){
				oldUid = GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap).getString("PREFIX")+ oldUid;
			}
			
			String uid = GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap).getString("PREFIX") + iMap.getString("UID");
			String searchUid = oldUid!=null?oldUid:uid;
			
			String containerName  = ldapProperties.getString("ldap.containerName");
			String dn = "uid=" + searchUid + "," + containerName;      
			String searchFilter = "uid=" + searchUid;

			LDAPConnection lc = new LDAPConnection();
			// connect to the server
			lc.connect( ldapProperties.getString("ldap.server.host"), Integer.parseInt(ldapProperties.getString("ldap.server.port")) );
			// authenticate to the server
			lc.bind( LDAPConnection.LDAP_V3, ldapProperties.getString("ldap.authentication.dn"), ldapProperties.getString("ldap.authentication.password").getBytes() );

			LDAPSearchResults results = lc.search(containerName, LDAPConnection.SCOPE_ONE, searchFilter, null, false);
			if(results.hasMore()){
				List<LDAPModification> modificationList = new ArrayList<LDAPModification>();
				if(iMap.getString("CN") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("cn", iMap.getString("CN"))));
				if(iMap.getString("SN") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("sn", iMap.getString("SN"))));
				if(iMap.getString("GIVEN_NAME") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("givenName", iMap.getString("GIVEN_NAME"))));
				if(iMap.getString("MAIL") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("mail", iMap.getString("MAIL"))));
				if(iMap.getString("PASSWORD") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("userPassword", iMap.getString("PASSWORD"))));
				if(iMap.getString("AKUSTIK_ACCOUNT_CLOSE_DATE") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("akustikAccountCloseDate", iMap.getString("AKUSTIK_ACCOUNT_CLOSE_DATE"))));
				if(iMap.getString("INET_USER_STATUS") != null)
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("inetuserstatus", iMap.getString("INET_USER_STATUS"))));
				else
					modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("inetuserstatus", "Active")));
				
				
				LDAPModification[] modifications = modificationList.toArray(new LDAPModification[modificationList.size()]);
				lc.modify(dn, modifications);
				
				if (oldUid != null && !oldUid.equals(uid)) {
					String newRdn = "uid=" + uid;
					LDAPModifyDNRequest req = new LDAPModifyDNRequest(dn,newRdn,containerName,true,null);
					lc.sendRequest(req, null);
				}
				
				logger.info("LDAP kullan�c�s� g�ncellendi:" + dn +", pwdReset = " +iMap.getString("PWD_RESET") );
				
			}
			else{
				LDAPAttributeSet attributeSet = new LDAPAttributeSet();

				attributeSet.add( new LDAPAttribute("objectclass", ldapProperties.getString("ldap.objectclass").split(",")));
				attributeSet.add( new LDAPAttribute("uid", uid));
				attributeSet.add( new LDAPAttribute("cn", iMap.getString("CN")));   
				attributeSet.add( new LDAPAttribute("sn", iMap.getString("SN")));        
				if(iMap.getString("GIVEN_NAME") != null)
					attributeSet.add( new LDAPAttribute("givenName", iMap.getString("GIVEN_NAME")));
				if(iMap.getString("MAIL") != null)
					attributeSet.add( new LDAPAttribute("mail", iMap.getString("MAIL")));
				if(iMap.getString("PASSWORD") != null)
					attributeSet.add( new LDAPAttribute("userPassword", iMap.getString("PASSWORD")));
				if(iMap.getString("AKUSTIK_ACCOUNT_CLOSE_DATE") != null)
					attributeSet.add( new LDAPAttribute("akustikAccountCloseDate", iMap.getString("AKUSTIK_ACCOUNT_CLOSE_DATE")));
				attributeSet.add( new LDAPAttribute("inetUserStatus", (iMap.getString("INET_USER_STATUS")!=null) ? iMap.getString("INET_USER_STATUS") : ldapProperties.getString("ldap.inetUserStatus.default")));

				LDAPEntry newEntry = new LDAPEntry( dn, attributeSet );
				lc.add( newEntry );
				logger.info( "LDAP kullan�c�s� eklendi: " + dn  +", pwdReset = " +iMap.getString("PWD_RESET") );

			}
			
			// PWD_RESET isi en son islem olarak yapilmalidir.... 
			if(iMap.getString("PWD_RESET") != null) {

				results = lc.search(containerName, LDAPConnection.SCOPE_ONE, searchFilter, null, false);
				if(results.hasMore()){

					LDAPModification pwdResetModification = 
							new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("pwdReset", iMap.getString("PWD_RESET")));
									
					lc.modify(dn, new LDAPModification[]{pwdResetModification} );
					
					logger.info("LDAP kullan�c�s� guncellendi: " + dn +", PWD_REST " +iMap.getString("PWD_RESET") +" olarak set edildi...");
				}
			}
			

			// disconnect with the server
			lc.disconnect();

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		logger.debug("[BNSPR_SYSTEM_LDAP_ADD_USER] ends..");
		return oMap;
	}

	@GraymoundService(value="BNSPR_SYSTEM_IS_LDAP_USER",authenticationRequired=false)
	public static GMMap isLDAPUser(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			ResourceBundle ldapProperties = ResourceBundle.getBundle(iMap.getString("LDAP_PROPERTY_FILE"));
			
			String uid = GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap).getString("PREFIX") + iMap.getString("UID");
			String containerName  = ldapProperties.getString("ldap.containerName");

			LDAPConnection lc = new LDAPConnection();
			// connect to the server
			lc.connect( ldapProperties.getString("ldap.server.host"), Integer.parseInt(ldapProperties.getString("ldap.server.port")) );
			// authenticate to the server
			lc.bind( LDAPConnection.LDAP_V3, ldapProperties.getString("ldap.authentication.dn"), ldapProperties.getString("ldap.authentication.password").getBytes() );

			String searchFilter = "uid=" + uid;
			LDAPSearchResults results = lc.search(containerName, LDAPConnection.SCOPE_ONE, searchFilter, null, false);

			oMap.put("LDAP_USER", results.hasMore());

			// disconnect with the server
			lc.disconnect();

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_SYSTEM_LDAP_SET_USER_STATUS")
	public static GMMap inactiveLDAPUser(GMMap iMap){
		logger.debug("[BNSPR_SYSTEM_LDAP_SET_USER_STATUS] starts..");
		GMMap oMap = new GMMap();
		try{
			ResourceBundle ldapProperties = ResourceBundle.getBundle(iMap.getString("LDAP_PROPERTY_FILE"));

			String uid = GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap).getString("PREFIX") + iMap.getString("UID");
			String containerName  = ldapProperties.getString("ldap.containerName");
			String dn = "uid=" + uid + "," + containerName;      

			LDAPConnection lc = new LDAPConnection();
			// connect to the server
			lc.connect( ldapProperties.getString("ldap.server.host"), Integer.parseInt(ldapProperties.getString("ldap.server.port")) );
			// authenticate to the server
			lc.bind( LDAPConnection.LDAP_V3, ldapProperties.getString("ldap.authentication.dn"), ldapProperties.getString("ldap.authentication.password").getBytes() );

			String searchFilter = "uid=" + uid;
			LDAPSearchResults results = lc.search(containerName, LDAPConnection.SCOPE_ONE, searchFilter, null, false);

			if(results.hasMore()){
				List<LDAPModification> modificationList = new ArrayList<LDAPModification>();

				modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("inetUserStatus",iMap.getString("USER_STATUS"))));
				LDAPModification[] modifications = modificationList.toArray(new LDAPModification[1]);

				lc.modify(dn, modifications);
				logger.info("LDAP kullan�c�s� g�ncellendi:" + dn );
			}       
			// disconnect with the server
			lc.disconnect();

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		logger.debug("[BNSPR_SYSTEM_LDAP_SET_USER_STATUS] ends..");
		return oMap;
	}
	
	@GraymoundService("BNSPR_SYSTEM_LDAP_SET_USER_ALIAS")
	public static GMMap setLDAPUserAlias(GMMap iMap){
		logger.debug("[BNSPR_SYSTEM_LDAP_SET_USER_ALIAS] starts..");
		GMMap oMap = new GMMap();
		try{
			ResourceBundle ldapProperties = ResourceBundle.getBundle(iMap.getString("LDAP_PROPERTY_FILE"));

			String uid = GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap).getString("PREFIX") + iMap.getString("UID");
			String containerName  = ldapProperties.getString("ldap.containerName");
			String dn = "uid=" + uid + "," + containerName;      

			LDAPConnection lc = new LDAPConnection();
			// connect to the server
			lc.connect( ldapProperties.getString("ldap.server.host"), Integer.parseInt(ldapProperties.getString("ldap.server.port")) );
			// authenticate to the server
			lc.bind( LDAPConnection.LDAP_V3, ldapProperties.getString("ldap.authentication.dn"), ldapProperties.getString("ldap.authentication.password").getBytes() );

			String searchFilter = "uid=" + uid;
			LDAPSearchResults results = lc.search(containerName, LDAPConnection.SCOPE_ONE, searchFilter, null, false);

			if(results.hasMore()){
				List<LDAPModification> modificationList = new ArrayList<LDAPModification>();

				modificationList.add(new LDAPModification(LDAPModification.REPLACE, new LDAPAttribute("iplanet-am-user-alias-list",iMap.getString("USER_ALIAS"))));
				LDAPModification[] modifications = modificationList.toArray(new LDAPModification[1]);

				lc.modify(dn, modifications);
				logger.info("LDAP kullan�c�s� g�ncellendi:" + dn );
			}       
			// disconnect with the server
			lc.disconnect();

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		logger.debug("[BNSPR_SYSTEM_LDAP_SET_USER_STATUS] ends..");
		return oMap;
	}
	
	@GraymoundService(value="BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",authenticationRequired=false)
	public static GMMap getLDAPUserPrefix(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			ResourceBundle ldapProperties = ResourceBundle.getBundle(iMap.getString("LDAP_PROPERTY_FILE"));
			String prefix = null;
			try {
				prefix = ldapProperties.getString("ldap.username.prefix");
			} catch (MissingResourceException e) {
				oMap.put("PREFIX", "");
				oMap.put("PREFIX_SIZE", 0);
				return oMap;
			}
			prefix.trim();
			oMap.put("PREFIX", prefix);
			oMap.put("PREFIX_SIZE", prefix.length());
			return oMap;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_SYSTEM_LDAP_ADD_USER_DLR")
	public static GMMap addLDAPUserDLR(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_DLR");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER",iMap);
	}

	@GraymoundService("BNSPR_SYSTEM_LDAP_ADD_USER_INT")
	public static GMMap addLDAPUserINT(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_INT");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER",iMap);
	}
	
	@GraymoundService(value="BNSPR_SYSTEM_LDAP_ADD_USER_BNSPR",authenticationRequired=false)
	public static GMMap addLDAPUserBNSPR(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_BNSPR");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER",iMap);
	}

	@GraymoundService("BNSPR_SYSTEM_IS_LDAP_USER_DLR")
	public static GMMap isLDAPUserDLR(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_DLR");
		return GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER",iMap);
	}
	
	@GraymoundService("BNSPR_SYSTEM_IS_LDAP_USER_INT")
	public static GMMap isLDAPUserINT(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_INT");
		return GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER",iMap);
	}
	
	@GraymoundService(value="BNSPR_SYSTEM_IS_LDAP_USER_BNSPR",authenticationRequired=false)
	public static GMMap isLDAPUserBNSPR(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_BNSPR");
		return GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER",iMap);
	}

	@GraymoundService("BNSPR_SYSTEM_LDAP_SET_USER_ALIAS_INT")
	public static GMMap setLDAPUserAliasINT(GMMap iMap){
		GMMap sMap = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_INT",iMap);
		iMap.put("LDAP_PROPERTY_FILE","ldap_INT");
		if(sMap.getBoolean("LDAP_USER")){
			GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_SET_USER_ALIAS",iMap);
		}
		return new GMMap();
	}

	@GraymoundService("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_DLR")
	public static GMMap inactiveLDAPUserDLR(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_DLR");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_SET_USER_STATUS",iMap);
	}
	
	@GraymoundService("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_INT")
	public static GMMap inactiveLDAPUserINT(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_INT");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_SET_USER_STATUS",iMap);
	}

	@GraymoundService("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX_DLR")
	public static GMMap getLDAPUserPrefixDLR(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_DLR");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap);
	}
	
	@GraymoundService("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX_INT")
	public static GMMap getLDAPUserPrefixINT(GMMap iMap){
		iMap.put("LDAP_PROPERTY_FILE","ldap_INT");
		return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_GET_USER_PREFIX",iMap);
	}
	
}
