package tr.com.calikbank.bnspr.email;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.List;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.mail.util.ByteArrayDataSource;
import javax.naming.InitialContext;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.lob.ClobImpl;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhIslemMailGonder;
import tr.com.calikbank.bnspr.system.util.MimeTypesDetector;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class Mailer {
	public static final String TO_KEY_NAME = "RECIPIENTS_TO";
	public static final String CC_KEY_NAME = "RECIPIENTS_CC";
	public static final String BCC_KEY_NAME = "RECIPIENTS_BCC";
	/**
	 * Email g�nderen servis
	 * Sonraki versiyonlar�nda attachmentlar stream olarak da ge�ilebilecek
	 *
	 * <p/>SERVICE NAME: BNSPR_SYSTEM_MAIL_SEND_EMAIL
	 * <p/>INPUT:
	 * <ul>
	 * <li><b>FROM:String</b> g�nderen e-mail adresi</li>
	 * <li><b>RECIPIENTS_TO:List<String></b> Al�c� e-mail adresleri</li>
	 * <li><b>IS_BODY_HTML:boolean<String></b> Mail Body Text mi HTML mi</li>
	 * <li><b>SUBJECT:String<String></b> Mail Subject</li>
	 * <li><b>MESSAGE_BODY:String<String></b> Mail body</li>
	 * <li><b>ATTACMENT_FILE_LIST:List<HashMap<String,Object></b> Attach edilecek dosya listesi</li>
	 * <li><b>ATTACMENT_FILE_LIST:FILE_NAME</b> Attach edilecek dosyan�n ad�</li>
	 * <li><b>ATTACMENT_FILE_LIST:FILE_DIRECTORY</b> Attach edilecek dosyan�n bulundu�u directory pathi</li>
	 * </ul>
	 * <p/>OUTPUT:
	 * <ul>
	 * <li><b>None</li>
	 * </ul>
	 */
	
	@GraymoundService("BNSPR_SYSTEM_MAIL_SEND_EMAIL")
	public static GMMap sendMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session;
		try {
			boolean debug = false;
			session = (Session) new InitialContext().lookup(DALUtil.modifyJNDINameForAppServer("java:/Mail"));
			MimeMessage msg = new MimeMessage(session);
			session.setDebug(debug);

			//mesaj� g�nderen
			msg.setFrom(new InternetAddress(iMap.getString("FROM")));
			
			//al�c� email listesi
			if(iMap.containsKey(TO_KEY_NAME))
				msg.setRecipients(Message.RecipientType.TO, createRecipientArray(iMap, TO_KEY_NAME));
			if(iMap.containsKey(CC_KEY_NAME))
				msg.setRecipients(Message.RecipientType.CC, createRecipientArray(iMap, CC_KEY_NAME));
			if(iMap.containsKey(BCC_KEY_NAME))
				msg.setRecipients(Message.RecipientType.BCC, createRecipientArray(iMap, BCC_KEY_NAME));

			
			String attachmentFileTableName = "ATTACMENT_FILE_LIST"; 
			//List<?> attachmentFileList = (List<?>)iMap.get(attachmentFileTableName);
			boolean isBodyHtml = false; //default false
			if(iMap.containsKey("IS_BODY_HTML"))
				isBodyHtml = iMap.getBoolean("IS_BODY_HTML");

			String databaseAdi = GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", iMap).getString("DATABASE_ADI");
			String sistemAdi = GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", iMap).getString("SISTEM_ADI");
			msg.setSubject(iMap.getString("SUBJECT")+(iMap.getString("SUBJECT").contains(sistemAdi)?"":(databaseAdi.equals("PROD")?"":"("+sistemAdi+")")));

			String messageBody = iMap.getString("MESSAGE_BODY");
			
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			if (iMap.containsKey(attachmentFileTableName)){
				messageBodyPart.setContent(messageBody, isBodyHtml ? "text/html;charset=ISO-8859-9" : "text/plain;charset=ISO-8859-9");  
				boolean sendAttachmentWithoutDys = iMap.getBoolean("SEND_ATTACHMENT_WITHOUT_DYS", false);
				for (int i = 0; i < iMap.getSize(attachmentFileTableName); i++) {
					if (sendAttachmentWithoutDys) {
						String fileName = iMap.getString(attachmentFileTableName, i, "FILE_NAME");
						byte[] data = (byte[]) iMap.get(attachmentFileTableName, i, "FILE_BYTE_ARRAY");
						multipart.addBodyPart(getAttachmentBodyPart(data, fileName));
					} else {
						String fileName = iMap.getString(attachmentFileTableName, i, "DMS_FILE_NAME");
						GMMap dysMap = new GMMap();
						dysMap.put("FILE_NAME", fileName);
						dysMap.put("MAIL_ID", iMap.getString("DMS_FOLDER_NAME"));
						byte[] data = (byte[]) GMServiceExecuter.call("DYS_CMIS_GET_MAIL_ATTACHMENT_AS_BYTEARRAY", dysMap).get("FILE_BYTE_ARRAY");
						multipart.addBodyPart(getAttachmentBodyPart(data, fileName));
					}
				}
				msg.setContent(multipart);
			} else {
				msg.setContent(messageBody, isBodyHtml ? "text/html;charset=ISO-8859-9" : "text/plain;charset=ISO-8859-9");
			}

			Transport.send(msg);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	private static MimeBodyPart getAttachmentBodyPart(byte[] data, String fileName) throws MessagingException, UnsupportedEncodingException{
		MimeBodyPart attachmentBodypart = new MimeBodyPart();
		ByteArrayDataSource byteArrayDataSource = new ByteArrayDataSource(data, MimeTypesDetector.getMime(FilenameUtils.getExtension(fileName)));
		attachmentBodypart.setDataHandler(new DataHandler(byteArrayDataSource));
		attachmentBodypart.setFileName(MimeUtility.encodeText(fileName));
		return attachmentBodypart;
	}
	
	private static InternetAddress[] createRecipientArray(GMMap iMap, String listName) throws AddressException{
		List<?> recipientsList = (List<?>)iMap.get(listName);
		InternetAddress[] addressess = new InternetAddress[recipientsList.size()];
		for (int i = 0; i < recipientsList.size(); i++) {
			addressess[i] = new InternetAddress((String)recipientsList.get(i));
		}
		return addressess;
	}
	
	public static final String ATTACHMENT_KEY = "MAIL_ATTACHMENT_LIST";
	public static final String MAIL_ATTACHMENT_ROOT_DIR = "MAIL_ATTACHMENTS";
	
	@GraymoundService("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL")
	public static GMMap sendAsynchronousMail(GMMap iMap) {
		try {			
			org.hibernate.Session session = DAOSession.getSession("BNSPRDal");
		    MuhIslemMailGonder muhIslemMailGonder = new MuhIslemMailGonder();
		    iMap.put("TABLE_NAME", "MAIL_ID");
		    String mailIdStr = GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap).get("ID").toString();
		    muhIslemMailGonder.setMailId(new BigDecimal(mailIdStr));
		    muhIslemMailGonder.setTxNo(iMap.getBigDecimal("TRX_NO"));
		    muhIslemMailGonder.setMailFrom(iMap.getString("MAIL_FROM"));
		    muhIslemMailGonder.setMailTo(iMap.getString("MAIL_TO"));
		    muhIslemMailGonder.setMailCc(iMap.getString("MAIL_CC"));
		    muhIslemMailGonder.setMailBcc(iMap.getString("MAIL_BCC"));

			String databaseAdi = GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", iMap).getString("DATABASE_ADI");
			String sistemAdi = GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", iMap).getString("SISTEM_ADI");

		    muhIslemMailGonder.setMailSubject(iMap.getString("MAIL_SUBJECT")+(iMap.getString("MAIL_SUBJECT").contains(sistemAdi)?"":(databaseAdi.equals("PROD")?"":"("+sistemAdi+")")));
		    muhIslemMailGonder.setMailBody(iMap.getString("MAIL_BODY"));
		    muhIslemMailGonder.setBodyHtmlEh(iMap.getString("IS_BODY_HTML"));
		    muhIslemMailGonder.setMailBody2(iMap.getString("MAIL_BODY2"));
		    muhIslemMailGonder.setMailBody3(iMap.getString("MAIL_BODY3"));
		    muhIslemMailGonder.setMailBody4(iMap.getString("MAIL_BODY4"));
		    muhIslemMailGonder.setMailBody5(iMap.getString("MAIL_BODY5"));
		    muhIslemMailGonder.setMailBodyClob((iMap.getString("MAIL_BODY_CLOB") != null ) ? new ClobImpl(iMap.getString("MAIL_BODY_CLOB")) : new ClobImpl(""));
		    
		    StringBuilder sb = new StringBuilder();
		    if(iMap.containsKey(ATTACHMENT_KEY)){
		    	for (int i = 0; i < iMap.getSize(ATTACHMENT_KEY); i++) {
		    		GMMap servisMap = new GMMap();
		    		
		    		servisMap.put("FILE_NAME"		, iMap.getString(ATTACHMENT_KEY, i, "FILE_NAME"));
		    		servisMap.put("MAIL_ID"			, mailIdStr);
		    		servisMap.put("MAIL_TX_NO"		, iMap.getBigDecimal("TRX_NO"));
		    		servisMap.put("MAIL_FROM"		, iMap.getString("MAIL_FROM"));
		    		servisMap.put("MAIL_TO"			, iMap.getString("MAIL_TO"));
		    		servisMap.put("MAIL_CC"			, iMap.getString("MAIL_CC"));
		    		servisMap.put("MAIL_BCC"		, iMap.getString("MAIL_BCC"));
		    		servisMap.put("MAIL_SUBJECT"	, iMap.getString("MAIL_SUBJECT"));
		    		servisMap.put("FILE_BYTE_ARRAY"	, iMap.get(ATTACHMENT_KEY, i, "FILE_CONTENT"));
					GMServiceExecuter.execute("DYS_CMIS_CREATE_OR_UPDATE_MAIL_ATTACHMENT",servisMap);

					sb.append(iMap.getString(ATTACHMENT_KEY, i, "FILE_NAME")).append(";");
				}
		    }
		    muhIslemMailGonder.setFileName(sb.toString());
		    session.save(muhIslemMailGonder);
		    session.flush();
			return new GMMap().put("MAIL_ID", mailIdStr);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
