package tr.com.calikbank.bnspr.pos.services;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PosUtils {
	/**
	 * Hatal� pos tipi g�nderilmesi durumunda g�sterilecek mesaj.
	 * @param posType
	 * @return
	 */
	protected static String getWrongPosTypeErrorMessage(String posType){
		return String.format("Pos tipi(%s) bilgisi hatal�. Kontrol edip tekrar deneyin.", posType);
	}
	
	/**
	 * Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.
	 * @param iMap
	 * @return posType
	 */
	protected static String checkPosType(GMMap iMap){
		if (iMap.containsKey("POS_TYPE") && !StringUtils.isBlank(iMap.getString("POS_TYPE"))) {
			return iMap.getString("POS_TYPE");
		} else {
			return GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", AkustikConstants.GLOBAL_POS_PARAM_KEY)).getString("DEGER");
		}
	}
	
	protected static String maskCCNumber(String kartNo) {
		String maskedKartNo = kartNo;
		if (!StringUtil.isEmpty(maskedKartNo) && maskedKartNo.length() >= 16) {
			maskedKartNo = kartNo.substring(0, 4) + "********" + kartNo.subSequence(12, 16);
		}
		return maskedKartNo;
	}
	
	protected static boolean throwException(GMMap iMap){
		return ( !iMap.containsKey("THROW_EXCEPTION") || iMap.getBoolean("THROW_EXCEPTION") );
	}
}
