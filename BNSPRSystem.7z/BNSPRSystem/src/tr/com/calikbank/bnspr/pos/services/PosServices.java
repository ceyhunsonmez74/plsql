package tr.com.calikbank.bnspr.pos.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.dao.GnlPosAktifposLog;
import tr.com.aktifbank.bnspr.dao.GnlPosChannelClientRel;
import tr.com.aktifbank.bnspr.dao.GnlPosHb3dPaymentLog;
import tr.com.aktifbank.bnspr.dao.GnlPosPaymentLog;
import tr.com.aktifbank.bnspr.dao.GnlPosVbPaymentLog;
import tr.com.aktifbank.integration.aktifpos.AktifPosClient;
import tr.com.aktifbank.integration.garantipos.PaymentResponse;
import tr.com.aktifbank.integration.garantipos.PosClient;
import tr.com.aktifbank.integration.hbpos.HBPosClient;
import tr.com.aktifbank.integration.vbpos.VBPosClient;
import tr.com.aktifbank.integration.vbpos.VBPosRequest;
import tr.com.aktifbank.integration.vbpos.VBPosResponse;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.est.jpay;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class PosServices {

	private static Logger logger = Logger.getLogger(PosServices.class);
	
	private static final String POS_COMMON_ERR_MSG = "��leminiz ger�ekle�tirilememektedir. L�tfen bilgilerinizi kontrol ederek tekrar deneyiniz.";
		
	/**	 
	 * AKTIFPOS VIZE
	 * If OrderId element is not sent, the system will generate an unique OrderId and sent the id back in response message.
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-NUMBER, 
	 * 			-EXPIRES, 
	 * 			-CVV2VAL,  
	 * 			-TOTAL,  
	 * 			-CURRENCY, 
	 * @return oMap
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-RESPONSE(Approved, Declined, Error), 
	 * 			-AUTH_CODE, 
	 * 			-HOST_REF_NUM, 
	 * 			-PROC_RETURN_CODE(onayl� i�lem i�in = 00, �deme ge�iti hatalar� i�in = 99, di�er t�m kodlar ISO-8583 hata kodlar� 
	 * 			-TRANS_ID, 
	 * 			-ERR_MSG, 
	 * 			-CARDTYPE, 
	 * 			-Extra(Map)
	 * 				-SETTLEID, 
	 * 				-TRXDATE, 
	 * 				-ERRORCODE, 
	 * 				-AVANS_PUAN, 
	 * 				-ODUL, 
	 * 				-NUMCODE, 
	 * 				-CAVV_RESULT_CODE
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_VIZE")
	public static GMMap aktifPosDoVize(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {
			posType = PosUtils.checkPosType(iMap);
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.vize(iMap);
			}else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
//			not implemented
//			else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
//			} 
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " VIZE");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			iMap.put("NUMBER", PosUtils.maskCCNumber(iMap.getString("NUMBER"))); //mask cc number
			logMap.put("INPUTS",iMap.toString());
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	/**	 
	 * AKTIFPOS PAYMENT
	 * If OrderId element is not sent, the system will generate an unique OrderId and sent the id back in response message.
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-NUMBER, 
	 * 			-EXPIRES, 
	 * 			-CVV2VAL,  
	 * 			-TOTAL,  
	 * 			-CURRENCY, 
	 * @return oMap
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-RESPONSE(Approved, Declined, Error), 
	 * 			-AUTH_CODE, 
	 * 			-HOST_REF_NUM, 
	 * 			-PROC_RETURN_CODE(onayl� i�lem i�in = 00, �deme ge�iti hatalar� i�in = 99, di�er t�m kodlar ISO-8583 hata kodlar� 
	 * 			-TRANS_ID, 
	 * 			-ERR_MSG, 
	 * 			-CARDTYPE, 
	 * 			-Extra(Map)
	 * 				-SETTLEID, 
	 * 				-TRXDATE, 
	 * 				-ERRORCODE, 
	 * 				-AVANS_PUAN, 
	 * 				-ODUL, 
	 * 				-NUMCODE, 
	 * 				-CAVV_RESULT_CODE
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_PAYMENT")
	public static GMMap aktifPosDoPayment(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {
			posType = PosUtils.checkPosType(iMap);
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.payment(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.payment(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}

			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " PAYMENT");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			iMap.put("NUMBER", PosUtils.maskCCNumber(iMap.getString("NUMBER"))); //mask cc number
			logMap.put("INPUTS",iMap.toString());
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	/**	 
	 * AKTIFPOS PREAUTH
	 * If OrderId element is not sent, the system will generate an unique OrderId and sent the id back in response message.
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-NUMBER, 
	 * 			-EXPIRES, 
	 * 			-CVV2VAL, 
	 * 			-CURRENCY, 
	 * @return oMap
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-RESPONSE(Approved, Declined, Error), 
	 * 			-AUTH_CODE, 
	 * 			-HOST_REF_NUM, 
	 * 			-PROC_RETURN_CODE(onayl� i�lem i�in = 00, �deme ge�iti hatalar� i�in = 99, di�er t�m kodlar ISO-8583 hata kodlar� 
	 * 			-TRANS_ID, 
	 * 			-ERR_MSG,
	 * 			-CARDTYPE,  
	 * 			-Extra(Map)
	 * 				-SETTLEID, 
	 * 				-TRXDATE, 
	 * 				-ERRORCODE, 
	 * 				-AVANS_PUAN, 
	 * 				-ODUL, 
	 * 				-NUMCODE, 
	 * 				-CAVV_RESULT_CODE
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_PREAUTH")
	public static GMMap aktifPosDoPreauth(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {
			posType = PosUtils.checkPosType(iMap);			
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.preAuth(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.preAuth(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
			
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " PREAUTH");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			iMap.put("NUMBER", PosUtils.maskCCNumber(iMap.getString("NUMBER"))); //mask cc number
			logMap.put("INPUTS",iMap.toString());
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	/**	 
	 * AKTIFPOS POSTAUTH
	 * OrderId needs to be set which order the postauthorization is for. Partial postauthorization is supported: 
	 * The postauthorization amount can be lower then the preauthorization amount.
	 * 
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-CURRENCY(opt.), 
	 * 			-TOTAL(opt.),
	 * @return oMap
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-RESPONSE(Approved, Declined, Error), 
	 * 			-AUTH_CODE, 
	 * 			-HOST_REF_NUM, 
	 * 			-PROC_RETURN_CODE(onayl� i�lem i�in = 00, �deme ge�iti hatalar� i�in = 99, di�er t�m kodlar ISO-8583 hata kodlar� 
	 * 			-TRANS_ID, 
	 * 			-ERR_MSG,
	 * 			-CARDTYPE,  
	 * 			-Extra(Map)
	 * 				-SETTLEID, 
	 * 				-TRXDATE, 
	 * 				-ERRORCODE, 
	 * 				-AVANS_PUAN, 
	 * 				-ODUL, 
	 * 				-NUMCODE, 
	 * 				-CAVV_RESULT_CODE
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_POSTAUTH")
	public static GMMap aktifPosDoPostauth(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {
			logMap.put("INPUTS",iMap.toString());
			posType = PosUtils.checkPosType(iMap);		
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.postAuth(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.postAuth(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
			
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " POSTAUTH");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	/**	 
	 * AKTIFPOS REFUND
	 * OrderId needs to be set which order the refund is for. Multiple partial refunds are supported: 
	 * You can make as many partial refunds until the original sale amount is not exceeded.
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-CURRENCY, 
	 * 			-TOTAL,
	 * @return oMap
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-RESPONSE(Approved, Declined, Error), 
	 * 			-AUTH_CODE, 
	 * 			-HOST_REF_NUM, 
	 * 			-PROC_RETURN_CODE(onayl� i�lem i�in = 00, �deme ge�iti hatalar� i�in = 99, di�er t�m kodlar ISO-8583 hata kodlar� 
	 * 			-TRANS_ID, 
	 * 			-ERR_MSG, 
	 * 			-CARDTYPE, 
	 * 			-Extra(Map)
	 * 				-SETTLEID, 
	 * 				-TRXDATE, 
	 * 				-ERRORCODE, 
	 * 				-AVANS_PUAN, 
	 * 				-ODUL, 
	 * 				-NUMCODE, 
	 * 				-CAVV_RESULT_CODE
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_REFUND")
	public static GMMap aktifPosDoRefund(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {			
			logMap.put("INPUTS",iMap.toString());
			posType = PosUtils.checkPosType(iMap);		
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.refund(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.refund(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
			
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " REFUND");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	/**	 
	 * AKTIFPOS VOID
	 * Either orderId or transId needs to be set which order the void is for. If transId is set, the transaction with the transId will be voided. 
	 * If orderId is set, the successful transaction within the order will be searched and voided. 
	 * If there are multiple successful transactions for the order (such as multiple refunds) the system will return an error.
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 			-GROUP_ID, 
	 * 	  		-ORDER_ID, 
	 * 			-TRANS_ID,
	 * 			-EXTRA(opt.)
	 * @return oMap
	 * 			-ORDER_ID, 
	 * 			-GROUP_ID, 
	 * 			-RESPONSE(Approved, Declined, Error), 
	 * 			-AUTH_CODE, 
	 * 			-HOST_REF_NUM, 
	 * 			-PROC_RETURN_CODE(onayl� i�lem i�in = 00, �deme ge�iti hatalar� i�in = 99, di�er t�m kodlar ISO-8583 hata kodlar� 
	 * 			-TRANS_ID, 
	 * 			-ERR_MSG, 
	 * 			-CARDTYPE, 
	 * 			-Extra(Map)
	 * 				-SETTLEID, 
	 * 				-TRXDATE, 
	 * 				-ERRORCODE, 
	 * 				-AVANS_PUAN, 
	 * 				-ODUL, 
	 * 				-NUMCODE, 
	 * 				-CAVV_RESULT_CODE
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_VOID")
	public static GMMap aktifPosDoVoid(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {			
			logMap.put("INPUTS",iMap.toString());
			posType = PosUtils.checkPosType(iMap);		
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.voidType(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.voidType(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
			
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " VOID");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	
	/**	 
	 * AKTIFPOS ORDER STATUS
	 * Sipari� Durum Sorgulama, sat��, iade, iptal, �n otorizasyon, �n otorizasyon kapama,
	 *	ba��ms�z iade i�lem tipleri i�in yap�labilir. �deme ge�idi ve banka sisteminde hi� bir �eyi de�i�tirmez.
	 *	Finansal bir anlam� yoktur. Sipari�in durumunu d�ner.
 	 *	Sipari�in birden fazla i�lemi olabilir. Bu sebeple, sorgulama sonucundaki �OrderStatus�
	 *	alan�nda sipari�e ait son ba�ar�l� i�lemin durumu yer al�r. E�er sipari�e ait hi� ba�ar�l� i�lem yoksa,
	 *	�OrderStatus� alan�ndaki de�er, sipari�e ait son ba�ar�s�z i�lemin durumunu g�sterir.
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 	  		-ORDER_ID
	 * @return oMap
	 *	<ErrMsg>Hata mesaj�</ErrMsg>
 	 *	<ProcReturnCode>��lem durum kodu</ProcReturnCode>
	 *	<Response>{Approved, Error}</Response>
	 *	<OrderId>Sipari� numaras�</OrderId>
	 *	<TransId>��lem numaras�</TransId>
	 *	<Extra>
	 *		<AUTH_DTTM>�n otorizasyon tarihi</AUTH_DTTM>
	 *		<HOSTDATE>Banka onay tarihi</HOSTDATE>
	 *		<TRANS_STAT>��lem durumu</TRANS_STAT>
	 *		<ORDERSTATUS>ORD_ID:OrderId
	 *			CHARGE_TYPE_CD:TransactionTtype
	 *			ORIG_TRANS_AMT:FirstAmount
	 *			CAPTURE_AMT:TransactionAmount
	 *			TRANS_STAT:TransactionStatus
	 *			AUTH_DTTM:AuthorizationTime
	 *			CAPTURE_DTTM:DepositTime AUTH_CODE:118889
	 *			TRANS_ID:TransactionId
	 *			�YE �� YER� ENTEGRASYON DOK�MANI
	 *		</ORDERSTATUS>
	 *		<ORIG_TRANS_AMT>�lk tutar</ORIG_TRANS_AMT>
	 *		<PROC_RET_CD>Banka onay kodu</PROC_RET_CD>
	 *		<CAPTURE_AMT>i�lem tutar�</CAPTURE_AMT>
	 *		<HOST_REF_NUM>Banka referans numaras�</HOST_REF_NUM>
	 *		<SETTLEID>G�n sonu numaras�</SETTLEID>
	 *		<TRANS_ID>i�lem numaras�</TRANS_ID>
	 *		<ORD_ID>Sipari� numaras�</ORD_ID>
	 *		<CHARGE_TYPE_CD>��lem Tipi</CHARGE_TYPE_CD>
	 *		<AUTH_CODE>Banka onay kodu</AUTH_CODE>
	 *		<NUMCODE>N�merik hata kodu</NUMCODE>
	 *		<CAPTURE_DTTM>�n otorizasyon kapama tarihi</CAPTURE_DTTM>
	 *	</Extra>
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_GET_ORDER_STATUS")
	public static GMMap aktifPosGetOrderStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {
			logMap.put("INPUTS",iMap.toString());
			posType = PosUtils.checkPosType(iMap);		
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.getOrderStatus(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.getOrderStatus(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
			
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " GET ORDER STATUS");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	/**	 
	 * AKTIFPOS ORDER HISTORY
	 *	�ye i� yeri sipari�e ait i�lemlerin durumlar�n� sorgulayabilir. Sipari�e ait bir iade var m�?
	 *	Sipari� ya da iadesi ba�ar�l� m�? Gibi...
	 * 
	 * @param iMap
	 * 			-POS_TYPE (Opsiyonel - Pos tipi g�nderilmezse global parametrede tan�ml� olan sanalpos kullan�l�r.)
	 * 			-CHANNEL,
	 * 			-NAME,
	 * 			-PASSWORD,
	 * 			-CLIENT_ID,
	 * 	  		-ORDER_ID
	 * @return oMap
	 *	<CC5Response>
	 *		<ErrMsg>Error message</ErrMsg>
	 *		<ProcReturnCode>��lem durum kodu</ProcReturnCode>
	 *		<Response>{Approved, Error}</Response>
	 *		<OrderId>Sipari� numaras�</OrderId>
	 *		<Extra>
	 *	 		<TRXCOUNT>Transaction count</TRXCOUNT>
	 *			<TRXLIST>tab-separeted transaction list</TRX_LIST>
	 *			<NUMCODE>0</NUMCODE>
	 *		</Extra>
	 *	</CC5Response>
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_GET_ORDER_HISTORY")
	public static GMMap aktifPosGetOrderHistory(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap logMap = new GMMap();
		long startTimeinMillis = System.currentTimeMillis();
		String posType = null;
		try {
			posType = PosUtils.checkPosType(iMap);	
			logMap.put("INPUTS",iMap.toString());
			if (AkustikConstants.AKTIFBANK_VPOS.equals(posType)) {
				oMap = AktifPosClient.getOrderHistory(iMap);
			} else if (AkustikConstants.HALKBANK_VPOS.equals(posType)) {
				oMap = HBPosClient.getOrderHistory(iMap);
			} else {
				throw new GMRuntimeException(0, PosUtils.getWrongPosTypeErrorMessage(posType));
			}
			
			logMap.put("RESPONSE",oMap.toString());
			logMap.put("HATA_KOD", "2");
			logMap.put("HATA", "");
		} catch (Exception e) {
			logMap.put("HATA_KOD", "0");
			logMap.put("HATA", e.getMessage());
			throw ExceptionHandler.convertException(e);
		} finally {
			long endTimeInMillis = System.currentTimeMillis();
			logMap.put("METHOD_NAME", posType + " GET ORDER HISTORY");
			logMap.put("CHANNEL", iMap.getString("CHANNEL"));
			iMap.put("PASSWORD", "*"); //mask password
			logAktifPos(logMap, startTimeinMillis, endTimeInMillis);
		}
		return oMap;
	}
	
	
	///////**************************** GARANTI ************************************ ////////////////////
	
	/**
	 * 
	 * @param iMap
	 *            -KART_NO -KART_SON_KULLANMA -KART_GUVENLIK -ODEME_TUTARI
	 *            -ACIKLAMA -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB
	 *            M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi
	 *            sa�lanmal�d�r, loglama amacli) -TX_NO (Transactional bir
	 *            i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_DO_PAYMENT")
	public static GMMap posDoPayment(GMMap iMap) {
		GMMap oMap = new GMMap();
		PaymentResponse paymentResponse = null;
		try {

			String bundleName = iMap.getString("CONFIG_FILE", "garanti-pos");
			ResourceBundle properties = ResourceBundle.getBundle(bundleName);

			PosClient posClient = new PosClient();
			paymentResponse = posClient.pay( properties.getString("version"), 
											 properties.getString("mode"), 
											 properties.getString("host"), 
											 properties.getString("provUserId"), 
											 properties.getString("userId"), 
											 properties.getString("terminalId"), 
											 properties.getString("merchantId"), 
											 properties.getString("password"), 
											 iMap.getString("KART_NO"), 
											 iMap.getString("KART_GUVENLIK"), 
											 iMap.getString("KART_SON_KULLANMA"), 
											 iMap.getBigDecimal("ODEME_TUTARI").doubleValue(), 
											 properties.getString("currency"), 
											 iMap.getString("ACIKLAMA", ""), 
											 ADCSession.getString("CLIENT_IP"));

			if ( PosUtils.throwException(iMap) ) { // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
				if (!"00".equals(paymentResponse.getReasonCode())) // procReturnCode 00 ise i�lem basarilidir
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMMap logMap = new GMMap();
			logMap.put("ODEME_TUTARI", iMap.getBigDecimal("ODEME_TUTARI"));
			logMap.put("KART_NO", iMap.getString("KART_NO"));
			logMap.put("KART_GUVENLIK", iMap.getString("KART_GUVENLIK"));
			logMap.put("KART_SON_KULLANMA", iMap.getString("KART_SON_KULLANMA"));
			logMap.put("SOURCE", iMap.getString("SOURCE"));
			logMap.put("TX_NO", iMap.getBigDecimal("TX_NO"));
			logMap.put("ORDER_ID", paymentResponse.getOrderId()); // Siparis No
			logMap.put("AUTH_CODE", paymentResponse.getAuthCode()); // Provizyon No
			logMap.put("RESPONSE", paymentResponse.getMessage()); // Approved,Declined ya da Error
			logMap.put("REF_NUM", paymentResponse.getRetRefNum()); // Referans No
			logMap.put("RETURN_CODE", paymentResponse.getReasonCode()); // Bankadan gelen islem kodu
			logMap.put("ERR_MSG", (paymentResponse.getSysErrorMsg() == null ? "" : paymentResponse.getSysErrorMsg()) + (paymentResponse.getErrorMsg() == null ? "" : ("#" + paymentResponse.getErrorMsg()))); // Hata A��klama
			logMap.put("TRANS_TYPE", "sales");
			GMServiceExecuter.executeNT("BNSPR_POS_PAYMENT_LOG", logMap);

			oMap.put("ORDER_ID", paymentResponse.getOrderId());
			oMap.put("AUTH_CODE", paymentResponse.getAuthCode());
			oMap.put("RESPONSE", paymentResponse.getMessage());
			oMap.put("REF_NUM", paymentResponse.getRetRefNum());
			oMap.put("RETURN_CODE", paymentResponse.getReasonCode());
			oMap.put("SYS_ERR_MSG", paymentResponse.getSysErrorMsg());
			oMap.put("ERR_MSG", paymentResponse.getErrorMsg());
		}
		return oMap;
	}

	/**
	 * 
	 * @param iMap
	 * 		-KART_NO
	        -KART_SON_KULLANMA
	        -KART_GUVENLIK
	        -ODEME_TUTARI
	        -ACIKLAMA
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi sa�lanmal�d�r, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_DO_PREAUTH")
	public static GMMap posDoPreAuth(GMMap iMap){
		GMMap oMap = new GMMap();
		PaymentResponse paymentResponse = null;
		try{
			
			String bundleName = iMap.getString("CONFIG_FILE", "garanti-pos");
			ResourceBundle properties = ResourceBundle.getBundle(bundleName);


			PosClient posClient = new PosClient();
			paymentResponse = posClient.preAuth( properties.getString("version"), 
						   					 properties.getString("mode"), 
											 properties.getString("host"), 
											 properties.getString("provUserId"), 
											 properties.getString("userId"), 
											 properties.getString("terminalId"), 
											 properties.getString("merchantId"), 
											 properties.getString("password"),
											 iMap.getString("KART_NO"), 
											 iMap.getString("KART_GUVENLIK"), 
											 iMap.getString("KART_SON_KULLANMA"), 
											 iMap.getBigDecimal("ODEME_TUTARI").doubleValue(), 
											 properties.getString("currency"), 
											 iMap.getString("ACIKLAMA", ""),
											 ADCSession.getString("CLIENT_IP"));

			if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
				if(!"00".equals(paymentResponse.getReasonCode())) //procReturnCode 00 ise i�lem ba�ar�l�d�r
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
			}	
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMMap logMap = new GMMap();
			logMap.put("ODEME_TUTARI"		, iMap.getBigDecimal("ODEME_TUTARI"));
			logMap.put("KART_NO"			, iMap.getString("KART_NO"));
			logMap.put("KART_GUVENLIK"		, iMap.getString("KART_GUVENLIK"));
			logMap.put("KART_SON_KULLANMA"	, iMap.getString("KART_SON_KULLANMA"));
			logMap.put("SOURCE"				, iMap.getString("SOURCE"));
        	logMap.put("TX_NO"				, iMap.getBigDecimal("TX_NO"));
        	logMap.put("ORDER_ID" 			, paymentResponse.getOrderId());		// Siparis No
        	logMap.put("AUTH_CODE" 			, paymentResponse.getAuthCode());		// Provizyon No
        	logMap.put("RESPONSE" 			, paymentResponse.getMessage());		// Approved,Declined ya da Error
        	logMap.put("REF_NUM" 			, paymentResponse.getRetRefNum());		// Referans No
        	logMap.put("RETURN_CODE" 		, paymentResponse.getReasonCode());		// Bankadan gelen islem kodu
        	logMap.put("ERR_MSG" 			, ( paymentResponse.getSysErrorMsg() ==null ? "" : paymentResponse.getSysErrorMsg() )
        									+ ( paymentResponse.getErrorMsg() ==null ? "" : ("#" + paymentResponse.getErrorMsg()) ) );		// Hata A��klama
        	logMap.put("TRANS_TYPE", 		"preauth");
        	GMServiceExecuter.executeNT("BNSPR_POS_PAYMENT_LOG", logMap);
        	
        	oMap.put("ORDER_ID"		, paymentResponse.getOrderId());
        	oMap.put("AUTH_CODE"	, paymentResponse.getAuthCode());
        	oMap.put("RESPONSE"		, paymentResponse.getMessage());
        	oMap.put("REF_NUM"		, paymentResponse.getRetRefNum());
        	oMap.put("RETURN_CODE"	, paymentResponse.getReasonCode());
        	oMap.put("SYS_ERR_MSG"	, paymentResponse.getSysErrorMsg());
        	oMap.put("ERR_MSG"		, paymentResponse.getErrorMsg());
		}
		return oMap;
	}

	/**
	 * 
	 * @param iMap
	 * 		-KART_NO
	        -KART_SON_KULLANMA
	       	-KART_GUVENLIK 
	       	-ORDER_ID
	        -ACIKLAMA
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi sa�lanmal�d�r, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_DO_CANCEL")
	public static GMMap posDoCancel(GMMap iMap){
		GMMap oMap = new GMMap();
		PaymentResponse paymentResponse = null;
		try{
			
			String bundleName = iMap.getString("CONFIG_FILE", "garanti-pos");
			ResourceBundle properties = ResourceBundle.getBundle(bundleName);

			PosClient posClient = new PosClient();
			paymentResponse = posClient.cancel( properties.getString("version"), 
						   					 properties.getString("mode"), 
											 properties.getString("host"), 
											 properties.getString("provUserId"), 
											 properties.getString("userId"), 
											 properties.getString("terminalId"), 
											 properties.getString("merchantId"), 
											 properties.getString("password"),
											 iMap.getString("KART_NO"), 
											 iMap.getString("KART_GUVENLIK"), 
											 iMap.getString("KART_SON_KULLANMA"),
											 iMap.getString("ORDER_ID"),
											 new BigDecimal(0).doubleValue(), 
											 properties.getString("currency"), 
											 iMap.getString("ACIKLAMA", ""),
											 ADCSession.getString("CLIENT_IP"));

			if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
				if(!"00".equals(paymentResponse.getReasonCode())) //procReturnCode 00 ise i�lem ba�ar�l�d�r
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
			}	
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMMap logMap = new GMMap();
			logMap.put("ODEME_TUTARI"		, iMap.getBigDecimal("ODEME_TUTARI"));
			logMap.put("KART_NO"			, iMap.getString("KART_NO"));
			logMap.put("KART_GUVENLIK"		, iMap.getString("KART_GUVENLIK"));
			logMap.put("KART_SON_KULLANMA"	, iMap.getString("KART_SON_KULLANMA"));
			logMap.put("SOURCE"				, iMap.getString("SOURCE"));
        	logMap.put("TX_NO"				, iMap.getBigDecimal("TX_NO"));
        	logMap.put("ORDER_ID" 			, iMap.getString("ORDER_ID"));		// Siparis No
        	logMap.put("AUTH_CODE" 			, paymentResponse.getAuthCode());		// Provizyon No
        	logMap.put("RESPONSE" 			, paymentResponse.getMessage());		// Approved,Declined ya da Error
        	logMap.put("REF_NUM" 			, paymentResponse.getRetRefNum());		// Referans No
        	logMap.put("RETURN_CODE" 		, paymentResponse.getReasonCode());		// Bankadan gelen islem kodu
        	logMap.put("ERR_MSG" 			, ( paymentResponse.getSysErrorMsg() ==null ? "" : paymentResponse.getSysErrorMsg() )
        									+ ( paymentResponse.getErrorMsg() ==null ? "" : ("#" + paymentResponse.getErrorMsg()) ) );		// Hata A��klama
        	logMap.put("TRANS_TYPE", 		"void");
        	GMServiceExecuter.executeNT("BNSPR_POS_PAYMENT_LOG", logMap);
        	
        	oMap.put("ORDER_ID"		, paymentResponse.getOrderId());
        	oMap.put("AUTH_CODE"	, paymentResponse.getAuthCode());
        	oMap.put("RESPONSE"		, paymentResponse.getMessage());
        	oMap.put("REF_NUM"		, paymentResponse.getRetRefNum());
        	oMap.put("RETURN_CODE"	, paymentResponse.getReasonCode());
        	oMap.put("SYS_ERR_MSG"	, paymentResponse.getSysErrorMsg());
        	oMap.put("ERR_MSG"		, paymentResponse.getErrorMsg());
		}
		return oMap;
	}

	/**
	 * 
	 * @param iMap
	 * 		-KART_NO
	        -KART_SON_KULLANMA
	       	-KART_GUVENLIK 
	        -ACIKLAMA
	       	-ORDER_ID	        
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi sa�lanmal�d�r, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_DO_REFUND")
	public static GMMap posDoRefund(GMMap iMap){
		GMMap oMap = new GMMap();
		PaymentResponse paymentResponse = null;
		try{
			
			String bundleName = iMap.getString("CONFIG_FILE", "garanti-pos");
			ResourceBundle properties = ResourceBundle.getBundle(bundleName);

			PosClient posClient = new PosClient();
			paymentResponse = posClient.refund( properties.getString("version"), 
						   					 properties.getString("mode"), 
											 properties.getString("host"), 
											 properties.getString("provUserId"), 
											 properties.getString("userId"), 
											 properties.getString("terminalId"), 
											 properties.getString("merchantId"), 
											 properties.getString("password"),
											 iMap.getString("KART_NO"), 
											 iMap.getString("KART_GUVENLIK"), 
											 iMap.getString("KART_SON_KULLANMA"), 
											 iMap.getString("ORDER_ID"),
											 new BigDecimal(0).doubleValue(), 
											 properties.getString("currency"), 
											 iMap.getString("ACIKLAMA", ""),
											 ADCSession.getString("CLIENT_IP"));

			if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
				if(!"00".equals(paymentResponse.getReasonCode())) //procReturnCode 00 ise islem basarilidir
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
			}	
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMMap logMap = new GMMap();
			logMap.put("ODEME_TUTARI"		, iMap.getBigDecimal("ODEME_TUTARI"));
			logMap.put("KART_NO"			, iMap.getString("KART_NO"));
			logMap.put("KART_GUVENLIK"		, iMap.getString("KART_GUVENLIK"));
			logMap.put("KART_SON_KULLANMA"	, iMap.getString("KART_SON_KULLANMA"));
			logMap.put("SOURCE"				, iMap.getString("SOURCE"));
        	logMap.put("TX_NO"				, iMap.getBigDecimal("TX_NO"));
        	logMap.put("ORDER_ID" 			, iMap.getString("ORDER_ID"));		// Siparis No
        	logMap.put("AUTH_CODE" 			, paymentResponse.getAuthCode());		// Provizyon No
        	logMap.put("RESPONSE" 			, paymentResponse.getMessage());		// Approved,Declined ya da Error
        	logMap.put("REF_NUM" 			, paymentResponse.getRetRefNum());		// Referans No
        	logMap.put("RETURN_CODE" 		, paymentResponse.getReasonCode());		// Bankadan gelen islem kodu
        	logMap.put("ERR_MSG" 			, ( paymentResponse.getSysErrorMsg() ==null ? "" : paymentResponse.getSysErrorMsg() )
        									+ ( paymentResponse.getErrorMsg() ==null ? "" : ("#" + paymentResponse.getErrorMsg()) ) );		// Hata A��klama
        	logMap.put("TRANS_TYPE", 		"refund");
        	GMServiceExecuter.executeNT("BNSPR_POS_PAYMENT_LOG", logMap);
        	
        	oMap.put("ORDER_ID"		, paymentResponse.getOrderId());
        	oMap.put("AUTH_CODE"	, paymentResponse.getAuthCode());
        	oMap.put("RESPONSE"		, paymentResponse.getMessage());
        	oMap.put("REF_NUM"		, paymentResponse.getRetRefNum());
        	oMap.put("RETURN_CODE"	, paymentResponse.getReasonCode());
        	oMap.put("SYS_ERR_MSG"	, paymentResponse.getSysErrorMsg());
        	oMap.put("ERR_MSG"		, paymentResponse.getErrorMsg());
		}
		return oMap;
	}

	
	@GraymoundService("BNSPR_POS_PAYMENT_LOG")
	public static GMMap logPosPayment(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlPosPaymentLog gnlPosPaymentLog = new GnlPosPaymentLog();
			
			GMMap xMap = new GMMap().put("TABLE_NAME", "GNL_POS_PAYMENT_LOG");
			gnlPosPaymentLog.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID"));
			gnlPosPaymentLog.setAuthCode(iMap.getString("AUTH_CODE"));
			gnlPosPaymentLog.setErrMsg(iMap.getString("ERR_MSG"));
			gnlPosPaymentLog.setHostRefNum(iMap.getString("REF_NUM"));
			gnlPosPaymentLog.setKartGuvenlik(iMap.getString("KART_GUVENLIK"));
			gnlPosPaymentLog.setKartNo(iMap.getString("KART_NO"));
			gnlPosPaymentLog.setKartSonKullanma(iMap.getString("KART_SON_KULLANMA"));
			gnlPosPaymentLog.setOdemeTutari(iMap.getBigDecimal("ODEME_TUTARI"));
			gnlPosPaymentLog.setOrderId(iMap.getString("ORDER_ID"));
			gnlPosPaymentLog.setProcReturnCode(iMap.getString("RETURN_CODE"));
			gnlPosPaymentLog.setResponse(iMap.getString("RESPONSE"));
			gnlPosPaymentLog.setSource(iMap.getString("SOURCE"));
			gnlPosPaymentLog.setTxNo(iMap.getBigDecimal("TX_NO"));
			gnlPosPaymentLog.setTransType(iMap.getString("TRANS_TYPE"));
			
			session.save(gnlPosPaymentLog);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}	
	
	
	///////**************************** VAKIFBANK ************************************ ////////////////////
	
	/**
	 * Vakifbank pos provizyon servisi
	 * 
	 * 
	 * @param iMap
	 * 		-KART_NO
	        -KART_SON_KULLANMA
	        -KART_GUVENLIK
	        -ODEME_TUTARI
	        -ACIKLAMA
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi saglanmalidir, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_VB_DO_PAYMENT")
	public static GMMap posVbDoPayment(GMMap iMap){
		GMMap oMap = new GMMap();
		VBPosResponse posResponse = null;
		VBPosRequest posRequest = null;
		try{
			VBPosClient client = new VBPosClient();
			posRequest = initializeVbPosRequest(iMap);

			posRequest.setTxType("PRO");
	
			posResponse = client.sendPosTransaction(posRequest);		

			if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
				if(!"00".equals(posResponse.getKod())) /// kod 00 ise islem basarilidir
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
			}	
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logVbPosPayment(iMap, posRequest, posResponse);
        	
        	oMap.put("ORDER_ID"		, posRequest.getUyeRef());
        	oMap.put("PROVNO"		, posResponse.getProvNo());
        	oMap.put("STATUS"		, posResponse.getStatus());
        	oMap.put("RETURN_CODE"	, posResponse.getKod());
        	oMap.put("MESAJ"		, posResponse.getMesaj());
		}
		return oMap;
	}


	/**
	 * Vakifbank pos on provizyon servisi
	 * 
	 * @param iMap
	 * 		-KART_NO
	        -KART_SON_KULLANMA
	        -KART_GUVENLIK
	        -ODEME_TUTARI
	        -ACIKLAMA
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi saglanmalidir, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_VB_DO_PREAUTH")
	public static GMMap posVbDoPreAuth(GMMap iMap){
		GMMap oMap = new GMMap();
		VBPosResponse posResponse = null;
		VBPosRequest posRequest = null;
		try{

			VBPosClient client = new VBPosClient();
			posRequest = initializeVbPosRequest(iMap);

			posRequest.setTxType("OPR");
			
			posResponse = client.sendPosTransaction(posRequest);		

			if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
				if(!"00".equals(posResponse.getKod())) // kod 00 ise islem basarilidir
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
			}	
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logVbPosPayment(iMap, posRequest, posResponse);
  	
        	oMap.put("ORDER_ID"		, posRequest.getUyeRef());
        	oMap.put("PROVNO"		, posResponse.getProvNo());
        	oMap.put("STATUS"		, posResponse.getStatus());
        	oMap.put("RETURN_CODE"	, posResponse.getKod());
        	oMap.put("MESAJ"		, posResponse.getMesaj());
		}
		return oMap;
	}
	

	@GraymoundService("BNSPR_POS_VB_PAYMENT_LOG")
	public static GMMap logPosVbPayment(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GnlPosVbPaymentLog gnlPosVbPaymentLog = new GnlPosVbPaymentLog();

			VBPosRequest posRequest = (VBPosRequest) iMap.get("POS_REQUEST");
			VBPosResponse posResponse = (VBPosResponse) iMap.get("POS_RESPONSE");

			GMMap xMap = new GMMap().put("TABLE_NAME", "GNL_POS_VB_PAYMENT_LOG");
			gnlPosVbPaymentLog.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID"));
			gnlPosVbPaymentLog.setIslem(posRequest.getTxType());
			gnlPosVbPaymentLog.setKartNo(iMap.getString("KART_NO"));
			gnlPosVbPaymentLog.setOdemeTutari(iMap.getBigDecimal("ODEME_TUTARI"));
			gnlPosVbPaymentLog.setUyeref(posRequest.getUyeRef());
			gnlPosVbPaymentLog.setVbref(posResponse.getVbRef());
			gnlPosVbPaymentLog.setTarih(posResponse.getTarih());
			gnlPosVbPaymentLog.setProvno(posResponse.getProvNo());
			gnlPosVbPaymentLog.setBkmkod(posResponse.getBkmKod());
			gnlPosVbPaymentLog.setKod(posResponse.getKod());
			gnlPosVbPaymentLog.setStatus(posResponse.getStatus());
			gnlPosVbPaymentLog.setMesaj(posResponse.getMesaj());
			gnlPosVbPaymentLog.setCevapXml(posResponse.getResponseXml());
			gnlPosVbPaymentLog.setSource(iMap.getString("SOURCE"));
			gnlPosVbPaymentLog.setTxNo(iMap.getBigDecimal("TX_NO"));

			session.save(gnlPosVbPaymentLog);
			session.flush();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	
	private static VBPosRequest initializeVbPosRequest(GMMap iMap) {
		String bundleName = iMap.getString("CONFIG_FILE", "aktifbank-int-vbpos");
		ResourceBundle properties = ResourceBundle.getBundle(bundleName);

		VBPosRequest posRequest = new VBPosRequest();
		posRequest.setHost(properties.getString("host"));
		posRequest.setUser(properties.getString("user"));
		posRequest.setPassword(properties.getString("password"));
		posRequest.setMerchantNo(properties.getString("merchantNo"));
		posRequest.setPosNo(properties.getString("posNo"));
		posRequest.setXcip(properties.getString("xcip"));
		posRequest.setCvc(iMap.getString("KART_GUVENLIK"));
		posRequest.setCreditCardNumber(iMap.getString("KART_NO"));
		posRequest.setExpireDate(iMap.getString("KART_SON_KULLANMA"));
		posRequest.setAmount(iMap.getBigDecimal("ODEME_TUTARI").doubleValue());
		posRequest.setUyeRef(UUID.randomUUID().toString().replaceAll("-", ""));
		posRequest.setKhip(ADCSession.getString("CLIENT_IP"));
		return posRequest;
	}

	private static void logVbPosPayment(GMMap iMap, VBPosRequest posRequest, VBPosResponse posResponse) {
		GMMap logMap = new GMMap();
		logMap.put("ODEME_TUTARI", iMap.getBigDecimal("ODEME_TUTARI"));
		logMap.put("KART_NO", PosUtils.maskCCNumber(iMap.getString("KART_NO")));
		logMap.put("SOURCE", iMap.getString("SOURCE"));
		logMap.put("TX_NO", iMap.getBigDecimal("TX_NO"));
		logMap.put("POS_REQUEST", posRequest);
		logMap.put("POS_RESPONSE", posResponse);
		GMServiceExecuter.executeNT("BNSPR_POS_VB_PAYMENT_LOG", logMap);
	}
	
	///////**************************** VAKIFBANK ************************************ ////////////////////


	
	///////**************************** HALK BANKASI ************************************ ////////////////////

	
	/**
	 * Halk bankasi 3d Secure provizyon servisi
	 * 
	 * 
	 * @param iMap (SOURCE ve TX_NO haricindeki parametreler 3d secure sayfasini karsilayan url'lere parametre olarak geciliyor, bu url'lerdeki b�t�n request parametreleri bu servise yollanmali )
	 * 		-mdStatus
	        -HASHPARAMS
	        -HASHPARAMSVAL
	        -clientId
	        -md
	        -amount
	        -eci
	        -xid
	        -cavv
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi saglanmalidir, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_HB_3DSECURE_DO_PAYMENT")
	public static GMMap posHb3DSecureDoPayment(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			iMap.put("PAYMENT_TYPE", "Auth");
			oMap = posHb3DSecureProcessTransaction(iMap);
			return oMap;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Halk bankasi 3d Secure on provizyon servisi
	 * 
	 * 
	 * @param iMap (SOURCE ve TX_NO haricindeki parametreler 3d secure sayfasini karsilayan url'lere parametre olarak geciliyor, bu url'lerdeki b�t�n request parametreleri bu servise yollanmali )
	 * 		-mdStatus
	        -HASHPARAMS
	        -HASHPARAMSVAL
	        -clientId
	        -md
	        -amount
	        -eci
	        -xid
	        -cavv
	        -SOURCE (��lemin yap�ld��� kaynak bilgisi, WEB M��TER� BA�VURU vs. gibi i�lemi ay�rt edici bir bilgi saglanmalidir, loglama amacli)
	        -TX_NO (Transactional bir i�lemse tx_no sa�lanmal�)
	 * @return
	 */
	@GraymoundService("BNSPR_POS_HB_3DSECURE_DO_PREAUTH")
	public static GMMap posHb3DSecureDoPreAuth(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			iMap.put("PAYMENT_TYPE", "PreAuth");
			oMap = posHb3DSecureProcessTransaction(iMap);
			return oMap;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}


	private static GMMap posHb3DSecureProcessTransaction(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();
		jpay payment = new jpay();
		String returnCode = "";
		try{
			String bundleName = iMap.getString("CONFIG_FILE", "aktifbank-int-hbpos");
			ResourceBundle properties = ResourceBundle.getBundle(bundleName);
				
			String mdStatus = iMap.getString("mdStatus"); // 3D isleminin sonucunu g�sterir (1,2,3,4) ise basarili, (5,6,7,8,9,0) i�e basarisizdir

			if (mdStatus != null && (mdStatus.equals("1") || mdStatus.equals("2") || mdStatus.equals("3") || mdStatus.equals("4"))) {//Basarili ve odeme ger�eklestiriliyor
				
				if( isHashSecure(iMap, properties.getString("storekey")) ){	// 

					payment.setDebug("true".equals(properties.getString("debug")));
					payment.setMode(properties.getString("mode"));
					payment.setName(properties.getString("username"));
					payment.setPassword(properties.getString("password"));
						
					payment.setType(iMap.getString("PAYMENT_TYPE"));
						
					payment.setClientId(iMap.getString("clientid"));
					payment.setNumber(iMap.getString("md")); // 3d secure isleminden d�nen MD parametresi
					payment.setExpires(""); // Son kullanma tarihine md kullan�ldigi icin gerek yoktur.
					payment.setCvv2Val(""); // MD degeri kullanildiginda gerek yoktur.
					payment.setTotal(iMap.getString("amount"));
					payment.setCurrency(iMap.getString("currency")); //YTL icin 949
	
					// 3d icin odeme alanlar�
					payment.setCardholderPresentCode("13"); // her zaman 13 de�erini al�r
					payment.setPayerSecurityLevel(iMap.getString("eci")); // 3d sonucu parametre olarak gelir
					payment.setPayerTxnId(iMap.getString("xid")); //3d Sonucu parametre olarak gelir.
					payment.setPayerAuthenticationCode(iMap.getString("cavv")); //3d sonucu parametre olarak gelir
	
					/************************    Optional        *****************************/
					/*
					payment.setTaksit("");
					payment.setOrderId(oid);
					payment.setGroupId("");
					payment.setTransId("");
					payment.setIPAddress("");
					payment.setUserId("");
					payment.setComments("");
					payment.setBName("xxxfirma");
					payment.setBStreet1("");
					payment.setBStreet2("");
					payment.setBStreet3("");
					payment.setBCity("");
					payment.setBPostalCode("");
					payment.setBStateProv("");
					payment.setSName("");
					payment.setSStreet1("");
					payment.setSStreet2("");
					payment.setSStreet3("");
					payment.setSCity("");
					payment.setSPostalCode("");
					payment.setSStateProv("");
					//myjpay.setExtra("","");
					 */
	
					int val = payment.processTransaction(properties.getString("host"), Integer.parseInt(properties.getString("port")), properties.getString("api"));
	
					if(val == 0 || !"Approved".equalsIgnoreCase(payment.getResponse())){ // val==0 ise baglanti hatasidir
						logger.info("Pos transaction is unsuccessful");
						if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
							throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
						}	
					}
					else{ //Odeme basarili
						logger.info("Pos transaction is approved");
					}
					
					returnCode = payment.getProcReturnCode(); //Bankadan donen return code
	
				}
				else{
					if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
						throw new GMRuntimeException(0, POS_COMMON_ERR_MSG);
					}	
					else{
						returnCode = "AB02"; //Hashler uyumsuz
					}
				}
			}		
			else{
				logger.info("3D Secure authentication failed");
				if( PosUtils.throwException(iMap) ){  // exception atmasi istenmiyorsa THROW_EXCEPTION false set edilebilir disaridan
					throw new GMRuntimeException(0, POS_COMMON_ERR_MSG );
				}	
				returnCode = "AB01"; //3D Secure onayi alinamadi
			}
			
		}catch(Exception e){
			throw e;
		}
		finally {	
        	oMap.put("TRANS_ID"			, payment.getTransId());
        	oMap.put("HOST_REF_NUM"		, payment.getHostRefNum());
        	oMap.put("RETURN_CODE"		, returnCode);
        	oMap.put("ERR_MSG"			, payment.getErrMsg());
        	oMap.put("AUTH_CODE"		, payment.getAuthCode());
        	logHb3dPosPayment(iMap, oMap, payment);
		}
		return oMap;
	}
	
	private static boolean isHashSecure(GMMap iMap, String storeKey) throws Exception{
		boolean isHashSecure = false;
		String hashparams = iMap.getString("HASHPARAMS");
		logger.info("hashparams=" 	 + hashparams);
		if( !StringUtil.isEmpty(hashparams) ){ // HASHPARAMS parametresi gelmiyorsa hash dogrulamasi yapma
			String hashparamsval = iMap.getString("HASHPARAMSVAL", "");
			String paramsval = "";
			int index1 = 0, index2 = 0;
			// hash hesaplamada kullanilacak degerler ayristirilip degerleri birlestiriliyor.
			do {
				index2 = hashparams.indexOf(":", index1);
				String val = iMap.getString(hashparams.substring(index1,index2)) == null ? "" : iMap.getString(hashparams.substring(index1, index2));
				paramsval += val;
				index1 = index2 + 1;
			} while (index1 < hashparams.length());

			logger.info("hashparamsval=" + hashparamsval);
			logger.info("paramsval=" 	 + paramsval);

			String hashval = paramsval + storeKey; //elde edilecek hash de�eri i�in paramsval e store key ekleniyor. (i�yeri anahtar�)
			String hashparam = iMap.getString("HASH");
			java.security.MessageDigest sha1 = java.security.MessageDigest.getInstance("SHA-1");
			String hash = (new sun.misc.BASE64Encoder()).encode(sha1.digest(hashval.getBytes()));

			logger.info("request hash=" 	+ hashparam );
			logger.info("constructed hash=" + hash );
			
			if(paramsval.equals(hashparamsval) && hash.equals(hashparam)){ //olusturulan hash ile gelen hash ve hash parametreleri degerleri ile ayristirilip elde edilen ayn� olmali.
				isHashSecure = true;
			}	
			else{
				isHashSecure = false;
				//hashler uyumsuz, guvenlik hatasi
				logger.info("Hashes do not match!!!");
			}	
			
		}
		return isHashSecure;
	}
	
	
	private static void logHb3dPosPayment(GMMap iMap, GMMap oMap, jpay payment) {
		GMMap logMap = new GMMap();
		logMap.put("STORE_TYPE",      iMap.getString("storetype"));
		logMap.put("CLIENT_ID",    	  iMap.getString("clientid"));
		logMap.put("EXP_DATE_MONTH",  iMap.getString("Ecom_Payment_Card_ExpDate_Month"));
		logMap.put("EXP_DATE_YEAR",   iMap.getString("Ecom_Payment_Card_ExpDate_Year"));
		logMap.put("AMOUNT",   		  iMap.getString("amount"));
		logMap.put("CURRENCY",  	  iMap.getString("currency"));
		logMap.put("MD_STATUS",   	  iMap.getString("mdStatus"));
		logMap.put("MD_ERR_MSG",   	  iMap.getString("mdErrorMsg"));
		logMap.put("OID",   	  	  iMap.getString("oid"));
		logMap.put("XID",   	  	  iMap.getString("xid"));
		logMap.put("MASKED_PAN",   	  iMap.getString("MaskedPan"));
		logMap.put("TYPE",   	  	  iMap.getString("PAYMENT_TYPE"));
		logMap.put("TRANS_ID",   	  payment.getTransId());
		logMap.put("AUTH_CODE",   	  payment.getAuthCode());
		logMap.put("RESPONSE",   	  payment.getResponse());
		logMap.put("HOST_REF_NUM",    payment.getHostRefNum());
		logMap.put("RETURN_CODE",     oMap.getString("RETURN_CODE"));
		logMap.put("ERR_MSG",   	  payment.getErrMsg());
		logMap.put("SOURCE", 	   	  iMap.getString("SOURCE"));
		logMap.put("TX_NO", 	   	  iMap.getBigDecimal("TX_NO"));
		GMServiceExecuter.executeNT("BNSPR_POS_HB_3D_PAYMENT_LOG", logMap);
	}
	
	@GraymoundService("BNSPR_POS_HB_3D_PAYMENT_LOG")
	public static GMMap logPosHb3dPayment(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GnlPosHb3dPaymentLog paymentLog = new GnlPosHb3dPaymentLog();

			GMMap xMap = new GMMap().put("TABLE_NAME", "GNL_POS_HB_3D_PAYMENT_LOG");
			paymentLog.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID"));
			paymentLog.setStoreType(iMap.getString("STORE_TYPE"));
			paymentLog.setClientId(iMap.getString("CLIENT_ID"));
			paymentLog.setExpDateMonth(iMap.getString("EXP_DATE_MONTH"));
			paymentLog.setExpDateYear(iMap.getString("EXP_DATE_YEAR"));
			paymentLog.setAmount(iMap.getString("AMOUNT"));
			paymentLog.setCurrency(iMap.getString("CURRENCY"));
			paymentLog.setMdStatus(iMap.getString("MD_STATUS"));
			paymentLog.setMdErrMsg(iMap.getString("MD_ERR_MSG"));
			paymentLog.setOid(iMap.getString("OID"));
			paymentLog.setXid(iMap.getString("XID"));
			paymentLog.setMaskedPan(iMap.getString("MASKED_PAN"));
			paymentLog.setType(iMap.getString("TYPE"));
			paymentLog.setTransId(iMap.getString("TRANS_ID"));
			paymentLog.setAuthCode(iMap.getString("AUTH_CODE"));
			paymentLog.setResponse(iMap.getString("RESPONSE"));
			paymentLog.setHostRefNum(iMap.getString("HOST_REF_NUM"));
			paymentLog.setReturnCode(iMap.getString("RETURN_CODE"));
			paymentLog.setErrMsg(iMap.getString("ERR_MSG"));
			paymentLog.setSource(iMap.getString("SOURCE"));
			paymentLog.setTxNo(iMap.getBigDecimal("TX_NO"));
			session.save(paymentLog);
			session.flush();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	
	

	private static void logAktifPos(GMMap logMap, long startTimeinMillis, long endTimeInMillis) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		logMap.put("START_TIME",   	dateFormat.format(startTimeinMillis));
		logMap.put("END_TIME",   	dateFormat.format(endTimeInMillis));
		logMap.put("DURATION",  	endTimeInMillis-startTimeinMillis);
		logMap.put("SERVER_IP",     ADCSession.getString("SERVER_IP"));
		logMap.put("SESSION_ID",    ADCSession.getSessionID());
		GMServiceExecuter.executeNT("BNSPR_POS_AKTIFPOS_LOG", logMap);
	}
	
	@GraymoundService("BNSPR_POS_AKTIFPOS_LOG")
	public static GMMap logAktifPosLog(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlPosAktifposLog aktifposLog = new GnlPosAktifposLog();
			
			aktifposLog.setDuration(iMap.getBigDecimal("DURATION"));
			aktifposLog.setEndTime(iMap.getString("END_TIME"));
			aktifposLog.setHata(iMap.getString("HATA"));
			aktifposLog.setHataKod(iMap.getString("HATA_KOD"));
			aktifposLog.setInputs(iMap.getString("INPUTS"));
			aktifposLog.setMethodName(iMap.getString("METHOD_NAME"));
			aktifposLog.setResponse( (iMap.getString("RESPONSE") != null ) ? new ClobImpl(iMap.getString("RESPONSE")) : new ClobImpl(""));
			aktifposLog.setServerIp(iMap.getString("SERVER_IP"));
			aktifposLog.setSessionId(iMap.getString("SESSION_ID"));
			aktifposLog.setStartTime(iMap.getString("START_TIME"));
			aktifposLog.setChannel(iMap.getString("CHANNEL"));
			session.save(aktifposLog);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	
	/**
	 * BNSPR_POS_AKTIFPOS_GET_AUTH_INFO
	 * 
	 * @param iMap
	 * 			-CHANNEL,
	 * 			-SUB_CHANNEL,
	 * 			-PROCESS_TYPE
	 * @return oMap
	 * 			-IS_SUCCESSFUL true ->  
	 * 							 -NAME, 
	 * 							 -PASSWORD, 
	 * 							 -CLIENT_ID
	 * 						   false -> 
	 * 							 -FAIL_DESC
	 */
	@GraymoundService("BNSPR_POS_AKTIFPOS_GET_AUTH_INFO")
	public static GMMap getAuthInfoWithChannel(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String channel = iMap.getString("CHANNEL");
			String subChannel = iMap.getString("SUB_CHANNEL");
			String processType = iMap.getString("PROCESS_TYPE");
			
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(GnlPosChannelClientRel.class);
			if(channel != null && !channel.trim().isEmpty()){
				criteria.add(Restrictions.eq("channel", channel));
			}
			if(subChannel != null && !subChannel.trim().isEmpty()){
				criteria.add(Restrictions.eq("subChannel", subChannel));
			}
			if(processType != null && !processType.trim().isEmpty()){
				criteria.add(Restrictions.eq("processType", processType));
			}
			
			@SuppressWarnings("unchecked")
			List<GnlPosChannelClientRel> list = criteria.list();
			if (list != null && list.size() > 0) {
				if(list.size() == 1){
					oMap.put("IS_SUCCESSFUL", true);
					oMap.put("NAME", list.get(0).getName());
					oMap.put("PASSWORD", list.get(0).getPassword());
					oMap.put("CLIENT_ID", list.get(0).getClientId());
				}else if(list.size() > 1){
					oMap.put("IS_SUCCESSFUL", false);				
					oMap.put("FAIL_DESC", "Result is not unique");				
				}
			}else{
				oMap.put("IS_SUCCESSFUL", false);
				oMap.put("FAIL_DESC", "No data found");				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}