package tr.com.calikbank.bnspr.ftm;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class FtmDashboardServices {
	
	@GraymoundService("BNSPR_FTM_DB_GET_PROCESS_LOGS")
	public static GMMap getProcessLogs(GMMap iMap) {
		return callFTMService("BNSPR_FTM_GET_PROCESS_LOGS",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_GET_PROCESS_DETAIL")
	public static GMMap getProcessDetail(GMMap iMap) {
		return callFTMService("BNSPR_FTM_GET_PROCESS_DETAIL",iMap);
	}	
	
	@GraymoundService("BNSPR_FTM_DB_GET_REAL_TIME_PROCESS")
	public static GMMap getRealTimeProcess(GMMap iMap) {
		return callFTMService("BNSPR_FTM_GET_REAL_TIME_PROCESS",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_SHUTDOWN")
	public static GMMap shutdownFTM(GMMap iMap) {
		return callFTMService("BNSPR_FTM_SHUTDOWN",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_RESTART")
	public static GMMap reStartFTM(GMMap iMap) {
		return callFTMService("BNSPR_FTM_RESTART",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_REFRESH_CACHES")
	public static GMMap refreshFtmCaches(GMMap iMap) {
		return callFTMService("BNSPR_FTM_REFRESH_CACHES",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_GET_REQUEST_LOGS")
	public static GMMap getFileRequestLogs(GMMap iMap) {
		return callFTMService("BNSPR_FTM_GET_FILE_REQUEST_LOGS",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_GET_REQUEST_LOG_DATA")
	public static GMMap getFileRequestLogData(GMMap iMap) {
		return callFTMService("BNSPR_FTM_GET_FILE_REQUEST_LOG_DATA",iMap);
	}
	
	@GraymoundService("BNSPR_FTM_DB_RECALL_CREATE_AND_TRANSFER_FILE")
	public static GMMap reCallCreateFileFromContent(GMMap iMap) {
		return callFTMService("BNSPR_FTM_CREATE_AND_TRANSFER_FILE",(GMMap)iMap.get("DATA"));
	}
	
	private static GMMap callFTMService(String serviceName,GMMap iMap){
		GMMap oMap=new GMMap();
		GMConnection connection=null;
		try {
			connection = GMConnection.getConnection("FTM");
			oMap.putAll(connection.serviceCall(serviceName, iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
