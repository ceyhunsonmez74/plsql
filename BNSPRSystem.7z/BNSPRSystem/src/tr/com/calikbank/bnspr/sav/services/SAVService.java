package tr.com.calikbank.bnspr.sav.services;

import org.apache.log4j.Logger;
import org.datacontract.schemas._2004._07.ega_services.AccessProtocolType;
import org.datacontract.schemas._2004._07.ega_services.ArrayOfSignerInfoType;
import org.datacontract.schemas._2004._07.ega_services.BinarySigningRequestSyncType;
import org.datacontract.schemas._2004._07.ega_services.CmsArchiveType;
import org.datacontract.schemas._2004._07.ega_services.ComplexSigningRequestSyncType;
import org.datacontract.schemas._2004._07.ega_services.DataAccessType;
import org.datacontract.schemas._2004._07.ega_services.SignerInfoType;
import org.datacontract.schemas._2004._07.ega_services.SigningRequestSyncResponseType;
import org.datacontract.schemas._2004._07.ega_services.SigningType;

import tr.com.aktifbank.integration.ega.EgaWebService;
import tr.com.ega.sav.MEIASignAndVerifyService;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SAVService {
	
	private static Logger logger = Logger.getLogger(SAVService.class);
	
	private static final int SUCCESSFUL_CODE=101;
	
	@GraymoundService("BNSPR_SAV_BINARY_UBL_SIGNING")
	public static GMMap binaryUblSigning(GMMap iMap) {
		try {
			GMMap oMap=new GMMap();
			
			BinarySigningRequestSyncType binarySigningRequestSyncType=new BinarySigningRequestSyncType();
			binarySigningRequestSyncType.setAppId(iMap.getString("APP_ID"));
			binarySigningRequestSyncType.setAppName(iMap.getString("APP_NAME"));
			binarySigningRequestSyncType.setAppUser(iMap.getString("APP_USER"));
			
			binarySigningRequestSyncType.setSigningType(SigningType.UBL);
			
			binarySigningRequestSyncType.setFileName(iMap.getString("FILE_NAME"));
			binarySigningRequestSyncType.setBinaryData((byte[]) iMap.get("BINARY_ARRAY"));
			
			//Signer Info
			ArrayOfSignerInfoType arrayOfSignerInfoType=new ArrayOfSignerInfoType();
			SignerInfoType signerInfoType=new SignerInfoType();
			signerInfoType.setCertificateOwner(iMap.getString("CERTIFICATE_OWNER"));
			signerInfoType.setCertificateSerialNo(iMap.getString("CERTIFICATE_SERIAL_NO"));
			signerInfoType.setCertificateTCKNo(iMap.getString("CERTIFICATE_TCK_NO"));
			
			SignerInfoType parentSignerInfoType=new SignerInfoType();
			parentSignerInfoType.setCertificateOwner(iMap.getString("PARENT_CERTIFICATE_OWNER"));
			parentSignerInfoType.setCertificateSerialNo(iMap.getString("PARENT_CERTIFICATE_SERIAL_NO"));
			parentSignerInfoType.setCertificateTCKNo(iMap.getString("PARENT_CERTIFICATE_TCK_NO"));
			
			signerInfoType.setParentSignature(parentSignerInfoType);
			arrayOfSignerInfoType.getSignerInfoType().add(signerInfoType);
			binarySigningRequestSyncType.setSignersInfo(arrayOfSignerInfoType);
			
			MEIASignAndVerifyService proxy=EgaWebService.getClient();
			SigningRequestSyncResponseType signingRequestSyncResponseType=proxy.binarySigningRequestSync(binarySigningRequestSyncType);
			logger.info("status code:"+signingRequestSyncResponseType.getStatusCode()+ " status message:"+signingRequestSyncResponseType.getMessage());
			
			oMap.put("STATUS_CODE", signingRequestSyncResponseType.getStatusCode());
			if(signingRequestSyncResponseType.getStatusCode()==SUCCESSFUL_CODE){
				oMap.put("STATUS", true);
				oMap.put("SIGNED_BINARY_DATA", signingRequestSyncResponseType.getSignedBinaryData());
			} else {
				oMap.put("STATUS", false);
			}
			
			return oMap;
			
		} catch(Exception exp){
			logger.error(exp);
			throw new GMRuntimeException(0, exp);
		}
		
	}	
	
	@GraymoundService("BNSPR_SAV_COMPLEX_SIGNING")
	public static GMMap complexSigning(GMMap iMap) {
		try {
			GMMap oMap=new GMMap();
			
			ComplexSigningRequestSyncType complexSigningRequestSyncType=new ComplexSigningRequestSyncType();
			complexSigningRequestSyncType.setAppId(iMap.getString("APP_ID"));
			complexSigningRequestSyncType.setAppName(iMap.getString("APP_NAME"));
			complexSigningRequestSyncType.setAppUser(iMap.getString("APP_USER"));
			
			complexSigningRequestSyncType.setSigningType(SigningType.CMS);
			complexSigningRequestSyncType.setArchiveType(CmsArchiveType.BES);
			
			//Input Info
			DataAccessType inputDataAccessType=new DataAccessType();
			inputDataAccessType.setAccessBinaryData((byte[]) iMap.get("BINARY_ARRAY"));
			inputDataAccessType.setAccessType(AccessProtocolType.BINARY);
			complexSigningRequestSyncType.setResourceInfo(inputDataAccessType);
			
			//Output Info
			DataAccessType outputDataAccessType=new DataAccessType();
			outputDataAccessType.setAccessType(AccessProtocolType.BINARY);
			complexSigningRequestSyncType.setOutputInfo(outputDataAccessType);
			
			//Signer Info
			ArrayOfSignerInfoType arrayOfSignerInfoType=new ArrayOfSignerInfoType();
			SignerInfoType signerInfoType=new SignerInfoType();
			signerInfoType.setCertificateOwner(iMap.getString("CERTIFICATE_OWNER"));
			signerInfoType.setCertificateSerialNo(iMap.getString("CERTIFICATE_SERIAL_NO"));
			signerInfoType.setCertificateTCKNo(iMap.getString("CERTIFICATE_TCK_NO"));
			arrayOfSignerInfoType.getSignerInfoType().add(signerInfoType);
			complexSigningRequestSyncType.setSignersInfo(arrayOfSignerInfoType);
			
			MEIASignAndVerifyService proxy=EgaWebService.getClient();
			SigningRequestSyncResponseType signingRequestSyncResponseType=proxy.complexSigningRequestSync(complexSigningRequestSyncType);
			logger.info("status code:"+signingRequestSyncResponseType.getStatusCode()+ " status message:"+signingRequestSyncResponseType.getMessage());
			
			oMap.put("STATUS_CODE", signingRequestSyncResponseType.getStatusCode());
			if(signingRequestSyncResponseType.getStatusCode()==SUCCESSFUL_CODE){
				oMap.put("STATUS", true);
				oMap.put("SIGNED_BINARY_DATA", signingRequestSyncResponseType.getSignedBinaryData());
			} else {
				oMap.put("STATUS", false);
			}
			
			return oMap;
			
		} catch(Exception exp){
			logger.error(exp);
			throw new GMRuntimeException(0, exp);
		}
		
	}
	
	@GraymoundService("BNSPR_SAV_GET_TIMESTAMP")
	public static GMMap getTimeStamp(GMMap iMap) {
		try {
			GMMap oMap=new GMMap();

			MEIASignAndVerifyService proxy=EgaWebService.getClient();
			byte[] result=proxy.getTimeStamp((byte[])iMap.get("DATA_BYTE_ARRAY"));
			oMap.put("DATA_BYTE_ARRAY", result);
			
			return oMap;
			
		} catch(Exception exp){
			logger.error(exp);
			throw new GMRuntimeException(0, exp);
		}
	}
	
}
