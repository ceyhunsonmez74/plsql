package tr.com.calikbank.bnspr.dcc;

import java.util.List;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.DccDefinition;
import tr.com.aktifbank.bnspr.dao.DccDefinitionTx;
import tr.com.aktifbank.bnspr.dao.DccParameter;
import tr.com.aktifbank.bnspr.dao.DccParameterTx;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ContentCreatorDashboardServices {

	/**
	 * 
	 * DEFINITION
	 * 
	 */
	
	@GraymoundService("BNSPR_DCC_DB_GET_DEFINITION_INFO")
	public static GMMap getDefinitionInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		DccDefinitionTx dccDefinitionTx=(DccDefinitionTx)session.get(DccDefinitionTx.class, iMap.getBigDecimal("TRX_NO"));
		
		oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

		if(dccDefinitionTx.getType().equals("I")) {
			oMap.put("OPER_TYPE", "I");
			oMap.put("FOLDER", dccDefinitionTx.getFolderName());
			oMap.put("TEMPLATE", dccDefinitionTx.getTemplateName());
			return oMap;
			
		} else if(dccDefinitionTx.getType().equals("U")) {
			oMap.put("OPER_TYPE", "U");
			oMap.put("FOLDER", dccDefinitionTx.getFolderName());
			oMap.put("TEMPLATE", dccDefinitionTx.getTemplateName());
			DccDefinition dccDefinition=(DccDefinition)session.get(DccDefinition.class, dccDefinitionTx.getOid());
			return putDefinitionToGMMap(dccDefinition, oMap);
			
		} else if(dccDefinitionTx.getType().equals("D")) {
			oMap.put("OPER_TYPE", "D");
			oMap.put("FOLDER", "");
			oMap.put("TEMPLATE", "");
			DccDefinition dccDefinition=(DccDefinition)session.get(DccDefinition.class, dccDefinitionTx.getOid());
			return putDefinitionToGMMap(dccDefinition, oMap);
		}
		
		return oMap;
	}
	
	private static GMMap putDefinitionToGMMap(List<DccDefinition> dccDefinitionList,GMMap oMap){
		int index=0;
		for(DccDefinition dccDefinition:dccDefinitionList) {
			oMap.put("DEFINITION_LIST", index, "OID", dccDefinition.getOid());
			oMap.put("DEFINITION_LIST", index, "FOLDER", dccDefinition.getFolderName());
			oMap.put("DEFINITION_LIST", index, "TEMPLATE", dccDefinition.getTemplateName());
			oMap.put("DEFINITION_LIST", index, "TYPE_ID", dccDefinition.getTypeOid());
			oMap.put("DEFINITION_LIST", index, "TYPE", (dccDefinition.getTypeOid()==1)?"PDF":"HTML");
			index++;
		}
		return oMap;
	}
	
	private static GMMap putDefinitionToGMMap(DccDefinition dccDefinition,GMMap oMap){
		oMap.put("DEFINITION_LIST", 0, "OID", dccDefinition.getOid());
		oMap.put("DEFINITION_LIST", 0, "FOLDER", dccDefinition.getFolderName());
		oMap.put("DEFINITION_LIST", 0, "TEMPLATE", dccDefinition.getTemplateName());
		oMap.put("DEFINITION_LIST", 0, "TYPE_ID", dccDefinition.getTypeOid());
		oMap.put("DEFINITION_LIST", 0, "TYPE", (dccDefinition.getTypeOid()==1)?"PDF":"HTML");
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_DCC_DB_GET_DEFINITION_LIST")
	public static GMMap getDefinitionList(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		
		List<DccDefinition> dccDefinitionList=(List<DccDefinition>)session.createCriteria(DccDefinition.class)
												.addOrder(Order.asc("folderName"))
												.addOrder(Order.asc("templateName")).list();
		
		return putDefinitionToGMMap(dccDefinitionList, oMap);
	}
	
	@GraymoundService("BNSPR_DCC_DB_GET_TYPE")
	public static GMMap getTypeList(GMMap iMap) {
		GMMap oMap=new GMMap();
		GuimlUtil.wrapMyCombo(oMap, "TYPE", "1", "PDF");
		GuimlUtil.wrapMyCombo(oMap, "TYPE", "2", "HTML");
		return oMap;
	}

	@GraymoundService("BNSPR_DCC_DB_SAVE_DEFINITION")
	public static GMMap saveDefinition(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		DccDefinitionTx dccDefinitionTx=new DccDefinitionTx();
		dccDefinitionTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		dccDefinitionTx.setOid(UUID.randomUUID().toString());
		dccDefinitionTx.setFolderName(iMap.getString("FOLDER"));
		dccDefinitionTx.setTemplateName(iMap.getString("TEMPLATE"));
		dccDefinitionTx.setTypeOid((byte)iMap.getInt("TYPE_ID"));
		dccDefinitionTx.setType("I");
		session.save(dccDefinitionTx);
		session.flush();
		return callTrn9972(iMap);
	}
	
	@GraymoundService("BNSPR_DCC_DB_UPDATE_DEFINITION")
	public static GMMap updateDefinition(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		DccDefinitionTx dccDefinitionTx = new DccDefinitionTx();
		dccDefinitionTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		dccDefinitionTx.setOid(iMap.getString("OID"));
		dccDefinitionTx.setFolderName(iMap.getString("FOLDER"));
		dccDefinitionTx.setTemplateName(iMap.getString("TEMPLATE"));
		dccDefinitionTx.setTypeOid((byte)iMap.getInt("TYPE_ID"));
		dccDefinitionTx.setType("U");
		session.save(dccDefinitionTx);
		session.flush();
		return callTrn9972(iMap);
	}
	
	@GraymoundService("BNSPR_DCC_DB_DELETE_DEFINITION")
	public static GMMap deleteDefinition(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		DccDefinition dccDefinition = (DccDefinition)session.get(DccDefinition.class,iMap.getString("OID"));
		DccDefinitionTx dccDefinitionTx = new DccDefinitionTx();
		dccDefinitionTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		dccDefinitionTx.setOid(dccDefinition.getOid());
		dccDefinitionTx.setFolderName(dccDefinition.getFolderName());
		dccDefinitionTx.setTemplateName(dccDefinition.getTemplateName());
		dccDefinitionTx.setTypeOid(dccDefinition.getTypeOid());
		dccDefinitionTx.setType("D");
		session.save(dccDefinitionTx);
		session.flush();
		return callTrn9972(iMap);
	}
	
	private static GMMap callTrn9972(GMMap iMap){
		iMap.put("TRX_NAME" , "9972");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
	
	/**
	 * 
	 * DEFINITION VARIABLE
	 * 
	 */
	
	@GraymoundService("BNSPR_DCC_DB_GET_DEFINITION_VARIABLE_INFO")
	public static GMMap getDefinitionVariableInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		DccParameterTx dccParameterTx=(DccParameterTx)session.get(DccParameterTx.class, iMap.getBigDecimal("TRX_NO"));
		
		oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
		
		if(dccParameterTx.getType().equals("I")) {
			oMap.put("OPER_TYPE", "I");
			oMap.put("PARAM_NAME", dccParameterTx.getParamName());
			oMap.put("PARAM_VALUE", dccParameterTx.getParamValue());
			DccDefinition dccDefinition=(DccDefinition)session.get(DccDefinition.class, dccParameterTx.getDefinitionOid());
			return putDefinitionToGMMap(dccDefinition, oMap);
			
		} else if(dccParameterTx.getType().equals("U")) {
			oMap.put("OPER_TYPE", "U");
			oMap.put("PARAM_NAME", dccParameterTx.getParamName());
			oMap.put("PARAM_VALUE", dccParameterTx.getParamValue());
			DccDefinition dccDefinition=(DccDefinition)session.get(DccDefinition.class, dccParameterTx.getDefinitionOid());
			oMap=putDefinitionToGMMap(dccDefinition, oMap);
			DccParameter dccParameter=(DccParameter)session.get(DccParameter.class, dccParameterTx.getOid());
			return putParameterToGMMap(dccParameter, oMap);
			
		} else if(dccParameterTx.getType().equals("D")) {
			oMap.put("OPER_TYPE", "D");
			oMap.put("PARAM_NAME", "");
			oMap.put("PARAM_VALUE", "");
			DccDefinition dccDefinition=(DccDefinition)session.get(DccDefinition.class, dccParameterTx.getDefinitionOid());
			oMap=putDefinitionToGMMap(dccDefinition, oMap);
			DccParameter dccParameter=(DccParameter)session.get(DccParameter.class, dccParameterTx.getOid());
			return putParameterToGMMap(dccParameter, oMap);			
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_DCC_DB_GET_DEFINITION_VARIABLE_LIST")
	public static GMMap getDefinitionVariableList(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		
		DccDefinition dccDefinition = (DccDefinition)session.get(DccDefinition.class,iMap.getString("OID"));
		List<DccParameter> dccParameters=(List<DccParameter>)session.createCriteria(DccParameter.class)
											.add(Restrictions.eq("definitionOid", dccDefinition.getOid()))
											.addOrder(Order.asc("paramName")).list();
		
		return putParameterToGMMap(dccParameters, oMap);
	}
	
	private static GMMap putParameterToGMMap(List<DccParameter> dccParameters,GMMap oMap){
		int index=0;
		for(DccParameter dccParameter:dccParameters) {
			oMap.put("VARIABLE_LIST", index, "OID", dccParameter.getOid());
			oMap.put("VARIABLE_LIST", index, "NAME", dccParameter.getParamName());
			oMap.put("VARIABLE_LIST", index, "VALUE", dccParameter.getParamValue());
			index++;
		}
		return oMap;
	}
	
	private static GMMap putParameterToGMMap(DccParameter dccParameter,GMMap oMap){
		oMap.put("VARIABLE_LIST", 0, "OID", dccParameter.getOid());
		oMap.put("VARIABLE_LIST", 0, "NAME", dccParameter.getParamName());
		oMap.put("VARIABLE_LIST", 0, "VALUE", dccParameter.getParamValue());
		return oMap;
	}
	
	@GraymoundService("BNSPR_DCC_DB_SAVE_DEFINITION_PARAMETER")
	public static GMMap saveDefinitionParameter(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		DccParameterTx dccParameterTx=new DccParameterTx();
		dccParameterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		dccParameterTx.setOid(UUID.randomUUID().toString());
		dccParameterTx.setDefinitionOid(iMap.getString("OID"));
		dccParameterTx.setParamName(iMap.getString("NAME"));
		dccParameterTx.setParamValue(iMap.getString("VALUE"));
		dccParameterTx.setType("I");
		session.save(dccParameterTx);
		session.flush();
		return callTrn9973(iMap);
	}
	
	@GraymoundService("BNSPR_DCC_DB_UPDATE_DEFINITION_PARAMETER")
	public static GMMap updateDefinitionParameter(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		DccParameter dccParameter = (DccParameter)session.get(DccParameter.class,iMap.getString("OID"));
		DccParameterTx dccParameterTx=new DccParameterTx();
		dccParameterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		dccParameterTx.setOid(dccParameter.getOid());
		dccParameterTx.setDefinitionOid(dccParameter.getDefinitionOid());
		dccParameterTx.setParamName(iMap.getString("NAME"));
		dccParameterTx.setParamValue(iMap.getString("VALUE"));
		dccParameterTx.setType("U");
		session.save(dccParameterTx);
		session.flush();
		return callTrn9973(iMap);
	}
	
	@GraymoundService("BNSPR_DCC_DB_DELETE_DEFINITION_PARAMETER")
	public static GMMap deleteDefinitionParameter(GMMap iMap) {
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		DccParameter dccParameter = (DccParameter)session.get(DccParameter.class,iMap.getString("OID"));
		DccParameterTx dccParameterTx=new DccParameterTx();
		dccParameterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		dccParameterTx.setOid(dccParameter.getOid());
		dccParameterTx.setDefinitionOid(dccParameter.getDefinitionOid());
		dccParameterTx.setParamName(dccParameter.getParamName());
		dccParameterTx.setParamValue(dccParameter.getParamValue());
		dccParameterTx.setType("D");
		session.save(dccParameterTx);
		session.flush();
		return callTrn9973(iMap);
	}
	
	private static GMMap callTrn9973(GMMap iMap){
		iMap.put("TRX_NAME" , "9973");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	}
}
