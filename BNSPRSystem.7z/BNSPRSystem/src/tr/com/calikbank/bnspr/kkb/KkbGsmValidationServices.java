package tr.com.calikbank.bnspr.kkb;

import org.apache.log4j.Logger;

import tr.com.aktifbank.kkb.gsm.validation.model.start.RequestStartInput;
import tr.com.aktifbank.kkb.gsm.validation.model.start.RequestStartOutput;
import tr.com.aktifbank.kkb.gsm.validation.service.KkbGsmValidationIntServices;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class KkbGsmValidationServices {
	
	private static final Logger logger = Logger.getLogger(KkbGsmValidationServices.class);

	@GraymoundService("BNSPR_KKB_GSM_VALIDATION_START")
	public static GMMap start(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			RequestStartInput requestStartInput=new RequestStartInput();
			requestStartInput.setTckn(iMap.getString("TCKN"));
			requestStartInput.setKullaniciKodu(iMap.getString("KULLANICI_KODU"));
			requestStartInput.setGsmNo(iMap.getString("GSM_NO"));
			requestStartInput.setDogrulanacakBankaAdedi(iMap.getInt("DOGRULAMA_ADET"));
			RequestStartOutput output=KkbGsmValidationIntServices.requestStart(getToken(), requestStartInput);
			logger.info("RequestStartOutput, Islem Sonucu:"+output.getIslemSonucu()
					+"-HataKodu:"+output.getHataKodu()
					+"-Hata Mesaji:"+output.getHataMesaji()
					+"-Hata Ek Aciklama:"+output.getEkHataAciklamasi()
					+"-Dogrulama Islem Id:"+output.getDogrulamaIslemId());
		} catch (Exception exp) {
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KKB_GSM_VALIDATION_INQUIRY")
	public static GMMap inquiry(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

		} catch (Exception exp) {
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KKB_GSM_VALIDATION_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

		} catch (Exception exp) {
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	private static String getToken(){
		GMMap tokenInputMap = new GMMap();
		tokenInputMap.put("SCOPE", "gsm-validation");
		return GMServiceExecuter.call("BNSPR_KKB_GET_TOKEN", tokenInputMap).getString("TOKEN");
	}
	
}
