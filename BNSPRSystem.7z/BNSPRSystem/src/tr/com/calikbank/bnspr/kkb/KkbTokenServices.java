package tr.com.calikbank.bnspr.kkb;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkbOauthToken;
import tr.com.aktifbank.kkb.oauth.model.CreateTokenOut;
import tr.com.aktifbank.kkb.oauth.model.RefreshTokenOut;
import tr.com.aktifbank.kkb.oauth.services.OAuthClientService;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
/**
 * It presents graymound services to get token from db and update all tokens 
 * @author feride.celik
 *
 */
public class KkbTokenServices {
	
	private static final Logger logger = Logger.getLogger(KkbTokenServices.class);

	/**
	 * This service is called by a job, it creates a valid token and update all token values.
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_KKB_OAUTH_GENERATE_TOKEN")
	public static GMMap generateOAuthToken(GMMap iMap) {
		List<String> failedScopeList = new ArrayList<String>();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<KkbOauthToken> token = session.createCriteria(KkbOauthToken.class).list();
			
			int tryCount = Integer.valueOf(OAuthClientService.getParameter("try_count"));
			for (KkbOauthToken kkbAuthToken : token) {
				iMap.put("KKB_OAUTH_TOKEN_OBJ", kkbAuthToken);
				iMap.put("SESSION", session);
				boolean isError = true;
				for(int i=0; (i<tryCount && isError) ; i++){ // some scopes are producing connect timeout error in the first try, so lets try more than once
					isError = Boolean.valueOf((String) GMServiceExecuter.executeNT("BNSPR_KKB_OAUTH_GENERATE_TOKEN_NT", iMap).get("IS_ERROR"));
				}
				if(isError){
					failedScopeList.add(kkbAuthToken.getScope());
				}
			}
			logger.info("Token values updated...");
			if(failedScopeList.size()>0){
				throw new GMRuntimeException(0, "Exception occured while processing these tokens: " + failedScopeList.toString());
			}
		}
		catch (Exception e) {
			logger.error("Exception occured while token values were updating...");
			throw ExceptionHandler.convertException(new GMRuntimeException(0, e.getMessage()));
		}

		return new GMMap();
	}
	
	@GraymoundService("BNSPR_KKB_OAUTH_GENERATE_TOKEN_NT")
	public static GMMap generateOAuthTokenNt(GMMap iMap) {
		boolean isError = false;
		Session session = (Session) iMap.get("SESSION");
		KkbOauthToken kkbAuthToken = (KkbOauthToken) iMap.get("KKB_OAUTH_TOKEN_OBJ");
		if(StringUtils.isEmpty(kkbAuthToken.getAuthToken()) || !DateUtils.isSameDay(new Date(), kkbAuthToken.getCreateDate())){
			// call create token service
			try {
				 CreateTokenOut createToken = OAuthClientService.createToken(kkbAuthToken);
				 kkbAuthToken.setAuthToken(createToken.getAccessToken());
				 kkbAuthToken.setRefreshToken(createToken.getRefreshToken());
				 kkbAuthToken.setCreateDate(new Date());
				 kkbAuthToken.setUpdateDate(new Date());
				 session.save(kkbAuthToken);
				 session.flush();
				 logger.info(String.format("Token for %s was created." , kkbAuthToken.getScope()));
			} catch (Exception e) {
				isError = true;
				logger.warn(String.format("Exception occured while creating token for the scope: " + kkbAuthToken.getScope()), e);
			}
		}
		else {
			// call refresh token service
			try {
				RefreshTokenOut refreshToken = OAuthClientService.refreshToken(kkbAuthToken);
				kkbAuthToken.setAuthToken(refreshToken.getAccessToken());
				kkbAuthToken.setRefreshToken(refreshToken.getRefreshToken());
				kkbAuthToken.setUpdateDate(new Date());
				session.save(kkbAuthToken);
				session.flush();
				logger.info(String.format("Token for %s was updated." , kkbAuthToken.getScope()));
			} catch (Exception e) {
				isError = true;
				logger.warn(String.format("Exception occured while refreshing token for the scope: " + kkbAuthToken.getScope()), e);
			}
		}
		return new GMMap().put("IS_ERROR", isError);
	}
	
	/**
	 * This service provides valid token from db
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_KKB_GET_TOKEN")
	public static GMMap getValidToken(GMMap iMap) {
		GMMap map = new GMMap();
		try{
			String scope = iMap.getString("SCOPE");
			Session session = DAOSession.getSession("BNSPRDal");
			KkbOauthToken kkbAuthToken = (KkbOauthToken) session.createCriteria(KkbOauthToken.class).
					add(Restrictions.eq("scope", scope)).uniqueResult();
			if(kkbAuthToken!=null)
				map.put("TOKEN", kkbAuthToken.getAuthToken());
			
		}catch (Exception e) {
			logger.error("Could not get token from db...:" + e);
			throw ExceptionHandler.convertException(new GMRuntimeException(0, e.getMessage()));
		}
		return map;
	}

}
