package tr.com.calikbank.bnspr.quartz;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.quartz.impl.StdScheduler;

import tr.com.aktifbank.bnspr.dao.MuhislemSmsGonder;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlJsJobTurTanim;
import tr.com.calikbank.bnspr.dao.GnlJsLog;
import tr.com.calikbank.bnspr.dao.MuhIslemMailGonder;
import tr.com.calikbank.bnspr.email.Mailer;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.CommonHelper;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SchedulerServices {
	static Log logger = LogFactory.getLog(SchedulerServices.class);
	
	static {
		addShutdownHookForJob();
	}
	
	private static void addShutdownHookForJob(){
		try {
			InitialContext iniCtx = new InitialContext();
			StdScheduler sched = (StdScheduler)iniCtx.lookup("Quartz");
			Runtime.getRuntime().addShutdownHook(new QuartzShutdownHook(sched));
			logger.info("Scheduler Shutdownhook Tanimlandi.");
		} catch (NamingException exp) {
			logger.error("Scheduler Tanimi Bulunamadi!");
			
		} catch (Exception exp) {
			logger.error("Scheduler Shutdownhook Tanimlanamadi!");
			logger.error(exp);
		}
	}

	@GraymoundService("BNSPR_QUARTZ_JOB_CALISSIN_MI")
	public static GMMap jobCalissinMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet=null;
		
		GMMap oMap = new GMMap();
		GMMap btMap = new GMMap();
		 
		//graymound un GMMap.getDate() methodunda reproduce edemedi�imiz bir bug var
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		btMap.put("TARIH", sdf.format(new Date()));
		boolean isGunumu = GMServiceExecuter.execute("BNSPR_TRN2301_GET_GUN_OZELLIK", btMap).get("RESULT").equals(new BigDecimal(0)) ? true : false;
		boolean calissin = true;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select a.tatil_gunu_calissin from GNL_JS_TANIM_PR a where a.job_adi = ?");
			stmt.setString(1, iMap.getString("JOB_NAME"));
			rSet = stmt.executeQuery();
			if(rSet.next()){
				String tatilGunu=rSet.getString(1);
				if(isGunumu && tatilGunu.equals("S")){
					calissin=false;
				} else if(!isGunumu && tatilGunu.equals("H")){
					calissin=false;
				}
			}
			
			oMap.put("CALISSIN", new Boolean(calissin).toString());
			oMap.put("ISGUNU", new Boolean(isGunumu).toString());
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(0 ,e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static final String MAIL_STATUS_SENT = "E";
	public static final String MAIL_STATUS_IN_PROGRESS = "P";
	public static final String MAIL_STATUS_FAILED = "X";
	 
	public static void main(String[] args) {
		List<Integer> mailIdList = new ArrayList<Integer>();
		mailIdList.add(10);
		mailIdList.add(3);
		mailIdList.add(22);
		mailIdList.add(123);
		mailIdList.add(4);
		mailIdList.add(57);
		mailIdList.add(2);
		mailIdList.add(2234);
		mailIdList.add(23);
		mailIdList.add(26);
	    List<List<Integer>> splittedMailList = CommonHelper.splitListWithThreadCount(mailIdList, 5);
	    System.out.println(splittedMailList.toString());
	}
	
	
	@GraymoundService("BNSPR_QUARTZ_GENERAL_EMAIL_JOB")
	public static GMMap runGeneralEmailJob(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select a.mail_id from muh_islem_mail_gonder a where DECODE(a.status, 'H', 'H', NULL) = 'H' ");
			rSet = stmt.executeQuery();
			List<BigDecimal> mailIdList = new ArrayList<BigDecimal>();
			while (rSet.next()) {
				mailIdList.add(rSet.getBigDecimal("mail_id"));
			}
		    										
		    if(mailIdList.size()>0){
				int threadSize = Integer.valueOf(CommonHelper.getGlobalParameter("MAIL_JOB_NUMBER_OF_THREADS"));
			    List<List<BigDecimal>> splittedMailIdList = CommonHelper.splitListWithThreadCount(mailIdList, threadSize);
				logger.info(String.format("%s adet email gonderimi %s thread ile yapiliyor..", mailIdList.size(), threadSize));
				logger.info(String.format("splittedMailIdList: %s", splittedMailIdList.toString()));
				
				List<GMMap> tasks = new ArrayList<GMMap>();
				for (int i = 0; i < splittedMailIdList.size(); i++) {
					GMMap emailMap = new GMMap();
					emailMap.put("MAIL_LIST_OBJ", splittedMailIdList.get(i));
					emailMap.put("T_SERVICE_NAME", "BNSPR_QUARTZ_MAIL_JOB_THREAD");
					tasks.add(emailMap);
				}

				if (tasks.size() > 0) {
					GMMap maps = new GMMap();
					maps.put("T_TASKS", tasks);
					GMMap result = GMServiceExecuter.callParallel(maps);
					@SuppressWarnings("unchecked")
					List<GMMap> responseList = (List<GMMap>) result.get("T_RESULTS");
					boolean isAllSuccessful = true;
					String error = "";
					for (GMMap gmMap : responseList) {
						if (gmMap.getBoolean("T_SUCCESSFUL")) {
							isAllSuccessful = isAllSuccessful & gmMap.getBoolean("T_SUCCESSFUL");
						} else {
							isAllSuccessful = false;
							error = error.concat("-").concat(gmMap.getString("ERROR"));
						}
					}
					if (isAllSuccessful) {
						logger.info("GENARAL EMAIL JOB - Tum emailler basarili olarak gonderildi...");
					} else {
						logger.info(String.format("GENARAL EMAIL JOB - Hata alan bazi email gonderimleri var: %s", error));
					}
				}
		    }
		}catch (Exception e) {
			BnsprSchedulerLogger.Log(logger, iMap.getString("JOB_NAME"), "GENARAL EMAIL JOB - Calisirken hata ile karsilasti", e.getMessage(), false);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_QUARTZ_MAIL_JOB_THREAD")
	public static GMMap mailJobThread(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal"); 
			@SuppressWarnings("unchecked")
			List<BigDecimal> mailIdList = (List<BigDecimal>) iMap.get("MAIL_LIST_OBJ");
			for (BigDecimal mailId : mailIdList) {
			    MuhIslemMailGonder muhIslemMailGonder = (MuhIslemMailGonder) session.createCriteria(MuhIslemMailGonder.class)
			    																	.add(Restrictions.eq("status", "H"))
			    																	.add(Restrictions.eq("mailId", mailId))
			    																	.uniqueResult();			   
																								
				BigDecimal mailID = muhIslemMailGonder.getMailId();
				if(updateMailStatus(mailID, MAIL_STATUS_IN_PROGRESS)){// mail kaydinin statusu baska bir job tarafindan guncellendiyse updateMailStatus false doner ve buraya girilmez, ikinci kez ayn� kayit icin mail gonderimini onluyoruz bu kontrolle
				
					GMMap mailServisMap = new GMMap();
					mailServisMap.put("FROM", muhIslemMailGonder.getMailFrom());
					if(StringUtils.isNotBlank(muhIslemMailGonder.getMailTo()))
						mailServisMap.put(Mailer.TO_KEY_NAME, GuimlUtil.createFromCommaSeparatedList(muhIslemMailGonder.getMailTo()));
					if(StringUtils.isNotBlank(muhIslemMailGonder.getMailCc()))
						mailServisMap.put(Mailer.CC_KEY_NAME, GuimlUtil.createFromCommaSeparatedList(muhIslemMailGonder.getMailCc()));
					if(StringUtils.isNotBlank(muhIslemMailGonder.getMailBcc()))
						mailServisMap.put(Mailer.BCC_KEY_NAME, GuimlUtil.createFromCommaSeparatedList(muhIslemMailGonder.getMailBcc()));
					mailServisMap.put("SUBJECT", muhIslemMailGonder.getMailSubject());
					String messageBody = muhIslemMailGonder.getMailBody();
					if(StringUtils.isBlank(messageBody)){
						messageBody = IOUtils.toString(muhIslemMailGonder.getMailBodyClob().getCharacterStream());
					}
					if(StringUtils.isNotBlank(muhIslemMailGonder.getMailBody2()))
						messageBody += muhIslemMailGonder.getMailBody2();
					if(StringUtils.isNotBlank(muhIslemMailGonder.getMailBody3()))
						messageBody += muhIslemMailGonder.getMailBody3(); 
					mailServisMap.put("MESSAGE_BODY", messageBody);
					mailServisMap.put("IS_BODY_HTML", "E".equals(muhIslemMailGonder.getBodyHtmlEh()) ? true: false );
					
					mailServisMap.put("DMS_FOLDER_NAME", mailID.toString());
					
					if(StringUtils.isNotBlank(muhIslemMailGonder.getFileName())){
						ArrayList<String> fileNames = GuimlUtil.createFromCommaSeparatedList(muhIslemMailGonder.getFileName());
						for (int i = 0; i < fileNames.size(); i++) {
							mailServisMap.put("ATTACMENT_FILE_LIST", i, "DMS_FILE_NAME", fileNames.get(i));
						}
					}
					try {
						GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);
						updateMailStatus(mailID, MAIL_STATUS_SENT);
						BnsprSchedulerLogger.Log(logger, iMap.getString("JOB_NAME"), mailID + " nolu mail ba�ar�yla g�nderildi", null, false);
					}catch (Exception e) { //mail g�nderilemedi
						updateMailStatus(mailID, MAIL_STATUS_FAILED);
						BnsprSchedulerLogger.Log(logger, iMap.getString("JOB_NAME"), mailID + " nolu mail g�nderilirken hata ile kar��la��ld�", e.getMessage(), false);
					}
				}	
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	private static boolean updateMailStatus(BigDecimal mailID, String status){
		GMMap servisMap = new GMMap();
		servisMap.put("MAIL_ID", mailID);
		servisMap.put("MAIL_STATUS", status);
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_QUARTZ_UPDATE_MAIL_STATUS", servisMap));
		return AkustikConstants.RESPONSE_SUCCESS.equals(oMap.getString("RESPONSE"));
	}

	@GraymoundService("BNSPR_QUARTZ_UPDATE_MAIL_STATUS")
	public static GMMap updateMailStatusGS(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call Pkg_Mail.mail_status_update(?, ?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MAIL_ID"));
			stmt.setString(2, iMap.getString("MAIL_STATUS"));
			stmt.execute();
		} catch (SQLException e) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QUARTZ_CREATE_SCHEDULER_LOG")
	public static GMMap logScheduler(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlJsLog log = new GnlJsLog();
			GMMap servisMap = new GMMap();
			servisMap.put("TABLE_NAME", "JOB_LOG_ID");
			log.setId((BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", servisMap).get("ID"));
			log.setJobName(iMap.getString("JOB_NAME"));
			log.setLogDate(new Date());
			log.setStatus(iMap.getString("STATUS"));
			log.setErrorMessage(iMap.getString("ERROR_MESSAGE"));
			log.setDescription(iMap.getString("DESCRIPTION"));
			session.save(log);
			session.flush();
		} catch (Exception e) {
			logger.error("BNSPR_QUARTZ_CREATE_SCHEDULER_LOG �al���rken hata ald�" + e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QUARTZ_RUN_BATCH_JOB")
	public static GMMap runBatchJob(GMMap iMap) {
		int batchNumber = iMap.getInt("BATCH_NUM");
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_batch.Is_Yarat(?,?)}");
			stmt.setInt(1, batchNumber);
			stmt.registerOutParameter(2, Types.NUMERIC);
			stmt.execute();
		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_QUARTZ_JOB_EXCEPTION_RECORD")
	public static GMMap createJobExceptionEmailRecord(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call JS_HATA_MAIL(?,?,?)}");
			stmt.setString(1, iMap.getString("JOB_NAME"));
			stmt.setString(2, iMap.getString("ERROR_MESSAGE"));
			stmt.setString(3, "H"); //E g�nderirsek developera mail gidiyor.
			stmt.execute();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_QUARTZ_RUN_TEST_JOB")
	public static GMMap runTestJob(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call log_user_global_params(?)}");
			stmt.setString(1, iMap.getString("VALUE"));
			stmt.execute();
			System.out.println("BIG_DECIMAL : " + iMap.getBigDecimal("BIG_DECIMAL"));
			System.out.println("STRING : " + iMap.getString("STRING"));
			System.out.println("INTEGER : " + iMap.getInt("INTEGER"));
			System.out.println("DATE : " + iMap.getDate("DATE"));
			System.out.println("BOOLEAN : " + iMap.getBoolean("BOOLEAN"));

			String test = "1";
			if("1".equals(test))
				throw new Exception("sentetik hata :) ");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_QUARTZ_RUN_HESAP_EXTRE_JOB")
	public static GMMap testHesapExtre(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt1 = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call pkg_ekstre.BasilacakHesapEkstreleriBul}");
			stmt.execute();
			stmt1 = conn.prepareCall("select x.yollama_turu, x.email, x.hesap_no, to_char(x.baslangic_tar, 'yyyymmdd') as BASLANGIC_TARIHI, to_char(x.bitis_tar,'yyyymmdd') as BITIS_TARIHI, nvl(x.OTO_EKSTRE_DIL_KOD, 'TR') OTO_EKSTRE_DIL_KOD, pkg_parametre.ParamTextDegerVarMi('COK_HAREKETLI_HESAP',x.hesap_no) as P_COK_HAREKETLI from muh_ekstre_log x where x.basilma_tar is null order by x.baslangic_tar desc");	
			rSet = stmt1.executeQuery();
			while(rSet.next()){
				BigDecimal hesapNo = rSet.getBigDecimal("HESAP_NO");
				long t1 = System.currentTimeMillis();
				logger.info(String.format("%s nolu hesap icin ekstre gonderimi yapiliyor...", hesapNo));
				
				GMMap paramMap=new GMMap();
				paramMap.put("YOLLAMA_TURU"		 , rSet.getString("YOLLAMA_TURU")		);
				paramMap.put("HESAP_NO"			 , hesapNo								);
				paramMap.put("BASLANGIC_TARIHI"	 , rSet.getString("BASLANGIC_TARIHI")	);
				paramMap.put("BITIS_TARIHI"		 , rSet.getString("BITIS_TARIHI")		);
				paramMap.put("OTO_EKSTRE_DIL_KOD", rSet.getString("OTO_EKSTRE_DIL_KOD")	);
				paramMap.put("EMAIL"			 , rSet.getString("EMAIL")				);
				paramMap.put("P_COK_HAREKETLI"   , rSet.getString("P_COK_HAREKETLI")	);
				
				GMServiceExecuter.executeNT("BNSPR_QUARTZ_RUN_HESAP_EXTRE_JOB_FOR_ONE_ACCOUNT", paramMap);
				logger.info(String.format("%s nolu hesap icin ekstre gonderimi %s saniyede yapildi...", hesapNo, (System.currentTimeMillis()-t1)));
			}
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}
	
	

	@GraymoundService("BNSPR_QUARTZ_RUN_HESAP_EXTRE_JOB_FOR_ONE_ACCOUNT")
	public static GMMap qrtzHesapExtreForOneAccount(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt1 = null;
		CallableStatement stmt2 = null;
		try {
			conn = DALUtil.getGMConnection();
			
			String yollamaTuru 		= iMap.getString		("YOLLAMA_TURU"			);
			BigDecimal hesapNo 		= iMap.getBigDecimal	("HESAP_NO"				);
			String baslangicTarihi 	= iMap.getString		("BASLANGIC_TARIHI"		);
			String bitisTarihi 		= iMap.getString		("BITIS_TARIHI"			);
			String ekstreDilKodu 	= iMap.getString		("OTO_EKSTRE_DIL_KOD"	);
			String pCokHareketli 	= iMap.getString		("P_COK_HAREKETLI"		);
			
			GMMap servisMap = new GMMap();
			servisMap.put("TABLE_NAME", "HESAP_HAREKET_NO");
			BigDecimal idNo = (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", servisMap).get("ID");
//				StringBuffer filePathSb = new StringBuffer("HESAP_EKSTRE/");
//				SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd");
//				filePathSb.append(sdf.format(new Date()));
//				filePathSb.append("/");
//				String filePath = filePathSb.toString();

			StringBuffer fileNameSb = new StringBuffer();
			fileNameSb.append(idNo);
			fileNameSb.append("_");
			fileNameSb.append(hesapNo);
			String fileName = fileNameSb.toString() + ".pdf";
			
			
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("P_KULLANICI_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", null).getString("KULLANICI_KOD"));
			parameters.put("HESAP_NO", hesapNo);
			parameters.put("EKSTRE_BASLANGIC_TAR", baslangicTarihi);
			parameters.put("EKSTRE_BITIS_TAR", bitisTarihi);
			parameters.put("P_COK_HAREKETLI", pCokHareketli);
			parameters.put("LOGOLU", true);
			JasperPrint jasperPrint = ReportUtil.generateReport(ekstreDilKodu.equals("EN")?"HESAP_EKSTRESI_INGILIZCE":"HESAP_EKSTRESI", parameters);
			
			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			String fileAbsPath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileAbsPath);
			pdfexporter.exportReport();

			File newFile = new File(fileAbsPath);
				
			GMMap ackMap = new GMMap();
			//ackMap.put("ACK_NO", "230");
			//String mailBody = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ACIKLAMA_PR", ackMap).get("TEXT");
			stmt1 = conn.prepareCall(ekstreDilKodu.equals("EN")?"{ ? =call pkg_ekstre.F_Mail_Body_Ing(?)}":"{ ? =call pkg_ekstre.F_Mail_Body(?)}");
			stmt1.registerOutParameter(1, Types.CHAR);
			stmt1.setBigDecimal(2, hesapNo);
			stmt1.execute();
			String mailBody = (String) stmt1.getObject(1);
			ackMap.put("ACK_NO", "231");
			String mailSubject= (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ACIKLAMA_PR", ackMap).get("TEXT");
			
			
			if(yollamaTuru.equals("E") || yollamaTuru.equals("EP")){
				String mailTo = iMap.getString("EMAIL");
				if(mailTo != null){
					GMMap mailServisMap = new GMMap();
		            mailServisMap.put("FROM" , "aktifbank@aktifbank.com.tr");
					mailServisMap.put("SUBJECT", mailSubject);
					mailServisMap.put("MESSAGE_BODY", mailBody);
					mailServisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", fileName);
					mailServisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(newFile));
		            mailServisMap.put("RECIPIENTS_TO" , GuimlUtil.createFromCommaSeparatedList(mailTo));
					mailServisMap.put("IS_BODY_HTML", true);
					mailServisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
					GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);
				}
			}
			stmt2 = conn.prepareCall("{ call pkg_ekstre.SonEkstreTarihiniGuncelle(?)}");
			stmt2.setBigDecimal(1, hesapNo);
			stmt2.execute();
			
//				Mail g�nderme methodunda fileller zaten DYS ye at�l�yor 
//				WebdavClient client =  new WebdavClient();
//		        client.createNestedDirectories("", filePath);
//		        client.put(filePath, newFile);
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		
		return new GMMap();
	}

	
	
	
	@GraymoundService("BNSPR_QUARTZ_CALL_GM_SERVIS")
	public static GMMap callGmService(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			GMServiceExecuter.execute(iMap.getString("SERVICE_NAME"), iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e.getMessage());
		}
		return oMap;
	}
	
	//bu servis art�k kullan�lm�yor
	@GraymoundService("BNSPR_QUARTZ_GET_FILE_PATH")
	public static GMMap getTempFilePath(GMMap iMap) {
		GMMap oMap = new GMMap();
		String graymoundHome = GMServer.getProperty("graymound.home", "");
		String folderName = GMServer.getProperty("temp.file.folder", "db-share");
		oMap.put("FILE_PATH", graymoundHome + "/" + folderName + "/");
		System.err.println("GRAUMOUND HOME" + graymoundHome + "/" + folderName + "/");
		return oMap;
	}

	@GraymoundService("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB")
	public static GMMap runSN(GMMap iMap) {
		GMServiceExecuter.execute("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB_41", iMap);
		//GMServiceExecuter.execute("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB_SN", iMap);
		GMServiceExecuter.execute("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB_42", iMap);
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB_41")
	public static GMMap run41(GMMap iMap) {
		GMMap oMap = new GMMap();
		int duzenliOdemeP1 = 41;
		Connection conn = null;
		CallableStatement stmtBatch = null;
		try{
			conn = DALUtil.getGMConnection();
			stmtBatch = conn.prepareCall("{call pkg_batch.Is_Yarat(?,?)}");
			stmtBatch.setInt(1, duzenliOdemeP1);
			stmtBatch.registerOutParameter(2, Types.NUMERIC);
			stmtBatch.execute();
		} catch (Exception e) {
			throw new GMRuntimeException(99, e.getMessage());
		} finally {
			GMServerDatasource.close(stmtBatch);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB_42")
	public static GMMap run42(GMMap iMap) {
		GMMap oMap = new GMMap();
		int duzenliOdemeP2 = 42;

		Connection conn = null;
		CallableStatement stmtBatch = null;
		try{
			conn = DALUtil.getGMConnection();
			stmtBatch = conn.prepareCall("{call pkg_batch.Is_Yarat(?,?)}");
			stmtBatch.setInt(1, duzenliOdemeP2);
			stmtBatch.registerOutParameter(2, Types.NUMERIC);
			stmtBatch.execute();
			GMServiceExecuter.execute("BNSPR_QUARTZ_RUN_REMOTE_PROCESS_LOG", new GMMap().put("LOG_NO", stmtBatch.getBigDecimal(2)));
		} catch (Exception e) {
			throw new GMRuntimeException(99, e.getMessage());
		} finally {
			GMServerDatasource.close(stmtBatch);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_QUARTZ_RUN_REMOTE_PROCESS_LOG")
	public static GMMap runRemoteProcessLog(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			query.append("select musteri_no, musteri_tckimno,process_code,process_date,doviz_kod,tutar,channel_code, status, status_message, sira_no, taksit_id ")
				 .append("from gnl_duzenli_odeme_process_log ")
				 .append("where log_no=? ");
			
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("LOG_NO"));
			
			rSet = stmt.executeQuery();
			GMMap serviceMap;
			while (rSet.next()) {
				int j=2;
				serviceMap = new GMMap();
				serviceMap.put("USER_CODE", rSet.getString(j++));
				serviceMap.put("PROCESS_CODE", rSet.getString(j++));
				serviceMap.put("PROCESS_DATE", rSet.getString(j++));
				serviceMap.put("AMOUNT_CODE", rSet.getString(j++));
				serviceMap.put("AMOUNT", rSet.getBigDecimal(j++));
				serviceMap.put("CHANNEL_CODE", rSet.getString(j++));
				serviceMap.put("PROCESS_KEY", "0");
				// TODO: Ask Sinem Aybal
				serviceMap.put("STATUS", rSet.getString(j++));
				serviceMap.put("STATUS_MESSAGE", rSet.getString(j++));
				serviceMap.put("REC_ID", rSet.getString(j++));
				serviceMap.put("INST_ID", rSet.getString(j++));

				serviceMap.put("SERVICE_NAME", "ADC_REMOTE_DIRECTIVE_PROCESS_LOG");
				GMServiceExecuter.execute("ADK_CALL_SERVICE", serviceMap);
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0, e.getMessage());
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new GMMap();
	}
	@GraymoundService("BNSPR_QUARTZ_RUN_DUZENLI_ODEME_JOB_SN")
	public static GMMap runDuzenliOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmtOracleUpdate = null;
		CallableStatement stmtOracleSelect = null;
		ResultSet oracleRSet = null;
		try{
			conn = DALUtil.getGMConnection();
			StringBuffer sbOracleQuery = new StringBuffer();
			sbOracleQuery.append("select a.rowid from gnl_gun_duzenli_odeme a ");
			sbOracleQuery.append("where a.odeme_tarihi = pkg_muhasebe.Banka_Tarihi_Bul ");
			sbOracleQuery.append("and a.odeme_sekli = 'EFT' ");
			sbOracleQuery.append("and a.sorgu_no is null ");
			stmtOracleSelect = conn.prepareCall(sbOracleQuery.toString());
			
			StringBuffer sbOracleUpdate = new StringBuffer();
			sbOracleUpdate.append("update gnl_gun_duzenli_odeme a ");
			sbOracleUpdate.append("set a.sorgu_no = ?,");
			sbOracleUpdate.append("a.eft_ref = ? ");
			sbOracleUpdate.append("where a.rowid = ? ");
			stmtOracleUpdate = conn.prepareCall(sbOracleUpdate.toString());
			
			oracleRSet = stmtOracleSelect.executeQuery();
			while(oracleRSet.next()){
				String rowid = oracleRSet.getString(1);
				Map<?, ?> sorguNoSevisMap = GMServiceExecuter.execute("BNSPR_TRN2315_GET_SORGU_NO", new GMMap());
				
				stmtOracleUpdate.clearParameters();
				stmtOracleUpdate.setString(1, (String)sorguNoSevisMap.get("SORGU_NO"));
				stmtOracleUpdate.setString(2, (String)sorguNoSevisMap.get("REF"));
				stmtOracleUpdate.setString(3, rowid);
				stmtOracleUpdate.execute();
			}

		} catch (Exception e) {
			throw new GMRuntimeException(99, e.getMessage());
		} finally {
			GMServerDatasource.close(oracleRSet);
			GMServerDatasource.close(stmtOracleUpdate);
			GMServerDatasource.close(stmtOracleSelect);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QUARTZ_GET_JOB_SERVICE_NAME")
	public static GMMap getJobServiceName(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlJsJobTurTanim jobTurTanim = (GnlJsJobTurTanim)session.get(GnlJsJobTurTanim.class, iMap.getBigDecimal("JOB_TUR_KOD"));
			oMap.put("SERVICE_NAME", jobTurTanim.getServiceName());
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_QUARTZ_GET_SERVIS_MAP")
	public static GMMap getServisMap(GMMap iMap) {
		GMMap serviceMap;
		if(iMap.get("SERVICE_MAP") == null)
			serviceMap=new GMMap();
		else
			serviceMap=(GMMap)iMap.get("SERVICE_MAP");
		
		iMap.remove("SERVICE_MAP");
		serviceMap.putAll(iMap);
		
		GMMap oMap=new GMMap();
		oMap.put("SERVICE_MAP", serviceMap);
		return oMap;
	}
	
	@GraymoundService("BNSPR_QUARTZ_SET_SERVIS_MAP")
	public static GMMap setServisMap(GMMap iMap) {
		if(iMap.get("SERVICE_MAP") == null)
			return new GMMap();
		else
			return (GMMap)iMap.get("SERVICE_MAP");
	}
	public static final String SMS_STATUS_SENT = "E";
	public static final String SMS_STATUS_IN_PROGRESS = "P";
	public static final String SMS_STATUS_FAILED = "X";
	
	@GraymoundService("BNSPR_QUARTZ_GENERAL_SMS_JOB")
	public static GMMap runGeneralSmsJob(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal"); 
		    @SuppressWarnings("unchecked")
			List<MuhislemSmsGonder> smsList = session.createCriteria(MuhislemSmsGonder.class).add(Restrictions.eq("status", "H"))
		    																   				 .addOrder(Order.asc("smsId"))
		    																   				 .list();
		    										
		    if(smsList.size()>0){
				int threadSize = Integer.valueOf(CommonHelper.getGlobalParameter("SMS_JOB_NUMBER_OF_THREADS"));
			    List<List<MuhislemSmsGonder>> splittedSmsList = CommonHelper.splitListWithThreadCount(smsList, threadSize);
			    
				List<GMMap> tasks = new ArrayList<GMMap>();
				for (int i = 0; i < splittedSmsList.size(); i++) {
					GMMap emailRequest = new GMMap();
					emailRequest.put("SMS_LIST_OBJ", splittedSmsList.get(i));
					emailRequest.put("T_SERVICE_NAME", "BNSPR_QUARTZ_SMS_JOB_THREAD");
					tasks.add(emailRequest);
				}

				if (tasks.size() > 0) {
					GMMap maps = new GMMap();
					maps.put("T_TASKS", tasks);
					GMMap result = GMServiceExecuter.callParallel(maps);
					@SuppressWarnings("unchecked")
					List<GMMap> responseList = (List<GMMap>) result.get("T_RESULTS");
					boolean isAllSuccessful = true;
					String error = "";
					for (GMMap gmMap : responseList) {
						if (gmMap.getBoolean("T_SUCCESSFUL")) {
							isAllSuccessful = isAllSuccessful & gmMap.getBoolean("T_SUCCESSFUL");
						} else {
							isAllSuccessful = false;
							error = error.concat("-").concat(gmMap.getString("ERROR"));
						}
					}
					if (isAllSuccessful) {
						logger.info("GENARAL SMS JOB - Tum smsler basarili olarak gonderildi...");
					} else {
						logger.info(String.format("GENARAL SMS JOB - Hata alan bazi sms gonderimleri var: %s", error));
					}
				}
		    }
		}catch (Exception e) {
			BnsprSchedulerLogger.Log(logger, iMap.getString("JOB_NAME"), "GENARAL SMS JOB - Calisirken hata ile karsilasti", e.getMessage(), false);
		} 
		return new GMMap();
	}
	
	private static void updateSmsStatus(BigDecimal smsID, String status){
		GMMap servisMap = new GMMap();
		servisMap.put("SMS_ID", smsID);
		servisMap.put("SMS_STATUS", status);
		GMServiceExecuter.executeNT("BNSPR_QUARTZ_UPDATE_SMS_STATUS", servisMap);
	}
	
	@GraymoundService("BNSPR_QUARTZ_SMS_JOB_THREAD")
	public static GMMap smsJobThread(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			@SuppressWarnings("unchecked")
			List<MuhislemSmsGonder> smsList = (List<MuhislemSmsGonder>) iMap.get("SMS_LIST_OBJ");
			for (MuhislemSmsGonder muhislemSmsGonder : smsList) {

				BigDecimal smsID = muhislemSmsGonder.getSmsId();
				updateSmsStatus(smsID, SMS_STATUS_IN_PROGRESS);
				GMMap smsServisMap = new GMMap();
				smsServisMap.put("MSISDN", muhislemSmsGonder.getCepTel());
				smsServisMap.put("CONTENT", muhislemSmsGonder.getMesaj());
				smsServisMap.put("FILTER", muhislemSmsGonder.getFilter());
				smsServisMap.put("SECURE_CONTENT", muhislemSmsGonder.getSecureContent());
				smsServisMap.put("HEADER", muhislemSmsGonder.getHeader());

				try {
					int mesajTuru = muhislemSmsGonder.getMesajTuru().intValue();
					if (1 == mesajTuru)
						GMServiceExecuter.execute("BNSPR_SMS_SEND_BULK_SMS", smsServisMap);
					else if (2 == mesajTuru)
						GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsServisMap);
					else if (3 == mesajTuru)
						GMServiceExecuter.execute("BNSPR_SMS_SEND_OTP", smsServisMap);
					updateSmsStatus(smsID, SMS_STATUS_SENT);
					BnsprSchedulerLogger.Log(logger, iMap.getString("JOB_NAME"), smsID + " nolu sms basariyla gonderildi", null, false);
				} catch (Exception e) { // sms g�nderilemedi
					updateSmsStatus(smsID, SMS_STATUS_FAILED);
					BnsprSchedulerLogger.Log(logger, iMap.getString("JOB_NAME"), smsID + " nolu sms gonderilirken hata ile karsilasildi", e.getMessage(), false);
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QUARTZ_UPDATE_SMS_STATUS")
	public static GMMap updateSmsStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_sms.sms_status_update(?, ?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("SMS_ID"));
			stmt.setString(2, iMap.getString("SMS_STATUS"));
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
