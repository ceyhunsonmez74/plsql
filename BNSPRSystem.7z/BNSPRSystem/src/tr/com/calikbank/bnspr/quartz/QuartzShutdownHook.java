package tr.com.calikbank.bnspr.quartz;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.impl.StdScheduler;

public class QuartzShutdownHook extends Thread {

	static Log logger = LogFactory.getLog(QuartzShutdownHook.class);
	
	private StdScheduler sched=null;
	
	public QuartzShutdownHook(StdScheduler sched) {
		this.sched=sched;
	}
	
	@Override
	public void run() {
		if(sched!=null && !sched.isShutdown()){
			logger.info("Scheduler Kapatiliyor!!!");
			sched.shutdown(true);
		}else{
			logger.info("Scheduler Zaten Kapali!!!");
		}
	}
	
}
