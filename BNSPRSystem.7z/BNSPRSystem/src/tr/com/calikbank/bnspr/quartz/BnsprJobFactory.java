package tr.com.calikbank.bnspr.quartz;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Trigger.TriggerState;
import org.quartz.TriggerKey;
import org.quartz.impl.StdScheduler;
import org.quartz.impl.matchers.GroupMatcher;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.quartz.QuartzEnums.JobHolidayOptions;
import tr.com.calikbank.bnspr.quartz.QuartzEnums.MisfirePolicy;
import tr.com.calikbank.bnspr.system.util.Constants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.connection.GMConnection;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BnsprJobFactory{
	
	private static final Class<BnsprBaseJob> BASE_JOB_CLASS = tr.com.calikbank.bnspr.quartz.BnsprBaseJob.class;
	private static final Class<BnsprStatefulJob> STATEFUL_JOB_CLASS = tr.com.calikbank.bnspr.quartz.BnsprStatefulJob.class;

	protected JobDetail createJob(GMMap iMap){
		//JobDetail jobDetail =  new JobDetail(iMap.getString("JOB_NAME"), DEFAULT_BNSPR_JOB_GROUB_NAME, iMap.getBoolean("CONCURRENCY_ALLOWED") ? BASE_JOB_CLASS : STATEFUL_JOB_CLASS);

		JobDetail jobDetail = newJob(iMap.getBoolean("CONCURRENCY_ALLOWED") ? BASE_JOB_CLASS : STATEFUL_JOB_CLASS)
				    .withIdentity(iMap.getString("JOB_NAME"), Constants.DEFAULT_BNSPR_JOB_GROUB_NAME)
				    .withDescription(iMap.getString("DESCRIPTION"))
				    .requestRecovery(iMap.getBoolean("RECOVERY"))
				    .build();
	
		jobDetail.getJobDataMap().put("JOB_SERVICE_NAME", getServiceName(iMap.getBigDecimal("JOB_TUR_KOD")));
		
		
		//parametre ekranindan doldurulan map
		if(iMap.get("SERVICE_MAP") != null)
			iMap.putAll((Map<?, ?>)iMap.get("SERVICE_MAP"));
		
		if(iMap!=null){
			JobDataMap jobDataMap=new JobDataMap();
			Iterator<Object> cacheItr=iMap.keySet().iterator();
			while(cacheItr.hasNext()){
				Object iMapKey=cacheItr.next();
				jobDataMap.put(String.valueOf(iMapKey), iMap.get(iMapKey));
			}
			jobDetail.getJobDataMap().putAll(jobDataMap);
		}
		return jobDetail;
	}
	
	private String getServiceName (BigDecimal jobTurKod){
		GMMap servisMap = new GMMap();
		servisMap.put("JOB_TUR_KOD", jobTurKod);
		GMConnection gmCon = null;
		try{
			gmCon = BnsprConnection.getConnection();
			return (String)gmCon.serviceCall("BNSPR_QUARTZ_GET_JOB_SERVICE_NAME", servisMap).get("SERVICE_NAME");
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally{
			BnsprConnection.closeConnection(gmCon);
		}
	}

	protected CronTrigger createCronTrigger(GMMap iMap){
		try {
			
	        Calendar startTime = Calendar.getInstance();
	        startTime.setTime(new Date());
	        startTime.add(Calendar.MINUTE, 1);
			
	        CronTrigger trigger = newTrigger()
	                .withIdentity(iMap.getString("JOB_NAME"), Constants.DEFAULT_BNSPR_JOB_GROUB_NAME)
	                .withSchedule(createCronSchedule(iMap))
	                .withDescription(iMap.getString("DESCRIPTION"))
	                .startAt(startTime.getTime())
	                .build();
			
			return trigger;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	private CronScheduleBuilder createCronSchedule(GMMap iMap){
		String cronExpression=iMap.getString("CRON_EXPRESSION");
		int misfirePolicy=iMap.getInt("MISFIRE_POLICY");
		
		if(MisfirePolicy.DoNothing.getValue()==misfirePolicy) {
			return cronSchedule(cronExpression).withMisfireHandlingInstructionDoNothing();
			
		} else if(MisfirePolicy.IgnoreMisfires.getValue()==misfirePolicy) {
			return cronSchedule(cronExpression).withMisfireHandlingInstructionIgnoreMisfires();
			
		} else {
			return cronSchedule(cronExpression);
		}
		
	}
	
	public void scheduleJob(GMMap iMap){
		JobDetail jobDetail = null;
		InitialContext iniCtx = null;
		StdScheduler sched = null;
		CronTrigger trigger = null;
		try {
			iniCtx = new InitialContext();
			sched = (StdScheduler)iniCtx.lookup("Quartz");
			
			jobDetail = createJob(iMap);
			trigger = createCronTrigger(iMap);
			
	        //jobDetail.setDescription(iMap.getString("DESCRIPTION"));
	        
	        //Calendar startTime = Calendar.getInstance();
	        //startTime.setTime(new Date());
	        //startTime.add(Calendar.MINUTE, 1);
	        
	        //trigger.setStartTime(startTime.getTime());
	        sched.scheduleJob(jobDetail, trigger);
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	public void deleteJob(GMMap iMap){
		try {
			StdScheduler sched = getStandartScheduler();
			sched.deleteJob(new JobKey(iMap.getString("JOB_NAME"), getJobGrupName(iMap)));
		} catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0, e);
		} 
	}
	
	public void resumeJob(GMMap iMap){
		try {
			StdScheduler sched = getStandartScheduler();
			sched.resumeJob(new JobKey(iMap.getString("JOB_NAME"), getJobGrupName(iMap)));
		} catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0, e);
		} 
	}
	
	public void pauseJob(GMMap iMap){
		try {
			StdScheduler sched = getStandartScheduler();
			sched.pauseJob(new JobKey(iMap.getString("JOB_NAME"), getJobGrupName(iMap)));
		} catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0, e);
		} 
	}
	
	public void triggerJob(GMMap iMap){
		try {
			StdScheduler sched = getStandartScheduler();
			sched.triggerJob(new JobKey(iMap.getString("JOB_NAME"), getJobGrupName(iMap)));
		} catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0, e);
		} 
	}
	
	public void triggerJobWithData(GMMap iMap){
		try {
			JobDataMap jobDataMap=new JobDataMap();
			if(iMap!=null){
				int tableSize=iMap.getSize("JOB_DATA_LIST");
				for(int index=0;index<tableSize;index++){
					jobDataMap.put(iMap.getString("JOB_DATA_LIST", index, "KEY"), iMap.getString("JOB_DATA_LIST", index, "VALUE"));
				}
			}
			StdScheduler sched = getStandartScheduler();
			sched.triggerJob(new JobKey(iMap.getString("JOB_NAME"), getJobGrupName(iMap)),jobDataMap);
		} catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0, e);
		} 
	}
	
	public GMMap getAllJob(String tableName,GMMap oMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			StdScheduler sched = getStandartScheduler();
			//List<String> jobsInGroup = sched.getTriggerNames(DEFAULT_BNSPR_JOB_GROUB_NAME);
			
			StringBuilder sb = new StringBuilder();
			sb.append("select a.batch_grup_kod, a.aciklama, a.job_tur_kod, b.job_tur_ad, a.tatil_gunu_calissin, b.service_name, b.parameter_guiml_name, a.job_id, a.concurrency_allowed, a.sched_id, a.misfire_policy, a.recovery, a.job_owner_id ");
			sb.append("from gnl_js_tanim_pr a, gnl_js_job_tur_tanim b ");
			sb.append("where a.job_tur_kod = b.job_tur_kod ");
			sb.append("and a.job_adi = ? ");
			conn = DALUtil.getGMConnection();

			/*for (JobKey jobKey : scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName))) {
				 
			  String jobName = jobKey.getName();
			  String jobGroup = jobKey.getGroup();
			
			  //get job's trigger
			  List<Trigger> triggers = (List<Trigger>) scheduler.getTriggersOfJob(jobKey);
			  Date nextFireTime = triggers.get(0).getNextFireTime(); 
			
				System.out.println("[jobName] : " + jobName + " [groupName] : "
				+ jobGroup + " - " + nextFireTime);
			
			}	*/		
			
			int index=oMap.getSize(tableName);
			for(JobKey jobKey : sched.getJobKeys(GroupMatcher.jobGroupEquals(Constants.DEFAULT_BNSPR_JOB_GROUB_NAME))){
			//for (int i = 0; i < jobsInGroup.length; i++) {
				CronTrigger trg = (CronTrigger)sched.getTrigger(new TriggerKey(jobKey.getName(), jobKey.getGroup()));
				oMap.put(tableName, index, "JOB_NAME", trg.getKey().getName());
				oMap.put(tableName, index, "CRON_STATEMENT", trg.getCronExpression());
				oMap.put(tableName, index, "DESCRIPTION", trg.getDescription());
				TriggerState triggerState =  sched.getTriggerState(trg.getKey());
				oMap.put(tableName, index, "STATUS", getTriggerState(triggerState));
				GMMap serviceMap = new GMMap();
				serviceMap.put("value", sched.getJobDetail(jobKey).getJobDataMap().get("SERVICE_MAP"));
				oMap.put(tableName, index, "SERVICE_MAP", serviceMap);
				stmt = conn.prepareCall(sb.toString());
				stmt.setString(1, trg.getKey().getName());
				rSet = stmt.executeQuery();
				
				if(rSet.next()){
					oMap.put(tableName, index, "BATCH_KOD", rSet.getBigDecimal("batch_grup_kod"));
					oMap.put(tableName, index, "TATIL_GUNU", rSet.getString("tatil_gunu_calissin"));
					oMap.put(tableName, index, "TATIL_GUNU_ACIKLAMA", JobHolidayOptions.valueOf(rSet.getString("tatil_gunu_calissin")).getOptionName());
					oMap.put(tableName, index, "DESCRIPTION", rSet.getString("aciklama"));
					oMap.put(tableName, index, "JOB_TUR_KOD", rSet.getString("job_tur_kod"));
					oMap.put(tableName, index, "JOB_TURU", rSet.getString("job_tur_ad"));
					oMap.put(tableName, index, "SERVICE_NAME", rSet.getString("service_name"));
					oMap.put(tableName, index, "PARAMETER_GUIML_NAME", rSet.getString("parameter_guiml_name"));
					oMap.put(tableName, index, "JOB_ID", rSet.getString("job_id"));
					oMap.put(tableName, index, "CONCURRENCY_ALLOWED", GuimlUtil.convertToCheckBoxValue(rSet.getString("concurrency_allowed")));
					oMap.put(tableName, index, "SCHED_ID",rSet.getString("sched_id"));
					oMap.put(tableName, index, "MISFIRE_POLICY",rSet.getString("misfire_policy"));
					oMap.put(tableName, index, "RECOVERY", rSet.getBoolean("recovery")?1:0);
					oMap.put(tableName, index, "OWNER_ID", rSet.getBigDecimal("job_owner_id"));
				}
				index++;
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private String getTriggerState(TriggerState state) { 
		String triggerState = ""; 	
		
		switch(state) { 
			case BLOCKED: triggerState = "Running"; break; 
			case COMPLETE: triggerState = "Complete"; break; 
		    case ERROR: triggerState = "Error"; break; 
	      	case NONE: triggerState = "N/A"; break; 
			case NORMAL: triggerState = "Normal"; break; 
			case PAUSED: triggerState = "Paused"; break; 
			default: triggerState = "No such State"; break; 
		}
		
		return triggerState; 
	}
	
	private static StdScheduler getStandartScheduler() throws NamingException{
		InitialContext iniCtx = new InitialContext();
		return (StdScheduler)iniCtx.lookup("Quartz");
	}
	
	protected String getJobGrupName(GMMap map) {
		return Constants.DEFAULT_BNSPR_JOB_GROUB_NAME;
	}
}
