package tr.com.calikbank.bnspr.quartz;

import java.io.IOException;

import org.apache.commons.logging.Log;

import com.graymound.connection.GMConnection;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BnsprSchedulerLogger {

	public static void Log(GMConnection gmConnection, Log logger, String jobName, String description, String errorMessage, boolean sendEmail){
		GMMap servisMap = new GMMap();
		servisMap.put("JOB_NAME", jobName);
		servisMap.put("ERROR_MESSAGE", errorMessage);
		servisMap.put("DESCRIPTION", description);
		logger.info(description);
		if (sendEmail){
			logger.info(errorMessage);
			createJobExceptionEmailRecord(gmConnection, jobName, description, errorMessage);
		}
		try {
			gmConnection.serviceCall("BNSPR_QUARTZ_CREATE_SCHEDULER_LOG", servisMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void Log(Log logger, String jobName, String description, String errorMessage, boolean sendEmail){
		GMMap servisMap = new GMMap();
		servisMap.put("JOB_NAME", jobName);
		//servisMap.put("STATUS", log.getStatus());
		servisMap.put("ERROR_MESSAGE", errorMessage);
		servisMap.put("DESCRIPTION", description);
		logger.info(description);
		if (sendEmail){
			logger.info(errorMessage);
			createJobExceptionEmailRecord(jobName, description, errorMessage);
		}
		try {
			GMServiceExecuter.executeNT("BNSPR_QUARTZ_CREATE_SCHEDULER_LOG", servisMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void createJobExceptionEmailRecord(GMConnection gmConnection, String jobName, String description, String errorMessage){
		GMMap servismap = new GMMap();
		servismap.put("JOB_NAME", jobName);
		servismap.put("ERROR_MESSAGE", description + " -- " + errorMessage);
		try {
			gmConnection.serviceCall("BNSPR_QUARTZ_JOB_EXCEPTION_RECORD", servismap);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void createJobExceptionEmailRecord(String jobName, String description, String errorMessage){
		GMMap servismap = new GMMap();
		servismap.put("JOB_NAME", jobName);
		servismap.put("ERROR_MESSAGE", description + " -- " + errorMessage);
		GMServiceExecuter.execute("BNSPR_QUARTZ_JOB_EXCEPTION_RECORD", servismap);
	}
}