package tr.com.calikbank.bnspr.quartz;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import tr.com.calikbank.bnspr.system.util.Constants;

import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BnsprBaseJob implements Job {
	
	static Log logger = LogFactory.getLog(BnsprBaseJob.class);
	public static final String JOB_NAME_KEY = "JOB_NAME";
	private String jobName;
	private GMConnection gmConnection;
	
	public void execute(JobExecutionContext context) throws JobExecutionException {
		if(isLocalDevelopementServer()){
			//System.err.print("job localDevelopmentServer");
			return;
		}
		jobName = context.getJobDetail().getJobDataMap().getString(JOB_NAME_KEY);
		if(context.isRecovering()) {
			logger.info("RECOVERING JOB NAME : "+jobName);
		}
		try {
			gmConnection = BnsprConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
			reportConnectionError();
			return;
		}
		boolean afterActionState=false;
		try {
			GMMap servisMap = new GMMap(context.getMergedJobDataMap());
			Map<?, ?> oMap = gmConnection.serviceCall("BNSPR_QUARTZ_JOB_CALISSIN_MI", servisMap);
			if(oMap.get("CALISSIN").equals("true")){
				logStatus("BnsprJob.execute", "job �al��maya ba�lad�",  null);
				afterActionState=true;
				gmConnection.serviceCall(servisMap.getString("JOB_SERVICE_NAME"), servisMap);
				logStatus("BnsprJob.execute", "job �al��mas� ba�ar�yla tamamland�",  null);
			} else {
				if(oMap.get("ISGUNU").equals("true")) {
					logStatus("BnsprJob.execute", "i� g�n� oldu�u i�in job �al��t�r�lmad�", null);
				} else {
					logStatus("BnsprJob.execute", "tatil g�n� oldu�u i�in job �al��t�r�lmad�", null);
				}
			}
		} catch (Exception e) {
			logger.error(e);
			afterActionState=false;
			logStatus("BnsprJob.execute ", jobName+" job �al���rken hata ile kar��la�t�",  e.getMessage());
			
		} finally{
			context.getJobDetail().getJobDataMap().put(Constants.AFTER_ACTION_STATE, afterActionState);
			BnsprConnection.closeConnection(gmConnection);
		}
	}
	
	private boolean isLocalDevelopementServer(){
		return "E".equals(GMServer.getProperty("LOCAL_DEV_SERVER", "H"));
	}
	
	protected String createStatusMessage(String methodName, String statusMessage){
		return new StringBuilder(jobName)
			.append(" -- ")
			.append(methodName)
			.append(" -- ")
			.append(statusMessage)
			.toString();
	}
	
	protected void logStatus(String methodName, String description, String errorMessage){
		BnsprSchedulerLogger.Log(gmConnection, logger, jobName,  createStatusMessage(methodName, description), errorMessage, errorMessage != null);
	}
	
	protected void reportConnectionError(){
		GMMap mailMap = new GMMap();
		List<String> toList = new ArrayList<String>();
		toList.add("BTYazilimGelistirme@aktifbank.com.tr");
		mailMap.put("FROM","BNSPR-System@aktifbank.com.tr");
		mailMap.put("RECIPIENTS_TO", toList);
		mailMap.put("SUBJECT", "Job Hata");
		mailMap.put("MESSAGE_BODY", "GMConnection al�n�rken hata olu�tu");
		GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailMap);
	}
	
	protected GMConnection getConnection(){
		return gmConnection;
	}
	
	protected String getjobName(){
		return jobName;
	}
}
