package tr.com.calikbank.bnspr.quartz;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.listeners.JobListenerSupport;

import tr.com.calikbank.bnspr.system.util.Constants;

import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class BnsprJobListener extends JobListenerSupport {

	private String name; 
	
	public BnsprJobListener() {
		
	}
	
	@Override
	public void jobWasExecuted(JobExecutionContext context, JobExecutionException jobException) {
		getLog().info("jobWasExecuted Begin: "+context.getJobDetail().getKey());

        try {
    		if(context.getJobDetail().getJobDataMap()!=null 
    				&& context.getJobDetail().getJobDataMap().containsKey(Constants.AFTER_ACTION_NAME)
    				&& context.getJobDetail().getJobDataMap().getBoolean(Constants.AFTER_ACTION_STATE)) {
    			
	        	 String jobName=context.getJobDetail().getJobDataMap().getString(Constants.AFTER_ACTION_NAME);
	        	 if(!StringUtils.isEmpty(jobName)){
		        	 JobKey jobKey=new JobKey(jobName, Constants.DEFAULT_BNSPR_JOB_GROUB_NAME);
		        	 if(context.getScheduler().checkExists(jobKey)){

		        		 callTriggerJobService(jobKey);
		        		 
		        		 getLog().info("Tetiklenen Job: "+jobKey);
		        	 }else{
		        		 getLog().error("Linked Job Mevcut Degil! "+jobKey);
		        	 }
	        	 }
    		}
        } catch(Exception exp) {
            getLog().error("Scheduler Exception in jobWasExecuted:", exp);
        }
		
		getLog().info("jobWasExecuted End: "+context.getJobDetail().getKey());
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String getName() {
		return name;
	}
	
	private void callTriggerJobService(JobKey jobKey) throws IOException{
		GMConnection gmConnection=null;
		try {
			gmConnection = BnsprConnection.getConnection();
			gmConnection.serviceCall("BNSPR_PAR9949_TRIGGER_REMOTE_JOB", new GMMap().put("JOB_NAME", jobKey.getName()));
		} finally {
			if(gmConnection!=null){
				BnsprConnection.closeConnection(gmConnection);
			}
		}
		
	}
}
