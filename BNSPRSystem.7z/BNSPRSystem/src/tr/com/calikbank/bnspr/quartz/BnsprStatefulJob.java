package tr.com.calikbank.bnspr.quartz;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.PersistJobDataAfterExecution;

@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class BnsprStatefulJob extends BnsprBaseJob {

}
