package tr.com.calikbank.bnspr.quartz;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.graymound.connection.GMConnection;
import com.graymound.util.GMRuntimeException;

public class BnsprConnection {
	static Log logger = LogFactory.getLog(BnsprBaseJob.class);
	
	public static GMConnection getConnection(){
		try {
			return GMConnection.getConnection("SCHEDULER");
		} catch (Exception e) {
			logger.info("getConnection() da hata ald�");
			throw new GMRuntimeException(0, e);
		}
	}
	
	public static void closeConnection(GMConnection gmConnection){
		try {
			gmConnection.close();
		} catch (Exception e) { //ignore
//			logger.info("closeConnection() da hata ald�");
//			throw new GMRuntimeException(0, e);
		}
	}
}
