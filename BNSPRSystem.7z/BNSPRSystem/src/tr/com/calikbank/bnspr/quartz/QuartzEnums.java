package tr.com.calikbank.bnspr.quartz;


public class QuartzEnums {

	public enum Schedulers {
		
		SCHED_1(1,"SCHEDULER_NODE_1"),
		SCHED_2(2,"SCHEDULER_NODE_2");
		
        private int id;
        private String connectionName;

        private Schedulers(int id, String connectionName) {
                this.id = id;
                this.connectionName=connectionName;
        }
		public int getId() {
			return id;
		}
		public String getConnectionName() {
			return connectionName;
		}
	};
	
	public enum MisfirePolicy {
		
		FireAndProceed(1),
		DoNothing(2),
		IgnoreMisfires(-1);
		
        private int value;

        private MisfirePolicy(int value) {
                this.value = value;
        }
		public int getValue() {
			return value;
		}	
	};
	
	public enum JobHolidayOptions{
		
		E("Tatil g�nleri de �al��s�n"),
		H("Tatil g�nleri �al��mas�n"),
		S("Sadece tatil g�nleri �al��s�n");
		
        private String optionName;
        
        private JobHolidayOptions(String optionName) {
                this.optionName = optionName;
        }

		public String getOptionName() {
			return optionName;
		}
        
	};
	
}
