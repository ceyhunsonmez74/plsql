package tr.com.aktifbank.bnspr.musteriedinim.services;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.KkBasvuruBelgeId;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MusteriEdinimServices {

	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	private static final String EVET = "E";
	private static final String HAYIR = "H";
	private static final String KURYEDEN_IPTAL_STAT_CODE = "I";
	private static final String KURYEDEN_IPTAL_SUB_STAT_CODE = "K";
	private static final String KURYEDEN_IPTAL_CANCEL_CODE = "IK";
	private static final String GEREKCE_KOD_MUSTERI_IPTAL = "2";
	private static final String GEREKCE_KOD_OTOMATIK_IPTAL = "4";

	@GraymoundService("BNSPR_MUSTERI_EDINIM_SEND_BHS")
	public static GMMap sendBHS(GMMap iMap) {
		GMMap oMap = new GMMap();

		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);

		String inpKartNo = iMap.getString("CARD_NO");
		BigDecimal musteriNo = null;
		if (StringUtils.isEmpty(inpKartNo)) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			return oMap;
		}

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kartNo", inpKartNo)).uniqueResult();
		if (tffBasvuru != null) {
			musteriNo = tffBasvuru.getMusteriNo();
		}

		else {
			KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("kartNo", inpKartNo)).uniqueResult();
			if (kkBasvuru != null) {
				musteriNo = kkBasvuru.getMusteriNo();

			}
		}

		iMap.put("MUSTERI_NO", musteriNo);

		iMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", iMap));
		if ("E".equals(iMap.getString("F_BHS"))) {
			// bhs var bi�iy yapma
			return oMap;
		}
		iMap.putAll(GMServiceExecuter.execute("BNSPR_GET_DYS_INFO", iMap));

		if (iMap.get("DYS_INFO_LIST") != null && iMap.getSize("DYS_INFO_LIST") != 0) {
			ArrayList<String> docList = new ArrayList();
			for (int i = 0; i < iMap.getSize("DYS_INFO_LIST"); i++) {
				String[] docListArray = !StringUtils.isEmpty(iMap.getString("DYS_INFO_LIST", i, "DOCUMENT_CODE")) ? iMap.getString("DYS_INFO_LIST", i, "DOCUMENT_CODE").split(",") : null;
				if (docListArray != null && docListArray.length > 0) {
					docList.addAll(new ArrayList<String>(Arrays.asList(docListArray)));
				}
			}

			if (docList.size() > 0) {

				List<GnlParamText> gnlParamTextList = (List<GnlParamText>) session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "BHS_DOKUMAN_KODLARI")).add(Restrictions.in("key1", docList)).list();
				if (gnlParamTextList != null && gnlParamTextList.size() > 0) {
					// bhs var bi�iy yapma
					return oMap;
				}

				// bhs si yok bhs g�nder
				// default dagitim kodu sec
				GnlParamText gnlParamText = (GnlParamText) session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "MUSTERI_EDINIM_BHS_KOD")).uniqueResult();
				if (gnlParamText == null || StringUtils.isEmpty(gnlParamText.getKey1())) {
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					return oMap;
				}

				iMap.put("DYS_NO", gnlParamText.getKey1());
				if (tffBasvuru != null) {
					// intra send bhs
					oMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_SEND_PREPAID_TO_DEBIT_AGREEMENT", iMap));

				}

				else {
					KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("kartNo", inpKartNo)).uniqueResult();
					if (kkBasvuru != null) {
						// ocean send bhs
						oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_SEND_PREPAID_TO_DEBIT_AGREEMENT", iMap));

					}
				}

			}

		}

		return oMap;

	}

	@GraymoundService("BNSPR_KK_KART_BELGE_EKSIK_MI")
	public static GMMap kartBelgeEksikMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap bhsMap = new GMMap();

		Boolean belgeEksikMi = true;
		BigDecimal basvuruNo = basvuruNoBul(iMap.getString("MUSTERI_NO"), iMap.getString("KART_NO"));

		/*M��teri �zerinde bhs var m�?*/
		bhsMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", iMap));

		if (EVET.equals(bhsMap.getString("F_BHS")))
			belgeEksikMi = false;
		else {
			/*kurye s�reci bitmemi� kart bhs var m�*/
			bhsMap.putAll(GMServiceExecuter.execute("BNSPR_KART_KURYE_TESLIM_BHS_KONTROL", iMap));

			if (EVET.equals(bhsMap.getString("F_BHS")))
				belgeEksikMi = false;

			else {
				if (basvuruNo.compareTo(BigDecimal.ZERO) == 0) {
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					oMap.put("RESPONSE_DATA", "Basvuru No Bulunamadi");
				}
				else {
					/*ba�vuruya �zel belge ��kmal� m�? 999 belge ��kmamal� demek*/
					GMMap dysMap = new GMMap();
					dysMap.put("BASVURU_NO", basvuruNo);
					dysMap.put("KART_SIRASINDA_MI", HAYIR);
					dysMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DAGITIM_KOD", dysMap));

					if (BASVURU_DAGITIM_KOD_BOS.equals(dysMap.getString("DAGITIM_KOD")))
						belgeEksikMi = false;
				}
			}

		}
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		oMap.put("BELGE_EKSIK_MI", belgeEksikMi);
		return oMap;
	}

	@GraymoundService("BNSPR_KK_KART_BELGE_GONDER")
	public static GMMap kartBelgeGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap belgeMap = new GMMap();
		GMMap sorguMap = new GMMap();

		BigDecimal basvuruNo = basvuruNoBul(iMap.getString("MUSTERI_NO"), iMap.getString("KART_NO"));
		if (basvuruNo.compareTo(BigDecimal.ZERO) == 0) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", "Kart Basvuru No Bulunamadi");
		}
		else {
			belgeMap.put("BASVURU_NO", basvuruNo);
			belgeMap.put("KART_SIRASINDA_MI", HAYIR);
			belgeMap.putAll(GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", belgeMap));

			// Basvuru datasini kaydet
			sorguMap.put("ISLEM_FLAG", "G");
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("DURUM_KOD", "ACIK");
			sorguMap.putAll(iMap);
			sorguMap.putAll(basvuruAdresKaydet(sorguMap));

			// Basvuruyu tamamla
			GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap);

			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
			oMap.put("RESPONSE_DATA", "Islem Basarili");
		}
		return oMap;
	}

	private static GMMap basvuruAdresKaydet(GMMap iMap) {
		GMMap sorguMap = new GMMap();
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		if (!StringUtils.isEmpty(iMap.getString("TESLIMAT_ADRES_KOD"))) {
			KkBasvuruAdres applicationAddress = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();

			if (applicationAddress != null) {

				applicationAddress.setTeslimatAdresiMi(HAYIR);
				session.saveOrUpdate(applicationAddress);
				session.flush();
			}
		}

		if (!StringUtils.isEmpty(iMap.getString("ILETISIM_ADRES_KOD"))) {
			KkBasvuruAdres applicationAddress = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("iletisimAdresi", "E")).uniqueResult();

			if (applicationAddress != null) {

				applicationAddress.setIletisimAdresi(HAYIR);
				session.saveOrUpdate(applicationAddress);
				session.flush();
			}
		}

		// Islem no
		if (iMap.get("TRX_NO") == null) {
			sorguMap.clear();
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap));
		}
		// Ev Adres
		if (StringUtils.isNotBlank(iMap.getString("EV_ADRES"))) {
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "E");
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("ADRES_TIPI", "E");
			sorguMap.put("IL_KOD", iMap.get("EV_IL"));
			sorguMap.put("ILCE_KOD", iMap.get("EV_ILCE"));
			sorguMap.put("ACIK_ADRES", iMap.get("EV_ADRES"));
			sorguMap.put("POSTA_KOD", iMap.get("EV_POSTA_KOD"));
			sorguMap.put("ILETISIM_MI", "E".equals(iMap.getString("ILETISIM_ADRES_KOD")) == true ? "E" : "H");
			sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.EVET);
			sorguMap.put("TESLIMAT_ADRESI_MI", "E".equals(iMap.getString("TESLIMAT_ADRES_KOD")) == true ? "E" : "H");
			oMap.putAll(GMServiceExecuter.call("BNSPR_KK_SAVE_OR_UPDATE_ADRES", sorguMap));
		}

		// Is Adres
		if (StringUtils.isNotBlank(iMap.getString("IS_ADRES"))) {
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "E");
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("ADRES_TIPI", "I");
			sorguMap.put("IL_KOD", iMap.get("IS_IL"));
			sorguMap.put("ILCE_KOD", iMap.get("IS_ILCE"));
			sorguMap.put("ACIK_ADRES", iMap.get("IS_ADRES"));
			sorguMap.put("POSTA_KOD", iMap.get("IS_POSTA_KOD"));
			sorguMap.put("ILETISIM_MI", "I".equals(iMap.getString("ILETISIM_ADRES_KOD")) == true ? "E" : "H");
			sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("TESLIMAT_ADRESI_MI", "I".equals(iMap.getString("TESLIMAT_ADRES_KOD")) == true ? "E" : "H");
			oMap.putAll(GMServiceExecuter.call("BNSPR_KK_SAVE_OR_UPDATE_ADRES", sorguMap));
		}

		// Teslimat Adres
		if (StringUtils.isNotBlank(iMap.getString("DIGER_ADRES"))) {
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "E");
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("ADRES_TIPI", "D");
			sorguMap.put("IL_KOD", iMap.get("DIGER_IL"));
			sorguMap.put("ILCE_KOD", iMap.get("DIGER_ILCE"));
			sorguMap.put("ACIK_ADRES", iMap.get("DIGER_ADRES"));
			sorguMap.put("POSTA_KOD", iMap.get("DIGER_POSTA_KOD"));
			sorguMap.put("ILETISIM_MI", "D".equals(iMap.getString("ILETISIM_ADRES_KOD")) == true ? "E" : "H");
			sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("TESLIMAT_ADRESI_MI", "D".equals(iMap.getString("TESLIMAT_ADRES_KOD")) == true ? "E" : "H");
			oMap.putAll(GMServiceExecuter.call("BNSPR_KK_SAVE_OR_UPDATE_ADRES", sorguMap));
		}

		return oMap;
	}

	@GraymoundService("BNSPR_KK_BELGE_KURYE_TESLIM")
	public static GMMap kartBelgeTeslimEdildi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		String cardNo= StringUtils.EMPTY;
		GMMap profileMap = new GMMap();

		KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("REFERANS_NO"));

		if (kkBasvuru != null) {
			cardNo = kartNoBul(kkBasvuru.getMusteriNo(), kkBasvuru.getBasvuruNo());
			try {
				profileMap = profilKoduGuncelle(cardNo, kkBasvuru.getMusteriNo(), iMap.getBigDecimal("REFERANS_NO"), true);

				if (!AkustikConstants.RESPONSE_SUCCESS.equals(profileMap.getString("RETURN_CODE")))
					sendSmsBackOffice(kkBasvuru.getBasvuruNo(), cardNo, "Kart/M��teri Profil Kodu g�ncellenemedi :" + oMap.getString("RETURN_DESCRIPTION"), false);

			}
			catch (Exception e) {
				sendSmsBackOffice(kkBasvuru.getBasvuruNo(), cardNo, "Kart/M��teri Profil Kodu g�ncellenemedi :" + e.getMessage(), false);

			}
		}
	
		// ayn� barkodla birden fazla belge olursa diye dokuman kod da eklenmeli sonras�nda
		KkBasvuruBelge kkBasvuruBelge = (KkBasvuruBelge) session.createCriteria(KkBasvuruBelge.class).add(Restrictions.eq("id.barkodNumarasi", iMap.getString("BARKOD_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("REFERANS_NO"))).uniqueResult();
		if (kkBasvuruBelge != null) {
			kkBasvuruBelge.setSsKuryeFirmasi(iMap.getString("KURYE_ADI") + " Tarafindan Teslim Edildi");
			session.saveOrUpdate(kkBasvuruBelge);
			session.flush();
		}
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		oMap.put("RESPONSE_DATA", "Islem Basarili");

		return oMap;
	}

	private static BigDecimal basvuruNoBul(String musteriNo, String kartNo) {
		GMMap cardMap = new GMMap();
		cardMap.put("CUSTOMER_NO", musteriNo);
		cardMap.put("CARD_NO", kartNo);
		cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", cardMap);
		BigDecimal basvuruNo = BigDecimal.ZERO;
		if (cardMap.getSize("CARD_DETAIL_INFO") > 0) {
			basvuruNo = cardMap.getBigDecimal("CARD_DETAIL_INFO", 0, "APPLICATION_NO");
		}
		return basvuruNo;
	}

	private static String kartNoBul(BigDecimal musteriNo, BigDecimal basvuruNo) {
		GMMap cardMap = new GMMap();
		cardMap.put("CUSTOMER_NO", musteriNo);
		cardMap.put("APPLICATION_NO", basvuruNo);
		cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", cardMap);
		String cardNo = StringUtils.EMPTY;
		if (cardMap.getSize("CARD_DETAIL_INFO") > 0) {
			cardNo = cardMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO");
		}
		return cardNo;
	}

	@GraymoundService("BNSPR_SANAL_KART_KURYEDEN_IPTAL")
	public static GMMap sanalKartKuryedenIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap updateMap = new GMMap();
		String cardNo = StringUtils.EMPTY;
		Boolean isCancelledFromJob = iMap.getBoolean("IS_CANCELLED_BY_JOB");
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		BigDecimal basvuruNo = BigDecimal.ZERO;
		String iptalAciklama = StringUtils.EMPTY;
		if (iMap.containsKey("BASVURU_NO") && !StringUtils.isEmpty(iMap.getString("BASVURU_NO")))
			basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		else
			basvuruNo = iMap.getBigDecimal("REFERANS_NO");

		KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);

		if (kkBasvuru != null) {
			cardNo = kartNoBul(kkBasvuru.getMusteriNo(), kkBasvuru.getBasvuruNo());

			if (!StringUtils.isEmpty(cardNo)) {
				if (isCancelledFromJob)
					iptalAciklama = "Maksimum S�rede Aksiyon Al�nmayan MTF Nedeniyle Iptal";
				else
					iptalAciklama = "M��teri MTF Teslimat�n� Reddetti";

				updateMap.put("CARD_NO", cardNo);
				updateMap.put("STATUS", KURYEDEN_IPTAL_STAT_CODE);
				updateMap.put("SUBSTATUS", KURYEDEN_IPTAL_SUB_STAT_CODE);
				updateMap.put("EMBOSS_CODE", KURYEDEN_IPTAL_SUB_STAT_CODE);
				updateMap.put("CANCEL_CODE", KURYEDEN_IPTAL_CANCEL_CODE);
				updateMap.put("FREE_TEXT", iptalAciklama);

				oMap.putAll(GMServiceExecuter.call("BNSPR_GENERAL_UPDATE_CARD_STATUS", updateMap));

				if (!AkustikConstants.RESPONSE_SUCCESS.equals(oMap.getString("RETURN_CODE")))
					sendSmsBackOffice(kkBasvuru.getBasvuruNo(), cardNo, "Kart/Basvuru statu g�ncellenemedi :" + oMap.getString("RETURN_DESCRIPTION"), isCancelledFromJob);

				oMap.put("RESPONSE", oMap.getString("RETURN_CODE"));
				oMap.put("RESPONSE_DATA", oMap.getString("RETURN_DESCRIPTION"));
			}
			else {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", "Kart No Bulunamadi");
			}
		}
		else {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", "Basvuru No Bulunamadi");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_VIRTUAL_CARDS")
	public static GMMap getVirtualCards(GMMap iMap) {

		String virtualPPUrunId = KkProductsUtil.getVirtualProductId();
		GMMap oMap = new GMMap();
		boolean hasOpenCard = false;
		int noOfClosedCards = 0;
		boolean hasCancelledFromCourier = false;
		int j = 0;

		GMMap cMap = new GMMap();
		cMap.put("CARD_DCI", OceanConstants.Akustik_Basvuru_PrepaidCard);
		cMap.put("CUSTOMER_NO", iMap.getString("CUSTOMER_NO"));

		cMap.putAll(GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", cMap));

		for (int i = 0; i < cMap.getSize("CARD_DETAIL_INFO"); i++) {

			if (virtualPPUrunId.equals(cMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_ID"))) {
				oMap.put("CARD_DETAIL_INFO", j, cMap.getMap("CARD_DETAIL_INFO", i));

				if (isOpenCard(cMap.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE"), cMap.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE"), cMap.getString("CARD_DETAIL_INFO", i, "OLD_CARD_NO")))
					hasOpenCard = true;
				else {
					if (KURYEDEN_IPTAL_CANCEL_CODE.equals(cMap.get("CARD_DETAIL_INFO", i, "STATUS_REASON")))
						hasCancelledFromCourier = true;

					noOfClosedCards++;
				}
				j++;
			}

		}
		oMap.put("NUMBER_OF_CLOSED_CARDS", noOfClosedCards);
		oMap.put("HAS_CANCELLED_CARD_FROM_COURIER", hasCancelledFromCourier);
		oMap.put("HAS_OPEN_CARD", hasOpenCard);
		oMap.put("IS_VIRTUAL_CARD_CUSTOMER", (hasOpenCard || (noOfClosedCards > 0)));
		oMap.put("MAX_CLOSED_CARDS_NUMBER", BnsprOceanCommonFunctions.getGlobalParam("MAX_KAPALI_SANAL_KART_ADEDI"));

		return oMap;
	}

	private static boolean isOpenCard(String status, String subStatus, String prevCardNo) {
		if ("N".equals(status) || (!StringUtil.isEmpty(prevCardNo) && status.equals("G") && (subStatus.equals("B") || subStatus.equals("J"))))
			return true;
		else
			return false;

	}

	public static void sendSmsBackOffice(BigDecimal basvuruNo, String cardNo, String message, boolean isAutoCancelled) {

		GMMap sorguMap = new GMMap();
		String mailFrom = "system@aktifbank.com.tr";
		String mailToParametre = "KART_BCKOFFICE_ENTGRTN_MAIL_TO";
		String mailSubject = (isAutoCancelled) ? "Maksimum S�rede Aksiyon Al�nmayan MTF Nedeniyle Sanal Kart Ba�vuru/Kart �ptali" : "Teslim al�nmayan MTF Nedeniyle Sanal Kart Ba�vuru/Kart �ptali";

		StringBuilder mailBody = new StringBuilder();
		mailBody.append("Hata alan ba�vuru/kart bilgileri:");
		mailBody.append("\n");
		mailBody.append("BASVURU NO: " + basvuruNo);
		mailBody.append("\n");
		mailBody.append("KART NO : " + cardNo);
		mailBody.append("\n");
		mailBody.append("HATA : " + message);

		sorguMap.put("MAIL_TO_PARAM", mailToParametre);
		sorguMap.put("MAIL_FROM", mailFrom);
		sorguMap.put("MAIL_SUBJECT", mailSubject);
		sorguMap.put("MAIL_BODY", mailBody.toString());

		GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);

	}
	

	private static GMMap profilKoduGuncelle(String cardNo, BigDecimal customerNo, BigDecimal appNo, boolean addProfile){

		GMMap updateMap = new GMMap();
		updateMap.put("CARD_NO", cardNo);
		updateMap.put("CUSTOMER_NO", customerNo);
		updateMap.put("FORM_NUMBER", appNo);
		updateMap.put("IS_ADD_PROFILE_MAP", addProfile);
		updateMap.putAll(GMServiceExecuter.execute("BNSPR_GENERAL_UPDATE_CARD_PROFILE", updateMap));

		return updateMap;
	}

}
