package tr.com.aktifbank.bnspr.upt.services;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.tff.document.type.CardDocument;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.annotation.Parameter;
import com.graymound.annotation.ParameterType;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class PrepaidUptServices {

	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	private static final String BAYI_KANAL = "2";
	
	@GraymoundService("BNSPR_UPT_START_PREPAID_APPLICATION")
	public static GMMap startUptPrepaidApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap validateMap = new GMMap();
		validateMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_CARD_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(validateMap.getString("RESPONSE"))) {
			return validateMap;
		}

		GMMap barkodResponseMap = new GMMap();
		barkodResponseMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_IS_VALID_OCEAN_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(barkodResponseMap.getString("RETURN_CODE"))) {
			oMap.put("RESPONSE", barkodResponseMap.getString("RETURN_CODE"));
			oMap.put("RESPONSE_DATA", barkodResponseMap.getString("RETURN_DESCRIPTION"));

			return oMap;
		}

		if (iMap.get("TRX_NO") == null) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		}
		BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));

		GMMap phoneMap = new GMMap();
		phoneMap.put("CUSTOMER_NO", musteriNo);
		phoneMap.put("PHONE_COUNTRY_CODE", iMap.getString("PHONE_COUNTRY_CODE"));
		phoneMap.put("PHONE_OPERATOR_CODE", iMap.getString("PHONE_OPERATOR_CODE"));
		phoneMap.put("PHONE_NUMBER", iMap.getString("PHONE_NUMBER"));
		phoneMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_APPLICATION_PHONE_CONTROL", phoneMap));

		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(phoneMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", TffServicesMessages.UYE_TELEFON_EKLE_GENEL_HATA);
			oMap.put("RESPONSE_DATA", phoneMap.getString("RESPONSE_DATA"));

			return oMap;
		}
		
		GMMap customerMap = new GMMap();

		if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {


			customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CUSTOMER", iMap));
			musteriNo = customerMap.getBigDecimal("MUSTERI_NO");
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
				return customerMap;
			}

		}

		else {
			iMap.put("MUSTERI_NO", musteriNo);
			
			/*GMMap gm = new GMMap();
			gm.put("MUSTERI_NO", musteriNo);
			gm.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_MUSTERIMI_KONTAKMI", gm));
			String res = gm.getString("KONTAK_MUSTERI");
			
			if ("K".equals(res)) {
				customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER", iMap));
			}
			*/
				// update aps adress if necessary
				if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
					GMMap customerApsMap = new GMMap();
					customerApsMap.put("TCKN", iMap.getString("TCKN"));
					customerApsMap.put("TRX_NO", iMap.get("TRX_NO"));
					customerApsMap.put("MUSTERI_NO", musteriNo);
					customerApsMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER_APS_ADRESS", customerApsMap));
					if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(customerApsMap.getString("RESPONSE"))) {
						return customerApsMap;
					}
				}
		
		}

		BigDecimal prepaidAppNo = GMServiceExecuter.call("BNSPR_TRN3871_GET_BASVURU_NO", iMap).getBigDecimal("ID");

		GMMap createKkBasvuruMap = new GMMap();
		createKkBasvuruMap.put("BASVURU_NO", prepaidAppNo);
		createKkBasvuruMap.put("MUSTERI_NO", musteriNo);
		createKkBasvuruMap.put("TCKN", iMap.getString("TCKN"));
		createKkBasvuruMap.put("PASAPORT_NO", iMap.getString("PASSPORT_NO"));
		createKkBasvuruMap.put("UYRUK", iMap.getString("COUNTRY_CODE"));
		createKkBasvuruMap.put("BAYI_KOD", iMap.getString("BOX_OFFICE_ID"));
		createKkBasvuruMap.put("TRX_NO", iMap.get("TRX_NO"));
		createKkBasvuruMap.put("KART_NO", iMap.get("CARD_NO"));
		//upt i�in eklendi
		createKkBasvuruMap.put("MOTHER_NAME", iMap.get("MOTHER_NAME"));
		createKkBasvuruMap.put("FATHER_NAME", iMap.get("FATHER_NAME"));
		createKkBasvuruMap.put("BIRTH_PLACE", iMap.get("BIRTH_PLACE"));
		createKkBasvuruMap.put("MESLEK", iMap.get("JOB_INFO"));
		createKkBasvuruMap.put("CALISMA_SEKLI", iMap.get("WORKING_STATUS"));
		createKkBasvuruMap.putAll(iMap);

		GMMap createKkMap = new GMMap();
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_CREATE_APPLICATION", createKkBasvuruMap));

		if (!AkustikConstants.RESPONSE_SUCCESS.equals(createKkMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", createKkMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", createKkMap.getString("RESPONSE_DATA"));
			return oMap;
		}
		
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DAGITIM_KOD", createKkBasvuruMap));
		
		// sozlesme ak��� zorunlulu�u kald�r�ld� direk kayit ac

		iMap.put("MUSTERI_NO", musteriNo);
		GMMap matchCustomerMap = new GMMap();
		iMap.put("BASVURU_NO", prepaidAppNo);
		matchCustomerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_MATCH_CARD_CUSTOMER", iMap));

		if (!AkustikConstants.RESPONSE_SUCCESS.equals(matchCustomerMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", matchCustomerMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", matchCustomerMap.getString("RESPONSE_DATA"));
			return oMap;
		}

		
		createKkBasvuruMap.put("DURUM_KOD", "ACIK");
		oMap.put("APPLICATION_STATUS", "ACIK");
		GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", createKkBasvuruMap);
		

		if (!StringUtils.isEmpty(createKkMap.getString("DAGITIM_KOD")) && !BASVURU_DAGITIM_KOD_BOS.equals(createKkMap.getString("DAGITIM_KOD"))) {

			// istenen belgeleri bul
			
			createKkBasvuruMap.put("SORGU_TIPI", "B");
			GMMap documentMap = new GMMap();
			documentMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI_BY_KANAL", createKkBasvuruMap));
			int resultSize = documentMap.getSize("DOKUMAN_LIST");
			if (resultSize > 0) {
				for (int i = 0; i < resultSize; i++) {
					oMap.put("DOCUMENT_LIST", i, "DOC_CODE", documentMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
					oMap.put("DOCUMENT_LIST", i, "IS_OWNER", documentMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				}
			}


			GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", iMap);

		}

		oMap.put("APPLICATION_NO", prepaidAppNo);
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		oMap.put("CUSTOMER_NO", musteriNo);

		return oMap;

	}

	@GraymoundService("BNSPR_UPT_GET_DOCUMENT_TEMPLATES")
	public static GMMap getUptDocumentTemplates(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_GET_DOCUMENT_TEMPLATES", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_UPT_GET_DOCUMENT_DATA")
	public static GMMap getUptDocumentData(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
		if (kkBasvuru == null) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}

		KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("APPLICATION_NO"));

		if (kkBasvuruKimlik == null) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}

		GMMap sorguMap = new GMMap();
		sorguMap.put("TCKN", kkBasvuruKimlik.getTcKimlikNo());
		sorguMap.put("PASSPORT_NO", kkBasvuruKimlik.getPasaportNo());
		sorguMap.put("KART_NO", kkBasvuru.getKartNo());
		sorguMap.put("BOX_OFFICE_ID", kkBasvuru.getBayiKod());
		GMMap barkodResponseMap = new GMMap();

		barkodResponseMap.putAll(GMServiceExecuter.execute("BNSPR_SS_KURYE_BILGISI_VER", sorguMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(barkodResponseMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", barkodResponseMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", barkodResponseMap.getString("RESPONSE_DATA"));

			return oMap;
		}
		iMap.put("BASVURU_NO", iMap.get("APPLICATION_NO"));
		iMap.put("BARKOD_NO", barkodResponseMap.getString("BARKOD_NO"));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CARD_DOCUMENT_DATA", iMap));
		oMap.put("BARCODE", barkodResponseMap.getString("BARKOD_NO"));
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;
	}

	@GraymoundService("BNSPR_UPT_SAVE_AGREEMENT_DOCUMENTS")
	public static GMMap saveAgreementDocumentsUpt(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		Session session = null;
		try {

			session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("APPLICATION_NO"))).uniqueResult();

			if (kkBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("50018");

			}
			KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("APPLICATION_NO"))).uniqueResult();

			if (kkBasvuruKimlik == null) {
				CreditCardServicesUtil.raiseGMError("50018");

			}
			GMMap saveMap = new GMMap();
			GMMap saveResultMap = new GMMap();
			for (int i = 0; i < iMap.getSize("DOC_LIST"); i++) {
				saveMap.clear();
				saveResultMap.clear();
				saveMap.put("APPLICATION_NO", iMap.getBigDecimal("APPLICATION_NO"));
				saveMap.put("DOC_CODE", iMap.getString("DOC_CODE"));
				saveMap.put("DOC_CONTENT", iMap.getString("DOC_LIST", i, "DOC_CONTENT"));
				saveMap.put("PAGE_NO", i + 1);
				saveMap.put("SOURCE", iMap.getString("SOURCE"));
				
				saveResultMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_AGREEMENT_DOCUMENTS_PDF", saveMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(saveResultMap.getString("RESPONSE"))) {
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					oMap.put("RESPONSE_DATA", saveResultMap.getString("RESPONSE_DATA"));
					return oMap;
				}
			}
			
			

			if (kkBasvuru.getDurumKod().equals("BASVURU")) {
				
				GMMap musteriMevcutDokuman = new GMMap();
				musteriMevcutDokuman.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
				musteriMevcutDokuman.put("SOURCE", iMap.getString("SOURCE"));
				musteriMevcutDokuman.putAll(GMServiceExecuter.execute("BNSPR_KK_GET_CUSTOMER_DOCUMENTS", musteriMevcutDokuman));
				
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(musteriMevcutDokuman.getString("RESPONSE"))) {
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					oMap.put("RESPONSE_DATA", "Musteri Dokumani Alinamadi");
					return  oMap;
				}
			
				HashSet<String> nameSet = null;
				nameSet = (HashSet<String>)musteriMevcutDokuman.get("FILE_NAME_LIST");
				if(nameSet == null || nameSet.size() == 0){
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					oMap.put("RESPONSE_DATA", "Musteri Dokumani bulunamadi");
					return  oMap;
				}
				
				// tum basvuru dokuman kodlar� tam?
				
				
				GMMap  sorguMap = new GMMap();
				sorguMap.put("SORGU_TIPI", "B");
				sorguMap.put("BASVURU_NO" , kkBasvuru.getBasvuruNo());
				sorguMap.put("SOURCE", iMap.getString("SOURCE"));
				sorguMap.put("TCKN", kkBasvuruKimlik.getTcKimlikNo());
				sorguMap.put("PASAPORT_NO", kkBasvuruKimlik.getPasaportNo());
				sorguMap.put("UYRUK", kkBasvuruKimlik.getUyrukKod());
				GMMap documentMap = new GMMap();
				documentMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI_BY_KANAL", sorguMap));
				int resultSize = documentMap.getSize("DOKUMAN_LIST");
				if (resultSize > 0) {
					for (int i = 0; i < resultSize; i++) {
						if(!"E".equals(documentMap.get("DOKUMAN_LIST", i, "ALINDI_MI"))){
						if(!nameSet.contains(documentMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"))){
							oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
							return  oMap;
						}
					}
					}
				}
				
				
				

				GMMap matchCustomerMap = new GMMap();
				matchCustomerMap.put("BASVURU_NO", iMap.getBigDecimal("APPLICATION_NO"));
				
				String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
				//bayi yeni ak��tan geldiyse upt hesap no zorunlu de�il
				if (!BAYI_KANAL.equals(kanalKodu))
				{
					if (!iMap.containsKey("UPT_ACCOUNT_NO") || StringUtils.isBlank(iMap.getString("UPT_ACCOUNT_NO"))) {
						oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
						oMap.put("RESPONSE_DATA", "UPT Hesap Numaras� Bo� Olamaz");
						return  oMap;
					}
					matchCustomerMap.put("UPT_ACCOUNT_NO", iMap.getBigDecimal("UPT_ACCOUNT_NO"));
				}
				matchCustomerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_MATCH_CARD_CUSTOMER", matchCustomerMap));

				if (!AkustikConstants.RESPONSE_SUCCESS.equals(matchCustomerMap.getString("RESPONSE"))) {
					return matchCustomerMap;
				}

				GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", matchCustomerMap);

				if (BAYI_KANAL.equals(kanalKodu))
				{
					GMMap uptMap = new GMMap();
					uptMap.put("BASVURU_NO", iMap.getBigDecimal("APPLICATION_NO"));
					uptMap.putAll(GMServiceExecuter.execute("BNSPR_UPT_CARD_CREATE", uptMap));
					
					
					GMMap oceanMap = new GMMap();
					oceanMap.put("CARD_NO", kkBasvuru.getKartNo());
					oceanMap.put("EXT_SYS_ACCOUNT_NO", uptMap.getString("EXT_SYS_ACCOUNT_NO"));
					oceanMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CARD_ACCOUNT_DETAIL_INSERT", oceanMap));
					
				}
				matchCustomerMap.put("DURUM_KOD", "ACIK");

				GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", matchCustomerMap);

			}
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		}
		catch (GMRuntimeException e) {

			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());

		}

		catch (Exception e) {

			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());

		}
		return oMap;

	}

	@GraymoundService("BNSPR_UPT_CANCEL_APPLICATION")
	public static GMMap cancelApplicationUpt(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			if (kkBasvuru == null) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", "Ba�vuru bulunamad�");
				return oMap;
			}
			if (!"BASVURU".equals(kkBasvuru.getDurumKod()))
			{
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", "Sadece Ba�vuru stat�s�ndeki ba�vurular iptal edilebilir");
				return oMap;
			}

			sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
			sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
			sorguMap.put("ISLEM_KOD", "SS");
			if (StringUtils.isEmpty(iMap.getString("TXN_CODE"))) {
				sorguMap.put("GEREKCE_KOD", "1");// kanal talebi
			}
			else {
				sorguMap.put("GEREKCE_KOD", iMap.getString("TXN_CODE"));
			}
			if (StringUtils.isEmpty(iMap.getString("TXN_DESC"))) {
				sorguMap.put("ACIKLAMA", "Kart iptal talebi");// kanal talebi
			}
			else {
				sorguMap.put("ACIKLAMA", iMap.getString("TXN_DESC"));
			}

			sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_UPT_GET_DOCUMENT_TEMPLATE_DATA")
	public static GMMap getUptDocumentTemplateData(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
		if (kkBasvuru == null) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}

		KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("APPLICATION_NO"));

		if (kkBasvuruKimlik == null) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}

		GMMap sorguMap = new GMMap();
		sorguMap.put("TCKN", kkBasvuruKimlik.getTcKimlikNo());
		sorguMap.put("PASSPORT_NO", kkBasvuruKimlik.getPasaportNo());
		sorguMap.put("KART_NO", kkBasvuru.getKartNo());
		sorguMap.put("BOX_OFFICE_ID", kkBasvuru.getBayiKod());
		GMMap barkodResponseMap = new GMMap();

		barkodResponseMap.putAll(GMServiceExecuter.execute("BNSPR_SS_KURYE_BILGISI_VER", sorguMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(barkodResponseMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", barkodResponseMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", barkodResponseMap.getString("RESPONSE_DATA"));

			return oMap;
		}
		iMap.put("BASVURU_NO", iMap.get("APPLICATION_NO"));
		iMap.put("BARKOD_NO", barkodResponseMap.getString("BARKOD_NO"));
		//iMap.put("QRCODE", "778###1#S");

		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CARD_DOCUMENT_TEMPLATE_DATA", iMap));
		oMap.put("BARCODE", barkodResponseMap.getString("BARKOD_NO"));
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;
	}

	@GraymoundService("BNSPR_UPT_SAVE_PDF_AGREEMENT_DOCUMENTS")
	public static GMMap savePdfAggrementDocumentsUpt(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			if (kkBasvuru == null) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
				return oMap;
			}

			KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("APPLICATION_NO"));

			if (kkBasvuruKimlik == null) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
				return oMap;
			}
			GMMap sorguMap = new GMMap();

			sorguMap.put("TCKN", kkBasvuruKimlik.getTcKimlikNo());
			sorguMap.put("PASSPORT_NO", kkBasvuruKimlik.getPasaportNo());
			sorguMap.put("KART_NO", kkBasvuru.getKartNo());
			sorguMap.put("BOX_OFFICE_ID", kkBasvuru.getBayiKod());
			GMMap barkodResponseMap = new GMMap();

			barkodResponseMap.putAll(GMServiceExecuter.execute("BNSPR_SS_KURYE_BILGISI_VER", sorguMap));
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(barkodResponseMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", barkodResponseMap.getString("RESPONSE"));
				oMap.put("RESPONSE_DATA", barkodResponseMap.getString("RESPONSE_DATA"));

				return oMap;
			}

			GMMap dMap = new GMMap();
			dMap.put("DYS_TRANSFER", true);
			dMap.put("MAIL_TRANSFER", false);
			dMap.put("APPLICATION_NO", iMap.get("APPLICATION_NO"));

			dMap.put("BARKOD", barkodResponseMap.getString("BARKOD_NO"));
			//dMap.put("QRCODE", "778###1#S");
			dMap.put("DOC_LIST", iMap.get("DOC_LIST"));

			GMServiceExecuter.execute("BNSPR_CREATE_KK_CARD_DOCUMENTS", dMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_UPT_GET_APPLICATION_SUMMARY_INFO")
	public static GMMap getUptApplicationSummaryInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (!CardServicesHelper.isSourceValid(iMap)) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", "Gecersiz kanal tipi");
			return oMap;
		}
		iMap.put("BASVURU_URUN_ADI", "NKOLAY PREPAID KART UPT");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_COMMON_GET_APPLICATION_SUMMARY_INFO", iMap));
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			GMMap responseDataInpMap = new GMMap();
			responseDataInpMap.put("SOURCE", iMap.getString("SOURCE"));
			responseDataInpMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
			GMMap responseDataMap = new GMMap();
			responseDataMap.putAll(GMServiceExecuter.execute("BNSPR_KK_COMMON_CONVERT_RESPONSE_DATA_BY_SOURCE", responseDataInpMap));
			if (!StringUtils.isEmpty(responseDataMap.getString("RESPONSE_DATA"))) {
				oMap.put("RESPONSE_DATA", responseDataMap.getString("RESPONSE_DATA"));
			}
		}

		return oMap;
	}

}
