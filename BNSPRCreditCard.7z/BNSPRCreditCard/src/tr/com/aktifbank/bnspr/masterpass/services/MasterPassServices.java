package tr.com.aktifbank.bnspr.masterpass.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.StringUtils;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.aktifbank.bnspr.tff.services.TffCommonServices;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.obss.adc.core.otp.util.OtpGenerator;

public class MasterPassServices {

	private static final int MASTERPASS_PADDED_CARD_NO_PAN_LENGTH = 24;
	private static final int MASTERPASS_PADDED_CVV2_PAN_LENGTH = 8;
	public static final String BASARILI = "0000";
	public static final String SISTEM_HATASI = "6096";
	public static final String KART_SAHIBI_BULUNAMADI = "6001";
	public static final String KART_BILGILERI_GECERSIZ = "6002";
	public static final String MUSTERIYE_AIT_CEP_TELEFONU_BULUNAMADI = "6003";
	public static final String ISLEM_ZAMANI_GECERLI_ARALIKTA_DEGIL = "6004";
	public static final String SIFRELI_VERININ_FORMATI_GECERLI_DEGIL = "6005";
	public static final String OTP_DEGERI_DOGRULANAMADI = "6006";
	
	private static final Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-masterpass.properties");

	
	@GraymoundService("BNSPR_MASTERPASS_SEND_OTP")
	public static GMMap sendOTP(GMMap iMap) {
		GMMap returnMap = new GMMap();
		String encryptedPan = iMap.getString("ENC_PAN");
		String clearPan;
		try {
			returnMap.put("RESULT_CODE", BASARILI);
			// decryption
			try {
				clearPan = decryptPan(encryptedPan);
			}
			catch (Exception ex) {
				returnMap.put("RESULT_CODE", SIFRELI_VERININ_FORMATI_GECERLI_DEGIL);
				returnMap.put("RESULT_DESCRIPTION", "SIFRELI VERININ FORMATI GECERLI DEGIL");
				return returnMap;
			}

			GMMap panMap = splitPaddedPan(clearPan);
			String cardNo = panMap.getString("CARD_NO");
			String cvv2 = panMap.getString("CVV2");
			if (StringUtil.isEmpty(cardNo)) {
				returnMap.put("RESULT_CODE", KART_BILGILERI_GECERSIZ);
				returnMap.put("RESULT_DESCRIPTION", "KART BILGILERI GECERSIZ");
				return returnMap;
			}

			GMMap inMap = new GMMap();
			GMMap propMap = new GMMap();
			GMMap cardMap = new GMMap();
			GMMap cvv2Map = new GMMap();

			// Card & Customer properties

			inMap.put("CARD_NO", cardNo);
			inMap.put("CVV2", cvv2);
			propMap = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", inMap);
			if (!propMap.getString("RETURN_CODE").equals("0"))
			{
				returnMap.put("RESULT_CODE", KART_SAHIBI_BULUNAMADI);
				returnMap.put("RESULT_DESCRIPTION", "KART SAHIBI BULUNAMADI");
				return returnMap;
			}
			String dest = propMap.getString("DESTINATION");

			if (iMap.containsKey("CARD_BANK_STATUS")) {
				inMap.put("CARD_BANK_STATUS", iMap.getString("CARD_BANK_STATUS"));
			}
			else {
				inMap.put("CARD_BANK_STATUS", "N");
			}
			
			try{
				inMap.put("CARD_DCI", "A");
				if (dest.equals(OceanConstants.Card_Source_Ocean)) {
					
					cardMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", inMap));				
				}
				else if (dest.equals(OceanConstants.Card_Source_Intracard)) {
			
					cardMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", inMap));				
				}
				else {
					returnMap.put("RESULT_CODE", KART_SAHIBI_BULUNAMADI);
					returnMap.put("RESULT_DESCRIPTION", "KART SAHIBI BULUNAMADI");
					return returnMap;
				}
			}
			catch(Exception ex){
					returnMap.put("RESULT_CODE", KART_SAHIBI_BULUNAMADI);
					returnMap.put("RESULT_DESCRIPTION", "KART SAHIBI BULUNAMADI");
					return returnMap;
			}
				
			String customerNo = "";
			int s = cardMap.getSize("CARD_DETAIL_INFO");
			if (s > 0) {

				for (int i = 0; i < s; i++) {
					customerNo = cardMap.getString(OceanMapKeys.CARD_DETAIL_INFO, i, OceanMapKeys.CUSTOMER_NO);
				}
			}
			else {
				returnMap.put("RESULT_CODE", KART_SAHIBI_BULUNAMADI);
				returnMap.put("RESULT_DESCRIPTION", "KART SAHIBI BULUNAMADI");
				return returnMap;
			}
			
			if (!cvv2.equals("000")) {
				try{
					if (dest.equals(OceanConstants.Card_Source_Ocean)) {
						cvv2Map = GMServiceExecuter.call("BNSPR_OCEAN_CVV2_CHECK" , inMap);
	
					}
					else if (dest.equals(OceanConstants.Card_Source_Intracard)) {
						cvv2Map.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_CVV_CHECK" , inMap));
		
					}
	
					if (!cvv2Map.getString("RETURN_CODE").equals("0"))	
					{
						returnMap.put("RESULT_CODE", KART_BILGILERI_GECERSIZ);
						returnMap.put("RESULT_DESCRIPTION", "KART BILGILERI GECERSIZ");
						return returnMap;
					}
				}
				catch(Exception ex){
					returnMap.put("RESULT_CODE", KART_BILGILERI_GECERSIZ);
					returnMap.put("RESULT_DESCRIPTION", "KART BILGILERI GECERSIZ");
					return returnMap;
				}
			}
			
				GMMap sorguMap = new GMMap();	
				sorguMap.clear();
				sorguMap.put("CUSTOMER_NO", customerNo);
				sorguMap.put("FORMAT", "UAT");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", sorguMap));
				
				if  (!"1".equals(sorguMap.getString("RESPONSE")) || StringUtils.isEmpty(sorguMap.getString("PHONE_NUMBER")))
				{
					returnMap.put("RESULT_CODE", MUSTERIYE_AIT_CEP_TELEFONU_BULUNAMADI);
					returnMap.put("RESULT_DESCRIPTION", "MUSTERIYE AIT CEP TELEFONU BULUNAMADI");
					return returnMap;
				}
				String cepNo = sorguMap.getString("PHONE_NUMBER");

				
				// Send OTP
				GMMap otpMap = new GMMap();
				GMMap otpResultMap = new GMMap();
				otpMap.put("CONTENT", iMap.getString("OTP_MESSAGE"));
				otpMap.put("HEADER", conf.getProperty("aktifbank-int-masterpass.header"));
				otpMap.put("MSISDN","+" +  cepNo);
				
				otpResultMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_OTP", otpMap));
				
				if (!otpResultMap.getString("RESPONSE").equals(TffCommonServices.RESPONSE_BASARILI))
				{
					returnMap.put("RESULT_CODE", SISTEM_HATASI);
					returnMap.put("RESULT_DESCRIPTION", "SISTEM_HATASI");
					return returnMap;
				}
	
				// Bank Reference No
				Calendar cal = Calendar.getInstance();
	
				String bankRefNo;
				try {
					BigDecimal referenceNo = getBankReferenceNo();
					bankRefNo = String.valueOf(cal.get(Calendar.YEAR)) + String.valueOf(cal.get(Calendar.MONTH)) + String.valueOf(cal.get(Calendar.DAY_OF_MONTH)) + StringUtil.lPad(referenceNo.toString(), 6);
				}
				catch (Exception ex) {
					returnMap.put("RESULT_CODE", SISTEM_HATASI);
					returnMap.put("RESULT_DESCRIPTION", "SISTEM HATASI");
					return returnMap;
				}
	
				// ReturnMap
				returnMap.put("BANK_REFERENCE_NO", bankRefNo);
				returnMap.put("OTP_LENGTH", 6);
				returnMap.put("RESULT_CODE", BASARILI);
				returnMap.put("RESULT_DESCRIPTION", "BASARILI");
				returnMap.put("TCKN", iMap.getString("TCKN") );
				returnMap.put("CUSTOMER_NO", customerNo);
				returnMap.put("CARD_HOLDER_NAME", "");
				returnMap.put("CARD_TYPE", "");
				returnMap.put("EXPIRY_DATE", "");
				returnMap.put("ENC_PAN", "");
	
				return returnMap;

		}
		catch (Exception ex) {
			returnMap.put("RESULT_CODE", SISTEM_HATASI);
			returnMap.put("RESULT_DESCRIPTION", ex.toString());
			return returnMap;
		}

	}
	

	public static BigDecimal getBankReferenceNo() throws Exception {
		try {
			return new BigDecimal(DALUtil.getResult("select SEQ_MASTERPASS_REFERENCE.nextval from dual"));
		}
		catch (Exception ex) {
			throw ex;
		}
	}

	private static GMMap splitPaddedPan(String paddedPan) {
		String cardNo = "";
		String cvv2 = "";
		GMMap oMap = new GMMap();
		int splitCharNo = 0;
		String cardPan = StringUtils.substring(paddedPan, 0, MASTERPASS_PADDED_CARD_NO_PAN_LENGTH);
		for (int i = 1; i < MASTERPASS_PADDED_CARD_NO_PAN_LENGTH; i++) {
			if ("8".equals(StringUtils.substring(cardPan, MASTERPASS_PADDED_CARD_NO_PAN_LENGTH - i, MASTERPASS_PADDED_CARD_NO_PAN_LENGTH - i + 1))) {
				splitCharNo = MASTERPASS_PADDED_CARD_NO_PAN_LENGTH - i;
				break;
			}
		}
		// kontrol
		if ("0".equals(StringUtils.substring(cardPan, splitCharNo + 1, splitCharNo + 2)))
			cardNo = StringUtils.substring(cardPan, 0, splitCharNo);

		oMap.put("CARD_NO", cardNo);
		
		splitCharNo = 0;
		String cvv2Pan = StringUtils.substring(paddedPan, MASTERPASS_PADDED_CARD_NO_PAN_LENGTH, MASTERPASS_PADDED_CARD_NO_PAN_LENGTH+MASTERPASS_PADDED_CVV2_PAN_LENGTH);
		for (int i = 1; i < MASTERPASS_PADDED_CVV2_PAN_LENGTH; i++) {
			if ("8".equals(StringUtils.substring(cvv2Pan, MASTERPASS_PADDED_CVV2_PAN_LENGTH - i, MASTERPASS_PADDED_CVV2_PAN_LENGTH - i + 1))) {
				splitCharNo = MASTERPASS_PADDED_CVV2_PAN_LENGTH - i;
				break;
			}
		}
		// kontrol
		if ("0".equals(StringUtils.substring(cvv2Pan, splitCharNo + 1, splitCharNo + 2)))
			cvv2 = StringUtils.substring(cvv2Pan, 0, splitCharNo);

		
		oMap.put("CVV2", cvv2);
		return oMap;
	}

	private static String decryptPan(String encryptedPan) throws Exception {
		String clearPan;
		try {
			AESCryptor aes = new AESCryptor();
			clearPan = aes.decrypt(encryptedPan);
			return clearPan;
		}
		catch (Exception ex) {
			throw ex;
		}
	}
	
	

}
