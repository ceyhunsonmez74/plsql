package tr.com.aktifbank.bnspr.masterpass.services;

import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.annotation.adapters.HexBinaryAdapter;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import tr.com.calikbank.integration.core.conf.Configurator;

public class AESCryptor {
	
	private static final Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-masterpass.properties");

	private static String iv = conf.getProperty("aktifbank-int-masterpass.iv");
	private static String key = conf.getProperty("aktifbank-int-masterpass.key");
	private static SecretKey key_;
	private static IvParameterSpec iv_;
	private static Cipher cipher;
	private static Cipher decipher;
	private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
	
    private static final char[] HEX_DIGITS = new char[]{
        '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
};
private static final char[] FIRST_CHAR = new char[256];
private static final char[] SECOND_CHAR = new char[256];
static {
    for (int i = 0; i < 256; i++) {
        FIRST_CHAR[i] = HEX_DIGITS[(i >> 4) & 0xF];
        SECOND_CHAR[i] = HEX_DIGITS[i & 0xF];
    }
}

	public AESCryptor() {
		try { 
			Security.addProvider(new BouncyCastleProvider());
			 
			key_ = new SecretKeySpec(hexToBytes(key), "AES");
			iv_ = new IvParameterSpec(hexToBytes(iv));

	        cipher = Cipher.getInstance("AES/CBC/NoPadding");
			cipher.init(Cipher.ENCRYPT_MODE, key_, iv_);

			decipher = Cipher.getInstance("AES/CBC/NoPadding");
			decipher.init(Cipher.DECRYPT_MODE, key_, iv_);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static byte[] hexToBytesYeni(String hexString) {
	     HexBinaryAdapter adapter = new HexBinaryAdapter();
	     byte[] bytes = adapter.unmarshal(hexString);
	     return bytes;}
	
	
	private static byte[] hexToBytes(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
		}
		return data;
	}
	private static String bytesToHex(byte[] input) {
		char[] hexChars = new char[input.length * 2];
		for (int j = 0; j < input.length; j++) {
			int v = input[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];

		}
		return new String(hexChars);
	}
	
    public String encrypt(String clearValue) throws Exception {
    	
        byte[] encrypted = cipher.doFinal(hexToBytes(clearValue));
        String encryptedString = bytesToHex(encrypted);
        return encryptedString;
    }
    

    public String decrypt(String encryptedValue) throws Exception {

        byte[] decrypted = decipher.doFinal(hexToBytes(encryptedValue));
        String decryptedString =bytesToHex(decrypted);
        return decryptedString;
    }
    
}