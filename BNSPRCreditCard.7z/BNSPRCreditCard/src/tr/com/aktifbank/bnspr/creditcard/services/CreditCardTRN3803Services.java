package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.com.aktifbank.bnspr.dao.TffTopluBasvuru;
import tr.com.aktifbank.bnspr.dao.TffTopluBasvuruTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * TFF basvuru bilgilerini excel dosyasindan alarak alinan bilgileri sisteme aktarmak uzere tabloya aktarir.
 * <p>Excel Formati:
 * Excel icerisinde kolon basliklari bulunmalidir ve kolon isimleri ve siralari asagida belirtilen sirada olmalidir.
 * <p>UYRUK, TCKN, PASAPORT_NO, AD, IKINCI_AD, SOYAD, DOGUM_TARIHI, CEP_ULKE_KOD, CEP_ALAN_KOD, CEP_NO, KART_TIPI, 
 * TAKIM, URUN_TIPI, URUN_LOGO, KURYE_TIPI, TESLIMAT_ADRES_TIPI, IL, ILCE, ACIK_ADRES, TESLIMAT_NOKTA_KODU
 * 
 * @author murat.el
 * @since PYTFFKBS-548
 */
public class CreditCardTRN3803Services {
	//Logger
	private static final Logger logger = LoggerFactory.getLogger(CreditCardTRN3803Services.class);
	
	/** 
	 * Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-7940
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>KART_TIPI_LIST - Tff kart tipleri
	 *         <li>TAKIM_LIST - Takimlar
	 *         <li>URUN_LIST - Tff urun tipleri
	 *         <li>KURYE_TIPI_LIST - Kurye tipleri
	 *         <li>ADRES_TIPI_LIST - Adres tipleri
	 *          li>IL_LIST - Iller
	 *         <li>PTT_TESLIMAT_NOKTASI - Ptt teslimat noktalari
	 *         <li>STAD_TESLIMAT_NOKTASI - Stad teslimat noktalari
	 *         <li>AKTIF_PTT_TESLIMAT_NOKTASI - Aktif Ptt teslimat noktalari
	 *         <li>AKTIF_STAD_TESLIMAT_NOKTASI - Aktif Stad teslimat noktalari
	 */
	@GraymoundService("BNSPR_TRN3803_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Kart Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			//Kulup
			String query = "SELECT kod, adi FROM BNSPR.urun_sahip ORDER BY adi";
			DALUtil.fillComboBox(oMap, "TAKIM_LIST", true, query);
			//Urun
			oMap.putAll(CreditCardServicesUtil.getParameterList("URUN_LIST", "TFF_BASVURU_URUN_KOD", "A", "E"));
			//Kurye Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KURYE_TIPI_LIST", "TFF_TOPLU_BASVURU_KURYE_TIPI", "E"));
			//Adresi Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("ADRES_TIPI_LIST", "TFF_TESLIMAT_ADRES_KOD", "E"));
			//Il
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_ILLER", iMap));//IL_LIST
			//PTT/Stad Bilgisini al
	    	oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_PTT_STADIUM_LIST", iMap));
	    	//Odeme Tipi
	    	oMap.putAll(CreditCardServicesUtil.getParameterList("ODEME_TIPI_LIST", "TFF_TOPLU_ODEME_TIPI"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** 
	 * TFF basvuru ise kart alinabilecek takimlari listeler.<br>
	 * @author murat.el
	 * @since PY-7940
	 * @param iMap - Sorgu kriterleri<br>
	 *         <li>KART_TIPI - TFF kart tipi
	 *         <li>URUN - TFF urun kodu
	 *         <li>SOURCE - TFF basvuru kanali
	 * @return oMap - Urun tipleri<br>
	 *         <li>URUN_SAHIP_LIST - Urun tipleri
	 */
	@GraymoundService("BNSPR_TRN3803_GET_URUN_SAHIPLER")
	public static GMMap listUrunSahip(GMMap iMap) {
		GMMap oMap = new GMMap(); 
		
		StringBuilder query = new StringBuilder();
		query.append(" SELECT DISTINCT u.kod, u.adi, u.sira")
			 .append(" FROM urun_sahip u, tff_ss_product_map m, tff_urun_kanal_map k")
		     .append(" WHERE u.lig is not null")
		     .append(" AND u.kod = m.urun_sahip_kod")
		     .append(" AND k.id = m.id")
		     .append(" AND k.gecerli = 'E'")
		     .append(" AND m.kart_tipi = ")
		     .append("'").append(iMap.getString("KART_TIPI")).append("'")
		     .append(" AND m.basvuru_urun_kodu = ")
		     .append("'").append(iMap.getString("URUN")).append("'")
		     .append(" AND k.source = ")
		     .append("'").append(iMap.getString("SOURCE")).append("'")
		     .append(" ORDER BY u.sira");
		DALUtil.fillComboBox(oMap, "URUN_SAHIP_LIST", true, query.toString());

		return oMap;
	}
	
	/** 
	 * Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since PY-7940
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>DOSYA - Okunacak dosya(byteArray)
	 *        <li>DOSYA_ADI - Okunacak dosya adi
	 *        <li>KART_TIPI - Tff kart tipi
	 *        <li>TAKIM - Tutulan takim kodu
	 *        <li>URUN - Tff urun tipi
	 *        <li>URUN_SAHIP - Tff urun
	 *        <li>KURYE_TIPI - Kurye tipi
	 *        <li>TESLIMAT_ADRESI - Teslimat adresi
	 *        <li>IL - Teslimat adresi il kodu
	 *        <li>ILCE - Teslimat adresi ilce kodu
	 *        <li>ACIK_ADRES - Teslimat adresi
	 *        <li>TESLIMAT_NOKTASI - Teslimat noktasi
	 *        <li>ODEME_TIPI - Odeme tipi
	 *        <li>PROMOSYON_KODU - Promosyon kodu
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3803_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffTopluBasvuruTx tffTopluBasvuruTx = (TffTopluBasvuruTx) session.get(TffTopluBasvuruTx.class, trxNo);
			if (tffTopluBasvuruTx == null) {
				tffTopluBasvuruTx = new TffTopluBasvuruTx();
				tffTopluBasvuruTx.setTxNo(trxNo);
			}
			//Islem bilgilerini al.
			tffTopluBasvuruTx.setDosyaAdi(iMap.getString("DOSYA_ADI"));
			tffTopluBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
			tffTopluBasvuruTx.setTakim(iMap.getString("TAKIM"));
			tffTopluBasvuruTx.setUrun(iMap.getString("URUN"));
			tffTopluBasvuruTx.setUrunSahipKodu(iMap.getString("URUN_SAHIP"));
			tffTopluBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
			tffTopluBasvuruTx.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRESI"));
			tffTopluBasvuruTx.setIl(iMap.getString("IL"));
			tffTopluBasvuruTx.setIlce(iMap.getString("ILCE"));
			tffTopluBasvuruTx.setAcikAdres(iMap.getString("ACIK_ADRES"));
			tffTopluBasvuruTx.setTeslimatNoktaKodu(iMap.getString("TESLIMAT_NOKTASI"));
			tffTopluBasvuruTx.setOdemeTipi(iMap.getString("ODEME_TIPI"));
			tffTopluBasvuruTx.setPromosyonKodu(iMap.getString("PROMOSYON_KODU"));
			
			//Islem bilgilerini kaydet
			session.save(tffTopluBasvuruTx);
			session.flush();
			
			//Girilen bilgileri kontrol et
			sorguMap.clear();
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3803_AFTER_CONTROL", sorguMap));
			
			//Okunacak kolon sayisini al
			String excelKolonSayisi = null;
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "TFF_TOPLU_BASVURU_KOLON_SAYISI");
			excelKolonSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");
			//Dosyayi oku
			sorguMap.clear();
			sorguMap.put("DOSYA", iMap.get("DOSYA"));
			sorguMap.put("KOLON_SAYISI", excelKolonSayisi);
			sorguMap.put("BASLIK_VAR_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXCEL_TO_LIST", sorguMap));
			//Kontrol
			Object basvuruList = null;
			if (sorguMap.get("TABLE") == null || sorguMap.getSize("TABLE") < 1) {
				CreditCardServicesUtil.raiseGMError("660", "Dosya icerisinde data bulunamadi");
			} else {
				basvuruList = sorguMap.get("TABLE");
			}
			
			//Dosyadaki bilgileri kaydet
			sorguMap.clear();
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("BASVURU_LIST", basvuruList);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3803_SAVE_BASVURU_LIST", sorguMap));
			
			//Alinan islem bilgileri ile islemi sonlandir.
			sorguMap.clear();
			sorguMap.put("TRX_NAME", "3803");
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** 
	 * ByteArray olarak alinan excel dosyasinin icerigini liste olarak dondurur.<br>
	 * @author murat.el
	 * @since PY-7940
	 * @param iMap - Islem bilgileri<br>
	 *        <li>DOSYA - Okunacak dosya(byteArray)
	 *        <li>KOLON_SAYISI - Okunacak dosyadaki olmasi gerekn kolon sayisi
	 *        <li>BASLIK_VAR_MI - Dosyadaki baslik bilgisi kullanilacak mi?(E:Evet|H:Hayir)
	 * @return Excel icerisindeki data<br>
	 *        <li>TABLE - Data listesi
	 */
	@GraymoundService("BNSPR_EXCEL_TO_LIST")
	public static GMMap importExcelToList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Dosya var mi?
			byte[] inputFile = (byte[]) iMap.get("DOSYA");
            if (inputFile == null) {
            	CreditCardServicesUtil.raiseGMError("330", "Islenecek Dosya");
            }

            //Excel dosya ayarlari
            WorkbookSettings ws = new WorkbookSettings();
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            
            //Excel dosyasini al
            Workbook workbook = null;
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
                //Kolon sayisi verildi mi?
                if (iMap.get("KOLON_SAYISI") == null || iMap.getInt("KOLON_SAYISI") < 1) {
                	CreditCardServicesUtil.raiseGMError("330", "Dosyada Olmasi Gereken Kolon Sayisi");
                }
                //Kolon sayisi kontrolunu yap
                if (workbook.getSheet(0).getColumns() != iMap.getInt("KOLON_SAYISI")) {
                	logger.debug("Kolon Sayisi : {}", iMap.getInt("KOLON_SAYISI"));
                	CreditCardServicesUtil.raiseGMError("660", "Dosyada Istenen Sayida Kolon Yok");
                }
            } catch (Exception e) {
                e.printStackTrace();
                CreditCardServicesUtil.raiseGMError("660", "Gecerli Bir Excel Dosyasi Secmediniz.");
            }
            
            //Baslik bilgisi excelde varsa basliklari al
            Sheet sheet = workbook.getSheet(0);
            String[] headerArray = null;
            if (CreditCardServicesUtil.EVET.equals(iMap.getString("BASLIK_VAR_MI"))) {
            	headerArray = new String[iMap.getInt("KOLON_SAYISI")];
            	for (int i = 0; i < sheet.getColumns(); i++) {
            		headerArray[i] = sheet.getCell(i, 0).getContents().trim();
                }
            }
            
            // Excel dosyasindan datalari oku. Baslik satirini atla.
            for (int j = 0; j + 1 < sheet.getRows(); j++) {
                for (int i = 0; i < sheet.getColumns(); i++) {
                	//Bos satiri atla
                	if (sheet.getCell(i, j + 1) != null && sheet.getCell(i, j + 1).getType() == CellType.EMPTY) {
                		continue;
                	}
                	
                	if (CreditCardServicesUtil.EVET.equals(iMap.getString("BASLIK_VAR_MI"))) {
                		oMap.put("TABLE", j, headerArray[i], sheet.getCell(i, j + 1).getContents());//column,row
                	} else {
                		oMap.put("TABLE", j, "COLUMN_" + (i), sheet.getCell(i, j + 1).getContents());//column,row
                	}
                }
            }
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** 
	 * Excelden okunan basvuru bilgilerini veilen islem numarasi ile kaydeder.<br>
	 * @author murat.el
	 * @since PY-7940
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_LIST - Dosyadan okunan basvuru bilgileri
	 *        <li>TRX_NO - Default olarak gelmesi gereken degerlerin alindigi slem numarasi
	 * @return Output Yok<br>
	 */
	@GraymoundService("BNSPR_TRN3803_SAVE_BASVURU_LIST")
	public static GMMap saveBasvuruList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap odemeMap = new GMMap();

		try {
			//Kullanicinin atadigi bilgileri al
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffTopluBasvuruTx tffTopluBasvuruTx = (TffTopluBasvuruTx) 
					session.get(TffTopluBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffTopluBasvuruTx == null) {
				CreditCardServicesUtil.raiseGMError("330", "Islem Numarasi");
			}
			
			//Kontrol
			String tableName = "BASVURU_LIST";
			if (iMap.get(tableName) == null || iMap.getSize(tableName) < 1) {
				CreditCardServicesUtil.raiseGMError("330", "Basvuru Bilgileri");
			}
			//Basvuru listesini kaydet
			sorguMap.put("TABLE_NAME", "TFF_TOPLU_BASVURU");
			TffTopluBasvuru tffTopluBasvuru = null;
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				tffTopluBasvuru = new TffTopluBasvuru();
				tffTopluBasvuru.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID"));
				tffTopluBasvuru.setTxNo(tffTopluBasvuruTx.getTxNo());
				tffTopluBasvuru.setDurum(BigDecimal.ZERO);//Okundu
				//Listeden datayi exceldeki header alanlarina gore al
				tffTopluBasvuru.setUyruk(iMap.getString(tableName, i, "UYRUK"));
				tffTopluBasvuru.setTckn(iMap.getString(tableName, i, "TCKN"));
				tffTopluBasvuru.setPasaportNo(iMap.getString(tableName, i, "PASAPORT_NO"));
				tffTopluBasvuru.setAd(iMap.getString(tableName, i, "AD"));
				tffTopluBasvuru.setIkinciAd(iMap.getString(tableName, i, "IKINCI_AD"));
				tffTopluBasvuru.setSoyad(iMap.getString(tableName, i, "SOYAD"));
				
				Date dogumTarihi = null;
				if (iMap.get(tableName, i, "DOGUM_TARIHI") != null) {
					try {
						SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
						dogumTarihi = sdf.parse(iMap.getString(tableName, i, "DOGUM_TARIHI"));	
					} catch (ParseException e) {
						logger.debug("{} nolu satirdaki dogum tarihi hatali: {}", i+2, iMap.getString(tableName, i, "DOGUM_TARIHI"));
						CreditCardServicesUtil.raiseGMError("4188");
					}
				}
				tffTopluBasvuru.setDogumTarihi(dogumTarihi);
				
				tffTopluBasvuru.setCepUlkeKod(iMap.getString(tableName, i, "CEP_ULKE_KOD"));
				tffTopluBasvuru.setCepAlanKod(iMap.getString(tableName, i, "CEP_ALAN_KOD"));
				tffTopluBasvuru.setCepNo(iMap.getString(tableName, i, "CEP_NO"));
				tffTopluBasvuru.setKartTipi(CreditCardServicesUtil.nvl(
						tffTopluBasvuruTx.getKartTipi(), iMap.getString(tableName, i, "KART_TIPI")));
				tffTopluBasvuru.setTakim(CreditCardServicesUtil.nvl(
						tffTopluBasvuruTx.getTakim(), iMap.getString(tableName, i, "TAKIM")));
				tffTopluBasvuru.setUrun(CreditCardServicesUtil.nvl(
						tffTopluBasvuruTx.getUrun(), iMap.getString(tableName, i, "URUN_TIPI")));
				tffTopluBasvuru.setUrunSahipKodu(CreditCardServicesUtil.nvl(
						tffTopluBasvuruTx.getUrunSahipKodu(), iMap.getString(tableName, i, "URUN_LOGO")));
				tffTopluBasvuru.setKuryeTipi(CreditCardServicesUtil.nvl(
						tffTopluBasvuruTx.getKuryeTipi(), iMap.getString(tableName, i, "KURYE_TIPI")));
				
				if ("TN".equals(tffTopluBasvuru.getKuryeTipi()) || "GN".equals(tffTopluBasvuru.getKuryeTipi())) {
					tffTopluBasvuru.setTeslimatNoktaKodu(CreditCardServicesUtil.nvl(
							tffTopluBasvuruTx.getTeslimatNoktaKodu(), iMap.getString(tableName, i, "TESLIMAT_NOKTA_KODU")));
					tffTopluBasvuru.setTeslimatAdresi(CreditCardServicesUtil.nvl(
							tffTopluBasvuruTx.getTeslimatAdresi(), tffTopluBasvuru.getKuryeTipi()));
					tffTopluBasvuru.setIl(tffTopluBasvuruTx.getIl());
					tffTopluBasvuru.setIlce(null);
					tffTopluBasvuru.setAcikAdres(tffTopluBasvuruTx.getAcikAdres());
				} else {
					tffTopluBasvuru.setTeslimatNoktaKodu(null);
					tffTopluBasvuru.setTeslimatAdresi(CreditCardServicesUtil.nvl(
							tffTopluBasvuruTx.getTeslimatAdresi(), iMap.getString(tableName, i, "TESLIMAT_ADRES_TIPI")));
					tffTopluBasvuru.setIl(CreditCardServicesUtil.nvl(
							tffTopluBasvuruTx.getIl(), iMap.getString(tableName, i, "IL")));
					tffTopluBasvuru.setIlce(CreditCardServicesUtil.nvl(
							tffTopluBasvuruTx.getIlce(), iMap.getString(tableName, i, "ILCE")));
					tffTopluBasvuru.setAcikAdres(CreditCardServicesUtil.nvl(
							tffTopluBasvuruTx.getAcikAdres(), iMap.getString(tableName, i, "ACIK_ADRES")));
				}
				//Odeme
				String odemeTipi = CreditCardServicesUtil.nvl(tffTopluBasvuruTx.getOdemeTipi(), 
						iMap.getString(tableName, i, "ODEME_TIPI"));
				String promosyonKodu = CreditCardServicesUtil.nvl(tffTopluBasvuruTx.getPromosyonKodu(), 
						iMap.getString(tableName, i, "PROMOSYON_KODU"));
				//Ekrandan/Onceden odeme secenegi belirtilmisse ona gore hesaplama yap
				if (StringUtils.isNotBlank(odemeTipi)) {
					//Promosyon ile odeme yapilacaksa check et
					if ("P".equals(tffTopluBasvuruTx.getOdemeTipi())) {
						odemeMap.clear();
						odemeMap.put("PROMOSYON_KODU", promosyonKodu);
						odemeMap.put("URUN_SAHIP_KODU", tffTopluBasvuru.getUrunSahipKodu());
						odemeMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
						odemeMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3803_PROMOSYON_KODU_GECERLI_MI", odemeMap));
						//Promosyon kodunu kaydet
						tffTopluBasvuru.setPromosyonKodu(promosyonKodu);
					}
					
					//Ucretleri al
					odemeMap.clear();
					odemeMap.put("ODEME_TIPI", tffTopluBasvuruTx.getOdemeTipi());
					odemeMap.put("KART_TIPI", tffTopluBasvuru.getKartTipi());
					odemeMap.put("URUN_KODU", tffTopluBasvuru.getUrun());
					odemeMap.put("URUN_SAHIP_KODU", tffTopluBasvuru.getUrunSahipKodu());
					odemeMap.put("KURYE_TIPI", tffTopluBasvuru.getKuryeTipi());
					odemeMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3803_UCRET_HESAPLA", odemeMap));
					//Kaydet
					tffTopluBasvuru.setKartBedeli(odemeMap.getBigDecimal("KART_BEDELI"));
					tffTopluBasvuru.setVizeBedeli(odemeMap.getBigDecimal("VIZE_BEDELI"));
					tffTopluBasvuru.setLoyaltyBedeli(odemeMap.getBigDecimal("LOYALTY_BEDELI"));
					tffTopluBasvuru.setKuryeBedeli(odemeMap.getBigDecimal("KURYE_BEDELI"));
				}
				
				session.save(tffTopluBasvuru);
			}
			//DB tarafinda kayit islemini tamamla.
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>DOSYA_ADI - Okunacak dosya adi
	 *         <li>KART_TIPI - Tff kart tipi
	 *         <li>TAKIM - Tutulan takim kodu
	 *         <li>URUN - Tff urun tipi
	 *         <li>URUN_SAHIP - Tff urun
	 *         <li>KURYE_TIPI - Kurye tipi
	 *         <li>TESLIMAT_ADRESI - Teslimat adresi
	 *         <li>IL - Teslimat adresi il kodu
	 *         <li>ILCE - Teslimat adresi ilce kodu
	 *         <li>ACIK_ADRES - Teslimat adresi
	 *         <li>TESLIMAT_NOKTASI - Teslimat noktasi
	 *         <li>ODEME_TIPI - Odeme tipi
	 *         <li>PROMOSYON_KODU - Odemeye ait promosyon kodu
	 */
	@GraymoundService("BNSPR_TRN3803_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al
			TffTopluBasvuruTx tffTopluBasvuruTx = (TffTopluBasvuruTx) session.get(TffTopluBasvuruTx.class, trxNo);
			if (tffTopluBasvuruTx != null) {
				oMap.put("DOSYA_ADI", tffTopluBasvuruTx.getDosyaAdi());
				oMap.put("KART_TIPI", tffTopluBasvuruTx.getKartTipi());
				oMap.put("TAKIM", tffTopluBasvuruTx.getTakim());
				oMap.put("URUN", tffTopluBasvuruTx.getUrun());
				oMap.put("URUN_SAHIP", tffTopluBasvuruTx.getUrunSahipKodu());
				oMap.put("KURYE_TIPI", tffTopluBasvuruTx.getKuryeTipi());
				oMap.put("TESLIMAT_ADRESI", tffTopluBasvuruTx.getTeslimatAdresi());
				oMap.put("IL", tffTopluBasvuruTx.getIl());
				oMap.put("ILCE", tffTopluBasvuruTx.getIlce());
				oMap.put("ACIK_ADRES", tffTopluBasvuruTx.getAcikAdres());
				oMap.put("TESLIMAT_NOKTASI", tffTopluBasvuruTx.getTeslimatNoktaKodu());
				oMap.put("ODEME_TIPI", tffTopluBasvuruTx.getOdemeTipi());
				oMap.put("PROMOSYON_KODU", tffTopluBasvuruTx.getPromosyonKodu());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Tff toplu basvurusu isleminin alan kontrollerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since 10.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3803_AFTER_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3803.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** VErilen kriterlere gore toplu basvuru islemi icin ucret hesaplamasi yapar.<br>
	 * @author murat.el
	 * @since PY-8686
	 * @param iMap
	 *         <li>ODEME_TIPI - Odeme tipi
	 *         <li>KURYE_TIPI - Kurye tipi
	 *         <li>KART_TIPI - Tff kart tipi
	 *         <li>URUN_KODU - Tff urun tipi
	 *         <li>URUN_SAHIP_KODU - Tff urun
	 * @return Isleme ait bilgiler<br>
	 *         <li>KART_BEDELI - Kart bedeli
	 *         <li>VIZE_BEDELI - Vize bedeli
	 *         <li>LOYALTY_BEDELI - Loyalty bedeli
	 *         <li>KURYE_BEDELI - Kurye bedeli
	 */
	@GraymoundService("BNSPR_TRN3803_UCRET_HESAPLA")
	public static GMMap ucretHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call pkg_trn3803.Kart_Ucretleri(?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			
			int i = 1;
			stmt.setString(i++, iMap.getString("ODEME_TIPI"));
			stmt.setString(i++, iMap.getString("KURYE_TIPI"));
			stmt.setString(i++, iMap.getString("KART_TIPI"));
			stmt.setString(i++, iMap.getString("URUN_KODU"));
			stmt.setString(i++, iMap.getString("URUN_SAHIP_KODU"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();
			
			oMap.put("KURYE_BEDELI", stmt.getBigDecimal(--i));
			oMap.put("LOYALTY_BEDELI", stmt.getBigDecimal(--i));
			oMap.put("VIZE_BEDELI", stmt.getBigDecimal(--i));
			oMap.put("KART_BEDELI", stmt.getBigDecimal(--i));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen promosyon kodunun verilen urun icin gecerlilik kontrolunu yapar<br>
	 * @author murat.el
	 * @since PY-8686
	 * @param iMap
	 *         <li>PROMOSYON_KODU - Promosyon kodu
	 *         <li>URUN_SAHIP_KODU - Urun logo kodu
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi (E:Evet|H::Hayir)
	 * @return Isleme ait bilgiler<br>
	 *         <li>GECERLI_MI - Promosyon kodu gecerli mi (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3803_PROMOSYON_KODU_GECERLI_MI")
	public static GMMap promosyonKoduGecerliMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			query = "{? = call pkg_trn3803.Promosyon_Kodu_Gecerli_Mi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("PROMOSYON_KODU"));
			stmt.setString(3, iMap.getString("URUN_SAHIP_KODU"));
			stmt.execute();

			String gecerliMi = stmt.getString(1);
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				if (CreditCardServicesUtil.HAYIR.equals(gecerliMi)) {
					CreditCardServicesUtil.raiseGMError("4213");
				}
			} else {
				oMap.put("GECERLI_MI", gecerliMi);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
}
