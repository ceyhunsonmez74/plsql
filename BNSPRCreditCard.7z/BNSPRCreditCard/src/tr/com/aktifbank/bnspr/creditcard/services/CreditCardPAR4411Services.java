package tr.com.aktifbank.bnspr.creditcard.services;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import javax.swing.ImageIcon;
import org.hibernate.Session;
import tr.com.aktifbank.bnspr.dao.UrunSahip;
import tr.com.aktifbank.bnspr.dao.UrunSahipTip;
import tr.com.aktifbank.bnspr.dao.UrunSahipTipId;
import tr.com.aktifbank.bnspr.dao.UrunTipi;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class CreditCardPAR4411Services {
	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	@GraymoundService("BNSPR_PAR4411_URUN_TIP_LIST")
	public static GMMap urunTipList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<UrunTipi> list = session.createCriteria(UrunTipi.class).list();
			String tableName="URUN_TABLE";
			int row=0;
			for(UrunTipi ut:list) {
				 oMap.put(tableName,row,"KOD",ut.getKod());
				 oMap.put(tableName,row,"ACIKLAMA", ut.getAciklama());
				 oMap.put(tableName,row,"AKTIF_MI", (ut.getAktifMi().equals("E")?"Evet":"Hay�r"));
				 oMap.put(tableName,row,"AKTIF_MI_EH", ut.getAktifMi());
				 oMap.put(tableName,row,"VIZE_BEDELI", ut.getVizeBedeli());
				 oMap.put(tableName,row,"LOYALTY_BEDELI", ut.getLoyaltyBedeli());
				 oMap.put(tableName,row,"KART_BEDELI", ut.getKartBedeli());
				 oMap.put(tableName,row,"KURYE_BEDELI", ut.getKuryeBedeli());
				 oMap.put(tableName,row,"LOGO_RESIM",ut.getLogoResim());
				 oMap.put(tableName,row,"OCEAN_ID",ut.getOceanId());
				 oMap.put(tableName,row,"DEBIT_INTRACARD_ID",ut.getDebitIntracardId());
				 oMap.put(tableName,row,"PP_INTRACARD_ID",ut.getPpIntracardId());
				 oMap.put(tableName,row,"LOGO_ID",ut.getLogoId());
				 oMap.put(tableName,row,"FINANCIAL_TYPE",ut.getFinancialType());
				 row++;
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);		
		}
		return oMap;
	}
	@GraymoundService("BNSPR_PAR4411_URUN_TIP_SAVE")
	public static GMMap urunTipSave(GMMap iMap) {
		GMMap oMap = new GMMap();		
	    try{
	        Session session = DAOSession.getSession("BNSPRDal");
	        UrunTipi urunTipi = new UrunTipi();
	        urunTipi.setKod(iMap.getString("KOD"));
	        urunTipi.setAciklama(iMap.getString("ACIKLAMA"));
	        urunTipi.setAktifMi(iMap.getString("AKTIF_MI"));
	        urunTipi.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
	        urunTipi.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
	        urunTipi.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
	        urunTipi.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
	        urunTipi.setDebitIntracardId(iMap.getString("DEBIT_INTRACARD_ID"));
	        urunTipi.setOceanId(iMap.getString("OCEAN_ID"));
	        urunTipi.setPpIntracardId(iMap.getString("PP_INTRACARD_ID"));
	        urunTipi.setLogoId(iMap.getString("LOGO_ID"));
	        urunTipi.setFinancialType(iMap.getString("FINANCIAL_TYPE"));
	        iMap.put("FILE_ID", urunTipi.getKod());
	        iMap.put("FOLDER_ID", "urunler");
	        String fileName = saveLogo(iMap);				
			urunTipi.setLogoResim(fileName);
	        session.saveOrUpdate(urunTipi);
	        session.flush();     
	    } catch (Exception e){	    	
            throw ExceptionHandler.convertException(e);
        }         
        oMap.put("MESSAGE", "��leminiz ba�ar�l� bir �ekilde ger�ekle�tirildi.");
	    return oMap;
	}
	@GraymoundService("BNSPR_PAR4411_URUN_SAHIP_LIST")
	public static GMMap urunSahipList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<UrunSahip> list = session.createCriteria(UrunSahip.class).list();
			String tableName="URUN_TABLE";
			int row=0;
			for(UrunSahip us:list) {
				 oMap.put(tableName,row,"KOD",us.getKod());
				 oMap.put(tableName,row,"AKTIF_MI", (us.getAktifMi().equals("E")?"Evet":"Hay�r"));
				 oMap.put(tableName,row,"ACIKLAMA", us.getAciklama());
				 oMap.put(tableName,row,"ADI", us.getAdi());
				 oMap.put(tableName,row,"AKTIF_MI_EH", us.getAktifMi());
				 oMap.put(tableName,row,"LOGO_RESIM", us.getLogoResim());				 
				 row++;
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);		
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR4411_URUN_SAHIP_SAVE")
	public static GMMap urunSahipSave(GMMap iMap) {
		GMMap oMap = new GMMap();		
	    try{
	    	Session session = DAOSession.getSession("BNSPRDal");
	    	UrunSahip urunSahip = new UrunSahip();
	    	urunSahip.setKod(iMap.getString("KOD"));
	    	urunSahip.setAktifMi(iMap.getString("AKTIF_MI"));
	    	urunSahip.setAciklama(iMap.getString("ACIKLAMA"));
	        urunSahip.setAdi(iMap.getString("ADI"));
	        iMap.put("FILE_ID", urunSahip.getKod());
	        iMap.put("FOLDER_ID", "takimlar");
	        String fileName = saveLogo(iMap);				
			urunSahip.setLogoResim(fileName);
	    	session.saveOrUpdate(urunSahip);
	    	session.flush();
	    	
	    } catch (Exception e){	    	            
	    	throw ExceptionHandler.convertException(e);
        }         
	    oMap.put("MESSAGE", "��leminiz ba�ar�l� bir �ekilde ger�ekle�tirildi.");
        return oMap;
	}
	
	@GraymoundService("BNSPR_PAR4411_URUN_GET_LOGO")
	public static GMMap urunGetLogo(GMMap iMap) {
		GMMap oMap = new GMMap();		
	    try{
	    	if(iMap.get("CONTENT")!=null) {
		    	byte[] imageArray = null;
		        String contentType = iMap.getString("CONTENT_TYPE");
		        if("FILE".equals(contentType)) {
		    	    imageArray = (byte[]) iMap.get("CONTENT");
		        }
		        if("PATH".equals(contentType)) {		        	
		        	String folderPath=getFolderPath();		        	
		        	String fileId = iMap.getString("CONTENT");
		        	String fileName = folderPath+fileId;
		        	FileInputStream fis = new FileInputStream(new File(fileName));	        
		        	imageArray = new byte[fis.available()];
		        	fis.read(imageArray);
		        	fis.close();	        	
		        }
		        ImageIcon icon=new ImageIcon(imageArray);	   
		        oMap.put("ICON", icon);	       	      
		        oMap.put("ICON_HEIGHT", 150);
			    oMap.put("ICON_WIDTH", 200);
	    	}
	    } catch (Exception e){	    	
            throw ExceptionHandler.convertException(e);
        }         
        return oMap;
	}
	
	@GraymoundService("BNSPR_PAR4411_URUN_SAHIP_TIP_LIST")
	public static GMMap urunSahipTipList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<UrunSahipTip> list = session.createCriteria(UrunSahipTip.class).list();
			String tableName="URUN_TABLE";
			int row=0;
			for(UrunSahipTip ust:list) {
				 oMap.put(tableName,row,"URUN_TIP_KOD",ust.getId().getUrunTipKod());
				 oMap.put(tableName,row,"URUN_SAHIP_KOD",ust.getId().getUrunSahipKod());
				 oMap.put(tableName,row,"ACIKLAMA", ust.getAciklama());
				 oMap.put(tableName,row,"AKTIF_MI", (ust.getAktifMi().equals("E")?"Evet":"Hay�r"));
				 oMap.put(tableName,row,"AKTIF_MI_EH", ust.getAktifMi());
				 oMap.put(tableName,row,"VIZE_BEDELI", ust.getVizeBedeli());
				 oMap.put(tableName,row,"LOYALTY_BEDELI", ust.getLoyaltyBedeli());
				 oMap.put(tableName,row,"KART_BEDELI", ust.getKartBedeli());
				 oMap.put(tableName,row,"KURYE_BEDELI", ust.getKuryeBedeli());
				 oMap.put(tableName,row,"LOGO_RESIM",ust.getLogoResim());
				 oMap.put(tableName,row,"OCEAN_ID", ust.getOceanId());
				 oMap.put(tableName,row,"DEBIT_INTRACARD_ID",ust.getDebitIntracardId());
				 oMap.put(tableName,row,"PP_INTRACARD_ID",ust.getPpIntracardId());
				 oMap.put(tableName,row,"LOGO_ID",ust.getLogoId());
				 oMap.put(tableName,row,"FINANCIAL_TYPE",ust.getFinancialType());
				 row++;
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);		
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR4411_URUN_SAHIP_TIP_SAVE")
	public static GMMap urunSahipTipSave(GMMap iMap) {
		GMMap oMap = new GMMap();		
	    try{
	        Session session = DAOSession.getSession("BNSPRDal");
	        UrunSahipTip urunSahipTip = new UrunSahipTip();
	        UrunSahipTipId urunSahipTipId = new UrunSahipTipId();
	        urunSahipTipId.setUrunTipKod(iMap.getString("URUN_TIP_KOD"));
	        urunSahipTipId.setUrunSahipKod(iMap.getString("URUN_SAHIP_KOD"));
	        urunSahipTip.setId(urunSahipTipId);	        
	        urunSahipTip.setAciklama(iMap.getString("ACIKLAMA"));
	        urunSahipTip.setAktifMi(iMap.getString("AKTIF_MI"));
	        urunSahipTip.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
	        urunSahipTip.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
	        urunSahipTip.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
	        urunSahipTip.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
	        urunSahipTip.setOceanId(iMap.getString("OCEAN_ID"));
	        urunSahipTip.setDebitIntracardId(iMap.getString("DEBIT_INTRACARD_ID"));
	        urunSahipTip.setPpIntracardId(iMap.getString("PP_INTRACARD_ID"));
	        urunSahipTip.setLogoId(iMap.getString("LOGO_ID"));
	        urunSahipTip.setFinancialType(iMap.getString("FINANCIAL_TYPE"));
	        iMap.put("FILE_ID", urunSahipTipId.getUrunSahipKod()+urunSahipTipId.getUrunTipKod());
	        iMap.put("FOLDER_ID", "takim_urun");
	        String fileName = saveLogo(iMap);			
			urunSahipTip.setLogoResim(fileName);
	        session.saveOrUpdate(urunSahipTip);
	        session.flush();     
	    } catch (Exception e){	    	
            throw ExceptionHandler.convertException(e);
        }         
        oMap.put("MESSAGE", "��leminiz ba�ar�l� bir �ekilde ger�ekle�tirildi.");
	    return oMap;
	}
	
	private static String saveLogo(GMMap iMap) {
		String fileName="";
		String filePath = "";
		if (iMap.getString("CONTENT") != null ){
			try {
				byte[] imageArray = null;
		        String contentType = iMap.getString("CONTENT_TYPE");
		        if("FILE".equals(contentType)) {
		    	    imageArray = (byte[]) iMap.get("CONTENT");
		        }
		        if("PATH".equals(contentType)) {
		        	FileInputStream fis = new FileInputStream(new File(iMap.getString("CONTENT")));	        
		        	imageArray = new byte[fis.available()];
		        	fis.read(imageArray);
		        	fis.close();	        	
		        }
		      	String fileId=iMap.getString("FILE_ID");
		      	String folderId=iMap.getString("FOLDER_ID");		    	
		      	String folderPath=getFolderPath();
		      	folderPath += File.separator + folderId + File.separator;	
			    File folder = new File(folderPath);
			    if(!folder.exists()) {
			    	folder.mkdir();
			    }		    
		    	fileName = folderPath + fileId +".jpg";			
				File file = new File(fileName);			
				if (!file.exists()) {
					file.createNewFile();
				}	
				filePath = File.separator + folderId + File.separator + fileId +".jpg";	
				FileOutputStream fos=new FileOutputStream(file);
				fos.write(imageArray);
				fos.close();
			} catch(Exception e){
				 throw ExceptionHandler.convertException(e);
			}
		}
		return filePath;
	}
	
    private static String getFolderPath() {
    	String folderPath = ROOT + File.separator + "files" ;    	
		try {	
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "L", BnsprType.STRING, "RESIM_PATH"));					
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
		return folderPath;
    }
}
