package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaDty;
import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaTx;
import tr.com.aktifbank.bnspr.dao.SbaEftGelenUcretler;
import tr.com.aktifbank.bnspr.dao.SbaMcvTakasTx;
import tr.com.aktifbank.bnspr.dao.SbaMcvTakasTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4483Services implements OceanMapKeys{
	@GraymoundService("BNSPR_TRN4483_INITIALIZE")
	public static GMMap initialize (GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		try {
			conn = DALUtil.getGMConnection();
			ps = conn.prepareStatement("select key1,key2,text from BNSPR.v_ml_gnl_param_text where kod='SBA_MC_VISA_TAKAS_KALEMLERI' and substr(text,0,1)='I' order by to_number(key3)");
			rs = ps.executeQuery();
			int i = 0;
			while (rs.next()) {
				oMap.put("INCOMING",i,"SERVICENAME",rs.getString("KEY1"));
				oMap.put("INCOMING",i,"SA",rs.getString("KEY2"));
				oMap.put("INCOMING",i,"SERVICECODE",rs.getString("TEXT"));
				i=i+1;
			}
			
			ps1 = conn.prepareStatement("select key1,key2,text from BNSPR.v_ml_gnl_param_text where kod='SBA_MC_VISA_TAKAS_KALEMLERI' and substr(text,0,1)='O' order by to_number(key3)");
			rs1 = ps1.executeQuery();
			int s = 0;
			while (rs1.next()) {
				oMap.put("OUTGOING",s,"SERVICENAME",rs1.getString("KEY1"));
				oMap.put("OUTGOING",s,"SA",rs1.getString("KEY2"));
				oMap.put("OUTGOING",s,"SERVICECODE",rs1.getString("TEXT"));
				s=s+1;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			GMServerDatasource.close(rs1);
			GMServerDatasource.close(ps1);
			GMServerDatasource.close(conn);

		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4483_GET_CURRENCY")
	public static GMMap getCurrency (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap kurMap = new GMMap();
			GMMap kurMapD = new GMMap();
			kurMap.put("TARIH", iMap.getDate("TARIH"));
			kurMap.put("DOVIZ1", "USD");
			kurMap.put("DOVIZ2", "TRY");
			kurMap.put("TUTAR",1);
			kurMap.put("KUR_TABLO", "O");
			kurMap.put("ALIS_SATIS", "A");
			kurMap.put("KUR_TIP", "1");
			kurMapD = GMServiceExecuter.call("BNSPR_COMMON_DOVIZ_CEVIR", kurMap);
			oMap.put("DOVIZ_ALIS", kurMapD.getBigDecimal("KARSILIK"));
			kurMap.put("ALIS_SATIS", "S");
			kurMapD = GMServiceExecuter.call("BNSPR_COMMON_DOVIZ_CEVIR", kurMap);
			oMap.put("DOVIZ_SATIS", kurMapD.getBigDecimal("KARSILIK"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4483_CALCULATE")
	public static GMMap calculate(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		BigDecimal kur = BigDecimal.ZERO;
		try {
			conn = DALUtil.getGMConnection();
			
			BigDecimal dovizAlis=iMap.getBigDecimal("DOVIZ_ALIS");
			BigDecimal dovizSatis=iMap.getBigDecimal("DOVIZ_SATIS");
			String sa="";
			String serviceCode="";
			BigDecimal settlement = BigDecimal.ZERO;
			BigDecimal comAmountTl = BigDecimal.ZERO;
			BigDecimal bsmv = BigDecimal.ZERO;
			String settlementDk="";
			String islemTipi = iMap.getString("ISLEMTIPI");
			String kod ="";
			if  (islemTipi.equals("M")){
				kod = getGlobalParam("MASTERCARD_SETTLEMENT_DK");
			}
			else{
				kod = getGlobalParam("VISA_SETTLEMENT_DK");
			}
			int s = iMap.getSize("INCOMING");		
			for (int i = 0; i < s; i++) {
				if (!StringUtils.isEmpty(iMap.getString("INCOMING",i, "COM_AMOUNT"))){
				iMap.put("INCOMING",i, "COM_AMOUNT", iMap.getString("INCOMING",i, "COM_AMOUNT").replace(",","."));
				}
				if (!StringUtils.isEmpty(iMap.getString("INCOMING",i, "AMOUNT"))){
				iMap.put("INCOMING",i, "AMOUNT", iMap.getString("INCOMING",i, "AMOUNT").replace(",","."));
				}
				ps = conn.prepareStatement("select B_A,TUTAR_FROM from SBA_MCV_TAKAS_MAP where service_code =? and mv = ? and hesap_no=?");
				ps.setString(1 , iMap.getString("INCOMING",i,"SERVICECODE"));
				ps.setString(2 , islemTipi);
				ps.setString(3 , kod);
				rs = ps.executeQuery();
				while (rs.next()) {
					if (rs.getString("B_A").equals("B")){
						settlement = settlement.add(iMap.getBigDecimal("INCOMING",i,rs.getString("TUTAR_FROM"))== null?BigDecimal.ZERO: iMap.getBigDecimal("INCOMING",i,rs.getString("TUTAR_FROM")));
					}
					else{
						settlement = settlement.subtract(iMap.getBigDecimal("INCOMING",i,rs.getString("TUTAR_FROM"))== null?BigDecimal.ZERO:iMap.getBigDecimal("INCOMING",i,rs.getString("TUTAR_FROM")));
					}
				}
				if(!StringUtils.isEmpty(iMap.getString("INCOMING",i,"COM_AMOUNT"))){
					sa=iMap.get("INCOMING",i,"SA")==null?"":iMap.getString("INCOMING",i,"SA");
					if (sa.equals("S")){
					comAmountTl=iMap.getBigDecimal("INCOMING",i,"COM_AMOUNT").multiply(dovizSatis);
					comAmountTl = comAmountTl.setScale(2, BigDecimal.ROUND_HALF_UP);
					bsmv = BigDecimal.ZERO;
					iMap.put("INCOMING", i,"COM_AMOUNT_TL",comAmountTl);
					iMap.put("INCOMING", i,"BSMV_AMOUNT",bsmv);
					}
					else if (sa.equals("A")){
					comAmountTl=iMap.getBigDecimal("INCOMING",i,"COM_AMOUNT").multiply(dovizAlis);
					comAmountTl = comAmountTl.setScale(2, BigDecimal.ROUND_HALF_UP);
					bsmv = comAmountTl.multiply(BigDecimal.valueOf(0.05));
					bsmv = bsmv.setScale(2, BigDecimal.ROUND_HALF_UP);
					iMap.put("INCOMING", i,"COM_AMOUNT_TL",comAmountTl);
					iMap.put("INCOMING", i,"BSMV_AMOUNT",bsmv);
					}
					
				}
				GMServerDatasource.close(rs);
				GMServerDatasource.close(ps);
			}
			 s = iMap.getSize("OUTGOING");
			 for (int i = 0; i < s; i++) {
				 kur = BigDecimal.ZERO;
				if (!StringUtils.isEmpty(iMap.getString("OUTGOING",i, "COM_AMOUNT"))){
				iMap.put("OUTGOING",i, "COM_AMOUNT", iMap.getString("OUTGOING",i, "COM_AMOUNT").replace(",","."));
				}if (!StringUtils.isEmpty(iMap.getString("OUTGOING",i, "AMOUNT"))){
				iMap.put("OUTGOING",i, "AMOUNT", iMap.getString("OUTGOING",i, "AMOUNT").replace(",","."));
				}if (!StringUtils.isEmpty(iMap.getString("OUTGOING",i, "AMOUNT_TL"))){
				iMap.put("OUTGOING",i, "AMOUNT_TL", iMap.getString("OUTGOING",i, "AMOUNT_TL").replace(",","."));
				}
				 ps = conn.prepareStatement("select B_A,TUTAR_FROM from SBA_MCV_TAKAS_MAP where service_code =? and mv = ? and hesap_no=?");
					ps.setString(1 , iMap.getString("OUTGOING",i,"SERVICECODE"));
					ps.setString(2 , islemTipi);
					ps.setString(3 , kod);
					rs = ps.executeQuery();
					while (rs.next()) {
						if (rs.getString("B_A").equals("B")){
							settlement = settlement.add(iMap.getBigDecimal("OUTGOING",i,rs.getString("TUTAR_FROM"))== null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,rs.getString("TUTAR_FROM")));
						}
						else{
							settlement = settlement.subtract(iMap.getBigDecimal("OUTGOING",i,rs.getString("TUTAR_FROM"))== null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,rs.getString("TUTAR_FROM")));
						}
					}
				 if(!StringUtils.isEmpty(iMap.getString("OUTGOING",i,"COM_AMOUNT"))){
						sa=iMap.get("OUTGOING",i,"SA")==null?"":iMap.getString("OUTGOING",i,"SA");
						if (sa.equals("S")){
						comAmountTl=iMap.getBigDecimal("OUTGOING",i,"COM_AMOUNT").multiply(dovizSatis);
						comAmountTl = comAmountTl.setScale(2, BigDecimal.ROUND_HALF_UP);
						bsmv = BigDecimal.ZERO;
						iMap.put("OUTGOING", i,"COM_AMOUNT_TL",comAmountTl);
						iMap.put("OUTGOING", i,"BSMV_AMOUNT",bsmv);	
						}
						else if (sa.equals("A")){
						comAmountTl=iMap.getBigDecimal("OUTGOING",i,"COM_AMOUNT").multiply(dovizAlis);
						comAmountTl = comAmountTl.setScale(2, BigDecimal.ROUND_HALF_UP);
						bsmv = comAmountTl.multiply(BigDecimal.valueOf(0.05));
						bsmv = bsmv.setScale(2, BigDecimal.ROUND_HALF_UP);
						iMap.put("OUTGOING", i,"COM_AMOUNT_TL",comAmountTl);
						iMap.put("OUTGOING", i,"BSMV_AMOUNT",bsmv);	
						}
						
					}
				 serviceCode =iMap.get("OUTGOING",i,"SERVICECODE")==null?"":iMap.getString("OUTGOING",i,"SERVICECODE");
				 if(serviceCode.equals("O05") || serviceCode.equals("O06")|| serviceCode.equals("O25")|| serviceCode.equals("O26")|| serviceCode.equals("O07")|| serviceCode.equals("O27")){
					 if (iMap.get("OUTGOING",i,"AMOUNT")!=null && iMap.getBigDecimal("OUTGOING",i,"AMOUNT").compareTo(BigDecimal.ZERO)>0){
					 kur = iMap.getBigDecimal("OUTGOING",i,"AMOUNT_TL").divide(iMap.getBigDecimal("OUTGOING",i,"AMOUNT"),8,RoundingMode.CEILING);
					 iMap.put("OUTGOING",i, "KUR",kur);
					 }
				 }
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			}
			 iMap.put("NETSETTLEMENT", iMap.getString("NETSETTLEMENT").replace(",", "."));
			 iMap.put("SETTLEMENT", settlement);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			GMServerDatasource.close(conn);

		}
		return iMap;
	}
	@GraymoundService("BNSPR_TRN4483_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			int s = iMap.getSize("INCOMING");
			SbaMcvTakasTx sbaMcv =null;
			SbaMcvTakasTxId sbaMcvId = null;
			String mv = iMap.getString("MV");
			BigDecimal hesap = BigDecimal.ZERO;
			if (mv.equals("M")){
				hesap = BigDecimal.valueOf(Long.valueOf(getGlobalParam("MASTERCARD_KAPAMA_HESABI")));
			}
			else{
				hesap = BigDecimal.valueOf(Long.valueOf(getGlobalParam("VISA_KAPAMA_HESABI")));
			}
			BigDecimal trx_no = iMap.getBigDecimal("TRX_NO");
			BigDecimal settlement = iMap.getBigDecimal("SETTLEMENT");
			BigDecimal netSettlement = iMap.getBigDecimal("NETSETTLEMENT");
			Date tarih = iMap.getDate("TARIH");
			BigDecimal dovizAlis = iMap.getBigDecimal("DOVIZ_ALIS");
			BigDecimal dovizSatis = iMap.getBigDecimal("DOVIZ_SATIS");
			for (int i = 0; i < s; i++) {
				if(!StringUtils.isEmpty(iMap.getString("INCOMING",i,"AMOUNT")) || !StringUtils.isEmpty(iMap.getString("INCOMING",i,"COM_AMOUNT"))){
					
				sbaMcvId = new SbaMcvTakasTxId();
				sbaMcvId.setMv(mv);
				sbaMcvId.setServiceCode(iMap.getString("INCOMING",i,"SERVICECODE"));
				sbaMcvId.setTxNo(trx_no);
				sbaMcv = new SbaMcvTakasTx();
				sbaMcv.setId(sbaMcvId);
				sbaMcv.setAmount(iMap.getBigDecimal("INCOMING",i,"AMOUNT") == null?BigDecimal.ZERO:iMap.getBigDecimal("INCOMING",i,"AMOUNT"));
				sbaMcv.setAmountTl(iMap.getBigDecimal("INCOMING",i,"AMOUNT_TL") == null?BigDecimal.ZERO:iMap.getBigDecimal("INCOMING",i,"AMOUNT_TL"));
				sbaMcv.setBsmvAmount(iMap.getBigDecimal("INCOMING",i,"BSMV_AMOUNT") == null?BigDecimal.ZERO:iMap.getBigDecimal("INCOMING",i,"BSMV_AMOUNT"));
				sbaMcv.setComAmount(iMap.getBigDecimal("INCOMING",i,"COM_AMOUNT") == null?BigDecimal.ZERO:iMap.getBigDecimal("INCOMING",i,"COM_AMOUNT"));
				sbaMcv.setComAmountTl(iMap.getBigDecimal("INCOMING",i,"COM_AMOUNT_TL") == null?BigDecimal.ZERO:iMap.getBigDecimal("INCOMING",i,"COM_AMOUNT_TL"));
				sbaMcv.setHesapNo(hesap);
				sbaMcv.setInitSettlement(netSettlement);
				sbaMcv.setKur(BigDecimal.ZERO);
				sbaMcv.setServiceName(iMap.getString("INCOMING",i,"SERVICENAME"));
				sbaMcv.setSettlement(settlement);
				sbaMcv.setTarih(tarih);
				sbaMcv.setUsdAlis(dovizAlis);
				sbaMcv.setUsdSatis(dovizSatis);
				session.saveOrUpdate(sbaMcv);
			}
		}
			s = iMap.getSize("OUTGOING");
			for (int i = 0; i < s; i++) {
				if(!StringUtils.isEmpty(iMap.getString("OUTGOING",i,"AMOUNT")) || !StringUtils.isEmpty(iMap.getString("OUTGOING",i,"COM_AMOUNT"))){
					
				sbaMcvId = new SbaMcvTakasTxId();
				sbaMcvId.setMv(mv);
				sbaMcvId.setServiceCode(iMap.getString("OUTGOING",i,"SERVICECODE"));
				sbaMcvId.setTxNo(trx_no);
				sbaMcv = new SbaMcvTakasTx();
				sbaMcv.setId(sbaMcvId);
				sbaMcv.setAmount(iMap.getBigDecimal("OUTGOING",i,"AMOUNT") == null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,"AMOUNT"));
				sbaMcv.setAmountTl(iMap.getBigDecimal("OUTGOING",i,"AMOUNT_TL") == null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,"AMOUNT_TL"));
				sbaMcv.setBsmvAmount(iMap.getBigDecimal("OUTGOING",i,"BSMV_AMOUNT") == null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,"BSMV_AMOUNT"));
				sbaMcv.setComAmount(iMap.getBigDecimal("OUTGOING",i,"COM_AMOUNT") == null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,"COM_AMOUNT"));
				sbaMcv.setComAmountTl(iMap.getBigDecimal("OUTGOING",i,"COM_AMOUNT_TL") == null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,"COM_AMOUNT_TL"));
				sbaMcv.setHesapNo(hesap);
				sbaMcv.setInitSettlement(netSettlement);
				sbaMcv.setKur(iMap.getBigDecimal("OUTGOING",i,"KUR") == null?BigDecimal.ZERO:iMap.getBigDecimal("OUTGOING",i,"KUR"));
				sbaMcv.setServiceName(iMap.getString("OUTGOING",i,"SERVICENAME"));
				sbaMcv.setSettlement(settlement);
				sbaMcv.setTarih(tarih);
				sbaMcv.setUsdAlis(dovizAlis);
				sbaMcv.setUsdSatis(dovizSatis);
				session.saveOrUpdate(sbaMcv);
			}
		}
			session.flush();
			iMap.put("TRX_NO", trx_no);
			iMap.put("TRX_NAME" , "4483");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4483_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> takasList =session.createCriteria(SbaMcvTakasTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i =0;
			int o =0;
			for(Object name : takasList){
				SbaMcvTakasTx takas = (SbaMcvTakasTx) name;
				if(takas.getId().getServiceCode().startsWith("I")){
					oMap.put("INCOMING",i,"SERVICENAME",takas.getServiceName());
					oMap.put("INCOMING",i,"SERVICECODE",takas.getId().getServiceCode());
					oMap.put("INCOMING", i,"AMOUNT",takas.getAmount());
					oMap.put("INCOMING",i,"AMOUNT_TL", takas.getAmountTl());
					oMap.put("INCOMING",i,"BSMV_AMOUNT", takas.getBsmvAmount());
					oMap.put("INCOMING",i,"COM_AMOUNT",takas.getComAmount() );
					oMap.put("INCOMING",i,"COM_AMOUNT_TL", takas.getComAmountTl());
					oMap.put("INCOMING",i,"KUR", takas.getKur());
					i=i+1;
					
				}
				if(takas.getId().getServiceCode().startsWith("O")){
					oMap.put("OUTGOING",o,"SERVICENAME",takas.getServiceName());
					oMap.put("OUTGOING",o,"SERVICECODE",takas.getId().getServiceCode());
					oMap.put("OUTGOING", o,"AMOUNT",takas.getAmount());
					oMap.put("OUTGOING",o,"AMOUNT_TL", takas.getAmountTl());
					oMap.put("OUTGOING",o,"BSMV_AMOUNT", takas.getBsmvAmount());
					oMap.put("OUTGOING",o,"COM_AMOUNT",takas.getComAmount() );
					oMap.put("OUTGOING",o,"COM_AMOUNT_TL", takas.getComAmountTl());
					oMap.put("OUTGOING",o,"KUR", takas.getKur());
					o=o+1;
				}
				
				oMap.put("TARIH", takas.getTarih());
				oMap.put("NETSETTLEMENT", takas.getInitSettlement());
				oMap.put("SETTLEMENT",takas.getSettlement() );
				oMap.put("USD_ALIS",takas.getUsdAlis());
				oMap.put("USD_SATIS",takas.getUsdSatis());
				oMap.put("MV",takas.getId().getMv());
				oMap.put("TRX_NO",takas.getId().getTxNo());
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	 public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
}
