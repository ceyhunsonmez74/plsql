package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.KkOceanCardinfo;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardGeneralServices implements OceanMapKeys {

	public static final int DATE_TIME_LENGTH = 14;

	private static String maskCardNumber(String cardNumber) {
		if (StringUtils.isNotBlank(cardNumber))
			return cardNumber.replaceAll("(\\w{1,12})(\\w{1,4})", "**** **** **** $2");
		else
			return cardNumber;
	}

	@GraymoundService("BNSPR_GET_CC_CARD_LIST_WITH_CUST_NO")
	public static GMMap getCardList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		iMap2.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap2.put(CARD_NO, "");
		iMap2.put(CARD_DCI, "C");
		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		try {
			GMMap eMap = new GMMap();
			GMMap oMap2 = new GMMap();
			eMap.put("KOD", "4405_KT_KARTLARI_GETIR");
			eMap.put("KEY", iMap.getString("BOLUM_KODU"));
			String isKT = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI", eMap).getString("IS_EXIST");
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap2);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			if (oMap2.getString(RETURN_CODE).equals("2"))

			{
				int m = 0;
				for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
					if (isKT.equals("E") && !oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE).equals("P")) {
						continue;
					}
					oMap.put("TABLO", m, "CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
					oMap.put("TABLO", m, "MASKED_CARD_NO", maskCardNumber(oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO)));
					oMap.put("TABLO", m, "EMBOSS_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_EMBOSS_NAME_1));
					oMap.put("TABLO", m, "CARD_BRAND", oMap2.getString("CARD_DETAIL_INFO", i, CARD_BRAND));
					oMap.put("TABLO", m, "PRODUCT_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_PRODUCT_NAME));
					oMap.put("TABLO", m, "STATUS", oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
					oMap.put("TABLO", m, "MAIN_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, MAIN_CARD_NO));
					oMap.put("TABLO", m, "SON_ODEME_TARIHI", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", i, LAST_PAYMENT_DATE)));
					oMap.put("TABLO", m, "DURUM", oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE));
					oMap.put("TABLO", m, "ALT_DURUM", oMap2.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE));
					oMap.put("TABLO", m, "CARD_LEVEL", oMap2.getString("CARD_DETAIL_INFO", i, CARD_LEVEL));
					oMap.put("TABLO", m, "COUNTRY_CODE", oMap2.getString("CARD_DETAIL_INFO", i, COUNTRY_CODE));
					oMap.put("TABLO", m, "PRODUCT_ID", oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
					oMap.put("TABLO", m, "KULL_NA_LIMIT", oMap2.getBigDecimal("CARD_DETAIL_INFO", i, CASH_LIMIT_AVAILABLE));
					oMap.put("TABLO", m, "EXPIRY_DATE", oMap2.getBigDecimal("CARD_DETAIL_INFO", i, EXPIRY_DATE));

					List<GMMap> cardDebt = (List<GMMap>) oMap2.get(CARD_DETAIL_INFO, i, DEBT_INFO_LIST);
					GMMap cardMap = new GMMap(cardDebt.get(0));

					for (int j = 0; j < cardMap.getSize(DEBT_INFO_LIST); j++) {

						if (cardMap.getString(DEBT_INFO_LIST, j, CURRENCY).equals("TRY")) {
							oMap.put("TABLO", m, "KALAN_MIN_ODEME", cardMap.getBigDecimal(DEBT_INFO_LIST, j, MIN_PAYMENT_REMAINING));
							oMap.put("TABLO", m, "KALAN_EKSTRE_BORCU", cardMap.getBigDecimal(DEBT_INFO_LIST, j, LAST_STATEMENT_REMAINING));
							oMap.put("TABLO", m, "GUNCEL_DONEM_BORCU", cardMap.getBigDecimal(DEBT_INFO_LIST, j, CYCLE_DEBT));
						}
						else if (cardMap.getString(DEBT_INFO_LIST, j, CURRENCY).equals("USD")) {
							oMap.put("TABLO", m, "KALAN_MIN_ODEME_USD", cardMap.getBigDecimal(DEBT_INFO_LIST, j, MIN_PAYMENT_REMAINING));
							oMap.put("TABLO", m, "KALAN_EKSTRE_BORCU_USD", cardMap.getBigDecimal(DEBT_INFO_LIST, j, LAST_STATEMENT_REMAINING));
							oMap.put("TABLO", m, "GUNCEL_DONEM_BORCU_USD", cardMap.getBigDecimal(DEBT_INFO_LIST, j, CYCLE_DEBT));
						}
						else {
							oMap.put("TABLO", m, "KALAN_MIN_ODEME_OTH", cardMap.getBigDecimal(DEBT_INFO_LIST, j, MIN_PAYMENT_REMAINING));
							oMap.put("TABLO", m, "KALAN_EKSTRE_BORCU_OTH", cardMap.getBigDecimal(DEBT_INFO_LIST, j, LAST_STATEMENT_REMAINING));
							oMap.put("TABLO", m, "GUNCEL_DONEM_BORCU_OTH", cardMap.getBigDecimal(DEBT_INFO_LIST, j, CYCLE_DEBT));
						}

					}

					GMMap sMap = new GMMap();
					GMMap isMap = new GMMap();
					isMap.put(CARD_NO, oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
					isMap.put(CARD_BRANCH, 1000);
					sMap = GMServiceExecuter.call("BNSPR_GET_CC_CARD_LAST_STATEMENT", isMap);
					oMap.put("TABLO", m, "EKSTRE_BORCU", sMap.getBigDecimal("EKSTRE_BORCU"));
					oMap.put("TABLO", m, "MIN_ODEME_TUTARI", sMap.getBigDecimal("MIN_ODEME_TUTARI"));
					oMap.put("TABLO", m, "HESAP_KESIM_TARIHI", sMap.getDate("HESAP_KESIM_TARIHI"));
					oMap.put("TABLO", m, "SONRAKI_EKSTRE_KESIM_TARIHI", sMap.getDate("SONRAKI_EKSTRE_KESIM_TARIHI"));
					oMap.put("TABLO", m, "SONRAKI_SON_ODEME_TARIHI", sMap.getDate("SONRAKI_SON_ODEME_TARIHI"));
					m++;
				}
			}
			else
				throw new Exception(oMap.getString(ERROR_DETAIL));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CARD_LIST_WITH_CUST_NO")
	public static GMMap getAllCardList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		GMMap iMap3 = new GMMap();
		boolean isUptKart = false;
		boolean isTroyKart = false;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		iMap2.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap2.put(CARD_NO, "");
		iMap2.put(CARD_DCI, iMap.getString("CARD_DCI"));
		if (iMap.containsKey("CARD_GROUP"))
			iMap2.put("CARD_GROUP", iMap.getString("CARD_GROUP"));
		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		try {

			GMMap oMap2 = new GMMap();
			GMMap oMap3 = new GMMap();
			GMMap oMap4 = new GMMap();
			if (BnsprOceanCommonFunctions.isNewCard(iMap.getString("MUST_NO"), null, null)) {
				if (iMap.containsKey("CARD_GROUP")) {
					iMap2.put("SEGMENT", "1".equals(iMap.getString("CARD_GROUP")) ? "TFF" : "");

				}
				oMap2 = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", iMap2);
				String productId = "";
				int j = 0;
				for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
					productId = !StringUtils.isEmpty(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID)) ? oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID) : "";
					isUptKart = KkProductsUtil.isUptPpProduct(productId);// "912".equals(oMap2.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID)); //dev
					isTroyKart = KkProductsUtil.isTroyDebitProduct(productId);// "916".equals(oMap2.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID)); //dev
					if (!isUptKart && !isTroyKart) {

						oMap.put("TABLO", j, "CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
						oMap.put("TABLO", j, "CARD_NO_12_MASKED", maskCardNumber12(oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO)));
						oMap.put("TABLO", j, "MASKED_CARD_NO", CreditCardGeneralServices.maskCardNumberFirst6Last4(oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO)));
						oMap.put("TABLO", j, "EMBOSS_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_EMBOSS_NAME_1));
						oMap.put("TABLO", j, "CARD_BRAND", oMap2.getString("CARD_DETAIL_INFO", i, CARD_BRAND));
						oMap.put("TABLO", j, "PRODUCT_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_PRODUCT_NAME));
						oMap.put("TABLO", j, "STATUS", oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
						oMap.put("TABLO", j, "MAIN_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, MAIN_CARD_NO));
						oMap.put("TABLO", j, "LAST_STMT_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", i, LAST_STMT_DATE)));
						oMap.put("TABLO", j, "DUE_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", 0, "LAST_DUE_DATE")));

						oMap.put("TABLO", j, "OLD_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, OLD_CARD_NO));
						oMap.put("TABLO", j, "EXPIRY_DATE", oMap2.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE));
						oMap.put("TABLO", j, "CARD_LEVEL", oMap2.getString("CARD_DETAIL_INFO", i, CARD_LEVEL));
						oMap.put("TABLO", j, "COUNTRY_CODE", oMap2.getString("CARD_DETAIL_INFO", i, COUNTRY_CODE));
						oMap.put("TABLO", j, "PRODUCT_ID", oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));

						oMap4.clear();
						oMap4.put(CARD_NO, oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
						oMap4 = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_LIMIT_INFO", oMap4);
						if ("2".equals(oMap4.getString("RETURN_CODE"))) {
							oMap.put("TABLO", j, "CASH_ADVANCE_LIMIT", oMap4.getString("LIMIT_INFO", 0, CARD_CASH_LIMIT));
							oMap.put("TABLO", j, "CASH_LIMIT_AVAILABLE", oMap4.getString("LIMIT_INFO", 0, CARD_CASH_LIMIT_AVAILABLE));
						}
						else {
							oMap.put("TABLO", j, "CASH_ADVANCE_LIMIT", "0");
							oMap.put("TABLO", j, "CASH_LIMIT_AVAILABLE", "0");
						}
						j++;
					}
				}
				return oMap;
			}
			else {
				oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap2);
				String productId = "";
				int j = 0;
				if (oMap2.getString(RETURN_CODE).equals("2")) {
					for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
						productId = !StringUtils.isEmpty(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID)) ? oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID) : "";
						isUptKart = KkProductsUtil.isUptPpProduct(productId);// "912".equals(oMap2.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID)); //dev
						isTroyKart = KkProductsUtil.isTroyDebitProduct(productId);// "916".equals(oMap2.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID)); //dev

						if (!isUptKart && !isTroyKart) {

							oMap.put("TABLO", j, "CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
							oMap.put("TABLO", j, "CARD_NO_12_MASKED", maskCardNumber12(oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO)));
							oMap.put("TABLO", j, "MASKED_CARD_NO", CreditCardGeneralServices.maskCardNumberFirst6Last4(oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO)));
							oMap.put("TABLO", j, "EMBOSS_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_EMBOSS_NAME_1));
							oMap.put("TABLO", j, "CARD_BRAND", oMap2.getString("CARD_DETAIL_INFO", i, CARD_BRAND));
							oMap.put("TABLO", j, "PRODUCT_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_PRODUCT_NAME));
							oMap.put("TABLO", j, "STATUS", oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
							oMap.put("TABLO", j, "MAIN_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, MAIN_CARD_NO));
							oMap.put("TABLO", j, "LAST_STMT_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", i, LAST_STMT_DATE)));

							oMap3 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_STATEMENTS", iMap3.put(CARD_NO, oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO)));
							if (StringUtils.isNotBlank(oMap3.getString("STMT_SUMMARY_LIST", 0, DUE_DATE)))
								oMap.put("TABLO", j, "DUE_DATE", sdf.parse(oMap3.getString("STMT_SUMMARY_LIST", 0, DUE_DATE)));

							oMap.put("TABLO", j, "CASH_ADVANCE_LIMIT", oMap2.getString("CARD_DETAIL_INFO", i, CASH_ADVANCE_LIMIT));
							oMap.put("TABLO", j, "CASH_LIMIT_AVAILABLE", oMap2.getString("CARD_DETAIL_INFO", i, CASH_LIMIT_AVAILABLE));
							oMap.put("TABLO", j, "OLD_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, OLD_CARD_NO));
							oMap.put("TABLO", j, "EXPIRY_DATE", oMap2.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE));
							oMap.put("TABLO", j, "CARD_LEVEL", oMap2.getString("CARD_DETAIL_INFO", i, CARD_LEVEL));
							oMap.put("TABLO", j, "COUNTRY_CODE", oMap2.getString("CARD_DETAIL_INFO", i, COUNTRY_CODE));
							oMap.put("TABLO", j, "PRODUCT_ID", oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));

							j++;
						}
					}
				}
				else
					throw new Exception(oMap.getString(ERROR_DETAIL));
				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_CARD_INFO_WITH_CARD_NO")
	public static GMMap getCardInfoA(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		iMap2.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
		iMap2.put(CARD_DCI, iMap.getString("CARD_DCI"));
		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		try {
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap2);

			if (oMap2.getString(RETURN_CODE).equals("2"))

			{
				if (oMap2.getSize("CARD_DETAIL_INFO") < 1) {
					throw new Exception("Kart Bulunamad�");
				}

				for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
					oMap.put("CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
					oMap.put("EMBOSS_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_EMBOSS_NAME_1));
					oMap.put("CARD_BRAND", oMap2.getString("CARD_DETAIL_INFO", i, CARD_BRAND));
					oMap.put("CUSTOMER_NO", oMap2.getString("CARD_DETAIL_INFO", i, CUSTOMER_NO));
					oMap.put("STATUS", oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
					oMap.put("MAIN_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, MAIN_CARD_NO));
					oMap.put("LAST_STMT_DATE", oMap2.getString("CARD_DETAIL_INFO", i, LAST_STMT_DATE));
					oMap.put("OLD_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, OLD_CARD_NO));

				}
			}
			else
				throw new Exception(oMap.getString(ERROR_DETAIL));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_CARD_INFO")
	public static GMMap getAllCardInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		iMap2.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
		iMap2.put(CARD_DCI, iMap.getString("CARD_DCI"));

		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		try {

			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap2);
			if (oMap2.getString(RETURN_CODE).equals("2")) {

				oMap.put("CARD_NO", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_NO));
				oMap.put("CARD_EMBOSS_NAME_1", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_EMBOSS_NAME_1));
				oMap.put("CARD_EMBOSS_NAME_2", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_EMBOSS_NAME_2));
				oMap.put("MAIN_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", 0, MAIN_CARD_NO));

				oMap.put("CARD_LEVELM", "M".equals(oMap2.getString("CARD_DETAIL_INFO", 0, CARD_LEVEL)) ? true : false);
				oMap.put("CARD_LEVELS", "S".equals(oMap2.getString("CARD_DETAIL_INFO", 0, CARD_LEVEL)) ? true : false);

				oMap.put("CARD_BRAND", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_BRAND));
				oMap.put("PRODUCT_ID", oMap2.getString("CARD_DETAIL_INFO", 0, PRODUCT_ID));
				oMap.put("CARD_PRODUCT_NAME", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_PRODUCT_NAME));
				oMap.put("CARD_STAT_CODE", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_STAT_CODE));
				oMap.put("CARD_STAT_DESC", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_STAT_DESC));
				oMap.put("CARD_SUB_STAT_CODE", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_SUB_STAT_CODE));
				oMap.put("CARD_TYPE", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_TYPE));
				oMap.put("CARD_BRANCH", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_BRANCH));
				oMap.put("EXPIRY_DATE", oMap2.getString("CARD_DETAIL_INFO", 0, EXPIRY_DATE));
				oMap.put("EMBOSS_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", 0, EMBOSS_DATE)));
				oMap.put("CARD_LIMIT", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_LIMIT));
				oMap.put("CARD_AVAIL_LIMIT", oMap2.getString("CARD_DETAIL_INFO", 0, CARD_AVAIL_LIMIT));
				oMap.put("CUST_AVAIL_LIMIT", oMap2.getString("CARD_DETAIL_INFO", 0, CUST_AVAIL_LIMIT));
				oMap.put("CASH_ADVANCE_LIMIT", oMap2.getString("CARD_DETAIL_INFO", 0, CASH_ADVANCE_LIMIT));
				oMap.put("CASH_LIMIT_AVAILABLE", oMap2.getString("CARD_DETAIL_INFO", 0, CASH_LIMIT_AVAILABLE));
				oMap.put("EARNED_POINT", oMap2.getString("CARD_DETAIL_INFO", 0, EARNED_POINT));
				oMap.put("USED_POINT", oMap2.getString("CARD_DETAIL_INFO", 0, USED_POINT));
				oMap.put("CAMPAIGN_POINT", oMap2.getString("CARD_DETAIL_INFO", 0, CAMPAIGN_POINT));
				oMap.put("AVAILABLE_POINT", oMap2.getString("CARD_DETAIL_INFO", 0, AVAILABLE_POINT));
				oMap.put("LAST_STMT_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", 0, LAST_STMT_DATE)));
				oMap.put("CARD_STAT_CHANGE_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", 0, CARD_STAT_CHANGE_DATE)));
				oMap.put("TOTAL_PENDING_INSTALLMENTS", oMap2.getString("CARD_DETAIL_INFO", 0, TOTAL_PENDING_INSTALLMENTS));
				oMap.put("LAST_PAYMENT_DATE", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", 0, LAST_PAYMENT_DATE)));
				if (oMap2.get(CARD_DETAIL_INFO, 0, DEBT_INFO_LIST) != null) {
					List<GMMap> cardDebt = (List<GMMap>) oMap2.get(CARD_DETAIL_INFO, 0, DEBT_INFO_LIST);
					GMMap cardMap = new GMMap(cardDebt.get(0));
					for (int i = 0; i < cardMap.getSize(DEBT_INFO_LIST); i++) {
						oMap.put("DEBT_INFO_LIST", i, "CURRENCY", cardMap.getString(DEBT_INFO_LIST, i, CURRENCY));
						oMap.put("DEBT_INFO_LIST", i, "CYCLE_DEBT", cardMap.getString(DEBT_INFO_LIST, i, CYCLE_DEBT));
						oMap.put("DEBT_INFO_LIST", i, "CYCLE_PAYMENT_TOTAL", cardMap.getString(DEBT_INFO_LIST, i, CYCLE_PAYMENT_TOTAL));
						oMap.put("DEBT_INFO_LIST", i, "LAST_STATEMENT_REMAINING", cardMap.getString(DEBT_INFO_LIST, i, LAST_STATEMENT_REMAINING));
						oMap.put("DEBT_INFO_LIST", i, "MIN_PAYMENT_REMAINING", cardMap.getString(DEBT_INFO_LIST, i, MIN_PAYMENT_REMAINING));
						oMap.put("DEBT_INFO_LIST", i, "TOTAL_DEBT", cardMap.getString(DEBT_INFO_LIST, i, TOTAL_DEBT));
					}
				}
				if (oMap2.get(CARD_DETAIL_INFO, 0, INTEREST_RATE_DETAIL) != null) {
					List<GMMap> interestRate = (List<GMMap>) oMap2.get(CARD_DETAIL_INFO, 0, INTEREST_RATE_DETAIL);
					GMMap intMap = new GMMap(interestRate.get(0));
					for (int i = 0; i < intMap.getSize(INTEREST_RATE_DETAIL); i++) {
						oMap.put("INTEREST_RATE_DETAIL", i, "IRD_CURR_DESC", intMap.getString(INTEREST_RATE_DETAIL, i, IRD_CURR_DESC));
						oMap.put("INTEREST_RATE_DETAIL", i, "SALES_INTEREST_RATE", intMap.getString(INTEREST_RATE_DETAIL, i, SALES_INTEREST_RATE));
						oMap.put("INTEREST_RATE_DETAIL", i, "CASH_INTEREST_RATE", intMap.getString(INTEREST_RATE_DETAIL, i, CASH_INTEREST_RATE));
						oMap.put("INTEREST_RATE_DETAIL", i, "LATE_PYMT_SALES_INT_RATE", intMap.getString(INTEREST_RATE_DETAIL, i, LATE_PYMT_SALES_INT_RATE));
						oMap.put("INTEREST_RATE_DETAIL", i, "LATE_PYMT_CASH_INT_RATE", intMap.getString(INTEREST_RATE_DETAIL, i, LATE_PYMT_CASH_INT_RATE));
					}
				}
				if (oMap2.get(CARD_DETAIL_INFO, 0, AUTO_PAYMENT_INFO) != null) {
					List<GMMap> autoPayment = (List<GMMap>) oMap2.get(CARD_DETAIL_INFO, 0, AUTO_PAYMENT_INFO);
					GMMap payMap = new GMMap(autoPayment.get(0));
					for (int i = 0; i < payMap.getSize(AUTO_PAYMENT_INFO); i++) {
						oMap.put("AUTO_PAYMENT_INFO", i, "AUTO_CURR_CODE", payMap.getString(AUTO_PAYMENT_INFO, i, AUTO_CURR_CODE));
						oMap.put("AUTO_PAYMENT_INFO", i, "AUTO_PAYMENT_TYPE", payMap.getString(AUTO_PAYMENT_INFO, i, AUTO_PAYMENT_TYPE));
						oMap.put("AUTO_PAYMENT_INFO", i, "AUTO_ACCOUNT_NO", payMap.getString(AUTO_PAYMENT_INFO, i, AUTO_ACCOUNT_NO));
						oMap.put("AUTO_PAYMENT_INFO", i, "AUTO_ACCOUNT_BRANCH", payMap.getString(AUTO_PAYMENT_INFO, i, AUTO_ACCOUNT_BRANCH));
					}
				}
				if (oMap2.get(CARD_DETAIL_INFO, 0, DEBIT_ACCOUNT_LIST) != null) {
					List<GMMap> accList = (List<GMMap>) oMap2.get(CARD_DETAIL_INFO, 0, DEBIT_ACCOUNT_LIST);
					GMMap accMap = new GMMap(accList.get(0));
					for (int i = 0; i < accMap.getSize(DEBIT_ACCOUNT_LIST); i++) {
						oMap.put("DEBIT_ACCOUNT_LIST", i, "DEBIT_CURR_CODE", accMap.getString(DEBIT_ACCOUNT_LIST, i, DEBIT_CURR_CODE));
						oMap.put("DEBIT_ACCOUNT_LIST", i, "DEBIT_BRANCH", accMap.getString(DEBIT_ACCOUNT_LIST, i, DEBIT_BRANCH));
						oMap.put("DEBIT_ACCOUNT_LIST", i, "DEBIT_ACCOUNT_TYPE", accMap.getString(DEBIT_ACCOUNT_LIST, i, DEBIT_ACCOUNT_TYPE));
						oMap.put("DEBIT_ACCOUNT_LIST", i, "DEBIT_ACCOUNT_NO", accMap.getString(DEBIT_ACCOUNT_LIST, i, DEBIT_ACCOUNT_NO));
					}
				}
				String func = "{?=call Pkg_Rc3297.GETIHTARNAMETARIHI(?)}";
				String must_no = iMap.getString("MUST_NO");
				oMap.put("IHTARNAME_TARIHI", DALUtil.callOneParameterFunction(func, Types.DATE, must_no));

			}
			else
				throw new Exception(oMap.getString(ERROR_DETAIL));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_CC_CARD_LAST_STATEMENT")
	public static GMMap getCardStatements(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
			GMMap iMap2 = new GMMap();
			iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
			iMap2.put(CARD_BRANCH, iMap.getString("CARD_BRANCH"));
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_STATEMENTS", iMap2);
			if (oMap2.get(STMT_SUMMARY_LIST) != null && oMap2.getSize(STMT_SUMMARY_LIST) > 0) {
				oMap.put("EKSTRE_BORCU", oMap2.getBigDecimal(STMT_SUMMARY_LIST, 0, TOTAL_AMOUNT));
				oMap.put("MIN_ODEME_TUTARI", oMap2.getBigDecimal(STMT_SUMMARY_LIST, 0, MIN_AMOUNT));
				oMap.put("HESAP_KESIM_TARIHI", sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, 0, STMT_DATE)));
				oMap.put("SONRAKI_EKSTRE_KESIM_TARIHI", sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, 0, NEXT_STMT_DATE)));
				oMap.put("SONRAKI_SON_ODEME_TARIHI", sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, 0, NEXT_DUE_DATE)));
				oMap.put("STMT_DATE", sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, 0, STMT_DATE)));
				oMap.put("DUE_DATE", sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, 0, DUE_DATE)));
			}
			else {
				oMap.put("EKSTRE_BORCU", 0);
				oMap.put("MIN_ODEME_TUTARI", 0);
				oMap.put("HESAP_KESIM_TARIHI", sdf.parse("19000101"));
				oMap.put("SONRAKI_EKSTRE_KESIM_TARIHI", sdf.parse("19000101"));
				oMap.put("SONRAKI_SON_ODEME_TARIHI", sdf.parse("19000101"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CC_CARD_STATEMENT")
	public static GMMap getCardStatementsAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		try {
			GMMap iMap2 = new GMMap();
			iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
			GMMap oMapH = new GMMap();
			oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
			iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_STATEMENTS", iMap2);
			for (int i = 0; i < oMap2.getSize(STMT_SUMMARY_LIST); i++) {

				oMap.put("EKSTRE", i, "CARD_LIMIT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, CARD_LIMIT));
				oMap.put("EKSTRE", i, "CARD_NO", oMap2.getString(STMT_SUMMARY_LIST, i, CARD_NO));
				oMap.put("EKSTRE", i, "STMT_DATE", sdf1.format(sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, i, STMT_DATE))));
				oMap.put("EKSTRE", i, "DUE_DATE", sdf1.format(sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, i, DUE_DATE))));
				oMap.put("EKSTRE", i, "NEXT_STMT_DATE", sdf1.format(sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, i, NEXT_STMT_DATE))));
				oMap.put("EKSTRE", i, "NEXT_DUE_DATE", sdf1.format(sdf.parse(oMap2.getString(STMT_SUMMARY_LIST, i, NEXT_DUE_DATE))));
				oMap.put("EKSTRE", i, "CURRENCY_CODE", oMap2.getString(STMT_SUMMARY_LIST, i, CURR_CODE));
				oMap.put("EKSTRE", i, "TOTAL_INTEREST_FEE", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, TOTAL_INTEREST_FEE));
				oMap.put("EKSTRE", i, "EARNED_POINT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, EARNED_POINT));
				oMap.put("EKSTRE", i, "TOTAL_POINT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, TOTAL_POINT));
				oMap.put("EKSTRE", i, "TOTAL_AMOUNT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, TOTAL_AMOUNT));
				oMap.put("EKSTRE", i, "MIN_AMOUNT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, MIN_AMOUNT));
				oMap.put("EKSTRE", i, "PREV_TOTAL_AMOUNT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, PREV_TOTAL_AMOUNT));
				oMap.put("EKSTRE", i, "REMAINING_CARD_LIMIT", oMap2.getBigDecimal(STMT_SUMMARY_LIST, i, REMAIN_CARD_LIMIT));

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CC_CARD_STATEMENT_TRANSACTIONS")
	public static GMMap getCardStatementTransactions(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMdd");
		try {
			GMMap iMap2 = new GMMap();
			iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
			iMap2.put(CURR_CODE, iMap.getString("CURR_CODE"));
			iMap2.put(STMT_DATE, sdf1.format(sdf.parse(iMap.getString("STMT_DATE"))));
			GMMap oMapH = new GMMap();
			oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
			iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_STATEMENT_TRANSACTIONS", iMap2);
			for (int i = 0; i < oMap2.getSize(ALL_TXN_LIST); i++) {
				oMap.put("EKSTRE_DETAY", i, "CARD_NO", oMap2.getString(ALL_TXN_LIST, i, CARD_NO));
				oMap.put("EKSTRE_DETAY", i, "MAIN_CARD_NO", oMap2.getString(ALL_TXN_LIST, i, MAIN_CARD_NO));
				oMap.put("EKSTRE_DETAY", i, "TXN_DATE", sdf.format(sdf1.parse(oMap2.getString(ALL_TXN_LIST, i, TXN_DATE))));
				oMap.put("EKSTRE_DETAY", i, "EARNED_POINT", oMap2.getString(ALL_TXN_LIST, i, EARNED_POINT));
				oMap.put("EKSTRE_DETAY", i, "DEBIT_CREDIT_FLAG", oMap2.getString(ALL_TXN_LIST, i, DEBIT_CREDIT_FLAG));
				oMap.put("EKSTRE_DETAY", i, "TXN_CURRENCY", oMap2.getString(ALL_TXN_LIST, i, TXN_CURR));
				oMap.put("EKSTRE_DETAY", i, "LCL_TXN_CURRENCY", oMap2.getString(ALL_TXN_LIST, i, LCL_TXN_CURR));
				oMap.put("EKSTRE_DETAY", i, "TXN_DESC", oMap2.getString(ALL_TXN_LIST, i, TXN_DESC));
				oMap.put("EKSTRE_DETAY", i, "INSTALL_AMOUNT", oMap2.getString(ALL_TXN_LIST, i, INSTALL_AMOUNT));
				oMap.put("EKSTRE_DETAY", i, "INSTALL_NO", oMap2.getString(ALL_TXN_LIST, i, INSTALL_NO));
				oMap.put("EKSTRE_DETAY", i, "TOTAL_INSTALL_COUNT", oMap2.getString(ALL_TXN_LIST, i, TOTAL_INSTALL_COUNT));
				oMap.put("EKSTRE_DETAY", i, "REMAINING_INSTALL_COUNT", oMap2.getString(ALL_TXN_LIST, i, REMAIN_INSTALL_COUNT));
				oMap.put("EKSTRE_DETAY", i, "TOTAL_INSTALL_AMOUNT", oMap2.getString(ALL_TXN_LIST, i, TOTAL_INSTALL_AMOUNT));
				oMap.put("EKSTRE_DETAY", i, "TXN_AMOUNT", oMap2.getString(ALL_TXN_LIST, i, TXN_AMOUNT));
				oMap.put("EKSTRE_DETAY", i, "LCL_TXN_AMOUNT", oMap2.getString(ALL_TXN_LIST, i, LCL_TXN_AMOUNT));
				oMap.put("EKSTRE_DETAY", i, "RELEASE_DATE", oMap2.getString(ALL_TXN_LIST, i, RELEASE_DATE));

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CC_CARD_PROVISIONS")
	public static GMMap getCardProvisions(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		try {
			GMMap iMap2 = new GMMap();
			iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
			GMMap oMapH = new GMMap();
			oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
			iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_PROVISIONS", iMap2);
			for (int i = 0; i < oMap2.getSize(PROVISION_LIST); i++) {
				oMap.put("PROVISIONS", i, "CARD_NO", oMap2.getString(PROVISION_LIST, i, CARD_NO));
				oMap.put("PROVISIONS", i, "MAIN_CARD_NO", oMap2.getString(PROVISION_LIST, i, MAIN_CARD_NO));
				oMap.put("PROVISIONS", i, "TXN_NAME", oMap2.getString(PROVISION_LIST, i, TXN_NAME));
				oMap.put("PROVISIONS", i, "TXN_DATE", sdf1.format(sdf.parse(oMap2.getString(PROVISION_LIST, i, TXN_DATE))));
				oMap.put("PROVISIONS", i, "TXN_AMOUNT", oMap2.getString(PROVISION_LIST, i, TXN_AMOUNT));
				oMap.put("PROVISIONS", i, "TXN_CURRENCY", oMap2.getString(PROVISION_LIST, i, TXN_CURR));
				oMap.put("PROVISIONS", i, "LCL_TXN_AMOUNT", oMap2.getString(PROVISION_LIST, i, LCL_TXN_AMOUNT));
				oMap.put("PROVISIONS", i, "LCL_TXN_CURRENCY", oMap2.getString(PROVISION_LIST, i, LCL_TXN_CURR));
				oMap.put("PROVISIONS", i, "SETTL_TXN_AMOUNT", oMap2.getString(PROVISION_LIST, i, SETTL_TXN_AMOUNT));
				oMap.put("PROVISIONS", i, "SETTL_TXN_CURR", oMap2.getString(PROVISION_LIST, i, SETTL_TXN_CURR));
				oMap.put("PROVISIONS", i, "TXN_DESC", oMap2.getString(PROVISION_LIST, i, TXN_DESC));
				oMap.put("PROVISIONS", i, "INSTALL_NO", oMap2.getString(PROVISION_LIST, i, INSTALL_NO));
				oMap.put("PROVISIONS", i, "TOTAL_INSTALL_COUNT", oMap2.getString(PROVISION_LIST, i, TOTAL_INSTALL_COUNT));
				oMap.put("PROVISIONS", i, "REMAINING_INSTALL_COUNT", oMap2.getString(PROVISION_LIST, i, REMAIN_INSTALL_COUNT));
				oMap.put("PROVISIONS", i, "INSTALL_AMOUNT", oMap2.getString(PROVISION_LIST, i, INSTALL_AMOUNT));
				oMap.put("PROVISIONS", i, "TOTAL_INSTALL_AMOUNT", oMap2.getString(PROVISION_LIST, i, TOTAL_INSTALL_AMOUNT));
				oMap.put("PROVISIONS", i, "EARNED_POINT", oMap2.getString(PROVISION_LIST, i, EARNED_POINT));
				oMap.put("PROVISIONS", i, "USED_POINT", oMap2.getString(PROVISION_LIST, i, USED_POINT));
				String debitCredit = "";
				if (oMap2.getString(PROVISION_LIST, i, DEBIT_CREDIT_FLAG).equals("D"))
					debitCredit = "Bor�";
				else if (oMap2.getString(PROVISION_LIST, i, DEBIT_CREDIT_FLAG).equals("C"))
					debitCredit = "Alacak";
				else
					debitCredit = "N�tr";

				oMap.put("PROVISIONS", i, "DEBIT_CREDIT_FLAG", debitCredit);
				oMap.put("PROVISIONS", i, "STATE", oMap2.getString(PROVISION_LIST, i, STATE));
				oMap.put("PROVISIONS", i, "TXN_STATE", oMap2.getString(PROVISION_LIST, i, TXN_STATE));
				oMap.put("PROVISIONS", i, "RELEASE_DATE", oMap2.getString(PROVISION_LIST, i, RELEASE_DATE));
				oMap.put("PROVISIONS", i, "PROVISION_CODE", oMap2.getString(PROVISION_LIST, i, PROVISION_CODE));

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CC_CARD_CYCLE_TRANSACTIONS")
	public static GMMap getCardCycleTxn(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		try {
			GMMap iMap2 = new GMMap();
			iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
			iMap2.put(BILLING_CURR_CODE, iMap.getString("CURR_CODE"));
			GMMap oMapH = new GMMap();
			oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
			iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
			GMMap oMap2 = new GMMap();

			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_CYCLE_TRANSACTIONS", iMap2);
			for (int i = 0; i < oMap2.getSize(CYCLE_TXN_LIST); i++) {
				oMap.put("CYCLE_TXN", i, "CARD_NO", oMap2.getString(CYCLE_TXN_LIST, i, CARD_NO));
				oMap.put("CYCLE_TXN", i, "MAIN_CARD_NO", oMap2.getString(CYCLE_TXN_LIST, i, MAIN_CARD_NO));
				oMap.put("CYCLE_TXN", i, "TXN_NAME", oMap2.getString(CYCLE_TXN_LIST, i, TXN_NAME));
				oMap.put("CYCLE_TXN", i, "TXN_DATE", sdf1.format(sdf.parse(oMap2.getString(CYCLE_TXN_LIST, i, TXN_DATE))));
				oMap.put("CYCLE_TXN", i, "TXN_AMOUNT", oMap2.getString(CYCLE_TXN_LIST, i, TXN_AMOUNT));
				oMap.put("CYCLE_TXN", i, "TXN_CURRENCY", oMap2.getString(CYCLE_TXN_LIST, i, TXN_CURR));
				oMap.put("CYCLE_TXN", i, "LCL_TXN_AMOUNT", oMap2.getString(CYCLE_TXN_LIST, i, LCL_TXN_AMOUNT));
				oMap.put("CYCLE_TXN", i, "LCL_TXN_CURRENCY", oMap2.getString(CYCLE_TXN_LIST, i, LCL_TXN_CURR));
				oMap.put("CYCLE_TXN", i, "TXN_DESC", oMap2.getString(CYCLE_TXN_LIST, i, TXN_DESC));
				oMap.put("CYCLE_TXN", i, "INSTALL_DATE", oMap2.getString(CYCLE_TXN_LIST, i, INSTALL_DATE));
				oMap.put("CYCLE_TXN", i, "INSTALL_NO", oMap2.getString(CYCLE_TXN_LIST, i, INSTALL_NO));
				oMap.put("CYCLE_TXN", i, "TOTAL_INSTALL_COUNT", oMap2.getString(CYCLE_TXN_LIST, i, TOTAL_INSTALL_COUNT));
				oMap.put("CYCLE_TXN", i, "REMAINING_INSTALL_COUNT", oMap2.getString(CYCLE_TXN_LIST, i, REMAIN_INSTALL_COUNT));
				oMap.put("CYCLE_TXN", i, "REMAINING_INSTALL_AMOUNT", oMap2.getString(CYCLE_TXN_LIST, i, REMAIN_INSTALL_AMOUNT));
				oMap.put("CYCLE_TXN", i, "INSTALL_AMOUNT", oMap2.getString(CYCLE_TXN_LIST, i, INSTALL_AMOUNT));
				oMap.put("CYCLE_TXN", i, "TOTAL_INSTALL_AMOUNT", oMap2.getString(CYCLE_TXN_LIST, i, TOTAL_INSTALL_AMOUNT));
				oMap.put("CYCLE_TXN", i, "EARNED_POINT", oMap2.getString(CYCLE_TXN_LIST, i, EARNED_POINT));
				oMap.put("CYCLE_TXN", i, "USED_POINT", oMap2.getString(CYCLE_TXN_LIST, i, USED_POINT));
				String debitCredit = "";
				if (oMap2.getString(CYCLE_TXN_LIST, i, DEBIT_CREDIT_FLAG).equals("D"))
					debitCredit = "Bor�";
				else if (oMap2.getString(CYCLE_TXN_LIST, i, DEBIT_CREDIT_FLAG).equals("C"))
					debitCredit = "Alacak";
				else
					debitCredit = "N�tr";

				oMap.put("CYCLE_TXN", i, "DEBIT_CREDIT_FLAG", debitCredit);

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CC_CARD_INSTALLMENTS")
	public static GMMap getCardInstallments(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");

		try {
			GMMap iMap2 = new GMMap();
			iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
			iMap2.put(CURR_CODE, iMap.getString("CURR_CODE"));
			GMMap oMapH = new GMMap();
			oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
			iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
			iMap2.put(INSTALL_START_DATE, "");
			iMap2.put(INSTALL_END_DATE, "");
			iMap2.put(TXN_START_DATE, iMap.getString("TXN_START_DATE"));
			iMap2.put(TXN_END_DATE, iMap.getString("TXN_END_DATE"));
			if (iMap.get("TXN_START_DATE") != null && iMap.get("TXN_END_DATE") != null) {
				if (iMap.getDate("TXN_START_DATE").after(iMap.getDate("TXN_END_DATE"))) {
					GMMap exMap = new GMMap();
					exMap.put("P1", "Biti� tarihi ba�lang�� tarihinden b�y�k olmal�!");
					exMap.put("HATA_NO", "660");
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
				}

			}
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INSTALLMENTS", iMap2);
			int i = oMap2.getSize(INSTALL_TXN_LIST);
			int j = 0;

			for (int a = 0; a < i; a++) {
				if ("0".equals(oMap2.getString(INSTALL_TXN_LIST, a, INSTALL_NO))) {

					continue;
				}
				oMap.put("CARD_INSTALL", j, "CARD_NO", oMap2.getString(INSTALL_TXN_LIST, a, CARD_NO));
				oMap.put("CARD_INSTALL", j, "MAIN_CARD_NO", oMap2.getString(INSTALL_TXN_LIST, a, MAIN_CARD_NO));
				oMap.put("CARD_INSTALL", j, "TXN_DATE", sdf1.format(sdf.parse(oMap2.getString(INSTALL_TXN_LIST, a, TXN_DATE))));
				oMap.put("CARD_INSTALL", j, "INSTALL_DATE", sdf1.format(sdf.parse(oMap2.getString(INSTALL_TXN_LIST, a, INSTALL_DATE))));
				oMap.put("CARD_INSTALL", j, "TXN_CURRENCY", oMap2.getString(INSTALL_TXN_LIST, a, TXN_CURR_CODE));
				oMap.put("CARD_INSTALL", j, "INSTALL_NO", oMap2.getString(INSTALL_TXN_LIST, a, INSTALL_NO));
				oMap.put("CARD_INSTALL", j, "TOTAL_INSTALL_COUNT", oMap2.getString(INSTALL_TXN_LIST, a, TOTAL_INSTALL_COUNT));
				oMap.put("CARD_INSTALL", j, "REMAINING_INSTALL_COUNT", oMap2.getString(INSTALL_TXN_LIST, a, REMAIN_INSTALL_COUNT));
				oMap.put("CARD_INSTALL", j, "TXN_NAME", oMap2.getString(INSTALL_TXN_LIST, a, TXN_NAME));
				oMap.put("CARD_INSTALL", j, "TXN_DESC", oMap2.getString(INSTALL_TXN_LIST, a, TXN_DESC));
				oMap.put("CARD_INSTALL", j, "INSTALL_AMOUNT", oMap2.getString(INSTALL_TXN_LIST, a, INSTALL_AMOUNT));
				oMap.put("CARD_INSTALL", j, "TOTAL_INSTALL_AMOUNT", oMap2.getString(INSTALL_TXN_LIST, a, TOTAL_INSTALL_AMOUNT));
				oMap.put("CARD_INSTALL", j, "EARNED_POINT", oMap2.getString(INSTALL_TXN_LIST, a, EARNED_POINT));
				oMap.put("CARD_INSTALL", j, "USED_POINT", oMap2.getString(INSTALL_TXN_LIST, a, USED_POINT));
				oMap.put("CARD_INSTALL", j, "F43", oMap2.getString(INSTALL_TXN_LIST, a, F43));
				oMap.put("CARD_INSTALL", j, "RELEASE_DATE", oMap2.getString(INSTALL_TXN_LIST, a, RELEASE_DATE));
				oMap.put("CARD_INSTALL", j, "IS_DEFERED", oMap2.getString(INSTALL_TXN_LIST, a, IS_DEFERED));
				oMap.put("CARD_INSTALL", j, "BSMV_AMOUNT", oMap2.getString(INSTALL_TXN_LIST, a, BSMV_AMOUNT));
				oMap.put("CARD_INSTALL", j, "KKDF_AMOUNT", oMap2.getString(INSTALL_TXN_LIST, a, KKDF_AMOUNT));
				oMap.put("CARD_INSTALL", j, "REMAIN_INSTALL_AMOUNT", oMap2.getString(INSTALL_TXN_LIST, a, REMAIN_INSTALL_AMOUNT));
				j++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_GET_CC_CARD_INFO_WITH_CARD_NO")
	public static GMMap getCardInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		GMMap eMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		iMap2.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap2.put(CARD_NO, iMap.getString("CARD_NO"));
		iMap2.put(CARD_DCI, "C");
		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		eMap.put("KOD", "4405_KT_KARTLARI_GETIR");
		eMap.put("KEY", iMap.getString("BOLUM_KODU"));
		String isKT = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI", eMap).getString("IS_EXIST");
		try {
			GMMap oMap2 = new GMMap();
			oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap2);

			if (oMap2.getString(RETURN_CODE).equals("2"))

			{
				if (oMap2.getSize("CARD_DETAIL_INFO") < 1) {
					throw new Exception("Kart Bulunamad�");
				}
				if (isKT.equals("E") && !oMap2.getString("CARD_DETAIL_INFO", 0, CARD_STAT_CODE).equals("P")) {
					throw new Exception("Kart Bulunamad�");
				}
				for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {

					oMap.put("CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
					oMap.put("EMBOSS_NAME", oMap2.getString("CARD_DETAIL_INFO", i, CARD_EMBOSS_NAME_1));
					oMap.put("CARD_BRAND", oMap2.getString("CARD_DETAIL_INFO", i, CARD_BRAND));
					oMap.put("CUSTOMER_NO", oMap2.getString("CARD_DETAIL_INFO", i, CUSTOMER_NO));
					oMap.put("STATUS", oMap2.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
					oMap.put("MAIN_CARD_NO", oMap2.getString("CARD_DETAIL_INFO", i, MAIN_CARD_NO));
					oMap.put("SON_ODEME_TARIHI", sdf.parse(oMap2.getString("CARD_DETAIL_INFO", i, LAST_PAYMENT_DATE)));
					oMap.put("SON_KULL_TARIHI", oMap2.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE));

					List<GMMap> cardDebt = (List<GMMap>) oMap2.get(CARD_DETAIL_INFO, i, DEBT_INFO_LIST);
					GMMap cardMap = new GMMap(cardDebt.get(0));
					for (int j = 0; j < cardMap.getSize(DEBT_INFO_LIST); j++) {
						if (cardMap.getString(DEBT_INFO_LIST, j, CURRENCY).equals("TRY")) {
							oMap.put("KALAN_MIN_ODEME", cardMap.getBigDecimal(DEBT_INFO_LIST, j, MIN_PAYMENT_REMAINING));
							oMap.put("KALAN_EKSTRE_BORCU", cardMap.getBigDecimal(DEBT_INFO_LIST, j, LAST_STATEMENT_REMAINING));
							oMap.put("GUNCEL_DONEM_BORCU", cardMap.getBigDecimal(DEBT_INFO_LIST, j, CYCLE_DEBT));
						}
						else if (cardMap.getString(DEBT_INFO_LIST, j, CURRENCY).equals("USD")) {
							oMap.put("KALAN_MIN_ODEME_USD", cardMap.getBigDecimal(DEBT_INFO_LIST, j, MIN_PAYMENT_REMAINING));
							oMap.put("KALAN_EKSTRE_BORCU_USD", cardMap.getBigDecimal(DEBT_INFO_LIST, j, LAST_STATEMENT_REMAINING));
							oMap.put("GUNCEL_DONEM_BORCU_USD", cardMap.getBigDecimal(DEBT_INFO_LIST, j, CYCLE_DEBT));
						}
						else {
							oMap.put("KALAN_MIN_ODEME_OTH", cardMap.getBigDecimal(DEBT_INFO_LIST, j, MIN_PAYMENT_REMAINING));
							oMap.put("KALAN_EKSTRE_BORCU_OTH", cardMap.getBigDecimal(DEBT_INFO_LIST, j, LAST_STATEMENT_REMAINING));
							oMap.put("GUNCEL_DONEM_BORCU_OTH", cardMap.getBigDecimal(DEBT_INFO_LIST, j, CYCLE_DEBT));
						}

					}

					GMMap sMap = new GMMap();
					GMMap isMap = new GMMap();
					isMap.put(CARD_NO, oMap2.getString("CARD_DETAIL_INFO", i, CARD_NO));
					isMap.put(CARD_BRANCH, 1000);
					sMap = GMServiceExecuter.call("BNSPR_GET_CC_CARD_LAST_STATEMENT", isMap);
					oMap.put("EKSTRE_BORCU", sMap.getBigDecimal("EKSTRE_BORCU"));
					oMap.put("MIN_ODEME_TUTARI", sMap.getBigDecimal("MIN_ODEME_TUTARI"));
					oMap.put("HESAP_KESIM_TARIHI", sMap.getDate("HESAP_KESIM_TARIHI"));
					oMap.put("SONRAKI_EKSTRE_KESIM_TARIHI", sMap.getDate("SONRAKI_EKSTRE_KESIM_TARIHI"));
					oMap.put("SONRAKI_SON_ODEME_TARIHI", sMap.getDate("SONRAKI_SON_ODEME_TARIHI"));
					oMap.put("KULL_NA_LIMIT", oMap2.getString("CARD_DETAIL_INFO", i, CASH_LIMIT_AVAILABLE));
				}
			}
			else
				throw new Exception(oMap.getString(ERROR_DETAIL));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_CRD_IS_CUSTOMER_HAS_AN_ACTIVE_CARD")
	public static GMMap isCutomerHasAnActiveCard(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			String branchCode = getBranchCode();

			if (activeCardFromOcean(iMap.getBigDecimal(CUSTOMER_NO), branchCode)) {
				oMap.put("ACTIVE", "1");

			}
			else {
				oMap.put("ACTIVE", "0");
			}

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			oMap.put("ACTIVE", "2");
			oMap.put(ERROR_DETAIL, e.getMessage());
		}

		return oMap;
	}

	private static String getBranchCode() {
		return GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_SUBE_KOD", new GMMap()).getString("SUBE_KODU");
	}

	private static boolean activeCardFromOcean(BigDecimal customer, String branch) {
		GMMap ccMap = new GMMap();
		ccMap.put(CUSTOMER_NO, customer);
		ccMap.put(CARD_BRANCH, branch);
		ccMap.put(CARD_DCI, "A");
		ccMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", ccMap);

		int s = ccMap.getSize(CARD_DETAIL_INFO);
		if (s == 0) {
			return false;
		}

		String statuCode = "";
		String subStatuCode = "";

		for (int i = 0; i < s; i++) {

			statuCode = ccMap.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE");
			subStatuCode = ccMap.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE");

			if (statuCode.equals("N")) { // normal kart

				return true;

			}
			else if (statuCode.equals("G")) {

				if (subStatuCode.equals("N") || // Gecikmeli kart
				subStatuCode.equals("Y") || // Ayl�k yenileme
				subStatuCode.equals("T") || // Tahsilat takibinde
				subStatuCode.equals("P")) { // G�nl�k yenileme
					return true;
				}

			}
			else if (statuCode.equals("S")) {

				if (subStatuCode.equals("F") || // Fraud nedeni ile kapal�
				subStatuCode.equals("O")) { // Ge�ici s�reli a��k fraud
					return true;
				}

			}
			else if (statuCode.equals("I")) {
				if (subStatuCode.equals("I") || // �dari takip
				subStatuCode.equals("Y")) { // Yasal takip
					return true;
				}
			}
		}

		return false;
	}

	@GraymoundService("BNSPR_CVV2_RANDOM_CHAR_GETTER")
	public static GMMap creditCardCashAdvanceInitialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("CVV1", 1);
		oMap.put("CVV2", 2);
		oMap.put("CVV_TEXT", GMMessageFactory.getMessage("CCCASHADVCVV_CC", oMap));
		return oMap;
	}

	@GraymoundService("BNSPR_CVV2_RANDOM_CHAR_VALIDATE")
	public static GMMap validateCreditCardCashAdvance(GMMap iMap) {
		GMMap oMap = new GMMap();

		int cvvCounter = 0;
		if (iMap.getString("TXT_CVV1") != null && iMap.getString("TXT_CVV1").length() > 0) {
			cvvCounter++;
		}
		if (iMap.getString("TXT_CVV2") != null && iMap.getString("TXT_CVV2").length() > 0) {
			cvvCounter++;
		}
		if (iMap.getString("TXT_CVV3") != null && iMap.getString("TXT_CVV3").length() > 0) {
			cvvCounter++;
		}
		if (cvvCounter < 2) {
			oMap.put("RESPONSE", "1");
			oMap.put("RESPONSE_DATA", "CVV2 degerinizi eksik girdiniz.");
			oMap.put("REMOVE_CURRENT", false);
		}
		else {
			String cvv2 = iMap.getString("TXT_CVV1").isEmpty() ? "*" : iMap.getString("TXT_CVV1");
			cvv2 = cvv2.concat(iMap.getString("TXT_CVV2").isEmpty() ? "*" : iMap.getString("TXT_CVV2"));
			cvv2 = cvv2.concat(iMap.getString("TXT_CVV3").isEmpty() ? "*" : iMap.getString("TXT_CVV3"));

			iMap.put("CVV2", cvv2);

			GMMap cardMap = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap);

			GMMap cvv2Map = null;
			if ("I".equals(cardMap.getString("DESTINATION")))
				cvv2Map = GMServiceExecuter.call("BNSPR_INTRACARD_CVV_CHECK", iMap);
			else
				cvv2Map = GMServiceExecuter.call("BNSPR_OCEAN_CVV2_CHECK", iMap);

			oMap.put("RESPONSE", cvv2Map.getInt("RETURN_CODE"));

			if (cvv2Map.getInt("RETURN_CODE") == 57) {
				oMap.put("RESPONSE_DATA", "CVV2 degerinizi yanl�� girdiniz.");
			}
			else if (cvv2Map.getInt("RETURN_CODE") == 5) {
				oMap.put("RESPONSE_DATA", "Hatal� giri� nedeniyle CVV2 blokelenmi�tir.");
			}
			else if (cvv2Map.getInt("RETURN_CODE") != 0) {
				oMap.put("RESPONSE_DATA", cvv2Map.getString("RETURN_DESCRIPTION"));
			}

		}
		return oMap;
	}

	@GraymoundService("BNSPR_OCEAN_SET_AUTOPAYMENT")
	public static GMMap setAutoPayment(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "AUTO_PAYMENT_INFO";
		List<GMMap> AutoPaymentList = (ArrayList<GMMap>) iMap.get(tableName);
		if (AutoPaymentList != null && AutoPaymentList.size() > 0) {
			oMap = AutoPaymentList.get(0);
			for (int i = 0; i < oMap.getSize(tableName); i++) {
				if ("MinimumBalance".equals(oMap.getString(tableName, i, "AUTO_PAYMENT_TYPE")))
					oMap.put(tableName, i, "AUTO_PAYMENT_TYPE_NAME", "Asgari Bor�");
				else if ("TotalBalance".equals(oMap.getString(tableName, i, "AUTO_PAYMENT_TYPE")))
					oMap.put(tableName, i, "AUTO_PAYMENT_TYPE_NAME", "Toplam Bor�");
			}
		}
		else {
			oMap.put(tableName, (String) null);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CC_GET_CARD_PAYMENT_INFO")
	public static GMMap getPaymentInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = GMServiceExecuter.call("BNSPR_TFF_KART_ODEME_BILGILERI_WITH_FOTO", iMap);
			oMap.put("KART_BEDELI", oMap.getString("ODEME_BILGILERI", 0, "KART_BEDELI"));
			oMap.put("KURYE_BEDELI", oMap.getString("ODEME_BILGILERI", 0, "KURYE_BEDELI"));
			oMap.put("VIZE_BEDELI", oMap.getString("ODEME_BILGILERI", 0, "VIZE_BEDELI"));
		}
		catch (Exception e) {
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CC_GET_DEBIT_PREPAID_TRANSPORT")
	public static GMMap getDebitPrepaidTransportations(GMMap iMap) {
		GMMap oMap;
		GMMap oceanMap;
		String tableName = "TXN_LIST";
		oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_EKENT_TRX_LIST", iMap);
		for (int i = 0; i < oMap.getSize(tableName); i++) {
			if (StringUtils.isNotBlank(oMap.getString(tableName, i, "PROCESS_DATE_TIME")) && oMap.getString(tableName, i, "PROCESS_DATE_TIME").length() == DATE_TIME_LENGTH) {
				oMap.put(tableName, i, "PROCESS_DATE", oMap.getString(tableName, i, "PROCESS_DATE_TIME").substring(0, 8));
				oMap.put(tableName, i, "PROCESS_TIME", oMap.getString(tableName, i, "PROCESS_DATE_TIME").substring(8));
			}
		}
		oceanMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_EKENT_TXN_LIST", iMap);
		for (int i = 0; i < oceanMap.getSize(tableName); i++) {
			if (StringUtils.isNotBlank(oceanMap.getString(tableName, i, "PROCESS_DATE_TIME")) && oceanMap.getString(tableName, i, "PROCESS_DATE_TIME").length() == DATE_TIME_LENGTH) {
				oceanMap.put(tableName, i, "PROCESS_DATE", oceanMap.getString(tableName, i, "PROCESS_DATE_TIME").substring(0, 8));
				oceanMap.put(tableName, i, "PROCESS_TIME", oceanMap.getString(tableName, i, "PROCESS_DATE_TIME").substring(8));
			}
			oMap.put(tableName, oMap.getSize(tableName), oceanMap.getMap(tableName, i));
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_CARD_INFO_FOR_TRANSACTIONS")
	public static GMMap getCardInfoForTrans(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap oceanMap = new GMMap();
		GMMap newMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM/yy");

		boolean isHceOnline = false;
		boolean isHceAnkara = false;
		boolean isHceKahraman = false;
		boolean isCreditCard = false;

		if (BnsprOceanCommonFunctions.isNewCard(iMap.getString(CUSTOMER_NO), iMap.getString(CARD_NO), null)) {
			newMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_INFO", iMap);

			try {

				String productId = "";
				for (int i = 0, k = 0; i < newMap.getSize("CARD_DETAIL_INFO"); i++) {

					if (BnsprOceanCommonFunctions.isIntra(newMap.getString(CARD_DETAIL_INFO, i, CARD_GROUP), newMap.getString(CARD_DETAIL_INFO, i, CARD_DCI))) {
						newMap.put(CARD_DETAIL_INFO, i, SYSTEM, OceanConstants.Card_Source_Intracard);
					}
					else {
						newMap.put(CARD_DETAIL_INFO, i, SYSTEM, OceanConstants.Card_Source_Ocean);
					}

					if (StringUtils.isNotBlank(newMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
						newMap.put("CARD_DETAIL_INFO", i, "EXPIRE_DATE", sdf2.format(sdf.parse(newMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
						newMap.put("CARD_DETAIL_INFO", i, "TOTAL_EARNED_POINTS", GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_POINT_INFO", iMap).getBigDecimal("POINT_TABLE", 0, "TOTAL_EARNED_POINT"));
					}

					productId = !StringUtils.isEmpty(newMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)) ? newMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID) : "";

					isHceOnline = KkProductsUtil.isHceProduct(productId, "ONLINE");
					isHceAnkara = KkProductsUtil.isHceProduct(productId, "OFFLINE", "ANKARA");
					isHceKahraman = KkProductsUtil.isHceProduct(productId, "OFFLINE", "MARAS");
					isCreditCard = "Credit".equals(newMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));

					if (isHceAnkara) {
						oMap.put("TRANSPORTATION_CARD_HCE", newMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
						oMap.put("TRANSPORTATION_CARD_HCE_MASKED", newMap.getString("CARD_DETAIL_INFO", i, MASKED_CARD_NO));
						oMap.put("PRODUCT_ID_HCE", productId);
					}
					if (isHceKahraman) {
						oMap.put("TRANSPORTATION_CARD_KAHRAMAN", newMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
						oMap.put("TRANSPORTATION_CARD_KAHRAMAN_MASKED", newMap.getString("CARD_DETAIL_INFO", i, MASKED_CARD_NO));
						oMap.put("PRODUCT_ID_KAHRAMAN", productId);
					}

					if (!isCreditCard && !isHceOnline && !isHceAnkara && !isHceKahraman) { // hce ve kredi kart� hari� intra/ocean/mchip dahil
						oMap.put("CARD_DETAIL_INFO", k, newMap.getMap("CARD_DETAIL_INFO", i));
						k++;
					}

				}
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}

		}
		else {
			oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", iMap);
			oceanMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap);

			try {
				for (int i = 0; i < oMap.getSize("CARD_DETAIL_INFO"); i++) {
					if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
						oMap.put("CARD_DETAIL_INFO", i, "EXPIRE_DATE", sdf2.format(sdf.parse(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
						oMap.put("CARD_DETAIL_INFO", i, "TOTAL_EARNED_POINTS", GMServiceExecuter.call("BNSPR_INTRACARD_GET_CUSTOMER_POINT_INFO", iMap).getBigDecimal("POINT_TABLE", 0, "TOTAL_EARNED_POINT"));
						oMap.put("CARD_DETAIL_INFO", i, "SYSTEM", "I");

					}
				}
				String productId = "";

				for (int i = 0, k = 0; i < oceanMap.getSize("CARD_DETAIL_INFO"); i++) {

					productId = !StringUtils.isEmpty(oceanMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)) ? oceanMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID) : "";

					isCreditCard = "Credit".equals(oceanMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));

					isHceAnkara = KkProductsUtil.isHceProduct(productId, "OFFLINE", "ANKARA");
					isHceKahraman = KkProductsUtil.isHceProduct(productId, "OFFLINE", "MARAS");

					if (isHceAnkara) {
						oMap.put("TRANSPORTATION_CARD_HCE", oceanMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
						oMap.put("TRANSPORTATION_CARD_HCE_MASKED", oceanMap.getString("CARD_DETAIL_INFO", i, MASKED_CARD_NO));
						oMap.put("PRODUCT_ID_HCE", productId);
					}
					if (isHceKahraman) {
						oMap.put("TRANSPORTATION_CARD_KAHRAMAN", oceanMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
						oMap.put("TRANSPORTATION_CARD_KAHRAMAN_MASKED", oceanMap.getString("CARD_DETAIL_INFO", i, MASKED_CARD_NO));
						oMap.put("PRODUCT_ID_KAHRAMAN", productId);
					}

					if (!isCreditCard && !isHceOnline && !isHceAnkara && !isHceKahraman) { // hce ve kredi kart� hari� ocean/mchip dahil
						if (StringUtils.isNotBlank(oceanMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
							oceanMap.put("CARD_DETAIL_INFO", k, "EXPIRE_DATE", sdf2.format(sdf.parse(oceanMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
							oceanMap.put("CARD_DETAIL_INFO", k, "TOTAL_EARNED_POINTS", GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_POINT_INFO", iMap).getBigDecimal("POINT_TABLE", 0, "TOTAL_EARNED_POINT"));
						}
						oMap.put("CARD_DETAIL_INFO", k, oceanMap.getMap("CARD_DETAIL_INFO", i));
						oMap.put("CARD_DETAIL_INFO", k, "SYSTEM", "O");
						k++;
					}
				}
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_PIN_COMBO_DATA")
	public static GMMap getPinComboData(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GuimlUtil.wrapMyCombo(oMap, "CARD_DETAIL_INFO", "O", "ONLINE PIN �LE  DO�RULAMA YAPILDI");
			GuimlUtil.wrapMyCombo(oMap, "CARD_DETAIL_INFO", "N", "��FRE KULLANILMADI");
			GuimlUtil.wrapMyCombo(oMap, "CARD_DETAIL_INFO", "F", "OFFLINE PIN �LE DO�RULANDI");
			GuimlUtil.wrapMyCombo(oMap, "CARD_DETAIL_INFO", "S", "�MZA �LE DO�RULAMA YAPILDI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_WEBEXT_OCEAN_GET_CUSTOMER_INFO_WRAPPER")
	public static GMMap BNSPR_WEBEXT_OCEAN_GET_CUSTOMER_INFO_WRAPPER(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = GMServiceExecuter.call("BNSPR_WEBEXT_OCEAN_GET_CUSTOMER_INFO", iMap);
			for (int i = 0; i < oMap.getSize("AddressList"); i++) {
				String adres = "";
				adres += " " + (oMap.getString("AddressList", i, "AddressLine1") == null ? " " : oMap.getString("AddressList", i, "AddressLine1"));
				adres += " " + (oMap.getString("AddressList", i, "AddressLine2") == null ? " " : oMap.getString("AddressList", i, "AddressLine2"));
				adres += " " + (oMap.getString("AddressList", i, "AddressLine3") == null ? " " : oMap.getString("AddressList", i, "AddressLine3"));
				adres += " " + (oMap.getString("AddressList", i, "AddressCity") == null ? " " : oMap.getString("AddressList", i, "AddressCity"));
				adres += " " + (oMap.getString("AddressList", i, "Town") == null ? " " : oMap.getString("AddressList", i, "Town"));
				adres += " " + (oMap.getString("AddressList", i, "AddressCountry") == null ? " " : oMap.getString("AddressList", i, "AddressCountry"));
				if (oMap.getString("AddressList", i, "AddressType").equals("H"))
					oMap.put("HomeAddress", adres);
				else if (oMap.getString("AddressList", i, "AddressType").equals("W"))
					oMap.put("WorkAddress", adres);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_GET_CARD_INFO_CVV2_UNBLOCK")
	public static GMMap getCardListForCVV2Unblock(GMMap iMap) {
		GMMap iMap2 = new GMMap();
		iMap2.put(CUSTOMER_NO, iMap.getString("CUSTOMER_NO"));
		iMap2.put(CARD_NO, "");
		iMap2.put("INPUT_PARAMETER_TYPE", "CST");
		iMap2.put("NO_NEED_APPLICATIONS", true);
		iMap2.put("CARD_BANK_STATUS_CC", "All");
		iMap2.put("PROCEED", iMap.getString("PROCEED"));

		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap2.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		GMMap oMap = new GMMap();
		String cardGroup = "";
		String cardProductId = "";
		boolean isNKolayKart = false;
		boolean isPassoligCard = false;
		// boolean isYIMKart = false;
		// boolean isUptKart = false;
		// boolean isTroyKart = false;
		// -Hce
		boolean isVirtualPP = false;
		// -Hce
		boolean mchipCard = false;
		try {
			GMMap oMap2 = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap2);
			for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
				if (oMap2.getInt("CARD_DETAIL_INFO", i, CVV2_RETRY_COUNT) >= 3 || StringUtils.isNotBlank(oMap2.getString("CARD_DETAIL_INFO", i, CVV2_BLOCK_DATE))) {
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_IS_BLOCKED", "Blokeli");
				}
				else {
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_IS_BLOCKED", "Blokesiz");

				}
				if ("Credit".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI)))
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Kredi Kart�");
				else if ("Prepaid".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI)))
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Prepaid");
				else if ("Debit".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI)))
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Debit");

				String cardNo = oMap2.getString("CARD_DETAIL_INFO", i, "CARD_NO");
				oMap2.put("CARD_DETAIL_INFO", i, "MASKED_CARD_NO", maskCardNumberFirst6Last4(cardNo));

				cardGroup = oMap2.getString(CARD_DETAIL_INFO, i, CARD_GROUP);
				cardProductId = oMap2.getString(CARD_DETAIL_INFO, i, PRODUCT_ID);

				isPassoligCard = "1".equals(cardGroup);
				isNKolayKart = KkProductsUtil.isNkolayProduct(cardProductId);// "905".equals(cardProductId) || "906".equals(cardProductId); //hepsini kaps�yor (905,906,910,912,917,916)
				// isYIMKart = "910".equals(cardProductId);
				// isUptKart ="912".equals(cardProductId);
				// isTroyKart ="916".equals(cardProductId);
				// -Hce
				isVirtualPP = KkProductsUtil.isVirtualProduct(cardProductId);// "914".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				// -Hce
				mchipCard = KkProductsUtil.isMchipProduct(cardProductId);// CreditCardQRY4410Services.mchipFilter(oMap2, i, 1,"CARD_DETAIL_INFO", PRODUCT_ID);
				// if(isPassoligCard || isNKolayKart || isYIMKart || isUptKart || isTroyKart || isVirtualPP || mchipCard){
				if (isPassoligCard || isNKolayKart || isVirtualPP || mchipCard) {
					oMap.put(CARD_DETAIL_INFO, oMap.getSize(CARD_DETAIL_INFO), oMap2.getMap(CARD_DETAIL_INFO, i));
				}

			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_CARD_INFO_CC")
	public static GMMap getCardListForDebitPrepaidCard(GMMap iMap) {
		GMMap oMapH = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));
		boolean OCEAN_BUT_ONLY_OCEAN_DEBIT = iMap.getBoolean("OCEAN_BUT_ONLY_OCEAN_DEBIT", false);
		boolean ONLY_PREPAID = iMap.getBoolean("ONLY_PREPAID", false);
		boolean NON_NKOLAY = iMap.getBoolean("NON_NKOLAY", false);
		boolean isOcean = false;
		boolean isNKolayKart = false;
		boolean isYIMKart = false;
		boolean isUptKart = false;
		boolean isTroyKart = false;
		boolean isVirtualPP = false;
		boolean mchipCard = false;
		String cardStatCode = "";
		String cardSubStatCode = "";

		GMMap oMap = new GMMap();
		try {
			GMMap oMap2 = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
			for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
				if ("Credit".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI)))
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Kredi Kart�");
				else if ("Prepaid".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI)))
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Prepaid");
				else if ("Debit".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI)))
					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Debit");

				String cardNo = oMap2.getString("CARD_DETAIL_INFO", i, "CARD_NO");
				oMap2.put("CARD_DETAIL_INFO", i, "MASKED_CARD_NO", CommonServices.maskCardNumber(cardNo));

				String cardProductId = !StringUtils.isEmpty(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID)) ? oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID) : "";
				isOcean = "O".equals(oMap2.getString("CARD_DETAIL_INFO", i, SYSTEM));
				isNKolayKart = KkProductsUtil.isNkolayDebitProduct(cardProductId, OceanConstants.MASTERCARD);// "905".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID)) || "906".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isYIMKart = KkProductsUtil.isYimPpProduct(cardProductId);// "910".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isUptKart = KkProductsUtil.isUptPpProduct(cardProductId);// "912".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isTroyKart = KkProductsUtil.isTroyDebitProduct(cardProductId);// "916".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isVirtualPP = KkProductsUtil.isVirtualProduct(cardProductId); // "914".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				mchipCard = KkProductsUtil.isMchipProduct(cardProductId);// CreditCardQRY4410Services.mchipFilter(oMap2, i, 1, "CARD_DETAIL_INFO", PRODUCT_ID);
				cardStatCode = oMap2.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE");
				cardSubStatCode = oMap2.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE");

				if (NON_NKOLAY) {
					if (((isOcean || isUptKart || isTroyKart) && !isNKolayKart) || !isOcean) {
						oMap.put(CARD_DETAIL_INFO, oMap.getSize(CARD_DETAIL_INFO), oMap2.getMap(CARD_DETAIL_INFO, i));
					}
				}
				else if (OCEAN_BUT_ONLY_OCEAN_DEBIT) {
					if (!isOcean || isNKolayKart || isYIMKart || isTroyKart || isUptKart || isVirtualPP || mchipCard) {

						oMap.put(CARD_DETAIL_INFO, oMap.getSize(CARD_DETAIL_INFO), oMap2.getMap(CARD_DETAIL_INFO, i));

					}
				}
				else if (ONLY_PREPAID) {
					if ("Prepaid".equals(oMap2.getString("CARD_DETAIL_INFO", i, CARD_DCI))) {
						oMap.put(CARD_DETAIL_INFO, oMap.getSize(CARD_DETAIL_INFO), oMap2.getMap(CARD_DETAIL_INFO, i));
					}
				}
				else {
					oMap.put(CARD_DETAIL_INFO, oMap.getSize(CARD_DETAIL_INFO), oMap2.getMap(CARD_DETAIL_INFO, i));
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_DEBIT_CARD_INFO_CC")
	public static GMMap getCardListForDebitCard(GMMap iMap) {
		GMMap oMapH = new GMMap();
		GMMap inMap = new GMMap();
		GMMap bMap = new GMMap();
		GMMap cardMap = new GMMap();
		oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap);
		iMap.put(CARD_BRANCH, oMapH.getString("SUBE_KOD"));

		GMMap oMap = new GMMap();
		try {
			GMMap oMap2 = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
			for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
				String cardNo = oMap2.getString("CARD_DETAIL_INFO", i, "CARD_NO");
				oMap2.put("CARD_DETAIL_INFO", i, "MASKED_CARD_NO", CommonServices.maskCardNumber(cardNo));
				if (("Debit".equals(oMap2.getString("CARD_DETAIL_INFO", i, "CARD_DCI")) || "Prepaid".equals(oMap2.getString("CARD_DETAIL_INFO", i, "CARD_DCI"))) && "N".equals(oMap2.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE"))) {

					cardMap.put("CARD_NO", oMap2.getString(CARD_DETAIL_INFO, i, CARD_NO));

					cardMap.put("SYSTEM", oMap2.getString(CARD_DETAIL_INFO, i, SYSTEM));

					inMap.put("HESAP_NO", GMServiceExecuter.call("BNSPR_DC_GET_TFF_DEBIT_CARD_MAIN_ACCOUNT", cardMap).getString("DEBIT_ACCOUNT_NO"));

					bMap.put("INFO", 0, "KULLANILABILIR_BAKIYE", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", inMap).getString("KULLANILABILIR_BAKIYE"));

					oMap2.put("CARD_DETAIL_INFO", i, "CARD_DCI_DESC", "Debit");

					oMap2.put("CARD_DETAIL_INFO", i, "KULLANILABILIR_BAKIYE", bMap.getString("INFO", 0, "KULLANILABILIR_BAKIYE"));

					oMap.put("CARD_DETAIL_INFO", oMap.getSize(CARD_DETAIL_INFO), oMap2.getMap(CARD_DETAIL_INFO, i));

					// oMap.put("CARD_DETAIL_INFO", oMap.getSize(CARD_DETAIL_INFO), bMap.getMap(CARD_DETAIL_INFO, 0));

				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_CC_GET_CREDIT_TRANSPORT")
	public static GMMap getCreditTransportations(GMMap iMap) {
		GMMap oMap;
		String tableName = "TXN_LIST";
		oMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_EKENT_TXN_LIST", iMap);
		for (int i = 0; i < oMap.getSize(tableName); i++) {
			if (StringUtils.isNotBlank(oMap.getString(tableName, i, "PROCESS_DATE_TIME")) && oMap.getString(tableName, i, "PROCESS_DATE_TIME").length() == DATE_TIME_LENGTH) {
				oMap.put(tableName, i, "PROCESS_DATE", oMap.getString(tableName, i, "PROCESS_DATE_TIME").substring(0, 8));
				oMap.put(tableName, i, "PROCESS_TIME", oMap.getString(tableName, i, "PROCESS_DATE_TIME").substring(8));
			}
		}

		return oMap;
	}

	@GraymoundService("CHANGE_DEBIT_PREPAID_CARD_PIN_RANDOM_SEND_SMS")
	public static GMMap changeDebitPrepaidCardPinRandomSendSMS(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_CODE", "DPCPINSMS");// CHANGE_DEBIT_PREPAID_CARD_PIN_RANDOM_SEND_SMS_INNER
		oMap.putAll(GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap));
		return oMap;
	}

	@GraymoundService("CHANGE_DEBIT_PREPAID_CARD_PIN_RANDOM_SEND_SMS_INNER")
	public static GMMap changeDebitPrepaidCardPinRandomSendSMSInner(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap cardMap = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap);
		if ("I".equals(cardMap.getString("DESTINATION"))) {
			oMap = changeIntraCardPinRandomSendSMS(iMap);
		}
		else {
			iMap.put("LOGGED_ALREADY", true);
			oMap = changeOceanCardPinRandomSendSMS(iMap);
		}
		return oMap;
	}

	public static GMMap changeIntraCardPinRandomSendSMS(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_PIN_CHANGE_WITH_RANDOM_NEW_PIN", iMap));
		// EY Ekledi NKolay ve Passo Kartlarda SMS Aktifbank gitmeli
		if ("IVR".equals(iMap.getString("HEADER_SOURCE"))) {
			iMap.put("HEADER", iMap.getString("IVR_HEADER"));
		}
		else {
			iMap.put("HEADER", "Passolig");
		}
		iMap.put("CARD_TYPE", "INTRACARD");
		sendSMS(iMap, oMap);
		return oMap;
	}

	@GraymoundService("CHANGE_CREDIT_CARD_PIN_RANDOM_SEND_SMS")
	public static GMMap changeOceanCardPinRandomSendSMS(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (iMap.containsKey("LOGGED_ALREADY")) {
			oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_PIN_CHANGE_WITH_RANDOM_NEW_PIN", iMap));
		}
		else {
			iMap.put("PROCESS_CODE", "CCPINSMS");// BNSPR_OCEAN_PIN_CHANGE_WITH_RANDOM_NEW_PIN
			oMap.putAll(GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap));
		}

		// EY Ekledi NKolay ve Passo Kartlarda SMS Aktifbank gitmeli
		if ("IVR".equals(iMap.getString("HEADER_SOURCE"))) {
			iMap.put("HEADER", iMap.getString("IVR_HEADER"));
		}
		else {
			iMap.put("HEADER", "Aktif Bank");
		}

		iMap.put("CARD_TYPE", "OCEAN");
		sendSMS(iMap, oMap);
		return oMap;
	}

	private static void sendSMS(GMMap iMap, GMMap oMap) {
		String otpPhoneNumber = getOTPPhoneNumber(iMap);
		String MSISDN = otpPhoneNumber;
		boolean FILTER = true;
		boolean SECURE_CONTENT = true;

		iMap.put("CONTENT", "Sayin musterimiz, " + iMap.getString("CARD_NO").substring(12, 16) + " ile biten kartinizin sifresi " + oMap.getString("NEW_PIN") + " olarak belirlenmistir. Guvenliginiz icin sifrenizi kimseyle paylasmayiniz");

		String MUSTERI_NO = iMap.getString("CUSTOMER_NO");

		iMap.put("MSISDN", MSISDN);
		iMap.put("FILTER", FILTER);
		iMap.put("SECURE_CONTENT", SECURE_CONTENT);
		iMap.put("MUSTERI_NO", MUSTERI_NO);

		GMServiceExecuter.executeAsync("BNSPR_SMS_SEND_SMS", iMap);
	}

	private static String getOTPPhoneNumber(GMMap iMap) {

		if ("OCEAN".equals(iMap.getString("CARD_TYPE")))
			iMap = getCustomerDetailsFromOcean(iMap);
		else
			iMap = getCustomerDetailsFromIntraCard(iMap);

		iMap.put("MUSTERI_NO", iMap.getString("CUSTOMER_NO"));

		GMMap oMap = GMServiceExecuter.call("CNSPR_MUSTERI_TELEFON_NO_LISTE", iMap);

		String gsmPhone = null;

		for (int i = 0; i < oMap.getSize("MUSTERI_TEL_NO_LISTE"); i++) {

			String tip = oMap.getString("MUSTERI_TEL_NO_LISTE", i, "TEL_TIP");
			String otpMi = oMap.getString("MUSTERI_TEL_NO_LISTE", i, "OTP_MI");

			if ("E".equalsIgnoreCase(otpMi)) {
				return oMap.getString("MUSTERI_TEL_NO_LISTE", i, "TEL");
			}
			else if ("3".equals(tip)) {
				gsmPhone = oMap.getString("MUSTERI_TEL_NO_LISTE", i, "TEL");
			}
		}

		return gsmPhone;

	}

	private static GMMap getCustomerDetailsFromIntraCard(GMMap iMap) {
		iMap.put("CARD_DCI", "All");
		iMap.put("CUSTOMER_NO", "");
		iMap.put("TCKN", "");
		GMMap customerMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", iMap);
		ArrayList<HashMap> arrayList = (ArrayList<HashMap>) customerMap.get("CARD_DETAIL_INFO");
		customerMap.putAll(arrayList.get(0));
		String customerNo = customerMap.getString("OCEAN_CUSTOMER_NO");
		iMap.put("CUSTOMER_NO", customerNo);
		customerMap = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_BIRTH_DATE", iMap);
		iMap.put("BIRTH_DATE", customerMap.getString("BIRTH_DATE"));
		return iMap;
	}

	private static GMMap getCustomerDetailsFromOcean(GMMap iMap) {
		iMap.put("CARD_DCI", "All");
		iMap.put("CUSTOMER_NO", "");
		iMap.put("TCKN", "");
		GMMap customerMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap);
		ArrayList<HashMap> arrayList = (ArrayList<HashMap>) customerMap.get("CARD_DETAIL_INFO");
		customerMap.putAll(arrayList.get(0));
		String customerNo = customerMap.getString("OCEAN_CUSTOMER_NO");
		iMap.put("CUSTOMER_NO", customerNo);
		customerMap = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_BIRTH_DATE", iMap);
		iMap.put("BIRTH_DATE", customerMap.getString("BIRTH_DATE"));
		return iMap;
	}

	@GraymoundService("BNSPR_GET_KK_OCEAN_CARD_INFO")
	public static GMMap getKKOceanCardInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			// TY-3663 - SS patlama durumlarina karsin parametre eklendi
			GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "KART_BILGILERI_SORGU")).uniqueResult();
			if (!"A".equals(parametre.getDeger())) {
				oMap.put("RESPONSE_DATA", "KART_BILGILERI_SORGU parametresi aktif degil");
				return oMap;
			}

			// PY-7931 - Basvuru numarasindan musteri no bul
			if (iMap.get("MUSTERI_NO") == null) {
				if (iMap.get("BASVURU_NO") == null) {
					oMap.put("RESPONSE_DATA", "Musteri ve Basvuru No alanlari bos");
					return oMap;
				}

				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuru != null) {
					iMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
				}
				else {
					oMap.put("RESPONSE_DATA", "Basvuru bulunamadi");
					return oMap;
				}
			}

			// Musterinin oceandaki bilgilerini al
			GMMap customerMap = new GMMap();
			customerMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			customerMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CUSTOMER_INFO", customerMap));
			// Musteri var mi?
			String iTableName = "CUSTOMER_INFO_LIST";
			if (customerMap.getSize(iTableName) == 0) {
				oMap.put("RESPONSE_DATA", "BNSPR_OCEAN_GET_CUSTOMER_INFO servisinden deger donmedi");
				return oMap;
			}

			for (int i = 0; i < customerMap.getSize(iTableName); i++) {
				String customerLimit = customerMap.getString(iTableName, i, "CUSTOMER_LIMIT");
				if (StringUtils.isNotBlank(customerLimit)) {
					customerLimit = customerLimit.replace(",", ".");
				}

				customerMap.put("MUSTERI_LIMIT", customerLimit);
				customerMap.put("MUSTERI_GRUP", customerMap.get(iTableName, i, "CUSTOMER_GROUP"));
				customerMap.put("MUSTERI_TIP", customerMap.get(iTableName, i, "CUSTOMER_TYPE"));
			}
			customerMap.remove(iTableName);

			// Musterinin oceandaki kart bilgilerini al
			GMMap cardMap = new GMMap();
			cardMap.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
			cardMap.put("CARD_DCI", "C");
			cardMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardMap));
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(cardMap.getString(RETURN_CODE))) {
				oMap.put("RESPONSE_DATA", "BNSPR_OCEAN_GET_CARD_INFO servisinden deger donmedi");
				return oMap;
			}

			// KkOceanCardinfo id almak icin map olustur
			int list_count = 0;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			GMMap nbsmMap = new GMMap();
			GMMap idMap = new GMMap();
			idMap.put("TABLE_NAME", "KK_OCEAN_CARD_INFO");

			// iki tane DEBT_INFO_LIST var icice
			for (int i = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {
				List<GMMap> debtInfoMapList = (List<GMMap>) cardMap.get(CARD_DETAIL_INFO, 0, DEBT_INFO_LIST);
				GMMap debtInfoMap = new GMMap(debtInfoMapList.get(0));
				for (int j = 0; j < debtInfoMap.getSize(DEBT_INFO_LIST); j++) {
					if (!"E".equals(iMap.getString("TAHSIS_IZLEME"))) {
						idMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", idMap));
						KkOceanCardinfo kkOceanCardinfo = new KkOceanCardinfo();
						kkOceanCardinfo.setId(idMap.getBigDecimal("ID"));
						kkOceanCardinfo.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						kkOceanCardinfo.setMusteriNo(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CUSTOMER_NO));
						kkOceanCardinfo.setCardNo(cardMap.getString(CARD_DETAIL_INFO, i, CARD_NO));
						kkOceanCardinfo.setDurumKod(cardMap.getString(CARD_DETAIL_INFO, i, CARD_STAT_CODE));
						kkOceanCardinfo.setDurumKodAciklama(cardMap.getString(CARD_DETAIL_INFO, i, CARD_STAT_DESC));
						kkOceanCardinfo.setAltDurumKod(cardMap.getString(CARD_DETAIL_INFO, i, CARD_SUB_STAT_CODE));
						kkOceanCardinfo.setAcilisTarihi(cardMap.getDate(CARD_DETAIL_INFO, i, EMBOSS_DATE));
						kkOceanCardinfo.setDurumDegismeTarihi(cardMap.getDate(CARD_DETAIL_INFO, i, CARD_STAT_CHANGE_DATE));
						kkOceanCardinfo.setKartLimiti(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CARD_LIMIT));
						kkOceanCardinfo.setKullanilabilirLimit(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CARD_AVAIL_LIMIT));
						kkOceanCardinfo.setDovizKodu(debtInfoMap.getString(DEBT_INFO_LIST, j, CURRENCY));
						kkOceanCardinfo.setKapamaTutari(debtInfoMap.getBigDecimal(DEBT_INFO_LIST, j, PAYOFF_TOTAL));
						kkOceanCardinfo.setYasalSayacDegeri(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, MIN_PAYMENT_COUNT));
						kkOceanCardinfo.setEskiKartNo(cardMap.getString(CARD_DETAIL_INFO, i, OLD_CARD_NO));
						kkOceanCardinfo.setKartBasvuruNo(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, APPLICATION_NO));
						kkOceanCardinfo.setToplamRiski(debtInfoMap.getBigDecimal(DEBT_INFO_LIST, j, TOTAL_DEBT));
						kkOceanCardinfo.setMusteriTipi(customerMap.getString("MUSTERI_TIP"));

						// NBSM bilgilerini al
						nbsmMap.clear();
						nbsmMap.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
						nbsmMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_NBSM_INFO", nbsmMap));
						if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(nbsmMap.getString(RETURN_CODE))) {
							for (int k = 0; k < nbsmMap.getSize("LIST"); k++) {
								if (kkOceanCardinfo.getCardNo().equals(nbsmMap.getString("LIST", k, "CARD_NO"))) {
									kkOceanCardinfo.setGecikmeGunSayisi(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_PYMNT_DELAY_D"));
									kkOceanCardinfo.setGecikmeTutari(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_PYMNT_DELAY_AMNT"));
									kkOceanCardinfo.setSonOdemeTutari(nbsmMap.getBigDecimal("LIST", k, "APP_CC_PAY_AMNT"));
									kkOceanCardinfo.setToplamEkstreAdediMax(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_TOT_EXTRACT_NUM"));
									kkOceanCardinfo.setToplamEkstreTutariMax(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_TOT_EXTRACT_AMNT"));
									kkOceanCardinfo.setToplamOdemeTutariMax(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_TOT_PAID_AMNT"));
									kkOceanCardinfo.setSonEkstreTutariMax(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_LM_EXTRACT_AMNT"));
									kkOceanCardinfo.setSonOdemeTutariMax(nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_LM_PAID_AMNT"));
									kkOceanCardinfo.setKanuniTakipVarMi(nbsmMap.getString("LIST", k, "APP_CC_OPEN_LTG_F"));
									kkOceanCardinfo.setMacLimitliMi(nbsmMap.getString("LIST", k, "APPN_MATCH_TICKET_F"));
								}
							}
						}

						session.saveOrUpdate(kkOceanCardinfo);
						session.flush();
					}
					else {
						oMap.put("KREDI_KART_BILGI", list_count, "ILISKI_TURU", "Kendisi");
						oMap.put("KREDI_KART_BILGI", list_count, "BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						oMap.put("KREDI_KART_BILGI", list_count, "KART_NO", cardMap.getString(CARD_DETAIL_INFO, i, CARD_NO));
						oMap.put("KREDI_KART_BILGI", list_count, "DURUM", cardMap.getString(CARD_DETAIL_INFO, i, CARD_STAT_DESC));
						oMap.put("KREDI_KART_BILGI", list_count, "ILK_TANIMLAMA_TARIHI", sdf.parse(cardMap.getString(CARD_DETAIL_INFO, i, EMBOSS_DATE)));
						oMap.put("KREDI_KART_BILGI", list_count, "LIMIT", cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CARD_LIMIT));
						oMap.put("KREDI_KART_BILGI", list_count, "LIMIT_KULLANIM_ORANI", cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CARD_LIMIT).subtract(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CARD_AVAIL_LIMIT)).divide(cardMap.getBigDecimal(CARD_DETAIL_INFO, i, CARD_LIMIT), 4, RoundingMode.HALF_UP));
						oMap.put("KREDI_KART_BILGI", list_count, "DOVIZ_KODU", debtInfoMap.getString(DEBT_INFO_LIST, j, CURRENCY));

						nbsmMap.clear();
						nbsmMap.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
						nbsmMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_NBSM_INFO", nbsmMap));
						if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(nbsmMap.getString(RETURN_CODE))) {
							for (int k = 0; k < nbsmMap.getSize("LIST"); k++) {
								if (cardMap.getString(CARD_DETAIL_INFO, i, CARD_NO).equals(nbsmMap.getString("LIST", k, "CARD_NO"))) {
									oMap.put("KREDI_KART_BILGI", list_count, "GUNCEL_GECIKME_GUN_SAYISI", nbsmMap.getBigDecimal("LIST", k, "APP_CC_OPEN_PYMNT_DELAY_D"));
								}
							}
						}

						// TODO SS gelistirmeyi yapinca beslenecek
						oMap.put("KREDI_KART_BILGI", list_count, "EKSTRE_GECIKME_SAYISI", BigDecimal.ZERO);
						oMap.put("KREDI_KART_BILGI", list_count, "LIMIT_ASIMI_SAYISI", BigDecimal.ZERO);

						list_count++;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_KK_IS_JEST_CUSTOMER")
	public static GMMap getCustomerInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "CUSTOMER_INFO_LIST";
		oMap.put("IS_JEST_CUSTOMER", false);
		try {
			oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_INFO", iMap));
			for (int i = 0; i < oMap.getSize(tableName); i++) {
				if ("J".equals(oMap.getString(tableName, i, "CUSTOMER_GROUP"))) {
					oMap.put("IS_JEST_CUSTOMER", true);
					return oMap;
				}
			}
			oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CUSTOMER_INFO", iMap));
			for (int i = 0; i < oMap.getSize(tableName); i++) {
				if ("J".equals(oMap.getString(tableName, i, "CUSTOMER_GROUP"))) {
					oMap.put("IS_JEST_CUSTOMER", true);
					return oMap;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static String maskCardNumber12(String cardNumber) {
		if (StringUtils.isNotBlank(cardNumber))
			return cardNumber.replaceAll("(\\w{1,12})(\\w{1,4})", "**** **** **** $2");
		else
			return cardNumber;
	}

	/**
	 * Islemleri tamamlanan kartin kullanimini aktiflestirir. Kullanima acar.
	 * 
	 * @param iMap
	 *            - CARD_NO
	 * @return
	 */
	@GraymoundService("BNSPR_CARD_ACTIVATION_WRAPPER")
	public static GMMap cardActivation(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CARD_ACTIVATION", iMap));
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", "");
		}
		catch (Exception e) {
			oMap.put("RESPONSE", "2");
			oMap.put("RESPONSE_DATA", e.getMessage());
			e.printStackTrace();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_NONDEBIT_OCEANS")
	public static GMMap getCardListNonDebitOceans(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean isDebit = false;
		GMMap cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
		for (int i = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {
			isDebit = "Debit".equals(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
			// if (!isDebit)
			// oMap.put("CARD_DETAIL_INFO" , oMap.getSize("CARD_DETAIL_INFO") , cardMap.getMap("CARD_DETAIL_INFO" , i));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_GET_CARD_APPLICATION_ADDRESS")
	public static GMMap getCardApplicationAddress(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder stb;

		Session session = DAOSession.getSession("BNSPRDal");

		TffBasvuru basvuruRecord = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		if (basvuruRecord == null) {
			basvuruRecord = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		}

		if (basvuruRecord != null) {

			TffBasvuruAdres record = (TffBasvuruAdres) session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", basvuruRecord.getBasvuruNo())).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();
			if (record != null) {
				stb = new StringBuilder();
				stb.append(record.getAcikAdres());
				stb.append(" ");
				stb.append(StringUtils.isNotBlank(record.getMahalleAd()) ? record.getMahalleAd() : "");
				stb.append(" ");
				stb.append(record.getIlceAd());
				stb.append(" ");
				stb.append(record.getIlAd());
				oMap.put("TEBLIGAT_ADRESI", stb.toString());
				oMap.put("TEBLIGAT_ADRES_TIP", record.getId().getAdresKod());

			}
		}
		else {

			KkBasvuru kkBasvuruRecord = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (kkBasvuruRecord != null) {

				KkBasvuruAdres kkRecord = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", kkBasvuruRecord.getBasvuruNo())).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();
				if (kkRecord != null) {
					stb = new StringBuilder();
					stb.append(kkRecord.getAdres());
					stb.append(" ");
					stb.append(LovHelper.diLov(kkRecord.getIlceKod(), kkRecord.getIlKod(), "10011/LOV_ADRES_ILCE", "ILCE_ADI"));
					stb.append(" ");
					stb.append(LovHelper.diLov(kkRecord.getIlKod(), "10011/LOV_ADRES_IL", "IL_ADI"));
					oMap.put("TEBLIGAT_ADRESI", stb.toString());
					oMap.put("TEBLIGAT_ADRES_TIP", kkRecord.getId().getAdresKod());

				}
				else {
					oMap.put("TEBLIGAT_ADRESI", "");
				}
			}
			else {
				oMap.put("TEBLIGAT_ADRESI", "");
			}
		}
		return oMap;
	}

	@GraymoundService("BNSPR_GET_CARD_INFO_FOR_GREEN4CARDLIST")
	public static GMMap getCardInfoForGreen4KardList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap cardMap = GMServiceExecuter.call("BNSPR_GET_CARD_INFO_CC", iMap); // BNSPR_INTRACARD_GET_CARDS_VIA_TCKN
		try {
			boolean isYIMKart;
			boolean isSanalPPKart;
			boolean isUptKart = false;
			boolean isTroyKart = false;
			boolean isHceKart = false;
			boolean isHceKart_2 = false;
			boolean mChipCard = false;
			boolean isKahramanKart = false;
			String productId = "";

			for (int i = 0, k = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {

				productId = !StringUtils.isEmpty(cardMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)) ? cardMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID) : "";

				isYIMKart = KkProductsUtil.isYimPpProduct(productId);// "910".equals(cardMap.getString(CARD_DETAIL_INFO , i , PRODUCT_ID));
				isSanalPPKart = KkProductsUtil.isVirtualProduct(productId);// "914".equals(cardMap.getString(CARD_DETAIL_INFO , i , PRODUCT_ID));
				isUptKart = KkProductsUtil.isUptPpProduct(productId);// "912".equals(cardMap.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID));
				isTroyKart = KkProductsUtil.isTroyDebitProduct(productId);// "916".equals(cardMap.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID));
				isHceKart = KkProductsUtil.isHceProduct(productId, "ONLINE");// "920".equals(cardMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart_2 = KkProductsUtil.isHceProduct(productId, "OFFLINE", "ANKARA"); // "921".equals(cardMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isKahramanKart = KkProductsUtil.isHceProduct(productId, "OFFLINE", "MARAS"); // "922".equals(cardMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				mChipCard = KkProductsUtil.isMchipProduct(productId);// CreditCardQRY4410Services.mchipFilter(cardMap, i, 0,"CARD_DETAIL_INFO", PRODUCT_ID);
				if (!isYIMKart && !isSanalPPKart && !isUptKart && !isTroyKart && !isHceKart && !isHceKart_2 && !mChipCard && !isKahramanKart) {
					oMap.put("CARD_DETAIL_INFO", k, cardMap.getMap("CARD_DETAIL_INFO", i));
					k++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static String maskCardNumberFirst6Last4(String cardNumber) {
		if (StringUtils.isNotBlank(cardNumber))
			return cardNumber.replaceAll("(\\w{1,6})(\\w{1,6})(\\w{1,4})", "$1 ** **** $3");
		else
			return cardNumber;
	}

}