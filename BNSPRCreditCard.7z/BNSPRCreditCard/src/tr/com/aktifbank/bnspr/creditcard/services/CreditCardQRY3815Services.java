package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * TFF Basvuru Odeme Izleme Ekrani Servisleri
 * 
 * @author ayse.erdogan
 * @since 13.10.2014
 */
public class CreditCardQRY3815Services {

	/**
	 * Girilen kriterlere gore istenen tff basvurularinin odemelerini listeler.
	 * 
	 * @author ayse.erdogan
	 * @since 13.10.2014
	 * @param iMap
	 *            - Sorgu Kriterleri<br>
	 *            <li>BASVURU_NO <li>ISLEM_NO <li>ODEME_REFERANSI <li>BASLANGIC_TAR <li>BITIS_TAR <li>KANAL
	 * @return oMap - Odeme Listesi<br>
	 *         <li>ODEME_BILGILERI
	 */
	@GraymoundService("BNSPR_QRY3815_TFF_ODEME_LIST")
	public static GMMap getBasvuruOdemeList(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3815.Rc_Qry3815_List_Odeme(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("ODEME_REFERANSI"));

			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}

			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}

			stmt.setString(i++, iMap.getString("SOURCE"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("PASAPORT_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResultsPutStr(rSet, "ODEME_BILGILERI"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Basvuru Odeme izleme ekrani acilisinda kullanilan degerleri doner.
	 * 
	 * @author ayse.erdogan
	 * @since 13.10.2014
	 * @param iMap
	 *            - Input Yok<br>
	 * @return oMap - Ekran acilis degerleri<br>
	 *         <li>SOURCE_LIST - Tff basvuru yeri listesi <li>BASLANGIC_TARIHI - Arama yapilacak default baslangic tarihi <li>BITIS_TARIHI - Arama
	 *         yapilacak default bitis tarihi
	 */
	@GraymoundService("BNSPR_QRY3815_FILL_INITIAL_VALUES")
	public static GMMap fillInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Source Listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3815_TFF_SOURCE_LIST", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3815_BAS_BIT_TARIHI", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Tff basvurusu yapilabilen yerleri listeler.
	 * 
	 * @author ayse.erdogan
	 * @since 13.10.2014
	 * @param iMap
	 *            - Input Yok<br>
	 * @return oMap - Source Listesi<br>
	 *         <li>SOURCE_LIST - Tff basvurusu yapilabilen yerler
	 */
	@GraymoundService("BNSPR_QRY3815_TFF_SOURCE_LIST")
	public static GMMap getSourceList(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "SOURCE_LIST");
		iMap.put("LIST_QUERY", "select key1 kod, text aciklama from v_ml_gnl_param_text t where t.kod = 'TFF_WEBSERVIS_PARAM' and t.key2='KANAL_KOD' order by 2");
		return DALUtil.fillComboBox(iMap);
	}

	/**
	 * Java sistem tarihini ve bir ay sonrasini baslangic ve bitis tarihleri olarak doner.
	 * 
	 * @author ayse.erdogan
	 * @since 13.10.2014
	 * @param iMap
	 *            - Input Yok<br>
	 * @return oMap - Baslangic ve bitis tarihleri<br>
	 *         <li>Baslangic ve bitis tarihleri
	 */
	@GraymoundService("BNSPR_QRY3815_BAS_BIT_TARIHI")
	public static GMMap getStartFinishDates(GMMap iMap) {

		Date toDay;
		Date minusOneMonth;
		GMMap oMap = new GMMap();
		try {
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			toDay = c.getTime();
			c.add(Calendar.MONTH, -1);
			minusOneMonth = c.getTime();
			oMap.put("BASLANGIC_TARIHI", minusOneMonth);
			oMap.put("BITIS_TARIHI", toDay);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
