package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.CrdKartNakitAvansTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4406Services implements OceanMapKeys {
	
	@GraymoundService("BNSPR_CREDIT_CARD_CASH_ADVANCE_FOR_REMOTE_CALL")
	public static Map<?, ?> CreditCardCashAdvanceforRemoteCall(GMMap iMap){
		try {
			
			return GMServiceExecuter.executeNT("BNSPR_CREDIT_CARD_CASH_ADVANCE", iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_CREDIT_CARD_CASH_ADVANCE")
	public static GMMap CreditCardCashAdvance(GMMap iMap) {
        GMMap oMap = new GMMap(); 
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			CrdKartNakitAvansTx crdKartNakitAvans = new CrdKartNakitAvansTx();
			crdKartNakitAvans.setAciklama(iMap.getString("ACIKLAMA"));
			crdKartNakitAvans.setAliciAdiSoyadi(iMap.getString("ALICI_ADI_SOYADI"));
			crdKartNakitAvans.setAliciHesapNo(iMap.getBigDecimal("ALICI_HESAP_NO"));
			crdKartNakitAvans.setAliciMusteriNo(iMap.getBigDecimal("ALICI_MUSTERI_NO"));
			crdKartNakitAvans.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
			crdKartNakitAvans.setCvv2(iMap.getBigDecimal("CVV2"));
			crdKartNakitAvans.setCvv2Exists(iMap.getString("CVV2_EXISTS"));
			crdKartNakitAvans.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			crdKartNakitAvans.setGonderenAdiSoyadi(iMap.getString("GONDEREN_ADI_SOYADI"));
			crdKartNakitAvans.setGonderenMusteriNo(iMap.getBigDecimal("GONDEREN_MUSTERI_NO"));
			crdKartNakitAvans.setHesapDovizKodu(iMap.getString("HESAP_DOVIZ_KODU"));
			crdKartNakitAvans.setKartDurumu(iMap.getString("KART_DURUMU"));
			crdKartNakitAvans.setKartNo(iMap.getString("KART_NO"));
			crdKartNakitAvans.setKaynak(iMap.getString("KAYNAK"));
			crdKartNakitAvans.setKullanabilirNaLimit(iMap.getBigDecimal("KULL_NA_LIMIT"));
			crdKartNakitAvans.setSonKullanmaTarihi(iMap.getBigDecimal("SON_KULL_TARIHI"));
			crdKartNakitAvans.setTutar(iMap.getBigDecimal("TUTAR"));
			if (iMap.getBigDecimal("TRX_NO") == null) {
				GMMap oMapN = new GMMap();
				oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
				BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
				
				crdKartNakitAvans.setTxNo(trxNo);
				iMap.put("TRX_NO", trxNo);
			}
			else
				crdKartNakitAvans.setTxNo(iMap.getBigDecimal("TRX_NO"));

			session.saveOrUpdate(crdKartNakitAvans);

			session.flush();
			iMap.put("TRX_NAME", "4406");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			oMap.put("TX_NO", iMap.getString("TRX_NO"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN4406_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap(); 
		try {
	            
	            Session session = DAOSession.getSession("BNSPRDal");
	   
	            CrdKartNakitAvansTx crdKartNakitAvansTx = (CrdKartNakitAvansTx) session.get(CrdKartNakitAvansTx.class, iMap.getBigDecimal("TRX_NO"));
	            
	            oMap.put("ACIKLAMA", crdKartNakitAvansTx.getAciklama());
	            oMap.put("ALICI_ADI_SOYADI", crdKartNakitAvansTx.getAliciAdiSoyadi());
	            oMap.put("ALICI_HESAP_NO", crdKartNakitAvansTx.getAliciHesapNo());
	            oMap.put("ALICI_MUSTERI_NO", crdKartNakitAvansTx.getAliciMusteriNo());
	            oMap.put("ASIL_KART_NO", crdKartNakitAvansTx.getAsilKartNo());
	            oMap.put("CVV2", "***");
	            oMap.put("DOVIZ_KODU", crdKartNakitAvansTx.getDovizKodu());
	            oMap.put("GONDEREN_ADI_SOYADI", crdKartNakitAvansTx.getGonderenAdiSoyadi());
	            oMap.put("GONDEREN_MUSTERI_NO", crdKartNakitAvansTx.getGonderenMusteriNo());
	            oMap.put("HESAP_DOVIZ_KODU", crdKartNakitAvansTx.getHesapDovizKodu());
	            oMap.put("KART_DURUMU", crdKartNakitAvansTx.getKartDurumu());
	            oMap.put("KART_NO", crdKartNakitAvansTx.getKartNo());
	            oMap.put("KAYNAK", crdKartNakitAvansTx.getKaynak());
	            oMap.put("KULL_NA_LIMIT", crdKartNakitAvansTx.getKullanabilirNaLimit());
	            oMap.put("SON_KULL_TARIHI", crdKartNakitAvansTx.getSonKullanmaTarihi());
	            oMap.put("TUTAR", crdKartNakitAvansTx.getTutar());
	            
	            oMap.put("TRX_NO", crdKartNakitAvansTx.getTxNo());
	            
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	}
	@GraymoundService("BNSPR_TRN4406_AFTER_APPROVAL")
	public static GMMap after_Approval(GMMap iMap) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		GMMap iMapx = new GMMap();
		GMMap oMapx = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			conn = DALUtil.getGMConnection();
			ps = conn.prepareStatement("SELECT * FROM CRD_KART_NAKIT_AVANS_TX where tx_no=?");
			ps.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			rs = ps.executeQuery();

			while (rs.next()) {
				GMMap iMapA = new GMMap();
				GMMap oMapH = new GMMap();
				oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMapA);
				
				iMapx.put(CARD_NO, rs.getObject("KART_NO"));
				iMapx.put(ACCOUNT_BRANCH_ID, oMapH.getString("SUBE_KOD"));
				iMapx.put(RRN, "");
				iMapx.put(REQUEST_TYPE, OceanConstants.Request_Normal);
				GMMap oMapK = new GMMap();
				oMapK = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMapA);
				String channelCode;
				if (oMapK.getString("KANAL_KOD").equals("4") || oMapK.getString("KANAL_KOD").equals("10"))
					channelCode = OceanConstants.Channel_INT;
				else if (oMapK.getString("KANAL_KOD").equals("5"))
					channelCode = OceanConstants.Channel_IVR;
				else if (oMapK.getString("KANAL_KOD").equals("15"))
				    channelCode = OceanConstants.Channel_Evam;
				else
					channelCode = OceanConstants.Channel_Branch;
				iMapx.put(CHANNEL, channelCode);
				iMapx.put(TERMINAL_ID,"9999999");
				iMapx.put(TERMINAL_TYPE, "Crt");
				iMapx.put(CVV2_EXISTS, rs.getObject("CVV2_EXISTS"));
				
				iMapx.put(TXN_DESC, rs.getObject("ACIKLAMA")==null?"Nakit Avans":rs.getObject("ACIKLAMA"));
				iMapx.put(TXN_AMOUNT, rs.getObject("TUTAR"));
				iMapx.put(CVV2, rs.getObject("CVV2"));
				iMapx.put(CARD_EXPIRE_DATE, rs.getObject("SON_KULLANMA_TARIHI"));
				iMapx.put(TXN_CURR, rs.getString("DOVIZ_KODU"));
				
			
			}
			oMapx = GMServiceExecuter.call("BNSPR_GENERAL_POST_CASH_ADVANCE", iMapx);
			if (oMapx.getInt(RETURN_CODE) == 2) {
				CrdKartNakitAvansTx crdKartNakitAvansTx = new CrdKartNakitAvansTx();
				crdKartNakitAvansTx = (CrdKartNakitAvansTx) session.get(CrdKartNakitAvansTx.class, iMap.getBigDecimal("ISLEM_NO"));
				crdKartNakitAvansTx.setRrn(oMapx.getString(RRN));
				crdKartNakitAvansTx.setAurthorizationCode(oMapx.getString(AUTHORIZATION_CODE));
				session.saveOrUpdate(crdKartNakitAvansTx);
				session.flush();
				return oMapx;
			}
			else {
				
				throw new GMRuntimeException(0, getParamText(oMapx.getString("IRC_CODE"), "IRC_CODE_EXPLANATIONS"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			GMServerDatasource.close(conn);

		}
	}
	
	

    @GraymoundService("BNSPR_CREDIT_CARD_CASH_ADVANCE_FOR_EVAM")
    public static GMMap CreditCardCashAdvanceForEvam(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            GMMap cardMap = new GMMap();
            cardMap = GMServiceExecuter.call("BNSPR_GET_CC_CARD_INFO_WITH_CARD_NO" , iMap);
            
            
            
            if (iMap.getBigDecimal("TRX_NO") == null) {
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
            
                iMap.put("TRX_NO", trxNo);
            }
            oMap.put("ACIKLAMA" , "Evam - Kart No : "+iMap.getString("CARD_NO")+" TRX NO : "+iMap.getString("TRX_NO"));
           
            iMap.put("ALICI_HESAP_NO",DALUtil.callOneParameterFunction("{? = call PKG_TRN4438.get_hesap_no(?)}", Types.NUMERIC, iMap.getBigDecimal("MUSTERI_NO")));
            iMap.put("ALICI_MUSTERI_NO" , iMap.getBigDecimal("MUSTERI_NO"));
            iMap.put("ASIL_KART_NO" , cardMap.getString("MAIN_CARD_NO"));
            iMap.put("CVV2" , new BigDecimal(123));
            iMap.put("CVV2_EXISTS" , "N");
            iMap.put("DOVIZ_KODU" , "TRY");
            iMap.put("HESAP_DOVIZ_KODU" , "TRY");
            iMap.put("KART_DURUMU" ,cardMap.getString("STATUS"));
            iMap.put("KAYNAK" ,"HESABA");       
            iMap.put("SON_KULL_TARIHI" , new BigDecimal(iMap.getInt("SON_KULL_TARIHI")));
            iMap.put("KART_NO" , iMap.getString(CARD_NO));
           
            
            oMap = GMServiceExecuter.call("BNSPR_CREDIT_CARD_CASH_ADVANCE" , iMap);
            oMap.put("HESAP_NO" , iMap.getString("ALICI_HESAP_NO"));
           
       
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    private static boolean isNotExistAndNull(GMMap iMap, String key) {
        // TODO Auto-generated method stub
        if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0){
            return true;
        } else{
            return false;
        }
    }

    public static String getParamText(String key, String kod){
		GMMap pMap = new GMMap();
		pMap.put("KOD", kod);
		pMap.put("KEY", key);
		String text="";
		try {
			pMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", pMap);
			text = pMap.getString("TEXT");
		}
		catch (Exception e) {
			text="Teknik bir Hata Olu�tu!";
		}
		
		return text;
		
	}
}