package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.axis.utils.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import org.apache.axis.utils.StringUtils;

public class CreditCardQRY3893Services {
	
	private static final Logger logger = LoggerFactory.getLogger(CreditCardQRY3893Services.class);
	private static String SERVICE_DATE_FORMAT	=	"yyyyMMdd";
	private static String Return_Error_Code	=	"1";
	private static String Return_Success_Code	=	"2";
	private static String SorguTipi_Hata_Aciklama	=	"Sorgu Tipi Parametresi Zorunludur";
	private static String Musteri_Numarasi_Hata_Aciklama	=	"Musteri Numarasi Parametresi Zorunludur";
	private static String Kimlik_Numarasi_Hata_Aciklama	=	"Kimlik Numarasi Parametresi Zorunludur";
	private static String Musteri_Adi_Hata_Aciklama	=	"Musteri Adi Parametresi Zorunludur";
	private static String Musteri_Soyadi_Hata_Aciklama	=	"Musteri Soyadi Parametresi Zorunludur";
	private static String Sube_Hata_Aciklama	=	"Sube Parametresi Zorunludur";
	private static String Tahsis_Tarih_Hata_Aciklama	=	"Tahsis Tarihi Parametresi Zorunludur";

	@GraymoundService("BNSPR_QRY3893_LKS_SORGULA")
	public static GMMap initiazlize(GMMap iMap) {
		try {
			
			GMMap oMap = new GMMap();
			
			
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
	}
	
	@GraymoundService("BNSPR_QRY3893_LKS_MANUEL_TAHSIS_YAP")
	public static GMMap lksManuelTahsisYap(GMMap iMap)
	{
		try {
			
			GMMap oMap = new GMMap();
			String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'03') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
			if ( oMap.isEmpty()){
				throw new Exception("Kayit Bulunamadi");
			}
			
			//LKS sorgusu yap
			GMMap lMap = new GMMap();
			oMap.put("MANUEL_SORGU", iMap.getString("MANUEL_SORGU"));
			lMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_ONLINE_TAHSIS_YAP", oMap));
			
			if ( "2".equals(oMap.getString("RESPONSE")) ){
				GMMap tMap = new GMMap();
				tMap.put("SORGU_TIPI",iMap.getString("SORGU_TIPI"));
				if(iMap.getString("BASVURU_NO").isEmpty())
					tMap.put("SORGU_NO",oMap.getString("SORGU_NO"));
				else
					tMap.put("BASVURU_NO",iMap.getString("BASVURU_NO"));
				
				oMap = GMServiceExecuter.call("BNSPR_QRY3893_LKS_GECMIS_SORGULA", tMap);
			}
			return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
	}
	
	@GraymoundService("BNSPR_QRY3893_LKS_MANUEL_EK_TAHSIS_YAP")
	public static GMMap lksManuelEkTahsisYap(GMMap iMap)
	{
		try {
			
			GMMap oMap = new GMMap();
			String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'04') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
			if ( oMap.isEmpty()){
				throw new Exception("Kayit Bulunamadi");
			}
			
			//LKS sorgusu yap
			GMMap lMap = new GMMap();
			oMap.put("MANUEL_SORGU", iMap.getString("MANUEL_SORGU"));
			lMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_ONLINE_EK_TAHSIS_YAP", oMap));
			
			if ( "2".equals(oMap.getString("RESPONSE")) ){
				GMMap tMap = new GMMap();
				tMap.put("SORGU_TIPI",iMap.getString("SORGU_TIPI"));
				if(iMap.getString("BASVURU_NO").isEmpty())
					tMap.put("SORGU_NO",oMap.getString("SORGU_NO"));
				else
					tMap.put("BASVURU_NO",iMap.getString("BASVURU_NO"));
				
				oMap = GMServiceExecuter.call("BNSPR_QRY3893_LKS_GECMIS_SORGULA", tMap);
			}
			return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
	}
	

	@GraymoundService("BNSPR_QRY3893_LKS_YKN_MANUEL_TAHSIS_SORGU_YAP")
	public static GMMap lksYabanciMusteriManuelTahsisSorguYap(GMMap iMap)
	{
		GMMap oMap = new GMMap();
		
		try{
			
			/*Variable*/
			String sorguTipi = iMap.getString("SORGU_TIPI"); 
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			String kimlikNo = iMap.getString("TCKN");
			String ilkAdi = iMap.getString("ILK_ADI");
			String ikinciAdi = iMap.getString("IKINCI_ADI");
			String soyadi = iMap.getString("SOYADI");
			String dogumTarihi = iMap.getString("DOGUM_TARIHI");
			String babaAdi = iMap.getString("BABA_ADI");
			String tahsisTarihi = iMap.getString("TAHSIS_TARIHI"); 
			String guncelLimit = iMap.getString("GUNCEL_LIMIT"); 
			String sube = iMap.getString("SUBE");
			String manuelSorgu = iMap.getString("MANUEL_SORGU");
			String tarih = new SimpleDateFormat(SERVICE_DATE_FORMAT).format(new Date()); 
			String kullanici = BnsprOceanCommonFunctions.getUser();
			
			/*Control & Set2MAP*/
			if(sorguTipi == null || StringUtils.isEmpty(sorguTipi)){
				oMap.put("RETURN_CODE", Return_Error_Code);
				oMap.put("RETURN_DESCRIPTION", SorguTipi_Hata_Aciklama);
			}else if(BigDecimal.ZERO.equals(musteriNo)){
				oMap.put("RETURN_CODE", Return_Error_Code);
				oMap.put("RETURN_DESCRIPTION", Musteri_Numarasi_Hata_Aciklama);
			}else if(kimlikNo == null || StringUtils.isEmpty(kimlikNo)){
				oMap.put("RETURN_CODE", Return_Error_Code);
				oMap.put("RETURN_DESCRIPTION", Kimlik_Numarasi_Hata_Aciklama);
			}else if(ilkAdi == null || StringUtils.isEmpty(ilkAdi)){
				oMap.put("RETURN_CODE", Return_Error_Code);
				oMap.put("RETURN_DESCRIPTION", Musteri_Adi_Hata_Aciklama);
			}else if(soyadi == null || StringUtils.isEmpty(soyadi)){
				oMap.put("RETURN_CODE", Return_Error_Code);
				oMap.put("RETURN_DESCRIPTION", Musteri_Soyadi_Hata_Aciklama);
			}else if(sube == null || StringUtils.isEmpty(sube)){
				oMap.put("RETURN_CODE", Return_Error_Code);
				oMap.put("RETURN_DESCRIPTION", Sube_Hata_Aciklama);
			}else{
				// LKS
				if(kimlikNo.length() != 11){
					iMap.put("VKN", kimlikNo);
					iMap.remove("TCKN");
				}
				if(ikinciAdi == null) iMap.put("IKINCI_ADI", "");
				if(dogumTarihi == null || StringUtils.isEmpty(dogumTarihi)) iMap.remove("DOGUM_TARIHI");
				if(babaAdi == null) iMap.put("BABA_ADI", "");
				if(manuelSorgu == null) iMap.put("MANUEL_SORGU", "E");
				if(guncelLimit == null || StringUtils.isEmpty(guncelLimit)) iMap.remove("GUNCEL_LIMIT");
				if(tahsisTarihi == null || StringUtils.isEmpty(tahsisTarihi)) iMap.remove("TAHSIS_TARIHI");
				
				iMap.put("TARIH", tarih);
				iMap.put("KULLANICI_KODU", kullanici);
				
				// Send to LKS
				logger.info("BNSPR_QRY3893_LKS_YKN_MANUEL_TAHSIS_SORGU_YAP request: " + iMap.toString());
				GMMap rMap = GMServiceExecuter.call("LKS_SORGUSU_YAP",iMap);
				if ( "2".equals(rMap.getString("RESPONSE")) ){
					oMap.put("RETURN_CODE", Return_Success_Code);
					oMap.put("RETURN_DESCRIPTION","SorguNo: " + rMap.getString("SORGU_NO"));
				} else{
					oMap.put("RETURN_CODE", rMap.getString("RESPONSE"));
					oMap.put("RETURN_DESCRIPTION", rMap.getString("RESPONSE_MESSAGE"));
				}
			}
			return oMap;
		}catch(Exception e){
			oMap.put("RETURN_CODE", Return_Error_Code);
			oMap.put("RETURN_DESCRIPTION", "Serviste hata meydana geldi. Hata: " + e.getMessage());
			logger.error("BNSPR_QRY3893_LKS_YKN_MANUEL_TAHSIS_SORGU_YAP Hata: ", e);
			return oMap;
		}
	}
	
	@GraymoundService("BNSPR_QRY3893_LKS_MANUEL_TAHSIS_SORGU_YAP")
	public static GMMap lksManuelTahsisSorguYap(GMMap iMap)
	{
		try {
			GMMap oMap = new GMMap();

			oMap = GMServiceExecuter.call("LKS_SORGUSU_YAP",iMap);
			if ( "2".equals(oMap.getString("RESPONSE")) ){
				GMMap tMap = new GMMap();
				tMap.put("SORGU_TIPI",iMap.getString("SORGU_TIPI"));
				if(iMap.getString("BASVURU_NO").isEmpty())
					tMap.put("SORGU_NO",oMap.getString("SORGU_NO"));
				else
					tMap.put("BASVURU_NO",iMap.getString("BASVURU_NO"));
				oMap = GMServiceExecuter.call("BNSPR_QRY3893_LKS_GECMIS_SORGULA", tMap);
			}
			return oMap;
        } catch (Exception e){	
            throw ExceptionHandler.convertException(e);
        }
	}

	@GraymoundService("BNSPR_QRY3893_LKS_GECMIS_SORGULA")
	public static GMMap lksGecmisSorgula(GMMap iMap) {
		try {
			
			GMMap oMap = new GMMap();

			String func = "{? = call BNSPR.PKG_LKS_ISLEM.lks_sorgu_tarihce(?,?,?,?,?,?) }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "SORGU_LISTE", 	BnsprType.STRING, iMap.getString("SORGU_TIPI"),
																					BnsprType.NUMBER, iMap.getBigDecimal("SORGU_NO"),
																					BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),
																					BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
																					BnsprType.STRING, iMap.getString("ILK_TARIH"),
																					BnsprType.STRING, iMap.getString("SON_TARIH"));

			return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
	}
}
