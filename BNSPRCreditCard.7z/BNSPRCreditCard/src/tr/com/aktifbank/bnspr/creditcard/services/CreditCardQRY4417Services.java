package tr.com.aktifbank.bnspr.creditcard.services;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY4417Services implements OceanMapKeys {
    
    private static final Logger logger = Logger.getLogger(CreditCardQRY4417Services.class);
    
    @GraymoundService("BNSPR_QRY4417_GET_CARD_LIMIT_INFO")
    public static GMMap getCardLimit(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            
            oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_LIMIT_INFO" , iMap));
            int i = 0;
            oMap.put(BANKING_CUSTOMER_NO , oMap.get(LIMIT_INFO , i , BANKING_CUSTOMER_NO));
            oMap.put(CARD_NO , oMap.get(LIMIT_INFO , i , CARD_NO));
            oMap.put(CARD_CASH_LIMIT , oMap.get(LIMIT_INFO , i , CARD_CASH_LIMIT));
            oMap.put(CARD_CASH_LIMIT_AVAILABLE , oMap.get(LIMIT_INFO , i , CARD_CASH_LIMIT_AVAILABLE));
            oMap.put(CARD_CASH_LIMIT_USED_FC , oMap.get(LIMIT_INFO , i , CARD_CASH_LIMIT_USED_FC));
            oMap.put(CARD_CASH_LIMIT_USED_LC , oMap.get(LIMIT_INFO , i , CARD_CASH_LIMIT_USED_LC));
            oMap.put(CARD_LIMIT , oMap.get(LIMIT_INFO , i , CARD_LIMIT));
            oMap.put(CARD_LIMIT_AVAILABLE , oMap.get(LIMIT_INFO , i , CARD_LIMIT_AVAILABLE));
            oMap.put(CARD_LIMIT_USED_FC , oMap.get(LIMIT_INFO , i , CARD_LIMIT_USED_FC));
            oMap.put(CARD_LIMIT_USED_LC , oMap.get(LIMIT_INFO , i , CARD_LIMIT_USED_LC));
            oMap.put(CARD_OVER_LIMIT , oMap.get(LIMIT_INFO , i , CARD_OVER_LIMIT));
            oMap.put(CARD_OVER_LIMIT_AVAILABLE , oMap.get(LIMIT_INFO , i , CARD_OVER_LIMIT_AVAILABLE));
            oMap.put(CUSTOMER_CASH_LIMIT_AVAILABLE , oMap.get(LIMIT_INFO , i , CUSTOMER_CASH_LIMIT_AVAILABLE));
            oMap.put(CUSTOMER_CASH_LIMIT_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_CASH_LIMIT_LC));
            oMap.put(CUSTOMER_CASH_LIMIT_USED_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_CASH_LIMIT_USED_FC));
            oMap.put(CUSTOMER_CASH_LIMIT_USED_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_CASH_LIMIT_USED_LC));
            oMap.put(CUSTOMER_DAILY_ATM_CASH_LIMIT_AVAIL_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_ATM_CASH_LIMIT_AVAIL_FC));
            oMap.put(CUSTOMER_DAILY_ATM_CASH_LIMIT_AVAIL_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_ATM_CASH_LIMIT_AVAIL_LC));
            oMap.put(CUSTOMER_DAILY_ATM_CASH_LIMIT_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_ATM_CASH_LIMIT_FC));
            oMap.put(CUSTOMER_DAILY_ATM_CASH_LIMIT_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_ATM_CASH_LIMIT_LC));
            oMap.put(CUSTOMER_DAILY_ATM_CASH_LIMIT_USED_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_ATM_CASH_LIMIT_USED_FC));
            oMap.put(CUSTOMER_DAILY_ATM_CASH_LIMIT_USED_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_ATM_CASH_LIMIT_USED_LC));
            oMap.put(CUSTOMER_DAILY_CASH_LIMIT_AVAIL_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_CASH_LIMIT_AVAIL_FC));
            oMap.put(CUSTOMER_DAILY_CASH_LIMIT_AVAIL_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_CASH_LIMIT_AVAIL_LC));
            oMap.put(CUSTOMER_DAILY_CASH_LIMIT_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_CASH_LIMIT_FC));
            oMap.put(CUSTOMER_DAILY_CASH_LIMIT_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_CASH_LIMIT_LC));
            oMap.put(CUSTOMER_DAILY_CASH_LIMIT_USED_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_CASH_LIMIT_USED_FC));
            oMap.put(CUSTOMER_DAILY_CASH_LIMIT_USED_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_DAILY_CASH_LIMIT_USED_LC));
            oMap.put(CUSTOMER_LIMIT_AVAILABLE , oMap.get(LIMIT_INFO , i , CUSTOMER_LIMIT_AVAILABLE));
            oMap.put(CUSTOMER_LIMIT_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_LIMIT_LC));
            oMap.put(CUSTOMER_LIMIT_USED_FC , oMap.get(LIMIT_INFO , i , CUSTOMER_LIMIT_USED_FC));
            oMap.put(CUSTOMER_LIMIT_USED_LC , oMap.get(LIMIT_INFO , i , CUSTOMER_LIMIT_USED_LC));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY4417_GET_CARD_INFO")
    public static GMMap getCardList(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap iMap2 = new GMMap();
        iMap2.put(CUSTOMER_NO , iMap.getString("CUSTOMER_NO"));
        iMap2.put(CARD_NO , "");
        iMap2.put(CARD_DCI , "C");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        SimpleDateFormat sdf2 = new SimpleDateFormat("MM/yy");
        GMMap oMapH = new GMMap();
        oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , iMap);
        iMap2.put(CARD_BRANCH , oMapH.getString("SUBE_KOD"));
        boolean isDebit = false;
        boolean isUptKart = false;
        boolean isTroyKart = false;
        try{
            
            GMMap oMap2 = new GMMap();
            oMap2 = (GMMap) GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , iMap2);
            String productId ="";
            if (oMap2.getString(RETURN_CODE).equals("2"))            
            {
                for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++){
    				productId = !StringUtils.isEmpty(oMap2.getString("CARD_DETAIL_INFO", i, "CARD_DCI"))? oMap2.getString("CARD_DETAIL_INFO", i, "CARD_DCI") : "";

                    isDebit = "Debit".equals(oMap2.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
                    isUptKart = KkProductsUtil.isUptPpProduct(productId); //"912".equals(oMap2.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID"));
                    isTroyKart = KkProductsUtil.isTroyDebitProduct(productId); //"916".equals(oMap2.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID"));
                 		 if (!isDebit && !isUptKart && !isTroyKart){
                        oMap.put("TABLO" , i , "CARD_NO" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_NO));
                        oMap.put("TABLO" , i , "MASKED_CARD_NO" , maskCardNumber(oMap2.getString("CARD_DETAIL_INFO" , i , CARD_NO)));
                        oMap.put("TABLO" , i , "EMBOSS_NAME" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_EMBOSS_NAME_1));
                        oMap.put("TABLO" , i , "CARD_AVAIL_LIMIT" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_AVAIL_LIMIT));
                        oMap.put("TABLO" , i , "CARD_GROUP_DESC" , oMap2.getString("CARD_DETAIL_INFO" , i , "CARD_GROUP_DESC"));
                        if (StringUtils.isNotBlank(oMap2.getString("CARD_DETAIL_INFO" , i , EXPIRY_DATE))){
                            oMap.put("TABLO" , i , "EXPIRY_DATE" , sdf2.format(sdf.parse(oMap2.getString("CARD_DETAIL_INFO" , i , EXPIRY_DATE))));
                        }
                    }
                }
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    private static String maskCardNumber(String cardNumber) {
        return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})" , "$1 **** **** $3");
    }
}
