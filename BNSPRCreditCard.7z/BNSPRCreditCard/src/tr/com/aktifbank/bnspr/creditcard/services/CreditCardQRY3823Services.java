package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.math.NumberUtils;

import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.jcraft.jsch.Logger;

public class CreditCardQRY3823Services implements OceanMapKeys {
    @GraymoundService("BNSPR_3823_GET_TOPLU_BASVURU")
    public static GMMap getIslemList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSetOzet = null;
        ResultSet rSetDetay = null;
        String ozetTable = "TABLE_OZET";
        String detayTable = "TABLE_DETAY";
        int ozetRow = 0;
        int detayRow = 0;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC3823.get_islem_listesi(?,?,?)}");
            stmt.setBigDecimal(1 , iMap.getBigDecimal("TX_NO"));
            stmt.registerOutParameter(2 , -10);
            stmt.registerOutParameter(3 , -10);
            stmt.execute();
            rSetOzet = (ResultSet) stmt.getObject(2);
            rSetDetay = (ResultSet) stmt.getObject(3);
            while (rSetOzet.next()){
                
                oMap.put(ozetTable , ozetRow , "DURUM" , rSetOzet.getObject("DURUM"));
                oMap.put(ozetTable , ozetRow , "TOPLAM" , rSetOzet.getObject("TOPLAM"));
                ozetRow++;
                
            }
            if (ozetRow == 0){
                GMMap exMap = new GMMap();
                exMap.put("P1" , " kay�t gelmedi!");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
            
            while (rSetDetay.next()){
                
                ;
                oMap.put(detayTable , detayRow , "UYRUK" , rSetDetay.getObject("UYRUK"));
                oMap.put(detayTable , detayRow , "TCKN" , rSetDetay.getObject("TCKN"));
                oMap.put(detayTable , detayRow , "PASAPORT_NO" , rSetDetay.getObject("PASAPORT_NO"));
                oMap.put(detayTable , detayRow , "AD" , rSetDetay.getObject("AD"));
                oMap.put(detayTable , detayRow , "IKINCI_AD" , rSetDetay.getObject("IKINCI_AD"));
                oMap.put(detayTable , detayRow , "SOYAD" , rSetDetay.getObject("SOYAD"));
                oMap.put(detayTable , detayRow , "DOGUM_TARIHI" , rSetDetay.getObject("DOGUM_TARIHI"));
                oMap.put(detayTable , detayRow , "CEP_ULKE_KOD" , rSetDetay.getObject("CEP_ULKE_KOD"));
                oMap.put(detayTable , detayRow , "CEP_ALAN_KOD" , rSetDetay.getObject("CEP_ALAN_KOD"));
                oMap.put(detayTable , detayRow , "CEP_NO" , rSetDetay.getObject("CEP_NO"));
                oMap.put(detayTable , detayRow , "KART_TIPI" , rSetDetay.getObject("KART_TIPI"));
                oMap.put(detayTable , detayRow , "TAKIM" , rSetDetay.getObject("TAKIM"));
                oMap.put(detayTable , detayRow , "URUN_TIPI" , rSetDetay.getObject("URUN_TIPI"));
                oMap.put(detayTable , detayRow , "URUN_LOGO" , rSetDetay.getObject("URUN_LOGO"));
                oMap.put(detayTable , detayRow , "KURYE_TIPI" , rSetDetay.getObject("KURYE_TIPI"));
                oMap.put(detayTable , detayRow , "TESLIMAT_ADRES_TIPI" , rSetDetay.getObject("TESLIMAT_ADRES_TIPI"));
                oMap.put(detayTable , detayRow , "IL" , rSetDetay.getObject("IL"));
                oMap.put(detayTable , detayRow , "ILCE" , rSetDetay.getObject("ILCE"));
                oMap.put(detayTable , detayRow , "ACIK_ADRES" , rSetDetay.getObject("ACIK_ADRES"));
                oMap.put(detayTable , detayRow , "TESLIMAT_NOKTA_KODU" , rSetDetay.getObject("TESLIMAT_NOKTA_KODU"));
                oMap.put(detayTable , detayRow , "DURUM" , rSetDetay.getObject("DURUM"));
                oMap.put(detayTable , detayRow , "DURUM_ACIKLAMA" , rSetDetay.getObject("DURUM_ACIKLAMA"));
                oMap.put(detayTable , detayRow , "BASVURU_NO" , rSetDetay.getObject("BASVURU_NO"));
                detayRow++;
                
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSetOzet);
            GMServerDatasource.close(rSetDetay);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    @GraymoundService("BNSPR_TOPLU_BASVURU_DURDUR")
	public static GMMap stopBatchApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		if(txNo == null){
			oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","Islem yap�lacak liste seciniz");
			return oMap;
		}
		String func = "{? = call pkg_trn3803.Toplu_Basvuru_Durdur(?)}";
		try {
			BigDecimal res =  (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER,BnsprType.NUMBER,txNo);
			if(BigDecimal.ONE.compareTo(res) == 0){
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
				oMap.put("RESPONSE_DATA","Basarili");
			}else{
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA","Guncellenecek kayit yok");
			}
		} catch (SQLException e) {
			oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","Guncelleme yapilamadi");
			e.printStackTrace();
		}
		
		return oMap;
		
	}
    @GraymoundService("BNSPR_TOPLU_BASVURU_TEKRAR_CALISTIR")
   	public static GMMap rerunBatchApplication(GMMap iMap) {
    	GMMap oMap = new GMMap();
		BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		String func = "{? = call pkg_trn3803.Toplu_Basvuru_Tekrar_Calistir(?)}";
		if(txNo == null){
			oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","Islem yap�lacak liste seciniz");
			return oMap;
		}
		try {
			BigDecimal res =  (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER,BnsprType.NUMBER,txNo);
			if(BigDecimal.ONE.compareTo(res) == 0){
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
				oMap.put("RESPONSE_DATA","Basarili");
			}else{
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA","Guncellenecek kayit yok");
			}
		} catch (SQLException e) {
			oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","Guncelleme yapilamadi");
			e.printStackTrace();
		}
		
		return oMap;
   		
   	}
    
}
