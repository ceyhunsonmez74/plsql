package tr.com.aktifbank.bnspr.creditcard.services;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriAdres;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class CreditCardTRN4468Services {
    
    private static final String deliveryCode = "570";
    
    @GraymoundService("BNSPR_TRN4468_GET_CARDS")
    public static GMMap bnspr4468GetCards(GMMap iMap) {
        GMMap oMap = new GMMap();
        iMap.put("CARD_BRANCH" , GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , iMap).getString("SUBE_KOD"));
        try{
            GMMap cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN" , iMap);
            boolean isOcean = false;
            for (int i = 0, k = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++){
                isOcean = "O".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "SYSTEM"));
                if (isEligible(cardMap , i)){
                    iMap.put("CARD_NO" , cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_NO"));
                    oMap.put("CARD_DETAIL_INFO" , k , cardMap.getMap("CARD_DETAIL_INFO" , i));
                    
                    GMMap barcodeMap = isOcean ? GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_BARCODE_QRCODE" , iMap) : GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_BARCODE_QRCODE" , iMap);
                    oMap.put("CARD_DETAIL_INFO" , k , "COURIER_CODE" , barcodeMap.getString("COURIER_CODE"));
                    oMap.put("CARD_DETAIL_INFO" , k , "COURIER_CODE_DESC" , "1".equals(barcodeMap.getString("COURIER_CODE")) ? "Aktif ileti" : "2".equals(barcodeMap.getString("COURIER_CODE")) ? "Kuryenet" : "6".equals(barcodeMap.getString("COURIER_CODE")) ? "PTTKurye" : "");
                    
                    oMap.put("CARD_DETAIL_INFO" , k , "BAR_CODE" , barcodeMap.getString("BAR_CODE"));
                    iMap.put("BAR_CODE" , barcodeMap.getString("BAR_CODE"));
                    
                    GMMap courierHistoryMap = isOcean ? GMServiceExecuter.call("BNSPR_OCEAN_GET_COURIER_HISTORY" , iMap) : GMServiceExecuter.call("BNSPR_INTRACARD_GET_COURIER_HISTORY" , iMap);
                    for (int j = 0; j < courierHistoryMap.getSize("LIST"); j++){
                        if (deliveryCode.equals(courierHistoryMap.getString("LIST" , j , "COURIER_SUB_CODE"))){
                            oMap.put("CARD_DETAIL_INFO" , k , "TXN_DATE" , courierHistoryMap.getString("LIST" , j , "TXN_DATE"));
                            break;
                        }
                        
                    }
                    k++;
                }
                
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
        
    }
    
    private static boolean isEligible(GMMap cardMap, int i) {
    	
        boolean isOcean = "O".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "SYSTEM"));
        boolean isStatNormal = "N".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CODE")) && "N".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_SUB_STAT_CODE"));
        boolean isStatCourier = "G".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CODE")) && "J".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_SUB_STAT_CODE"));
        GMMap panSeqMap = cardMap.getMap("CARD_DETAIL_INFO" , i);
        int panSeq = GMServiceExecuter.call(isOcean ? "BNSPR_OCEAN_GET_CARD_FEE" : "BNSPR_INTRACARD_GET_CARD_FEE" , panSeqMap).getInt("PAN_SEQ");
        boolean isPrintedMoreThanOnce = panSeq > 1;
        GMMap postInfoMap = panSeqMap;
        GMMap postInfoReturnMap = GMServiceExecuter.call(isOcean ? "BNSPR_OCEAN_GET_CARD_POST_INFO" : "BNSPR_INTRACARD_GET_CARD_POST_INFO"  , postInfoMap);
        boolean isSentByPost = "Posta".equals(postInfoReturnMap.getString("CARD_POST_INFO_LIST", 0, "CARD_POST_TYPE"));
        boolean isNotDelivered = "H".equals(postInfoReturnMap.getString("CARD_POST_INFO_LIST", 0, "ACTIVITY_TYPE"));
        
        return isNotDelivered && isSentByPost && ((isStatNormal && isPrintedMoreThanOnce) || isStatCourier);
    }
    
    @SuppressWarnings({ "unchecked", "deprecation" })
    @GraymoundService("BNSPR_TRN4468_GET_POST_INFO")
    public static GMMap bnspr4468GetPostInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        StringBuilder stb;
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            List<GnlMusteriAdres> recordList = (List<GnlMusteriAdres>) session.createCriteria(GnlMusteriAdres.class).add(Restrictions.eq("id.musteriNo" , iMap.getBigDecimal("MUSTERI_NO"))).list();
            int i = 0;
            for (GnlMusteriAdres record : recordList){
                stb = new StringBuilder();
                stb.append(StringUtils.isNotBlank(record.getIsyeriUnvani()) ? record.getIsyeriUnvani() : "");
                stb.append(" ");
                stb.append(record.getAdres());
                stb.append(" ");
                stb.append(StringUtils.isNotBlank(record.getSemt()) ? record.getSemt() : "");
                stb.append(" ");
                stb.append(LovHelper.diLov(record.getIlceKod() , record.getIlKod() , "10011/LOV_ADRES_ILCE" , "ILCE_ADI"));
                stb.append(" ");
                stb.append(LovHelper.diLov(record.getIlKod() , "10011/LOV_ADRES_IL" , "IL_ADI"));
                stb.append(" ");
                stb.append(LovHelper.diLov(record.getUlkeKod() , "10011/LOV_ULKE" , "ULKE_ADI"));
                oMap.put("ADDRESS_LIST" , i , "ADDRESS" , stb.toString());
                oMap.put("ADDRESS_LIST" , i , "ADDRESS_TYPE" , record.getId().getAdresKod());
                
                oMap.put("ADDRESS_LIST" , i , "CHECKED" , false);
                i++;
                
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4468_ADDRESS_CHECK_CONTROL")
    public static GMMap bnspr4468AddressCheckControl(GMMap iMap) throws Exception {
        GMMap oMap = new GMMap();
        int checkCount = 0;
        try{
            for (int i = 0; i < iMap.getSize("TABLE"); i++){
                if (iMap.getBoolean("TABLE" , i , "CHECKED"))
                    checkCount++;
            }
            if (checkCount > 1){
                iMap.put("P1" , "Yaln�zca bir adres se�ilebilir");
                iMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , iMap);
            }
            if (checkCount < 1){
                iMap.put("P1" , "Adres se�iniz");
                iMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , iMap);
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4468_GET_EXTERNAL_POST_INFO")
    public static GMMap bnspr4468GetExternalPostInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            if ("2".equals(iMap.getString("KURYE_KOD"))){
                String takipNo = iMap.getString("TAKIP_NO");
                String takipNoWithoutLastChar = takipNo.substring(0 , takipNo.length() - 1);
                iMap.put("TAKIP_NO" , takipNoWithoutLastChar);
            }
            GMMap addressMap = new GMMap();
             addressMap.putAll(GMServiceExecuter.call("BNSPR_EXT_GET_KURYE_ADRES_BILGILERI" , iMap));
            GMMap currentAddressMap = addressMap.getMap("ADDRESS_LIST" , 0);
            if(currentAddressMap!=null){
            oMap.put("CURRENT_DELIVERY_ADDRESS",0, "ADDRESS", currentAddressMap.getString("BIRINCI_ADRES"));
            oMap.put("CURRENT_DELIVERY_ADDRESS",1, "ADDRESS", currentAddressMap.getString("IKINCI_ADRES"));
            oMap.put("CURRENT_DELIVERY_ADDRESS",2, "ADDRESS", currentAddressMap.getString("UCUNCU_ADRES"));
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4468_GET_COURIER_HISTORY")
    public static GMMap bnspr4468getCourierHistory(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            boolean isOcean = "O".equals(iMap.getString("SYSTEM"));
            GMMap courierHistoryMap = isOcean ? GMServiceExecuter.call("BNSPR_OCEAN_GET_COURIER_HISTORY" , iMap) : GMServiceExecuter.call("BNSPR_INTRACARD_GET_COURIER_HISTORY" , iMap);
            oMap.put("COURIER_HISTORY" , courierHistoryMap.get("LIST"));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4468_GET_COURIER_ISLEM_BILGILERI")
    public static GMMap bnspr4468getCourierIslem(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap islemMap = new GMMap();
        try{
            if ("2".equals(iMap.getString("KURYE_KOD"))){
                String takipNo = iMap.getString("TAKIP_NO");
                String takipNoWithoutLastChar = takipNo.substring(0 , takipNo.length() - 1);
                iMap.put("TAKIP_NO" , takipNoWithoutLastChar);
            }
             islemMap.putAll(GMServiceExecuter.call("BNSPR_EXT_GET_KURYE_ISLEM_BILGILERI" , iMap));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4468_CREATE_APPROVE_MESSAGE")
    public static GMMap bnspr4468getCreateApproveMessage(GMMap iMap) {
        GMMap oMap = new GMMap();
        String address = "";
        String cardNoLast4 = "";
        try{
            if (StringUtils.isBlank(iMap.getString("CARD_NO"))){
                iMap.put("P1" , "Kart Se�iniz");
                iMap.put("HATA_NO" , "660");
            }
            for (int i = 0; i < iMap.getSize("ADDRESS_TABLE"); i++){
                if (iMap.getBoolean("ADDRESS_TABLE" , i , "CHECKED")){
                    address = iMap.getString("ADDRESS_TABLE" , i , "ADDRESS");
                    break;
                }
            }
            cardNoLast4 = iMap.getString("CARD_NO").substring(12 , 16);
            oMap.put("MESSAGE" , cardNoLast4 + " ile biten kart�n�z�n \" " + address + " \" adresine teslim edilmek �zere kurye firmas�na talimat verilmesini onayl�yor musunuz?");
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4468_UPDATE_COURIER_ADDRESS")
    public static GMMap bnspr4468updateCourierAddress(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            if ("2".equals(iMap.getString("KURYE_KOD"))){
                String takipNo = iMap.getString("TAKIP_NO");
                String takipNoWithoutLastChar = takipNo.substring(0 , takipNo.length() - 1);
                iMap.put("TAKIP_NO" , takipNoWithoutLastChar);
                iMap.put("AGENT_ID" , GMContext.getCurrentContext().getSession().get("USER_NAME"));
                iMap.put("ADI" , GMContext.getCurrentContext().getSession().get("USER_NAME"));
            } else{
                iMap.put("AGENT_ID" ,"41718");
                iMap.put("ADI" , "aktifbank");
            }
           
            iMap.put("ADRES_KOD" , "1");
           
             oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_UPDATE_KURYE_ADRES_BILGILERI" , iMap));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    
}
