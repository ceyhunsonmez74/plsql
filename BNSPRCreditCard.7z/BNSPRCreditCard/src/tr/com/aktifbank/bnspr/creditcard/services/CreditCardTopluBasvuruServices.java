package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkTopluBasvuruHavuz;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/** Kredi karti EVAM'dan toplu basvuru islemlerini gerceklestirir.
 * @author murat.el
 * @since PYKKBAS-266
 */
public class CreditCardTopluBasvuruServices {
	
	private final static String AKIS_TURU_LIMIT_GUNCELLEME = "L";
	private final static String AKIS_TURU_ON_ONAY = "O";
	private final static String AKIS_TURU_YENI_BASVURU = "B";
	private final static String ISLEM_BASLAT = "0";
	private final static String ISLEM_BASARILI = "1";
	private final static String ISLEM_BASARISIZ = "2";
	private final static String ISLEM_HATALI = "3";
	private final static String LIMIT_GUNCELLE_EVENT_NO = "41";
	private final static String ONONAY_BASVURU_EVENT_NO = "50";
	//private static final Logger logger = Logger.getLogger(CreditCardTopluBasvuruServices.class);
	
	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- HAVUZA EKLE/GUNCELLE
	//--------------------------------------------------------------------------------------------
	/** 
	 * ByteArray olarak alinan excel dosyasinin icerigini okuyarak kredi karti toplu basvuru islemi olarak kaydeder.
	 * Islem icin 3892 ekrani kullanilir.<br>
	 * @author murat.el
	 * @since PY-7940
	 * @param iMap - Dosya bilgileri<br>
	 *        <li>DOSYA - Okunacak dosya(byteArray)
	 *        <li>AKTARIM_NO - Okunacak dosyadaki kayitlari takip amacli aktarim numarasi
	 * @return oMap - Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_EXCEL_TO_HAVUZ")
	public static GMMap topluBasvuruExceldenHavuzaEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		String excelTableName = "TABLE";

		try {
			//1. Excel kolon sayisi kontrol
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "KK_TOPLU_BASVURU_KOLON_SAYISI");
			String kolonSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");
			
			//2. Excelden datalari al
			GMMap excelMap = new GMMap();
			excelMap.put("DOSYA", iMap.get("DOSYA"));
			excelMap.put("KOLON_SAYISI", kolonSayisi);
			excelMap.put("BASLIK_VAR_MI", CreditCardServicesUtil.EVET);
			excelMap.putAll(GMServiceExecuter.execute("BNSPR_EXCEL_TO_LIST", excelMap));//TABLE
			//Kontrol
			if (excelMap.get(excelTableName) == null || excelMap.getSize(excelTableName) < 1) {
				CreditCardServicesUtil.raiseGMError("660", "Dosya icerisinde data bulunamadi");
			}

			//3. Alinan datalari havuza kaydet
			for (int i = 0; i < excelMap.getSize(excelTableName); i++) {
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", excelMap.get(excelTableName, i, "TC_KIMLIK_NO"));
				sorguMap.put("KART_NO", excelMap.get(excelTableName, i, "KART_NO"));
				sorguMap.put("AKIS_TURU", excelMap.get(excelTableName, i, "AKIS_TURU"));
				sorguMap.put("SENARYO", "DOSYA");
				sorguMap.put("AYLIK_GELIR", excelMap.get(excelTableName, i, "AYLIK_GELIR"));
				sorguMap.put("TALEP_EDILEN_LIMIT", excelMap.get(excelTableName, i, "TALEP_EDILEN_LIMIT"));
				sorguMap.put("ANLIK_BASVURU_MU", excelMap.get(excelTableName, i, "ANLIK_BASVURU_MU"));
				sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", excelMap.get(excelTableName, i, "OTOMATIK_LIMIT_ARTSIN_MI"));
				sorguMap.put("CEP_ULKE_KOD", excelMap.get(excelTableName, i, "CEP_ULKE_KOD"));
				sorguMap.put("CEP_ALAN_KOD", excelMap.get(excelTableName, i, "CEP_ALAN_KOD"));
				sorguMap.put("CEP_NO", excelMap.get(excelTableName, i, "CEP_NO"));
				sorguMap.put("BASVURU_NO", excelMap.get(excelTableName, i, "BASVURU_NO"));
				sorguMap.put("AKTARIM_NO", iMap.get("AKTARIM_NO"));
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
				sorguMap.put("KAMPANYA", excelMap.get(excelTableName, i, "KAMPANYA"));
				sorguMap.put("KANAL", excelMap.get(excelTableName, i, "KANAL"));
				sorguMap.putAll(topluBasvuruHavuzaEkle(sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		iMap.put("MESSAGE_NO", new BigDecimal(2356));
		oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
		return oMap;
	}
	
	/** Kredi karti limit guncelleme/toplu basvuru/on onayli basvuru icin islenmesi gereken kayitlari havuza ekler.<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 *        <li>KART_NO - Kart numarasi
	 *        <li>AKIS_TURU - Islemde hangi akisin kullanilacagi bilgisi: KK_EVAM_AKIS_TURU (Zorunlu)
	 *        <li>SENARYO - Evam senaryosu(EVAM tarafindan kullanilacak)
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi(Zorunlu)
	 *        <li>TALEP_EDILEN_LIMIT - Istenen yeni kart limiti
	 *        <li>ANLIK_BASVURU_MU - Anlik basvuru yapilsin mi?(E:Evet|H:Hayir)
	 *        <li>OTOMATIK_LIMIT_ARTSIN_MI - Otomatik olarak limit artsin mi?(E:Evet|H:Hayir)
	 *        <li>CEP_ULKE_KOD - Cep telefonu ulke kodu
	 *        <li>CEP_ALAN_KOD - Cep telefonu alan kodu
	 *        <li>CEP_NO - Cep telefonu numarasi
	 *        <li>BASVURU_NO - Yarim kalip devam ettirilmek istenen basvuru numarasi
	 *        <li>AKTARIM_NO - Toplu aktarim yapilacaksa, aktarim numarasi
	 *        <li>HATA_VERILSIN_MI - Islem sonucunda hata verilsin mi?(E:Evet|H:Hayir)
	 *        <li>KAMPANYA - Kampanya Adi(Senaryonun tetikledigi tanim)
	 *        <li>KANAL - Basvurunun hangi urun kanalindan tetiklendigi (TFF|BEYOGLU|PASSO)
	 * @return oMap - Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu (0:Basarisiz | 2:Basarili)
	 *        <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_HAVUZA_EKLE")
	public static GMMap topluBasvuruHavuzaEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//1.Alan Kontrolleri
			//Tc Kimlik no
			if (StringUtils.isBlank(iMap.getString("TC_KIMLIK_NO"))) {
				CreditCardServicesUtil.raiseGMError("330", "Tc Kimlik No");
			} else {
				//TCKN kontrolu
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", sorguMap));
				if ("0".equals(sorguMap.getString("SONUC"))) {
					CreditCardServicesUtil.raiseGMError("456", iMap.getString("TC_KIMLIK_NO"));
				}
			}
			//Akis turu
			String akisTuru = iMap.getString("AKIS_TURU");
			if (StringUtils.isBlank(akisTuru)) {
				CreditCardServicesUtil.raiseGMError("330", "Akis Turu");
			} else {
				sorguMap.clear();
				sorguMap.put("KOD", "KK_EVAM_AKIS_TURU");
				sorguMap.put("KEY1", akisTuru);
				GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap);
			}
			//Senaryo
			sorguMap.clear();
			sorguMap.put("KOD", "KK_TOPLU_BASVURU_SENARYO_KOD");
			sorguMap.put("KEY", iMap.getString("SENARYO"));
			sorguMap.put("KEY2", akisTuru);//Akis Turu
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("IS_EXIST"))) {
				CreditCardServicesUtil.raiseGMError("330", "Senaryo");
			}
			//Aylik Gelir - Zorunluluk kaldirildi
			if (StringUtils.isNotBlank(iMap.getString("AYLIK_GELIR"))) {
				if (NumberUtils.isNumber(iMap.getString("AYLIK_GELIR"))) {
					if (BigDecimal.ZERO.compareTo(iMap.getBigDecimal("AYLIK_GELIR")) == 0) {
						CreditCardServicesUtil.raiseGMError("330", "Aylik Gelir");
					}
				} else {
					CreditCardServicesUtil.raiseGMError("1406", "Aylik Gelir");
				}
			}
			//Format kontrolu
			if (StringUtils.isNotBlank(iMap.getString("AYLIK_GELIR"))) {
				if (NumberUtils.isNumber(iMap.getString("AYLIK_GELIR"))) {
					if (BigDecimal.ZERO.compareTo(iMap.getBigDecimal("AYLIK_GELIR")) == 0) {
						CreditCardServicesUtil.raiseGMError("2597", "Aylik Gelir");
					}
				} else {
					CreditCardServicesUtil.raiseGMError("1406", "Aylik Gelir Formati");
				}
			}
			//Talep edilen kart limiti
			if (StringUtils.isNotBlank(iMap.getString("TALEP_EDILEN_LIMIT"))) {
				if (NumberUtils.isNumber(iMap.getString("TALEP_EDILEN_LIMIT"))) {
					if (BigDecimal.ZERO.compareTo(iMap.getBigDecimal("TALEP_EDILEN_LIMIT")) == 0) {
						CreditCardServicesUtil.raiseGMError("330", "Talep Edilen Kart Limiti Formati");
					}
				} else {
					CreditCardServicesUtil.raiseGMError("1406", "Talep Edilen Kart Limiti Formati");
				}
			}
			//Anlik Basvuru
			String anlikBasvuruMu = CreditCardServicesUtil.HAYIR;
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("ANLIK_BASVURU_MU"))) {
				anlikBasvuruMu = CreditCardServicesUtil.EVET;
			}
			//Otomatik Limit Artis
			String otomatikLimitArtisMi = CreditCardServicesUtil.HAYIR;
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("OTOMATIK_LIMIT_ARTSIN_MI"))) {
				otomatikLimitArtisMi = CreditCardServicesUtil.EVET;
			}
			//Cep Tel
			if (AKIS_TURU_ON_ONAY.equals(akisTuru) || AKIS_TURU_YENI_BASVURU.equals(akisTuru)) {
				if (StringUtils.isBlank(iMap.getString("CEP_ULKE_KOD"))) {
					CreditCardServicesUtil.raiseGMError("330", "Cep Telefonu Ulke Kodu");
				}
				
				if (StringUtils.isBlank(iMap.getString("CEP_ALAN_KOD"))) {
					CreditCardServicesUtil.raiseGMError("330", "Cep Telefonu Alan Kodu");
				}
				
				if (StringUtils.isBlank(iMap.getString("CEP_NO"))) {
					CreditCardServicesUtil.raiseGMError("330", "Cep Telefonu Numarasi");
				}
			}
			//Kampanya
			if (AKIS_TURU_LIMIT_GUNCELLEME.equals(akisTuru)) {
				if (StringUtils.isBlank(iMap.getString("KAMPANYA"))) {
					CreditCardServicesUtil.raiseGMError("330", "Kampanya");
				}
			}
			//2.Default alanlari ata
			//Id al
			sorguMap.clear();
			sorguMap.put("TABLE_NAME", "KK_TOPLU_BASVURU_HAVUZ");
			BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID");
			//Durum kodu belirle
			sorguMap.clear();
			sorguMap.put("KOD", "KK_EVAM_DURUM_ACIKLAMA_KOD");
			sorguMap.put("KEY1", "01");//Kayit okundu.
			String durumAciklama = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");
			String durumKod = ISLEM_BASLAT;
			
			//3.Havuza eklenecek datayi olustur
			KkTopluBasvuruHavuz kktopluBasvuruHavuz = new KkTopluBasvuruHavuz();
			kktopluBasvuruHavuz.setId(id);
			kktopluBasvuruHavuz.setAkisTuru(akisTuru);
			kktopluBasvuruHavuz.setSenaryo(iMap.getString("SENARYO"));
			kktopluBasvuruHavuz.setAnlikBasvuru(anlikBasvuruMu);
			kktopluBasvuruHavuz.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			kktopluBasvuruHavuz.setCepUlkeKod(iMap.getString("CEP_ULKE_KOD"));
			kktopluBasvuruHavuz.setCepAlanKod(iMap.getString("CEP_ALAN_KOD"));
			kktopluBasvuruHavuz.setCepNo(iMap.getString("CEP_NO"));
			kktopluBasvuruHavuz.setDurumKod(durumKod);
			kktopluBasvuruHavuz.setDurumAciklama(durumAciklama);
			kktopluBasvuruHavuz.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kktopluBasvuruHavuz.setOtoLimitArtis(otomatikLimitArtisMi);
			kktopluBasvuruHavuz.setTalepKartLimit(iMap.getBigDecimal("TALEP_EDILEN_LIMIT"));
			kktopluBasvuruHavuz.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			kktopluBasvuruHavuz.setAktarimNo(iMap.getBigDecimal("AKTARIM_NO"));
			kktopluBasvuruHavuz.setKartNo(iMap.getString("KART_NO"));
			kktopluBasvuruHavuz.setKampanya(iMap.getString("KAMPANYA"));
			kktopluBasvuruHavuz.setKanal(CreditCardServicesUtil.nvl(iMap.getString("KANAL"), "TFF"));
			session.saveOrUpdate(kktopluBasvuruHavuz);
			session.flush();
			
			//4.Islem sonucunu don
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}

		return oMap;
	}
	
	/** Kredi karti toplu basvuru/Limit guncelleme akislarini yonetir.<br>
	 * @author murat.el
	 * @since PY-8526, PY-9701
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>AKIS_TURU - Islemde hangi akisin kullanilacagi bilgisi(Zorunlu)
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi(Zorunlu)
	 * @return oMap - Output Yok.
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_YAP")
	public static GMMap topluBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Lks icin kullanilacak kart bilgilerini al
			GMMap kartMap = new GMMap();
			kartMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			kartMap.putAll(getKartBilgiByTckn(kartMap));
			
			//Kart numarasi varsa havuz datasini guncelle
			if (kartMap.get("KART_NO") != null) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("KART_NO", kartMap.get("KART_NO"));
				updateTopluBasvuruHavuz(sorguMap);
			}

			//Ayl�k gelir bilgisi verilmisse, lks limit uygunluk kontrolu yap
			BigDecimal lksLimit = null;
			BigDecimal lksSorguNo = null;
			sorguMap.clear();
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("KART_VAR_MI", kartMap.get("KART_VAR_MI"));
			sorguMap.put("MUSTERI_LIMIT", kartMap.get("MUSTERI_LIMIT"));
			sorguMap.put("AYLIK_GELIR", iMap.get("AYLIK_GELIR"));
			sorguMap.put("TALEP_EDILEN_KART_LIMIT", iMap.get("TALEP_KART_LIMIT"));
			sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_KK_TOPLU_BASVURU_LKS_SORGUSU_YAP", sorguMap));
			//Lks sorgusu sonucunda limiti var mi?
			lksLimit = sorguMap.getBigDecimal("LKS_LIMIT");
			lksSorguNo = sorguMap.getBigDecimal("LKS_SORGU_NO");
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				String durumAciklama = "02";//Lks Limiti Yetersiz
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("LKS_HATALI_MI"))) {
					durumAciklama = "13";//LKS sorgusu hatali
				}
				//Toplu basvuru tablosunda durum alanlarini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
				sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
				sorguMap.put("SENARYO", iMap.get("SENARYO"));
				sorguMap.put("AKIS_TURU", iMap.get("AKIS_TURU"));
				updateTopluBasvuruHavuzDurum(sorguMap);

				//Islemi sonlandir
				return oMap;
			} else {
				//Alinan lks limitini toplu basvuruya ekle
				if (lksLimit != null && BigDecimal.ZERO.compareTo(lksLimit) < 0) {
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("LKS_LIMIT", lksLimit);
					updateTopluBasvuruHavuz(sorguMap);
				}
			}

			//Akis turune gore islemleri yap.
			String akisTuru = iMap.getString("AKIS_TURU");
			if (AKIS_TURU_LIMIT_GUNCELLEME.equals(akisTuru)) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
				sorguMap.put("KART_VAR_MI", kartMap.get("KART_VAR_MI"));
				sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", BooleanUtils.toBoolean(iMap.getString("OTO_LIMIT_ARTIS"), 
						CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
				sorguMap.put("KART_NO", kartMap.get("KART_NO"));
				sorguMap.put("KART_LIMIT", kartMap.get("KART_LIMIT"));
				sorguMap.put("KART_RISK", kartMap.get("KART_RISK"));
				sorguMap.put("TALEP_EDILEN_KART_LIMITI", CreditCardServicesUtil.nvl(iMap.get("TALEP_EDILEN_KART_LIMITI"), lksLimit));
				sorguMap.put("AYLIK_GELIR", iMap.get("AYLIK_GELIR"));
				sorguMap.put("MUSTERI_LIMIT", kartMap.get("MUSTERI_LIMIT"));
				sorguMap.put("SENARYO", iMap.get("SENARYO"));
				sorguMap.put("KAMPANYA", iMap.get("KAMPANYA"));
				sorguMap.put("MUSTERI_TIP", kartMap.get("MUSTERI_TIP"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_LIMIT_GUNCELLE", sorguMap));
			} else if (AKIS_TURU_ON_ONAY.equals(akisTuru)) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("LKS_SORGU_NO", lksSorguNo);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_ON_ONAY_BASVURU_YAP", sorguMap));
			} else if (AKIS_TURU_YENI_BASVURU.equals(akisTuru)) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_TAM_BASVURU_YAP", sorguMap));
			}
			
			//Islemlerden alinan sonuca gore islemi basarili olarak guncelle.
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				//Toplu basvuru tablosunda durum alanlarini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARILI);
				sorguMap.put("DURUM_ACIKLAMA", "09");//Islem basari ile tamamlandi
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
				sorguMap.put("SENARYO", iMap.get("SENARYO"));
				sorguMap.put("AKIS_TURU", iMap.get("AKIS_TURU"));
				updateTopluBasvuruHavuzDurum(sorguMap);
			}
		}
		//Hata alinirsa islemi tamamla, kaydi hatali olarak guncelle
		catch (Exception e) {
			//Yapilan islemlerin rollback edilmesi icin exc. firlatildi
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Hata alinca rollback islemlerinin yapilmasi icin ayri bir transaction ile islem calistirildi.
	 * Rollback sonrasi havuzdaki kaydin durumu sistem hatasi olarak guncelleniyor.
	 * 
	 * */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_YAP_NT")
	public static GMMap topluBasvuruYapNt(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_KK_TOPLU_BASVURU_YAP", iMap));
		}
		catch (Exception e) {
			//Hatayi ekran/tabloda tutmak icin ayri transaction olarak save islemi yapilir.
			String hataMesaji = e.getMessage();
			if (hataMesaji.length() > 200) {
				hataMesaji = hataMesaji.substring(0, 200);
			}
			
			GMMap sorguMap = new GMMap();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", ISLEM_HATALI);
			sorguMap.put("DURUM_ACIKLAMA", hataMesaji);
			sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.HAYIR);
			sorguMap.put("SENARYO", iMap.get("SENARYO"));
			sorguMap.put("AKIS_TURU", iMap.get("AKIS_TURU"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_DURUM_GUNCELLE", sorguMap));
		}

		return oMap;
	}

	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- LKS SORGULAMA
	//--------------------------------------------------------------------------------------------
	/** Kredi karti EVAM toplu basvuru islemleri icin lks sorgusu yapar.<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi(Zorunlu)
	 *        <li>KART_VAR_MI - Onceden kredi karti var mi? (E:Evet | H:Hayir)
	 *        <li>MUSTERI_LIMIT - Onceden kredi karti varsa musteri limit bilgisi
	 *        <li>TALEP_EDILEN_KART_LIMIT - Talep edilen kart limiti
	 *        <li>HATA_VERILSIN_MI - Hata verilecek mi? (E:Evet | H:Hayir)
	 * @return oMap - Limit uygun mu?
	 * 		  <li>RESPONSE - Limit uygun mu sonuc kodu (0:Uygun Degil | 2:Uygun)
	 *        <li>LKS_HATALI_MI - Lks sorgusu sirasinda hata alindi mi (E:Evet|H:Hayir)
	 * 		  <li>LKS_LIMIT - Limit uygunsa lks limit tutari
	 *        <li>LKS_SORGU_NO - Lks sorgusu yapilmissa sorgu numarasi
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_LKS_SORGUSU_YAP")
	public static GMMap topluBasvuruLksSorgusuYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap musteriMap = new GMMap();

		try {
			//Aksi olana kadar islem basarili kabul edilir.
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			oMap.put("LKS_HATALI_MI", CreditCardServicesUtil.HAYIR);
			
			//LKS sorgusu icin gerekli datayi TCKN bazinda al, banka musterisi degilse KPS yapilir.
			sorguMap.clear();
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			musteriMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_MUSTERI_BILGI", sorguMap));
			
			//Mevcut karti varsa 02, yoksa 01 tipinde sorgu yapilir.
			String sorguTipi = "01";
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("KART_VAR_MI"))) {
				sorguTipi = "02";
			}
			
			//LKS sorgusu yap, hata alinmasi ya da basarisiz olunmasi durumunda
			//tekrar yapilacagi icin atlandi. Basarili olma durumunda ise 
			//lksden cikan limitin uygunluk kontrolu yapilir. 
			BigDecimal lksSorguNo = null;
			try {
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriMap.get("MUSTERI_NO"));
				sorguMap.put("TCKN", musteriMap.get("TC_KIMLIK_NO"));
				sorguMap.put("ILK_ADI", musteriMap.get("ADI"));
				sorguMap.put("IKINCI_ADI", musteriMap.get("IKINCI_ADI"));
				sorguMap.put("SOYADI", musteriMap.get("SOYADI"));
				sorguMap.put("DOGUM_TARIHI", musteriMap.get("DOGUM_TARIHI"));
				sorguMap.put("BABA_ADI", musteriMap.get("BABA_ADI"));
				sorguMap.put("ANA_ADI", musteriMap.get("ANNE_ADI"));
				sorguMap.put("SORGU_TIPI", sorguTipi);
				sorguMap.put("MANUEL_SORGU", CreditCardServicesUtil.EVET);
				sorguMap.putAll(GMServiceExecuter.execute("LKS_SORGUSU_YAP", sorguMap));
				lksSorguNo = sorguMap.getBigDecimal("SORGU_NO");
			} 
			catch (Exception e) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("LKS_HATALI_MI", CreditCardServicesUtil.EVET);
				return oMap;
			}
			oMap.put("LKS_SORGU_NO", lksSorguNo);
			
			//LKS basarili mi
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("LKS_YAPILDIMI")) && 
					CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
				//Aylik gelir bilgisi varsa
				if (StringUtils.isNotBlank(iMap.getString("AYLIK_GELIR"))) {
					//LKS limiti uygun mu, degilse reddet
					sorguMap.clear();
					sorguMap.put("AKIS_TURU", "P");
					sorguMap.put("SORGU_NO", lksSorguNo);
					sorguMap.put("AYLIK_GELIR", iMap.get("AYLIK_GELIR"));
					sorguMap.put("KART_LIMIT", iMap.get("MUSTERI_LIMIT"));
					sorguMap.put("TALEP_EDILEN_KART_LIMIT", iMap.get("TALEP_EDILEN_KART_LIMIT"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LKS_LIMIT_UYGUN_MU", sorguMap));
					if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("LKS_LIMIT_UYGUN_MU", CreditCardServicesUtil.HAYIR))) {
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
						return oMap;
					} else {
						oMap.put("LKS_LIMIT", sorguMap.get("LKS_LIMIT"));
					}
				}
			}
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			}
		}

		return oMap;
	}
	
	/** Toplu basvuru olusturulmasi icin TCKN uzerinden kisi/musteri/kart bilgilerini alir..<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 * @return oMap - Musteri/Kart bilgileri
	 *        <li>TC_KIMLIK_NO - KPS yapilmissa dogrulanan kimlik numarasi, yoksa input olan tc kimlik numarasi
	 *        <li>MUSTERI_NO - Banka musterisi ise musteri numarasi
	 *        <li>ADI - Ad
	 *        <li>IKINCI_ADI - Ik�nci ad
	 *        <li>SOYADI - Soyadi
	 *        <li>DOGUM_TARIHI - Dogum tarihi
	 *        <li>BABA_ADI - Baba adi
	 *        <li>ANNE_ADI - Anne adi
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_MUSTERI_BILGI")
	public static GMMap topluBasvuruMusteriBilgisiAl(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Basvuru mevcut bir musteri tarafindan mi yapiliyor
			sorguMap.clear();
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			oMap.putAll(getMusteriBilgiByTckn(sorguMap));
			//Mevcut musteri degilse KPS sorgusu yap.
			if (oMap.isEmpty() || oMap.get("ADI") == null) {
				sorguMap.clear();
				sorguMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", sorguMap));
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					oMap.put("TC_KIMLIK_NO", sorguMap.get("TCKNO_OUT"));
					oMap.put("ADI", sorguMap.get("AD1"));
					oMap.put("IKINCI_ADI", sorguMap.get("AD2"));
					oMap.put("SOYADI", sorguMap.get("SOYAD"));
					oMap.put("DOGUM_TARIHI", sorguMap.get("DOGUM_TARIHI"));
					oMap.put("BABA_ADI", sorguMap.get("BABA_AD"));
					oMap.put("ANNE_ADI", sorguMap.get("ANNE_AD"));
				}
			}	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- LIMIT GUNCELLEME
	//--------------------------------------------------------------------------------------------
	/** Kredi karti toplu basvuru/Limit guncelleme akislarini yonetir.<br>
	 * @author murat.el
	 * @since PY-8526, PY-9701
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>ID - Havuzdan islenecek kaydin ID degeri
	 * 		  <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 * 		  <li>KART_VAR_MI - Limiti guncellenecek kisinin mevcut kredi karti var mi?(E:Evet|H:Hayir)
	 * 		  <li>OTOMATIK_LIMIT_ARTSIN_MI - Limit duzenli olarak otomatik arttirilsin mi?(E:Evet|H:Hayir)
	 *        <li>KART_NO - Kredi karti numarasi
	 *        <li>KART_LIMIT - Kredi karti limit tutari
	 *        <li>KART_RISK - Kredi karti risk tutari
	 *        <li>TALEP_EDILEN_KART_LIMITI - Talep edilen kart limit tutari
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi(Zorunlu)
	 *        <li>MUSTERI_LIMIT - Musteri limit tutari (E:Evet|H:Hayir)
	 *        <li>SENARYO - Limit guncelleme isleminin nereden tetiklendigi bilgisi
	 *        <li>KAMPANYA - Kampanya Adi(Senaryonun tetikledigi tanim)
	 *        <li>MUSTERI_TIP - Musteri Tipi
	 * @return oMap - Output Yok.
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_LIMIT_GUNCELLE")
	public static GMMap topluBasvuruLimitGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Kontroller
			Boolean hataVarMi = Boolean.FALSE;
			String hataKodu = null;
			//Karti var mi? Varsa isleme gir yoksa evama bildir
			if (CreditCardServicesUtil.HAYIR.equals(iMap.getString("KART_VAR_MI"))) {
				hataVarMi = true;
				hataKodu = "04";//Mevcut kullanilmakta olan kart bulunamadi
			}
			//Talep edilen kart limit alani dolu ve mevcut kart limitinden azsa limit azaltma islemi yapilmaz
			if (!hataVarMi && iMap.get("TALEP_EDILEN_KART_LIMITI") != null && 
					BigDecimal.ZERO.compareTo(iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI")) == -1) {
				if (iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI").compareTo(iMap.getBigDecimal("KART_LIMIT")) == -1) {
					hataVarMi = true;
					hataKodu = "03";//Limit azaltma islemi yapilamaz.
				}
			}
			/*Otomatik limit artis varsa sureci baslat, yoksa evama bildir
			if (!hataVarMi && !iMap.getBoolean("OTOMATIK_LIMIT_ARTSIN_MI") &&
					"EVAM_LIMIT_GUNCELLEME_1".equals(iMap.getString("SENARYO"))) {
				hataVarMi = true;
				hataKodu = "05";//Otomatik limit 
			}PY-10072*/
			//Musteri bilgilerini al
			BigDecimal musteriNo = null;
			if (!hataVarMi) {
				GMMap musteriMap = new GMMap();
				musteriMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
				musteriMap.putAll(getMusteriBilgiByTckn(musteriMap));
				if (StringUtils.isBlank(musteriMap.getString("MUSTERI_NO"))) {
					hataVarMi = true;
					hataKodu = "15";//Musteri tanimi bulunamadi
				} else {
					musteriNo = musteriMap.getBigDecimal("MUSTERI_NO");
				}
			}
			//Musteri tipi mac limitli mi
			if (!hataVarMi) {
				sorguMap.clear();
				sorguMap.put("MUSTERI_TIP",  iMap.get("MUSTERI_TIP"));
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_MUSTERI_TIPI_MAC_LIMITLI_MI", sorguMap));
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("MAC_LIMITLI_MI")) && 
						CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("MAC_LIMITI_ARTIRILABILIR_MI"))) {
					hataVarMi = true;
					hataKodu = "18";//Mac limitli musterilere limit artirimi yapilmaz.
				}
			}
			
			//Hata varsa islemi sonlandir.
			if (hataVarMi) {
				//Toplu basvuru tablosunda durum alanlarini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
				sorguMap.put("DURUM_ACIKLAMA", hataKodu);
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
				sorguMap.put("SENARYO", iMap.get("SENARYO"));
				sorguMap.put("AKIS_TURU", AKIS_TURU_LIMIT_GUNCELLEME);
				updateTopluBasvuruHavuzDurum(sorguMap);
				
				//Islemi sonlandir
				return oMap;
			}
			
			//Evam senaryo 3 ise senaryo 2 ile olusturulmus bir limit artis talebi var mi kontrol et. 
			//Varsa onceki talebi iptal et
			if ("EVAM_LIMIT_GUNCELLEME_3".equals(iMap.getString("SENARYO")) &&
					limitEvamSenaryo2VarMi(iMap.getString("TC_KIMLIK_NO"))) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("ONCEKI_DURUM_KOD", "LIMIT_JOB");
				GMServiceExecuter.execute("BNSPR_QRY3822_IPTAL", sorguMap);
			}
			
			//Limit guncelle
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
			
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "E");
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("MUSTERI_NO", musteriNo);
			sorguMap.put("KART_NO", iMap.get("KART_NO"));
			sorguMap.put("KART_LIMIT", iMap.get("KART_LIMIT"));
			sorguMap.put("KART_RISK", iMap.get("KART_RISK"));
			sorguMap.put("TALEP_EDILEN_KART_LIMITI", iMap.get("TALEP_EDILEN_KART_LIMITI"));
			sorguMap.put("AYLIK_GELIR", iMap.get("AYLIK_GELIR"));
			sorguMap.put("LIMIT_GUNCELLEME_NEDENI", "01");
			sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("MUSTERI_LIMIT", iMap.get("MUSTERI_LIMIT"));
			sorguMap.put("ISLEM_YERI", iMap.getString("SENARYO"));
			sorguMap.put("ONCEKI_DURUM_KOD", "BASVURU");
			sorguMap.put("KAMPANYA", iMap.get("KAMPANYA"));
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3821_SAVE", sorguMap));
			BigDecimal limitGuncellemeId = sorguMap.getBigDecimal("ID");
			if (limitGuncellemeId != null) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("LIMIT_GUNCELLEME_ID", limitGuncellemeId);
				updateTopluBasvuruHavuz(sorguMap);
			}
			
			//Buradan gelen hatalar business hatasi olarak degerlendirilmeli
			try {
				sorguMap.clear();
				sorguMap.put("TRX_NO", trxNo);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_AFTER_CONTROL", sorguMap));
			}
			catch (Exception e) {
				//Hatayi kes.
				String hataMesaji = e.getMessage();
				if (hataMesaji.length() > 200) {
					hataMesaji = hataMesaji.substring(0, 200);
				}
				//Toplu basvuru tablosunda durum alanlarini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
				sorguMap.put("DURUM_ACIKLAMA", hataMesaji);
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.HAYIR);
				sorguMap.put("SENARYO", iMap.get("SENARYO"));
				sorguMap.put("AKIS_TURU", AKIS_TURU_LIMIT_GUNCELLEME);
				updateTopluBasvuruHavuzDurum(sorguMap);
				
				return oMap;
			}
			
			//Limit kontrolleri OK, banka akisini baslat
			sorguMap.clear();
			sorguMap.put("ISLEM_NO", trxNo);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_DEGISIM_AKIS", sorguMap));
			BigDecimal basvuruNo = sorguMap.getBigDecimal("BASVURU_NO");
			//Toplu basvuru tablosunda basvuru alanini guncelle
			if (basvuruNo != null) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("BASVURU_NO", basvuruNo);
				updateTopluBasvuruHavuz(sorguMap);
			}
			
			sorguMap.clear();
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	private static boolean limitEvamSenaryo2VarMi(String tcKimlikNo) {
		boolean senaryoVarMi = false;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = pkg_trn3821.evamLimitSenaryo2VarMi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, tcKimlikNo);
			stmt.execute();
			//Sonucu al
			if (CreditCardServicesUtil.EVET.equals(stmt.getString(1))) {
				senaryoVarMi = true;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return senaryoVarMi;
	}
	
	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- ON ONAY BASVURU
	//--------------------------------------------------------------------------------------------	
	/** Kredi karti toplu basvuru on oanyli basvuru akislarini yonetir. 
	 * Bu akisa giren musterilerin daha once kredi karti olmasi gerekir.<br>
	 * @author murat.el
	 * @since PY-8526
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>ID - Havuzdan islenecek kaydin ID degeri
	 * 		  <li>LKS_SORGU_NO - Yapilmis LKS sorgu no
	 * @return oMap - Islem sonuc bilgisi<br>
	 *        <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_ON_ONAY_BASVURU_YAP")
	public static GMMap topluBasvuruOnOnayBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Havuzdan yapilmak istenen basvuru datasini al
			KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
					session.get(KkTopluBasvuruHavuz.class, iMap.getBigDecimal("ID"));
			//Yapilmis LKS inputlarinin alinabilmesi icin lks sorgusunda basvuru numarasini guncelle
			//Basvuru numarasini al
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_BASVURU_NO", sorguMap));
			BigDecimal basvuruNo = sorguMap.getBigDecimal("ID");
			//Alinan basvuru numarasini lksde guncelle
			sorguMap.clear();
			sorguMap.put("LKS_SORGU_NO", iMap.get("LKS_SORGU_NO"));
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_KK_TOPLU_UPDATE_LKS_ISLEM", sorguMap));
			//Kredi karti kisa basvuru olustur
			sorguMap.clear();
			//NBSM'in calismasi icin meslek bilgilerinin de kayit edilmesi gerekiyor
			sorguMap.put("TC_KIMLIK_NO", kkTopluBasvuruHavuz.getTcKimlikNo());
			sorguMap.putAll(getSonBasvuruBilgiByTckn(sorguMap));
			//Onceki basvuru bilgileri bulundu mu? Bulunamadi ise bsvuru tamamlansin istenmiyorsa hata ver.
			if (StringUtils.isBlank(sorguMap.getString("MUSTERI_NO"))) {
				if (AKIS_TURU_YENI_BASVURU.equals(kkTopluBasvuruHavuz.getAkisTuru()) ||
						(AKIS_TURU_ON_ONAY.equals(kkTopluBasvuruHavuz.getAkisTuru()) && 
								CreditCardServicesUtil.EVET.equals(kkTopluBasvuruHavuz.getAnlikBasvuru()))) {
					//Toplu basvuru tablosunda durum alanlarini guncelle
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
					sorguMap.put("DURUM_ACIKLAMA", "08");//Onceki basvuru bilgileri bulunamadi
					sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
					sorguMap.put("SENARYO", kkTopluBasvuruHavuz.getSenaryo());
					sorguMap.put("AKIS_TURU", kkTopluBasvuruHavuz.getAkisTuru());
					updateTopluBasvuruHavuzDurum(sorguMap);
					//Islemi sonlandir
					return oMap;
				}
			}
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("TC_KIMLIK_NO", kkTopluBasvuruHavuz.getTcKimlikNo());
			sorguMap.put("CEP_ULKE_KOD", kkTopluBasvuruHavuz.getCepUlkeKod());
			sorguMap.put("CEP_TEL_KOD", kkTopluBasvuruHavuz.getCepAlanKod());
			sorguMap.put("CEP_TEL_NO", kkTopluBasvuruHavuz.getCepNo());
			sorguMap.put("AYLIK_GELIR", kkTopluBasvuruHavuz.getAylikGelir());
			sorguMap.put("KREDI_KARTI_SEVIYESI", "O");//On onayli basvuru
			sorguMap.put("BASVURU_SONLANDIRILSIN_MI", CreditCardServicesUtil.EVET);
			sorguMap.put("KPS_JOB_AKTIF_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3870_KISA_BASVURU_YAP", sorguMap));
			basvuruNo = sorguMap.getBigDecimal("BASVURU_NO");
			BigDecimal trxNo = sorguMap.getBigDecimal("TRX_NO");
			String aciklama = sorguMap.getString("RESPONSE_DATA");
			//Kredi karti kisa basvuru islemi basarisizsa, havuzdaki kaydin durumunu guncelle
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				//Basvuru hata alarak NBSM jobda kaldi ise iptal et, tekrar girilmesini sagla
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("NBSM_HATASI_MI"))) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", basvuruNo);
					sorguMap.put("ISLEM_NO", trxNo);
					sorguMap.put("DURUM_KOD", "IPTAL");
					sorguMap.put("TARIHCE_AKSIYON", "G");
					sorguMap.put("ISLEM_ACIKLAMA", "On onayli basvuruda NBSM hatasi aldigindan iptal edildi");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
				}
				//Basvuru bilgisini guncelle
				if (basvuruNo != null) {
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("BASVURU_NO", basvuruNo);
					updateTopluBasvuruHavuz(sorguMap);
				}
				
				//Toplu basvuru tablosunda durum alanlarini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
				sorguMap.put("DURUM_ACIKLAMA", aciklama);//
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.HAYIR);
				sorguMap.put("SENARYO", kkTopluBasvuruHavuz.getSenaryo());
				sorguMap.put("AKIS_TURU", kkTopluBasvuruHavuz.getAkisTuru());
				updateTopluBasvuruHavuzDurum(sorguMap);
				//Islemi sonlandir
				return oMap;
			//Kredi karti basvuru islemi basariliysa, havuzdaki kaydin basvuru no alanini guncelle.
			} else {
				//Basvuru uzerinden onaylanan kart bilgisini al
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
				session.refresh(kkBasvuru);
				BigDecimal onaylananLimit = CreditCardServicesUtil.nvl(kkBasvuru.getOnaylananKartLimiti(), BigDecimal.ZERO);
				//Basvuru bilgisini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("BASVURU_NO", basvuruNo);
				sorguMap.put("ONAYLANAN_LIMIT", kkBasvuru.getOnaylananKartLimiti());
				updateTopluBasvuruHavuz(sorguMap);
				//Onaylanan kart limiti kontrolu yap
				if (BigDecimal.ZERO.compareTo(onaylananLimit) >= 0) {
					//Limit cikmadi ise olusturulan basvuruyu iptal et
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", basvuruNo);
					sorguMap.put("ISLEM_NO", trxNo);
					sorguMap.put("DURUM_KOD", "IPTAL");
					sorguMap.put("TARIHCE_AKSIYON", "G");
					sorguMap.put("ISLEM_ACIKLAMA", "On onayli basvuru icin limit cikmadigindan  iptal edildi");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
					
					//Havuz tablosunu guncelle.
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
					sorguMap.put("DURUM_ACIKLAMA", "11");//Onaylanan limit yok
					sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
					sorguMap.put("SENARYO", kkTopluBasvuruHavuz.getSenaryo());
					sorguMap.put("AKIS_TURU", kkTopluBasvuruHavuz.getAkisTuru());
					updateTopluBasvuruHavuzDurum(sorguMap);
					//Islemi sonlandir
					return oMap;
				}
				
				//Anlik basvurusu yapilsin ise tam basvuruya cevirmeye calis, yoksa islem basarili olarak sonlansin
				if (AKIS_TURU_ON_ONAY.equals(kkTopluBasvuruHavuz.getAkisTuru()) &&
						CreditCardServicesUtil.EVET.equals(kkTopluBasvuruHavuz.getAnlikBasvuru())) {
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_TAM_BASVURU_YAP", sorguMap));
					if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
						return oMap;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	/** Yapilan LKS sorgu sonuclarinin NBSMde beslenmesi icin olusturalacak basvuru bilgisini lks tablolarinda gunceller.<br>
	 * @author murat.el
	 * @since PY-9078
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>LKS_SORGU_NO - Yapilmis LKS sorgu no
	 *        <li>BASVURU_NO - Olusturulacak basvuru no
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_TOPLU_UPDATE_LKS_ISLEM")
	public static GMMap updateLksIslemByBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call pkg_trn3821.updateLksIslemByBasvuruNo(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("LKS_SORGU_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- KISA BASVURU ILERLET/TAM BASVURU YAP
	//--------------------------------------------------------------------------------------------
	/** Kredi karti toplu basvuru on oanyli basvuru akislarini yonetir. 
	 * Bu akisa giren musterilerin daha once kredi karti olmasi gerekir.<br>
	 * @author murat.el
	 * @since PY-8526
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>ID - Havuzdan islenecek kaydin ID degeri
	 * @return oMap - Islem sonuc bilgisi<br>
	 *        <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_TAM_BASVURU_YAP")
	public static GMMap topluBasvuruTamBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap basvuruMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Havuzdan yapilmak istenen basvuru datasini al
			KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
					session.get(KkTopluBasvuruHavuz.class, iMap.getBigDecimal("ID"));
			//Daha onceden yapilmis yarim basvurusu var mi? Varsa onu ilerlet, yoksa yeni basvuru akisi baslat
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", kkTopluBasvuruHavuz.getBasvuruNo());
			sorguMap.put("TC_KIMLIK_NO", kkTopluBasvuruHavuz.getTcKimlikNo());
			sorguMap.putAll(onOnayliBasvuruVarMi(sorguMap));
			//basvuru no verilmisse basvuru gecerli mi?
			if (kkTopluBasvuruHavuz.getBasvuruNo() != null) {
				if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("BASVURU_VAR_MI"))) {
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
					sorguMap.put("DURUM_ACIKLAMA", "07");
					sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);//Verilen basvuru on onayli degil
					sorguMap.put("SENARYO", kkTopluBasvuruHavuz.getSenaryo());
					sorguMap.put("AKIS_TURU", kkTopluBasvuruHavuz.getAkisTuru());
					updateTopluBasvuruHavuzDurum(sorguMap);
					//Islemi sonlandir
					return oMap;
				}
				
			//Basvuru no verilmemisse on onayli kisa basvuru olustur
			} else {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_ON_ONAY_BASVURU_YAP", sorguMap));
				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
					return oMap;
				}
			}
			//Kisa basvurunun tamamlanmasi icin onceki basvurularindan bilgi alinir.
			sorguMap.clear();
			sorguMap.put("TC_KIMLIK_NO", kkTopluBasvuruHavuz.getTcKimlikNo());
			sorguMap.put("BASVURU_NO", kkTopluBasvuruHavuz.getBasvuruNo());
			basvuruMap.putAll(getSonBasvuruBilgiByTckn(sorguMap));
			if ("YENI".equals(basvuruMap.getString("ONCEKI_KART_TIPI"))) {
				//Toplu basvuru tablosunda durum alanlarini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
				sorguMap.put("DURUM_ACIKLAMA", "08");
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);//basvuruya ait bilgi alinamadi
				sorguMap.put("SENARYO", kkTopluBasvuruHavuz.getSenaryo());
				sorguMap.put("AKIS_TURU", kkTopluBasvuruHavuz.getAkisTuru());
				updateTopluBasvuruHavuzDurum(sorguMap);
				
				//Islemi sonlandir
				return oMap;
			}
			//ononayli olusturulduktan sonra normal basvuru girilmisse
			//ilerletmeye calistiginda on onayli basvurusunu iptal et.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", kkTopluBasvuruHavuz.getBasvuruNo());
			sorguMap.put("TC_KIMLIK_NO", kkTopluBasvuruHavuz.getTcKimlikNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_KONTROL", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				//Iptal et
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", kkTopluBasvuruHavuz.getBasvuruNo());
				sorguMap.put("ONCEKI_DURUM_KOD", "ON_BASVURU");
				sorguMap.put("ISLEM_KOD", "ON_ONAY");
				sorguMap.put("GEREKCE_KOD", "2");
				sorguMap.put("ACIKLAMA", "KK Basvurusu oldugundan iptal edildi");
				sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
				//Havuz kaydini guncelle
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
				sorguMap.put("DURUM_ACIKLAMA", "14");
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);//KK basvurusu/karti mevcut
				sorguMap.put("SENARYO", kkTopluBasvuruHavuz.getSenaryo());
				sorguMap.put("AKIS_TURU", kkTopluBasvuruHavuz.getAkisTuru());
				updateTopluBasvuruHavuzDurum(sorguMap);
				//Islemi sonlandir
				return oMap;
			}
			//Excel ile cagriliyorsa islem tamamlanmaya calisilir. 
			if ("DOSYA".equals(kkTopluBasvuruHavuz.getSenaryo())) {
				//Islemi tamamla
				sorguMap.clear();
				basvuruMap.put("BASVURU_NO", kkTopluBasvuruHavuz.getBasvuruNo());
				basvuruMap.put("DURUM_KOD", "ON_BASVURU");
				basvuruMap.put("AYLIK_GELIR", CreditCardServicesUtil.nvl(kkTopluBasvuruHavuz.getAylikGelir(), basvuruMap.get("AYLIK_GELIR")));
				basvuruMap.put("IS_FULL_SAVE", "N");
				basvuruMap.put("IS_FIRST_PAGE", "N");
				basvuruMap.put("ACTION", "OUTBOUND");
				basvuruMap.put("MUSTERI_GUNCELLENSIN_MI", CreditCardServicesUtil.EVET);
				basvuruMap.put("KREDI_KARTI_SEVIYESI", "K");//Gercek KK basvurusu
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER", basvuruMap));
				String aciklama = sorguMap.getString("RESPONSE_DATA");
				//Kontrol
				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
					//Toplu basvuru tablosunda durum alanlarini guncelle
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", ISLEM_BASARISIZ);
					sorguMap.put("DURUM_ACIKLAMA", aciklama);
					sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.HAYIR);
					updateTopluBasvuruHavuz(sorguMap);
					
					//Islemi sonlandir
					return oMap;
				}
			}
			//Yoksa Debit/KKdan alinan bilgiler tamamlandiktan sonra EVAMa dusurulur.
			else {
				if ("D".equals(basvuruMap.getString("ONCEKI_KART_TIPI")) ||
						"KK".equals(basvuruMap.getString("ONCEKI_KART_TIPI"))) {
					//Alinan bilgileri kaydet
					basvuruMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap));
					basvuruMap.put("BASVURU_NO", kkTopluBasvuruHavuz.getBasvuruNo());
					basvuruMap.put("DURUM_KOD", "ON_BASVURU");
					basvuruMap.put("AYLIK_GELIR", CreditCardServicesUtil.nvl(kkTopluBasvuruHavuz.getAylikGelir(), basvuruMap.get("AYLIK_GELIR")));
					basvuruMap.put("IS_FULL_SAVE", "N");
					basvuruMap.put("IS_FIRST_PAGE", "N");
					basvuruMap.put("ACTION", "OUTBOUND");
					basvuruMap.put("MUSTERI_GUNCELLENSIN_MI", CreditCardServicesUtil.EVET);
					basvuruMap.put("KREDI_KARTI_SEVIYESI", "O");//On onayli kk basvurusu
					GMServiceExecuter.execute("BNSPR_TRN3871_SAVE", basvuruMap);
					//Alinan bilgileri kontrol et
					sorguMap.clear();
					sorguMap.put("TRX_NO", basvuruMap.get("TRX_NO"));
					sorguMap.put("IS_FIRST_PAGE", "N");
					GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", sorguMap);
					//Islemi tamamla
					sorguMap.clear();
					sorguMap.put("TRX_NO", basvuruMap.get("TRX_NO"));
					sorguMap.put("TRX_NAME", "3871");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION_TEMP", sorguMap);
				} else if ("P".equals(basvuruMap.getString("ONCEKI_KART_TIPI"))) {
					//kanal kodu guncelle
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkTopluBasvuruHavuz.getBasvuruNo());
					kkBasvuru.setKanalKod("40");
					session.saveOrUpdate(kkBasvuru);
					session.flush();
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	/** Verilen basvurunun on onayli bir basvuru olup olmadigi bilgisini doner<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi
	 * @return oMap - Musteri bilgileri
	 *        <li>BASVURU_VAR_MI - On onayli bir basvuru mu? (E:Evet|H:Hayir)
	 *        <li>BASVURU_NO - Basvuru varsa basvuru numarasi
	 */
	private static GMMap onOnayliBasvuruVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call pkg_trn3821.on_onayli_basvuru_var_mi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("TC_KIMLIK_NO"));
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();

			oMap.put("BASVURU_VAR_MI", stmt.getString(3));
			oMap.put("BASVURU_NO", stmt.getBigDecimal(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen basvurunun on onayli bir basvuru olup olmadigi bilgisini doner<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 *        <li>BASVURU_NO - Basvuru numarasi(Zorunlu)
	 * @return oMap - Son ilerlemis basvuru bilgileri
	 */
	private static GMMap getSonBasvuruBilgiByTckn(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3821.get_son_basvuru_bilgi_by_tckn(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- TFF BASVURU OLUSTUR JOB
	//--------------------------------------------------------------------------------------------
	/** Kredi karti basvuru nosu verilen bir basvurunun bilgileri ile otomatik olarak tff basvurusunu olusturur.<br>
	 * Basvuru sahibine ait daha onceden alinmis fotoyu olusturulan bu basvuru icin alarak dizine atar.
	 * Daha once kk basvurusu icin tff basvurusu olusturulmussa islem yapilmaz.
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>KK_BASVURU_NO - Kk basvuru no
	 * @return oMap - Islem sonuc bilgileri
	 *        <li>TFF_BASVURU_NO - Tff basvuru no
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_TFF_BASVURU_OLUSTUR")
	public static GMMap kkTffAkisOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal basvuruNo = null;
		
		try {
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("KK_BASVURU_NO"))) {
				CreditCardServicesUtil.raiseGMError("330", "Basvuru No");
			}
			//Basvuru bilgilerini tablolara direkt(insert into ile) olarak kaydet
			sorguMap.clear();
			sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
			sorguMap.putAll(tffBasvuruOlustur(sorguMap));
			//Basvuru olustu mu
			basvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
			if (basvuruNo == null) {
				CreditCardServicesUtil.raiseGMError("4263", "Tff basvurusu olusturulamadi");
			} else {
				//Zaten bir tff basvurusu varsa hicbir sey yapma.
				if (basvuruNo.compareTo(new BigDecimal("-1")) == 0) {
					return oMap;
				}
			}
			//Basvuru bilgileri basarili olusturuldu ise onayli fotosunu alip 
			//fotograf dizinine basvuru numarasi ile koy
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", basvuruNo);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_CREATE_FOTO_FROM_APPROVED_FOTO", sorguMap));
			//Foto kopyalanamadi ise hata ver
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				CreditCardServicesUtil.raiseGMError("4263", sorguMap.getString("RESPONSE_DATA"));
			}
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("TFF_BASVURU_NO", basvuruNo);
		return oMap;
	}
	
	/** Kredi karti basvuru nosu verilen bir basvurunun bilgileri ile otomatik olarak tff basvurusunu olusturur.<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>KK_BASVURU_NO - Kk basvuru no
	 * @return oMap - Islem sonuc bilgileri
	 *        <li>TFF_BASVURU_NO - Tff basvuru no
	 */
	private static GMMap tffBasvuruOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3821.kk_tff_basvuru_olustur(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("KK_BASVURU_NO"));
			stmt.execute();

			oMap.put("TFF_BASVURU_NO", stmt.getBigDecimal(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Kredi karti basvuru nosu verilen bir basvurunun bilgileri ile otomatik olarak tff basvurusunu olusturur.<br>
	 * Basvuru sahibine ait daha onceden alinmis fotoyu olusturulan bu basvuru icin alarak dizine atar.
	 * Daha once kk basvurusu icin tff basvurusu olusturulmussa islem yapilmaz.
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>KK_BASVURU_NO - Kk basvuru no
	 * @return oMap - Islem sonuc bilgileri
	 *        <li>ODEME_ISLEM_NO - Tff basvuru no
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_TFF_ODEME_YAP")
	public static GMMap kkTffOdemeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al ve odeme muhasebesini olustur
			conn = DALUtil.getGMConnection();

			query = "{ call pkg_trn3821.kk_tff_odeme_yap(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setString(1, iMap.getString("KK_BASVURU_NO"));
			stmt.registerOutParameter(2, Types.NUMERIC);
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.execute();

			oMap.put("ODEME_ISLEM_NO", stmt.getBigDecimal(2));
			oMap.put("TUTAR", stmt.getBigDecimal(3));
			//Bedeli acilan karta borc olarak yansit
			if (oMap.get("TUTAR") != null && BigDecimal.ZERO.compareTo(oMap.getBigDecimal("TUTAR")) == -1) {
				sorguMap.clear();
				sorguMap.put("KART_NO", iMap.get("KART_NO"));
				sorguMap.put("KART_TIPI", iMap.get("KART_TIPI"));
				sorguMap.put("TUTAR", oMap.get("TUTAR"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_TFF_FINANSAL_BAKIM", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Mevcutta aktif karta borc gecmek uzere finansal bakim yapilmasini saglar
	 * @author murat.el
	 * @since PY-9340
	 * @param iMap - Islem bilgileri<br>
	 *        <li>KART_NO - Kart numarasi
	 *        <li>KART_TIPI - Kart tipi(P:Prepaid|D:Debit|KK:Kredi Karti)
	 *        <li>TUTAR - Finansal bakim tutari
	 * @return oMap - Islem sonuc bilgileri
	 *        <li>ODEME_ISLEM_NO - Tff basvuru no
	 */
	@GraymoundService("BNSPR_CREDITCARD_TFF_FINANSAL_BAKIM")
	public static GMMap tffFinansalBakim(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Parametre kontrol
			String kartNo = iMap.getString("KART_NO");
			if (StringUtils.isBlank(kartNo)) {
				CreditCardServicesUtil.raiseGMError("330", "Kart No");
			}
			String kartTipi = iMap.getString("KART_TIPI");
			if (StringUtils.isBlank(kartTipi)) {
				CreditCardServicesUtil.raiseGMError("330", "Kart Tipi");
			}
			BigDecimal tutar = iMap.getBigDecimal("TUTAR");
			if (tutar == null || BigDecimal.ZERO.compareTo(tutar) == 1) {
				CreditCardServicesUtil.raiseGMError("330", "Tutar");
			}
			//Parametreleri al
			sorguMap.clear();
            sorguMap.put("BSMV_RATE", BigDecimal.ZERO);
            sorguMap.put("KKF_RATE", BigDecimal.ZERO);
            sorguMap.put("TXN_AMOUNT", tutar);
            sorguMap.put("CARD_NO", kartNo);
            sorguMap.put("TXN_DESC", "E-Bilet Yillik Kullanim Bedeli");
            sorguMap.put("TXN_CURR_CODE", "TRY");
            sorguMap.put("TXN_TYPE", "1103~1610~10~N");
            sorguMap.put("TXN_STATE", "N");
            sorguMap.put("TXN_DATE", new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime()));
            //Servisi belirle
            String serviceName = null;
            if ("D".equals(kartTipi) || "P".equals(kartTipi)) {//Intra
            	serviceName = "BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT";
            } else if ("KK".equals(kartTipi)) {//CreditCard
            	serviceName = "BNSPR_OCEAN_FINANCIAL_ADJUSTMENT";
            } else {
            	CreditCardServicesUtil.raiseGMError("330", "Kart Tipi");
            }
            //Islemi yap
            sorguMap.putAll(GMServiceExecuter.call(serviceName, sorguMap));
            if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RETURN_CODE"))) {
                  throw new GMRuntimeException(4448011, "Kart Transfer : "+ sorguMap.getString("RETURN_DESCRIPTION"));
            }
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- UTIL METHODS
	//--------------------------------------------------------------------------------------------
	/** Kredi karti toplu basvuru havuzundaki kaydin durumunu gunceller, islem evamdan tetikleniyorsa EVAM kaydi olusturulur.<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>ID - Toplu basvuru havuzundaki kaydin ID degeri
	 *        <li>DURUM_KOD - Yeni durum kod
	 *        <li>DURUM_ACIKLAMA - Yeni durum aciklama
	 *        <li>KODDAN_ACIKLAMA_AL - Tanimli hata mesaji mi kullanilacak?(E:Evet|H:Hayir)
	 *        <li>SENARYO - Hangi islem sonucu kaydin olusturuldugu
	 *        <li>AKIS_TURU - Havuzdaki kaydin girecegi akis turu
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_DURUM_GUNCELLE")
	public static GMMap updateTopluBasvuruHavuzDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Durum aciklamasi al
			String durumAciklama = null;
			if (StringUtils.isNotBlank(iMap.getString("DURUM_ACIKLAMA"))) {
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("KODDAN_ACIKLAMA_AL"))) {
					sorguMap.clear();
					sorguMap.put("KOD", "KK_EVAM_DURUM_ACIKLAMA_KOD");
					sorguMap.put("KEY1", iMap.getString("DURUM_ACIKLAMA"));
					durumAciklama = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");
				} else {
					durumAciklama = iMap.getString("DURUM_ACIKLAMA");
				}
			}
			//Guncelle
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
			sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
			updateTopluBasvuruHavuz(sorguMap);
			//Senaryo EVAMa ait mi?
			sorguMap.clear();
			sorguMap.put("KOD", "KK_TOPLU_BASVURU_SENARYO_KOD");
			sorguMap.put("KEY", iMap.getString("SENARYO"));//ISLEM_TETIKLI_LIMIT_GUNCELLEME
			sorguMap.put("KEY2", iMap.getString("AKIS_TURU"));//Akis Turu
			sorguMap.put("KEY3", "E");//Evam
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
			String evamMi = CreditCardServicesUtil.HAYIR;
			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
				evamMi = CreditCardServicesUtil.EVET;
			}
			
			//Evam tarafi tetiklenecek.
			if (CreditCardServicesUtil.EVET.equals(evamMi)) {
				//Limit guncelleme eventi tetiklenecek
				if (AKIS_TURU_LIMIT_GUNCELLEME.equals(iMap.getString("AKIS_TURU"))) {
					if (!ISLEM_BASARILI.equals(iMap.getString("DURUM_KOD"))) {
						sorguMap.clear();
						sorguMap.put("EVENT_TYPE_NO", LIMIT_GUNCELLE_EVENT_NO);
						sorguMap.put("EVENT_REF_NO", iMap.get("ID"));
						GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap);
					}
				//On onayli basvuru eventi tetiklenecek.
				} else {
					//Session ac
					Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
					//Kaydi al
					KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
							session.get(KkTopluBasvuruHavuz.class, iMap.getBigDecimal("ID"));
					//Islem basarili ise
					if (ISLEM_BASARILI.equals(iMap.getString("DURUM_KOD"))) {
						if (AKIS_TURU_YENI_BASVURU.equals(iMap.getString("AKIS_TURU")) ||
								(AKIS_TURU_ON_ONAY.equals(iMap.getString("AKIS_TURU")) && 
								 CreditCardServicesUtil.EVET.equals(kkTopluBasvuruHavuz.getAnlikBasvuru()))) {
							sorguMap.clear();
							sorguMap.put("EVENT_TYPE_NO", ONONAY_BASVURU_EVENT_NO);
							sorguMap.put("EVENT_REF_NO", kkTopluBasvuruHavuz.getBasvuruNo());
							sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap));
						}
					}
				} 
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_GUNCELLE")
	public static GMMap updateTopluBasvuruHavuz(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Durum guncelle
			KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
					session.get(KkTopluBasvuruHavuz.class, iMap.getBigDecimal("ID"));
			if (kkTopluBasvuruHavuz != null) {
				//Akis turu, senaryo, tckn alanlari guncellenmemeli
				//kkTopluBasvuruHavuz.setAkisTuru(CreditCardServicesUtil.nvl(iMap.getString("AKIS_TURU"), kkTopluBasvuruHavuz.getAkisTuru()));
				kkTopluBasvuruHavuz.setAktarimNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AKTARIM_NO"), kkTopluBasvuruHavuz.getAktarimNo()));
				kkTopluBasvuruHavuz.setAnlikBasvuru(CreditCardServicesUtil.nvl(iMap.getString("ANLIK_BASVURU_MU"), kkTopluBasvuruHavuz.getAnlikBasvuru()));
				kkTopluBasvuruHavuz.setAylikGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AYLIK_GELIR"), kkTopluBasvuruHavuz.getAylikGelir()));
				kkTopluBasvuruHavuz.setBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("BASVURU_NO"), kkTopluBasvuruHavuz.getBasvuruNo()));
				kkTopluBasvuruHavuz.setCepUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("CEP_ULKE_KOD"), kkTopluBasvuruHavuz.getCepUlkeKod()));
				kkTopluBasvuruHavuz.setCepAlanKod(CreditCardServicesUtil.nvl(iMap.getString("CEP_ALAN_KOD"), kkTopluBasvuruHavuz.getCepAlanKod()));
				kkTopluBasvuruHavuz.setCepNo(CreditCardServicesUtil.nvl(iMap.getString("CEP_NO"), kkTopluBasvuruHavuz.getCepNo()));
				kkTopluBasvuruHavuz.setDurumKod(CreditCardServicesUtil.nvl(iMap.getString("DURUM_KOD"), kkTopluBasvuruHavuz.getDurumKod()));
				kkTopluBasvuruHavuz.setDurumAciklama(CreditCardServicesUtil.nvl(iMap.getString("DURUM_ACIKLAMA"), kkTopluBasvuruHavuz.getDurumAciklama()));
				kkTopluBasvuruHavuz.setKartNo(CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), kkTopluBasvuruHavuz.getKartNo()));
				kkTopluBasvuruHavuz.setLksLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("LKS_LIMIT"), kkTopluBasvuruHavuz.getLksLimit()));
				kkTopluBasvuruHavuz.setOnaylananKartLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ONAYLANAN_LIMIT"), kkTopluBasvuruHavuz.getOnaylananKartLimit()));
				kkTopluBasvuruHavuz.setOtoLimitArtis(CreditCardServicesUtil.nvl(iMap.getString("OTOMATIK_LIMIT_ARTSIN_MI"), kkTopluBasvuruHavuz.getOtoLimitArtis()));
				//kkTopluBasvuruHavuz.setSenaryo(CreditCardServicesUtil.nvl(iMap.getString("SENARYO"), kkTopluBasvuruHavuz.getSenaryo()));
				kkTopluBasvuruHavuz.setTalepKartLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("TALEP_EDILEN_LIMIT"), kkTopluBasvuruHavuz.getTalepKartLimit()));
				//kkTopluBasvuruHavuz.setTcKimlikNo(CreditCardServicesUtil.nvl(iMap.getString("TC_KIMLIK_NO"), kkTopluBasvuruHavuz.getTcKimlikNo()));
				kkTopluBasvuruHavuz.setKkLimitGuncellemeID(CreditCardServicesUtil.nvl(iMap.getBigDecimal("LIMIT_GUNCELLEME_ID"), kkTopluBasvuruHavuz.getKkLimitGuncellemeID()));
				session.saveOrUpdate(kkTopluBasvuruHavuz);
				session.flush();
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Havuz idsi verilen kaydin musterisini bul<br>
	 * @author murat.el
	 * @category PY-9629
	 * @since 07.01.2015
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>ID - Havuz ID
	 * @return Islem sonucu<br>
	 *        <li>MUSTERI_NO - Musteri numarasi
	 */
	@GraymoundService("BNSPR_KK_TOPLU_BASVURU_GET_MUSTERI_NO_BY_ID")
	public static GMMap getMusteriNoByHavuzId(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		//Default deger ata
		oMap.put("MUSTERI_NO", StringUtils.EMPTY);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Musteri numarasini al
			KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz)
					session.get(KkTopluBasvuruHavuz.class, iMap.getBigDecimal("ID"));
			if (kkTopluBasvuruHavuz != null) {
				sorguMap.clear();
				sorguMap.put("TCKN", kkTopluBasvuruHavuz.getTcKimlikNo());
				sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
				sorguMap.putAll(GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
				if (sorguMap.get("CUSTOMER_NO") != null && BigDecimal.ZERO.compareTo(sorguMap.getBigDecimal("CUSTOMER_NO")) < 0) {
					oMap.put("MUSTERI_NO", sorguMap.get("CUSTOMER_NO"));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Havuz idsi verilen kaydin musterisini bul<br>
	 * @author murat.el
	 * @category PY-9629
	 * @since 07.01.2015
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 * @return Islem sonucu<br>
	 *        <li>MUSTERI_NO - Musteri numarasi
	 */
	@GraymoundService("BNSPR_KK_GET_MUSTERI_NO_BY_BASVURU_NO")
	public static GMMap getMusteriNoByKkBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		//Default deger ata
		oMap.put("MUSTERI_NO", StringUtils.EMPTY);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Musteri numarasini al
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (kkBasvuru != null && kkBasvuru.getMusteriNo() != null) {
				oMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen TCKN ile musteri bilgilerini alir.<br>
	 * @author murat.el
	 * @since PY-8489
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 * @return oMap - Musteri bilgileri
	 *        <li>TC_KIMLIK_NO - KPS yapilmissa dogrulanan kimlik numarasi, yoksa input olan tc kimlik numarasi
	 *        <li>MUSTERI_NO - Banka musterisi ise musteri numarasi
	 *        <li>ADI - Ad
	 *        <li>IKINCI_ADI - Ik�nci ad
	 *        <li>SOYADI - Soyadi
	 *        <li>DOGUM_TARIHI - Dogum tarihi
	 *        <li>BABA_ADI - Baba adi
	 *        <li>ANNE_ADI - Anne adi
	 */
	private static GMMap getMusteriBilgiByTckn(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3821.get_musteri_bilgi_by_tckn(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("TC_KIMLIK_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen TCKN ile kart bilgilerini alir.<br>
	 * @author murat.el
	 * @since PY-8489, PY-9701
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi(Zorunlu)
	 * @return oMap - Musteri/Kart bilgileri
	 *        <li>KART_VAR_MI - Kullanmakta oldugu kredi karti var mi? (E:Evet|H:Hayir)
	 *        <li>MUSTERI_LIMIT - Musteri kart limiti
	 *        <li>KART_NO - Kart numarasi
	 *        <li>KART_LIMIT - Kart limiti
	 *        <li>KART_RISK - Kart riski
	 *        <li>MUSTERI_TIP - Musteri Tipi
	 */
	private static GMMap getKartBilgiByTckn(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			oMap.put("KART_VAR_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("MAC_LIMITI_KONTROL_EDILSIN_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIST", sorguMap));
			if (sorguMap.getSize("KART_LIST") > 0) {
				oMap.put("KART_VAR_MI", CreditCardServicesUtil.EVET);
				oMap.put("MUSTERI_LIMIT", sorguMap.getBigDecimal("MUSTERI_LIMIT"));
				oMap.put("KART_NO", sorguMap.getString("KART_LIST", 0, "KART_NO"));
				oMap.put("KART_LIMIT", sorguMap.getString("KART_LIST", 0, "KART_LIMIT"));
				oMap.put("KART_RISK", sorguMap.getString("KART_LIST", 0, "KART_RISK"));
				oMap.put("MUSTERI_TIP", sorguMap.getString("MUSTERI_TIP"));
			} else {
				oMap.put("KART_VAR_MI", CreditCardServicesUtil.HAYIR);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
