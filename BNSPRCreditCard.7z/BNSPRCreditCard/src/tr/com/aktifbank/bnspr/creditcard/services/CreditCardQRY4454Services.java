package tr.com.aktifbank.bnspr.creditcard.services;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY4454Services {
    
    @GraymoundService("BNSPR_QRY4454_GET_CARD_LIST")
    public static GMMap getCardList(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap outMap = new GMMap();
        
        if (iMap.get("CUSTOMER_NO") == null){
            return oMap;
        }
        
        try{
            iMap.put("CARD_BANK_STATUS_CC" , true);
            iMap.put("NO_NEED_APPLICATIONS" , true);
            outMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN" , iMap);
            int s = outMap.getSize("CARD_DETAIL_INFO");
            
            for (int i = 0; i < s; i++){
                oMap.put("LIST" , i , "CARD_NO" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_NO"));
                oMap.put("LIST" , i , "CARD_DCI" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_DCI"));
                oMap.put("LIST" , i , "CARD_STAT_CODE" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CODE"));
                oMap.put("LIST" , i , "CARD_STAT_DESC" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_DESC"));
                oMap.put("LIST" , i , "EMBOSS_NAME" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_EMBOSS_NAME_1"));
                oMap.put("LIST" , i , "EXPIRY_DATE" , outMap.getString("CARD_DETAIL_INFO" , i , "EXPIRY_DATE"));
                
                if ("19000101".equals(outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CHANGE_DATE"))){
                    oMap.put("LIST" , i , "CARD_STAT_CHANGE_DATE" , "");
                } else{
                    oMap.put("LIST" , i , "CARD_STAT_CHANGE_DATE" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CHANGE_DATE"));
                }
                oMap.put("LIST" , i , "CARD_UPDATE_USER" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_UPDATE_USER"));
                oMap.put("LIST" , i , "CARD_SUB_STAT_CODE" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_SUB_STAT_CODE"));
                oMap.put("LIST" , i , "CARD_GROUP_DESC" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_GROUP_DESC"));
                
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY4454_INTRACARD_GET_CARD_MEMO")
    public static GMMap getCardMemo(GMMap iMap) {
        String serviceName = "";
        serviceName = "Credit".equals(iMap.getString("SYSTEM")) ? "BNSPR_OCEAN_GET_CARD_MEMO" : "BNSPR_INTRACARD_GET_CARD_MEMO";
        GMMap oMap = GMServiceExecuter.call(serviceName , iMap);
        
        for (int i = 0; i < oMap.getSize("MEMO_LIST"); i++){
            oMap.put("MEMO_LIST" , i , "OLD_CARD_NO" , iMap.getString("OLD_CARD_NO"));
            if (StringUtils.isNotBlank(oMap.getString("MEMO_LIST" , i , "UPDATE_DATE")) && oMap.getString("MEMO_LIST" , i , "UPDATE_DATE").length() == 14){
                oMap.put("MEMO_LIST" , i , "PROCESS_DATE" , oMap.getString("MEMO_LIST" , i , "UPDATE_DATE").substring(0 , 8));
                oMap.put("MEMO_LIST" , i , "PROCESS_TIME" , oMap.getString("MEMO_LIST" , i , "UPDATE_DATE").substring(8 , 14));
            }
            else if(StringUtils.isNotBlank(oMap.getString("MEMO_LIST" , i , "UPDATE_DATE")) && oMap.getString("MEMO_LIST" , i , "UPDATE_DATE").length() == 13){
                oMap.put("MEMO_LIST" , i , "PROCESS_DATE" , oMap.getString("MEMO_LIST" , i , "UPDATE_DATE").substring(0 , 8));
                oMap.put("MEMO_LIST" , i , "PROCESS_TIME" , "0"+oMap.getString("MEMO_LIST" , i , "UPDATE_DATE").substring(8 , 13));
            }
            
        }
        return oMap;
    }
    
}
