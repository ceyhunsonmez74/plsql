package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import sun.java2d.pipe.GeneralCompositePipe;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruIptalTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdeme;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import common.Logger;

/** TFF basvuru iptal islemi
 * @author murat.el
 * @since 17.01.2014
 */
public class CreditCardTRN3809Services {
	
	private static final String ISLEM_KODU = "3809";
	public static final String POS_DEFAULT_CURRENCY = "949";
	private static final String BASVURU_IPTAL_EVENT_TYPE_NO = "35";
	private static final String VAR = "VAR";
	
	private static final Logger logger = Logger.getLogger(CreditCardTRN3809Services.class);
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since 17.01.2014
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>GEREKCE_KOD_LIST - Secilebilecek iptal gerekceleri
	 *         <li>ONCEKI_DURUM_KOD_LIST - Iptal edilebilecek basvuru durumlari
	 */
	@GraymoundService("BNSPR_TRN3809_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			/*GMMap cMap= new GMMap();
			String tckn= null;
			BigDecimal customerNo = null;
			String countryCode= iMap.getString("COUNTRY_CODE");
		    Boolean noNeedApplications= true; 
		    Boolean iadeYap= true; */
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			
			//Gerekce listesi
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY2, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'KK_BASVURU_AKSIYON_KARAR_KOD'");
			query.append(" AND KEY1 = 'C'");
			query.append(" AND KEY2 IN ('1','2','3','4','5')");
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "GEREKCE_KOD_LIST", true, query.toString());
			
			//Durum Listesi
			query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'TFF_BASVURU_DURUM_KOD'");
			query.append(" AND KEY1 NOT IN ('IPTAL', 'ACIK')");
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "ONCEKI_DURUM_KOD_LIST", true, query.toString());
			
			
			//BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			//TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			//if (tffBasvuru == null) {
			//	CreditCardServicesUtil.raiseGMError("2999", basvuruNo);
			//}
			//customerNo = tffBasvuru.getMusteriNo();
			//tckn= tffBasvuru.getTcKimlikNo();
			
			//cMap.put("CUSTOMER_NO", customerNo);
			//cMap.put("NO_NEED_APPLICATIONS", noNeedApplications);
			//cMap.put("INPUT_PARAMETER_TYPE", "CST");
			
			//M��terinin a��k passolig kart� var m�?
			//GMMap IsOpenCard = new GMMap();
			//IsOpenCard = GMServiceExecuter.call("BNSPR_INTRACARD_GET_TFF_CARDS_VIA_TCKN", cMap);
			
			//if(IsOpenCard.getSize("CARD_DETAIL_INFO")==0){
			//	GMMap nMap= new GMMap();
			//	nMap.put("NATIONAL_ID", tckn);
			//	nMap.put("COUNTRY_CODE", countryCode);
			//	nMap = GMServiceExecuter.call("BNSPR_NETAS_BILETLEME", nMap);
			//	if (nMap.getBoolean("VALUE")){ //bilet varsa
			//		iadeYap=false;
			//	}
			//}
			//oMap.put("IADE_YAP", iadeYap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since 17.01.2014, PY-10667, TY-4639
	 * @param iMap - Tff basvuru iptal islemi bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>ONCEKI_DURUM_KOD - Basvuru durum kodu
	 *        <li>ISLEM_KOD - Iptalin hangi ekran ya da islemden yapildigi.
	 *        <li>GEREKCE_KOD - Iptal gerekcesi
	 *        <li>ACIKLAMA - Iptal aciklamasi
	 *        <li>KK_BASVURU_IPTAL_MI - Basvuruya ait kredi karti var ise iptal edilsin mi(E:Evet | H:Hayir)
	 *        <li>BASIM_ACIK_IPTAL_MI - Durumu BASIM ya da ACIK ise iptal edilsin mi(E:Evet | H:Hayir)
	 *        <li>MUHASEBE_YAPILSIN_MI - Iptal muhasebesi yapilsin mi(E:Evet | H:Hayir)
	 *        <li>KART_IPTAL_MI - Karti var ise iptal edilsin mi(E:Evet | H:Hayir)
	 *        <li>IADE_YAPILABILIR_MI - true|false
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3809_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Parametre Kontrol
			String basvuruNoStr = iMap.getString("BASVURU_NO");
			if (!NumberUtils.isNumber(basvuruNoStr)) {
				CreditCardServicesUtil.raiseGMError("3043");
			}
			
			String durumKodu = iMap.getString("ONCEKI_DURUM_KOD");
			if (StringUtils.isBlank(durumKodu)) {
				CreditCardServicesUtil.raiseGMError("330", "Onceki Durum Kodu");
			}
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			
			//TFF Basvurusu bilgisini al
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", basvuruNo);
			}
			
			//Mevcut durum kodu ile islemin yapildigi durum ayni mi? Baskasi basvuruyu ilerletti mi?
			if (!durumKodu.equals(tffBasvuru.getDurumKod())) {
				CreditCardServicesUtil.raiseGMError("2701", basvuruNo, tffBasvuru.getDurumKod(), durumKodu);
			}
			
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null) {
				trxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO").toString());
			}
			
			TffBasvuruIptalTx tffBasvuruIptalTx = (TffBasvuruIptalTx) session.get(TffBasvuruIptalTx.class, trxNo);
			if (tffBasvuruIptalTx == null) {
				tffBasvuruIptalTx = new TffBasvuruIptalTx();
			}
			//Islem bilgilerini al.
			tffBasvuruIptalTx.setTxNo(trxNo);
			tffBasvuruIptalTx.setBasvuruNo(basvuruNo);
			tffBasvuruIptalTx.setIslemKodu(iMap.getString("ISLEM_KOD"));
			tffBasvuruIptalTx.setGerekceKod(iMap.getString("GEREKCE_KOD"));
			tffBasvuruIptalTx.setOncekiDurumKod(tffBasvuru.getDurumKod());
			tffBasvuruIptalTx.setAciklama(iMap.getString("ACIKLAMA"));
			tffBasvuruIptalTx.setKkBasvuruIptalMi(iMap.getString("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR));
			tffBasvuruIptalTx.setBasimAcikIptalMi(iMap.getString("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR));
			tffBasvuruIptalTx.setMuhasebeYapilsinMi(iMap.getString("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.EVET));
			tffBasvuruIptalTx.setIadeYapilsinMi(iMap.getBoolean("IADE_YAPILABILIR_MI") ? CreditCardServicesUtil.EVET : CreditCardServicesUtil.HAYIR);
			tffBasvuruIptalTx.setMacBiletiVarMi((iMap.getBoolean("MAC_BILETLI_MI") ? "VAR" : "YOK"));
			//TY-4639 tffBasvuruIptalTx.setMacBiletiVarMi(iMap.getBoolean("MAC_BILETI_MCM_KONTROLU") ? "KONTROL" : (iMap.getBoolean("MAC_BILETLI_MI") ? "VAR" : "YOK"));
			tffBasvuruIptalTx.setKartIptalMi(iMap.getString("KART_IPTAL_MI", CreditCardServicesUtil.EVET));
			
			//Islem bilgilerini kaydet
			session.save(tffBasvuruIptalTx);
			session.flush();
			
			GMServiceExecuter.execute("BNSPR_TRN3809_AFTER_CONTROL", iMap);
			
			GMMap cMap= new GMMap();
			String tckn= null;
			String pasaportNo= iMap.getString("PASAPORT_NO");
			String countryCode= iMap.getString("COUNTRY_CODE");
		    Boolean noNeedApplications= true; 
		    BigDecimal customerNo = null;
		    
		    
			customerNo = tffBasvuru.getMusteriNo();
			tckn= tffBasvuru.getTcKimlikNo();
			
			if(tckn == null){
				tckn= pasaportNo;
			}
			
		   
			cMap.put("CUSTOMER_NO", customerNo);
			cMap.put("NO_NEED_APPLICATIONS", noNeedApplications);
			cMap.put("INPUT_PARAMETER_TYPE", "CST");
						
			//M��terinin a��k passolig kart� var m�?
			GMMap IsOpenCard = new GMMap();
			IsOpenCard = GMServiceExecuter.call("BNSPR_INTRACARD_GET_TFF_CARDS_VIA_TCKN", cMap);
			
			boolean devam = true;
			if(IsOpenCard.getSize("CARD_DETAIL_INFO")==0){
				GMMap nMap= new GMMap();
				nMap.put("NATIONAL_ID", tckn);
				nMap.put("COUNTRY_CODE", countryCode);
				nMap = GMServiceExecuter.call("BNSPR_NETAS_BILETLEME", nMap);
				if (nMap.getBoolean("VALUE")){
					devam =false;
				}
				
			}
			if(devam){
			//ucret iadesi
				if (iMap.getBoolean("IADE_YAPILABILIR_MI")) {
					//Iptal icin 
					if (!"3813".equals(iMap.getString("ISLEM_KOD"))) { //otomatik iptal icin bilgiler alinmali
						iMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
						iMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_IADE_BILGILERI", iMap));
						iMap.put("TXN_DESCRIPTION", "Otomatik iptal sonrasinda ucret iadesi");
						iMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
					} else {
						iMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
					}
					
					GMMap sorguMap = new GMMap();
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_BASVURU_UCRET_IADE", iMap));
					if(CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) //iade basarili
					{
						tffBasvuruIptalTx.setIadeIslemNo(sorguMap.getBigDecimal("IADE_TRX_NO"));
						tffBasvuruIptalTx.setIadeYapilsinMi(CreditCardServicesUtil.EVET);
					}
				}
			}
			
			else{ 
				tffBasvuruIptalTx.setMacBiletiVarMi( VAR);

			}
			//Islem bilgilerini kaydet
			session.saveOrUpdate(tffBasvuruIptalTx);
			session.flush();
			
			GMMap onayMap = new GMMap();
			//mac bileti kontrol edilmeyecekse 4448 islemini onaylar
			if(!iMap.getBoolean("MAC_BILETI_MCM_KONTROLU"))
			{
				//iade islem numarasi varsa 4448 islemini de onaylar
				if(tffBasvuruIptalTx.getIadeIslemNo() != null)
				{
					Object islemTamamlanmisMi = DALUtil.callOneParameterFunction("{? = call PKG_TX.Islem_tamamlanmis_mi(?)}" , Types.NUMERIC  , tffBasvuruIptalTx.getIadeIslemNo());
					
					if(!islemTamamlanmisMi.toString().equals("0"))
					{
						onayMap.put("ISLEM_TURU", "O");
						onayMap.put("ISLEM_NO", tffBasvuruIptalTx.getIadeIslemNo());
						onayMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
					}
				}
			}
			
			//Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", ISLEM_KODU);
			islemMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));
			if(!StringUtil.isEmpty(onayMap.getString("MESSAGE")))
				oMap.put("MESSAGE", oMap.getString("MESSAGE") + " " + onayMap.getString("MESSAGE"));
			
			GMServiceExecuter.executeAsync("BNSPR_TFF_BELGE_IPTAL", iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen iptal islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since 17.01.2014
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>BASVURU_NO - Basvuru numarasi
	 *         <li>GEREKCE_KOD - Iptal gerekcesi
	 *         <li>ACIKLAMA - Iptal aciklamasi
	 *         <li>BASIM_ACIK_IPTAL_MI - Durumu BASIM ya da ACIK ise iptal edilsin mi(true:Evet | false:Hayir)
	 *         <li>MUHASEBE_YAPILSIN_MI - Iptal muhasebesi yapilsin mi(true:Evet | false:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3809_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al
			TffBasvuruIptalTx tffBasvuruIptalTx = (TffBasvuruIptalTx) session.get(TffBasvuruIptalTx.class, trxNo);
			if (tffBasvuruIptalTx != null) {
				oMap.put("BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
				oMap.put("ONCEKI_DURUM_KOD", tffBasvuruIptalTx.getOncekiDurumKod());
				oMap.put("GEREKCE_KOD", tffBasvuruIptalTx.getGerekceKod());
				oMap.put("ACIKLAMA", tffBasvuruIptalTx.getAciklama());
				oMap.put("BASIM_ACIK_IPTAL_MI", BooleanUtils.toBoolean(tffBasvuruIptalTx.getBasimAcikIptalMi(),
						CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
				oMap.put("MUHASEBE_YAPILSIN_MI", BooleanUtils.toBoolean(tffBasvuruIptalTx.getMuhasebeYapilsinMi(),
						CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
				
				if(tffBasvuruIptalTx.getIadeIslemNo() != null)
				{
					GMMap iMap2 = new GMMap();
					iMap2.put("TRX_NO", tffBasvuruIptalTx.getIadeIslemNo());
					oMap.putAll(GMServiceExecuter.call("BNSPR_TRN4448_GET_INFO" , iMap2));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Islem sonrasi yapilacak islemleri gerceklestirir, Iptal islemi sonrasi bilgilendirme maili atilir.<br>
	 * @author murat.el
	 * @since 23.01.2014, TY-2602
	 * @param iMap - Islem bilgileri<br>
	 *         <li>ISLEM_NO - Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3809_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");
		StringBuilder mailBody = null;

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruIptalTx tffBasvuruIptalTx = (TffBasvuruIptalTx) session.get(TffBasvuruIptalTx.class, trxNo);
			
			//basim bekliyor durumundaki kartlar icin kart kapama cagirilacaktir
			if (tffBasvuruIptalTx != null && 
					("BASIM".equals(tffBasvuruIptalTx.getOncekiDurumKod()) &&
					 CreditCardServicesUtil.EVET.equals(tffBasvuruIptalTx.getBasimAcikIptalMi()) &&
					 CreditCardServicesUtil.EVET.equals(tffBasvuruIptalTx.getKartIptalMi()) ))
			{
				//Basvuru bilgisini al
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruIptalTx.getBasvuruNo());
				if (tffBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", tffBasvuruIptalTx.getBasvuruNo());
				}
				
                GMMap iMap2 = new GMMap();
                GMMap oMap2 = new GMMap();
                iMap2.put("CARD_NO", tffBasvuru.getKartNo());
                iMap2.put("STATUS", "I");
                iMap2.put("SUBSTATUS", "M");
                iMap2.put("EMBOSS_CODE", "N");

                Boolean kartIptalHata = false;
                try{
	                if ("KK".equals(tffBasvuru.getKartTipi())){
	                	oMap2 = GMServiceExecuter.call("BNSPR_OCEAN_UPDATE_CARD_STATUS" , iMap2);
	                    
	                } else{
	                	oMap2 = GMServiceExecuter.call("BNSPR_INTRACARD_UPDATE_CARD_STATUS" , iMap2);
	                }
	                if (oMap2.getInt("RETURN_CODE") != OceanConstants.Result_Succesful)
	                {
	                	//kart iptal yapilamadi
	                	kartIptalHata = true;
	                }
                } catch (Exception e) {
                	kartIptalHata = true;
    				e.printStackTrace();
    				logger.error("Kart iptal yapilamadi BASVURU_NO:" + tffBasvuru.getBasvuruNo());
    			}
                
                if(kartIptalHata){
					mailBody = new StringBuilder();
					mailBody.append(tffBasvuru.getBasvuruNo());
					mailBody.append(" no'lu TFF basvurusunun iptal soonrasinda basilan karti iptal edilirken hata almistir.");
					mailBody.append(" Manuel kart iptal surecini baslatiniz.");
					mailBody.append("\n");
			
					sorguMap.clear();
					sorguMap.put("MAIL_TO_PARAM", "TFF_BASVURU_KART_IPTAL_MAIL_TO");
					sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
					sorguMap.put("MAIL_SUBJECT", "TFF Basvuru Iptal Sonrasi Manuel Kart Iptali - " + tffBasvuruIptalTx.getBasvuruNo().toString());
					sorguMap.put("MAIL_BODY", mailBody);
					GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
                }
			}
			
			if (tffBasvuruIptalTx != null && CreditCardServicesUtil.EVET.equals(tffBasvuruIptalTx.getMuhasebeYapilsinMi())) {
				//Odeme Bilgilerini Al
				TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, tffBasvuruIptalTx.getBasvuruNo());
				if (tffBasvuruOdeme != null) {
					//Basvuru bilgisini al
					TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruIptalTx.getBasvuruNo());
					if (tffBasvuru == null) {
						CreditCardServicesUtil.raiseGMError("2999", tffBasvuruIptalTx.getBasvuruNo());
					}
					//Instant basvurularda iade bildirimi/acik karta iade yok.
					//Mac Biletli Mi Kontrol� - PY-9890 ao 02.02.2015
					/*sorguMap.put("BASVURU_NO", tffBasvuruOdeme.getBasvuruNo());
					sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
					sorguMap.put("CARD_NO", tffBasvuru.getKartNo());	
					sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRN3809_MAC_BILETLI_MI", sorguMap));
					String macBiletliMiEH = sorguMap.getString("MAC_BILETLI_MI_EH");
					Boolean macBiletiMcmKontrolu = sorguMap.getBoolean("MAC_BILETI_MCM_KONTROLU"); //MCM tarafindan mac bileti kontrolu yapilacak mi?
						*/			
					if (!(("A".equals(tffBasvuru.getKuryeTipi()) && "NTS01".equals(tffBasvuru.getSource())) || "KONTROL".equals(tffBasvuruIptalTx.getMacBiletiVarMi()) || "VAR".equals(tffBasvuruIptalTx.getMacBiletiVarMi()))) {
						/*Odeme Iade Et - PY-9403 ile kaldirildi
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuruOdeme.getBasvuruNo());
						sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_KARTA_UCRET_IADE", sorguMap));
						//Iade islemi Basarisizsa Mail At.
						*/
						
						if("H".equals(tffBasvuruIptalTx.getIadeYapilsinMi()) || ("E".equals(tffBasvuruIptalTx.getIadeYapilsinMi()) && tffBasvuruIptalTx.getIadeIslemNo() == null)) // otomatik iade yapilmadiysa 
						{
							//Subject olustur
							BigDecimal tutar = tffBasvuruOdeme.getKartBedeli()
									.add(tffBasvuruOdeme.getLoyaltyBedeli())
									.add(tffBasvuruOdeme.getKuryeBedeli());
							
							StringBuilder mailSubject = new StringBuilder();
							mailSubject.append("TFF Basvuru Manuel Iptal+");
							mailSubject.append(tffBasvuruOdeme.getOdemeRefId());
							mailSubject.append("+");
							mailSubject.append(tutar.toString());

							//Body olustur
							sorguMap.clear();
							sorguMap.put("KOD", "TFF_WEBSERVIS_PARAM");
							sorguMap.put("KEY1", tffBasvuruOdeme.getOdemeSekli());
							sorguMap.put("KEY2", "ODEME_TIPI");
							String odemeSekli = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");
							
							mailBody = new StringBuilder();
							mailBody.append(tffBasvuruOdeme.getBasvuruNo());
							mailBody.append(" no'lu TFF basvurusunun ");
							mailBody.append(odemeSekli);
							mailBody.append(" ile yapilan ");
							mailBody.append(tffBasvuruOdeme.getOdemeRefId());
							mailBody.append(" referansli islemi iptal edilmistir.");
							mailBody.append(" Manuel iade surecini baslatiniz.");
							mailBody.append("\n");
							mailBody.append(" Islem Aciklamasi: ");
							mailBody.append("\n");
							mailBody.append(tffBasvuruIptalTx.getAciklama());
							mailBody.append("\n");
							mailBody.append(" Tutar: ");
							mailBody.append(tutar.toString());
							
							//Gonder
							sorguMap.clear();
							sorguMap.put("MAIL_TO_PARAM", "TFF_BASVURU_IPTAL_MAIL_TO");
							sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
							sorguMap.put("MAIL_SUBJECT", mailSubject.toString());
							sorguMap.put("MAIL_BODY", mailBody);
							GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
						}
					}
					
					//TY-3861- Sanal pos iadesi yapilanlara sms gonderilsin -- mac bileti kontrolu yap�lacaksa SMS at�lmas�n, kontrol sonras�nda iade bligilendirme SMS'i at�lacak
					if ("S".equals(tffBasvuruOdeme.getOdemeSekli()) && tffBasvuruIptalTx.getIadeIslemNo() != null && !"KONTROL".equals(tffBasvuruIptalTx.getMacBiletiVarMi())) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
						sorguMap.putAll(smsBilgiAl(sorguMap));
						String cepNo = sorguMap.getString("CEP_NO");
						String mesaj = sorguMap.getString("MESAJ");
						//Cep numarasi var ise smsi gonder
						if (StringUtils.isNotBlank(cepNo) && StringUtils.isNotBlank(mesaj)) {
							sorguMap.clear();
							sorguMap.put("GIDEN_MESAJ", mesaj);
							sorguMap.put("CEP_NO",cepNo);
					        oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
						}
					}
				}
			}
			
			//Islem basarili ile sonlandi ise ve onceki durum veri konntrol ise 
			//veri kontrol havuzundaki kaydi sil
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
			GMServiceExecuter.execute("BNSPR_TRN3805_DELETE_HAVUZ", sorguMap);
			
			//EVAM ve ININ cagirlarini kapat
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
			sorguMap.put("DURUM_KOD", tffBasvuruIptalTx.getOncekiDurumKod());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_EVENT_IPTAL", sorguMap));
			
			try {
				iMap.put("TFF_BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
				iMap.put("CRM_TYPE", CrmTypes.MAIN);
				GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + iMap.containsKey("TFF_BASVURU_NO"));
			}
		}
		catch (Exception e) {
			logger.error("3819 IPTAL HATA");
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Iptal islemi sonrasi odeme yapildi ise tutari -varsa- aktif diger kartlarina iade eder. <br>
	 * @author murat.el
	 * @since 26.02.2014
	 * @param iMap - Basvuru bilgileri<br>
	 *         <li>BASVURU_NO - Tff basvuru numarasi
	 *         <li>HATA_VERILSIN_MI - Hata verilecek mi? (E:Evet | H:Hayir)
	 * @return oMap - Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3809_KARTA_UCRET_IADE")
	public static GMMap digerKartaIadeEt(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Musteri bilgisini al
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", iMap.getString("BASVURU_NO") + " Nolu Basvuru Bulunamadi");
				return oMap;
			}
			
			//Iadenin yapilacagi karti bul
			String kartNo = null;
			//Acik karti var mi?
			sorguMap.clear();
			sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			sorguMap.put("KART_TIPI", "A");//Acik
			sorguMap.put("DURUM", "N");//Hepsi
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_KART_LISTELE", sorguMap));
			if (sorguMap == null || sorguMap.isEmpty() || sorguMap.getSize("KART_LIST") < 1) {
				kartNo = null;
			} else {
				//Kart numarasini al. Debit varsa onu al, yoksa prepaid al.
				for (int i = 0; i < sorguMap.getSize("KART_LIST"); i++) {
					if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(sorguMap.getString("KART_LIST", i, "KART_TIPI"))) {
						kartNo = sorguMap.getString("KART_LIST", i, "KART_NO");
						break;
					} else if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(sorguMap.getString("KART_LIST", i, "KART_TIPI"))) {
						kartNo = sorguMap.getString("KART_LIST", i, "KART_NO");
					}
				}
			}
			
			//Kart var mi?
			if (StringUtils.isBlank(kartNo)) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Odemenin Iade Edilebilecegi Kart Bulunamadi");
				return oMap;
			}
			
			//Odeme Bilgisini Al
			TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, tffBasvuru.getBasvuruNo());
			if (tffBasvuruOdeme == null) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Odemesi Yapilmamis");
				return oMap;
			}
			
			//Iade edilecek tutari al
			BigDecimal iadeMiktar = tffBasvuruOdeme.getKartBedeli()
					.add(tffBasvuruOdeme.getKuryeBedeli())
					.add(tffBasvuruOdeme.getLoyaltyBedeli())
					.add(tffBasvuruOdeme.getVizeBedeli());
			
			//Odeme Sekline gore hesap no ve cinsini al
			String hesapCinsi = "DK";
			String hesapNo = null;		
			if ("S".equals(tffBasvuruOdeme.getOdemeSekli())) {
				sorguMap.clear();
				sorguMap.put("PARAMETRE", "AKTIF_VPOS_EH");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEGER"))) {
					hesapNo = "280997111";
				} else {
					hesapNo = "280997112";
				}
			} else {
				hesapNo = "390993003";
			}

			//Diger karta iade et.
			sorguMap.clear();
			sorguMap.put("TCKN", tffBasvuru.getTcKimlikNo());
			sorguMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
			sorguMap.put("KART_NO", kartNo);
			sorguMap.put("TOPUP_AMOUNT", iadeMiktar);//iade edilecek �cret
			sorguMap.put("TOPUP_CURRENCY", "TRY");//d�viz cinsi
			sorguMap.put("BORCLU_HESAP_CINSI", hesapCinsi);//Bor� ge�ilecek hesab�n cinsi (DK ise DK, m��terili ise VS)
			sorguMap.put("BORCLU_HESAP_NO", hesapNo);//Bor� ge�ilecek Hesap
			sorguMap.put("IPTAL_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_KART_UCRETI_IADE", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE_CODE"))) {
				//Iade islem numarasini odeme tablosuna yaz.
				tffBasvuruOdeme.setIadeIslemNo(sorguMap.getBigDecimal("TX_NO"));
				session.saveOrUpdate(tffBasvuruOdeme);
				session.flush();
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", sorguMap.getString("RESPONSE_DESC"));
				return oMap;
			}
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", e.getMessage());
				return oMap;
			}
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		return oMap;
	}
	//BNSPR_TFF_GET_CANCEL_APP_LIST
	
	@GraymoundService("BNSPR_TFF_GET_CANCEL_APP_LIST")
	public static GMMap getCancelledAppListAfterBooking(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
		BigDecimal appNo = iMap.getBigDecimal("BASVURU_NO");
		BigDecimal tckn = iMap.getBigDecimal("TCKN");
		String countryCode = iMap.getString("COUNTRY_CODE");
		String passportNo = iMap.getString("PASSOPORT_NO");
		

		try {
			String procStr = "{call BNSPR.PKG_TRN3809.Get_Apps_After_Booking (?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[10];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = customerNo;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = appNo;			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = tckn;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = countryCode;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = passportNo;
			i = 0;
			Object[] outputValues = new Object[2];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "LIST";
			 

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.put("MUSTERI_NO", customerNo);
			oMap.put("BASVURU_NO", appNo);
			oMap.put("URUN_ADI", oMap.getString("LIST", 0, "URUN_ADI"));
			oMap.put("BASVURU_BEDELI", oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI"));
			oMap.put("BASVURU_BAKIYESI", oMap.getBigDecimal("LIST", 0, "BASVURU_BAKIYESI"));
			oMap.put("TOPLAM_TUTAR", oMap.getBigDecimal("LIST", 0, "BASVURU_BAKIYESI").add(oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI")));
			oMap.put("CEP_TEL_NO", oMap.getBigDecimal("LIST", 0, "CEP_TEL"));
			
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);	
		}
		catch (Exception ex){
			ex.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.KARA_LISTE_KONTROL_GENEL_HATA);
		}

		return oMap;
	}
	
	/** Kart yenileme/kayip icin alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since PY-8697, PY-10873, TY-4418
	 * @param iMap - Tff basvuru iptal islemi bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>ISLEM_KOD - Iptalin hangi ekran ya da islemden yapildigi.
	 *        <li>ACIKLAMA - Iptal aciklamasi
	 *        <li>URUN_TIPI - PASSO | TFF
	 *        <li>KART_TTPI - KK:Kredi karti | D:Debit | P:Prepaid
	 *        <li>MUSTERI_NO - Musteri numarasi
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3809_KART_BASVURU_IPTAL")
	public static GMMap kartBasvuruIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			//Urun tipi ve kart tipine gore iptal islemini gerceklestir.
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			String urunTipi = iMap.getString("URUN_TIPI");
			if ("PASSO".equals(urunTipi)) {
				//KK basvuru bilgisini al
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
				if (kkBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", basvuruNo);
				}
				//Durumu basimsa iptal et
//				if ("BASIM".equals(kkBasvuru.getDurumKod())) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
					sorguMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD","SS"));
					sorguMap.put("GEREKCE_KOD", iMap.getString("GEREKCE_KOD","4"));//Otomatik Iptal
					sorguMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
					sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
//				}
			} else if ("TFF".equals(urunTipi)) {
				//TFF Basvurusu bilgisini al
				String kartTipi = iMap.getString("KART_TIPI");
				TffBasvuru tffBasvuru = null;
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi)) {
					tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
							.add(Restrictions.eq("kkBasvuruNo", basvuruNo))
							.uniqueResult();
				} else if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(kartTipi) ||
						CreditCardTffServices.TFF_PREPAID_KARTI.equals(kartTipi)) {
				    tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
				} 
				//Kontrol
				if (tffBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", basvuruNo);
				}
				//Durumu basimsa iptal et
				if ("BASIM".equals(tffBasvuru.getDurumKod())) {
					sorguMap.clear();
					
					if ("SS".equals(iMap.getString("ISLEM_KOD"))) {
						// erol der ki 6 ay sonra yine acin derler belli olmaz  TY-6616
						sorguMap.put("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.HAYIR);
					} else {
						sorguMap.put("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.HAYIR);
					}
					
					sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
					sorguMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD"));
					sorguMap.put("GEREKCE_KOD", iMap.getString("GEREKCE_KOD","4"));//Otomatik Iptal
					sorguMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
					sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.EVET);
					sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);
					sorguMap.put("KART_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("IADE_YAPILABILIR_MI", Boolean.FALSE);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
				}
			} else {
				CreditCardServicesUtil.raiseGMError("3", "Urun tipi", urunTipi);
			}
			
			//Limit artis basvurusu iptal
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			Object[] durumKodlari = {"BASIM", "ACIK", "IPTAL", "RED"};
			List<?> kkLimitBasvuruList = session.createCriteria(KkBasvuru.class)
					.add(Restrictions.eq("musteriNo", musteriNo))
					.add(Restrictions.eq("kartSeviyesi", "L"))
					.add(Restrictions.not(Restrictions.in("durumKod", durumKodlari)))
					.add(Restrictions.or(Restrictions.isNull("kartTipi"), Restrictions.eq("kartTipi", "KK")))
					.list();
			if (kkLimitBasvuruList != null && !kkLimitBasvuruList.isEmpty()) {
				KkBasvuru kkBasvuru = null;
				for (Object o : kkLimitBasvuruList) {
					kkBasvuru = (KkBasvuru) o;
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
					sorguMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD"));
					sorguMap.put("GEREKCE_KOD", "4");//Otomatik Iptal
					sorguMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
					sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Mac bileti var mi kontrolu<br>
	 * @author sezgi.yilmaz
	 * @since TY-3947
	 * @param iMap<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>KART_NO - Kart numarasi
	 * @return Islem sonucu<br>
	 *        <li>MAC_BILETLI_MI_EH - Mac biletli mi Evet/Hayir
	 *        <li>MAC_BILETLI_MI - Mac biletli mi true/false
	 *        <li>MAC_BILETLI_MCM_KONTROLU - Mac bileti mcm kontrolu yapilacak mi true/false
	 */
	@GraymoundService("BNSPR_TRN3809_MAC_BILETLI_MI")
	public static GMMap macBiletliMi(GMMap iMap) {
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		GMMap oMap = new GMMap();
		GMMap caMap= new GMMap();
		String tckn= null;
		BigDecimal customerNo = null;
		String countryCode= iMap.getString("COUNTRY_CODE");
	    Boolean noNeedApplications= true; 
	    Boolean iadeYap= true; 
		
		oMap.put("MAC_BILETLI_MI_EH", CreditCardServicesUtil.HAYIR);	
		oMap.put("MAC_BILETLI_MI", false);
		oMap.put("MAC_BILETI_MCM_KONTROLU", false);
		
		try {		
	  		String tablo = "CARD_DETAIL_INFO";
	  		String durum = "CARD_STAT_CODE";
	  		Boolean oceandaKartiVar = false;
	  		Boolean intradaKartiVar = false;
	  		
	  		//oceandaki kartlari kontrol ediliyor
			GMMap cMap = new GMMap();
			cMap.put("CUSTOMER_NO", iMap.getBigDecimal("MUSTERI_NO"));
			cMap.put("CARD_DCI", "C");
			cMap.put("CARD_BANK_STATUS", "All");
			cMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", cMap));//CUSTOMER_NO
			
			if (cMap.get(tablo) != null) {
				for (int j = 0; j < iMap.getSize(tablo); j++) {
					if("N".equals(iMap.get(tablo, j, durum)) /*Normal*/ 
							|| "G".equals(iMap.get(tablo, j, durum)) /*gecici kapali*/)
						if(!iMap.getString(tablo, j, "CARD_NO").equals(iMap.getString("KART_NO"))) //basvurunun kart numarasi ile esit degilse
							oceandaKartiVar = true;
				}
			}
			
			//intradaki kartlari kontrol ediliyor
			cMap.clear();
			cMap.put("CUSTOMER_NO", iMap.getBigDecimal("MUSTERI_NO"));
			cMap.put("CARD_BANK_STATUS", "All");
			cMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_GET_CARD_INFO", cMap));//CUSTOMER_NO
			
			if (cMap.get(tablo) != null) {
				for (int j = 0; j < iMap.getSize(tablo); j++) {
					if("N".equals(iMap.get(tablo, j, durum)) /*Normal*/ 
							|| "G".equals(iMap.get(tablo, j, durum)) /*gecici kapali*/)
						if(!iMap.getString(tablo, j, "CARD_NO").equals(iMap.getString("KART_NO"))) //basvurunun kart numarasi ile esit degilse
							intradaKartiVar = true;
				}
			}
			
			//mevcut baska basvurulari var mi kontrol ediliyor
			GMMap appMap = new GMMap();
			appMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
			appMap.put("MEVCUT_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			appMap =  GMServiceExecuter.call("BNSPR_TFF_GET_ODENMIS_BASVURU_LIST", appMap); //not in ('IPTAL', 'RED', 'ACIK')
			
			if((appMap != null && appMap.getSize("BASVURU_BILGILERI") == 0) && !oceandaKartiVar && !intradaKartiVar) //baska aktif basvurusu ve karti yoksa 
			{
				//basvuru ile bilet alindi mi kontrolu yapilir
				oMap.putAll(GMServiceExecuter.execute("BNSPR_CRD_TFF_GET_TICKET_SALE_LIST", iMap));
				String tableName = "CARD_SALE_LIST";
				BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
				int size = oMap.getSize(tableName);
				boolean basvuruListedeMi = false;
				if (basvuruNo != null && size >0) {
					for (int i=0; i<size; i++) {
						 if (basvuruNo.compareTo(oMap.getBigDecimal(tableName, i, "BASVURU_NO")) == 0) {
						     basvuruListedeMi = true;	  
						 }
					} 
				}
				
				if(basvuruListedeMi) //bu basvuru ile bilet alindiysa
				{
					oMap.put("MAC_BILETLI_MI_EH", CreditCardServicesUtil.EVET); 	
					oMap.put("MAC_BILETLI_MI", true);
					oMap.put("MAC_BILETI_MCM_KONTROLU", false);
				}
				else
				{
					oMap.put("MAC_BILETLI_MI_EH", CreditCardServicesUtil.HAYIR); 	
					oMap.put("MAC_BILETLI_MI", false);
					oMap.put("MAC_BILETI_MCM_KONTROLU", true);
				}
				
			}
			else //baska aktif basvurusu ya da karti varsa 
			{
				oMap.put("MAC_BILETLI_MI_EH", CreditCardServicesUtil.HAYIR); 	
				oMap.put("MAC_BILETLI_MI", false);
				oMap.put("MAC_BILETI_MCM_KONTROLU", false);
			}

			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", basvuruNo);
			}
			customerNo = tffBasvuru.getMusteriNo();
			tckn= tffBasvuru.getTcKimlikNo();
			
			caMap.put("CUSTOMER_NO", customerNo);
			caMap.put("NO_NEED_APPLICATIONS", noNeedApplications);
			caMap.put("INPUT_PARAMETER_TYPE", "CST");
			
			//M��terinin a��k passolig kart� var m�?
			GMMap IsOpenCard = new GMMap();
			IsOpenCard = GMServiceExecuter.call("BNSPR_INTRACARD_GET_TFF_CARDS_VIA_TCKN", caMap);
			
			if(IsOpenCard.getSize("CARD_DETAIL_INFO")==0){
				GMMap nMap= new GMMap();
				nMap.put("NATIONAL_ID", tckn);
				nMap.put("COUNTRY_CODE", countryCode);
				nMap = GMServiceExecuter.call("BNSPR_NETAS_BILETLEME", nMap);
				if (nMap.getBoolean("VALUE")){ //bilet varsa
					iadeYap=false;
				}
			}
			if(!oMap.getBoolean("MAC_BILETLI_MI") && !iadeYap)
				oMap.put("MAC_BILETLI_MI", true);
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	

	@GraymoundService("BNSPR_TRN3809_SANAL_POSTAN_IADE_EDILEBILIR_MI")
	public static GMMap sanalPostanIadeEdilebilirMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3809.SanalPostanIadeEdilebilirMi(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			oMap.put("IADE_EDILEBILIR_MI", stmt.getString(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3809_GET_ODEME_IADE_TIPI")
	public static GMMap getOdemeIadeTipi2(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		if("3809".equals(iMap.getString("EKRAN_KODU")))
		{
			if("D".equals(iMap.getString("ODEME_SEKLI")) || "N".equals(iMap.getString("ODEME_SEKLI")))
			{
				oMap.put("TARGET_LIST", 0, "VALUE", "");
				oMap.put("TARGET_LIST", 0, "NAME", " ");
				
				oMap.put("TARGET_LIST", 1, "VALUE", "H");
				oMap.put("TARGET_LIST", 1, "NAME", "Hesap");
				
				oMap.put("TARGET_LIST", 2, "VALUE", "P");
				oMap.put("TARGET_LIST", 2, "NAME", "Prepaid Kart");
				
				oMap.put("TARGET_LIST", 3, "VALUE", "C");
				oMap.put("TARGET_LIST", 3, "NAME", "Kredi Karti");
				
				oMap.put("TARGET_LIST", 4, "VALUE", "HE");
				oMap.put("TARGET_LIST", 4, "NAME", "Hesaba EFT");
				
				oMap.put("TARGET_LIST", 5, "VALUE", "IE");
				oMap.put("TARGET_LIST", 5, "NAME", "IBAN'a EFT");
			}
			else if("S".equals(iMap.getString("ODEME_SEKLI")) || "I".equals(iMap.getString("ODEME_SEKLI")))
			{
				oMap.put("TARGET_LIST", 0, "VALUE", "S");
				oMap.put("TARGET_LIST", 0, "NAME", "Sanal Pos");
			}
			else
			{
				oMap.put("TARGET_LIST", 0, "VALUE", "");
				oMap.put("TARGET_LIST", 0, "NAME", " ");
				
				oMap.put("TARGET_LIST", 1, "VALUE", "HE");
				oMap.put("TARGET_LIST", 1, "NAME", "Hesaba EFT");
				
				oMap.put("TARGET_LIST", 2, "VALUE", "IE");
				oMap.put("TARGET_LIST", 2, "NAME", "IBAN'a EFT");
				
				oMap.put("TARGET_LIST", 3, "VALUE", "C");
				oMap.put("TARGET_LIST", 3, "NAME", "Kredi Kart�");
			
				oMap.put("TARGET_LIST", 4, "VALUE", "P");
				oMap.put("TARGET_LIST", 4, "NAME", "Prepaid Kart");
					
				oMap.put("TARGET_LIST", 5, "VALUE", "H");
				oMap.put("TARGET_LIST", 5, "NAME", "Hesap");
				
				oMap.put("TARGET_LIST", 6, "VALUE", "B");
				oMap.put("TARGET_LIST", 6, "NAME", "Ba�vuru");
				
				oMap.put("TARGET_LIST", 7, "VALUE", "S");
				oMap.put("TARGET_LIST", 7, "NAME", "Sanal Pos");				
			}
		}
		else if("4448".equals(iMap.getString("EKRAN_KODU")))
		{
			if("D".equals(iMap.getString("ODEME_SEKLI")) || "N".equals(iMap.getString("ODEME_SEKLI")))
			{
				oMap.put("TARGET_LIST", 0, "VALUE", "");
				oMap.put("TARGET_LIST", 0, "NAME", " ");
				
				oMap.put("TARGET_LIST", 1, "VALUE", "HE");
				oMap.put("TARGET_LIST", 1, "NAME", "Hesaba EFT");
				
				oMap.put("TARGET_LIST", 2, "VALUE", "IE");
				oMap.put("TARGET_LIST", 2, "NAME", "IBAN'a EFT");
				
				oMap.put("TARGET_LIST", 3, "VALUE", "C");
				oMap.put("TARGET_LIST", 3, "NAME", "Kredi Kart�");
			
				oMap.put("TARGET_LIST", 4, "VALUE", "P");
				oMap.put("TARGET_LIST", 4, "NAME", "Prepaid Kart");
					
				oMap.put("TARGET_LIST", 5, "VALUE", "H");
				oMap.put("TARGET_LIST", 5, "NAME", "Hesap");
				
				oMap.put("TARGET_LIST", 6, "VALUE", "B");
				oMap.put("TARGET_LIST", 6, "NAME", "Ba�vuru");
			}
			else if("S".equals(iMap.getString("ODEME_SEKLI")) || "I".equals(iMap.getString("ODEME_SEKLI")))
			{
				oMap.put("TARGET_LIST", 0, "VALUE", "");
				oMap.put("TARGET_LIST", 0, "NAME", " ");
				
				oMap.put("TARGET_LIST", 1, "VALUE", "S");
				oMap.put("TARGET_LIST", 1, "NAME", "Sanal Pos");
				
				oMap.put("TARGET_LIST", 2, "VALUE", "HE");
				oMap.put("TARGET_LIST", 2, "NAME", "Hesaba EFT");
				
				oMap.put("TARGET_LIST", 3, "VALUE", "IE");
				oMap.put("TARGET_LIST", 3, "NAME", "IBAN'a EFT");
				
				oMap.put("TARGET_LIST", 4, "VALUE", "C");
				oMap.put("TARGET_LIST", 4, "NAME", "Kredi Kart�");
			
				oMap.put("TARGET_LIST", 5, "VALUE", "P");
				oMap.put("TARGET_LIST", 5, "NAME", "Prepaid Kart");
					
				oMap.put("TARGET_LIST", 6, "VALUE", "H");
				oMap.put("TARGET_LIST", 6, "NAME", "Hesap");
				
				oMap.put("TARGET_LIST", 7, "VALUE", "B");
				oMap.put("TARGET_LIST", 7, "NAME", "Ba�vuru");
			}
			else
			{
				oMap.put("TARGET_LIST", 0, "VALUE", "");
				oMap.put("TARGET_LIST", 0, "NAME", " ");
				
				oMap.put("TARGET_LIST", 1, "VALUE", "HE");
				oMap.put("TARGET_LIST", 1, "NAME", "Hesaba EFT");
				
				oMap.put("TARGET_LIST", 2, "VALUE", "IE");
				oMap.put("TARGET_LIST", 2, "NAME", "IBAN'a EFT");
				
				oMap.put("TARGET_LIST", 3, "VALUE", "C");
				oMap.put("TARGET_LIST", 3, "NAME", "Kredi Kart�");
			
				oMap.put("TARGET_LIST", 4, "VALUE", "P");
				oMap.put("TARGET_LIST", 4, "NAME", "Prepaid Kart");
					
				oMap.put("TARGET_LIST", 5, "VALUE", "H");
				oMap.put("TARGET_LIST", 5, "NAME", "Hesap");
				
				oMap.put("TARGET_LIST", 6, "VALUE", "B");
				oMap.put("TARGET_LIST", 6, "NAME", "Ba�vuru");
				
				oMap.put("TARGET_LIST", 7, "VALUE", "S");
				oMap.put("TARGET_LIST", 7, "NAME", "Sanal Pos");				
			}
		}
			
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3809_BASVURU_UCRET_IADE")
	public static GMMap basvuruUcretininIadesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {		
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Odeme Bilgisini Al
			TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuruOdeme == null) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Odemesi Yapilmamis");
				return oMap;
			}
			
			if("3813".equals(iMap.getString("ISLEM_KOD")) 
					|| (!"3813".equals(iMap.getString("ISLEM_KOD")) && ("S".equals(tffBasvuruOdeme.getOdemeSekli()) || "I".equals(tffBasvuruOdeme.getOdemeSekli()))))
			{
				iMap.put("APPLICATION_NO", iMap.getBigDecimal("BASVURU_NO"));
				iMap.put("EKRAN_KODU", "3819");
				
				try {
					iMap.put("IADE_EDILECEK_BEDEL", iMap.get("BASVURU_BEDELI"));
					iMap.put("IADE_EDILECEK_BAKIYE", iMap.get("BASVURU_BAKIYESI"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CRD_TFF_APP_FEE_TRANSFER", iMap));
					
					//Iade islem numarasini odeme tablosuna yaz.
					oMap.put("IADE_TRX_NO", sorguMap.getBigDecimal("TRX_NO"));
					tffBasvuruOdeme.setIadeIslemNo(sorguMap.getBigDecimal("TRX_NO"));
					session.saveOrUpdate(tffBasvuruOdeme);
					session.flush();
				}
				catch (GMRuntimeException e) { //iade hatali
					if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
						throw ExceptionHandler.convertException(e);
					} else {
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", e.getMessage());
						return oMap;
					}
				}
				catch (Exception e) { //iade hatali
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", sorguMap.getString("MESSAGE"));
					return oMap;
				}
			}
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", e.getMessage());
				return oMap;
			}
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		return oMap;
	}	
	
	@GraymoundService("BNSPR_TFF_BASVURU_IADE_BILGILERI")
	public static GMMap getBasvuruIadeBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
		BigDecimal appNo = iMap.getBigDecimal("BASVURU_NO");	

		try {
			String procStr = "{call BNSPR.PKG_TRN3809.Get_BasvuruIadeBilgileri (?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[4];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = customerNo;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = appNo;			
			i = 0;
			Object[] outputValues = new Object[2];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "LIST";
			 

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.put("MUSTERI_NO", customerNo);
			oMap.put("BASVURU_NO", appNo);
			oMap.put("AD_SOYAD", oMap.getString("LIST", 0, "AD_SOYAD"));
			oMap.put("CEP_TEL_NO", oMap.getString("LIST", 0, "CEP_TEL"));
			oMap.put("URUN_ADI", oMap.getString("LIST", 0, "URUN_ADI"));
			oMap.put("APP_PRODUCT_NAME", oMap.getString("LIST", 0, "URUN_ADI"));
			oMap.put("BASVURU_BEDELI", oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI"));
			oMap.put("BASVURU_BAKIYESI", oMap.getBigDecimal("LIST", 0, "BASVURU_BAKIYESI"));
			oMap.put("NAKIT_IADE_BAKIYE", oMap.getBigDecimal("LIST", 0, "NAKIT_IADE_BAKIYE"));
			oMap.put("BASVURU_BEDELI_TX", oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI"));
			oMap.put("BASVURU_BAKIYESI_TX", oMap.getBigDecimal("LIST", 0, "BASVURU_BAKIYESI"));			
			oMap.put("MANUEL_IADE_BASVURU_BAKIYESI", oMap.getBigDecimal("LIST", 0, "MANUEL_IADE_BASVURU_BAKIYESI"));
			oMap.put("TOPLAM_TUTAR", oMap.getBigDecimal("LIST", 0, "BASVURU_BAKIYESI").add(oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI")));
			oMap.put("TOPLAM_IADE_BAKIYE", oMap.getBigDecimal("LIST", 0, "BASVURU_BAKIYESI")
					.add(oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI"))
					.add(oMap.getBigDecimal("LIST", 0, "NAKIT_IADE_BAKIYE"))
					.add(oMap.getBigDecimal("LIST", 0, "MANUEL_IADE_BASVURU_BAKIYESI")));
			oMap.put("IADE_YAPILSIN_MI", !(oMap.getBigDecimal("TOPLAM_TUTAR").equals(BigDecimal.ZERO)));
			oMap.put("TUMU_PROMOSYONLU", (oMap.getBigDecimal("TOPLAM_TUTAR").equals(BigDecimal.ZERO)) && !(oMap.getBigDecimal("LIST", 0, "PROMOSYON_BEDELI").equals(BigDecimal.ZERO)));
			oMap.put("TARGET_CODE", oMap.getString("LIST", 0, "TARGET_CODE"));
			oMap.put("SANAL_POS_TYPE", oMap.getString("LIST", 0, "SANAL_POS_TYPE"));
			if("S".equals(oMap.getString("LIST", 0, "TARGET_CODE")))
			{
				oMap.put("TARGET_NO", GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", new GMMap().put("KOD", "TFF_BASVURU_BDL_IADE_POS_ALACK")).getString("DEGER")); 
				if(oMap.getString("LIST", 0, "SANAL_POS_TYPE") != null && !oMap.getString("LIST", 0, "SANAL_POS_TYPE").isEmpty())
				{
					oMap.put("SANAL_POS_ODEME_REF_ID", oMap.getString("LIST", 0, "SANAL_POS_ODEME_REF_ID"));
					oMap.put("SANAL_POS_REF_ID", oMap.getString("LIST", 0, "SANAL_POS_ODEME_REF_ID"));
					if("E".equals(GMServiceExecuter.call("BNSPR_TRN3809_SANAL_POSTAN_IADE_EDILEBILIR_MI", iMap).getString("IADE_EDILEBILIR_MI")))
						oMap.put("SANAL_POS_REF_UYUMSUZ", false);
					else
						oMap.put("SANAL_POS_REF_UYUMSUZ", true);
				}
				else
					oMap.put("SANAL_POS_REF_UYUMSUZ", true);
			}
			else
				oMap.put("SANAL_POS_REF_UYUMSUZ", false);
			
			//Mac Biletli Mi Kontrol�
			GMMap sorguMap = new GMMap();
			sorguMap.put("BASVURU_NO", appNo);
			sorguMap.put("MUSTERI_NO", customerNo);
			sorguMap.put("CARD_NO", iMap.getString("KART_NO"));			
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRN3809_MAC_BILETLI_MI", sorguMap));
			oMap.put("MAC_BILETLI_MI", sorguMap.getBoolean("MAC_BILETLI_MI"));
			if(BigDecimal.ZERO.equals(oMap.getBigDecimal("BASVURU_BEDELI")))
				oMap.put("MAC_BILETI_MCM_KONTROLU", false);
			else
				oMap.put("MAC_BILETI_MCM_KONTROLU", sorguMap.getBoolean("MAC_BILETI_MCM_KONTROLU"));
			
			//mac biletliler icin durum kontrolu
//			if("E".equals(oMap.getString("MAC_BILETLI_MI")) && "E".equals(oMap.getString("LIST", 0, "ODEME_YAPILDI_MI"))) //odeme yapilmissa mevcut kartlari kontrol edilecek
//			{
//		  		String tablo = "CARD_DETAIL_INFO";
//		  		String durum = "CARD_STAT_CODE";
//		  		String altDurum = "CARD_SUB_STAT_CODE";
//		  		
//		  		//oceandaki kartlari kontrol ediliyor
//				GMMap cMap = new GMMap();
//				cMap.put("CUSTOMER_NO", customerNo);
//				cMap.put("CARD_DCI", "C");
//				cMap.put("CARD_BANK_STATUS", "All");
//				cMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", cMap));//CUSTOMER_NO
//				
//				if (cMap.get(tablo) != null) {
//					for (int j = 0; j < iMap.getSize(tablo); j++) {
//						if(("N".equals(iMap.get(tablo, j, durum)) && "N".equals(iMap.get(tablo, j, altDurum))) /*Normal*/ 
//								|| ("G".equals(iMap.get(tablo, j, durum)) && "N".equals(iMap.get(tablo, j, altDurum))) /*gecici kapali*/)
//							if(!iMap.getString(tablo, j, "CARD_NO").equals(iMap.getString("KART_NO"))) //basvurunun kart numarasi ile esit degilse
//								oMap.put("MAC_BILETLI_MI", false);
//					}
//				}
//				
//				if("E".equals(oMap.getString("MAC_BILETLI_MI")))
//				{
//					//intradaki kartlari kontrol ediliyor
//					cMap.clear();
//					cMap.put("CUSTOMER_NO", customerNo);
//					cMap.put("CARD_BANK_STATUS", "All");
//					cMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_GET_CARD_INFO", cMap));//CUSTOMER_NO
//					
//					if (cMap.get(tablo) != null) {
//						for (int j = 0; j < iMap.getSize(tablo); j++) {
//							if(("N".equals(iMap.get(tablo, j, durum)) && "N".equals(iMap.get(tablo, j, altDurum))) /*Normal*/ 
//									|| ("G".equals(iMap.get(tablo, j, durum)) && "N".equals(iMap.get(tablo, j, altDurum))) /*gecici kapali*/)
//								if(!iMap.getString(tablo, j, "CARD_NO").equals(iMap.getString("KART_NO"))) //basvurunun kart numarasi ile esit degilse
//									oMap.put("MAC_BILETLI_MI", false);
//						}
//					}
//				}
//			}
			
			//onceden iade edildi mi kontrolu
			sorguMap.clear();
			sorguMap.put("APPLICATION_NO", appNo);
			sorguMap.put("BASVURU_BEDELI", oMap.getBigDecimal("LIST", 0, "BASVURU_BEDELI"));	
			sorguMap.put("HATA_VERILSIN", "H");
			oMap.put("ONCEDEN_IADE_EDILMIS_MI", GMServiceExecuter.call("BNSPR_CRD_TFF_APP_FEE_CHECK_EXISTING_TX", sorguMap).getBoolean("IADE_EDILMIS")); 
			
			//kart basilmis mi kontrolu
			sorguMap.clear();
			if("BASIM".equals(oMap.getString("LIST", 0, "DURUM_KODU"))) //basvurunun durumu basim ise kart paketindeki durumu sorgulanacak
			{
				sorguMap.put("DURUM_KODU", oMap.getString("LIST", 0, "DURUM_KODU"));
				sorguMap.put("CARD_NO", iMap.getString("KART_NO"));
				sorguMap.putAll(GMServiceExecuter.call("BNSPR_TFF_BASVURU_KART_DURUM_BILGISI", sorguMap));
				if("G".equals(sorguMap.getString("KART_DURUM_KOD")) &&  "G".equals(sorguMap.getString("KART_ALT_DURUM_KOD")))
					oMap.put("KART_BASILMIS_MI", true);
				else
					oMap.put("KART_BASILMIS_MI", false);
			}
			else
				oMap.put("KART_BASILMIS_MI", false);
			
			oMap.put("IADE_YAPILABILIR_MI", !(oMap.getBoolean("KART_BASILMIS_MI") || oMap.getBoolean("ONCEDEN_IADE_EDILMIS_MI") || oMap.getBoolean("MAC_BILETLI_MI") || oMap.getBoolean("SANAL_POS_REF_UYUMSUZ")));
			
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);	
		}
		catch (Exception ex){
			ex.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.KARA_LISTE_KONTROL_GENEL_HATA);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3809_AFTER_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3809.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/**Basvuru iptal edildiginde EVAM ve ININ de acik cagrilari kapatir<br>
	 * @author murat.el
	 * @since TY-3804
	 * @param iMap - Tff basvuru iptal islemi bilgileri<br>
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 *        <li>DURUM_KOD - Tff basvuru durum kodu
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3809_EVENT_IPTAL")
	public static GMMap eventIptal(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//TFF basvurusunu al
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				logger.error("Event iptali icin basvuru bulunamadi. Basvuru No : " +  iMap.getBigDecimal("BASVURU_NO"));
				return oMap;
			}
			//
			GMMap sorguMap = new GMMap();
			String durumKod = CreditCardServicesUtil.nvl(iMap.getString("DURUM_KOD"), tffBasvuru.getDurumKod());
			//ININ acik cagrilari kapat
			if ("VERI_TAMAMLAMA".equals(durumKod) || "ON_BASVURU".equals(durumKod)) {
				String callType = null;
				if ("VERI_TAMAMLAMA".equals(durumKod)) {
					callType = "KART_VERI_TAMAMLAMA";
				} else {
					callType = "AKTIF_NOKTA_KISA_BASVURU";
				}
				
				sorguMap.clear();
				sorguMap.put("CUSTOMER_ID", tffBasvuru.getBasvuruNo());
				sorguMap.put("CALL_TYPE", callType);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXT_DIALER_DISPOSE_CALL", sorguMap));
			}
			
			//EVAM acik cagrilari kapat
			if ("VERI_TAMAMLAMA".equals(durumKod) || "ON_BASVURU".equals(durumKod) || "FOTO_EKSIK".equals(durumKod)) {
				//EVAM
				String eventRefNo = tffBasvuru.getBasvuruNo().toString();
				if ("VERI_TAMAMLAMA".equals(durumKod) && 
						CreditCardTffServices.TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
					eventRefNo = tffBasvuru.getKkBasvuruNo().toString();
				}
				
				sorguMap.clear();
				sorguMap.put("EVENT_TYPE_NO", BASVURU_IPTAL_EVENT_TYPE_NO);
				sorguMap.put("EVENT_REF_NO", eventRefNo);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.error("Event iptali yapilirken hata olustu. Basvuru No : " +  iMap.getBigDecimal("BASVURU_NO"));
		}

		return oMap;
	}
	
	/** Iptal edilecek basvuruya gidecek sms bilgilerini alir.<br>
	 * @author murat.el
	 * @since TY-3861
	 * @param iMap - Tff basvuru bilgisi<br>
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Sms bilgisi<br>
	 * 		  <li>MESAJ - Sms icerigi
	 * 		  <li>CEP_NO - Basvuruda verilen cep numarasi
	 */
	private static GMMap smsBilgiAl(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call pkg_trn3809.Sms_Bilgisi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
            stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();
            //Bilgileri al
            oMap.put("MESAJ", stmt.getString(2));
            oMap.put("CEP_NO", stmt.getString(3));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3809_UCRET_IADE_RED")
	public static GMMap ucretIadeRed(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruIptalTx tffBasvuruIptalTx = (TffBasvuruIptalTx) session.createCriteria(TffBasvuruIptalTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if(tffBasvuruIptalTx != null)
			{
				if(tffBasvuruIptalTx.getIadeIslemNo() != null)
				{
					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "OR");
					onayMap.put("ISLEM_NO", tffBasvuruIptalTx.getIadeIslemNo());
					oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
				}
				
				tffBasvuruIptalTx.setMacBiletiVarMi("VAR");
				session.save(tffBasvuruIptalTx);
				session.flush();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.error("3809 ucret iade red edilirken hata aldi. Basvuru No : " +  iMap.getBigDecimal("BASVURU_NO"));
		}

		return oMap;
	}	
	
	@GraymoundService("BNSPR_TRN3809_UCRET_IADE_ONAY")
	public static GMMap ucretIadeOnay(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruIptalTx tffBasvuruIptalTx = (TffBasvuruIptalTx) session.createCriteria(TffBasvuruIptalTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.isNotNull("iadeIslemNo")).uniqueResult();

			if(tffBasvuruIptalTx != null)
			{
				Boolean otomatikIadeBasarili = true;
				
				if(tffBasvuruIptalTx.getIadeIslemNo() != null)
				{
					try
					{
						GMMap onayMap = new GMMap();
						onayMap.put("ISLEM_TURU", "O");
						onayMap.put("ISLEM_NO", tffBasvuruIptalTx.getIadeIslemNo());
						oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
					}
					catch (Exception e) {
						otomatikIadeBasarili = false;
						e.printStackTrace();
						logger.error("3809 ucret iade onaylanirken hata aldi. Basvuru No : " +  iMap.getBigDecimal("BASVURU_NO"));
					}
				}
				if(tffBasvuruIptalTx.getIadeIslemNo() == null || !otomatikIadeBasarili)
				{
					//Basvuru bilgisini al
					TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruIptalTx.getBasvuruNo());
					if (tffBasvuru == null) {
						CreditCardServicesUtil.raiseGMError("2999", tffBasvuruIptalTx.getBasvuruNo());
					}
					
					TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, tffBasvuruIptalTx.getBasvuruNo());
					
					if (!("A".equals(tffBasvuru.getKuryeTipi()) && "NTS01".equals(tffBasvuru.getSource()))) {
						
						if("H".equals(tffBasvuruIptalTx.getIadeYapilsinMi()) || ("E".equals(tffBasvuruIptalTx.getIadeYapilsinMi()) && (tffBasvuruIptalTx.getIadeIslemNo() == null || !otomatikIadeBasarili))) // otomatik iade yapilmadiysa 
						{
							GMMap sorguMap = new GMMap();
							sorguMap.put("KOD", "TFF_WEBSERVIS_PARAM");
							sorguMap.put("KEY1", tffBasvuruOdeme.getOdemeSekli());
							sorguMap.put("KEY2", "ODEME_TIPI");
							String odemeSekli = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");
	
							StringBuilder mailBody = null;
							
							mailBody = new StringBuilder();
							mailBody.append(tffBasvuruOdeme.getBasvuruNo());
							mailBody.append(" no'lu TFF basvurusunun ");
							mailBody.append(odemeSekli);
							mailBody.append(" ile yapilan ");
							mailBody.append(tffBasvuruOdeme.getOdemeRefId());
							mailBody.append(" referansli islemi iptal edilmistir.");
							mailBody.append(" Manuel iade surecini baslatiniz.");
							mailBody.append("\n");
							mailBody.append(" Islem Aciklamasi: ");
							mailBody.append("\n");
							mailBody.append(tffBasvuruIptalTx.getAciklama());
					
							sorguMap.clear();
							sorguMap.put("MAIL_TO_PARAM", "TFF_BASVURU_IPTAL_MAIL_TO");
							sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
							sorguMap.put("MAIL_SUBJECT", "TFF Basvuru Manuel Iptal - " + tffBasvuruIptalTx.getBasvuruNo().toString());
							sorguMap.put("MAIL_BODY", mailBody);
							GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
						}
					}
					
					//TY-3861- Sanal pos iadesi yapilanlara sms gonderilsin
					if ("S".equals(tffBasvuruOdeme.getOdemeSekli()) && tffBasvuruIptalTx.getIadeIslemNo() != null && otomatikIadeBasarili) {
						GMMap sorguMap = new GMMap();
						sorguMap.put("BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
						sorguMap.putAll(smsBilgiAl(sorguMap));
						String cepNo = sorguMap.getString("CEP_NO");
						String mesaj = sorguMap.getString("MESAJ");
						//Cep numarasi var ise smsi gonder
						if (StringUtils.isNotBlank(cepNo) && StringUtils.isNotBlank(mesaj)) {
							sorguMap.clear();
							sorguMap.put("GIDEN_MESAJ", mesaj);
							sorguMap.put("CEP_NO",cepNo);
					        oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
						}
					}
				}
				
				tffBasvuruIptalTx.setMacBiletiVarMi("YOK");
				session.save(tffBasvuruIptalTx);
				session.flush();
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logger.error("3809 ucret iade onaylanirken hata aldi. Basvuru No : " +  iMap.getBigDecimal("BASVURU_NO"));
		}

		return oMap;
	}
	
	/** Iptal basvuru bakiye/iade tutar bilgilerini listeler<br>
	 * @author murat.el
	 * @since TY-4931
	 * @param iMap - Tff basvuru iptal islemi bilgileri<br>
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3809_LIST_IPTAL_BASVURU_TUTAR_BILGI")
	public static GMMap listBasvuruBedeliTutarBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("CUSTOMER_NO")) ) {
				CreditCardServicesUtil.raiseGMError("330", "Musteri No");
			}

			BigDecimal musteriNo = iMap.getBigDecimal("CUSTOMER_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			
			//Iptal olmus isleme girebilecek basvurulari listele
			GMMap basvuruMap = new GMMap();
			basvuruMap.put("MUSTERI_NO", musteriNo);
			basvuruMap.put("BASVURU_NO", basvuruNo);
			basvuruMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_LIST_IPTAL_BASVURU", basvuruMap));
			//Ekstra istenmis
			oMap.put("CEP_TEL_NO", basvuruMap.get("LIST", 0, "CEP_TEL"));
			//Basvurular icin ucret/bakiye bilgilerini al
			GMMap sorguMap = new GMMap();
			int listIndex = 0;
			for (int i = 0; i < basvuruMap.getSize("LIST"); i++) {
				//Basvuru bedelini al
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", basvuruMap.getBigDecimal("LIST", i, "BASVURU_NO"));
				sorguMap.putAll(getBasvuruOdemeBilgi(sorguMap));
				//Odeme icin bir tutar odendi mi, odendiyse bilgileri listele
				if (sorguMap.getBigDecimal("BASVURU_BEDELI") != null && 
						BigDecimal.ZERO.compareTo(sorguMap.getBigDecimal("BASVURU_BEDELI")) < 0) {
					oMap.put("LIST", listIndex, basvuruMap.getMap("LIST", i));
					oMap.put("LIST", listIndex, "ODEME_SEKLI", sorguMap.get("ODEME_SEKLI"));
					oMap.put("LIST", listIndex, "ODEME_TIPI", sorguMap.get("ODEME_TIPI"));
					oMap.put("LIST", listIndex, "SANAL_POS_TYPE", sorguMap.get("SANAL_POS_TYPE"));
					oMap.put("LIST", listIndex, "SANAL_POS_ODEME_REF_ID", sorguMap.get("SANAL_POS_ODEME_REF_ID"));
					oMap.put("LIST", listIndex, "BASVURU_BEDELI", sorguMap.get("BASVURU_BEDELI"));
					oMap.put("LIST", listIndex, "BASVURU_BAKIYESI", sorguMap.get("BASVURU_BAKIYESI"));
					oMap.put("LIST", listIndex, "IADE_DURUM", sorguMap.get("IADE_DURUM"));
					oMap.put("LIST", listIndex, "IADE_TARIH", sorguMap.get("IADE_TARIH"));
					listIndex++;
				}
				//nakit topup bakiyesini al
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", basvuruMap.getBigDecimal("LIST", i, "BASVURU_NO"));
				sorguMap.putAll(getBasvuruNakitBakiye(sorguMap));
				//nakit bakiye var mi, varsa bilgileri listele
				if (sorguMap.getBigDecimal("BASVURU_BAKIYESI") != null && 
						BigDecimal.ZERO.compareTo(sorguMap.getBigDecimal("BASVURU_BAKIYESI")) < 0) {
					oMap.put("LIST", listIndex, basvuruMap.getMap("LIST", i));
					oMap.put("LIST", listIndex, "ODEME_SEKLI", sorguMap.get("ODEME_SEKLI"));
					oMap.put("LIST", listIndex, "ODEME_TIPI", sorguMap.get("ODEME_TIPI"));
					oMap.put("LIST", listIndex, "SANAL_POS_TYPE", sorguMap.get("SANAL_POS_TYPE"));
					oMap.put("LIST", listIndex, "SANAL_POS_ODEME_REF_ID", sorguMap.get("SANAL_POS_ODEME_REF_ID"));
					oMap.put("LIST", listIndex, "BASVURU_BEDELI", sorguMap.get("BASVURU_BEDELI"));
					oMap.put("LIST", listIndex, "BASVURU_BAKIYESI", sorguMap.get("BASVURU_BAKIYESI"));
					oMap.put("LIST", listIndex, "IADE_DURUM", StringUtils.EMPTY);
					oMap.put("LIST", listIndex, "IADE_TARIH", StringUtils.EMPTY);
					listIndex++;
				}
				//sanal topup bakiyesini al
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", basvuruMap.getBigDecimal("LIST", i, "BASVURU_NO"));
				sorguMap.putAll(getBasvuruSanalBakiye(sorguMap));
				//sanal bakiye var mi, varsa bilgileri listele
				for (int j = 0; j < sorguMap.getSize("SANAL_BAKIYE_LIST"); j++) {
					if (sorguMap.getBigDecimal("SANAL_BAKIYE_LIST", j, "BASVURU_BAKIYESI") != null && 
							BigDecimal.ZERO.compareTo(sorguMap.getBigDecimal("SANAL_BAKIYE_LIST", j, "BASVURU_BAKIYESI")) < 0) {
						oMap.put("LIST", listIndex, basvuruMap.getMap("LIST", i));
						oMap.put("LIST", listIndex, "ODEME_SEKLI", sorguMap.get("SANAL_BAKIYE_LIST", j, "ODEME_SEKLI"));
						oMap.put("LIST", listIndex, "ODEME_TIPI", sorguMap.get("SANAL_BAKIYE_LIST", j, "ODEME_TIPI"));
						oMap.put("LIST", listIndex, "SANAL_POS_TYPE", sorguMap.get("SANAL_BAKIYE_LIST", j, "SANAL_POS_TYPE"));
						oMap.put("LIST", listIndex, "SANAL_POS_ODEME_REF_ID", sorguMap.get("SANAL_BAKIYE_LIST", j, "SANAL_POS_ODEME_REF_ID"));
						oMap.put("LIST", listIndex, "BASVURU_BEDELI", sorguMap.get("SANAL_BAKIYE_LIST", j, "BASVURU_BEDELI"));
						oMap.put("LIST", listIndex, "BASVURU_BAKIYESI", sorguMap.get("SANAL_BAKIYE_LIST", j, "BASVURU_BAKIYESI"));
						oMap.put("LIST", listIndex, "IADE_DURUM", StringUtils.EMPTY);
						oMap.put("LIST", listIndex, "IADE_TARIH", StringUtils.EMPTY);
						listIndex++;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3809_LIST_IPTAL_BASVURU")
	public static GMMap listIptalBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3809.list_basvuru_for_iade(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static GMMap getBasvuruOdemeBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3809.get_basvuru_odeme_bilgi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static GMMap getBasvuruNakitBakiye(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3809.get_basvuru_nakit_bakiye(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static GMMap getBasvuruSanalBakiye(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3809.get_basvuru_sanal_bakiye(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "SANAL_BAKIYE_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
}
