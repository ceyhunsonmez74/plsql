package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KartBasvuruVeriKntlDtyTx;
import tr.com.aktifbank.bnspr.dao.KartBasvuruVeriKntlTx;
import tr.com.aktifbank.bnspr.dao.KartBasvuruVeriTmmlTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** TFF basvurusu veri tamamlama islemlerini gerceklestiren servisleri icerir.
*
* @author murat.el
* @since 26.11.2013
*
*/
public class CreditCardTRN3806Services {
	
	/** Veri kontrol sonucu uygun */
	private static final String UYGUN = "1";
	//private static final String UYGUN_DEGIL = "2";
	//private static final String EKSIK = "3";
	
	private static final String ISLEM_SONRASI_MESAJ = "ISLEM_SONRASI_MESAJ";
	private static final Logger logger = Logger.getLogger(CreditCardTRN3806Services.class);
	/** Ekran ilk degerlerini al
	 *
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap
	 * @return oMap - IL_LIST, AKSIYON_KOD_TFF, AKSIYON_KOD_KK
	 */
	@GraymoundService("BNSPR_TRN3806_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Il
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_ILLER", iMap));//IL_LIST
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3806_GET_OUTBOUND_AGENT_CODES", iMap));
			
			//Aksiyon TFF
			oMap.putAll(CreditCardServicesUtil.getParameterList("AKSIYON_KOD_TFF", "KART_VERI_KONTROL_AKSIYON", "TFF", CreditCardServicesUtil.EVET));
			
			//Aksiyon KK
			StringBuilder query = new StringBuilder();
			query.append(" SELECT t.key1,t.text");
			query.append(" FROM v_ml_gnl_param_text t");
			query.append(" WHERE t.kod = 'KART_VERI_KONTROL_AKSIYON'");
			query.append(" AND t.key3 = 'KK'");
			query.append(" ORDER BY t.sira_no");
			DALUtil.fillComboBox(oMap, "AKSIYON_KOD_KK", true, query.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Veri tamamlama islemi icin verilen musteri numarasina gore musterinin tff basvuru bilgilerini getirir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - MUSTERI_NO
	 * @return oMap - BASVURU_LIST
	 */
	@GraymoundService("BNSPR_TRN3806_GET_BASVURU_INFO")
	public static GMMap getBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3806.Rc_Qry3806_Get_Basvuru(?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, "BASVURU_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Verilen islem numarasina ait anne kizlik soyadi, ev/is adresi veri kontrol isleminin sonuclarini degerleri ile listeler.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - TRX_NO
	 * @return oMap - BASVURU_NO, KART_TIPI, Alan Durumlari, Alan Degerleri
	 */
	@GraymoundService("BNSPR_TRN3806_GET_VERI_KONTROL_INFO")
	public static GMMap getVeriKontrolInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		String degerStr = "_DEGER";
		String durumStr = "_DURUM";
		String aciklamaStr = "_ACIKLAMA";
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Kontrol bilgilerini al
			KartBasvuruVeriKntlTx kartBasvuruVeriKntlTx = (KartBasvuruVeriKntlTx)
					session.get(KartBasvuruVeriKntlTx.class, trxNo);
			if (kartBasvuruVeriKntlTx != null) {
				oMap.put("BASVURU_NO", kartBasvuruVeriKntlTx.getBasvuruNo());
				oMap.put("KART_TIPI", kartBasvuruVeriKntlTx.getKartTipi());
			}
			
			//Kontrol edilen alanlari al
			List<?> veriKontrolList = session.createCriteria(KartBasvuruVeriKntlDtyTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
			//Kontrol edilen alanlari ekranda set et.
			for (Object object : veriKontrolList) {
				KartBasvuruVeriKntlDtyTx tx = (KartBasvuruVeriKntlDtyTx) object;
				oMap.put(tx.getId().getAlanKodu() + degerStr, tx.getDeger());
				oMap.put(tx.getId().getAlanKodu() + aciklamaStr, tx.getAciklama());
				
				//Durumu check edilmisse bir daha kontrol edilmesine gerek yok
				if (UYGUN.equals(tx.getDurum())) {
					oMap.put(tx.getId().getAlanKodu() + durumStr, 0);
				//Yeni deger alinacak.
				} else {
					oMap.put(tx.getId().getAlanKodu() + durumStr, 1);
				}
			}
			
			//Kontrol edilen alan degilse veri tamamlama islemi yapma.
			oMap.put("ADRES1_DURUM", oMap.getString("ADRES1_DURUM", "0"));
			oMap.put("ADRES2_DURUM", oMap.getString("ADRES2_DURUM", "0"));
			oMap.put("ADRES3_DURUM", oMap.getString("ADRES3_DURUM", "0"));
			oMap.put("EV_TEL_DURUM", oMap.getString("EV_TEL_DURUM", "0"));
			oMap.put("IS_TEL_DURUM", oMap.getString("IS_TEL_DURUM", "0"));
			oMap.put("ISYERI_ADI_DURUM", oMap.getString("ISYERI_ADI_DURUM", "0"));

		    //Foto alanini al
			iMap.put("FILE_PATH", oMap.get("FOTO_DEGER"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_GET_FOTO", iMap));
			
			//Adres alanini parcala
			oMap.putAll(CreditCardTRN3805Services.parseAdresToAlanlar(oMap.getString("ADRES1_DEGER"), "1", "/"));
			oMap.putAll(CreditCardTRN3805Services.parseAdresToAlanlar(oMap.getString("ADRES2_DEGER"), "2", "/"));
			oMap.putAll(CreditCardTRN3805Services.parseAdresToAlanlar(oMap.getString("ADRES3_DEGER"), "3", "/"));
			
			//islemi al
			oMap.put("TRX_NO", trxNo);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Verilen islem numarasina ait anne kizlik soyadi, ev/is adresi veri kontrol isleminin sonuclarini degerleri ile listeler.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - TRX_NO
	 * @return oMap - AKSIYON_KOD, ACIKLAMA, VERI_KONTROL_TX_NO, Alan Yeni Degerleri
	 */
	@GraymoundService("BNSPR_TRN3806_GET_VERI_TAMAMLAMA_INFO")
	public static GMMap getVeriTamamlamaInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		String degerStr = "_DEGER";
		String durumStr = "_DURUM";
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Veri tamamlama islemi bilgisini al
			KartBasvuruVeriTmmlTx kartBasvuruVeriTmmlTx = (KartBasvuruVeriTmmlTx)
					session.get(KartBasvuruVeriTmmlTx.class, trxNo);
			if (kartBasvuruVeriTmmlTx != null) {
				oMap.put("AKSIYON_KOD", kartBasvuruVeriTmmlTx.getAksiyonKod());
				oMap.put("ACIKLAMA", kartBasvuruVeriTmmlTx.getAciklama());
				oMap.put("VERI_KONTROL_TX_NO", kartBasvuruVeriTmmlTx.getVeriKontrolTxNo());
			}
			
			//Kontrol edilen alanlari al
			List<?> veriTamamlamaList = session.createCriteria(KartBasvuruVeriKntlDtyTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
			//Kontrol edilen alanlari ekranda set et.
			for (Object object : veriTamamlamaList) {
				KartBasvuruVeriKntlDtyTx tx = (KartBasvuruVeriKntlDtyTx) object;
				oMap.put(tx.getId().getAlanKodu() + degerStr, tx.getDeger());
				
				//Durumu check edilmisse bir daha kontrol edilmesine gerek yok
				if (UYGUN.equals(tx.getDurum())) {
					oMap.put(tx.getId().getAlanKodu() + durumStr, 0);
				//Yeni deger alinacak.
				} else {
					oMap.put(tx.getId().getAlanKodu() + durumStr, 1);
				}
			}
			
		    //Foto alanini al
			iMap.put("FILE_PATH", kartBasvuruVeriTmmlTx.getVeriKontrolTxNo());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_GET_FOTO", iMap));
			
			//Adres alanini parcala
			oMap.putAll(CreditCardTRN3805Services.parseAdresToAlanlar(oMap.getString("ADRES1_DEGER"), "1", "/"));
			oMap.putAll(CreditCardTRN3805Services.parseAdresToAlanlar(oMap.getString("ADRES2_DEGER"), "2", "/"));
			
			//islemi al
			oMap.put("TRX_NO", trxNo);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Veri tamamlama islemi sonucunda alinan degerlerle belirtilen aksiyonu kaydeder.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - TRX_NO, VERI_KONTROL_TX_NO, AKSIYON_KOD, ACIKLAMA, Alan Yeni Degerleri
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TRN3806_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		
		try {
			//Islem tamamlanmis mi
			GMMap sorguMap = new GMMap();
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.EVET);
			GMServiceExecuter.execute("BNSPR_KK_ISLEM_TAMAMLANDI_MI", sorguMap);
			
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("VERI_KONTROL_TX_NO"))) {
				CreditCardServicesUtil.raiseGMError("1064");
			}
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Bilgileri islem tablosuna kaydet
			KartBasvuruVeriTmmlTx tx = (KartBasvuruVeriTmmlTx) session.get(KartBasvuruVeriTmmlTx.class, trxNo);
			if (tx == null) {
				tx = new KartBasvuruVeriTmmlTx();
			}
			
			tx.setTxNo(trxNo);
			tx.setVeriKontrolTxNo(iMap.getBigDecimal("VERI_KONTROL_TX_NO"));
			tx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			tx.setAciklama(CreditCardServicesUtil.trimNewLine(iMap.getString("ACIKLAMA")));
			tx.setKdhIstiyorMu(BooleanUtils.toString(iMap.getBoolean("KDH_ISTIYOR_MU"),
					CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
			session.saveOrUpdate(tx);
			
			//Save edilebilir tum alanlari al
			oMap.putAll(CreditCardTRN3805Services.getVeriKontrolAlanAdi(iMap));
			
			//Detay tablosuna kontrol edilen alanlari kaydet
			int row = 0;
			String alanKodu = null;
			String deger = null;
			String durum = null;
			while(oMap.getSize("VK_ALAN_TABLE") > row) {
				alanKodu = oMap.getString("VK_ALAN_TABLE", row, "ALAN_KODU");//Orn:FOTO
				deger = iMap.getString(alanKodu + "_YENI");//Ekrandan:FOTO_YENI
				durum = iMap.getString(alanKodu + "_DURUM");//Ekrandan:FOTO_DURUM
				
				//Durum secilmisse kaydet
				if (StringUtils.isNotBlank(durum) && iMap.getBoolean(alanKodu + "_DURUM")) {
					CreditCardTRN3805Services.saveVeriKontrolDetay(trxNo, alanKodu, deger, UYGUN, null);
				}

				row++;
			}
			session.flush();
			
			//Alan kontrollerini gerceklestir.
			afterControl(iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Veri tamamlama islemi kontrollerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since 03.12.2013
	 * @param iMap - TRX_NO
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TRN3806_AFTER_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3806.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Veri tamamlama islemini sonlandirir. Alinan aksiyona gore basvuru uzerinde islemler yapar.
	 * 
	 * @author murat.el
	 * @since 03.12.2013
	 * @param iMap - TRX_NO
	 * @return oMap - MESSAGE
	 */
	@GraymoundService("BNSPR_TRN3806_SEND_TRANSACTION")
	public static GMMap sendTransaction(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			iMap.put("TRX_NAME", "3806");
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

			//Iptal islemi ise iptal edildigini hata mesajina ekle
			oMap.put("MESSAGE", oMap.getString("MESSAGE") + ADCSession.getString(ISLEM_SONRASI_MESAJ, StringUtils.EMPTY));
			ADCSession.remove(ISLEM_SONRASI_MESAJ);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Verilen basvuru numarasina durumu veri kontrole getiren islem numarasini bulur.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - BASVURU_NO
	 * @return oMap - KK_TRX_NO
	 */
	@GraymoundService("BNSPR_TRN3806_GET_KK_TRX_NO")
	public static GMMap getKKIslemNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal kkIslemNo = null;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3806.get_kk_islem_no(?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
            stmt.execute();
            
            //Islem numarasini al
            kkIslemNo = stmt.getBigDecimal(1);
            oMap.put("KK_TRX_NO", kkIslemNo);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* ISLEM SONRASI SERVIS
	//---------------------------------------------------------------------
	/** TFF basvurusu veri tamamlama islemi tamamlandiktan sonra kart basima gonderilir ve
	 * musteriye varsa bilgilendirme smsi gonderilir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - ISLEM_NO
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TRN3806_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");
		
		try {
			//Islem numarasi verilen basvurunun veri tamamlama bilgilerini al.
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KartBasvuruVeriTmmlTx kartBasvuruVeriTmmlTx = (KartBasvuruVeriTmmlTx)
					session.get(KartBasvuruVeriTmmlTx.class, trxNo);
			if (kartBasvuruVeriTmmlTx == null) {
				return oMap;//Hata ver
			}
			
			//Veri tamamlama bilgisinden veri kontrol bilgilerine ulas.
			KartBasvuruVeriKntlTx kartBasvuruVeriKntlTx = (KartBasvuruVeriKntlTx)
					session.get(KartBasvuruVeriKntlTx.class, kartBasvuruVeriTmmlTx.getVeriKontrolTxNo());
			if (kartBasvuruVeriKntlTx == null) {
				return oMap;//Hata ver
			}
			
			//Kredi karti ise TFF basvuru bilgisini al
			TffBasvuru tffBasvuru = null;
			if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
				tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
						.add(Restrictions.eq("kkBasvuruNo", kartBasvuruVeriKntlTx.getBasvuruNo()))
						.add(Restrictions.eq("kartTipi", kartBasvuruVeriKntlTx.getKartTipi()))
						.uniqueResult();
				if (tffBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", kartBasvuruVeriKntlTx.getBasvuruNo());
				}
			}
			
			//Veri tamamlama ekran�nda alinan aksiyonlara gore islem sonrasi guncellemeleri gerceklestir.
			//Islem onaylandi ise
			if ("O".equals(kartBasvuruVeriTmmlTx.getAksiyonKod())) {
				//Musteri Bilgilerini Guncelle
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", tffBasvuru==null?kartBasvuruVeriKntlTx.getBasvuruNo():tffBasvuru.getBasvuruNo());
				sorguMap.put("SOURCE", "TFF");
				GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
				
				//Kredi karti ise durumunu kontrol et ve gerekirse kart donusumu yap.
				sorguMap.clear();
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					//KK basvurusunun durumunu al
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kartBasvuruVeriKntlTx.getBasvuruNo());
					if (kkBasvuru == null) {
						return oMap;//Hata ver
					}
					
					//KK basvurusu red ya da iptal oldu ise kart donustur
					if ("RED".equals(kkBasvuru.getDurumKod()) || "IPTAL".equals(kkBasvuru.getDurumKod())) {
						if ("IPTAL".equals(tffBasvuru.getDurumKod())) {
							ADCSession.put(ISLEM_SONRASI_MESAJ, "Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
						}
						//TFF basvurusu servis icerisinde guncelleniyor
					} else if (!"BASIM".equals(kkBasvuru.getDurumKod())) {
						//Basim durumunda kredi karti sureci tamamlandigindan bu duruma gerek yok
						durumGuncelle(tffBasvuru.getBasvuruNo(), trxNo, "KREDI_KARTI", kartBasvuruVeriTmmlTx.getAciklama());
					}
				//KK degilse basimi gerceklestir.
				} else {
					//durumunu guncelle
					durumGuncelle(kartBasvuruVeriKntlTx.getBasvuruNo(), trxNo, "BASIM", kartBasvuruVeriTmmlTx.getAciklama());
					//bas
					sorguMap.put("BASVURU_NO", kartBasvuruVeriKntlTx.getBasvuruNo());
					sorguMap.put("ISLEM_NO", kartBasvuruVeriTmmlTx.getTxNo());
					sorguMap.put("DURUM_KOD", "BASIM");
					sorguMap.put("KART_TIPI", kartBasvuruVeriKntlTx.getKartTipi());
					oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", sorguMap));
				}
			//Islem KK istegi iptal edilerek onaylandi ise
			} else if ("K".equals(kartBasvuruVeriTmmlTx.getAksiyonKod())) {
				//Musteri Bilgilerini Guncelle
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", tffBasvuru==null?kartBasvuruVeriKntlTx.getBasvuruNo():tffBasvuru.getBasvuruNo());
				sorguMap.put("SOURCE", "TFF");
				GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
				
				//Kredi karti basvurusu ise
				sorguMap.clear();
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					//KK basvurusunun durumunu al
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kartBasvuruVeriKntlTx.getBasvuruNo());
					if (kkBasvuru == null) {
						return oMap;//Hata ver
					}
					
					//KK basvurusu red ya da iptal oldu ise kart donustur
					if ("RED".equals(kkBasvuru.getDurumKod()) || "IPTAL".equals(kkBasvuru.getDurumKod())) {
						sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
						sorguMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
						sorguMap.put("ISLEM_KOD", "3806");
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap));
						
						//Kart tipine gore islem sonrasi mesaj duzenle
						if (StringUtils.isBlank(oMap.getString("KART_TIPI"))) {
							ADCSession.put(ISLEM_SONRASI_MESAJ, "Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
						}
					}
				}
			//Iptal ise, iptal islemini gerceklestir.
			} else if ("I".equals(kartBasvuruVeriTmmlTx.getAksiyonKod())) {
				BigDecimal basvuruNo = kartBasvuruVeriKntlTx.getBasvuruNo();
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					basvuruNo = tffBasvuru.getBasvuruNo();
				}
				
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", basvuruNo);
				sorguMap.put("ONCEKI_DURUM_KOD", "VERI_TAMAMLAMA");
				sorguMap.put("ISLEM_KOD", "3806");
				sorguMap.put("GEREKCE_KOD", "2");
				sorguMap.put("ACIKLAMA", kartBasvuruVeriTmmlTx.getAciklama());
				sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.EVET);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
				ADCSession.put("ISLEM_SONRASI_MESAJ", oMap.get("MESSAGE"));
			} else if ("F".equals(kartBasvuruVeriTmmlTx.getAksiyonKod())) {
				//durumunu guncelle
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					durumGuncelle(tffBasvuru.getBasvuruNo(), trxNo, "FRAUD", kartBasvuruVeriTmmlTx.getAciklama());
				} else {
					durumGuncelle(kartBasvuruVeriKntlTx.getBasvuruNo(), trxNo, "FRAUD", kartBasvuruVeriTmmlTx.getAciklama());
				}
			}
			
			try {
				sorguMap.put("TFF_BASVURU_NO", tffBasvuru==null?kartBasvuruVeriKntlTx.getBasvuruNo():tffBasvuru.getBasvuruNo());
				sorguMap.put("CRM_TYPE", CrmTypes.MAIN);
				GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", sorguMap);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + sorguMap.containsKey("TFF_BASVURU_NO"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	private static void durumGuncelle(BigDecimal basvuruNo, BigDecimal trxNo, String yeniDurum, String aciklama) {
		GMMap kontrolMap = new GMMap();
		kontrolMap.put("BASVURU_NO", basvuruNo);
		kontrolMap.put("ISLEM_NO", trxNo);
		kontrolMap.put("DURUM_KOD", yeniDurum);
		kontrolMap.put("ISLEM_ACIKLAMA", aciklama);
		kontrolMap.put("TARIHCE_AKSIYON", "E");
		GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", kontrolMap);
	}
	
	@GraymoundService("BNSPR_TRN3806_GET_OUTBOUND_AGENT_CODES")
    public static GMMap getAgentCodes(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        iMap.put("KOD", "TFF_AGENT_CODE");
        iMap.put("ADD_EMPTY_KEY", "H");
        oMap.put("AGENT_CODES", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
        return oMap;
    }
}
