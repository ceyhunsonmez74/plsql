package tr.com.aktifbank.bnspr.creditcard.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CommonServices {
    
    /**
     * This service is used by process executer for logging purposes.
     * 
     * @param iMap
     * @return
     */
    @GraymoundService("BNSPR_CREDITCARD_LOG_CARD_INFO_PROXY")
    public static GMMap logCardInfoProxy(GMMap iMap) {
        return iMap;
    }

    /**
     * Service wrapper to call Ocean and Intracard services.
     * Exception handling is provided which will be helpful
     * for process call logging.
     * 
     * @param iMap
     * @return
     */
    @GraymoundService("BNSPR_CREDITCARD_CALL_CARD_SERVICE")
    public static GMMap callCardService(GMMap iMap) {
        GMMap oMap = null;
        String serviceName = iMap.getString("SERVICE_NAME");
        
        try {
            oMap = GMServiceExecuter.call(serviceName, iMap);
        } catch (GMRuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
        if (!oMap.getString("RETURN_CODE", "2").equals("2")) {
            String message = oMap.getString("RETURN_DESCRIPTION");
            throw ExceptionHandler.convertException(new GMRuntimeException(0, message ));
        }
        
        return oMap;
    }

    public static String maskCardNumber(String cardNumber) {
        return cardNumber.replaceAll("(\\w{1,6})(\\w{1,6})(\\w{1,4})" , "$1******$3");
    }
    
}
