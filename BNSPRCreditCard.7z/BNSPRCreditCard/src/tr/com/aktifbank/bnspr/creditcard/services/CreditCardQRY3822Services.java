package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdLksFileProcess;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkLimitGuncelleme;
import tr.com.aktifbank.bnspr.dao.KkTopluBasvuruHavuz;
import tr.com.aktifbank.bnspr.dao.LksislemBildirim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY3822Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-9034
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>BASLANGIC_TARIHI - Ekran acilisinda gosterilecek baslangic tarihi
	 *         <li>BITIS_TARIHI - Ekran acilisinda gosterilecek bitis tarihi
	 *         <li>DURUM_LIST - KK limit guncelleme islem sonuc kodlari
	 */
	@GraymoundService("BNSPR_QRY3822_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Islem tipi
			GuimlUtil.wrapMyCombo(oMap, "ISLEM_TIPI_LIST", null, "Hepsi");
			GuimlUtil.wrapMyCombo(oMap, "ISLEM_TIPI_LIST", "E", "Limit Artis");
			GuimlUtil.wrapMyCombo(oMap, "ISLEM_TIPI_LIST", "H", "Limit Azaltma");
			//Arama icin default Baslangic ve Bitis Tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
			//Durum
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM_LIST", "KK_LIMIT_GUNCELLEME_DURUM_KOD", "HEPSI"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore istenilen sonuclari listeler<br>
	 * @author murat.el
	 * @since PY-9034
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>ADI - Musteri adi
	 *        <li>IKINCI_ADI - Musteri ikinci adi
	 *        <li>SOYADI - Musteri soyadi
	 *        <li>BAS_TARIHI - Arama baslangic tarihi
	 *        <li>BIT_TARIHI - Arama bitis tarihi
	 *        <li>DURUM_KOD - Durum listesi yerine direk kod kullanilacaksa doldurulur
	 *        <li>DURUM_LIST - KK limit guncelleme durum kodu
	 *        <li>ISLEM_TIPI - Limit guncelleme islem tipi
	 *        <li>EKRAN_KOD - Limit islemlerinin izlendigi ekranin kodu 
	 * @return Sorgu sonuclari<br>
	 *        <li>BASVURU_LIST - Istenilen kriterlere uygun islemler
	 */
	@GraymoundService("BNSPR_QRY3822_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			query = "{? = call pkg_rc3822.Rc_Qry3822_List(?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			//bas tarihi
			if (iMap.getDate("BAS_TARIHI") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIHI").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			//bit tarihi
			if (iMap.getDate("BIT_TARIHI") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIHI").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			//Durum list
			String durumList = null;
			if (StringUtils.isEmpty(iMap.getString("DURUM_KOD"))) {
				durumList = CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"));
				if (StringUtils.isBlank(durumList)) {
					durumList = "HEPSI,";
				}
			} else {
				durumList = iMap.getString("DURUM_KOD") + ",";
			}

			stmt.setString(i++, durumList);
			stmt.setString(i++, iMap.getString("EKRAN_KOD"));
			stmt.execute();
			
			//Ekran formatina cevir
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "BASVURU_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen limit guncelleme talebine ait yapilmis islemleri listeler.<br>
	 * @author murat.el
	 * @since PY-9034
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>ID - Limit guncelleme talep ID
	 * @return Sorgu sonuclari<br>
	 *        <li>RESULTS - Istenilen kriterlere uygun islemler
	 */
	@GraymoundService("BNSPR_QRY3822_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_rc3822.Rc_Qry3822_Tarihce(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen limit guncelleme talebiniptal eder.<br>
	 * @author murat.el
	 * @since PY-9034
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>ID - Limit guncelleme talep ID
	 *        <li>ONCEKI_DURUM_KOD - Onceki durum kodu
	 * @return ISlem sonuclari<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_QRY3822_IPTAL")
	public static GMMap limitIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Kayit var mi?
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkLimitGuncelleme kkLimitGuncelleme = (KkLimitGuncelleme)
					session.get(KkLimitGuncelleme.class, iMap.getBigDecimal("ID"));
			if (kkLimitGuncelleme == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("ID"));
			}
			
			//Limit artis basvurusu varsa kredi karti basvurusunu iptal et
			if (CreditCardServicesUtil.EVET.equals(kkLimitGuncelleme.getLimitArttiMi())) {
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkLimitGuncelleme.getBasvuruNo());
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
				sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
				sorguMap.put("ISLEM_KOD", "LIMIT");
				sorguMap.put("GEREKCE_KOD", "4");
				sorguMap.put("ACIKLAMA", "Limit Artis Talebi Iptal Edildi");
				sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
			} else {
				//Islem no al
				BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
				//Kaydet
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "G");
				sorguMap.put("TRX_NO", trxNo);
				sorguMap.put("ID", kkLimitGuncelleme.getId());
				sorguMap.put("ONCEKI_DURUM_KOD", iMap.get("ONCEKI_DURUM_KOD"));
				sorguMap.put("DURUM_KOD", "IPTAL");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
			}
			
			//Tahsis edilmis LKS limiti varsa 
			//EVAM_SENARYO_1 ve limit artis ise
			if (CreditCardServicesUtil.EVET.equals(kkLimitGuncelleme.getLimitArttiMi()) &&
					"EVAM_LIMIT_GUNCELLEME_1".equals(kkLimitGuncelleme.getIslemYeri())) {
				sorguMap.clear();
				sorguMap.put("ID", kkLimitGuncelleme.getId());
				sorguMap.put("LIMIT_ARTTI_MI", kkLimitGuncelleme.getLimitArttiMi());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3822_LKS_BILDIRIM_YAPILDI_MI", sorguMap));
				//bildirim yapilmissa lks gunluk bildirim tablosuna azaltma kaydi at.
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("BILDIRIM_YAPILDI_MI"))) {
					CrdLksFileProcess crdLksFileProcess = new CrdLksFileProcess();
					crdLksFileProcess.setCustomerNumber(kkLimitGuncelleme.getMusteriNo());
					crdLksFileProcess.setMainCardNumber(kkLimitGuncelleme.getKartNo());
					crdLksFileProcess.setOldCustomerLimit(CreditCardServicesUtil.nvl(kkLimitGuncelleme.getOnaylananKartLimit(), kkLimitGuncelleme.getYeniKartLimit()));
					crdLksFileProcess.setNewCustomerLimit(kkLimitGuncelleme.getKartLimit());
					crdLksFileProcess.setLimitUpdateUser(ADCSession.getString("USERNAME"));
					crdLksFileProcess.setStatus("0");//Kayit okundu
					//Azaltim tipine gore alalari doldur
					SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMMdd");
					SimpleDateFormat timeFormatter = new SimpleDateFormat("hhmmss");
					if (crdLksFileProcess.getNewCustomerLimit() == null || 
							BigDecimal.ZERO.compareTo(crdLksFileProcess.getNewCustomerLimit()) == 0) {
						crdLksFileProcess.setLimitCloseDate(dateFormatter.format(Calendar.getInstance().getTime()));
						crdLksFileProcess.setLimitCloseTime(timeFormatter.format(Calendar.getInstance().getTime()));
						crdLksFileProcess.setLimitCloseReason("03");
					} else {
						crdLksFileProcess.setLimitChangeDate(dateFormatter.format(Calendar.getInstance().getTime()));
						crdLksFileProcess.setLimitChangeTime(timeFormatter.format(Calendar.getInstance().getTime()));
						crdLksFileProcess.setLimitChangeReason("02");//02
					}
					session.save(crdLksFileProcess);
					session.flush();
				} 
				//bildirim yapilmamissa lks islem durumunu iptale cek
				else {
					LksislemBildirim lksislemBildirim = (LksislemBildirim) session.createCriteria(LksislemBildirim.class)
							.add(Restrictions.eq("basvuruNo", kkLimitGuncelleme.getBasvuruNo()))
							.uniqueResult();
					if (lksislemBildirim != null) {
						lksislemBildirim.setBildirimDurumu("I");
						lksislemBildirim.setBildirimTarihi(Calendar.getInstance().getTime());
						session.save(lksislemBildirim);
						session.flush();
					}
				}
			}
			
			//Evamdan geliyorsa evami ve havuz kaydini MUSTERI_RED seklinde guncelle.
			KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
					session.createCriteria(KkTopluBasvuruHavuz.class)
					.add(Restrictions.eq("kkLimitGuncellemeID", iMap.getBigDecimal("ID")))
					.uniqueResult();
			if (kkTopluBasvuruHavuz != null) {
				//Havuz kaydini guncelle
				sorguMap.clear();
				sorguMap.put("ID", kkTopluBasvuruHavuz.getId());
				sorguMap.put("DURUM_KOD", "6");//Musteri iptal etti
				sorguMap.put("DURUM_ACIKLAMA", "17");//Musteri iptal etti
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
				sorguMap.put("SENARYO", kkLimitGuncelleme.getIslemYeri());
				sorguMap.put("AKIS_TURU", "L");//Limit guncelleme
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_DURUM_GUNCELLE", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen limit guncelleme talebiniptal eder.<br>
	 * @author murat.el
	 * @since PY-9034
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>ID - Limit guncelleme talep ID
	 *        <li>LIMIT_ARTTI_MI - Limit artis(E), Limit azaltma(H) gostergesi
	 *        <li>BASVURU_NO - Limit artis basvuru numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 * @return Islem sonuclari<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_QRY3822_ONAY")
	public static GMMap limitOnay(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Limit artirma islemini gerceklestir
			if ("E".equals(iMap.getString("LIMIT_ARTTI_MI"))) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("EVAM_MI", CreditCardServicesUtil.HAYIR);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN_LIMIT", sorguMap));
			//Limit azaltma islemini gerceklestir
			} else if ("H".equals(iMap.getString("LIMIT_ARTTI_MI"))) {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_AZALT", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen limit guncelleme talebiniptal eder.<br>
	 * @author murat.el
	 * @since PY-9034
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>ID - Limit guncelleme talep ID
	 *        <li>LIMIT_ARTTI_MI - Limit artis(E), Limit azaltma(H) gostergesi
	 * @return ISlem sonuclari<br>
	 *        <li>BILDIRIM_YAPILDI_MI - Bildirim yapildi mi? (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_QRY3822_LKS_BILDIRIM_YAPILDI_MI")
	public static GMMap lksBildirimYapildiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BILDIRIM_YAPILDI_MI", CreditCardServicesUtil.HAYIR);

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call Pkg_TRN3821.bildirimYapildiMi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
			stmt.setString(3, iMap.getString("LIMIT_ARTTI_MI"));
			stmt.execute();

			oMap.put("BILDIRIM_YAPILDI_MI", 
					CreditCardServicesUtil.nvl(stmt.getString(1), CreditCardServicesUtil.HAYIR));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("LIMIT_GUNCELLEME_IZLEME_JUST_FOR_LOG")
	public static GMMap LimitGuncellemeIzlemeLog(GMMap iMap) {
		return new GMMap();
	}
	
	@GraymoundService("LIMIT_GUNCELLEME_TARIHCE_JUST_FOR_LOG")
	public static GMMap LimitGuncellemeTarihceLog(GMMap iMap) {
		return new GMMap();
	}
	
	@GraymoundService("LIMIT_GUNCELLEME_MUSTERI_TARIHCE_JUST_FOR_LOG")
	public static GMMap LimitGuncellemeMusteriTarihceLog(GMMap iMap) {
		return new GMMap();
	}
	
	@GraymoundService("CNSPR_LIMIT_ISLEM_JUST_FOR_LOG")
	public static GMMap LimitIslemGuncelTarihceLog(GMMap iMap) {
		return new GMMap();
	}
	
}
