package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


/** TFF Basvuru Izleme Ekrani Servisleri
 * 
 * @author murat.el
 * @since 24.02.2014
 */
public class CreditCardQRY3813Services {

	/** Girilen kriterlere gore istenen tff basvurularini listeler.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Sorgu Kriterleri<br>
	 *        <li>BASVURU_NO
	 *        <li>TC_KIMLIK_NO
	 *        <li>MUSTERI_NO
	 *        <li>TFF_KART_TIPI
	 *        <li>ADI
	 *        <li>IKINCI_ADI
	 *        <li>SOYADI
	 *        <li>DURUM_LIST
	 *        <li>BASLANGIC_TAR
	 *        <li>BITIS_TAR
	 *        <li>KANAL_KODU
	 *        <li>CEP_TEL_ALAN
	 *        <li>CEP_TEL_NUMARA
	 *        <li>EUPT_HESAP_NO
	 *        <li>SOURCE
	 * @return oMap - Basvuru Listesi<br>
	 *         <li>BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_QRY3813_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruIzlemeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		// initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal basvuruNo= BigDecimal.ZERO;
		BigDecimal musteriNo= BigDecimal.ZERO;
		try {
			if (!StringUtils.isEmpty(iMap.getString("BASVURU_NO")) && StringUtils.isNumeric(iMap.getString("BASVURU_NO"))){
				if(StringUtils.isEmpty(iMap.getString("MUSTERI_NO"))){
					basvuruNo= iMap.getBigDecimal("BASVURU_NO");
					TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
					if(tffBasvuru!=null && tffBasvuru.getMusteriNo().compareTo(BigDecimal.ZERO)>0){
						musteriNo = tffBasvuru.getMusteriNo();
					}
				}
			}
				
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3813.Rc_Qry3813_List_Basvuru(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("PASAPORT_NO"));
			if (basvuruNo.compareTo(BigDecimal.ZERO)>0 && musteriNo.compareTo(BigDecimal.ZERO)>0){
				stmt.setBigDecimal(i++, musteriNo);
			}else {
				stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			}
			stmt.setString(i++, iMap.getString("TFF_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," : CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));

			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}

			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}

			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("CEP_TEL_ALAN"));
			stmt.setString(i++, iMap.getString("CEP_TEL_NUMARA"));
			stmt.setString(i++, iMap.getString("EUPT_HESAP_NO"));
			stmt.setString(i++, iMap.getString("SOURCE"));
			stmt.setString(i++, iMap.getString("URUN_SAHIP_KODU"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/** Basvuru izleme ekrani acilisinda kullanilan degerleri doner.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Input Yok<br>
	 * @return oMap - Ekran acilis degerleri<br>
	 *         <li>DURUM - Tff basvuru durumlari
	 *         <li>KART_TIPI_LIST - Tff kart tipleri
	 *         <li>KANAL_LIST - Tff basvurusu yapilabilecek kanallar
	 *         <li>SOURCE_LIST - Tff basvuru yapilacabilecek kaynaklar
	 *         <li>BASLANGIC_TARIHI - Arama yapilacak default baslangic tarihi
	 *         <li>BITIS_TARIHI - Arama yapilacak default bitis tarihi
	 */
	@GraymoundService("BNSPR_QRY3813_FILL_INITIAL_VALUES")
	public static GMMap fillInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Durums
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM", "TFF_BASVURU_DURUM_KOD", "HEPSI"));
			// Kart tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			// Source
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3183_TFF_SOURCE_LIST", iMap));
			// Kanal Listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3183_TFF_KANAL_LIST", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
			//takim listesi
			String query = "SELECT kod, adi FROM BNSPR.urun_sahip ORDER BY adi";
			DALUtil.fillComboBox(oMap, "KULUP_LIST", true, query);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Tff basvurusu yapilabilecek kanallari listeler.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Input Yok<br>
	 * @return oMap - Kanal Listesi<br>
	 *         <li>KANAL_LIST - Tff basvurusu yapilabilecek kanallar
	 */
	@GraymoundService("BNSPR_TRN3183_TFF_KANAL_LIST")
	public static GMMap getKanalList(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "KANAL_LIST");
		iMap.put("LIST_QUERY", "select p.kod, p.aciklama from bnspr.gnl_kanal_grup_kod_pr p order by 2");
		return DALUtil.fillComboBox(iMap);
	}

	/** Tff basvurusu yapilabilecek kaynaklari listeler.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Input Yok<br>
	 * @return oMap - Kaynak Listesi<br>
	 *         <li>SOURCE_LIST - Tff basvurusu yapilabilecek kaynaklar
	 */
	@GraymoundService("BNSPR_TRN3183_TFF_SOURCE_LIST")
	public static GMMap getSourceList(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "SOURCE_LIST");
		iMap.put("LIST_QUERY", "select key1 kod, text aciklama from v_ml_gnl_param_text t where t.kod = 'TFF_WEBSERVIS_PARAM' and t.key2='KANAL_KOD' order by 2");
		return DALUtil.fillComboBox(iMap);
	}
	
	/** Girilen basvuru numarasi icin daha once yapilmis islemleri listeler.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Basvuru Bilgisi<br>
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Basvuru Tarihcesi
	 *        <li>RESULTS - Verilen basvuruya ait islem listesi
	 */
	@GraymoundService("BNSPR_TFF_GET_TARIHCE")
	public static GMMap getTffTarihce(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.get_tarihce(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_GET_ODEME_BILGILERI")
	public static GMMap getTffOdemeBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3813.Basvuru_Kart_Bedeli(?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			i = 2;
			oMap.put("KART_BEDELI", stmt.getBigDecimal(i++));
			oMap.put("LOYALTY_BEDELI", stmt.getBigDecimal(i++));
			oMap.put("KURYE_BEDELI", stmt.getBigDecimal(i++));
			oMap.put("BANKA_EK_PAYI", stmt.getBigDecimal(i++));
			oMap.put("PROMOSYON_KART_BEDELI", stmt.getBigDecimal(i++));
			oMap.put("PROMOSYON_LOYALTY_BEDELI", stmt.getBigDecimal(i++));
			oMap.put("PROMOSYON_KURYE_BEDELI", stmt.getBigDecimal(i++));
			oMap.put("TOPLAM_TUTAR", stmt.getBigDecimal(i++));
			oMap.put("ODENEN_TUTAR", stmt.getBigDecimal(i++));
			oMap.put("EKSIK_TUTAR", stmt.getBigDecimal(i++));
			
			rSet = (ResultSet) stmt.getObject(i++);
			oMap.putAll(DALUtil.rSetResultsPutStr(rSet, "IADE_BILGILERI"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//--------------------------------------------------------INSERTTARIHCE
	/** Verilen parametrelerle basvuruya ait tarihce kaydi olusturur.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Tarhice Bilgisi<br>
	 *        <li>ISLEM_KODU
	 *        <li>BASVURU_NO
	 *        <li>DURUM_KODU
	 *        <li>ISLEM_SONRASI_DURUM_KODU
	 *        <li>TRX_NO
	 *        <li>AKSIYON_KOD
	 *        <li>AKSIYON_ACIKLAMA
	 *        <li>GORUS
	 *        <li>BAS_TARIHI
	 *        <li>YENI_KAYIT_MI
	 * @return oMap - Output Yok<br>
	 */
	@GraymoundService("BNSPR_TFF_TARIHCE_KAYDET")
	public static GMMap insertTffTarihce(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			query = "{ call PKG_TFF_BASVURU.insert_tarihce (?,?,?,?,?,?,?,?,?,?) }";
			stmt = conn.prepareCall(query);
			
			int i = 1;
			stmt.setString(i++, iMap.getString("ISLEM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("ISLEM_SONRASI_DURUM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("AKSIYON_KOD"));
			stmt.setString(i++, iMap.getString("AKSIYON_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("GORUS"));
			stmt.setDate(i++, (java.sql.Date) iMap.getDate("BAS_TARIHI"));
			stmt.setString(i++, iMap.getString("YENI_KAYIT_MI"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//--------------------------------------------------------KURYEBILGISI
	/** Basvurunun kurye durum bilgisini getirir.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Basvuru Bilgisi<br>
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Basvuru Tarihcesi
	 *        <li>KURYE_LIST - Kurye sirasindaki hareketler
	 *        <li>DURUM - Basvuru son kurye durumu
	 *        <li>RESPONSE - Islem sonucu
	 *        <li>REPSONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TFF_BASVURU_KURYE_DURUM_BILGISI")
	public static GMMap kuryeBilgisiAl(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Session al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Tff basvurusu bilgisini al
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}
			
			//Basvuru durumu BASIM ise kurye sorgulamasi yapilabilir.
			if (!"BASIM".equals(tffBasvuru.getDurumKod())) {
				CreditCardServicesUtil.raiseGMError("3344", iMap.getBigDecimal("BASVURU_NO"));
			}
			
			//Kurye Bilgisini Al. Alinamazsa hata ver.
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KURYE_BILGILERI_VER", sorguMap));//KURYE_BILGILERI
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Kurye Bilgisi Sorgulanirken Hata Alindi");
				return oMap;
			}
			
			//Kurye Bilgisi Dogru Alinmis Mi?
			if (sorguMap.get("KURYE_BILGILERI") == null || sorguMap.getSize("KURYE_BILGILERI") < 1) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Kurye Bilgisi Alinamadi");
				return oMap;
			}
			
			oMap.put("KURYE_LIST", sorguMap.get("KURYE_BILGILERI"));
			//AktifBank icerisindeki durum bilgisini al, //TY-4861
			oMap.put("DURUM", tffKuryeDurumAciklamaAl(sorguMap.getString("KURYE_BILGILERI", 0, "KOD")));
			oMap.put("DURUM_KOD", sorguMap.getString("KURYE_BILGILERI", 0, "KOD"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		return oMap;
	}
	
	/** Smartsoft tarafindan alinan kurye kodunun aktifbank tarafindaki durum aciklamasini bulur.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param kuryeDurumKodu - SmartSoft kurye durum kodu
	 * @return aciklama - Aktifbank kurye durum aciklamasi
	 */
	private static String tffKuryeDurumAciklamaAl(String kuryeDurumKodu) {
		String aciklama = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TFF_BASVURU.KuryeDurumAciklamaAl(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, kuryeDurumKodu);
			stmt.execute();

			aciklama = stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return aciklama;
	}
	
	@GraymoundService("BNSPR_TFF_BASVURU_KART_DURUM_BILGISI")
	public static GMMap kartDurumBilgisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			//Basvuru durumu BASIM ya da ACIK ise kart bilgisi sorgulamasi yapilabilir.
			if (!"BASIM".equals(iMap.getString("DURUM_KODU")) && !"ACIK".equals(iMap.getString("DURUM_KODU"))) {
				oMap.put("KART_DURUM", "");
			}
			
			//kartin tipi ogrenilir
			GMMap cardProperty = new GMMap();
			GMMap cardInfo = new GMMap();
			cardProperty.put("CARD_NO", iMap.getString("CARD_NO"));
			cardProperty.putAll(GMServiceExecuter.execute("BNSPR_GET_CARD_PROPERTIES", cardProperty));//KART_BILGILERI
			
			if (cardProperty.getString("RETURN_CODE").equals("0")) {
				String dest = cardProperty.getString("DESTINATION");
				cardProperty.put("CARD_DCI", cardProperty.getString("DCI"));
				//kart tipini bul
				if ("O".equals(dest)) {
					cardInfo.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO",cardProperty));
				} else if ("I".equals(dest)) {
					cardInfo.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO",cardProperty));
				}
				for (int i = 0; i < cardInfo.getSize("CARD_DETAIL_INFO"); i++){
	                if (StringUtils.isNotBlank(cardInfo.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_DESC"))){
	                    oMap.put("KART_DURUM", cardInfo.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_DESC"));
	                    oMap.put("KART_DURUM_KOD", cardInfo.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CODE"));
	                    oMap.put("KART_ALT_DURUM_KOD", cardInfo.getString("CARD_DETAIL_INFO" , i , "CARD_SUB_STAT_CODE"));
	                }
	            }
			}
			else
			{
				oMap.put("KART_DURUM", "");
				oMap.put("KART_DURUM_KOD", "");
				oMap.put("KART_ALT_DURUM_KOD", "");
				}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		return oMap;
	}
		
	@GraymoundService("BNSPR_QRY3819_BASVURU_IPTAL_ONAY_LIST")
	public static GMMap getBasvuruIptalOnayList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3813.Rc_Qry3819_Iptal_Onay_List(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("PASAPORT_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("TFF_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));

			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("CEP_TEL_ALAN"));
			stmt.setString(i++, iMap.getString("CEP_TEL_NUMARA"));
			stmt.setString(i++, iMap.getString("EUPT_HESAP_NO"));
			stmt.setString(i++, iMap.getString("SOURCE"));
			stmt.setString(i++, iMap.getString("URUN_SAHIP_KODU"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}	
}
