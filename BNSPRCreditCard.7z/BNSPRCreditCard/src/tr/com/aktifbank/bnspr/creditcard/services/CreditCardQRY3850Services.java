package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY3850Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>KANAL_KODLARI - Kanal listesi
	 */
	private static final Logger logger = Logger.getLogger(CreditCardQRY3850Services.class);
	@GraymoundService("BNSPR_QRY3850_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Kanal Kodlari
			oMap.putAll(CreditCardServicesUtil.getParameterList("ISLEM_TIPI_LIST", 
					"KART_BASVURU_TALEP_ISLEM_TIPI", CreditCardServicesUtil.EVET));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap - Islem bilgileri<br>
	 *        <li>DOSYA - Islem yapilmak istenen excel dosyasi
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>ISLEM_TIPI - Islem tipi
	 * @return Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu(0:Basarisiz|2:Basarili)
	 */
	@GraymoundService("BNSPR_QRY3850_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
		GMMap sorguMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		try {
			//1. Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("ISLEM_TIPI"))) {
				CreditCardServicesUtil.raiseGMError("330", "Islem Tipi");
			}
			
			if (iMap.get("DOSYA") == null) {
				CreditCardServicesUtil.raiseGMError("330", "Dosya");
			}
			
			if (iMap.get("TRX_NO") == null) {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			}
			
			//2. Excel kolon sayisi kontrol
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "KART_TALEP_KOLON_SAYISI");
			String kolonSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");
			
			//3. Excelden datalari al
			GMMap excelMap = new GMMap();
			excelMap.put("DOSYA", iMap.get("DOSYA"));
			excelMap.put("KOLON_SAYISI", kolonSayisi);
			excelMap.put("BASLIK_VAR_MI", CreditCardServicesUtil.EVET);
			excelMap.putAll(GMServiceExecuter.execute("BNSPR_EXCEL_TO_LIST", excelMap));//TABLE
			//Kontrol
			String excelTableName = "TABLE";
			if (excelMap.get(excelTableName) == null || excelMap.getSize(excelTableName) < 1) {
				CreditCardServicesUtil.raiseGMError("660", "Dosya icerisinde data bulunamadi");
			}

			//4. Alinan datalari havuza kaydet
			GMMap rowMap = null;
			for (int i = 0; i < excelMap.getSize(excelTableName); i++) {
				sorguMap.clear();
				sorguMap.put("AKTARIM_NO", iMap.get("TRX_NO"));
				sorguMap.put("KANAL", "DOSYA");
				sorguMap.put("ISLEM_TIPI", iMap.get("ISLEM_TIPI"));
				//Gercek musteri ise musterinin uzerinden datalari al
				
				if(!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "TCKN"))){
					if(excelMap.getBigDecimal(excelTableName, i, "MUSTERI_NO") == null){
						 Criteria criteria = session.createCriteria(GnlMusteri.class)
									.add(Restrictions.eq("tcKimlikNo", excelMap.getString(excelTableName, i, "TCKN").trim()))
									.add(Restrictions.ne("musteriStat1" , "4"))
						            .add(Restrictions.eq("durumKodu" , "A"))						 
									.add(Restrictions.eq("musteriTurKod", "G"))
									.add(Restrictions.eq("musteriKontakt", "M"));
									
									
						GnlMusteri gnlMusteri = (GnlMusteri) criteria.uniqueResult();
						if(gnlMusteri == null){
							logger.info("--------- BNSPR_QRY3850_SAVE + " + i + " musteri bulunamadi");
							continue;
						}
						if(!("G".equals(gnlMusteri.getMusteriTurKod()))){
							logger.info("--------- BNSPR_QRY3850_SAVE + " + i + " musteri tur kod kontakt musteri hatasi");
							continue;
						}
						
						excelMap.put(excelTableName,  i, "MUSTERI_NO", gnlMusteri.getMusteriNo());
						excelMap.put(excelTableName,  i, "REFERANS_NO", gnlMusteri.getTcKimlikNo());
						
						if(!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "EV_ADRES")) || !StringUtils.isEmpty(excelMap.getString(excelTableName, i, "IS_ADRES"))
								|| !StringUtils.isEmpty(excelMap.getString(excelTableName, i, "DIGER_ADRES"))
						)
						{
							if(StringUtils.isEmpty(excelMap.getString(excelTableName, i, "TESLIMAT_ADRES_KOD"))
							   ||
								StringUtils.isEmpty(excelMap.getString(excelTableName, i, "ILETISIM_ADRES_KOD"))
							  )
							{
								logger.info("--------- BNSPR_QRY3850_SAVE + " + i + " teslimat adres kod eksik");
								continue;
								
							}
							
							if (!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "EV_ADRES"))) {
								if (StringUtils.isEmpty(excelMap.getString(excelTableName, i, "EV_IL")) || StringUtils.isEmpty(excelMap.getString(excelTableName, i, "EV_ILCE")) || StringUtils.isEmpty(excelMap.getString(excelTableName, i, "EV_POSTA_KOD"))) {
									logger.info("--------- BNSPR_QRY3850_SAVE + " + i + " ev il , ilce , posta kod eksik");
									continue;

								}
							}
							
							if(!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "IS_ADRES"))){
								if (StringUtils.isEmpty(excelMap.getString(excelTableName, i, "IS_IL")) || StringUtils.isEmpty(excelMap.getString(excelTableName, i, "IS_ILCE")) || StringUtils.isEmpty(excelMap.getString(excelTableName, i, "IS_POSTA_KOD"))) {
									logger.info("--------- BNSPR_QRY3850_SAVE + " + i + " is il , is ilce , is posta kod eksik");
									continue;

								}
							}
							
							if(!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "DIGER_ADRES"))){
								if (StringUtils.isEmpty(excelMap.getString(excelTableName, i, "DIGER_IL")) || StringUtils.isEmpty(excelMap.getString(excelTableName, i, "DIGER_ILCE")) || StringUtils.isEmpty(excelMap.getString(excelTableName, i, "DIGER_POSTA_KOD"))) {
									logger.info("--------- BNSPR_QRY3850_SAVE + " + i + " diger il , diger ilce , diger posta kod eksik");
									continue;

								}
							}
							
							
						}
						
						
						sorguMap.putAll(getApplicationInfoFromCustomer(excelMap.getBigDecimal(excelTableName, i, "MUSTERI_NO") , true , 
								!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "TESLIMAT_ADRES_KOD")) ? excelMap.getString(excelTableName, i, "TESLIMAT_ADRES_KOD").trim() : null
										,!StringUtils.isEmpty(excelMap.getString(excelTableName, i, "ILETISIM_ADRES_KOD")) ? excelMap.getString(excelTableName, i, "ILETISIM_ADRES_KOD").trim() : null));
												
						
						
					}
					
					else{
						sorguMap.putAll(getApplicationInfoFromCustomer(excelMap.getBigDecimal(excelTableName, i, "MUSTERI_NO") ,false , null , null));
						
					}
					
					
				}
				
				
				//Excelde bulunan ve bos olmayan datalari al
				rowMap = excelMap.getMap(excelTableName, i);
				String key = null;
				for (Object o : rowMap.keySet()) {
					key = (String) o;
					if (StringUtils.isNotBlank(rowMap.getString(key))) {
						sorguMap.put(key, rowMap.get(key));
					}
				}
				//Alinan datalarla talebi kaydet
				oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;
	}

	private static GMMap getApplicationInfoFromCustomer(BigDecimal customerNo , boolean filled , String teslimatAdresKod , String iletisimAdresKod) {
		GMMap sorguMap = new GMMap();
		sorguMap.put("MUSTERI_NO", customerNo);
		sorguMap.put("FILLED", filled);
		sorguMap.put("TESLIMAT_ADRES_KOD", teslimatAdresKod);
		sorguMap.put("ILETISIM_ADRES_KOD", iletisimAdresKod);
		sorguMap.putAll(getApplicationInfoFromCustomer(sorguMap));
		
		return sorguMap;
	}
	
	@GraymoundService("BNSPR_QRY3850_GET_APP_INFO_FROM_CUSTOMER")
	public static GMMap getApplicationInfoFromCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			if(iMap.getBoolean("FILLED")){
				query = "{? = call PKG_RC3851.getApplicationInfoByTcknMusNo(?,?,?)}";
				stmt = conn.prepareCall(query);
				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
				stmt.setString(3, iMap.getString("TESLIMAT_ADRES_KOD"));
				stmt.setString(4, iMap.getString("ILETISIM_ADRES_KOD"));
				stmt.execute();
			}
			else{
				query = "{? = call PKG_RC3851.getApplicationInfoByMusteriNo(?)}";
				stmt = conn.prepareCall(query);
				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
				stmt.execute();
			}

			

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
}
