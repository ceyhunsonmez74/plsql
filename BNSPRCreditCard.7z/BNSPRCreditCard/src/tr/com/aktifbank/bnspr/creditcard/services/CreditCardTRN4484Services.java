package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.CrdDebitTransferBakiye;
import tr.com.aktifbank.bnspr.dao.SbaKartaiadeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4484Services implements OceanMapKeys {

	@GraymoundService("BNSPR_TRN4484_GET_CARD_LIST")
	public static GMMap getCardList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap cMap = new GMMap();
			GMMap lMap = new GMMap();
			cMap.put(INPUT_PARAMETER_TYPE, "CST");
			cMap.put(CUSTOMER_NO, iMap.getBigDecimal("MUST_NO"));
			cMap.put("NO_NEED_APPLICATIONS", true);
			cMap.put("PROCEED", "INCLUDE");
			lMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", cMap);

			int s = lMap.getSize("CARD_DETAIL_INFO");
			int j = 0;
			for (int i = 0; i < s; i++) {
				String dci = lMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI_AKUSTIK");
				String dest = lMap.getString("CARD_DETAIL_INFO", i, "SYSTEM");
				if (!dci.equals("D")) {
					if (lMap.getString("CARD_DETAIL_INFO", 0, "CARD_STAT_CODE").equals("N")) {
						oMap.put("TABLO", j, "CARD_NO", lMap.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
						oMap.put("TABLO", j, "CUSTOMER_NO", lMap.getBigDecimal("CARD_DETAIL_INFO", i, "CUSTOMER_NO"));
						oMap.put("TABLO", j, "CARD_DCI", dci);
						oMap.put("TABLO", j, "CARD_STAT_DESC", lMap.getString("CARD_DETAIL_INFO", i, "CARD_STAT_DESC"));
						oMap.put("TABLO", j, "CARD_EMBOSS_NAME", lMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1"));
						if (dci.equals("C")) {
							oMap.put("TABLO", j, "ALICI_DK", getGlobalParam("KK_BORC_DK"));
							oMap.put("TABLO", j, "ALICI_SUBE", 998);
						}
						else if (dci.equals("P") && dest.equals("O")) {
							oMap.put("TABLO", j, "ALICI_SUBE", 998);
							if ("YIM".equals(KkProductsUtil.getSourceFromProductId(lMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)))) {
								oMap.put("TABLO", j, "ALICI_DK", getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ"));
							}
							else if ("UPT".equals(KkProductsUtil.getSourceFromProductId(lMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)))) {
								oMap.put("TABLO", j, "ALICI_DK", getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ_UPT"));
							}
							else if ("HCE".equals(KkProductsUtil.getSourceFromProductId(lMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)))) {
								oMap.put("TABLO", j, "ALICI_DK", getGlobalParam("OCEAN_HCE_TOPUP_HAVUZ"));
							}
							else if ("MCHIP".equals(KkProductsUtil.getSourceFromProductId(lMap.getString(CARD_DETAIL_INFO, i, PRODUCT_ID)))) {
								oMap.put("TABLO", j, "ALICI_DK", getGlobalParam("OCEAN_PROCEED_TOPUP_HAVUZ"));
							}

						}
						else if (dci.equals("P")) {
							oMap.put("TABLO", j, "ALICI_DK", getGlobalParam("PP_BORC_DK"));
							oMap.put("TABLO", j, "ALICI_SUBE", 997);
						}
						j = j + 1;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4484_GET_SANAL_POS_INFO")
	public static GMMap getSanalPosInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("ALICI_DK", getGlobalParam("POS_143_HAVUZ_HESABI"));
			oMap.put("ALICI_SUBE", 997);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TRN4484_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaKartaiadeTx sbaKartaiadeTx = new SbaKartaiadeTx();
			sbaKartaiadeTx.setAciklama(iMap.getString("ACIKLAMA"));
			sbaKartaiadeTx.setAliciDk(iMap.getString("ALICI_DK"));
			sbaKartaiadeTx.setAliciSube(iMap.getString("ALICI_SUBE"));
			sbaKartaiadeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			sbaKartaiadeTx.setKartNo(iMap.getString("KART_NO"));
			sbaKartaiadeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			sbaKartaiadeTx.setSanalPosIadesi(iMap.getBoolean("SANAL_POS") ? "1" : "0");
			sbaKartaiadeTx.setTutar(iMap.getBigDecimal("TUTAR"));
			sbaKartaiadeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			sbaKartaiadeTx.setBankaAciklama(iMap.getString("BANKA_ACIKLAMA"));
			sbaKartaiadeTx.setSiparisNo(iMap.getString("SIPARIS_NO"));
			session.saveOrUpdate(sbaKartaiadeTx);
			session.flush();

			iMap.put("TRX_NAME", "4484");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

			withdrawFromDebitCardTopupBalance(iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4484_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaKartaiadeTx sbaKartaiadeTx = (SbaKartaiadeTx) session.createCriteria(SbaKartaiadeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("ACIKLAMA", sbaKartaiadeTx.getAciklama());
			oMap.put("ALICI_DK", sbaKartaiadeTx.getAliciDk());
			oMap.put("ALICI_SUBE", sbaKartaiadeTx.getAliciSube());
			oMap.put("HESAP_NO", sbaKartaiadeTx.getHesapNo());
			oMap.put("KART_NO", sbaKartaiadeTx.getKartNo());
			oMap.put("MUSTERI_NO", sbaKartaiadeTx.getMusteriNo());
			oMap.put("SANAL_POS", sbaKartaiadeTx.getSanalPosIadesi() == "1" ? true : false);
			oMap.put("TUTAR", sbaKartaiadeTx.getTutar());
			oMap.put("BANKA_ACIKLAMA", sbaKartaiadeTx.getBankaAciklama());
			oMap.put("SIPARIS_NO", sbaKartaiadeTx.getSiparisNo());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4484_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {

			GMMap iMapA = new GMMap();
			GMMap oMapA = new GMMap();
			GMMap oMapH = new GMMap();
			GMMap iMapx = new GMMap();
			SbaKartaiadeTx sbaKartaiadeTx = (SbaKartaiadeTx) session.createCriteria(SbaKartaiadeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			if (sbaKartaiadeTx.getSanalPosIadesi().equals("0")) {
				iMapA.put("HESAP_NO", sbaKartaiadeTx.getHesapNo());
				oMapA = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", iMapA);

				iMapx.put(ACCOUNT_NO, sbaKartaiadeTx.getHesapNo());
				oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMapA);
				iMapx.put(BRANCH_CODE, oMapH.getString("SUBE_KOD"));

				iMapx.put(CARD_NO, sbaKartaiadeTx.getKartNo());
				iMapx.put(ORIGINAL_RRN, "");
				iMapx.put(TERMINAL_ID, "9999999");
				String channelCode = OceanConstants.Channel_Branch;
				String paymentType = OceanConstants.Payment_From_Account;
				iMapx.put(PAYMENT_TYPE, paymentType);
				iMapx.put(REQUEST_TYPE, OceanConstants.Request_Normal);
				iMapx.put(TXN_AMOUNT, sbaKartaiadeTx.getTutar());
				iMapx.put(TERMINAL_TYPE, "Crt");
				iMapx.put(TXN_CURR, "TRY");
				if (StringUtils.isEmpty(sbaKartaiadeTx.getAciklama()))
					iMapx.put(TXN_DESC, "Hesaptan Karta �ade");
				else
					iMapx.put(TXN_DESC, sbaKartaiadeTx.getAciklama());
				if (sbaKartaiadeTx.getAliciDk().equals(getGlobalParam("KK_BORC_DK"))) {
					iMapx.put(REFERENCE_NO, iMap.getString("ISLEM_NO"));
					iMapx.put(ACCOUNT_BRANCH, oMapA.getString("SUBE_KODU"));
					GMServiceExecuter.call("BNSPR_OCEAN_MAKE_CARD_PAYMENT", iMapx);
				}
				else if (sbaKartaiadeTx.getAliciDk().equals(getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ")) || sbaKartaiadeTx.getAliciDk().equals(getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ_UPT")) || sbaKartaiadeTx.getAliciDk().equals(getGlobalParam("OCEAN_HCE_TOPUP_HAVUZ")) || sbaKartaiadeTx.getAliciDk().equals(getGlobalParam("OCEAN_PROCEED_TOPUP_HAVUZ"))) {
					iMapx.put(REFERENCE_NO, iMap.getString("ISLEM_NO"));
					iMapx.put(ACCOUNT_BRANCH, oMapA.getString("SUBE_KODU"));
					iMapx.put(ACCOUNT_BRANCH_ID, oMapA.getString("SUBE_KODU"));
					iMapx.put(TX_NO, iMap.getString("ISLEM_NO"));
					GMServiceExecuter.call("BNSPR_OCEAN_PREPAID_TOPUP", iMapx);
				}
				else if (sbaKartaiadeTx.getAliciDk().equals(getGlobalParam("PP_BORC_DK"))) {
					iMapx.put(TX_NO, iMap.getString("ISLEM_NO"));
					iMapx.put(ACCOUNT_BRANCH_ID, oMapA.getString("SUBE_KODU"));
					GMServiceExecuter.call("BNSPR_INTRACARD_CARD_TOPUP", iMapx);
				}

			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4484_ACIKLAMA_OLUSTUR")
	public static GMMap aciklamaOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (iMap.getString("ALICI_DK").equals(getGlobalParam("KK_BORC_DK"))) {
			iMap.put("MESSAGE_NO", "5256");
			iMap.put("P1", iMap.getString("KART_NO"));
			oMap.put("BANKA_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
			iMap.put("P1", kartMaskele(iMap.getString("KART_NO")));
			oMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
		}
		else if (iMap.getString("ALICI_DK").equals(getGlobalParam("PP_BORC_DK")) || iMap.getString("ALICI_DK").equals(getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ")) || iMap.getString("ALICI_DK").equals(getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ_UPT")) || iMap.getString("ALICI_DK").equals(getGlobalParam("OCEAN_HCE_TOPUP_HAVUZ")) || iMap.getString("ALICI_DK").equals(getGlobalParam("OCEAN_PROCEED_TOPUP_HAVUZ"))) {
			iMap.put("MESSAGE_NO", "5257");
			iMap.put("P1", iMap.getString("KART_NO"));
			oMap.put("BANKA_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
			iMap.put("P1", kartMaskele(iMap.getString("KART_NO")));
			oMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
		}
		else if (iMap.getString("ALICI_DK").equals(getGlobalParam("POS_143_HAVUZ_HESABI"))) {
			iMap.put("MESSAGE_NO", "5258");
			oMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
			oMap.put("BANKA_ACIKLAMA", oMap.getString("ACIKLAMA"));
		}

		return oMap;
	}

	public static String getGlobalParam(String batchParamCode) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", batchParamCode);
		iMapG.put("TRIM_QUOTES", true);
		String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return batchNo;
	}

	private static void withdrawFromDebitCardTopupBalance(GMMap iMap) {

		CrdDebitTransferBakiye crdDebitTransferBakiye = findTopupRecord(iMap.getBigDecimal("HESAP_NO"));
		BigDecimal bTutar = iMap.getBigDecimal("TUTAR");
		if (crdDebitTransferBakiye != null) {
			BigDecimal dusBakiye = BigDecimal.ZERO;

			if (bTutar.compareTo(crdDebitTransferBakiye.getBakiye()) > 0) {
				dusBakiye = crdDebitTransferBakiye.getBakiye();
			}
			else {
				dusBakiye = bTutar;
			}

			GMMap bkyMap = new GMMap();
			bkyMap.put("HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
			bkyMap.put("TUTAR", dusBakiye.multiply(BigDecimal.valueOf(-1)));
			bkyMap.put("EXTERNAL_TRX_ID", iMap.getString("TRX_NO"));

			GMServiceExecuter.call("BNSPR_TRANSFER_TO_DEBIT_FROM_CREDIT", bkyMap);
		}
	}

	private static CrdDebitTransferBakiye findTopupRecord(BigDecimal accountNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		CrdDebitTransferBakiye crdDebitTransferBakiye = (CrdDebitTransferBakiye) session.createCriteria(CrdDebitTransferBakiye.class).add(Restrictions.eq("hesapNo", accountNo)).uniqueResult();
		return crdDebitTransferBakiye;
	}

	private static String kartMaskele(String kartNo) {
		// format the number
		return kartNo.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})", "$1 **** **** $3");
	}

}
