package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlPosChannelClientRel;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdeme;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdemeTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyon;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonGrup;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrun;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrunId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruSmsLink;
import tr.com.aktifbank.bnspr.dao.TffBasvuruVdOdeme;
import tr.com.aktifbank.bnspr.dao.TffBasvuruVdOdemeTx;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import common.Logger;

public class CreditCardTRN3802Services {
	private static final Logger logger = Logger.getLogger(CreditCardTRN3802Services.class);
	
	public static final String ODEME_BEKLE = "ODEME_BEKLE";
	public static final String VERI_KONTROL = "VERI_KONTROL";
	public static final String ODEME_BASARISIZ = "ODEME_BASARISIZ";
	public static final String ODEME = "ODEME";
	public static final String FOTO_EKSIK= "FOTO_EKSIK";
	public static final String FOTO= "FOTO";
	public static final BigDecimal PROMOSYON_DURUM_UYGUN= BigDecimal.ZERO;
	public static final BigDecimal PROMOSYON_DURUM_KULLANILDI= BigDecimal.ONE;
	public static final BigDecimal PROMOSYON_DURUM_PASIF=  BigDecimal.ONE.negate();
 
	public static final String BASVURU = "BASVURU";
	
	public static final String POS_APPROVED = "Approved";
	public static final String POS_DECLINED = "Declined";
	public static final String POS_ERROR = "Error";
	public static final String POS_DEFAULT_CURRENCY = "949";
	/*EVAM event type*/
	private static final String FOTO_EKSIK_EVENT_TYPE_NO = "27";
	private static final String EVENT_TYPE_NO = "20";
	public static final String EPOS_EVENT_TYPE_NO = "28";
		
    private static final String MOBILE_SRC = "MBL01";

	private static Configurator conf = Configurator.createConfiguratorFromProperties (  "configuration/aktifbank-int-tff.properties" );
	
	@GraymoundService("BNSPR_TRN3802_TFF_BASVURU_ODEME_GUNCELLE")
	public static GMMap tffBasvuruOdemeGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		boolean islemBasarili = StringUtils.isEmpty(iMap.getString("ISLEM_BASARISIZ"))?true:("E".equals(iMap.getString("ISLEM_BASARISIZ"))?false:true);
		String islemNo = "";
		String basvuruNo = "";
		
		if (iMap.containsKey("VD_YENILEME_MI") && !StringUtils.isEmpty(iMap.getString("VD_YENILEME_MI")) && "E".equals(iMap.getString("VD_YENILEME_MI"))){
			return GMServiceExecuter.call("BNSPR_VADE_YENILEME_ODEME_GUNCELLE", iMap);
		}

		if ( StringUtils.isNotEmpty(iMap.getString("BASVURU_NO")) ){
			StringTokenizer stringTokenizer = new StringTokenizer(iMap.getString("BASVURU_NO"),"-");
			basvuruNo = stringTokenizer.nextToken();
			if ( stringTokenizer.hasMoreTokens()){
				islemNo = stringTokenizer.nextToken();
			}
			
		}
		if ( StringUtils.isNotEmpty(iMap.getString("ISLEM_NO")) ){
			islemNo =iMap.getString("ISLEM_NO") ;
			
		}
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, new BigDecimal(basvuruNo));
		
		if (tffBasvuru != null) {

			TffBasvuruOdemeTx basvuruOdemeTx = (TffBasvuruOdemeTx)session.get(TffBasvuruOdemeTx.class, new BigDecimal(islemNo));			

			if (tffBasvuru.getDurumKod().equals(ODEME_BEKLE)  )//ayn� ba�vuru/kart vade yenileme �demesi ise
			{
				if ( StringUtils.isEmpty(islemNo) ){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_ISLEM_NO_EKSIK_HATASI);
					return oMap;
				}
				iMap.put("TRX_NO", islemNo);
				logger.info("----tffBasvuruOdemeGuncelle  TRX_NO " + iMap.getString("TRX_NO"));
				logger.info("----tffBasvuruOdemeGuncelle  ODEME_REF_ID " + iMap.getString("ODEME_REF_ID"));
				logger.info("----tffBasvuruOdemeGuncelle  BASVURU_NO " + iMap.getString("BASVURU_NO"));
				//TffBasvuruOdemeTx basvuruOdemeTx = (TffBasvuruOdemeTx)session.get(TffBasvuruOdemeTx.class, new BigDecimal(islemNo));// session.createCriteria(TffBasvuruOdemeTx.class).add(Restrictions.eq("txNo", new BigDecimal(islemNo))).uniqueResult();
			
				basvuruOdemeTx.setOdemeRefId(iMap.getString("ODEME_REF_ID"));
				session.saveOrUpdate(basvuruOdemeTx);
				session.flush();

				GMServiceExecuter.call("BNSPR_TRN3802_MUH_ISLEM_GUNCELLE", iMap);
				
				if ( islemBasarili){
					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "O");
					onayMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));

					List<TffBasvuruAdres> baList = session.createCriteria(TffBasvuruAdres.class)
							.add(Restrictions.eq("teslimatAdresiMi", "E")).add(Restrictions.eq("id.basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("uyeAdresNo")).list();
					if(baList.size() < 1){
						logger.info("----tffBasvuruOdemeGuncelle(GMMap)  TESLIMAT_ADRESI_YOK basvuru:  " + iMap.getString("BASVURU_NO"));
						
						List<TffBasvuruAdresTx> txList = session.createCriteria(TffBasvuruAdresTx.class)
								.add(Restrictions.eq("teslimatAdresiMi", "E")).add(Restrictions.eq("basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("uyeAdresNo")).list();
						if(txList.size()> 0 ){
							TffBasvuruAdresTx lastRec = txList.get(0);
							for(TffBasvuruAdres b: baList){
								if(b.getId().getAdresKod().equals(lastRec.getId().getAdresKod())){
									b.setTeslimatAdresiMi("E");
									session.save(b);
									session.flush();
									break;
								}
							}
						}
					}
				
				}
				else{
					GMMap onayRedMap = new GMMap();
					onayRedMap.put("ISLEM_TURU", "OR");
					onayRedMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayRedMap));
				}
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
			}
			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_BASVURU_DURUM_UYGUN_DEGIL_HATASI);
			}
		}
		else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_BASVURU_BULUNAMADIL_HATASI);
		}

		return oMap;

	}
/*
 * islem onaylandiktan sonra kredi karti istegi varsa kredi karti basvurusunu olusuturlmasi saglanir.
 * */
	@GraymoundService("BNSPR_TRN3802_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Islem numarasi verilen basvurunun tahsis bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruOdemeTx tffBasvuruOdemeTx = (TffBasvuruOdemeTx) session.get(TffBasvuruOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
			TffBasvuru tffBasvuru = (TffBasvuru)session.get(TffBasvuru.class, tffBasvuruOdemeTx.getBasvuruNo());

			if(tffBasvuruOdemeTx != null) {
				iMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
				iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
				GMMap odemeMap= GMServiceExecuter.call("BNSPR_TFF_COMMON_ODEME_YAPILDI_MI", iMap);
				GMMap fotoMap= GMServiceExecuter.call("BNSPR_TFF_COMMON_FOTO_YUKLENDI_MI", iMap);
				if(!"SMS".equals(tffBasvuru.getSource()) || ("SMS".equals(tffBasvuru.getSource()) && "E".equals(fotoMap.getString("FOTO_YUKLENDIMI")))){
					if ("KK".equals(tffBasvuru.getKartTipi()) ){
						GMMap kkBasvuru = new GMMap();
						kkBasvuru.put("KULLANICI_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", null).getString("KULLANICI_KOD"));
						kkBasvuru.put("UYE_NO", tffBasvuru.getTffUyeNo());
						kkBasvuru.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						//GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU", kkBasvuru);
						if(!"BATCH".equals(tffBasvuru.getSource())){
							GMServiceExecuter.executeAsync("BNSPR_TFF_KK_BASVURU", kkBasvuru);
						}
						
					}
				}
				
				
				//Veri kontrol havuzuna kaydi at
				session.refresh(tffBasvuru);
				if ("VERI_KONTROL".equals(tffBasvuru.getDurumKod())) {
					boolean veriKontrolYapilsinMi = Boolean.TRUE;
					if ("BATCH".equals(tffBasvuru.getSource())) {
						sorguMap.clear();
						sorguMap.put("KOD", "TFF_TOPLU_BASVURU");
						sorguMap.put("KEY1", "ODEME");
						sorguMap.put("KEY2", "VERI_KONTROL");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap));
						if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("TEXT"))) {
							veriKontrolYapilsinMi = Boolean.FALSE;
						}
					}
					
					if (veriKontrolYapilsinMi) {
						sorguMap.clear();
						sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						sorguMap.put("KK_BASVURU_NO", tffBasvuru.getKkBasvuruNo());
						sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
						sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
						sorguMap.put("SOURCE", tffBasvuru.getSource());
						GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap);
					}
				}else if ("FOTO_EKSIK".equals(tffBasvuru.getDurumKod())) {
					
					TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, tffBasvuru.getBasvuruNo());
					//TffBasvuruSmsLink tffSmsLink = (TffBasvuruSmsLink) session.get(TffBasvuruSmsLink.class, tffBasvuru.getBasvuruNo());
					
					TffBasvuruSmsLink tffSmsLink = (TffBasvuruSmsLink) session.createCriteria(TffBasvuruSmsLink.class).add(Restrictions.eq("basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("id")).list().get(0);
					
					
					GMMap dataMap = new GMMap();
					iMap.put("EVENT_TYPE_NO", FOTO_EKSIK_EVENT_TYPE_NO);
					iMap.put("EVENT_REF_NO", tffBasvuru.getBasvuruNo());
					dataMap.put("NAME", tffBasvuruKimlik.getAd());
					dataMap.put("SURNAME", tffBasvuruKimlik.getSoyad());
					dataMap.put("SOURCE", tffBasvuru.getSource());
					if("SMS".equals(tffBasvuru.getSource()) && tffSmsLink != null){
						
						GMMap linkMap = new GMMap();
						linkMap.put("CODE", tffSmsLink.getCode());
						linkMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_GET_LINK", linkMap));
						if("2".equals(linkMap.getString("RESPONSE"))){
							dataMap.put("CODE", linkMap.getString("LINK"));
						}else{
							dataMap.put("CODE", linkMap.getString("FULL_LINK"));
						}
					}
					iMap.put("DATA_MAP", dataMap);
					GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
				}
				if(!"SMS".equals(tffBasvuru.getSource())){
					try {
						iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						iMap.put("CRM_TYPE", CrmTypes.PAYMENT);
						GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
					} catch (Exception e) {
						e.printStackTrace();
						logger.error("CRM payment guncellemesi yapilamadi BASVURU_NO:" + iMap.get("TFF_BASVURU_NO"));
					}
					
					
					try {
                        iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
                        iMap.put("CRM_TYPE", CrmTypes.MAIN);
                        GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error("CRM payment guncellemesi yapilamadi BASVURU_NO:" + iMap.get("TFF_BASVURU_NO"));
                    }
				}
			
		
		}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3802_ODEME_YAP")
	public static GMMap tffBasvuruOdemeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
				
			
			// Ana tablolara kayitlari kaydet
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			boolean islemiOnayla = false;
			boolean isKuryeTipiChanged = false;
			String odemeRefID= "";
			String sonrakiDurumKodu = VERI_KONTROL;
			String kuryeTipi = "";
			
			
			if("NTS02".equals(iMap.getString("SOURCE"))){
				String giseID	= iMap.getString("GISE_ID");
				String giseUser	= iMap.getString("GISE_USER");
				
				if(StringUtils.isBlank(giseID)){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA","0219");
					return oMap;
				}
				if(StringUtils.isBlank(giseUser)){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA","0218");
					return oMap;
				}
			}
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			
			session.refresh(tffBasvuru);
			if (tffBasvuru != null) {
				if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
					GMMap tMap = new GMMap();
					tMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
					iMap.put("TRX_NO", tMap.getString("TRX_NO"));
					
				}
				
				boolean tcVatandasiMi = false;
				if (StringUtils.isNotEmpty(tffBasvuru.getTcKimlikNo())){
					tcVatandasiMi = true;
				}
				
				 kuryeTipi =  getKuryeTipi(iMap.getString("SOURCE"), iMap.getString("KURYE_TIPI",""), tcVatandasiMi);
		
				
				//TODO: SMS basvuruda teslimat kurye olmak zorunda KK oldugundan.
				//kurye tipi degisir duruma gelirse fiyat degisir, eski yarat�lan TX hatal� tutarli olur,
				//bunun iptal edilip yeni tx yaratmak lazim.
				//asagidaki islem ayni txte oldugu icin bu kontrolu pas gecer
				if(StringUtils.isNotBlank(tffBasvuru.getKuryeTipi()) && !tffBasvuru.getKuryeTipi().equals(kuryeTipi)){
					isKuryeTipiChanged = true;
				}
				
				if (tffBasvuru.getDurumKod().equals(ODEME) || tffBasvuru.getDurumKod().equals(ODEME_BASARISIZ) || tffBasvuru.getDurumKod().equals(ODEME_BEKLE) || (tffBasvuru.getDurumKod().equals("FOTO") && "SMS".equals(tffBasvuru.getSource()))) {
					//TY-5169 - EPOStan sanal pos odeme tipi ile geliyordu, buraya her turlu nakit olmasi icin eklendi.
					if ("EPOS".equals(iMap.getString("SOURCE"))) {
						iMap.put("ODEME_TIPI", "N");
					}
					
					if ( "D".equals(iMap.getString("ODEME_TIPI")) ||"S".equals(iMap.getString("ODEME_TIPI")) || "V".equals(iMap.getString("ODEME_TIPI")) ) { //  sanal pos,eupt icin trx sonlandirma, odeme bekle yap. + vodafone
						islemiOnayla = false;
						sonrakiDurumKodu = ODEME_BEKLE;
					}
					else if ("I".equals(iMap.getString("ODEME_TIPI")) || "F".equals(iMap.getString("ODEME_TIPI")) || "N".equals(iMap.getString("ODEME_TIPI")) || "H".equals(iMap.getString("ODEME_TIPI")) ) {//fiziksel pos ya da nakit icin odeme zaten manuel yapilmis. islemi sonlandir.
						islemiOnayla = true;
						sonrakiDurumKodu = ODEME_BEKLE;
						odemeRefID = iMap.getString("ODEME_REF_ID");
					}
					
					
				}
				else {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_BASVURU_DURUM_UYGUN_DEGIL_HATASI);
					return oMap;
				}
			}
			else{
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_BASVURU_BULUNAMADI_HATASI);
				return oMap;
			}
			if (StringUtils.isNotEmpty(iMap.getString("TESLIMAT_ADRES_NO"))){
				BigDecimal teslimatNo = iMap.getBigDecimal("TESLIMAT_ADRES_NO");
				logger.info("----tffBasvuruOdemeYap  TESLIMAT_ADRES_NO" + iMap.getBigDecimal("TESLIMAT_ADRES_NO"));
				List<TffBasvuruAdres> baList = session.createCriteria(TffBasvuruAdres.class)
						.add(Restrictions.eq("uyeAdresNo", teslimatNo)).add(Restrictions.eq("id.basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("id.basvuruNo")).list();
				TffBasvuruAdres ba = null;
				logger.info("----tffBasvuruOdemeYap  Adres SIZE " + baList.size());
				if(baList.size() > 0){
					ba = baList.get(0);
				}
				try {
					if (ba != null) {
						
						
						GMMap adresMap = new GMMap();
						adresMap.put("UYE_NO", tffBasvuru.getTffUyeNo());
						logger.info("----tffBasvuruOdemeYap  UYE_NO " + tffBasvuru.getTffUyeNo());
						adresMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						adresMap.put("ADRES_TIPI", ba.getId().getAdresKod());
						logger.info("----tffBasvuruOdemeYap  ADRES_TIPI " + ba.getId().getAdresKod());
						adresMap.put("ADRES_RUMUZ", new String());
						adresMap.put("IL_KOD", ba.getIlKod());
						adresMap.put("IL_AD", ba.getIlAd());
						adresMap.put("ILCE_AD", ba.getIlceAd());
						adresMap.put("ILCE_KOD", ba.getIlceKod());
						adresMap.put("ACIK_ADRES", ba.getAcikAdres());
						adresMap.put("ILETISIM_MI", ba.getIletisimMi());
						adresMap.put("TESLIMAT_ADRESI_MI", "E");
						adresMap.put("ADRES_NO", iMap.getString("TESLIMAT_ADRES_NO"));
						
						logger.info("----tffBasvuruOdemeYap  TESLIMAT_NOKTASI_KODU " + ba.getTeslimatNoktasiKodu());
						adresMap.put("TESLIMAT_NOKTASI_KODU", ba.getTeslimatNoktasiKodu());
						logger.info("----tffBasvuruOdemeYap  KURYE_TIPI " + kuryeTipi);
						adresMap.put("SOURCE", iMap.getString("SOURCE"));
						adresMap.put("MUSTERIYE_EKLE", "H");
						GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS", adresMap);
						if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
							
							if("D".equals(ba.getId().getAdresKod())){
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.KK_TESLIMAT_ADRESI_D_OLAMAZ);
								return oMap;
							}
							TffKrediKartiBasvuru krediKartiBasvuru = (TffKrediKartiBasvuru) session.get(TffKrediKartiBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
							if (krediKartiBasvuru != null) {
								krediKartiBasvuru.setTeslimatAdresi( ba.getId().getAdresKod());
								session.saveOrUpdate(krediKartiBasvuru);
								session.flush();
							}
						}
					}
				} catch (Exception e) {
					logger.error(e);
					String mailFrom = "system@aktifbank.com.tr";
					String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
					String mailSubject = "TFF ODEME TESLIMAT ADRESI HATA";
					String mailBody = "Odeme adiminda adres eklemede hata :";
					mailBody += "<br> HATA" + TffServicesHelper.getTraceAsString(e);
					mailBody += "<br> MAP" + iMap.toString();
					TffServicesHelper.sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
				}
	
			}else{}
						
			boolean islemBasarili = StringUtils.isEmpty(iMap.getString("ISLEM_BASARISIZ"))?true:("E".equals(iMap.getString("ISLEM_BASARISIZ"))?false:true);
			BigDecimal promosyonTutar =StringUtils.isNotBlank(iMap.getString("PROMOSYON_DEGERI"))?iMap.getBigDecimal("PROMOSYON_DEGERI"):BigDecimal.ZERO;
			TffBasvuruPromosyon promosyonlar = null;
			if(StringUtils.isBlank(iMap.getString("PROMOSYON_BEDELI"))){
				iMap.put("PROMOSYON_BEDELI",BigDecimal.ZERO);
			}
			if ( islemBasarili ){
			
				if (StringUtils.isNotBlank(iMap.getString("PROMOSYON_KODU"))) {
					logger.info("----tffBasvuruOdemeYap  PROMOSYON_KODU :" + iMap.getString("PROMOSYON_KODU"));
					promosyonlar = (TffBasvuruPromosyon) session.get(TffBasvuruPromosyon.class, iMap.getString("PROMOSYON_KODU"));
					if (promosyonlar != null) {
						TffBasvuruPromosyonGrup grup = (TffBasvuruPromosyonGrup) session.get(TffBasvuruPromosyonGrup.class, promosyonlar.getGrupId());
						if (grup.getBaslangicTarihi().before(new Date())){
							
							if(grup.getBitisTarihi().after(new Date())) {

								promosyonTutar = promosyonlar.getKartBedeli().add(promosyonlar.getKuryeBedeli()).add(promosyonlar.getLoyaltyBedeli()).add(promosyonlar.getVizeBedeli());
								if (TffServicesMessages.IPTAL.equals(promosyonlar.getDurum())) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_IPTAL);
									return oMap;
								}
								if (promosyonlar.getKalanAdet().intValue() == 0) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_KULLANILMISTIR);
									return oMap;
								}
								if (!TffServicesHelper.isPromosyonHasValidKartTipi(grup, tffBasvuru.getKartTipi())) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_KART_TIPI_UYGUN_DEGIL);
									return oMap;
								}

								if (!TffServicesHelper.isPromosyonHasValidSource(grup, iMap.getString("SOURCE"))) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_GECERSIZ_KANAL);
									return oMap;

								}
								TffBasvuruPromosyonUrun urun = (TffBasvuruPromosyonUrun) session.get(TffBasvuruPromosyonUrun.class, new TffBasvuruPromosyonUrunId(promosyonlar.getGrupId(), tffBasvuru.getUrunSahipKodu()));
								if (urun == null) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_GECERSIZ_URUN);
									return oMap;
								}
							}
							else {
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_BITIS_TARIHI_UYGUN_DEGIL);
								return oMap;

							}
						}
						else {
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_BASLANGIC_TARIHI_UYGUN_DEGIL);
							return oMap;

						}
					}
					else {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_BULUNAMADI_HATASI);
						return oMap;
					}

				}
			}
			else{
				sonrakiDurumKodu = ODEME_BEKLE;
			}
			
			GMMap kuryeMap = new GMMap();
			kuryeMap.put("KURYE_TIPI", kuryeTipi);
			
			if(!TffServicesHelper.isKuryeTipiValid(kuryeMap)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.GECERSIZ_KURYE_TIPI);
				return oMap;
			}else{
				tffBasvuru.setKuryeTipi(kuryeTipi);
			}
			TffBasvuruOdemeTx basvuruOdemeTx = new TffBasvuruOdemeTx();

			basvuruOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			basvuruOdemeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			basvuruOdemeTx.setGiseId(iMap.getString("GISE_ID"));
			basvuruOdemeTx.setGiseUser(iMap.getString("GISE_USER"));
			basvuruOdemeTx.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
			basvuruOdemeTx.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
			basvuruOdemeTx.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
			basvuruOdemeTx.setOdemeSekli(iMap.getString("ODEME_TIPI"));
			basvuruOdemeTx.setPromosyonBedeli(iMap.getBigDecimal("PROMOSYON_BEDELI"));
			basvuruOdemeTx.setPromosyonKodu(iMap.getString("PROMOSYON_KODU"));
			basvuruOdemeTx.setPromosyonOrani(iMap.getBigDecimal("PROMOSYON_ORANI"));
			basvuruOdemeTx.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
			basvuruOdemeTx.setKuryeTipi(kuryeTipi);
			iMap.put("TOPLAM_BEDEL", iMap.getBigDecimal("KART_BEDELI").add(iMap.getBigDecimal("KURYE_BEDELI")).add(iMap.getBigDecimal("LOYALTY_BEDELI")).add(iMap.getBigDecimal("VIZE_BEDELI")));
			if("H".equals(iMap.getString("ODEME_TIPI"))){
				logger.info("----tffBasvuruOdemeYap  HESAP_NO :" + iMap.getString("HESAP_NO"));
				
				if(StringUtils.isNotBlank(iMap.getString("HESAP_NO"))){
					//Hesaptan ise kullanilabilir bakiye uygun mu?
					GMMap sorguMap = new GMMap();
					sorguMap.put("HESAP_NO", iMap.get("HESAP_NO"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", sorguMap));
					if (iMap.getBigDecimal("TOPLAM_BEDEL").compareTo(sorguMap.getBigDecimal("KULLANILABILIR_BAKIYE")) == 1) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.HESAP_BAKIYE_YETERSIZ_HATA);
						return oMap;
					}
					
					basvuruOdemeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
				}else{
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.HESAP_NO_BULUNAMADI);
					return oMap;
				}
			}
			basvuruOdemeTx.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
			
			if(promosyonlar != null){
				basvuruOdemeTx.setPromosyonKart(promosyonlar.getKartBedeli());
				basvuruOdemeTx.setPromosyonKurye(promosyonlar.getKuryeBedeli());
				basvuruOdemeTx.setPromosyonLoyalty(promosyonlar.getLoyaltyBedeli());
				basvuruOdemeTx.setPromosyonVize(promosyonlar.getVizeBedeli());

				logger.info("----tffBasvuruOdemeYap  promosyonKartBedeli :" + promosyonlar.getKartBedeli());
				logger.info("----tffBasvuruOdemeYap  promosyonKuryeBedeli :" + promosyonlar.getKuryeBedeli());
				logger.info("----tffBasvuruOdemeYap  promosyonLoyaltyBedeli :" + promosyonlar.getLoyaltyBedeli());
				logger.info("----tffBasvuruOdemeYap  promosyonVizeBedeli :" + promosyonlar.getVizeBedeli());
			}
			
			logger.info("----tffBasvuruOdemeYap  TRX_NO :" + iMap.getString("TRX_NO"));
			logger.info("----tffBasvuruOdemeYap  BASVURU_NO :" + iMap.getString("BASVURU_NO"));
			logger.info("----tffBasvuruOdemeYap  ODEME_TIPI :" + iMap.getString("ODEME_TIPI"));
			logger.info("----tffBasvuruOdemeYap  KURYE_TIPI :" + kuryeTipi);
			logger.info("----tffBasvuruOdemeYap  KART_BEDELI :" + iMap.getString("KART_BEDELI"));
			logger.info("----tffBasvuruOdemeYap  KURYE_BEDELI :" + iMap.getString("KURYE_BEDELI"));
			logger.info("----tffBasvuruOdemeYap  LOYALTY_BEDELI :" + iMap.getString("LOYALTY_BEDELI"));
			logger.info("----tffBasvuruOdemeYap  VIZE_BEDELI :" + iMap.getString("VIZE_BEDELI"));
			
			
			logger.info("----tffBasvuruOdemeYap  TESLIMAT_ADRES_NO :" + iMap.getString("TESLIMAT_ADRES_NO"));
			
			

			basvuruOdemeTx.setOdemeRefId(odemeRefID);
			basvuruOdemeTx.setAktifbankEkPay(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AKTIFBANK_EK_PAY"), getAktifbankEkPayInner(basvuruOdemeTx.getBasvuruNo())));
			session.saveOrUpdate(basvuruOdemeTx);
			session.flush();
			if("D".equals(iMap.getString("ODEME_TIPI"))){
				iMap.put("EVENT_TYPE_NO", EVENT_TYPE_NO);
				iMap.put("EVENT_REF_NO", iMap.getBigDecimal("BASVURU_NO"));
				GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
			}
			iMap.put("TRX_NAME", "3802");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			if ( islemiOnayla ){
				if ( islemBasarili){
					
					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "O");
					onayMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					onayMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
					
					if("EPOS".equals(tffBasvuru.getSource()) || "NTS02".equals(tffBasvuru.getSource())) {
						if (!TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
							iMap.put("EVENT_TYPE_NO", EPOS_EVENT_TYPE_NO);
							iMap.put("EVENT_REF_NO", iMap.getBigDecimal("BASVURU_NO"));
							GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
						}
					}
				     try {
	                        iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
	                        iMap.put("CRM_TYPE", CrmTypes.MAIN);
	                        GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
	                    } catch (Exception e) {
	                        e.printStackTrace();
	                        logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + iMap.containsKey("TFF_BASVURU_NO"));
	                    }
				}
				else{
					GMMap onayRedMap = new GMMap();
					onayRedMap.put("ISLEM_TURU", "OR");
					onayRedMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					onayRedMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayRedMap));
					

		            try {
		                iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
		                iMap.put("CRM_TYPE", CrmTypes.MAIN);
		                GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
		            } catch (Exception e) {
		                e.printStackTrace();
		                logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + iMap.containsKey("TFF_BASVURU_NO"));
		            }
				}
			}
			else
			{
			    try {
                    iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
                    iMap.put("CRM_TYPE", CrmTypes.MAIN);
                    GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + iMap.containsKey("TFF_BASVURU_NO"));
                }
			}
			
			oMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

			/*Netmera durum kodu bildirmek icin asenkron cagri*/

			GMMap inputMap = new GMMap();
			inputMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			inputMap.put("DURUM_KOD", sonrakiDurumKodu);
			GMServiceExecuter.executeAsync("BNSPR_PUSH_KART_DURUM_GUNCELLE_EVENT", inputMap);

		}
		catch(Exception e){
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_GENEL_HATA);
			return oMap;
		}

		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3802_MUH_ISLEM_GUNCELLE")
	public static GMMap muhIslemGuncelle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3802.Muh_Islem_Guncelle(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/** Verilen iptal islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since PY-7842
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>BASVURU_NO - Basvuru numarasi
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>KURYE_TIPI - Kurye tipi
	 *         <li>TESLIMAT_ADRESI - Teslimat adresi
	 *         <li>IL - Teslimat adres ili
	 *         <li>ILCE - Teslimat adres ilcesi
	 *         <li>ACIK_ADRES - Teslimat acik adresi
	 *         <li>TESLIMAT_NOKTASI - PTT Sube/Stad Gise kodu
	 *         <li>TOPLAM_UCRET - Odenecek tutar
	 *         <li>ODEME_TIPI - Odeme tipi
	 *         <li>HESAP_NO - Odemenin alindigi hesap numarasi
	 */
	@GraymoundService("BNSPR_TRN3802_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ ? = call pkg_trn3802.Rc_Qry3802_Get_Islem_Info(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	/**
	 * 
	 * odeme yap,
	 * sanal pos, 
	 * odeme guncelle
	 * 
	 * Promosyon kodu olmayanlar icin
	 * 
	 * @param iMap
	 * <br>BASVURU_NO
	 * <br>KURYE_TIPI
	 * <br>TESLIMAT_ADRES_NO
	 *<br> KART_NO, 
	 * <br>KART_BITIS_TARIHI 10.2018, 
	 * <br>CVV2

	 * 

	 * 
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3802_SANAL_POS_ODEME_YAP")
	public static GMMap sanalPosOdemeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();

		//odeme servisi inputlari toparla
		GMMap odemeMap = new GMMap();
		
	
		odemeMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
		
		if(tffBasvuru == null){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_BASVURU_BULUNAMADI_HATASI);
			return oMap;
		}
		
		
		TffSsProductMap ssmap = (TffSsProductMap)session.createCriteria(TffSsProductMap.class)
				.add(Restrictions.eq("urunSahipKod", tffBasvuru.getUrunSahipKodu()))
				.add(Restrictions.eq("kartTipi",tffBasvuru.getKartTipi()))
				.add(Restrictions.eq("under18","H"))
				.add(Restrictions.eq("gecerli","E")).list().get(0);
	
		if(ssmap == null){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
			return oMap;
		}
		//GMMap odemeBilgileri = GMServiceExecuter.call("BNSPR_TFF_GET_KART_BEDELI", odemeMap);
		BigDecimal total = ssmap.getKartBedeli().add(ssmap.getLoyaltyBedeli()).add(ssmap.getVizeBedeli());
		BigDecimal kuryeBedeli = TffServicesHelper.getKuryeBedeli(iMap.getString("KURYE_TIPI"));
		if("S".equals(iMap.getString("KURYE_TIPI"))){
			total.add(kuryeBedeli);
		}
				
		
		
		odemeMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		odemeMap.put("KURYE_TIPI", iMap.getString("KURYE_TIPI"));
		odemeMap.put("ODEME_TIPI", "S");

		odemeMap.put("TESLIMAT_ADRES_NO", iMap.getString("TESLIMAT_ADRES_NO"));

		odemeMap.put("PROMOSYON_KODU",  "");
		//odemeMap.put("ODEME_REF_ID",  iMap.getString("ODEME_REF_ID"));
		odemeMap.put("KART_BEDELI",  ssmap.getKartBedeli());
		odemeMap.put("KURYE_BEDELI",  kuryeBedeli);
		
		odemeMap.put("LOYALTY_BEDELI",  ssmap.getLoyaltyBedeli());
		odemeMap.put("VIZE_BEDELI",  ssmap.getVizeBedeli());
		odemeMap.put("PROMOSYON_BEDELI", 0);
		odemeMap.put("SOURCE", tffBasvuru.getSource());
		tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_ODEME_YAP", odemeMap);

		GMMap sanalPosMap = new GMMap();
		GMMap sanalPosResultMap = new GMMap();
		if("2".equals(tmpMap.getString("RESPONSE"))){
			//basarili odeme servisi sonrasi sanalpos yap
			
			sanalPosMap.put("PARAMETRE", "POS_SANALPOS_TIPI");
			String posType = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sanalPosMap).getString("DEGER");
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));
			GnlPosChannelClientRel config = (GnlPosChannelClientRel)session.createCriteria(GnlPosChannelClientRel.class)
					.add(Restrictions.or(Restrictions.eq("channel", "IVR"),Restrictions.eq("channel", "CC")))
					.add(Restrictions.eq("processType","3802")).list().get(0);
			if(config == null){
				logger.error("-------------- sanalPosOdemeYap  : GnlPosChannelClientRel Sanalpos config kaydi bulunamadi -");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_SANAL_POS_HATA);
				return oMap;
			}
			/** Altyapi tarafinda pos type belirlenecek globalden okunup gondermeye gerek yok
			sanalPosMap.put("PARAMETRE", "POS_SANALPOS_TIPI");
			String posType = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sanalPosMap).getString("DEGER");
			sanalPosMap.put("POS_TYPE", posType);
			 */
			
			sanalPosMap.put("POS_TYPE", posType);
			String orderId ="IVR-"+ String.valueOf(tffBasvuruKimlik.getBasvuruNo());
			if("TR".equals(tffBasvuruKimlik.getUyrukKod())){
				orderId = orderId +"-"+tffBasvuruKimlik.getTcKimlikNo();
			}else{
				orderId = orderId +"-"+tffBasvuruKimlik.getPasaportNo();
			}
			orderId = "TFF-"+orderId +"-"+tmpMap.getString("ISLEM_NO");
			sanalPosMap.put("CLIENT_ID", config.getClientId());
			sanalPosMap.put("NAME", config.getName());
			sanalPosMap.put("PASSWORD", config.getPassword());
			sanalPosMap.put("CHANNEL", orderId.substring(0,15));
			sanalPosMap.put("ORDER_ID", orderId);
			sanalPosMap.put("NUMBER", iMap.getString("KART_NO"));
			sanalPosMap.put("EXPIRES", iMap.getString("KART_BITIS_TARIHI"));
			sanalPosMap.put("CVV2VAL", iMap.getString("CVV2"));
			sanalPosMap.put("TOTAL", total);//Totali mape koy
			sanalPosMap.put("CURRENCY", POS_DEFAULT_CURRENCY);
			//SANALPOS
			try {
				sanalPosResultMap = GMServiceExecuter.call("BNSPR_POS_AKTIFPOS_PAYMENT", sanalPosMap);
			} catch (Exception e) {
				logger.error("Sanal pos isleminde hata !!!!");
				logger.error(sanalPosResultMap.toString());
				e.printStackTrace();
				//sanalposu beceremediysen geri al
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_SANAL_POS_HATA);
				return oMap;
			}
			try {

				if(POS_APPROVED.equals(sanalPosResultMap.getString("RESPONSE"))){
					odemeMap.put("ODEME_REF_ID", posType+"-"+sanalPosResultMap.getString("TRANS_ID"));
					odemeMap.put("ISLEM_NO", tmpMap.getString("ISLEM_NO"));
					tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_TFF_BASVURU_ODEME_GUNCELLE", odemeMap);
					if(TffServicesMessages.RESPONSE_BASARILI.equals(tmpMap.getString("RESPONSE"))){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
						oMap.put("ODEME_REF_ID", sanalPosResultMap.getString("TRANS_ID"));
						return oMap;
					}else{
						logger.error("Sanal pos sonrasi odeme guncelle basarisiz");
						logger.error(tmpMap.toString());

						//cekilen paranin iadesi icin
						throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
					}
				}else{

					odemeMap.put("ODEME_REF_ID", sanalPosResultMap.getString("TRANS_ID"));
					odemeMap.put("ISLEM_NO", tmpMap.getString("ISLEM_NO"));
					odemeMap.put("ISLEM_BASARISIZ", "E");
					tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_TFF_BASVURU_ODEME_GUNCELLE", odemeMap);
				}
			} catch (Exception e) {
				logger.error("Sanal pos sonrasi odeme guncelede hata !!!!");
				logger.error(odemeMap.toString());
				e.printStackTrace();
				//odeme guncellemeyi beceremediysen geri al
				sanalPosResultMap = GMServiceExecuter.call("BNSPR_POS_AKTIFPOS_VOID", sanalPosMap);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_SANAL_POS_HATA);
				return oMap;
			}


		}else{//odeme yap basarisiz
			oMap.putAll(tmpMap);
		}

		return oMap;
	}
	
	private static BigDecimal getAktifbankEkPayInner(BigDecimal tffBasvuruNo) {
		GMMap sorguMap = new GMMap();
		sorguMap.put("TFF_BASVURU_NO", tffBasvuruNo);
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3802_GET_AKTIFBANK_EK_PAY", sorguMap));
		return sorguMap.getBigDecimal("AKTIFBANK_EK_PAY");
	}
	
	@GraymoundService("BNSPR_TRN3802_GET_AKTIFBANK_EK_PAY")
	public static GMMap getAktifbankEkPay(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_tff_basvuru.Get_Aktifbank_Payi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("ODEME_ISLEM_NO"));
			stmt.execute();

			oMap.put("AKTIFBANK_EK_PAY", CreditCardServicesUtil.nvl(stmt.getBigDecimal(1), BigDecimal.ZERO));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3802_TFF_BASVURU_ODEME_TIPI_GUNCELLE")
	public static GMMap tffBasvuruOdemeTipiGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		String islemNo = "";
		BigDecimal vdBasvuruNo = BigDecimal.ZERO;
		if ( StringUtils.isNotEmpty(iMap.getString("ISLEM_NO")) ){
			islemNo =iMap.getString("ISLEM_NO") ;	
		}
		else{
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_ISLEM_NO_EKSIK_HATASI);
			return oMap;
		}
		
		BigDecimal odemeBasvuruNo = BigDecimal.ZERO;
		
		TffBasvuruOdemeTx basvuruOdemeTx = (TffBasvuruOdemeTx)session.get(TffBasvuruOdemeTx.class, new BigDecimal(islemNo));// session.createCriteria(TffBasvuruOdemeTx.class).add(Restrictions.eq("txNo", new BigDecimal(islemNo))).uniqueResult();
		
		if (basvuruOdemeTx != null) {
				
				logger.info("----tffBasvuruOdemeTipiGuncelle  TRX_NO " + iMap.getString("ISLEM_NO"));
				logger.info("----tffBasvuruOdemeTipiGuncelle  BASVURU_NO " + iMap.getString("BASVURU_NO"));
			
				basvuruOdemeTx.setOdemeSekli(iMap.getString("ODEME_TIPI"));
				session.saveOrUpdate(basvuruOdemeTx);
				session.flush();

				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
				odemeBasvuruNo = basvuruOdemeTx.getBasvuruNo();

		}
		else {
			//vade yenileme ba�vurusu mu?
			TffBasvuruVdOdemeTx basvuruVdOdemeTx = (TffBasvuruVdOdemeTx)session.get(TffBasvuruVdOdemeTx.class, new BigDecimal(islemNo));
			vdBasvuruNo = basvuruVdOdemeTx.getBasvuruNo();
			
			if (basvuruVdOdemeTx != null) {
					
					logger.info("----tffBasvuruOdemeTipiGuncelle Skt TRX_NO " + iMap.getString("ISLEM_NO"));
					logger.info("----tffBasvuruOdemeTipiGuncelle Skt BASVURU_NO " + iMap.getString("BASVURU_NO"));
				
					basvuruVdOdemeTx.setOdemeSekli(iMap.getString("ODEME_TIPI"));
					session.saveOrUpdate(basvuruVdOdemeTx);
					session.flush();

					oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
				
			}
			
			else{
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_ISLEM_NO_EKSIK_HATASI);
			}
		}
		
		
		TffBasvuruOdeme basvuruOdeme = (TffBasvuruOdeme)session.get(TffBasvuruOdeme.class, odemeBasvuruNo);

		if (basvuruOdeme != null) {
			
			logger.info("----tffBasvuruOdemeTipiGuncelle  TRX_NO " + iMap.getString("ISLEM_NO"));
			logger.info("----tffBasvuruOdemeTipiGuncelle  BASVURU_NO " + iMap.getString("BASVURU_NO"));
		
			basvuruOdeme.setOdemeSekli(iMap.getString("ODEME_TIPI"));
			session.saveOrUpdate(basvuruOdeme);
			session.flush();

			oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
		
		}
		else {
			
			if (vdBasvuruNo.compareTo(BigDecimal.ZERO)>0){
				
				TffBasvuruVdOdeme basvuruVdOdeme = (TffBasvuruVdOdeme)session.get(TffBasvuruVdOdeme.class, vdBasvuruNo);
				if (basvuruVdOdeme != null) {
				logger.info("----tffBasvuruOdemeTipiGuncelle Skt TRX_NO " + iMap.getString("ISLEM_NO"));
				logger.info("----tffBasvuruOdemeTipiGuncelle Skt  BASVURU_NO " + iMap.getString("BASVURU_NO"));
			
				basvuruVdOdeme.setOdemeSekli(iMap.getString("ODEME_TIPI"));
				session.saveOrUpdate(basvuruVdOdeme);
				session.flush();
	
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);
				}
				else{
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_ISLEM_NO_EKSIK_HATASI);
				}
			}
		}
		
		return oMap;

	}
	
	private static String getKuryeTipi(String source, String kuryeTipi, boolean tcVatandasi) {

		String kuryeTipiSon = kuryeTipi;
		if(MOBILE_SRC.equals(source)){

			if (tcVatandasi){
				kuryeTipiSon =	"S";
			}
			else{
				kuryeTipiSon =	"GN";
			}

		}
		return kuryeTipiSon;
		
	}
	
	
	@GraymoundService("BNSPR_TFF_SANALPOS_ODEME_YAP_BY_KANAL")
	public static GMMap sktSanalPosOdemeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		String serviceNameOdeme;
		String serviceNameGuncelle;
		boolean vadeYenilemeMi = false;
		//odeme servisi inputlari toparla
		GMMap odemeMap = new GMMap();
        GMMap ispMap = new GMMap();
        GMMap ospMap = new GMMap();
		
	
		odemeMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
		
		if(tffBasvuru == null){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_BASVURU_BULUNAMADI_HATASI);
			return oMap;
		}
		
		if (vadeYenilemeBasvurusuMu(tffBasvuru, true)){
			vadeYenilemeMi = true;
			serviceNameOdeme="BNSPR_VADE_YENILEME_ODEME_YAP";	
			serviceNameGuncelle ="BNSPR_VADE_YENILEME_ODEME_GUNCELLE";

		}
		else{
			serviceNameOdeme ="BNSPR_TRN3802_ODEME_YAP";
			serviceNameGuncelle="BNSPR_TRN3802_TFF_BASVURU_ODEME_GUNCELLE";
		}


		odemeMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		odemeMap.put("KURYE_TIPI", iMap.getString("KURYE_TIPI",""));
		odemeMap.put("ODEME_TIPI", "S");

		odemeMap.put("TESLIMAT_ADRES_NO", iMap.getString("TESLIMAT_ADRES_NO"));

		odemeMap.put("PROMOSYON_KODU",  iMap.getBigDecimal("PROMOSYON_KODU"));// "");
		//odemeMap.put("ODEME_REF_ID",  iMap.getString("ODEME_REF_ID"));
		odemeMap.put("KART_BEDELI",  iMap.getBigDecimal("KART_BEDELI"));// ssmap.getKartBedeli());
		odemeMap.put("KURYE_BEDELI", iMap.getBigDecimal("KURYE_BEDELI"));// kuryeBedeli);
		
		odemeMap.put("LOYALTY_BEDELI",  iMap.getBigDecimal("LOYALTY_BEDELI")); //ssmap.getLoyaltyBedeli());
		odemeMap.put("VIZE_BEDELI", iMap.getBigDecimal("VIZE_BEDELI"));// ssmap.getVizeBedeli());
		
		if(StringUtils.isBlank(iMap.getString("PROMOSYON_BEDELI"))){
			iMap.put("PROMOSYON_BEDELI",BigDecimal.ZERO);
		}
		else
			odemeMap.put("PROMOSYON_BEDELI", iMap.getString("PROMOSYON_BEDELI"));
		odemeMap.put("SOURCE", tffBasvuru.getSource());
		
		BigDecimal total = iMap.getBigDecimal("KART_BEDELI").add(iMap.getBigDecimal("KURYE_BEDELI")).add(iMap.getBigDecimal("LOYALTY_BEDELI")).add(iMap.getBigDecimal("VIZE_BEDELI"));		
		odemeMap.put("TOPLAM_BEDEL", total);
		
		tmpMap = GMServiceExecuter.call(serviceNameOdeme, odemeMap);

		GMMap sanalPosMap = new GMMap();
		GMMap sanalPosResultMap = new GMMap();
		if("2".equals(tmpMap.getString("RESPONSE"))){
			//basarili odeme servisi sonrasi sanalpos yap
			
			sanalPosMap.put("PARAMETRE", "POS_SANALPOS_TIPI");
			String posType = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sanalPosMap).getString("DEGER");
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

            ispMap.put("CHANNEL", "IVR");
            ispMap.put("SUB_CHANNEL", "KartYenileme");
            ispMap.put("PROCESS_TYPE", "1000");
        
            ospMap= GMServiceExecuter.call("BNSPR_POS_AKTIFPOS_GET_AUTH_INFO", ispMap);
            
            sanalPosMap.put("NAME" , ospMap.getString("NAME"));
            sanalPosMap.put("PASSWORD" , ospMap.getString("PASSWORD"));
            sanalPosMap.put("CLIENT_ID" , ospMap.getString("CLIENT_ID"));


			sanalPosMap.put("POS_TYPE", posType);
			String orderId = generateOrderId(vadeYenilemeMi ,iMap.getString("SOURCE"),tffBasvuruKimlik.getUyrukKod(),tffBasvuruKimlik.getTcKimlikNo(),tffBasvuruKimlik.getPasaportNo(),iMap.getString("BASVURU_NO"), tmpMap.getString("ISLEM_NO"));
		
			sanalPosMap.put("CHANNEL", orderId.substring(0,15));
			sanalPosMap.put("ORDER_ID", orderId);
			sanalPosMap.put("NUMBER", iMap.getString("KART_NO"));
			sanalPosMap.put("EXPIRES", iMap.getString("KART_BITIS_TARIHI"));
			sanalPosMap.put("CVV2VAL", iMap.getString("CVV2"));
			sanalPosMap.put("TOTAL", total);//Totali mape koy
			sanalPosMap.put("CURRENCY", POS_DEFAULT_CURRENCY);
			//SANALPOS
			try {
				sanalPosResultMap.putAll(GMServiceExecuter.call("BNSPR_POS_AKTIFPOS_PAYMENT", sanalPosMap));
			} catch (Exception e) {
				logger.error("Sanal pos isleminde hata !!!!");
				logger.error(sanalPosResultMap.toString());
				e.printStackTrace();
				//sanalpos hata verdiyse geri al
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_SANAL_POS_HATA);
				return oMap;
			}
			try {
				if(POS_APPROVED.equals(sanalPosResultMap.getString("RESPONSE"))){
					odemeMap.put("ODEME_REF_ID", orderId);
					odemeMap.put("ISLEM_NO", tmpMap.getString("ISLEM_NO"));
					tmpMap.putAll(GMServiceExecuter.call(serviceNameGuncelle, odemeMap));
					if(TffServicesMessages.RESPONSE_BASARILI.equals(tmpMap.getString("RESPONSE"))){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
						oMap.put("ODEME_REF_ID", orderId);
						oMap.put("STATUS", 1);
						//return oMap; vadeyenileme �a��r
					}else{
						logger.error("Sanal pos sonrasi odeme guncelle basarisiz");
						logger.error(tmpMap.toString());

						//cekilen paranin iadesi icin
						throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
					}
				}else{

					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_SANAL_POS_HATA);
					return oMap;
				}
			} catch (Exception e) {
				logger.error("Sanal pos sonrasi odeme guncellede hata !!!!");
				logger.error(odemeMap.toString());
				e.printStackTrace();
				//odeme guncellemeyi beceremediysen geri al
				sanalPosResultMap = GMServiceExecuter.call("BNSPR_POS_AKTIFPOS_VOID", sanalPosMap);
				if(!POS_APPROVED.equals(sanalPosResultMap.getString("RESPONSE")))
					sanalPosHataMailAt(true, sanalPosMap, sanalPosResultMap);
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.SANAL_POS_SONRASI_ODEME_GUNCELLE_HATA);
					return oMap;
			}
			
		}else{//odeme yap basarisiz
			oMap.putAll(tmpMap);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_GENEL_HATA);
			return oMap;
		}
		//ba�vuru �demesi ise ��k
		
		if (vadeYenilemeMi) {
			//vizeleme card renewal
			GMMap visaMap = new GMMap();

			try {
				visaMap.put("APPLICATION_NO", iMap.getBigDecimal("BASVURU_NO"));
				visaMap.put("BRANCH_CODE", iMap.getString("SUBE_KOD"));
				visaMap.put("CARD_DELIVERY_TYPE", iMap.getString("CARD_DELIVERY_TYPE"));
				visaMap.put("CARD_POST_IDX", iMap.getString("CARD_POST_IDX"));
		        visaMap.put("ADDRESS_CITY", iMap.getString("ADRES_IL"));
		        visaMap.put("ADDRESS_CITY_CODE", iMap.getString("ADRES_IL_KOD"));
		        visaMap.put("ADDRESS_COUNTRY", iMap.getString("ADRES_ULKE"));
		        visaMap.put("ADDRESS_TOWN_CODE", iMap.getString("ADRES_ILCE_KOD"));
		        visaMap.put("ADDRESS_TOWN", iMap.getString("ADRES_ILCE"));
		        visaMap.put("ADDRESS_ZIP_CODE", iMap.getString("ADRES_POSTA_KOD"));
		        visaMap.put("ADDRESS1", iMap.getString("ACIK_ADRES"));
		        visaMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());

				visaMap = GMServiceExecuter.call("BNSPR_INTRACARD_VADE_YENILEME", visaMap);
				
				if(! TffServicesMessages.RESPONSE_BASARILI.equals(visaMap.getString("RESPONSE"))){
					//todo: �deme iptal ak���
					//sanalpos iptal ak���
					logger.error("Sanal pos ve �deme sonras� vade yenilemede hata !!!!");
					logger.error(visaMap.toString());

					throw new GMRuntimeException(0,visaMap.getString("RESPONSE_DATA"));
				}
			} catch (Exception e) {

				logger.error("Sanal pos ve �deme sonras� vade yenilemede hata alindi");
				logger.error(visaMap.toString());
				e.printStackTrace();
				//todo: �deme iptal ak���
				BigDecimal iptalTrxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO").toString());
				odemeMap.put("TRX_NO", iptalTrxNo);
				odemeMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				odemeMap.put("ACIKLAMA", "Sanal pos ve �deme sonras� vade yenilemede hata");
				odemeMap.put("HATA_ACIKLAMA", e.toString());
				odemeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_VADE_YENILEME_ODEME_IPTAL", odemeMap));
		
				//�deme iptal ak���
				sanalPosResultMap = GMServiceExecuter.call("BNSPR_POS_AKTIFPOS_VOID", sanalPosMap);
				if(!POS_APPROVED.equals(sanalPosResultMap.getString("RESPONSE")))
				sanalPosHataMailAt(true, sanalPosMap, sanalPosResultMap);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_ALINDI_YENILEMEDE_HATA);
			
				return oMap;
			}
					
		}

		return oMap;
	}
	
	
	private static String generateOrderId(boolean vadeYenileme, String source, String uyrukKod, String tckn, String pasaportNo, String applicationNo, String txNo){
		
		String orderId = (vadeYenileme ? "S" : "B") + source.substring(0,3) + "_"+ applicationNo ;
		
		if("TR".equals(uyrukKod)){
			orderId = orderId +"_"+tckn;
		}else{
			orderId = orderId +"_"+pasaportNo;
		}
		 orderId = orderId + "_" + txNo;
    return orderId;

	}
    
	public static boolean vadeYenilemeBasvurusuMu(TffBasvuru tffBasvuru, boolean ccKanal){
		
		if (!ccKanal){ //cc kanal�ndan geliyorsa ya vade yenilemedir ya da skt yeni ba�vuru, normal ba�vuru ak��� olamaz
			
			if (tffBasvuru.getVdBasvuruNo() != null  &&  tffBasvuru.getVdBasvuruNo().compareTo(BigDecimal.ZERO) !=0 ){
				
				return tffBasvuru.getBasvuruNo().equals(tffBasvuru.getVdBasvuruNo());
			}
		}
		else{

			if (tffBasvuru.getVdBasvuruMu() != null  &&  "E".equals(tffBasvuru.getVdBasvuruMu()) ){
				 return false;
			}
			return true;

		}

		 return false;
	}
	
	public static void sanalPosHataMailAt(boolean iptalMi, GMMap iMap, GMMap oMap){
		String mailFrom = "system@aktifbank.com.tr";
		String mailToParametre = "SKT_SANAPOS_MAIL_TO";
		String mailSubject;
		if (iptalMi)
		mailSubject = "SKT VADE YENILEME SANAL POS ODEME IPTALI HATA";
		else
		mailSubject = "SKT VADE YENILEME SANAL POS ODEME HATA";
		
		String mailBody = mailSubject;
		mailBody += "<br> HATA" + oMap.toString();
		mailBody += "<br> MAP" + iMap.toString();
		TffServicesHelper.sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
	}
	
	
}
