package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirDogrulamaKayit;
import tr.com.aktifbank.bnspr.dao.BirDogrulamaKayitTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.KkDogrulamaDetayTx;
import tr.com.aktifbank.bnspr.dao.KkDogrulamaDetayTxId;
import tr.com.aktifbank.bnspr.dao.KkDogrulamaTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


/** BNSPR_TRN3880 ile baslayan ekranlarin servislerini icerir.
 * 
 * @author murat.el
 * @since 21/08/2013
 */
public class CreditCardTRN3880Services {
		
	//---------------------------------------------------------------------
	//******************************************************* 3880 Ekrani
	//---------------------------------------------------------------------
	/**
	 * BNSPR_TRN3880.guiml ekrani acilisinda alinacak degerleri ekrana aktarir.
	 */
	@GraymoundService("BNSPR_TRN3880_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Dogrulama Sonucu
			oMap.putAll(CreditCardServicesUtil.getParameterList("DOGRULAMA_SONUCU", "BAS_DOGRULAMA_KOD", "E"));
			
			//Randevu Mu?
			oMap.putAll(CreditCardServicesUtil.getParameterList("RANDEVU_MU", "EVET_HAYIR", "E"));
			
			//Calisma Sekli
			oMap.putAll(CreditCardServicesUtil.getParameterList("CALISMA_SEKLI_KOD", "CALISMA_SEKLI", "E"));

			//Isyeri Faaliyet Alani
			oMap.putAll(CreditCardServicesUtil.getParameterList("ISYERI_FAAL_KONU_KOD", "ISYERI_FAAL_KONU_KOD", "E"));

			//Isyeri Karar
			GuimlUtil.wrapMyCombo(oMap, "ISYERI_KARAR", "KABUL", "Kabul");
			GuimlUtil.wrapMyCombo(oMap, "ISYERI_KARAR", "RED", "Red");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * BNSPR_TRN3880.guiml ekrani Dogrulama Sonucu combosundan secilen degere gore
	 * Dogrulama Sebebi combosunu doldurur.
	 * 
	 * @param iMap - DOGRULAMA_SONUCU
	 * @return {@link GMMap} - DOGRULAMA_SEBEBI
	 */
	@GraymoundService("BNSPR_TRN3880_GET_DOGRULAMA_SEBEBI")
	public static GMMap fillDogrulamaSebebiList(GMMap iMap) {
		String key = iMap.getString("DOGRULAMA_SONUCU");
		return CreditCardServicesUtil.getParameterList("DOGRULAMA_SEBEBI", "BAS_ISYERI_DOG_SEBEP", key, "E");
	}

	/** BNSPR_TRN3880.guiml ekrani Calisma Sekli combosundan secilen degere gore
	 * dogum tarihi ve egitim durumu kriterleri ile Meslek combosunu doldurur.
	 * 
	 * @param egitimDurum - Basvuruyu yapan kisinin ogrenim durumu
	 * @param calismaSekli - Basvuruyu yapan kisinin calisma sekli
	 * @param dogumTarihi - Basvuruyu yapan kisinin dogum tarihi
	 * @return {@link GMMap} - MESLEK_LIST
	 */
	private static GMMap fillMeslekList(String egitimDurum, String calismaSekli, Date dogumTarihi) {
		GMMap oMap = new GMMap();
		
		try {
			GMMap iMap = new GMMap();
			
			//Banka tarihini al
			String bankaTarihi =
					GMServiceExecuter.execute("BNSPR_COMMON_GET_BANKA_TARIH", iMap).get("BANKA_TARIH").toString();
			
			iMap.put("EGITIM_KOD", egitimDurum);
			iMap.put("CALISMA_SEKLI", calismaSekli);
			iMap.put("BANKA_TARIHI", bankaTarihi);
			iMap.put("DOGUM_TARIHI", dogumTarihi);
			iMap.put("BOS_ALAN", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MESLEKLER", iMap));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/** BNSPR_TRN3880.guiml ekrani basvuruya ait alinacak dogrulama aksiyonlarini bulur.
	 * <br>Ekrandaki Dogrulama Bilgileri Paneli.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru Dogrulama Aksiyon Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3880_GET_DOG_AKS_INFO")
    public static GMMap getDogrulamaAksiyonInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

        try {
            conn = DALUtil.getGMConnection();
            // Dogrulama Aksiyon Bilgilerini Al
            query = "{? = call PKG_TRN3880.RC_QRY3880_GET_DOG_AKS_INFO(?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
            stmt.execute();
            
            //Aksiyon combo degerleri
            String comboListName = "AKSIYON_COMBO";
			oMap.put(comboListName, (String) null);
			
			rSet = (ResultSet)stmt.getObject(1);
			if (rSet.next()) {
				oMap.put("ISYERI_ARAMA_ADET", rSet.getBigDecimal("ISYERI_ARAMA_ADET"));
				oMap.put("ISYERI_AKSIYON_KOD", rSet.getString("ISYERI_AKSIYON_KOD"));
				GuimlUtil.wrapMyCombo(oMap, comboListName,
						rSet.getString("ISYERI_AKSIYON_KOD"), rSet.getString("ISYERI_AKSIYON_ACIKLAMA"));

				oMap.put("WEB_ACIKLAMA", "(" + rSet.getString("WEB_ACIKLAMA") + ")");
				oMap.put("WEB_AKSIYON_KOD", rSet.getString("WEB_AKSIYON_KOD"));
				GuimlUtil.wrapMyCombo(oMap, comboListName,
						rSet.getString("WEB_AKSIYON_KOD"), rSet.getString("WEB_AKSIYON_ACIKLAMA"));
			}
        } catch(Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }
	
	/** BNSPR_TRN3880.guiml ekrani isyeri dogrulamasi icin gerekli bilgileri bulur
	 * <br>Ekrandaki Isyeri Tabi->Musteri Isyeri Dogrulama Bilgileri Paneli.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Musteri/Isyeri Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3880_GET_ISYERI_DETAY")
	public static GMMap getIsyeriDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TRN3880.Rc_Qry3880_Get_Isyeri_Detay(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, "MI");
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));

			//Ekrandaki meslek comboboxini doldur
			//Service parameters
			String ogrenimDurumu = oMap.getString("OGRENIM_DURUM_KOD");
			Date dogumTarihi = new java.sql.Date(oMap.getDate("DOGUM_TARIHI").getTime());
			if(dogumTarihi != null && ogrenimDurumu != null) {
				oMap.putAll(fillMeslekList(ogrenimDurumu, oMap.getString("CALISMA_SEKLI"), dogumTarihi));
			}
			
			//Ekrandaki unvan comboboxini doldur
			iMap.put("MESLEK_KOD", oMap.getString("MESLEK"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_UNVAN_TURLERI", iMap));
			
			//Isyeri dogrulama nedenini al
			oMap.put("DOGRULAMA_NEDENI", getIsyeriDogrulamaNedeni(iMap.getBigDecimal("BASVURU_NO")));
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3880.guiml ekrani varsa yapilan son dogrulamaya ait bilgileri bulur.
	 * <br>Ekrandaki Dogrulama Bilgileri Paneli->Son Dogrulama Paneli.
	 * <br>Ekrandaki Isyeri Tabi->Isyeri Dogrulama Bilgileri Paneli->Yeni Bilgiler Paneli.
	 * 
	 * @param iMap - BASVURU_NO, KONTROL_TIPI
	 * @return {@link GMMap} - Basvuru Dogrulama Aksiyon Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3880_GET_SON_DOGRULAMA")
	public static GMMap getSonDogrulama(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			//Dogrulama Durumu Bilgilerini Al
			query = "{call PKG_TRN3880.Rc_Qry3880_Dog_Son_Durum(?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("KONTROL_TIPI"));
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.TIMESTAMP);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.registerOutParameter(11, Types.VARCHAR);
			stmt.execute();
			
			//Degerleri Al.
			oMap.put("SON_DOG_SONUC_KOD", stmt.getString(3));
			oMap.put("SON_DOG_SONUC_ACIKLAMA", stmt.getString(5));
			//oMap.put("SON_DOG_SEBEP_KOD", stmt.getString(6));
			oMap.put("SON_DOG_SEBEP_ACIKLAMA", stmt.getString(7));
			oMap.put("SON_DOG_RANDEVU_MU", stmt.getString(8));
			oMap.put("SON_GORUSULEN_KISI", stmt.getString(9));
			oMap.put("SON_GORUSULEN_UNVAN", stmt.getString(10));
			oMap.put("ACIKLAMA", stmt.getString(11));
			
			if (stmt.getTimestamp(4) != null) {
				String[] tarihSaat = splitDateAndTime(stmt.getTimestamp(4));

				oMap.put("SON_DOG_TARIH", tarihSaat[0]);
				oMap.put("SON_DOG_TARIH_SAAT", tarihSaat[1]);
			}

			GMServerDatasource.close(stmt);

			//Dogrulama Kayit Bilgilerini Al
			query = "{? = call PKG_TRN3880.Rc_Qry3880_Get_Dog_Kayit(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("KONTROL_TIPI"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			String calismaSuresi = oMap.getString("YENI_ISYERINDE_CALISMA_SURESI");
			if(calismaSuresi != null && calismaSuresi.length() == 4) {
				oMap.put("YENI_IS_CALISMA_SURESI_YIL", calismaSuresi.substring(0, 2));
				oMap.put("YENI_IS_CALISMA_SURESI_AY", calismaSuresi.substring(2, 4));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** Basvuruya ait daha onceden yapilmis bir dogrulama varsa nedenini bulur.
	 * 
	 * @param basvuruNo - Basvuru Numarasi
	 * @return Dogrulama Nedeni
	 */
	private static String getIsyeriDogrulamaNedeni(BigDecimal basvuruNo) {
		String dogrulamaNedeni = null;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_TRN3880.GET_ISYERI_DOGRULAMA_NEDENI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			if(rSet.next()) {
				dogrulamaNedeni = rSet.getString("NEDEN_KOD");
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return dogrulamaNedeni;
	}
	
	/** BNSPR_TRN3880.guiml ekrani Yapilmis bir dogrulamaya ait bilgileri
	 * basvuru numarasi ya da islem numarasina gore bulur.
	 * <br>Ekrani izleme modunda acinca calisir ve tum alanlari doldurur.
	 * 
	 * @param iMap - BASVURU_NO, TRX_NO
	 * @return {@link GMMap}
	 */
	@GraymoundService("BNSPR_TRN3880_GET_DOGRULAMA_DETAY")
	public static GMMap getDogrulamaDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			org.hibernate.Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Dogrulama Bilgilerini Al.
			KkDogrulamaTx kkDogrulamaTx = null;
			if (iMap.getBigDecimal("TRX_NO") != null) {
				kkDogrulamaTx = (KkDogrulamaTx)
						session.get(KkDogrulamaTx.class, iMap.getBigDecimal("TRX_NO"));
			} else if (iMap.getBigDecimal("BASVURU_NO") != null) {
				List<?> list = session.createCriteria(KkDogrulamaTx.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
				.addOrder(Order.desc("txNo"))
				.setMaxResults(1)
				.list();
				
				if (list != null && !list.isEmpty()) {
					kkDogrulamaTx = (KkDogrulamaTx) list.get(0);
				}
			}

			if (kkDogrulamaTx != null) {
				String[] tarihSaat = splitDateAndTime(kkDogrulamaTx.getMusIsyeriDogSaat());
				oMap.put("MUS_ISYERI_RANDEVU_TARIHI", tarihSaat[0]);
				oMap.put("MUS_ISYERI_RANDEVU_SAATI", tarihSaat[1]);
				oMap.put("BASVURU_NO", kkDogrulamaTx.getBasvuruNo());
				oMap.put("TRX_NO", kkDogrulamaTx.getTxNo());

				// Musteri Isyeri Dogrulama Detay Bilgilerini Al
				KkDogrulamaDetayTx kkDogrulamaDetayTx = (KkDogrulamaDetayTx)
						session.createCriteria(KkDogrulamaDetayTx.class)
						.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
						.add(Restrictions.eq("id.dogrulamaTipKod", "MI"))
						.uniqueResult();
				
				if (kkDogrulamaDetayTx != null) {
					oMap.put("MUS_ISYERI_ACIKLAMA", kkDogrulamaDetayTx.getAciklama());
					oMap.put("MUS_ISYERI_DOGRULAMA_KOD", kkDogrulamaDetayTx.getDogrulamaKod());
					oMap.put("MUS_ISYERI_DOGRULAMA_SEBEP_KOD", kkDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("MUS_ISYERI_GORUSULEN_ISIM", kkDogrulamaDetayTx.getGorusulenIsim());
					oMap.put("MUS_ISYERI_GORUSULEN_UNVAN", kkDogrulamaDetayTx.getGorusulenUnvan());
					oMap.put("MUS_ISYERI_YENI_CALISMA_SEKLI_KOD", kkDogrulamaDetayTx.getYeniCalismaSekliKod());
					oMap.put("MUS_ISYERI_YENI_IS_ADRES", kkDogrulamaDetayTx.getYeniIsAdres());
					oMap.put("MUS_ISYERI_YENI_ISYERI_ADI", kkDogrulamaDetayTx.getYeniIsyeriAdi());
					
					String calismaSuresi = kkDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
					if (calismaSuresi != null) {
						oMap.put("MUS_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
						oMap.put("MUS_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
					}
					
					oMap.put("MUS_ISYERI_YENI_MESLEK_KOD", kkDogrulamaDetayTx.getYeniMeslekKod());
					oMap.put("MUS_ISYERI_YENI_UNVAN", kkDogrulamaDetayTx.getYeniUnvan());
					oMap.put("MUS_YENI_ISYERINDE_FAAL_KONU_KOD", kkDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
					oMap.put("MUS_YENI_GELIR", kkDogrulamaDetayTx.getYeniGelir());
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3880.guiml ekrani Web dogrulamasi icin basvuru numarasi ve guvenlik kodu ile
	 *  esgm sitesinde dogrulama sorgusunu gerceklestirir.
	 * <br>Ekrandaki Web Tabi->Bilgileri Getir Butonu
	 * 
	 * @param iMap - BASVURU_NO, GUVENLIK_KODU
	 * @return {@link GMMap}
	 */
	@GraymoundService("BNSPR_TRN3880_WEB_BILGILERI_GETIR")
	public static GMMap getWebBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Captcha islemlerini gerceklestir.
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3880_ESGM_SORGU", iMap));
			
			//Sorgu Sonucu Kontrol
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_KK_BASVURU_SORGU.ESGM_DOGRULAMA_DEGER('VerAppWebSystemF',?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
				stmt.execute();
				
				if (CreditCardServicesUtil.YES.equals(stmt.getString(1))) {
					CreditCardServicesUtil.raiseGMError("2580");
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3880_ESGM_SORGU")
	public static GMMap getApplicationCaptcha(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Basvuru bilgisi varsa kimlik bilgilerini al
			KkBasvuruKimlik kkbasvuruKimlik = null;
			if(iMap.getBigDecimal("BASVURU_NO") != null) {
				kkbasvuruKimlik = (KkBasvuruKimlik)
						session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));
			}

			//Kimlik bilgisi varsa esgm sorgu servisini calistir
			if(kkbasvuruKimlik != null) {
				//Sorgula
				GMMap tMap = new GMMap();
				tMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
				tMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
				tMap.put("TCKN", kkbasvuruKimlik.getTcKimlikNo());
				tMap.put("IL_KODU", kkbasvuruKimlik.getNufusIlKod());
				tMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(kkbasvuruKimlik.getDogumTar()));
				tMap.put("CILT_NO", kkbasvuruKimlik.getCiltNo());
				tMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_SOLVE_CAPTCHA", tMap));
				
				//Sorgu Kontrol
				if ("0".equals(oMap.getString("RESPONSE"))) {
					oMap.put("RESPONSE", 0);
					oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));

					return oMap;
				}
				
				//Response Parse
				ADCSession.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_PARSE", tMap);
				ADCSession.remove("BASVURU_NO");
			}

			oMap.put("RESPONSE", 2);
			oMap.put("RESPONSE_DATA", "");
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3880.guiml ekrani acilisinda daha onceden yapilmis ESGM sorgu sonuclarini listeler
	 * <br>Ekrandaki Web Tabi->ESGM_SORGU_SONUC tablosunu doldurur
	 * 
	 * @param iMap - BASVURU_NO
	 * @return Varolan ESGM Sorgu Sonucu:ESGM_SORGU_SONUC
	 */
	@GraymoundService("BNSPR_TRN3880_GET_ESGM_SORGU_SONUC")
	public static GMMap esgmSorguSonuc(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TRN3880.Rc_Qry3880_Esgm_Sorgu(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "ESGM_SORGU_SONUC"));
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3880.guiml ekranindan girilen dogrulama bilgilerini kaydeder.
	 * 
	 * @param iMap - Ekrandaki tum bilgiler
	 * @return oMap - Islem sonucu
	 */
	@GraymoundService("BNSPR_TRN3880_SAVE")
    public static GMMap saveTRN3880(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		//initial common variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
		
        try {
        	//Session ac
            Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
            
            //Sessionda dogrulama bilgisi varsa al
    		Object dogrulamaInstance = DogrulamaTipKodu.getInstance();
			DogrulamaTipKodu.putAll(ADCSession.get("3880_DYN_INS_" + trxNo), dogrulamaInstance);

            //Kayit islemi icin yeni bir ID al
            BigDecimal idNo = getIdNo(basvuruNo);
            
            //Dogrulama Kaydini Olustur
            KkDogrulamaTx kkDogrulamaTx = (KkDogrulamaTx) session.get(KkDogrulamaTx.class, trxNo);
            if(kkDogrulamaTx == null) {
            	kkDogrulamaTx = new KkDogrulamaTx();
            }
            
            kkDogrulamaTx.setIdNo(idNo);
        	kkDogrulamaTx.setTxNo(trxNo);
        	kkDogrulamaTx.setBasvuruNo(basvuruNo);
        	kkDogrulamaTx.setOncekiDurumKodu(iMap.getString("ONCEKI_DURUM_KOD"));

        	//Isyeri icin Dogrulama Islemi Yapildi ise
        	boolean dogrulamaYapildiMi = false;
        	if (iMap.getString("MUS_ISYERI_DOGRULAMA_KOD") != null) {
        		//Isyeri Dogrulama Bilgilerini Olustur
        		kkDogrulamaTx.setMusIsyeriDogKod(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD"));
        		
        		//Dogrulama Sonucu Tekrar Aranacak ise Zaman Bilgisini Kontrol Et
        		if ("3".equals(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD"))) {
					if (iMap.getString("MUS_ISYERI_RANDEVU_TARIHI") != null) {
						kkDogrulamaTx.setMusDogIsyeriSaatTip("E");
						
						java.util.Date dogZamani = addTimeToDate(iMap.getDate("MUS_ISYERI_RANDEVU_TARIHI"), iMap.getString("MUS_ISYERI_RANDEVU_SAATI"));
						kkDogrulamaTx.setMusIsyeriDogSaat(dogZamani);
					} else {
						kkDogrulamaTx.setMusDogIsyeriSaatTip("H");
						
						query = "{? = call PKG_TRN3180.randevu_tarih_saati()}";
						Timestamp dogZamani = (Timestamp) DALUtil.callNoParameterFunction(query, Types.TIMESTAMP);
						kkDogrulamaTx.setMusIsyeriDogSaat(dogZamani);
					}
				}
        		
        		//Isyeri Dogrulama Detay Bilgilerini Olustur
        		KkDogrulamaDetayTxId id = new KkDogrulamaDetayTxId();
                id.setDogrulamaTipKod(DogrulamaTipKodu.MI.name());
                id.setTxNo(trxNo);
                
                KkDogrulamaDetayTx kkDogrulamaDetayTx = (KkDogrulamaDetayTx) session.get(KkDogrulamaDetayTx.class, id);
                if(kkDogrulamaDetayTx == null) {
                	kkDogrulamaDetayTx = new KkDogrulamaDetayTx(id, idNo);
                }
                
                kkDogrulamaDetayTx.setBasvuruNo(basvuruNo);
                //Arama Adedi, bir arttirilarak gonderilir.
                kkDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("MUS_ISYERI_ARAMA_ADEDI").add(new BigDecimal(1)));
                kkDogrulamaDetayTx.setDogrulamaKod(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD"));
                kkDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("MUS_ISYERI_DOGRULAMA_SEBEP_KOD"));
                
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_ISYERI_ADI", iMap.getString("MUS_YENI_ISYERI_ADI"));
                kkDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_ISYERI_GORUSULEN_TELEFON"));
                kkDogrulamaDetayTx.setGorusulenIsim(iMap.getString("MUS_GORUSULEN_ISIM"));
                kkDogrulamaDetayTx.setGorusulenUnvan(iMap.getString("MUS_GORUSULEN_UNVAN"));
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "DOGRULAMA_NEDENI", iMap.getString("MUS_DOGRULAMA_NEDENI"));
                
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_GELIR", iMap.getBigDecimal("MUS_YENI_GELIR"));
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_CALISMA_SEKLI_KOD", iMap.getString("MUS_YENI_CALISMA_SEKLI_KOD"));
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_MESLEK_KOD", iMap.getString("MUS_YENI_MESLEK_KOD"));
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_UNVAN", iMap.getString("MUS_YENI_UNVAN"));
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_ISYERI_FAAL_KONU_KOD", iMap.getString("MUS_YENI_ISYERINDE_FAAL_KONU_KOD"));
				DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_IS_ADRES", iMap.getString("MUS_YENI_IS_ADRESI"));
                
				String calismaSuresi = concatYilAy(iMap.getString("MUS_YENI_YIL"),iMap.getString("MUS_YENI_AY"));
                DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_ISYERINDE_CALISMA_SURESI", calismaSuresi);

				DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "ISYERI_DOGRULAMA", iMap.getString("MUS_ISYERI_KARAR"));
				kkDogrulamaDetayTx.setAciklama(iMap.getString("MUS_ISYERI_ACIKLAMA"));
                                
                //Tekrar aranacak ise ve max arama sayisina ulasildiysa Ulasilmadi(2)/Max Arama Sayisi Asildi(24) olarak gonder
                query = "BNSPR_GET_PARAMETRE_DEGER_AL_K_N";
                BigDecimal maxAramaSayisi =
                		GMServiceExecuter.call(query, new GMMap().put("PARAMETRE", "MAX_ARAMA_SAYISI")).getBigDecimal("DEGER");
                if( "3".equals(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD")) &&
                        maxAramaSayisi.equals(kkDogrulamaDetayTx.getAramaAdedi()) ) {
                	kkDogrulamaDetayTx.setDogrulamaKod("2");
                	kkDogrulamaDetayTx.setDogrulamaSebepKod("24");

                	kkDogrulamaTx.setMusIsyeriDogKod("2");
                }

                //Dogrulama Detay Bilgilerini Kaydet
                session.saveOrUpdate(kkDogrulamaDetayTx);
                session.flush();
                dogrulamaYapildiMi = true;
        	} else { // Dogrulama Islemi Yapilmadi ise son dogrulamadaki degerleri gonder, onceki dogrulamalari ezmesin diye.
                GMMap inMap = new GMMap();
                inMap.put("BASVURU_NO", basvuruNo);
                inMap.put("KONTROL_TIPI", "MI");
                
                GMMap outMap = GMServiceExecuter.call("BNSPR_TRN3880_GET_SON_DOGRULAMA", inMap);
                kkDogrulamaTx.setMusDogIsyeriSaatTip(outMap.getString("SON_DOG_RANDEVU_MU"));
                kkDogrulamaTx.setMusIsyeriDogKod(outMap.getString("SON_DOG_SONUC_KOD"));
                if (outMap.getBigDecimal("SON_DOG_SAAT") != null) {
                	kkDogrulamaTx.setMusIsyeriDogSaat(new Date(outMap.getBigDecimal("SON_DOG_SAAT").longValue()));
                }
            }//Isyeri Dogrulama Islemi Sonu
        	
        	//Web icin Dogrulama Islemi Yapildi ise
        	if (CreditCardServicesUtil.YES.equals(iMap.getString("MW_AKSIYON_KOD"))) {
        		//Gercekten yapildi mi?
        		kkDogrulamaTx.setMusWebDogKod("1");//Zorunlu alan
        		if (CreditCardServicesUtil.EVET.equals(iMap.getString("ESGM_SORGU_YAPILDI_MI"))) {
        			//Dogrulama Detay Bilgilerini Olustur
            		KkDogrulamaDetayTxId id = new KkDogrulamaDetayTxId();
                    id.setDogrulamaTipKod(DogrulamaTipKodu.MW.name());
                    id.setTxNo(trxNo);
                    
                    KkDogrulamaDetayTx kkDogrulamaDetayTx = (KkDogrulamaDetayTx) session.get(KkDogrulamaDetayTx.class, id);
                    if(kkDogrulamaDetayTx == null) {
                    	kkDogrulamaDetayTx = new KkDogrulamaDetayTx(id, idNo);
                    }

                    kkDogrulamaDetayTx.setAciklama(iMap.getString("Web dogrulama yapildi"));
    				// Arama Adedi, bir arttirilarak gonderilir.
                    kkDogrulamaDetayTx.setBasvuruNo(basvuruNo);
                    kkDogrulamaDetayTx.setDogrulamaKod("1");
                    kkDogrulamaDetayTx.setDogrulamaSebepKod("28");
                    kkDogrulamaDetayTx.setGorusulenIsim(iMap.getString("MUS_GORUSULEN_ISIM"));
                    kkDogrulamaDetayTx.setGorusulenUnvan(iMap.getString("MUS_GORUSULEN_UNVAN"));
                    kkDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));

                    //Dogrulama Detay Bilgilerini Kaydet
    				session.saveOrUpdate(kkDogrulamaDetayTx);
    				session.flush();
        		}
			}//Web Dogrulama Islemi Sonu
        	
        	//Dogrulama Islemleri Tamamlandi Mi?
        	if ( (CreditCardServicesUtil.NO.equals(iMap.getString("MI_AKSIYON_KOD")) ||
        			"Not Required".equals(iMap.getString("MI_AKSIYON_KOD")))
        		  && CreditCardServicesUtil.YES.equals(iMap.getString("MW_AKSIYON_KOD")) ) {
				dogrulamaYapildiMi = true;
			}
        	
        	//Tamamlanmadi ise Hata Ver
        	if (!dogrulamaYapildiMi) {
        		throw new GMRuntimeException(0, GMMessageFactory.getMessage("3180_DOGRULAMA_YAPILMADI", null));
			}
        	
        	//bir_dogrulama_kayit Tablosuna Dogrulama Yeni Degerlerini Kaydet
			conn = DALUtil.getGMConnection();
			
			query = "{call PKG_TRN3180.save_trn3180_tx(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, trxNo);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.setString(3, DogrulamaTipKodu.valuesOf(dogrulamaInstance));
			stmt.execute();
			stmt.close();
			
			// Dogrulama yapilmasi gereken alanlarin hepsinin dogrulamasi yapildiysa IslemSonrasiDurumKodu'na NBSM set edilir.
			String nbsm_ilerlet = null;
			query = "{? = call PKG_TRN3880.nbsm_ilerlet_sonuc(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, trxNo);
			stmt.execute();
			
			nbsm_ilerlet = stmt.getString(1);
			if ("Y".equals(nbsm_ilerlet)) {
				kkDogrulamaTx.setIslemSonrasiDurumKodu("NBSM");
			}

			//Dogrulama Bilgilerini Kaydet
			session.saveOrUpdate(kkDogrulamaTx);
			session.flush();
			
			//Transaciton islemlerini gerceklestir
			iMap.put("TRX_NAME", "3880");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			//Basvuru Akisindaki Kullanici Bilgilerini Guncelle
			if ("IS_HAVUZU".equals(iMap.getString("ACTION"))) {
				GMMap akisMap = new GMMap();
				akisMap.put("ROL", "T");//Islem Tamamlandi
				akisMap.put("BASVURU_NO", kkDogrulamaTx.getBasvuruNo());
				akisMap.put("TX_NO", kkDogrulamaTx.getTxNo());
				akisMap.put("DURUM_KOD", kkDogrulamaTx.getIslemSonrasiDurumKodu());
				GMServiceExecuter.call("BNSPR_QRY3829_KULLANICI_ISLEM", akisMap);
			}
			
			// birBasvuru tablosunun durum kodu da NBSM yapilir.
			if ("Y".equals(nbsm_ilerlet)) {
				callNbsmSorgu(trxNo, basvuruNo, musteriNo);
				GMServiceExecuter.call("BNSPR_BASVURU_SEND_SMS", iMap);
			}
			
			//Session Temizle
			ADCSession.remove("3880_DYN_INS_" + iMap.getString("TRX_NO"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
        
        return oMap;
    }
	
	/** Basvurunun dogrulanma asamasindaki islemler icin ID bilgisini alir.
	 * 
	 * @param basvuruNo - Dogrulanma asamasinda islem goren basvuru numarasi
	 * @return idNo - {@link BigDecimal}
	 */
	private static BigDecimal getIdNo(BigDecimal basvuruNo) {
		//initial database variables
		BigDecimal idNo = null;
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

        try {
            conn = DALUtil.getGMConnection();
            
            query = "{? = call PKG_TRN3880.GET_ID(?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setBigDecimal(2, basvuruNo);
            stmt.execute();
            
            idNo = stmt.getBigDecimal(1);
        } catch(Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return idNo;
    }
	
	private static void callNbsmSorgu(BigDecimal trxNo, BigDecimal basvuruNo, BigDecimal musteriNo) {
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		// Islem sonrasinda basvurunun durumkodu NBSM olmussa NBSM Call yapilir.
		KkDogrulamaTx kkDogrulamaTx = (KkDogrulamaTx) session.get(KkDogrulamaTx.class, trxNo);
		if ("NBSM".equals(kkDogrulamaTx.getIslemSonrasiDurumKodu())) {
			GMMap iMap = new GMMap();
			iMap.put("TRX_NO", trxNo);
			iMap.put("BASVURU_NO", basvuruNo);
			iMap.put("MUSTERI_NO", musteriNo);
			GMServiceExecuter.execute("BNSPR_TRN3871_FINAL_SORGULAR", iMap);
			
			nbsmSonrasiOcean(iMap);
		}
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3880_IADE Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3880_IADE.guiml Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since 12.02.2014
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>GEREKCE_KOD_LIST - Secilebilecek iade gerekceleri
	 *         <li>DURUM_KOD_LIST - Iade edilebilecek basvuru durumlari
	 */
	@GraymoundService("BNSPR_TRN3880_IADE_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Gerekce listesi
			iMap.put("KARAR", "I");
			iMap.put("IADE_KOD", "BASVURU");
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3874_GET_BASVURU_AKSIYON_KARAR_KOD", iMap));
			oMap.put("GEREKCE_KOD_LIST", iMap.get("AKSIYON_KARAR_KOD"));
			
			//Durum Listesi
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM_KOD_LIST", "KK_BASVURU_DURUM_KOD", "H"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Dogrulama asamasinda basvuruyu iade eder.<br>
	 * @author murat.el
	 * @since 12.02.2014
	 * @param iMap - Iade Islemi Bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>TRX_NO - Basvuru numarasi
	 *        <li>ONCEKI_DURUM_KOD - Onceki Durum Kodu
	 *        <li>YENI_DURUM_KOD - Yeni Durum Kodu
	 *        <li>GEREKCE_KOD - Iade Gerekcesi
	 *        <li>ACIKLAMA - Iade aciklamasi
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3880_IADE")
	public static GMMap basvuruIade(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
            Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

            //Dogrulama Kaydini Olustur
            KkDogrulamaTx kkDogrulamaTx = (KkDogrulamaTx) session.get(KkDogrulamaTx.class, trxNo);
            if(kkDogrulamaTx == null) {
            	kkDogrulamaTx = new KkDogrulamaTx();
            }
            
            kkDogrulamaTx.setIdNo(getIdNo(basvuruNo));
        	kkDogrulamaTx.setTxNo(trxNo);
        	kkDogrulamaTx.setBasvuruNo(basvuruNo);
        	kkDogrulamaTx.setOncekiDurumKodu(iMap.getString("ONCEKI_DURUM_KOD"));
        	kkDogrulamaTx.setIslemSonrasiDurumKodu(iMap.getString("YENI_DURUM_KOD"));
        	kkDogrulamaTx.setAksiyonKod("I");
        	kkDogrulamaTx.setAksiyonKararKod(iMap.getString("GEREKCE_KOD"));//BNSPR_TRN3874_GET_BASVURU_AKSIYON_KARAR_KOD
        	kkDogrulamaTx.setAciklama(iMap.getString("ACIKLAMA"));
        	session.save(kkDogrulamaTx);
        	session.flush();
        	
        	//Transaciton islemlerini gerceklestir
			iMap.put("TRX_NAME", "3880");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Dogrulama isleminde yapilan iadeye ait bilgileri listeler.<br>
	 * @author murat.el
	 * @since 12.02.2014
	 * @param iMap - Islem Sorgu Bilgileri<br>
	 *        <li>TRX_NO - Basvuru numarasi
	 * @return Islem Bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>ONCEKI_DURUM_KOD - Onceki Durum Kodu
	 *        <li>YENI_DURUM_KOD - Yeni Durum Kodu
	 *        <li>GEREKCE_KOD - Iade Gerekcesi
	 *        <li>ACIKLAMA - Iade aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3880_IADE_GET_ISLEM_INFO")
	public static GMMap getBasvuruIadeIslemBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
            Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

            //Dogrulama islem bilgisini al
            KkDogrulamaTx kkDogrulamaTx = (KkDogrulamaTx) session.get(KkDogrulamaTx.class, trxNo);
            if(kkDogrulamaTx == null) {
            	kkDogrulamaTx = new KkDogrulamaTx();
            }
            
            //Islem bilgilerini ekrana don
            oMap.put("BASVURU_NO", kkDogrulamaTx.getBasvuruNo());
            oMap.put("ONCEKI_DURUM_KOD", kkDogrulamaTx.getOncekiDurumKodu());
            oMap.put("YENI_DURUM_KOD", kkDogrulamaTx.getIslemSonrasiDurumKodu());
            oMap.put("GEREKCE_KOD", kkDogrulamaTx.getAksiyonKararKod());
            oMap.put("ACIKLAMA", kkDogrulamaTx.getAciklama());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3880_TARIHCE Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3880_TARIHCE.guiml ekraninda basvurunun dogrulama tarihcesini listeler.
	 * <br>
	 *  BNSPR_TRN3880.guiml ekraninda Dogrulama Tarihcesi Butonu
	 * 
	 * @param iMap - BASVURU_NO
	 * @return Basvuruya ait dogrulama tarihce listesi:RESULTS
	 */
	@GraymoundService("BNSPR_TRN3880_GET_TARIHCE")
	public static GMMap getBasvuruTarihce(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TRN3880.Rc_Qry3880_Get_Tarihce(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3880_KISI_BILGISI Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3880_KISI_BILGISI.guiml ekraninda basvuru sahibinin kisi bilgilerini listeler.
	 * <br>
	 *  BNSPR_TRN3880.guiml ekraninda Isyeri Tabi->Kimlik Bilgileri Butonu
	 * 
	 * @param iMap - BASVURU_NO
	 * @return Basvuru sahibine ait kisi bilgileri
	 */
	@GraymoundService("BNSPR_TRN3880_GET_KISI_BILGISI")
    public static GMMap getKisiBilgisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

        try {
            conn = DALUtil.getGMConnection();

            query = "{? = call PKG_TRN3880.Rc_Qry3880_Get_Kisi_Bilgi(?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
            stmt.execute();
            
            rSet = (ResultSet)stmt.getObject(1);
            if(rSet.next()) {
            	oMap.put("TC_KIMLIK_NO", rSet.getBigDecimal("TC_KIMLIK_NO"));//
            	oMap.put("BABA_AD", rSet.getString("BABA_AD"));
                oMap.put("AD_SOYAD", rSet.getString("AD_SOYAD"));
                oMap.put("DOGUM_TARIHI", rSet.getDate("DOGUM_TARIHI"));
                oMap.put("DOGUM_YERI", rSet.getString("DOGUM_YERI"));//
                oMap.put("MEDENI_HAL", rSet.getString("MEDENI_HAL"));
                oMap.put("EV_ADRES", rSet.getString("EV_ADRES"));
                oMap.put("VERGI_DAIRE_IL", rSet.getString("VERGI_DAIRE_IL"));
                oMap.put("VERGI_DAIRE_AD", rSet.getString("VERGI_DAIRE_AD"));
                oMap.put("EV_TELEFON", rSet.getString("EV_TELEFON"));
                oMap.put("IS_TELEFON" , rSet.getString("IS_TELEFON"));
                oMap.put("IS_DAHILI", rSet.getString("IS_DAHILI"));
                oMap.put("CEP_TELEFON", rSet.getString("CEP_TELEFON"));
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }
	
	//---------------------------------------------------------------------
	//******************************************************* 3880_Popup-Manuel-WEB-Dogrulama Ekrani
	//---------------------------------------------------------------------
	//Isyeri Tabi Manuel Dogrulama Butonu
	//init combobox model
	/**
	 * BNSPR_TRN3880_Popup-Manuel-WEB-Dogrulama.guiml ekrani acilisinda combobox datalarini set eder.
	 * <br>
	 * BNSPR_TRN3880.guiml ekranindaki Web Tabi->Manuel Dogrulama Butonu
	 */
	@GraymoundService("BNSPR_TRN3880_WEB_FILL_COMBOBOX")
	public static GMMap fillWebEkraniComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Calisma Sekli
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));

			//Dogrulama Sonucu
			oMap.putAll(CreditCardServicesUtil.getParameterList("DOGRULA", "BAS_DOG_SONUC", "E"));
					
			//Isyeri Il
			oMap.put("LIST_NAME", "ISYERI_IL");
			oMap.put("ADD_EMPTY_KEY", true);
			oMap.put("LIST_QUERY", "SELECT kod, (CASE WHEN kod >= '100' THEN kod||'-'||il_adi ELSE SUBSTR (kod,2)||'-'||il_adi END) il_adi FROM gnl_il_kod_pr ORDER BY kod");
			DALUtil.fillComboBox(oMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	//Init Ekran
	/**
	 * BNSPR_TRN3880_Popup-Manuel-WEB-Dogrulama.guiml ekrani acilisinda alinacak degerleri ekrana aktarir.
	 * <br>
	 * Ekrandan girilen degerleri sessionda tutarak daha onceden girilen bilgileri tekrar acilinca listeler.
	 * <br>
	 * BNSPR_TRN3880.guiml ekranindaki Web Tabi->Manuel Dogrulama Butonu
	 */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3880_GET_DOGRULAMA_KODLARI")
	public static GMMap getDogrulamaKodlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			// Eger bir alt bilesenden cagriliyorsa ve veriler onceden sessiona kaydedilmis ise (popup tarzi kapanip acilan ekranlar icin bunu if
			// icerisinde kontrol ettigimiz ekrana ozgu bir variable degeri varsa anlayacagiz) onlari dondur:
			if (StringUtils.isNotBlank(iMap.getString("CHECKING_VARIABLE")) &&
					StringUtils.isNotBlank(iMap.getString("TRX_NO"))) {
				Object instance = ADCSession.get("3880_DYN_INS_" + iMap.getString("TRX_NO"));
				String[] keyPair = iMap.getString("CHECKING_VARIABLE").split("/", 2);

				if (instance != null && DogrulamaTipKodu.valueOf(keyPair[0]).contains(instance, keyPair[1])) {
					Map<String, Object> result = DogrulamaTipKodu.getForView(instance);
					oMap.putAll(result);

					return oMap;
				}
			}

			// Eger ana ekran disindaki bir bilesenden cagrilirsa(popup, dynamik part gibi) onceden veriler if altindaki kodlardan alinmis olacagi
			// icin on bellekten verileri al:
			if (iMap.getBoolean("DYN_VIEW")) {
				Map<String, Object> result =
						(Map<String, Object>) ADCSession.get("3880_VIEW_DYN_INS_" + iMap.getBigDecimal("TRX_NO"));
				if(result != null) {
					oMap.putAll(result);
				}
				
				return oMap;
			}
			ADCSession.remove("3880_VIEW_DYN_INS_" + iMap.getBigDecimal("TRX_NO"));
			
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			Object instance = DogrulamaTipKodu.getInstance();
			List<?> list = null;

			if (iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI") || iMap.getString("ACTION").equals("BASVURU_IZLE")) {
				list = session.createCriteria(BirDogrulamaKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

				for (BirDogrulamaKayitTx birTx : (List<BirDogrulamaKayitTx>) list) {
					DogrulamaTipKodu.valueOf(birTx.getId().getDogrulamaTipKod()).addItem(instance, birTx.getId().getDogrulamaParam(), birTx.getDogrulamaDeger());
				}
			}
			else {
				list = session.createCriteria(BirDogrulamaKayit.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();

				for (BirDogrulamaKayit bir : (List<BirDogrulamaKayit>) list) {
					DogrulamaTipKodu.valueOf(bir.getId().getDogrulamaTipKod()).addItem(instance, bir.getId().getDogrulamaParam(), bir.getDogrulamaDeger());
				}
			}

			Map<String, Object> result = DogrulamaTipKodu.getForView(instance);
			ADCSession.put("3880_VIEW_DYN_INS_" + iMap.getBigDecimal("TRX_NO"), result);

			oMap.putAll(result);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			if (StringUtils.isNotBlank(iMap.getString("FINALIZING_SERVICE"))) {
				oMap.putAll(GMServiceExecuter.call(iMap.getString("FINALIZING_SERVICE"), oMap));
			}
		}
		
		return oMap;
	}
	
	/** Dogrulama bilgilerini session icerisine aktarir.
	 * 
	 * @param iMap - TRX_NO
	 */
	@GraymoundService("BNSPR_TRN3880_WEB_CREATE_DYN_INS")
	public static GMMap getDynIns(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Call initialize service
			if (StringUtils.isNotBlank(iMap.getString("PREPARING_SERVICE"))) {
				iMap.putAll(GMServiceExecuter.call(iMap.getString("PREPARING_SERVICE"), iMap));
			}

			Object instance = ADCSession.get("3880_DYN_INS_" + iMap.getBigDecimal("TRX_NO"));
			if (instance == null) {
				instance = DogrulamaTipKodu.getInstance();
			}

			String key = null;
			for (Object str : iMap.keySet()) {
				key = (String) str;

				String[] tmp = key.split("/", 2);
				if (tmp.length == 2) {
					DogrulamaTipKodu.valueOf(tmp[0]).addItem(instance, tmp[1], StringUtils.isBlank(iMap.getString(key)) ? null : iMap.getString(key));
				}
			}

			ADCSession.put("3880_DYN_INS_" + iMap.getBigDecimal("TRX_NO"), instance);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Dogrulama bilgilerini session icerisinden alir.
	 * 
	 * @param iMap - Tum Dogrulama Bilgileri
	 * @return Session icerisindeki dogrulama bilgileri
	 */
	@GraymoundService("BNSPR_TRN3880_WEB_GET_DOG_DYN_DATA")
	public static GMMap getWebDogData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			boolean ucretli = false;
			if (StringUtils.isNotBlank(iMap.getString("MW/SSK_SON_PRIM_TARIHI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/SSK_CALISMA_SURESI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/SSK_PRIM_TUTARI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/SSK_BASLANGIC_TARIHI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/SSK_TESPIT"))
					|| StringUtils.isNotBlank(iMap.getString("MW/SSK_ISYERI_ILI"))) {
				ucretli = true;
			}

			boolean kamu = false;
			if (StringUtils.isNotBlank(iMap.getString("MW/KAMU_CALISMA_DURUMU"))
					&& iMap.getString("MW/KAMU_CALISMA_DURUMU").equals("AKT\u0130F")) {
				kamu = true;
			}
			
			boolean ozelSandik = false;
			if (StringUtils.isNotBlank(iMap.getString("MW/OZEL_SANDIK_CALISMA_DURUMU"))
					&& iMap.getString("MW/OZEL_SANDIK_CALISMA_DURUMU").equals("AKT\u0130F")) {
				ozelSandik = true;
			}

			boolean serbestMeslek = false;
			if (StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU"))
					|| StringUtils.isNotBlank(iMap.getString("MW/BAKUR_CALISMA_SURESI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_ISYERI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_ISYERI_UYUMLU"))
					|| StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_VERGI_MATRAHI"))
					|| StringUtils.isNotBlank(iMap.getString("MW/SSK_ISYERI_ILI"))) {
				serbestMeslek = true;
			}

			boolean emekli = false;
			if (StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK"))
					|| StringUtils.isNotBlank(iMap.getString("OKE"))
					|| StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN"))
					|| iMap.getBoolean("SSK") || iMap.getBoolean("BAGKUR")
					|| iMap.getBoolean("EMEKLI_SANDIGI")
					|| iMap.getBoolean("OZEL_SANDIK")) {
				emekli = true;
			}

			//Calisan emekli tur bilgisini al
			String key = null;
			//CALISAN_EMEKLI_TUR parametresinin bozulmamasini hanife istedi. 
			//Aciklama alanlari da hardcore(hardcoded) oldu.
			String aciklama = StringUtils.EMPTY;
			if ((ucretli || kamu || serbestMeslek || ozelSandik) && emekli) {
				key = "CE";
			} else if (ucretli) {
				key =  "CS";
			} else if (kamu) {
				key =  "CES";
			} else if (serbestMeslek) {
				key =  "CB";
			} else if (ozelSandik) {
				aciklama = "Calisan Ozel Sandik";
			}else if (iMap.getBoolean("SSK")) {
				key =  "ES";
			} else if (iMap.getBoolean("EMEKLI_SANDIGI")) {
				key =  "EK";
			} else if (iMap.getBoolean("OZEL_SANDIK")) {
				key =  "EOS";
			} else if (iMap.getBoolean("BAGKUR")) {
				key =  "EB";
			} else if (iMap.getBoolean("SAKINCALI")) {
				aciklama = "Emekli Sakincali";
			}
			
			GMMap tMap = new GMMap();
			tMap.put("KOD", "CALISAN_EMEKLI_TUR");
			tMap.put("KEY", key);
			
			if (StringUtils.isNotBlank(tMap.getString("KEY"))) {
				oMap.put("MW/CALISAN_EMEKLI_TUR",
						GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", tMap).getString("TEXT"));
			} else {
				oMap.put("MW/CALISAN_EMEKLI_TUR", aciklama);
			}
			
			tMap.remove("KEY");
			
			//Emekli tur bilgisini al
			key = null;
			aciklama = StringUtils.EMPTY;
			if (iMap.getBoolean("SSK")) {
				key =  "ES";
			} else if (iMap.getBoolean("EMEKLI_SANDIGI")) {
				key =  "EK";
			} else if (iMap.getBoolean("OZEL_SANDIK")) {
				key =  "EOS";
			} else if (iMap.getBoolean("BAGKUR")) {
				key =  "EB";
			} else if (iMap.getBoolean("SAKINCALI")) {
				aciklama = "Emekli Sakincali";
			}
			
			tMap.put("KEY", key);
			if (StringUtils.isNotBlank(tMap.getString("KEY"))) {
				oMap.put("MW/EMEKLI_TUR",
						GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", tMap).getString("TEXT"));
			} else {
				oMap.put("MW/EMEKLI_TUR", aciklama);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3880_WEB_SET_DOG_DYN_DATA")
	public static GMMap setWebDogData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			oMap.put("MW/SSK_CALISMA_SURESI_1", StringUtils.isNotBlank(iMap.getString("MW/SSK_CALISMA_SURESI")) && iMap.getString("MW/SSK_CALISMA_SURESI").equals("1F"));
			oMap.put("MW/SSK_CALISMA_SURESI_2", StringUtils.isNotBlank(iMap.getString("MW/SSK_CALISMA_SURESI")) && iMap.getString("MW/SSK_CALISMA_SURESI").equals("1A"));

			oMap.put("MW/BAGKUR_CALISMA_DURUMU_1", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("AKT�F"));
			oMap.put("MW/BAGKUR_CALISMA_DURUMU_2", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("KAPALI"));

			oMap.put("MW/BAGKUR_CALISMA_DURUMU_1", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("AKT�F"));
			oMap.put("MW/BAGKUR_CALISMA_DURUMU_2", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("KAPALI"));

			oMap.put("MW/BAKUR_CALISMA_SURESI_1", StringUtils.isNotBlank(iMap.getString("MW/BAKUR_CALISMA_SURESI")) && iMap.getString("MW/BAKUR_CALISMA_SURESI").equals("1F"));
			oMap.put("MW/BAKUR_CALISMA_SURESI_2", StringUtils.isNotBlank(iMap.getString("MW/BAKUR_CALISMA_SURESI")) && iMap.getString("MW/BAKUR_CALISMA_SURESI").equals("1A"));

			oMap.put("MW/SSK_TESPIT_1", StringUtils.isNotBlank(iMap.getString("MW/SSK_TESPIT")) && iMap.getString("MW/SSK_TESPIT").contains("Sik is degistiriyor"));
			oMap.put("MW/SSK_TESPIT_2", StringUtils.isNotBlank(iMap.getString("MW/SSK_TESPIT")) && iMap.getString("MW/SSK_TESPIT").contains("Duzensiz pirim odemesi var"));

			oMap.put("MW/KAMU_CALISMA_DURUMU", StringUtils.isNotBlank(iMap.getString("MW/KAMU_CALISMA_DURUMU")) && iMap.getString("MW/KAMU_CALISMA_DURUMU").equals("AKT�F"));
			oMap.put("MW/OZEL_SANDIK_CALISMA_DURUMU", StringUtils.isNotBlank(iMap.getString("MW/OZEL_SANDIK_CALISMA_DURUMU")) && iMap.getString("MW/OZEL_SANDIK_CALISMA_DURUMU").equals("AKT�F"));

			oMap.put("MW/EMEKLI_AYLIK_KIMDEN_1", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) && iMap.getString("MW/EMEKLI_AYLIK_KIMDEN").equals("K"));
			oMap.put("MW/EMEKLI_AYLIK_KIMDEN_2", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) && iMap.getString("MW/EMEKLI_AYLIK_KIMDEN").equals("A"));
			oMap.put("MW/EMEKLI_AYLIK_KIMDEN_3", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) && iMap.getString("MW/EMEKLI_AYLIK_KIMDEN").equals("D"));

			GMMap tMap = new GMMap();
			tMap.put("KOD", "CALISAN_EMEKLI_TUR");
			tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", tMap);

			String result = "RESULTS";
			for (int i = 0; i < tMap.getSize(result); i++) {
				if (tMap.getString(result, i, "NAME").equals(iMap.getString("MW/EMEKLI_TUR"))) {
					iMap.put("MW/EMEKLI_TUR", tMap.getString(result, i, "VALUE"));
					break;
				}
			}

			oMap.put("MW/EMEKLI_TUR_1", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("ES"));
			oMap.put("MW/EMEKLI_TUR_2", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("EB"));
			oMap.put("MW/EMEKLI_TUR_3", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("EK"));
			oMap.put("MW/EMEKLI_TUR_4", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("EOS"));
			oMap.put("MW/EMEKLI_TUR_5", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("Emekli Sakincali"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3880_Popup-KKB-Dogrulama Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3880_Popup-KKB-Dogrulama.guiml ekraninda basvuru
	 * KKB, Basvuru, Musteri, Aps bilgilerini dorulama amaciyla karsilastirmak icin listeler.
	 * <br>
	 *  BNSPR_TRN3880_Popup-KKB-Dogrulama.guiml ekrani acilisinda calisir
	 * 
	 * @param iMap - BASVURU_NO
	 * @return Basvuruya ait KKB, Basvuru, Musteri, Aps bilgileri
	 */
	@GraymoundService("BNSPR_TRN3880_GET_KKB_BILGI")
	public static GMMap getKkbBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			conn = DALUtil.getGMConnection();
			
			// KKB Bilgilerini Al
			query = "{ ? = call PKG_TRN3180.RC_TRN3180_KKB_DOG_KKB_BILGI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "KKB_BILGI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "SORGU_NO", rSet.getObject("SORGU_NO"));
				oMap.put(tableName, row, "SIRA_NO", rSet.getObject("SIRA_NO"));
				oMap.put(tableName, row, "SIRALAMA", rSet.getObject("SIRALAMA"));
				oMap.put(tableName, row, "KAYIT_TURU", rSet.getObject("KAYIT_TURU"));
				oMap.put(tableName, row, "ACILIS_TARIHI", rSet.getObject("ACILIS_TARIHI") == null ? null : sdf.format(sdf2.parse(rSet.getString("ACILIS_TARIHI"))));
				oMap.put(tableName, row, "KAPANIS_TARIHI", rSet.getObject("KAPANIS_TARIHI") == null ? null : sdf.format(sdf3.parse(rSet.getString("KAPANIS_TARIHI"))));
				oMap.put(tableName, row, "LIMIT", rSet.getObject("LIMIT"));
				oMap.put(tableName, row, "RISK", rSet.getObject("RISK"));
				oMap.put(tableName, row, "SOP", rSet.getObject("SOP"));
				oMap.put(tableName, row, "DONEM", rSet.getObject("DONEM"));
				oMap.put(tableName, row, "VADE", rSet.getObject("VADE"));
				oMap.put(tableName, row, "TCKN", rSet.getObject("TCKN"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put(tableName, row, "ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK_SOYADI"));
				oMap.put(tableName, row, "EV_TEL", rSet.getObject("EV_TEL"));
				oMap.put(tableName, row, "IS_TEL", rSet.getObject("IS_TEL"));
				oMap.put(tableName, row, "CEP_TEL", rSet.getObject("CEP_TEL"));
				oMap.put(tableName, row, "EV_ADRES", rSet.getObject("EV_ADRES"));
				oMap.put(tableName, row, "IS_ADRES", rSet.getObject("IS_ADRES"));
				oMap.put(tableName, row, "KIMLIK_TURU", rSet.getObject("KIMLIK_TURU"));
				oMap.put(tableName, row, "KIMLIK_NO", rSet.getObject("KIMLIK_NO"));
				oMap.put(tableName, row, "DOGUM_TARIHI", rSet.getObject("DOGUM_TARIHI") == null ? null : sdf.format(sdf2.parse(rSet.getString("DOGUM_TARIHI"))));
				oMap.put(tableName, row, "ANNE_AD", rSet.getObject("ANNE_AD"));
				row++;
			}
			
			stmt.close();
			
			//Basvuru Bilgilerini Al
			query = "{ ? = call PKG_TRN3880.RC_QRY3880_GET_KISI_BILGI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("BASVURU_TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put("BASVURU_AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put("BASVURU_ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK"));
				oMap.put("BASVURU_EV_TEL", rSet.getObject("EV_TELEFON"));
				oMap.put("BASVURU_IS_TEL", rSet.getObject("IS_TELEFON"));
				oMap.put("BASVURU_CEP_TEL", rSet.getObject("CEP_TELEFON"));
				oMap.put("BASVURU_EV_ADRES", rSet.getObject("EV_ADRES"));
				oMap.put("BASVURU_IS_ADRES", rSet.getObject("IS_ADRES"));
				oMap.put("BASVURU_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put("BASVURU_DOGUM_TARIHI", rSet.getObject("DOGUM_TARIHI") == null ? null : sdf.format(rSet.getObject("DOGUM_TARIHI")));
				oMap.put("BASVURU_ANNE_AD", rSet.getObject("ANNE_ADI"));
			}

			stmt.close();
			
			//Basvuru Kimlik Turunu Al
			query = "{ ? = call PKG_KKB_ONLINE.GET_KKB_CODE(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, "KKB_IDENTITY_TYPE_CODE");
			stmt.setString(3, "3");
			stmt.execute();

			oMap.put("BASVURU_KIMLIK_TURU", stmt.getString(1));
			stmt.close();
			
			//Musteri Bilgilerini Al
			query = "{ ? = call PKG_TRN3880.RC_QRY3880_GET_MUSTERI_BILGI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			stmt.close();

			//APS Bilgilerini Al
			query = "{ ? = call PKG_TRN3880.RC_QRY3880_GET_APS_BILGI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			stmt.close();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* KART BASIM SERVISLERI
	//---------------------------------------------------------------------
	/** Dogrulama islemi sonunda basvuru basim asamasinda ise karti basima gondermek icin gerekli servisler cagrilir
	 * ve basvuru sahibine bilgilendirme amaciyla sms atilir.
	 * 
	 * @param iMap - BASVURU_NO
	 */
	public static GMMap nbsmSonrasiOcean(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Islem numarasi verilen basvurunun dogrulama bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru)
					session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			//Basvuru dogrulama islemi varsa
			if (kkBasvuru != null) {
				session.refresh(kkBasvuru);
				//ve son durumu BASIM ise
				if ("BASIM".equals(kkBasvuru.getDurumKod())) {
					iMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					iMap.put("ISLEM_KODU", "DOGRULAMA");
		  			iMap.put("DURUM_KOD", "BASIM");
					GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
					GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
				} else {
					if ("40".equals(kkBasvuru.getKanalKod())) {
						if ("RED".equals(kkBasvuru.getDurumKod())) {
							if (CreditCardServicesUtil.HAYIR.equals(
										CreditCardServicesUtil.nvl(kkBasvuru.getOnOnayliMi(), CreditCardServicesUtil.HAYIR))) {
								sorguMap.clear();
								sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
								sorguMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
								sorguMap.put("ISLEM_KOD", "3880");
								oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap));
							}
						} else if ("IPTAL".equals(kkBasvuru.getDurumKod())) {
							//TFF basvurusunu al
							sorguMap.clear();
							sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
							sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
							BigDecimal tffBasvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
							//Tff basvurusunu al ve iptal et.
							if (tffBasvuruNo != null) {
								TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
								session.refresh(tffBasvuru);
								
								sorguMap.clear();
								sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
  								sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
  								sorguMap.put("ISLEM_KOD", "3880");
  								sorguMap.put("GEREKCE_KOD", "2");
  								sorguMap.put("ACIKLAMA", "kk iptal oldugundan tff iptal edildi");
  								sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
  								oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
							}
						}	
					} else {
						if ("L".equals(kkBasvuru.getKartSeviyesi())) {
							if ("RED".equals(kkBasvuru.getDurumKod()) || "IPTAL".equals(kkBasvuru.getDurumKod())) {
  								//Limit durum guncelle
  								sorguMap.clear();
  								sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
  								sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
  								sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
  								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
  							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	//---------------------------------------------------------------------
	//******************************************************* UTIL
	//---------------------------------------------------------------------
    private static String[] splitDateAndTime(java.util.Date date) {
    	String[] tarihSaat = null;
    	
    	if(date == null) {
    		tarihSaat = new String[] { "", "" };
    	} else {
    		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
    		tarihSaat = dateFormat.format(date).split(" ");
    	}

    	return tarihSaat;
	}
    
    @SuppressWarnings("unused")
    public static String concatYilAy(String yil, String ay) {
        String yilAy = new String();

        if (yil != null && yil.isEmpty() && ay != null && ay.isEmpty()) { return null; }

        if (yil == null) {
            if (ay == null) {
                return null;
            } else if (ay.length() == 0) {
                return null;
            } else if (ay.length() == 1) {
                return "000" + ay;
            } else {
                return "00" + ay;
            }
        }

        if (ay == null) {
            if (yil == null) {
                return null;
            } else if (yil.length() == 0) {
                return null;
            } else if (yil.length() == 1) {
                return "0" + yil + "00";
            } else {
                return yil + "00";
            }
        }
        if (yil.length() == 0 || yil.equals("0")) yilAy = "00";
        else if (yil.length() == 1) yilAy = "0" + yil;
        else yilAy = yil;
        if (ay.length() == 0 || ay.equals("0")) yilAy = yilAy + "00";
        else if (ay.length() == 1) yilAy = yilAy + "0" + ay;
        else yilAy = yilAy + ay;

        return yilAy;
    }
    
    private static java.util.Date addTimeToDate(java.util.Date randevuTarihi, String randevuSaati) {
        java.util.Date dogZamani = null;
        
        //Randevu Saati Gecerli ise Sonraki Randevu Zamanini Set Et.
        if (!StringUtil.isEmpty(randevuSaati) && randevuSaati.length() == 6) {
        	Calendar c = Calendar.getInstance();
            c.setTime(randevuTarihi);
            c.add(Calendar.HOUR, Integer.parseInt(randevuSaati.substring(0, 2)));
            c.add(Calendar.MINUTE, Integer.parseInt(randevuSaati.substring(2, 4)));
            c.add(Calendar.SECOND, Integer.parseInt(randevuSaati.substring(4, 6)));
            dogZamani = c.getTime();
            
            //Sonraki RAndevu Saati Guncel Tarihden Kucuk Olamaz
            java.util.Date bankaTarihi = Calendar.getInstance().getTime();
            if (dogZamani.before(bankaTarihi)) {
                CreditCardServicesUtil.raiseGMError("652", new SimpleDateFormat("dd.MM.yyyy").format(bankaTarihi));
            }
        } else {
        	CreditCardServicesUtil.raiseGMError("330", "Bir Sonraki Arama Saati");
        }
        
        return dogZamani;
    }

    @SuppressWarnings("unchecked")
	enum DogrulamaTipKodu {
		MF, M, MI, MW, K1I, K2I, DS, KRD, KK, A, K1F, K2F;

		static Map<DogrulamaTipKodu, Map<String, Object>> actionList = getInstance();
		static {
			DogrulamaTipKodu.DS.addItem(actionList, "KIMLIK_DOGRULAMA_NF_VER_TAR", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KIMLIK_DOGRULAMA_NF_VER_YER", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KIMLIK_DOGRULAMA_NF_VER_NEDEN", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KRD_DOGRULAMA_ACIK", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KRD_DOGRULAMA_KAPALI", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KK_DOGRULAMA_ACIK", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KK_DOGRULAMA_KAPALI", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "ARAC_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "URUN_BASKASINA_MI", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_ADRES_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_AKS_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_AKS_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_CEPTEL_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_EVTEL_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_ISTEL_DOGRULAMA", "Boolean");

			// DogrulamaTipKodu.M.addItem(actionList, "ADRES_FARKLI_MI", "Boolean");
			DogrulamaTipKodu.M.addItem(actionList, "DETAY_PAYLASILMADI", "Boolean");
			// DogrulamaTipKodu.M.addItem(actionList, "URUN_BASKASINA_MI", "Boolean");
			DogrulamaTipKodu.M.addItem(actionList, "TESLIMAT_TARIH", "Date");

			DogrulamaTipKodu.MW.addItem(actionList, "MANUEL_WEB_DOGRULAMA_YOK", "Boolean");
			DogrulamaTipKodu.MW.addItem(actionList, "CALISAN_EMEKLI_KAYIT_YOK", "Boolean");
			DogrulamaTipKodu.MW.addItem(actionList, "BAGKUR_ISYERI_UYUMLU", "Boolean");
			DogrulamaTipKodu.MW.addItem(actionList, "SSK_SON_PRIM_TARIHI", "Date");
			DogrulamaTipKodu.MW.addItem(actionList, "SSK_BASLANGIC_TARIHI", "Date");
		};

		@Override
		public String toString() {
			return this.name();
		};

		public static Map<DogrulamaTipKodu, Map<String, Object>> getInstance() {
			Map<DogrulamaTipKodu, Map<String, Object>> map = new HashMap<DogrulamaTipKodu, Map<String, Object>>();

			for (DogrulamaTipKodu tip : DogrulamaTipKodu.values()) {
				map.put(tip, new HashMap<String, Object>());
			}
			return map;
		}

		public void addItem(Object instance, String key, Object value) {
			Map<String, Object> map = ((Map<DogrulamaTipKodu, Map<String, Object>>) instance).get(this);
			map.put(key, value == null ? "" : value.toString());
		}

		public boolean contains(Object instance, String key) {
			Map<String, Object> map = ((Map<DogrulamaTipKodu, Map<String, Object>>) instance).get(this);
			return map.containsKey(key);
		}

		public Object getValue(Object instance, String key) {
			Map<DogrulamaTipKodu, Map<String, Object>> source = (Map<DogrulamaTipKodu, Map<String, Object>>) instance;
			return source.get(this).get(key);
		}

		public static String valuesOf(Object instance) {
			Map<DogrulamaTipKodu, Map<String, Object>> map = (Map<DogrulamaTipKodu, Map<String, Object>>) instance;
			Map<String, Object> tmp;
			StringBuilder tmpRTN = new StringBuilder();
			Object value;

			String postfix = "";

			for (DogrulamaTipKodu tip : DogrulamaTipKodu.values()) {
				tmp = map.get(tip);

				for (String key : tmp.keySet()) {
					value = tmp.get(key);
					tmpRTN.append(postfix).append(tip.name()).append("/").append(key).append("=").append(value == null ? "" : value.toString());

					if (postfix.isEmpty()) {
						postfix = "|";
					}
				}
			}

			return tmpRTN.toString();
		}

		public static void putAll(Object sourceInstance, Object targetInstance) {
			if (sourceInstance == null)
				return;

			Map<DogrulamaTipKodu, Map<String, Object>> source = (Map<DogrulamaTipKodu, Map<String, Object>>) sourceInstance;
			Map<DogrulamaTipKodu, Map<String, Object>> target = (Map<DogrulamaTipKodu, Map<String, Object>>) targetInstance;
			Map<String, Object> tempSRC;
			Map<String, Object> tempDES;

			for (DogrulamaTipKodu tip : source.keySet()) {
				tempSRC = source.get(tip);
				tempDES = target.get(tip);

				tempDES.putAll(tempSRC);
			}
		}

		public static Map<String, Object> getForView(Object instance) throws ParseException {
			Map<DogrulamaTipKodu, Map<String, Object>> source = (Map<DogrulamaTipKodu, Map<String, Object>>) instance;
			Map<String, Object> returnData = new HashMap<String, Object>();
			Map<String, Object> tmp, tmp2;
			String type;
			boolean isBlank;
			String value;

			for (DogrulamaTipKodu tip : actionList.keySet()) { // Varsayilan degerler
				tmp = actionList.get(tip);
				for (String str : tmp.keySet()) {
					type = (String) tmp.get(str);
					if (type.equals("Boolean")) {
						returnData.put(tip + "/" + str + "_0", true);
						returnData.put(tip + "/" + str + "_1", false);
						returnData.put(tip + "/" + str + "_2", false);
					}
				}
			}
						
			for (DogrulamaTipKodu tip : source.keySet()) {
				tmp = source.get(tip);
				for (String tmpKEY : tmp.keySet()) {
					tmp2 = actionList.get(tip);
					type = (String) tmp2.get(tmpKEY);
					value = tmp.get(tmpKEY).toString();
					isBlank = StringUtils.isBlank(value);

					if (type != null && type.equals("Boolean")) {
						returnData.put(tip + "/" + tmpKEY + "_0", isBlank);
						returnData.put(tip + "/" + tmpKEY + "_1", !isBlank && value.equals("Y"));
						returnData.put(tip + "/" + tmpKEY + "_2", !isBlank && value.equals("N"));
					}
					else if (type != null && type.equals("Date") && !isBlank) {
						try {
							returnData.put(tip + "/" + tmpKEY, new SimpleDateFormat("dd.MM.yyyy").parse(value));
						}
						catch (Exception e) {
							try {
								returnData.put(tip + "/" + tmpKEY, new SimpleDateFormat("yyyyMMdd").parse(value));
							}
							catch (Exception e1) {
								returnData.put(tip + "/" + tmpKEY, null);
							}
						}
					}
					else {
						returnData.put(tip + "/" + tmpKEY, value);
					}
				}
			}

			return returnData;
		}
	}
}
