package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY3892Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>BASLANGIC_TARIHI - Ekran acilisinda gosterilecek baslangic tarihi
	 *         <li>BITIS_TARIHI - Ekran acilisinda gosterilecek bitis tarihi
	 *         <li>AKIS_TURU_LIST - KK toplu basvuru akis turleri
	 *         <li>DURUM_LIST - KK toplu basvuru islem sonuc kodlari
	 */
	@GraymoundService("BNSPR_QRY3892_IZLEME_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Arama icin default Baslangic ve Bitis Tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
			//Akis Turu
			oMap.putAll(CreditCardServicesUtil.getParameterList("AKIS_TURU_LIST", "KK_EVAM_AKIS_TURU", "E"));
			//Durum
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM_LIST", "KK_EVAM_DURUM_KOD", "E"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore istenilen sonuclari listeler<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>AKTARIM_NO - Dosya aktarim numarasi
	 *        <li>TC_KIMLIK_NO - Tc kimlik numarasi
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>BAS_TARIHI - Arama baslangic tarihi
	 *        <li>BIT_TARIHI - Arama bitis tarihi
	 *        <li>AKIS_TURU - KK toplu basvuru akis turu
	 *        <li>DURUM - KK toplu basvuru durum kodu
	 * @return Sorgu sonuclari<br>
	 *        <li>ISLEM_LIST - Istenilen kriterlere uygun islemler
	 *        <li>OZET_LIST - Istenilen kriterlere uygun islemlerin durum bazli ozeti
	 */
	@GraymoundService("BNSPR_QRY3892_IZLEME_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			query = "{ call PKG_RC3892.Rc_Qry3892_List(?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("AKTARIM_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			
			if (iMap.getDate("BAS_TARIHI") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIHI").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			if (iMap.getDate("BIT_TARIHI") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIHI").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			stmt.setString(i++, iMap.getString("AKIS_TURU"));
			stmt.setString(i++, iMap.getString("DURUM"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			//Ekran formatina cevir
			rSet = (ResultSet) stmt.getObject(--i);
			oMap.putAll(DALUtil.rSetResults(rSet, "OZET_LIST"));
			
			rSet = (ResultSet) stmt.getObject(--i);
			oMap.putAll(DALUtil.rSetResults(rSet, "ISLEM_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

}
