package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQueriesServices {

	/** Verilen basvuru numaras�na ait musteri icin bilinmeyen numara sorgusu gerceklestirir<br>
	 *  Sorgu Sonucunda bilinmeyen numara servisinden numaraya ait bilgiler alinir.<br>
	 * 
	 * @param iMap - BASVURU_NO: BASVURU NO
	 * @param iMap - SORGU_SEVIYESI
	 * @param iMap - EVTEL_SORGU_GEREKLI: Y or N
	 * output:LOG_ID=1265, PHONEBOOK_LIST=[{PHONEBOOK_TYPE_ENUM_VALUE=AVEA, LAST_MODIFIED_DATE_TIME=2013-08-28T00:46:09+03:00,<br>
	 *  FIRST_NAME=AL�, CITY_NAME=BURDUR, ID=null, DISTRICT_NAME=BURDUR, LAST_NAME=DURAN, PHONE_NUMBER=5058233626}], <br>
	 *  RESPONSE_TYPE=SUCCESS, CLIENT_QUERY_NO=1265
	 */
	@GraymoundService("BNSPR_NBSM_KK_UNKNOWN_NUMBER_QUERY")
	public static GMMap nbsmKkUnknownNumberQuery(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "118_WEB_SORGULAMA")).uniqueResult();

		try {
			if ("A".equals(parametre.getDeger())) {
				conn = DALUtil.getGMConnection();


				stmt = conn.prepareCall("{? = call PKG_IST_BILINMEYEN_NUMARA.rc_kk_basvuru_bilgi (?,?)}");

				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(3,  "TELEFON");
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);

				String ev_tel = null;
				String is_tel = null;
				String cep_tel = null;

				while (rSet.next()) {
					if("1".equals(rSet.getString("TEL_TIP"))){ // ev tel
						ev_tel=rSet.getString("TEL_NO");
					}
					else if("2".equals(rSet.getString("TEL_TIP"))){ //is tel
						is_tel=rSet.getString("TEL_NO");
					}
					else{    // cep tel
						cep_tel=rSet.getString("TEL_NO");
					}
				}

				iMap.put("PARAM_REF_TUR", "KK_BASVURU");
				iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
				iMap.put("CLIENT_QUERY_NO", "1");

				sMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
				sMap.put("SORGU_TIP_KOD", "4");
				sMap.put("KIM_ICIN", iMap.getString("KIM_ICIN"));
				sMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
				
				if ("Y".equals(iMap.getString( "EVTEL_SORGU_GEREKLI")) && !StringUtils.isBlank(ev_tel) && ev_tel.length() == 10) {
					oMap = new GMMap();
					iMap.put("PHONE_NUMBER", ev_tel);
					oMap = GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", iMap);

					if (oMap.getString("LOG_ID") != null) {
						sMap.put("SORGU_NO", new BigDecimal(oMap.getString("LOG_ID")));
						insertBasvuruSorguTakip(sMap);
					}

				}
				if ("Y".equals(iMap.getString("ISTEL_SORGU_GEREKLI")) && !StringUtils.isBlank(is_tel) && is_tel.length() == 10) {
					oMap = new GMMap();
					iMap.put("PHONE_NUMBER", is_tel);
					oMap = GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", iMap);

					if (oMap.getString("LOG_ID") != null) {
						sMap.put("SORGU_NO", new BigDecimal(oMap.getString("LOG_ID")));
						insertBasvuruSorguTakip(sMap);
					}
				}
				if ("Y".equals(iMap.getString("CEPTEL_SORGU_GEREKLI")) && !StringUtils.isBlank(cep_tel) && cep_tel.length() == 10) {
					oMap = new GMMap();
					iMap.put("PHONE_NUMBER", cep_tel);
					oMap = GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", iMap);

					if (oMap.getString("LOG_ID") != null) {
						sMap.put("SORGU_NO", new BigDecimal(oMap.getString("LOG_ID")));
						insertBasvuruSorguTakip(sMap);
					}
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static void insertBasvuruSorguTakip(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_BASVURU_SORGU.insert_bir_basvuru_sorgu_takip (?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SORGU_NO"));
			stmt.setString(i++, iMap.getString("SORGU_TIP_KOD"));
			stmt.setString(i++, iMap.getString("KIM_ICIN"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, null);
			stmt.setString(i++, null);
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3871_LKS_ONLINE_TAHSIS_SORGU_YAP")
	public static  GMMap lksOnlineTahsisSorguYap(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call BNSPR.pkg_kk_basvuru_sorgu.RC_GET_LKS_SORGU_DATA(?,?,'01') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"));
			if ( oMap.isEmpty()){
				System.err.println("Kayit Bulunamadi:" + iMap.getBigDecimal("BASVURU_NO") + "-" + iMap.getBigDecimal("TRX_NO"));
				oMap.put("LKS_YAPILDIMI", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				return oMap;
			}
			
			GMMap tMap = new GMMap();
			tMap.putAll(oMap.getMap("GIDEN_SORGU_DETAY",0));
			tMap.put("SORGU_TIPI", "01");
			tMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("LKS_SORGUSU_YAP", tMap));
		}
		catch (Throwable e) {
			e.printStackTrace();
			oMap.put("LKS_YAPILDIMI", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3871_LKS_ONLINE_EK_TAHSIS_SORGU_YAP")
	public static  GMMap lksOnlineEkTahsisSorguYap(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call BNSPR.pkg_kk_basvuru_sorgu.RC_GET_LKS_SORGU_DATA(?,?,'02') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"));
			if ( oMap.isEmpty()){
				System.err.println("Kayit Bulunamadi:" + iMap.getBigDecimal("BASVURU_NO") + "-" + iMap.getBigDecimal("TRX_NO"));
				oMap.put("LKS_YAPILDIMI", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				return oMap;
			}
			GMMap tMap = new GMMap();
			tMap.putAll(oMap.getMap("GIDEN_SORGU_DETAY",0));
			tMap.put("SORGU_TIPI", "02");
			tMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			return new GMMap(GMServiceExecuter.execute("LKS_SORGUSU_YAP", tMap));
		}
		catch (Throwable e) {
			e.printStackTrace();
			oMap.put("LKS_YAPILDIMI", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3871_LKS_TAHSIS_IPTAL")
	public static GMMap lksTahsisIptal(GMMap iMap){
		GMMap oMap= new GMMap();
		try {
			String procStr="{call PKG_LKS_ISLEM.lks_tahsis_iptal (?,?,?)}";
			int i = 0;
			Object [] inputValues = new Object [2];
			Object [] outputValues= new Object [4];
			inputValues[i++]=BnsprType.NUMBER;
			inputValues[i++]=iMap.getBigDecimal("SORGU_NO");
			i=0;
			outputValues[i++]=BnsprType.NUMBER;
			outputValues[i++]="RESPONSE";
			outputValues[i++]=BnsprType.STRING;
			outputValues[i++]="RESPONSE_MESSAGE";
			
		
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Throwable e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3871_LKS_ONLINE_TAHSIS_YAP")
	public static  GMMap lksOnlineTahsisYap(GMMap iMap){
		
		try {
			GMMap oMap = new GMMap(),
			      tMap1 = new GMMap(),
			    		  tMap2 = new GMMap();
			
			
			/*String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'03') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
			if ( oMap.isEmpty()){
				throw new Exception("Kayit Bulunamadi");
			}*/
			
			tMap1.putAll(iMap.getMap("GIDEN_SORGU_DETAY",0));
			tMap1.put("MANUEL_SORGU", iMap.getString("MANUEL_SORGU"));
			tMap1.put("SORGU_TIPI", "03");
			tMap2 = new  GMMap(GMServiceExecuter.call("LKS_SORGUSU_YAP", tMap1));
			if ( "HAYIR".equals(tMap2.getString("TEKRAR_MI"))  && tMap2.getString("RESPONSE").equals("2")){
				String procStr="{call pkg_kk_basvuru_sorgu.BASVURU_BILDIRIM_insert (?,?,?,?,?)}";
				int i = 0;
				Object [] inputValues = new Object [6];
				Object [] outputValues= new Object [4];
				inputValues[i++]=BnsprType.NUMBER;
				inputValues[i++]=tMap1.getBigDecimal("BASVURU_NO");
				inputValues[i++]=BnsprType.NUMBER;
				inputValues[i++]=tMap2.getBigDecimal("SORGU_NO");
				inputValues[i++]=BnsprType.NUMBER;
				inputValues[i++]=new BigDecimal("1"); //1: LKS_FTP Tahsis Islemi
				i=0;
				outputValues[i++]=BnsprType.STRING;
				outputValues[i++]="RESPONSE";
				outputValues[i++]=BnsprType.STRING;
				outputValues[i++]="RESPONSE_MESSAGE";
				oMap=(GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
				oMap.put("LKS_YAPILDIMI", tMap2.getString("LKS_YAPILDIMI"));
				oMap.put("SORGU_NO", tMap2.getString("SORGU_NO"));
			
			}
			else{
				if("2".equals(tMap2.getString("RESPONSE")))
					bildirimDurumuGuncelle(tMap2.getBigDecimal("SORGU_NO"),"H",new Date(Calendar.getInstance().getTime().getTime()), tMap1.getBigDecimal("BASVURU_NO"));
				else
					bildirimDurumuGuncelle(tMap2.getBigDecimal("SORGU_NO"),"I",new Date(Calendar.getInstance().getTime().getTime()), tMap1.getBigDecimal("BASVURU_NO"));
				oMap.put("SORGU_NO", tMap2.getString("SORGU_NO"));
				oMap.put("LKS_YAPILDIMI", tMap2.getString("LKS_YAPILDIMI"));
				oMap.put("RESPONSE",tMap2.getString("RESPONSE"));
				oMap.put("RESPONSE_MESSAGE", tMap2.getString("RESPONSE_MESSAGE"));
			}
			return oMap;
		}
		catch (Throwable e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	private static void bildirimDurumuGuncelle(BigDecimal sorguNo, String status, Date bildirimTarihi, BigDecimal basvuruNo) {
		String procStr = "{call PKG_LKS_BILDIRIM.lks_bildirim_update (?,?,?,?)}";
		int i = 0;
		Object[] inputValues = new Object[8];
		Object[] outputValues = new Object[0];
		inputValues[i++] = BnsprType.NUMBER;
		inputValues[i++] = sorguNo;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = status;
		inputValues[i++] = BnsprType.DATE;
		inputValues[i++] = bildirimTarihi;
		inputValues[i++] = BnsprType.NUMBER;
		inputValues[i++] = basvuruNo;
		try {
			DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3871_LKS_ONLINE_EK_TAHSIS_YAP")
	public static  GMMap lksOnlineEkTahsisYap(GMMap iMap){
		GMMap oMap =new GMMap(),
		tMap1 = new GMMap(),
	    		  tMap2 = new GMMap();
		try {
//			String func = "{? = call BNSPR.pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'04') }";
//			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
//			if ( oMap.isEmpty()){
//				throw new Exception("Kayit Bulunamadi");
//			}
			tMap1.put("MANUEL_SORGU", iMap.getString("MANUEL_SORGU"));
			tMap1.putAll(iMap.getMap("GIDEN_SORGU_DETAY",0));
			tMap1.put("SORGU_TIPI", "04");
			tMap2 = new  GMMap(GMServiceExecuter.execute("LKS_SORGUSU_YAP", tMap1));
			if ("HAYIR".equals(tMap2.getString("TEKRAR_MI"))  &&  tMap2.getString("RESPONSE").equals("2") ){
				String procStr="{call pkg_kk_basvuru_sorgu.BASVURU_BILDIRIM_insert (?,?,?,?,?)}";
				int i = 0;
				Object [] inputValues = new Object [6];
				Object [] outputValues= new Object [4];
				inputValues[i++]=BnsprType.NUMBER;
				inputValues[i++]=tMap1.getBigDecimal("BASVURU_NO");
				inputValues[i++]=BnsprType.NUMBER;
				inputValues[i++]=tMap2.getBigDecimal("SORGU_NO");
				inputValues[i++]=BnsprType.NUMBER;
				inputValues[i++]=new BigDecimal("4"); //4: LKS_FTP Ek Tahsis Islemi
				i=0;
				outputValues[i++]=BnsprType.STRING;
				outputValues[i++]="RESPONSE";
				outputValues[i++]=BnsprType.STRING;
				outputValues[i++]="RESPONSE_MESSAGE";
				oMap=(GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
				oMap.put("LKS_YAPILDIMI", tMap2.getString("LKS_YAPILDIMI"));
				oMap.put("SORGU_NO", tMap2.getString("SORGU_NO"));
			}
			else{
				if("2".equals(tMap2.getString("RESPONSE")))
					bildirimDurumuGuncelle(tMap2.getBigDecimal("SORGU_NO"),"H",new Date(Calendar.getInstance().getTime().getTime()), tMap1.getBigDecimal("BASVURU_NO"));
				else
					bildirimDurumuGuncelle(tMap2.getBigDecimal("SORGU_NO"),"I",new Date(Calendar.getInstance().getTime().getTime()), tMap1.getBigDecimal("BASVURU_NO"));
				oMap.put("LKS_YAPILDIMI", tMap2.getString("LKS_YAPILDIMI"));
				oMap.put("SORGU_NO", tMap2.getString("SORGU_NO"));
				oMap.put("RESPONSE",tMap2.getString("RESPONSE"));
				oMap.put("RESPONSE_MESSAGE", tMap2.getString("RESPONSE_MESSAGE"));
			}
			return oMap;
		}
		catch (Throwable e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	public static GMMap TCMBSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_kk_basvuru_sorgu.tcmb_sorgu (?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			
			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap FraudSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_kk_basvuru_sorgu.fraud_sorgu (?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));

			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap KKBSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i;
		BigDecimal sorguNo = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_kk_basvuru_sorgu.kkb_sorgu (?,?,?,?,?,?)}");
			i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("BBE_GEREKLI") != null ? iMap.getString("BBE_GEREKLI") :"0");
			
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			GMMap sMap = new GMMap();
			sMap.putAll(DALUtil.rSetResults(rSet, "KKB_SORGU_LIST"));
			for (int z = 0; z < sMap.getSize("KKB_SORGU_LIST"); z++) {
				sorguNo = sMap.getBigDecimal("KKB_SORGU_LIST", z, "SORGU_ID");
			}
			if (stmt.getString(5).equals("E")) {
				GMServiceExecuter.execute("ADD_KKB_TEST", sMap);
			}
			
			stmt2 = conn.prepareCall("{? = call pkg_kk_basvuru_sorgu.kkb_sorgu_devam (?,?,?,?)}");
			i = 1;
			stmt2.registerOutParameter(i++, Types.VARCHAR);
			stmt2.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt2.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt2.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt2.setBigDecimal(i++, sorguNo);
			
			stmt2.execute();

			oMap.put("KKB_BASARILI", stmt2.getString(1));

		}
		catch (Exception e) {
			oMap.put("KKB_BASARILI", "H");

			try {
				stmt3 = conn.prepareCall("{? = call pkg_kk_basvuru_sorgu.kkb_sorgu_devam (?,?,?,?)}");
				i = 1;
				stmt3.registerOutParameter(i++, Types.VARCHAR);
				stmt3.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt3.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt3.setString(i++, iMap.getString("SORGU_SEVIYESI"));
				stmt3.setBigDecimal(i++, sorguNo);

				stmt3.execute();
			}
			catch (Exception e2) {
				oMap.put("KKB_BASARILI", "H");
			}
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	public static GMMap getApplicationData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("3")); // Application 3
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			if (iMap.getString("SORGU_SEVIYESI").equals("R"))
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap getCustomerData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("4")); // Customer 4
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			if (iMap.getString("SORGU_SEVIYESI").equals("R"))
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap getKKBData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("5")); // KKB 5
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap getVerificationFraudData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("2")); // Vertification&Fraud 2
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap getTCMBData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("6")); // TCMB 6
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static void fillNbsmDeger(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC_NBSM.fill_nbsm_deger(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SMCallType"));

			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap brmDecisionCall(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			GMMap bMap = new GMMap();
			bMap.put("CallId", (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "BIR_NBSM_SORGU")).get("ID"));
			oMap.put("CallId", bMap.getBigDecimal("CallId"));
			bMap.put("APPL", getApplicationData(iMap));
			oMap.put("KDH_ISTIYOR_MU", bMap.getMap("APPL").getString("AppnODReqF"));
			oMap.put("BASVURU_TIPI", bMap.getMap("APPL").getString("AppnCCAppType"));//1.Kart 2.Ononayli 3.Limit
			bMap.put("MVT", getCustomerData(iMap));
			oMap.put("MUSTERI_BLOKESI_VAR", bMap.getMap("MVT").getString("AppBlockedCustCode"));
			bMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			if ("E".equals(iMap.getString("KKB_YAPILDI")) || "R".equals(iMap.getString("SMCallType")) || "F".equals(iMap.getString("SMCallType"))) {
				bMap.put("KKB", getKKBData(iMap));
			}
			bMap.put("FRAUD", getVerificationFraudData(iMap));
			bMap.put("TCMB", getTCMBData(iMap));

			bMap.put("SMCallType", iMap.getString("SMCallType"));
			if (iMap.getMap("RESULT") != null)
				bMap.put("RESULT", iMap.getMap("RESULT"));

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_kk_basvuru_sorgu.basvuru_insert_nbsm_sorguid (?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SMCallType"));
			stmt.setBigDecimal(i++, bMap.getBigDecimal("CallId"));
			stmt.execute();
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_BRM_DECISION_CREDIT_CARD_CALL", bMap));

			fillNbsmDeger(bMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static String getPrevNbsmOutputValue(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM_7RSL.get_prev_nbsm_output_value (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setString(i++, iMap.getString("NBSM_KEY"));

			stmt.execute();

			return stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap getPrevNbsmData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM_7RSL.get_prev_nbsm_outputs (?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SMCallType"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap.put("RESULT", DALUtil.rSetMap(rSet));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static String brmDecisionGetString(String brmKey, GMMap iMap1, GMMap iMap2) {
		if (iMap1.getString(brmKey) != null)
			return iMap1.getString(brmKey);
		else
			return iMap2.getString(brmKey);
	}

	/** Kredi karti basvurusu sahibine ait daha once yapilmis aktif basvuru var mi?<br>
	 * @author murat.el
	 * @since PY-
	 * @param iMap - Basvuru/Basvuru sahibi bilgileri
	 *        <li> BASVURU_NO - Basvuru numarasi
	 *        <li> TRX_NO - Islem numarasi
	 *        <li> TCK_NO - Basvuru sahibi kimlik numarasi
	 *        <li> BASVURU_SONLANDIR - Basvuru sonlandirilsin mi?(E|H)
	 *        <li> KART_TIPI - Kart tipi (KK|D)
	 * @return oMap - Aktif basvuru var mi?
	 *        <li> DEVAM - Isleme devam edilebilir mi?(E|H)
	 *        <li> MESSAGE - Red almis ise red alma sebebi
	 */
	@GraymoundService("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL")
	public static GMMap basvuruGirisCaprazKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Input
			Object [] inputValues = new Object [6];
			int i = 0;
			inputValues[i++]=BnsprType.NUMBER;
			inputValues[i++]=iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++]=BnsprType.STRING;
			inputValues[i++]=iMap.getString("TCK_NO");
			inputValues[i++]=BnsprType.STRING;
			inputValues[i++]=CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), "KK");
			//Output
			Object [] outputValues = new Object [4];
			i = 0;
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESULT";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MESSAGE_NO";
			//Execute
			String procStr="{call PKG_KK_BASVURU_SORGU.basvurugiriscaprazkontrol(?,?,?,?,?)}";
			sorguMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			//Kontrol
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("RESULT"))) {  // is kesilmeli
				oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sorguMap).get("ERROR_MESSAGE"));
	        	oMap.put("DEVAM", CreditCardServicesUtil.HAYIR);
	        	//Basvuru sonlandirilmasi isteniyorsa basvuruyu iptal et ve islemi bitir.
	        	if (CreditCardServicesUtil.EVET.equals(iMap.getString("BASVURU_SONLANDIR", CreditCardServicesUtil.EVET))) {
	        		sorguMap.clear();
	        		sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
	        		sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
	        		sorguMap.put("DURUM", "IPTAL");
	        		sorguMap.put("AKSIYON_KOD", "C");
	        		sorguMap.put("AKSIYON_KARAR_KOD", "3");
					basvuruSonlandir(sorguMap);
	        	}
			} else {
				oMap.put("DEVAM", CreditCardServicesUtil.EVET);
			}
		}
		catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Kredi karti basvurusu sahibine ait son 20 gunde red almis basvuru var mi?<br>
	 * 
	 * @param iMap - Basvuru/Basvuru sahibi bilgileri
	 *        <li> BASVURU_NO - Basvuru numarasi
	 *        <li> TRX_NO - Islem numarasi
	 *        <li> TCK_NO - Basvuru sahibi kimlik numarasi
	 *        <li> BASVURU_SONLANDIR - Basvuru sonlandirilsin mi?(E|H)
	 * @return Red almis mi?
	 *        <li> DEVAM - Isleme devam edilebilir mi?(E|H)
	 *        <li> MESSAGE - Red almis ise red alma sebebi
	 */
	@GraymoundService("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL")
	public static GMMap basvuruGirisRedKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Input
			Object [] inputValues = new Object [6];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TRX_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCK_NO");
			//Output
			Object [] outputValues = new Object [4];
			i = 0;
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESULT";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MESAJ_KOD";
			//Execute
			String procStr="{call PKG_KK_BASVURU_SORGU.aynitcknyirmigundered(?,?,?,?,?)}";
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			if (CreditCardServicesUtil.HAYIR.equals(oMap.getString("RESULT"))) {  // is kesilmeli
				iMap.put("MESSAGE_NO",oMap.getBigDecimal("MESAJ_KOD") );
				oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
	        	oMap.put("DEVAM", CreditCardServicesUtil.HAYIR);
	        	//Basvuru sonlandirilmasi isteniyorsa, islemi bitir.
	        	if (CreditCardServicesUtil.EVET.equals(iMap.getString("BASVURU_SONLANDIR", CreditCardServicesUtil.EVET))) {
	        		iMap.put("DURUM", "IPTAL");  // durum_kod iptal
					iMap.put("AKSIYON_KOD", "C");
					iMap.put("AKSIYON_KARAR_KOD", "3");
					basvuruSonlandir(iMap);		// trx calistir
	        	}
			} else {
				oMap.put("DEVAM", CreditCardServicesUtil.EVET);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3871_DEVAM_SORGULAR")
	public static GMMap devamSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			iMap.put("SORGU_KIM_ICIN", "M");
			iMap.put("SORGU_SEVIYESI", "H");
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
//			durumKontrol(iMap);
			TCMBSorgu(iMap);
			FraudSorgu(iMap);
			
			GMServiceExecuter.execute("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap);
			
			iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));

			GMMap bMap = new GMMap();
			bMap.putAll(brmDecisionCall(iMap)); // KKB icin NBSM sorgusu yapiliyor
			oMap.put("NBSM_KARAR_KOD", bMap.getString("KKBPolicyRulesDecisionCategory"));
			oMap.put("NBSM_KDH_KARAR_KOD", bMap.getString("KKBPolicyRulesODDecisionCategory"));
			oMap.put("NBSM_FRAUD_KARAR_KOD", bMap.getString("SMFraudStrategyFraudLevel"));
			oMap.put("CallId", bMap.getBigDecimal("CallId"));
			
			//H call kararlarini al
			String basvuruKararH = bMap.getString("KKBPolicyRulesDecisionCategory");
			String kdhKararH = bMap.getString("KKBPolicyRulesODDecisionCategory");
			
			boolean basvuruKararHRedMi = "Policy Decline".equals(basvuruKararH) || "Decline".equals(basvuruKararH);
			boolean kdhKararHRedMi = "Policy Decline".equals(kdhKararH) || "Decline".equals(kdhKararH);
			boolean kdhBasvuruMu = CreditCardServicesUtil.YES.equals(bMap.getString("KDH_ISTIYOR_MU"));
			
			//Yorumla
			//Kart basvurusu redse; kdh yoksa RED,  kdh varsa ve red ise RED
			if ((basvuruKararHRedMi && !kdhBasvuruMu) || (basvuruKararHRedMi && kdhBasvuruMu && kdhKararHRedMi)) {
			//if (basvuruKararHRedMi && kdhKararHRedMi) {
				oMap.put("DURUM", "RED");
				oMap.put("DEVAM", "H");
				oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
				oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
				oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));
			}
			//H call basari ile tamamlandi I call sonucunu kontrol et
			else {
				iMap.put("SORGU_SEVIYESI", "I");
				iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
				//I call icin KKB gerekli mi
				if ("Y".equals(bMap.getString("KKBStrategyKKBYNRequiredYN"))) {
					//BBE gerekli mi
					if ("Y".equals(bMap.getString("KKBStrategyBBEYNRequiredYN"))){
						iMap.put("BBE_GEREKLI", "1");
					}
					//KKB sorgusu her durumda yapilir, hata almasi durumunda akis kesilmez, F callda tekrar yapilir
					KKBSorgu(iMap);
					iMap.put("KKB_YAPILDI", "E");
					//Fraud sorgusu yap
					FraudSorgu(iMap);
					//Onceki NBSM datasini al
					iMap.putAll(getPrevNbsmData(iMap));
					//I call
					GMMap b2Map = new GMMap();
					b2Map.putAll(brmDecisionCall(iMap));
					oMap.put("ONAY_KART_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeFinalLimit"));
					oMap.put("ONAY_KDH_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeODLimit"));
					oMap.put("ONAY_LKS_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeLKSLimit"));
					oMap.put("ONAY_EKSPRES_LIMIT", BigDecimal.ZERO);
					oMap.put("NAKIT_LIMIT_ORANI", b2Map.getBigDecimal("StrategyLimitMergeCashLimitPerc"));
					//oMap.put("ONAY_NAKIT_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeCashLimitPerc").subtract(b2Map.getBigDecimal("StrategyLimitMergeFinalLimit")));
					oMap.put("NBSM_KARAR_KOD", b2Map.getString("InitialDecisionMergeDecCatgry"));
					oMap.put("NBSM_KDH_KARAR_KOD", b2Map.getString("InitialDecisionODMergeDecCatgry"));
					oMap.put("NBSM_FRAUD_KARAR_KOD", b2Map.getString("SMFraudStrategyFraudLevel"));
					oMap.put("CallId", b2Map.getBigDecimal("CallId"));
					oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
					oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
					oMap.put("GARANTORLU_MU", b2Map.getString("StrategyLimitMergeCmpGuarantorF"));
					oMap.put("MUSTERI_BLOKESI_VAR", b2Map.getString("MUSTERI_BLOKESI_VAR"));
					oMap.put("EVTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppHomChReq", b2Map, bMap));
					oMap.put("ISTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppWorkChReq", b2Map, bMap));
					oMap.put("CEPTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppGSMChReq", b2Map, bMap));
					oMap.put("ES_KKB_SORGU_GEREKLI", brmDecisionGetString("KKBStrategySpoKKBYNRequiredYN", b2Map, bMap));
					oMap.put("MAC_BILETI_LIMITI_MI", b2Map.getString("StrategyLimitMergeMacBiletiLimitF"));
					oMap.put("MAC_BILETI_MUST_GRUP", b2Map.getString("StrategyLimitMergeMacBiletiMusteriGrubu"));
					
					//I call kararlarini al
					String basvuruKararI = b2Map.getString("InitialDecisionMergeDecCatgry");
					String kdhKararI = b2Map.getString("InitialDecisionODMergeDecCatgry");
					
					boolean basvuruKararIRedMi = "Policy Decline".equals(basvuruKararI) || "Decline".equals(basvuruKararI);
					boolean kdhKararIRedMi = "Policy Decline".equals(kdhKararI) || "Decline".equals(kdhKararI);
					//Kart basvurusu redse; kdh yoksa RED,  kdh varsa ve red ise RED
					if ((basvuruKararIRedMi && !kdhBasvuruMu) || (basvuruKararIRedMi && kdhBasvuruMu && kdhKararIRedMi)) {
					//if (basvuruKararIRedMi && kdhKararIRedMi) {
						oMap.put("DURUM", "RED");
						oMap.put("DEVAM", "H");
						oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
					}
					else {
						// ikinci ekranda gelir alanlari gosterilecek mi
						oMap.put("GELIR_GOSTER", b2Map.getString("InitialStrategyIncYNReq"));
						oMap.put("DURUM", "ON_BASVURU");
						oMap.put("DEVAM", "E");
						oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
					}
				}
			}
			//118 bilinmeyen numara sorgusu yap
			if("E".equals(oMap.getString("DEVAM")))
			{
				if ("Y".equals(oMap.getString("EVTEL_SORGU_GEREKLI")) || "Y".equals(oMap.getString("ISTEL_SORGU_GEREKLI")) || "Y".equals(oMap.getString("CEPTEL_SORGU_GEREKLI"))) {
					GMMap i2Map = new GMMap();
					i2Map.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					i2Map.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
					i2Map.put("KIM_ICIN", "M");
					i2Map.put("EVTEL_SORGU_GEREKLI", oMap.getString("EVTEL_SORGU_GEREKLI"));
					i2Map.put("ISTEL_SORGU_GEREKLI", oMap.getString("ISTEL_SORGU_GEREKLI"));
					i2Map.put("CEPTEL_SORGU_GEREKLI", oMap.getString("CEPTEL_SORGU_GEREKLI"));
					GMServiceExecuter.executeNT("BNSPR_NBSM_KK_UNKNOWN_NUMBER_QUERY", i2Map);
				}
			}
			//Alinan nbsm sonuclarini kaydet
			updateNbsmSorguSonuc(iMap, oMap);
		}
		catch (Exception e) {
			e.printStackTrace();
			//Durum Guncelle
			int length = e.getMessage().length();
			if (e.getMessage().length() > 4000) {
				length = 4000;
			}
			
			iMap.put("DURUM_KOD", "NBSM");
			iMap.put("ISLEM_NO", iMap.get("TRX_NO"));
			iMap.put("ISLEM_ACIKLAMA", e.getMessage().substring(0, length));
			iMap.put("TARIHCE_AKSIYON", "G");
			GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
			
			//Mail Gonder
			String hataMesaji = ExceptionUtils.getStackTrace(e);
			if(StringUtils.isNotBlank(hataMesaji)) {
				hataMesaji = hataMesaji.substring(0, hataMesaji.length()>4000?3999:hataMesaji.length());
			}
			
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_TO_PARAM", "NBSM_HATA_MAIL_TO");
			mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			mailMap.put("MAIL_SUBJECT", "NBSM Durumundaki Basvuru - " + iMap.getString("BASVURU_NO"));
			mailMap.put("MAIL_BODY", hataMesaji);
			GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			
			//Output parametreleri set et
			oMap.put("DURUM", "NBSM");
			oMap.put("DEVAM", "H");
			oMap.put("NBSM_HATASI_MI", "E");
			oMap.put("MESSAGE", CreditCardTffServices.errorMessageOlustur("1803" , "H"));
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	public static GMMap basvuruTxDurumGuncelle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_KK_BASVURU.Tx_Durum_Guncelle (?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DURUM"));
			stmt.setString(i++, iMap.getString("AKSIYON_KOD"));
			stmt.setString(i++, iMap.getString("AKSIYON_KARAR_KOD"));
			stmt.setString(i++, iMap.getString("NBSM_KARAR_KOD"));
			stmt.setString(i++, iMap.getString("NBSM_KDH_KARAR_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ONAY_KDH_LIMIT"));
			stmt.execute();
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3871_BASVURU_SONLANDIR")
	public static GMMap basvuruSonlandir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			
			basvuruTxDurumGuncelle(iMap);
			
			if ((iMap.getBigDecimal("KANAL_KOD") == null) || (iMap.getString("KANAL_KOD").compareTo("7") != 0)) {
				iMap.put("TRX_NAME", "3871");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap updateNbsmSorguSonuc(GMMap iMap, GMMap i2Map) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			//if (i2Map.containsKey("CallId") && i2Map.getBigDecimal("CallId") != null)
			{
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{call PKG_KK_BASVURU_SORGU.update_nbsm_sorgu_sonuc (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				int i = 1;
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("CallId"));
				stmt.setString(i++, i2Map.getString("DURUM"));
				stmt.setString(i++, i2Map.getString("NBSM_KARAR_KOD"));
				stmt.setString(i++, i2Map.getString("NBSM_KOD"));
				stmt.setString(i++, i2Map.getString("GELIR_GOSTER"));
				stmt.setString(i++, i2Map.getString("GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ADRES_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("GMENKUL_GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ES_GELIR_BELGE_GEREKLI"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONAY_KART_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONAY_LKS_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONAY_EKSPRES_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONAY_NAKIT_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("NBSM_UW_ONCELIK"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("NBSM_FRAUD_ONCELIK"));
				stmt.setString(i++, i2Map.getString("NBSM_FRAUD_KARAR_KOD"));
				stmt.setString(i++, i2Map.getString("MUSTERI_BLOKESI_VAR"));
				stmt.setString(i++, i2Map.getString("NBSM_KARAR_GEREKCE"));
				stmt.setString(i++, i2Map.getString("EVTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ISTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("CEPTEL_SORGU_GEREKLI"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("NAKIT_LIMIT_ORANI"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONAY_KDH_LIMIT"));
				stmt.setString(i++, i2Map.getString("NBSM_KDH_KARAR_KOD"));
				stmt.setString(i++, i2Map.getString("MAC_BILETI_LIMITI_MI"));
				stmt.setString(i++, i2Map.getString("MAC_BILETI_MUST_GRUP"));
				stmt.execute();
			}

			iMap.put("DURUM", i2Map.getString("DURUM"));
			if (!"R".equals(iMap.getString("SORGU_SEVIYESI"))) {
				if (!"E".equals(i2Map.getString("DEVAM")) && ("RED".equals(i2Map.getString("DURUM")) || "FRAUD".equals(i2Map.getString("DURUM"))))
				{
					iMap.put("NBSM_KARAR_KOD", i2Map.getString("NBSM_KARAR_KOD"));
					iMap.put("NBSM_KDH_KARAR_KOD", i2Map.get("NBSM_KDH_KARAR_KOD"));
					iMap.put("ONAY_KDH_LIMIT", i2Map.get("ONAY_KDH_LIMIT"));
					basvuruSonlandir(iMap);
				}
			}
			
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3871_GONDER_SORGULAR")
	public static GMMap gonderSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap tarihceMap = new GMMap();
		
		try {
			GMMap oMap = new GMMap();
			iMap.put("SORGU_SEVIYESI", "F");
			iMap.put("SORGU_KIM_ICIN", "M");
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
//						durumKontrol(iMap);
			iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));

			GMMap b2Map = new GMMap();
			GMMap lMap = new GMMap();
			
			if ("E".equals(iMap.getString("LIMIT_ARTIS"))) {
				lMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_ONLINE_EK_TAHSIS_SORGU_YAP", iMap));
			}
			else {
				if (!"ON_ONAY_BASVURU".equals(iMap.getString("ACTION"))) {
					lMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_ONLINE_TAHSIS_SORGU_YAP", iMap));
				}
			}				
			
			if("2".equals(lMap.getString("LKS_YAPILDIMI")) && "2".equals(lMap.getString("RESPONSE"))) {
				//Tarihce kaydi olustur
				if ("LKS_JOB_1".equals(iMap.getString("DURUM_KOD"))) {//LKS_JOB dan geliyor
					tarihceMap.put("DURUM_KODU", "LKS_JOB_1");
				} else if ("VERI_KONTROL".equals(iMap.getString("DURUM_KOD"))) {//Veri kontrolden geliyor
					tarihceMap.put("DURUM_KODU", "VERI_KONTROL");
				} else if ("VERI_TAMAMLAMA".equals(iMap.getString("DURUM_KOD"))) {//Veri tamamlamadan geliyor
					tarihceMap.put("DURUM_KODU", "VERI_TAMAMLAMA");
				} else if ("BASIM".equals(iMap.getString("DURUM_KOD"))) {//Veri tamamlamadan geliyor
					tarihceMap.put("DURUM_KODU", "BASIM");
				} else if ("LKS_JOB_2".equals(iMap.getString("DURUM_KOD"))) {//lks tahsisden geliyor
					tarihceMap.put("DURUM_KODU", "LKS_JOB_2");
				} else if ("OCEAN_JOB".equals(iMap.getString("DURUM_KOD"))) {//ocean hatasindan geliyor
					tarihceMap.put("DURUM_KODU", "OCEAN_JOB");
				} else {//Ekrandan geliyor
					tarihceMap.put("DURUM_KODU", "ON_BASVURU");
				}

				// onceki nbsm datalari
				iMap.putAll(getPrevNbsmData(iMap));
				
				String KKBStrategyKKBYNRequiredYN = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "KKBStrategyKKBYNRequiredYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "I"));
				String KKBStrategyBBEYNRequiredYN = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "KKBStrategyBBEYNRequiredYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "I"));
				
				boolean kkbBasarili = false;
				if ("Y".equals(KKBStrategyKKBYNRequiredYN)) // KKB gerekli
				{
					if("Y".equals(KKBStrategyBBEYNRequiredYN)){
						iMap.put("BBE_GEREKLI", "1");
					}
					
					kkbBasarili = "E".equals(KKBSorgu(iMap).get("KKB_BASARILI"));
					if (!kkbBasarili) {
						tarihceMap.put("ISLEM_SONRASI_DURUM_KODU", "KKB_JOB");
						oMap.put("DURUM", "KKB_JOB");
						iMap.put("MESSAGE_NO", new BigDecimal(2998));
						oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
						oMap.put("DEVAM", "E");
					} else {
						tarihceMap.put("ISLEM_SONRASI_DURUM_KODU", "NBSM");
					}
					
					//Tarihce kaydi olustur.
					if ("BASIM".equals(iMap.getString("DURUM_KOD"))) {
						tarihceMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						tarihceMap.put("TRX_NO", iMap.get("UST_ISLEM_TRX_NO"));
						tarihceMap.put("YENI_DURUM_KODU", tarihceMap.get("ISLEM_SONRASI_DURUM_KODU"));
						tarihceMap.put("ISLEM_SONRASI_DURUM_KODU", iMap.get("DURUM_KOD"));
						GMServiceExecuter.execute("BNSPR_KK_TARIHCE_GUNCELLE", tarihceMap);
					} else {
						tarihceMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						tarihceMap.put("TRX_NO", iMap.get("TRX_NO"));
						tarihceMap.put("ISLEM_KODU", "BASVURU");
						tarihceMap.put("YENI_KAYIT_MI", "E");
						GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", tarihceMap);
					}
				} else {
					iMap.put("MESSAGE_NO", new BigDecimal(2998));
					oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
					oMap.put("DEVAM", "E");
					return oMap;
				}
				
				if(kkbBasarili)
				{
					TCMBSorgu(iMap);
					FraudSorgu(iMap);
					GMServiceExecuter.execute("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap);
					
					b2Map.putAll(brmDecisionCall(iMap));
					oMap.put("NBSM_KARAR_KOD", b2Map.getString("FinalDecisionMergeDecCategory"));
					oMap.put("NBSM_KDH_KARAR_KOD", b2Map.getString("FinalDecisionODMergeDecCategory"));
					oMap.put("ONAY_KDH_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeODLimit"));
					oMap.put("NBSM_FRAUD_KARAR_KOD", b2Map.getString("SMFraudStrategyFraudLevel"));
					oMap.put("CallId", b2Map.getBigDecimal("CallId"));
					oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
					oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
					oMap.put("ADRES_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionAddressDocumentsRequired"));
					oMap.put("GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionIncomeDocumentsRequired"));
					oMap.put("GMENKUL_GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionREMADocumentsRequired"));
					oMap.put("ES_GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionSpouseDocumentRequired"));
					oMap.put("MUSTERI_BLOKESI_VAR", b2Map.getString("MUSTERI_BLOKESI_VAR"));
					oMap.put("EVTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppHomChReq", b2Map, new GMMap()));
					oMap.put("ISTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppWorkChReq", b2Map, new GMMap()));
					oMap.put("CEPTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppGSMChReq", b2Map, new GMMap()));
					oMap.put("MAC_BILETI_LIMITI_MI", b2Map.getString("StrategyLimitMergeMacBiletiLimitF"));
					oMap.put("MAC_BILETI_MUST_GRUP", b2Map.getString("StrategyLimitMergeMacBiletiMusteriGrubu"));
					
					//F call kararlarini al
					String basvuruKararF = b2Map.getString("FinalDecisionMergeDecCategory");
					String kdhKararF = b2Map.getString("FinalDecisionODMergeDecCatgry");
					String fraudKararF = b2Map.getString("SMFraudStrategyFraudLevel");
					
					boolean kdhBasvuruMu = CreditCardServicesUtil.YES.equals(b2Map.getString("KDH_ISTIYOR_MU"));
					boolean basvuruKararFRedMi = "Policy Decline".equals(basvuruKararF) || "Decline".equals(basvuruKararF);
					boolean kdhKararFRedMi = "Policy Decline".equals(kdhKararF) || "Decline".equals(kdhKararF);
					boolean basvuruKararFAcceptMi = "Policy Accept".equals(basvuruKararF) || "Accept".equals(basvuruKararF);
					boolean basvuruKararFReferMi = "Decline Refer".equals(basvuruKararF) || "Accept Refer".equals(basvuruKararF) || "Refer".equals(basvuruKararF);
					boolean kdhKararFReferMi = "Decline Refer".equals(kdhKararF) || "Accept Refer".equals(kdhKararF) || "Refer".equals(kdhKararF);
					
					//Yorumla
					if ((basvuruKararFRedMi && !kdhBasvuruMu) || (basvuruKararFRedMi && kdhBasvuruMu && kdhKararFRedMi)) {
						//Frauddan Red mi
						if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN"))) {
							oMap.put("DURUM", "RED");
							oMap.put("DEVAM", "H");
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
						}
						//Iade mi
						else if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) {
							oMap.put("DURUM", "BASVURU");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("DEVAM", "E");
						}
						//Fraud mi, NBSM SMFraudStrategyFraudQueueYN Y gelmemesi gerekiyor, donerse bi bakalim.
						else {
							if(CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
								oMap.put("DURUM", "RED");
							}
							else {
								oMap.put("DURUM", "FRAUD");
							}
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("DEVAM", "H");
						}
					}
					else {
						if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "BASVURU");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							oMap.put("ONAY_KART_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeFinalLimit"));
							oMap.put("ONAY_LKS_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeLKSLimit"));
							oMap.put("ONAY_EKSPRES_LIMIT", BigDecimal.ZERO);
							oMap.put("NAKIT_LIMIT_ORANI", b2Map.getBigDecimal("StrategyLimitMergeCashLimitPerc"));
							//oMap.put("ONAY_NAKIT_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeCashLimitPerc").subtract(b2Map.getBigDecimal("StrategyLimitMergeFinalLimit")));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("DEVAM", "E");
						}
						else {
							oMap.put("ONAY_KART_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeFinalLimit"));
							oMap.put("ONAY_LKS_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeLKSLimit"));
							oMap.put("ONAY_EKSPRES_LIMIT", BigDecimal.ZERO);
							oMap.put("NAKIT_LIMIT_ORANI", b2Map.getBigDecimal("StrategyLimitMergeCashLimitPerc"));
							//oMap.put("ONAY_NAKIT_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeCashLimitPerc").subtract(b2Map.getBigDecimal("StrategyLimitMergeFinalLimit")));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq")
									+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode")
									+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq")
									+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq")
							);
							oMap.put("DEVAM", "E");
							
							if ("Y".equals(oMap.getString("EVTEL_SORGU_GEREKLI")) || "Y".equals(oMap.getString("ISTEL_SORGU_GEREKLI")) || "Y".equals(oMap.getString("CEPTEL_SORGU_GEREKLI"))) {
								GMMap i2Map = new GMMap();
								i2Map.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
								i2Map.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
								i2Map.put("KIM_ICIN", "M");
								i2Map.put("EVTEL_SORGU_GEREKLI", oMap.getString("EVTEL_SORGU_GEREKLI"));
								i2Map.put("ISTEL_SORGU_GEREKLI", oMap.getString("ISTEL_SORGU_GEREKLI"));
								i2Map.put("CEPTEL_SORGU_GEREKLI", oMap.getString("CEPTEL_SORGU_GEREKLI"));
								GMServiceExecuter.executeNT("BNSPR_NBSM_KK_UNKNOWN_NUMBER_QUERY", i2Map);
							}

							if ("N".equals(b2Map.getString("FinalStrategyAppVerAppChReq"))
									&& "Not Required".equals(b2Map.getString("FinalStrategyEmptVerReqCode"))
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN"))
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudChReq"))
									&& "N".equals(b2Map.getString("FinalStrategyWebChReq"))
							) {
								if (basvuruKararFReferMi || kdhKararFReferMi) {
									oMap.put("DURUM", "TAHSIS");
								}
								else if (basvuruKararFRedMi) {
									oMap.put("DURUM", "RED");
									oMap.put("DEVAM", "H");
									oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
								}
								else if (basvuruKararFAcceptMi) {
									if ("No Fraud".equals(fraudKararF) || "High Fraud".equals(fraudKararF)) {
										if (CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
											if ("3".equals(b2Map.getString("BASVURU_TIPI"))) {
												oMap.put("DURUM", "BASIM");
											} else {
												if ("BASIM".equals(iMap.getString("DURUM_KOD"))) {
													GMMap sorguMap = new GMMap();
													sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
													sorguMap.putAll(GMServiceExecuter.execute("BNSPR_HUNTER_IS_APP_PROCESSED", sorguMap));
													if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("ISLENDI_MI"))) {
														oMap.put("DURUM", "BASIM");
													} else {
														oMap.put("DURUM", "HUNTER");
													}
												} else {
													oMap.put("DURUM", "HUNTER");
												}
											}
										}
										else {
											oMap.put("DURUM", "BASIM");
										}
									}
									else {
										oMap.put("DURUM", "TAHSIS");
									}
								}
								else {
									oMap.put("DURUM", "TAHSIS");
								}
							}
							else if ("N".equals(b2Map.getString("FinalStrategyAppVerAppChReq"))
									&& "Not Required".equals(b2Map.getString("FinalStrategyEmptVerReqCode"))
									&& "Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN"))
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudChReq"))
									&& "N".equals(b2Map.getString("FinalStrategyWebChReq"))
							) {
								if (basvuruKararFReferMi || kdhKararFReferMi) {
									oMap.put("DURUM", "TAHSIS");
								}
								else if (basvuruKararFRedMi) {
									oMap.put("DURUM", "RED");
									oMap.put("DEVAM", "H");
									oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
								}	
								else {	
									if ("3".equals(b2Map.getString("BASVURU_TIPI"))) {
										oMap.put("DURUM", "BASIM");
									} else {
										if (CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
											if ("BASIM".equals(iMap.getString("DURUM_KOD"))) {
												GMMap sorguMap = new GMMap();
												sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
												sorguMap.putAll(GMServiceExecuter.execute("BNSPR_HUNTER_IS_APP_PROCESSED", sorguMap));
												if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("ISLENDI_MI"))) {
													oMap.put("DURUM", "BASIM");
												} else {
													oMap.put("DURUM", "HUNTER");
												}
											} else {
												oMap.put("DURUM", "HUNTER");
											}
											
											oMap.put("DURUM", "HUNTER");
										} else {
											oMap.put("DURUM", "FRAUD");
										}
									}
								}
							}
							else if (("Y".equals(b2Map.getString("FinalStrategyAppVerAppChReq"))
											|| "Home".equals(b2Map.getString("FinalStrategyEmptVerReqCode"))
											|| "Work".equals(b2Map.getString("FinalStrategyEmptVerReqCode"))
											|| "Web".equals(b2Map.getString("FinalStrategyEmptVerReqCode"))
											|| "Y".equals(b2Map.getString("SMFraudStrategyFraudChReq"))
									|| "Y".equals(b2Map.getString("FinalStrategyWebChReq"))
									)
							) {
								// dogrulama ekranina gonderilir, sm final 2 call yapilacak
								oMap.put("DURUM", "DOGRULAMA");
								oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq")
										+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode")
										+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq")
										+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq")
								);
							}
							else {
								iMap.put("HATA_NO", new BigDecimal(1499));
								return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
							}
						}
					}
				}
				iMap.put("LKS_YAPILDI", "E");
			}
			else {
				oMap.put("DURUM", "LKS_JOB_1");
				
				if (!"LKS_JOB_1".equals(iMap.getString("DURUM_KOD"))) {//Jobdan gelmiyorsa
					tarihceMap.clear();
					if ("BASIM".equals(iMap.getString("DURUM_KOD", "ON_BASVURU"))) {
						tarihceMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						tarihceMap.put("TRX_NO", iMap.get("UST_ISLEM_TRX_NO"));
						tarihceMap.put("YENI_DURUM_KODU", "LKS_JOB_1");
						tarihceMap.put("ISLEM_SONRASI_DURUM_KODU", iMap.get("DURUM_KOD"));
						GMServiceExecuter.execute("BNSPR_KK_TARIHCE_GUNCELLE", tarihceMap);
					} else {
						tarihceMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						tarihceMap.put("ISLEM_KODU", "BASVURU");
						tarihceMap.put("YENI_KAYIT_MI", "E");
						tarihceMap.put("DURUM_KODU", iMap.getString("DURUM_KOD", "ON_BASVURU"));//Ekrandan �nce buna set ediliyor.
						tarihceMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
						tarihceMap.put("ISLEM_SONRASI_DURUM_KODU", "LKS_JOB_1");
						GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", tarihceMap);
					}
				}
				
				iMap.put("MESSAGE_NO", new BigDecimal(2998));
				oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				oMap.put("DEVAM", "E");
			}

			updateNbsmSorguSonuc(iMap, oMap);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3871_FINAL_SORGULAR")
	public static GMMap finalSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			iMap.put("SORGU_SEVIYESI", "R");
			iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
//			durumKontrol(iMap);
			// onceki nbsm datalari
			
			GMServiceExecuter.execute("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap);
			
			GMMap bMap = new GMMap();
			iMap.putAll(getPrevNbsmData(iMap));
			bMap.putAll(brmDecisionCall(iMap));
			// sonuca gore red, fraud var, fraud yok, onay
			oMap.put("CallId", bMap.getBigDecimal("CallId"));
			oMap.put("DEVAM", "E");

			oMap.put("ONAY_KART_LIMIT", bMap.getBigDecimal("StrategyLimitMergeFinalLimit"));
			oMap.put("ONAY_KDH_LIMIT", bMap.getBigDecimal("StrategyLimitMergeODLimit"));
			oMap.put("ONAY_LKS_LIMIT", bMap.getBigDecimal("StrategyLimitMergeLKSLimit"));
			oMap.put("ONAY_EKSPRES_LIMIT", BigDecimal.ZERO);
			oMap.put("NAKIT_LIMIT_ORANI", bMap.getBigDecimal("StrategyLimitMergeCashLimitPerc"));
			//oMap.put("ONAY_NAKIT_LIMIT", bMap.getBigDecimal("StrategyLimitMergeCashLimitPerc").subtract(bMap.getBigDecimal("StrategyLimitMergeFinalLimit")));
			oMap.put("NBSM_KARAR_KOD", bMap.getString("FinalDecisionMergeDecCategory"));
			oMap.put("NBSM_KDH_KARAR_KOD", bMap.getString("FinalDecisionMergeODDecisionCategory"));
			oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
			oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));
			oMap.put("ADRES_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionAddressDocumentsRequired"));
			oMap.put("GELIR_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionIncomeDocumentsRequired"));
			oMap.put("GMENKUL_GELIR_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionREMADocumentsRequired"));
			oMap.put("ES_GELIR_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionSpouseDocumentRequired"));
			oMap.put("MUSTERI_BLOKESI_VAR", bMap.getString("MUSTERI_BLOKESI_VAR"));
			oMap.put("EVTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppHomChReq"));
			oMap.put("ISTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppWorkChReq"));
			oMap.put("CEPTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppGSMChReq"));
			oMap.put("MAC_BILETI_LIMITI_MI", bMap.getString("StrategyLimitMergeMacBiletiLimitF"));
			oMap.put("MAC_BILETI_MUST_GRUP", bMap.getString("StrategyLimitMergeMacBiletiMusteriGrubu"));
			
			//R call kararlarini al
			String basvuruKararR = bMap.getString("FinalDecisionMergeDecCategory");
			String kdhKararR = bMap.getString("FinalDecisionODMergeDecCatgry");
			String fraudKararR = bMap.getString("SMFraudStrategyFraudLevel");
			
			boolean kdhBasvuruMu = CreditCardServicesUtil.YES.equals(bMap.getString("KDH_ISTIYOR_MU"));
			boolean basvuruKararRRedMi = "Policy Decline".equals(basvuruKararR) || "Decline".equals(basvuruKararR);
			boolean kdhKararRRedMi = "Policy Decline".equals(kdhKararR) || "Decline".equals(kdhKararR);
			boolean basvuruKararRAcceptMi = "Policy Accept".equals(basvuruKararR) || "Accept".equals(basvuruKararR);
			boolean basvuruKararRReferMi = "Decline Refer".equals(basvuruKararR) || "Accept Refer".equals(basvuruKararR) || "Refer".equals(basvuruKararR);
			boolean kdhKararRReferMi = "Decline Refer".equals(kdhKararR) || "Accept Refer".equals(kdhKararR) || "Refer".equals(kdhKararR);
			
			//Yorumla
			if ((basvuruKararRRedMi && !kdhBasvuruMu) || (basvuruKararRRedMi && kdhBasvuruMu && kdhKararRRedMi)) {
				//Frauddan Red mi
				if ("N".equals(bMap.getString("SMFraudStrategyFraudQueueYN"))) {
					oMap.put("DURUM", "RED");
					oMap.put("DEVAM", "H");
					oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
				}
				//Iade mi
				else if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) {
					oMap.put("DURUM", "BASVURU");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
					oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
					oMap.put("DEVAM", "E");
				}
				//Fraud mi, NBSM SMFraudStrategyFraudQueueYN Y gelmemesi gerekiyor, donerse bi bakalim.
				else {
					if(CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
						oMap.put("DURUM", "RED");
					}
					else {
						oMap.put("DURUM", "FRAUD");
					}
					oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
					oMap.put("DEVAM", "H");
				}
			}
			else {
				oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));

				if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) { // Iade gerekli
					oMap.put("DURUM", "BASVURU");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
				}
				else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN"))) {
					if (basvuruKararRReferMi || kdhKararRReferMi) {
						oMap.put("DURUM", "TAHSIS");
					}
					else if (basvuruKararRRedMi) {
						oMap.put("DURUM", "RED");
						oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
					}	
					else {		
						if ("3".equals(bMap.getString("BASVURU_TIPI"))) {
							oMap.put("DURUM", "BASIM");
						} else {
							if(CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
								oMap.put("DURUM", "HUNTER");
							}	
							else {
								oMap.put("DURUM", "FRAUD");
							}	
						}
					}
				}
				else {
					if (basvuruKararRReferMi || kdhKararRReferMi) {
						oMap.put("DURUM", "TAHSIS");
					}
					else if (basvuruKararRRedMi) {
						oMap.put("DURUM", "RED");
						oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
					}
					else if (basvuruKararRAcceptMi) {
						if ("No Fraud".equals(fraudKararR) || "High Fraud".equals(fraudKararR)) {
							if (CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
								if ("3".equals(bMap.getString("BASVURU_TIPI"))) {
									oMap.put("DURUM", "BASIM");
								} else {
									oMap.put("DURUM", "HUNTER");
								}
							}	
							else {
								oMap.put("DURUM", "BASIM");
							}
						}
						else {
							oMap.put("DURUM", "TAHSIS");
						}
					}
					else {
						oMap.put("DURUM", "TAHSIS");
					}
				}
			}

			updateNbsmSorguSonuc(iMap, oMap);
			
			if("HUNTER".equals(oMap.getString("DURUM"))){
				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				sorguMap.put("BASVURU_TIPI", "KK");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_HUNTER_SEND_APPL_INFO", sorguMap));
				if("ACCEPT".equals(sorguMap.getString("HUNTER_RESULT")))
				{
					GMMap tarihceMap = new GMMap();
					tarihceMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					tarihceMap.put("ISLEM_NO", iMap.get("TRX_NO"));
					tarihceMap.put("DURUM_KOD", "BASIM");
					tarihceMap.put("ISLEM_ACIKLAMA", sorguMap.getString("HUNTER_RESULT"));
					tarihceMap.put("TARIHCE_AKSIYON", "E");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", tarihceMap);
					
					tarihceMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
					basvuruTxDurumGuncelle(tarihceMap);
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
