package tr.com.aktifbank.bnspr.creditcard.util;


public interface Constants {
	public static final int CONST_NUMERIC_ZERO = 0;
	public static final int CONST_NUMERIC_ONE = 1;
	public static final int DRKD_REFUSED_RECORD_LINE_LENGHT = 47;
	public static final String DEGER = "DEGER";
	public static final String KOD = "KOD";
	public static final String LINE = "LINE";
	public static final String FILE_LINE = "FILE_LINE";
	public static final String FILE_LIST = "FILE_LIST";
	public static final String FILE_NAME = "FILE_NAME";
	public static final String BANKA_TARIH = "BANKA_TARIH";
	public static final String PROCESS_ID = "PROCESS_ID";
	public static final String REDDEDILEN_KAYIT_SAYISI = "REDDEDILEN KAYIT SAYISI";
	
	public static final String PORTFOY_HAVUZ_KONTAK_MUSTERI = "0444.BRY.99.00";
	public static final String KAZANIM_KANALI_SANALKART = "SANALKART";
	public static final String KAZANIM_KANALI_KART = "KART";

	//pp card ba�vuru source lar�
	public static final String SOURCE_YIM = "YIM";
	public static final String SOURCE_UPT = "UPT";
	public static final String SOURCE_EGOMBL = "EGOMBL";
	public static final String SOURCE_EKENT = "EKENT";
	public static final String SOURCE_NKOLAYAPP = "MBLNKOLAY";
	public static final String SOURCE_MRSMBL = "MRSMBL";
	public static final String SOURCE_DOLMUS = "DOLMUS";



    public static enum SOURCE_KAZANIM_URUNU{
		
    	MBLNKOLAY(KAZANIM_KANALI_SANALKART, PORTFOY_HAVUZ_KONTAK_MUSTERI),
    	MRSMBL(KAZANIM_KANALI_SANALKART, PORTFOY_HAVUZ_KONTAK_MUSTERI),
    	EGOMBL(KAZANIM_KANALI_SANALKART, PORTFOY_HAVUZ_KONTAK_MUSTERI),
    	UPT(KAZANIM_KANALI_KART, PORTFOY_HAVUZ_KONTAK_MUSTERI),
		YIM(KAZANIM_KANALI_KART, PORTFOY_HAVUZ_KONTAK_MUSTERI),
		EKENT(KAZANIM_KANALI_KART, PORTFOY_HAVUZ_KONTAK_MUSTERI),
		DOLMUS(KAZANIM_KANALI_SANALKART, PORTFOY_HAVUZ_KONTAK_MUSTERI);

	
        private String urun;
        private String portfoyKod;

        private SOURCE_KAZANIM_URUNU(String urun , String portfoyKod) {
                this.urun = urun;
                this.portfoyKod = portfoyKod;
        }
        
		public String getUrun() {
			return urun;
		}
		
		public String getPortfoyKod(){
			return portfoyKod;
		}
		
		public static SOURCE_KAZANIM_URUNU getBySource(String source){
			for(SOURCE_KAZANIM_URUNU v : SOURCE_KAZANIM_URUNU.values()){
		        if( v.name().equals(source)){
		            return v;
		        }
		      
		    }
			return null;

		}
    }

}
