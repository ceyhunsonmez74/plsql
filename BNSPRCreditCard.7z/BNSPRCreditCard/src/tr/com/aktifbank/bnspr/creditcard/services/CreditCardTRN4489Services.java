package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaDty;
import tr.com.aktifbank.bnspr.dao.SbaMcvFaturaGiderTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.SbaBkmFaturaGiderTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4489Services{
	
	@GraymoundService("BNSPR_TRN4489_GET_CURRENCY")
	public static GMMap getCurrency (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap kurMap = new GMMap();
			GMMap kurMapD = new GMMap();
			kurMap.put("TARIH", iMap.getDate("TARIH"));
			kurMap.put("DOVIZ1", "USD");
			kurMap.put("DOVIZ2", "TRY");
			kurMap.put("TUTAR",1);
			kurMap.put("KUR_TABLO", "N");
			kurMap.put("ALIS_SATIS", "S");
			kurMap.put("KUR_TIP", "1");
			kurMapD = GMServiceExecuter.call("BNSPR_COMMON_DOVIZ_CEVIR", kurMap);
			
			oMap.put("KUR", kurMapD.getBigDecimal("KARSILIK"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4489_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap =new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaMcvFaturaGiderTx gider = new SbaMcvFaturaGiderTx(); 
			gider.setAposEuro(iMap.getBigDecimal("APOS_EURO"));
			gider.setAposSeuro(iMap.getBigDecimal("APOS_SEURO"));
			gider.setAposUsd(iMap.getBigDecimal("APOS_USD"));
			gider.setAtmEuro(iMap.getBigDecimal("ATM_EURO"));
			gider.setAtmSeuro(iMap.getBigDecimal("ATM_SEURO"));
			gider.setAtmUsd(iMap.getBigDecimal("ATM_USD"));
			gider.setCposEuro(iMap.getBigDecimal("CPOS_EURO"));
			gider.setCposSeuro(iMap.getBigDecimal("CPOS_SEURO"));
			gider.setCposUsd(iMap.getBigDecimal("CPOS_USD"));
			gider.setDkEuro(iMap.getBigDecimal("DK_EURO"));
			gider.setDkSeuro(iMap.getBigDecimal("DK_SEURO"));
			gider.setDkUsd(iMap.getBigDecimal("DK_USD"));
			gider.setEurTutar(iMap.getBigDecimal("EUR_TUTAR"));
			gider.setKkEuro(iMap.getBigDecimal("KK_EURO"));
			gider.setKkSeuro(iMap.getBigDecimal("KK_SEURO"));
			gider.setKkUsd(iMap.getBigDecimal("KK_USD"));
			gider.setKur(iMap.getBigDecimal("KUR"));
			gider.setParite(iMap.getBigDecimal("PARITE"));
			gider.setTarih(iMap.getDate("TARIH"));
			gider.setToplamApos(iMap.getBigDecimal("APOS_TTL"));
			gider.setToplamAtm(iMap.getBigDecimal("ATM_TTL"));
			gider.setToplamCpos(iMap.getBigDecimal("CPOS_TTL"));
			gider.setToplamDk(iMap.getBigDecimal("DK_TTL"));
			gider.setToplamKdv(iMap.getBigDecimal("TOPLAM_KDV"));
			gider.setToplamKk(iMap.getBigDecimal("KK_TTL"));
			gider.setToplamStopaj(iMap.getBigDecimal("TOPLAM_STL"));
			gider.setToplamUsd(iMap.getBigDecimal("TOPLAM_TUSD"));
			gider.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gider.setUsdTutar(iMap.getBigDecimal("USD_TUTAR"));
			gider.setMv(iMap.getString("ISLEM_TIPI"));
						
			session.saveOrUpdate(gider);
			session.flush();
			
			iMap.put("TRX_NAME" , "4489");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN4489_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap =new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaMcvFaturaGiderTx stx = (SbaMcvFaturaGiderTx) session.createCriteria(SbaMcvFaturaGiderTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("APOS_EURO",stx.getAposEuro());
			oMap.put("APOS_SEURO",stx.getAposSeuro());
			oMap.put("APOS_USD",stx.getAposUsd());
			oMap.put("ATM_EURO",stx.getAtmEuro());
			oMap.put("ATM_SEURO",stx.getAtmSeuro());
			oMap.put("ATM_USD",stx.getAtmUsd());
			oMap.put("CPOS_EURO",stx.getCposEuro());
			oMap.put("CPOS_USD",stx.getCposUsd());
			oMap.put("CPOS_SEURO",stx.getCposSeuro());
			oMap.put("DK_EURO",stx.getDkEuro());
			oMap.put("DK_SEURO",stx.getDkSeuro());
			oMap.put("DK_USD",stx.getDkUsd());
			oMap.put("EUR_TUTAR",stx.getEurTutar());
			oMap.put("KK_EURO",stx.getKkEuro());
			oMap.put("KK_SEURO",stx.getKkSeuro());
			oMap.put("KK_USD",stx.getKkUsd());
			oMap.put("KUR",stx.getKur());
			oMap.put("PARITE",stx.getParite());
			oMap.put("TARIH",stx.getTarih());
			oMap.put("APOS_TTL",stx.getToplamApos());
			oMap.put("ATM_TTL",stx.getToplamAtm());
			oMap.put("CPOS_TTL",stx.getToplamCpos());
			oMap.put("DK_TTL",stx.getToplamDk());
			oMap.put("TOPLAM_KDV",stx.getToplamKdv());
			oMap.put("KK_TTL",stx.getToplamKk());
			oMap.put("TOPLAM_STL",stx.getToplamStopaj());
			oMap.put("TOPLAM_TUSD",stx.getToplamUsd());
			oMap.put("USD_TUTAR",stx.getUsdTutar());
			oMap.put("ISLEM_TIPI",stx.getMv());
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", batchParamCode);
		String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return batchNo;
	}
	
}
