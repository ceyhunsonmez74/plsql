package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KkBasvuruKararCozmeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3897Services {
	
	/**
	 * Basvuru izleme ekrani acilirken, baslangicta dolmasi gereken alanlari doner.
	 * 
	 * @param iMap
	 * 
	 * @return oMap - DURUM, KART_TIPI_LIST, KANAL_LIST
	 */
	@GraymoundService("BNSPR_QRY3897_MODAL_FILL_INITIAL_VALUES")
	public static GMMap fillInitialValues(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			//Durum veri tamamlama yapilamaz
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'KK_BASVURU_DURUM_KOD'");
			query.append(" AND KEY1 IN ('LKS_JOB_2','RED','IPTAL')");
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "DURUM", true, query.toString());
			
			// Kart tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "KREDI_KART_TIPI", "E"));
			// Kanal Listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3872_KANAL_LIST", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3897_FILL_DURUM_LIST")
	public static GMMap getOnayStatuListYeni(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			//Eski durumlar
			oMap.putAll(CreditCardServicesUtil.getParameterList("ESKI_DURUM", "KK_BASVURU_DURUM_KOD", "E"));
			
			//Durum veri tamamlama yapilamaz
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'KK_BASVURU_DURUM_KOD'");
			query.append(" AND KEY1 IN ('TAHSIS','IPTAL')");
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "YENI_DURUM", true, query.toString());
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Girilen kriterlere gore arama yapip, basvuru listesi doner.
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO, KREDI_KART_TIPI, ADI, IKINCI_ADI,
	 *             SOYADI, DURUM_LIST, BASLANGIC_TAR, BITIS_TAR, IPTAL,KANAL_KODU, BAYI_KODU
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_QRY3897_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruIzlemeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3897.Rc_Qry3897_List_Basvuru(?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("KREDI_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," :
                CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));
			
			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
				
			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}

			if (iMap.getBoolean("IPTAL") == true) {
				stmt.setString(i++, "TRUE");
			} else {
				stmt.setString(i++, "FALSE");
			}
			
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("BAYI_KODU"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
	@GraymoundService("BNSPR_TRN3897_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			KkBasvuruKararCozmeTx kkBasvuruKararCozmeTx = new KkBasvuruKararCozmeTx();
			kkBasvuruKararCozmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kkBasvuruKararCozmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kkBasvuruKararCozmeTx.setEskiDurumKodu(iMap.getString("ESKI_DURUM_KODU"));
			kkBasvuruKararCozmeTx.setYeniDurumKodu(iMap.getString("YENI_DURUM_KODU"));
			kkBasvuruKararCozmeTx.setAciklama(iMap.getString("ACIKLAMA"));
			kkBasvuruKararCozmeTx.setKararGerekce(iMap.getString("GEREKCE"));
			
			session.save(kkBasvuruKararCozmeTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3897");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
