package tr.com.aktifbank.bnspr.creditcard.services;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.axis.encoding.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.jsoup.helper.StringUtil;

import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonGrup;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.gov.nvi.kpsv2.model.TarihModel;

import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public abstract class CardServicesHelper implements TffServicesMessages {

	private static final Logger logger = Logger.getLogger(CardServicesHelper.class);
	protected static Configurator conf = Configurator.createConfiguratorFromProperties ("configuration/aktifbank-int-tff.properties");

	protected static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	
	public static boolean isPromosyonHasValidSource(TffBasvuruPromosyonGrup grup, String source){
		if(BigDecimal.ONE.compareTo(grup.getKanalBatch()) == 0 && "BATCH".equals(source)){
			return true;
		}

		if(BigDecimal.ONE.compareTo(grup.getKanalMobil()) == 0 && "MBL01".equals(source)){
			return true;
		}

		if(BigDecimal.ONE.compareTo(grup.getKanalWeb()) == 0 && ("MTT01".equals(source) || "TABLET".equals(source)|| "SMS".equals(source))){
			return true;
		}



		if(BigDecimal.ONE.compareTo(grup.getKanalGise()) == 0 && "NTS01".equals(source)){
			return true;
		}

		if(BigDecimal.ONE.compareTo(grup.getKanalEpos()) == 0 && "EPOS".equals(source)){
			return true;
		}
		return false;
	}
	public static boolean isPromosyonHasValidKartTipi(TffBasvuruPromosyonGrup grup, String karttipi){
		if(BigDecimal.ONE.compareTo(grup.getTipKk()) == 0 && "KK".equals(karttipi)){
			return true;
		}
		if(BigDecimal.ONE.compareTo(grup.getTipD()) == 0 && "D".equals(karttipi)){
			return true;
		}
		if(BigDecimal.ONE.compareTo(grup.getTipP()) == 0 && "P".equals(karttipi)){
			return true;
		}
		return false;
	}
	public boolean isMemberPhoneValid(String ulke, String alan, String numara,boolean isLocal){

		logger.info("----isMemberPhoneValid - ulke :" + ulke);
		logger.info("----isMemberPhoneValid - alan :" + alan);
		logger.info("----isMemberPhoneValid - numara :" + numara);
		logger.info("----isMemberPhoneValid - isLocal :" + isLocal);
		if("".equals(ulke) || "".equals(alan) || "".equals(numara) || ulke == null || alan == null || numara == null){

			logger.info("----isMemberPhoneValid - result :" + false);
			return false;

		}else{
			boolean res =  isPhoneNumberValidInternational(ulke,alan,numara);
			logger.info("----isMemberPhoneValid - result :" + res);
			return res;
		}

	}
	/**
	 * Web servisleri kullanan kanal�n ge�erli olup olmad���n� kontrol eder
	 * TFF_WEBSERVIS_PARAM da KANAL_KOD ile yeni kanallar tan�mlanmal�d�r
	 * Kapat�lmak istenen kanal�n kayd� silinerek servislere eri�imi engellenebilir
	 * 
	 * @param iMap
	 * SOURCE
	 * @return boolean
	 */
	public static  boolean isSourceValid(GMMap iMap){

		boolean result = false;
		String source = iMap.getString("SOURCE");
		if(!StringUtils.isBlank(source)){
			String func = "{? = call pkg_trn3801.is_source_valid(?)}";
			try {
				String res =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING,BnsprType.STRING,source));
				if("E".equals(res)){
					result = true;
				}
			} catch (SQLException e) {
				result = false;
			}
		}
		return result;
	}

	public static  boolean isUyrukValid(GMMap iMap){

		boolean result = false;
		String uyruk = iMap.getString("UYRUK");
		if(!StringUtils.isBlank(uyruk)){
			String func = "{? = call pkg_trn3801.is_uyruk_valid(?)}";
			try {
				String res =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING,BnsprType.STRING,uyruk));
				if("E".equals(res)){
					result = true;
				}
			} catch (SQLException e) {
				result = false;
			}
		}
		return result;
	}

	public static  BigDecimal getKuryeBedeli(String kuryeTipi){

		BigDecimal res;
		String func = "{? = call pkg_tff_basvuru.Get_Tff_Teslimat_Ucreti(?)}";
		try {
			res =  (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER,BnsprType.STRING,kuryeTipi);

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		return res;
	}
	public static  boolean isKuryeTipiValid(GMMap iMap){

		boolean result = false;
		String tip = iMap.getString("KURYE_TIPI");
		if(!StringUtils.isBlank(tip)){
			String func = "{? = call pkg_trn3801.is_kurye_tipi_valid(?)}";
			try {
				String res =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING,BnsprType.STRING,tip));
				if("E".equals(res)){
					result = true;
				}
			} catch (SQLException e) {
				result = false;
			}
		}
		return result;
	}
	protected static String getOrtamAdi(){
		GMMap xMap = new GMMap();
		return GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", xMap).getString("DATABASE_ADI");
	}
	public static void sendMail(String mailFrom, String mailToParametre,String subject, String mailBody) {
		try {
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", mailFrom);
			GMMap xMap = new GMMap();
			xMap.put("PARAMETRE", mailToParametre);
			servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
			servisMap.put("MAIL_SUBJECT", subject + " --- " + getOrtamAdi());
			if(mailBody.length() > 3000){
				servisMap.put("MAIL_BODY_CLOB", mailBody);
			}else{
				servisMap.put("MAIL_BODY", mailBody);
			}
			servisMap.put("IS_BODY_HTML", "H");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
		}
		catch (Exception e) {
			logger.error(e);
		}


	}
	public static String maskCardNumber(String cardNumber) {

		return cardNumber.replaceAll("(\\d{1,4})(\\d{1,8})(\\d{1,4})", "**** **** **** $3");
	}
	public static BigDecimal searchCustomer(String pasaportNo){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal musteri_no = new BigDecimal(0);
		try {
			conn = DALUtil.getGMConnection();
			
				stmt = conn.prepareStatement("select banka_musteri_no from tff_uyeler  where pasaport_no=?");
				stmt.setString(1, pasaportNo);
				
			rSet = stmt.executeQuery();

			
			if ( rSet.next() ){
				musteri_no = rSet.getBigDecimal(1);
			}
		
			

			return musteri_no;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static BigDecimal searchCustomer(String uyruk, String tckn,String pasaportNo){
		GMMap searchMap=new GMMap();
		searchMap.put("COUNTRY_CODE", uyruk);
		if (uyruk.equals("TR")) {
			searchMap.put("TCKN", tckn);
		} else {
			searchMap.put("PASSPORT_NO", pasaportNo);
		}
		return GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY",searchMap).getBigDecimal("CUSTOMER_NO");
	}
	public static <T> T nvl(T a, T b) {
		if (a instanceof String) return StringUtils.isBlank((String) a) ? b : a;
		return a == null ? b : a;
	}

	public static boolean islemTamamlanmisMi(BigDecimal trxno){
		CallableStatement stmt = null;
		Connection conn = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TX.Islem_bitmis_mi(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, trxno);
			stmt.execute();
			int tamamlanmismi = stmt.getInt(1); // 0 tamamlandi, 1 tamamlanmadi anlamina geliyor
			if (tamamlanmismi == 1)
				return true;
			return false;
		}
		catch (Exception ex){
			throw ExceptionHandler.convertException(ex);
		}
		finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	public static String islemDurum(BigDecimal trxno){
		CallableStatement stmt = null;
		Connection conn = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TX.islem_durum(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, trxno);
			stmt.execute();
			String durum = stmt.getString(1); // R: red P:Procesed

			return durum;
		}
		catch (Exception ex){
			throw ExceptionHandler.convertException(ex);
		}
		finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	protected static boolean telAlanKodDogrumu(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			if ("E".equals(iMap.getString("GSM_MI"))){
				stmt = conn.prepareStatement("select kod from gnl_tel_alan_kod_pr where GSM='E'AND KOD = ?");
				stmt.setString(1, iMap.getString("CEP_ALAN_KOD"));
			}
			else{
				stmt = conn.prepareStatement("select kod from gnl_tel_alan_kod_pr where GSM='H' AND  il_kod = ? and kod=?");
				stmt.setString(1, iMap.getString("IL_KODU"));
				stmt.setString(2, iMap.getString("TEL_ALAN"));
			}

			rSet = stmt.executeQuery();

			if ( rSet.next() ){
				return true;
			}
			else{
				return false;
			}



		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	public static boolean isEmailValid(String email){

		
		String validator = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		if(email.matches(validator)){
			return true;
		}
		return false;
	}

	public static boolean isPhoneNumberValid(String phoneNumber){

		if(phoneNumber != null && phoneNumber.length() == 7 && !phoneNumber.matches("(\\d)\\1{6}"))
			return true;

		return false;
	}

	public static boolean isPhoneNumberValidInternational(String countryCode, String areaCode,String phoneNumber){

		if( !StringUtil.isBlank(phoneNumber)  && !StringUtil.isBlank(countryCode) && !StringUtil.isBlank(areaCode))
			if(phoneNumber.length() == 7 && !phoneNumber.matches("(\\d)\\1{6}") && "90".equals(countryCode)){
				return true;
			}else if(phoneNumber.length() <= 10 && !phoneNumber.matches("(\\d)\\1{9}") && !"90".equals(countryCode) ){
				return true;
			}


		return false;
	}
	/**
	 * Telefon numaras�n� kontrol eder, gecerli bir telefon degilse hata kodunu doner
	 * return 
	 * */
	public static String validatePhoneNumber(String phoneType, String countryCode, String areaCode,String phoneNumber){
		String returnCode ="2";
		String func = "{? = call pkg_trn3801.CHECK_PHONE(?,?,?,?)}";
		try {
			String res =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING,BnsprType.STRING,phoneType,BnsprType.STRING,countryCode,BnsprType.STRING,areaCode,BnsprType.STRING,phoneNumber));
			if("2".equals(res)){
				return returnCode;
			}else if("C".equals(phoneType) && "0".equals(res)){
				returnCode = "0225";
			}else if("C".equals(phoneType) && "3".equals(res)){
				returnCode = "0224";
			}else if("C".equals(phoneType) && "4".equals(res)){
				returnCode = "0223";
			}else if("E".equals(phoneType) && "0".equals(res)){
				returnCode = "0231";
			}else if("E".equals(phoneType) && "3".equals(res)){
				returnCode = "0230";
			}else if("E".equals(phoneType) && "4".equals(res)){
				returnCode = "0229";
			}else if("I".equals(phoneType) && "0".equals(res)){
				returnCode = "0228";
			}else if("I".equals(phoneType) && "3".equals(res)){
				returnCode = "0227";
			}else if("I".equals(phoneType) && "4".equals(res)){
				returnCode = "0226";
			}
		} catch (SQLException e) {
			returnCode = "0115";
		}
		return returnCode;
	}

	@SuppressWarnings("unchecked")
	protected static GMMap findUye(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		List<TffUyeler> list = null;
		if ( "TR".equals(iMap.getString("UYRUK")) ){
			list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn", iMap.getBigDecimal("TCKN"))).list();
		}
		else{
			list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaportNo", iMap.getString("PASAPORT_NO"))).list();
		}
		if(list!=null && list.size()>0){
			oMap.put("UYE_NO", list.get(0).getUyeNo());
		}
		return oMap;
	}
	protected static TffUyeler findUye(String uyruk, BigDecimal tckn,  String pasaportNo){
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		List<?> list = null;
		if ( "TR".equals(uyruk) ){
			list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn",tckn)).list();
		}
		else if (uyruk==null || StringUtils.isEmpty(uyruk)){
			list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaportNo", pasaportNo)).list();
		}
		else
		{
		    list = session.createCriteria(TffUyeler.class).add(Restrictions.and(Restrictions.eq("pasaportNo", pasaportNo) , Restrictions.eq("uyruk",uyruk)) ).list();
		}
		if(list != null && list.size() == 1){
			return ((TffUyeler) list.get(0));
		}else{
			logger.error("---------- findUye : uye bulunamadi" + uyruk + "  tckn:" +tckn +" pasaport:"+ pasaportNo);

		}
		return null;
	}
	protected static TffUyeler findUye(BigDecimal uyeNo){
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, uyeNo);

		return tffUyeler;
	}
	@SuppressWarnings("unchecked")
	protected static GMMap findUyeWithTCKN(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn", iMap.getBigDecimal("TCKN"))).list();
		if(list!=null && list.size()>0){
			oMap.put("UYE_NO", list.get(0).getUyeNo());
		}

		return oMap;
	}

	protected static byte[] decode64ByteArray(String textToDecode) throws Exception {
		byte[] decodedDocByteArray = null;
		decodedDocByteArray = Base64.decode(textToDecode);
		return decodedDocByteArray;
	}
	public static String getFotoExtension(String fileName){
		if(!"".equals(fileName) && fileName != null){
			String[] res = fileName.split("\\.");
			if(res.length>1)
				return res[res.length-1];
		}

		return null;
	}
	public static boolean createApprovedFolder(File path){


		String isWindows = "H";
		Runtime runtime =Runtime.getRuntime ();
		String approved = String.format("%s/%s", path.getAbsolutePath(),conf.getProperty("gise_foto_folder"));

		try {
			if ( isWindows.equals("E") )
				path.mkdirs();
			else{
				String command ="mkdir -p "+approved;
				String[] args = {"/bin/sh", "-c",command};
				Process p =runtime.exec ( args );
				p.waitFor();
			}
			return true;

		}
		catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF FOTO GUNCELLE HATA";
			String mailBody = "hata alan kimlik bilgileri:";
			mailBody += "<br>" + "FOTO SOURCE:" + path.getAbsolutePath();
			mailBody += "<br>" + "HATA :" + e.getMessage();
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			mailBody += "<br>" + "TRACE :" + sw.toString();

			sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
			e.printStackTrace();
			logger.error("Resim kopyalamada hata olustu");
		}

		return false;
	}
	public static boolean copyFile(File source, File target){

		try {
			FileUtils.copyFile(source, target);
			return true;
		} catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF FOTO GUNCELLE HATA";
			String mailBody = "hata alan kimlik bilgileri:";
			mailBody += "<br>" + "FOTO SOURCE:" + source.getAbsolutePath();
			mailBody += "<br>" + "FOTO TARGET:" + target.getAbsolutePath();
			mailBody += "<br>" + "HATA :" + e.getMessage();
			mailBody += "<br>" + "TRACE :" + getTraceAsString(e);

			sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
			e.printStackTrace();
			logger.error("Resim kopyalamada hata olustu");
		}



		return false;

	}

	public static boolean deleteFile(File source){

		try {
			FileUtils.forceDelete(source);
			return true;
		} catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF FOTO GUNCELLE HATA";
			String mailBody = "Silme isleminde hata :";
			mailBody += "<br>" + "FOTO SOURCE:" + source.getAbsolutePath();
			mailBody += "<br>" + "HATA :" + e.getMessage();
			mailBody += "<br>" + "TRACE :" + getTraceAsString(e);

			sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
			e.printStackTrace();
			logger.error("Resim kopyalamada hata olustu");
		}



		return false;

	}
	protected static String encode64ByteArray(byte[] decodedDocByteArray) throws Exception{
		return  Base64.encode(decodedDocByteArray);
	}



	
	/*
	     procedure tff_adres_ekle_alan_kontrol(ps_adres_tipi in varchar2,
	      								pn_il_kod        in varchar2,
                                        pn_ilce_kod      in varchar2,
                                        ps_response      out number,
                                        ps_response_data out varchar2) 
	 * */
	protected static GMMap tffAdresEkleAlanKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.tff_adres_ekle_alan_kontrol (?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[6];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ADRES_TIPI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("IL_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ILCE_KOD");

			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", ADRES_HATALI);
		}
		return oMap;
	}
	/*
  procedure tff_basvuru_yap_alan_kontrol(ps_urun_kodu       in varchar2,
                                         ps_urun_sahip_kodu varchar2,
                                         ps_KART_TIPI       in varchar2,
                                         ps_calisma_sekli in varchar2,
                                         ps_meslek_kod in varchar2,
                                         ps_egitim_kod    in varchar2,
                                         ps_response      out number,
                                         ps_response_data out varchar2)
	 * */
	protected static GMMap tffBasvuruYapAlanKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.tff_basvuru_yap_alan_kontrol (?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[12];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("URUN_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("URUN_SAHIP_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KART_TIPI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CALISMA_SEKLI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("MESLEK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("OGRENIM_DURUMU");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", FIZIKI_BASVURU_ALAN_KONTROL_GENEL_HATA);
		}
		return oMap;
	}

	/*
	 *   procedure aktif_kart_tipi_basvurulari(pn_uye_no            in number,
                                        pn_kk_basvuru_sayisi out number,
                                        pn_d_basvuru_sayisi  out number,
                                        pn_p_basvuru_sayisi  out number)
	 * */

	protected static GMMap tffAktifKartBasvurulari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.aktif_kart_tipi_basvurulari (?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("UYE_NO");

			i = 0;
			Object[] outputValues = new Object[12];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "KK_BASVURU_SAYISI";

			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "D_BASVURU_SAYISI";

			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "P_BASVURU_SAYISI";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "KK_BASVURU_NO";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "D_BASVURU_NO";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "P_BASVURU_NO";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", AKTIF_KART_BASVURUSU_KONTROL_HATASI);
		}
		return oMap;
	}


	public static String errorMessageOlustur(String errorCode,String hataKoduVarMi, Object...parameters) {
		HashMap<String, Object> myMap = new HashMap<String, Object>();
		myMap.put("MESSAGE_NO", errorCode);
		myMap.put("HATA_KODU_VAR", StringUtils.isNotEmpty(hataKoduVarMi)?hataKoduVarMi:"H");
		if (parameters != null && parameters.length > 0) {
			int index = 0;
			while (index < parameters.length) {
				myMap.put("P" + (index+1), parameters[index]);
				index++;
			}
		}
		String errorMessage = GMServiceExecuter.execute("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR", myMap).get("ERROR_MESSAGE").toString();
		return  errorMessage;

	}

	/*
	    procedure tff_uye_ekle_alan_kontrol(ps_uyruk_kod in varchar2,
                                          ps_ulke_kod      in varchar2,
                                      ps_alan_kod      in varchar2,
                                      ps_telno         in varchar2,
                                      ps_email         in varchar2,
                                      ps_response      out number,
                                      ps_response_data out varchar2)
	 * */
	protected static GMMap tffUyeEkleAlanKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			if(!isSourceValid(iMap)){
				oMap.put("RESPONSE", RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			String procStr = "{call BNSPR.PKG_TRN3801.tff_uye_ekle_alan_kontrol (?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[10];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("UYRUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_ULKE_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_ALAN_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_NUMARA");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("EMAIL");

			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			if(StringUtils.isNotBlank(iMap.getString("EMAIL"))){
				if(!isEmailValid(iMap.getString("EMAIL"))){
					oMap.put("RESPONSE",  RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", EMAIL_HATALI_HATASI);
				}
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", FIZIKI_BASVURU_ALAN_KONTROL_GENEL_HATA);
		}
		return oMap;
	}


	/*
	 *   procedure tff_fiz_basvuru_yap_alan_ktr(ps_uyruk_kod       in varchar2,
                                         ps_urun_kodu       in varchar2,
                                         ps_urun_sahip_kodu varchar2,
                                         ps_KART_TIPI       in varchar2,
                                         pn_il_kod          in varchar2,
                                         pn_ilce_kod        in varchar2,
                                         ps_ulke_kod        in varchar2,
                                         ps_alan_kod        in varchar2,
                                         ps_telno           in varchar2,
                                         ps_calisma_sekli   in varchar2,
                                         ps_email           in varchar2,
                                         ps_response        out number,
                                         ps_response_data   out varchar2)
	 * */
	protected static GMMap tffFizikiBasvuruAlanKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String procStr = "{call BNSPR.PKG_TRN3801.tff_fiz_basvuru_yap_alan_ktr (?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[22];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("UYRUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("URUN_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("URUN_SAHIP_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KART_TIPI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("UAVT_IL_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("UAVT_ILCE_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_ULKE_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_ALAN_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_NUMARA");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CALISMA_SEKLI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("EMAIL");

			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", FIZIKI_BASVURU_ALAN_KONTROL_GENEL_HATA);
		}
		return oMap;
	}
	public static  String getTraceAsString(Exception e){
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

	public static String getPhotoForBatchApplication(String tckn){

		String path = "";
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			path =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_TOPLU_BASVURU", BnsprType.STRING, "FOTO", BnsprType.STRING, "FOTO_PATH"));


		}
		catch (Exception e) {
			path = "";
		}
		if(StringUtils.isNotBlank(path)){
			String folderPath= path +File.separator + "TOPLU_BASVURU"+ File.separator+ tckn+".jpg";
			byte[] imageInByte;
			File file = new File(folderPath);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			try {
				BufferedImage originalImage = ImageIO.read(file);

				// convert BufferedImage to byte array

				ImageIO.write(originalImage, "jpg", baos);
				baos.flush();
				imageInByte = baos.toByteArray();
				return encode64ByteArray(imageInByte);
			} catch(Exception e){
				e.printStackTrace();
			}finally{
				try {
					baos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return path;
	}

	public static String padLeft(Object str, Integer len) {
		return String.format("%0" + len + "d", Integer.parseInt(str + ""));
	}
	
	
	public static String padStringLeft(String str, Integer len) {
		return StringUtils.leftPad(str, len, "0");
	}


	public static String convertTarihModel(TarihModel tarih) {
		if (tarih == null || tarih.getAy()==null || tarih.getGun()==null || tarih.getYil()==null)
			return null;
		return tarih.getYil() + padLeft(tarih.getAy(), 2) + padLeft(tarih.getGun(), 2);
	}

	public static boolean isWindowsReservedFilename(String str) {
		//"CON,PRN,AUX,NUL"
		String pathExp = conf.getProperty("tff-foto-path-exp");
		return pathExp.contains(str);
	}

	public static boolean isUnder18(String dt) throws Exception {

		logger.info("------------------ isUnder18 WEB_DOGUM_TARIHI" + dt);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);
		Date wdt = sdf.parse(dt);
		Calendar dob = Calendar.getInstance();
		dob.setTime(wdt);
		Calendar today = Calendar.getInstance();
		int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
		if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
			age--;
		} else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
			age--;
		}

		if (age < 18) {
			return true;
		}


		return false;
	}
	public static boolean isUnder18(Date wdt) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);
		Calendar dob = Calendar.getInstance();
		dob.setTime(wdt);
		Calendar today = Calendar.getInstance();
		int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
		if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
			age--;
		} else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
			age--;
		}

		if (age < 18) {
			return true;
		}


		return false;
	}
	public static int getYas(String dt) throws Exception {

		logger.info("------------------ getYas WEB_DOGUM_TARIHI" + dt);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);
		Date wdt = sdf.parse(dt);
		Calendar dob = Calendar.getInstance();
		dob.setTime(wdt);
		Calendar today = Calendar.getInstance();
		int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
		if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
			age--;
		} else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
			age--;
		}

		return age;

	}
	public static int getYas(Date wdt) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);
		Calendar dob = Calendar.getInstance();
		dob.setTime(wdt);
		Calendar today = Calendar.getInstance();
		int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
		if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
			age--;
		} else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
			age--;
		}

		return age;

	}
	
	public static String generatePhotoPath(BigDecimal basvuruNo,String uyrukKod,BigDecimal tckn,String pasaportNo,boolean isApprovedPhoto) throws Exception{
		
		if(StringUtils.isBlank(uyrukKod)){
			throw new Exception("Uyruk kod bos foto path hesaplanamaz");
		}
		
		if(tckn ==null && StringUtils.isBlank(pasaportNo)){
			throw new Exception("Kimlik bilgileri bos foto path hesaplanamaz");
		}
		String kimlikNo = String.valueOf(tckn);
		if(!"TR".equals(uyrukKod)){
			kimlikNo = pasaportNo; 
		}
		
		String kimlikNoGercek = kimlikNo;
		kimlikNo = StringUtils.leftPad(kimlikNo, 12,"0");
		String folderPath = ROOT + File.separator + "files";
		try {

			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));

		} catch (Exception e) {
			logger.error("Foto path alinamdi TFF_WEBSERVIS_PARAM-K-RESIM_PATH" );
			e.printStackTrace();
		}
		String[] sp = kimlikNo.split("(?<=\\G.{3})");
		
		for (int i = 0; i < sp.length - 1 && i < 3; i++) {
			if (CardServicesHelper.isWindowsReservedFilename(sp[i])){
				folderPath = String.format("%s/%s", folderPath, "XXX");
			}	else{
				folderPath = String.format("%s/%s", folderPath, sp[i]);
			}
			
		}
		folderPath = String.format("%s/%s", folderPath, kimlikNoGercek);
		
		// klasor.mkdir();
		String type = "jpg";
		
		String approvedImageFile = folderPath + File.separator + conf.getProperty("gise_foto_folder","APPROVED")+ File.separator +kimlikNoGercek+ "." + type;
		String imageFile = folderPath + File.separator + kimlikNoGercek + "_" + basvuruNo + "." + type;
		if(isApprovedPhoto){
			return approvedImageFile;
		}else{
			return imageFile;
		}
	}
	public static String convertUygunluk(String x){

		if("1".equals(x)){
			return "U";
		}else if("2".equals(x)){
			return "E";
		}else{
			return "H";
		}
	}
	
	public static GMMap adresKontrol(GMMap iMap) {		
		//Adres tipi
		String adresTipi = iMap.getString("ADRES_TIPI");
		if (!("E".equals(adresTipi) || "I".equals(adresTipi) || "D".equals(adresTipi) ||
				"TN".equals(adresTipi) || "GN".equals(adresTipi))) {
			return CreditCardServicesUtil.getErrorResponse(ADRES_TIPI_HATASI);
		}
		
		//Gise-Ptt
		if ("TN".equals(adresTipi) || "GN".equals(adresTipi)) {
			if (StringUtils.isBlank(iMap.getString("TESLIMAT_NOKTASI_KODU"))) {
				return CreditCardServicesUtil.getErrorResponse(UYE_ADRES_EKLE_GENEL_HATA);
			}
		} 
		
		//Ev-Is-Diger
		if ("E".equals(adresTipi) || "I".equals(adresTipi) || "D".equals(adresTipi)) {
			//Il
			if (StringUtils.isBlank(iMap.getString("IL_KOD"))) {
				if ("E".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(EV_IL_BOS_OLAMAZ);
				} else if ("I".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(IS_IL_BOS_OLAMAZ);
				} else if ("D".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(DIGER_ADRES_IL_BOS_OLAMAZ);
				}
			}
			
			//Ilce
			if (StringUtils.isBlank(iMap.getString("ILCE_KOD"))) {
				if ("E".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(EV_ILCE_BOS_OLAMAZ);
				} else if ("I".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(IS_ILCE_BOS_OLAMAZ);
				} else if ("D".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(DIGER_ADRES_ILCE_BOS_OLAMAZ);
				}
			}
			
			//Uyumlu mu
			GMMap sorguMap = new GMMap();
			sorguMap.putAll(tffAdresEkleAlanKontrol(iMap));
			if (RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}
			
			//Acik Adres
			if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
				if ("E".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(EV_ACIK_ADRES_BOS_OLAMAZ);
				} else if ("I".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(IS_ACIK_ADRES_BOS_OLAMAZ);
				} else if ("D".equals(adresTipi)) {
					return CreditCardServicesUtil.getErrorResponse(DIGER_ADRES_ACIK_ADRES_BOS_OLAMAZ);
				}
			} else {
				if (iMap.getString("ACIK_ADRES").length() < 10 || !iMap.getString("ACIK_ADRES").trim().contains(" ")) {
					return CreditCardServicesUtil.getErrorResponse(UYE_ADRES_EKLE_GENEL_HATA);
				}
			}
		}
		

		return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
	}
	
	public static GMMap telefonKontrol(GMMap iMap) {
		String tip = iMap.getString("TELEFON_TIPI");
		String ulkeKod = iMap.getString("ULKE_KOD", "90");
		String alanKod = iMap.getString("ALAN_KOD");
		String numara = iMap.getString("NUMARA");
		String ilKod = iMap.getString("IL_KOD");
		
		if (!("C".equals(tip) || "E".equals(tip) || "I".equals(tip))) {
			return CreditCardServicesUtil.getErrorResponse(UYE_TELEFON_EKLE_GENEL_HATA);
		}
		
		//ulke Kod
		if (StringUtils.isBlank(ulkeKod) || !StringUtils.isNumeric(ulkeKod)) {
			if ("C".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(CEP_ULKE_KOD_HATALI);
			} else if ("E".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(EV_ULKE_KOD_HATALI);
			} else if ("I".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(IS_ULKE_KOD_HATALI);
			}
			
		}
		
		//Alan kod
		if (StringUtils.isBlank(alanKod) || !StringUtils.isNumeric(alanKod)) {
			if ("C".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(CEP_ALAN_KOD_HATALI);
			} else if ("E".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(EV_ALAN_KOD_HATALI);
			} else if ("I".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(IS_ALAN_KOD_HATALI);
			}
		}
		
		//Numara
		if (StringUtils.isBlank(numara) || !StringUtils.isNumeric(numara)) {
			if ("C".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(CEP_TEL_NO_HATALI);
			} else if ("E".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(EV_TEL_NO_HATALI);
			} else if ("I".equals(tip)) {
				return CreditCardServicesUtil.getErrorResponse(IS_TEL_NO_HATALI);
			}
		}
		
		//Genel kontrol - alan uyumlu mu vs.
		String responseData = validatePhoneNumber(tip, ulkeKod, alanKod, numara);
		if (!RESPONSE_BASARILI.equals(responseData)) {
			return CreditCardServicesUtil.getErrorResponse(responseData);
		}
		
		//Il dolu ise kontrol et
		if (StringUtils.isNotBlank(ilKod) && ("E".equals(tip) || "I".equals(tip))) {
			GMMap sorguMap = new GMMap();
			sorguMap.put("TEL_ALAN", alanKod);
			sorguMap.put("IL_KODU", ilKod);
			if (!telAlanKodDogrumu(sorguMap)) {
				return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_EV_ALAN_EV_ADRES_UYUMSUZ);
			}
		}
		
		return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
	}
}
