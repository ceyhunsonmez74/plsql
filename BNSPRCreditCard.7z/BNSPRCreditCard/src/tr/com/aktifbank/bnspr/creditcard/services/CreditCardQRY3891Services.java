package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkTopluBasvuruTemp;
import tr.com.aktifbank.bnspr.dao.KkTopluBasvuruTempId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardQRY3891Services {

	/**
	 * Excel dosyas�n� ekranda g�r�nmesi i�in y�kler.
	 * 
	 * @param iMap
	 *            - DOSYA
	 */
	@GraymoundService("BNSPR_QRY3891_LOAD_EXCEL_FILE")
	public static GMMap loadExcelFile(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			WorkbookSettings workbookSettings = new WorkbookSettings();
			workbookSettings.setEncoding("CP1254");
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")), workbookSettings);
			Sheet sheet = workbook.getSheet(0);

			String tableName = "RESULT_LIST";
			String basvuruTipi = iMap.getString("BASVURU_TIPI");
			int tableRow = 0;

			for (int excelRow = 1; excelRow < sheet.getRows(); excelRow++, tableRow++) {
				int cc = 0;
				oMap.put(tableName, tableRow, "TCKN", sheet.getCell(cc, excelRow).getContents().trim());
				cc++;
				oMap.put(tableName, tableRow, "CEP_TEL_ALAN", sheet.getCell(cc, excelRow).getContents().trim());
				cc++;
				oMap.put(tableName, tableRow, "CEP_TEL_NUMARA", sheet.getCell(cc, excelRow).getContents().trim());
				cc++;
				if ("T".equals(basvuruTipi)) {
					oMap.put(tableName, tableRow, "KANAL_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "KARTIN_UZERINE_YAZILACAK_ISIM", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "KART_SEVIYESI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "KART_LIMITI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "URUN_TIPI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EKSTRE_SECIMI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EKSTRE_TIPI_POSTA", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EKSTRE_TIPI_SMS", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EKSTRE_TIPI_EMAIL", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "HESAP_KESIM_TARIHI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "OTOMATIK_ODEME_TALIMATI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "YURTDISI_HARCAMA_EKSTRESI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "E_POSTA", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "ANNE_KIZLIK", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "KIMLIK_SERI_NO", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "KIMLIK_SIRA_NO", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "CALISMA_SEKLI_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "UNVAN_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "MESLEK_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "AYLIK_GELIR", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "OGRENIM_DURUM_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IKAMET_DURUM_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EVDE_OTURMA_SURESI_YIL", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EVDE_OTURMA_SURESI_AY", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "CALISMA_SURESI_YIL", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "CALISMA_SURESI_AY", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_ADRES", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_ILCE_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_IL_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_POSTA_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_EKSTRE_ADRESI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_TEL_ALAN", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "EV_TEL_NUMARA", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_ADRES", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_ILCE_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_IL_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_POSTA_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_TEL_ALAN", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_TEL_NUMARA", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_TEL_DAHILI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "IS_EKSTRE_ADRESI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "ISYERI_ADI", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "ISYERI_FAALIYET_ALANI_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "VERGI_DAIRE_AD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "VERGI_DAIRE_IL_KOD", sheet.getCell(cc, excelRow).getContents().trim());
					cc++;
					oMap.put(tableName, tableRow, "MUSTERI_GRUP", sheet.getCell(cc, excelRow).getContents().trim());
				}
			}
			workbook.close();
		}
		catch (IndexOutOfBoundsException e) {
			throw new GMRuntimeException(0, "Excel s�tunu eksik");
		}
		catch (FileNotFoundException e) {
			throw new GMRuntimeException(0, "Belirtilen dizinde dosya bulunamad�");
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, "Ge�ersiz bir dosya se�tiniz.L�ften ge�erli bir dosya y�kleyin");
		}
		return oMap;
	}

	/**
	 * Excel dosyas�ndan ekrana y�klenen bilgileri KK_TOPLU_BASVURU_TEMP tablosuna kaydeder.
	 * 
	 * @param iMap
	 *            - BASVURU_LIST
	 */

	@GraymoundService("BNSPR_QRY3891_SAVE")
	public static GMMap save(GMMap iMap) {
		BigDecimal trxNo;
		String basvuruTipi;
		String tableName;

		Connection conn = null;
		CallableStatement stmt = null;
		Session session;

		GMMap oMap = new GMMap();
		try {

			session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			conn = DALUtil.getGMConnection();

			tableName = "BASVURU_LIST";
			trxNo = iMap.getBigDecimal("TRX_NO");
			basvuruTipi = iMap.getString("BASVURU_TIPI");

			List<?> basvuruList = (List<?>) iMap.get(tableName);
			if (basvuruList.size() > 0) {
				for (int i = 0; i < basvuruList.size(); i++) {
					KkTopluBasvuruTempId id = new KkTopluBasvuruTempId(new BigDecimal(String.valueOf(i + 1)), trxNo);
					KkTopluBasvuruTemp kkTopluBasvuruTemp = (KkTopluBasvuruTemp) session.get(KkTopluBasvuruTemp.class, id);

					if (kkTopluBasvuruTemp == null) {
						kkTopluBasvuruTemp = new KkTopluBasvuruTemp(id, basvuruTipi);
					}
					kkTopluBasvuruTemp.setDurum("0");
					kkTopluBasvuruTemp.setTckn(iMap.getString(tableName, i, "TCKN"));
					kkTopluBasvuruTemp.setCepTelAlan(iMap.getString(tableName, i, "CEP_TEL_ALAN"));
					kkTopluBasvuruTemp.setCepTelNumara(iMap.getString(tableName, i, "CEP_TEL_NUMARA"));

					if ("T".equals(basvuruTipi)) {
						kkTopluBasvuruTemp.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
						kkTopluBasvuruTemp.setKartinUzerineYazilacakIsim(iMap.getString(tableName, i, "KARTIN_UZERINE_YAZILACAK_ISIM"));
						kkTopluBasvuruTemp.setKartSeviyesi(iMap.getString(tableName, i, "KART_SEVIYESI"));
						kkTopluBasvuruTemp.setKartLimiti(iMap.getBigDecimal(tableName, i, "KART_LIMITI"));
						kkTopluBasvuruTemp.setUrunTipi(iMap.getString(tableName, i, "URUN_TIPI"));
						kkTopluBasvuruTemp.setEkstreSecimi(iMap.getString(tableName, i, "EKSTRE_SECIMI"));
						kkTopluBasvuruTemp.setEkstreTipiPosta(iMap.getString(tableName, i, "EKSTRE_TIPI_POSTA"));
						kkTopluBasvuruTemp.setEkstreTipiSms(iMap.getString(tableName, i, "EKSTRE_TIPI_SMS"));
						kkTopluBasvuruTemp.setEkstreTipiEmail(iMap.getString(tableName, i, "EKSTRE_TIPI_EMAIL"));
						kkTopluBasvuruTemp.setHesapKesimTarihi(iMap.getString(tableName, i, "HESAP_KESIM_TARIHI"));
						kkTopluBasvuruTemp.setOtomatikOdemeTalimati(iMap.getString(tableName, i, "OTOMATIK_ODEME_TALIMATI"));
						kkTopluBasvuruTemp.setYurtdisiHarcamaEkstresi(iMap.getString(tableName, i, "YURTDISI_HARCAMA_EKSTRESI"));
						kkTopluBasvuruTemp.setEPosta(iMap.getString(tableName, i, "E_POSTA"));
						kkTopluBasvuruTemp.setAnneKizlik(iMap.getString(tableName, i, "ANNE_KIZLIK"));
						kkTopluBasvuruTemp.setKimlikSeriNo(iMap.getString(tableName, i, "KIMLIK_SERI_NO"));
						kkTopluBasvuruTemp.setKimlikSiraNo(iMap.getString(tableName, i, "KIMLIK_SIRA_NO"));
						kkTopluBasvuruTemp.setCalismaSekliKod(iMap.getString(tableName, i, "CALISMA_SEKLI_KOD"));
						kkTopluBasvuruTemp.setUnvanKod(iMap.getString(tableName, i, "UNVAN_KOD"));
						kkTopluBasvuruTemp.setMeslekKod(iMap.getString(tableName, i, "MESLEK_KOD"));
						kkTopluBasvuruTemp.setAylikGelir(iMap.getBigDecimal(tableName, i, "AYLIK_GELIR"));
						kkTopluBasvuruTemp.setOgrenimDurumKod(iMap.getString(tableName, i, "OGRENIM_DURUM_KOD"));
						kkTopluBasvuruTemp.setIkametDurumKod(iMap.getString(tableName, i, "IKAMET_DURUM_KOD"));
						kkTopluBasvuruTemp.setEvdeOturmaSuresiYil(iMap.getString(tableName, i, "EVDE_OTURMA_SURESI_YIL"));
						kkTopluBasvuruTemp.setEvdeOturmaSuresiAy(iMap.getString(tableName, i, "EVDE_OTURMA_SURESI_AY"));
						kkTopluBasvuruTemp.setCalismaSuresiYil(iMap.getString(tableName, i, "CALISMA_SURESI_YIL"));
						kkTopluBasvuruTemp.setCalismaSuresiAy(iMap.getString(tableName, i, "CALISMA_SURESI_AY"));
						kkTopluBasvuruTemp.setEvAdres(iMap.getString(tableName, i, "EV_ADRES"));
						kkTopluBasvuruTemp.setEvIlceKod(iMap.getString(tableName, i, "EV_ILCE_KOD"));
						kkTopluBasvuruTemp.setEvIlKod(iMap.getString(tableName, i, "EV_IL_KOD"));
						kkTopluBasvuruTemp.setEvPostaKod(iMap.getString(tableName, i, "EV_POSTA_KOD"));
						kkTopluBasvuruTemp.setEvEkstreAdresi(iMap.getString(tableName, i, "EV_EKSTRE_ADRESI"));
						kkTopluBasvuruTemp.setEvTelAlan(iMap.getString(tableName, i, "EV_TEL_ALAN"));
						kkTopluBasvuruTemp.setEvTelNumara(iMap.getString(tableName, i, "EV_TEL_NUMARA"));
						kkTopluBasvuruTemp.setIsAdres(iMap.getString(tableName, i, "IS_ADRES"));
						kkTopluBasvuruTemp.setIsIlceKod(iMap.getString(tableName, i, "IS_ILCE_KOD"));
						kkTopluBasvuruTemp.setIsIlKod(iMap.getString(tableName, i, "IS_IL_KOD"));
						kkTopluBasvuruTemp.setIsPostaKod(iMap.getString(tableName, i, "IS_POSTA_KOD"));
						kkTopluBasvuruTemp.setIsTelAlan(iMap.getString(tableName, i, "IS_TEL_ALAN"));
						kkTopluBasvuruTemp.setIsTelNumara(iMap.getString(tableName, i, "IS_TEL_NUMARA"));
						kkTopluBasvuruTemp.setIsTelDahili(iMap.getString(tableName, i, "IS_TEL_DAHILI"));
						kkTopluBasvuruTemp.setIsEkstreAdresi(iMap.getString(tableName, i, "IS_EKSTRE_ADRESI"));
						kkTopluBasvuruTemp.setIsyeriAdi(iMap.getString(tableName, i, "ISYERI_ADI"));
						kkTopluBasvuruTemp.setIsyeriFaaliyetAlaniKod(iMap.getString(tableName, i, "ISYERI_FAALIYET_ALANI_KOD"));
						kkTopluBasvuruTemp.setVergiDaireAd(iMap.getString(tableName, i, "VERGI_DAIRE_AD"));
						kkTopluBasvuruTemp.setVergiDaireIlKod(iMap.getString(tableName, i, "VERGI_DAIRE_IL_KOD"));
						kkTopluBasvuruTemp.setMusteriGrup(iMap.getString(tableName, i, "MUSTERI_GRUP"));

					}
					session.saveOrUpdate(kkTopluBasvuruTemp);
				}
				session.flush();
				stmt = conn.prepareCall("{call pkg_rc3891.RC_QRY3891_CHECK_FIELDS (?)}");
				int i = 1;
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt.execute();

				oMap.put("MESSAGE", "��lem ba�ar�yla ger�ekle�tirildi");
				oMap.put("SAVE_RESPONSE", "1");
			}
			else {
				oMap.put("MESSAGE", "Tabloda kay�t yok.L�tfen dosyay� y�kleyin.");
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	/**
	 * KK_TOPLU_BASVURU_TEMP tablosuna kaydedilen ve
	 * durumu '0' olan kay�tlar�n basvurular�n�n yap�lmas�n� sa�lar.
	 * Bu servis job taraf�ndan �a�r�l�r.
	 * 
	 * 
	 */

	@GraymoundService("BNSPR_TRN3891_KK_JOB")
	public static GMMap kkJob(GMMap iMap) {
		Session session;
		GMMap oMap = new GMMap();

		try {

			session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			List<?> list = (List<?>) session.createCriteria(KkTopluBasvuruTemp.class).add(Restrictions.eq("durum", "0")).list();

			if (list == null)
				return oMap;
			for (int i = 0; i < list.size(); i++) {
				// �nceki kay�ttan gelen verilerin temizlenmesi i�in clear �al��t�r�l�r
				iMap.clear();
				KkTopluBasvuruTemp kkTopluBasvuruTemp = (KkTopluBasvuruTemp) list.get(i);
				iMap.put("KK_TOPLU_BASVURU_TEMP", kkTopluBasvuruTemp);

				// k�sa basvuru
				if ("K".equals(kkTopluBasvuruTemp.getBasvuruTipi())) {
					GMServiceExecuter.executeNT("BNSPR_TRN3891_KISA_BASVURU_YAP", iMap);
				}
				// tam basvuru
				if ("T".equals(kkTopluBasvuruTemp.getBasvuruTipi())) {
					GMServiceExecuter.executeNT("BNSPR_TRN3891_TAM_BASVURU_YAP", iMap);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3891_KISA_BASVURU_YAP")
	public static GMMap kisaBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		KkTopluBasvuruTemp kkTopluBasvuruTemp = (KkTopluBasvuruTemp) iMap.get("KK_TOPLU_BASVURU_TEMP");

		try {
			// Bu flag kps ba�ar�l� yap�lamay�nca kps_joba d��mesini engeller.
			oMap.put("TOPLU_BASVURU_MU", "E");
			oMap.put("TCK_NO", kkTopluBasvuruTemp.getTckn());
			oMap.put("CEP_TEL_KOD", kkTopluBasvuruTemp.getCepTelAlan());
			oMap.put("CEP_TEL_NO", kkTopluBasvuruTemp.getCepTelNumara());
			oMap.put("BASVURU_NO", kkTopluBasvuruTemp.getBasvuruNo());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_CREATE_BASVURU_BY_CEP_TCKN_NO", oMap));

			// Servisten herhangi bir nedenden dolay� response flagi 0 d�nerse,tekrar �al��mas� i�in durum "0" yap�lacak.
			if ("0".equals(oMap.getString("RESPONSE"))) {
				kkTopluBasvuruTemp.setDurum("0");
				kkTopluBasvuruTemp.setAlinanHata(oMap.getString("MESSAGE"));
			}
			// Servisten herhangi bir nedenden dolay� response flagi 2 d�nerse,tekrar �al��mamas� i�in durum "1" yap�lacak.
			else if ("2".equals(oMap.getString("RESPONSE"))) {
				kkTopluBasvuruTemp.setBasvuruNo(oMap.getBigDecimal("BASVURU_NO"));
				kkTopluBasvuruTemp.setAlinanHata(oMap.getString("MESSAGE"));
				kkTopluBasvuruTemp.setDurum("1");
			}
		}
		catch (Exception e) {
			kkTopluBasvuruTemp.setAlinanHata(e.toString());
		}
		session.saveOrUpdate(kkTopluBasvuruTemp);
		session.flush();

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3891_TAM_BASVURU_YAP")
	public static GMMap tamBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		KkTopluBasvuruTemp kkTopluBasvuruTemp = (KkTopluBasvuruTemp) iMap.get("KK_TOPLU_BASVURU_TEMP");

		try {
			// Bu flag kps ba�ar�l� yap�lamay�nca kps_joba d��mesini engeller.
			oMap.put("TOPLU_BASVURU_MU", "E");
			// Bu flag 3871 start transaction methodunun tam ba�vuru i�in �al��mas�n� �nlemek i�indir.
			oMap.put("TOPLU_BASVURU_TAM", "E");
			oMap.put("TCK_NO", kkTopluBasvuruTemp.getTckn());
			oMap.put("CEP_TEL_KOD", kkTopluBasvuruTemp.getCepTelAlan());
			oMap.put("CEP_TEL_NO", kkTopluBasvuruTemp.getCepTelNumara());
			oMap.put("BASVURU_NO", kkTopluBasvuruTemp.getBasvuruNo());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_CREATE_BASVURU_BY_CEP_TCKN_NO", oMap));

			// Servisten herhangi bir nedenden dolay� response flagi 0 d�nerse,tekrar �al��mas� i�in durum "0" yap�lacak.
			if ("0".equals(oMap.getString("RESPONSE"))) {
				kkTopluBasvuruTemp.setAlinanHata(oMap.getString("MESSAGE"));
				kkTopluBasvuruTemp.setDurum("0");
			}
			// Servisten herhangi bir nedenden dolay� response flagi H d�nerse,tekrar �al��mamas� i�in durum "1" yap�lacak.
			if ("2".equals(oMap.getString("RESPONSE"))) {
				kkTopluBasvuruTemp.setBasvuruNo(oMap.getBigDecimal("BASVURU_NO"));
				// E�er servisten d�nen devam E ise, yani i�leme devam edilmesi gerekiyorsa, tam ba�vurunun geri kalan k�sm� yap�l�r
				if ("E".equals(oMap.getString("DEVAM")))
					oMap.putAll(tamBasvuruYap(kkTopluBasvuruTemp, oMap));
				kkTopluBasvuruTemp.setAlinanHata(oMap.getString("MESSAGE"));
				kkTopluBasvuruTemp.setDurum("1");
			}
		}
		catch (Exception e) {
			kkTopluBasvuruTemp.setAlinanHata(e.toString());
		}

		session.saveOrUpdate(kkTopluBasvuruTemp);
		session.flush();
		return oMap;
	}
	

	/**
	 * Tam basvurunun k�sa ba�vurudan ayr�lan k�sm�
	 */
	private static GMMap tamBasvuruYap(KkTopluBasvuruTemp kkTopluBasvuruTemp, GMMap iMap) {
		GMMap oMap = new GMMap();

		// Save basvuru
		// info from kps

		iMap.put("ADI", iMap.getString("AD"));
		iMap.put("IKINCI_ADI", iMap.getString("AD2"));
		iMap.put("SOYADI", iMap.getString("SOYAD"));
		iMap.put("BABA_ADI", iMap.getString("BABA_AD"));
		iMap.put("ANNE_ADI", iMap.getString("ANNE_AD"));
		iMap.put("KIMLIK_SERI_NO_KPS", iMap.getString("KIMLIK_SERI_NO"));
		iMap.put("KIMLIK_SIRA_NO_KPS", iMap.getString("KIMLIK_SIRA_NO"));
		iMap.put("NUFUS_IL_KOD", iMap.getString("IL_KODU"));
		iMap.put("NUFUS_ILCE_KOD", iMap.getString("ILCE_KODU"));
		iMap.put("NUFUS_CILT_NO", iMap.getString("CILT_KODU"));
		iMap.put("NUFUS_AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
		iMap.put("NUFUS_SIRA_NO", iMap.getString("BIREY_SIRA_NO"));
		iMap.put("NUFUS_VERILIS_TARIHI", iMap.getString("VERILIS_TARIHI"));
		if (iMap.getString("CINSIYET") != null)
			iMap.put("CINSIYET", iMap.getString("CINSIYET").substring(0, 1));
		if ("E".equals(iMap.getString("MEDENI_HALI").substring(0, 1))) {
			iMap.put("MEDENI_HAL", "1");
		}
		else {
			iMap.put("MEDENI_HAL", "2");
		}
		iMap.put("KAYIP_CUZDAN_NO", iMap.getString("KAYIP_CUZDAN_NO"));
		iMap.put("KAYIP_CUZDAN_SERI", iMap.getString("KAYIP_CUZDAN_SERI"));
		iMap.put("KPS_YAPILDI", "E");
		iMap.put("NUF_VERILDIGI_YER", iMap.getString("VERILDIGI_ILCE_ADI"));
		iMap.put("NUF_VERILIS_NEDENI", iMap.getString("VERILIS_NEDENI"));
		iMap.put("APS_YAPILDIMI", iMap.getString("APS_YAPILDIMI"));
		iMap.put("ES_TCKN", iMap.getString("ES_TCKN"));
		iMap.put("NUFUS_MAHALLE", iMap.getString("MAHALLE_KOY"));
		iMap.put("ASIL_KART_MUSTERI_NO", iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
		iMap.put("ASIL_KART_NO", iMap.getString("ASIL_KART_NO"));

		// info from excel file
		iMap.put("TC_KIMLIK_NO", kkTopluBasvuruTemp.getTckn());
		iMap.put("KIMLIK_SERI_NO", kkTopluBasvuruTemp.getKimlikSeriNo());
		iMap.put("KIMLIK_SIRA_NO", kkTopluBasvuruTemp.getKimlikSiraNo());
		iMap.put("ANNE_KIZLIK_SOYADI", kkTopluBasvuruTemp.getAnneKizlik());
		iMap.put("EMAIL_TAM", kkTopluBasvuruTemp.getEPosta());
		iMap.put("ISYERI_ADI", kkTopluBasvuruTemp.getIsyeriAdi());
		iMap.put("CALISMA_SEKLI", kkTopluBasvuruTemp.getCalismaSekliKod());
		iMap.put("KREDI_KARTI_EKSTRE_SECIMI", kkTopluBasvuruTemp.getEkstreSecimi());
		iMap.put("EKSTRE_SECIMI", kkTopluBasvuruTemp.getEkstreSecimi());
		iMap.put("KREDI_KARTI_SEVIYESI", kkTopluBasvuruTemp.getKartSeviyesi());
		iMap.put("KART_LIMITI", kkTopluBasvuruTemp.getKartLimiti());
		iMap.put("KREDI_KARTI_EKSTRE_TIPI_EMAIL", kkTopluBasvuruTemp.getEkstreTipiEmail());
		iMap.put("KREDI_KARTI_EKSTRE_TIPI_POSTA", kkTopluBasvuruTemp.getEkstreTipiPosta());
		iMap.put("KREDI_KARTI_EKSTRE_TIPI_SMS", kkTopluBasvuruTemp.getEkstreTipiSms());
		iMap.put("KART_URUN_TIP", kkTopluBasvuruTemp.getUrunTipi());
		iMap.put("CALISMA_SEKLI", kkTopluBasvuruTemp.getCalismaSekliKod());
		iMap.put("AYLIK_GELIR", kkTopluBasvuruTemp.getAylikGelir());
		iMap.put("ISYERI_ADI", kkTopluBasvuruTemp.getIsyeriAdi());
		iMap.put("KANAL_KOD", kkTopluBasvuruTemp.getKanalKod());
		iMap.put("HESAP_KESIM_TARIHI", kkTopluBasvuruTemp.getHesapKesimTarihi());
		iMap.put("KART_OTOMATIK_ODEME", kkTopluBasvuruTemp.getOtomatikOdemeTalimati());
		iMap.put("YURT_DISI_EKSTRE_TIP", kkTopluBasvuruTemp.getYurtdisiHarcamaEkstresi());
		iMap.put("OGRENIM_DURUMU", kkTopluBasvuruTemp.getOgrenimDurumKod());
		iMap.put("IKAMET_DURUMU", kkTopluBasvuruTemp.getIkametDurumKod());
		iMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", kkTopluBasvuruTemp.getEvdeOturmaSuresiYil());
		iMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", kkTopluBasvuruTemp.getEvdeOturmaSuresiYil());
		iMap.put("ISYERINDE_CALISMA_SURESI_YIL", kkTopluBasvuruTemp.getCalismaSuresiYil());
		iMap.put("ISYERINDE_CALISMA_SURESI_AY", kkTopluBasvuruTemp.getCalismaSuresiAy());
		iMap.put("ISYERI_FAALIYET_ALANI", kkTopluBasvuruTemp.getIsyeriFaaliyetAlaniKod());
		iMap.put("UNVANI", kkTopluBasvuruTemp.getUnvanKod());
		iMap.put("MESLEK", kkTopluBasvuruTemp.getMeslekKod());
		iMap.put("ISYERI_VERGI_DAIRESI_ADI", kkTopluBasvuruTemp.getVergiDaireAd());
		iMap.put("ISYERI_VERGI_DAIRESI_IL", kkTopluBasvuruTemp.getVergiDaireIlKod());
		iMap.put("KART_UZERINDEKI_ISIM", kkTopluBasvuruTemp.getKartinUzerineYazilacakIsim());
		iMap.put("CEP_TEL_KOD", kkTopluBasvuruTemp.getCepTelAlan());
		iMap.put("CEP_TEL_NO", kkTopluBasvuruTemp.getCepTelNumara());
		iMap.put("IS_TEL_KOD", kkTopluBasvuruTemp.getIsTelAlan());
		iMap.put("IS_TEL_NO", kkTopluBasvuruTemp.getIsTelNumara());
		iMap.put("IS_TEL_DAHILI", kkTopluBasvuruTemp.getIsTelDahili());
		iMap.put("EV_TEL_KOD", kkTopluBasvuruTemp.getEvTelAlan());
		iMap.put("EV_TEL_NO", kkTopluBasvuruTemp.getEvTelNumara());
		iMap.put("EV_IL", kkTopluBasvuruTemp.getEvIlKod());
		iMap.put("EV_ILCE", kkTopluBasvuruTemp.getEvIlceKod());
		iMap.put("EV_ADRESI", kkTopluBasvuruTemp.getEvAdres());
		iMap.put("EV_POSTA_KODU", kkTopluBasvuruTemp.getEvPostaKod());
		iMap.put("IS_IL", kkTopluBasvuruTemp.getIsIlKod());
		iMap.put("IS_ILCE", kkTopluBasvuruTemp.getIsIlceKod());
		iMap.put("IS_ADRESI", kkTopluBasvuruTemp.getIsAdres());
		iMap.put("IS_POSTA_KODU", kkTopluBasvuruTemp.getIsPostaKod());
		iMap.put("MUSTERI_GROUP", kkTopluBasvuruTemp.getMusteriGrup());
		// insert tarih�e i�in gerekli alanlar
		iMap.put("DURUM_KODU", "ON_BASVURU");
		iMap.put("ISLEM_SONRASI_DURUM_KODU", "NBSM");
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_CURRENT_TIME", new GMMap())); // CURRENT_DATE

		// iMap.put("MESLEK_ACIKLAMA", kkTopluBasvuruTemp);
		iMap.put("IS_FULL_SAVE", "Y"); // insert all records when calling 3871save

		// ilk sayfa kontrollerinin tekrar yap�lmamas� i�in
		iMap.put("IS_FIRST_PAGE", "N");

		// call 3871 Save
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_SAVE", iMap));

		// call 3871 Check Fields
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", iMap));

		// call 3871 Insert Tarihce
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_INSERT_TARIHCE", iMap)); // DURUM_KODU,

		// call gonder sorgular
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", iMap));

		String message = oMap.getString("MESSAGE");
		// send trx
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", iMap));

		// Bilgilendir
		oMap.put("MESSAGE", message);
		return oMap;
	}

}
