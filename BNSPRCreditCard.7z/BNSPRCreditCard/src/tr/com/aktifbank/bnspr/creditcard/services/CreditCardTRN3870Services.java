package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3870Services {
	
	private static final String ISLEM_KODU_KISA_BASVURU = "3870";
	private static final Logger logger = LoggerFactory.getLogger(CreditCardTRN3870Services.class);
	
	/** Kredi karti kisa basvuru islemini gerceklestirir.<br>
	 * @author murat.el
	 * @since PY-8929
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *        <li>TRX_NO - Kredi karti islem numarasi
	 *        <li>DURUM_KOD - Basvurunun durum kodu
	 *        <li>TC_KIMLIK_NO - Basvuru sahibi kimlik numarasi
	 *        <li>CEP_ULKE_KOD - Cep telefonu ulke kodu
	 *        <li>CEP_TEL_KOD - CEp telefonu alan kodu
	 *        <li>CEP_TEL_NO - Cep telefonu numarasi
	 *        <li>KPS_JOB_AKTIF_MI - Kps yapilamazsa joba dusurulsun mu? (E:Evet|H:Hayir)
	 *        <li>KREDI_KARTI_SEVIYESI - Kredi karti basvurusunun hangi amacla yapildigi
	 * @return oMap - Islem sonucu<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *        <li>TRX_NO - Kredi karti islem numarasi
	 *        <li>RESPONSE - Islem sonuc kodu. NBSM asamasinda kaldi response basarisiz olarak doner.
	 *        <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 *        <li>NBSM_HATASI_MI - NBSM sirasinda hata alindi mi? (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3870_KISA_BASVURU_YAP")
	public static GMMap kisaBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			GMMap sorguMap = new GMMap();
			//1.Parametreleri Al.
			//Islem No. KPS_JOB dolu geliyor.
			if (iMap.get("TRX_NO") == null) {
				sorguMap.clear();
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap));
			}
			oMap.put("TRX_NO", iMap.get("TRX_NO"));
			//Basvuru No. KPS_JOB dolu geliyor.
			if (iMap.get("BASVURU_NO") == null) {
				sorguMap.clear();
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_BASVURU_NO", sorguMap));
				iMap.put("BASVURU_NO", sorguMap.getString("ID"));
			}
			oMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			//Tarihce i�in durum_kodu degi�keni. KPS_JOB dolu geliyor.
			if (iMap.get("DURUM_KOD") == null) {
				iMap.put("DURUM_KOD", "ON_BASVURU");
				iMap.put("ISLEM_FLAG", "E");//Yeni bir basvuru olusturulacak
			} else {
				iMap.put("ISLEM_FLAG", "G");//Mevcut bir basvuru guncellenecek
			}
			//Kanal Kodu
			sorguMap.clear();
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", sorguMap));//KANAL_KOD
			//Sube Kodu
			sorguMap.clear();
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_SUBE_KOD", sorguMap)); //SUBE_KOD
			//Basvuru Tarihi
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_CURRENT_TIME", sorguMap)); //CURRENT_DATE
			iMap.put("BASVURU_TARIHI", sorguMap.get("TODAY"));
			//APS
			iMap.put("APS_YAPILDIMI", CreditCardServicesUtil.HAYIR);
			//Kart seviyesi
			iMap.put("KREDI_KARTI_SEVIYESI", CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_SEVIYESI"), "K"));
			if ("O".equals(iMap.getString("KREDI_KARTI_SEVIYESI"))) {
				iMap.put("ON_ONAYLI_MI", CreditCardServicesUtil.EVET);
			}
			
			//2.KPS Sorgusu Yap
			sorguMap.clear();
			sorguMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("KPS_JOB_AKTIF_MI", CreditCardServicesUtil.nvl(iMap.getString("KPS_JOB_AKTIF_MI"), CreditCardServicesUtil.HAYIR));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_KPS_SORGULA", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", sorguMap.getString("RESPONSE_DATA"));
				return oMap;
			} else {
				iMap.putAll(sorguMap);//KPSden alinan bilgileri al.
			}
			
			//3.Bilgileri kaydet
			GMServiceExecuter.executeNT("BNSPR_TRN3870_SAVE", iMap);

			//4.Sorgu Islemlerini gerceklestir ve basvuruyu tamamla
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("KREDI_KARTI_SEVIYESI", iMap.get("KREDI_KARTI_SEVIYESI"));
			sorguMap.put("BASVURU_SONLANDIR", CreditCardServicesUtil.HAYIR);
			sorguMap.put("ISLEM_SONLANDIR", CreditCardServicesUtil.EVET);
			sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("APS_YAPILDI_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_DEVAM", sorguMap));
			//Sonucu don
			oMap.put("RESPONSE_DATA", sorguMap.getString("RESPONSE_DATA"));
			oMap.put("NBSM_HATASI_MI", sorguMap.getString("NBSM_HATASI_MI"));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			}
		}
		catch (Exception e) {
			logger.info("Kisa Basvuru Hata : " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3870_BASVURU_GIRIS_RED_KONTROL")
	public static GMMap basvuruGirisRedKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			iMap.put("BASVURU_SONLANDIR", CreditCardServicesUtil.EVET);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL", iMap));
			if (CreditCardServicesUtil.EVET.equals(oMap.getString("DEVAM"))) {
				oMap.put("BASVURU_GIRIS_RED_KONTROL_SONUC", CreditCardServicesUtil.EVET);
				oMap.put("BASVURU_GIRIS_RED_KONTROL_MESAJ", "Islem Basarili");
			} else {
				oMap.put("BASVURU_GIRIS_RED_KONTROL_SONUC", CreditCardServicesUtil.HAYIR);
				oMap.put("BASVURU_GIRIS_RED_KONTROL_MESAJ", "Islem Iptal");
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * Verilen TC kimlik numarasinin KPS sistemi sorgusunu gerceklestirir.<br>
	 * Sorgu Sonucunda KPS sisteminden kimlik bilgileri alinir.<br>
	 * 
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TCK_NO - TC Kimlik Numarasi
	 *        <li>KPS_JOB_AKTIF_MI - KPSde hata alinirsa joba dussun mu? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonucu (0:Islem Basarisiz|2:Islem Basarili)
	 *        <li>RESPONSE_DATA - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3870_KPS_SORGULA")
	public static GMMap kpsSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kpsYapildi = CreditCardServicesUtil.HAYIR;
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		
		
		// KPS Sorgusu Yap - get kimlik sorgu info
		iMap.put("TCKNO", iMap.getString("TCK_NO"));
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_SORGULAMA", iMap));

		// KPS Sorgu Sonucunu Kontrol Et
		if (StringUtils.isNotBlank(iMap.getString("TCKNO_OUT"))) { // Sorgu Basarili
			// Kimlik Dogrulama Bilgilerini Al - get kimlik dogrulama info
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_DOGRULAMA", iMap));

			// Kimlik Kayip mi Sorgusu Yap - get kimlik kayip sorgu info
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));

			// Olum Durumunu Kontrol Et - Olmusse Hata Ver
			String olumTarihi = iMap.getString("OLUM_TARIHI");
			if (StringUtils.isNotBlank(olumTarihi)) {
				String errorMessage = null;
				if (olumTarihi.length() >= 8) {
					errorMessage = olumTarihi.substring(6, 8) + "/" + olumTarihi.substring(4, 6) + "/" + olumTarihi.substring(0, 4);
				}
				iMap.put("MESSAGE_NO", new BigDecimal(918));
				iMap.put("P1", errorMessage);
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}

			// TCKN Durumunu Kontrol Et - Uygun Degilse Hata Ver
			else if (!"1".equals(iMap.getString("DURUMU"))) {
				iMap.put("MESSAGE_NO", new BigDecimal(2087));
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			kpsYapildi = CreditCardServicesUtil.EVET;
		} else {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			// Sorgu Basarisizsa ve toplu ba�vuru de�ilse Islem Kesilir ve KPS yapilacak durumunda tablolara kayit atilir
			if ("E".equals(iMap.getString("KPS_JOB_AKTIF_MI"))) {
				// Basvuruyu Kaydet
				GMMap saveMap = new GMMap();
				saveMap.put("TRX_NO", iMap.getString("TRX_NO"));
				saveMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
				saveMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
				saveMap.put("DURUM_KOD", "KPS_JOB");
				saveMap.put("BASVURU_TARIHI", iMap.get("TODAY"));

				String cepNo = iMap.getString("CEP_NO");
				if (StringUtils.isNotBlank(cepNo) && cepNo.length() >= 3) {
					saveMap.put("CEP_TEL_KOD", cepNo.substring(0, 3));
				}

				if (StringUtils.isNotBlank(cepNo) && cepNo.length() >= 10) {
					saveMap.put("CEP_TEL_NO", cepNo.substring(3, 10));
				}
				//Save
				saveMap.put("IS_CONTROL_REQUIRED", "N");  // to eliminate db field controls totally
				GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_KIMLIK", saveMap); // save kimlik info
				
				//Tarihce Kaydi Olustur. BASVURU_NO, TRX_NO zaten var.
				if (!"KPS_JOB".equals(iMap.getString("DURUM_KOD"))) {
					saveMap.put("ISLEM_KODU", "BASVURU");
					saveMap.put("DURUM_KODU", "BASVURU");
					saveMap.put("ISLEM_SONRASI_DURUM_KODU", "KPS_JOB");
					saveMap.put("YENI_KAYIT_MI", "E");
					GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", saveMap);
				}
			}
		}
		
		oMap.put("UYRUK_KOD", "TR");
		oMap.put("TC_KIMLIK_NO", iMap.get("TCKNO_OUT"));
		oMap.put("ADI", iMap.get("AD1"));
		oMap.put("IKINCI_ADI", iMap.get("AD2"));
		oMap.put("SOYADI", iMap.get("SOYAD"));
		oMap.put("DOGUM_YERI", iMap.get("DOGUM_YERI"));
		oMap.put("DOGUM_TARIHI", iMap.get("DOGUM_TARIHI"));
		oMap.put("BABA_ADI", iMap.get("BABA_AD"));
		oMap.put("KIMLIK_SERI_NO_KPS", iMap.get("KIMLIK_SERI_NO"));
		oMap.put("KIMLIK_SIRA_NO_KPS", iMap.get("KIMLIK_SIRA_NO"));
		oMap.put("ANNE_ADI", iMap.get("ANNE_AD"));
		oMap.put("ONCEKI_SOYAD", iMap.get("KIZLIK_SOYAD"));
		oMap.put("NUFUS_IL_KOD", iMap.get("IL_KODU"));
		oMap.put("NUFUS_ILCE_KOD", iMap.get("ILCE_KODU"));
		oMap.put("NUFUS_CILT_NO", iMap.get("CILT_KODU"));
		oMap.put("NUFUS_AILE_SIRA_NO", iMap.get("AILE_SIRA_NO"));
		oMap.put("NUFUS_SIRA_NO", iMap.get("BIREY_SIRA_NO"));
		oMap.put("NUFUS_VERILIS_TARIHI", iMap.get("VERILIS_TARIHI"));
		oMap.put("CINSIYET", iMap.getString("CINSIYET").substring(0,1));
		oMap.put("MEDENI_HAL", "E".equals(iMap.getString("MEDENI_HALI").substring(0,1))?1:2);
		oMap.put("KAYIP_CUZDAN_NO", iMap.get("KAYIP_CUZDAN_NO"));
		oMap.put("KAYIP_CUZDAN_SERI", iMap.get("KAYIP_CUZDAN_SERI"));
		oMap.put("NUF_VERILDIGI_YER", iMap.get("VERILDIGI_ILCE_ADI"));
		oMap.put("NUF_VERILIS_NEDENI", iMap.get("VERILIS_NEDENI"));
		oMap.put("ES_TCKN", iMap.get("ES_TCKN"));
		oMap.put("NUFUS_MAHALLE", iMap.get("MAHALLE_KOY"));
		oMap.put("KPS_YAPILDI", kpsYapildi);
		
		return oMap;
	}

	/**
	 * Verilen TC kimlik numarasinin KPS sistemi sorgusunu gerceklestirdikten sonra alinan bilgilerle
	 * basvuruyu kaydeder.
	 * 
	 * @param iMap
	 *            - Basvuru Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3870_SAVE_BASVURU_BILGI")
	public static GMMap saveBasvuruBilgisi(GMMap iMap) {
		GMMap oMap=new GMMap();
		try{
		// Kanal Bilgisini Yoksa Al
		if (StringUtils.isBlank(iMap.getString("KANAL_KOD"))) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
		}

		// Kaydedilecek Bilgileri Al
		GMMap saveMap = new GMMap();
		saveMap.put("TRX_NO", iMap.getString("TRX_NO"));
		saveMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
		saveMap.put("BASVURU_TARIHI", iMap.get("TODAY"));
		saveMap.put("KANAL_KOD", iMap.getString("KANAL_KOD"));
		saveMap.put("BAYI_KOD", iMap.getString("BAYI_KOD"));
		saveMap.put("DURUM_KOD", "ON_BASVURU");
		saveMap.put("OGRENIM_DURUMU", iMap.getString("OGRENIM_DURUMU"));
		saveMap.put("AYLIK_GELIR", iMap.getBigDecimal("AYLIK_GELIR"));
		saveMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
		saveMap.put("ADI", iMap.getString("AD1"));
		saveMap.put("IKINCI_ADI", iMap.getString("AD2"));
		saveMap.put("SOYADI", iMap.getString("SOYAD"));
		saveMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
		saveMap.put("DOGUM_TARIHI", iMap.getString("DOGUM_TARIHI"));
		saveMap.put("BABA_ADI", iMap.getString("BABA_AD"));
		saveMap.put("KIMLIK_SERI_NO_KPS", iMap.getString("KIMLIK_SERI_NO_KPS"));
		saveMap.put("KIMLIK_SIRA_NO_KPS", iMap.getString("KIMLIK_SIRA_NO_KPS"));
		saveMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
		saveMap.put("KIMLIK_SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
		saveMap.put("ANNE_ADI", iMap.getString("ANNE_AD"));
		saveMap.put("NUFUS_IL_KOD", iMap.getString("IL_KODU"));
		saveMap.put("NUFUS_ILCE_KOD", iMap.getString("ILCE_KODU"));
		saveMap.put("NUFUS_CILT_NO", iMap.getString("CILT_KODU"));
		saveMap.put("NUFUS_AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
		saveMap.put("NUFUS_SIRA_NO", iMap.getString("BIREY_SIRA_NO"));
		saveMap.put("NUFUS_VERILIS_TARIHI", iMap.getString("VERILIS_TARIHI"));
		saveMap.put("KAYIP_CUZDAN_NO", iMap.getString("KAYIP_CUZDAN_NO"));
		saveMap.put("KAYIP_CUZDAN_SERI", iMap.getString("KAYIP_CUZDAN_SERI"));
		saveMap.put("KPS_YAPILDI", "E");
		saveMap.put("NUF_VERILDIGI_YER", iMap.getString("VERILDIGI_ILCE_ADI"));
		saveMap.put("NUF_VERILIS_NEDENI", iMap.getString("VERILIS_NEDENI"));
		saveMap.put("APS_YAPILDIMI", iMap.getString("APS_YAPILDIMI"));
		saveMap.put("ES_TCKN", iMap.getString("ES_TCKN"));
		saveMap.put("NUFUS_MAHALLE", iMap.getString("MAHALLE_KOY"));
		saveMap.put("KREDI_KARTI_SEVIYESI", "K"); // default asil kart
		saveMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
		saveMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
		saveMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
		saveMap.put("TESLIMAT_ADRESI", iMap.getString("TESLIMAT_ADRESI"));
		saveMap.put("EV_IL", iMap.getString("EV_IL"));
		saveMap.put("EV_ILCE", iMap.getString("EV_ILCE"));
		saveMap.put("EV_ADRESI", iMap.getString("EV_ADRESI"));
		saveMap.put("IS_IL", iMap.getString("IS_IL"));
		saveMap.put("IS_ILCE", iMap.getString("IS_ILCE"));
		saveMap.put("IS_ADRESI", iMap.getString("IS_ADRESI"));
		saveMap.put("SUBE_KOD", iMap.getString("SUBE_KOD"));
		
		saveMap.put("KART_UZERINDEKI_ISIM", iMap.getString("KART_UZERINDEKI_ISIM"));
		saveMap.put("KART_LIMITI", iMap.getString("KART_LIMITI"));
		saveMap.put("NAKIT_KART_LIMITI", iMap.getString("NAKIT_KART_LIMITI"));
		saveMap.put("EKSPRESS_KART_LIMITI", iMap.getString("EKSPRESS_KART_LIMITI"));
		saveMap.put("KART_URUN_TIP", iMap.getString("KART_URUN_TIP"));
		saveMap.put("KREDI_KARTI_EKSTRE_TIPI_EMAIL", iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
		saveMap.put("KREDI_KARTI_EKSTRE_TIPI_POSTA", iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
		saveMap.put("KREDI_KARTI_EKSTRE_TIPI_SMS", iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
		saveMap.put("KREDI_KARTI_EKSTRE_SECIMI", iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
		saveMap.put("YURT_DISI_EKSTRE_TIP", iMap.getString("YURT_DISI_EKSTRE_TIP"));
		saveMap.put("HESAP_KESIM_TARIHI", iMap.getString("HESAP_KESIM_TARIHI"));
		saveMap.put("KART_OTOMATIK_ODEME", iMap.getString("KART_OTOMATIK_ODEME"));
		saveMap.put("OTOMATIK_LIMIT_ARTIS", iMap.getString("OTOMATIK_LIMIT_ARTIS"));
		saveMap.put("EK_KART_VAR_MI", iMap.getString("EK_KART_VAR_MI"));
		saveMap.put("MUSTERI_GROUP", iMap.getString("MUSTERI_GROUP"));
		saveMap.put("MUSTERI_TIPI", iMap.getString("MUSTERI_TIPI"));
		saveMap.put("FINANSAL_TIP", iMap.getString("FINANSAL_TIP"));
		saveMap.put("LOGO_KODU", iMap.getString("LOGO_KODU"));
		saveMap.put("EMAIL", iMap.getString("EMAIL"));
		saveMap.put("SESSION_IP", iMap.getString("SESSION_IP"));
		saveMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD", "90"));
		saveMap.put("CEP_TEL_KOD", iMap.getString("CEP_TEL_KOD"));
		saveMap.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
		saveMap.put("KDH_ISTIYOR_MU", iMap.getString("KDH_ISTIYOR_MU"));
		
		String cinsiyet = iMap.getString("CINSIYET");
		if (StringUtils.isNotBlank(cinsiyet)) {
			saveMap.put("CINSIYET", cinsiyet.substring(0, 1));
		}

		String medeniHali = iMap.getString("MEDENI_HALI");
		if (StringUtils.isNotBlank(medeniHali)) {
			medeniHali = medeniHali.trim();
			if ("1".equals(medeniHali) || "2".equals(medeniHali)) {
				saveMap.put("MEDENI_HAL", medeniHali);
			} else {
				if ("E".equals(medeniHali.substring(0, 1))) {
					saveMap.put("MEDENI_HAL", "1");
				} else {
					saveMap.put("MEDENI_HAL", "2");
				}
			}
		}
		
		// Kaydet
		if("E".equals(iMap.getString("TFF_KK"))) {
			saveMap.put("DURUM_KOD", "NBSM");
			GMServiceExecuter.executeNT("BNSPR_TRN3871_TFF_SAVE_KIMLIK", saveMap);
		} else {
			GMServiceExecuter.executeNT("BNSPR_TRN3871_SAVE_KIMLIK", saveMap);
		}
			
		
		// SMS Basvurularinda Ikinci Sayfa Kullanilmaz.
		iMap.put("IS_FIRST_PAGE", "Y");
			
		saveMap.put("YENI_KAYIT_MI", "E");
		GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", iMap);

		}
		catch(Exception e){
			oMap.put("SAVE_KIMLIK_SONUC", CreditCardServicesUtil.HAYIR);
			oMap.put("SAVE_KIMLIK_MESAJ", e.getMessage());
		}
		return oMap;
	}

	/**
	 * Verilen TC kimlik numarasinin KPS sistemi sorgusunu gerceklestirdikten sonra alinan bilgilerle
	 * kontakt musteri kaydi olusturur.
	 * 
	 * @param iMap
	 *            - Kontakt Musteri Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3870_SAVE_KONTAKT_MUSTERI_BILGI")
	public static void saveKontaktMusteriBilgisi(GMMap iMap) {
		// Kaydedilecek Bilgileri Al
		GMMap saveMap = new GMMap();
		saveMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
		saveMap.put("ADI", iMap.getString("AD1"));
		saveMap.put("SOYADI", iMap.getString("SOYAD"));
		saveMap.put("ANNE_ADI", iMap.getString("ANNE_AD"));
		saveMap.put("BABA_ADI", iMap.getString("BABA_AD"));
		saveMap.put("IKINCI_ADI", iMap.getString("AD2"));
		saveMap.put("CINSIYET", iMap.getString("CINSIYET"));
		saveMap.put("MEDENI_HAL", iMap.getString("MEDENI_HALI"));
		saveMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
		saveMap.put("IL_KODU", iMap.getString("IL_KODU"));
		saveMap.put("ILCE_KODU", iMap.getString("ILCE_KODU"));
		saveMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
		saveMap.put("KIMLIK_SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
		saveMap.put("NUFUS_VERILIS_TARIHI", iMap.getString("VERILIS_TARIHI"));
		saveMap.put("NUF_VERILIS_NEDENI", iMap.getString("VERILIS_NEDENI"));
		saveMap.put("NUF_VERILDIGI_YER", iMap.getString("VERILDIGI_ILCE_ADI"));
		saveMap.put("NUFUS_CILT_NO", iMap.getString("CILT_KODU"));
		saveMap.put("NUFUS_AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
		saveMap.put("NUFUS_SIRA_NO", iMap.getString("BIREY_SIRA_NO"));
		saveMap.put("NUFUS_MAHALLE", iMap.getString("MAHALLE_KOY"));
		saveMap.put("KANAL_ALT_KOD", iMap.getString("KANAL_ALT_KOD"));
		saveMap.put("TCKNO_IN", iMap.getString("TCK_NO"));
		saveMap.put("TCKNO_OUT", iMap.getString("TCK_NO"));
		String cepNo = iMap.getString("CEP_NO");
		if (StringUtils.isNotBlank(cepNo) && cepNo.length() >= 3) {
			saveMap.put("CEP_TEL_KOD", cepNo.substring(0, 3));
		}

		if (StringUtils.isNotBlank(cepNo) && cepNo.length() >= 10) {
			saveMap.put("CEP_TEL_NO", cepNo.substring(3, 10));
		}

		// Kaydet
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_KONTAK_MUSTERI_GERCEK", saveMap));
	}

	/**
	 * Basvuruyu APS sorgusu yapildi olarak guncelle
	 * 
	 * @param iMap
	 *            - <li>TRX_NO : Transaciton No <li>APS_YAPILDIMI : APS Sorgu Durumu
	 */
	@GraymoundService("BNSPR_TRN3870_UPDATE_APS_INFO")
	public static GMMap updateApsInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			KkBasvuruKimlikTx kkBasvuruKimlikTx = (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (kkBasvuruKimlikTx != null) {
				kkBasvuruKimlikTx.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
				session.saveOrUpdate(kkBasvuruKimlikTx);
				session.flush();
			}
		}
		catch (Exception e) {			
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3870 Ekrani
	//---------------------------------------------------------------------
	/** Kredi karti kisa basvuru giris ekrani acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>TODAY - Anlik basvuru zamani
	 *         <li>CINSIYET_LIST - Cinsiyet degerleri listesi
	 *         <li>MEDENI_HAL_LIST - Medeni hal degerleri listesi
	 *         <li>KANAL_KOD - Kanal kodu
	 *         <li>KANAL_ALT_KOD - Kanal alt kodu
	 *         <li>SUBE_KOD - Sube kodu
	 *         <li>KREDI_KARTI_SEVIYESI_LIST_IZLEME - Basvurusu izlenebilecek Kredi karti basvuru turleri
	 *         <li>KREDI_KARTI_SEVIYESI_LIST_GIRIS - Basvurusu girilebilecek Kredi karti basvuru turleri
	 *         <li>KREDI_KARTI_SEVIYESI_LIST_EDIT - Basvurusu guncellenebilecek Kredi karti basvuru turleri
	 */
	@GraymoundService("BNSPR_TRN3870_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Gunun tarihi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_CURRENT_TIME", iMap));
			//Cinsiyet
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_CINSIYET_TURLERI", iMap));
			//Medeni hal
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_MEDENI_HAL_TURLERI", iMap));
			//Kanal kod
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			//Kanal alt kod
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD", iMap));
			//Sube kod
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_SUBE_KOD", iMap));
			//Kart seviyesi - Izleme
			oMap.putAll(CreditCardServicesUtil.getParameterListByKey("KREDI_KARTI_SEVIYESI_LIST_IZLEME", 
					"KREDI_KART_SEVIYESI_KOD", "E", "I"));
			//Kart seviyesi - Giris
			oMap.putAll(CreditCardServicesUtil.getParameterListByKey("KREDI_KARTI_SEVIYESI_LIST_GIRIS",
					"KREDI_KART_SEVIYESI_KOD", "E", "G"));
			//Kart seviyesi - Guncelleme
			oMap.putAll(CreditCardServicesUtil.getParameterListByKey("KREDI_KARTI_SEVIYESI_LIST_EDIT",
					"KREDI_KART_SEVIYESI_KOD", "E", "E"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Kredi karti kisa basvuru giris isleminin alan kontrollerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since PY -
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3870_AFTER_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3870.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Alinan bilgilerle aktif nokta tff basvuru kaydini olusturur/gunceller.<br>
	 * @author murat.el
	 * @since PY-
	 * @see {@link #saveBasvuru(GMMap)} - Basvuru temel bilgisi
	 * @see {@link #saveKimlik(GMMap)} - KPSden alinan kimlik bilgisi
	 * @see {@link #saveTelefon(GMMap)} - Cep telefonu bilgisi
	 * @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3871Services#saveEsBilgileri(GMMap)} - Es bilgisi
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3870_SAVE")
	public static GMMap saveKisaBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Basvuru bilgilerini kaydet
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_BASVURU", iMap));
			//Kimlik bilgilerini kaydet
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_KIMLIK", iMap));
			//Meslek bilgilerini kaydet
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_MESLEK", iMap));
			//Cep telefonu bilgisini kaydet: CEP_TEL_KOD, CEP_TEL_NO,
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "E");//Tx alanina eklenecek, basvurda guncellenecek. Pakette
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TELEFON_TIPI", "C");//Cep tel
			sorguMap.put("ULKE_KOD", iMap.get("CEP_ULKE_KOD"));
			sorguMap.put("ALAN_KOD", iMap.get("CEP_TEL_KOD"));
			sorguMap.put("NUMARA", iMap.get("CEP_TEL_NO"));
			sorguMap.put("ILETISIM_MI", iMap.get("ILETISIM_MI"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_TELEFON", sorguMap));
			//Esi varsa es bilgilerini alarak kaydet
            if (StringUtils.isNotBlank(iMap.getString("ES_TCKN"))) {
            	sorguMap.clear();
            	sorguMap.put("ES_TCKN",iMap.get("ES_TCKN"));
            	sorguMap.put("TRX_NO",iMap.get("TRX_NO"));
            	sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
	            GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_ES_BILGILERI", sorguMap);
            }
            
            //Kaydedilen bilgiler gecerli mi?
            sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_AFTER_CONTROL", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle kredi karti kisa basvuru kontrollerini yaptiktan sonra 
	 * NBSM sorgularini yaparak basvuruyu gunceller.<br>
	 * @author murat.el
	 * @since PY-
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *        <li>TRX_NO - Kredi karti islem numarasi
	 *        <li>TC_KIMLIK_NO - BAsvuru sahibi kimlik numarasi
	 *        <li>KREDI_KARTI_SEVIYESI - Kredi karti basvurusunun hangi amacla yapildigi
	 *        <li>BASVURU_SONLANDIR - Capraz kontrol sonucunda basvuru sonlandirilsin mi? (E:Evet|H:Hayir)
	 *        <li>ISLEM_SONLANDIR - Islem sonucunda basvuru sonlandirilsin mi? (E:Evet|H:Hayir)
	 *        <li>HATA_VERILECEK_MI - Aktif kredi karti varsa hata verilsin mi? (E:Evet|H:Hayir)
	 *        <li>APS_YAPILDI_MI - Yapilmis APS sorgusu var mi? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu
	 *        <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 *        <li>MUSTERI_NO - Olusturulan/Guncellenen musteri numarasi
	 *        <li>APS_YAPILDI_MI - APS sorgusu yapildi mi? (E:Evet|H:Hayir)
	 *        <li>NBSM_HATASI_MI - NBSM sirasinda hata lindi mi? (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3870_DEVAM")
	public static GMMap devam(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial map
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		oMap.put("RESPONSE_DATA", StringUtils.EMPTY);

		try {
			//Basvuru Kontrol Islemleri
			//--
			//Basvuruya ait tamamlanan islem var mi? Varsa hata ver ve devam etme.
			//Ekrandan bir basvurunun ayni anda alinma durumunda/tamamlanan islemle 
			//devam edilme durumunda olmasi kontrol edildi
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("HATA_VERILECEK_MI", iMap.getString("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_3871_BASVURU_ISLENSIN_KONTROL", sorguMap));
			//Kontrol
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("HATA_MESAJI"));
				return oMap;
			}
			
			//Aktif basvurusu var mi? Varsa hata ver
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("BASVURU_SONLANDIR", iMap.getString("BASVURU_SONLANDIR", CreditCardServicesUtil.HAYIR));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
				return oMap;
			}
			
			//Daha once ayni tckn ye ait son 20 gunde red olan basvuru var mi? Varsa basvuruyu sonlandir
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("BASVURU_SONLANDIR", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
				return oMap;
			}
			
			//Mevcutta kullanilan aktif kredi karti var mi? Varsa basvuru iptal edilir.
			if ("K".equals(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_SEVIYESI"), "K"))) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("MUST_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
				sorguMap.put("HATA_VERILECEK_MI", iMap.getString("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KART_VAR_MI", sorguMap));
				if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
					oMap.put("RESPONSE_DATA", sorguMap.get("KART_VAR_HATA_MESAJI"));
					return oMap;
				}
			}
			
			//Basvuru APS/Musteri Islemleri
			//--
			//Aps bilgisi sorgula, sorgulama sonucunu basvuru ustunde guncelle
			if (CreditCardServicesUtil.HAYIR.equals(iMap.getString("APS_YAPILDI_MI", CreditCardServicesUtil.HAYIR))) {
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", sorguMap));
				logger.debug("APS sonucu : {}", sorguMap.getString("APS_YAPILDIMI"));
				oMap.put("APS_YAPILDI_MI", sorguMap.getString("APS_YAPILDIMI"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_UPDATE_APS_INFO", sorguMap));
			}
			
			//Kontakt musteri olustur, olusturulan musteri bilgisini kaydet
		    //Musteri bilgisi var mi?
			boolean musteriVarMi = false;
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
			if (StringUtils.isNotBlank(sorguMap.getString("CUSTOMER_NO")) &&
					BigDecimal.ZERO.compareTo(sorguMap.getBigDecimal("CUSTOMER_NO")) < 0) {
				musteriVarMi = true;
				oMap.put("MUSTERI_NO", sorguMap.get("CUSTOMER_NO"));
			}
			////Musteri varsa on onayli basvuruda guncellenmez, yoksa olusturulur.
			if (!musteriVarMi || "K".equals(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_SEVIYESI"), "K"))) {
				sorguMap.clear();
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("ISLEM_KODU", ISLEM_KODU_KISA_BASVURU);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_MUSTERI_BY_BASVURU", sorguMap));
				logger.debug("Musteri no : {}", sorguMap.getString("MUSTERI_NO"));
				oMap.put("MUSTERI_NO", sorguMap.getString("MUSTERI_NO"));
				// Kontakt Musteri Bilgisini Guncelle
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("MUSTERI_NO", sorguMap.get("MUSTERI_NO"));
				sorguMap.put("MUSTERI_YARATMA_TX_NO", sorguMap.get("MUSTERI_YARATMA_TX_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_UPDATE_MUSTERI_NO", sorguMap));
			}
			
			//Tarihceye NBSMe gonderildi kaydi at
			sorguMap.clear();
			sorguMap.put("ISLEM_KODU", "BASVURU");
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("DURUM_KODU", "BASVURU");
			sorguMap.put("ISLEM_SONRASI_DURUM_KODU", "NBSM");
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("BAS_TARIHI", Calendar.getInstance().getTime());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", sorguMap));

			//NBSM Sorgusu
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("MUSTERI_NO", oMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_DEVAM_SORGULAR", sorguMap));
			//Kontrol
			oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
			oMap.put("NBSM_HATASI_MI", sorguMap.getString("NBSM_HATASI_MI"));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("NBSM_HATASI_MI", CreditCardServicesUtil.HAYIR))) {
					//Islem kendi icinde tamamlandi:RED/IPTAL/FRAUD
					return oMap;
				} else {//Durum NBSM
					//Islemi tamamla
					sorguMap.clear();
					sorguMap.put("TRX_NAME", ISLEM_KODU_KISA_BASVURU);
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					if (CreditCardServicesUtil.HAYIR.equals(iMap.getString("ISLEM_SONLANDIR", CreditCardServicesUtil.HAYIR))) {
						sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION_TEMP", sorguMap));
					} else {
						sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", sorguMap));
					}
				}
			//Basvurunun tamamlanma islemi devam edecek.
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
				sorguMap.clear();
				sorguMap.put("TRX_NAME", ISLEM_KODU_KISA_BASVURU);
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				if (CreditCardServicesUtil.HAYIR.equals(iMap.getString("ISLEM_SONLANDIR", CreditCardServicesUtil.HAYIR))) {
					sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION_TEMP", sorguMap));
				} else {
					sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", sorguMap));
				}
			}
		}
		catch (Exception e) {
			logger.info("Kisa Basvuru Hata : " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Basvuru bilgilerini verilen basvuru ya da islem numarasina gore listeler.<br>
	 * @author murat.el
	 * @since PY-
	 * @param iMap - Basvuru sorgu bilgileri<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *        <li>TRX_NO - Kredi karti islem numarasi
	 * @return oMap - Basvuru bilgileri<br>
	 */
	@GraymoundService("BNSPR_TRN3870_GET_BASVURU")
	public static GMMap getBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3870.get_basvuru_info(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	//Basvuru Bilgileri, IS_FULL_SAVE, IS_FIRST_PAGE, ACTION, MUSTERI_GUNCELLENSIN_MI
	@GraymoundService("BNSPR_TRN3871_GONDER")
	public static GMMap gonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial map
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		oMap.put("RESPONSE_DATA", StringUtils.EMPTY);

		try {
			//Islem numarasi yoksa al
			if (iMap.get("TRX_NO") == null) {
				sorguMap.clear();
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap));
			}
			
			sorguMap.clear();
			sorguMap.putAll(iMap);
			GMServiceExecuter.executeNT("BNSPR_TRN3871_SAVE", sorguMap);
			
			sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("IS_FIRST_PAGE", iMap.get("IS_FIRST_PAGE"));
			GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", sorguMap);
			
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", sorguMap));
			oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
			//Kontrol
			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEVAM"))) {
				sorguMap.clear();
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap);
				
				//Kontakt musteri olustur, olusturulan musteri bilgisini kaydet
				if (CreditCardServicesUtil.EVET.equals(CreditCardServicesUtil.nvl(
						iMap.getString("MUSTERI_GUNCELLENSIN_MI"), CreditCardServicesUtil.HAYIR))) {
					sorguMap.clear();
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					sorguMap.put("ISLEM_KODU", "3871");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_MUSTERI_BY_BASVURU", sorguMap));
					logger.debug("Musteri no : {}", sorguMap.getString("MUSTERI_NO"));
					// Kontakt Musteri Bilgisini Guncelle
					if (iMap.get("MUSTERI_NO") == null) {
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("MUSTERI_NO", sorguMap.get("MUSTERI_NO"));
						sorguMap.put("MUSTERI_YARATMA_TX_NO", sorguMap.get("MUSTERI_YARATMA_TX_NO"));
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_UPDATE_MUSTERI_NO", sorguMap));
					}
				}
				//Butun islemler bitti ise islemi basarili olarak guncelle.
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle kredi karti kisa basvuru kontrollerini yaptiktan sonra 
	 * NBSM sorgularini yaparak basvuruyu gunceller.<br>
	 * @author murat.el
	 * @since PYKKBAS-297
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *        <li>TC_KIMLIK_NO - Basvuru sahibi kimlik numarasi
	 * @return oMap - Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu (0:Basvuru Kontrolden Gecemedi | 2:Basvuru Olusturulabilir)
	 *        <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3870_KONTROL")
	public static GMMap kontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial map
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		oMap.put("RESPONSE_DATA", StringUtils.EMPTY);

		try {
			//Aktif basvurusu var mi? Varsa hata ver
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("BASVURU_SONLANDIR", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
				return oMap;
			}
			
			//Daha once ayni tckn ye ait son 20 gunde red olan basvuru var mi? Varsa basvuruyu sonlandir
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("BASVURU_SONLANDIR", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
				return oMap;
			}
			
			//Mevcutta kullanilan aktif kredi karti var mi? Varsa basvuru iptal edilir.
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KART_VAR_MI", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("KART_VAR_HATA_MESAJI"));
				return oMap;
			}
		}
		catch (Exception e) {
			logger.info("Basvuru Kontrol Hata : " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	/** Verilen tckn gecerli mi<br>
	 * @author murat.el
	 * @since 
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>TC_KIMLIK_NO - Basvuru sahibi kimlik numarasi
	 *        <li>HATA_VERILSIN_MI - Hata verilecek mi? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu (0:Basarisiz | 2:Basarili)
	 *        <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3870_TCKN_KONTROL")
	public static GMMap tcknKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//TCKN validasyon
			//Zorunluluk kontrolu
			String tcKimlikNo = iMap.getString("TCKN").trim();
			if (StringUtils.isBlank(tcKimlikNo)) {
				CreditCardServicesUtil.raiseGMError("330", "Tc Kimlik No");
			}
			//Uzunluk kontrolu
			if (tcKimlikNo.length() != 11) {
				CreditCardServicesUtil.raiseGMError("2328");
			}
			//Format kontrolu - Yabanci mi
			if ("9".equals(tcKimlikNo.substring(0, 1))) {
				CreditCardServicesUtil.raiseGMError("1033");
			}
			//Format kontrolu - Digit
			GMMap sorguMap = new GMMap();
			sorguMap.put("TC_KIMLIK_NO", tcKimlikNo);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", sorguMap));
			if ("0".equals(sorguMap.getString("SONUC"))) {
				CreditCardServicesUtil.raiseGMError("456", tcKimlikNo);
			}
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}

}
