package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.axis.utils.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import org.apache.commons.codec.binary.Base64;

public class CreditCardQRY4414Services {
    private static Configurator conf = Configurator.createConfiguratorFromProperties (  "configuration/passolig-video-tutorials.properties" );
    
    @GraymoundService("BNSPR_QRY4414_INITIALIZE")
    public static GMMap fillInitialValues(GMMap iMap) {
	try {
	    return getVideoLinks();
	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	}

    }

    @GraymoundService("BNSPR_QRY4414_GONDER")
    public static GMMap qry4414Gonder(GMMap iMap) {
	try {
	    validateInputs(iMap);
	    return GMServiceExecuter.call("BNSPR_QRY4414_GONDER_" + iMap.getString("DELIVERY_TYPE"), iMap);
	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	}
    }
    
    public static GMMap validateInputs(GMMap iMap){
	String deliveryType = iMap.getString("DELIVERY_TYPE");
	String language = iMap.getString("LANGUAGE");
	String mail = iMap.getString("MAIL_TO");
	String cellular = iMap.getString("MSISDN");
	
	iMap.put("HATA_NO", "330");
	if (StringUtils.isEmpty(deliveryType)) {
	    iMap.put("P1", "G�NDER�M �EKL�");
	    return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	}else if (StringUtils.isEmpty(language)){
	    iMap.put("P1", "D�L");
	    return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	}else if ("MAIL".equals(deliveryType) && StringUtils.isEmpty(mail)) {
	    iMap.put("P1", "E-MAIL ADRES�");
	    return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	}else if ("SMS".equals(deliveryType) && StringUtils.isEmpty(cellular)) {
	    iMap.put("P1", "CEP TELEFONU");
	    return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	}else 
	    return iMap;
	    
	
    }

    @GraymoundService("BNSPR_QRY4414_GONDER_MAIL")
    public static GMMap qry4414GonderMail(GMMap iMap) {
	try {
	    setMail(iMap);
	    iMap = GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", iMap);
	    iMap.put("MESSAGE", "Mail G�nderildi");
	    return iMap;
	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	}

    }

    @GraymoundService("BNSPR_QRY4414_GONDER_SMS")
    public static GMMap qry4414GonderSms(GMMap iMap) {
	try {
	    setSms(iMap);
	    iMap = GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC" , iMap);
	    iMap.put("MESSAGE", "SMS G�nderildi");
	    return iMap;
	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	}

    }

    private static GMMap getVideoLinks() throws Exception {
	GMMap oMap = new GMMap();
	
	URL url = new URL(conf.getProperty("videos-url"));
	URLConnection connection = url.openConnection();
	
//	System.setProperty("http.proxyHost", "wcg2.aktifbank.com.tr");
//	System.setProperty("http.proxyPort", "8080");
//	
	String login = conf.getProperty("user") +":" +conf.getProperty("pass");
	byte[] encodedLoginBytes = Base64.encodeBase64(login.getBytes());
	String encodedLogin = new String(encodedLoginBytes);
	connection.setRequestProperty("Authorization", "Basic " + encodedLogin);
	
	Document document = parseVideoXML(connection.getInputStream());
	NodeList descNodes = document.getElementsByTagName("video");

	for (int i = 0; i < descNodes.getLength(); i++) {

	    Node nNode = descNodes.item(i);

	    if (nNode.getNodeType() == Node.ELEMENT_NODE) {

		Element eElement = (Element) nNode;

		oMap.put("RESULTS", i, "NAME", eElement.getElementsByTagName("videoName").item(0).getTextContent());
		oMap.put("RESULTS", i, "VALUE", eElement.getElementsByTagName("videoTextTr").item(0).getTextContent());
		oMap.put("RESULTS", i, "VALUE_EN", eElement.getElementsByTagName("videoTextEn").item(0).getTextContent());
		

	    }
	}
	
	return oMap;

    }

    private static Document parseVideoXML(InputStream stream) throws Exception {
	DocumentBuilderFactory Factory = null;
	DocumentBuilder Builder = null;
	Document doc = null;
	try {
	    Factory = DocumentBuilderFactory.newInstance();
	    Builder = Factory.newDocumentBuilder();

	    doc = Builder.parse(stream);
	} catch (Exception ex) {
	    throw ex;
	}

	return doc;
    }
    
    private static void setMail(GMMap iMap){
	iMap.put("MAIL_FROM", "aktifbank@aktifbank.com.tr");
	iMap.put("IS_BODY_HTML", "H");
	iMap.put("MAIL_SUBJECT", conf.getProperty("sms-header"));
	
	    if(StringUtils.isEmpty(iMap.getString("UNVAN")))
	iMap.put("MAIL_BODY", iMap.getString("TEXT"));
	    
	    else{
	iMap.put("MAIL_BODY", "EN".equals(iMap.getString("LANGUAGE")) ? 
		"Dear " +iMap.getString("UNVAN") + ", " +iMap.getString("TEXT") :
		"Say�n "+iMap.getString("UNVAN") + ", " +iMap.getString("TEXT"));
	}
    }
    
    private static void setSms(GMMap iMap){
	iMap.put("HEADER" , conf.getProperty("sms-header"));
	 if(StringUtils.isEmpty(iMap.getString("UNVAN")))
		iMap.put("CONTENT", iMap.getString("TEXT"));
		    
		    else{
		iMap.put("CONTENT", "EN".equals(iMap.getString("LANGUAGE")) ? 
			"Dear " +iMap.getString("UNVAN") + ", " +iMap.getString("TEXT") :
			"Say�n "+iMap.getString("UNVAN") + ", " +iMap.getString("TEXT"));
		    }
        iMap.put("FILTER" , true);
        iMap.put("SECURE_CONTENT" , true);
    }
}
