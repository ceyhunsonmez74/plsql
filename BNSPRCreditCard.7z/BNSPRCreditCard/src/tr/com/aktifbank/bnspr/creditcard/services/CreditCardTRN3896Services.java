package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TffBasvuruUrunFiyatTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruUrunFiyatTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3896Services {
	
	private static final String BANKA_EK_PAY_BEDELI_KOD = "B";
	private static final String IADE_BEDELI_KOD = "I";
	private static final String KART_BEDELI_KOD = "K";
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>TAKIM_LIST - Takim listesi
	 *         <li>KART_TIPI_LIST - Kart tipi listesi
	 */
	@GraymoundService("BNSPR_TRN3896_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Kulup
			String query = "SELECT kod, adi FROM BNSPR.urun_sahip WHERE aktif_mi = 'E' ORDER BY adi";
			DALUtil.fillComboBox(oMap, "TAKIM_LIST", true, query);
			
			//Kart Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			
			//Ucret Tipi
			GuimlUtil.wrapMyCombo(oMap, "UCRET_TIPI_LIST", "B", "Banka Ek Pay Bedeli");
			GuimlUtil.wrapMyCombo(oMap, "UCRET_TIPI_LIST", "I", "Iade Bedeli");
			
			//Cache Temizleme Linki
			oMap.put("PASSOLIG_CACHE_CLEAR_LINK", getCacheClearLink());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore istenilen sonuclari listeler<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>TAKIM - Takim kodu
	 *        <li>KART_TIPI - Kart tipi bilgisi
	 * @return Sorgu sonuclari<br>
	 *        <li>URUN_LIST - Verilen takim/kart bilgilerine ait urun listesi
	 */
	@GraymoundService("BNSPR_TRN3896_LIST_URUN")
	public static GMMap listUrun(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			query = "{? = call pkg_trn3896.listUrun(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("TAKIM"));
			stmt.setString(3, iMap.getString("KART_TIPI"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("URUN_ID"));
			stmt.execute();
			//Ekran formatina cevir
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "URUN_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore istenilen sonuclari listeler<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>TAKIM - Takim kodu
	 *        <li>KART_TIPI - Kart tipi bilgisi
	 * @return Sorgu sonuclari<br>
	 *        <li>URUN_LIST - Verilen takim/kart bilgilerine ait urun listesi
	 */
	@GraymoundService("BNSPR_TRN3896_LIST_FIYAT")
	public static GMMap listFiyat(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			query = "{? = call pkg_trn3896.listUrunFiyat(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("URUN_ID"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			//Ekran formatina cevir
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "FIYAT_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3896_SAKLA")
	public static GMMap sakla(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Variables
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String islemTipi = iMap.getString("ISLEM_TIPI");
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Varsa islem numarasina ait bilgiyi al
			List<?> txList = session.createCriteria(TffBasvuruUrunFiyatTx.class)
					.add(Restrictions.eq("id.txNo", trxNo))
					.list();
			//Daha once islem varsa temizle.
			if (txList != null && txList.size() > 0) {
				TffBasvuruUrunFiyatTx tx = null;
				for (Object o : txList) {
					tx = (TffBasvuruUrunFiyatTx) o;
					if (("URUN".equals(islemTipi) && KART_BEDELI_KOD.equals(tx.getId().getIslemTipi())) ||
						("FIYAT".equals(islemTipi) && !KART_BEDELI_KOD.equals(tx.getId().getIslemTipi()))) {
						session.delete(tx);
					}
				}
			}
			//Yeni bilgileri kaydet
			String tableName = null;
			if ("URUN".equals(islemTipi)) {
				tableName = "URUN_LIST";
			} else if ("FIYAT".equals(islemTipi)) {
				tableName = "FIYAT_LIST";
			}
			
			GMMap sorguMap = new GMMap();
			int siraNo = 0;
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				sorguMap.clear();
				if ("URUN".equals(islemTipi)) {
					if (iMap.getBigDecimal(tableName, i, "ONCEKI_KART_BEDELI").compareTo(iMap.getBigDecimal(tableName, i, "KART_BEDELI")) != 0 ||
							iMap.getBigDecimal(tableName, i, "ONCEKI_LOYALTY_BEDELI").compareTo(iMap.getBigDecimal(tableName, i, "LOYALTY_BEDELI")) != 0) {
						sorguMap.put("TRX_NO", trxNo);
						sorguMap.put("URUN_ID", iMap.get(tableName, i, "URUN_ID"));
						sorguMap.put("ISLEM_TIPI", KART_BEDELI_KOD);
						sorguMap.put("SIRA_NO", ++siraNo);//Ayni urune birden fazla fiyat olamaz
						sorguMap.put("KART_BEDELI", iMap.get(tableName, i, "KART_BEDELI"));
						sorguMap.put("LOYALTY_BEDELI", iMap.get(tableName, i, "LOYALTY_BEDELI"));
						sorguMap.put("TFF_SS_PRODUCT_MAP_ID", iMap.get(tableName, i, "TFF_SS_PRODUCT_MAP_ID"));
						saveOrUpdateUrunFiyatTx(sorguMap);
					}
				} else if ("FIYAT".equals(islemTipi)) {
					sorguMap.put("TRX_NO", trxNo);
					sorguMap.put("URUN_ID", iMap.get("URUN_ID"));
					sorguMap.put("ISLEM_TIPI", iMap.getString(tableName, i, "ISLEM_TIPI"));
					//Tutar
					if (BANKA_EK_PAY_BEDELI_KOD.equals(iMap.getString(tableName, i, "ISLEM_TIPI"))) {
						sorguMap.put("AKTIFBANK_EK_PAY", iMap.get(tableName, i, "TUTAR"));
					} else if (IADE_BEDELI_KOD.equals(iMap.getString(tableName, i, "ISLEM_TIPI"))) {
						sorguMap.put("TOPLAM_IADE_BEDELI", iMap.get(tableName, i, "TUTAR"));
					}
					//Sira No
					if (iMap.get("SIRA_NO") != null && iMap.getInt("SIRA_NO") > 0) {
						siraNo = iMap.getInt("SIRA_NO");
					} else {
						siraNo++;
					}
					sorguMap.put("SIRA_NO", siraNo);
					//Diger
					sorguMap.put("BASLANGIC_TARIHI", iMap.get(tableName, i, "BASLANGIC_TARIHI"));
					sorguMap.put("BITIS_TARIHI", iMap.get(tableName, i, "BITIS_TARIHI"));
					sorguMap.put("TFF_BASVURU_URUN_FIYAT_ID", iMap.get(tableName, i, "ID"));
					sorguMap.put("TFF_SS_PRODUCT_MAP_ID", iMap.get("TFF_SS_PRODUCT_MAP_ID"));
					saveOrUpdateUrunFiyatTx(sorguMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static void saveOrUpdateUrunFiyatTx(GMMap iMap) throws ParseException {
		//Session ac
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		//
		TffBasvuruUrunFiyatTxId id = new TffBasvuruUrunFiyatTxId();
		id.setTxNo(iMap.getBigDecimal("TRX_NO"));
		id.setIslemTipi(iMap.getString("ISLEM_TIPI"));
		id.setUrunId(iMap.getBigDecimal("URUN_ID"));
		id.setSiraNo(iMap.getBigDecimal("SIRA_NO"));
		//
		TffBasvuruUrunFiyatTx tx = (TffBasvuruUrunFiyatTx) session.createCriteria(TffBasvuruUrunFiyatTx.class)
				.add(Restrictions.eq("id", id))
				.uniqueResult();
		if (tx == null) {
			tx = new TffBasvuruUrunFiyatTx();
			tx.setId(id);
		}
		
		tx.setTffSsProductMapId(iMap.getBigDecimal("TFF_SS_PRODUCT_MAP_ID"));
		tx.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
		tx.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
		tx.setAktifbankEkPay(iMap.getBigDecimal("AKTIFBANK_EK_PAY"));
		tx.setToplamIadeBedeli(iMap.getBigDecimal("TOPLAM_IADE_BEDELI"));
		tx.setBaslangicTarihi(iMap.getDate("BASLANGIC_TARIHI"));
		tx.setBitisTarihi(iMap.getDate("BITIS_TARIHI"));
		tx.setTffBasvuruUrunFiyatId(iMap.getBigDecimal("TFF_BASVURU_URUN_FIYAT_ID"));
		
		session.saveOrUpdate(tx);
		session.flush();
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @param iMap - Islem bilgileri<br>
	 *        <li>P1
	 *        <li>P2
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3896_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", "3896");
			islemMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>P1
	 *         <li>P2
	 */
	@GraymoundService("BNSPR_TRN3896_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			query = "{call pkg_trn3896.getIslemInfo(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();
			//Ekran formatina cevir
			//Urun
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetResults(rSet, "URUN_LIST"));
			//Fiyat
			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetResults(rSet, "FIYAT_LIST"));
			//Takim
			oMap.put("TAKIM", CreditCardServicesUtil.nvl(oMap.getString("URUN_LIST", 0, "URUN_SAHIP_KOD"), oMap.getString("FIYAT_LIST", 0, "URUN_SAHIP_KOD")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static String getCacheClearLink() {
		String link = null;
		GMMap sorguMap = new GMMap();
		
		try {
			//Sistemi al, buna gore linki belirle
			String sistem = GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", sorguMap).getString("DATABASE_ADI");
			
			//Parametreden linki al
			sorguMap.clear();
			sorguMap.put("KOD", "TFF_CACHE_CLEAR_LINK");
			sorguMap.put("KEY1", sistem);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap));
			link = sorguMap.getString("TEXT");
			
			//Sha1 olarak keyi al
			sorguMap.clear();
			sorguMap.put("KOD", "TFF_CACHE_CLEAR_LINK");
			sorguMap.put("KEY1", "KEY");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap));
			String key = sorguMap.getString("TEXT");
			key += new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
			
			//Linke key ekle
			link += DigestUtils.shaHex(key);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return link;
	}


}
