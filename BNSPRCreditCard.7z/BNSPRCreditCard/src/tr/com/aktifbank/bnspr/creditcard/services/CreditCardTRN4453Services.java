package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.tool.hbm2x.StringUtils;

import tr.com.aktifbank.bnspr.dao.CrdKartDurumGecis;
import tr.com.aktifbank.bnspr.dao.CrdKartDurumTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4453Services {
	private static final Logger logger = Logger.getLogger(CreditCardTRN4453Services.class);
	private static final String KURYEDEN_IPTAL_STAT_CODE = "I";
	private static final String KURYEDEN_IPTAL_SUB_STAT_CODE = "K";
	private static final String KURYEDEN_IPTAL_CANCEL_CODE = "IK";
	private static final String GEREKCE_KOD_MUSTERI_IPTAL = "2";
	private static final String GEREKCE_KOD_OTOMATIK_IPTAL = "4";

	@GraymoundService("BNSPR_TRN4453_SAVE")
	public static GMMap trn4453_Save(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			// int size = iMap.getSize("LIST");
			// for(int i=0; i<size; i++){
			CrdKartDurumTx durum = new CrdKartDurumTx();
			durum.setTxNo(iMap.getBigDecimal("TRX_NO"));
			durum.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			durum.setAciklama(iMap.getString("ACIKLAMA"));
			// durum.setAltStatu(iMap.getString("ALT_STATU")); //
			durum.setKartNo(iMap.getString("CARD_NO"));
			// durum.setKartStatusu(iMap.getString("KART_STATU")); //
			durum.setKartTipi(iMap.getString("CARD_DCI"));
			// durum.setSkt(iMap.getBigDecimal("SKT")); //
			durum.setStatu(iMap.getString("STATU"));
			// durum.setUrunTipi(iMap.getString("URUN_TIPI"));//
			durum.setYenilemeTalebi(iMap.getString("KART_YENILEME_TALEBI"));
			durum.setTckn(iMap.getString("TCKN"));
			durum.setKaliciKapama(iMap.getString("KALICI_KAPAMA"));
			durum.setCancelReason(iMap.getString("CANCEL_REASON"));
			durum.setAltStatuZorunlu(iMap.getString("ALT_STATU_ZORUNLU"));
			durum.setIlkStatu(iMap.getString("ILK_STATU"));
			durum.setRol(iMap.getString("ROL"));
			session.saveOrUpdate(durum);

			// }
			session.flush();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("TRX_NAME", "4453");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN4453_GET_INFO")
	public static GMMap getInfoTRN4453(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		try {

			List<?> durumTx = session.createCriteria(CrdKartDurumTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			for (Object name : durumTx) {
				CrdKartDurumTx durum = (CrdKartDurumTx) name;
				oMap.put("TRX_NO", durum.getTxNo());
				oMap.put("ACIKLAMA", durum.getAciklama());
				// oMap.put("ALT_STATU", durum.getAltStatu());
				oMap.put("CARD_NO", durum.getKartNo());
				// oMap.put("KART_STATU", durum.getKartStatusu());
				oMap.put("CARD_DCI", durum.getKartTipi());
				oMap.put("MUSTERI_NO", durum.getMusteriNo());
				// oMap.put("SKT", durum.getSkt());
				oMap.put("STATU", durum.getStatu());
				// oMap.put("URUN_TIPI", durum.getUrunTipi());
				oMap.put("KART_YENILEME_TALEBI", durum.getYenilemeTalebi());
				oMap.put("TCKN", durum.getTckn());
				oMap.put("KALICI_KAPAMA", durum.getKaliciKapama());
				oMap.put("CANCEL_REASON", durum.getCancelReason());
				oMap.put("ALT_STATU_ZORUNLU", durum.getAltStatuZorunlu());
				oMap.put("ILK_STATU", durum.getIlkStatu());
				oMap.put("ROL", durum.getRol());

				i = i + 1;
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN4453_AFTER_APPROVAL")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap inMap = new GMMap();
		GMMap iptalMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		String date = sdf.format(new Date());
		String today = new String(date);

		CrdKartDurumTx durumTx = (CrdKartDurumTx) session.createCriteria(CrdKartDurumTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
		if (durumTx == null) {
			oMap.put("RESPONSE_DATA", "Girilen i�lem numaras� ile kay�t bulunamad�.");
			oMap.put("RESPONSE", "01");
			return oMap;
		}
		if ("true".equals(durumTx.getAltStatuZorunlu()) && durumTx.getCancelReason() == null) {
			throw new GMRuntimeException(44532, "Alt Statu se�imi zorunludur");
		}

		inMap.put("TCKN", durumTx.getTckn());
		inMap.put("CARD_NO", durumTx.getKartNo());
		inMap.put("STATUS", durumTx.getStatu());
		inMap.put("SUBSTATUS", durumTx.getAltStatu());
		inMap.put("EMBOSS_CODE", "true".equals(durumTx.getYenilemeTalebi()) ? "Y" : "N");
		inMap.put("DESCRIPTION", durumTx.getAciklama());
		inMap.put("CANCEL_CODE", durumTx.getAltStatu());
		inMap.put("KART_YENILEME_TALEBI", durumTx.getYenilemeTalebi());
		inMap.put("FREE_TEXT", durumTx.getYenilemeTalebi());
		inMap.put("MUSTERI_NO", durumTx.getMusteriNo());
		inMap.put("TRX_NO", durumTx.getTxNo());
		inMap.put("KART_STATU", durumTx.getKartStatusu());
		inMap.put("KALICI_KAPAMA", durumTx.getKaliciKapama());
		inMap.put("TARIH", today);
		inMap.put("ILK_STATU", durumTx.getIlkStatu());
		inMap.put("ROL", durumTx.getRol());

		if ("NN".equals(durumTx.getStatu())) {
			// if (SYSTEM_INTRACARD.equals(iMap.getString("SYSTEM"))){
			oMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_STATUS_CONTROL", inMap);
			// } else
			// if (SYSTEM_OCEAN.equals(iMap.getString("SYSTEM"))){
			// oMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_STATUS_CONTROL" , inMap);
			// } else{
			// throw new GMRuntimeException(44532 , "Card DCI yanl��t�r!");
			// }
			//
			if ("false".equals(StringUtils.lowerCase(oMap.getString("CARD_STATUS_CONTROL")))) {
				inMap.put("STATUS", "G");
				inMap.put("SUBSTATUS", "J");
				GMMap returnMap = kartStatuGuncelle(iMap, inMap, oMap, iptalMap);
				oMap.put("RETURN_DESCRIPTION", returnMap.getString("RETURN_DESCRIPTION") + " Kart Aktivasyonu Sa�lanmal�!");
				return oMap;
			}
		}

		return kartStatuGuncelle(iMap, inMap, oMap, iptalMap);

	}

	private static GMMap kartStatuGuncelle(GMMap iMap, GMMap inMap, GMMap oMap, GMMap iptalMap) {
		inMap.put("IS_4453", "E");
		boolean kartKapatildi = false;
		// if (SYSTEM_INTRACARD.equals(iMap.getString("SYSTEM"))){
		oMap = GMServiceExecuter.call("BNSPR_GENERAL_UPDATE_CARD_STATUS", inMap);
		if (oMap.getInt("RETURN_CODE") != OceanConstants.Result_Succesful) {
			throw new GMRuntimeException(1, oMap.getString("RETURN_DESCRIPTION"));
		}
		kartKapatildi = true;
		if ("true".equals(inMap.getString("KART_YENILEME_TALEBI"))) {

			if (oMap.get("NEW_CARD_NO") == null) {
				throw new GMRuntimeException(1, "Kart Statusu fakat Yeni Kart Numaras� d�n�lmedi! ");
			}
			GMMap muhasebeMap = new GMMap();
			muhasebeMap.put("TRX_NO", inMap.getBigDecimal("TRX_NO"));
			muhasebeMap.put("CARD_NO", inMap.getString("CARD_NO"));
			muhasebeMap.put("NEW_CARD_NO", oMap.getString("NEW_CARD_NO"));
			muhasebeMap.put("CUSTOMER_NO", inMap.getString("MUSTERI_NO"));
			muhasebeMap.put("TCKN", inMap.getString("TCKN"));
			GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST", muhasebeMap);

		}

		// } else
		// if (SYSTEM_OCEAN.equals(iMap.getString("SYSTEM"))){
		// oMap = GMServiceExecuter.call("BNSPR_OCEAN_UPDATE_CARD_STATUS" , inMap);
		// if (oMap.getInt("RETURN_CODE") != OceanConstants.Result_Succesful){
		// throw new GMRuntimeException(1 , oMap.getString("RETURN_DESCRIPTION"));
		// }
		// kartKapatildi = true;
		//
		// if ("true".equals(iMap.getString("KART_YENILEME_TALEBI"))){
		//
		// if (oMap.get("NEW_CARD_NO") == null){
		// throw new GMRuntimeException(1 , "Kart Statusu fakat Yeni Kart Numaras� d�n�lmedi! ");
		// }
		// GMMap muhasebeMap = new GMMap();
		// muhasebeMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
		// muhasebeMap.put("CARD_NO" , iMap.getString("CARD_NO"));
		// muhasebeMap.put("NEW_CARD_NO" , oMap.getString("NEW_CARD_NO"));
		// muhasebeMap.put("CUSTOMER_NO" , iMap.getString("MUSTERI_NO"));
		// muhasebeMap.put("TCKN" , iMap.getString("TCKN"));
		// GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST" , muhasebeMap);
		//
		// }
		// }
		// tabloda tut
		if ("true".equals(inMap.getString("KALICI_KAPAMA")) && "false".equals(inMap.getString("KART_YENILEME_TALEBI")) && kartKapatildi) {

			iptalMap.put("ISLEM_KOD", "4453");
			iptalMap.put("CARD_NO", inMap.getString("CARD_NO"));
			GMMap xMap = new GMMap();
			xMap = GMServiceExecuter.call("BNSPR_CARD_APPLICATON_CANCEL_WITHOUT_FEE", iptalMap);
			// tff ba�vuru

			String basvuru_bedeli_iade = "H";

			Session session = DAOSession.getSession("BNSPRDal");
			CrdKartDurumGecis statuObj = (CrdKartDurumGecis) session.createCriteria(CrdKartDurumGecis.class).add(Restrictions.eq("ilkDurum", inMap.getString("ILK_STATU"))).add(Restrictions.eq("yeniDurum", inMap.getString("STATUS"))).add(Restrictions.eq("rol", inMap.getString("ROL"))).uniqueResult();

			if (statuObj == null) {
				basvuru_bedeli_iade = "H";
			}
			else {

				basvuru_bedeli_iade = statuObj.getBasvuruBedeliIade();

			}
			String newReturnDescription = null;
			if ("E".equals(basvuru_bedeli_iade)) {
				newReturnDescription = oMap.getString("RETURN_DESCRIPTION") + " " + (xMap.get("MESSAGE") == null ? "" : xMap.getString("MESSAGE")) + " Kart�n ba�l� oldu�u ba�vurusu da iptal edilmi�tir. 4448 nolu ekrandan ba�vuru bedeli iade edilmelidir.";
			}
			else {
				newReturnDescription = oMap.getString("RETURN_DESCRIPTION") + " " + (xMap.get("MESSAGE") == null ? "" : xMap.getString("MESSAGE"));

			}

			oMap.put("RETURN_DESCRIPTION", newReturnDescription);

		}
		mailGonder(inMap);
		return oMap;
	}

	// �cret iadesi yapmadan TFF ve PASSO ba�vurular� iade eder.
	@GraymoundService("BNSPR_CARD_APPLICATON_CANCEL_WITHOUT_FEE")
	public static GMMap cancelApplication(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		GMMap cardInfoMap = new GMMap();
		oMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD"));
		boolean basvuruIptalMi = false;
		BigDecimal basvuruNo = null;
		BigDecimal customerNo = null;
		String dci = "";
		iMap.put("CARD_DCI", "All");
		String iptalAciklama = "";
		String iptalGerekceKod = "";
		Boolean isCancelledFromJob = iMap.getBoolean("IS_CANCELLED_FROM_JOB", false);

		try {
			// GMMap pMap = getCardProperties(iMap.getString("CARD_NO"));
			//
			// if (OceanConstants.Card_Source_Ocean.equals(pMap.getString("DESTINATION"))){
			//
			// cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , iMap);
			// }
			//
			// else if (OceanConstants.Card_Source_Intracard.equals(pMap.getString("DESTINATION"))){
			//
			// cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO" , iMap);
			// }
			// else
			// {
			// throw new GMRuntimeException(445310 , "CARD BIN ��z�lemedi!");
			// }

			cardInfoMap.putAll(GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", iMap));

			// CARD_DETAIL_INFO size'� s�f�rdan b�y�kse kart bulundu demek.
			// Kart DCI'�n D ve CARD_GROUP = 0 ise ( PASSO ) hi�bir�ey yapma ba�a�rl� gibi devam et.
			if (StringUtils.isNotEmpty(cardInfoMap.getString("CARD_DETAIL_INFO", 0, "APPLICATION_NO"))) {
				basvuruNo = cardInfoMap.getBigDecimal("CARD_DETAIL_INFO", 0, "APPLICATION_NO");
				customerNo = cardInfoMap.getBigDecimal("CARD_DETAIL_INFO", 0, "CUSTOMER_NO");

				dci = cardInfoMap.getString("CARD_DETAIL_INFO", 0, "CARD_DCI");

				// String isApplicationBasim = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn4453.is_applicationno_basim(?)}", Types.VARCHAR, basvuruNo);
				iMap.put("BASVURU_NO", basvuruNo);
				String urunTipi = null;

				if (OceanConstants.Card_Segment_BNK.equals(cardInfoMap.getString("CARD_DETAIL_INFO", 0, "SEGMENT"))) {
					urunTipi = "PASSO";
				}
				else if (OceanConstants.Card_Segment_TFF.equals(cardInfoMap.getString("CARD_DETAIL_INFO", 0, "CARD_GROUP"))) {
					urunTipi = "TFF";

				}
				else {
					throw new GMRuntimeException(44532, "Kart kapat�ld� fakat card group bulunamad���ndan ba�vuru kapat�lamad�.");
				}

				iptalAciklama = "Kart iptali sebebiyle otomatik ba�vuru iptali";
				
				if (kuryedenIptalmi(iMap.getString("STATUS"), iMap.getString("SUBSTATUS"), iMap.getString("CANCEL_CODE"))) {

					if (isCancelledFromJob) {
						iptalAciklama = "Maksimum S�rede Aksiyon Al�nmayan MTF Nedeniyle Iptal";
						iptalGerekceKod = GEREKCE_KOD_OTOMATIK_IPTAL;
					}
					else {
						iptalAciklama = "M��teri MTF Teslimat�n� Reddetti";
						iptalGerekceKod = GEREKCE_KOD_MUSTERI_IPTAL;
					}
				}
				iMap.put("URUN_TIPI", urunTipi);
				iMap.put("ACIKLAMA", iptalAciklama);
				iMap.put("KART_TIPI", "C".equals(dci) ? "KK" : dci);
				iMap.put("KART_NO", iMap.getString("CARD_NO"));
				iMap.put("MUSTERI_NO", customerNo);
				iMap.put("GEREKCE_KOD", iptalGerekceKod);

				oMap = GMServiceExecuter.call("BNSPR_TRN3809_KART_BASVURU_IPTAL", iMap);
				basvuruIptalMi = true;
			}

		}
		catch (Exception e) {
			if (!basvuruIptalMi) {

				throw new GMRuntimeException(445311, "Kart Kapat�ld�. Karta ait " + basvuruNo.toString() + " numaral� ba�vuru iptali i�lemi ba�ar�s�z. L�tfen 3817 ekran�ndan ba�vuruyu iptal ediniz");

			}
			else {
				throw e;
			}
		}
		return oMap;
	}

	public static GMMap getCardPropertiesFromBIN(String kartNo) {
		GMMap iMap2 = new GMMap();
		iMap2.put("CARD_NO", kartNo);
		GMMap cardProperty = new GMMap();
		cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap2);
		return cardProperty;
	}


	

	public static void mailGonder(GMMap inMap) {
		try {
			GMMap outMap = new GMMap();
			outMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_STATUS_LIST", inMap);
			String desc1 = "";
			String desc2 = "";
			String out1 = "";
			String out2 = "";
			for (int i = 0; i < outMap.getSize("STATUS_LIST"); i++) {
				if (inMap.getString("ILK_STATU").equals(outMap.getString("STATUS_LIST", i, "CODE"))) {
					desc1 = outMap.getString("STATUS_LIST", i, "DESCRIPTION");
					String[] output = desc1.split(";");
					String description1 = output[0];
					out1 = description1.substring(4);
					logger.info(out1);

				}
				if (inMap.getString("STATUS").equals(outMap.getString("STATUS_LIST", i, "CODE"))) {
					desc2 = outMap.getString("STATUS_LIST", i, "DESCRIPTION");
					String[] output2 = desc2.split(";");
					String description2 = output2[0];
					out2 = description2.substring(4);
					logger.info(out2);
				}
			}

			String mailTo = getGlobalParam("4453_MAIL_TO");
			GMMap servisMap = new GMMap();
			servisMap.put("FROM", "Aktifbank@aktifbank.com.tr");
			servisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(mailTo));
			servisMap.put("TRX_NO", inMap.getBigDecimal("TRX_NO"));
			servisMap.put("SUBJECT", "Kart Stat� G�ncelleme");
			servisMap.put("MESSAGE_BODY", getUser() + " " + inMap.getString("TARIH") + " " + " de" + " " + inMap.getString("CARD_NO") + " nolu kart�" + " " + out1 + " " + "stat�den" + " " + out2 + " " + "stat�s�ne ald�");
			servisMap.put("IS_BODY_HTML", true);

			GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	public static String getGlobalParam(String kod) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", kod);
		iMapG.put("TRIM_QUOTES", true);
		String deger = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return deger;
	}

	public static String getUser() {
		return (String) GMContext.getCurrentContext().getSession().get("USER_NAME");
	}

	private static boolean kuryedenIptalmi(String status, String subStatus, String cancelReasonCode) {
		if (KURYEDEN_IPTAL_STAT_CODE.equals(status) && KURYEDEN_IPTAL_SUB_STAT_CODE.equals(subStatus) && KURYEDEN_IPTAL_CANCEL_CODE.equals(cancelReasonCode))
			return true;
		else
			return false;
	}
}
