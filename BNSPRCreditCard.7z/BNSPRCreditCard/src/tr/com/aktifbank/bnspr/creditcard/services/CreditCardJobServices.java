package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.File;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.com.aktifbank.bnspr.dao.CrdRestrictions;
import tr.com.aktifbank.bnspr.dao.CrdTicketSaleTx;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.LksBildirim;
import tr.com.aktifbank.bnspr.dao.LksSorguislem;
import tr.com.aktifbank.bnspr.dao.LksislemBildirim;
import tr.com.aktifbank.bnspr.dao.ManuelLksBildirim;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.TffBasvuruBelgeId;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * Kredi Karti Basvuru Surecinde Kullanilacak Job Servisleri<br>
 * 
 * @author murat.el
 * @since 29/08/2013
 */
public class CreditCardJobServices {

	private static final int MAX_THREAD_SIZE = Runtime.getRuntime().availableProcessors() * 4;
	private static final int THREAD_SIZE = 4;

	// Logger Tanimi
	private static final Logger logger = LoggerFactory.getLogger(CreditCardJobServices.class);

	// Cons Tanimlamalari
	private static final String RESULTS = "RESULTS";
	private static final String JOB_NAME = "JOB_NAME";
	private static final String KART_SEVIYESI_LIMIT = "L";
	private static final String FILES_FOLDER = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root" + File.separator + "files" + File.separator;

	private static final String SERVICE_NAME_LIST_KPS = "BNSPR_CREDITCARD_KPS_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KPS = "BNSPR_TRN3870_CREATE_BASVURU_BY_CEP_TCKN_NO";
	private static final String SERVICE_NAME_LIST_KKB = "BNSPR_CREDITCARD_KKB_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KKB = "BNSPR_CREDITCARD_KKB_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_LKS = "BNSPR_CREDITCARD_LKS_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_LKS = "BNSPR_CREDITCARD_LKS_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_OCEAN = "BNSPR_CREDITCARD_OCEAN_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_OCEAN = "BNSPR_CREDITCARD_OCEAN_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_VERI_KONTROL = "BNSPR_CREDITCARD_VERI_KONTROL_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_VERI_KONTROL = "BNSPR_CREDITCARD_VERI_KONTROL_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_INTRA = "BNSPR_CREDITCARD_INTRA_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_INTRA = "BNSPR_CREDITCARD_INTRA_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_ACTIVATION = "BNSPR_CREDITCARD_ACTIVATION_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_ACTIVATION = "BNSPR_CREDITCARD_ACTIVATION_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_ACTIVATION_2 = "BNSPR_CREDITCARD_ACTIVATION_JOB_2_LIST";
	private static final String SERVICE_NAME_PROCESS_ACTIVATION_2 = "BNSPR_CREDITCARD_ACTIVATION_JOB_2_PROCESS";
	private static final String SERVICE_NAME_LIST_NBSM = "BNSPR_CREDITCARD_NBSM_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_NBSM = "BNSPR_CREDITCARD_NBSM_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_KK_RED = "BNSPR_CREDITCARD_KK_RED_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_RED = "BNSPR_CREDITCARD_KK_RED_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_KK_YOK = "BNSPR_CREDITCARD_KK_YOK_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_YOK = "BNSPR_CREDITCARD_KK_YOK_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_KK_RED_SMS = "BNSPR_CREDITCARD_KK_RED_SMS_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_RED_SMS = "BNSPR_CREDITCARD_KK_RED_SMS_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_TFF_OTO_IPTAL = "BNSPR_CREDITCARD_TFF_OTO_IPTAL_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_TFF_OTO_IPTAL = "BNSPR_CREDITCARD_TFF_OTO_IPTAL_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_KK_TOPLU_BASVURU = "BNSPR_CREDITCARD_KK_TOPLU_BASVURU_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_TOPLU_BASVURU = "BNSPR_KK_TOPLU_BASVURU_YAP_NT";
	private static final String SERVICE_NAME_LIST_KK_LIMIT_JOB = "BNSPR_CREDITCARD_KK_LIMIT_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_LIMIT_JOB = "BNSPR_CREDITCARD_KK_LIMIT_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_EKSIK_VERI_KONTROL_JOB = "BNSPR_CREDITCARD_EKSIK_VERI_KONTROL_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_EKSIK_VERI_KONTROL_JOB = "BNSPR_TRN3871_TFF_BASVURU_TAMAMLA";
	private static final String SERVICE_NAME_LIST_KK_ILE_TFF_OLUSTUR = "BNSPR_CREDITCARD_KK_ILE_TFF_OLUSTUR_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_ILE_TFF_OLUSTUR = "BNSPR_KK_TOPLU_BASVURU_TFF_BASVURU_OLUSTUR";
	private static final String SERVICE_NAME_LIST_ON_ONAY_BASVURU_IPTAL_JOB = "BNSPR_CREDITCARD_ON_ONAY_BASVURU_IPTAL_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_ON_ONAY_BASVURU_IPTAL_JOB = "BNSPR_TRN3875_SAVE";
	private static final String SERVICE_NAME_LIST_KK_TOPLU_BASVURU_ODEME_JOB = "BNSPR_CREDITCARD_KK_TOPLU_BASVURU_ODEME_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_TOPLU_BASVURU_ODEME_JOB = "BNSPR_KK_TOPLU_BASVURU_TFF_ODEME_YAP";
	private static final String SERVICE_NAME_LIST_KDH_BASVURU_OLUSTUR_JOB = "BNSPR_CREDITCARD_KDH_BASVURU_OLUSTUR_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KDH_BASVURU_OLUSTUR_JOB = "BNSPR_CREDITCARD_KDH_BASVURU_OLUSTUR_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_TFF_IPTAL_SMS_JOB = "BNSPR_CREDITCARD_TFF_IPTAL_SMS_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_TFF_IPTAL_SMS_JOB = "BNSPR_CREDITCARD_TFF_IPTAL_SMS_JOB_PROCESS";
	private static final String SERVICE_NAME_LIST_KART_BASVURU_TALEP_JOB = "BNSPR_CREDITCARD_KART_BASVURU_TALEP_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_KART_BASVURU_TALEP_JOB = "BNSPR_DEBIT_COMMON_PROCESS_CARD_REQUEST";
	private static final String SERVICE_NAME_LIST_RM_DOCUMENT_UPDATE_JOB = "BNSPR_RM_UPDATE_CUSTOMER_DOCUMENT_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_RM_DOCUMENT_UPDATE_JOB = "BNSPR_RM_UPDATE_CUSTOMER_DOCUMENT_PROCESS";
	private static final String SERVICE_NAME_LIST_VADE_YENILEME_JOB = "BNSPR_TFF_VADE_YENILEME_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_VADE_YENILEME_JOB = "BNSPR_TFF_VADE_YENILEME_PROCESS";
	private static final String SERVICE_NAME_LIST_SANAL_KART_OTO_IPTAL = "BNSPR_CREDITCARD_SANAL_KART_OTO_IPTAL_JOB_LIST";
	private static final String SERVICE_NAME_PROCESS_SANAL_KART_OTO_IPTAL = "BNSPR_SANAL_KART_KURYEDEN_IPTAL";
	private static final String SERVICE_NAME_LIST_KK_UAT_KURYE_SUREC ="BNSPR_KK_UAT_KURYE_SUREC_LIST";
	private static final String SERVICE_NAME_PROCESS_KK_UAT_KURYE_SUREC = "BNSPR_EXT_UPDATE_PACKAGE_STATUS";

	// ---------------------------------------------------------------------
	// ******************************************************* KPS JOB
	// ---------------------------------------------------------------------
	/**
	 * Cep numarasi ve TC kimlik no ile yapilan basvurularda(BNSPR_TRN3870_CREATE_BASVURU_BY_CEP_TCKN_NO)
	 * KPS islemi yapilamazsa islem kesilir ve tx tablosunda durumu KPS yapilacak olarak guncellenir.(KPS_JOB)
	 * Bu job ile KPS yapilacak durumundaki basvurular icin KPS sistemi aktifse KPS sorgusu yapilacaktir.
	 * Sorgu basari ile tamamlandi ise basvuru s�recinde kalan islemler tamamlanir. <br>
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_KPS_JOB")
	public static GMMap creditCardKPSJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KPS");
		return processCreditCardJob(SERVICE_NAME_LIST_KPS, SERVICE_NAME_PROCESS_KPS, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KPS)
	public static GMMap listCreditCardKPSJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listKPSJobBasvuru");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KKB JOB
	// ---------------------------------------------------------------------
	/**
	 * KKB islemi yapilamazsa islem kesilir ve basvuru tablosunda durumu KKB yapilacak olarak guncellenir.(KKB_JOB)
	 * Bu job ile KKB yapilacak durumundaki basvurular icin KKB sistemi aktifse KKB sorgusu yapilacaktir.
	 * Sorgu basari ile tamamlandi ise basvuru s�recinde kalan islemler tamamlanir.<br>
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_KKB_JOB")
	public static GMMap creditCardKKBJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KKB");
		return processCreditCardJob(SERVICE_NAME_LIST_KKB, SERVICE_NAME_PROCESS_KKB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KKB)
	public static GMMap listCreditCardKKBJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listKKBJobBasvuru");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_KKB)
	public static GMMap processCreditCardKKBJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// KKB sorgusu yap.
		iMap.put("SORGU_SEVIYESI", "F");
		oMap.putAll(CreditCardQueriesServices.KKBSorgu(iMap));

		// Basarili degilse cik.
		if (!CreditCardServicesUtil.EVET.equals(oMap.get("KKB_BASARILI"))) {
			iMap.put("MESSAGE_NO", new BigDecimal(2998));
			oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return oMap;
		}
		
		// TCMB sorgusu yap
		CreditCardQueriesServices.TCMBSorgu(iMap);

		// FRAUD sorgusu yap.
		iMap.put("KKB_YAPILDI", CreditCardServicesUtil.EVET);
		CreditCardQueriesServices.FraudSorgu(iMap);

		try {
			// NBSM Cagrilicak
			GMMap tarihceMap = new GMMap();
			tarihceMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			tarihceMap.put("ISLEM_KODU", iMap.getString("DURUM_KOD"));
			tarihceMap.put("DURUM_KODU", iMap.getString("DURUM_KOD"));
			tarihceMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			tarihceMap.put("ISLEM_SONRASI_DURUM_KODU", "NBSM");
			tarihceMap.put("YENI_KAYIT_MI", "E");
			GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", tarihceMap);

			// Onceki NBSM bilgilerini al ve NBSMi cagir
			GMMap nbsmMap = new GMMap();
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
			iMap.putAll(CreditCardQueriesServices.getPrevNbsmData(iMap));
			nbsmMap.putAll(CreditCardQueriesServices.brmDecisionCall(iMap));

			// NBSM sonuclarini al
			oMap.put("NBSM_KARAR_KOD", nbsmMap.getString("FinalDecisionMergeDecCategory"));
			oMap.put("NBSM_FRAUD_KARAR_KOD", nbsmMap.getString("SMFraudStrategyFraudLevel"));
			oMap.put("CallId", nbsmMap.getBigDecimal("CallId"));
			oMap.put("NBSM_FRAUD_ONCELIK", nbsmMap.getString("SMPriorityStrategyFraudQueuePriority"));
			oMap.put("NBSM_UW_ONCELIK", nbsmMap.getString("SMPriorityStrategyUWQueuePriority"));
			oMap.put("ADRES_BELGE_GEREKLI", nbsmMap.getString("StrategyDocumentExceptionAddressDocumentsRequired"));
			oMap.put("GELIR_BELGE_GEREKLI", nbsmMap.getString("StrategyDocumentExceptionIncomeDocumentsRequired"));
			oMap.put("GMENKUL_GELIR_BELGE_GEREKLI", nbsmMap.getString("StrategyDocumentExceptionREMADocumentsRequired"));
			oMap.put("ES_GELIR_BELGE_GEREKLI", nbsmMap.getString("StrategyDocumentExceptionSpouseDocumentRequired"));
			oMap.put("MUSTERI_BLOKESI_VAR", nbsmMap.getString("MUSTERI_BLOKESI_VAR"));
			oMap.put("EVTEL_SORGU_GEREKLI", nbsmMap.getString("SMTelVerAppHomChReq"));
			oMap.put("ISTEL_SORGU_GEREKLI", nbsmMap.getString("SMTelVerAppWorkChReq"));
			oMap.put("CEPTEL_SORGU_GEREKLI", nbsmMap.getString("SMTelVerAppGSMChReq"));

			// NBSM sonucunu kontrol et
			String nbsmKarar = nbsmMap.getString("FinalDecisionMergeDecCategory");
			String iadeKarar = nbsmMap.getString("FinalStrategyReturnReq");
			String iadeGerekce = nbsmMap.getString("FinalStrategyReturnReasonCode");
			if ("Policy Decline".equals(nbsmKarar) || "Decline".equals(nbsmKarar)) {// TAMAM
				String fraudKarar = nbsmMap.getString("SMFraudStrategyFraudQueueYN");
				if (CreditCardServicesUtil.NO.equals(fraudKarar)) {
					oMap.put("DURUM", "RED");
				}
				else if (CreditCardServicesUtil.YES.equals(iadeKarar)) { // Iade gerekli mi
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", iadeGerekce);
				}
				else if (CreditCardServicesUtil.YES.equals(fraudKarar)) {
					if (CreditCardServicesUtil.hunterDevredeMi())
						oMap.put("DURUM", "RED");
					else
						oMap.put("DURUM", "FRAUD");
				}

				oMap.put("DEVAM", "H");
			}
			else {// DEVAM
				oMap.put("DEVAM", "E");
				oMap.put("ONAY_KART_LIMIT", nbsmMap.getBigDecimal("StrategyLimitMergeFinalLimit"));
				oMap.put("ONAY_LKS_LIMIT", nbsmMap.getBigDecimal("StrategyLimitMergeLKSLimit"));
				oMap.put("ONAY_EKSPRES_LIMIT", BigDecimal.ZERO);
				oMap.put("NAKIT_LIMIT_ORANI", nbsmMap.getBigDecimal("StrategyLimitMergeCashLimitPerc"));

				if (CreditCardServicesUtil.YES.equals(iadeKarar)) { // Iade gerekli mi
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", iadeGerekce);
				}
				else {
					oMap.put("NBSM_KOD", "MAppVer:" + nbsmMap.getString("FinalStrategyAppVerAppChReq") + "-MEmptVer:" + nbsmMap.getString("FinalStrategyEmptVerReqCode") + "-MFraudVer:" + nbsmMap.getString("SMFraudStrategyFraudChReq") + "-MWebVer:" + nbsmMap.getString("FinalStrategyWebChReq"));

					if (CreditCardServicesUtil.YES.equals(oMap.getString("EVTEL_SORGU_GEREKLI")) || CreditCardServicesUtil.YES.equals(oMap.getString("ISTEL_SORGU_GEREKLI")) || CreditCardServicesUtil.YES.equals(oMap.getString("CEPTEL_SORGU_GEREKLI"))) {
						GMMap unqMap = new GMMap();
						unqMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						unqMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
						unqMap.put("KIM_ICIN", "M");
						unqMap.put("EVTEL_SORGU_GEREKLI", oMap.getString("EVTEL_SORGU_GEREKLI"));
						unqMap.put("ISTEL_SORGU_GEREKLI", oMap.getString("ISTEL_SORGU_GEREKLI"));
						unqMap.put("CEPTEL_SORGU_GEREKLI", oMap.getString("CEPTEL_SORGU_GEREKLI"));
						GMServiceExecuter.executeNT("BNSPR_NBSM_UNKNOWN_NUMBER_QUERY", unqMap);
					}

					if (CreditCardServicesUtil.NO.equals(nbsmMap.getString("FinalStrategyAppVerAppChReq")) && "Not Required".equals(nbsmMap.getString("FinalStrategyEmptVerReqCode")) && CreditCardServicesUtil.NO.equals(nbsmMap.getString("SMFraudStrategyFraudQueueYN")) && CreditCardServicesUtil.NO.equals(nbsmMap.getString("SMFraudStrategyFraudChReq")) && CreditCardServicesUtil.NO.equals(nbsmMap.getString("FinalStrategyWebChReq"))) {
						String fraudLevel = nbsmMap.getString("SMFraudStrategyFraudLevel");
						if (("Policy Accept".equals(nbsmKarar) || "Accept".equals(nbsmKarar)) && ("No Fraud".equals(fraudLevel) || "High Fraud".equals(fraudLevel))) {
							if (CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi())
								oMap.put("DURUM", "HUNTER");
							else
								oMap.put("DURUM", "BASIM");
						}
						else if (("Policy Accept".equals(nbsmKarar) || "Accept".equals(nbsmKarar)) && "Low Fraud".equals(fraudLevel)) {
							oMap.put("DURUM", "TAHSIS");
						}
						else if ("Decline Refer".equals(nbsmKarar) || "Refer".equals(nbsmKarar) || "Accept Refer".equals(nbsmKarar)) {
							oMap.put("DURUM", "TAHSIS");
						}
						else { // gecici olarak TAHSIS'e aliyorum. Her durumda No Policy uretiyor
							oMap.put("DURUM", "TAHSIS");
						}
					}
					else if (CreditCardServicesUtil.NO.equals(nbsmMap.getString("FinalStrategyAppVerAppChReq")) && "Not Required".equals(nbsmMap.getString("FinalStrategyEmptVerReqCode")) && CreditCardServicesUtil.YES.equals(nbsmMap.getString("SMFraudStrategyFraudQueueYN")) && CreditCardServicesUtil.NO.equals(nbsmMap.getString("SMFraudStrategyFraudChReq")) && CreditCardServicesUtil.NO.equals(nbsmMap.getString("FinalStrategyWebChReq"))) {
						if ("Decline Refer".equals(nbsmKarar) || "Refer".equals(nbsmKarar) || "Accept Refer".equals(nbsmKarar)) {
							oMap.put("DURUM", "TAHSIS");
						}
						else {
							if (CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi())
								oMap.put("DURUM", "HUNTER");
							else
								oMap.put("DURUM", "FRAUD");
						}
					}
					else if (CreditCardServicesUtil.YES.equals(nbsmMap.getString("FinalStrategyAppVerAppChReq")) || "Home".equals(nbsmMap.getString("FinalStrategyEmptVerReqCode")) || "Work".equals(nbsmMap.getString("FinalStrategyEmptVerReqCode")) || "Web".equals(nbsmMap.getString("FinalStrategyEmptVerReqCode")) || CreditCardServicesUtil.YES.equals(nbsmMap.getString("SMFraudStrategyFraudChReq")) || CreditCardServicesUtil.YES.equals(nbsmMap.getString("FinalStrategyWebChReq"))) {
						oMap.put("DURUM", "DOGRULAMA");
					}
					else {
						iMap.put("HATA_NO", new BigDecimal(1499));
						return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
			}

			// Durum G�ncelle.
			oMap.put("MESSAGE", CreditCardServicesUtil.nvl(nbsmMap.getString("SMCommunicationStrategyMessage"), null));
			CreditCardQueriesServices.updateNbsmSorguSonuc(iMap, oMap);

			// Limit artis islemi tamamlanir.
			if (KART_SEVIYESI_LIMIT.equals(iMap.getString("KART_SEVIYESI"))) {
				if (CreditCardServicesUtil.EVET.equals(oMap.getString("DEVAM"))) {
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", iMap));
				}
			}

			// TFF basvuru ise durumunu guncelle.
			GMMap sorguMap = new GMMap();
			if ("BASIM".equals(oMap.getString("DURUM"))) {
				sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				sorguMap.put("ISLEM_KODU", "BASVURU");
				sorguMap.put("DURUM_KOD", "BASIM");
				GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", sorguMap);
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", sorguMap);
			}
			else if ("HUNTER".equals(oMap.getString("DURUM"))) {
				sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				sorguMap.put("BASVURU_TIPI", "KK");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_HUNTER_SEND_APPL_INFO", sorguMap));
				if ("ACCEPT".equals(sorguMap.getString("HUNTER_RESULT"))) {
					sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					sorguMap.put("ISLEM_NO", iMap.get("TRX_NO"));
					sorguMap.put("ISLEM_KODU", "HUNTER");
					sorguMap.put("DURUM_KOD", "BASIM");
					GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", sorguMap);
					GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", sorguMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* LKS JOB
	// ---------------------------------------------------------------------
	/**
	 * Basvuru girisinde veya OCEAN isleminden hemen �nce LKS sorgusu yap�lamazsa islem kesilir ve
	 * basvuru tablosunda durumu LKS yapilacak olarak guncellenir. (LKS_JOB_1, LKS_JOB_2)
	 * Bu job ile LKS yapilacak durumundaki basvurular icin LKS sistemi aktifse LKS sorgusu yapilacaktir.
	 * Sorgu basari ile tamamlandi ise basvuru s�recinde kalan islemler tamamlanir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_LKS_JOB")
	public static GMMap creditCardLKSJob(GMMap iMap) {
		iMap.put(JOB_NAME, "LKS");
		return processCreditCardJob(SERVICE_NAME_LIST_LKS, SERVICE_NAME_PROCESS_LKS, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_LKS)
	public static GMMap listCreditCardLKSJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listLKSJobBasvuru");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_LKS)
	public static GMMap processCreditCardLKSJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// Basvuru girisinde LKS islemi yapilamazsa LKS sorgusu yap
		if ("LKS_JOB_1".equals(iMap.getString("DURUM_KOD"))) {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", iMap));
			// Islemi tamamla.
			if (CreditCardServicesUtil.EVET.equals(oMap.getString("DEVAM"))) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", iMap));
			}
			// Ocean isleminden once LKS islemi yapilamazsa
		}
		else if ("LKS_JOB_2".equals(iMap.getString("DURUM_KOD"))) {
			iMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("GELEN_LKS_JOB_2", "E");

			GMServiceExecuter.execute("BNSPR_CREDITCARD_LKS_EKTAHSIS_IPTAL", iMap);
			GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
			GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_CREDITCARD_LKS_EKTAHSIS_IPTAL")
	public static GMMap lksOnlineEkTahsisIptalYap(GMMap iMap) {

		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

		GMMap tMap1 = new GMMap(), lksMap = new GMMap();
		Connection conn = null;
		String sorguTipi = "11";
		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
			Statement stmt = conn.createStatement();
			String sorguNo = null;
			String gidenSorgu = null;

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

			Date _date = new Date();

			Boolean isBildirim = isBildirimiYapilmis(basvuruNo);
			if (isBildirim) {

				String selectQuery = "select iss.sorgu_no, iss.giden_mesaj from bnspr.lks_sorgu_islem iss where iss.basvuru_no =" + basvuruNo + " and " + "iss.basvuru_no = (select kkk.basvuru_no from bnspr.kk_basvuru kkk where kkk.basvuru_no = iss.basvuru_no and kkk.durum_kod = 'LKS_JOB_2') " 
				+ "and iss.sorgu_no = (select msgg.sorgu_no from bnspr.lks_gelen_mesaj msgg where iss.sorgu_no = msgg.sorgu_no and trim(msgg.hata_kodu) = 'E03LKSSRC' " 
						+ "and msgg.sorgu_tipi='04' and msgg.islem_sonucu='3' " 
							+ "and msgg.rec_date = (select max(msf.rec_date) from bnspr.lks_gelen_mesaj msf where msgg.basvuru_no=msf.basvuru_no and msf.sorgu_tipi='04' and msf.islem_sonucu='3')) and iss.sorgu_tipi = '04'";
				ResultSet rs = stmt.executeQuery(selectQuery);
				while (rs.next()) {
					sorguNo = rs.getString(1);
					Clob clob = rs.getClob(2);
					Reader r = clob.getCharacterStream();
					StringBuffer buffer = new StringBuffer();
					int ch;
					while ((ch = r.read()) != -1) {
						buffer.append("" + (char) ch);
					}
					gidenSorgu = buffer.toString().substring(0, 10) + sorguTipi + buffer.toString().substring(12, buffer.toString().length());// sorguTipi
					gidenSorgu = gidenSorgu.toString().substring(0, 12) + dateFormat.format(_date) + gidenSorgu.toString().substring(26, gidenSorgu.toString().length());// Tarih
					gidenSorgu = gidenSorgu.toString().substring(0, 214) + "              000000000000000" + gidenSorgu.toString().substring(243, gidenSorgu.toString().length());// TahsisBilgileri
				}

				if (!StringUtils.isEmpty(sorguNo) && sorguNo != null && !BigDecimal.ZERO.equals(sorguNo)) {
					// LKS Sorgu
					logger.info("KK LKS Ek Tahsis Iptal Bildirim basvuruNo: " + basvuruNo + " nolu islemin giden sorgusu: " + gidenSorgu);
					tMap1.put("GIDEN_MESAJ", gidenSorgu);
					tMap1.put("TEKRAR_MI", "HAYIR");
					GMConnection gmConn = GMConnection.getConnection("GW_KKB");
					lksMap.put("GW_FORMAT", tMap1.getBigDecimal("SORGU_NO"));
					lksMap.put("GW_IN_MESSAGE", tMap1.getString("GIDEN_MESAJ"));
					lksMap.putAll(gmConn.serviceCall("BNSPR_KKB_GW_SEND_LKS_MESSAGE", lksMap));
					tMap1.put("LKS_GELEN_MESAJ", lksMap.getString("GW_OUT_MESSAGE"));

					LksSorguislem lksIslem = (LksSorguislem) session.createCriteria(LksSorguislem.class).add(Restrictions.eq("sorguNo", new BigDecimal(sorguNo))).uniqueResult();

					lksIslem.setSorguTipi(sorguTipi);

					session.saveOrUpdate(lksIslem);
					logger.info("KK LKS Tahsis Iptal Bildirim Uyari " + basvuruNo + " nolu islemin lks tahsis iptal islemi basarili. Giden Sorgu: " + gidenSorgu + " Gelen Mesaj: " + tMap1.getString("LKS_GELEN_MESAJ"));
					lksMailGonder("KK LKS Tahsis Iptal Bildirim Basarili", basvuruNo + " nolu islemin lks tahsis iptal islemi basarili. Giden Sorgu: " + gidenSorgu + " Gelen Mesaj: " + tMap1.getString("LKS_GELEN_MESAJ"));
				}
				else {
					logger.info("KK LKS Tahsis Iptal Bildirim Uyari " + basvuruNo + " nolu islemin lks tahsis iptal bilgisi gelmedi.");
					lksMailGonder("KK LKS Tahsis Iptal Bildirim Uyari", basvuruNo + " nolu islemin lks tahsis iptal bilgisi gelmedi.");
				}
			}
			else {
				logger.info("BNSPR_CREDITCARD_LKS_EKTAHSIS_IPTAL Hata KK LKS Tahsis Iptal Bildirim Uyari " + basvuruNo + " nolu islemin lks tahsis iptal islemi yapilamadi. Bildirimi yapilmamis");
				lksMailGonder("KK LKS Tahsis Iptal Bildirim Uyari", basvuruNo + " nolu islemin lks tahsis iptal islemi yapilamadi. Bildirimi yapilmamis");
			}
			session.flush();
			conn.close();
		}
		catch (Throwable e) {
			logger.error("BNSPR_CREDITCARD_LKS_EKTAHSIS_IPTAL Hata ", e);
			String errMsg = (e.getMessage() + " " + e.getStackTrace().toString()).length() > 4000 ? (e.getMessage() + " " + e.getStackTrace().toString()).substring(1, 3999) : e.getMessage() + " " + e.getStackTrace().toString();
			lksMailGonder("KK LKS Tahsis Iptal Hatas�", basvuruNo + " nolu islemin lks tahsis iptal islemi yapilamadi. Hata: " + errMsg);
		}
		return tMap1;
	}

	private static void lksMailGonder(String title, String body) {
		GMMap mailMap = new GMMap();
		mailMap.put("MAIL_TO_PARAM", "KART_BCKOFFC_ENTGRTN_MAIL");
		mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
		mailMap.put("MAIL_SUBJECT", title);
		mailMap.put("MAIL_BODY", body);
		GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
	}

	// ---------------------------------------------------------------------
	// ******************************************************* OCEAN JOB
	// ---------------------------------------------------------------------
	/**
	 * Basvuru tamamlanmasi icin gerceklesecek OCEAN i�lemi yap�lamazsa islem kesilir ve
	 * basvuru tablosunda durumu OCEAN islemi yapilacak olarak guncellenir. (OCEAN_JOB)
	 * Bu job ile OCEAN islemi yapilacak durumundaki basvurular icin islemler tamamlnir ve basima gonderilir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_OCEAN_JOB")
	public static GMMap creditCardOceanJob(GMMap iMap) {
		iMap.put(JOB_NAME, "OCEAN");
		return processCreditCardJob(SERVICE_NAME_LIST_OCEAN, SERVICE_NAME_PROCESS_OCEAN, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_OCEAN)
	public static GMMap listCreditCardOceanJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listOceanJobBasvuru");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_OCEAN)
	public static GMMap processCreditCardOceanJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// OCEAN islemi yapilamazsa
		if ("OCEAN_JOB".equals(iMap.getString("DURUM_KOD"))) {
			iMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
			GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
			GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* VERI KONTROL JOB
	// ---------------------------------------------------------------------
	/**
	 * Veri kontrol adimina gelen basvurular icin kullanici kilit mekanizmasi olusturuldu.
	 * Kullanici bir basvuruyu isleme aldiginda basvuru ustune atanir. Eger islemi tamamlamadan ekrandan
	 * cikarsa da basvuru uzerinde kalir. Parametrik belirlenen sure ile bu basvurularin kilitleri
	 * bu job ile kaldirilir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_VERI_KONTROL_JOB")
	public static GMMap creditCardVeriKontrolJob(GMMap iMap) {
		iMap.put(JOB_NAME, "VERI_KONTROL");
		return processCreditCardJob(SERVICE_NAME_LIST_VERI_KONTROL, SERVICE_NAME_PROCESS_VERI_KONTROL, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_VERI_KONTROL)
	public static GMMap listCreditCardVeriKontrolJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFVeriKontrolJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_VERI_KONTROL)
	public static GMMap processCreditCardVeriKontrolJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// Basvuru kilit kaldir.
		GMMap kilitMap = new GMMap();
		kilitMap.put("ROL", "U");
		kilitMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		kilitMap.put("DURUM_KOD", "VERI_KONTROL");
		kilitMap.put("AKIS_TIPI", "TFF");
		kilitMap.put("KULLANICI_KONTROL", CreditCardServicesUtil.HAYIR);
		GMServiceExecuter.execute("BNSPR_QRY3829_KULLANICI_ISLEM", kilitMap);

		return oMap;
	} 

	// ---------------------------------------------------------------------
	// ******************************************************* INTRA CARD JOB
	// ---------------------------------------------------------------------
	/**
	 * Veri kontrol/ Veri tamamlamada Debit ve Prepaid Kartlar icin IntraCard olusturulurken
	 * hata alinirsa basvurunun durumu INTRA CARD basim islemini tekrar denenmek uzere
	 * guncellenir. (INTRA_JOB) Guncellenen basvurular bu job ile tekrar calistirilarak
	 * basim islemi gerceklestirilir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_INTRA_JOB")
	public static GMMap creditCardIntraJob(GMMap iMap) {
		iMap.put(JOB_NAME, "INTRA_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_INTRA, SERVICE_NAME_PROCESS_INTRA, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_INTRA)
	public static GMMap listCreditCardIntraJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFIntraJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_INTRA)
	public static GMMap processCreditCardIntraJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// INTRA islemi yapilamazsa
		if ("INTRA_JOB".equals(iMap.getString("DURUM_KOD"))) {
			iMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
			GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", iMap);

			try {
				iMap.put("TFF_BASVURU_NO", iMap.get("BASVURU_NO"));
				iMap.put("CRM_TYPE", CrmTypes.MAIN);
				GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
			}
			catch (Exception e) {
				e.printStackTrace();
				logger.error("CRM payment guncellemesi yapilamadi BASVURU_NO:" + iMap.getString("BASVURU_NO"));
			}
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* ACTIVATON JOB
	// ---------------------------------------------------------------------
	/**
	 * Basim asamasina gecen kartlar OCEAN/INTRA tarafindan aktivasyon servisi kullanilmadan
	 * kendi taraflarinda aktif hale getirilebiliyor. Bunu senkron hale getirmek amaciyla
	 * OCEAN/INTRA tarafinda durumu ACIK, basvuru tarafinda durumu BASIM olan kayitlar icin
	 * aktivasyon islemleri yapilir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_ACTIVATION_JOB")
	public static GMMap creditCardActivationJob(GMMap iMap) {
		iMap.put(JOB_NAME, "ACTIVATON_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_ACTIVATION, SERVICE_NAME_PROCESS_ACTIVATION, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_ACTIVATION)
	public static GMMap listCreditCardActivationJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFActivationJob");
	}

	// KART_NO, KART_TIPI, BASVURU_NO, MUSTERI_NO,
	@GraymoundService(SERVICE_NAME_PROCESS_ACTIVATION)
	public static GMMap processCreditCardActivationJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean kartAcikMi = false;
		// Gecerli bir kart no olusmus mu?
		String kartNo = iMap.getString("KART_NO");
		String kartTipi = iMap.getString("KART_TIPI");
		String sistem = iMap.getString("SISTEM");
		if (StringUtils.isNotBlank(kartNo)) {
			// Kartin tipine gore aktif mi sorgusunu yap.
			GMMap kontrolMap = new GMMap();
			kontrolMap.put("CARD_DCI", "KK".equals(kartTipi) == true ? "C" : kartTipi);
			kontrolMap.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
			kontrolMap.put("CARD_BANK_STATUS", "N");
			kontrolMap.put("CARD_NO", kartNo);
			// Kart tipine gore gidilen servis farkli.
			if ("O".equals(sistem)) {
				kontrolMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", kontrolMap);
			}
			else {
				kontrolMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", kontrolMap);
			}

			// Kart Ocean/Intra tarafinda acik mi?
			if (kontrolMap != null && !kontrolMap.isEmpty() && kontrolMap.getSize("CARD_DETAIL_INFO") > 0) {
				kartAcikMi = true;
			}

			// Ocean/Intra tarafinda aktif, basvuru tarafinda basimsa aktiflestir.
			if (kartAcikMi) {
				logger.info("{} nolu kart icin aktivasyon islemi yapilmaktadir.", kartNo);
				GMMap kartMap = new GMMap();
				kartMap.put("CARD_NO", kartNo);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_CARD_ACTIVATION", kartMap));
				if ("0".equals(oMap.getString("RESPONSE"))) {
					logger.info("{} nolu kart icin aktivasyon islemi basariyla tamamlanmistir.", kartNo);
				}
				else {
					logger.info("{} nolu kart icin aktivasyon islemi hatali. Hata: {}", kartNo, oMap.getString("RESPONSE_DATA"));
				}
			}
		}
		else {
			logger.error("{} nolu basvuru basimda olmasina karsilik kart no olusmamis!!!", iMap.getString("BASVURU_NO"));
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* ACTIVATON JOB
	// ---------------------------------------------------------------------
	/**
	 * Basim asamasina gecen kartlar OCEAN/INTRA tarafindan aktivasyon servisi kullanilmadan
	 * kendi taraflarinda aktif hale getirilebiliyor. Bunu senkron hale getirmek amaciyla
	 * OCEAN/INTRA tarafinda durumu ACIK, basvuru tarafinda durumu BASIM olan kayitlar icin
	 * aktivasyon islemleri yapilir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_ACTIVATION_JOB_2")
	public static GMMap creditCardActivationJob2(GMMap iMap) {
		iMap.put(JOB_NAME, "ACTIVATON_JOB_2");
		return processCreditCardJob(SERVICE_NAME_LIST_ACTIVATION_2, SERVICE_NAME_PROCESS_ACTIVATION_2, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_ACTIVATION_2)
	public static GMMap listCreditCardActivationJob2(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFActivationJob");
	}

	// KART_NO, KART_TIPI, BASVURU_NO, MUSTERI_NO,
	@GraymoundService(SERVICE_NAME_PROCESS_ACTIVATION_2)
	public static GMMap processCreditCardActivationJob2(GMMap iMap) {
		GMMap oMap = new GMMap();
		// Gecerli bir kart no olusmus mu?
		String kartNo = iMap.getString("KART_NO");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		if (StringUtils.isNotBlank(kartNo)) {

			// Ocean/Intra tarafinda aktif, basvuru tarafinda basimsa aktiflestir.
			logger.info("{} nolu basvuru icin aktivasyon islemi yapilmaktadir.", basvuruNo);
			GMMap kartMap = new GMMap();
			kartMap.put("APPLICATION_NO", basvuruNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_AKTIVASYON_2", kartMap));
			if ("0".equals(oMap.getString("RESPONSE"))) {
				logger.info("{} nolu basvuru icin aktivasyon islemi basariyla tamamlanmistir.", basvuruNo);
			}
			else {
				logger.info("{} nolu basvuru icin aktivasyon islemi hatali. Hata: {}", basvuruNo, oMap.getString("RESPONSE_DATA"));
			}
		}
		else {
			logger.error("{} nolu basvuru basimda olmasina karsilik kart no olusmamis!!!", iMap.getString("BASVURU_NO"));
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* NBSM JOB
	// ---------------------------------------------------------------------
	/**
	 * Kredi karti basvurusu sirasinda nbsm sorgusu yapilamayan
	 * NBSM durumunda olan basvurularin islenmesi saglanir.
	 */
	@GraymoundService("BNSPR_CREDITCARD_NBSM_JOB")
	public static GMMap creditCardNbsmJob(GMMap iMap) {
		iMap.put(JOB_NAME, "NBSM_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_NBSM, SERVICE_NAME_PROCESS_NBSM, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_NBSM)
	public static GMMap listCreditCardNbsmJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listNBSMJobBasvuru");
	}

	// BASVURU_NO, DURUM_KOD, KANAL_KOD, MUSTERI_NO, TC_KIMLIK_NO, TRX_NO, TFF_BASVURU_NO
	@GraymoundService(SERVICE_NAME_PROCESS_NBSM)
	public static GMMap processCreditCardNbsmJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_DEVAM_SORGULAR", sorguMap));
			// NBSM Hatasi aldi ise cik
			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("NBSM_HATASI_MI"))) {
				logger.debug("{} nolu basvuru NBSM hatasi almistir.", iMap.getString("BASVURU_NO"));
				return oMap;
			}
			// Limit artis surecinden geliyorsa islemi tamamla
			String durumKodu = sorguMap.getString("DURUM");
			if (KART_SEVIYESI_LIMIT.equals(iMap.getString("KART_SEVIYESI"))) {
				// Gonder sorgular, kkb/lks sorgularini da yaparak nbsm islemlerini tamamla ve
				// basvurunun giris asamasini tamamla.
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("DURUM_KOD", durumKodu);
				sorguMap.put("LIMIT_ARTIS", CreditCardServicesUtil.EVET);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", sorguMap));
				if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
					oMap.put("RESPONSE_DATA", "Limit artis islemi banka kriterleri nedeniyle reddedildi");
				}
				else {
					sorguMap.clear();
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap));
				}

				return oMap;
			}
			// Kanal TFF Degilse hicbir islem yapma. Limti artis sureci kanali sube olacagi varsayilmistir.
			if (!"40".equals(iMap.getString("KANAL_KOD"))) {
				logger.debug("{} nolu basvuru icin nbsm sorgu islemi basariyla tamamlanmistir.", iMap.getString("BASVURU_NO"));
				return oMap;
			}
			// TFF basvurusunu ilerlet/tamamla
			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEVAM"))) {
				// Tff basvurusunun bulunmasi sart
				if (StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO"))) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getString("TFF_BASVURU_NO"));
				}

				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getString("TFF_BASVURU_NO"));
				}

				// Basvuru EPOS kanalindan geliyorsa
				if ("EPOS".equals(tffBasvuru.getSource()) || "NTS02".equals(tffBasvuru.getSource())) {
					// basvurunun durumunu VERI_KONTROL olarak guncellemeliyiz. CC'dan basvuru ilerletilmesin diye
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("ISLEM_NO", iMap.get("TRX_NO"));
					sorguMap.put("DURUM_KOD", "VERI_KONTROL");
					sorguMap.put("ISLEM_ACIKLAMA", "Odeme sonrasi kk basvuru veri kontrol");
					sorguMap.put("TARIHCE_AKSIYON", "E");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);

					// Kredi karti basari ile olustu, eventi olustur
					iMap.put("EVENT_TYPE_NO", CreditCardTRN3802Services.EPOS_EVENT_TYPE_NO);
					iMap.put("EVENT_REF_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
					GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
				}
				else {
					// Kredi karti basvurusunun durumu guncellenir.
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("TCK_NO", iMap.get("TCK_NO"));
					sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
					GMServiceExecuter.execute("BNSPR_TRN3871_TFF_TAM_BASVURU", sorguMap);
				}

				logger.debug("{} nolu basvuru basariyla ilerletilmistir.", iMap.getString("BASVURU_NO"));
				// Red/Iptal aldi ise
			}
			else {
				if ("RED".equals(sorguMap.getString("DURUM")) || "IPTAL".equals(sorguMap.getString("DURUM"))) {
					// Islem tamamlandi ise 3871.afterApproval icerisinde durumunu guncelliyor.
					boolean trxTamamlandiMi = false;
					sorguMap.clear();
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_ISLEM_TAMAMLANDI_MI", sorguMap));
					if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("ISLEM_TAMAMLANDI_MI"))) {
						trxTamamlandiMi = true;
					}

					// Islem tamamlanmadi ise durumunu guncelle.
					if (!trxTamamlandiMi) {
						sorguMap.clear();
						sorguMap.put("TFF_BASVURU_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
						sorguMap.put("KK_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						sorguMap.put("ISLEM_KOD", "NBSM");
						sorguMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
						GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap);
					}
				}

				logger.debug("{} nolu basvuru red almis ve kart donusum surecini girmistir.", iMap.getString("BASVURU_NO"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* RM JOB
	// ---------------------------------------------------------------------
	/**
	 * Kuryeye cikilmis ancak RM tarafindan eksik yada uygun degil olarak belirtilen belgelerin
	 * tekrar kuryeye cikilabilmesi icin bu belgelerin istenilen bilgilerini iceren
	 * bir excel dosyasi olusturulur ve olusturulan bu dosya mail ile ilgili gruba yonlendirilir.<br>
	 * 
	 * @author murat.el
	 * @since 13.03.2014
	 * @param iMap
	 *            - Belge tarih araliklari<br>
	 *            <li>BAS_TARIH - Belge arama baslangic tarihi(String Format:yyyyMMdd) <li>BIT_TARIH - Belge arama bitis tarihi(String Format:yyyyMMdd)
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_CREDITCARD_RM_JOB")
	public static GMMap creditCardRmJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap kuryeMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// 1.Belge listesini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TFF_RM_DOKUMAN.listRMJob (?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			if (iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(2, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(2, null);
			}
			if (iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(3, new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(3, null);
			}

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			sorguMap.putAll(DALUtil.rSetResultsPutStr(rSet, "TABLE_DATA"));// Excel olusturan serviste TABLE_DATA olarak kullaniliyor.

			// 2.Sorgu sonucu data var mi? Varsa kurye/barkod bilgisi tamamla.
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			if (sorguMap.size() > 0 && sorguMap.getSize("TABLE_DATA") > 0) {
				// ss barkod no/ ss kurye firmasi var mi?
				String barkodNo = StringUtils.EMPTY;
				BigDecimal basvuruNo = null;
				String dokumanKodu = null;
				for (int i = 0; i < sorguMap.getSize("TABLE_DATA"); i++) {
					basvuruNo = sorguMap.getBigDecimal("TABLE_DATA", i, "BASVURU_NO");
					dokumanKodu = sorguMap.getString("TABLE_DATA", i, "DOKUMAN_KOD");
					barkodNo = sorguMap.getString("TABLE_DATA", i, "BARKOD_NUMARASI");
					// Belgelerin SS tarafindan alinmasi gereken ss barkod no ve kurye firmasi bilgisini al
					if (StringUtils.isBlank(sorguMap.getString("TABLE_DATA", i, "SS_BARKOD_NUMARASI")) || StringUtils.isBlank(sorguMap.getString("TABLE_DATA", i, "KURYE_FIRMASI"))) {
						kuryeMap.clear();
						kuryeMap.put("KART_NO", sorguMap.get("TABLE_DATA", i, "KART_NO"));
						kuryeMap.putAll(GMServiceExecuter.execute("BNSPR_SS_KURYE_BILGISI_VER", kuryeMap));
						if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(kuryeMap.getString("RESPONSE"))) {
							// Excelde/Basvuru belgede set et
							// TFF Basvuru Belge bilgisini al
							TffBasvuruBelgeId id = new TffBasvuruBelgeId();
							id.setBasvuruNo(basvuruNo);
							id.setBarkodNumarasi(barkodNo);
							id.setDokumanKod(dokumanKodu);

							TffBasvuruBelge tffBasvuruBelge = (TffBasvuruBelge) session.get(TffBasvuruBelge.class, id);
							if (tffBasvuruBelge != null) {
								tffBasvuruBelge.setSsBarkodNumarasi(kuryeMap.getString("BARKOD_NO"));
								tffBasvuruBelge.setSsKuryeFirmasi(kuryeMap.getString("KURYE_KOD"));
								sorguMap.put("TABLE_DATA", i, "SS_BARKOD_NUMARASI", kuryeMap.get("BARKOD_NO"));
								sorguMap.put("TABLE_DATA", i, "KURYE_FIRMASI", kuryeMap.get("KURYE_KOD"));
								session.save(tffBasvuruBelge);
								session.flush();
							}
						}
					}
				}
			}

			// 3.Belge listesini excele aktar
			DateTime date = new DateTime();
			String islemTarihi = new SimpleDateFormat("ddMMyyyy").format(date.minusDays(1).toDate());
			String dosyaAdi = "RM_CIKILACAK_BELGE" + "_" + islemTarihi + "_";
			// Excelde yer alacak header bilgisini set et.
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();
			headers.put("SS_BARKOD_NUMARASI", new String[] { "Barkod Numaras�" });
			headers.put("AD_SOYAD", new String[] { "Ad Soyad" });
			headers.put("KART_TIPI", new String[] { "Kart Tipi" });
			headers.put("KURYE_FIRMASI", new String[] { "Kurye Firmas�" });
			headers.put("BELGE_ADI", new String[] { "Belge Ad�" });
			// Exceli olustur
			sorguMap.put("HEADERS", headers);
			sorguMap.put("FILE_NAME", dosyaAdi);
			sorguMap.put("CHANGE_PAGE_DIRECTION", false);
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", sorguMap));
			if (sorguMap.getInt("DOSYA_SAYISI") > 0) {
				for (int dosyaSayisi = 1; dosyaSayisi < sorguMap.getInt("DOSYA_SAYISI") + 1; dosyaSayisi++) {
					sorguMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_NAME", dosyaAdi + (sorguMap.getInt("DOSYA_SAYISI") == 1 ? "" : "-" + dosyaSayisi) + ".xls");
					sorguMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_CONTENT", FileUtil.readFileToByteArray(new File(FILES_FOLDER + dosyaAdi + dosyaSayisi + ".xls")));
				}
			}
			// 4.Olusan exceli mail ile gonder
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_TO_PARAM", "TFF_CIKILACAK_BELGE_MAIL_TO");
			mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			mailMap.put("MAIL_SUBJECT", "RM ��k�lacak Belgeler - Tarih:" + islemTarihi);
			mailMap.put("MAIL_BODY", islemTarihi + " tarihli RM ��k�lmas� gereken belgeler ekte bulunmaktad�r.");
			mailMap.put("MAIL_ATTACHMENT_LIST", sorguMap.get("MAIL_ATTACHMENT_LIST"));
			GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* TFF KK GECERSIZ JOB
	// ---------------------------------------------------------------------
	/**
	 * Kredi karti istenen TFF basvurularinda kredi karti basvurulari olusturulamaz ise
	 * musteriye karti iptal etmek icin bir is gunu sure verilir. bu sure zarfinda basvurunun
	 * durumu guncellenir.(KK_RED_JOB) Guncellenen basvurular bu job ile tekrar calistirilarak
	 * basim islemi gerceklestirilir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_RED_JOB")
	public static GMMap creditCardKKRedJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_RED_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_RED, SERVICE_NAME_PROCESS_KK_RED, iMap, true);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_RED)
	public static GMMap listCreditCardKKRedJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFKkRedJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_KK_RED)
	public static GMMap processCreditCardKKRedJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// INTRA islemi yapilamazsa
		if ("KK_RED_JOB".equals(iMap.getString("DURUM_KOD"))) {
			String sonrakiDurumKodu = StringUtils.EMPTY;
			if (iMap.getInt("VERI_KONTROL_SAYISI") > 0) {
				if ("EPOS".equals(iMap.getString("SOURCE")) || "NTS02".equals(iMap.getString("SOURCE"))) {
					if (StringUtils.isBlank(iMap.getString("ON_BASVURU_AKSIYON"))) {
						sonrakiDurumKodu = "ON_BASVURU";
					}
					else {
						if ("F".equals(iMap.getString("ON_BASVURU_AKSIYON"))) {
							if ("ON_BASVURU".equals(iMap.getString("ONCEKI_DURUM_KOD"))) {
								sonrakiDurumKodu = "FOTO_EKSIK_ONAY";
							}
							else {
								sonrakiDurumKodu = "BASIM";
							}
						}
						else {// Onaysa
							sonrakiDurumKodu = "BASIM";
						}
					}
				}
				else {
					sonrakiDurumKodu = "BASIM";
				}
			}
			else {
				sonrakiDurumKodu = "VERI_KONTROL";
			}

			sorguMap.put("TFF_BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
			sorguMap.put("KART_TIPI", iMap.get("KART_TIPI"));
			sorguMap.put("BASVURU_IPTAL_EDILSIN_MI", CreditCardServicesUtil.EVET);
			sorguMap.put("ISLEM_NO", iMap.get("TRX_NO"));
			sorguMap.put("ISLEM_KOD", "KK_RED_JOB");
			sorguMap.put("SONRAKI_DURUM_KODU", sonrakiDurumKodu);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_RED_KART_TIPI_DONUSTUR", sorguMap));
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* TFF KK YOK JOB
	// ---------------------------------------------------------------------
	/**
	 * Kredi karti istenen TFF basvurularinda kredi karti basvurulari olusturulamaz ise
	 * olusturulmasi icin basvurunun durumu guncellenir.(KK_YOK_JOB)
	 * Guncellenen basvurular bu job ile tekrar calistirilarak kredi karti basvurularinin olusturulamas� saglanir.
	 * 
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_YOK_JOB")
	public static GMMap creditCardKKYokJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_YOK_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_YOK, SERVICE_NAME_PROCESS_KK_YOK, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_YOK)
	public static GMMap listCreditCardKKYokJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFKkYokJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_KK_YOK)
	public static GMMap processCreditCardKKYokJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// INTRA islemi yapilamazsa
		if ("KK_YOK_JOB".equals(iMap.getString("DURUM_KOD"))) {
			// Kredi karti basvurusunu olustur.
			sorguMap.put("KULLANICI_KOD", iMap.get("KULLANICI_KOD"));
			sorguMap.put("UYE_NO", iMap.get("UYE_NO"));
			sorguMap.put("TFF_BASVURU_NO", iMap.get("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU", sorguMap));

			// Tff basvurusunun durumu ayni mi? Ayni ise veri kontrole ilerlet.
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru != null && "KK_YOK_JOB".equals(tffBasvuru.getDurumKod())) {
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
					String sonrakiDurumKodu = "VERI_KONTROL";
					if ("EPOS".equals(tffBasvuru.getSource()) || "NTS02".equals(tffBasvuru.getSource())) {
						sonrakiDurumKodu = "ON_BASVURU";
					}
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					sorguMap.put("DURUM_KOD", sonrakiDurumKodu);
					sorguMap.put("ISLEM_ACIKLAMA", "Job Sonrasi -- Kredi karti basvurusu olusturuldu!!!");
					sorguMap.put("TARIHCE_AKSIYON", "E");// Ekle
					GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap);
				}
				else {
					// NBSM hatasi var mi
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, oMap.getBigDecimal("BASVURU_NO"));
					if (kkBasvuru != null) {
						session.refresh(kkBasvuru);
						if ("NBSM".equals(kkBasvuru.getDurumKod())) {
							String sonrakiDurumKodu = "VERI_KONTROL";
							if ("EPOS".equals(tffBasvuru.getSource()) || "NTS02".equals(tffBasvuru.getSource())) {
								sonrakiDurumKodu = "ON_BASVURU";
							}
							sorguMap.clear();
							sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
							sorguMap.put("DURUM_KOD", sonrakiDurumKodu);
							sorguMap.put("ISLEM_ACIKLAMA", "Job Sonrasi -- Kredi karti basvurusu olusturuldu!!!");
							sorguMap.put("TARIHCE_AKSIYON", "E");// Ekle
							GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap);
						}
					}
				}
			}
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* TFF KK GECERSIZ SMS JOB
	// ---------------------------------------------------------------------
	/**
	 * Kredi karti istenen TFF basvurularinda kredi karti basvurulari olusturulamaz ise
	 * musteriye karti iptal etmek icin belirli sure verilir. bu sure zarfinda basvurunun
	 * durumu guncellenir. Durum guncellemeden musteriye bilgi smsi gonderilir.(KK_RED_SMS_JOB)
	 * 
	 * DURUM_KOD, BASVURU_NO, KK_BASVURU_NO, KART_TIPI
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_RED_SMS_JOB")
	public static GMMap creditCardKKRedSmsJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_RED_SMS_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_RED_SMS, SERVICE_NAME_PROCESS_KK_RED_SMS, iMap, true);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_RED_SMS)
	public static GMMap listCreditCardKKRedSmsJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFKkRedSmsJob");
	}

	@GraymoundService("BNSPR_CREDITCARD_KK_RED_SMS_JOB_PROCESS")
	public static GMMap processCreditCardKKRedSmsJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// Basvuru islenmeye uygun mu
		if (!"KK_RED_JOB".equals(iMap.getString("DURUM_KOD"))) {
			logger.debug("{} nolu basvurunun durumu {} oldugundan ilerletilemiyor.", iMap.getString("BASVURU_NO"), iMap.getString("DURUM_KOD"));
			return oMap;
		}

		// Donusturulecek kart tipini al
		String donusturKartTipi = null;
		sorguMap.clear();
		sorguMap.put("PARAMETRE", "KK_RED_TFF_KART_TIPI");
		donusturKartTipi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");

		// Mevcut kart tipi donusturulmeye uygun mu? Uygunsa yeni kart tipini al
		String yeniKartTipi = null;
		sorguMap.clear();
		sorguMap.put("TFF_BASVURU_NO", iMap.get("BASVURU_NO"));
		sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
		sorguMap.put("KART_TIPI", iMap.get("KART_TIPI"));
		sorguMap.put("KART_TIPI_GUNCELLENSIN_MI", CreditCardServicesUtil.HAYIR);
		if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(donusturKartTipi)) {
			sorguMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.EVET);
		}
		else {
			sorguMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.HAYIR);
		}
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TIPI_DONUSTUR", sorguMap));
		yeniKartTipi = sorguMap.getString("KART_TIPI");

		// Mevcut kart tipini al
		String mevcutKartTipi = null;
		if (sorguMap.getBoolean("DEBIT_KART_VAR_MI")) {
			mevcutKartTipi = CreditCardTffServices.TFF_DEBIT_KARTI;
		}
		else if (sorguMap.getBoolean("PREPAID_KART_VAR_MI")) {
			mevcutKartTipi = CreditCardTffServices.TFF_PREPAID_KARTI;
		}
		else {
			mevcutKartTipi = StringUtils.EMPTY;
		}

		// Sms Gonder
		if (iMap.get("KK_BASVURU_NO") != null) {
			sorguMap.clear();
			if (StringUtils.isBlank(yeniKartTipi)) {
				sorguMap.put("KART_VAR_MI", CreditCardServicesUtil.EVET);
				sorguMap.put("KART_TIPI", mevcutKartTipi);
			}
			else {
				sorguMap.put("KART_VAR_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.put("KART_TIPI", yeniKartTipi);
			}

			sorguMap.put("BASVURU_NO", iMap.get("KK_BASVURU_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_RED_SMS_GONDER", sorguMap));
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* TFF BASVURU OTO IPTAL JOB
	// ---------------------------------------------------------------------
	/**
	 * Kredi karti istenen TFF basvurularinda kredi karti basvurulari olusturulamaz ise
	 * musteriye karti iptal etmek icin belirli sure verilir. bu sure zarfinda basvurunun
	 * durumu guncellenir. Durum guncellemeden musteriye bilgi smsi gonderilir.(KK_RED_SMS_JOB)
	 * 
	 * DURUM_KOD, BASVURU_NO, KK_BASVURU_NO, KART_TIPI
	 */
	@GraymoundService("BNSPR_CREDITCARD_TFF_OTO_IPTAL_JOB")
	public static GMMap creditCardTffOtoIptalJob(GMMap iMap) {
		iMap.put(JOB_NAME, "TFF_OTO_IPTAL_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_TFF_OTO_IPTAL, SERVICE_NAME_PROCESS_TFF_OTO_IPTAL, iMap, true);
	}

	@GraymoundService(SERVICE_NAME_LIST_TFF_OTO_IPTAL)
	public static GMMap listCreditCardTffOtoIptalJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTFFOtoIptalJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_TFF_OTO_IPTAL)
	public static GMMap processCreditCardTffOtoIptalJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// Kredi karti basvurusu mu?
		boolean isKrediKarti = false;
		if (CreditCardTffServices.TFF_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
			isKrediKarti = true;
		}

		// Basvurulari iptal et
		sorguMap.clear();
		sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
		sorguMap.put("ISLEM_KOD", "IPTAL_JOB");
		sorguMap.put("ONCEKI_DURUM_KOD", iMap.get("DURUM_KOD"));
		sorguMap.put("GEREKCE_KOD", "2");
		sorguMap.put("ACIKLAMA", iMap.getString("IPTAL_SURE") + " gundur aksiyon alinmayan basvuru");
		sorguMap.put("KK_BASVURU_IPTAL_MI", BooleanUtils.toString(isKrediKarti, CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KK TOPLU BASVURU
	// ---------------------------------------------------------------------
	/**
	 * EVAM tarafindan toplu basvuru havuzuna eklenen kayitlari isleyerek akis turune gore
	 * limit guncelleme/on onay talebi/yeni basvuru talebi islemlerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since PY-8524
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_TOPLU_BASVURU_JOB")
	public static GMMap creditCardTopluBasvuruJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_TOPLU_BASVURU");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_TOPLU_BASVURU, SERVICE_NAME_PROCESS_KK_TOPLU_BASVURU, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_TOPLU_BASVURU)
	public static GMMap listCreditCardTopluBasvuruJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listTopluBasvuruJob");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KK TOPLU BASVURU
	// ---------------------------------------------------------------------
	/**
	 * EVAM tarafindan toplu basvuru havuzuna eklenen kayitlari isleyerek akis turune gore
	 * limit guncelleme/on onay talebi/yeni basvuru talebi islemlerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since PY-8524
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_LIMIT_JOB")
	public static GMMap creditCardLimitGuncelleJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_LIMIT_GUNCELLE");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_LIMIT_JOB, SERVICE_NAME_PROCESS_KK_LIMIT_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_LIMIT_JOB)
	public static GMMap listCreditCardLimitGuncelleJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listKkLimitGuncelleJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_KK_LIMIT_JOB)
	public static GMMap processCreditCardLimitGuncelleJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// Limit guncelleme tipine gore islemleri gerceklestir
		// Limit artis islemlerini gerceklestir
		if (CreditCardServicesUtil.EVET.equals(iMap.getString("LIMIT_ARTTI_MI"))) {
			// Herhangi bir islem LKS Bildirim/Kart Guncelleme gerceklesmedi ise iptal et.
			if ("EVAM_LIMIT_GUNCELLEME_1".equals(iMap.getString("ISLEM_YERI"))) {
				iMap.put("ISLEM_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				iMap.put("DURUM_KOD", "BASIM");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN_LIMIT", iMap));
			}
			else if ("EVAM_LIMIT_GUNCELLEME_2".equals(iMap.getString("ISLEM_YERI"))) {
				iMap.put("ONCEKI_DURUM_KOD", iMap.getString("DURUM_KOD"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3822_IPTAL", iMap));
			}
			// Limit azaltma islemini gerceklestir
		}
		else if (CreditCardServicesUtil.HAYIR.equals(iMap.getString("LIMIT_ARTTI_MI"))) {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_AZALT", iMap));
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* VERI KONTROL YARIM KALAN KK TAMAMLA JOB
	// ---------------------------------------------------------------------
	/**
	 * Veri kontrol islemi sonucunda async olarak cagrilan kk basvuru islemleri sirasinda
	 * alinacak hata nedeniyle TFF basvurusu ilerletilip KK basvurusu ilerletilemezse calistirilir.
	 * 
	 * @author murat.el
	 * @since PY-9053
	 */
	@GraymoundService("BNSPR_CREDITCARD_EKSIK_VERI_KONTROL_JOB")
	public static GMMap creditCardEksikVeriKontrolJob(GMMap iMap) {
		iMap.put(JOB_NAME, "EKSIK_VERI_KONTROL");
		return processCreditCardJob(SERVICE_NAME_LIST_EKSIK_VERI_KONTROL_JOB, SERVICE_NAME_PROCESS_EKSIK_VERI_KONTROL_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_EKSIK_VERI_KONTROL_JOB)
	public static GMMap listCreditCardEksikVeriKontrolJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listEksikVeriKontrolJob");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KKDAN TFF BASVURU OLUSTUR
	// ---------------------------------------------------------------------
	// ---------------------------------------------------------------------
	/**
	 * On onay/Dogrudan olusturulan kredi karti basvurularinin ayni bilgilerle TFF basvurularini
	 * olusturur.
	 * 
	 * @since PY-8907
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_ILE_TFF_OLUSTUR_JOB")
	public static GMMap creditCardKkIleTffOlusturJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_ILE_TFF_OLUSTUR");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_ILE_TFF_OLUSTUR, SERVICE_NAME_PROCESS_KK_ILE_TFF_OLUSTUR, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_ILE_TFF_OLUSTUR)
	public static GMMap listcreditCardKkIleTffOlusturJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listKkIleTffOlusturJob");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* ON ONAYLI KK BASVURU IPTAL JOB
	// ---------------------------------------------------------------------
	/**
	 * KK basvurusu yapmak uzere olusturulan on onayli kredi karti basvurulari
	 * belirlenen sure sonunda iptal edilir.
	 */
	@GraymoundService("BNSPR_CREDITCARD_ON_ONAY_BASVURU_IPTAL_JOB")
	public static GMMap creditCardOnOnayBasvuruIptalJob(GMMap iMap) {
		iMap.put(JOB_NAME, "ON_ONAY_BASVURU_IPTAL");
		return processCreditCardJob(SERVICE_NAME_LIST_ON_ONAY_BASVURU_IPTAL_JOB, SERVICE_NAME_PROCESS_ON_ONAY_BASVURU_IPTAL_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_ON_ONAY_BASVURU_IPTAL_JOB)
	public static GMMap listCreditCardOnOnayBasvuruIptalJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listOnOnayBasvuruIptalJob");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KK TOPLU BASVURU ODEME JOB
	// ---------------------------------------------------------------------
	/**
	 * On onayli basvurudan ilerletilen kredi karti basvurulari aktiflestirilince odeme muhasebesi yapilir.
	 */
	@GraymoundService("BNSPR_CREDITCARD_KK_TOPLU_BASVURU_ODEME_JOB")
	public static GMMap creditCardKkTopluBasvuruOdemeJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KK_TOPLU_BASVURU_ODEME");
		return processCreditCardJob(SERVICE_NAME_LIST_KK_TOPLU_BASVURU_ODEME_JOB, SERVICE_NAME_PROCESS_KK_TOPLU_BASVURU_ODEME_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KK_TOPLU_BASVURU_ODEME_JOB)
	public static GMMap listCreditCardKkTopluBasvuruOdemeJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listTopluBasvuruOdemeJob");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KDH BASVURU OLUSTUR JOB
	// ---------------------------------------------------------------------
	/**
	 * Debit ve Kredi kartlari icin basvuru sirasinda alinan kdh basvuru taleplerine istinaden
	 * debit/kk kartlari aktiflestirildikten sonra alianan taleplerin basvurularini olusturur.
	 */
	@GraymoundService("BNSPR_CREDITCARD_KDH_BASVURU_OLUSTUR_JOB")
	public static GMMap creditCardKdhBasvuruOlusturJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KDH_BASVURU_OLUSTUR_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_KDH_BASVURU_OLUSTUR_JOB, SERVICE_NAME_PROCESS_KDH_BASVURU_OLUSTUR_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KDH_BASVURU_OLUSTUR_JOB)
	public static GMMap listCreditCardKdhBasvuruOlusturJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU_SORGU.listKdhBasvuruOlusturJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_KDH_BASVURU_OLUSTUR_JOB)
	public static GMMap processCreditCardKdhBasvuruOlusturJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		// Duruma gore KDH baasvuru olustur/tanimi yap
		if ("DK".equals(iMap.getString("ILISKILI_BASVURU_URUN"))) {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3013_KDH_BASVURU_ADK", iMap));
		}
		else if ("KK".equals(iMap.getString("ILISKILI_BASVURU_URUN"))) {
			// Basvuru iptal ama kdh onaylandi ise aktif karti var mi diye bakilir, varsa karta kdh tanimi yapilir
			if (iMap.getInt("KDH_AKSIYON") == 4) {
				// Bu musteriye ait aktif debit kart var mi?
				GMMap sorguMap = new GMMap();
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("KART_TIPI", CreditCardTffServices.TFF_DEBIT_KARTI);
				sorguMap.put("DURUM", "N");// Acik
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_GECERLI_KART_LISTELE", sorguMap));
				// Kart listesi var mi? Yoksa kdh ile ilgili islem yapma
				if (sorguMap.getSize("KART_LIST") < 1) {
					logger.info("Gecerli debit karti bulunamadi");
					return oMap;
				}
				else {
					logger.info("Aktif debit kart no:" + sorguMap.get("KART_LIST", 0, "KART_NO"));
					iMap.put("HESAP_NO", sorguMap.get("KART_LIST", 0, "HESAP_NO"));
				}
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3013_KDH_DIGER_URUNDEN_BASVURU", iMap));
		}
		else {
			logger.info(iMap.getString("ILISKILI_BASVURU_URUN") + " iliskili urun kodu hatali");
			return oMap;
		}

		// Alinan kdh basvurusunu kk/tff tablolarinda guncelle
		if (StringUtils.isNotBlank(oMap.getString("BASVURU_NO"))) {
			updateKdhInfo(iMap.getString("ILISKILI_BASVURU_URUN"), iMap.getBigDecimal("ILISKILI_BASVURU_NO"), oMap.getBigDecimal("BASVURU_NO"));
		}

		return oMap;
	}

	private static void updateKdhInfo(String kartTipi, BigDecimal iliskiliBasvuruNo, BigDecimal kdhBasvuruNo) {
		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call PKG_KK_BASVURU_SORGU.updateKdhBasvuruNo(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setString(1, kartTipi);
			stmt.setBigDecimal(2, iliskiliBasvuruNo);
			stmt.setBigDecimal(3, kdhBasvuruNo);
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	// ---------------------------------------------------------------------
	// ******************************************************* TFF IPTAL SMS JOB
	// ---------------------------------------------------------------------
	/**
	 * KK red durumlarinda basvurunun iptale donmesi (mevcut bir debit karti veya bs�vurusu varsa) VEYA
	 * 120 gecmis olmasi durumunda iade yapilacaksa (bilet almismi kontrolu)
	 * otomatik dusen mailler icin iptalden 1 G�N SONRA sms g�nderilmesini saglar.
	 * 
	 * @author murat.el
	 * @since TYBK-841(TY-3448)
	 */
	@GraymoundService("BNSPR_CREDITCARD_TFF_IPTAL_SMS_JOB")
	public static GMMap tffIptalSmsJob(GMMap iMap) {
		iMap.put(JOB_NAME, "TFF_IPTAL_SMS_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_TFF_IPTAL_SMS_JOB, SERVICE_NAME_PROCESS_TFF_IPTAL_SMS_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_TFF_IPTAL_SMS_JOB)
	public static GMMap lisTffIptalSmsJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_BASVURU.listTffIptalSmsJob");
	}

	@GraymoundService(SERVICE_NAME_PROCESS_TFF_IPTAL_SMS_JOB)
	public static GMMap processTffIptalSmsJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// Mac Biletli Mi Kontrolu, degilse sms gonder
		sorguMap.clear();
		sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_MAC_BILETLI_MI", sorguMap));
		// Kontrol
		if (!"E".equals(sorguMap.getString("MAC_BILETLI_MI_EH"))) {
			// SMS gonder
			sorguMap.clear();
			sorguMap.put("GIDEN_MESAJ", CreditCardServicesUtil.errorMessageOlustur("4996"));
			sorguMap.put("CEP_NO", iMap.get("CEP_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
		}
		else {
			logger.info(iMap.getString("BASVURU_NO") + " numarali basvuru ile mac bileti alindigindan SMS gonderilmedi");
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* KART BASVURU TALEP JOB
	// ---------------------------------------------------------------------
	/**
	 * Alinan Kart basvuru taleblerini isleyerek yeni bir basvuru olusturur.
	 * 
	 * @author murat.el
	 * @since TY-4783
	 */
	@GraymoundService("BNSPR_CREDITCARD_KART_BASVURU_TALEP_JOB")
	public static GMMap kartBasvuruTalepJob(GMMap iMap) {
		iMap.put(JOB_NAME, "KART_BASVURU_TALEP_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_KART_BASVURU_TALEP_JOB, SERVICE_NAME_PROCESS_KART_BASVURU_TALEP_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_KART_BASVURU_TALEP_JOB)
	public static GMMap listkartBasvuruTalepJob(GMMap iMap) {
		return listCreditCardJob("PKG_KART_BASVURU_TALEP.listKartBasvuruTalepJob");
	}

	// ---------------------------------------------------------------------
	// ******************************************************* SUSISTIMAL - AYNI CEP NO BASVURU
	// ---------------------------------------------------------------------
	/**
	 * Ayn� cep telefonu ile belirlenen sure icerisinde belirlenen adet kadar tff basvuru
	 * girisi yapildiginda suistimal bolumune otomatik uyari maili gonderir.
	 * 
	 * @author murat.el
	 * @since TY-4869
	 */
	@GraymoundService("BNSPR_CREDITCARD_TFF_SUISTIMAL_UYARI_JOB")
	public static GMMap tffSuistimalUyariJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Islenecek kayitlari al.
			GMMap resultMap = listCreditCardJob("PKG_TFF_BASVURU.listTffSuistimalUyariJob");
			if (resultMap == null) {
				return oMap;
			}

			// Herhangi bir sonuc yoksa cik.
			List<?> list = (List<?>) resultMap.get(RESULTS);
			if (list == null || list.isEmpty()) {
				// TY-4955
				sorguMap.clear();
				sorguMap.put("MAIL_TO_PARAM", "SUISTIMAL_MAIL_TO");
				sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				sorguMap.put("MAIL_SUBJECT", "Ayni Cep Telefonundan Yapilan Basvurular");
				sorguMap.put("MAIL_BODY", "Ayni cep telefonundan gelen basvuru bulunmamaktadir.");
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
				return oMap;
			}

			// Data setini excele aktar
			DateTime date = new DateTime();
			String islemTarihi = new SimpleDateFormat("ddMMyyyy").format(date.minusDays(1).toDate());
			String dosyaAdi = "AYNI_CEP_TEL_BASVURU" + "_" + islemTarihi;
			// Excelde yer alacak header bilgisini set et.
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();
			headers.put("BASVURU_NO", new String[] { "Basvuru No" });
			headers.put("KART_TIPI", new String[] { "Kart Tipi" });
			headers.put("CEP_NO", new String[] { "Cep No" });
			headers.put("KIMLIK_NO", new String[] { "Kimlik No" });
			headers.put("KART_NO", new String[] { "Kart No" });
			headers.put("TAKIM", new String[] { "Takim" });
			headers.put("BASVURU_TARIHI", new String[] { "Basvuru Tarihi" });
			headers.put("BASVURU_DURUM", new String[] { "Basvuru Durumu" });
			headers.put("GISE_ID", new String[] { "Gise ID" });
			headers.put("GISE_USER", new String[] { "Gise Kullanici" });
			// Exceli olustur
			sorguMap.put("TABLE_DATA", resultMap.get(RESULTS));
			sorguMap.put("HEADERS", headers);
			sorguMap.put("FILE_NAME", dosyaAdi);
			sorguMap.put("CHANGE_PAGE_DIRECTION", false);
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", sorguMap));
			if (sorguMap.getInt("DOSYA_SAYISI") > 0) {
				for (int dosyaSayisi = 1; dosyaSayisi < sorguMap.getInt("DOSYA_SAYISI") + 1; dosyaSayisi++) {
					sorguMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_NAME", dosyaAdi + (sorguMap.getInt("DOSYA_SAYISI") == 1 ? "" : "-" + dosyaSayisi) + ".xls");
					sorguMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_CONTENT", FileUtil.readFileToByteArray(new File(FILES_FOLDER + dosyaAdi + dosyaSayisi + ".xls")));
				}
			}
			// Olusan exceli mail ile gonder
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_TO_PARAM", "SUISTIMAL_MAIL_TO");
			mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			mailMap.put("MAIL_SUBJECT", "Ayni Cep Telefonundan Yapilan Basvurular");
			mailMap.put("MAIL_BODY", "Ayni cep telden yapilan basvurular ekte bulunmaktad�r.");
			mailMap.put("MAIL_ATTACHMENT_LIST", sorguMap.get("MAIL_ATTACHMENT_LIST"));
			GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* TFF TESLIMAT ADRESI DEGISTI JOB
	// ---------------------------------------------------------------------
	/**
	 * Tff tesllimat adresi guncellemesi/tanimlamasi yapilan kayitlari
	 * bir liste olarak maille ilgili birime iletir.
	 * 
	 * @since TYWMC-631
	 * @author murat.el
	 */
	@GraymoundService("BNSPR_CREDITCARD_TFF_TESLIMAT_DEGISIKLIK_JOB")
	public static GMMap tffTeslimatDegisiklikJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Islenecek kayitlari al.
			GMMap resultMap = listCreditCardJob("PKG_TFF_BASVURU.listTffTeslimatDegislikJob");
			if (resultMap == null) {
				return oMap;
			}

			// Herhangi bir sonuc yoksa cik.
			List<?> list = (List<?>) resultMap.get(RESULTS);
			if (list == null || list.isEmpty()) {
				return oMap;
			}

			// Data setini excele aktar
			DateTime date = new DateTime();
			String islemTarihi = new SimpleDateFormat("ddMMyyyy").format(date.minusDays(1).toDate());
			String dosyaAdi = "TESLIMAT_ADRESI_DEGISTI" + "_" + islemTarihi;

			// Excelde yer alacak header bilgisini set et.
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();
			headers.put("BASVURU_NO", new String[] { "Basvuru No" });
			headers.put("KIMLIK_NO", new String[] { "Kimlik No" });
			headers.put("MUSTERI_NO", new String[] { "Musteri No" });
			headers.put("KART_NO", new String[] { "Kart No" });
			headers.put("KART_TIPI", new String[] { "Kart Tipi" });
			headers.put("LOGO_ADI", new String[] { "Logo Adi" });
			headers.put("DEGISIKLIK_TARIHI", new String[] { "Degisiklik Tarihi" });
			headers.put("ADRES_TIPI", new String[] { "Adres Tipi" });
			headers.put("ADRES", new String[] { "Adres" });

			// Exceli olustur
			sorguMap.put("TABLE_DATA", resultMap.get(RESULTS));
			sorguMap.put("HEADERS", headers);
			sorguMap.put("FILE_NAME", dosyaAdi);
			sorguMap.put("CHANGE_PAGE_DIRECTION", false);
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", sorguMap));
			if (sorguMap.getInt("DOSYA_SAYISI") > 0) {
				for (int dosyaSayisi = 1; dosyaSayisi < sorguMap.getInt("DOSYA_SAYISI") + 1; dosyaSayisi++) {
					sorguMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_NAME", dosyaAdi + (sorguMap.getInt("DOSYA_SAYISI") == 1 ? "" : "-" + dosyaSayisi) + ".xls");
					sorguMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_CONTENT", FileUtil.readFileToByteArray(new File(FILES_FOLDER + dosyaAdi + dosyaSayisi + ".xls")));
				}
			}

			// Olusan exceli mail ile gonder
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_TO_PARAM", "KART_BACKOFFICE_MAIL_TO");
			mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			mailMap.put("MAIL_SUBJECT", "IADE GELEN KARTLARIN DAGITIMA CIKARILMASI");
			mailMap.put("MAIL_BODY", "Kartlarin, belirtilen adreslere tekrar dagitima cikarilmasi");
			mailMap.put("MAIL_ATTACHMENT_LIST", sorguMap.get("MAIL_ATTACHMENT_LIST"));
			GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* JOB GENEL
	// ---------------------------------------------------------------------
	/**
	 * Job islemleri icin genel akis olarak kullanilir.<br>
	 * Islenecek kayitlar listServiceName servisinden alinir.
	 * Alinan kayitlar processServiceName servisi tarafindan islenir.
	 * 
	 * @param listServiceName
	 *            - Job tarafindan islenecek kayitlari alan servis adi
	 * @param processServiceName
	 *            - Job tarafindan alinan kayitlari isleyecek servis adi
	 * @param iMap
	 *            JOB_NAME
	 * 
	 */
	@GraymoundService("BNSPR_PROCESS_CREDIT_CARD_JOB")
	public static GMMap processCreditCardJob(GMMap iMap) {
		int threadCount = THREAD_SIZE;
		boolean isParallel = false;
		String listServiceName = StringUtils.EMPTY;
		String processServiceName = StringUtils.EMPTY;
		GMMap oMap = new GMMap();

		try {
			threadCount = iMap.getInt("THREAD_SIZE", THREAD_SIZE);
			isParallel = iMap.getBoolean("IS_PARALLEL", false);
			listServiceName = iMap.getString("LIST_SERVICE_NAME");
			processServiceName = iMap.getString("PROCESS_SERVICE_NAME");
			oMap.putAll(processCreditCardJob(listServiceName, processServiceName, iMap, isParallel, threadCount));
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static GMMap processCreditCardJob(String listServiceName, String processServiceName, GMMap iMap) {
		return processCreditCardJob(listServiceName, processServiceName, iMap, false);
	}

	private static GMMap processCreditCardJob(String listServiceName, String processServiceName, GMMap iMap, boolean isParallel) {
		return processCreditCardJob(listServiceName, processServiceName, iMap, isParallel, THREAD_SIZE);
	}

	private static GMMap processCreditCardJob(String listServiceName, String processServiceName, GMMap iMap, boolean isParallel, int threadSize) {
		GMMap oMap = new GMMap();

		threadSize = threadSize > MAX_THREAD_SIZE ? MAX_THREAD_SIZE : threadSize;

		try {

			if (StringUtils.isEmpty(listServiceName)) {
				throw new Exception("Servis parametresi bulunamad� : listServiceName");
			}
			if (StringUtils.isEmpty(processServiceName)) {
				throw new Exception("Servis parametresi bulunamad� : processServiceName");
			}

			logger.info("JOB : " + iMap.getString(JOB_NAME) + " durumundaki kayitlar isleme alinmistir.");

			// Islenecek kayitlari al.
			Map<?, ?> resultMap = GMServiceExecuter.executeNT(listServiceName, iMap);
			if (resultMap == null) {
				return oMap;
			}

			// Herhangi bir sonuc yoksa cik.
			List<?> list = (List<?>) resultMap.get(RESULTS);
			if (list == null || list.isEmpty()) {
				return oMap;
			}

			// Islemleri yap
			if (isParallel) {
				List<Object> recordList = new ArrayList<Object>();
				List<GMMap> parallelJobList = new ArrayList<GMMap>();
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					Map<?, ?> next = (Map<?, ?>) iterator.next();
					GMMap tempMap = new GMMap();
					tempMap.put("T_SERVICE_NAME", processServiceName);
					tempMap.putAll(next);
					parallelJobList.add(tempMap);
					oMap.put("T_TASKS", parallelJobList);

					logger.info("JOB ISLEM : " + next.get("BASVURU_NO") + " basvurusu islem alindi.");
					recordList.add(next.get("BASVURU_NO"));
					if (oMap.getSize("T_TASKS") == threadSize || !iterator.hasNext()) {
						try {
							GMServiceExecuter.callParallel(oMap);
						}
						catch (Exception e) {
							logger.error("JOB HATA 1: " + Arrays.toString(recordList.toArray()) + " - " + e.toString());
						}
						finally {
							logger.info("JOB ISLEM : " + next.get("BASVURU_NO") + " basvurusu islemi sonlandi.");
							recordList.clear();
							parallelJobList.clear();
							oMap.clear();
						}
					}
				}
			}
			else {
				Map<?, ?> listMap = null;
				for (Object object : list) {
					listMap = (Map<?, ?>) object;

					try {
						logger.info("JOB ISLEM : " + listMap.get("BASVURU_NO") + " basvurusu islem alindi.");
						GMServiceExecuter.executeNT(processServiceName, listMap);
					}
					catch (Exception e) {
						logger.error("JOB HATA 1: " + listMap.get("BASVURU_NO") + " - " + e.toString());
					}
					finally {
						logger.info("JOB ISLEM : " + listMap.get("BASVURU_NO") + " basvurusu islemi sonlandi.");
					}
				}
			}

		}
		catch (Exception e) {
			logger.error("JOB HATA 2: " + e.toString());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logger.info("JOB : " + iMap.getString(JOB_NAME) + " durumundaki kayitlarin islenmesi tamamlandi.");
		}

		return oMap;
	}

	/**
	 * Joblar icin yapilacak parametresiz listeleme icin kullanilir.
	 * 
	 * @param procName
	 *            - PAKET_ISMI.FUNC_ISMI formatinda olmasi gerekir
	 */
	private static GMMap listCreditCardJob(String procName) {
		GMMap oMap = new GMMap();
		
		
		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append(procName);
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, RESULTS);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	// Sadece tff debit ve kk basvurular� icin
	@GraymoundService("BNSPR_CRD_RESTRICTIONS_JOB")
	// K�s�t kald�rmada ba�ar�l� ise 1'e �evirir
	public static GMMap crdRestrictions(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rMap = new GMMap();
		Date date = new Date();

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			// K�s�t kald�racak basvurular� listeler
			List<CrdRestrictions> crdBasvuruList = session.createCriteria(CrdRestrictions.class).add(Restrictions.eq("restrictionResult", "0")).list();

			for (CrdRestrictions basvuruList : crdBasvuruList) {

				try {

					// basvuru'dan kart olu�up olu�mad���n� kontrol eder
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruList.getBasvuruNo())).uniqueResult();
					if (tffBasvuru == null) {
						basvuruList.setRestrictionResult("-1"); // tablodaki kayd� 1'e �ekiyor
						basvuruList.setDescription("Basvuru tff tablosunda olu�mam��");
						basvuruList.setUpdateDate(date);
						session.saveOrUpdate(basvuruList);
						session.flush();

					}
					else {

						// Kart olu�mu�sa k�s�t� kald�r�r, debit i�in Intra'ya , kk i�in Ocean'a gider
						if (tffBasvuru.getKartNo() != null) {
							rMap.put("CARD_NO", tffBasvuru.getKartNo());
							rMap.put("INTERNET_TYPE", "1");
							rMap.put("INTERNET", "1");

							// �ncelikle kartta k�s�t var m� diye kontrol ediliyor
							if (!isCardInternetRestrict(tffBasvuru.getKartNo(), tffBasvuru.getKartTipi())) {
								basvuruList.setRestrictionResult("1"); // tablodaki kayd� 1'e �ekiyor
								basvuruList.setDescription("Basvuruya ait Kart uzerinde kaldirilacak kisit yok");
								basvuruList.setUpdateDate(date);
								session.saveOrUpdate(basvuruList);
								session.flush();
							}
							else {
								if (("D").equals(tffBasvuru.getKartTipi()))
									oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_CARD_RESTRICT", rMap));
								else
									oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_SET_CARD_RESTRICTIONS", rMap));
								if (oMap.getString("RESPONSE") == "0") // ss taraf�nda ba�ar�l� i�lem
								{
									basvuruList.setRestrictionResult("1"); // tablodaki kayd� 1'e �ekiyor
									basvuruList.setDescription(tffBasvuru.getKartNo() + " uzerindeki kisit kaldirildi");
									basvuruList.setUpdateDate(date);
									session.saveOrUpdate(basvuruList);
									session.flush();
								}
							}
						}
						else {
							if ("IPTAL".equals(tffBasvuru.getDurumKod()) || "RED".equals(tffBasvuru.getDurumKod())) {
								basvuruList.setRestrictionResult("-1"); // tablodaki kayd� 1'e �ekiyor
								basvuruList.setDescription("Basvuru " + tffBasvuru.getDurumKod() + " edilmis");
								basvuruList.setUpdateDate(date);
								session.saveOrUpdate(basvuruList);
								session.flush();

							}
							else {
								basvuruList.setDescription("Basvuru uzerindeki kart henuz olusmamis");
								session.saveOrUpdate(basvuruList);
								session.flush();
							}
						}
					}
				}
				catch (Exception e) {
					basvuruList.setDescription(e.getStackTrace().toString());
					session.saveOrUpdate(basvuruList);
					session.flush();
					e.printStackTrace();

				}

			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static boolean isCardInternetRestrict(String cardNo, String dci) {
		GMMap oMap = new GMMap();
		oMap.put("CARD_NO", cardNo);

		// �ncelikle kartta k�s�t var m� diye kontrol ediliyor
		if (("D").equals(dci))
			oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_RESTRICTIONS", oMap));
		else
			oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_RESTRICTIONS", oMap));

		if ("0".equals(oMap.get("INTERNET")))
			return true;
		else
			return false;

	}

	// 28 g�n ekent hesab�nda bekleyen tutarlar�n, ba�ka bir ekent hesab�na aktar�lmas�
	@GraymoundService("BNSPR_BLOKE_TUTAR_TRANSFER_JOB")
	public static GMMap blokeTutarTransferJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		String productCode = "4617";
		BigDecimal txNo = null;

		txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
		// Aktar�lacak tutar� hesapla
		oMap.putAll(GMServiceExecuter.call("BNSPR_HESAPLA_HCE_BLOKE_TUTAR", oMap));
		// 4614 Muhasebesi i�in crd_ticket_sale_tx tablosunda transfer yap
		insertProductSaleTx(oMap.getBigDecimal("TOPLAM_TUTAR"), txNo, productCode);

		try {

			iMap.put("TRX_NAME", productCode);
			iMap.put("TRX_NO", txNo);
			GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {

			throw new GMRuntimeException(14017, "Muhasebe hatas� : " + e.getMessage());
		}

		return oMap;

	}

	// HCE Bloke hesaptaki 28 g�n bekleyen para y�kleme ve �deme i�lemlerinin toplam tutar�n� d�ner
	@GraymoundService("BNSPR_HESAPLA_HCE_BLOKE_TUTAR")
	public static GMMap hesaplaHceBlokeTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		String aliciHesap = "";
		BigDecimal toplamTutar = new BigDecimal(0);
		int count = 0;
		int blokeGunSayisi = 0;
		try {

			GMContext.getCurrentContext().getSession().get("USER_NAME");

			Session session = DAOSession.getSession("BNSPRDal");

			aliciHesap = getGlobalParam("EKENT_BLOKE_HESAP");

			// Muhasebesi ger�ekle�mi�, Ekent ula��m hesab�na yap�lm�� ve 28 g�n ge�mi� kay�tlar� listeler
			@SuppressWarnings("unchecked")
			List<CrdTicketSaleTx> listAnkaraKartTransfer = session.createCriteria(CrdTicketSaleTx.class).add(Restrictions.eq("durumKodu", "M")).add(Restrictions.eq("aliciHesapNo", aliciHesap)).add(Restrictions.sqlRestriction("trunc(rec_date + ?) = trunc(SYSDATE)", getGlobalParam("EKENT_BLOKE_GUN_SAYISI"), Hibernate.STRING)).list();

			for (CrdTicketSaleTx list : listAnkaraKartTransfer) {
				try {

					// M stat�l� olanlar i�lem sekli N toplan�yor, R ve V olanlar ��kar�l�yor
					if (list.getIslemSekli().equals("N"))
						toplamTutar = toplamTutar.add(list.getTutar());
					else
						toplamTutar = toplamTutar.subtract(list.getTutar());

					// Ge�ici hesaptaki i�lemlerin durumKodu 'T' stat�s�ne �ekiliyor ki bir daha gitmesin. Job ihtiya� olursa g�nde n kez �a�r�labilir.
					list.setDurumKodu("T");
					oMap.put("LIST", count, "DURUM", "BASARILI");
					oMap.put("LIST", count, "TX_NO", list.getTxNo());
					oMap.put("LIST", count, "TUTAR", list.getTutar());
					oMap.put("LIST", count, "ISLEM_SEKLI", list.getIslemSekli());

					session.saveOrUpdate(list);
					session.flush();

				}
				catch (Exception e) { // Hata almas� durumunda �nemseme
					toplamTutar = toplamTutar;
					oMap.put("LIST", count, "DURUM", "BASARISIZ");
					oMap.put("LIST", count, "TX_NO", list.getTxNo());
					oMap.put("LIST", count, "TUTAR", list.getTutar());
					oMap.put("LIST", count, "ISLEM_SEKLI", list.getIslemSekli());

				}
				count++;

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		oMap.put("TOPLAM_TUTAR", toplamTutar);
		return oMap;

	}

	private static String getGlobalParam(String kod) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", kod);
		iMapG.put("TRIM_QUOTES", true);
		String dkNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return dkNo;
	}

	public static void insertProductSaleTx(BigDecimal tutar, BigDecimal txNo, String productCode) {
		Session session = DAOSession.getSession("BNSPRDal");

		CrdTicketSaleTx saleTx = new CrdTicketSaleTx();

		saleTx.setAciklama("ULA�IM KARTA TRANSFER");
		saleTx.setAliciHesapCinsi(getGlobalParam("EKENT_ALACAKLI_HESAP_CINSI"));
		saleTx.setAliciHesapNo(getGlobalParam("EKENT_ALACAKLI_HESAP"));
		saleTx.setBorcHesapCinsi(getGlobalParam("EKENT_BLOKE_HESAP_CINSI"));
		saleTx.setBorcHesapNo(getGlobalParam("EKENT_BLOKE_HESAP"));
		saleTx.setDovizKodu("TRY");
		saleTx.setDurumKodu("A");
		saleTx.setIslemSekli("N");
		saleTx.setKanal("EKENTBLOKE");
		saleTx.setKartKaynagi("O");
		saleTx.setMasrafTahsilDoviz("TRY");
		saleTx.setSube(getGlobalParam("EKENT_BLOKE_HESAP_SUBE"));
		saleTx.setTutar(tutar);
		saleTx.setTxNo(txNo);
		saleTx.setProductCode(new BigDecimal(productCode));
		saleTx.setAlacakSube(getGlobalParam("EKENT_ALACAKLI_SUBE"));
		saleTx.setIslemCinsi("D");

		session.save(saleTx);
		session.flush();

	}

	// 2014'ten beri bildirimi yapilmayan lks kayitlarini bulup, tekrar bildirimi yapan servis
	// 3 manuel insert edilen, 0 lks yapilmasi beklenen, 1 basarili islem , 2 basarisiz veya daha �nce tahsilati yapilmis
	@GraymoundService("BNSPR_BILDIRIM_YAPILMAYAN_LKS_JOB")
	public static GMMap bildirimYapilmayanLksJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		Set<BigDecimal> basvuruNoList = new TreeSet<BigDecimal>();
		Session session = DAOSession.getSession("BNSPRDal");
		// HibernataNativeSql, ... Dosya �ikilmamis veya ilk asamada dosya �ikilmayip daha sonra �ikilan kayitlari listeler
		// 2 g�n �nce alinmasinin nedeni kkb'ye bildirim i�in 2 g�n s�re taninmasi
		String query = "select a.*,b.* from  bnspr.lks_islem_bildirim a , bnspr.lks_bildirim b " + "where a.Basvuru_No=b.BASVURU_NO and b.ISLEM_TIPI=1 and a.bildirim_durumu='H'" + " AND TRUNC(A.REC_DATE) < TRUNC(SYSDATE-2) and TRUNC(A.REC_DATE) >TRUNC(SYSDATE-:gun_sayisi)";

		SQLQuery sqlQuery = session.createSQLQuery(query);
		sqlQuery.addEntity(LksislemBildirim.class);
		sqlQuery.addEntity(LksBildirim.class);
		sqlQuery.setParameter("gun_sayisi", getGlobalParam("ONCEKI_GUN_SAYISI"));

		@SuppressWarnings("unchecked")
		List<Object[]> listBasvuru = sqlQuery.list();
		session.clear();

		for (Object[] objArr : listBasvuru) {
			// Object array'in ilk elamani lks_islem_bildirim , ikinci elemani lks_bildirim. Array'in ilk elemanindan basvuru_no alani aliniyor ve
			// basvurularin duplikasyonu olmamasi i�in set aray�z� kullanilmistir.
			basvuruNoList.add(((LksislemBildirim) objArr[0]).getBasvuruNo());

		}

		// Dosya cikilmis ama bildirimi ger�eklesmemis kayitlar icin elle insert ettigimiz basvurulari da ekleyelim
		@SuppressWarnings("unchecked")
		List<ManuelLksBildirim> manuelBasvuruList = session.createCriteria(ManuelLksBildirim.class).add(Restrictions.eq("status", "3")).list();
		session.clear();

		for (ManuelLksBildirim manuelBasvuru : manuelBasvuruList) {
			basvuruNoList.add(manuelBasvuru.getBasvuruNo());
		}

		int counter = 0;
		ManuelLksBildirim bildirim = new ManuelLksBildirim();

		for (BigDecimal basvuruNo : basvuruNoList) {

			bildirim.setBasvuruNo(basvuruNo);
			bildirim.setStatus("0");
			bildirim.setDescription("");
			session.saveOrUpdate(bildirim);
			session.flush();

			// Daha sonradan bildirim yapilmis mi kontrol edilir, eger yapilmissa yapilmayan kayit update edilir, yapilmamissa manuel tahsis yapilir
			try {
				if (!isBildirimiYapilmis(basvuruNo)) {

					iMap.put("BASVURU_NO", basvuruNo);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_LKS_MANUEL_TAHSIS_YAP", iMap));
					if ("2".equals(oMap.getString("RESPONSE"))) {
						bildirim.setStatus("1");
						BigDecimal sorguNo = oMap.getBigDecimal("SORGU_NO");
						bildirim.setDescription("Manuel tahsis yapildi, bildirilen tutar" + " =" + iMap.getString("GUNCEL_LIMIT") + " SORGU_NO" + "=" + sorguNo);
						session.update(bildirim);
						updateLksBildirim(basvuruNo, sorguNo);
						// Lks bildirimi yap�lan islemler sayiliyor.
						counter++;
					}
					else {
						bildirim.setStatus("2");
						bildirim.setDescription(StringUtils.left(oMap.getString("RESPONSE_MESSAGE"), 300));
						session.update(bildirim);
					}
				}
				else {
					updateLksBildirim(basvuruNo);
					bildirim.setStatus("2");
					bildirim.setDescription("Bildirimi yapilmamis kayitlar guncellendi");
					session.update(bildirim);
				}

			}
			catch (Exception e) {
				bildirim.setStatus("2");
				bildirim.setDescription(StringUtils.left(e.getMessage().toString(), 300));
				session.update(bildirim);
			}
			finally {
				session.flush();
				session.clear();
			}

			// Gunde 50 Kay�t g�ncelleyecek �ekilde de�i�tirildi
			if (counter == 50) {
				session.close();
				return oMap;
			}

		}

		session.close();
		return oMap;
	}

	// Bildirimin yapilip yapilmadigini kontrol eder, once manuel sorgu yapilir, daha sonra en son yapilan sorgunun detayina bakilir ve banka limiti var mi diye kontrol edilir.
	public static boolean isBildirimiYapilmis(BigDecimal basvuruNo) {

		try {
			// LKS sorgusu yap
			GMMap lMap = new GMMap();
			GMMap oMap = new GMMap();
			GMMap cMap = new GMMap();

			String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'03') }";
			cMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, basvuruNo);
			if (cMap.isEmpty()) {
				throw new Exception("Kayit Bulunamadi");
			}

			lMap.put("SOYADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "SOYADI"));
			lMap.put("MUSTERI_NO", cMap.getString("GIDEN_SORGU_DETAY", 0, "MUSTERI_NO"));
			lMap.put("IKINCI_ADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "IKINCI_ADI"));
			lMap.put("BABA_ADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "BABA_ADI"));
			lMap.put("TCKN", cMap.getString("GIDEN_SORGU_DETAY", 0, "TCKN"));
			lMap.put("BASVURU_NO", cMap.getString("GIDEN_SORGU_DETAY", 0, "BASVURU_NO"));
			lMap.put("ILK_ADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "ILK_ADI"));
			lMap.put("MANUEL_SORGU", "E");
			lMap.put("SORGU_TIPI", "01");
			cMap.clear();

			cMap = GMServiceExecuter.call("BNSPR_QRY3893_LKS_MANUEL_TAHSIS_SORGU_YAP", lMap);

			lMap.clear();
			lMap.put("SORGU_NO", cMap.getString("SORGU_LISTE", cMap.getSize("SORGU_LISTE") - 1, "SORGU_NO"));

			oMap = GMServiceExecuter.call("BNSPR_QRY3890_LKS_SORGU_GELEN_DETAY", lMap);
			if (oMap.get("GELEN_SORGU_LISTE") != null) {
				for (int i = 0; i < oMap.getSize("GELEN_SORGU_LISTE"); i++) {
					if (oMap.getString("GELEN_SORGU_LISTE", i, "BANKAMIZ_LIMITI_MI") != null && "1".equals(oMap.getString("GELEN_SORGU_LISTE", i, "BANKAMIZ_LIMITI_MI")))
						return true;
				}
			}

			return false;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	// Bildirimi yapilan kayitlar i�in update islemi yapilir
	public static void updateLksBildirim(BigDecimal basvuruNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<LksislemBildirim> lksBildirim = session.createCriteria(LksislemBildirim.class).add(Restrictions.eq("basvuruNo", basvuruNo)).list();
		for (LksislemBildirim list : lksBildirim) {
			if (list.getBildirimDurumu().equals("H")) {
				list.setBildirimDurumu("S");
				session.update(list);

			}
		}
		session.flush();
		session.clear();
	}

	// Bildirimi Job ile yap�lacak olan ba�vuruya ait eski kay�tlar� g�nceller
	public static void updateLksBildirim(BigDecimal basvuruNo, BigDecimal sorguNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<LksislemBildirim> lksBildirim = session.createCriteria(LksislemBildirim.class).add(Restrictions.eq("basvuruNo", basvuruNo)).list();
		for (LksislemBildirim list : lksBildirim) {
			if (list.getBildirimDurumu().equals("H") && list.getSorguNo().compareTo(sorguNo) != 0) {
				list.setBildirimDurumu("S");
				session.update(list);
			}

		}
		session.flush();
		session.clear();

	}

	// 2014'ten beri bildirimi yapilmayan lks kayitlarini bulup, tekrar bildirimi yapan servis
	@GraymoundService("BNSPR_LKS_MANUEL_TAHSIS_YAP")
	public static GMMap lksManuelTahsisYap(GMMap iMap) {
		try {

			GMMap oMap = new GMMap();
			String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'03') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
			if (oMap.isEmpty()) {
				throw new Exception("Kayit Bulunamadi");
			}

			// LKS sorgusu yap
			GMMap lMap = new GMMap();
			oMap.put("MANUEL_SORGU", "E");
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_ONLINE_TAHSIS_YAP", oMap));
			// Limit bilgisini al
			if (oMap.get("GIDEN_SORGU_DETAY", 0, "GUNCEL_LIMIT") != null)
				oMap.put("GUNCEL_LIMIT", oMap.get("GIDEN_SORGU_DETAY", 0, "GUNCEL_LIMIT"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	// Limit artt�r�mda Bas�m'da kalan kay�tlar�n ilerletilmesini sa�layanJob
	@GraymoundService("BNSPR_LIMIT_ARTTIRIM_BASIMDA_KALAN_ISLEMLERIN_ILERLETILMESI")
	public static GMMap limitArttirimTakilanIslemlerinIlerletilmesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<KkBasvuru> kkBasvuru = session.createCriteria(KkBasvuru.class).add(Restrictions.eq("durumKod", "BASIM")).add(Restrictions.eq("kartSeviyesi", "L")).list();
		for (KkBasvuru list : kkBasvuru) {
			list.setDurumKod("LKS_JOB_2");
			session.save(list);
		}
		session.flush();
		session.clear();
		oMap.put("RESPONSE_DATA", "ISLEM_BASARILI");
		return oMap;
	}

	// Toplu limit artt�r�m jon
	@GraymoundService("BNSPR_TOPLU_LIMIT_ARTTIRIM_JOB")
	public static GMMap topluLimitArttirimJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = null;

		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<ManuelLksBildirim> manuelBasvuruList = session.createCriteria(ManuelLksBildirim.class).add(Restrictions.eq("status", "4")).list();
		session.clear();

		ManuelLksBildirim bildirim = new ManuelLksBildirim();

		for (ManuelLksBildirim manuelBasvuru : manuelBasvuruList) {

			try {
				basvuruNo = manuelBasvuru.getBasvuruNo();
				ekTahsisSorguYap(basvuruNo);
				tahsisEkLimitAl(basvuruNo);
				bildirim.setBasvuruNo(basvuruNo);
				bildirim.setStatus("1");
				session.update(bildirim);
			}
			catch (Exception e) {
				bildirim.setBasvuruNo(basvuruNo);
				bildirim.setStatus("2");
				bildirim.setDescription(StringUtils.left(e.getMessage().toString(), 300));
				session.update(bildirim);
			}
			finally {
				session.flush();
				session.clear();
			}
		}
		oMap.put("RESPONSE_DATA", "ISLEM_BASARILI");
		return oMap;
	}

	private static void ekTahsisSorguYap(BigDecimal basvuruNo) throws Exception {

		GMMap oMap = new GMMap();
		String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'02') }";
		oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, basvuruNo);
		if (oMap.isEmpty()) {
			throw new Exception("Kayit Bulunamadi");

		}

		// LKS sorgusu yap

		oMap.put("SOYADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "SOYADI"));
		oMap.put("MUSTERI_NO", oMap.getString("GIDEN_SORGU_DETAY", 0, "MUSTERI_NO"));
		oMap.put("IKINCI_ADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "IKINCI_ADI"));
		oMap.put("BABA_ADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "BABA_ADI"));
		oMap.put("TCKN", oMap.getString("GIDEN_SORGU_DETAY", 0, "TCKN"));
		oMap.put("BASVURU_NO", oMap.getString("GIDEN_SORGU_DETAY", 0, "BASVURU_NO"));
		oMap.put("ILK_ADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "ILK_ADI"));
		oMap.put("MANUEL_SORGU", "E");
		oMap.put("SORGU_TIPI", "02");
		GMServiceExecuter.executeNT("BNSPR_QRY3893_LKS_MANUEL_TAHSIS_SORGU_YAP", oMap);

	}

	private static void tahsisEkLimitAl(BigDecimal basvuruNo) throws Exception {

		GMMap cMap = new GMMap();
		GMMap lMap = new GMMap();

		String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'04') }";
		cMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, basvuruNo);
		if (cMap.isEmpty()) {
			throw new Exception("Kayit Bulunamadi");
		}

		lMap.put("SOYADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "SOYADI"));
		lMap.put("MUSTERI_NO", cMap.getString("GIDEN_SORGU_DETAY", 0, "MUSTERI_NO"));
		lMap.put("IKINCI_ADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "IKINCI_ADI"));
		lMap.put("BABA_ADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "BABA_ADI"));
		lMap.put("TCKN", cMap.getString("GIDEN_SORGU_DETAY", 0, "TCKN"));
		lMap.put("BASVURU_NO", cMap.getString("GIDEN_SORGU_DETAY", 0, "BASVURU_NO"));
		lMap.put("ILK_ADI", cMap.getString("GIDEN_SORGU_DETAY", 0, "ILK_ADI"));
		lMap.put("MANUEL_SORGU", "E");
		lMap.put("SORGU_TIPI", "04");
		cMap.clear();

		GMServiceExecuter.call("BNSPR_QRY3893_LKS_MANUEL_EK_TAHSIS_YAP", lMap);

	}

	@GraymoundService("BNSPR_RM_UPDATE_CUSTOMER_DOCUMENT_JOB")
	public static GMMap updateCardCustomerDocumentJob(GMMap iMap) {
		iMap.put(JOB_NAME, "RM_UPDATE_CUSTOMER_DOCUMENTS");
		return processCreditCardJob(SERVICE_NAME_LIST_RM_DOCUMENT_UPDATE_JOB, SERVICE_NAME_PROCESS_RM_DOCUMENT_UPDATE_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_RM_DOCUMENT_UPDATE_JOB)
	public static GMMap listCardCustomerDocumentJob(GMMap iMap) {
		return listCreditCardJob("PKG_TFF_RM_DOKUMAN.listDocumentUpdate");
	}

	@GraymoundService("BNSPR_TFF_VADE_YENILEME_JOB")
	public static GMMap tffVadeYenilemeJob(GMMap iMap) {
		iMap.put(JOB_NAME, "BNSPR_TFF_VADE_YENILEME_JOB");
		return processCreditCardJob(SERVICE_NAME_LIST_VADE_YENILEME_JOB, SERVICE_NAME_PROCESS_VADE_YENILEME_JOB, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_VADE_YENILEME_JOB)
	public static GMMap listVadeYenilemeJob(GMMap iMap) {
		return listCreditCardJob("PKG_TRN3828.listVadeYenilemeBatch");
	}

	// 38 g�n kahramanmara� hesab�nda bekleyen tutarlar�n, ba�ka bir ekent hesab�na aktar�lmas�
	@GraymoundService("BNSPR_MARAS_BLOKE_TUTAR_TRANSFER_JOB")
	public static GMMap blokeMarasTutarTransferJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		String productCode = "4617";
		BigDecimal txNo = null;

		txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
		// Aktar�lacak tutar� hesapla
		oMap.putAll(GMServiceExecuter.call("BNSPR_HESAPLA_MARAS_BLOKE_TUTAR", oMap));
		// 4614 Muhasebesi i�in crd_ticket_sale_tx tablosunda transfer yap
		insertProductSaleTxForMaras(oMap.getBigDecimal("TOPLAM_TUTAR"), txNo, productCode);

		try {

			iMap.put("TRX_NAME", productCode);
			iMap.put("TRX_NO", txNo);
			GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {

			throw new GMRuntimeException(14017, "Muhasebe hatas� : " + e.getMessage());
		}

		return oMap;

	}

	// MARAS Bloke hesaptaki 38 g�n bekleyen para y�kleme ve �deme i�lemlerinin toplam tutar�n� d�ner
	@GraymoundService("BNSPR_HESAPLA_MARAS_BLOKE_TUTAR")
	public static GMMap hesaplaMarasHceBlokeTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		String aliciHesap = "";
		BigDecimal toplamTutar = new BigDecimal(0);
		int count = 0;
		int blokeGunSayisi = 0;
		try {

			GMContext.getCurrentContext().getSession().get("USER_NAME");

			Session session = DAOSession.getSession("BNSPRDal");

			aliciHesap = getGlobalParam("MARAS_BLOKE_HESAP");

			// Muhasebesi ger�ekle�mi�, Ekent ula��m hesab�na yap�lm�� ve 28 g�n ge�mi� kay�tlar� listeler
			@SuppressWarnings("unchecked")
			List<CrdTicketSaleTx> listAnkaraKartTransfer = session.createCriteria(CrdTicketSaleTx.class).add(Restrictions.eq("durumKodu", "M")).add(Restrictions.eq("aliciHesapNo", aliciHesap)).add(Restrictions.sqlRestriction("trunc(rec_date + ?) = trunc(SYSDATE)", getGlobalParam("EKENT_BLOKE_GUN_SAYISI"), Hibernate.STRING)).list();

			for (CrdTicketSaleTx list : listAnkaraKartTransfer) {
				try {

					// M stat�l� olanlar i�lem sekli N toplan�yor, R ve V olanlar ��kar�l�yor
					if (list.getIslemSekli().equals("N"))
						toplamTutar = toplamTutar.add(list.getTutar());
					else
						toplamTutar = toplamTutar.subtract(list.getTutar());

					// Ge�ici hesaptaki i�lemlerin durumKodu 'T' stat�s�ne �ekiliyor ki bir daha gitmesin. Job ihtiya� olursa g�nde n kez �a�r�labilir.
					list.setDurumKodu("T");
					oMap.put("LIST", count, "DURUM", "BASARILI");
					oMap.put("LIST", count, "TX_NO", list.getTxNo());
					oMap.put("LIST", count, "TUTAR", list.getTutar());
					oMap.put("LIST", count, "ISLEM_SEKLI", list.getIslemSekli());

					session.saveOrUpdate(list);
					session.flush();

				}
				catch (Exception e) { // Hata almas� durumunda �nemseme
					toplamTutar = toplamTutar;
					oMap.put("LIST", count, "DURUM", "BASARISIZ");
					oMap.put("LIST", count, "TX_NO", list.getTxNo());
					oMap.put("LIST", count, "TUTAR", list.getTutar());
					oMap.put("LIST", count, "ISLEM_SEKLI", list.getIslemSekli());

				}
				count++;

			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		oMap.put("TOPLAM_TUTAR", toplamTutar);
		return oMap;

	}

	public static void insertProductSaleTxForMaras(BigDecimal tutar, BigDecimal txNo, String productCode) {
		Session session = DAOSession.getSession("BNSPRDal");

		CrdTicketSaleTx saleTx = new CrdTicketSaleTx();

		saleTx.setAciklama("MARA� ULA�IM KARTA TRANSFER");
		saleTx.setAliciHesapCinsi(getGlobalParam("MARAS_ALACAKLI_HESAP_CINSI"));
		saleTx.setAliciHesapNo(getGlobalParam("MARAS_ALACAKLI_HESAP"));
		saleTx.setBorcHesapCinsi(getGlobalParam("MARAS_BLOKE_HESAP_CINSI"));
		saleTx.setBorcHesapNo(getGlobalParam("MARAS_BLOKE_HESAP"));
		saleTx.setDovizKodu("TRY");
		saleTx.setDurumKodu("A");
		saleTx.setIslemSekli("N");
		saleTx.setKanal("MARASBLOKE");
		saleTx.setKartKaynagi("O");
		saleTx.setMasrafTahsilDoviz("TRY");
		saleTx.setSube(getGlobalParam("EKENT_BLOKE_HESAP_SUBE"));
		saleTx.setTutar(tutar);
		saleTx.setTxNo(txNo);
		saleTx.setProductCode(new BigDecimal(productCode));
		saleTx.setAlacakSube(getGlobalParam("EKENT_ALACAKLI_SUBE"));
		saleTx.setIslemCinsi("D");

		session.save(saleTx);
		session.flush();

	}

	@GraymoundService("BNSPR_NONAME_CRD_KURYE_DATA_JOB")
	public static GMMap nonameKuryeData(GMMap iMap) {

		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Session session = DAOSession.getSession("BNSPRDal");

		try {

			List<GnlParamText> firmalar = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "NONAME_CARD_KURYE_FIRMA")).addOrder(Order.asc("siraNo")).list();

			for (GnlParamText firma : firmalar) {

				int i = 1;
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_kurye.nonamecrd_kurye_data(?)}");

				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, firma.getSiraNo());
				stmt.execute();
				stmt.getMoreResults();
				rSet = (ResultSet) stmt.getObject(1);

				int row = 0;

				while (rSet.next()) {
					iMap.put("LINE_LIST", row, "PROJE_KODU", "NONAMECRD");
					iMap.put("LINE_LIST", row, "BASVURU_NO", rSet.getString("BASVURU_NO"));
					iMap.put("LINE_LIST", row, "BARKOD_NO", rSet.getString("BARKOD_NO"));
					iMap.put("LINE_LIST", row, "AD", rSet.getString("AD"));
					iMap.put("LINE_LIST", row, "SOYAD", rSet.getString("SOYAD"));
					iMap.put("LINE_LIST", row, "TELEFON1", rSet.getString("TELEFON1"));
					iMap.put("LINE_LIST", row, "TELEFON2", rSet.getString("TELEFON2"));
					iMap.put("LINE_LIST", row, "EMAIL", rSet.getString("EMAIL"));
					iMap.put("LINE_LIST", row, "ADRES1_DETAY", rSet.getString("ADRES1_DETAY") == null ? " " : rSet.getString("ADRES1_DETAY"));
					iMap.put("LINE_LIST", row, "ADRES1_ILCE", rSet.getString("ADRES1_ILCE") == null ? " " : rSet.getString("ADRES1_ILCE"));
					iMap.put("LINE_LIST", row, "ADRES1_IL", rSet.getString("ADRES1_IL") == null ? " " : rSet.getString("ADRES1_IL"));
					iMap.put("LINE_LIST", row, "ADRES2_DETAY", rSet.getString("ADRES2_DETAY") == null ? " " : rSet.getString("ADRES2_DETAY"));
					iMap.put("LINE_LIST", row, "ADRES2_ILCE", rSet.getString("ADRES2_ILCE") == null ? " " : rSet.getString("ADRES2_ILCE"));
					iMap.put("LINE_LIST", row, "ADRES2_IL", rSet.getString("ADRES2_IL") == null ? " " : rSet.getString("ADRES2_IL"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_1", rSet.getString("DOKUMAN_KOD_1"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_1", rSet.getString("DOKUMAN_ADI_1"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_2", rSet.getString("DOKUMAN_KOD_2"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_2", rSet.getString("DOKUMAN_ADI_2"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_3", rSet.getString("DOKUMAN_KOD_3"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_3", rSet.getString("DOKUMAN_ADI_3"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_4", rSet.getString("DOKUMAN_KOD_4"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_4", rSet.getString("DOKUMAN_ADI_4"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_5", rSet.getString("DOKUMAN_KOD_5"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_5", rSet.getString("DOKUMAN_ADI_5"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_6", rSet.getString("DOKUMAN_KOD_6"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_6", rSet.getString("DOKUMAN_ADI_6"));

					row++;
				}

				iMap.put("KURYE_KOD", firma.getSiraNo());

				SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyy");
				iMap.put("FILE_NAME", firma.getKey1() + "_" + "NonameCrd" + "_" + sdf.format(new Date()) + ".txt");

				iMap.put("FTP_CREDENTIAL_PARAMCODE", firma.getKey2());
				iMap.put("PROJE_KODU", "NONAMECRD");
				GMServiceExecuter.execute("BNSPR_EXT_CREATE_KURYE_TOPLU_GONDERIM_DOSYASI", iMap);
				iMap.clear();
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_MSTEDINIM_KURYE_DATA_JOB")
	public static GMMap musteriEdinimKuryeData(GMMap iMap) {

		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Session session = DAOSession.getSession("BNSPRDal");

		try {

			List<GnlParamText> firmalar = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "MSTEDINIM_KURYE_FIRMA")).addOrder(Order.asc("siraNo")).list();

			for (GnlParamText firma : firmalar) {

				int i = 1;
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_kurye.mstedinim_kurye_data(?)}");

				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, firma.getSiraNo());
				stmt.execute();
				stmt.getMoreResults();
				rSet = (ResultSet) stmt.getObject(1);

				int row = 0;

				while (rSet.next()) {
					iMap.put("LINE_LIST", row, "PROJE_KODU", "MSTEDINIM");
					iMap.put("LINE_LIST", row, "BASVURU_NO", rSet.getString("BASVURU_NO"));
					iMap.put("LINE_LIST", row, "BARKOD_NO", rSet.getString("BARKOD_NO"));
					iMap.put("LINE_LIST", row, "AD", rSet.getString("AD"));
					iMap.put("LINE_LIST", row, "SOYAD", rSet.getString("SOYAD"));
					iMap.put("LINE_LIST", row, "TELEFON1", rSet.getString("TELEFON1"));
					iMap.put("LINE_LIST", row, "TELEFON2", rSet.getString("TELEFON2"));
					iMap.put("LINE_LIST", row, "EMAIL", rSet.getString("EMAIL"));
					iMap.put("LINE_LIST", row, "ADRES1_DETAY", rSet.getString("ADRES1_DETAY") == null ? " " : rSet.getString("ADRES1_DETAY"));
					iMap.put("LINE_LIST", row, "ADRES1_ILCE", rSet.getString("ADRES1_ILCE") == null ? " " : rSet.getString("ADRES1_ILCE"));
					iMap.put("LINE_LIST", row, "ADRES1_IL", rSet.getString("ADRES1_IL") == null ? " " : rSet.getString("ADRES1_IL"));
					iMap.put("LINE_LIST", row, "ADRES2_DETAY", rSet.getString("ADRES2_DETAY") == null ? " " : rSet.getString("ADRES2_DETAY"));
					iMap.put("LINE_LIST", row, "ADRES2_ILCE", rSet.getString("ADRES2_ILCE") == null ? " " : rSet.getString("ADRES2_ILCE"));
					iMap.put("LINE_LIST", row, "ADRES2_IL", rSet.getString("ADRES2_IL") == null ? " " : rSet.getString("ADRES2_IL"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_1", rSet.getString("DOKUMAN_KOD_1"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_1", rSet.getString("DOKUMAN_ADI_1"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_2", rSet.getString("DOKUMAN_KOD_2"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_2", rSet.getString("DOKUMAN_ADI_2"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_3", rSet.getString("DOKUMAN_KOD_3"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_3", rSet.getString("DOKUMAN_ADI_3"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_4", rSet.getString("DOKUMAN_KOD_4"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_4", rSet.getString("DOKUMAN_ADI_4"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_5", rSet.getString("DOKUMAN_KOD_5"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_5", rSet.getString("DOKUMAN_ADI_5"));
					iMap.put("LINE_LIST", row, "DOKUMAN_KOD_6", rSet.getString("DOKUMAN_KOD_6"));
					iMap.put("LINE_LIST", row, "DOKUMAN_ADI_6", rSet.getString("DOKUMAN_ADI_6"));

					row++;
				}

				iMap.put("KURYE_KOD", firma.getSiraNo());

				SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyy");
				iMap.put("FILE_NAME", firma.getKey1() + "_" + "MstEdinim" + "_" + sdf.format(new Date()) + ".txt");

				iMap.put("FTP_CREDENTIAL_PARAMCODE", firma.getKey2());
				iMap.put("PROJE_KODU", "MSTEDINIM");
				GMServiceExecuter.execute("BNSPR_EXT_CREATE_KURYE_TOPLU_GONDERIM_DOSYASI", iMap);
				iMap.clear();
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_SANAL_KART_OTO_IPTAL_JOB")
	public static GMMap sanalKartOtoIptalJob(GMMap iMap) {
		iMap.put(JOB_NAME, "BNSPR_SANAL_KART_OTO_IPTAL_JOB");
		iMap.put("IS_CANCELLED_BY_JOB", true);

		return processCreditCardJob(SERVICE_NAME_LIST_SANAL_KART_OTO_IPTAL, SERVICE_NAME_PROCESS_SANAL_KART_OTO_IPTAL, iMap);
	}

	@GraymoundService(SERVICE_NAME_LIST_SANAL_KART_OTO_IPTAL)
	public static GMMap listSanalKartOtoIptalJob(GMMap iMap) {
		return listCreditCardJob("PKG_KK_BASVURU.listSanalKartOtoIptalJob");
	}
	
	@GraymoundService("BNSPR_KK_UAT_KURYE_SUREC")
	public static GMMap uatKuryeSurec(GMMap iMap){
		
		iMap.put(JOB_NAME, "BNSPR_KK_UAT_KURYE_SUREC");
		iMap.put("IS_CANCELLED_BY_JOB", true);
		
		return processCreditCardJob(SERVICE_NAME_LIST_KK_UAT_KURYE_SUREC, SERVICE_NAME_PROCESS_KK_UAT_KURYE_SUREC,iMap);	
	}
	
	@GraymoundService(SERVICE_NAME_LIST_KK_UAT_KURYE_SUREC)
	public static GMMap listUatKuryeSurec(GMMap iMap){
		
		GMMap resultMap = new GMMap();
		try{
			resultMap = listCreditCardJob("PKG_KK_BASVURU.list_kk_uat_kurye_surec");
			
		}catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return resultMap;
		
	}
}