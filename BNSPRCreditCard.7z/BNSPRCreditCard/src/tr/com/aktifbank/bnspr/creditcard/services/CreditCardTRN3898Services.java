package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKararCozmeTx;
import tr.com.aktifbank.bnspr.dao.KkLimitGuncelleme;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3898Services {
	private static final String ISLEM_KODU_LIMIT_ARTTIRIM_IPTAL = "3822";
	/**
	 * Basvuru izleme ekrani acilirken, baslangicta dolmasi gereken alanlari doner.
	 * 
	 * @param iMap
	 * 
	 * @return oMap - DURUM, KART_TIPI_LIST, KANAL_LIST
	 */
	@GraymoundService("BNSPR_QRY3898_MODAL_FILL_INITIAL_VALUES")
	public static GMMap fillInitialValues(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			//Durum veri tamamlama yapilamaz
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'KK_BASVURU_DURUM_KOD'");
			query.append(" AND KEY1 NOT IN ('FOTO_EKSIK','VERI_TAMAMLAMA','BASIM','ACIK','RED')");
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "DURUM", true, query.toString());
			
			// Kart tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "OCEAN_BASVURU_KART_TIPI", "E"));
			// Kanal Listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3872_KANAL_LIST", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3898_FILL_DURUM_LIST")
	public static GMMap getOnayStatuListYeni(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			//Eski durumlar
			oMap.putAll(CreditCardServicesUtil.getParameterList("ESKI_DURUM", "KK_BASVURU_DURUM_KOD", "E"));
			
			//Yeni durum icin kart tipi kontrolu yap, //Durum veri tamamlama yapilamaz
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			if (basvuruNo == null) {
				KkBasvuruKararCozmeTx kkBasvuruKararCozmeTx = (KkBasvuruKararCozmeTx) 
						session.get(KkBasvuruKararCozmeTx.class, iMap.getBigDecimal("TRX_NO"));
				basvuruNo = kkBasvuruKararCozmeTx.getBasvuruNo();
			}
			
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
			//Kart tipi bazli sorgu
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'KK_BASVURU_DURUM_KOD'");
			if ("D".equals(kkBasvuru.getKartTipi())) {
				query.append(" AND KEY1 IN ('IPTAL')");
			} else {
				query.append(" AND KEY1 NOT IN ('FOTO_EKSIK','VERI_TAMAMLAMA','BASIM','ACIK','RED')");
			}
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "YENI_DURUM", true, query.toString());
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Girilen kriterlere gore arama yapip, basvuru listesi doner.
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO, KREDI_KART_TIPI, ADI, IKINCI_ADI,
	 *             SOYADI, DURUM_LIST, BASLANGIC_TAR, BITIS_TAR, IPTAL,KANAL_KODU, BAYI_KODU
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_QRY3898_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruIzlemeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3898.Rc_Qry3898_List_Basvuru(?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("KREDI_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," :
                CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));
			
			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
				
			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}

			if (iMap.getBoolean("IPTAL") == true) {
				stmt.setString(i++, "TRUE");
			} else {
				stmt.setString(i++, "FALSE");
			}
			
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("BAYI_KODU"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3898_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			KkBasvuruKararCozmeTx kkBasvuruKararCozmeTx = new KkBasvuruKararCozmeTx();
			kkBasvuruKararCozmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kkBasvuruKararCozmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kkBasvuruKararCozmeTx.setEskiDurumKodu(iMap.getString("ESKI_DURUM_KODU"));
			kkBasvuruKararCozmeTx.setYeniDurumKodu(iMap.getString("YENI_DURUM_KODU"));
			kkBasvuruKararCozmeTx.setAciklama(iMap.getString("ACIKLAMA"));
			kkBasvuruKararCozmeTx.setKararGerekce(iMap.getString("GEREKCE"));
			
			session.save(kkBasvuruKararCozmeTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3898");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3898_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			KkBasvuruKararCozmeTx kkBasvuruKararCozmeTx = (KkBasvuruKararCozmeTx)
					session.get(KkBasvuruKararCozmeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkBasvuruKararCozmeTx != null) {
				oMap.put("TX_NO", kkBasvuruKararCozmeTx.getTxNo());
				oMap.put("BASVURU_NO", kkBasvuruKararCozmeTx.getBasvuruNo());
				oMap.put("ESKI_DURUM_KOD", kkBasvuruKararCozmeTx.getEskiDurumKodu());
				oMap.put("YENI_DURUM_KOD", kkBasvuruKararCozmeTx.getYeniDurumKodu());
				oMap.put("ACIKLAMA", kkBasvuruKararCozmeTx.getAciklama());
				oMap.put("GEREKCE", kkBasvuruKararCozmeTx.getKararGerekce());
			} else {
				oMap.put("TX_NO", StringUtils.EMPTY);
				oMap.put("BASVURU_NO", StringUtils.EMPTY);
				oMap.put("ESKI_DURUM_KOD", StringUtils.EMPTY);
				oMap.put("YENI_DURUM_KOD", StringUtils.EMPTY);
				oMap.put("ACIKLAMA", StringUtils.EMPTY);
				oMap.put("GEREKCE", StringUtils.EMPTY);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Iptal islemi sonrasi tff basvurusu varsa onay sonrasi islemleri gerceklestirir.<br>
	 * @author murat.el
	 * @since 27.02.2014
	 * @param iMap - Islem bilgileri<br>
	 *         <li>ISLEM_NO - Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3898_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			KkBasvuruKararCozmeTx kkBasvuruKararCozmeTx = (KkBasvuruKararCozmeTx) session.get(KkBasvuruKararCozmeTx.class, trxNo);
			if (kkBasvuruKararCozmeTx != null) {
				// Limit basvurusu ise durumu guncelle
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkBasvuruKararCozmeTx.getBasvuruNo());
				if (kkBasvuru != null && "L".equals(kkBasvuru.getKartSeviyesi())) {
					if ("IPTAL".equals(kkBasvuruKararCozmeTx.getYeniDurumKodu()) ||
							"RED".equals(kkBasvuruKararCozmeTx.getYeniDurumKodu())) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
						sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuruKararCozmeTx.getYeniDurumKodu());
						sorguMap.put("LKS_RED_MI", CreditCardServicesUtil.HAYIR);
						
						sorguMap.put("SCREEN_CODE", ISLEM_KODU_LIMIT_ARTTIRIM_IPTAL);
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
					} else {
						String sonrakiDurumKodu = "KREDI_KARTI";
						if ("ACIK".equals(kkBasvuruKararCozmeTx.getYeniDurumKodu())) {
							sonrakiDurumKodu = "ONAY";
						}
						
						//Basvuru nodan limit guncelleme kaydini bul
						KkLimitGuncelleme kkLimitGuncelleme = (KkLimitGuncelleme)
								session.createCriteria(KkLimitGuncelleme.class)
								.add(Restrictions.eq("basvuruNo", kkBasvuru.getBasvuruNo()))
								.uniqueResult();
						if (kkLimitGuncelleme == null) {
							CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
						}
						
						//Durum guncelle
						sorguMap.clear();
						sorguMap.put("ISLEM_FLAG", "G");
						sorguMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
						sorguMap.put("ID", kkLimitGuncelleme.getId());
						sorguMap.put("DURUM_KOD", sonrakiDurumKodu);
						sorguMap.put("ONCEKI_DURUM_KOD", kkLimitGuncelleme.getDurumKod());
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
					}
				}
				// Sonraki durum iptal ise Iliskili TFF basvurusu varsa iptal edilsin
				if ("IPTAL".equals(kkBasvuruKararCozmeTx.getYeniDurumKodu())) {
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
							.add(Restrictions.eq("kkBasvuruNo", kkBasvuruKararCozmeTx.getBasvuruNo()))
							.uniqueResult();
					if (tffBasvuru != null && !"IPTAL".equals(tffBasvuru.getDurumKod())) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
						sorguMap.put("ISLEM_KOD", "3898");
						sorguMap.put("GEREKCE_KOD", "4");//Otomatik Iptal
						sorguMap.put("ACIKLAMA", kkBasvuruKararCozmeTx.getAciklama());
						sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
						GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap);
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
