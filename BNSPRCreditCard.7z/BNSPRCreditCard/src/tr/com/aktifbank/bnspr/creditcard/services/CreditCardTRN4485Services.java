package tr.com.aktifbank.bnspr.creditcard.services;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaTakastaniadeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4485Services implements OceanMapKeys{
	
	@GraymoundService("BNSPR_TRN4485_GET_CARD_LIST")
	public static GMMap getCardList (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap cMap = new GMMap();
			GMMap lMap = new GMMap();
			GMMap dMap = new GMMap();
			cMap.put(INPUT_PARAMETER_TYPE, "CST");
			cMap.put(CUSTOMER_NO, iMap.getBigDecimal("MUST_NO"));
			cMap.put("NO_NEED_APPLICATIONS", true);
			cMap.put("NO_NEED_INTRACARDS_CARDS", iMap.getBoolean("NO_NEED_INTRACARDS_CARDS"));
			cMap.put("NO_NEED_OCEAN_CARDS", iMap.getBoolean("NO_NEED_OCEAN_CARDS"));
			cMap.put("CARD_BANK_STATUS_CC", "A");
			if (iMap.getString("IS_PROCEED").equals("E")){
				cMap.put("PROCEED", "ONLY");
			}
			lMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", cMap);
			int j=0;
			int s = lMap.getSize("CARD_DETAIL_INFO"); 
			for (int i = 0; i < s; i++) {
				String dci = lMap.getString("CARD_DETAIL_INFO",i,"CARD_DCI_AKUSTIK");
				if (StringUtil.isEmpty(iMap.getString("KART_TURU")) || dci.equals(iMap.getString("KART_TURU"))){
				oMap.put("TABLO",j, "CARD_NO",lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"));
				oMap.put("TABLO",j, "CUSTOMER_NO",lMap.getBigDecimal("CARD_DETAIL_INFO",i,"CUSTOMER_NO"));
				oMap.put("TABLO",j, "CARD_DCI",dci);
				oMap.put("TABLO",j, "CARD_STAT_DESC",lMap.getString("CARD_DETAIL_INFO",i,"CARD_STAT_DESC"));
				oMap.put("TABLO",j, "CARD_EMBOSS_NAME",lMap.getString("CARD_DETAIL_INFO",i,"CARD_EMBOSS_NAME_1"));
				if(dci.equals("D")){
				dMap.clear();
				dMap.put("KART_NO", lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"));
				dMap =getDebitCardMainAccount(dMap);
						
				oMap.put("TABLO", j,"ACCOUNT_NO",dMap.getString("HESAP_NO"));
				}
				j=j+1;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@SuppressWarnings("deprecation")
	@GraymoundService("BNSPR_TRN4485_SAVE")
	public static GMMap save(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
		String ey ="";
		String mv = "";
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int cmonth = cal.get(Calendar.MONTH);
		int cday = cal.get(Calendar.DAY_OF_MONTH);
		int cyear = cal.get(Calendar.YEAR);
		cal.setTime(iMap.getDate("ISLEM_TARIHI"));
		int tmonth = cal.get(Calendar.MONTH);
		int tyear = cal.get(Calendar.YEAR);
		
		if(iMap.getString("ISLEM_TIPI").equals("TK06") ||  iMap.getString("ISLEM_TIPI").equals("TK08") ){
			if (cmonth == tmonth){
				ey="Y";
			}
			else if (cmonth == tmonth+1 && cday<=10 ){
				ey="Y";
			}
			else if (cyear== tyear+1 && cmonth==0 && tyear==11 && cday<=10){
				ey="Y";
			}
			else{
				ey="E";
			}
		}else{
			ey="Y";
		}
		
		
		BigDecimal komisyon = iMap.getBigDecimal("KOMISYON").divide(BigDecimal.valueOf(1.05),2,BigDecimal.ROUND_HALF_UP);
		BigDecimal bsmv =  iMap.getBigDecimal("KOMISYON").subtract(komisyon);
		SbaTakastaniadeTx sbaTakastaniadeTx = new SbaTakastaniadeTx();
		sbaTakastaniadeTx.setAciklama(iMap.getString("ACIKLAMA"));
		sbaTakastaniadeTx.setBsmv(bsmv);
		sbaTakastaniadeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
		sbaTakastaniadeTx.setKartNo(iMap.getString("KART_NO"));
		sbaTakastaniadeTx.setKomisyon(komisyon);
		sbaTakastaniadeTx.setKur(iMap.getBigDecimal("KUR"));
		sbaTakastaniadeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
		if (iMap.getBoolean("TFF")){
			mv="T"+ey;
			sbaTakastaniadeTx.setTffOcean("T");
		}
		if (iMap.getBoolean("OCEAN")){
			mv="O"+ey;
			sbaTakastaniadeTx.setTffOcean("O");
		}
		sbaTakastaniadeTx.setMv(mv);
		sbaTakastaniadeTx.setServiceCode(iMap.getString("ISLEM_TIPI"));
		sbaTakastaniadeTx.setServiceName("");
		sbaTakastaniadeTx.setTarih(iMap.getDate("ISLEM_TARIHI"));
		sbaTakastaniadeTx.setTopKom(iMap.getBigDecimal("KOMISYON"));
		sbaTakastaniadeTx.setTutar(iMap.getBigDecimal("TUTAR"));
		sbaTakastaniadeTx.setTutarTl(iMap.getBigDecimal("TUTAR").multiply(iMap.getBigDecimal("KUR")).setScale(2,BigDecimal.ROUND_HALF_UP));
		sbaTakastaniadeTx.setTutarUsd(iMap.getBigDecimal("TUTAR"));
		sbaTakastaniadeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		sbaTakastaniadeTx.setBankaAciklama(iMap.getString("BANKA_ACIKLAMA"));
		sbaTakastaniadeTx.setTelefon(iMap.getString("TELEFON"));
		sbaTakastaniadeTx.setSmsGonder(iMap.getBoolean("SMS_GONDER")?"E":"H");
		session.saveOrUpdate(sbaTakastaniadeTx);
		session.flush();
		iMap.put("TRX_NAME" , "4485");
		oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4485_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaTakastaniadeTx sbaTakastaniadeTx = (SbaTakastaniadeTx) session.createCriteria(SbaTakastaniadeTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO") )).uniqueResult();
			oMap.put("ACIKLAMA", sbaTakastaniadeTx.getAciklama());
			oMap.put("HESAP_NO", sbaTakastaniadeTx.getHesapNo());
			oMap.put("ISLEM_TARIHI", sbaTakastaniadeTx.getTarih());
			oMap.put("ISLEM_TIPI", sbaTakastaniadeTx.getServiceCode());
			oMap.put("KOMISYON", sbaTakastaniadeTx.getTopKom());
			oMap.put("KART_NO", sbaTakastaniadeTx.getKartNo());
			oMap.put("KUR", sbaTakastaniadeTx.getKur());
			oMap.put("MUSTERI_NO", sbaTakastaniadeTx.getMusteriNo());
			oMap.put("TELEFON", sbaTakastaniadeTx.getTelefon());
			oMap.put("SMS_GONDER", sbaTakastaniadeTx.getSmsGonder().equals("E")?true:false);
			if(sbaTakastaniadeTx.getMv().startsWith("T")){
				oMap.put("TFF", true);
				oMap.put("OCEAN", false);
			}
			else if(sbaTakastaniadeTx.getMv().startsWith("O")){
				oMap.put("OCEAN", true);
				oMap.put("TFF", false);
			}
			oMap.put("TUTAR", sbaTakastaniadeTx.getTutar());
			oMap.put("BANKA_ACIKLAMA", sbaTakastaniadeTx.getBankaAciklama());
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4485_GET_CARD_ACCOUNT")
	public static GMMap getDebitCardMainAccount(GMMap iMap) {
		
		String account = "0";
		GMMap oMap = new GMMap();
		GMMap mMap = new GMMap();
		GMMap cardProperty = new GMMap();
		cardProperty.put("CARD_NO", iMap.getString("KART_NO"));
		cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cardProperty);
		if (cardProperty.getString("RETURN_CODE").equals("0")) {
		
		GMMap dbMap = new GMMap();
		dbMap.put("CARD_NO", iMap.getString("KART_NO"));
		
		String system = cardProperty.getString("DESTINATION");
		String dci = cardProperty.getString("DCI");
		if (dci.equals("D")){
		if (system.equals(OceanConstants.Card_Source_Intracard)) {
			dbMap = GMServiceExecuter.call("BNSPR_INTRACARD_TFF_GET_DEBIT_CARD_MAIN_ACCOUNT", dbMap);
		}else {
			dbMap = GMServiceExecuter.call("BNSPR_OCEAN_TFF_GET_DEBIT_CARD_MAIN_ACCOUNT", dbMap);
		}
		}
		account = dbMap.getString("DEBIT_ACCOUNT_NO");
		
		
		if (account.equals("0")) {
			
			throw new GMRuntimeException(13022,  "Debit kart ana hesab� bulunamad�.");

		}
		}
		else{
			throw new GMRuntimeException(13031,  "Kart bini tan�m� bulunamad�.");
		}
		mMap.put("HESAP_NO", account);
		mMap = GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", mMap);
		oMap.put("MUSTERI_NO", mMap.getBigDecimal("MUSTERI_NO"));
		oMap.put("HESAP_NO", account);
		return oMap;
		
	}
	@GraymoundService("BNSPR_TRN4485_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
        iMap.put("KOD", "SBA_TAKAS_IADE_ISLEM_TIPI");
        oMap.put("COMBO_OUT", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4485_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap= new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaTakastaniadeTx sbaTakastaniadeTx = (SbaTakastaniadeTx) session.createCriteria(SbaTakastaniadeTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			if(sbaTakastaniadeTx.getServiceCode().equals("ON02") || sbaTakastaniadeTx.getServiceCode().equals("ON03")){
			GMMap cProperty = new GMMap();
			cProperty.put("CARD_NO", sbaTakastaniadeTx.getKartNo());
			cProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cProperty);
			String dest = cProperty.getString("DESTINATION");
			GMMap cardMap = new GMMap();
			GMMap cardRespMap = new GMMap();
			
			cardMap.put(BSMV_RATE, BigDecimal.ZERO);
			cardMap.put(KKF_RATE, BigDecimal.ZERO);
			
			cardMap.put(TXN_AMOUNT, sbaTakastaniadeTx.getTutar());
			cardMap.put(CARD_NO, sbaTakastaniadeTx.getKartNo());
			cardMap.put(TXN_DESC, "Bakiye Aktar�m�");
			cardMap.put(TXN_CURR_CODE, "TRY");
			cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
			cardMap.put(TXN_STATE, "N");

			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			cardMap.put(TXN_DATE, format.format(new Date()));
			
			if (dest.equals("I")) {
				//Prepaid 
				cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
				
			}else if (dest.equals("O")) {
				//Kredi kart� 
				cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
			}
			if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
				throw new GMRuntimeException(4448011, "Kart Transfer Hata : "+ cardRespMap.getString(RETURN_DESCRIPTION));
			}
			}
			if(!StringUtil.isEmpty(sbaTakastaniadeTx.getTelefon()) && sbaTakastaniadeTx.getSmsGonder().equals("E")){
			GMMap uMap = new GMMap();
			uMap.put("MUSTERI_NO", sbaTakastaniadeTx.getMusteriNo());
			uMap = GMServiceExecuter.call("BNSPR_CUST_GET_UNVAN", uMap);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");   
			GMMap sMap = new GMMap();
			sMap.put("CUSTOMER_NAME", uMap.getString("UNVAN"));
			sMap.put("TARIH", df.format(sbaTakastaniadeTx.getTarih()));
			String tutar ="";
			if (sbaTakastaniadeTx.getKur().compareTo(BigDecimal.ZERO)==0){
				tutar = sbaTakastaniadeTx.getTutar().toString() + " " +"TL";
			}else{
				tutar= sbaTakastaniadeTx.getTutar().toString()+" "+"USD";
			}
			sMap.put("TUTAR",tutar);
			sMap.put("TELEFON", sbaTakastaniadeTx.getTelefon());
			sendSMS(sMap, sMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	 private static void sendSMS(GMMap iMap, GMMap oMap) {
	        String MSISDN = iMap.getString("TELEFON");
	        boolean FILTER = false;
	        boolean SECURE_CONTENT = false;
	        GMMap smsMap = new GMMap();
	        smsMap.put("MESSAGE_NO", "5494");
	        smsMap.put("P1", iMap.getString("CUSTOMER_NAME"));
			smsMap.put("P2", iMap.getString("TARIH"));
			smsMap.put("P3", iMap.getString("TUTAR"));
			
			String mesaj = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", smsMap).get("ERROR_MESSAGE");
			
			
	        iMap.put("CONTENT" ,mesaj);
	        
	        String MUSTERI_NO = iMap.getString("CUSTOMER_NO");
	        
	        iMap.put("MSISDN" , MSISDN);
	        iMap.put("FILTER" , FILTER);
	        iMap.put("SECURE_CONTENT" , SECURE_CONTENT);
	        iMap.put("MUSTERI_NO" , MUSTERI_NO);
	        
	        GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC" , iMap);
	    }
	
}
