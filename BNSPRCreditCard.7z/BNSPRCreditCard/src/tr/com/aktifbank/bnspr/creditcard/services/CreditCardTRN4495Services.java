package tr.com.aktifbank.bnspr.creditcard.services;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaChargebackTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4495Services implements OceanMapKeys{
	@GraymoundService("BNSPR_TRN4495_GET_COMBO")
	public static GMMap getCombo(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			iMap.put("KOD" , "4495_ISLEM_TIPLERI");
            iMap.put("ADD_EMPTY_KEY" , "E");
            oMap.put("ISLEM_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN4495_GET_ISLEM_ALT_TIPI")
	public static GMMap getIslemAltTipi(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			iMap.put("KOD" , "4495_ISLEM_ALT_TIPLERI");
			iMap.put("KEY2" , iMap.getString("ISLEM_TIPI"));
	        iMap.put("ADD_EMPTY_KEY" , "E");
	        oMap.put("ISLEM_ALT_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4495_SAVE")
	public static GMMap save(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaChargebackTx sbaChargebackTx = new SbaChargebackTx();
			sbaChargebackTx.setAciklama(iMap.getString("ACIKLAMA"));
			sbaChargebackTx.setBankaAciklama(iMap.getString("BANKA_ACIKLAMA"));
			sbaChargebackTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			sbaChargebackTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			sbaChargebackTx.setHesapNoKart(iMap.getBigDecimal("HESAP_NO_KART"));
			sbaChargebackTx.setIslemAltTipi(iMap.getString("ISLEM_ALT_TIPI"));
			sbaChargebackTx.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			sbaChargebackTx.setKartNo(iMap.getString("KART_NO"));
			sbaChargebackTx.setKur(iMap.getBigDecimal("KUR"));
			sbaChargebackTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			sbaChargebackTx.setTutarTl(iMap.getBigDecimal("TUTAR"));
			sbaChargebackTx.setTutar(iMap.getBigDecimal("TUTAR_USD"));
			sbaChargebackTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			sbaChargebackTx.setKomisyon(iMap.getBigDecimal("KOMISYON"));
			String tip = iMap.getString("ISLEM_ALT_TIPI").substring(3);
			if (tip.equals("C")){
				sbaChargebackTx.setHesapNo(BigDecimal.valueOf(Long.valueOf(getGlobalParam("TFF_KOMBINE_SATIS_ALACAK"))));
			}
			session.saveOrUpdate(sbaChargebackTx);
			session.flush();
			
			iMap.put("TRX_NAME" , "4495");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4495_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaChargebackTx sbaChargebackTx = (SbaChargebackTx) session.createCriteria(SbaChargebackTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if(sbaChargebackTx !=null){
				oMap.put("ACIKLAMA", sbaChargebackTx.getAciklama());
				oMap.put("BANKA_ACIKLAMA", sbaChargebackTx.getBankaAciklama());
				oMap.put("BASVURU_NO", sbaChargebackTx.getBasvuruNo());
				oMap.put("HESAP_NO", sbaChargebackTx.getHesapNo());
				oMap.put("HESAP_NO_KART", sbaChargebackTx.getHesapNoKart());
				oMap.put("ISLEM_ALT_TIPI", sbaChargebackTx.getIslemAltTipi());
				oMap.put("ISLEM_TIPI", sbaChargebackTx.getIslemTipi());
				oMap.put("KART_NO", sbaChargebackTx.getKartNo());
				oMap.put("KUR", sbaChargebackTx.getKur());
				oMap.put("MUSTERI_NO", sbaChargebackTx.getMusteriNo());
				oMap.put("TUTAR", sbaChargebackTx.getTutarTl());
				oMap.put("TUTAR_USD", sbaChargebackTx.getTutar());
				oMap.put("KOMISYON", sbaChargebackTx.getKomisyon());
			}
					
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4495_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Session session = DAOSession.getSession("BNSPRDal");
		conn = DALUtil.getGMConnection();
		try {
			SbaChargebackTx sbaChargebackTx = (SbaChargebackTx) session.createCriteria(SbaChargebackTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			String islemAltTipi = sbaChargebackTx.getIslemAltTipi();
			String tip = islemAltTipi.substring(3);
			if (tip.equals("B")){
				ps = conn.prepareStatement("select b.basvuru_no BASVURU_NO, t.text ODEME_SEKLI_TXT, o.odeme_sekli ODEME_SEKLI, o.kart_bedeli - o.aktifbank_ek_pay KART_BEDELI, o.aktifbank_ek_pay EK_PAY, "
						+ "o.kurye_bedeli KURYE_BEDELI, o.loyalty_bedeli LOYALTY_BEDELI, to_char(o.rec_date,'yyyyMMdd') ODEME_TARIHI, o.tx_no ODEME_TX_NO from bnspr.tff_basvuru_odeme o "
						+ "join bnspr.tff_basvuru b on o.basvuru_no = b.basvuru_no "
						+ "left join BNSPR.GNL_PARAM_TEXT t on (o.odeme_sekli = t.key1 and t.kod = 'TFF_WEBSERVIS_PARAM' and t.key2 = 'ODEME_TIPI') where b.basvuru_no = ?");
				ps.setBigDecimal(1 , sbaChargebackTx.getBasvuruNo());
				rs = ps.executeQuery();
				GMMap bMap = new GMMap();
				while (rs.next()) {
					bMap.put("ODEME_TARIHI", rs.getString("ODEME_TARIHI"));
					bMap.put("EK_PAY", rs.getBigDecimal("EK_PAY"));
					bMap.put("KART_BEDELI", rs.getBigDecimal("KART_BEDELI"));
					bMap.put("KURYE_BEDELI", rs.getBigDecimal("KURYE_BEDELI"));
					bMap.put("LOYALTY_BEDELI", rs.getBigDecimal("LOYALTY_BEDELI"));
					bMap.put("ODEME_SEKLI", rs.getString("ODEME_SEKLI"));
					bMap.put("ODEME_SEKLI_TXT", rs.getString("ODEME_SEKLI_TXT"));
					bMap.put("ODEME_TX_NO", rs.getBigDecimal("ODEME_TX_NO"));
					bMap.put("TRX_NO", createTx());
					bMap.put("BASVURU_NO", sbaChargebackTx.getBasvuruNo());
					bMap.put("TRX_ONAYSIZ_ISLEM", "E");
				}
				
				GMServiceExecuter.call("BNSPR_TRN4493_SAVE", bMap);
			}
			if(tip.equals("K")){
				GMMap cMap = new GMMap();
				cMap.put("CARD_NO" , sbaChargebackTx.getKartNo());
				cMap = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cMap);
				String dest = cMap.getString("DESTINATION");
				String dci = cMap.getString("DCI");
				if (!StringUtil.isEmpty(dci) && (dci.equals("P") || dci.equals("C")) ){
				String islem = getParamText(islemAltTipi,"4495_GELEN_GIDEN_CHARGEBACK");
				
					GMMap cardMap = new GMMap();
					GMMap cardRespMap = new GMMap();
					
					cardMap.put(BSMV_RATE, BigDecimal.ZERO);
					cardMap.put(KKF_RATE, BigDecimal.ZERO);
					
					cardMap.put(TXN_AMOUNT, sbaChargebackTx.getTutarTl());
					cardMap.put(CARD_NO, sbaChargebackTx.getKartNo());
					cardMap.put(TXN_DESC, sbaChargebackTx.getAciklama());
					cardMap.put(TXN_CURR_CODE, "TRY");
					SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
					cardMap.put(TXN_DATE, format.format(new Date()));
					cardMap.put(TXN_STATE, "N");
					if(!sbaChargebackTx.getIslemTipi().equals("13")){
					if (islem.equals("GELEN")){
						cardMap.put(TXN_TYPE, getGlobalParam("4487_FINANSAL_BAKIM").replace("?", "~"));
					}else if (islem.equals("GIDEN")){
						cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
					}
					}
					else{
						cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_NO_FIN_ADJ_PP").replace("?", "~"));
					}
					
					if (dest.equals("I")){
						cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
					}else if (dest.equals("O")){
						cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
					}
					if(sbaChargebackTx.getIslemTipi().equals("13") && sbaChargebackTx.getKomisyon().compareTo(BigDecimal.ZERO)>0){
						cardMap.put(TXN_AMOUNT, sbaChargebackTx.getKomisyon());
						cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_NO_C_FIN_ADJ_PP").replace("?", "~"));
						if (dest.equals("I")){
							cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
						}else if (dest.equals("O")){
							cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
						}
					}
					
					if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
						throw new GMRuntimeException(4448011, "Kart Transfer Hata : "+ cardRespMap.getString(RETURN_DESCRIPTION));
					}
				}
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4495_GET_ISLEM_DETAY")
	public static GMMap getIslemDetay(GMMap iMap){
		GMMap oMap = new GMMap();
		String islem = iMap.getString("ISLEM_ALT_TIPI");
		String text = getParamText(islem,"4495_CHARGEBACK_KART_TIPLERI");
		String[] textd =text.split("&"); 
		String dest = textd[0];
		String dci  = textd[1];
		if (dci.equals("A")){
			dci="";
		}
		oMap.put("DEST",dest);
		oMap.put("DCI", dci);
		String tip = islem.substring(3);
		if(tip.equals("M")){
			oMap.put("PROCEED", "E");
		}else{
			oMap.put("PROCEED", "H");
		}
		
		return oMap;
	}
	public static BigDecimal createTx(){
    	GMMap oMapN = new GMMap();
		oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
		return oMapN.getBigDecimal("TRX_NO");
	}
	public static String getParamText(String key, String kod){
		GMMap pMap = new GMMap();
		pMap.put("KOD", kod);
		pMap.put("KEY", key);
		pMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", pMap);
		String text = pMap.getString("TEXT");
		return text;
		
	}
	public static String getGlobalParam(String batchParamCode) {
        GMMap iMapG = new GMMap();
        iMapG.put("KOD" , batchParamCode);
        iMapG.put("TRIM_QUOTES" , true);
        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
        return batchNo;
    }
}
