package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;

import net.dflora.pigeon.fix.AddressOut;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDiger;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDigerId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDigerTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDigerTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruMeslekiBilgi;
import tr.com.aktifbank.bnspr.dao.KkBasvuruMeslekiBilgiTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefonId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefonTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefonTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * Kredi karti basvuru genel islemlerini gerceklestirir.
 * 
 * @author murat.el
 * @since PY-7707
 * 
 */
public class CreditCardApplicationServices {
	
	private static final String GAP = " ";

	// ---------------------------------------------------------------------
	// ******************************************************* General Save Services
	// ---------------------------------------------------------------------
	/**
	 * Alinan bilgilerle tff basvuru bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Basvuru bilgileri<br>
	 *            <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle) 
	 *            <li>TRX_NO - Islem numarasi 
	 *            <li>BASVURU_NO - kk basvuru numarasi
	 *            <li>AKSIYON_KARAR_KOD <li>AKSIYON_KOD <li>ASIL_KART_MUSTERI_NO <li>ASIL_KART_NO 
	 *            <li>BASVURU_TARIHI <li>BAYI_KOD <li>DURUM_KOD <li>EK_KART_VAR_MI <li>EKSPRESS_KART_LIMITI 
	 *            <li>KREDI_KARTI_EKSTRE_SECIMI <li>KREDI_KARTI_EKSTRE_TIPI_EMAIL <li>KREDI_KARTI_EKSTRE_TIPI_SMS 
	 *            <li>KREDI_KARTI_EKSTRE_TIPI_POSTA <li>EMAIL <li>FINANSAL_TIP <li>GORUS <li>HESAP_KESIM_TARIHI
	 *            <li>KANAL_KOD <li>KART_UZERINDEKI_ISIM <li>KART_LIMITI <li>KART_NO <li>KREDI_KARTI_SEVIYESI 
	 *            <li>KART_TIPI <li>LOGO_KODU <li>MUSTERI_GROUP <li>MUSTERI_NO <li>MUSTERI_TIPI 
	 *            <li>NAKIT_KART_LIMITI <li>NBSM_KARAR_KOD <li>ONAY_EKSPRESS_KART_LIMITI <li>ONAY_KART_LIMITI 
	 *            <li>ONAY_NAKIT_KART_LIMITI <li>ON_ONAYLI_MI <li>KDH_ISTIYOR_MU <li>OTOMATIK_LIMIT_ARTIS
	 *            <li>KART_OTOMATIK_ODEME <li>SANAL_KART_MI <li>SESSION_IP <li>SUBE_KOD <li>KART_URUN_TIP 
	 *            <li>YURT_DISI_EKSTRE_TIP
	 *            
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_BASVURU")
	public static GMMap saveBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// Varsa isleme ait bilgileri al
			KkBasvuruTx kkBasvuruTx = (KkBasvuruTx) session.get(KkBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkBasvuruTx == null) {
				kkBasvuruTx = new KkBasvuruTx();
				kkBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				kkBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			}
			
			// Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
				}

				// TODO neden kullaniliyor: Basvuru Tarihi, Kart Tipi/Urun Tipi, Sanal kart var mi
				kkBasvuruTx.setAksiyonKararKod(CreditCardServicesUtil.nvl(iMap.getString("AKSIYON_KARAR_KOD"), kkBasvuru.getAksiyonKararKod()));
				kkBasvuruTx.setAksiyonKod(CreditCardServicesUtil.nvl(iMap.getString("AKSIYON_KOD"), kkBasvuru.getAksiyonKod()));
				kkBasvuruTx.setAsilKartMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"), kkBasvuru.getAsilKartMusteriNo()));
				kkBasvuruTx.setAsilKartNo(CreditCardServicesUtil.nvl(iMap.getString("ASIL_KART_NO"), kkBasvuru.getAsilKartNo()));
				kkBasvuruTx.setBasvuruTarihi(CreditCardServicesUtil.nvl(iMap.getDate("BASVURU_TARIHI"), kkBasvuru.getBasvuruTarihi()));
				kkBasvuruTx.setBayiKod(CreditCardServicesUtil.nvl(iMap.getString("BAYI_KOD"), kkBasvuru.getBayiKod()));
				kkBasvuruTx.setDurumKod(CreditCardServicesUtil.nvl(iMap.getString("DURUM_KOD"), kkBasvuru.getDurumKod()));
				kkBasvuruTx.setEkKartVarMi(CreditCardServicesUtil.nvl(iMap.getString("EK_KART_VAR_MI"), kkBasvuru.getEkKartVarMi()));
				kkBasvuruTx.setEkspressKartLimiti(CreditCardServicesUtil.nvl(iMap.getBigDecimal("EKSPRESS_KART_LIMITI"), kkBasvuru.getEkspressKartLimiti()));
				kkBasvuruTx.setEkstreSecimi(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"), kkBasvuru.getEkstreSecimi()));
				kkBasvuruTx.setEkstreTipiEmail(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"), kkBasvuru.getEkstreTipiEmail()));
				kkBasvuruTx.setEkstreTipiSms(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"), kkBasvuru.getEkstreTipiSms()));
				kkBasvuruTx.setEkstreTipiPosta(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"), kkBasvuru.getEkstreTipiPosta()));
				kkBasvuruTx.setEPosta(CreditCardServicesUtil.nvl(iMap.getString("EMAIL"), kkBasvuru.getEPosta()));
				kkBasvuruTx.setFinansalTip(CreditCardServicesUtil.nvl(iMap.getString("FINANSAL_TIP"), kkBasvuru.getFinansalTip()));
				kkBasvuruTx.setGorus(CreditCardServicesUtil.nvl(iMap.getString("GORUS"), kkBasvuru.getGorus()));
				kkBasvuruTx.setHesapKesimTarihi(CreditCardServicesUtil.nvl(iMap.getString("HESAP_KESIM_TARIHI"), kkBasvuru.getHesapKesimTarihi()));
				kkBasvuruTx.setKanalKod(CreditCardServicesUtil.nvl(iMap.getString("KANAL_KOD"), kkBasvuru.getKanalKod()));
				kkBasvuruTx.setKartinUzerineYazilacakIsim(CreditCardServicesUtil.nvl(iMap.getString("KART_UZERINDEKI_ISIM"), kkBasvuru.getKartinUzerineYazilacakIsim()));
				kkBasvuruTx.setKartLimiti(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KART_LIMITI"), kkBasvuru.getKartLimiti()));
				kkBasvuruTx.setKartNo(CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), kkBasvuru.getKartNo()));
				kkBasvuruTx.setKartSeviyesi(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_SEVIYESI"), kkBasvuru.getKartSeviyesi()));
				kkBasvuruTx.setKartTipi(CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), kkBasvuru.getKartTipi()));
				kkBasvuruTx.setLogoKod(CreditCardServicesUtil.nvl(iMap.getString("LOGO_KODU"), kkBasvuru.getLogoKod()));
				kkBasvuruTx.setMusteriGrup(CreditCardServicesUtil.nvl(iMap.getString("MUSTERI_GROUP"), kkBasvuru.getMusteriGrup()));
				kkBasvuruTx.setMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), kkBasvuru.getMusteriNo()));
				kkBasvuruTx.setMusteriTip(CreditCardServicesUtil.nvl(iMap.getString("MUSTERI_TIPI"), kkBasvuru.getMusteriTip()));
				kkBasvuruTx.setNakitKartLimiti(CreditCardServicesUtil.nvl(iMap.getBigDecimal("NAKIT_KART_LIMITI"), kkBasvuru.getNakitKartLimiti()));
				kkBasvuruTx.setNbsmKararKod(CreditCardServicesUtil.nvl(iMap.getString("NBSM_KARAR_KOD"), kkBasvuru.getNbsmKararKod()));
				kkBasvuruTx.setOnaylananEkspressKartLimiti(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ONAY_EKSPRESS_KART_LIMITI"), kkBasvuru.getOnaylananEkspressKartLimiti()));
				kkBasvuruTx.setOnaylananKartLimiti(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ONAY_KART_LIMITI"), kkBasvuru.getOnaylananKartLimiti()));
				kkBasvuruTx.setOnaylananNakitKartLimiti(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ONAY_NAKIT_KART_LIMITI"), kkBasvuru.getOnaylananNakitKartLimiti()));
				kkBasvuruTx.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), kkBasvuru.getOnOnayliMi()));
				kkBasvuruTx.setKdhIstiyorMu(CreditCardServicesUtil.nvl(iMap.getString("KDH_ISTIYOR_MU"), kkBasvuru.getKdhIstiyorMu()));
				kkBasvuruTx.setOtomatikLimitArtis(CreditCardServicesUtil.nvl(iMap.getString("OTOMATIK_LIMIT_ARTIS"), kkBasvuru.getOtomatikLimitArtis()));
				kkBasvuruTx.setOtomatikOdemeTalimati(CreditCardServicesUtil.nvl(iMap.getString("KART_OTOMATIK_ODEME"), kkBasvuru.getOtomatikOdemeTalimati()));
				kkBasvuruTx.setSanalKartVarMi(CreditCardServicesUtil.nvl(iMap.getString("SANAL_KART_MI"), kkBasvuru.getSanalKartVarMi()));
				kkBasvuruTx.setSessionIp(CreditCardServicesUtil.nvl(iMap.getString("SESSION_IP"), kkBasvuru.getSessionIp()));
				kkBasvuruTx.setSubeKod(CreditCardServicesUtil.nvl(iMap.getString("SUBE_KOD"), kkBasvuru.getSubeKod()));
				kkBasvuruTx.setUrunTipi(CreditCardServicesUtil.nvl(iMap.getString("KART_URUN_TIP"), kkBasvuru.getUrunTipi()));
				kkBasvuruTx.setYurtdisiHarcamaEkstresi(CreditCardServicesUtil.nvl(iMap.getString("YURT_DISI_EKSTRE_TIP"), kkBasvuru.getYurtdisiHarcamaEkstresi()));
				kkBasvuruTx.setKuryeTipi(CreditCardServicesUtil.nvl(iMap.getString("KURYE_TIPI"), kkBasvuru.getKuryeTipi()));
				kkBasvuruTx.setSource(CreditCardServicesUtil.nvl(iMap.getString("SOURCE"), kkBasvuru.getSource()));
				kkBasvuruTx.setPaket(CreditCardServicesUtil.nvl(iMap.getString("PAKET"), kkBasvuru.getPaket()));
				
			}
			else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				// Kanal Kodu Belirle
				if (StringUtils.isBlank(iMap.getString("KANAL_KOD"))) {
					iMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMap));
				}

				kkBasvuruTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
				kkBasvuruTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
				kkBasvuruTx.setAsilKartMusteriNo(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
				kkBasvuruTx.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
				kkBasvuruTx.setBasvuruTarihi(iMap.getDate("BASVURU_TARIHI"));
				kkBasvuruTx.setBayiKod(iMap.getString("BAYI_KOD"));
				kkBasvuruTx.setDurumKod(iMap.getString("DURUM_KOD"));
				kkBasvuruTx.setEkKartVarMi(iMap.getString("EK_KART_VAR_MI"));
				kkBasvuruTx.setEkspressKartLimiti(iMap.getBigDecimal("EKSPRESS_KART_LIMITI"));
				kkBasvuruTx.setEkstreSecimi(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
				kkBasvuruTx.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
				kkBasvuruTx.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
				kkBasvuruTx.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
				kkBasvuruTx.setEPosta(iMap.getString("EMAIL"));
				kkBasvuruTx.setFinansalTip(iMap.getString("FINANSAL_TIP"));
				kkBasvuruTx.setGorus(iMap.getString("GORUS"));
				kkBasvuruTx.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));
				kkBasvuruTx.setKanalKod(iMap.getString("KANAL_KOD"));
				kkBasvuruTx.setKartinUzerineYazilacakIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
				kkBasvuruTx.setKartLimiti(iMap.getBigDecimal("KART_LIMITI"));
				kkBasvuruTx.setKartNo(iMap.getString("KART_NO"));
				kkBasvuruTx.setKartSeviyesi(iMap.getString("KREDI_KARTI_SEVIYESI"));
				kkBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
				kkBasvuruTx.setLogoKod(iMap.getString("LOGO_KODU"));
				kkBasvuruTx.setMusteriGrup(iMap.getString("MUSTERI_GROUP"));
				kkBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				kkBasvuruTx.setMusteriTip(iMap.getString("MUSTERI_TIPI"));
				kkBasvuruTx.setNakitKartLimiti(iMap.getBigDecimal("NAKIT_KART_LIMITI"));
				kkBasvuruTx.setNbsmKararKod(iMap.getString("NBSM_KARAR_KOD"));
				kkBasvuruTx.setOnaylananEkspressKartLimiti(iMap.getBigDecimal("ONAY_EKSPRESS_KART_LIMITI"));
				kkBasvuruTx.setOnaylananKartLimiti(iMap.getBigDecimal("ONAY_KART_LIMITI"));
				kkBasvuruTx.setOnaylananNakitKartLimiti(iMap.getBigDecimal("ONAY_NAKIT_KART_LIMITI"));
				kkBasvuruTx.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), CreditCardServicesUtil.HAYIR));
				kkBasvuruTx.setKdhIstiyorMu(iMap.getString("KDH_ISTIYOR_MU"));
				kkBasvuruTx.setOtomatikLimitArtis(iMap.getString("OTOMATIK_LIMIT_ARTIS"));
				kkBasvuruTx.setOtomatikOdemeTalimati(iMap.getString("KART_OTOMATIK_ODEME"));
				kkBasvuruTx.setSanalKartVarMi(iMap.getString("SANAL_KART_MI"));
				kkBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
				kkBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
				kkBasvuruTx.setUrunTipi(iMap.getString("KART_URUN_TIP"));
				kkBasvuruTx.setYurtdisiHarcamaEkstresi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
				kkBasvuruTx.setKuryeTipi(CreditCardServicesUtil.nvl(iMap.getString("KURYE_TIPI"), kkBasvuruTx.getKuryeTipi()));
				kkBasvuruTx.setSource(CreditCardServicesUtil.nvl(iMap.getString("SOURCE"), kkBasvuruTx.getSource()));
				kkBasvuruTx.setPaket(CreditCardServicesUtil.nvl(iMap.getString("PAKET"), kkBasvuruTx.getPaket()));
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(kkBasvuruTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Alinan bilgilerle kk basvuru kimlik bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Basvuru bilgileri<br>
	 *            <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle) 
	 *            <li>TRX_NO - Islem numarasi 
	 *            <li>BASVURU_NO - kk basvuru numarasi 
	 *            <li>ADI <li>NUFUS_AILE_SIRA_NO <li>ANNE_ADI <li>ANNE_KIZLIK_SOYADI <li>APS_TEYIT 
	 *            <li>APS_YAPILDIMI <li>BABA_ADI <li>NUFUS_SIRA_NO <li>NUFUS_CILT_NO <li>CINSIYET 
	 *            <li>DOGUM_TARIHI <li>DOGUM_YERI <li>ES_TCKN <li>IKINCI_ADI <li>KAYIP_CUZDAN_SERI 
	 *            <li>KAYIP_CUZDAN_NO <li>KIMLIK_SERI_NO <li>KIMLIK_SERI_NO_KPS <li>KIMLIK_SIRA_NO 
	 *            <li>KIMLIK_SIRA_NO_KPS <li>KPS_YAPILDI <li>NUFUS_MAHALLE <li>MEDENI_HAL <li>NUFUS_ILCE_KOD 
	 *            <li>NUFUS_IL_KOD <li>NUF_VERILIS_NEDENI <li>NUFUS_VERILIS_TARIHI 
	 *            <li>NUF_VERILDIGI_YER <li>ONCEKI_SOYAD <li>SOYADI <li>TC_KIMLIK_NO <li>UYRUK_KOD
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_KIMLIK")
	public static GMMap saveKimlik(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// Varsa isleme ait bilgileri al
			KkBasvuruKimlikTx kkBasvuruKimlikTx = (KkBasvuruKimlikTx) session.get(KkBasvuruKimlikTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkBasvuruKimlikTx == null) {
				kkBasvuruKimlikTx = new KkBasvuruKimlikTx();
				kkBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				kkBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			}

			// Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuruKimlik == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
				}

				kkBasvuruKimlikTx.setAd(CreditCardServicesUtil.nvl(iMap.getString("ADI"), kkBasvuruKimlik.getAd()));
				kkBasvuruKimlikTx.setAileSiraNo(CreditCardServicesUtil.nvl(iMap.getString("NUFUS_AILE_SIRA_NO"), kkBasvuruKimlik.getAileSiraNo()));
				kkBasvuruKimlikTx.setAnneAdi(CreditCardServicesUtil.nvl(iMap.getString("ANNE_ADI"), kkBasvuruKimlik.getAnneAdi()));
				kkBasvuruKimlikTx.setAnneKizlik(CreditCardServicesUtil.nvl(iMap.getString("ANNE_KIZLIK_SOYADI"), kkBasvuruKimlik.getAnneKizlik()));
				kkBasvuruKimlikTx.setApsBilgileriUyumlumu(CreditCardServicesUtil.nvl(iMap.getString("APS_TEYIT"), kkBasvuruKimlik.getApsBilgileriUyumlumu()));
				kkBasvuruKimlikTx.setApsYapildi(CreditCardServicesUtil.nvl(iMap.getString("APS_YAPILDIMI"), kkBasvuruKimlik.getApsYapildi()));
				kkBasvuruKimlikTx.setBabaAd(CreditCardServicesUtil.nvl(iMap.getString("BABA_ADI"), kkBasvuruKimlik.getBabaAd()));
				kkBasvuruKimlikTx.setBireySiraNo(CreditCardServicesUtil.nvl(iMap.getString("NUFUS_SIRA_NO"), kkBasvuruKimlik.getBireySiraNo()));
				kkBasvuruKimlikTx.setCiltNo(CreditCardServicesUtil.nvl(iMap.getString("NUFUS_CILT_NO"), kkBasvuruKimlik.getCiltNo()));
				kkBasvuruKimlikTx.setCinsiyet(CreditCardServicesUtil.nvl(iMap.getString("CINSIYET"), kkBasvuruKimlik.getCinsiyet()));
				kkBasvuruKimlikTx.setDogumTar(CreditCardServicesUtil.nvl(iMap.getDate("DOGUM_TARIHI"), kkBasvuruKimlik.getDogumTar()));
				kkBasvuruKimlikTx.setDogumYeri(CreditCardServicesUtil.nvl(iMap.getString("DOGUM_YERI"), kkBasvuruKimlik.getDogumYeri()));
				kkBasvuruKimlikTx.setEsTcKimlikNo(CreditCardServicesUtil.nvl(iMap.getString("ES_TCKN"), kkBasvuruKimlik.getEsTcKimlikNo()));
				kkBasvuruKimlikTx.setIkinciAd(CreditCardServicesUtil.nvl(iMap.getString("IKINCI_ADI"), kkBasvuruKimlik.getIkinciAd()));
				kkBasvuruKimlikTx.setKayipKimlikSeriNo(CreditCardServicesUtil.nvl(iMap.getString("KAYIP_CUZDAN_SERI"), kkBasvuruKimlik.getKayipKimlikSeriNo()));
				kkBasvuruKimlikTx.setKayipKimlikSiraNo(CreditCardServicesUtil.nvl(iMap.getString("KAYIP_CUZDAN_NO"), kkBasvuruKimlik.getKayipKimlikSiraNo()));
				kkBasvuruKimlikTx.setKimlikSeriNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO"), kkBasvuruKimlik.getKimlikSeriNo()));
				kkBasvuruKimlikTx.setKimlikSeriNoKps(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO_KPS"), kkBasvuruKimlik.getKimlikSeriNoKps()));
				kkBasvuruKimlikTx.setKimlikSiraNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO"), kkBasvuruKimlik.getKimlikSiraNo()));
				kkBasvuruKimlikTx.setKimlikSiraNoKps(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO_KPS"), kkBasvuruKimlik.getKimlikSiraNoKps()));
				kkBasvuruKimlikTx.setKpsYapildi(CreditCardServicesUtil.nvl(iMap.getString("KPS_YAPILDI"), kkBasvuruKimlik.getKpsYapildi()));
				kkBasvuruKimlikTx.setMahalleKoy(CreditCardServicesUtil.nvl(iMap.getString("NUFUS_MAHALLE"), kkBasvuruKimlik.getMahalleKoy()));
				kkBasvuruKimlikTx.setMedeniHal(CreditCardServicesUtil.nvl(iMap.getString("MEDENI_HAL"), kkBasvuruKimlik.getMedeniHal()));
				kkBasvuruKimlikTx.setNufusIlceKod(CreditCardServicesUtil.nvl(iMap.getString("NUFUS_ILCE_KOD"), kkBasvuruKimlik.getNufusIlceKod()));
				kkBasvuruKimlikTx.setNufusIlKod(CreditCardServicesUtil.nvl(iMap.getString("NUFUS_IL_KOD"), kkBasvuruKimlik.getNufusIlKod()));
				kkBasvuruKimlikTx.setNufusVerNedeni(CreditCardServicesUtil.nvl(iMap.getString("NUF_VERILIS_NEDENI"), kkBasvuruKimlik.getNufusVerNedeni()));
				if (StringUtils.isNotBlank(iMap.getString("NUFUS_VERILIS_TARIHI"))){
				kkBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));}
				else{
					kkBasvuruKimlikTx.setNufusVerTar(kkBasvuruKimlik.getNufusVerTar());}
				kkBasvuruKimlikTx.setNufusVerYer(CreditCardServicesUtil.nvl(iMap.getString("NUF_VERILDIGI_YER"), kkBasvuruKimlik.getNufusVerYer()));
				kkBasvuruKimlikTx.setOncekiSoyad(CreditCardServicesUtil.nvl(iMap.getString("ONCEKI_SOYAD"), kkBasvuruKimlik.getOncekiSoyad()));
				kkBasvuruKimlikTx.setSoyad(CreditCardServicesUtil.nvl(iMap.getString("SOYADI"), kkBasvuruKimlik.getSoyad()));
				kkBasvuruKimlikTx.setTcKimlikNo(CreditCardServicesUtil.nvl(iMap.getString("TC_KIMLIK_NO"), kkBasvuruKimlik.getTcKimlikNo()));
				kkBasvuruKimlikTx.setUyrukKod(CreditCardServicesUtil.nvl(iMap.getString("UYRUK_KOD"), kkBasvuruKimlik.getUyrukKod()));
				kkBasvuruKimlikTx.setPasaportNo(CreditCardServicesUtil.nvl(iMap.getString("PASAPORT_NO"), kkBasvuruKimlik.getPasaportNo()));
			}
			else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				kkBasvuruKimlikTx.setAd(iMap.getString("ADI"));
				kkBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
				kkBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
				kkBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
				kkBasvuruKimlikTx.setApsBilgileriUyumlumu(iMap.getString("APS_TEYIT"));
				kkBasvuruKimlikTx.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
				kkBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
				kkBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
				kkBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
				kkBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
				kkBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
				kkBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
				kkBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
				kkBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
				kkBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
				kkBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
				kkBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
				kkBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
				kkBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
				kkBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
				kkBasvuruKimlikTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
				kkBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
				kkBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
				kkBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
				kkBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
				kkBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
				if(StringUtils.isNotBlank(iMap.getString("NUFUS_VERILIS_TARIHI"))){
					kkBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
				} 
				kkBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
				kkBasvuruKimlikTx.setOncekiSoyad(iMap.getString("ONCEKI_SOYAD"));
				kkBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
				kkBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				kkBasvuruKimlikTx.setUyrukKod(CreditCardServicesUtil.nvl(iMap.getString("UYRUK_KOD"), "TR"));
				kkBasvuruKimlikTx.setPasaportNo(iMap.getString("PASAPORT_NO"));
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(kkBasvuruKimlikTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Alinan bilgilerle kk basvuru adres bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Basvuru bilgileri<br>
	 *            <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle) 
	 *            <li>TRX_NO - Islem numarasi 
	 *            <li>BASVURU_NO - kk basvuru numarasi 
	 *            <li>ADRES_TIPI <li>IL_KOD <li>ILCE_KOD <li>ACIK_ADRES <li>TESLIMAT_ADRESI_MI 
	 *            <li>ILETISIM_MI <li>EKSTRE_ADRESI_MI <li>ISYERI_ADI <li>POSTA_KOD
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_ADRES")
	public static GMMap saveAdres(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// Varsa isleme ait bilgileri al
			KkBasvuruAdresTxId id = new KkBasvuruAdresTxId();
			id.setAdresKod(iMap.getString("ADRES_TIPI"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			KkBasvuruAdresTx kkBasvuruAdresTx = (KkBasvuruAdresTx) session.get(KkBasvuruAdresTx.class, id);
			if (kkBasvuruAdresTx == null) {
				kkBasvuruAdresTx = new KkBasvuruAdresTx();
				kkBasvuruAdresTx.setId(id);
				kkBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			}

			// Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				KkBasvuruAdresId adresId = new KkBasvuruAdresId();
				adresId.setAdresKod(iMap.getString("ADRES_TIPI"));
				adresId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				KkBasvuruAdres kkBasvuruAdres = (KkBasvuruAdres) session.get(KkBasvuruAdres.class, adresId);
				if (kkBasvuruAdres == null) {
					kkBasvuruAdres = new KkBasvuruAdres();
					// CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
				}

				kkBasvuruAdresTx.setAdres(CreditCardServicesUtil.trimNewLine(CreditCardServicesUtil.nvl(iMap.getString("ACIK_ADRES"), kkBasvuruAdres.getAdres())));
				kkBasvuruAdresTx.setEkstreAdresi(CreditCardServicesUtil.nvl(iMap.getString("EKSTRE_ADRESI_MI"), kkBasvuruAdres.getEkstreAdresi()));
				kkBasvuruAdresTx.setIlceKod(CreditCardServicesUtil.nvl(iMap.getString("ILCE_KOD"), kkBasvuruAdres.getIlceKod()));
				kkBasvuruAdresTx.setIletisimAdresi(CreditCardServicesUtil.nvl(iMap.getString("ILETISIM_MI"), kkBasvuruAdres.getIletisimAdresi()));
				kkBasvuruAdresTx.setIlKod(CreditCardServicesUtil.nvl(iMap.getString("IL_KOD"), kkBasvuruAdres.getIlKod()));
				kkBasvuruAdresTx.setIsyeriAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_ADI"), kkBasvuruAdres.getIsyeriAdi()));
				kkBasvuruAdresTx.setPostaKod(CreditCardServicesUtil.nvl(iMap.getString("POSTA_KOD"), kkBasvuruAdres.getPostaKod()));
				kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.nvl(iMap.getString("TESLIMAT_ADRESI_MI"), kkBasvuruAdres.getTeslimatAdresiMi()));
				
			}
			else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				kkBasvuruAdresTx.setAdres(CreditCardServicesUtil.trimNewLine(iMap.getString("ACIK_ADRES")));
				kkBasvuruAdresTx.setEkstreAdresi(iMap.getString("EKSTRE_ADRESI_MI"));
				kkBasvuruAdresTx.setIlceKod(iMap.getString("ILCE_KOD"));
				kkBasvuruAdresTx.setIletisimAdresi(iMap.getString("ILETISIM_MI"));
				kkBasvuruAdresTx.setIlKod(iMap.getString("IL_KOD"));
				kkBasvuruAdresTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
				kkBasvuruAdresTx.setPostaKod(iMap.getString("POSTA_KOD"));
				kkBasvuruAdresTx.setTeslimatAdresiMi(iMap.getString("TESLIMAT_ADRESI_MI"));
				
				
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			
			if("E".equals(kkBasvuruAdresTx.getTeslimatAdresiMi())){
				// tff basvurusu mu ?
				
				if(kkBasvuruAdresTx.getBasvuruNo() != null){
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", kkBasvuruAdresTx.getBasvuruNo())).uniqueResult();
					if(tffBasvuru != null){
						kkBasvuruAdresTx.setVeriKontrolEdilecekMi("E"); // set default
						if(!StringUtils.isEmpty(kkBasvuruAdresTx.getAdres())){
							
							
						    Criteria criteria = session.createCriteria(GnlParamText.class)
						    										.add(Restrictions.eq("kod", "VERI_KONTROL_ADRES_UYGUNLUK_ORANI"))
						    										.add(Restrictions.eq("key1", "A"));
						    										
							GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
							if(gnlParamText != null && gnlParamText.getSayi() != null && gnlParamText.getSayi().intValue() >= 0){
								BigDecimal compRate =  gnlParamText.getSayi(); 
								GMMap pigeonMap = new GMMap();
								
							    criteria = session.createCriteria(GnlilKodPr.class)
							    										.add(Restrictions.eq("kod", kkBasvuruAdresTx.getIlKod()));
							    							
							    										
							    GnlilKodPr gnlilKodPr = (GnlilKodPr) criteria.uniqueResult();
								
							   
							    criteria = session.createCriteria(GnlilceKodPr.class)
							    										.add(Restrictions.eq("id.gnlilKodPr.kod", kkBasvuruAdresTx.getIlKod()))
							    										.add(Restrictions.eq("id.ilceKod", kkBasvuruAdresTx.getIlceKod())
							    										  );
				
							    										
							    GnlilceKodPr gnlilceKodPr = (GnlilceKodPr) criteria.uniqueResult();
							    
							    String acikAdres = kkBasvuruAdresTx.getAdres();
							    if(gnlilceKodPr != null){
							    	acikAdres = acikAdres + " " + gnlilceKodPr.getIlceAdi();
							    }
								
							    if(gnlilKodPr != null){
							    	acikAdres = acikAdres + " " + gnlilKodPr.getIlAdi();
							    }
							    
								
								pigeonMap.put("ADDRESS", acikAdres);
								pigeonMap.put("FORMAT_RESPONSE",false);
								AddressOut checkedAdress = (AddressOut) GMServiceExecuter.call("BNSPR_COMMON_DETECT_BEST_ADDRESS", pigeonMap).get("RESULT_ADDRESS");
								
								
								if(checkedAdress != null){
									BigDecimal checkedAdressDecimal = new BigDecimal(checkedAdress.getCompletenessRate().getValue());
									kkBasvuruAdresTx.setPigeonCompletenessRate(checkedAdressDecimal);
									kkBasvuruAdresTx.setVeriKontrolEdilecekMi(checkedAdressDecimal.compareTo(compRate) == -1 ? "E" : "H");
								}
								
							}
							
						}
						
					}
				}
				
				
			}
			
			
			
			
			session.saveOrUpdate(kkBasvuruAdresTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Alinan bilgilerle kk basvuru adres bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Basvuru bilgileri<br>
	 *            <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle) 
	 *            <li>TRX_NO - Islem numarasi <li>BASVURU_NO - Tff basvuru numarasi 
	 *            <li>TELEFON_TIPI <li>ALAN_KOD <li>ILETISIM_MI <li>NUMARA <li>ULKE_KOD
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_TELEFON")
	public static GMMap saveTelefon(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Telefon tipini al
			String tip = iMap.getString("TELEFON_TIPI");
			if ("E".equals(tip) || "1".equals(tip)) {
				tip = "1";
			}
			else if ("I".equals(tip) || "2".equals(tip)) {
				tip = "2";
			}
			else if ("C".equals(tip) || "3".equals(tip)) {
				tip = "3";
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// Varsa isleme ait bilgileri al
			KkBasvuruTelefonTxId id = new KkBasvuruTelefonTxId();
			id.setTip(tip);
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			KkBasvuruTelefonTx kkBasvuruTelefonTx = (KkBasvuruTelefonTx) session.get(KkBasvuruTelefonTx.class, id);
			if (kkBasvuruTelefonTx == null) {
				kkBasvuruTelefonTx = new KkBasvuruTelefonTx();
				kkBasvuruTelefonTx.setId(id);
				kkBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			}

			// Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				KkBasvuruTelefonId telefonId = new KkBasvuruTelefonId();
				telefonId.setTip(tip);
				telefonId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				KkBasvuruTelefon kkBasvuruTelefon = (KkBasvuruTelefon) session.get(KkBasvuruTelefon.class, telefonId);
				if (kkBasvuruTelefon == null) {
					kkBasvuruTelefon = new KkBasvuruTelefon();
					// CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}

				kkBasvuruTelefonTx.setAlanKod(CreditCardServicesUtil.nvl(iMap.getString("ALAN_KOD"), kkBasvuruTelefon.getAlanKod()));
				kkBasvuruTelefonTx.setIletisim(CreditCardServicesUtil.nvl(iMap.getString("ILETISIM_MI"), kkBasvuruTelefon.getIletisim()));
				kkBasvuruTelefonTx.setNumara(CreditCardServicesUtil.nvl(iMap.getString("NUMARA"), kkBasvuruTelefon.getNumara()));
				kkBasvuruTelefonTx.setUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("ULKE_KOD"), kkBasvuruTelefon.getUlkeKod()));
				kkBasvuruTelefonTx.setUlkeKod(CreditCardServicesUtil.nvl(kkBasvuruTelefonTx.getUlkeKod(), "90"));
			}
			else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				kkBasvuruTelefonTx.setAlanKod(iMap.getString("ALAN_KOD"));
				kkBasvuruTelefonTx.setIletisim(iMap.getString("ILETISIM_MI", "H"));
				kkBasvuruTelefonTx.setNumara(iMap.getString("NUMARA"));
				kkBasvuruTelefonTx.setUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("ULKE_KOD"), "90"));
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(kkBasvuruTelefonTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Alinan bilgilerle kk basvuru meslek bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Basvuru bilgileri<br>
	 *            <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle) 
	 *            <li>TRX_NO - Islem numarasi 
	 *            <li>BASVURU_NO - Tff basvuru numarasi 
	 *            <li>AYLIK_GELIR <li>CALISMA_SEKLI <li>ISYERI_ADI <li>ISYERI_FAALIYET_ALANI <li>ISYERI_VERGI_DAIRESI_ADI 
	 *            <li>ISYERI_VERGI_DAIRESI_IL <li>MESLEK <li>MESLEK_ACIKLAMA <li>UNVANI <li>OGRENIM_DURUMU 
	 *            <li>ISYERINDE_CALISMA_SURESI_YIL <li>ISYERINDE_CALISMA_SURESI_AY <li>MEVCUT_ADRESTE_OTURMA_SURESI_YIL 
	 *            <li>MEVCUT_ADRESTE_OTURMA_SURESI_AY <li>DIGER_GELIR <li>ES_GELIRI<li>IKAMET_DURUMU <li>GMENKUL_GELIR
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_MESLEK")
	public static GMMap saveMeslek(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Default deger al
			String calismaSuresi = null;
			if (StringUtils.isNotBlank(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL")) || StringUtils.isNotBlank(iMap.getString("ISYERINDE_CALISMA_SURESI_AY"))) {
				calismaSuresi = CreditCardTRN3871Services.concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY"));
			}

			String oturmaSuresi = null;
			if (StringUtils.isNotBlank(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL")) || StringUtils.isNotBlank(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY"))) {
				oturmaSuresi = CreditCardTRN3871Services.concatYilAy(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY"));
			}

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// Varsa isleme ait bilgileri al
			KkBasvuruMeslekiBilgiTx kkBasvuruMeslekiBilgiTx = (KkBasvuruMeslekiBilgiTx) session.get(KkBasvuruMeslekiBilgiTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkBasvuruMeslekiBilgiTx == null) {
				kkBasvuruMeslekiBilgiTx = new KkBasvuruMeslekiBilgiTx();
				kkBasvuruMeslekiBilgiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				kkBasvuruMeslekiBilgiTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			}

			// Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				KkBasvuruMeslekiBilgi kkBasvuruMeslekiBilgi = (KkBasvuruMeslekiBilgi) session.get(KkBasvuruMeslekiBilgi.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuruMeslekiBilgi == null) {
					kkBasvuruMeslekiBilgi = new KkBasvuruMeslekiBilgi();
					// CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}

				// TODO meslek aciklama neden tutuluyor.
				kkBasvuruMeslekiBilgiTx.setAylikGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AYLIK_GELIR"), kkBasvuruMeslekiBilgi.getAylikGelir()));
				kkBasvuruMeslekiBilgiTx.setCalismaSekliKod(CreditCardServicesUtil.nvl(iMap.getString("CALISMA_SEKLI"), kkBasvuruMeslekiBilgi.getCalismaSekliKod()));
				kkBasvuruMeslekiBilgiTx.setCalismaSuresi(CreditCardServicesUtil.nvl(calismaSuresi, kkBasvuruMeslekiBilgi.getCalismaSuresi()));
				kkBasvuruMeslekiBilgiTx.setDigerGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("DIGER_GELIR"), kkBasvuruMeslekiBilgi.getDigerGelir()));
				kkBasvuruMeslekiBilgiTx.setEsGeliri(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ES_GELIRI"), kkBasvuruMeslekiBilgi.getEsGeliri()));
				kkBasvuruMeslekiBilgiTx.setEvdeOturmaSuresi(CreditCardServicesUtil.nvl(oturmaSuresi, kkBasvuruMeslekiBilgi.getEvdeOturmaSuresi()));
				kkBasvuruMeslekiBilgiTx.setFaaliyetAlaniKod(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_FAALIYET_ALANI"), kkBasvuruMeslekiBilgi.getFaaliyetAlaniKod()));
				kkBasvuruMeslekiBilgiTx.setIkametDurumKod(CreditCardServicesUtil.nvl(iMap.getString("IKAMET_DURUMU"), kkBasvuruMeslekiBilgi.getIkametDurumKod()));
				kkBasvuruMeslekiBilgiTx.setIsyeriAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_ADI"), kkBasvuruMeslekiBilgi.getIsyeriAdi()));
				kkBasvuruMeslekiBilgiTx.setMenkulGmenkulGeliri(CreditCardServicesUtil.nvl(iMap.getBigDecimal("GMENKUL_GELIR"), kkBasvuruMeslekiBilgi.getMenkulGmenkulGeliri()));
				kkBasvuruMeslekiBilgiTx.setMeslekAciklama(CreditCardServicesUtil.nvl(iMap.getString("MESLEK_ACIKLAMA"), kkBasvuruMeslekiBilgi.getMeslekAciklama()));
				kkBasvuruMeslekiBilgiTx.setMeslekKod(CreditCardServicesUtil.nvl(iMap.getString("MESLEK"), kkBasvuruMeslekiBilgi.getMeslekKod()));
				kkBasvuruMeslekiBilgiTx.setOgrenimDurumKod(CreditCardServicesUtil.nvl(iMap.getString("OGRENIM_DURUMU"), kkBasvuruMeslekiBilgi.getOgrenimDurumKod()));
				kkBasvuruMeslekiBilgiTx.setUnvanKod(CreditCardServicesUtil.nvl(iMap.getString("UNVANI"), kkBasvuruMeslekiBilgi.getUnvanKod()));
				kkBasvuruMeslekiBilgiTx.setVergiDaireAd(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"), kkBasvuruMeslekiBilgi.getVergiDaireAd()));
				kkBasvuruMeslekiBilgiTx.setVergiDaireIl(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"), kkBasvuruMeslekiBilgi.getVergiDaireIl()));
			}
			else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				kkBasvuruMeslekiBilgiTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				kkBasvuruMeslekiBilgiTx.setCalismaSekliKod(iMap.getString("CALISMA_SEKLI"));
				kkBasvuruMeslekiBilgiTx.setCalismaSuresi(calismaSuresi);
				kkBasvuruMeslekiBilgiTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
				kkBasvuruMeslekiBilgiTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI"));
				kkBasvuruMeslekiBilgiTx.setEvdeOturmaSuresi(oturmaSuresi);
				kkBasvuruMeslekiBilgiTx.setFaaliyetAlaniKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
				kkBasvuruMeslekiBilgiTx.setIkametDurumKod(iMap.getString("IKAMET_DURUMU"));
				kkBasvuruMeslekiBilgiTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
				kkBasvuruMeslekiBilgiTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
				kkBasvuruMeslekiBilgiTx.setMeslekAciklama(iMap.getString("MESLEK_ACIKLAMA"));
				kkBasvuruMeslekiBilgiTx.setMeslekKod(iMap.getString("MESLEK"));
				kkBasvuruMeslekiBilgiTx.setOgrenimDurumKod(iMap.getString("OGRENIM_DURUMU"));
				kkBasvuruMeslekiBilgiTx.setUnvanKod(iMap.getString("UNVANI"));
				kkBasvuruMeslekiBilgiTx.setVergiDaireAd(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				kkBasvuruMeslekiBilgiTx.setVergiDaireIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(kkBasvuruMeslekiBilgiTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * Alinan bilgilerle kk basvuru es kimlik bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since BT-6687
	 * @param iMap - Es Kimlik bilgileri<br>
	 *            <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle) 
	 *            <li>TRX_NO - Islem numarasi 
	 *            <li>BASVURU_NO - Kk basvuru numarasi
	 *            <li>TCKNO - Tc kimlik numarasi 
	 *            <li>AD<li>ADRES_NO<li>AILE_SIRA_NO<li>ANNE_AD<li>LOG_ID<li>BABA_AD<li>BIREY_SIRA_NO
	 *            <li>BUCAK<li>BUCAK_KOD<li>CILT_KODU<li>CINSIYET_KOD<li>CINSIYET<li>CSBM<li>CSBM_KODU
	 *            <li>DIN<li>DIS_KAPI_NO<li>DOGUM_TARIHI<li>DOGUM_YERI<li>DOGUM_YERI_KOD<li>DURUMU_ACIKLAMA
	 *            <li>DURUMU<li>ES_TCKN<li>EV_ADRES<li>IL_KODU<li>ILCE_KODU<li>IC_KAPI_NO<li>APS_IL<li>APS_ILCE
	 *            <li>IL<li>ILCE<li>KIMLIK_KAYIT_NO<li>KIMLIK_SERI_NO<li>KIMLIK_SIRA_NO<li>KOY<li>KOY_KAYIT_NO
	 *            <li>KOY_KOD<li>MAHALLE<li>MAHALLE_KOD<li>CILT<li>MEDENI_HALI_KOD<li>MEDENI_HALI<li>MUSTERI_NO
	 *            <li>ILCE_KODU<li>IL_KODU<li>VERILIS_NEDENI<li>VERILIS_TARIHI<li>VERILDIGI_ILCE_ADI
	 *            <li>OLUM_TARIHI<li>SOYAD<li>VERILDIGI_ILCE_KODU<li>VERILIS_NEDENI_KOD<li>YABANCI_ADRES
	 *            <li>YABANCI_SEHIR<li>YABANCI_ULKE<li>YABANCI_ULKE_KOD
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_KIMLIK_DIGER")
	public static GMMap saveKimlikDiger(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			// Varsa isleme ait bilgileri al
			KkBasvuruKimlikDigerTxId txId = new KkBasvuruKimlikDigerTxId();
			txId.setTxNo(iMap.getBigDecimal("TRX_NO"));//Zorunlu
			txId.setTcKimlikNo(iMap.getString("TCKNO"));//Zorunlu

			KkBasvuruKimlikDigerTx kkBasvuruKimlikDigerTx = (KkBasvuruKimlikDigerTx) session.get(KkBasvuruKimlikDigerTx.class, txId);
			if (kkBasvuruKimlikDigerTx == null) {
				kkBasvuruKimlikDigerTx = new KkBasvuruKimlikDigerTx();
				kkBasvuruKimlikDigerTx.setId(txId);
			}

			// Islem guncelleme islemi ise 
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				//basvuru tablosundaki bilgileri al
				KkBasvuruKimlikDigerId id = new KkBasvuruKimlikDigerId();
				id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));//Zorunlu
				id.setTcKimlikNo(iMap.getString("TCKNO"));
				
				KkBasvuruKimlikDiger kkBasvuruKimlikDiger = (KkBasvuruKimlikDiger) session.get(KkBasvuruKimlikDiger.class, id);
				if (kkBasvuruKimlikDiger == null) {
					kkBasvuruKimlikDiger = new KkBasvuruKimlikDiger();
					// CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
				}
				
				kkBasvuruKimlikDigerTx.setAd(CreditCardServicesUtil.nvl(iMap.getString("AD"), kkBasvuruKimlikDiger.getAd()));
				kkBasvuruKimlikDigerTx.setAdresNo(CreditCardServicesUtil.nvl(iMap.getString("ADRES_NO"), kkBasvuruKimlikDiger.getAdresNo()));
				kkBasvuruKimlikDigerTx.setAileSiraNo(CreditCardServicesUtil.nvl(iMap.getString("AILE_SIRA_NO"), kkBasvuruKimlikDiger.getAileSiraNo()));
				kkBasvuruKimlikDigerTx.setAnneAdi(CreditCardServicesUtil.nvl(iMap.getString("ANNE_AD"), kkBasvuruKimlikDiger.getAnneAdi()));
				kkBasvuruKimlikDigerTx.setApsLogId(CreditCardServicesUtil.nvl(iMap.getBigDecimal("LOG_ID"), kkBasvuruKimlikDiger.getApsLogId()));
				kkBasvuruKimlikDigerTx.setBabaAd(CreditCardServicesUtil.nvl(iMap.getString("BABA_AD"), kkBasvuruKimlikDiger.getBabaAd()));
				kkBasvuruKimlikDigerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));//Zorunlu
				kkBasvuruKimlikDigerTx.setBireySiraNo(CreditCardServicesUtil.nvl(iMap.getString("BIREY_SIRA_NO"), kkBasvuruKimlikDiger.getBireySiraNo()));
				kkBasvuruKimlikDigerTx.setBucak(CreditCardServicesUtil.nvl(iMap.getString("BUCAK"), kkBasvuruKimlikDiger.getBucak()));
				kkBasvuruKimlikDigerTx.setBucakKod(CreditCardServicesUtil.nvl(iMap.getString("BUCAK_KOD"), kkBasvuruKimlikDiger.getBucakKod()));
				kkBasvuruKimlikDigerTx.setCiltNo(CreditCardServicesUtil.nvl(iMap.getString("CILT_KODU"), kkBasvuruKimlikDiger.getCiltNo()));
				kkBasvuruKimlikDigerTx.setCinsiyet(CreditCardServicesUtil.nvl(iMap.getString("CINSIYET_KOD"), kkBasvuruKimlikDiger.getCinsiyet()));
				kkBasvuruKimlikDigerTx.setCinsiyetKps(CreditCardServicesUtil.nvl(iMap.getString("CINSIYET"), kkBasvuruKimlikDiger.getCinsiyetKps()));
				kkBasvuruKimlikDigerTx.setCsbm(CreditCardServicesUtil.nvl(iMap.getString("CSBM"), kkBasvuruKimlikDiger.getCsbm()));
				kkBasvuruKimlikDigerTx.setCsbmKod(CreditCardServicesUtil.nvl(iMap.getString("CSBM_KODU"), kkBasvuruKimlikDiger.getCsbmKod()));
				kkBasvuruKimlikDigerTx.setDin(CreditCardServicesUtil.nvl(iMap.getString("DIN"), kkBasvuruKimlikDiger.getDin()));
				kkBasvuruKimlikDigerTx.setDisKapiNo(CreditCardServicesUtil.nvl(iMap.getString("DIS_KAPI_NO"), kkBasvuruKimlikDiger.getDisKapiNo()));
				kkBasvuruKimlikDigerTx.setDogumTar(CreditCardServicesUtil.nvl(iMap.getDate("DOGUM_TARIHI"), kkBasvuruKimlikDiger.getDogumTar()));
				kkBasvuruKimlikDigerTx.setDogumYeri(CreditCardServicesUtil.nvl(iMap.getString("DOGUM_YERI"), kkBasvuruKimlikDiger.getDogumYeri()));
				kkBasvuruKimlikDigerTx.setDogumyerkod(CreditCardServicesUtil.nvl(iMap.getString("DOGUM_YERI_KOD"), kkBasvuruKimlikDiger.getDogumyerkod()));
				kkBasvuruKimlikDigerTx.setDurum(CreditCardServicesUtil.nvl(iMap.getString("DURUMU_ACIKLAMA"), kkBasvuruKimlikDiger.getDurum()));
				kkBasvuruKimlikDigerTx.setDurumkod(CreditCardServicesUtil.nvl(iMap.getString("DURUMU"), kkBasvuruKimlikDiger.getDurumkod()));
				kkBasvuruKimlikDigerTx.setEsTckn(CreditCardServicesUtil.nvl(iMap.getString("ES_TCKN"), kkBasvuruKimlikDiger.getEsTckn()));
				kkBasvuruKimlikDigerTx.setEvAdres(CreditCardServicesUtil.nvl(iMap.getString("EV_ADRES"), kkBasvuruKimlikDiger.getEvAdres()));//Yok
				kkBasvuruKimlikDigerTx.setEvAdrIlceKod(CreditCardServicesUtil.nvl(iMap.getString("ILCE_KODU"), kkBasvuruKimlikDiger.getEvAdrIlceKod()));
				kkBasvuruKimlikDigerTx.setEvAdrIlKod(CreditCardServicesUtil.nvl(iMap.getString("IL_KODU"), kkBasvuruKimlikDiger.getEvAdrIlKod()));
				kkBasvuruKimlikDigerTx.setEvAdrUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("ULKE_KODU"), kkBasvuruKimlikDiger.getEvAdrUlkeKod()));//Yok
				kkBasvuruKimlikDigerTx.setIcKapiNo(CreditCardServicesUtil.nvl(iMap.getString("IC_KAPI_NO"), kkBasvuruKimlikDiger.getIcKapiNo()));
				kkBasvuruKimlikDigerTx.setIl(CreditCardServicesUtil.nvl(iMap.getString("APS_IL"), kkBasvuruKimlikDiger.getIl()));
				kkBasvuruKimlikDigerTx.setIlce(CreditCardServicesUtil.nvl(iMap.getString("APS_ILCE"), kkBasvuruKimlikDiger.getIlce()));
				kkBasvuruKimlikDigerTx.setKayityeril(CreditCardServicesUtil.nvl(iMap.getString("IL"), kkBasvuruKimlikDiger.getKayityeril()));
				kkBasvuruKimlikDigerTx.setKayityerilce(CreditCardServicesUtil.nvl(iMap.getString("ILCE"), kkBasvuruKimlikDiger.getKayityerilce()));
				kkBasvuruKimlikDigerTx.setKimIcin("E");
				kkBasvuruKimlikDigerTx.setKimlikKayitNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_KAYIT_NO"), kkBasvuruKimlikDiger.getKimlikKayitNo()));
				kkBasvuruKimlikDigerTx.setKimlikSeriNoKps(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO"), kkBasvuruKimlikDiger.getKimlikSeriNoKps()));
				kkBasvuruKimlikDigerTx.setKimlikSiraNoKps(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO"), kkBasvuruKimlikDiger.getKimlikSiraNoKps()));
				kkBasvuruKimlikDigerTx.setKoy(CreditCardServicesUtil.nvl(iMap.getString("KOY"), kkBasvuruKimlikDiger.getKoy()));
				kkBasvuruKimlikDigerTx.setKoyKayitNo(CreditCardServicesUtil.nvl(iMap.getString("KOY_KAYIT_NO"), kkBasvuruKimlikDiger.getKoyKayitNo()));
				kkBasvuruKimlikDigerTx.setKoyKod(CreditCardServicesUtil.nvl(iMap.getString("KOY_KOD"), kkBasvuruKimlikDiger.getKoyKod()));
				kkBasvuruKimlikDigerTx.setMahalle(CreditCardServicesUtil.nvl(iMap.getString("MAHALLE"), kkBasvuruKimlikDiger.getMahalle()));
				kkBasvuruKimlikDigerTx.setMahalleKod(CreditCardServicesUtil.nvl(iMap.getString("MAHALLE_KOD"), kkBasvuruKimlikDiger.getMahalleKod()));
				kkBasvuruKimlikDigerTx.setMahalleKoy(CreditCardServicesUtil.nvl(iMap.getString("CILT"), kkBasvuruKimlikDiger.getMahalleKoy()));
				kkBasvuruKimlikDigerTx.setMedeniHal(CreditCardServicesUtil.nvl(iMap.getString("MEDENI_HALI_KOD"), kkBasvuruKimlikDiger.getMedeniHal()));
				kkBasvuruKimlikDigerTx.setMedeniHalKps(CreditCardServicesUtil.nvl(iMap.getString("MEDENI_HALI"), kkBasvuruKimlikDiger.getMedeniHalKps()));
				kkBasvuruKimlikDigerTx.setMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), kkBasvuruKimlikDiger.getMusteriNo()));
				kkBasvuruKimlikDigerTx.setNufusIlceKod(CreditCardServicesUtil.nvl(iMap.getString("ILCE_KODU"), kkBasvuruKimlikDiger.getNufusIlceKod()));
				kkBasvuruKimlikDigerTx.setNufusIlKod(CreditCardServicesUtil.nvl(iMap.getString("IL_KODU"), kkBasvuruKimlikDiger.getNufusIlKod()));
				kkBasvuruKimlikDigerTx.setNufusVerNedeni(CreditCardServicesUtil.nvl(iMap.getString("VERILIS_NEDENI"), kkBasvuruKimlikDiger.getNufusVerNedeni()));
				kkBasvuruKimlikDigerTx.setNufusVerTar(CreditCardServicesUtil.nvl(iMap.getDate("VERILIS_TARIHI"), kkBasvuruKimlikDiger.getNufusVerTar()));
				kkBasvuruKimlikDigerTx.setNufusVerYer(CreditCardServicesUtil.nvl(iMap.getString("VERILDIGI_ILCE_ADI"), kkBasvuruKimlikDiger.getNufusVerYer()));
				kkBasvuruKimlikDigerTx.setOlumtarih(CreditCardServicesUtil.nvl(iMap.getDate("OLUM_TARIHI"), kkBasvuruKimlikDiger.getOlumtarih()));
				kkBasvuruKimlikDigerTx.setSoyad(CreditCardServicesUtil.nvl(iMap.getString("SOYAD"), kkBasvuruKimlikDiger.getSoyad()));
				kkBasvuruKimlikDigerTx.setVerildigiilcekod(CreditCardServicesUtil.nvl(iMap.getString("VERILDIGI_ILCE_KODU"), kkBasvuruKimlikDiger.getVerildigiilcekod()));
				kkBasvuruKimlikDigerTx.setVerilmenedenkod(CreditCardServicesUtil.nvl(iMap.getString("VERILIS_NEDENI_KOD"), kkBasvuruKimlikDiger.getVerilmenedenkod()));
				kkBasvuruKimlikDigerTx.setYabanciAdres(CreditCardServicesUtil.nvl(iMap.getString("YABANCI_ADRES"), kkBasvuruKimlikDiger.getYabanciAdres()));
				kkBasvuruKimlikDigerTx.setYabanciSehir(CreditCardServicesUtil.nvl(iMap.getString("YABANCI_SEHIR"), kkBasvuruKimlikDiger.getYabanciSehir()));
				kkBasvuruKimlikDigerTx.setYabanciUlke(CreditCardServicesUtil.nvl(iMap.getString("YABANCI_ULKE"), kkBasvuruKimlikDiger.getYabanciUlke()));
				kkBasvuruKimlikDigerTx.setYabanciUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("YABANCI_ULKE_KOD"), kkBasvuruKimlikDiger.getYabanciUlkeKod()));
			}
			else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				kkBasvuruKimlikDigerTx.setAd(iMap.getString("AD"));
				kkBasvuruKimlikDigerTx.setAdresNo(iMap.getString("ADRES_NO"));
				kkBasvuruKimlikDigerTx.setAileSiraNo(iMap.getString("AILE_SIRA_NO"));
				kkBasvuruKimlikDigerTx.setAnneAdi(iMap.getString("ANNE_AD"));
				kkBasvuruKimlikDigerTx.setApsLogId(iMap.getBigDecimal("LOG_ID"));
				kkBasvuruKimlikDigerTx.setBabaAd(iMap.getString("BABA_AD"));
				kkBasvuruKimlikDigerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));//Zorunlu
				kkBasvuruKimlikDigerTx.setBireySiraNo(iMap.getString("BIREY_SIRA_NO"));
				kkBasvuruKimlikDigerTx.setBucak(iMap.getString("BUCAK"));
				kkBasvuruKimlikDigerTx.setBucakKod(iMap.getString("BUCAK_KOD"));
				kkBasvuruKimlikDigerTx.setCiltNo(iMap.getString("CILT_KODU"));
				kkBasvuruKimlikDigerTx.setCinsiyet(iMap.getString("CINSIYET_KOD"));
				kkBasvuruKimlikDigerTx.setCinsiyetKps(iMap.getString("CINSIYET"));
				kkBasvuruKimlikDigerTx.setCsbm(iMap.getString("CSBM"));
				kkBasvuruKimlikDigerTx.setCsbmKod(iMap.getString("CSBM_KODU"));
				kkBasvuruKimlikDigerTx.setDin(iMap.getString("DIN"));
				kkBasvuruKimlikDigerTx.setDisKapiNo(iMap.getString("DIS_KAPI_NO"));
				kkBasvuruKimlikDigerTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
				kkBasvuruKimlikDigerTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
				kkBasvuruKimlikDigerTx.setDogumyerkod(iMap.getString("DOGUM_YERI_KOD"));
				kkBasvuruKimlikDigerTx.setDurum(iMap.getString("DURUMU_ACIKLAMA"));
				kkBasvuruKimlikDigerTx.setDurumkod(iMap.getString("DURUMU"));
				kkBasvuruKimlikDigerTx.setEsTckn(iMap.getString("ES_TCKN"));
				kkBasvuruKimlikDigerTx.setEvAdres(iMap.getString("EV_ADRES"));//Yok
				kkBasvuruKimlikDigerTx.setEvAdrIlceKod(iMap.getString("ILCE_KODU"));
				kkBasvuruKimlikDigerTx.setEvAdrIlKod(iMap.getString("IL_KODU"));
				kkBasvuruKimlikDigerTx.setEvAdrUlkeKod(iMap.getString("ULKE_KODU"));//Yok
				kkBasvuruKimlikDigerTx.setIcKapiNo(iMap.getString("IC_KAPI_NO"));
				kkBasvuruKimlikDigerTx.setIl(iMap.getString("APS_IL"));
				kkBasvuruKimlikDigerTx.setIlce(iMap.getString("APS_ILCE"));
				kkBasvuruKimlikDigerTx.setKayityeril(iMap.getString("IL"));
				kkBasvuruKimlikDigerTx.setKayityerilce(iMap.getString("ILCE"));
				kkBasvuruKimlikDigerTx.setKimIcin("E");
				kkBasvuruKimlikDigerTx.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));
				kkBasvuruKimlikDigerTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO"));
				kkBasvuruKimlikDigerTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO"));
				kkBasvuruKimlikDigerTx.setKoy(iMap.getString("KOY"));
				kkBasvuruKimlikDigerTx.setKoyKayitNo(iMap.getString("KOY_KAYIT_NO"));
				kkBasvuruKimlikDigerTx.setKoyKod(iMap.getString("KOY_KOD"));
				kkBasvuruKimlikDigerTx.setMahalle(iMap.getString("MAHALLE"));
				kkBasvuruKimlikDigerTx.setMahalleKod(iMap.getString("MAHALLE_KOD"));
				kkBasvuruKimlikDigerTx.setMahalleKoy(iMap.getString("CILT"));
				kkBasvuruKimlikDigerTx.setMedeniHal(iMap.getString("MEDENI_HALI_KOD"));
				kkBasvuruKimlikDigerTx.setMedeniHalKps(iMap.getString("MEDENI_HALI"));
				kkBasvuruKimlikDigerTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				kkBasvuruKimlikDigerTx.setNufusIlceKod(iMap.getString("ILCE_KODU"));
				kkBasvuruKimlikDigerTx.setNufusIlKod(iMap.getString("IL_KODU"));
				kkBasvuruKimlikDigerTx.setNufusVerNedeni(iMap.getString("VERILIS_NEDENI"));
				kkBasvuruKimlikDigerTx.setNufusVerTar(iMap.getDate("VERILIS_TARIHI"));
				kkBasvuruKimlikDigerTx.setNufusVerYer(iMap.getString("VERILDIGI_ILCE_ADI"));
				kkBasvuruKimlikDigerTx.setOlumtarih(iMap.getDate("OLUM_TARIHI"));
				kkBasvuruKimlikDigerTx.setSoyad(iMap.getString("SOYAD"));
				kkBasvuruKimlikDigerTx.setVerildigiilcekod(iMap.getString("VERILDIGI_ILCE_KODU"));
				kkBasvuruKimlikDigerTx.setVerilmenedenkod(iMap.getString("VERILIS_NEDENI_KOD"));
				kkBasvuruKimlikDigerTx.setYabanciAdres(iMap.getString("YABANCI_ADRES"));
				kkBasvuruKimlikDigerTx.setYabanciSehir(iMap.getString("YABANCI_SEHIR"));
				kkBasvuruKimlikDigerTx.setYabanciUlke(iMap.getString("YABANCI_ULKE"));
				kkBasvuruKimlikDigerTx.setYabanciUlkeKod(iMap.getString("YABANCI_ULKE_KOD"));
			}
			else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(kkBasvuruKimlikDigerTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Once basvuru numarasi, sonra islem numarasi ile basvuru bilgilerini arar ve
	 * bulunan bilgilerle musteriyi olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Basvuru bilgileri<br>
	 *            <li>BASVURU_NO - Kredi karti basvuru numarasi 
	 *            <li>TRX_NO - Kredi karti basvuru giris islem numarasi 
	 *            <li>TC_KIMLIK_NO - Kredi karti basvuru sahibi kimlik numarasi
	 *            <li>ISLEM_KODU - Musteri olusturma/guncelleme isini yapan islem
	 * @return oMap - Musteri yaratma bilgisi<br>
	 *            <li>MUSTERI_NO - Olusturulan musteri numarasi
	 *            <li>MUSTERI_YARATMA_TX_NO - Musteri olusturulurken kullanilan islem numarasi
	 */
	@GraymoundService("BNSPR_KK_SAVE_OR_UPDATE_MUSTERI_BY_BASVURU")
	public static GMMap saveMusteriByBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap musteriMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// Basvuru degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TRN3870.get_musteri_info_by_basvuru(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			musteriMap.putAll(DALUtil.rSetMap(rSet));

			// Aps bilgisini al
			iMap.put("MUSTERI_NO", musteriMap.get("MUSTERI_NO"));
			musteriMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_APS_INFO", iMap));

			// Musteriyi olustur
			musteriMap.put("ISLEM_KODU", iMap.get("ISLEM_KODU"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_KONTAK_MUSTERI_GERCEK", musteriMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	// --------------------------------------------------------BASVURUDURUMGUNCELLE
	/**
	 * Kredi karti basvurusunun durumunu gunceller. Verilen aksiyona gore tarihce icin de islem yapar.
	 * 
	 * @author murat.el
	 * @since PY-7707
	 * @param iMap - Durum bilgileri<br>
	 *            <li>BASVURU_NO - Kredi karti basvuru numarasi 
	 *            <li>ISLEM_NO - Islem numarasi 
	 *            <li>DURUM_KOD - Yeni durum kodu 
	 *            <li>AKSIYON_KOD - Alinan aksiyon 
	 *            <li>AKSIYON_KARAR_KOD - Alinan aksiyon gerekcesi 
	 *            <li>ISLEM_ACIKLAMA - Aciklama 
	 *            <li>TARIHCE_AKSIYON - Tarihce islem kodu (E:Ekle|G:Guncelle|H:Hicbirsey yapma)
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_KK_DURUM_GUNCELLE")
	public static GMMap updateDurum(GMMap iMap) {
		// initial variables
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			query = "{ call PKG_KK_BASVURU.Durum_Guncelle (?,?,?,?,?,?,?) }";
			stmt = conn.prepareCall(query);

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KOD"));
			stmt.setString(i++, iMap.getString("AKSIYON_KOD"));
			stmt.setString(i++, iMap.getString("AKSIYON_KARAR_KOD"));
			stmt.setString(i++, iMap.getString("ISLEM_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("TARIHCE_AKSIYON"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	public static String getKartUzerindekiIsim(String ad, String ikinciAd, String soyad) {
		//Verilen parametrelerle tam metni al
		StringBuilder kartUzerindekiIsim = new StringBuilder();
		kartUzerindekiIsim.append(ad);
		kartUzerindekiIsim.append(GAP);
		
		if (StringUtils.isNotBlank(ikinciAd)) {
			kartUzerindekiIsim.append(ikinciAd);
			kartUzerindekiIsim.append(GAP);
		}
		
		kartUzerindekiIsim.append(soyad);
		
		//Kontrol
		if (StringUtils.isBlank(kartUzerindekiIsim.toString())) {
			return StringUtils.EMPTY;
		}
		
		//Max 26 karakter kontrolu yap
		if (kartUzerindekiIsim.length() > 26) {
			kartUzerindekiIsim = new StringBuilder();
			kartUzerindekiIsim.append(CreditCardServicesUtil.nvl(ikinciAd, ad));
			kartUzerindekiIsim.append(GAP);
			kartUzerindekiIsim.append(soyad);
			if (kartUzerindekiIsim.length() > 26) {
				kartUzerindekiIsim = new StringBuilder();
				kartUzerindekiIsim.append(CreditCardServicesUtil.nvl(ikinciAd, ad).substring(0, 1));
				kartUzerindekiIsim.append(". ");
				kartUzerindekiIsim.append(soyad);
			}
		}
		
		return kartUzerindekiIsim.toString();
	}

}
