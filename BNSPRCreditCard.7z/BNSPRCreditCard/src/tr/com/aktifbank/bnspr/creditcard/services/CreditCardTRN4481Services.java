package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaDty;
import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaTx;
import tr.com.aktifbank.bnspr.dao.SbaEftGelenUcretler;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4481Services implements OceanMapKeys{
	private static final String Debit_Main_Account    = "A";
	@GraymoundService("BNSPR_TRN4481_IMPORT_EXCEL")
	public static GMMap importExcel (GMMap iMap){
		GMMap oMap = new GMMap();
        try {
            byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
            } catch (Exception e) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            for (int j = 0; j < sheet.getRows(); j++) {
            	if(!StringUtils.isEmpty(sheet.getCell(0, j).getContents())){
                for (int i = 0; i < sheet.getColumns(); i++) {
                	if(i==0){
                		oMap.put("EFTLIST", j, "ISLEMTIPI", sheet.getCell(i, j).getContents());
                		oMap.put("EFTLIST",j, "ISLEM", getIslemTipi(sheet.getCell(i, j).getContents()));
                	}
                	if(i==1)
                		oMap.put("EFTLIST", j, "SUBEKODU", sheet.getCell(i, j).getContents());
                	if(i==2)
                		oMap.put("EFTLIST", j, "TCKN",sheet.getCell(i, j).getContents());
                	if(i==3)
                		oMap.put("EFTLIST", j, "KARTNO",sheet.getCell(i, j).getContents());
                	if(i==4)
                		oMap.put("EFTLIST", j, "ADSOYAD",sheet.getCell(i, j).getContents());
                	if(i==5)
                		oMap.put("EFTLIST", j, "TUTAR",sheet.getCell(i, j).getContents().replace(",", "."));
                	if(i==6)
                		oMap.put("EFTLIST", j, "HESAPNO",sheet.getCell(i, j).getContents());
                	if(i==7)
                		oMap.put("EFTLIST", j, "KARTTIPI",sheet.getCell(i, j).getContents());
                	if(i==8)
                		oMap.put("EFTLIST", j, "MUSTERINO",sheet.getCell(i, j).getContents());
                	if(i==9)
                		oMap.put("EFTLIST", j, "BASVURUNO",sheet.getCell(i, j).getContents());
                	if(i==10)
                		oMap.put("EFTLIST", j, "ACIKLAMA",sheet.getCell(i, j).getContents());
                }	
                }
            }
            
        } catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
        } 
        return oMap;
	}
	@GraymoundService("BNSPR_TRN4481_KONTROL")
	public static GMMap kontrol(GMMap iMap){
		String dci = "";
        String hesapNo = "";
        String dest = "";
        String cardNo="";
		try {
			int s = iMap.getSize("EFTLIST");
			for (int i = 0; i < s; i++) {
				if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("2")) {//2. Karta/Ba�vuruya Gelen EFT �demesi
					if (StringUtils.isEmpty(iMap.getString("EFTLIST",i,"KARTNO"))&&StringUtils.isEmpty(iMap.getString("EFTLIST",i,"HESAPNO"))
							&&StringUtils.isEmpty(iMap.getString("EFTLIST",i,"BASVURUNO"))) {
						 iMap.put("HATA_NO", new BigDecimal(660));
			                iMap.put("P1", "Kart numaras�, Hesap Numaras�, ba�vuru numaras� ayn� anda bo� olamaz");
			                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						
					}
					if (!StringUtils.isEmpty(iMap.getString("EFTLIST",i,"HESAPNO"))) {
						if (getUrunSinif(iMap.getBigDecimal("EFTLIST",i,"HESAPNO")).equals("KKART FON")){
							iMap.put("HATA_NO", new BigDecimal(660));
			                iMap.put("P1", "Hesap No KKART FON Olamaz, sat�r no: " + (i+1));
			                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						
                    	iMap.put("EFTLIST",i,"ALICIHESAPNO", iMap.getString("EFTLIST",i,"HESAPNO"));
                    	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "VS");
		                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "");
					}
					if (StringUtils.isEmpty(iMap.getString("EFTLIST",i,"HESAPNO")) && !StringUtils.isEmpty(iMap.getString("EFTLIST",i,"KARTNO")) ) {
						// �nce kart a��k m� kontrol et, a��k de�ilse ba�vuruya para yat�r.
						 GMMap cardProperty = new GMMap();
						 cardNo = iMap.getString("EFTLIST",i,"KARTNO");
						 cardProperty.put("CARD_NO" , cardNo);
				            cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cardProperty);
				            if (cardProperty.getString("RETURN_CODE").equals("0")){
				                dci = cardProperty.getString("DCI");
				                dest = cardProperty.getString("DESTINATION");
				                GMMap cardInfoMap = new GMMap();
				                cardInfoMap.put("CARD_NO" , cardNo);
				                cardInfoMap.put("CARD_DCI" , "A");
				                iMap.put("EFTLIST",i,"KART_KAYNAGI", dest);
				                if (dest.equals("I")){
				                	cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO" , cardInfoMap);
				                	
				                } else{
				                	cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , cardInfoMap);
				                }
				                if (!cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_STAT_CODE).equals("N") || !cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_SUB_STAT_CODE).equals("N")){
				                	iMap.put("EFTLIST",i,"BASVURUNO", cardInfoMap.getString(CARD_DETAIL_INFO,0,"APPLICATION_NO"));
				                	iMap.put("EFTLIST",i,"ALICIHESAPNO",getGlobalParam("TFF_PARA_YUKLEME_BASVURU_HVZ"));
				                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
				                	iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
				                	
				                }
				                else{
				                	if(cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("D")){
				                		 List<GMMap> cardAccount = (List<GMMap>) cardInfoMap.get("CARD_DETAIL_INFO" , 0 , "DEBIT_ACCOUNT_LIST");
				                         GMMap accMap = new GMMap(cardAccount.get(0));
				                         
				                         for (int j = 0; j < accMap.getSize("DEBIT_ACCOUNT_LIST"); j++){
				                             
				                             if (accMap.getString("DEBIT_ACCOUNT_LIST" , j , "DEBIT_ACCOUNT_TYPE").equals(Debit_Main_Account)){
				                                 
				                            	iMap.put("EFTLIST",i,"ALICIHESAPNO", accMap.getBigDecimal("DEBIT_ACCOUNT_LIST" , j , "DEBIT_ACCOUNT_NO"));
				                            	iMap.put("EFTLIST",i,"HESAPNO", accMap.getBigDecimal("DEBIT_ACCOUNT_LIST" , j , "DEBIT_ACCOUNT_NO"));
				                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "VS");
								                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "");
				                            	break; 
				                             }
				                         }
				                	}
				                	else if(cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("P") && dest.equals("I")) {
				                		iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("PREPAID_YUKLEME_HAVUZ"));
		                            	iMap.put("EFTLIST",i,"KARTTIPI", "P");
		                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
						                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
				                		
				                	}
				                	else if(cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("P") && dest.equals("O") &&
				                			"YIM".equals(KkProductsUtil.getSourceFromProductId(cardInfoMap.getString(CARD_DETAIL_INFO,0,PRODUCT_ID)))){
				                		iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ"));
		                            	iMap.put("EFTLIST",i,"KARTTIPI", "P");
		                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
						                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				                		
				                	}else if(cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("P") && dest.equals("O") &&
				                			"UPT".equals(KkProductsUtil.getSourceFromProductId(cardInfoMap.getString(CARD_DETAIL_INFO,0,PRODUCT_ID)))){
				                		iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ_UPT"));
		                            	iMap.put("EFTLIST",i,"KARTTIPI", "P");
		                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
						                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				                		
				                	}else if(cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("P") && dest.equals("O") &&
				                			"HCE".equals(KkProductsUtil.getSourceFromProductId(cardInfoMap.getString(CARD_DETAIL_INFO,0,PRODUCT_ID)))){
				                		iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("OCEAN_HCE_TOPUP_HAVUZ"));
		                            	iMap.put("EFTLIST",i,"KARTTIPI", "P");
		                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
						                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				                		
				                	}else if (cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("P") && dest.equals("O") &&
				                				cardProperty.getBoolean("IS_PROCEED")){
				                		iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("OCEAN_PROCEED_TOPUP_HAVUZ"));
		                            	iMap.put("EFTLIST",i,"KARTTIPI", "P");
		                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
						                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				                		
				                	}
				                	else if(cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_DCI_AKUSTIK).equals("C")){
				                		
				                		iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("KKART_ODEME_HAVUZ"));
		                            	iMap.put("EFTLIST",i,"KARTTIPI", "C");
		                            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
						                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				                	}else{
				                		iMap.put("HATA_NO", new BigDecimal(660));
						                iMap.put("P1", "Hatal� Kart Numaras�, sat�r no: " + (i+1));
						                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				                	}
				                }
				            }
				            else {
				            	iMap.put("HATA_NO", new BigDecimal(660));
				                iMap.put("P1", "Kart Numaras� hatal�, sat�r no: " + (i+1));
				                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
							}
					}
					if (StringUtils.isEmpty(iMap.getString("EFTLIST",i,"HESAPNO")) && StringUtils.isEmpty(iMap.getString("EFTLIST",i,"KARTNO")) && !StringUtils.isEmpty(iMap.getString("EFTLIST",i,"BASVURUNO")) ) {
						GMMap bsMap = new GMMap();
						bsMap.put("APPLICATION_NO",iMap.getString("EFTLIST",i,"BASVURUNO"));
						bsMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_GET_APPLICATION_SUMMARY_INFO", bsMap);
						
						if(!bsMap.getString("APPLICATION_SUMMARY_INFO",0,"APPLICATION_STATUS").equals("ACIK")){
						iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("TFF_PARA_YUKLEME_BASVURU_HVZ"));
	                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
		                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
		                }else{
		                	iMap.put("HATA_NO", new BigDecimal(660));
			                iMap.put("P1", "Ba�vurunun durumu a��k hale gelmi�, sat�r no: " + (i+1));
			                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		                }
						
					}
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("BKM_HESAP"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
				}
				else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("1")){ //1. EFT ile Gelen Vize �cretleri 
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("BKM_HESAP"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("G4_GISE_BASVURU_VIZE"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "VS");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "101");
				}
				else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("3")){//sil
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("SBA_EFT_GELEN_JEST_KART_BORC"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "DK");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", iMap.getString("EFTLIST",i,"SUBEKODU"));
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("G4_GISE_BASVURU_VIZE"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "VS");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "101");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("4")){//4. EFT ile gelen Sanal POS �adesi
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("BKM_HESAP"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("POS_143_HAVUZ_HESABI"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("5")){ //5. Ekent POS - Sanal POS Bakiye Aktar�m�
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("EKENT_POS_HESABI"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "444");
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("POS_143_HAVUZ_HESABI"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("6")){//6.Kombine - Bilet bedeli aktar�m
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("TFF_KOMBINE_SATIS_ALACAK"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("TFF_BILET_ALACAK_ASSET"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("7")){//7.Kombine - Kredi kart� takas iade
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("TFF_KOMBINE_SATIS_ALACAK"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("BKM_UYE_ISYERI_KK_HESABI"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("8")){//8.Kombine Banka kart� takas iade
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("TFF_KOMBINE_SATIS_ALACAK"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("BKM_UYE_ISYERI_DK_HESABI"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("9")){
					if (StringUtils.isEmpty(iMap.getString("EFTLIST",i,"KARTNO"))){
						//9. kombine - prepaid kart iade
						iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Kart numaras� bo� olamaz");
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					 GMMap cardProperty = new GMMap();
					 cardNo = iMap.getString("EFTLIST",i,"KARTNO");
					 cardProperty.put("CARD_NO" , cardNo);
			         cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cardProperty);
			         if (cardProperty.getString("RETURN_CODE").equals("0")){
			                dci = cardProperty.getString("DCI");
			                dest = cardProperty.getString("DESTINATION");
			                if (!dci.equals("P")){
			                	iMap.put("HATA_NO", new BigDecimal(660));
				                iMap.put("P1", "Kart Prepaid de�il, sat�r no: " + (i+1));
				                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			                }
			            }
			         else{
			        	iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Kart Numaras� hatal�, sat�r no: " + (i+1));
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			         }
					
			        iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("TFF_KOMBINE_SATIS_ALACAK"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	iMap.put("EFTLIST",i,"KART_KAYNAGI", dest);
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("PP_FINANSAL_BAKIM_HESAP"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "997");
	                iMap.put("EFTLIST",i,"KARTTIPI", "P");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("10")){//10. kombine - Kredi kart� iade
					if (StringUtils.isEmpty(iMap.getString("EFTLIST",i,"KARTNO"))){
						//9. kombine - prepaid kart iade
						iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Kart numaras� bo� olamaz");
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					cardNo = iMap.getString("EFTLIST",i,"KARTNO");
					GMMap cardProperty = new GMMap(); 
					cardProperty.put("CARD_NO" , cardNo);
			         cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cardProperty);
			         if (cardProperty.getString("RETURN_CODE").equals("0")){
			                dci = cardProperty.getString("DCI");
			                dest = cardProperty.getString("DESTINATION");
			                if (!dci.equals("C")){
			                	iMap.put("HATA_NO", new BigDecimal(660));
				                iMap.put("P1", "Kart Kredi Kart� de�il, sat�r no: " + (i+1));
				                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			                }
			            }
			         else{
			        	iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Kart Numaras� hatal�, sat�r no: " + (i+1));
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			         }
					iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("TFF_KOMBINE_SATIS_ALACAK"));
                	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
                	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "998");
                	iMap.put("EFTLIST",i,"KART_KAYNAGI", dest);
                	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("KK_FINANSAL_BAKIM_HESAP"));
                	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
	                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
	                iMap.put("EFTLIST",i,"KARTTIPI", "C");
				}else if (iMap.getString("EFTLIST",i,"ISLEMTIPI").equals("11")){ //11 - EGO Topup ��lem iadesi
				iMap.put("EFTLIST",i,"BORCHESAPNO",getGlobalParam("EKENT_POS_HESABI"));
            	iMap.put("EFTLIST",i,"BORCHESAPCINSI", "VS");
            	iMap.put("EFTLIST",i,"BORCHESAPSUBE", "444");
            	
            	iMap.put("EFTLIST",i,"ALICIHESAPNO", getGlobalParam("POS_143_HAVUZ_HESABI"));
            	iMap.put("EFTLIST",i,"ALICIHESAPCINSI", "DK");
                iMap.put("EFTLIST",i,"ALICIHESAPSUBE", "998");
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	@GraymoundService("BNSPR_TRN4481_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			int s= iMap.getSize("EFTLIST");
			for (int i = 0; i < s; i++) {
				SbaEftGelenUcretler ucret = new SbaEftGelenUcretler();
				ucret.setAciklama(iMap.getString("EFTLIST",i,"ACIKLAMA"));
				ucret.setAdSoyad(iMap.getString("EFTLIST",i,"ADSOYAD"));
				ucret.setAlckHesapCinsi(iMap.getString("EFTLIST",i,"ALICIHESAPCINSI"));
				ucret.setAlckHesapNo(iMap.getString("EFTLIST",i,"ALICIHESAPNO"));
				ucret.setAlckSubeKodu(iMap.getString("EFTLIST",i,"ALICIHESAPSUBE"));
				ucret.setBasvuruNo(iMap.getBigDecimal("EFTLIST",i,"BASVURUNO"));
				ucret.setBorcHesapCinsi(iMap.getString("EFTLIST",i,"BORCHESAPCINSI"));
				ucret.setBorcHesapNo(iMap.getString("EFTLIST",i,"BORCHESAPNO"));
				ucret.setBorcSubeKodu(iMap.getString("EFTLIST",i,"BORCHESAPSUBE"));
				ucret.setHesapNo(iMap.getBigDecimal("EFTLIST",i,"HESAPNO"));
				ucret.setIslemTipi(iMap.getString("EFTLIST",i,"ISLEMTIPI"));
				ucret.setKartNo(iMap.getString("EFTLIST",i,"KARTNO"));
				ucret.setKartTipi(iMap.getString("EFTLIST",i,"KARTTIPI"));
				ucret.setMainTxNo(iMap.getBigDecimal("TRX_NO"));
				ucret.setMusteriNo(iMap.getBigDecimal("EFTLIST",i,"MUSTERINO"));
				ucret.setSubeKodu(iMap.getString("EFTLIST",i,"SUBEKODU"));
				ucret.setTcKimlikNo(iMap.getString("EFTLIST",i,"TCKN"));
				ucret.setTutar(iMap.getBigDecimal("EFTLIST",i,"TUTAR"));
				ucret.setKartKaynagi(iMap.getString("EFTLIST",i,"KART_KAYNAGI"));
				ucret.setTxNo(createTx());
				session.saveOrUpdate(ucret);
			}
			session.flush();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("TRX_NAME" , "4481");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4482_AFTER_APPROVAL")
	public static GMMap afterApproval (GMMap iMap){
		GMMap oMap =new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaEftGelenUcretler ucret = (SbaEftGelenUcretler) session.createCriteria(SbaEftGelenUcretler.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			if (ucret.getIslemTipi().equals("2") || ucret.getIslemTipi().equals("10")){
				if ((ucret.getHesapNo()==null || ucret.getHesapNo().toString() == "")&& !(ucret.getBasvuruNo()==null || ucret.getBasvuruNo().toString()=="")){
					 GMMap inMap = new GMMap();
		                inMap.put("TX_NO" , ucret.getTxNo());
		                GMMap cMap = new GMMap();
		                cMap = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , cMap);
		                String kanal = cMap.getString("KANAL_KOD");
		                inMap.put("CHANNEL" , kanal);
		                inMap.put("APPLICATION_NO" , ucret.getBasvuruNo());
		                inMap.put("TXN_AMOUNT" , ucret.getTutar());
		                inMap.put("CUSTOMER_NO" , "");
		                inMap.put("TCKN" , ucret.getTcKimlikNo());
		                inMap.put("EUPT_ACCOUNT_NO" , "");
		                
		                GMServiceExecuter.call("BNSPR_INTRACARD_CRD_TFF_TOP_UP_APPLICATION_INVEST" , inMap);
				}
				else if ((ucret.getHesapNo()==null || ucret.getHesapNo().toString() == "") && !(ucret.getKartNo()==null || ucret.getKartNo() == "")&& (ucret.getKartTipi().equals("P") || ucret.getKartTipi().equals("C"))){
					GMMap tMap = new GMMap();
			        
			        tMap.put("TX_NO" , ucret.getTxNo());
			        tMap.put("CARD_NO" , ucret.getKartNo());
			        tMap.put("REQUEST_TYPE" , OceanConstants.Request_Normal);
			        tMap.put("TERMINAL_ID" , "9999999");
			        tMap.put("TXN_AMOUNT" , ucret.getTutar());
			        tMap.put("TXN_CURR" , "TRY");
			        tMap.put("PAYMENT_TYPE" , OceanConstants.Payment_LoadMoney);
			        tMap.put("REQUEST_TYPE" , "N");
			        tMap.put("ACCOUNT_BRANCH_ID" , "0");
			        tMap.put("TXN_DESC" , ucret.getKartNo() + " nolu karta EFT ile para y�kleme.");
			        
			        GMMap otMap = new GMMap();
			        if(ucret.getKartKaynagi().equals("I")){
			        	otMap = GMServiceExecuter.call("BNSPR_INTRACARD_CARD_TOPUP" , tMap);
			        }else if(ucret.getKartKaynagi().equals("O") && ucret.getKartTipi().equals("P")){
			        otMap = GMServiceExecuter.call("BNSPR_OCEAN_PREPAID_TOPUP" , tMap);}
			        
			        else if(ucret.getKartTipi().equals("C")){
			        	GMMap iMapx = new GMMap();
			        	 iMapx.put("ACCOUNT_BRANCH" , "998");
			             iMapx.put("ACCOUNT_NO" , "");
			             
			             iMapx.put("BRANCH_CODE" ,"998");
			             
			             iMapx.put("REFERENCE_NO" , ucret.getTxNo());
			             iMapx.put("CARD_NO" , ucret.getKartNo());
			             iMapx.put("ORIGINAL_RRN" , "");
			             iMapx.put("TERMINAL_ID" , "9999999");
			             
			             GMMap oMapK = new GMMap();
			             oMapK = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , oMapK);
			             
			             
			             iMapx.put("CHANNEL_CODE" , "1");
			             
			             iMapx.put("PAYMENT_TYPE" , "A");
			             iMapx.put("REQUEST_TYPE" , "N");
			             iMapx.put("TXN_AMOUNT" , ucret.getTutar());
			             
			             iMapx.put("TXN_CURR" , "TRY");
			             iMapx.put("TXN_DESC" , ucret.getKartNo() + " nolu karta EFT ile para y�kleme.");
			             
			             otMap = GMServiceExecuter.call("BNSPR_OCEAN_MAKE_CARD_PAYMENT" , iMapx);
			        }
			        
			        if (otMap.getInt("RETURN_CODE") != OceanConstants.Result_Succesful){
			        	String mailAdres = getGlobalParam("SBA_EFT_GELEN_UCRETLER_MAIL");
			        	String subject = "4481 Ekran� Hata";
			        	String mesaj = "Merhaba, \n A�a��daki karta para yat�r�lamad�, fi� iptal edilmeli \n Kart No: "+ucret.getKartNo() 
			        			+ "\n ��lem Numaras�: " +ucret.getTxNo().toString() + "\n Hata Mesaj�: " +otMap.getString("RETURN_CODE") + " : " + otMap.getString("RETURN_DESCRIPTION");
			        	GMMap mailMap = new GMMap();
			        	mailMap.put("TO_LIST", mailAdres);
			        	mailMap.put("SUBJECT", subject);
			        	mailMap.put("MESSAGE_BODY", mesaj);
			        	GMServiceExecuter.call("BNSPR_4482_SEND_MAIL", mailMap);
 			        }
			        
				}
			}
			if( ucret.getIslemTipi().equals("9")){
				GMMap cardMap = new GMMap();
				GMMap cardRespMap = new GMMap();
				
				cardMap.put(BSMV_RATE, BigDecimal.ZERO);
				cardMap.put(KKF_RATE, BigDecimal.ZERO);
				
				cardMap.put(TXN_AMOUNT, ucret.getTutar());
				cardMap.put(CARD_NO, ucret.getKartNo());
				cardMap.put(TXN_DESC, "Bilet-Kombine �ade");
				cardMap.put(TXN_CURR_CODE, "TRY");
				cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
				cardMap.put(TXN_STATE, "N");

				SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
				cardMap.put(TXN_DATE, format.format(new Date()));
				if(ucret.getKartKaynagi().equals("I")){
					cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
				}
				else if(ucret.getKartKaynagi().equals("O")){
					cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
				}
				
				if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
					String mailAdres = getGlobalParam("SBA_EFT_GELEN_UCRETLER_MAIL");
		        	String subject = "4481 Ekran� Hata";
		        	String mesaj = "Merhaba, \n A�a��daki karta para yat�r�lamad�, fi� iptal edilmeli \n Kart No: "+ucret.getKartNo() 
		        			+ "\n ��lem Numaras�: " +ucret.getTxNo().toString() + "\n Hata Mesaj�: " +cardRespMap.getString("RETURN_CODE") + " : " + cardRespMap.getString("RETURN_DESCRIPTION");
		        	GMMap mailMap = new GMMap();
		        	mailMap.put("TO_LIST", mailAdres);
		        	mailMap.put("SUBJECT", subject);
		        	mailMap.put("MESSAGE_BODY", mesaj);
		        	GMServiceExecuter.call("BNSPR_4482_SEND_MAIL", mailMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4481_AFTER_APPROVAL")
	public static GMMap afterApproval4481 (GMMap iMap){
		GMMap oMap =new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> ucretList = session.createCriteria(SbaEftGelenUcretler.class).add(Restrictions.eq("mainTxNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			for (Object name : ucretList) {
				try {
					SbaEftGelenUcretler ucret = (SbaEftGelenUcretler) name;
					iMap.put("TRX_NO", ucret.getTxNo());
					iMap.put("TRX_NAME" , "4482");
			        oMap = (GMMap) GMServiceExecuter.executeNT("BNSPR_TRX_SEND_TRANSACTION" , iMap);
				}
				catch (Exception e) {
					continue;
				}
				
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4481_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> ucretList = session.createCriteria(SbaEftGelenUcretler.class).add(Restrictions.eq("mainTxNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			for (Object name : ucretList) {
				SbaEftGelenUcretler ucret = (SbaEftGelenUcretler) name;
				oMap.put("EFTLIST",i, "ACIKLAMA",ucret.getAciklama());
				oMap.put("EFTLIST",i,"ADSOYAD",ucret.getAdSoyad());
				oMap.put("EFTLIST",i,"ALICIHESAPCINSI",ucret.getAlckHesapCinsi());
				oMap.put("EFTLIST",i,"ALICIHESAPNO",ucret.getAlckHesapNo());
				oMap.put("EFTLIST",i,"ALICIHESAPSUBE",ucret.getAlckSubeKodu());
				oMap.put("EFTLIST",i,"BASVURUNO",ucret.getBasvuruNo());
				oMap.put("EFTLIST",i,"BORCHESAPCINSI",ucret.getBorcHesapCinsi());
				oMap.put("EFTLIST",i,"BORCHESAPNO",ucret.getBorcHesapNo());
				oMap.put("EFTLIST",i,"BORCHESAPSUBE", ucret.getBorcSubeKodu());
				oMap.put("EFTLIST",i,"HESAPNO",ucret.getHesapNo());
				oMap.put("EFTLIST",i,"ISLEM",getIslemTipi(ucret.getIslemTipi()));
				oMap.put("EFTLIST",i,"ISLEMTIPI",ucret.getIslemTipi());
				oMap.put("EFTLIST",i,"KARTNO",ucret.getKartNo());
				oMap.put("EFTLIST",i,"KARTTIPI",ucret.getKartTipi());
				oMap.put("EFTLIST",i,"MUSTERINO",ucret.getMusteriNo());
				oMap.put("EFTLIST",i,"SUBEKODU", ucret.getSubeKodu());
				oMap.put("EFTLIST",i,"TCKN",ucret.getTcKimlikNo());
				oMap.put("EFTLIST",i,"TUTAR",ucret.getTutar());
				i=i+1;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	  @GraymoundService("BNSPR_4482_SEND_MAIL")
	    public static GMMap sendMail(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try{
	            GMMap mailServisMap = new GMMap();
	            mailServisMap.put("FROM" , "BNSPR-System@aktifbank.com.tr");
	            mailServisMap.put("RECIPIENTS_TO" , GuimlUtil.createFromCommaSeparatedList(iMap.getString("TO_LIST")));
	            if (iMap.getString("MAIL_CC") != null)
	                mailServisMap.put("RECIPIENTS_CC" , GuimlUtil.createFromCommaSeparatedList(iMap.getString("MAIL_CC")));
	            if (iMap.getString("MAIL_BCC") != null)
	                mailServisMap.put("RECIPIENTS_BCC" , GuimlUtil.createFromCommaSeparatedList(iMap.getString("MAIL_BCC")));
	            mailServisMap.put("SUBJECT" , iMap.getString("SUBJECT"));
	            String messageBody = iMap.getString("MESSAGE_BODY");
	            mailServisMap.put("MESSAGE_BODY" , messageBody);
	            mailServisMap.put("IS_BODY_HTML" , "E".equals(iMap.getString("IS_BODY_HTML")) ? true : false);
	            
	            GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL" , mailServisMap);
	            
	            oMap.put("RESPONSE" , "0");
	            oMap.put("RESPONSE_DATA" , "");
	            
	        } catch (Exception e){
	            oMap.put("RESPONSE" , "2");
	            oMap.put("RESPONSE_DATA" , e.getMessage());
	            e.printStackTrace();
	        }
	        
	        return oMap;
	    }
	 public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	 public static BigDecimal createTx(){
	    	GMMap oMapN = new GMMap();
			oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
			return oMapN.getBigDecimal("TRX_NO");
		}
	 public static String getUrunSinif (BigDecimal hesapNo){
		 Object[] input = new Object[2];
		 input[0] = BnsprType.NUMBER;
		 input[1] = hesapNo;
		 String func = "{? = call PKG_HESAP.urun_sinif_kod(?)}";
		 String urunSinif = (String) DALUtil.callOneParameterFunction(func, Types.CHAR, hesapNo);
		 return urunSinif;
	 }
	 public static String getIslemTipi (String islem){
		 if (islem.equals("1")){
			 return "Instant Ba�vuru ��in Gelen EFT" ;
		 }
		 else if (islem.equals("2")){
			 return "Gelen EFT�den M��terilere Bakiye Aktar�mlar�";
		 }
		 else if (islem.equals("3")){
			 return "Ba�vuru �cretinin Gider Hesab�ndan Kar��lanmas�";
		 }
		 else if (islem.equals("4")){
			 return "Di�er banka ��Y sanal pos bakiye aktar�m�";
		 }
		 else if (islem.equals("5")){
			 return "��Y Sanal POS Bakiye Aktar�m�";
		 }else if (islem.equals("6")){
			 return "Bilet bedeli aktar�m�";
		 }
		 else if (islem.equals("7")){
			 return "Kombine - Kredi Kart� Takas �ade";
		 }
		 else if (islem.equals("8")){
			 return "Kombine Banka Kart� Takas �ade";
		 }
		 else if (islem.equals("9")){
			 return "Kombine - Prepaid Kart �ade";
		 }else if (islem.equals("10")){
			 return "Kombine - Kredi Kart� �ade";
		 }
		 else{
			 return "";
		 }
	 }
	
}
