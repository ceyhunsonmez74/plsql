package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaTakastanPpiadeTx;
import tr.com.aktifbank.bnspr.dao.SbaTakastanPpiadeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4486Services implements OceanMapKeys{
	@GraymoundService("BNSPR_TRN4486_IMPORT_EXCEL")
	public static GMMap importExcel (GMMap iMap){
		GMMap oMap = new GMMap();
        try {
            byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
            } catch (Exception e) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            for (int j = 0; j < sheet.getRows(); j++) {
            	if(!StringUtils.isEmpty(sheet.getCell(0, j).getContents())){
                for (int i = 0; i < sheet.getColumns(); i++) {
                	if(i==0)
                		oMap.put("KARTLIST", j, "KARTNO", sheet.getCell(i, j).getContents());
                	if(i==1)
                		oMap.put("KARTLIST", j, "FISNO", sheet.getCell(i, j).getContents());
                	}	
                }
            }
            
        } catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
        } 
        return oMap;
	}
	@GraymoundService("BNSPR_TRN4486_KONTROL")
	public static GMMap kontrol(GMMap iMap){
		
		GMMap cardMap = new GMMap();
		
		try {
			int s = iMap.getSize("KARTLIST");
			boolean isError = false; 
			for (int i = 0; i < s; i++) {
				
				if (StringUtils.isEmpty(iMap.getString("KARTLIST",i,"KARTNO")) || StringUtils.isEmpty(iMap.getString("KARTLIST",i,"FISNO"))) {
						 iMap.put("HATA_NO", new BigDecimal(660));
			                iMap.put("P1", "Kart numaras� veya Fi� Numaras� bo� olamaz. Sat�r No: " + (i+1));
			                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						
					}
				cardMap.clear(); 
				cardMap.put("CARD_NO", iMap.getString("KARTLIST",i,"KARTNO"));
				cardMap = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cardMap);
				if (!cardMap.getString("RETURN_CODE").equals("0") || !cardMap.getString("DCI").equals("P")){
					iMap.put("KARTLIST",i, "ACIKLAMA","Kart Prepaid kart de�il!");
					isError=true;
				}
				else{
					iMap.put("KARTLIST",i, "ACIKLAMA","");
				}
				String func = "{?=call PKG_TRN4486.TUTAR_AL(?)}";
				BigDecimal tutar =  (BigDecimal) DALUtil.callOneParameterFunction(func, Types.NUMERIC, iMap.getBigDecimal("KARTLIST",i,"FISNO"));
				iMap.put("KARTLIST",i, "TUTAR",tutar);
				if (tutar.compareTo(BigDecimal.ZERO)==0)
					isError=true;
					
			}
			if(isError)
				iMap.put("HATA", "1");
			else
				iMap.put("HATA", "0");
		}
         catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	@GraymoundService("BNSPR_TRN4486_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			int s= iMap.getSize("KARTLIST");
			for (int i = 0; i < s; i++) {
				SbaTakastanPpiadeTx iade = new SbaTakastanPpiadeTx();
				SbaTakastanPpiadeTxId iadeId = new SbaTakastanPpiadeTxId();
				iadeId.setOrgFisNo(iMap.getBigDecimal("KARTLIST",i,"FISNO"));
				iadeId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				iade.setId(iadeId);
				iade.setAciklama(iMap.getString("KARTLIST",i,"ACIKLAMA"));
				iade.setTutar(iMap.getBigDecimal("KARTLIST",i,"TUTAR"));
				iade.setKartNo(iMap.getString("KARTLIST",i,"KARTNO"));
				iade.setDurum("A");
				session.saveOrUpdate(iade);
			}
			session.flush();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("TRX_NAME" , "4486");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4486_AFTER_APPROVAL")
	public static GMMap afterApproval (GMMap iMap){
		GMMap oMap =new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> iadeList = session.createCriteria(SbaTakastanPpiadeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).add(Restrictions.eq("durum", "A")).list();
			GMMap cardMap = new GMMap();
			GMMap cardRespMap = new GMMap();
			String kartList="";
					
			for (Object name : iadeList) {
				SbaTakastanPpiadeTx iade = (SbaTakastanPpiadeTx) name;
			
			cardMap.put(BSMV_RATE, BigDecimal.ZERO);
			cardMap.put(KKF_RATE, BigDecimal.ZERO);
			
			cardMap.put(TXN_AMOUNT, iade.getTutar());
			cardMap.put(CARD_NO, iade.getKartNo());
			cardMap.put(TXN_DESC, "Takastan Gelmeyen ��lem �adesi");
			cardMap.put(TXN_CURR_CODE, "TRY");
			cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
			cardMap.put(TXN_STATE, "N");

			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			cardMap.put(TXN_DATE, format.format(new Date()));
			try {
				cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
				if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
					iade.setDurum("X");
					session.saveOrUpdate(iade);
					kartList=kartList.trim()+" "+ iade.getKartNo()+",";
				}else{
				
				cardRespMap.put(TX_NO, iMap.getBigDecimal("ISLEM_NO"));
				cardRespMap.put(OCEAN_RESULT, cardRespMap.getString("OCEAN_RESULT"));
				GMServiceExecuter.executeAsync("BNSPR_CRD_INSERT_TOPUP_RRN_LOG", cardRespMap);
				iade.setDurum("M");
				session.saveOrUpdate(iade);
				}
			}
			catch (Exception e) {
				iade.setDurum("X");
				session.saveOrUpdate(iade);
				kartList=kartList.trim()+" "+ iade.getKartNo()+",";
			}
			
		}
			session.flush();
			String func ="{call PKG_TRN4486.Booking_after(?)}";
			Object [] inputValues = new Object[2];
			Object [] outputValues = new Object[0];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("ISLEM_NO");
			DALUtil.callOracleProcedure(func, inputValues, outputValues);
			
			oMap.put("MESSAGE", "��lem Ba�ar�yla Tamamland�");
			if(!StringUtil.isEmpty(kartList.trim())){
				mailGonder(kartList);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4486_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> iadeList = session.createCriteria(SbaTakastanPpiadeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			for (Object name : iadeList) {
				SbaTakastanPpiadeTx iade = (SbaTakastanPpiadeTx) name;
				oMap.put("KARTLIST", i,"KARTNO",iade.getKartNo());
				oMap.put("KARTLIST",i, "FISNO",iade.getId().getOrgFisNo());
				oMap.put("KARTLIST",i, "TUTAR",iade.getTutar());
				oMap.put("KARTLIST",i,"ACIKLAMA", iade.getAciklama());
			
				i=i+1;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	  
	 public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	 public static void mailGonder(String kartList){
		 String mailAdres ="takasvekartmutabakat.servisi@aktifbank.com.tr";
     	String subject = "4486 Ekran� Finansal Bak�m Yap�lamayan Kartlar";
     	String mesaj = "Merhaba, \n A�a��daki kartlara finansal bak�m yap�lamad�, kontrol ediniz \n"+kartList;
     			
     	GMMap mailMap = new GMMap();
     	mailMap.put("TO_LIST", mailAdres);
     	mailMap.put("SUBJECT", subject);
     	mailMap.put("MESSAGE_BODY", mesaj);
     	GMServiceExecuter.call("BNSPR_4482_SEND_MAIL", mailMap);
	 }
	
	
}
