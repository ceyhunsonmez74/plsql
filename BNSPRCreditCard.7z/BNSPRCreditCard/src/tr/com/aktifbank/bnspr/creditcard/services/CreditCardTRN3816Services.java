package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyoniptalTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyoniptalTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3816Services {

	private static final String ISLEM_KODU = "3816";

	@GraymoundService("BNSPR_TRN3816_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			if (iMap.getBigDecimal("GRUP_ID") == null && 
			   ("".equals(iMap.getString("PROMOSYON")) || iMap.getString("PROMOSYON") == null))
				CreditCardServicesUtil.raiseGMError("4669");

			String func = "{? = call PKG_TRN3816.Promosyon_Kodu_Listesi(?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("GRUP_ID"), 
					                 BnsprType.STRING, iMap.getString("PROMOSYON") };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "URUN_LISTE", inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3816_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			if (StringUtils.isBlank(iMap.getString("DIZIN")))
				CreditCardServicesUtil.raiseGMError("4349");

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			List<?> listUrun = (List<?>) iMap.get("URUN_LISTE");
			String tableName = "URUN_LISTE";
			if (listUrun != null) {
				for (int i = 0; i < listUrun.size(); i++) {
					if (iMap.getBoolean(tableName, i, "SEC")) {
						TffBasvuruPromosyoniptalTxId proTxId = new TffBasvuruPromosyoniptalTxId();
						TffBasvuruPromosyoniptalTx proTx = new TffBasvuruPromosyoniptalTx();
						proTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						proTxId.setGrupId(iMap.getBigDecimal(tableName, i, "GRUP_ID"));
						proTxId.setPromosyonKodu(iMap.getString(tableName, i, "PROMOSYON"));
						proTx.setId(proTxId);
						proTx.setAdet(iMap.getBigDecimal(tableName, i, "ADET"));
						proTx.setKartBedeli(iMap.getBigDecimal(tableName, i, "KART_BEDELI"));
						proTx.setKuryeBedeli(iMap.getBigDecimal(tableName, i, "KURYE_BEDELI"));
						proTx.setLoyaltyBedeli(iMap.getBigDecimal(tableName, i, "LOYALTY_BEDELI"));
						proTx.setVizeBedeli(iMap.getBigDecimal(tableName, i, "VIZE_BEDELI"));
						session.save(proTx);
						session.flush();
						iMap.put("GRUP_ID", iMap.getBigDecimal(tableName, i, "GRUP_ID"));
					}
				}
			}
			// iptal edilecek hicbir kayit secilmedi ise hata verilir.
			if (iMap.getBigDecimal("GRUP_ID") == null)
				CreditCardServicesUtil.raiseGMError("4671");

			// Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", ISLEM_KODU);
			islemMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3816_GET_PROMOSYON_KODLARI", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3816_GET_PROMOSYON_KODLARI")
	public static GMMap getPromosyonKodlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			BigDecimal gi = iMap.getBigDecimal("GRUP_ID");

			String fileName = "Promosyon_Iptal_" + gi.toString() + "_";
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();

			headers.put("GRUP_ID", new String[] { "Grup ID" });
			headers.put("GRUP_ADI", new String[] { "Grup Ad�" });
			headers.put("PROMOSYON_KODU", new String[] { "Promosyon Kodu" });
			headers.put("ADET", new String[] { "Adet" });
			headers.put("OLUSTURULAN_TARIH", new String[] { "Olu�turulan Tarih" });
			headers.put("SON_KULLANIM_TARIHI", new String[] { "Son Kullan�m Tarihi" });
			headers.put("GECERLI_TAKIMLAR", new String[] { "Ge�erli Tak�mlar" });
			headers.put("DURUM", new String[] { "Durum" });
			headers.put("IPTAL_TARIHI", new String[] { "�ptal Tarihi" });

			oMap.put("HEADERS", headers);
			oMap.put("FILE_NAME", fileName);
			oMap.put("CHANGE_PAGE_DIRECTION", false);

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.flush();

			String func = "{? = call PKG_TRN3812.Promosyon_Kodu_Listesi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("GRUP_ID") };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TABLE_DATA", inputValues));

			oMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", oMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
