package tr.com.aktifbank.bnspr.creditcard.services;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.PpBlokeKoy;
import tr.com.aktifbank.bnspr.dao.PpBlokeKoyTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CreditCardTRN4478Services implements OceanMapKeys{
	
	@GraymoundService("BNSPR_TRN4478_GET_CARD_LIST")
	public static GMMap getCardList (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap cMap = new GMMap();
			GMMap lMap = new GMMap();
			
			cMap.put(CUSTOMER_NO, iMap.getBigDecimal("MUST_NO"));
			cMap.put("PROCEED", "INCLUDE");
			String cardNo =StringUtil.isEmpty(iMap.getString("CARD_NO"))?"":iMap.getString("CARD_NO");
			lMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", cMap);
			int j=0;
			int s = lMap.getSize("CARD_DETAIL_INFO"); 
			for (int i = 0; i < s; i++) {
				String dci = lMap.getString("CARD_DETAIL_INFO",i,"CARD_DCI");
				String statCode = lMap.getString("CARD_DETAIL_INFO",i,"CARD_STAT_CODE");
				String subStatCode = lMap.getString("CARD_DETAIL_INFO",i,"CARD_SUB_STAT_CODE");
				
				if (dci.equals("P")){
				oMap.put("TABLO",j, "CARD_NO",lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"));
				oMap.put("TABLO",j, "CUSTOMER_NO",lMap.getBigDecimal("CARD_DETAIL_INFO",i,"CUSTOMER_NO"));
				oMap.put("TABLO",j, "CARD_DCI",dci);
				oMap.put("TABLO",j, "CARD_STAT_DESC",lMap.getString("CARD_DETAIL_INFO",i,"CARD_STAT_DESC"));
				oMap.put("TABLO",j, "CARD_EMBOSS_NAME",lMap.getString("CARD_DETAIL_INFO",i,"EMBOSS_NAME"));
				oMap.put("TABLO", j,"CARD_AVAIL_LIMIT", lMap.getString("CARD_DETAIL_INFO",i,"CARD_AVAIL_LIMIT"));
				j=j+1;
				}
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4478_SAVE")
	public static GMMap save(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			BigDecimal kartBakiye = iMap.getBigDecimal("KART_BAKIYE");
			BigDecimal blokeliBakiye = iMap.getBigDecimal("BLOKELI_BAKIYE");
			BigDecimal	tutar = iMap.getBigDecimal("TUTAR");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String date = sdf.format(new Date());
			BigDecimal today = new BigDecimal(date);
			
			
			
			/*if(iMap.getBoolean("F_KOY")){
				BigDecimal fark = kartBakiye.subtract(blokeliBakiye);
				if(tutar.compareTo(fark)>0){
					throw new GMRuntimeException(4448011, "Kart�n bakiyesi bloke i�in m�sait de�il");
				}
			}*/
			if(iMap.getBoolean("F_COZ")){
				if(StringUtil.isEmpty(iMap.getString("BLOKE_REFERANS"))){
					throw new GMRuntimeException(4448011, "Bloke referans�n� girmelisinizl");
				}
			}
			PpBlokeKoyTx ppBlokeKoyTx =new PpBlokeKoyTx();
			
			ppBlokeKoyTx.setAciklama(iMap.getString("ACIKLAMA"));
			ppBlokeKoyTx.setAliciAdSoyad(iMap.getString("ALICI_AD_SOYAD"));
			ppBlokeKoyTx.setBakiye(iMap.getBigDecimal("BAKIYE"));
			ppBlokeKoyTx.setBankaAciklama(iMap.getString("BANKA_ACIKLAMA"));
			ppBlokeKoyTx.setBlokeNedenKodu(iMap.getString("BLOKE_NEDEN_KODU"));
			ppBlokeKoyTx.setDurum("A");
			ppBlokeKoyTx.setKartNo(iMap.getString("KART_NO"));
			ppBlokeKoyTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			ppBlokeKoyTx.setTutar(iMap.getBigDecimal("TUTAR"));
			ppBlokeKoyTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			if(iMap.getBoolean("F_HESABA"))
				ppBlokeKoyTx.setAlacakliHesap(getGlobalParam("PP_BLOKE_COZME_HESAP"));
			GMMap cProperty = new GMMap();
			cProperty.put("CARD_NO", iMap.getString("KART_NO"));
			cProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cProperty);
			String destination = cProperty.getString("DESTINATION");
			ppBlokeKoyTx.setBlokeCoz(iMap.getBoolean("F_COZ")?"E":"H");
			ppBlokeKoyTx.setBlokeKoy(iMap.getBoolean("F_KOY")?"E":"H");
			ppBlokeKoyTx.setBorcluHesap(iMap.getString("HESAP_NO"));
			ppBlokeKoyTx.setBorcluHesapSube(destination.equals("I")?"997":"998");
			ppBlokeKoyTx.setHesaba(iMap.getBoolean("F_HESABA")?"E":"H");
			ppBlokeKoyTx.setCozulenRefNo(iMap.getString("BLOKE_REFERANS"));
			
			if(iMap.getBoolean("F_COZ")){
				ppBlokeKoyTx.setBlokeCozmeTarihi(today);
			}else{
				ppBlokeKoyTx.setBlokeKoymaTarihi(today);
			}
			
		session.saveOrUpdate(ppBlokeKoyTx);	
		session.flush();
		iMap.put("TRX_NAME" , "4478");
		oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4478_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			PpBlokeKoyTx ppBlokeKoyTx = (PpBlokeKoyTx) session.createCriteria(PpBlokeKoyTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO") )).uniqueResult();
			oMap.put("ACIKLAMA", ppBlokeKoyTx.getAciklama());
			oMap.put("KART_NO", ppBlokeKoyTx.getKartNo());
			oMap.put("MUSTERI_NO", ppBlokeKoyTx.getMusteriNo());
			oMap.put("TUTAR", ppBlokeKoyTx.getTutar());
			oMap.put("HESAP_NO", ppBlokeKoyTx.getBorcluHesap());
			oMap.put("BANKA_ACIKLAMA", ppBlokeKoyTx.getBankaAciklama());
			oMap.put("ALICI_AD_SOYAD", ppBlokeKoyTx.getAliciAdSoyad());
			oMap.put("BAKIYE", ppBlokeKoyTx.getBakiye());
			oMap.put("BLOKE_NEDEN_KODU", ppBlokeKoyTx.getBlokeNedenKodu());
			oMap.put("F_COZ",ppBlokeKoyTx.getBlokeCoz().equals("E")?true:false);
			oMap.put("F_KOY",ppBlokeKoyTx.getBlokeKoy().equals("E")?true:false);
			oMap.put("F_HESABA",ppBlokeKoyTx.getHesaba().equals("E")?true:false);
			oMap.put("BLOKE_REFERANS", ppBlokeKoyTx.getCozulenRefNo());
						
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4478_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap bMap= new GMMap();
		try {
			PpBlokeKoyTx ppBlokeKoyTx = (PpBlokeKoyTx) session.createCriteria(PpBlokeKoyTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("ISLEM_NO") )).uniqueResult();
			bMap.put("CUSTOMER_NO", ppBlokeKoyTx.getMusteriNo());
			bMap.put("CARD_NO", ppBlokeKoyTx.getKartNo());
			bMap.put("BLOCKED_AMOUNT", ppBlokeKoyTx.getTutar());
			bMap.put("BLOCKED_TYPE", "R");
			GMMap bakMap = new GMMap();
			bakMap = GMServiceExecuter.call("BNSPR_PP_CARD_BLOCKED_OPERATIONS", bMap);
			BigDecimal kartBakiye = bakMap.getBigDecimal("AVAILABLE_AMOUNT");
			BigDecimal blokeliBakiye = bakMap.getBigDecimal("BLOCKED_AMOUNT");
			BigDecimal fark = kartBakiye.subtract(blokeliBakiye);
					
			if(ppBlokeKoyTx.getBlokeKoy().equals("E")){
				/*if (ppBlokeKoyTx.getTutar().compareTo(fark)>0){
					throw new GMRuntimeException(4448011, "Kart�n bakiyesi bloke i�in m�sait de�il");
				}*/
				bMap.put("BLOCKED_TYPE", "Y");
			}else{
				bMap.put("BLOCKED_TYPE", "N");
			}
			
			GMServiceExecuter.call("BNSPR_PP_CARD_BLOCKED_OPERATIONS", bMap);
			if(ppBlokeKoyTx.getHesaba().equals("E")){
				String kartNo = ppBlokeKoyTx.getKartNo();
				
				GMMap cardMap = new GMMap();
				GMMap cardRespMap = new GMMap();
				
				cardMap.put(BSMV_RATE, BigDecimal.ZERO);
				cardMap.put(KKF_RATE, BigDecimal.ZERO);
				
				cardMap.put(TXN_AMOUNT, ppBlokeKoyTx.getTutar());
				cardMap.put(CARD_NO, kartNo);
				cardMap.put(TXN_DESC, "E Haciz Bakiye Aktar�m�");
				cardMap.put(TXN_CURR_CODE, "TRY");
				cardMap.put(TXN_TYPE, getGlobalParam("4478_FINANSAL_BAKIM").replace("?", "~"));
				cardMap.put(TXN_STATE, "N");

				SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
				cardMap.put(TXN_DATE, format.format(new Date()));
				
				cardRespMap=GMServiceExecuter.call("BNSPR_GENERAL_FINANCIAL_ADJUSTMENT", cardMap);
				
				if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
					throw new GMRuntimeException(4448011, "Kart Transfer Hata : "+ cardRespMap.getString(RETURN_DESCRIPTION));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4478_BLOKE_SORGULA")
	public static GMMap blokeSorgula(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			iMap.put("BLOCKED_TYPE", "R");
			oMap = GMServiceExecuter.call("BNSPR_PP_CARD_BLOCKED_OPERATIONS", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	
	public static String getGlobalParam(String batchParamCode) {
        GMMap iMapG = new GMMap();
        iMapG.put("KOD" , batchParamCode);
        iMapG.put("TRIM_QUOTES" , true);
        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
        return batchNo;
    }
	
	@GraymoundService("BNSPR_TRN4478_GET_BLOKE")
	public static GMMap ppBlokeKoy(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try{
			PpBlokeKoy ppBlokeKoy = (PpBlokeKoy)session.createCriteria(PpBlokeKoy.class).add(Restrictions.eq("blokeReferans", iMap.getString("BLOKE_REFERANS"))).uniqueResult();
			if(ppBlokeKoy !=null){
				oMap.put("TUTAR",ppBlokeKoy.getTutar());
				oMap.put("ACIKLAMA", ppBlokeKoy.getAciklama());
				oMap.put("BLOKE_NEDEN_KODU", ppBlokeKoy.getBlokeNedenKodu());
				oMap.put(RETURN_CODE, "2");
				oMap.put(RESPONSE_DATA, "BASARILI");
			}
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		
		return oMap;
	}
	
    
    private static void ValidateRequest(GMMap iMap) {
        
        if (StringUtils.isNotBlank(iMap.getString("KART_NO")) && StringUtils.isNotBlank(iMap.getString("REC_DATE"))
        		&& StringUtils.isNotBlank(iMap.getString("BLOKE_REFERANS"))
        		&& StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))){
        	
        	throw new GMRuntimeException(447801, "En az bir sorgu kriteri giriniz.");
        }
    }
    
//    public static void main(String[] args) throws ParseException {
//    	SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
//		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
//	String date = sdf.format(new Date());
//	 String	tarih = sdf1.format(sdf.parse(date));
//	 BigDecimal bd=BigDecimal.valueOf(Long.valueOf(tarih));
//
//		 System.out.println(bd)	;
//		 }
}
