package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY3873Services {
	
	/**
	 * Girilen kriterlere g�re arama yap�p, ba�vuru listesi d�ner.
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO, KREDI_KART_TIPI, ADI, IKINCI_ADI,
	 *             SOYADI, DURUM_LIST, BASLANGIC_TAR, BITIS_TAR, IPTAL,KANAL_KODU, BAYI_KODU   
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_QRY3873_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruIzlemeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3873.RC_QRY3873_BASVURU_IZLEME_LIST(?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("KREDI_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," : 
                CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));
			
			if (iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getBoolean("IPTAL") == true)
				stmt.setString(i++, "TRUE");
			else
				stmt.setString(i++, "FALSE");
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("BAYI_KODU"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3873_KK_BASVURU_KANAL_DURUM")
	public static GMMap getKanalBasvuruDurum(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3873.RC_QRY3873_BASVURU_IZLEME(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("BAYI_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CEP_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			if (!rSet.isBeforeFirst()) {
				iMap.put("HATA_NO", new BigDecimal(2747));
				// iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap()).get("TEXT"));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI_LIST");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	/**
	 * Ba�vuru izleme ekran� a��l�rken, ba�lang��ta dolmas� gereken alanlar� d�ner.
	 * 
	 * @param iMap
	 *          
	 * @return oMap - DURUM, KART_TIPI_LIST, KANAL_LIST
	 */
	@GraymoundService("BNSPR_QRY3873_FILL_INITIAL_VALUES")
	public static GMMap fillInitialValues(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			// Durum
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM", "KK_BASVURU_DURUM_KOD", "HEPSI"));
			// Kart tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			// Kanal Listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3872_KANAL_LIST", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));

		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);

		}

		return oMap;

	}
	
	/**
	 * Java sistem tarihini ve bir ay sonras�n� ba�lang�� ve biti� tarihleri olarak d�ner.
	 * 
	 * @param iMap
	 *          
	 * @return oMap - BASLANGIC_TARIHI, BITIS_TARIHI
	 */
	@GraymoundService("BNSPR_QRY3873_GET_START_FINISH_DATES")
	public static GMMap getStartFinishDates(GMMap iMap) {
	
		Date toDay;
		Date minusOneMonth;
		GMMap oMap = new GMMap();
		try {
			Calendar c = Calendar.getInstance(); 
			c.setTime(new Date()); 
			toDay=c.getTime();
			c.add(Calendar.MONTH, -1);
			minusOneMonth= c.getTime();
			oMap.put("BASLANGIC_TARIHI", minusOneMonth);
			oMap.put("BITIS_TARIHI", toDay);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
    
	
	/**
	 * Girilen ba�vuru numaras� i�in daha �nce yap�lm�� i�lemleri getirir.
	 * 
	 * @param iMap -BASVURU_NO 
	 *          
	 * @return oMap - RESULTS
	 */
	@GraymoundService("BNSPR_KK_GET_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KK_BASVURU.get_tarihce(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	//--------------------------------------------------------INSERTTARIHCE
	/** Verilen parametrelerle basvuruya ait tarihce kaydi olusturur.
	 * 
	 * @param iMap - BASVURU_NO, ISLEM_NO, DURUM_KOD
	 * @author murat.el
	 */
	@GraymoundService("BNSPR_KK_TARIHCE_KAYDET")
	public static GMMap insertTarihce(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			query = "{ call PKG_KK_BASVURU.insert_tarihce (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
			stmt = conn.prepareCall(query);
			
			int i = 1;
			stmt.setString(i++, iMap.getString("ISLEM_KODU"));
			stmt.setString(i++, iMap.getString("SISTEM_SORGU_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("ISLEM_SONRASI_DURUM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("GORUS"));
			stmt.setString(i++, iMap.getString("AKSIYON_KODU"));
			stmt.setString(i++, iMap.getString("AKSIYON_KARAR_KODU"));
			stmt.setString(i++, iMap.getString("AKSIYON_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("AKSIYON_KARAR_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("SISTEM_AKSIYON_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("SISTEM_AKSIYON_KARAR_ACIKLAMA"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ONAY_LIMIT"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ONAY_NAKIT_LIMIT"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ONAY_EKSPRES_LIMIT"));
			stmt.setDate(i++, iMap.getDate("BAS_TARIHI")==null?null:new java.sql.Date(iMap.getDate("BAS_TARIHI").getTime()));
			stmt.setString(i++, iMap.getString("YENI_KAYIT_MI"));
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	//--
	@GraymoundService("BNSPR_KK_TARIHCE_GUNCELLE")
	public static GMMap updateTarihceIslemSonrasiDurumKodu(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call pkg_kk_basvuru.update_tarihce_sonraki_durum(?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("ISLEM_SONRASI_DURUM_KODU"));
			stmt.setString(i++, iMap.getString("YENI_DURUM_KODU"));
			stmt.setString(i++, iMap.getString("GORUS"));
			stmt.execute();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
}
