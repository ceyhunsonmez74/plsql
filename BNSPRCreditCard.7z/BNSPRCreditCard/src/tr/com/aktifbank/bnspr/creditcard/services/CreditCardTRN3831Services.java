package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.dao.TffSmsBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/** SMS ile TFF basvurusu alma islemi
 * @author murat.el
 * @since PYTFFKBS-650
 */
public class CreditCardTRN3831Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>Tff basvuru giris ekrani ilk degerleri
	 *         <li>KART_TIPI_LIST - Tff sms basvuruda alinacak kart tipleri
	 *         <li>HESAP_KESIM_LIST - Hesap kesim tarihleri
	 *         <li>KREDI_KART_OTOMATIK_ODEME - Otomatik odeme talimati secenekleri
	 *         <li>AKSIYON_KOD - Islem sonucunda alinabilecek aksiyonlar
	 */
	@GraymoundService("BNSPR_TRN3831_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//3801 ekran acilisindaki parametreleri al
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_INITIALIZE", iMap));
			//Kart tipi listesini al- KART_TIPI_LIST
			oMap.putAll(CreditCardServicesUtil.getParameterListByKey("KART_TIPI_LIST", "TFF_KART_TIPI", null, null, "SMS", null));
			//Hesap kesim tarihi - HESAP_KESIM_LIST
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_HESAP_KESIM_TARIHI_LIST", iMap));
			//Otomatik Odeme Talimati - KREDI_KART_OTOMATIK_ODEME
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_KART_OTOMATIK_ODEME_TIP", iMap));
			//Aksiyon Kod - AKSIYON_KOD
			oMap.putAll(CreditCardServicesUtil.getParameterList("AKSIYON_KOD", "TFF_SMS_BASVURU_AKSIYON_KOD", CreditCardServicesUtil.EVET));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 *        <li>ODEME_TIPI - Tff basvuru ucreti odeme sekli
	 *        <li>AKSIYON_KOD - Islem sonucu
	 *        <li>ACIKLAMA - Islem aciklamasi
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3831_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffSmsBasvuruTx tffSmsBasvuruTx = (TffSmsBasvuruTx) session.get(TffSmsBasvuruTx.class, trxNo);
			if (tffSmsBasvuruTx == null) {
				tffSmsBasvuruTx = new TffSmsBasvuruTx();
				tffSmsBasvuruTx.setTxNo(trxNo);
			}
			//Islem bilgilerini al.
			tffSmsBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tffSmsBasvuruTx.setOdemeTipi(iMap.getString("ODEME_TIPI"));
			tffSmsBasvuruTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			tffSmsBasvuruTx.setAciklama(CreditCardServicesUtil.trimNewLine(iMap.getString("ACIKLAMA")));
			
			//Islem bilgilerini kaydet
			session.save(tffSmsBasvuruTx);
			session.flush();
			
			//Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", "3831");
			islemMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("KK_BASVURU_TAMAMLAMA_GORUNTULEME_JUST_FOR_LOG")
    public static GMMap kkBilgiTamamlamaLog(GMMap iMap) {
	return new GMMap();
    }
	
	@GraymoundService("KK_BASVURU_TAMAMLAMA_TRANSFER_IVR_JUST_FOR_LOG")
    public static GMMap kkBilgiTransferIVRLog(GMMap iMap) {
	return new GMMap();
    }
	
	
	@GraymoundService("KK_BASVURU_TAMAMLAMA_IVR_DONUS_JUST_FOR_LOG")
    public static GMMap kkBilgiTransferIVRDonusLog(GMMap iMap) {
	return new GMMap();
    }
	
	
	@GraymoundService("KK_BASVURU_TAMAMLAMA_SAVE_JUST_FOR_LOG")
    public static GMMap kkBilgiTransferSaveLog(GMMap iMap) {
	return new GMMap();
    }
	
	
	/** Verilen islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - TRX_NO : Islem numarasi
	 * @return oMap - Tff sms basvuru bilgileri<br>
	 */
	@GraymoundService("BNSPR_TRN3831_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffSmsBasvuruTx tffSmsBasvuruTx = (TffSmsBasvuruTx) session.get(TffSmsBasvuruTx.class, trxNo);
			if (tffSmsBasvuruTx != null) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", tffSmsBasvuruTx.getBasvuruNo());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3831_GET_BASVURU_BILGI", sorguMap));
				oMap.put("TX_NO", tffSmsBasvuruTx.getTxNo());
				oMap.put("AKSIYON_KOD", tffSmsBasvuruTx.getAksiyonKod());
				oMap.put("ACIKLAMA", tffSmsBasvuruTx.getAciklama());
				oMap.put("ODEME_TIPI", tffSmsBasvuruTx.getOdemeTipi());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Yapilan islem sonucunda musteri islemden vazgecmisse, 
	 * basvuru olusmussa/odeme alinmissa islemler iptal edilir.<br>
	 * @author murat.el
	 * @since PY-9513, TY-4404
	 * @param iMap - ISLEM_NO : Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3831_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffSmsBasvuruTx tffSmsBasvuruTx = (TffSmsBasvuruTx) session.get(TffSmsBasvuruTx.class, trxNo);
			if (tffSmsBasvuruTx == null) {
				return oMap;
			}
			//Musteri islemden vazgecti ya da eksik bilgi nedeniyle islem tamamlanamadi ise
			if ("I".equals(tffSmsBasvuruTx.getAksiyonKod()) ||
					"E".equals(tffSmsBasvuruTx.getAksiyonKod())) {
				//Basvuru yoksa islem gerek yok.
				if (tffSmsBasvuruTx.getBasvuruNo() == null) {
					return oMap;
				}
				//Basvuru varsa iptal et.
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffSmsBasvuruTx.getBasvuruNo());
				if (tffBasvuru != null) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
					sorguMap.put("ISLEM_KOD", "3831");
					sorguMap.put("GEREKCE_KOD", "2");
					sorguMap.put("ACIKLAMA", tffSmsBasvuruTx.getAciklama());
					sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.EVET);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** YVerilen data ile tff basvurusu olusturur.<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Tff sms basvuru bilgileri
	 * @return oMap - Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu(0:Islem Basarisiz|2:Islem Basarili)
	 *         <li>BASVURU_NO - Olusturulan basvuru numarasi
	 *         <li>TESLIMAT_ADRESI_NO - Teslimat adresi numarasi
	 */
	@GraymoundService("BNSPR_TRN3831_BASVURU_OLUSTUR")
	public static GMMap basvuruOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Basvuru olustur
			sorguMap.putAll(iMap);
			sorguMap.put("SERVICE_NAME", "BNSPR_TFF_SMS_BASVURU_YAP");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_SCREEN_WRAPPER_NT", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				throw new GMRuntimeException(0, sorguMap.getString("HATA_MESAJI"));
			}

			String teslimatAdresi = iMap.getString("TESLIMAT_ADRESI");
			String teslimatAdresNo = StringUtils.EMPTY;
			if ("E".equals(teslimatAdresi)) {
				teslimatAdresNo = sorguMap.getString("EV_ADRES_NO");
			} else if ("I".equals(teslimatAdresi)) {
				teslimatAdresNo = sorguMap.getString("IS_ADRES_NO");
			} else if ("D".equals(teslimatAdresi)) {
				teslimatAdresNo = sorguMap.getString("DIGER_ADRES_NO");
			} else if ("GN".equals(teslimatAdresi) || "TN".equals(teslimatAdresi)) {
				teslimatAdresNo = sorguMap.getString("NOKTA_ADRES_NO");
			} 
			
			oMap.put("BASVURU_NO", sorguMap.get("TFF_BASVURU_NO"));
			oMap.put("TESLIMAT_ADRESI_NO", teslimatAdresNo);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	/** Verilen kurye tipi ve urune gore basvuru ucretini hesaplar.<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Ucret kriterleri.
	 *         <li>KURYE_TIPI - Kart teslimat tipi
	 *         <li>URUN_ID - Urun id
	 * @return oMap - Ucretler<br>
	 *         <li>KURYE_BEDELI - Kurye ucreti
	 *         <li>KART_BEDELI - Kart ucreti
	 *         <li>LOYALTY_BEDELI - Loyalty ucreti
	 *         <li>VIZE_BEDELI - Vize ucreti
	 *         <li>TOPLAM_BEDEL - Toplam ucret
	 */
	@GraymoundService("BNSPR_TRN3831_UCRET_HESAPLA")
	public static GMMap ucretHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Kurye ucreti
			BigDecimal kuryeBedeli = BigDecimal.ZERO;
			if (StringUtils.isNotBlank(iMap.getString("KURYE_TIPI"))) {
				sorguMap.put("KOD", "TFF_KART_TESLIMAT_UCRETLERI");
				sorguMap.put("KEY1", iMap.get("KURYE_TIPI"));
				kuryeBedeli = CreditCardServicesUtil.getParamSayi(sorguMap).getBigDecimal("SAYI");
			}
			oMap.put("KURYE_BEDELI", kuryeBedeli);
			
			//Urun ucretleri
			BigDecimal kartBedeli = BigDecimal.ZERO;
			BigDecimal loyaltyBedeli = BigDecimal.ZERO;
			BigDecimal vizeBedeli = BigDecimal.ZERO;
			if (StringUtils.isNotBlank(iMap.getString("URUN_ID"))) {
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				TffSsProductMap tffSsProductMap = (TffSsProductMap)
						session.createCriteria(TffSsProductMap.class)
						.add(Restrictions.eq("urunId", iMap.getString("URUN_ID")))
						.uniqueResult();
				if (tffSsProductMap != null) {
					kartBedeli = CreditCardServicesUtil.nvl(tffSsProductMap.getKartBedeli(), BigDecimal.ZERO);
					loyaltyBedeli = CreditCardServicesUtil.nvl(tffSsProductMap.getLoyaltyBedeli(), BigDecimal.ZERO);
					vizeBedeli = CreditCardServicesUtil.nvl(tffSsProductMap.getVizeBedeli(), BigDecimal.ZERO);
				}
			}
			oMap.put("KART_BEDELI", kartBedeli);
			oMap.put("LOYALTY_BEDELI", loyaltyBedeli);
			oMap.put("VIZE_BEDELI", vizeBedeli);
			oMap.put("TOPLAM_BEDEL", kuryeBedeli.add(kartBedeli).add(loyaltyBedeli).add(vizeBedeli));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen basvuru numarasina ait sms basvuru bilgilerini listeler.<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Sorgu kriteri<br>
	 *         <li>BASVURU_NO - Tff Basvuru numarasi
	 * @return oMap - Basvuru bilgileri<br>
	 *         <li>Tff sms basvuru bilgileri
	 *         <li>OTOMATIK_LIMIT_ARTIS - KK otomatik limit artis
	 *         <li>EKSTRE_TIPI_SMS_MI - KK ekstre tipi sms mi(true|false)
	 *         <li>HESAP_KESIM_TARIHI - KK hesap kesim tarihi
	 *         <li>OTO_ODEME_TALIMATI - KK otomatik odeme talimat tipi
	 */
	@GraymoundService("BNSPR_TRN3831_GET_BASVURU_BILGI")
	public static GMMap getBasvuruBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_BASVURU_BILGI", iMap));
			//Kredi karti ile ilgili alanlari al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffKrediKartiBasvuru tffKrediKartiBasvuru = (TffKrediKartiBasvuru)
					session.get(TffKrediKartiBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffKrediKartiBasvuru != null) {
				oMap.put("OTOMATIK_LIMIT_ARTIS", BooleanUtils.toBoolean(
						CreditCardServicesUtil.nvl(tffKrediKartiBasvuru.getOtomatikLimitArtimi(), CreditCardServicesUtil.HAYIR),
						CreditCardServicesUtil.EVET,
						CreditCardServicesUtil.HAYIR));
				oMap.put("EKSTRE_TIPI_SMS_MI", BooleanUtils.toBoolean(
						CreditCardServicesUtil.nvl(tffKrediKartiBasvuru.getEkstreTipiSms(), CreditCardServicesUtil.HAYIR),
						CreditCardServicesUtil.EVET,
						CreditCardServicesUtil.HAYIR));
				oMap.put("HESAP_KESIM_TARIHI", tffKrediKartiBasvuru.getHesapKesimTarihi());
				oMap.put("OTO_ODEME_TALIMATI", tffKrediKartiBasvuru.getKartOtomatikOdeme());
			} else {
				oMap.put("OTOMATIK_LIMIT_ARTIS", 0);
				oMap.put("EKSTRE_TIPI_SMS_MI", 0);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen tcknye ait odemesi yapilmamis sms basvurusu var mi kontrolu yapar.<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Sorgu kriteri<br>
	 *         <li>TC_KIMLIK_NO - Tc kimlik numarasi
	 * @return oMap - sorgu sonucu<br>
	 *         <li>SMS_BASVURU_VAR_MI - Yarim sms basvurusu var mi(E:Evet|H:Hayir)
	 *         <li>BASVURU_NO - Yarim basvuruya ait basvuru numarasi
	 */
	@GraymoundService("BNSPR_TRN3831_SMS_BASVURU_VAR_MI")
	public static GMMap smsYarimBasvuruVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("SMS_BASVURU_VAR_MI", CreditCardServicesUtil.HAYIR);

		try {
			String[] durumKodList = { "FOTO_EKSIK", "ODEME_BEKLE" };
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			List<?> tffBasvuruList = session.createCriteria(TffBasvuru.class)
					.add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO")))
					.add(Restrictions.eq("source", "SMS"))
					.add(Restrictions.in("durumKod", durumKodList))
					.list();
			if (tffBasvuruList == null || tffBasvuruList.isEmpty() || tffBasvuruList.size() > 1) {
				return oMap;
			}
			//Basvuru varsa al
			TffBasvuru tffBasvuru = (TffBasvuru) tffBasvuruList.get(0);
			//Odeme yapildi mi, yapilmadi ise yarim basvuru olarak al ve guncelle.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ODEME_YAPILDI_MI", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("ODEME_YAPILDIMI"))) {
				oMap.put("SMS_BASVURU_VAR_MI", CreditCardServicesUtil.EVET);
				oMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			}			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen tcknye ait yapilmis aps sorgusu yoksa aps sorgusu yapar, varsa sorgu yapilmaz. 
	 * Aps bilgilerini listeler<br>
	 * @author murat.el
	 * @since PY-9513
	 * @param iMap - Sorgu kriteri<br>
	 *         <li>TC_KIMLIK_NO - Tc kimlik numarasi
	 *         <li>TRX_NO - Islem numarasi
	 *         <li>APS_YAPILDI_MI - APS sorgusu yapildi mi(E:Evet|H:Hayir)
	 * @return oMap - sorgu sonucu<br>
	 *         <li>APS_YAPILDI_MI - APS sorgusu yapildi mi(E:Evet|H:Hayir)
	 *         <li>IL_KODU - APS il kodu
	 *         <li>ILCE_KODU - APS ilce kodu
	 *         <li>ACIK_ADRES - APS acik adres
	 */
	@GraymoundService("BNSPR_TRN3831_GET_APS_INFO")
	public static GMMap getApsBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//APS bilgisi al
			if (CreditCardServicesUtil.HAYIR.equals(iMap.getString("APS_YAPILDI_MI", CreditCardServicesUtil.HAYIR))) {
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", sorguMap));
				oMap.put("APS_YAPILDI_MI", sorguMap.get("APS_YAPILDIMI"));
			} else {
				oMap.put("APS_YAPILDI_MI", CreditCardServicesUtil.EVET);
				sorguMap.clear();
				sorguMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
				sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
				BigDecimal musteriNo = sorguMap.getBigDecimal("CUSTOMER_NO");
				sorguMap.clear();
				if (musteriNo != null && BigDecimal.ZERO.compareTo(musteriNo) < 0) {
					sorguMap.put("MUSTERI_NO", musteriNo);
				} 
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_APS_INFO_BY_MUSTERI_NO", sorguMap));
			}
			//APS bilgileri basari ile alindi ise alinan APS bilgisini ekran formatina cevir
			oMap.putAll(getApsAcikAdres(sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static GMMap getApsAcikAdres(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder adres = new StringBuilder();
		String ayrac = " ";
		
	    if(!"0".equals(iMap.getString("ADRES_NO")) && iMap.getString("YABANCI_ULKE_KOD") == null) {
	    	//Acik adres
	    	if (StringUtils.isNotBlank(iMap.getString("BUCAK"))) {
	    		adres.append(iMap.getString("BUCAK")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("KOY"))) {
	    		adres.append(iMap.getString("KOY")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("MAHALLE"))) {
	    		adres.append(iMap.getString("MAHALLE")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("CSBM"))) {
	    		adres.append(iMap.getString("CSBM")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("DIS_KAPI_NO"))) {
	    		adres.append("NO:").append(iMap.getString("DIS_KAPI_NO")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("IC_KAPI_NO"))) {
	    		adres.append("DAIRE:").append(iMap.getString("IC_KAPI_NO"));
	    	}
	    	oMap.put("ACIK_ADRES", adres.toString().trim());
	    	//il kodu
	    	String ilKodu = iMap.getString("IL_KODU");
	    	if (StringUtils.isNotBlank(ilKodu)) {
	    		ilKodu = StringUtils.leftPad(ilKodu, 3, "0");
	    	}
	    	oMap.put("IL_KODU", ilKodu);
	    	//Ilce Kodu
	    	oMap.put("ILCE_KODU", iMap.getBigDecimal("ILCE_KODU"));
	    }
	    
	    return oMap;
	}

}
