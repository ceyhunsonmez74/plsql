package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffSsProductMapTx;
import tr.com.aktifbank.bnspr.dao.TffSsProductMapTxId;
import tr.com.aktifbank.bnspr.dao.TffUrunKanalMapTx;
import tr.com.aktifbank.bnspr.dao.TffUrunKanalMapTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3894Services {

	@GraymoundService("BNSPR_3894_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//PAKET
			GuimlUtil.wrapMyCombo(oMap, "PAKET", "INTRA", "INTRA");
			GuimlUtil.wrapMyCombo(oMap, "PAKET", "OCEAN", "OCEAN");
			
			//KART_TIPI
			iMap.put("KOD", "TFF_KART_TIPI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KART_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			//UNDER_18
			oMap.putAll(CreditCardServicesUtil.getParameterList("UNDER_18", "EVET_HAYIR", "E"));
			
			//GECERLI
			oMap.putAll(CreditCardServicesUtil.getParameterList("GECERLI", "EVET_HAYIR", "E"));
			
			//URUN_SAHIP_KOD
			String query = "SELECT kod, adi FROM BNSPR.urun_sahip ORDER BY adi";
			DALUtil.fillComboBox(oMap, "URUN_SAHIP_KOD", true, query);
			
			//MARKA			
			GuimlUtil.wrapMyCombo(oMap, "MARKA", "Maestro", "Maestro");
			GuimlUtil.wrapMyCombo(oMap, "MARKA", "MasterCard", "MasterCard");
			GuimlUtil.wrapMyCombo(oMap, "MARKA", "Visa", "Visa");
			
			//BASVURU_URUN_KODU
			iMap.put("KOD", "TFF_BASVURU_URUN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BASVURU_URUN_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));				
			
			//SOURCE
			query = "select key1 kod , text adi from bnspr.v_ml_gnl_param_text t where t.kod='TFF_WEBSERVIS_PARAM' and t.key2='KANAL_KOD'";
			DALUtil.fillComboBox(oMap, "SOURCE", true, query);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3894_GET_LIST")
	public static GMMap getTffSSProductMap(GMMap iMap){
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		String tableName = "SS_PRODUCT_MAP";
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3894.get_tff_ss_product_map}");
			
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			
			int row = 0;
			while (rSet.next()) {
				int i = 1;
				
				BigDecimal urunId = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "ID", urunId);
				oMap.put(tableName, row, "PAKET", rSet.getString(i++));
				oMap.put(tableName, row, "KART_TIPI", rSet.getString(i++));
				oMap.put(tableName, row, "BASVURU_URUN_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "URUN_ID", rSet.getString(i++));
				oMap.put(tableName, row, "URUN_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "LOGO_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "LOGO_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "FINANSAL_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "FINANSAL_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "KLUP_ID", rSet.getString(i++));
				oMap.put(tableName, row, "URUN_SAHIP_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "UNDER_18", rSet.getString(i++));
				oMap.put(tableName, row, "KART_BEDELI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "VIZE_BEDELI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "LOYALTY_BEDELI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "GECERLI", rSet.getString(i++));
				oMap.put(tableName, row, "MARKA", rSet.getString(i++));
				oMap.put(tableName, row, "MAX_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MIN_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "BASVURU_URUN_KODU", rSet.getString(i++));

				stmt2 = conn.prepareCall("{? = call PKG_TRN3894.get_tff_urun_kanal_map(?) }");
				
				stmt2.registerOutParameter(1, -10);
				stmt2.setBigDecimal(2, urunId);
				stmt2.execute();
				stmt2.getMoreResults();
				
				rSet2 = (ResultSet) stmt2.getObject(1);
				ArrayList<HashMap<String, Object>> kanalList = new ArrayList<HashMap<String, Object>>();
				
				while (rSet2.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("SOURCE", rSet2.getString(y++));
					rowData.put("GECERLI", rSet2.getString(y++));

					kanalList.add(rowData);
				}
				oMap.put(tableName, row, "URUN_KANAL_LIST", kanalList);
				
				GMServerDatasource.close(rSet2);
				GMServerDatasource.close(stmt2);
				
				row++;
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3894_GET_URUN_KANAL_LIST")
	public static GMMap getUrunKanalList(GMMap iMap){
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt2 = null;
		ResultSet rSet2 = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt2 = conn.prepareCall("{? = call PKG_TRN3894.get_tff_urun_kanal_map(?) }");
			
			stmt2.registerOutParameter(1, -10);
			stmt2.setBigDecimal(2, null);
			stmt2.execute();
			stmt2.getMoreResults();
			rSet2 = (ResultSet) stmt2.getObject(1);
			
			oMap.putAll(DALUtil.rSetResults(rSet2, "URUN_KANAL_LIST"));
		}
		catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		finally {
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3894_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "SS_PRODUCT_MAP";
			List<?> list = (List<?>)iMap.get("SS_PRODUCT_MAP");
			
			for (int i = 0; i < list.size(); i++) {
				TffSsProductMapTx tffSsProductMapTx = new TffSsProductMapTx();
				TffSsProductMapTxId tffSsProductMapTxId = new TffSsProductMapTxId();
				tffSsProductMapTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				tffSsProductMapTxId.setId(iMap.getBigDecimal(tableName, i,"ID"));
				tffSsProductMapTx.setId(tffSsProductMapTxId);
				tffSsProductMapTx.setBasvuruUrunAdi(iMap.getString(tableName, i,"BASVURU_URUN_ADI"));
				tffSsProductMapTx.setBasvuruUrunKodu(iMap.getString(tableName, i,"BASVURU_URUN_KODU"));
				tffSsProductMapTx.setFinansalKod(iMap.getString(tableName, i,"FINANSAL_KOD"));
				tffSsProductMapTx.setFinansalAdi(iMap.getString(tableName, i,"FINANSAL_ADI"));
				tffSsProductMapTx.setGecerli(iMap.getString(tableName, i,"GECERLI"));
				tffSsProductMapTx.setKartBedeli(iMap.getBigDecimal(tableName, i,"KART_BEDELI"));
				tffSsProductMapTx.setKartTipi(iMap.getString(tableName, i,"KART_TIPI"));
				tffSsProductMapTx.setKlupId(iMap.getString(tableName, i,"KLUP_ID"));
				tffSsProductMapTx.setLogoAdi(iMap.getString(tableName, i,"LOGO_ADI"));
				tffSsProductMapTx.setLogoKod(iMap.getString(tableName, i,"LOGO_KOD"));
				tffSsProductMapTx.setLoyaltyBedeli(iMap.getBigDecimal(tableName, i,"LOYALTY_BEDELI"));
				tffSsProductMapTx.setMarka(iMap.getString(tableName, i,"MARKA"));
				tffSsProductMapTx.setMaxLimit(iMap.getBigDecimal(tableName, i,"MAX_LIMIT"));
				//tffSsProductMapTx.setMetin(iMap.getString(tableName, i,"ID"));
				tffSsProductMapTx.setMinLimit(iMap.getBigDecimal(tableName, i,"MIN_LIMIT"));
				tffSsProductMapTx.setPaket(iMap.getString(tableName, i,"PAKET"));
				tffSsProductMapTx.setUnder18(iMap.getString(tableName, i,"UNDER_18"));
				tffSsProductMapTx.setUrunAdi(iMap.getString(tableName, i,"URUN_ADI"));
				tffSsProductMapTx.setUrunId(iMap.getString(tableName, i,"URUN_ID"));
				tffSsProductMapTx.setUrunSahipKod(iMap.getString(tableName, i,"URUN_SAHIP_KOD"));
				tffSsProductMapTx.setVizeBedeli(iMap.getBigDecimal(tableName, i,"VIZE_BEDELI"));
				
				session.save(tffSsProductMapTx);
				
				List<?> listKanal = (List<?>) iMap.get(tableName, i, "URUN_KANAL_LIST");
				iMap.put("URUN_KANAL_LIST", listKanal);
				String kanalTableName = "URUN_KANAL_LIST";
				if (listKanal != null){
					for (int j = 0; j < listKanal.size(); j++) {
						
						TffUrunKanalMapTx tffUrunKanalMapTx = new TffUrunKanalMapTx();
						TffUrunKanalMapTxId id = new TffUrunKanalMapTxId();
						
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						id.setId(iMap.getBigDecimal(tableName, i,"ID"));
						id.setSource(iMap.getString(kanalTableName, j, "SOURCE"));
						tffUrunKanalMapTx.setId(id);
						tffUrunKanalMapTx.setGecerli(iMap.getString(kanalTableName, j, "GECERLI"));
						
						session.save(tffUrunKanalMapTx);
						session.flush();
					}
				}
			}
			session.flush();
			
			iMap.put("TRX_NAME", "3894");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			if(e.getCause()!=null)throw new GMRuntimeException(0,e.getCause().getMessage());
			else throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3894_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		String tableName = "SS_PRODUCT_MAP";
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3894.get_tff_ss_product_map_info(?)}");
			
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			
			int row = 0;
			while (rSet.next()) {
				int i = 1;
				
				BigDecimal urunId = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "ID", urunId);
				oMap.put(tableName, row, "PAKET", rSet.getString(i++));
				oMap.put(tableName, row, "KART_TIPI", rSet.getString(i++));
				oMap.put(tableName, row, "BASVURU_URUN_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "URUN_ID", rSet.getString(i++));
				oMap.put(tableName, row, "URUN_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "LOGO_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "LOGO_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "FINANSAL_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "FINANSAL_ADI", rSet.getString(i++));
				oMap.put(tableName, row, "KLUP_ID", rSet.getString(i++));
				oMap.put(tableName, row, "URUN_SAHIP_KOD", rSet.getString(i++));
				oMap.put(tableName, row, "UNDER_18", rSet.getString(i++));
				oMap.put(tableName, row, "KART_BEDELI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "VIZE_BEDELI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "LOYALTY_BEDELI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "GECERLI", rSet.getString(i++));
				oMap.put(tableName, row, "MARKA", rSet.getString(i++));
				oMap.put(tableName, row, "MAX_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MIN_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "BASVURU_URUN_KODU", rSet.getString(i++));

				stmt2 = conn.prepareCall("{? = call PKG_TRN3894.get_tff_urun_kanal_map_info(?,?) }");
				
				stmt2.registerOutParameter(1, -10);
				stmt2.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt2.setBigDecimal(3, urunId);
				stmt2.execute();
				stmt2.getMoreResults();
				
				rSet2 = (ResultSet) stmt2.getObject(1);
				ArrayList<HashMap<String, Object>> kanalList = new ArrayList<HashMap<String, Object>>();
				
				while (rSet2.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("SOURCE", rSet2.getString(y++));
					rowData.put("GECERLI", rSet2.getString(y++));

					kanalList.add(rowData);
				}
				oMap.put(tableName, row, "URUN_KANAL_LIST", kanalList);
				
				GMServerDatasource.close(rSet2);
				GMServerDatasource.close(stmt2);
				
				row++;
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
}
