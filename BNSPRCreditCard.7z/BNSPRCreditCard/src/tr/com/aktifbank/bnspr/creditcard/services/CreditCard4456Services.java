package tr.com.aktifbank.bnspr.creditcard.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBiletBedeliOdemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhHesapBasvuruGunTx;
import tr.com.calikbank.bnspr.dao.MuhHesapBasvuruTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCard4456Services {
    public static boolean isNotExistAndNull(GMMap iMap, String key) {
        
        if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0){
            return true;
        } else{
            return false;
        }
    }
    
    @GraymoundService("BNSPR_TRN4456_GET_TRX_NO")
    public static GMMap getTrxNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            if (!isNotExistAndNull(iMap , "TUTAR")){
                GMMap exMap = new GMMap();
                exMap.put("P1" , "Tutar bo� olamaz!");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
            
            if (!isNotExistAndNull(iMap , "KOD")){
                GMMap exMap = new GMMap();
                exMap.put("P1" , "Kod bo� olamaz!");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
            Object[] values = new Object[] 
                    {
                    BnsprType.STRING,
                    iMap.getString("KOD"),
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("TUTAR")
                       
                    };
            oMap.put("TRX_NO",DALUtil.callOracleFunction("{? = call PKG_TRN4456.get_odeme_trxno(?,?)}" , BnsprType.NUMBER , values));
            

            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    
	
    @GraymoundService("BNSPR_TRN4456_GET_VALUES")
    public static GMMap getValues(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            Object[] inputValues = new Object[] {
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("TRX_NO")
            };

            Object[] outputValues = new Object[] {
                    BnsprType.REFCURSOR,
                    "LIST",
                    BnsprType.NUMBER,
                    "SABIT_HIZMET_ORANI",
                    BnsprType.NUMBER,
                    "TAKAS_KOMISYON_ORANI",
                    BnsprType.NUMBER,
                    "SABIT_HIZMET_TUTARI",
                    BnsprType.NUMBER,
                    "KOMISYON_TUTAR",
                    BnsprType.NUMBER,
                    "NET_TUTAR",
                    BnsprType.NUMBER,
                    "TOPLAM_TURNIKE_TUTARI",
                    BnsprType.STRING,
                    "ACIKLAMA",
                    BnsprType.NUMBER,
                    "KULUP_HESAP"
                    

            };
            
            oMap=(GMMap)DALUtil.callOracleProcedure("{call PKG_TRN4456.get_values(?,?,?,?,?,?,?,?,?,?)}" , inputValues , outputValues);
           
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    
	
    @GraymoundService("BNSPR_TRN4456_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Object[] inputValues = new Object[] {
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("TRX_NO")
            };

            Object[] outputValues = new Object[] {
                    BnsprType.REFCURSOR,
                    "LIST",
                    BnsprType.NUMBER,
                    "SABIT_HIZMET_ORANI",
                    BnsprType.NUMBER,
                    "TAKAS_KOMISYON_ORANI",
                    BnsprType.NUMBER,
                    "SABIT_HIZMET_TUTARI",
                    BnsprType.NUMBER,
                    "KOMISYON_TUTAR",
                    BnsprType.NUMBER,
                    "NET_TUTAR",
                    BnsprType.NUMBER,
                    "TOPLAM_TURNIKE_TUTARI",
                    BnsprType.STRING,
                    "URUN_SAHIP_KOD",
                    BnsprType.NUMBER,
                    "BILET_BEDELI",
                    BnsprType.STRING,
                    "F_KAPSAM",
                    BnsprType.STRING,
                    "ACIKLAMA",
                    BnsprType.NUMBER,
                    "KOMBINE_HIZMET_BEDELI",
                    BnsprType.NUMBER,
                    "EFATURA_HIZMET_BEDELI",
                    BnsprType.NUMBER,
                    "KULUP_HESAP"
                    
            };
            
            oMap=(GMMap)DALUtil.callOracleProcedure("{call PKG_TRN4456.get_info(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}" , inputValues , outputValues);
			oMap.put("F_KAPSAM_DISI", GuimlUtil.convertToCheckBoxSelected(oMap.getString("F_KAPSAM")));

            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    } 
    
	
    @GraymoundService("BNSPR_TRN4456_SAVE")
    public static GMMap save(GMMap iMap) {
        
        try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap exMap = new GMMap();
                exMap.put("P1" , "Transaction No bo� olamaz");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
			TffBiletBedeliOdemeTx tffBiletBedeliOdemeTx = (TffBiletBedeliOdemeTx) session.get(TffBiletBedeliOdemeTx.class, iMap.getBigDecimal("TRX_NO"));

			tffBiletBedeliOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tffBiletBedeliOdemeTx.setTopTurnikeTutari(iMap.getBigDecimal("TURNIKE_BEDELI"));
			tffBiletBedeliOdemeTx.setFKapsamDisi(iMap.getString("F_KAPSAM_DISI"));
			tffBiletBedeliOdemeTx.setAciklama(iMap.getString("ACIKLAMA"));
			tffBiletBedeliOdemeTx.setKomHzmBdl(iMap.getBigDecimal("KOMBINE_HIZMET_BEDELI"));
			tffBiletBedeliOdemeTx.setEfaturaHzmBdl(iMap.getBigDecimal("EFATURA_HIZMET_BEDELI"));
			
			

			session.saveOrUpdate(tffBiletBedeliOdemeTx);
			session.flush(); 

			
            iMap.put("TRX_NAME" , "4456");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
       
    }


}
