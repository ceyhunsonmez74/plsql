package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuruBelge;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import common.Logger;

public class CreditCardDYSServices implements TffServicesMessages {
	
	private static final Logger logger = Logger.getLogger(CreditCardDYSServices.class);
	
    @GraymoundService("BNSPR_CREDITCARD_DYS_GET_DOKUMAN_TIP")
    public static GMMap getKartDokumanTipleri(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "DOKUMAN_TIP_LIST", true, "select key1, pkg_genel_pr.Dokuman_Adi(key1) text from v_ml_gnl_param_text where kod = 'KK_BASVURU_BELGE_KOD' and key2 = 'KK' order by sira_no, text");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    @GraymoundService("BNSPR_CREDITCARD_DYS_GET_BELGE_STATU")
    public static GMMap getBelgeStatuleri1(GMMap iMap) {
        try {
        	int i=0;
        	GMMap oMap=new GMMap();
        	oMap.put("BELGE_STATU1_LIST", i, "NAME", "Uygun Belge");
        	oMap.put("BELGE_STATU1_LIST", i, "VALUE",i+1 );
        	
        	i++;
        	oMap.put("BELGE_STATU1_LIST", i, "NAME", "Eksik Belge");
        	oMap.put("BELGE_STATU1_LIST", i, "VALUE", i+1);
        	
        	i++;
        	oMap.put("BELGE_STATU1_LIST", i, "NAME", "Hatali Belge");
        	oMap.put("BELGE_STATU1_LIST", i, "VALUE", i+1);
        	
        	i++;
        	oMap.put("BELGE_STATU1_LIST", i, "NAME", "Supheli");
        	oMap.put("BELGE_STATU1_LIST", i, "VALUE", i+1);
        	
        	return oMap;
        	
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_CREDITCARD_DYS_GET_BELGE_STATU2")
    public static GMMap getBelgeStatuleri2(GMMap iMap) {
        try {
        	int i=0;
        	GMMap oMap=new GMMap();
        	oMap.put("BELGE_STATU2_LIST", i, "NAME", "Okunaksiz");
        	oMap.put("BELGE_STATU2_LIST", i, "VALUE","N" );
        	
        	i++;
        	oMap.put("BELGE_STATU2_LIST", i, "NAME", "Bilgi Uyumsuz");
        	oMap.put("BELGE_STATU2_LIST", i, "VALUE", "U");
        	
        	i++;
        	oMap.put("BELGE_STATU2_LIST", i, "NAME", "Belge Fotokopi");
        	oMap.put("BELGE_STATU2_LIST", i, "VALUE", "F");
        	
        	i++;
        	oMap.put("BELGE_STATU2_LIST", i, "NAME", "Imza BHS");
        	oMap.put("BELGE_STATU2_LIST", i, "VALUE", "I");
        	
        	i++;
        	oMap.put("BELGE_STATU2_LIST", i, "NAME", "Imza Yok");
        	oMap.put("BELGE_STATU2_LIST", i, "VALUE", "B");
        	
        	return oMap;
        	
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_CREDITCARD_DYS_GET_DOKUMAN_TIP")
    public static GMMap getFaaliyetAlanlari(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "DOKUMAN_TIP_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'ISYERI_FAAL_KONU_KOD' order by sira_no, text");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_CREDITCARD_DYS_GET_GELIS_NOKTASI_LIST")
    public static GMMap getGelisNoktasi(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "GELIS_NOKTASI_LIST", true, "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by aciklama");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

	//---------------------------------------------------------------------
	//******************************************************* BELGE KONTROL
	//---------------------------------------------------------------------
	/** Basim asamasindaki basvurularin belge kontrolu yapildiktan sonra
	 * musteri, hesap ve kart tamamlama islemleri gerceklestirilir
	 * 
	 * @author murat.el
	 * @param iMap - CARD_NO Zorunlu
	 */
	@GraymoundService("BNSPR_CREDITCARD_BELGE_KONTROL")
    public static GMMap controlKkBasvuruBelge(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Belgeler tamamlandiysa musteri,hesap ve kart islemlerini tamamla.
			//1.Basvuru musteri bilgisini al.
			String kartNo = iMap.getString("CARD_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			if(isNotExistAndNull(iMap,"APPLICATION_NO"))
			{
			    basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
			}
			GMMap musteriBilgiMap = new GMMap(); 
			musteriBilgiMap.putAll(getBasvuruMusteriInfo(kartNo, basvuruNo));//KART_NO
			//Hep parametre olarak gelen kart numarasi islemlerde esas olacak, basvuru no gelemeyebileceginden
			//fonk.dan donen deger ile tazelenir.
			if (musteriBilgiMap.isEmpty()) {
				oceanUpdateCardStatus(iMap);
				oMap.put("RESPONSE_DATA", "Basvuru numarasi bulunamadi. Kart aktivasyon cagrildi");
				return oMap;
			}
			else {
				basvuruNo = musteriBilgiMap.getBigDecimal("BASVURU_NO");
				iMap.putAll(musteriBilgiMap);
				if ("ACIK".equals(iMap.getString("DURUM_KODU"))) {
					oceanUpdateCardStatus(iMap);
					oMap.put("RESPONSE_DATA", "Durum acik tekrar kart aktivasyon cagirildi");
					return oMap;
				}
			}
						
			//basvuru durumu basim degilse cik.
			if (!"BASIM".equals(iMap.getString("DURUM_KODU"))) {
				CreditCardServicesUtil.raiseGMError("2701", basvuruNo, iMap.getString("DURUM_KODU"), "BASIM");
			}
			
			//2.musteri kontak ise gercege cevrilmelidir.
			//BNSPR_TRN3182_GERCEK_MUSTERI_DONUSTUR
			if ("K".equals(iMap.getString("MUSTERI_KONTAKT"))) {
				try {
					iMap.put("SISTEM", "OCEAN");
					iMap.put("KART_TIPI", musteriBilgiMap.getString("KART_TIPI"));
					iMap.put("KART_TIPI", musteriBilgiMap.getString("KART_TIPI"));

					oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
				}
				catch (Exception e) {
					//TFFden geliyorsa basvurudan musteri guncelle, yoksa hatayi firlat
					if ("40".equals(iMap.getString("KANAL_KODU"))) {
						GMMap sorguMap = new GMMap();
						sorguMap.put("KK_BASVURU_NO", basvuruNo);
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
						if (StringUtils.isNotBlank(sorguMap.getString("TFF_BASVURU_NO"))) {
							GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
							oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
						} 
					}
					else {
						throw ExceptionHandler.convertException(e);
					}
				}
			//3.musteri gercek ise basvuru bilgileri ile guncellenir.
			} // PY-6705 ile kaldirildi, ancak PY-11417 ile eklendi.
			else if ("M".equals(iMap.getString("MUSTERI_KONTAKT"))) {
				if ("D".equals(musteriBilgiMap.getString("KART_TIPI"))) {
					GMMap sorguMap = new GMMap();
					sorguMap.put("MUSTERI_NO", musteriBilgiMap.get("MUSTERI_NO"));
					GMServiceExecuter.execute("BNSPR_CREDITCARD_GERCEK_MUSTERI_GUNCELLE", sorguMap);
				}
			}
		
			//4.rezerv hesap yoksa vadesiz hesap acilmalidir.
			//sube kodu null ise calisilan sune kodunu al
			if (iMap.getString("SUBE_KODU") == null) {
				iMap.put("SUBE_KODU", "444");
			}
			
			iMap.put("BASVURU_NO", basvuruNo);
			
			//Vadesiz hesap al
			GMMap hesap = new GMMap();
			hesap.put("BASVURU_NO", basvuruNo);
			hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_VADESIZ_HESAP_AC", iMap));
			iMap.put("HESAP_NO", hesap.getString("HESAP_NO"));
			oMap.put("VADESIZ_HESAP_BILGI", hesap);
			
			// Otomatik �at� hesab� a��lmas�n diye kapat�ld�
			//Vadesiz hesabi cati Hesabina Cevir
			/*hesap = new GMMap();
			hesap.put("BASVURU_NO", basvuruNo);
			hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_CATI_HESAP_AC", iMap));
			oMap.put("CATI_HESAP_BILGI", hesap);*/
			
			//5.fon hesabi ac.
			if ("KK".equals(musteriBilgiMap.getString("KART_TIPI"))) {
				hesap = new GMMap();
				hesap.put("BASVURU_NO", basvuruNo);
				hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_FON_HESAP_AC", iMap));
				GMServiceExecuter.call("BNSPR_SAVE_KK_BASVURU_HESAP", hesap);
				oMap.put("FON_HESAP_BILGI", hesap);
			}
			
			//6.kart aktivasyonu
			if (!"DYS".equals(iMap.getString("ISLEM_YERI"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_ACTIVATION", iMap));
			}
			
			if ("KK".equals(musteriBilgiMap.getString("KART_TIPI"))) {
				//7.oceanda hesabi ac, bu sadece KK icin olamli, kritik, degisecekse hakan beye sorulmali
				hesap.put("CARD_NO", iMap.getString("CARD_NO"));
				hesap.put("ACCOUNT_NO", hesap.getBigDecimal("HESAP_NO"));
				GMServiceExecuter.call("BNSPR_CC_INSERT_FUNDING_ACCOUNT", hesap);
				
				/*8.E-upt hesabina yatirdigi bir bakiye varsa bu kart icin(TCKN ile kartnumarasi olusmadan yatirdigi para.) ve
				 * halen bu bakiye e-upt hesabinda bulunuyor ise; bu bakiyeyi karta gonder, hata alsa da devam
				 */
				try {
					//Varsa TFF Basvuru no al
					GMMap kartMap = new GMMap();
					kartMap.put("KK_BASVURU_NO", basvuruNo);
					kartMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", kartMap));
					kartMap.put("APP_NO", kartMap.getBigDecimal("TFF_BASVURU_NO"));
					kartMap.put("CARD_NO", iMap.getString("CARD_NO"));
					kartMap.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
					//PY-7183 - Serkan altta ERROR firlatinca yakalanmiyordu. Ayri transaction yapildi.
					//TY-2463 - Erdogan batchin calismasi icin kayit atan yeni servis verdi.
					GMServiceExecuter.executeAsync("BNSPR_CRD_INSERT_TFF_CARD_TOP_UP_FROM_APPLICATION_RECORD", kartMap);
				} catch (Exception e) {
					e.printStackTrace();
				}

				//9.KDH istemis ve onaylanmissa onay bilgilendirmesi yap.
				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", basvuruNo);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_KDH_BASVURU_ONAYLANDI_MI", sorguMap));
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("ONAYLANDI_MI"))) {
					//KDH sonuc bilgilendirmesi yap(SMS2)
					sorguMap.clear();
					sorguMap.put("EVENT_TYPE_NO", CreditCardServicesUtil.KDH_SONUC_EVENT_TYPE_NO);
					sorguMap.put("EVENT_REF_NO", "KK_" + basvuruNo);
					GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap);
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Verilen basvuru numarasina ait belge kontrolu tamamlandi mi?
	 * 
	 * @author murat.el
	 * @param iMap - BASVURU_NO - Basvuru Numarasi
	 * @return oMap - TAMAMLANDI_MI - true | false
	 */
	@GraymoundService("BNSPR_CREDITCARD_BELGE_TAMAMLANDI_MI")
	public static GMMap isBasvuruBelgeTamamlandi(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean isBasvuruBelgeTamamlandi = true;
		
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Basvuru bazli ya da butun belgelerin kontrolu yapilir
			Criteria criteria = session.createCriteria(KkBasvuruBelge.class);
			criteria.add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")));
			criteria.addOrder(Order.asc("id.basvuruNo"));
			
			//Bütün kredi karti belgelerini al, belge yoksa cik
			List<?> kkBasvuruBelgeList = criteria.list();
			if (kkBasvuruBelgeList == null || kkBasvuruBelgeList.isEmpty()) {
				oMap.put("TAMAMLANDI_MI", isBasvuruBelgeTamamlandi);
				return oMap;
			}
			
			//Basvuruya belgeleri tamamlanmis mi?
			KkBasvuruBelge kkBasvuruBelge = null;
			for (Object object : kkBasvuruBelgeList) {
				kkBasvuruBelge = (KkBasvuruBelge) object;
				
				//Belge alinmadi veya kontrol edilmediyse islenen belgeyi atla.
				if (!CreditCardServicesUtil.EVET.equals(kkBasvuruBelge.getAlindi()) ||
						!"1".equals(kkBasvuruBelge.getBelgeKontrol())) {
					isBasvuruBelgeTamamlandi = false;
					break;
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("TAMAMLANDI_MI", isBasvuruBelgeTamamlandi);
		return oMap;
	}
	
	
    /** Ocean'daki kartin durumunu aciga cevirir
	 * 
	 * @author sezgi.yilmaz
	 * @param iMap - CARD_NO Zorunlu
	 * @return oMap - ocean donusleri
	 */
	private static GMMap oceanUpdateCardStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			//1.OCEAN Kart Durumu Guncelle
			iMap.put("STATUS", CreditCardServicesUtil.NO);
			iMap.put("SUBSTATUS", CreditCardServicesUtil.NO);
			oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_UPDATE_CARD_STATUS", iMap));
			
			//Kart Acilmadi ise hata ver.
			if(!"2".equals(oMap.getString("RETURN_CODE"))) {
				throw new GMRuntimeException(0, oMap.getString("RETURN_DESCRIPTION") + " " + oMap.getString("ERROR_DETAIL"));
			}
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CREDITCARD_ACTIVATION")
	public static GMMap kartAktivasyon(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oceanUpdateCardStatus(iMap);
			
			//2.Basvuru Kart Durumu Guncelle
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			iMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			iMap.put("ISLEM_NO", oMap.get("TRX_NO"));
			iMap.put("DURUM_KOD", "ACIK");
			iMap.put("ISLEM_ACIKLAMA", "Acik");
			iMap.put("TARIHCE_AKSIYON", "E");
			GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
			
			//3. evam kaydi olustur
			iMap.put("EVENT_TYPE_NO", "18");
			iMap.put("EVENT_REF_NO", iMap.getBigDecimal("BASVURU_NO"));
			GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
			
			//4.tff basvurus ise durum guncelle.
			if ("40".equals(iMap.getString("KANAL_KODU"))) {
				BigDecimal tffBasvuruNo = getTffBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				
				GMMap durumMap = new GMMap();
				durumMap.put("BASVURU_NO", tffBasvuruNo);
				durumMap.put("ISLEM_NO", oMap.getBigDecimal("TRX_NO"));
				durumMap.put("DURUM_KOD", iMap.getString("DURUM_KOD"));
				durumMap.put("ISLEM_ACIKLAMA", "Kart acilma islemi gerceklesti");
				durumMap.put("TARIHCE_AKSIYON", "E");//Son Kaydin durumunu guncelle
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
				
				//5.CRM guncelle
				try {
					durumMap.clear();
					durumMap.put("TFF_BASVURU_NO", tffBasvuruNo);
					durumMap.put("CRM_TYPE", CrmTypes.MAIN);
					GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", durumMap);
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("CRM payment guncellemesi yapilamadi BASVURU_NO:" + tffBasvuruNo);
				}
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	private static BigDecimal getTffBasvuruNo(BigDecimal kkBasvuruNo) {
		BigDecimal tffBasvuruNo = null;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_KK_BASVURU.kk_tff_basvuru_no_al(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, kkBasvuruNo);
			stmt.execute();

			tffBasvuruNo = stmt.getBigDecimal(1);
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return tffBasvuruNo;
	}
	@GraymoundService("BNSPR_CREDITCARD_UPDATE_STATUS")
    public static GMMap updateCardStatusFromOcean(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartNo = iMap.getString("CARD_NO");
		BigDecimal basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
		try {
			// debit kart aktivasyon
			if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(iMap.getString("CARD_DCI"))) { 
				oMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_BELGE_KONTROL", iMap));
			// kredi karti aktivasyon
			} else {
				//Kart numarasi ile basvuru bilgilerini al
				oMap.putAll(getKartBasvuruInfo(kartNo, basvuruNo));
				basvuruNo = oMap.getBigDecimal("BASVURU_NO");
				
				//Basvuru kanal kodu bilgisini al.
				iMap.clear();
				iMap.put("CARD_NO", kartNo);
				iMap.put("BASVURU_NO", basvuruNo);
				iMap.put("ISLEM_YERI", "OCEAN");
				String kanalKodu = oMap.getString("KANAL_KOD");
				
				//Basvurunun kanali sube ve internet bankaciligi ise sadece aktivasyon yapilacak
				GMMap sorguMap = new GMMap();
				sorguMap.put("KOD", "KK_BELGE_KANAL_KOD");
				sorguMap.put("KEY", kanalKodu);
				String isExist = (String) GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap).get("IS_EXIST");//KOD, KEY
				if (CreditCardServicesUtil.EVET.equals(isExist)) {
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_BELGE_TAMAMLANDI_MI", iMap));
					Boolean isBasvuruBelgeTamamlandi = sorguMap.getBoolean("TAMAMLANDI_MI");//BASVURU_NO
					if (isBasvuruBelgeTamamlandi) {
						iMap.put("DURUM_KODU", oMap.getString("DURUM_KOD"));
						iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
						GMServiceExecuter.execute("BNSPR_CREDITCARD_ACTIVATION", iMap);
					} else {
						CreditCardServicesUtil.raiseGMError("2955", basvuruNo);
					}
				} else {
					oMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_BELGE_KONTROL", iMap));
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
		
    /** Basim asamasindaki basvurularin belge kontrolu yapildiktan sonra
	 * musteri, hesap ve kart tamamlama islemleri gerceklestirilir
	 * 
	 * @author murat.el
	 * @param basvuruNo - Kredi karti basvuru numarasi
	 * @param kartNo - Kredi karti numarasi
	 * @return Basvuru yapan musteri bilgileri
	 */
	private static GMMap getBasvuruMusteriInfo(String kartNo, BigDecimal basvuruNo) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_KK_BASVURU.Musteri_Bilgisi(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, kartNo);
			stmt.setBigDecimal(3, basvuruNo);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** Basim asamasindaki basvurularin belge kontrolu yapildiktan sonra
	 * musteri, hesap ve kart tamamlama islemleri gerceklestirilir
	 * 
	 * @author murat.el
	 * @param kartNo - Zorunlu
	 * @param basvuruNo - Opsiyonel
	 * @return Kartin basvuru bilgileri
	 */
	public static GMMap getKartBasvuruInfo(String kartNo, BigDecimal basvuruNo) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_KK_BASVURU.rc_get_basvuru_info_by_cardno(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, kartNo);
			stmt.setBigDecimal(3, null);
			stmt.setBigDecimal(4, basvuruNo);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/** Kredi karti basvurusu icin olusturulan kontakt musteri bilgileri ile gercek musteri olusturulur.
	 * 
	 * @author murat.el
	 * @param iMap - MUSTERI_NO, TC_KIMLIK_NO, KIMLIK_SERI_SIRA_NO, ADI_SOYADI, ONCEKI_SOYAD, DURUM_KODU, KANAL_KODU, APS_BILGILERI_UYUMLUMU
	 */
	@GraymoundService("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR")
	public static GMMap gercekMusteriDonustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			//Varsa musteri bilgilerini al.
			GMMap sorguMap = new GMMap();
			sorguMap.put("KONTAKT_NO", iMap.getBigDecimal("MUSTERI_NO"));
			sorguMap.put("ACTION", "NEW");
			
			GMMap kontaktMap = new GMMap();
			kontaktMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_GET_INFO", sorguMap));//MUSTERI_NO,ACTION

			//KPS yapilmadiysa yap
			if (StringUtils.isBlank(kontaktMap.getString("TCKNO_IN")) || StringUtils.isBlank(kontaktMap.getString("TCKNO_OUT"))) {
				sorguMap.put("tckno_in", iMap.getString("TC_KIMLIK_NO"));
				sorguMap.put("TCKNO", iMap.getString("TC_KIMLIK_NO"));
				
				
				GMMap kpsMap = new GMMap();
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_SORGULAMA", sorguMap));//tckno_in
				
				
				kontaktMap.put("TCKNO_IN", iMap.getString("TC_KIMLIK_NO"));
				kontaktMap.put("TCKNO_OUT", kpsMap.getString("TCKNO_OUT"));
				kontaktMap.put("ISIM", kpsMap.getString("AD1"));
				kontaktMap.put("IKINCI_ISIM", kpsMap.getString("AD2"));
				kontaktMap.put("SOYADI", kpsMap.getString("SOYAD"));
				kontaktMap.put("BABA_ADI", kpsMap.getString("BABA_AD"));
				kontaktMap.put("ANNE_ADI", kpsMap.getString("ANNE_AD"));
				kontaktMap.put("DOGUM_TARIHI", kpsMap.getString("DOGUM_TARIHI"));
				kontaktMap.put("DOGUM_YERI", kpsMap.getString("DOGUM_YERI"));
				kontaktMap.put("IL_KOD", kpsMap.getString("IL_KODU"));
				kontaktMap.put("CILT_NO", kpsMap.getString("CILT_KODU"));
				kontaktMap.put("AILE_SIRA_NO", kpsMap.getString("AILE_SIRA_NO"));
				kontaktMap.put("SIRA_NO", kpsMap.getString("BIREY_SIRA_NO"));
				kontaktMap.put("KIZLIK_SOYADI", kpsMap.getString("KIZLIK_SOYAD"));
				kontaktMap.put("ILCE_KOD", kpsMap.getString("ILCE_KODU"));
				//kontaktMap.put("OLUM_TARIHI", kpsMap.getString("olumTarihi"));
				
				
				kontaktMap.put("VERILDIGI_YER", kpsMap.getString("VERILDIGI_YER"));
				kontaktMap.put("NUF_VERILIS_NEDENI", kpsMap.getString("VERILIS_NEDENI"));
				kontaktMap.put("VERILIS_TARIHI", kpsMap.getString("VERILIS_TARIHI"));
				
				//KPS dogrulama sonrasi
				kontaktMap.put("F_NUF", CreditCardServicesUtil.EVET);
				if (StringUtils.isNotBlank(kpsMap.getString("TCKNO_OUT"))) {
					kontaktMap.put("CINSIYET_KOD", "Erkek".equals(kpsMap.getString("CINSIYET")) ? "E" : "K");
					kontaktMap.put("MEDENI_HAL_KOD", "Evli".equals(kpsMap.getString("MEDENI_HALI")) ? "1" : "2");
					kontaktMap.put("KISA_AD", (kpsMap.getString("AD1") + " " + kpsMap.getString("AD2")).trim() + " " + kpsMap.getString("SOYAD"));
				}
				
				if (StringUtils.isNotBlank(kpsMap.getString("KIMLIK_SERI_NO")) && StringUtils.isNotBlank(kpsMap.getString("KIMLIK_SIRA_NO"))) {
					kontaktMap.put("NUFUS_CUZDANI_SERI_NO", kpsMap.getString("KIMLIK_SERI_NO") + kpsMap.getString("KIMLIK_SIRA_NO"));
				} else {
					kontaktMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_SIRA_NO"));
				}
			// KPS yapildi ise
			} else {
				if (StringUtils.isBlank(kontaktMap.getString("NUFUS_CUZDANI_SERI_NO"))) {
					kontaktMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_SIRA_NO"));
				}
				
				if (StringUtils.isNotBlank(kontaktMap.getString("NUFUS_CUZDANI_SERI_NO"))) {
					kontaktMap.put("F_NUF", CreditCardServicesUtil.EVET);
				}
			}//KPS sonlandi
			
			//kontakt musteri kontrolleri
			if (StringUtils.isBlank(kontaktMap.getString("DK_GRUP_KOD"))) {
				kontaktMap.put("DK_GRUP_KOD", "1042");
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("KISA_AD"))) {
				kontaktMap.put("KISA_AD", iMap.getString("ADI_SOYADI"));
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("KIZLIK_SOYADI"))) {
				kontaktMap.put("KIZLIK_SOYADI", iMap.getString("ONCEKI_SOYAD"));
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("ANNE_KIZLIK_SOYADI"))) {
				kontaktMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("UYRUK_KOD"))) {
				kontaktMap.put("UYRUK_KOD", iMap.getString("UYRUK_KOD", "TR"));
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("KAZANIM_KANALI")) || "40".equals(iMap.getString("KANAL_KODU"))) {
				kontaktMap.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("BAGLI_KANAL_GRUBU")) || "40".equals(iMap.getString("KANAL_KODU"))) {
				kontaktMap.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
				kontaktMap.remove("KANAL_KODU");
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("YERLESIM_KOD"))) {
				kontaktMap.put("YERLESIM_KOD", "I");
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("MUSTERI_SEGMENTI"))) {
				kontaktMap.put("MUSTERI_SEGMENTI", CreditCardServicesUtil.NO);
			}

			if (StringUtils.isBlank(kontaktMap.getString("PROFIL_KOD"))) {
				kontaktMap.put("PROFIL_KOD", "1");
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("ISYERI_ADI"))) {
                kontaktMap.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
            }
			
            for (int i = 0; i < kontaktMap.getSize("ADRES_LIST"); i++){
                if ("I".equals(kontaktMap.getString("ADRES_LIST" , i , "ADRES_KOD")) && 
                   StringUtils.isEmpty(kontaktMap.getString("ADRES_LIST" , i , "ISYERI_UNVANI"))){
                    kontaktMap.put("ADRES_LIST" , i , "ISYERI_UNVANI" , kontaktMap.getString("ISYERI_ADI"));
                    
                }
                
            }
			
			//PY-11417
			int grupKodIndex = 0;
			if (StringUtils.isBlank(kontaktMap.getString("MUSTERI_GRUP_KOD"))) {
				kontaktMap.put("MUSTERI_GRUP_KOD", "1");
				kontaktMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_KOD", "1");
	    		kontaktMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_ADI", "Genel");
	    		grupKodIndex++;
			}
			
			if ("OCEAN".equals(iMap.getString("SISTEM")) && "D".equals(iMap.getString("KART_TIPI"))) {
				GMMap personelMap = new GMMap();
				personelMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
				personelMap.put("REFERANS_TIPI", "KK");
				personelMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
		    	String personelMi = GMServiceExecuter.call("BNSPR_CREDITCARD_PERSONEL_MI", personelMap).getString("PERSONEL_MI");
		    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
		    		kontaktMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_KOD", "201");
		    		kontaktMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_ADI", "N Kolay Kredi - Personel");
		    	} else {
		    		kontaktMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_KOD", "200");
		    		kontaktMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_ADI", "N Kolay Kredi - Standart M��teri");
		    	}
		    	grupKodIndex++;
			}

			if (StringUtils.isBlank(kontaktMap.getString("MESLEK_KOD"))) {
				kontaktMap.put("MESLEK_KOD", "14");
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("ORIJINAL_EVRAKLIMI"))) {
				kontaktMap.put("ORIJINAL_EVRAKLIMI", "H");
			}
			
			if (StringUtils.isBlank(kontaktMap.getString("PORTFOY_KOD"))) {
				kontaktMap.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
				kontaktMap.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", kontaktMap.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
			}
			
			//PY-5267
			
			if (StringUtils.isEmpty(kontaktMap.getString("KAZANIM_URUNU")) ) {
				logger.info("MUSTERI NO"+ kontaktMap.getString("MUSTERI_NO") +" Kazan�m �r�n� bo�");
				if ("40".equals(iMap.getString("KANAL_KODU"))) {
					kontaktMap.put("KAZANIM_URUNU", "TFFKART");//MUSTERI_KAZANIM_URUNU paramtextten al
				} else {
					if ("OCEAN".equals(iMap.getString("SISTEM"))) {
						kontaktMap.put("KAZANIM_URUNU", "KREDKART");//MUSTERI_KAZANIM_URUNU paramtextten al
					} else if ("INTRA".equals(iMap.getString("SISTEM"))) {
						kontaktMap.put("KAZANIM_URUNU", "TFFKART");//MUSTERI_KAZANIM_URUNU paramtextten al
					} else {
						kontaktMap.put("KAZANIM_URUNU", "TFFKART");//MUSTERI_KAZANIM_URUNU paramtextten al
					}
				}
			} 
			else{

				if (!StringUtils.isEmpty(iMap.getString("KAZANIM_URUNU")))
				kontaktMap.put("KAZANIM_URUNU", iMap.getString("KAZANIM_URUNU"));
				
			}
			
			kontaktMap.put("F_SAHTE", kontaktMap.getBoolean("F_SAHTE") ? "1" : "0");
			kontaktMap.put("F_MUSTERIYE_CEVRILEBILIR", kontaktMap.getBoolean("F_MUSTERIYE_CEVRILEBILIR") ? "1" : "0");
			kontaktMap.put("MUSTERI_KONTAKT", "M");
			kontaktMap.put("HESAP_UCRETI_F", CreditCardServicesUtil.HAYIR);
			kontaktMap.put("YATIRIM_EKSTRESI", CreditCardServicesUtil.HAYIR);
			
            boolean iletisimTelVarMi = false;
            for(int i=0; i<kontaktMap.getSize("TELEFON_LIST"); i++){
            	if("3".equals(kontaktMap.getString("TELEFON_LIST", i, "TEL_TIP")))
            		kontaktMap.put("ADK_MUSTERISIMI", CreditCardServicesUtil.EVET);
            	if("1".equals(kontaktMap.getString("TELEFON_LIST", i, "F_ILETISIM")))
            		iletisimTelVarMi = true;
			}
			if(!iletisimTelVarMi)
			{
				for(int i=0; i<kontaktMap.getSize("TELEFON_LIST"); i++){
	            	if("3".equals(kontaktMap.getString("TELEFON_LIST", i, "TEL_TIP")))
	            	{
	            		kontaktMap.put("ADK_MUSTERISIMI", CreditCardServicesUtil.EVET);
	            		kontaktMap.put("TELEFON_LIST", i, "F_ILETISIM", "1");
	            		break;
	            	}
				}
			}
			
			//APS bilgilerini al
			kontaktMap.put("F_APS", CreditCardServicesUtil.EVET);
			try {
				sorguMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
				kontaktMap.putAll(GMServiceExecuter.execute("BNSPR_QRY1098_GET_APS", sorguMap));
				kontaktMap.put("F_APS_TEYIT", CreditCardServicesUtil.EVET.equals(iMap.getString("APS_BILGILERI_UYUMLUMU")));
			} catch (Exception e) {
				kontaktMap.put("F_APS_TEYIT", false);
				System.out.println(e.getMessage().toString());
			}
			
			//Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
			kontaktMap.put("TRX_ONAYSIZ_ISLEM", CreditCardServicesUtil.EVET);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontaktMap));
			oMap.put("TRX_NO", kontaktMap.getBigDecimal("TRX_NO"));
			
			iMap.put("MESSAGE_NO", new BigDecimal(1753));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("GM_MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Gercek musteri bilgilerini gunceller.<br>
	 * @author murat.el
	 * @since PY-11417
	 * @param iMap
	 *         <li>MUSTERI_NO - Musteri numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_CREDITCARD_GERCEK_MUSTERI_GUNCELLE")
	public static GMMap gercekMusteriGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			//Guncellenecek musterinin bilgilerini tutan tx olustur.
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1040_CREATE_TRX_NO", sorguMap));//TRX_NO
			//Olusturulan txden bilgileri al
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", sorguMap));
			
			//--------------------------- GRUP KOD GUNCELLE
			//Grup kodunu guncelle - Aynisi varsa atla
			int grupKodIndex = sorguMap.getSize("GRUP_KOD");
			if (StringUtils.isBlank(sorguMap.getString("MUSTERI_GRUP_KOD"))) {
				sorguMap.put("MUSTERI_GRUP_KOD", "1");
				if (!GuimlUtil.contains((List<?>) sorguMap.get("GRUP_KOD") , "MUSTERI_GRUP_KOD" , "1")) {
					sorguMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_KOD", "1");
					sorguMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_ADI", "Genel");
					grupKodIndex++;
				}
			}
			
			//Personel mi
			GMMap personelMap = new GMMap();
			personelMap.put("TC_KIMLIK_NO", sorguMap.get("TC_KIMLIK_NO"));
			personelMap.put("REFERANS_TIPI", "KK");
			personelMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
	    	String personelMi = GMServiceExecuter.call("BNSPR_CREDITCARD_PERSONEL_MI", personelMap).getString("PERSONEL_MI");
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		if (!GuimlUtil.contains((List<?>) sorguMap.get("GRUP_KOD") , "MUSTERI_GRUP_KOD" , "201")) {
	    			sorguMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_KOD", "201");
		    		sorguMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_ADI", "N Kolay Kredi - Personel");
		    	}
	    	} else {
	    		if (!GuimlUtil.contains((List<?>) sorguMap.get("GRUP_KOD") , "MUSTERI_GRUP_KOD" , "200")) {
	    			sorguMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_KOD", "200");
		    		sorguMap.put("GRUP_KOD", grupKodIndex, "MUSTERI_GRUP_ADI", "N Kolay Kredi - Standart Musteri");
	    		}
	    	}
	    	//Islemi tamamla
	    	sorguMap.put("F_SAHTE", sorguMap.getBoolean("F_SAHTE") ? "1" : "0");//gelirken false olarak geliyor
	    	sorguMap.put("F_MUSTERIYE_CEVRILEBILIR", sorguMap.getBoolean("F_MUSTERIYE_CEVRILEBILIR") ? "1" : "0");//gelirken false olarak geliyor
	    	oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_SAVE", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
    @GraymoundService("BNSPR_KART_KURYE_TESLIM_BHS_KONTROL")
	public static GMMap kartKuryeTeslimBHSKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			oMap.put("F_BHS", DALUtil.callOneParameterFunction("{? = call PKG_TFF_RM_DOKUMAN.Musteri_Kart_BHS_varmi(?)}", Types.VARCHAR, iMap.getBigDecimal("MUSTERI_NO")));
		}
		catch (Exception e) {
			oMap.put("F_BHS", CreditCardServicesUtil.HAYIR);
		}
		return oMap;
	}
	

	@GraymoundService("BNSPR_KART_DOKUMAN_ALINDI_MI_BY_KANAL")
	public static GMMap dokumanAlindiMiByKanal(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {

			if (iMap.get("TFF_BASVURU_NO") != null) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI_MI_BY_KANAL", iMap));
			}
			else if (iMap.get("KK_BASVURU_NO") != null) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI_BY_KANAL", iMap));
			}

			else {
				oMap.putAll(CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI));
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	 public static boolean isNotExistAndNull(GMMap iMap, String key) {
	        
	        if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0){
	            return true;
	        } else{
	            return false;
	        }
	    }
	 
}
