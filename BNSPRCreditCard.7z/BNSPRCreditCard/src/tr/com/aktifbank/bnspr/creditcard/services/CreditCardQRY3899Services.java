package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

public class CreditCardQRY3899Services implements OceanMapKeys{

	
	private static void validateRequest(GMMap iMap) {
        
        if (StringUtils.isBlank(iMap.getString("BASVURU_NO")) 
        		&& StringUtils.isBlank(iMap.getString("TC_KIMLIK_NO"))
        		&& StringUtils.isBlank(iMap.getString("MUSTERI_NO"))
        		&& StringUtils.isBlank(iMap.getString("BASLANGIC_TARIHI"))
        		&& StringUtils.isBlank(iMap.getString("BITIS_TARIHI"))
        		&& StringUtils.isBlank(iMap.getString("KART_TIPI"))
        		&& StringUtils.isBlank(iMap.getString("KANAL"))
        		&& StringUtils.isBlank(iMap.getString("DURUM_KOD"))){
        	
        	throw new GMRuntimeException(447801, "En az bir sorgu kriteri giriniz.");
      
        }
	
    }
	
	@GraymoundService("BNSPR_QRY3899_FILL_COMBOS")
	public static GMMap fillInitialValues(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			
			//Source-KANAL List
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3899_FILL_KK_BASVURU_SOURCE", iMap));
			//Durum Kod List
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3899_FILL_KK_BASVURU_DURUM_KOD", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3899_GET_START_FINISH_DATES", iMap));
			//urun tipi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3899_FILL_URUN_TIPI", iMap));
			
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3899_FILL_KK_BASVURU_SOURCE")
	public static GMMap fillKkBasvuruSourceList(GMMap iMap){
		String query = "select distinct k.source, k.source from bnspr.kk_basvuru k where k.source IS not NULL and LENGTH(TRIM (k.source)) != 0";
		
		iMap.put("ADD_EMPTY_KEY","E");
		iMap.put("LIST_NAME", "KANAL_LIST");
		iMap.put("LIST_QUERY", query);
		return DALUtil.fillComboBox(iMap);
		
	}
	
	@GraymoundService("BNSPR_QRY3899_FILL_KK_BASVURU_DURUM_KOD")
	public static GMMap fillKkBasvuruDurumKodList(GMMap iMap){
		String query = "select key1 kod, text aciklama from bnspr.gnl_param_text where kod ='KK_BASVURU_DURUM_KOD' and key2= 'NKOLAY'";
		
		iMap.put("ADD_EMPTY_KEY","E");
		iMap.put("LIST_NAME", "DURUM_KOD");
		iMap.put("LIST_QUERY", query);
		return DALUtil.fillComboBox(iMap);
		
	}
	
	@GraymoundService("BNSPR_QRY3899_FILL_URUN_TIPI")
	public static GMMap fillUrunTipiList(GMMap iMap){

		String query = "select distinct urun_id kod, urun_adi text from bnspr.kk_ss_product_map m where m.gecerli = 'E'";

		iMap.put("ADD_EMPTY_KEY","E");
		iMap.put("LIST_NAME", "URUN_ID");
		iMap.put("LIST_QUERY", query);
		return DALUtil.fillComboBox(iMap);
		
	}
	
	@GraymoundService("BNSPR_QRY3899_FILL_COMBO_KK_BASVURU_KART_TIPI")
	public static GMMap getKkBasvuruSourceList(GMMap iMap){
			
			String query = "select key1 kod, text aciklama from bnspr.gnl_param_text where kod ='TFF_WEBSERVIS_PARAM' and key2= 'KART_TIPI'";
			iMap.put("ADD_EMPTY_KEY","E");
			iMap.put("LIST_NAME", "KART_TIPI_LIST");
			iMap.put("LIST_QUERY", query);
			return DALUtil.fillComboBox(iMap);
			
			/*
		 	Connection conn = null;
	        PreparedStatement stmt = null;
	        ResultSet rSet = null;
	        GMMap oMap = new GMMap();
	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareStatement("select distinct  kart_tipi, kart_tipi from bnspr.kk_basvuru  where kart_tipi IS not NULL and LENGTH(TRIM (kart_tipi)) != 0");
	            rSet = stmt.executeQuery();
	
	            String listName = "KART_TIPI_LIST";
	            while (rSet.next()) {
	                GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
	            }
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	        */
	        
	}
	
	@GraymoundService("BNSPR_QRY3899_GET_START_FINISH_DATES")
	public static GMMap getStartFinishDates(GMMap iMap) {
	
		Date toDay;
		Date minusOneMonth;
		GMMap oMap = new GMMap();
		try {
			Calendar c = Calendar.getInstance(); 
			c.setTime(new Date()); 
			toDay=c.getTime();
			c.add(Calendar.MONTH, -1);
			minusOneMonth= c.getTime();
			oMap.put("BASLANGIC_TARIHI", minusOneMonth);
			oMap.put("BITIS_TARIHI", toDay);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	 @GraymoundService("BNSPR_QRY3899_BASVURU_IZLEME_LISTELE")
		public static GMMap basvuruIzlemeListele(GMMap iMap){
			validateRequest(iMap);			
			GMMap oMap = new GMMap();					
			try{
				String tableName = "BASVURU_BILGILERI";
		    	String func = "{? = call PKG_QRY3899.list_basvuru(?,?,?,?,?,?,?,?,?)}";
			    Object[] inputValues =
			            new Object[] { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), 
			    		BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
			    		BnsprType.STRING, iMap.getString("MUSTERI_NO"), 
			    		BnsprType.STRING, iMap.getString("KART_TIPI"),
			    		BnsprType.STRING, iMap.getString("KANAL"),
			    		BnsprType.STRING, iMap.getString("DURUM_KOD"),
			    		BnsprType.STRING, iMap.getString("URUN_ID"),
			    		BnsprType.DATE, iMap.getDate("BASLANGIC_TARIHI"),
			    		BnsprType.DATE, iMap.getDate("BITIS_TARIHI")} ;
			    
			    oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			    
		    
			    // durum kodlar� yerine paramtextteki isimleri koy
			    for(int i = 0; i< oMap.getSize(tableName);i++){
			    	String durumKod = oMap.getString(tableName,i,"DURUM_KOD");
			    	if(StringUtils.isNotEmpty(durumKod)){
			    		if(StringUtils.equals(durumKod, "ACIK")){
			    			oMap.put(tableName, i, "DURUM_KOD", "Kart A��k");
			    		}else if(StringUtils.equals(durumKod, "BASIM")){
			    			oMap.put(tableName, i, "DURUM_KOD", "Kart bas�m");
			    		}else if(StringUtils.equals(durumKod, "IPTAL")){
			    			oMap.put(tableName, i, "DURUM_KOD", "�ptal");
			    		}else if(StringUtils.equals(durumKod, "BASVURU")){
			    			oMap.put(tableName, i, "DURUM_KOD", "Ba�vuru");
			    		}
			    	}
			    }
			    
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			
			
			return oMap;
		}
	
	 @GraymoundService("BNSPR_QRY3899_BASVURU_DURUM_BILGISI")
		public static GMMap kartDurumBilgisi(GMMap iMap) {
			GMMap oMap = new GMMap();
	
			//Basvuru durumu BASIM, BASVURU, IPTAL, ACIK ise kart bilgisi sorgulamasi yapilabilir.
			if (!"BASIM".equals(iMap.getString("DURUM_KOD"))&&!"BASIM".equals(iMap.getString("DURUM_KOD")) && !"ACIK".equals(iMap.getString("DURUM_KOD"))) {
				oMap.put("KART_DURUM", "");
			}

			try{
				// get card details 
				GMMap cardDetails = new GMMap();
				cardDetails.put("CARD_NO",iMap.getString("KART_NO"));
				cardDetails =  GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", cardDetails);
				
				
				if(cardDetails.getString("RETURN_CODE").equals("2")){
					for (int i = 0; i < cardDetails.getSize("CARD_DETAIL_INFO"); i++){
		                if (StringUtils.isNotBlank(cardDetails.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_DESC"))){
		                    oMap.put("KART_DURUM", cardDetails.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_DESC"));
		                }
		            }
				}else{
					oMap.put("KART_DURUM", "--");
				}
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
				
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "Islem Basarili");
			return oMap;
	}
	 
	 
	 @GraymoundService("BNSPR_QRY3899_GET_TARIHCE")
		public static GMMap getTffTarihce(GMMap iMap) {
			GMMap oMap = new GMMap();
			
			//initial database variables
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_QRY3899.get_tarihce(?)}");
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.execute();
	
				rSet = (ResultSet) stmt.getObject(1);
				oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			
			return oMap;
		}
 
	 @GraymoundService("BNSPR_QRY3899_GET_KURYE_LIST")
		public static GMMap getKuryeInfo(GMMap iMap) {
			GMMap oMap = new GMMap();

			try {
				//Alanlarin degerlerini al
				String func = "{? = call PKG_QRY3899.getKuryeInfoByBasvuruNo(?)}";
				/*Object[] inputValues = new Object[2];
				inputValues[0] = BnsprType.NUMBER;
				inputValues[1] = iMap.getBigDecimal("BASVURU_NO");*/
				Object[] inputValues =
			            new Object[] { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")};
				
				 oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "KURYE_LIST", inputValues));
						 
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			
			return oMap;
		}
	 
	 @GraymoundService("BNSPR_QRY3899_GET_SOZLESME")
		public static GMMap getSozlesme(GMMap iMap) {
			GMMap oMap = new GMMap();
			
			//initial database variables
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_QRY3899.getDokumanBilgi(?)}");
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.execute();

				rSet = (ResultSet) stmt.getObject(1);
				oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			
			return oMap;
		}
}
