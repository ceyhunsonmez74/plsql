package tr.com.aktifbank.bnspr.creditcard.services;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.math.BigDecimal;
import java.net.URLConnection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.apache.axis.encoding.Base64;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruGidenOtp;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyon;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonGrup;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrun;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.aktifbank.bnspr.tff.services.TffCommonServices;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.obss.adc.core.otp.util.OtpGenerator;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3801Services {

	private static final Logger logger = Logger.getLogger(CreditCardTRN3801Services.class);
	private static Configurator conf = Configurator.createConfiguratorFromProperties (  "configuration/aktifbank-int-tff.properties" );
	
	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";
	private static final double MAX_SIZE = 100;
	private static final BigDecimal KANAL = new BigDecimal(8);
	public static final BigDecimal PROMOSYON_DURUM_UYGUN= BigDecimal.ZERO;
	public static final BigDecimal PROMOSYON_DURUM_KULLANILDI= BigDecimal.ONE;
	public static final BigDecimal PROMOSYON_DURUM_PASIF=  BigDecimal.ONE.negate();
	@GraymoundService("BNSPR_TRN3801_FOTO_PATH_VER")
	public static GMMap tffFotoPathVer(GMMap iMap){
		GMMap oMap = new GMMap();
		String kimlikNo = iMap.getString("KIMLIK_NO");
		String kimlikNoGercek = iMap.getString("KIMLIK_NO");
		kimlikNo = StringUtil.lPad(kimlikNo, 12);
		String basvuruNo = iMap.getString("BASVURU_NO");
		String folderPath = ROOT + File.separator + "files";
		try {

			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING,
					BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
		
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		String[] sp = kimlikNo.split("(?<=\\G.{3})");
		File klasor = null;
		//folderPath = String.format("/%s/%s/%s/%s/%s/", folderPath,sp[0],sp[1],sp[2],kimlikNo);
		for (int i = 0; i < sp.length-1 && i < 3; i++) {
			if(TffServicesHelper.isWindowsReservedFilename(sp[i]))
				folderPath = String.format("%s/%s", folderPath,"XXX");	
			else
				folderPath = String.format("%s/%s", folderPath,sp[i]);
			klasor = new File(folderPath);
			if (!klasor.exists()){
				oMap.put("PATH", folderPath);
				oMap.put("RESPONSE", 1);
				return oMap;
			}
		}
		folderPath = String.format("%s/%s", folderPath,kimlikNoGercek);
		if (!klasor.exists()){
			oMap.put("PATH", folderPath);
			oMap.put("RESPONSE", 1);
			return oMap;
		}
			//klasor.mkdir();
		String type = "jpg";
		String imageFile = folderPath + File.separator + kimlikNoGercek + "_" + basvuruNo + "." + type;
		try {
			File img = new File(imageFile);
			if(img.exists()){
				oMap.put("PATH", imageFile);
			}
			else{
				type = "png";
				imageFile = folderPath + File.separator + kimlikNoGercek + "_" + basvuruNo + "." + type;
				img = new File(imageFile);
				if(img.exists()){
					oMap.put("PATH", imageFile);
				}
				else{
					oMap.put("PATH", imageFile);
					oMap.put("RESPONSE", 1);
				}
			}
		}
		catch (Exception e) {
		
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3801_PROMOSYON_DETAY_SORGU")
	public static GMMap promosyonDetaySorgu(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		if (StringUtils.isNotBlank(iMap.getString("PROMOSYON_KODU"))) {
			TffBasvuruPromosyon promosyonlar = (TffBasvuruPromosyon) session.get(TffBasvuruPromosyon.class, iMap.getString("PROMOSYON_KODU"));
			if (promosyonlar != null) {
				if (!TffServicesMessages.IPTAL.equals(promosyonlar.getDurum())) {
					if (promosyonlar.getKalanAdet().intValue() > 0) {
						TffBasvuruPromosyonGrup grup = (TffBasvuruPromosyonGrup) session.get(TffBasvuruPromosyonGrup.class, promosyonlar.getGrupId());
						
						if(StringUtils.isNotBlank(iMap.getString("TFF_BASVURU_NO"))){
							TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
							if(("KK".equals(tffBasvuru.getKartTipi()) && grup.getTipKk().compareTo(BigDecimal.ONE) == 0)
									|| ("D".equals(tffBasvuru.getKartTipi()) && grup.getTipD().compareTo(BigDecimal.ONE) == 0)
									|| ("P".equals(tffBasvuru.getKartTipi()) && grup.getTipP().compareTo(BigDecimal.ONE) == 0)
									){
								logger.info("Promosyon kodu kart tipi uygun");
							}else{
								oMap.put("RESPONSE", 0);
								oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_KART_TIPI_UYGUN_DEGIL);
								return oMap;
							}
						}
						if (grup.getBaslangicTarihi().before(new Date())) {
							if(grup.getBitisTarihi().after(new Date())){
								oMap.put("PROMOSYON_DEGER", 0, "GRUP_ID", promosyonlar.getGrupId());
								oMap.put("PROMOSYON_DEGER", 0, "BASLANGIC_TARIHI", grup.getBaslangicTarihi());
								oMap.put("PROMOSYON_DEGER", 0, "BITIS_TARIHI", grup.getBitisTarihi());
								oMap.put("PROMOSYON_DEGER", 0, "KART_BEDELI", promosyonlar.getKartBedeli());
								oMap.put("PROMOSYON_DEGER", 0, "KURYE_BEDELI", promosyonlar.getKuryeBedeli());
								oMap.put("PROMOSYON_DEGER", 0, "LOYALTY_BEDELI", promosyonlar.getLoyaltyBedeli());
								oMap.put("PROMOSYON_DEGER", 0, "PROMOSYON_BEDELI", promosyonlar.getKartBedeli().add(promosyonlar.getKuryeBedeli()).add(promosyonlar.getLoyaltyBedeli()).add(promosyonlar.getVizeBedeli()));
								oMap.put("PROMOSYON_DEGER", 0, "VIZE_BEDELI", promosyonlar.getVizeBedeli());

								int i = 0;
								List<TffBasvuruPromosyonUrun> urunList = (List<TffBasvuruPromosyonUrun>) session.createCriteria(TffBasvuruPromosyonUrun.class).add(Restrictions.eq("id.grupId", promosyonlar.getGrupId())).list();
								for (TffBasvuruPromosyonUrun urun : urunList) {
									oMap.put("PROMOSYON_URUN", i, "GRUP_ID", urun.getId().getGrupId());
									oMap.put("PROMOSYON_URUN", i, "URUN", urun.getId().getGecerliUrun());

									i++;
								}

								oMap.put("RESPONSE", 2);
							}else{
								//Bitis tarihi gecti
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_BITIS_TARIHI_UYGUN_DEGIL);
								return oMap;
							}
						}else{
							//baslangic tarihi gelmedi
							
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_BASLANGIC_TARIHI_UYGUN_DEGIL);
							return oMap;
						}
			
				}else {// adet hatasi
						oMap.put("RESPONSE", 0);
						oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_KULLANILMISTIR);
					}
				}
				else {// durum hatasi
					oMap.put("RESPONSE", 0);
					oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_IPTAL);
				}
			}
			else {
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_BULUNAMADI_HATASI);
			}
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3801_PROMOSYON_KODU_URET")
	public static GMMap promosyonKoduUret(GMMap iMap) {
		GMMap oMap = new GMMap();
		String sonuc = "";
		try {

			String func = "{? = call Pkg_TRN3801.promosyon_kodu_uret (?,?,?,?,?,?,?,?,?,?,?,?)}";
		
			String  grupKod 	= iMap.getString("GRUP_KOD");
			String  tip			= iMap.getString("TIP");
			BigDecimal  durum 	= iMap.getBigDecimal("DURUM");
			Date  baslangic		= iMap.getDate("BASLANGIC_TARIHI");
			Date  bitis			= iMap.getDate("BITIS_TARIHI");
			BigDecimal adet		= iMap.getBigDecimal("ADET");
			BigDecimal  oran 	= iMap.getBigDecimal("PROMOSYON_ORAN");
			BigDecimal  deger	= iMap.getBigDecimal("PROMOSYON_DEGERI");
			BigDecimal  kurye	= iMap.getBigDecimal("KURYE_BEDELI");
			BigDecimal  kart	= iMap.getBigDecimal("KART_BEDELI");
			BigDecimal  sadakat	= iMap.getBigDecimal("LOYALTY_BEDELI");
			BigDecimal  vize	= iMap.getBigDecimal("VIZE_BEDELI");

			
			sonuc = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.NUMBER,
					BnsprType.STRING, grupKod, 
					BnsprType.STRING, tip, 
					BnsprType.NUMBER, durum,
					BnsprType.DATE, baslangic, 
					BnsprType.DATE, bitis, 
					BnsprType.NUMBER, adet,
					BnsprType.NUMBER, oran, 
					BnsprType.NUMBER, deger, 
					BnsprType.NUMBER, kurye,
					BnsprType.NUMBER,kart, 
					BnsprType.NUMBER,sadakat, 
					BnsprType.NUMBER, vize
					));
		
			
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE_DATA", e.getMessage());
			oMap.put("RESPONSE", 0);
			return oMap;
		}
		oMap.put("RESPONSE", 2);
		oMap.put("RESPONSE_DATA", sonuc);
		return oMap;

	}

	
	
	@GraymoundService("BNSPR_TRN3801_TFF_BASVURU_ISLEM_KAYIT")
	public static GMMap basvuruIslemKayit(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap xMap = new GMMap().put("TABLE_NAME", "TFF_BASVURU_ISLEM");
			BigDecimal islemId = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
			
			// ADCSession.put("CLIENT_SESSION_ID",iMap.getString("CLIENT_SESSION_ID"));
			if (String.valueOf(iMap.getString("CORE_CLIENT_SESSION_ID")).equals(String.valueOf((iMap.getString("CLIENT_SESSION_ID"))))) {
				

				oMap.put("ISLEM_ID", 				islemId);
				oMap.put("RESPONSE", "2");
			}
			else {
				
				oMap.put("RESPONSE", "1");
				oMap.put("RESPONSE_DATA", CreditCardTffServices.errorMessageOlustur("3000","E"));
			}
			int i = 0;
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_BASVURU_ISLEM_KAYIT (?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			Object[] inputValues = new Object[24];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] =islemId;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CORE_CLIENT_SESSION_ID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_SESSION_ID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CORE_SESSION_ID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM_TIPI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_TEL_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TFF_BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_IP");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("KK_BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("OTP_ID");

			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception ex){
			oMap.put("RESPONSE",0);
			oMap.put("RESPONSE_DATA","E-0001:" + ex.getMessage());
			
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_BASVURU_LISTE")
	public static GMMap basvuruListele(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_basvuru_detay_bilgileri (?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[6];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "BASVURU_DETAY";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "ADRES_LISTE";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			oMap.put("RESPONSE",2);
		}
		catch (Exception e) {
			oMap.put("RESPONSE",0);
			oMap.put("RESPONSE_DATA",CreditCardTffServices.errorMessageOlustur("3003","E", StringUtils.isBlank(iMap.getString("TCKN"))?iMap.getString("PASAPORT_NO"):iMap.getString("TCKN")));

		}
		return oMap;

	}

	private static byte[] decode64ByteArray(String textToDecode) throws Exception {

		byte[] decodedDocByteArray = null;
		decodedDocByteArray = Base64.decode(textToDecode);

		return decodedDocByteArray;
	}

	@GraymoundService("BNSPR_TRN3801_FOTO_YUKLE")
	public static GMMap fotoYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if ( tffBasvuru != null ){
				if(tffBasvuru.getDurumKod().equals("FOTO") ){
					tffBasvuru.setDurumKod(CreditCardTRN3802Services.ODEME);
				}
				else if(tffBasvuru.getDurumKod().equals("FOTO_EKSIK")){
					tffBasvuru.setDurumKod(CreditCardTRN3802Services.VERI_KONTROL);
				}
				else{
					CreditCardTffServices.raiseTffGMError("3016","E" );
				}
				
			}
			else{
				CreditCardTffServices.raiseTffGMError("2999","E",iMap.getString("TFF_BASVURU_NO") );
			}
			session.saveOrUpdate(tffBasvuru);
			session.flush();
			byte[] bytes = decode64ByteArray(iMap.getString("FOTO_BYTE_ARRAY"));
			String kimlikNo = iMap.getString("KIMLIK_NO");
			String basvuruNo = iMap.getString("TFF_BASVURU_NO");
			double fileSize = bytes.length;
			
			if (fileSize > MAX_SIZE * 1024 * 1024) {
				CreditCardTffServices.raiseTffGMError("3005","E",iMap.getString("KIMLIK_NO"),iMap.getString("TFF_BASVURU_NO") );
			}
			ImageInputStream iis = ImageIO.createImageInputStream(new ByteArrayInputStream(bytes));
			Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);

			ByteArrayInputStream bis = new ByteArrayInputStream(bytes);

			String sourceMimeType = URLConnection.guessContentTypeFromStream(bis);

			GMMap t = new GMMap();
			t.put("image/png", "png");
			t.put("image/jpeg", "jpg");
			String type = "jpg";
			if (t.getString(sourceMimeType).isEmpty()) {
				CreditCardTffServices.raiseTffGMError("3006","E",iMap.getString("KIMLIK_NO"),iMap.getString("TFF_BASVURU_NO") );
			}
			else{
				type = t.getString(sourceMimeType);
			}

			String kimlikNoLpad =  StringUtil.lPad(kimlikNo, 12);
			// Iterator<?> readers = ImageIO.getImageReadersByFormatName("jpg");

			// ImageIO is a class containing static methods for locating ImageReaders
			// and ImageWriters, and performing simple encoding and decoding.

			ImageReader reader = (ImageReader) readers.next();
		//	Object source = bis;
			// ImageInputStream iis = ImageIO.createImageInputStream(source);
			reader.setInput(iis, true);
			ImageReadParam param = reader.getDefaultReadParam();

			Image image = reader.read(0, param);
			// got an image file

			String folderPath = ROOT + File.separator + "files";
			String isWindows = "H";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {

			
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			
				
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
			try {
				isWindows =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "WINDOWS", BnsprType.STRING, "SISTEM"));
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			String[] sp = kimlikNoLpad.split("(?<=\\G.{3})");
			File klasor = null;
			
			Runtime runtime =Runtime.getRuntime ();
			

			                
			//folderPath = String.format("/%s/%s/%s/%s/%s/", folderPath,sp[0],sp[1],sp[2],kimlikNo);
			for (int i = 0; i < sp.length-1; i++) {
				folderPath = String.format("%s/%s", folderPath,sp[i]);
				klasor = new File(folderPath);
				if (!klasor.exists()){
					if ( isWindows.equals("E") )
						klasor.mkdir();
					else{
						String[] cmdLine = {"mkdir", folderPath};
		                Process p =runtime.exec ( cmdLine );
		                p.waitFor();
					}
				}
			}
			folderPath = String.format("%s/%s", folderPath,kimlikNo);
			klasor = new File(folderPath);
			if (!klasor.exists()){
				if ( isWindows.equals("E") )
					klasor.mkdir();
				else{
					String[] cmdLine = {"mkdir", folderPath};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
			}
			BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
			// bufferedImage is the RenderedImage to be written

			Graphics2D g2 = bufferedImage.createGraphics();
			g2.drawImage(image, null, null);

			File imageFile = new File(folderPath + File.separator + kimlikNo + "_" + basvuruNo + "." + type);
			ImageIO.write(bufferedImage, type, imageFile);
			
			
			oMap.put("RESPONSE", "2");
			oMap.put("RESPONSE_DATA", "BASARILI");

		}
		catch (Exception e) {
			oMap.put("RESPONSE",0);
			oMap.put("RESPONSE_DATA",CreditCardTffServices.errorMessageOlustur("3004","E", iMap.getString("KIMLIK_NO"),iMap.getString("TFF_BASVURU_NO") ) + e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_TCKN_KONTROL")
	public static GMMap tckNoKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// TCKN Kontrolu
			String tcKimlikNo = iMap.getString("TCK_NO");
			if (StringUtils.isNotBlank(tcKimlikNo) && "9".equals(tcKimlikNo.substring(0, 1))) {
				oMap.put("KONTROL_BASARILI_MI", CreditCardServicesUtil.HAYIR);
				CreditCardTffServices.raiseTffGMError("1033","E");
			}

			// Validasyon
			iMap.put("TC_KIMLIK_NO", tcKimlikNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", iMap));
			if ("0".equals(oMap.getString("SONUC"))) {
				oMap.put("KONTROL_BASARILI_MI", CreditCardServicesUtil.HAYIR);
				CreditCardTffServices.raiseTffGMError("456","E", tcKimlikNo);
			}

			oMap.put("KONTROL_BASARILI_MI", CreditCardServicesUtil.EVET);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_TFF_KPS_SORGULA")
	public static GMMap tffKpsSorgula(GMMap iMap) {
		GMMap oMap = new GMMap(), tMap = new GMMap(), iMap2 = new GMMap();
		try {
			iMap2 = new GMMap();
			iMap2.put("TCK_NO", iMap.getString("TCKN"));
		//	iMap2.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_KPS_SORGULA", iMap2));
			if (oMap.getString("RESPONSE").equals("1")) {
				return oMap;
			}
		/*	iMap2.put("KPS_AD", oMap.getString("AD1"));
			iMap2.put("KPS_IKINCI_AD", oMap.getString("AD2"));
			iMap2.put("KPS_SOYAD", oMap.getString("SOYAD"));
			iMap2.put("KPS_ANNE_AD", oMap.getString("ANNE_AD"));
			iMap2.put("KPS_BABA_AD", oMap.getString("BABA_AD"));
			iMap2.put("KPS_DOGUM_IL", oMap.getString("DOGUM_IL_KODU"));
			iMap2.put("KPS_DOGUM_YERI", oMap.getString("DOGUM_YERI"));
			iMap2.put("KPS_DOGUM_TARIHI", oMap.getString("DOGUM_TARIHI"));
			iMap2.put("KPS_CINSIYET", oMap.getString("CINSIYET"));
			iMap2.put("KPS_MEDENI_HAL", oMap.getString("MEDENI_HALI"));
			iMap2.put("KPS_KIZLIK_SOYAD", oMap.getString("KIZLIK_SOYAD"));
			iMap2.put("KPS_ANNE_SOYAD", oMap.getString("ANA_SOYAD"));
			iMap2.put("KPS_NUFUS_IL", oMap.getString("IL_KODU"));
			iMap2.put("KPS_NUFUS_ILCE", oMap.getString("ILCE_KODU"));
			iMap2.put("KPS_NUFUS_MAHALLE", oMap.getString("MAHALLE_KOY"));
			iMap2.put("KPS_CILT_NO", oMap.getString("CILT_KODU"));
			iMap2.put("KPS_AILE_SIRA_NO", oMap.getString("AILE_SIRA_NO"));
			iMap2.put("KPS_BIREY_SIRA_NO", oMap.getString("BIREY_SIRA_NO"));
			iMap2.put("KPS_VER_YER", oMap.getString("VERILDIGI_ILCE_KODU"));
			iMap2.put("KPS_NUFUS_VER_TAR", oMap.getString("VERILIS_TARIHI"));
			iMap2.put("KPS_ES_TCKN", oMap.getString("ES_TCKN"));
			iMap2.put("KPS_KIMLIK_SERI_NO", oMap.getString("KIMLIK_SERI_NO"));
			iMap2.put("KPS_KIMLIK_SIRA_NO", oMap.getString("KIMLIK_SIRA_NO"));
			iMap2.put("KPS_VERILIS_NEDENI", oMap.getString("VERILIS_NEDENI"));
			iMap2.put("KPS_KAYIP_CUZDAN_SERI_NO", oMap.getString("KAYIP_CUZDAN_SERI"));
			iMap2.put("KPS_KAYIP_CUZDAN_SIRA_NO", oMap.getString("KAYIP_CUZDAN_SIRA"));
			iMap2.put("KPS_VER_YER", oMap.getString("VERILDIGI_ILCE_ADI"));
			iMap2.put("18_YASINDA_MI", oMap.getString("18_YASINDA_MI"));
			iMap2.put("UYRUK_KOD", "TR");

		/*	if (oMap.getString("TFF_BASVURU_NO") == null) {

				tMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_BASVURU_NO", new GMMap()));
				oMap.put("BASVURU_NO", tMap.getString("ID"));
			}
			else {
				oMap.put("BASVURU_NO", oMap.getString("TFF_BASVURU_NO"));
			}
			if (oMap.getString("TRX_NO") == null) {
				tMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				oMap.put("TRX_NO", tMap.getString("TRX_NO"));
			}
			iMap2.put("TRX_NO", oMap.getString("TRX_NO"));
			iMap2.put("BASVURU_NO", oMap.getString("BASVURU_NO"));
			iMap2.put("DURUM_KOD", "BASVURU");*/
		//	GMServiceExecuter.execute("BNSPR_TRN3801_SAVE_TEMP", iMap2);

			tMap = new GMMap();
			tMap.put("RESPONSE", "2");
			tMap.put("RESPONSE_DATA", "BASARILI");

			tMap.put("TFF_BASVURU_NO", oMap.getString("BASVURU_NO"));
			tMap.put("MUSTERI_BILGILERI", 0, "ADI", oMap.getString("AD1"));
			tMap.put("MUSTERI_BILGILERI", 0, "IKINCI_ADI", oMap.getString("AD2"));
			tMap.put("MUSTERI_BILGILERI", 0, "SOYADI", oMap.getString("SOYAD"));
			tMap.put("MUSTERI_BILGILERI", 0, "DOGUM_TARIHI", new SimpleDateFormat("yyyyMMdd").format(oMap.getDate("DOGUM_TARIHI")));
			tMap.put("MUSTERI_BILGILERI", 0, "BABA_ADI", oMap.getString("BABA_AD"));
			tMap.put("MUSTERI_BILGILERI", 0, "ANNE_ADI", oMap.getString("ANNE_AD"));
			tMap.put("MUSTERI_BILGILERI", 0, "CINSIYET", oMap.getString("CINSIYET"));
			tMap.put("MUSTERI_BILGILERI", 0, "MEDENI_DURUMU", oMap.getString("MEDENI_HALI"));
			tMap.put("MUSTERI_BILGILERI", 0, "NUFUS_VERILIS_TARIHI", new SimpleDateFormat("yyyyMMdd").format(oMap.getDate("VERILIS_TARIHI")));
			tMap.put("MUSTERI_BILGILERI", 0, "ES_TCKN", oMap.getString("ES_TCKN"));
			tMap.put("MUSTERI_BILGILERI", 0, "DOGUM_YERI", oMap.getString("DOGUM_YERI"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			//CreditCardTffServices.raiseTffGMError("3007",!(String.valueOf(iMap.getString("TCKN")).isEmpty())?iMap.getString("TCKN"):iMap.getString("PASAPORT"));
		}
		return tMap;
	}

	@GraymoundService("BNSPR_TRN3801_KPS_SORGULA")
	public static GMMap kpsSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		boolean kpsroguYap = true;
		if (iMap.getString("TFF_BASVURU_NO") != null && !iMap.getString("TFF_BASVURU_NO").isEmpty()) {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuruKimlik != null) {
				oMap.put("TFF_BASVURU_NO", tffBasvuruKimlik.getBasvuruNo());
				kpsroguYap = false;
				oMap.put("AD1", tffBasvuruKimlik.getAd());
				oMap.put("AD2", tffBasvuruKimlik.getIkinciAd());
				oMap.put("SOYAD", tffBasvuruKimlik.getSoyad());
				oMap.put("ANNE_AD", tffBasvuruKimlik.getAnneAdi());
				oMap.put("BABA_AD", tffBasvuruKimlik.getBabaAd());
				oMap.put("DOGUM_IL_KODU", tffBasvuruKimlik.getDogumYeri());
				oMap.put("DOGUM_YERI", tffBasvuruKimlik.getDogumYeri());
				oMap.put("DOGUM_TARIHI", tffBasvuruKimlik.getDogumTar());
				oMap.put("CINSIYET", tffBasvuruKimlik.getCinsiyet());
				oMap.put("MEDENI_HALI", tffBasvuruKimlik.getMedeniHal());
				oMap.put("KIZLIK_SOYAD", tffBasvuruKimlik.getAnneKizlik());
				oMap.put("ANA_SOYAD", tffBasvuruKimlik.getAnneKizlik());
				oMap.put("IL_KODU", tffBasvuruKimlik.getNufusIlKod());
				oMap.put("ILCE_KODU", tffBasvuruKimlik.getNufusIlceKod());
				oMap.put("MAHELLE_KOY", tffBasvuruKimlik.getMahalleKoy());
				oMap.put("CILT_KODU", tffBasvuruKimlik.getCiltNo());
				oMap.put("AILE_SIRA_NO", tffBasvuruKimlik.getAileSiraNo());
				oMap.put("BIREY_SIRA_NO", tffBasvuruKimlik.getBireySiraNo());
				oMap.put("VERILIS_TARIHI", tffBasvuruKimlik.getNufusVerTar());
				oMap.put("ES_TCKN", tffBasvuruKimlik.getEsTcKimlikNo());
				oMap.put("KIMLIK_SERI_NO", tffBasvuruKimlik.getKimlikSeriNo());
				oMap.put("KIMLIK_SIRA_NO", tffBasvuruKimlik.getKimlikSiraNo());
				oMap.put("VERILIS_NEDENI", tffBasvuruKimlik.getNufusVerNedeni());
				oMap.put("KAYIP_CUZDAN_SERI", tffBasvuruKimlik.getKayipKimlikSeriNo());
				oMap.put("KAYIP_CUZDAN_SIRA", tffBasvuruKimlik.getKayipKimlikSiraNo());
				oMap.put("VERILDIGI_ILCE_ADI", tffBasvuruKimlik.getNufusVerYer());
				oMap.put("TFF_BASVURU_NO", tffBasvuruKimlik.getBasvuruNo());
				oMap.put("TCKNO_IN", iMap.getString("TCKN"));
				oMap.put("TCKNO_OUT", iMap.getString("TCKN"));
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

				String strDogumTarihi = dateFormat.format(tffBasvuruKimlik.getDogumTar());
				if (StringUtils.isNotBlank(strDogumTarihi)) {
					DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyyMMdd");

					DateTime dogumTarihi = new DateTime(formatter.parseDateTime(strDogumTarihi));
					DateTime simdi = new DateTime(Calendar.getInstance().getTime());

					if (Years.yearsBetween(dogumTarihi, simdi).getYears() >= 18) {
						oMap.put("18_YASINDA_MI", CreditCardServicesUtil.EVET);
					}
					else {
						oMap.put("18_YASINDA_MI", CreditCardServicesUtil.HAYIR);
					}
					oMap.put("KPS_YASI",Years.yearsBetween(dogumTarihi, simdi).getYears());
				}
				else {
					oMap.put("18_YASINDA_MI", CreditCardServicesUtil.EVET);
				}

				oMap.put("UYRUK_KOD", "TR");
			}

		}
		if (kpsroguYap) {
			try {
				// TCKN Kontrolu
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_TCKN_KONTROL", iMap));

				// KPS yap
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_KPS_SORGULA_FIRST_STEP", iMap));
				if (!oMap.getString("RESPONSE").equals("2")) {
					oMap.put("RESPONSE", "1");
					oMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
					return oMap;
				}
				// Cinsiyet Donusumu
				String cinsiyet = oMap.getString("CINSIYET");
				if (StringUtils.isNotBlank(cinsiyet)) {
					oMap.remove("CINSIYET");
					if ("Erkek".equals(cinsiyet)) {
						oMap.put("CINSIYET", "E");
					}
					else if ("Kad�n".equals(cinsiyet)) {
						oMap.put("CINSIYET", "K");
					}
				}

				// Medeni Hal
				String medeniHal = oMap.getString("MEDENI_HALI");
				if (StringUtils.isNotBlank(medeniHal)) {
					oMap.remove("MEDENI_HALI");
					if ("E".equals(medeniHal.substring(0, 1))) {
						oMap.put("MEDENI_HALI", "2");
					}
					else
						oMap.put("MEDENI_HALI", "1");
				}

				// KPS basarili ise 18 yas kontrolu yap
				if (CreditCardServicesUtil.EVET.equals(oMap.getString("KPS_BASARILI_MI"))) {
					String strDogumTarihi = oMap.getString("DOGUM_TARIHI");

					if (StringUtils.isNotBlank(strDogumTarihi)) {
						DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyyMMdd");
						DateTime dogumTarihi = new DateTime(formatter.parseDateTime(strDogumTarihi));
						DateTime simdi = new DateTime(Calendar.getInstance().getTime());

						if (Years.yearsBetween(dogumTarihi, simdi).getYears() >= 18) {
							oMap.put("18_YASINDA_MI", CreditCardServicesUtil.EVET);
						}
						else {
							oMap.put("18_YASINDA_MI", CreditCardServicesUtil.HAYIR);
						}
						oMap.put("KPS_YASI",Years.yearsBetween(dogumTarihi, simdi).getYears());
					}
					else {
						oMap.put("18_YASINDA_MI", CreditCardServicesUtil.EVET);
					}
				}
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		oMap.put("RESPONSE", "2");
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_GET_BASVURU_NO")
	public static GMMap getBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("ID", new BigDecimal(DALUtil.getResult("select SEQ_TFF_BASVURU.nextval from dual")));

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_SAVE_BASVURU")
	public static GMMap saveBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		//TffBasvuruTx tffBasvuruTx = new TffBasvuruTx();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			BigDecimal musteriNo = null;
			String euptId ="";
			TffBasvuruTx tffBasvuruTx = (TffBasvuruTx) session.get(TffBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruTx == null){
				tffBasvuruTx = new TffBasvuruTx();
				euptId = iMap.getString("EUPT_USER_ID");
				musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			}
			else{
				musteriNo = tffBasvuruTx.getMusteriNo();
				euptId = tffBasvuruTx.getEuptUserId();
			}
			if (tffBasvuru == null) {
				tffBasvuruTx.setDurumKod(StringUtils.isNotBlank(iMap.getString("DURUM_KODU"))?iMap.getString("DURUM_KODU") : "BASVURU");
			}
			else{
				musteriNo = tffBasvuru.getMusteriNo();
				euptId = tffBasvuru.getEuptUserId();
				
				if ( tffBasvuru.getDurumKod().equals("FOTO") ){
					tffBasvuruTx.setDurumKod("FOTO");
				}
				else if ( tffBasvuru.getDurumKod().equals("BASVURU") ){
					tffBasvuruTx.setDurumKod(StringUtils.isNotBlank(iMap.getString("DURUM_KODU"))?iMap.getString("DURUM_KODU") : "FOTO");
				}
				/*else if ( tffBasvuru.getDurumKod().equals("ODEME") ){
					tffBasvuruTx.setDurumKod("VERI_KONTROL");
				}*/
				else
					tffBasvuruTx.setDurumKod(tffBasvuru.getDurumKod());
			}
			tffBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tffBasvuruTx.setKartNo(null);
			tffBasvuruTx.setKkBasvuruNo(null);
			tffBasvuruTx.setSessionIp(iMap.getString("CLIENT_SESSION_ID"));
			if ( StringUtils.isNotBlank(iMap.getString("UYE_NO")) )
				tffBasvuruTx.setTffUyeNo(iMap.getBigDecimal("UYE_NO"));
			if ( StringUtils.isNotBlank(iMap.getString("KULUP")) )
				tffBasvuruTx.setTakim(iMap.getString("KULUP"));
			tffBasvuruTx.setTcKimlikNo(iMap.getString("TC_TCKN"));
			tffBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			if ( StringUtils.isNotBlank(iMap.getString("KULUP_URUN")) ){
				tffBasvuruTx.setUrun(iMap.getString("KULUP_URUN"));
			}
			if ( StringUtils.isNotBlank(iMap.getString("KULUP_URUN_SAHIP")) ){
				tffBasvuruTx.setUrunSahipKodu(iMap.getString("KULUP_URUN_SAHIP"));
			}
			if ( StringUtils.isNotBlank(iMap.getString("KURYE_TIPI")) )
				tffBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
			tffBasvuruTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			
			if (iMap.containsKey("URUN_ID")){
				tffBasvuruTx.setUrunId(iMap.getBigDecimal("URUN_ID"));
			}
			;

			String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
			tffBasvuruTx.setKanalKod(kanalKodu);

			tffBasvuruTx.setMusteriNo(musteriNo);
			tffBasvuruTx.setEuptUserId(euptId);
			if ( StringUtils.isNotBlank(iMap.getString("FRAUD_MU")) && iMap.getBoolean("FRAUD_MU") ){
				tffBasvuruTx.setDurumKod("FRAUD");
			}

			if (StringUtils.isNotBlank(iMap.getString("EMAIL1")) && StringUtils.isNotBlank(iMap.getString("EMAIL2"))) {
				tffBasvuruTx.setEPosta(iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
			}
			else if (StringUtils.isNotBlank(iMap.getString("EMAIL"))) {
				tffBasvuruTx.setEPosta(iMap.getString("EMAIL"));
			}
			if ( StringUtils.isNotBlank(iMap.getString("KART_TIPI")) ){
				tffBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
			}
			else{
					tffBasvuruTx.setKartTipi("P");
			}
			if ("BASVURU".equals( tffBasvuruTx.getDurumKod()) && tffBasvuru== null ){
				tffBasvuru = new TffBasvuru();
				tffBasvuru.setBasvuruNo(tffBasvuruTx.getBasvuruNo());
				tffBasvuru.setCalismaSekli(tffBasvuruTx.getCalismaSekli());
				tffBasvuru.setDurumKod(tffBasvuruTx.getDurumKod());
				tffBasvuru.setEPosta(tffBasvuruTx.getDurumKod());
				tffBasvuru.setEuptUserId(tffBasvuruTx.getEuptUserId());
				tffBasvuru.setKanalKod(tffBasvuruTx.getKanalKod());
				tffBasvuru.setKartTipi(tffBasvuruTx.getKartTipi());
				tffBasvuru.setMusteriNo(tffBasvuruTx.getMusteriNo());
				tffBasvuru.setSessionIp(tffBasvuruTx.getSessionIp());
				tffBasvuru.setTakim(tffBasvuruTx.getTakim());
				tffBasvuru.setTcKimlikNo(tffBasvuruTx.getTcKimlikNo());
				tffBasvuru.setUrunId(tffBasvuruTx.getUrunId());
				session.saveOrUpdate(tffBasvuru);
				session.flush();
				
			}
			session.saveOrUpdate(tffBasvuruTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3801_TFF_KARA_LISTE_EKLE")
	public static GMMap karaListeyeEkle(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String procStr = "{call BNSPR.PKG_TRN3801.tff_karaliste_ekle (?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[14];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_TEL");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_ID");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("KILIT_SEBEP");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_IP");
			
			i = 0;
			Object[] outputValues = new Object[6];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "KARA_LISTE_ID";


			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_URUN_LISTE_SORGULA")
	public static GMMap urunListeSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();


		try {
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_basvuru_urun_bilgileri (?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			i = 0;
			Object[] outputValues = new Object[6];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "URUN_TIPI";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "URUN_SAHIBI";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "URUN_SAHIBI_TIPI";


			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			CreditCardTffServices.raiseTffGMError("3003","E", StringUtils.isBlank(iMap.getString("TCKN"))?iMap.getString("PASAPORT_NO"):iMap.getString("TCKN") );
		}
		return oMap;

			
		
	}

	@GraymoundService("BNSPR_TRN3801_OTP_KONTROL")
	public static GMMap tffOtpKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_BASVURU_OTP_DOGRULAMA (?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[16];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("OTP_CEVAP");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KANAL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("OTP_ID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_IP");
			
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TRN3801_SMS_GONDER")
	public static GMMap tffSMSGonder(GMMap iMap) {

		GMMap otpMap = new GMMap();
		GMMap oMap = new GMMap();
		otpMap.put("CONTENT", iMap.getString("GIDEN_MESAJ"));
		String header = StringUtils.isNotEmpty(iMap.getString("HEADER"))?iMap.getString("HEADER"):conf.getProperty("passolig-info-sms-header");
		otpMap.put("HEADER", header);
		otpMap.put("MSISDN","+" +  iMap.getString("CEP_NO"));
		boolean mesajTipiSms = false;
		
		GMMap paramMap = CreditCardServicesUtil.getParameterList("RESULTS", "SMS_HEADER_TANIM");
        for(int i = 0 ; i< paramMap.getSize("RESULTS"); i++){   
        	if (header.equals(conf.getProperty(paramMap.getString("RESULTS", i, "NAME")))){
        		mesajTipiSms = true;
        		}
        }
       		
		if (mesajTipiSms){
			oMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", otpMap));
			oMap.put("RESPONSE", "2");
			oMap.put("BNSPR_LOG_ID", "1");
		}
		else{
			oMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_OTP", otpMap));
		}
		
		
		return oMap;

	}

	@GraymoundService("BNSPR_TRN3801_OTP_GONDER")
	public static GMMap tffOtpGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		try {
			GMMap otpMap = GMServiceExecuter.call("BNSPR_TRN3801_OTP_GONDER_KONTROL", iMap);
			if (otpMap.getString("RESPONSE").equals("2")) {
				String otpValue = OtpGenerator.generate();
				GMMap otpMessageMap = new GMMap();
				otpMessageMap.put("MESSAGE_NO", iMap.getString("GIDEN_MESAJ_KOD"));
				otpMessageMap.put("P1", BnsprOceanCommonFunctions.otpValueforCodec(otpValue));
				otpMessageMap.put("P2", "");
				otpMessageMap.put("P3", "");
				otpMessageMap.put("P4", "");
				otpMessageMap.put("P5", KANAL);
				otpMessageMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", otpMessageMap));
				otpMap.put("CONTENT", otpMessageMap.getString("ERROR_MESSAGE"));
				otpMap.put("HEADER",conf.getProperty("tff-sms-header"));
				otpMap.put("MSISDN", iMap.getString("CEP_NO"));

				
				oMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_OTP", otpMap));

				if (oMap.getString("RESPONSE").equals("2")) {
					GMMap xMap = new GMMap().put("TABLE_NAME", "OTP_ID");
					BigDecimal otpId;
					if (iMap.getString("OTP_ID").isEmpty())
						otpId = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
					else
						otpId = iMap.getBigDecimal("OTP_ID");
					TffBasvuruGidenOtp basvuruGidenOtp = new TffBasvuruGidenOtp();
					basvuruGidenOtp.setCepTelNo(iMap.getString("CEP_NO"));
					basvuruGidenOtp.setDenemeSayisi(BigDecimal.ZERO);
					basvuruGidenOtp.setDurum("B");
					basvuruGidenOtp.setKimlikNo(StringUtils.isNotBlank(iMap.getString("TCKN"))? iMap.getString("TCKN") : iMap.getString("PASAPORT"));
					basvuruGidenOtp.setOtpValue(otpValue);
					basvuruGidenOtp.setSmsRefId(oMap.getString("BNSPR_LOG_ID"));

					basvuruGidenOtp.setId(otpId);
					session.saveOrUpdate(basvuruGidenOtp);
					session.flush();
					oMap = new GMMap();
					oMap.put("OTP_ID", otpId + "-" + otpValue);
					oMap.put("RESPONSE", "2");
					//oMap.put("RESPONSE_DATA", iMap.getString("CEP_NO") + " NUMARAYA OTP GONDERILDI");
				}
				else {
					
					oMap.put("RESPONSE", "0");
					oMap.put("RESPONSE_DATA", CreditCardTffServices.errorMessageOlustur("3012", "E",iMap.getString("CEP_NO")));
				}
			}
			else {
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", otpMap.getString("RESPONSE_DATA"));
			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA",e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_OTP_GONDER_KONTROL")
	public static GMMap otpGonderKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_BASVURU_OTP_GONDER_KONTROL (?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[14];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("LOGIN_MI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KANAL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_IP");
			
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
		}
		catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA","E-0001:" + e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_KK_KISA_BASVURU")
	public static GMMap tffKKKisaBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap iMap2 = new GMMap();
			iMap2.put("TCK_NO", iMap.getString("TCKN"));
			iMap2.put("CEP_NO", iMap.getString("CEP_TEL_KOD") + iMap.getString("CEP_TEL_NO"));
			iMap2.put("CEP_TEL_KOD", iMap.getString("CEP_TEL_KOD"));
			iMap2.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
			iMap2.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
			iMap2.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		
			iMap2.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_KISA_BASVURU_OLUSTUR", iMap2));
			oMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
			TffKrediKartiBasvuru krediKartiBasvuru = (TffKrediKartiBasvuru) session.get(TffKrediKartiBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			
			
			if (CreditCardServicesUtil.EVET.equals(oMap.getString("BASVURU_OLUSTU_MU"))) {
				krediKartiBasvuru.setKkBasvuruNo(oMap.getBigDecimal("BASVURU_NO"));
				session.save(krediKartiBasvuru);
				session.flush();
				
				if (CreditCardServicesUtil.EVET.equals(oMap.getString("BASVURU_GECERLI_MI"))) {
					oMap.put("RESPONSE",CreditCardServicesUtil.RESPONSE_BASARILI);
				} else {
					oMap.put("RESPONSE",CreditCardServicesUtil.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", StringUtils.isNotEmpty(oMap.getString("MESSAGE"))?oMap.getString("MESSAGE"):oMap.getString("RESPONSE_DATA"));
				}
			}
			else{
				oMap.put("RESPONSE",CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", StringUtils.isNotEmpty(oMap.getString("MESSAGE"))?oMap.getString("MESSAGE"):oMap.getString("RESPONSE_DATA"));
			}
		
			

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA","E-0001:" + e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_KK_TAM_BASVURU")
	public static GMMap tffKKTamBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			
			GMMap kkMap = new GMMap();
			kkMap.put("TCK_NO", iMap.getString("TCKN"));
			kkMap.put("CEP_NO", iMap.getString("CEP_TEL_KOD") + iMap.getString("CEP_TEL_NO"));
			kkMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
			kkMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			kkMap.put("TRX_NO", iMap.getString("TRX_NO"));
			kkMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_TFF_TAM_BASVURU", kkMap));
			
	
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE")) || (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) && CreditCardServicesUtil.HAYIR.equals(oMap.getString("DEVAM")) )){
				oMap.put("RESPONSE",CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", oMap.getString("MESSAGE"));
			}
			else{
				oMap.put("RESPONSE",CreditCardServicesUtil.RESPONSE_BASARILI);
			}
			oMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));


		}
		catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA","E-0001:" + e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_TFF_SON_TRX_BUL")
	public static GMMap tffSonTrxNoBul(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.sonTrxNoAl (?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TFF_BASVURU_NO");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "TRX_NO";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception ex){
			throw ExceptionHandler.convertException(ex);
		}
		
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_TRN3801_TFF_TCKN_KARA_LISTE_KONTROL")
	public static GMMap tcknKaraListeKontrol(GMMap iMap){
		//procedure tff_tckn_karaliste_kontrol(ps_tckn in number, PS_PASAPORT_NO in varchar2,PS_CEP_TEL_NO in varchar2, PS_response out number, ps_response_data out varchar2) is
		GMMap oMap = new GMMap();
		
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.tff_tckn_karaliste_kontrol (?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[6];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] =iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD")+ iMap.getString("CEP_NUMARA");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception ex){
			throw ExceptionHandler.convertException(ex);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3801_TFF_BASVURU_YAP")
	public static GMMap tffBasvuruYap(GMMap iMap) {
		GMMap iMap2 = new GMMap(), oMap = new GMMap(), tMap = new GMMap(), customerContactMap = new GMMap();
		
		try {
			boolean yeniBasvuruMu = StringUtils.isEmpty(iMap.getString("YENI_BASVURU"))?false:iMap.getBoolean("YENI_BASVURU");
			if ( yeniBasvuruMu){
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_TFF_TCKN_KARA_LISTE_KONTROL", iMap));
			if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) )
				return oMap;
			
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_AKTIF_BASVURU_VAR_MI", iMap));
			
			if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) )
				return oMap;
			GMMap karaListeMap = new GMMap();
			if ( CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE") )){
				boolean  fraudMu=false;

				tMap = new GMMap();
				tMap.put("TCK_NO", iMap.getString("TCKN"));
				tMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
				tMap.put("YENI_BASVURU",yeniBasvuruMu);
				String musteriNo = "";
				String kkAlabilirMi = CreditCardServicesUtil.HAYIR;
				if (iMap.getString("UYRUK").equals("TR")) {
					
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_KPS_SORGULA", tMap));
					if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
						return oMap;
					}
					
					int minBasvuruYasi = 7;
					try {
						String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
						minBasvuruYasi =  Integer.parseInt(String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING,"MIN_YAS", BnsprType.STRING, "BASVURU_KRITER")));

						
					}
					catch (Exception e) {
						minBasvuruYasi = 7;
					}
					if ( StringUtils.isNotEmpty(oMap.getString("KPS_YASI")) && oMap.getInt("KPS_YASI")< minBasvuruYasi ) {
						String errorMessage = CreditCardTffServices.errorMessageOlustur("3049","E", "7");
						oMap.put("RESPONSE", 1);
						oMap.put("RESPONSE_DATA", errorMessage);

						return oMap;
					
					}
					
					String verTarihCheck = "H";
					try {
						String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
						verTarihCheck =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, iMap.getString("SOURCE"), BnsprType.STRING, "VER_TAR_CHECK"));

						
					}
					catch (Exception e) {
						verTarihCheck = "H";
					}
					if (StringUtils.isNotEmpty(iMap.getString("NUFUS_VER_TAR")))
						iMap.put("NUFUS_VER_TAR_2", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					if ("E".equals(verTarihCheck) &&  iMap.getString("NUFUS_VER_TAR_2") != null && oMap.getString("VERILIS_TARIHI") != null && !(iMap.getDate("NUFUS_VER_TAR_2").equals(oMap.getDate("VERILIS_TARIHI")))) {
						
						karaListeMap.put("TCKN", iMap.getString("TCKN"));
						karaListeMap.put("CEP_TEL", iMap.getString("CEP_ULKE_KOD") +iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
						karaListeMap.put("ISLEM_ID", iMap.getString("ISLEM_ID"));
						karaListeMap.put("KILIT_SEBEP", CreditCardTffServices.TFF_KARA_LISTE_TCKN_VER_TARIH);
						karaListeMap.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
						karaListeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
						karaListeMap = GMServiceExecuter.call("BNSPR_TRN3801_TFF_KARA_LISTE_EKLE", karaListeMap);
						if ( CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(karaListeMap.getString("RESPONSE")) ){
							return karaListeMap;
						}
						fraudMu =true;
					}
					if (!fraudMu && yeniBasvuruMu){
						/*START CREATE CUSTOMER CONTACT*/
						customerContactMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
						customerContactMap.put("ADI", oMap.getString("AD1"));
						customerContactMap.put("SOYADI", oMap.getString("SOYAD"));
						customerContactMap.put("ONCEKI_SOYADI", oMap.getString("KIZLIK_SOYAD"));
						customerContactMap.put("ANNE_ADI", oMap.getString("ANNE_AD"));
						customerContactMap.put("BABA_ADI", oMap.getString("BABA_AD"));
						customerContactMap.put("IKINCI_ADI", oMap.getString("AD2"));
						customerContactMap.put("CINSIYET", oMap.getString("CINSIYET"));
						customerContactMap.put("MEDENI_HAL", oMap.getString("MEDENI_HALI"));
						customerContactMap.put("DOGUM_YERI", oMap.getString("DOGUM_YERI"));
						customerContactMap.put("NUFUS_IL_KOD", oMap.getString("IL_KODU"));
						customerContactMap.put("NUFUS_ILCE_KOD", oMap.getString("ILCE_KODU"));
						customerContactMap.put("KIMLIK_SERI_NO", oMap.getString("KIMLIK_SERI_NO"));
						customerContactMap.put("KIMLIK_SIRA_NO", oMap.getString("KIMLIK_SIRA_NO"));
						customerContactMap.put("NUFUS_VERILIS_TARIHI", oMap.getString("VERILIS_TARIHI"));
						customerContactMap.put("NUF_VERILIS_NEDENI", oMap.getString("VERILIS_NEDENI"));
						customerContactMap.put("NUF_VERILDIGI_YER",  oMap.getString("VERILDIGI_ILCE_ADI"));
						customerContactMap.put("NUFUS_CILT_NO", oMap.getString("CILT_KODU"));
						customerContactMap.put("NUFUS_AILE_SIRA_NO", oMap.getString("AILE_SIRA_NO"));
						customerContactMap.put("NUFUS_SIRA_NO", oMap.getString("BIREY_SIRA_NO"));
						customerContactMap.put("NUFUS_MAHALLE", oMap.getString("MAHALLE_KOY"));
						customerContactMap.put("KANAL_ALT_KOD", "");
						customerContactMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
						
						customerContactMap.put("CEP_TEL_KOD", iMap.getString("CEP_ALAN_KOD"));
						customerContactMap.put("CEP_TEL_NO", iMap.getString("CEP_ALAN_NUMARA"));
		
						customerContactMap.put("DOGUM_IL_KOD", oMap.getString("DOGUM_IL_KODU"));
						customerContactMap.put("DOGUM_TARIHI", oMap.getString("DOGUM_TARIHI"));
						
						customerContactMap.put("TCKNO_IN", iMap.getString("TCKN"));
						customerContactMap.put("TCKNO_OUT", iMap.getString("TCKN"));
					 		   
						
						customerContactMap.put("ADRES_TIPI",iMap.getString("ADRES_TIPI"));
						customerContactMap.put("ADRES_IL_KOD",iMap.getString("UAVT_IL_KOD"));
						customerContactMap.put("ADRES_ILCE_KOD",iMap.getString("UAVT_ILCE_KOD"));
						customerContactMap.put("ACIK_ADRES",iMap.getString("UAVT_ADRES_ACIKLAMA"));
		
						customerContactMap.put("CEP_NUMARA",iMap.getString("CEP_NUMARA"));
						customerContactMap.put("CEP_ALAN_KOD",iMap.getString("CEP_ALAN_KOD"));
						customerContactMap.put("CEP_ULKE_KOD",iMap.getString("CEP_ULKE_KOD"));
						customerContactMap.put("UYRUK",iMap.getString("UYRUK"));
						customerContactMap.put("EPOSTA", iMap.getString("EMAIL"));
						customerContactMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
						customerContactMap.put("TCKN", iMap.getString("TCKN"));
						customerContactMap.putAll(GMServiceExecuter.call("BNSPR_TRN3801_SAVE_KONTAK_MUSTERI_GERCEK", customerContactMap));
						
						musteriNo = customerContactMap.getString("MUSTERI_NO");
					}
					/*END CREATE CUSTOMER CONTACT*/
	
					iMap2.put("MUSTERI_NO", musteriNo);
					iMap2.put("KPS_AD", oMap.getString("AD1"));
					iMap2.put("TCK_NO", iMap.getString("TCKN"));
					iMap2.put("KPS_IKINCI_AD", oMap.getString("AD2"));
					iMap2.put("KPS_SOYAD", oMap.getString("SOYAD"));
					iMap2.put("KPS_ANNE_AD", oMap.getString("ANNE_AD"));
					iMap2.put("KPS_BABA_AD", oMap.getString("BABA_AD"));
					iMap2.put("KPS_DOGUM_IL", oMap.getString("DOGUM_IL_KODU"));
					iMap2.put("KPS_DOGUM_YERI", oMap.getString("DOGUM_YERI"));
					iMap2.put("KPS_DOGUM_TARIHI", oMap.getString("DOGUM_TARIHI"));
					iMap2.put("KPS_CINSIYET", oMap.getString("CINSIYET"));
					iMap2.put("KPS_MEDENI_HAL", oMap.getString("MEDENI_HALI"));
					iMap2.put("KPS_KIZLIK_SOYAD", oMap.getString("KIZLIK_SOYAD"));
					iMap2.put("KPS_ANNE_SOYAD", oMap.getString("ANA_SOYAD"));
					iMap2.put("KPS_NUFUS_IL", oMap.getString("IL_KODU"));
					iMap2.put("KPS_NUFUS_ILCE", oMap.getString("ILCE_KODU"));
					iMap2.put("KPS_NUFUS_MAHALLE", oMap.getString("MAHALLE_KOY"));
					iMap2.put("KPS_CILT_NO", oMap.getString("CILT_KODU"));
					iMap2.put("KPS_AILE_SIRA_NO", oMap.getString("AILE_SIRA_NO"));
					iMap2.put("KPS_BIREY_SIRA_NO", oMap.getString("BIREY_SIRA_NO"));
					iMap2.put("KPS_NUFUS_VER_TAR", oMap.getString("VERILIS_TARIHI"));
					iMap2.put("KPS_ES_TCKN", oMap.getString("ES_TCKN"));
					iMap2.put("KPS_KIMLIK_SERI_NO", oMap.getString("KIMLIK_SERI_NO"));
					iMap2.put("KPS_KIMLIK_SIRA_NO", oMap.getString("KIMLIK_SIRA_NO"));
					iMap2.put("KPS_VERILIS_NEDENI", oMap.getString("VERILIS_NEDENI"));
					iMap2.put("KPS_KAYIP_CUZDAN_SERI_NO", oMap.getString("KAYIP_CUZDAN_SERI"));
					iMap2.put("KPS_KAYIP_CUZDAN_SIRA_NO", oMap.getString("KAYIP_CUZDAN_SIRA"));
					iMap2.put("KPS_VER_YER", oMap.getString("VERILDIGI_ILCE_ADI"));
					iMap2.put("18_YASINDA_MI", oMap.getString("18_YASINDA_MI"));
					if (  oMap.getString("18_YASINDA_MI").equals(CreditCardServicesUtil.EVET)){
						kkAlabilirMi = CreditCardServicesUtil.EVET;
					}
					
					iMap2.put("DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
					if (StringUtils.isNotEmpty(iMap.getString("NUFUS_VER_TAR")))
						iMap2.put("NUFUS_VER_TAR", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					iMap2.put("TC_TCKN", iMap.getString("TCKN"));
				}
				else {
					
					iMap2.put("YABANCI_AD", iMap.getString("WEB_ADI"));
					iMap2.put("YABANCI_IKINCI_AD", iMap.getString("WEB_IKINCI_ADI"));
					iMap2.put("YABANCI_SOYAD", iMap.getString("WEB_SOYADI"));
					iMap2.put("YABANCI_DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
					
					customerContactMap.put("PASAPORT_NO", iMap.getString("PASAPORT_NO"));
					customerContactMap.put("ADI", iMap.getString("WEB_ADI"));
					customerContactMap.put("SOYADI", iMap.getString("WEB_SOYADI"));
					customerContactMap.put("DOGUM_TARIHI", oMap.getString("WEB_DOGUM_TARIHI"));
					customerContactMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
		            
						   		
					customerContactMap.put("ADRES_TIPI",iMap.getString("ADRES_TIPI"));
					customerContactMap.put("ADRES_IL_KOD",iMap.getString("UAVT_IL_KOD"));
					customerContactMap.put("ADRES_ILCE_KOD",iMap.getString("UAVT_ILCE_KOD"));
					customerContactMap.put("ACIK_ADRES",iMap.getString("UAVT_ADRES_ACIKLAMA"));
	
					customerContactMap.put("CEP_NUMARA",iMap.getString("CEP_NUMARA"));
					customerContactMap.put("CEP_ALAN_KOD",iMap.getString("CEP_ALAN_KOD"));
					customerContactMap.put("CEP_ULKE_KOD",iMap.getString("CEP_ULKE_KOD"));
					customerContactMap.put("UYRUK",iMap.getString("UYRUK"));
					customerContactMap.put("EPOSTA",iMap.getString("EMAIL"));
					customerContactMap.putAll(GMServiceExecuter.call("BNSPR_TRN3801_SAVE_KONTAK_MUSTERI_GERCEK", customerContactMap));
					musteriNo = customerContactMap.getString("MUSTERI_NO");
					iMap2.put("MUSTERI_NO", musteriNo);
				}
	
				
				if (iMap.getString("TFF_BASVURU_NO") == null) {
					tMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_BASVURU_NO", new GMMap()));
					iMap2.put("BASVURU_NO", tMap.getString("ID"));

	
				}
				else {
					iMap2.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
				}
				iMap2.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
				iMap2.put("DIL", iMap.getString("DIL"));
				iMap2.put("SOURCE", iMap.getString("SOURCE"));
				iMap2.put("DURUM_KODU","FOTO");
				iMap2.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
				iMap2.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
				iMap2.put("UYRUK_KOD", iMap.getString("UYRUK"));
				iMap2.put("PASAPORT_NO", iMap.getString("PASAPORT_NO"));

				iMap2.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
				iMap2.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
				iMap2.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
			
				iMap2.put("EMAIL", iMap.getString("EMAIL"));
				iMap2.put("KULUP", iMap.getString("KULUP"));
				iMap2.put("CEP_TEL", iMap.getString("CEP_ULKE_KOD") +iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
				iMap2.put("ISLEM_ID", iMap.getString("ISLEM_ID"));
				if (StringUtils.isNotBlank( iMap.getString("KULUP_URUN")) ){
					iMap2.put("DURUM_KODU","FOTO");

					iMap2.put("TRX_SONLANDIR", true);
					StringTokenizer stringTokenizer = new StringTokenizer(iMap.getString("KULUP_URUN"),"-");
					iMap2.put("KULUP_URUN_SAHIP",stringTokenizer.nextToken());
					if ( stringTokenizer.hasMoreTokens())
						iMap2.put("KULUP_URUN",stringTokenizer.nextToken());
				}
				else{
					iMap2.put("DURUM_KODU","BASVURU");
					iMap2.put("TRX_SONLANDIR", false);
				}
				
				iMap2.put("FRAUD_MU", fraudMu);
				iMap2.put("ADRES_TIPI", iMap.getString("ADRES_TIPI"));
				iMap2.put("ADRES_IL_KOD", iMap.getString("UAVT_IL_KOD"));
				iMap2.put("ADRES_IL_AD", iMap.getString("UAVT_IL_AD"));
				iMap2.put("ADRES_ILCE_KOD", iMap.getString("UAVT_ILCE_KOD"));
				iMap2.put("ADRES_ILCE_AD", iMap.getString("UAVT_ILCE_AD"));
				iMap2.put("ACIK_ADRES", iMap.getString("UAVT_ADRES_ACIKLAMA"));
				iMap2.put("KURYE_TIPI", iMap.getString("KURYE_TIPI"));
				iMap2.put("KART_TIPI", iMap.getString("KART_TIPI"));
				iMap2.put("KIMLIK_TIPI", iMap.getString("KIMLIK_TIPI"));
				iMap2.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
				String euptUserId="";
				if (!fraudMu && yeniBasvuruMu){
					GMMap euptRegInput=createEuptRegisterInput(iMap2);
					try {
						GMMap euptMap = new GMMap();
						euptMap.putAll(GMServiceExecuter.execute("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", euptRegInput));
						//euptMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", euptRegInput));
						euptUserId = euptMap.getString("USERID");
						iMap2.put("EUPT_USER_ID", euptUserId);
						
						
					}
					catch (Exception e) {
						logger.error(e);
					}
				}
				
				GMMap sonTxMap = new GMMap ();
				if ( !yeniBasvuruMu )
					sonTxMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_TFF_SON_TRX_BUL", iMap));
				else
					sonTxMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sonTxMap.getString("RESPONSE"))){
					iMap2.put("TRX_NO", sonTxMap.getString("TRX_NO"));
				}
				else{
					if (oMap.getString("TRX_NO") == null) {
						tMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
						iMap2.put("TRX_NO", tMap.getString("TRX_NO"));
					}
					else {
						iMap2.put("TRX_NO", oMap.getString("TRX_NO"));
					}
				}
					try {
						GMMap uyeSorgu = new GMMap();
						uyeSorgu.put("UYRUK", iMap2.getString("UYRUK_KOD"));
						uyeSorgu.put("TCKN", iMap2.getString("TCK_NO"));
						uyeSorgu.put("PASAPORT_NO", iMap2.getString("PASAPORT_NO"));
						uyeSorgu.putAll(GMServiceExecuter.call("BNSPR_TRN3801_TFF_UYE_BILGILERI_VER", uyeSorgu));
						if ( CreditCardServicesUtil.RESPONSE_BASARILI.equals(uyeSorgu.getString("RESPONSE")) ){
							iMap2.put("UYE_NO",  uyeSorgu.getBigDecimal("UYE_NO"));
						}
						else{
							GMMap xMap = new GMMap().put("TABLE_NAME", "TFF_UYELER");
							BigDecimal  id= GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
							iMap2.put("UYE_NO",  id);
						}
					}
					catch (Exception e) {
						logger.error(e);
					}
					
					GMMap uyeMap = new GMMap();
					uyeMap.put("ADI", iMap2.getString("KPS_AD"));
					uyeMap.put("IKINCI_ADI", iMap2.getString("KPS_IKINCI_AD"));
					uyeMap.put("SOYADI", iMap2.getString("KPS_SOYAD"));
					uyeMap.put("TCKN", iMap2.getString("TCK_NO"));
					uyeMap.put("PASAPORT_NO", iMap2.getString("PASAPORT_NO"));
					uyeMap.put("UYRUK", iMap2.getString("UYRUK_KOD"));
					uyeMap.put("VERILIS_TARIHI", iMap2.getString("VERILIS_TARIHI"));
					uyeMap.put("VERILIS_TARIHI", iMap2.getString("NUFUS_VER_TAR"));
					uyeMap.put("EPOSTA", iMap2.getString("EMAIL"));
					uyeMap.put("MUSTERI_NO", iMap2.getString("MUSTERI_NO"));
					uyeMap.put("EUPT_NO", iMap2.getString("EUPT_USER_ID"));
					uyeMap.put("CALISMA_SEKLI", iMap2.getString("CALISMA_SEKLI"));
					uyeMap.put("CEP_TEL", iMap2.getString("CEP_TEL"));
					uyeMap.put("KIMLIK_TIPI", iMap2.getString("KIMLIK_TIPI"));
					uyeMap.put("KIMLIK_SERI_NO", iMap2.getString("KIMLIK_SERI_NO"));
					uyeMap.put("TAKIM", iMap2.getString("KULUP"));
					if (!fraudMu)
						uyeMap.put("UYE_NO", iMap2.getString("UYE_NO"));
					
				oMap = new GMMap();
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SAVE", iMap2));
	
				// call eupt service
				tMap = new GMMap();
				tMap.put("GOVID", iMap2.getString("TC_TCKN"));
				tMap.put("NATIONALITY", iMap2.getString("UYRUK_KOD"));
				tMap.put("NAME", iMap2.getString("KPS_AD"));
				tMap.put("SECOND_NAME", iMap2.getString("KPS_IKINCI_AD"));
				tMap.put("SURNAME", iMap2.getString("KPS_SOYAD"));
				tMap.put("EMAIL", iMap2.getString("EMAIL"));
				tMap.put("MOBILECOUNTRY", iMap2.getString("CEP_ULKE_KOD"));
				tMap.put("MOBILECODE", iMap2.getString("CEP_ALAN_KOD"));
				tMap.put("MOBILENUMBER", iMap2.getString("CEP_NUMARA"));
	
				tMap.put("GENDER_CODE", iMap2.getString("KPS_CINSIYET"));
				tMap.put("TOWN_CODE", iMap2.getString("KPS_NUFUS_IL"));
				tMap.put("DISTRICT_CODE", iMap2.getString("KPS_NUFUS_ILCE"));
				
				if ( fraudMu){
				
					return karaListeMap;
				}
				else{
					
					try {
						GMServiceExecuter.executeNT("BNSPR_TRN3801_TFF_UYE_YAP", uyeMap);
					}
					catch (Exception e) {
						logger.error(e);
					}
					if ( CreditCardServicesUtil.EVET.equals(kkAlabilirMi) ){
						try {
							GMMap kkAlabilirMiMap = new GMMap();
							kkAlabilirMiMap.put("KK_ALABILIR_MI", kkAlabilirMi);
							kkAlabilirMiMap.put("MUST_NO", musteriNo);
							kkAlabilirMiMap.put("TCKN", iMap2.getString("TC_TCKN"));
							kkAlabilirMiMap = GMServiceExecuter.call("BNSPR_TRN3801_KK_ALABILME_KONTROL", kkAlabilirMiMap);
						    kkAlabilirMi = kkAlabilirMiMap.getString("KK_VERILEBILIR_MI");
						}
						catch (Exception e) {
							logger.error(e);
						}
					}
					oMap.put("KK_ALABILIR_MI", kkAlabilirMi);
					oMap.put("RESPONSE", "2");
					oMap.put("RESPONSE_DATA", oMap.getString("MESSAGE"));
					oMap.put("TFF_BASVURU_NO", iMap2.getString("BASVURU_NO"));
					oMap.put("EUPT_REF_ID", euptUserId);
				}
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	/**
	 *
	 * DESC    : DESCRIPTION
	 *
	 * @param iMap (GMMap)
	 *          ADI
	 *          SOYADI
	 *          IKINCI_ADI
	 *          TCKN
	 *          PASAPORT_NO
	 *          UYRUK
	 *          VERILIS_TARIHI
	 *          EPOSTA
	 *          MUSTERI_NO
	 *          EUPT_NO
	 *          KPS_TARIH
	 *          CALISMA_SEKLI
	 *          CEP_TEL
	 *          KIMLIK_TIPI
	 *          KIMLIK_SERI_NO
	 *          ONAYLANDI_MI
	 *          TAKIM
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA
	 *
	 * Company : Aktifbank
	 *
	 */
	@GraymoundService("BNSPR_TRN3801_TFF_UYE_YAP")
	public static GMMap tffUyeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			if ( StringUtils.isNotEmpty(iMap.getString("UYE_NO")) ) {
				tffUyeler = (TffUyeler) session.get(TffUyeler.class,iMap.getBigDecimal("UYE_NO") );
			}
			
			if ( tffUyeler == null ){
				tffUyeler = new TffUyeler();
				
				tffUyeler.setUyeNo(iMap.getBigDecimal("UYE_NO"));
				tffUyeler.setBankaMusteriNo(StringUtils.isNotEmpty(iMap.getString("MUSTERI_NO"))?iMap.getBigDecimal("MUSTERI_NO"):null);
				tffUyeler.setEuptNo(StringUtils.isNotEmpty(iMap.getString("EUPT_NO"))?iMap.getString("EUPT_NO"):null);
			}
			else{
				return new GMMap();
				/*if ( tffUyeler.getBankaMusteriNo() == null )
					tffUyeler.setBankaMusteriNo(StringUtils.isNotEmpty(iMap.getString("MUSTERI_NO"))?iMap.getBigDecimal("MUSTERI_NO"):null);
				if ( tffUyeler.getEuptNo() == null )
					tffUyeler.setEuptNo(StringUtils.isNotEmpty(iMap.getString("EUPT_NO"))?iMap.getString("EUPT_NO"):null);*/
			}
			
			tffUyeler.setAdi(iMap.getString("ADI"));
			tffUyeler.setSoyadi(iMap.getString("SOYADI"));
			tffUyeler.setIkinciAdi(iMap.getString("IKINCI_ADI"));
			tffUyeler.setTckn(StringUtils.isNotEmpty(iMap.getString("TCKN"))?iMap.getBigDecimal("TCKN"):null);
			tffUyeler.setPasaportNo(StringUtils.deleteWhitespace(iMap.getString("PASAPORT_NO")));
			tffUyeler.setUyruk(iMap.getString("UYRUK"));
			//tffUyeler.setNufusVerilisTarihi(iMap.getDate("VERILIS_TARIHI"));
			if (StringUtils.isNotEmpty(iMap.getString("VERILIS_TARIHI")))
				tffUyeler.setNufusVerilisTarihi(iMap.getDate("VERILIS_TARIHI"));
			else
				tffUyeler.setNufusVerilisTarihi(null);
			tffUyeler.setEposta(iMap.getString("EPOSTA"));
			tffUyeler.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			tffUyeler.setCepTel(iMap.getString("CEP_TEL"));
			tffUyeler.setKimlikTipi(iMap.getString("KIMLIK_TIPI"));
			tffUyeler.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
			tffUyeler.setTakim(iMap.getString("TAKIM"));
			
			session.saveOrUpdate(tffUyeler);
			session.flush();
			oMap.put("RESPONSE", 2);
			oMap.put("UYE_NO", tffUyeler.getUyeNo());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/**
	 *
	 * DESC    : DESCRIPTION
	 *
	 * @param iMap (GMMap)
		UYRUK
		TCKN
		PASAPORT_NO
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA

	 *      	ADI
	 *          SOYADI
	 *          IKINCI_ADI
	 *          TCKN
	 *          PASAPORT_NO
	 *          UYRUK
	 *          VERILIS_TARIHI
	 *          EPOSTA
	 *          MUSTERI_NO
	 *          EUPT_NO
	 *          KPS_TARIH
	 *          CALISMA_SEKLI
	 *          CEP_TEL
	 *          KIMLIK_TIPI
	 *          KIMLIK_SERI_NO
	 *          ONAYLANDI_MI
	 *          TAKIM
	 *          UYE_NO
	
	 * 
	 *
	 * Company : Aktifbank
	 *
	 */
	@GraymoundService("BNSPR_TRN3801_TFF_UYE_BILGILERI_VER")
	public static GMMap tffUyeBilgileriVer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			if ( "TR".equals(iMap.getString("UYRUK"))) {
				tffUyeler = (TffUyeler) session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn",iMap.getBigDecimal("TCKN"))).uniqueResult();
			}
			else{
				
				tffUyeler = (TffUyeler) session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaport_no",iMap.getString("PASAPORT_NO"))).uniqueResult();
			}

			if ( tffUyeler == null ){
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				return oMap;
			}
			oMap.put("ADI", tffUyeler.getAdi());
			oMap.put("SOYADI", tffUyeler.getSoyadi());
			oMap.put("IKINCI_ADI", tffUyeler.getIkinciAdi());
			oMap.put("DOGUM_TARIHI", "");
			oMap.put("ANNE_KIZLIK_SOYADI", tffUyeler.getAnneKizlikSoyadi());
			oMap.put("CEP_TEL", tffUyeler.getCepTel());
			oMap.put("KK_ALABILIR_MI", "E");
			oMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());
			oMap.put("VERILIS_TARIHI",  new SimpleDateFormat("yyyyMMdd").format(tffUyeler.getNufusVerilisTarihi()));
			oMap.put("EPOSTA", tffUyeler.getEposta());
			oMap.put("CALISMA_SEKLI", tffUyeler.getCalismaSekli());
			oMap.put("TAKIM",tffUyeler.getTakim());
			oMap.put("TCKN", tffUyeler.getTckn());
			oMap.put("PASAPORT_NO",tffUyeler.getPasaportNo());
			oMap.put("UYRUK",tffUyeler.getUyruk());
			oMap.put("UYE_NO", tffUyeler.getUyeNo());
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		}
		return oMap;
	}

	private static GMMap createEuptRegisterInput(GMMap iMap2){
		// call eupt service
		GMMap tMap = new GMMap();
		tMap.put("CUSTOMER_NO", 	iMap2.getString("MUSTERI_NO"));
		tMap.put("NATIONALITY", 	iMap2.getString("UYRUK_KOD"));
		tMap.put("LANGUAGE", 		iMap2.getString("DIL"));
		tMap.put("SIGNUPIP", 		iMap2.getString("CLIENT_IP"));
		tMap.put("MOBILECOUNTRY", 	iMap2.getString("CEP_ULKE_KOD"));
		tMap.put("MOBILECODE", 		iMap2.getString("CEP_ALAN_KOD"));
		tMap.put("MOBILENUMBER", 	iMap2.getString("CEP_NUMARA"));
		tMap.put("NICK", 			tMap.getString("MOBILECOUNTRY")+tMap.getString("MOBILECODE")+tMap.getString("MOBILENUMBER"));
		tMap.put("EMAIL", 			iMap2.getString("EMAIL"));
		tMap.put("REGCHANNEL", 		"TFF");
		
		GMMap tMapKps = new GMMap();
		
		if(iMap2.getString("UYRUK_KOD").equals("TR")){
			tMap.put("GOVID", 		iMap2.getString("TCK_NO"));
			tMap.put("MIDNAME", 	iMap2.getString("KPS_IKINCI_AD"));
			tMap.put("NAME",		iMap2.getString("KPS_AD"));
			tMap.put("SURNAME", 	iMap2.getString("KPS_SOYAD"));
			tMap.put("PHONECOUNTRY","");
			tMap.put("PHONECODE", 	"");
			tMap.put("PHONENUMBER", "");
			tMap.put("BIRTHDATE", iMap2.getString("KPS_DOGUM_TARIHI"));
			tMap.put("COUNTRY", 	"TR");
			
			tMapKps.put("NAME", 			iMap2.getString("KPS_AD"));
			tMapKps.put("SURNAME",   		iMap2.getString("KPS_SOYAD"));
			tMapKps.put("GENDER_CODE", 		iMap2.getString("KPS_CINSIYET"));
			tMapKps.put("MOTHERNAME", 		iMap2.getString("KPS_ANNE_AD"));
			tMapKps.put("FATHERNAME", 		iMap2.getString("KPS_BABA_AD"));
			tMapKps.put("BIRTHPLACE", 		iMap2.getString("KPS_DOGUM_YERI"));
			tMapKps.put("MARITALSTATUS",	iMap2.getString("KPS_MEDENI_HAL"));
			tMapKps.put("BIRTHDATE", 		iMap2.getString("KPS_DOGUM_TARIHI"));
			tMapKps.put("DISTRICT_CODE", 	iMap2.getString("KPS_NUFUS_ILCE"));
			tMapKps.put("TOWN_CODE",		iMap2.getString("KPS_NUFUS_IL"));
			tMapKps.put("FAMILY_ORDER_NO", 	iMap2.getString("KPS_AILE_SIRA_NO"));
			tMapKps.put("BINDING_NO", 	  	iMap2.getString("KPS_CILT_NO"));
			tMapKps.put("REGISTER_NO", 		"");
			tMapKps.put("ID_ORDER_NO", 	  	iMap2.getString("KPS_KIMLIK_SIRA_NO"));
			tMapKps.put("QUARTER", 			iMap2.getString("KPS_NUFUS_MAHALLE"));
			tMapKps.put("ID_SERIAL_NO", 	iMap2.getString("KPS_KIMLIK_SERI_NO"));
			tMapKps.put("ORDER_NO", 		iMap2.getString("KPS_BIREY_SIRA_NO"));
			tMapKps.put("GIVEN_DISTRICT_CODE", "");
			tMapKps.put("GIVEN_PLACE", 			iMap2.getString("KPS_VER_YER"));
			tMapKps.put("GIVEN_REASON", 		iMap2.getString("KPS_VERILIS_NEDENI"));
			tMapKps.put("GIVEN_DATE", 			iMap2.getString("NUFUS_VER_TAR"));
			tMapKps.put("DEATH_DATE", 			"");
			
		} else {
			tMap.put("GOVID", 		iMap2.getSize("PASAPORT_NO"));
			tMap.put("MIDNAME", 	iMap2.getString("YABANCI_IKINCI_AD"));
			tMap.put("NAME", 		iMap2.getString("YABANCI_AD"));
			tMap.put("SURNAME", 	iMap2.getString("YABANCI_SOYAD"));
			tMap.put("BIRTHDATE", 	iMap2.getString("YABANCI_DOGUM_TARIHI"));
			tMap.put("COUNTRY", 	"TR");
            
			tMapKps.put("NAME", 		iMap2.getString("YABANCI_AD"));
			tMapKps.put("SURNAME", 		iMap2.getString("YABANCI_SOYAD"));
			tMapKps.put("BIRTHDATE", 	iMap2.getString("YABANCI_DOGUM_TARIHI"));
		}
		
		tMapKps.put("TC_KIMLIK_NO",  tMap.getString("GOVID"));
		tMapKps.put("GOVID",         tMap.getString("GOVID"));
		
		tMap.put("KPSRESULT", tMapKps);
		return tMap;
	}
	
	@GraymoundService("BNSPR_TRN3801_SAVE_KONTAK_MUSTERI_GERCEK")
    public static GMMap saveContactMusteriGercek(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        PreparedStatement pStmt = null;
        ResultSet rSet = null;
        try {

            String kanalKod = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMap).getString("KANAL_KOD");

            conn = DALUtil.getGMConnection();
            pStmt = conn.prepareStatement("select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr where kod = ?"); // bunu sp isteyelim
            pStmt.setString(1, kanalKod);
            rSet = pStmt.executeQuery();

            GMMap customerMap = new GMMap();
          
            customerMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
            customerMap.put("PASAPORT_NO",iMap.getString("PASAPORT_NO"));
            customerMap.put("MUSTERI_TURUNE_GORE_MI", true);
        
            customerMap.put("KAYNAK","TFF");
            customerMap.put("TUR","TFFKART");
            customerMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
            BigDecimal musteriNo=TffServicesHelper.searchCustomer(iMap.getString("UYRUK"), iMap.getString("TCKN"), iMap.getString("PASAPORT_NO"));
			if(musteriNo != null &&  musteriNo.compareTo(BigDecimal.ZERO)>0){
				GMMap currentCustomer=new GMMap();
				currentCustomer.put("MUSTERI_NO", musteriNo);
				customerMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", currentCustomer));
			}
            
            if ( "TR".equals(iMap.getString("UYRUK")) ){
            //PY-4110
                customerMap.put("F_KPS",iMap.getString("F_KPS"));
                customerMap.put("KPS_TARIH",iMap.getString("KPS_TARIH"));
	            customerMap.put("ANNE_KIZLIK_SOYADI",iMap.getString("ANNE_KIZLIK_SOYADI"));
	            customerMap.put("MESLEK_KOD",nvl(iMap.getString("MESLEK_KOD"), customerMap.getString("MESLEK_KOD")));
	            customerMap.put("EGITIM_KOD",nvl(iMap.getString("EGITIM_KOD"), customerMap.getString("EGITIM_KOD")));
	            customerMap.put("CALISMA_SEKLI",nvl(iMap.getString("CALISMA_SEKLI"), customerMap.getString("CALISMA_SEKLI")));
	            customerMap.put("UNVAN_KOD",iMap.getString("UNVAN_KOD"));
	            customerMap.put("TCKNO_IN",iMap.getString("TCKNO_IN"));
	            if (StringUtils.isNotBlank(iMap.getString("TCKNO_OUT"))) {
	            	customerMap.put("TCKNO_OUT",iMap.getString("TCKNO_OUT"));
	            }
	            customerMap.put("ADK_MUSTERISIMI","H");
	            customerMap.put("MUSTERI_GRUP_KOD","1");
	            customerMap.put("KIZLIK_SOYADI",nvl(iMap.getString("ONCEKI_SOYADI"), customerMap.getString("KIZLIK_SOYADI")));
	            //
	            
	            customerMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
	
	            customerMap.put("ISIM", nvl(iMap.getString("ADI"), customerMap.getString("ADI")));
	            customerMap.put("SOYADI", nvl(iMap.getString("SOYADI"), customerMap.getString("SOYADI")));
	            customerMap.put("ANNE_ADI", nvl(iMap.getString("ANNE_ADI"), customerMap.getString("ANNE_ADI")));
	            customerMap.put("BABA_ADI", nvl(iMap.getString("BABA_ADI"), customerMap.getString("BABA_ADI")));
	            if (iMap.containsKey("IKINCI_ADI")){ 
	            	customerMap.put("IKINCI_ISIM" , iMap.getString("IKINCI_ADI"));
	             } 
	             else {
	            	 customerMap.put("IKINCI_ISIM", nvl(iMap.getString("IKINCI_ADI"), customerMap.getString("IKINCI_ADI")));
	             }
	            
	            if (iMap.containsKey("KISA_AD")){ 
	            	customerMap.put("KISA_AD" , iMap.getString("KISA_AD"));
	             } 
	             else {
	            	 customerMap.put("KISA_AD", nvl(iMap.getString("KISA_AD"), customerMap.getString("KISA_AD")));
	             }
	            
	            customerMap.put("UYRUK_KOD",  "TR");
	            if (!StringUtils.isNotBlank(customerMap.getString("TICARI_UNVAN"))) customerMap.put("TICARI_UNVAN", nvl(iMap.getString("UNVAN"), customerMap.getString("TICARI_UNVAN")));
	
	            if (StringUtils.isNotBlank(iMap.getString("CINSIYET"))) {
	                customerMap.put("CINSIYET_KOD", iMap.getString("CINSIYET").substring(0, 1));
	            }
	
	            if (StringUtils.isNotBlank(iMap.getString("MEDENI_HAL"))) {
	                customerMap.put("MEDENI_HAL", "E".equals(iMap.getString("MEDENI_HAL").substring(0, 1)) ? "1" : "2");
	            }
	
	            customerMap.put("DOGUM_YERI", nvl(iMap.getString("DOGUM_YERI"), customerMap.getString("DOGUM_YERI")));
	            customerMap.put("DOGUM_TARIHI", nvl(iMap.getDate("DOGUM_TARIHI"), customerMap.getDate("DOGUM_TARIHI")));
	
	            if (StringUtils.isNotBlank(iMap.getString("KIMLIK_SERI_NO")) && StringUtils.isNotBlank(iMap.getString("KIMLIK_SIRA_NO"))) {
	                customerMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_NO") + iMap.getString("KIMLIK_SIRA_NO"));
	            } else {
	                customerMap.put("NUFUS_CUZDANI_SERI_NO", customerMap.getString("NUF_SERI_NO"));
	            }
	
	            if (!StringUtils.isEmpty(iMap.getString("NUFUS_VERILIS_TARIHI"))) {
	                customerMap.put("VERILDIGI_TARIH", iMap.getDate("NUFUS_VERILIS_TARIHI"));
	            } else {
	                customerMap.put("VERILDIGI_TARIH", customerMap.getDate("NUF_VERILDIGI_TARIH"));
	            }
	            
	            customerMap.put("NUF_VERILIS_NEDENI", nvl(iMap.getString("NUF_VERILIS_NEDENI"), customerMap.getString("NUF_VERILIS_NEDENI")));
	            customerMap.put("VERILDIGI_YER", nvl(iMap.getString("NUF_VERILDIGI_YER"), customerMap.getString("NUF_VERILDIGI_YER")));
	            customerMap.put("IL_KOD", nvl(iMap.getString("NUFUS_IL_KOD"), customerMap.getString("NUF_IL_KOD")));
	            customerMap.put("ILCE_KOD", nvl(iMap.getString("NUFUS_ILCE_KOD"), customerMap.getString("NUF_ILCE_KOD")));
	            customerMap.put("CILT_NO", nvl(iMap.getString("NUFUS_CILT_NO"), customerMap.getString("NUF_CILT_NO")));
	            customerMap.put("AILE_SIRA_NO", nvl(iMap.getString("NUFUS_AILE_SIRA_NO"), customerMap.getString("NUF_AILE_SIRA_NO")));
	            customerMap.put("SIRA_NO", nvl(iMap.getString("NUFUS_SIRA_NO"), customerMap.getString("NUF_SIRA_NO")));
	            customerMap.put("MAHALLE_KOY", nvl(iMap.getString("NUFUS_MAHALLE"), customerMap.getString("NUF_MAHALLE_KOY")));
	            if(!"@".equals(iMap.getString("EPOSTA")))
	            	customerMap.put("EMAIL_KISISEL", nvl(iMap.getString("EPOSTA"), customerMap.getString("EMAIL_KISISEL")));
	            else
	            	customerMap.put("EMAIL_KISISEL", customerMap.getString("EMAIL_KISISEL"));
	            
	            GMMap adresMap = new GMMap();
	            
	            
	            if (StringUtils.isNotBlank(iMap.getString("ADRES_TIPI"))) {
	
	                adresMap.put("ADRES_KOD", iMap.getString("ADRES_TIPI"));
	                adresMap.put("ADRES", iMap.getString("ACIK_ADRES"));
	                
	                adresMap.put("EXTRE_ADRES_KOD_F", "E");
	      
	                
	                adresMap.put("ULKE_KOD", "TR");
	                adresMap.put("ADRES_IL_KOD", iMap.getString("ADRES_IL_KOD"));
	                adresMap.put("ADRES_ILCE_KOD", iMap.getString("ADRES_ILCE_KOD"));
	                customerMap.put("ADRES_LIST", customerMap.get("ADRES"));
	                customerMap.put("ADRES_LIST", customerMap.getSize("ADRES"), adresMap);
	
	            }
	            GMMap telefonCepMap = new GMMap();
	            for(int i = 0 ; i< customerMap.getSize("TELEFON"); i++){
	            	telefonCepMap = new GMMap();
	            	telefonCepMap.put("TEL_TIP", customerMap.getString("TELEFON",i,"TEL_TIP"));
	            	telefonCepMap.put("ALAN_KOD", customerMap.getString("TELEFON",i,"ALAN_KOD"));
	            	telefonCepMap.put("ULKE_KODU",customerMap.getString("TELEFON",i,"ULKE_KODU"));
	            	telefonCepMap.put("TEL_NO", customerMap.getString("TELEFON",i,"TEL_NO"));
	            	telefonCepMap.put("OTPMI", customerMap.getString("TELEFON",i,"OTP_MI"));
 	                customerMap.put("TELEFON_LIST", i, telefonCepMap);
            	}
	            
	        //    GMMap telefonCepMap = new GMMap();
	            if (iMap.get("CEP_NUMARA") != null && StringUtils.isNotBlank(iMap.getString("CEP_NUMARA"))) {
	            	telefonCepMap.put("TEL_TIP", "3");
	            	telefonCepMap.put("ULKE_KODU", nvl(iMap.getString("CEP_ULKE_KOD"), customerMap.getString("TELEFON", 0, "ULKE_KOD")));
	            	telefonCepMap.put("ALAN_KOD", nvl(iMap.getString("CEP_ALAN_KOD"), customerMap.getString("TELEFON", 0, "ALAN_KOD")));
	            	telefonCepMap.put("TEL_NO", nvl(iMap.getString("CEP_NUMARA"), customerMap.getString("TELEFON", 0, "TEL_NO")));
	            	telefonCepMap.put("OTPMI", true);
	            	telefonCepMap.put("F_ILETISIM", "3".equals(iMap.getString("ILETISIM_TEL_TIP")) || "C".equals(iMap.getString("ILETISIM_TEL_TIP")) ?1:0 );
	            	customerMap.put("TELEFON_LIST", customerMap.get("TELEFON"));
	                customerMap.put("TELEFON_LIST", customerMap.getSize("TELEFON"), telefonCepMap);
	            }
	
	            customerMap.put("TRX_ONAYSIZ_ISLEM", "E");
	            if (StringUtils.isNotBlank(customerMap.getString("MUSTERI_NO")) && StringUtils.isNotBlank(customerMap.getString("TC_KIMLIK_NO"))) { //Gercek Guncelle
	            	try
	                {
		                oMap.put("MUSTERI_NO", customerMap.getString("MUSTERI_NO"));
	            		GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerMap);
	                } catch (Exception e) {
	                	logger.error(e);
	                	// TODO: handle exception
	                }
	            } else if (StringUtils.isNotBlank(customerMap.getString("TC_KIMLIK_NO"))) {//Gercek Yarat
	                customerMap.remove("MUSTERI_NO");
	                customerMap.put("KAZANIM_KANALI", kanalKod);
	                customerMap.put("KANAL_KODU", iMap.getString("KANAL_ALT_KOD"));
	                customerMap.put("BAGLI_KANAL_GRUBU", kanalKod);
	                customerMap.put("MUSTERI_TIPI_KOD", "G");
	                customerMap.put("MUSTERI_SEGMENTI", "N");
	                customerMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
	                customerMap.put("YERLESIM_KOD", "I");
	                customerMap.put("PROFIL_KOD", "1");
	                customerMap.put("KAZANIM_URUNU", "TFFKART");
	                customerMap.put("HESAP_UCRETI_F", "H");
	                customerMap.put("YATIRIM_EKSTRESI", "H");
	                customerMap.put("MUSTERIYI_KAZANDIRAN", "514");
	                customerMap.put("ADK_MUSTERISIMI", "H");
	                if(!StringUtils.isBlank(iMap.getString("BASVURU_NO"))){
	                	customerMap.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
	                }else{
	                	GMMap xMap = new GMMap();
	                	xMap.put("PARAMETRE", "KK_PORTFOY_KOD");
	                	customerMap.put("PORTFOY_KOD", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
	                	
	                }
	                customerMap.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", customerMap.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
	                try
	                {
		                GMMap sMap = GMServiceExecuter.call("BNSPR_CUST_CREATE_GERCEK_MUSTERI", customerMap);
		                oMap.put("MUSTERI_NO", sMap.getString("MUSTERI_NO"));
		                oMap.put("MUSTERI_YARATMA_TX_NO", sMap.getString("MUSTERI_YARAT_TX_NO"));
	                } catch (Exception e) {
	                	logger.error(e);
	                	// TODO: handle exception
	                }
	            } else if (StringUtils.isNotBlank(iMap.getString("PASAPORT_NO"))){
	            	customerMap.put("PASSPORT_NO", iMap.getString("PASAPORT_NO"));
	            	customerMap.put("YERLESIM_KOD", "I");
	            	
		            GMMap sMap = GMServiceExecuter.call("BNSPR_CUST_CREATE_GERCEK_MUSTERI", customerMap);
		            oMap.put("MUSTERI_NO", sMap.getString("MUSTERI_NO"));
		            oMap.put("MUSTERI_YARATMA_TX_NO", sMap.getString("MUSTERI_YARAT_TX_NO"));
	            }
            }
            else{
	            customerMap.put("MESLEK_KOD",nvl(iMap.getString("MESLEK_KOD"), customerMap.getString("MESLEK_KOD")));
	            customerMap.put("EGITIM_KOD",nvl(iMap.getString("EGITIM_KOD"), customerMap.getString("EGITIM_KOD")));
	            customerMap.put("CALISMA_SEKLI",nvl(iMap.getString("CALISMA_SEKLI"), customerMap.getString("CALISMA_SEKLI")));
                customerMap.put("ISIM", nvl(iMap.getString("ADI"), customerMap.getString("ADI")));
	            customerMap.put("SOYADI", nvl(iMap.getString("SOYADI"), customerMap.getString("SOYADI")));
	            
	            if (iMap.containsKey("IKINCI_ADI")){ 
	            	customerMap.put("IKINCI_ISIM" , iMap.getString("IKINCI_ADI"));
	             } 
	             else {
	            	 customerMap.put("IKINCI_ISIM", nvl(iMap.getString("IKINCI_ADI"), customerMap.getString("IKINCI_ADI")));
	             }
	            
	            if (iMap.containsKey("KISA_AD")){ 
	            	customerMap.put("KISA_AD" , iMap.getString("KISA_AD"));
	             } 
	             else {
	            	 customerMap.put("KISA_AD", nvl(iMap.getString("KISA_AD"), customerMap.getString("KISA_AD")));
	             }
	                             
  
	            customerMap.put("UYRUK_KOD",  iMap.getString("UYRUK"));
            	customerMap.put("DOGUM_TARIHI", nvl(iMap.getDate("DOGUM_TARIHI"), customerMap.getDate("DOGUM_TARIHI")));
            	customerMap.put("PASSPORT_NO", iMap.getString("PASAPORT_NO"));
            	customerMap.put("MUSTERI_GRUP_KOD","1");
            	customerMap.put("YERLESIM_KOD", "I");
            	
	            if(!"@".equals(iMap.getString("EPOSTA")))
	            	customerMap.put("EMAIL_KISISEL", nvl(iMap.getString("EPOSTA"), customerMap.getString("EMAIL_KISISEL")));
	            else
	            	customerMap.put("EMAIL_KISISEL", customerMap.getString("EMAIL_KISISEL"));
	          
	            
	            
	            if (StringUtils.isNotBlank(iMap.getString("ADRES_TIPI"))) {
	            	  GMMap adresMap = new GMMap();
	            	for(int i = 0 ; i< customerMap.getSize("ADRES"); i++){
	            		adresMap = new GMMap();
	            		adresMap.put("ADRES_KOD", customerMap.getString("ADRES",i,"ADRES_KOD"));
	 	                adresMap.put("ADRES", customerMap.getString("ADRES",i,"ADRES"));
	 	                adresMap.put("EXTRE_ADRES_KOD_F", customerMap.getString("ADRES",i,"EXTRE_ADRESI_MI"));
	 	                adresMap.put("ULKE_KOD",customerMap.getString("ADRES",i,"ULKE_KOD"));
	 	                adresMap.put("ADRES_IL_KOD", iMap.getString("ADRES",i,"IL_KOD"));
	 	                adresMap.put("ADRES_ILCE_KOD", iMap.getString("ADRES",i,"ILCE_KOD"));
	 	                customerMap.put("ADRES_LIST", i, adresMap);
	            	}
	            	adresMap.put("ADRES_KOD", iMap.getString("ADRES_TIPI"));
 	                adresMap.put("ADRES", iMap.getString("ACIK_ADRES"));
 	                adresMap.put("EXTRE_ADRES_KOD_F", "E");
 	                adresMap.put("ULKE_KOD", "TR");
 	                adresMap.put("ADRES_IL_KOD", iMap.getString("ADRES_IL_KOD"));
 	                adresMap.put("ADRES_ILCE_KOD", iMap.getString("ADRES_ILCE_KOD"));
 	                customerMap.put("ADRES_LIST",customerMap.getSize("ADRES"), adresMap);
	            
	                customerMap.getString("ADRES_LIST");
	            }
	            GMMap telefonCepMap = new GMMap();
	            for(int i = 0 ; i< customerMap.getSize("TELEFON"); i++){
	            	telefonCepMap = new GMMap();
	            	telefonCepMap.put("TEL_TIP", customerMap.getString("TELEFON",i,"TEL_TIP"));
	            	telefonCepMap.put("ALAN_KOD", customerMap.getString("TELEFON",i,"ALAN_KOD"));
	            	telefonCepMap.put("ULKE_KOD",customerMap.getString("TELEFON",i,"ULKE_KOD"));
	            	telefonCepMap.put("TEL_NO", customerMap.getString("TELEFON",i,"TEL_NO"));
	            	telefonCepMap.put("OTPMI", customerMap.getString("TELEFON",i,"OTP_MI"));
 	                customerMap.put("TELEFON_LIST", i, telefonCepMap);
            	}
	            
	            if (StringUtils.isNotBlank(iMap.getString("CEP_NUMARA"))) {

	            	telefonCepMap.put("TEL_TIP", "3");
	            	telefonCepMap.put("ULKE_KODU", nvl(iMap.getString("CEP_ULKE_KOD"), customerMap.getString("TELEFON", 0, "CEP_ULKE_KOD")));
	            	telefonCepMap.put("ALAN_KOD", nvl(iMap.getString("CEP_ALAN_KOD"), customerMap.getString("TELEFON", 0, "ALAN_KOD")));
	            	telefonCepMap.put("TEL_NO", nvl(iMap.getString("CEP_NUMARA"), customerMap.getString("TELEFON", 0, "TEL_NO")));
	            	telefonCepMap.put("OTPMI", true);
	            	telefonCepMap.put("F_ILETISIM", "3".equals(iMap.getString("ILETISIM_TEL_TIP"))?1:0);
	            	//telefonCepMap.put("F_ILETISIM", 1);
	                customerMap.put("TELEFON_LIST", customerMap.getSize("TELEFON_LIST"), telefonCepMap);
	            }
	
	            customerMap.put("TRX_ONAYSIZ_ISLEM", "E");
            	
	            if (StringUtils.isNotBlank(customerMap.getString("MUSTERI_NO")) && StringUtils.isNotBlank(customerMap.getString("PASAPORT_NO"))) { //Gercek Guncelle
	            	try
	                {
		                oMap.put("MUSTERI_NO", customerMap.getString("MUSTERI_NO"));
	            		GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerMap);
	                } catch (Exception e) {
	                	logger.error(e);
	                	// TODO: handle exception
	                }
	            }
	            else{
	            	customerMap.remove("MUSTERI_NO");
	                customerMap.put("KAZANIM_KANALI", kanalKod);
	                customerMap.put("KANAL_KODU", iMap.getString("KANAL_ALT_KOD"));
	                customerMap.put("BAGLI_KANAL_GRUBU", kanalKod);
	                customerMap.put("MUSTERI_TIPI_KOD", "G");
	                customerMap.put("MUSTERI_SEGMENTI", "N");
	                customerMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
	                customerMap.put("PROFIL_KOD", "1");
	                customerMap.put("KAZANIM_URUNU", "TFFKART");
	                customerMap.put("HESAP_UCRETI_F", "H");
	                customerMap.put("YATIRIM_EKSTRESI", "H");
	                customerMap.put("MUSTERIYI_KAZANDIRAN", "514");
	                customerMap.put("ADK_MUSTERISIMI", "H");
	                
	                if (!StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
	                	customerMap.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
	                } else{
	                	GMMap xMap = new GMMap();
	                	xMap.put("PARAMETRE", "KK_PORTFOY_KOD");
	                	customerMap.put("PORTFOY_KOD", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
	                	
	                }
	                customerMap.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", customerMap.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
	                
		            GMMap sMap = GMServiceExecuter.call("BNSPR_CUST_CREATE_GERCEK_MUSTERI", customerMap);
		            oMap.put("MUSTERI_NO", sMap.getString("MUSTERI_NO"));
		            oMap.put("MUSTERI_YARATMA_TX_NO", sMap.getString("MUSTERI_YARAT_TX_NO"));
	            }
            }

            return oMap;
        } catch (Exception e) {
     
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(pStmt);
            GMServerDatasource.close(conn);
        }
    }

	
	
	 public static <T> T nvl(T a, T b) {
	        if (a instanceof String) return StringUtils.isBlank((String) a) ? b : a;
	        return a == null ? b : a;
	    }
	@GraymoundService("BNSPR_TRN3801_AKTIF_BASVURU_VAR_MI")
	public static GMMap tffAktifBasvuruVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kulupUrun = "";
		String kulupUrunSahip = "";
		if (StringUtils.isNotBlank( iMap.getString("KULUP_URUN")) ){
			StringTokenizer stringTokenizer = new StringTokenizer(iMap.getString("KULUP_URUN"),"-");
			kulupUrunSahip = stringTokenizer.nextToken();
			if ( stringTokenizer.hasMoreTokens())
				kulupUrun = stringTokenizer.nextToken();
		}

			try {
				String procStr = "{call BNSPR.PKG_TRN3801.tffAktifBasvuruVarmi (?,?,?,?,?,?,?)}";
				int i = 0;
				Object[] inputValues = new Object[10];
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("TCKN");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getString("PASAPORT_NO");
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("TFF_BASVURU_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = kulupUrun;
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = kulupUrunSahip;
				i = 0;
				Object[] outputValues = new Object[4];
				outputValues[i++] = BnsprType.STRING;
				outputValues[i++] = "RESPONSE";
				outputValues[i++] = BnsprType.STRING;
				outputValues[i++] = "RESPONSE_DATA";

				oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			}
			catch (Exception ex){
				throw ExceptionHandler.convertException(ex);
			}

		
		return oMap;
	}

	
	@GraymoundService("BNSPR_TRN3801_UYE_AKTIF_BASVURU_VAR_MI")
	public static GMMap tffUyeAktifBasvuruVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kulupUrun = iMap.getString("KULUP_URUN");
		String kulupUrunSahip = iMap.getString("KULUP_URUN_SAHIP");
			
		
			try {
				String procStr = "{call BNSPR.PKG_TRN3801.tffUyeAktifBasvuruVarmi (?,?,?,?,?,?)}";
				int i = 0;
				Object[] inputValues = new Object[10];
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("UYE_NO");
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("TFF_BASVURU_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = kulupUrun;
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = kulupUrunSahip;
				i = 0;
				Object[] outputValues = new Object[4];
				outputValues[i++] = BnsprType.STRING;
				outputValues[i++] = "RESPONSE";
				outputValues[i++] = BnsprType.STRING;
				outputValues[i++] = "RESPONSE_DATA";

				oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			}
			catch (Exception ex){
				throw ExceptionHandler.convertException(ex);
			}

		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3801_KPS_SORGULA_FIRST_STEP")
	public static GMMap kpsSorgulaFirstStep(GMMap iMap){
		GMMap oMap = new GMMap();

		// KPS Sorgusu Yap - get kimlik sorgu info
		iMap.put("TCKNO", iMap.getString("TCK_NO"));
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_SORGULAMA", iMap));

		// KPS Sorgu Sonucunu Kontrol Et
		if (StringUtils.isNotBlank(iMap.getString("TCKNO_OUT"))) { // Sorgu Basarili
			// Kimlik Dogrulama Bilgilerini Al - get kimlik dogrulama info
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_DOGRULAMA", iMap));

			// Kimlik Kayip mi Sorgusu Yap - get kimlik kayip sorgu info
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));

			// Olum Durumunu Kontrol Et - Olmusse Hata Ver
			String olumTarihi = iMap.getString("OLUM_TARIHI");
			if (StringUtils.isNotBlank(olumTarihi)) {
				String errorMessage = null;
				if (olumTarihi.length() >= 8) {
					errorMessage = olumTarihi.substring(6, 8) + "/" + olumTarihi.substring(4, 6) + "/" + olumTarihi.substring(0, 4);
				}
				iMap.put("MESSAGE_NO", new BigDecimal(918));
				iMap.put("P1", errorMessage);
				oMap.put("RESPONSE_DATA", CreditCardTffServices.errorMessageOlustur("918","E",errorMessage)); //GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				oMap.put("RESPONSE","1");
				return oMap;
			}

			// TCKN Durumunu Kontrol Et - Uygun Degilse Hata Ver
			else if (!"1".equals(iMap.getString("DURUMU"))) {
				iMap.put("MESSAGE_NO", new BigDecimal(2087));
				
				oMap.put("RESPONSE_DATA", CreditCardTffServices.errorMessageOlustur("2087","E"));//GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				oMap.put("RESPONSE","1");
				return oMap;
			}
			oMap.put("RESPONSE","2");
			oMap.put("RESPONSE_DATA", "KPS TAMAMLANDI");
			oMap.put("KPS_BASARILI_MI", "E");
		}
		
		else{
		
			oMap.put("RESPONSE","1");
			oMap.put("RESPONSE_DATA", "B-0000:KPS YAPILAMADI");
		}
		oMap.putAll(iMap);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3801_KK_ALABILME_KONTROL")
	public static GMMap tffKrediKartiAlabilmeKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		String krediKartiKontrol = CreditCardServicesUtil.HAYIR;
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			krediKartiKontrol =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "VERILEBILIR_MI", BnsprType.STRING, "KK_KONRTOL"));
		}
		catch (Exception e) {
			krediKartiKontrol = CreditCardServicesUtil.HAYIR;
		}
		if ( krediKartiKontrol.equals(CreditCardServicesUtil.HAYIR) ){
			oMap.put("KK_VERILEBILIR_MI", CreditCardServicesUtil.HAYIR);
			return oMap;
		}
		try {
			oMap = GMServiceExecuter.call("BNSPR_TRN3871_KART_VAR_MI", iMap);
			
			if ( oMap.getBoolean("KART_VAR_MI")){
				oMap.put("KK_VERILEBILIR_MI", CreditCardServicesUtil.HAYIR);
				return oMap;
			}
			
			oMap = GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", iMap);
		}
		catch (Exception e) {
			oMap.put("KK_VERILEBILIR_MI", CreditCardServicesUtil.HAYIR);
			return oMap;
		}
		
		
		oMap.put("KK_VERILEBILIR_MI",  CreditCardServicesUtil.EVET);
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN3801_BASVURU_BASLAT")
	public static GMMap tffBasvuruBaslat(GMMap iMap){
		GMMap iMap2 = new GMMap(), oMap = new GMMap(), tMap = new GMMap(), customerContactMap = new GMMap();
		
		try {
			boolean yeniBasvuruMu = StringUtils.isEmpty(iMap.getString("YENI_BASVURU"))?false:iMap.getBoolean("YENI_BASVURU");
			if ( yeniBasvuruMu){
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_TFF_TCKN_KARA_LISTE_KONTROL", iMap));
			if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) )
				return oMap;
			
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_AKTIF_BASVURU_VAR_MI", iMap));
			
			if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) )
				return oMap;
			GMMap karaListeMap = new GMMap();
			if ( CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE") )){
				boolean  fraudMu=false;

				tMap = new GMMap();
				tMap.put("TCK_NO", iMap.getString("TCKN"));
				tMap.put("TFF_BASVURU_NO", iMap.getString("BASVURU_NO"));
				tMap.put("YENI_BASVURU",yeniBasvuruMu);
				String musteriNo = "";
				String kkAlabilirMi = CreditCardServicesUtil.HAYIR;
				if (iMap.getString("UYRUK").equals("TR")) {
					
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_KPS_SORGULA", tMap));
					if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
						return oMap;
					}
					String verTarihCheck = "H";
					try {
						String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
						verTarihCheck =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, iMap.getString("SOURCE"), BnsprType.STRING, "VER_TAR_CHECK"));

						
					}
					catch (Exception e) {
						verTarihCheck = "H";
					}
					if (StringUtils.isNotEmpty(iMap.getString("NUFUS_VER_TAR")))
						iMap.put("NUFUS_VER_TAR_2", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					if ("E".equals(verTarihCheck) && iMap.getString("NUFUS_VER_TAR_2") != null && oMap.getString("VERILIS_TARIHI") != null && !(iMap.getDate("NUFUS_VER_TAR_2").equals(oMap.getDate("VERILIS_TARIHI")))) {
						
						karaListeMap.put("TCKN", iMap.getString("TCKN"));
						karaListeMap.put("CEP_TEL", iMap.getString("CEP_ULKE_KOD") +iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
						karaListeMap.put("ISLEM_ID", iMap.getString("ISLEM_ID"));
						karaListeMap.put("KILIT_SEBEP", CreditCardTffServices.TFF_KARA_LISTE_TCKN_VER_TARIH);
						karaListeMap.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
						karaListeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
						karaListeMap = GMServiceExecuter.call("BNSPR_TRN3801_TFF_KARA_LISTE_EKLE", karaListeMap);
						if ( CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(karaListeMap.getString("RESPONSE")) ){
							return karaListeMap;
						}
						fraudMu =true;
	
					}
					if (!fraudMu && yeniBasvuruMu){
						/*START CREATE CUSTOMER CONTACT*/
						customerContactMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
						customerContactMap.put("ADI", oMap.getString("AD1"));
						customerContactMap.put("SOYADI", oMap.getString("SOYAD"));
						customerContactMap.put("ONCEKI_SOYADI", oMap.getString("KIZLIK_SOYAD"));
						customerContactMap.put("ANNE_ADI", oMap.getString("ANNE_AD"));
						customerContactMap.put("BABA_ADI", oMap.getString("BABA_AD"));
						customerContactMap.put("IKINCI_ADI", oMap.getString("AD2"));
						customerContactMap.put("CINSIYET", oMap.getString("CINSIYET"));
						customerContactMap.put("MEDENI_HAL", oMap.getString("MEDENI_HALI"));
						customerContactMap.put("DOGUM_YERI", oMap.getString("DOGUM_YERI"));
						customerContactMap.put("NUFUS_IL_KOD", oMap.getString("IL_KODU"));
						customerContactMap.put("NUFUS_ILCE_KOD", oMap.getString("ILCE_KODU"));
						customerContactMap.put("KIMLIK_SERI_NO", oMap.getString("KIMLIK_SERI_NO"));
						customerContactMap.put("KIMLIK_SIRA_NO", oMap.getString("KIMLIK_SIRA_NO"));
						customerContactMap.put("NUFUS_VERILIS_TARIHI", oMap.getString("VERILIS_TARIHI"));
						customerContactMap.put("NUF_VERILIS_NEDENI", oMap.getString("VERILIS_NEDENI"));
						customerContactMap.put("NUF_VERILDIGI_YER", iMap2.getString("TC_TCKN"));
						customerContactMap.put("NUFUS_CILT_NO", oMap.getString("CILT_KODU"));
						customerContactMap.put("NUFUS_AILE_SIRA_NO", oMap.getString("AILE_SIRA_NO"));
						customerContactMap.put("NUFUS_SIRA_NO", oMap.getString("BIREY_SIRA_NO"));
						customerContactMap.put("NUFUS_MAHALLE", oMap.getString("MAHELLE_KOY"));
						customerContactMap.put("KANAL_ALT_KOD", "");
						customerContactMap.put("CEP_TEL_KOD", iMap.getString("CEP_ALAN_KOD"));
						customerContactMap.put("CEP_TEL_NO", iMap.getString("CEP_ALAN_NUMARA"));
		
						customerContactMap.put("DOGUM_IL_KOD", oMap.getString("DOGUM_IL_KODU"));
						customerContactMap.put("DOGUM_TARIHI", oMap.getString("DOGUM_TARIHI"));
						
						customerContactMap.put("TCKNO_IN", iMap.getString("TCKN"));
						customerContactMap.put("TCKNO_OUT", iMap.getString("TCKN"));
					 		   
						
						customerContactMap.put("ADRES_TIPI",iMap.getString("ADRES_TIPI"));
						customerContactMap.put("ADRES_IL_KOD",iMap.getString("UAVT_IL_KOD"));
						customerContactMap.put("ADRES_ILCE_KOD",iMap.getString("UAVT_ILCE_KOD"));
						customerContactMap.put("ACIK_ADRES",iMap.getString("UAVT_ADRES_ACIKLAMA"));
		
						customerContactMap.put("CEP_NUMARA",iMap.getString("CEP_NUMARA"));
						customerContactMap.put("CEP_ALAN_KOD",iMap.getString("CEP_ALAN_KOD"));
						customerContactMap.put("CEP_ULKE_KOD",iMap.getString("CEP_ULKE_KOD"));
						customerContactMap.put("UYRUK",iMap.getString("UYRUK"));
						customerContactMap.put("ANNE_KIZLIK_SOYADI",iMap.getString("ANNE_KIZLIK_SOYADI"));
						customerContactMap.putAll(GMServiceExecuter.call("BNSPR_TRN3801_SAVE_KONTAK_MUSTERI_GERCEK", customerContactMap));
						
						musteriNo = customerContactMap.getString("MUSTERI_NO");
					}
					/*END CREATE CUSTOMER CONTACT*/
	
					iMap2.put("MUSTERI_NO", musteriNo);
					iMap2.put("KPS_AD", oMap.getString("AD1"));
					iMap2.put("TCK_NO", iMap.getString("TCKN"));
					iMap2.put("KPS_IKINCI_AD", oMap.getString("AD2"));
					iMap2.put("KPS_SOYAD", oMap.getString("SOYAD"));
					iMap2.put("KPS_ANNE_AD", oMap.getString("ANNE_AD"));
					iMap2.put("KPS_BABA_AD", oMap.getString("BABA_AD"));
					iMap2.put("KPS_DOGUM_IL", oMap.getString("DOGUM_IL_KODU"));
					iMap2.put("KPS_DOGUM_YERI", oMap.getString("DOGUM_YERI"));
					iMap2.put("KPS_DOGUM_TARIHI", oMap.getString("DOGUM_TARIHI"));
					iMap2.put("KPS_CINSIYET", oMap.getString("CINSIYET"));
					iMap2.put("KPS_MEDENI_HAL", oMap.getString("MEDENI_HALI"));
					iMap2.put("KPS_KIZLIK_SOYAD", oMap.getString("KIZLIK_SOYAD"));
					iMap2.put("KPS_ANNE_SOYAD", oMap.getString("ANA_SOYAD"));
					iMap2.put("KPS_NUFUS_IL", oMap.getString("IL_KODU"));
					iMap2.put("KPS_NUFUS_ILCE", oMap.getString("ILCE_KODU"));
					iMap2.put("KPS_NUFUS_MAHALLE", oMap.getString("MAHELLE_KOY"));
					iMap2.put("KPS_CILT_NO", oMap.getString("CILT_KODU"));
					iMap2.put("KPS_AILE_SIRA_NO", oMap.getString("AILE_SIRA_NO"));
					iMap2.put("KPS_BIREY_SIRA_NO", oMap.getString("BIREY_SIRA_NO"));
					iMap2.put("KPS_NUFUS_VER_TAR", oMap.getString("VERILIS_TARIHI"));
					iMap2.put("KPS_ES_TCKN", oMap.getString("ES_TCKN"));
					iMap2.put("KPS_KIMLIK_SERI_NO", oMap.getString("KIMLIK_SERI_NO"));
					iMap2.put("KPS_KIMLIK_SIRA_NO", oMap.getString("KIMLIK_SIRA_NO"));
					iMap2.put("KPS_VERILIS_NEDENI", oMap.getString("VERILIS_NEDENI"));
					iMap2.put("KPS_KAYIP_CUZDAN_SERI_NO", oMap.getString("KAYIP_CUZDAN_SERI"));
					iMap2.put("KPS_KAYIP_CUZDAN_SIRA_NO", oMap.getString("KAYIP_CUZDAN_SIRA"));
					iMap2.put("KPS_VER_YER", oMap.getString("VERILDIGI_ILCE_ADI"));
					iMap2.put("18_YASINDA_MI", oMap.getString("18_YASINDA_MI"));
					if (  oMap.getString("18_YASINDA_MI").equals(CreditCardServicesUtil.EVET)){
						kkAlabilirMi = CreditCardServicesUtil.EVET;
					}
					
					iMap2.put("DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
					iMap2.put("NUFUS_VER_TAR", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					iMap2.put("TC_TCKN", iMap.getString("TCKN"));
				}
				else {
					
					iMap2.put("YABANCI_AD", iMap.getString("WEB_ADI"));
					iMap2.put("YABANCI_IKINCI_AD", iMap.getString("WEB_IKINCI_ADI"));
					iMap2.put("YABANCI_SOYAD", iMap.getString("WEB_SOYADI"));
					iMap2.put("YABANCI_DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
					
					customerContactMap.put("PASAPORT_NO", iMap.getString("PASAPORT_NO"));
					customerContactMap.put("ADI", iMap.getString("WEB_ADI"));
					customerContactMap.put("SOYADI", iMap.getString("WEB_SOYADI"));
					customerContactMap.put("DOGUM_TARIHI", oMap.getString("WEB_DOGUM_TARIHI"));
	
					customerContactMap.put("CEP_NUMARA",iMap.getString("CEP_NUMARA"));
					customerContactMap.put("CEP_ALAN_KOD",iMap.getString("CEP_ALAN_KOD"));
					customerContactMap.put("CEP_ULKE_KOD",iMap.getString("CEP_ULKE_KOD"));
					customerContactMap.put("UYRUK",iMap.getString("UYRUK"));
					customerContactMap.put("EPOSTA",iMap.getString("EMAIL"));
					customerContactMap.putAll(GMServiceExecuter.call("BNSPR_TRN3801_SAVE_KONTAK_MUSTERI_GERCEK", customerContactMap));
					musteriNo = customerContactMap.getString("MUSTERI_NO");
					iMap2.put("MUSTERI_NO", musteriNo);
				}
	
				
				if (iMap.getString("TFF_BASVURU_NO") == null) {
					tMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_BASVURU_NO", new GMMap()));
					iMap2.put("BASVURU_NO", tMap.getString("ID"));

	
				}
				else {
					iMap2.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
				}
				iMap2.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
				iMap2.put("DIL", iMap.getString("DIL"));
				iMap2.put("SOURCE", iMap.getString("SOURCE"));
				iMap2.put("DURUM_KODU","FOTO");
				iMap2.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
				iMap2.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
				iMap2.put("UYRUK_KOD", iMap.getString("UYRUK"));
				iMap2.put("PASAPORT_NO", iMap.getString("PASAPORT_NO"));

				iMap2.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
				iMap2.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
				iMap2.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
			
				iMap2.put("EMAIL", iMap.getString("EMAIL"));
				iMap2.put("KULUP", iMap.getString("KULUP"));
				iMap2.put("CEP_TEL", iMap.getString("CEP_ULKE_KOD") +iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
				iMap2.put("ISLEM_ID", iMap.getString("ISLEM_ID"));
				
				iMap2.put("DURUM_KODU","BASVURU");
				iMap2.put("TRX_SONLANDIR", false);
				iMap2.put("FRAUD_MU", fraudMu);
				String euptUserId="";
				if (!fraudMu && yeniBasvuruMu){
					GMMap euptRegInput=createEuptRegisterInput(iMap2);
					try {
						GMMap euptMap = new GMMap();
						euptMap.putAll(GMServiceExecuter.execute("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", euptRegInput));
						//euptMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", euptRegInput));
						euptUserId = euptMap.getString("USERID");
						iMap2.put("EUPT_USER_ID", euptUserId);
						
						
					}
					catch (Exception e) {
						logger.error(e);
					}
				}
				
				GMMap sonTxMap = new GMMap ();
				if ( !yeniBasvuruMu )
					sonTxMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_TFF_SON_TRX_BUL", iMap));
				else
					sonTxMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sonTxMap.getString("RESPONSE"))){
					iMap2.put("TRX_NO", sonTxMap.getString("TRX_NO"));
				}
				else{
					if (oMap.getString("TRX_NO") == null) {
						tMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
						iMap2.put("TRX_NO", tMap.getString("TRX_NO"));
					}
					else {
						iMap2.put("TRX_NO", oMap.getString("TRX_NO"));
					}
				}
				oMap = new GMMap();
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SAVE", iMap2));
	
				tMap.put("GENDER_CODE", iMap2.getString("KPS_CINSIYET"));
				tMap.put("TOWN_CODE", iMap2.getString("KPS_NUFUS_IL"));
				tMap.put("DISTRICT_CODE", iMap2.getString("KPS_NUFUS_ILCE"));
				
				if ( fraudMu){
					return karaListeMap;
				}
				else{
					oMap.put("ISLEM_NO", iMap2.getString("TRX_NO"));
					oMap.put("KK_ALABILIR_MI", kkAlabilirMi);
					oMap.put("RESPONSE", "2");
					oMap.put("RESPONSE_DATA", oMap.getString("MESSAGE"));
					oMap.put("TFF_BASVURU_NO", iMap2.getString("BASVURU_NO"));
					oMap.put("EUPT_REF_ID", euptUserId);
				}
				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3801_BASVURU_URUN_GUNCELLE")
	public static GMMap tffUrunGuncelle(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			
			
			if ( !CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) )
				return oMap;
			
			
			GMMap basvuruMap = new GMMap();

			

			basvuruMap.put("KART_TIPI", iMap.getString("KART_TIPI"));
			basvuruMap.put("KULUP_URUN", iMap.getString("URUN"));
			basvuruMap.put("KULUP_URUN_SAHIP",  iMap.getString("URUN_SAHIBI"));
			if ( StringUtils.isNotEmpty(iMap.getString("ISLEM_NO")) ){
				TffBasvuruTx tffBasvuruTx = null;
				tffBasvuruTx = (TffBasvuruTx)session.get(TffBasvuruTx.class,iMap.getBigDecimal("ISLEM_NO"));
				
				if ( tffBasvuruTx == null ){
					oMap.put("RESPONSE_DATA", CreditCardTffServices.errorMessageOlustur("3043","E"));
					oMap.put("RESPONSE","1");
					return oMap;
				}
				basvuruMap.put("BASVURU_NO", tffBasvuruTx.getBasvuruNo());
				basvuruMap.put("TRX_NO", iMap.get("ISLEM_NO"));
				if (CreditCardTRN3802Services.BASVURU.equals( tffBasvuruTx.getDurumKod() )){
					basvuruMap.put("DURUM_KODU", CreditCardTRN3802Services.FOTO);
				}
				else{
					basvuruMap.put("DURUM_KODU",  tffBasvuruTx.getDurumKod());
				}
				
				basvuruMap.put("KULUP", tffBasvuruTx.getTakim());
				basvuruMap.put("TC_TCKN", tffBasvuruTx.getTcKimlikNo());
				basvuruMap.put("KURYE_TIPI", tffBasvuruTx.getKuryeTipi());
				basvuruMap.put("CALISMA_SEKLI", tffBasvuruTx.getCalismaSekli());
				basvuruMap.put("EUPT_USER_ID", tffBasvuruTx.getEuptUserId());
				basvuruMap.put("MUSTERI_NO",tffBasvuruTx.getMusteriNo());
				basvuruMap.put("EMAIL", tffBasvuruTx.getEPosta());
				basvuruMap.put("CLIENT_SESSION_ID",tffBasvuruTx.getSessionIp());
				
			}
			else{
				
				
				if ( StringUtils.isNotEmpty(iMap.getString("BASVURU_NO")) ){
					GMMap trxMap = new GMMap ();
					trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
					trxMap.put("TRX_NO", trxMap.getString("TRX_NO"));
					
					TffBasvuru tffBasvuru = (TffBasvuru)session.get(TffBasvuru.class,iMap.getBigDecimal("BASVURU_NO"));
					
					basvuruMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					basvuruMap.put("TRX_NO", trxMap.getString("TRX_NO"));
					basvuruMap.put("DURUM_KODU", tffBasvuru.getDurumKod());
					basvuruMap.put("KULUP", tffBasvuru.getTakim());
					basvuruMap.put("TC_TCKN", tffBasvuru.getTcKimlikNo());
					basvuruMap.put("KURYE_TIPI", tffBasvuru.getKuryeTipi());
					basvuruMap.put("CALISMA_SEKLI", tffBasvuru.getCalismaSekli());
					basvuruMap.put("EUPT_USER_ID", tffBasvuru.getEuptUserId());
					basvuruMap.put("MUSTERI_NO",tffBasvuru.getMusteriNo());
					basvuruMap.put("EMAIL", tffBasvuru.getEPosta());
					basvuruMap.put("CLIENT_SESSION_ID",tffBasvuru.getSessionIp());
				}
			}
			
		/*	if ( uyeNo != null ){
				GMMap aktifBasvuruKontrolMap = new GMMap();
				aktifBasvuruKontrolMap.put("UYE_NO", uyeNo);
				aktifBasvuruKontrolMap.put("TFF_BASVURU_NO", basvuruMap.getString("BASVURU_NO"));
				aktifBasvuruKontrolMap.put("KULUP_URUN", basvuruMap.getString("KULUP_URUN"));
				aktifBasvuruKontrolMap.put("KULUP_URUN_SAHIP", basvuruMap.getString("KULUP_URUN_SAHIP"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_UYE_AKTIF_BASVURU_VAR_MI", basvuruMap));
				if ( CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE") )){
					return oMap;
				}
				oMap = new GMMap();
			}
			*/
			
			GMMap trxMap = new GMMap();
			trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SAVE_BASVURU", basvuruMap));
			// Ana tablolara kayitlari kaydet
			iMap.put("TRX_NAME", "3801");
			iMap.put("TRX_NO",basvuruMap.getString("TRX_NO"));
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			oMap.put("RESPONSE", "2");
			oMap.put("BASVURU_NO", basvuruMap.getString("BASVURU_NO"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
		
	}

	//--------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------- EKRAN
	//--------------------------------------------------------------------------------------------
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since 25.02.2014, TY-3969
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 * 		   <li>IL_LIST - Iller
	 *         <li>KULUP_LIST - Takim listesi
	 *         <li>URUN_LIST - Urun tipi listesi
	 *         <li>KART_TIPI_LIST - TFF kart tipleri kredi kartli
	 *         <li>KART_TIPI_LIST_TFF - TFF kart tipleri kredi kartsiz
	 *         <li>CALISMA_SEKLI - Calisma sekilleri
	 *         <li>OGRENIM_LIST - Ogrenim durumu listesi
	 *         <li>BANKA_TARIH - Banka tarihi
	 *         <li>KULLANICI_KOD - Islemi yapan kullanici kodu
	 *         <li>PTT_TESLIMAT_NOKTASI - Ptt teslimat noktalari
	 *         <li>STAD_TESLIMAT_NOKTASI - Stad teslimat noktalari
	 *         <li>TESLIMAT_NOKTASI - Butun teslimat noktalari
	 *         <li>VERGI_DAIRESI_IL_LIST - Vergi dairelerinin bulundugu iller
	 *         <li>AKTIF_PTT_TESLIMAT_NOKTASI - Aktif Ptt teslimat noktalari
	 *         <li>AKTIF_STAD_TESLIMAT_NOKTASI - Aktif Stad teslimat noktalari
	 */
	@GraymoundService("BNSPR_TRN3801_INITIALIZE")
	public static GMMap initialize3801(GMMap iMap) {
		GMMap oMap = new GMMap();
		String query = null;

		try {
			// Il
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_ILLER", iMap));//IL_LIST
			
			//Kulup
			query = "SELECT kod, adi FROM BNSPR.urun_sahip ORDER BY adi";
			DALUtil.fillComboBox(oMap, "KULUP_LIST", true, query);
			
			//Urun
			oMap.putAll(CreditCardServicesUtil.getParameterList("URUN_LIST", "TFF_BASVURU_URUN_KOD", "A", "E"));
			
			//Kart Tipi - Hepsi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			
			//Kart Tipi - KKs�z
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST_TFF", "TFF_KART_TIPI", "TFF", "E"));
			
			//Calisma sekli
			query = "select key1 kod, text adi from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' order by sira_no";
			DALUtil.fillComboBox(oMap, "CALISMA_SEKLI", true, query);
			
			//Ogrenim
			query = "select kod, aciklama from v_ml_gnl_egitim_kod_pr order by sira_no";
			DALUtil.fillComboBox(oMap, "OGRENIM_LIST", true, query);
			
			//Banka Tarihi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_BANKA_TARIH", iMap));//BANKA_TARIH
			
			//Kullanici kodu
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap));//KULLANICI_KOD

	    	//PTT/Stad Bilgisini al
	    	oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_PTT_STADIUM_LIST", iMap));
	    	
	    	//Vergi dairesi il
	    	oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_VERGI_DAIRESI_ILLERI", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** TFF basvurusunda teslimat adresi olarak kullanilabilecek PTT Subeleri/Stad Giselerini listeler<br>
	 * @author murat.el
	 * @since TY-3969
	 * @param iMap - Input yok<br>
	 * @return Teslimat noktasi tipine gore listeler<br>
	 *         <li>PTT_TESLIMAT_NOKTASI -  PTT Subeleri
	 *         <li>STAD_TESLIMAT_NOKTASI - Stad Giseleri
	 *         <li>TESLIMAT_NOKTASI - Hem PTT Subeleri hem Stad Giseleri
	 *         <li>AKTIF_PTT_TESLIMAT_NOKTASI - Aktif PTT Subeleri
	 *         <li>AKTIF_STAD_TESLIMAT_NOKTASI - Aktif Stad Giseleri
	 */
	@GraymoundService("BNSPR_TRN3801_GET_PTT_STADIUM_LIST")
	public static GMMap getPttStadList(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Listeleri al
			GMMap sorguMap = new GMMap();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_GET_PTT_STADIUM_LIST", sorguMap));
			oMap.putAll(sorguMap);
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				return oMap;
			}
			//Aktif PTT listeleri bul
			String noktaListName = "PTT_TESLIMAT_NOKTASI";
			String aktifNoktaListName = "AKTIF_PTT_TESLIMAT_NOKTASI";
			for (int i=0, j=0; i<sorguMap.getSize(noktaListName); i++) {
				//Aktif mi?
				if ("Y".equals(sorguMap.getString(noktaListName, i, "IS_VALID"))) {
					oMap.put(aktifNoktaListName, j, sorguMap.getMap(noktaListName, i));
					j++;
				}
			}
			//Aktif Stadyum listeleri bul
			noktaListName = "STAD_TESLIMAT_NOKTASI";
			aktifNoktaListName = "AKTIF_STAD_TESLIMAT_NOKTASI";
			for (int i=0, j=0; i<sorguMap.getSize(noktaListName); i++) {
				//Aktif mi?
				if ("Y".equals(sorguMap.getString(noktaListName, i, "IS_VALID"))) {
					oMap.put(aktifNoktaListName, j, sorguMap.getMap(noktaListName, i));
					j++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** TFF basvurusuna ya da islemine ait bilgileri listeler.<br>
	 * @author murat.el
	 * @since 25.02.2014
	 * @param iMap - Sorgu kriterleri<br>
	 *         <li>KART_TIPI - TFF kart tipi
	 *         <li>DOGUM_TARIHI - Basvuru sahibi dogum tarihi
	 *         <li>URUN - TFF urun kodu
	 *         <li>SOURCE - Basvuru kanali
	 * @return oMap - Urun tipleri<br>
	 *         <li>URUN_SAHIP_LIST - Urun tipleri
	 */
	@GraymoundService("BNSPR_TRN3801_GET_URUN_SAHIPLER")
	public static GMMap listUrunSahip(GMMap iMap) {
		GMMap oMap = new GMMap();
		String listName = "URUN_SAHIP_LIST";

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			query = "{? = call PKG_TFF_BASVURU.Urun_Sahip_List(?,?,?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("URUN"));
			stmt.setString(3, iMap.getString("KART_TIPI"));
			if (iMap.getDate("DOGUM_TARIHI") != null) {
				stmt.setDate(4, new java.sql.Date(iMap.getDate("DOGUM_TARIHI").getTime()));
			} else {
				stmt.setDate(4, null);
			}
			stmt.setString(5, iMap.getBoolean("YENI_BASVURU") ? "E" : "H");
			stmt.setString(6, iMap.getString("SOURCE"));
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			
			oMap.put(listName, 0, "VALUE", StringUtils.EMPTY);
			oMap.put(listName, 0, "NAME", " ");
			oMap.put(listName, 0, "URUN_ID", StringUtils.EMPTY);
			for (int i=1; rSet.next(); i++) {
				oMap.put(listName, i, "VALUE", rSet.getString(1));
				oMap.put(listName, i, "NAME", rSet.getString(2));
				oMap.put(listName, i, "URUN_ID", rSet.getString(3));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** TFF basvurusuna ya da islemine ait bilgileri listeler.<br>
	 * @author murat.el
	 * @since 25.02.2014
	 * @param iMap - Sorgu kriterleri<br>
	 *         <li>BASVURU_NO - TFF basvuru numarasi
	 *         <li>TRX_NO - TFF basvuru islem numarasi
	 * @return oMap - Ekranda gosterilecek basvuru bilgileri<br>
	 */
	@GraymoundService("BNSPR_TRN3801_GET_BASVURU_BILGI")
	public static GMMap getBasvuruBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			query = "{? = call PKG_TRN3801.Rc_Qry3801_Get_Basvuru_Bilgi(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
			oMap.put("KK_RED_IPTAL_MI", oMap.getString("KK_RED_IPTAL_MI", "0"));//Boolean
			oMap.put("KDH_ISTIYOR_MU", BooleanUtils.toBoolean(CreditCardServicesUtil.nvl(oMap.getString("KDH_ISTIYOR_MU"), CreditCardServicesUtil.HAYIR),
					CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
			
			//KDH Basvuru bilgilerini al
			if (oMap.getBoolean("KDH_ISTIYOR_MU")) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_KDH_BASVURU_BILGI", iMap));
			} else {
				oMap.put("EKSTRE_TIPI_EMAIL_MI", 0);
				oMap.put("EKSTRE_TIPI_POSTA_MI", 0);
				oMap.put("OTOMATIK_LIMIT_ARTIS", 0);
				oMap.put("EKSTRE_ADRESI_EV_MI", 0);
				oMap.put("EKSTRE_ADRESI_IS_MI", 0);
				oMap.put("KK_OTOMATIK_ODEME", 0);
				oMap.put("BK_OTOMATIK_ODEME", 0);
				oMap.put("SIGORTA_OTOMATIK_ODEME", 0);
				oMap.put("OTOMATIK_TALIMAT_ODEME", 0);
				oMap.put("DUZENLI_TALIMAT_ODEME", 0);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** TFF kdh basvurusuna ya da islemine ait bilgileri listeler.<br>
	 * @author murat.el
	 * @since 25.02.2014
	 * @param iMap - Sorgu kriterleri<br>
	 *         <li>BASVURU_NO - TFF basvuru numarasi
	 *         <li>TRX_NO - TFF basvuru islem numarasi
	 * @return oMap - Ekranda gosterilecek basvuru bilgileri<br>
	 */
	@GraymoundService("BNSPR_TRN3801_GET_KDH_BASVURU_BILGI")
	public static GMMap getKdhBasvuruBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			query = "{? = call PKG_TRN3801.Rc_Qry3801_Kdh_Basvuru_Bilgi(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
			//Kontrol
			if (oMap.isEmpty()) {
				oMap.put("EKSTRE_TIPI_EMAIL_MI", 0);
				oMap.put("EKSTRE_TIPI_POSTA_MI", 0);
				oMap.put("OTOMATIK_LIMIT_ARTIS", 0);
				oMap.put("EKSTRE_ADRESI_EV_MI", 0);
				oMap.put("EKSTRE_ADRESI_IS_MI", 0);
				oMap.put("KK_OTOMATIK_ODEME", 0);
				oMap.put("BK_OTOMATIK_ODEME", 0);
				oMap.put("SIGORTA_OTOMATIK_ODEME", 0);
				oMap.put("OTOMATIK_TALIMAT_ODEME", 0);
				oMap.put("DUZENLI_TALIMAT_ODEME", 0);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	//--------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------- JEST
	//--------------------------------------------------------------------------------------------
	/** Alinan bilgilerle aktif nokta tff basvuru ve uye kaydini olusturur/gunceller.<br>
	 * @param iMap - Uye/Basvuru bilgileri<br>
	 *		  @see {@link tr.com.aktifbank.bnspr.tff.services.TffCommonServices#createOrUpdateMember(GMMap)}
	 *        @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3811Services.#saveBasvuru(GMMap)}
	 *        @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3811Services.#saveKimlik(GMMap)}
	 *        @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3811Services.#saveAdres(GMMap)}
	 *        @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3811Services.#saveTelefon(GMMap)}
	 *        @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3811Services.#saveMeslek(GMMap)}
	 *        FOTO_DEGER_BASE64 - Fotograf icerigi
	 * @return Islem sonucu<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_JEST")
	public static GMMap saveJest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap uyeMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//1. Turk vatandasi ise KPS sorgusu yap.
			if ("TR".equals(iMap.getString("UYRUK_KOD"))) {
				sorguMap.clear();
				sorguMap.put("TCKN", iMap.get("TCKN"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", sorguMap));
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					iMap.put("KIMLIK_SERI_NO", CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO"), sorguMap.getString("KIMLIK_SERI_NO")));
					iMap.put("KIMLIK_SIRA_NO", CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO"), sorguMap.getString("KIMLIK_SIRA_NO")));
					iMap.put("AILE_SIRA_NO", sorguMap.get("AILE_SIRA_NO"));
					iMap.put("ANNE_AD", sorguMap.get("ANNE_AD"));
					iMap.put("BABA_AD", sorguMap.get("BABA_AD"));
					iMap.put("BIREY_SIRA_NO", sorguMap.get("BIREY_SIRA_NO"));
					iMap.put("CILT_KODU", sorguMap.get("CILT_KODU"));
					iMap.put("CINSIYET", sorguMap.get("CINSIYET"));
					iMap.put("DOGUM_YERI", sorguMap.get("DOGUM_YERI"));
					iMap.put("ES_TCKN", sorguMap.get("ES_TCKN"));
					//TODO iMap.put("KAYIP_CUZDAN_SERI_NO", sorguMap.get("KAYIP_CUZDAN_SERI_NO"));
					//TODO iMap.put("KAYIP_CUZDAN_SIRA_NO", sorguMap.get("KAYIP_CUZDAN_SIRA_NO"));
					iMap.put("MAHALLE_KOY", sorguMap.get("MAHALLE_KOY"));
					iMap.put("MEDENI_HALI", sorguMap.get("MEDENI_HALI"));
					iMap.put("ILCE_KODU", sorguMap.get("ILCE_KODU"));
					iMap.put("IL_KODU", sorguMap.get("IL_KODU"));
					iMap.put("VERILIS_NEDENI", sorguMap.get("VERILIS_NEDENI"));
					iMap.put("VERILIS_TARIHI", sorguMap.get("VERILIS_TARIHI"));
					iMap.put("VERILDIGI_ILCE_ADI", sorguMap.get("VERILDIGI_ILCE_ADI"));
					iMap.put("KIZLIK_SOYAD", sorguMap.get("KIZLIK_SOYAD"));
				} else {
					sorguMap.clear();
					sorguMap.put("WEB_HATA_KOD", sorguMap.getString("RESPONSE_DATA"));
					sorguMap.put("SOURCE", "GENEL");
					sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", sorguMap));
					throw new GMRuntimeException(0, "KPS sorgusu sirasinda hata olustu : " + sorguMap.getString("HATA_MESAJI"));
				}
			}
			
			//2. Basvuru kayit islemleri
			iMap.put("CLIENT_IP", ADCSession.getString("CLIENT_IP"));
			//Email ekrandan bos olsa bile @ ile geliyor.
			if ("@".equals(iMap.getString("EMAIL").trim())) {
				iMap.put("EMAIL", StringUtils.EMPTY);
			}
			//Meslek secilmemisse Diger olsun
			if (StringUtils.isBlank(iMap.getString("MESLEK"))) {
				iMap.put("MESLEK", "14");
			}
			//Kurye tipi belirle
			String teslimatAdresi = iMap.getString("TESLIMAT_ADRESI_TIPI");
			if ("E".equals(teslimatAdresi) || "I".equals(teslimatAdresi) || "D".equals(teslimatAdresi)) {
				iMap.put("KURYE_TIPI", "S");
			} else {
				iMap.put("KURYE_TIPI", teslimatAdresi);
			}
			
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SAVE_OR_UPDATE", iMap));
			oMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			
			//Alan kontrolleri
			//Basvuru
			sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3801_AFTER_CONTROL", sorguMap);
			
			//Foto
			if (StringUtils.isBlank(iMap.getString("FOTO_DEGER_BASE64"))) {
				CreditCardServicesUtil.raiseGMError("330", "Fotograf");
			}
			
			//3. Uye kayit islemleri
			uyeMap.clear();
			uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SAVE_OR_UPDATE_UYE", iMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(uyeMap.getString("RESPONSE"))) {
				if (StringUtils.isBlank(uyeMap.getString("RESPONSE_DATA"))) {
					throw new GMRuntimeException(0, "Uye bilgileri guncellenirken hata olustu");
				} else {
					sorguMap.clear();
					sorguMap.put("WEB_HATA_KOD", uyeMap.getString("RESPONSE_DATA"));
					sorguMap.put("SOURCE", "GENEL");
					sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", sorguMap));
					throw new GMRuntimeException(0, "Uye bilgileri guncellenirken hata olustu : " + sorguMap.getString("HATA_MESAJI"));
				}
			} else {
				if (StringUtils.isBlank(uyeMap.getString("UYE_NO"))) {
					throw new GMRuntimeException(0, "Uye Kaydi Olusturulamadi");
				} else {
					oMap.put("UYE_NO", uyeMap.get("UYE_NO"));
				}
			}
			
			//4. Uye, musteri, eupt numarasini guncelle
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Isleme ait bilgileri al
			TffBasvuruTx tffBasvuruTx = (TffBasvuruTx) session.get(TffBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruTx != null){
				tffBasvuruTx.setTffUyeNo(uyeMap.getBigDecimal("UYE_NO"));
				tffBasvuruTx.setMusteriNo(uyeMap.getBigDecimal("MUSTERI_NO"));
				tffBasvuruTx.setEuptUserId(uyeMap.getString("EUPT_REF_ID"));
				session.saveOrUpdate(tffBasvuruTx);
				session.flush();
			} else {
				throw new GMRuntimeException(0, "Basvuru uzerinde uye bilgisi guncellenemedi");
			}
			
			//5. Aktif basvuru/karti var mi?
			sorguMap.clear();
			sorguMap.put("UYE_NO", tffBasvuruTx.getTffUyeNo());
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("URUN_KODU", iMap.get("URUN_KODU"));
			sorguMap.put("URUN_SAHIP_KODU", iMap.get("URUN_SAHIP_KODU"));
			sorguMap.put("SOURCE", iMap.get("SOURCE"));
			sorguMap.put("KART_TIPI", iMap.get("KART_TIPI"));
			sorguMap.put("MUSTERI_NO", tffBasvuruTx.getMusteriNo());
			sorguMap.put("TCKN", iMap.get("TCKN"));
			if(!iMap.containsKey("URUN_ID")){
				
				TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO")); 
				String isUnder18S = "H";
				try{
				boolean isUnder18 = TffCommonServices.isUnder18(tffUyeler.getDogumTarihi());
				
				if(isUnder18){
					isUnder18S =  "E"; 
				}
				}catch(Exception e){
					
				}
				List<TffSsProductMap> tffSsProductMapList = (List<TffSsProductMap>) 
						session.createCriteria(TffSsProductMap.class).add(Restrictions.eq("kartTipi", iMap.getString("KART_TIPI")))
						.add(Restrictions.eq("urunSahipKod", iMap.getString("URUN_SAHIP_KODU"))).add(Restrictions.eq("gecerli", "E"))
						.add(Restrictions.eq("under18", isUnder18S)).list();
				
				TffSsProductMap tffSsProductMap = null;
				
				if(tffSsProductMapList == null || tffSsProductMapList.size() <= 0){
					
				}
				else{
					 tffSsProductMap = (TffSsProductMap)tffSsProductMapList.get(0);
					 sorguMap.put("URUN_ID", tffSsProductMap != null ?  tffSsProductMap.getUrunId() : null);
					 
				}
			}
			
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				uyeMap.clear();
				uyeMap.put("WEB_HATA_KOD", sorguMap.getString("RESPONSE_DATA"));
				uyeMap.put("SOURCE", "GENEL");
				uyeMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", uyeMap));
				throw new GMRuntimeException(0, uyeMap.getString("HATA_MESAJI"));
			}
			
			//6. Islemi Sonlandir
			sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SEND_TRANSACTION", sorguMap));
			
			//7. Fotograf islemleri
			//Fotograf ekle.
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("UYRUK_KOD", iMap.get("UYRUK_KOD"));
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TCKN"));
			sorguMap.put("PASAPORT_NO", iMap.get("PASAPORT_NO"));
			sorguMap.put("FOTO_BYTE_ARRAY", iMap.get("FOTO_DEGER_BASE64"));
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TFF_CORE_FOTO_YUKLE", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				uyeMap.clear();
				uyeMap.put("WEB_HATA_KOD", sorguMap.getString("RESPONSE_DATA"));
				uyeMap.put("SOURCE", "GENEL");
				uyeMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", uyeMap));
				throw new GMRuntimeException(0, "Foto eklenirken hata olustu : " + uyeMap.getString("HATA_MESAJI"));
			}
			
			//Fotografi onayla
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TFF_GISE_FOTO_GUNCELLE", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				uyeMap.clear();
				uyeMap.put("WEB_HATA_KOD", sorguMap.getString("RESPONSE_DATA"));
				uyeMap.put("SOURCE", "GENEL");
				uyeMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", uyeMap));
				throw new GMRuntimeException(0, "Onayli foto eklenirken hata olustu : " + uyeMap.getString("HATA_MESAJI"));
			}
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuru.setFotoDurum("T"); 
			session.save(tffBasvuru);
			//Durumu guncelle
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("ISLEM_NO", iMap.get("TRX_NO"));
			sorguMap.put("DURUM_KOD", "ODEME");
			sorguMap.put("ISLEM_ACIKLAMA", "Jest Kart foto eklendi");
			sorguMap.put("TARIHCE_AKSIYON", "E");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap));
			
			//8. Odeme islemleri : 0 tutarli bir kayit olustur
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("KART_BEDELI", BigDecimal.ZERO);
			sorguMap.put("KURYE_BEDELI", BigDecimal.ZERO);
			sorguMap.put("LOYALTY_BEDELI", BigDecimal.ZERO);
			sorguMap.put("PROMOSYON_BEDELI", BigDecimal.ZERO);
			sorguMap.put("ODEME_TIPI", "N");//Nakit
			sorguMap.put("VIZE_BEDELI", BigDecimal.ZERO);
			sorguMap.put("KURYE_TIPI", iMap.get("KURYE_TIPI"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3802_ODEME_YAP", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				uyeMap.clear();
				uyeMap.put("WEB_HATA_KOD", sorguMap.getString("RESPONSE_DATA"));
				uyeMap.put("SOURCE", "GENEL");
				uyeMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", uyeMap));
				throw new GMRuntimeException(0, "Odeme sirasinda hata olustu : " + uyeMap.getString("HATA_MESAJI"));
			} else {
				oMap.put("ODEME_TRX_NO", sorguMap.get("ISLEM_NO"));
			}
						
			//9. Basim
			//Islem no al. Odeme sonrasi basima gecmezse calisir. Olmamasi lazim.
			BigDecimal basimTrxNo =  oMap.getBigDecimal("ODEME_TRX_NO");
			//Durum kodu basim degilse guncelle.
			
			if (tffBasvuru != null) {
				session.refresh(tffBasvuru);
				if (!"BASIM".equals(tffBasvuru.getDurumKod())) {
					//Tarihcede intraya duserse dogru kaydi guncellemesi icin yeni islem no alindi
					sorguMap.clear();
					basimTrxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap).getBigDecimal("TRX_NO");
					oMap.put("BASIM_TRX_NO", basimTrxNo);
					
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
					sorguMap.put("ISLEM_NO", basimTrxNo);
					sorguMap.put("DURUM_KOD", "BASIM");
					sorguMap.put("ISLEM_ACIKLAMA", "Jest Kart odeme yapildi");
					sorguMap.put("TARIHCE_AKSIYON", "E");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap));
				}
			}
			//Bas
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("ISLEM_NO", basimTrxNo);
			sorguMap.put("DURUM_KOD", "BASIM");
			sorguMap.put("KART_TIPI", iMap.get("KART_TIPI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", sorguMap));
			
			//10.Musteri bilgilerini guncelle.
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("SOURCE", "TFF");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Pathi verilen ya da default olarak olusturulan pathdeki resmi alarak string formatinda encode ederek doner.
	 * 
	 * @author murat.el
	 * @since PY-7119
	 * @param iMap - FILE, FILE_NAME, TC_KIMLIK_NO, PASAPORT_NO, UYRUK_KOD, TFF_BASVURU_NO, HATA_VERILSIN_MI
	 * @return oMap - FOTO_DEGER, FOTO_PATH
	 */
	@GraymoundService("BNSPR_TRN3801_GET_FOTO")
	public static GMMap getBasvuruFoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Parametre kontrol
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				if (StringUtils.isBlank(iMap.getString("UYRUK_KOD"))) {
					CreditCardServicesUtil.raiseGMError("330", "Uyruk Bilgisi");
				}
				
				if (StringUtils.isBlank(iMap.getString("TC_KIMLIK_NO")) || 
						StringUtils.isBlank(iMap.getString("PASAPORT_NO"))) {
					CreditCardServicesUtil.raiseGMError("330", "Kimlik Bilgisi");
				}
			}

			//foto kaydedilecekse dosyayi server uzerine yaz.
			String serverFilePath = null;
			if (StringUtils.isNotBlank(iMap.getString("FILE"))) {
				sorguMap.clear();
				sorguMap.put("FILE", iMap.get("FILE"));
				sorguMap.put("FILE_NAME", iMap.get("FILE_NAME"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COPY_FILE_TO_SERVER_TEMP", sorguMap));
				serverFilePath = sorguMap.getString("SERVER_PATH");
			}
			
			//Kaydedilecekse dosyayi server uzerinden oku, yoksa kimlik no ve basvuru no ile foto dizininden al.
			sorguMap.clear();
			sorguMap.put("FILE_PATH", serverFilePath);
			sorguMap.put("TC_KIMLIK_NO", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("PASAPORT_NO", iMap.get("PASAPORT_NO"));
			sorguMap.put("UYRUK_KOD", iMap.get("UYRUK_KOD"));
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_GET_FOTO", sorguMap));
		} catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			}
		}
		
		return oMap;
	}
	
}
