package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;
import org.joda.time.Years;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlMusteriDegisen;
import tr.com.aktifbank.bnspr.dao.GnlMusteriDegisenId;
import tr.com.aktifbank.bnspr.dao.KartBasvuruTalep;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriAdres;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import common.Logger;

public class CreditCardDocumentServices extends TffServicesHelper {

	private static final Logger logger = Logger.getLogger(CreditCardDocumentServices.class);

	private static final String KONTAKT_MUSTERI = "K";
	private static final String DOKUMAN_SORGU_TIPI_BASVURU = "B";
	private static final String DOKUMAN_SORGU_TIPI_MUSTERI = "M";
	private static final String DOKUMAN_SORGU_TIPI_HEPSI = "H";
	private static final String DOKUMAN_SORGU_TIPI_P2D = "P2D";
	private static final String DOKUMAN_SORGU_TIPI_DAGITIM_KOD = "DK";
	private static final String DOKUMAN_ISLEM_FTP_AKTAR = "F";
	private static final String DOKUMAN_ISLEM_MUSTERI_ISARETLE = "M";
	private static final String DOKUMAN_ISLEM_HEPSI = "H";
	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	private static final String DOCUMENT_TABLE = "DOCUMENT_TABLE";
	private static final String DAGITIM_KODU_BOS = "999";
	private static final String DAGITIM_KODU_TFF_GISE = "843";
	private static final String DAGITIM_KODU_TFF_KURYE = "842";



	// ---------------------------------------------------------------------
	// ******************************************************* AKTIVASYON
	// ---------------------------------------------------------------------
	/**
	 * Basim asamasindaki basvurularin belge kontrolu yapildiktan sonra
	 * musteri, hesap ve kart tamamlama islemleri gerceklestirilir
	 * 
	 * @author murat.el
	 * @param iMap
	 *            -Aktivasyon yapilacak kart/basvuru bilgisi <li>CARD_NO - Kart numarasi (Zorunlu) <li>APPLICATION_NO - Basvuru numarasi
	 */
	@GraymoundService("BNSPR_TFF_BASVURU_AKTIVASYON")
	public static GMMap controlTffBasvuruBelge(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Belgeler tamamlandiysa musteri,hesap ve kart islemlerini tamamla.
			// 1.Basvuru musteri bilgisini al.
			String kartNo = iMap.getString("CARD_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
			GMMap musteriBilgiMap = new GMMap();
			musteriBilgiMap.putAll(getBasvuruMusteriInfo(kartNo, basvuruNo));// KART_NO
			// Hep parametre olarak gelen kart numarasi islemlerde esas olacak, basvuru no gelemeyebileceginden
			// fonk.dan donen deger ile tazelenir.
			if (musteriBilgiMap.isEmpty()) {
				GMMap kartMap = new GMMap();
				kartMap.put("CARD_NO", kartNo);
				kartMap.put("STATUS", CreditCardServicesUtil.NO);
				kartMap.put("SUBSTATUS", CreditCardServicesUtil.NO);
				kartMap.put("EMBOSS_CODE", " ");
				oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_UPDATE_CARD_STATUS", kartMap));

				oMap.put("RESPONSE_DATA", "Basvuru numarasi bulunamadi. Kart aktivasyon cagirildi");
				return oMap;
			}
			else {
				basvuruNo = musteriBilgiMap.getBigDecimal("BASVURU_NO");
				iMap.putAll(musteriBilgiMap);
					if ("ACIK".equals(iMap.getString("DURUM_KODU"))) {
						GMMap kartMap = new GMMap();
						kartMap.put("CARD_NO", kartNo);
						kartMap.put("STATUS", CreditCardServicesUtil.NO);
						kartMap.put("SUBSTATUS", CreditCardServicesUtil.NO);
						kartMap.put("EMBOSS_CODE", " ");
						oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_UPDATE_CARD_STATUS", kartMap));
	
						oMap.put("RESPONSE_DATA", "Durum acik tekrar kart aktivasyon cagirildi");
						return oMap;
					}
			}

			// basvuru durumu basim degilse cik.
			if (!"BASIM".equals(iMap.getString("DURUM_KODU"))) {
				CreditCardServicesUtil.raiseGMError("2701", basvuruNo, iMap.getString("DURUM_KODU"), "BASIM");
			}

			// 2.musteri kontak ise gercege cevrilmelidir.
			if (KONTAKT_MUSTERI.equals(iMap.getString("MUSTERI_KONTAKT"))) {
				// Gercek musteriye cevrilsin mi?
				boolean isGercekMusteri = false;
				// 18 yasindan buyuk prepaid kart sahibleri anne kizlik soyadini vermiyorsa cevirme.
				if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(iMap.getString("KART_TIPI"))) {
					isGercekMusteri = false;
					/* PY-
					boolean is18YasUstu = CreditCardServicesUtil.EVET.equals(iMap.getString("YAS_KONTROL"));
					boolean isYerli = "TR".equals(iMap.getString("UYRUK_KOD"));
					if (is18YasUstu && isYerli && StringUtils.isNotBlank(iMap.getString("ANNE_KIZLIK_SOYADI"))) {
						//instant kart basim ise gercege cevirme
						if ("NTS01".equals(iMap.getString("SOURCE")) && "A".equals(iMap.getString("KURYE_TIPI"))) {
							isGercekMusteri = false;
						} else if ("JEST".equals(iMap.getString("SOURCE"))) {
							isGercekMusteri = false;
						} else {
							isGercekMusteri = true;
						}
					}
					*/
				}
				else {// Debit icin musteri gercege cevrilir.
					isGercekMusteri = true;
				}
				// Gercek musteriye cevir
				if (isGercekMusteri) {
					try {
						iMap.put("SISTEM", "INTRA");
						oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
					}
					catch (Exception e) {
						GMMap sorguMap = new GMMap();
						sorguMap.put("TFF_BASVURU_NO", basvuruNo);
						GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
						oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
					}
				}
				// 3.musteri gercek ise basvuru bilgileri ile guncellenir.
			}/* PY-6705
				else if (GERCEK_MUSTERI.equals(iMap.getString("MUSTERI_KONTAKT"))) {
				iMap.put("KAYNAK","TFF");
				iMap.put("TUR","TFFKART");
				oMap.putAll(GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", iMap));
				}*/

			// 4.Kart debit ise Vadesiz hesap ac, cati Hesabina Cevir
			iMap.put("BASVURU_NO", basvuruNo);
			if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(iMap.getString("KART_TIPI"))) {
				GMMap hesap = new GMMap();
				hesap.put("BASVURU_NO", basvuruNo);
				hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_VADESIZ_HESAP_AC", iMap));
				iMap.put("HESAP_NO", hesap.getString("HESAP_NO"));
				oMap.put("VADESIZ_HESAP_BILGI", hesap);
				
				// Otomatik �at� hesab� a��lmas�n diye kapat�ld�
				/*hesap = new GMMap();
				hesap.put("BASVURU_NO", basvuruNo);
				hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_CATI_HESAP_AC", iMap));
				oMap.put("CATI_HESAP_BILGI", hesap);*/
			}

			// 5.Karti aktiflestir.
			GMMap kartMap = new GMMap();
			kartMap.put("APPLICATION_NO", iMap.getBigDecimal("BASVURU_NO"));
			kartMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			kartMap.put("CARD_NO", kartNo);
			// Instant basvurularda sadece durum acik yapilir.
			if ("A".equals(iMap.getString("KURYE_TIPI")) && "NTS01".equals(iMap.getString("SOURCE")) && "P".equals(iMap.getString("KART_TIPI"))) {
				GMMap durumMap = new GMMap();
				durumMap.put("BASVURU_NO", basvuruNo);
				durumMap.put("DURUM_KOD", "ACIK");
				durumMap.put("ISLEM_ACIKLAMA", "Kart Aktif");
				durumMap.put("TARIHCE_AKSIYON", "E");// Yeni kayit ekle
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
			}
			else {
				oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_ACTIVATION", kartMap));
			}

			/*6.E-upt hesabina yatirdigi bir bakiye varsa bu kart i�in(TCKN ile kartnumarasi olusmadan yatirdigi para.) ve
			 * halen bu bakiye e-upt hesabinda bulunuyor ise; bu bakiyeyi karta gonder, hata alsa da devam
			 */
			try {
				// PY-7183 - Serkan altta ERROR firlatinca yakalanmiyordu. Ayri transaction yapildi.
				// TY-2463 - Erdogan batchin calismasi icin kayit atan yeni servis verdi.
				kartMap.clear();
				kartMap.put("APP_NO", basvuruNo);
				kartMap.put("CARD_NO", kartNo);
				kartMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
				GMServiceExecuter.executeAsync("BNSPR_CRD_INSERT_TFF_CARD_TOP_UP_FROM_APPLICATION_RECORD", kartMap);
			}
			catch (Exception e) {
				e.printStackTrace();
			}

			// 7.Event olustur
			iMap.put("EVENT_TYPE_NO", "18");
			iMap.put("EVENT_REF_NO", iMap.getBigDecimal("BASVURU_NO"));
			GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_AKTIVASYON_2")
	public static GMMap controlTffBasvuruBelge2(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Belgeler tamamlandiysa musteri,hesap ve kart islemlerini tamamla.
			// 1.Basvuru musteri bilgisini al.
			String kartNo = iMap.getString("CARD_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
			iMap.putAll(getBasvuruMusteriInfo(kartNo, basvuruNo));// KART_NO
			// Hep parametre olarak gelen kart numarasi islemlerde esas olacak, basvuru no gelemeyebileceginden
			// fonk.dan donen deger ile tazelenir.
			basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			// basvuru durumu basim degilse cik.
			if (!"BASIM".equals(iMap.getString("DURUM_KODU"))) {
				CreditCardServicesUtil.raiseGMError("2701", basvuruNo, iMap.getString("DURUM_KODU"), "BASIM");
			}

			// 2.musteri kontak ise gercege cevrilmelidir.
			if (KONTAKT_MUSTERI.equals(iMap.getString("MUSTERI_KONTAKT"))) {
				// Gercek musteriye cevrilsin mi?
				boolean isGercekMusteri = false;
				// 18 yasindan buyuk prepaid kart sahibleri anne kizlik soyadini vermiyorsa cevirme.
				if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(iMap.getString("KART_TIPI"))) {
					isGercekMusteri = false;
				}
				else {// Debit icin musteri gercege cevrilir.
					isGercekMusteri = true;
				}
				// Gercek musteriye cevir
				if (isGercekMusteri) {
					try {
						iMap.put("SISTEM", "INTRA");
						oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
					}
					catch (Exception e) {
						GMMap sorguMap = new GMMap();
						sorguMap.put("TFF_BASVURU_NO", basvuruNo);
						GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
						oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
					}
				}
				// 3.musteri gercek ise basvuru bilgileri ile guncellenir.
			}

			// 4.Kart debit ise Vadesiz hesap ac, cati Hesabina Cevir
			iMap.put("BASVURU_NO", basvuruNo);
			if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(iMap.getString("KART_TIPI"))) {
				GMMap hesap = new GMMap();
				hesap.put("BASVURU_NO", basvuruNo);
				hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_VADESIZ_HESAP_AC", iMap));
				iMap.put("HESAP_NO", hesap.getString("HESAP_NO"));
				oMap.put("VADESIZ_HESAP_BILGI", hesap);
				// Otomatik �at� hesab� a��lmas�n diye kapat�ld�
				/*hesap = new GMMap();
				hesap.put("BASVURU_NO", basvuruNo);
				hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_CATI_HESAP_AC", iMap));
				oMap.put("CATI_HESAP_BILGI", hesap);*/
			}

			// 2.Basvuru Kart Durumu Guncelle
			GMMap durumMap = new GMMap();
			durumMap.put("BASVURU_NO", basvuruNo);
			durumMap.put("DURUM_KOD", "ACIK");
			durumMap.put("ISLEM_ACIKLAMA", "Kart Aktif");
			durumMap.put("TARIHCE_AKSIYON", "E");// Yeni kayit ekle
			GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KART_MUSTERI_BILGI")
	public static GMMap getTffKartMusteriInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		String kartNo = iMap.getString("CARD_NO");

		try {
			// Kart noya iat basvuru numarasini bul
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TFF_BASVURU.Basvuru_No_Bul(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, kartNo);
			stmt.execute();
			BigDecimal basvuruNo = stmt.getBigDecimal(1);

			// KArt no veya basvuru numarasindan musteri bilgilerini al
			oMap.putAll(getBasvuruMusteriInfo(iMap.getString("CARD_NO"), basvuruNo));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Verilen kart ya da basvuru numarasi ile tff basvuru sahibi musteri bilgilerini listeler.
	 * 
	 * @author murat.el
	 * @since TY-1909
	 * @param kartNo
	 *            - Kart numarasi
	 * @param basvuruNo
	 *            - Basvuru numarasi
	 * @return Basvuru yapan musteri bilgileri
	 */
	private static GMMap getBasvuruMusteriInfo(String kartNo, BigDecimal basvuruNo) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TFF_BASVURU.Musteri_Bilgisi(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, kartNo);
			stmt.setBigDecimal(3, basvuruNo);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Islemleri tamamlanan kartin kullanimini aktiflestirir. Kullanima acar.
	 * 
	 * @author murat.el
	 * @since TY-1909
	 * @param iMap
	 *            - Aktivasyonu yapilacak kart/basvuru bilgisi<br>
	 *            <li>CARD_NO - Kart numarasi <li>APPLICATION_NO - Basvuru numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_CARD_ACTIVATION")
	public static GMMap kartAktivasyon(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// 1.Kart ozelliklerini al
			oMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CARD_PROPERTIES", iMap));
			if ("2".equals(oMap.getString("RETURN_CODE"))) {
				CreditCardServicesUtil.raiseGMError("3215", iMap.getString("CARD_NO"), "no.lu kart bilgileri");
			}

			// 2.Hangi kart oldugunu bul. Bulunan kart tipine gore aktivasyon islemlerini gerceklestir.
			String kartTipi = oMap.getString("DCI");
			String kartKanali = oMap.getString("DESTINATION");
			// Intra ve Debit ya da Prepaid ise
			if (OceanConstants.Card_Source_Intracard.equals(kartKanali) && (CreditCardTffServices.TFF_PREPAID_KARTI.equals(kartTipi) || CreditCardTffServices.TFF_DEBIT_KARTI.equals(kartTipi))) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_AKTIVASYON", iMap));
				// Ocean ce Kredi Karti ise
			}
			else if (OceanConstants.Card_Source_Ocean.equals(kartKanali) && (OceanConstants.Akustik_CreditCard.equals(kartTipi) || CreditCardTffServices.TFF_DEBIT_KARTI.equals(kartTipi) || OceanConstants.Akustik_PrepaidCard.equals(kartTipi))) {
				iMap.put("CARD_DCI", kartTipi);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_UPDATE_STATUS", iMap));
			}
			
			//skt den gelen ba�vuru ise eski kart� iptal ediyoruz
			BigDecimal applicationNo = BigDecimal.ZERO;
			if (iMap.containsKey("APPLICATION_NO") && StringUtils.isNotBlank(iMap.getString("APPLICATION_NO")))
				applicationNo = iMap.getBigDecimal("APPLICATION_NO");
			else{
				//ba�vuru bilgisi gelmiyorsa intra/ocean dan al�yoruz
				GMMap infoMap = new GMMap();
			  	infoMap.put("CARD_NO", iMap.getString("CARD_NO"));

				if (OceanConstants.Card_Source_Intracard.equals(kartKanali))
					infoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO" , infoMap);
				else
					infoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , infoMap);
				
			  	applicationNo = infoMap.getBigDecimal("CARD_DETAIL_INFO", 0, "APPLICATION_NO");
			}
			
			if (applicationNo.compareTo(BigDecimal.ZERO) > 0){
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			TffBasvuru tffBasvuru = null;
			
			if(OceanConstants.Akustik_CreditCard.equals(kartTipi))
				 tffBasvuru =  (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", applicationNo)).uniqueResult();

			else
			     tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, applicationNo);
			
				if (tffBasvuru !=null){
					if (sktDenYeniBasvuruMu(tffBasvuru)){
						GMMap sktMap = new GMMap();
						sktMap.put("APPLICATION_NO", tffBasvuru.getBasvuruNo());
						sktMap.put("CARD_NO", iMap.getString("CARD_NO"));
						sktMap.put("CARD_DCI", kartTipi);
	
						GMServiceExecuter.executeAsync("BNSPR_TFF_VADE_YENILEME_ESKI_KART_IPTAL", sktMap);	
					}
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Islemleri tamamlanan intra kartin kullanimini aktiflestirir. Kullanima acar.
	 * 
	 * @param iMap
	 *            - CARD_NO, APPLICATION_NO
	 * @since TY-5146
	 * @return
	 */
	@GraymoundService("BNSPR_INTRACARD_ACTIVATION")
	public static GMMap intraKartAktivasyon(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// 1.Intra Kart Durumu Guncelle
			sorguMap.clear();
			sorguMap.put("CARD_NO", iMap.getString("CARD_NO"));
			sorguMap.put("STATUS", CreditCardServicesUtil.NO);
			sorguMap.put("SUBSTATUS", CreditCardServicesUtil.NO);
			sorguMap.put("EMBOSS_CODE", " ");
			oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_UPDATE_CARD_STATUS", sorguMap));

			// Kart Acilmadi ise hata ver.
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
				throw new GMRuntimeException(0, oMap.getString("RETURN_DESCRIPTION") + " " + oMap.getString("ERROR_DETAIL"));
			}

			// 2.Basvuru Kart Durumu Guncelle
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sorguMap.put("DURUM_KOD", "ACIK");
			sorguMap.put("ISLEM_ACIKLAMA", "Kart Aktif");
			sorguMap.put("TARIHCE_AKSIYON", "E");// Yeni kayit ekle
			GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap);

			// 3.CRM guncelle
			try {
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				sorguMap.put("CRM_TYPE", CrmTypes.MAIN);
				GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", sorguMap);
			}
			catch (Exception e) {
				e.printStackTrace();
				logger.error("CRM payment guncellemesi yapilamadi BASVURU_NO:" + iMap.getString("BASVURU_NO"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Basvuruya ait musteri no bilgisini bulur. CC ekibi icin hazirlandi.<br>
	 * 
	 * @author murat.el
	 * @since 28.01.2014 - PY-5644, PY-10898
	 * @param iMap
	 *            - Basvuru bilgileri<br>
	 *            <li>BASVURU_NO - Basvuru Numarasi
	 * @return Musteri bilgileri<br>
	 *         <li>MUSTERI_NO - Musteri Numarasi
	 */
	@GraymoundService("BNSPR_TFF_GET_MUSTERI_NO_BY_BASVURU_NO")
	public static GMMap getTffMusteriNoByBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		BigDecimal musteriNo = null;
		String durumKod = null;
		String source = null;

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			if (tffBasvuru != null) {
				musteriNo = tffBasvuru.getMusteriNo();
				durumKod = tffBasvuru.getDurumKod();
				source = tffBasvuru.getSource();
			}
		}
		catch (Exception e) {
			musteriNo = null;
			durumKod = null;
		}

		oMap.put("MUSTERI_NO", musteriNo);
		oMap.put("BASVURU_DURUMU", durumKod);
		oMap.put("BASVURU_YAPILDIGI_YER", source);
		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* BELGE
	// ---------------------------------------------------------------------
	@GraymoundService("BNSPR_UPDATE_BARCODE_NO_FROM_SS")
	public static GMMap updateBarcodeNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;

		try {
			// BNSPR_OCEAN_CREATE_CARD
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Get_Barkodsuz_Basvurular}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			GMMap bMap = new GMMap();
			GMMap boMap = new GMMap();
			while (rSet.next()) {
				bMap.clear();
				boMap.clear();
				bMap.put("CARD_NO", rSet.getString("KART_NO"));
				boMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_GET_CARD_BARCODE_QRCODE", bMap));
				if ("2".equals(boMap.getString("ORESULT"))) {
					stmt2 = conn.prepareCall("{call PKG_TFF_BASVURU.Update_Barkod_No(?,?)}");
					i = 1;
					stmt2.setBigDecimal(i++, rSet.getBigDecimal("BASVURU_NO"));
					stmt2.setString(i++, boMap.getString("BAR_CODE"));
					stmt2.execute();
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Basim asamasindaki basvurularin tamamlanabilmesi icin gerekli belgeleri bulur ve
	 * gereken belgeleri basvuru uzerine kaydeder.
	 * 
	 * @author murat.el
	 * @param iMap
	 *            - BASVURU_NO Zorunlu
	 */
	@GraymoundService("BNSPR_TFF_BELGE_KAYIT")
	public static GMMap saveTffBasvuruBelge(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TFF_BASVURU.BasvuruDokumanKaydet(?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/**
	 * Yenilenen basvurularin tamamlanabilmesi icin gerekli belgeleri bulur ve
	 * gereken belgeleri basvuru uzerine kaydeder.
	 * 
	 * @author murat.el
	 * @param iMap
	 *            - BASVURU_NO Zorunlu
	 */
	@GraymoundService("BNSPR_TFF_BELGE_KAYIT_YENILEME")
	public static GMMap saveTffBasvuruBelgeYenileme(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TFF_BASVURU.BasvuruDokumanKaydetYenileme(?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Tff musterisi icin kanaldan alinmasi gereken dokumanlari listeler.<br>
	 * 
	 * @author murat.el
	 * @since TY-5183
	 * @param iMap
	 *            - Sorgu Kriterleri<br>
	 *            <li>SOURCE - Kanal kodu <li>SORGU_TIPI - Basvuru mu Musteri mi(B:Basvuru|M:Musteri) <li>TCKN - TC kimlik numarasi <li>TFF_BASVURU_NO - Tff basvuru numarasi <li>DOKUMAN_KOD - Sorgulanan dokuman kodu
	 * @return oMap - Sorgu sonuclari<br>
	 *         <li>DOKUMAN_LIST - Dokumanin daha onceden alinip alinmadigi bilgisini tutar
	 *         <ul>
	 *         DOKUMAN_KOD<br>
	 *         ALINDI_MI
	 */

	@GraymoundService("BNSPR_TFF_DOKUMAN_ALINDI_MI_BY_KANAL")
	public static GMMap dokumanAlindiMiByKanal(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Validasyon yap
			iMap.put("TFF_BASVURU_NO", nvl(iMap.get("TFF_BASVURU_NO"), iMap.get("BASVURU_NO")));
			sorguMap.putAll(validateDokumanAlindiMi(iMap));
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				// dokuman sorgulama servisi NTS01 ya da NTS02 den cagirildiysa 18 yasindan kucuk ya da yabanci uyruklu olma durumunu hata mesaji ile atmayacagiz bunun yerine 
				// basarili response donulecek 
				
				if("NTS01".equals(iMap.getString("SOURCE")) || "NTS02".equals(iMap.getString("SOURCE"))){
					if(TffServicesMessages.ONSEKIZ_YAS_KK_D_KONTROLU.equals(sorguMap.getString("RESPONSE_DATA"))){
						oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
						return oMap;
					}
				}
				
				
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}
			String kartTipi = sorguMap.getString("KART_TIPI");

			// TCKN ile musteri bul
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
			sorguMap.put("PASSPORT_NO", iMap.get("PASAPORT_NO"));
			sorguMap.put("COUNTRY_CODE" ,iMap.get("UYRUK"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
			if (sorguMap.get("CUSTOMER_NO") == null || BigDecimal.ZERO.equals(sorguMap.getBigDecimal("CUSTOMER_NO"))) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
			BigDecimal musteriNo = sorguMap.getBigDecimal("CUSTOMER_NO");

			// Alinacak dokumanlari listele
			// Basvuru
			String sorguTipi = iMap.getString("SORGU_TIPI");

			if (DOKUMAN_SORGU_TIPI_DAGITIM_KOD.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
				GMMap dagitimKodSorguMap = new GMMap();
				dagitimKodSorguMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				dagitimKodSorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DAGITIM_KOD", dagitimKodSorguMap));
				 if (StringUtils.isEmpty(dagitimKodSorguMap.getString("DAGITIM_KOD")) || BASVURU_DAGITIM_KOD_BOS.equals(dagitimKodSorguMap.getString("DAGITIM_KOD"))) {
					return oMap;
				}

				dagitimKodSorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_DOKUMAN_LISTELE", dagitimKodSorguMap));
				if (dagitimKodSorguMap.getSize(DOCUMENT_TABLE) == 0) {
					return oMap;
				}
				int docIndex = 0;
				for (int i = 0; i < dagitimKodSorguMap.getSize(DOCUMENT_TABLE); i++) {
					String dokumanKod = dagitimKodSorguMap.getString(DOCUMENT_TABLE, i, "DOKUMAN_KODU");
					GMMap paramSorguMap = new GMMap();
					paramSorguMap.put("KOD", "TFF_BASVURU_ALINAN_BELGE");
					paramSorguMap.put("KEY", iMap.getString("SOURCE"));
					paramSorguMap.put("KEY2", DOKUMAN_SORGU_TIPI_DAGITIM_KOD);
					paramSorguMap.put("KEY3", dokumanKod);

					paramSorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", paramSorguMap));
					if (TffServicesMessages.EVET.equals(paramSorguMap.getString("IS_EXIST"))) {
						oMap.put("DOKUMAN_LIST", docIndex, "DOKUMAN_KOD", dokumanKod);
						oMap.put("DOKUMAN_LIST", docIndex, "ALINDI_MI", "H");
						docIndex++;
					}

				}

			}

			if (DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				if (StringUtils.isNotBlank(kartTipi)) {
					// Basvuru uzerindekileri al
					sorguMap.clear();
					sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
					sorguMap.put("KART_TIPI", kartTipi);
					sorguMap.put("SOURCE", iMap.get("SOURCE"));
					sorguMap.put("MUSTERI_NO", musteriNo);
					sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_KOD"));
					oMap.putAll(basvuruDokumanAlindiMi(sorguMap));
				}
			}
			// Musteri
			if (DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				// Musteri uzerindekileri al
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriNo);
				sorguMap.put("SOURCE", iMap.get("SOURCE"));
				sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_KOD"));
				sorguMap.putAll(musteriDokumanAlindiMi(sorguMap));
				int resultSize = oMap.getSize("DOKUMAN_LIST");
				for (int i = 0; i < sorguMap.getSize("DOKUMAN_LIST"); i++) {
					oMap.put("DOKUMAN_LIST", resultSize + i, "DOKUMAN_KOD", sorguMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
					oMap.put("DOKUMAN_LIST", resultSize + i, "ALINDI_MI", sorguMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				}
			}
			
			
			if (DOKUMAN_SORGU_TIPI_P2D.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				// Musteri uzerindekileri al

				boolean aktifTalepVar = false;
				//bu ba�vuru �zerinde daha �nce al�nm�� bir p2d talebi varsa i�lemi sonland�r
				//talep olu�tuktan sonra BNSPR_DEBIT_COMMON_IS_EXIST_ACTIVE_REQUEST ile kontrol ediliyordu, servisteki db kontrol� performans nedeni ile kullan�lmay�p hibernate e kopyaland� 
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				
				BigDecimal[] durumKodList = {BigDecimal.ZERO,BigDecimal.ONE,new BigDecimal(2),new BigDecimal(3),new BigDecimal(9)}; 

				List<KartBasvuruTalep> list = session.createCriteria(KartBasvuruTalep.class).add(Restrictions.eq("tffBasvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).add(Restrictions.eq("islemTip", CreditCardDocumentServices.DOKUMAN_SORGU_TIPI_P2D)).add(Restrictions.in("durumKod", durumKodList)).list();
				if (list.size() > 0) {
					aktifTalepVar = true;
				}
				
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriNo);
				sorguMap.put("SOURCE", iMap.get("SOURCE"));
				sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_KOD"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.putAll(p2DDokumanAlindiMi(sorguMap));
				int resultSize = oMap.getSize("DOKUMAN_LIST");
				for (int i = 0; i < sorguMap.getSize("DOKUMAN_LIST"); i++) {
					oMap.put("DOKUMAN_LIST", resultSize + i, "DOKUMAN_KOD", sorguMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
					oMap.put("DOKUMAN_LIST", resultSize + i, "ALINDI_MI", sorguMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				}
				
				oMap.put("KURYE", sorguMap.get("KURYE"));
				oMap.put("ANINDA_DONUSUM", sorguMap.get("ANINDA_DONUSUM"));
				oMap.put("AKTIF_TALEP_VAR", (aktifTalepVar ? "E" : "H"));
			}
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
		return oMap;
	}

	private static GMMap validateDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		Session session = null;
		

		try {
			// Source kontrol et
			sorguMap.clear();
			sorguMap.put("SOURCE", iMap.get("SOURCE"));
			if (!TffServicesHelper.isSourceValid(sorguMap)) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
			}

			// Sorgu tipi kontrol et
			String sorguTipi = iMap.getString("SORGU_TIPI");
			if (!DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_P2D.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_DAGITIM_KOD.equals(sorguTipi)) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_SORGULA_SORGU_TIPI_HATALI);
			}
			
			// Pasaport kontrol et
			
			

			// TCKN kontrol et
			sorguMap.clear();
			
			if(StringUtils.isEmpty(iMap.getString("TCKN")) && StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))){
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
			
			TffUyeler tffUyeler = null;
			
			if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
				sorguMap.put("TCKN", iMap.get("TCKN"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_TCKN_KONTROL", sorguMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
				}
				
				session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				tffUyeler =  (TffUyeler)session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn", iMap.getBigDecimal("TCKN"))).uniqueResult();
			}
			
			
			if(!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))){
				
				
				
				// Pasaport ile TFF basvurusu yapmis mi
				session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				tffUyeler =  (TffUyeler)session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaportNo", iMap.getString("PASAPORT_NO"))).uniqueResult();
				
				
				
			}
			
			if(tffUyeler == null ){
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}

			if(tffUyeler.getBankaMusteriNo() == null || tffUyeler.getBankaMusteriNo().compareTo(BigDecimal.ZERO) == 0){
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
			

			// Basvuru bilgilerini kontrol et
			String kartTipi = StringUtils.EMPTY;
			boolean basvuruOkMi = true;
			boolean musteriOkMi = true;
			String hataKodu = null;
			if (DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				if (StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO"))) {
					basvuruOkMi = false;
					hataKodu = TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI;
				}
				else {
					TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
					if (tffBasvuru == null) {
						basvuruOkMi = false;
						hataKodu = TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI;
					}

					kartTipi = tffBasvuru.getKartTipi();
				}
			}
			// Musteri bilgilerini kontrol et
			if (DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_P2D.equals(sorguTipi)) {
				// Musteri var mi
				GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, tffUyeler.getBankaMusteriNo());
				if (gnlMusteri == null) {
					musteriOkMi = false;
					hataKodu = TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI;
				}
				// Varsa turk mu ve 18 yasindan buyuk mu
				boolean musteriGecerliMi = false;
				if (StringUtils.isNotBlank(gnlMusteri.getTcKimlikNo()) && "TR".equals(gnlMusteri.getUyrukKod())) {
					GnlMusteriKimlik gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, gnlMusteri.getMusteriNo());
					DateTime dogumTarihi = new DateTime(gnlMusteriKimlik.getDogumTarihi());
					DateTime simdi = new DateTime(Calendar.getInstance().getTime());
					if (Years.yearsBetween(dogumTarihi, simdi).getYears() >= 18) {
						musteriGecerliMi = true;
					}
				}

				if (!musteriGecerliMi) {
					musteriOkMi = false;
					hataKodu = TffServicesMessages.ONSEKIZ_YAS_KK_D_KONTROLU;
				}
			}
			// Kontrol
			if ((DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) && !basvuruOkMi) || // basvuruda sikinti var mi
			(DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) && !musteriOkMi) || // musteride sikinti mi
			(DOKUMAN_SORGU_TIPI_P2D.equals(sorguTipi) && !musteriOkMi) ||
			(DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) && !(basvuruOkMi || musteriOkMi))) {// basvuru veya musteri sikinti mi
				return CreditCardServicesUtil.getErrorResponse(hataKodu);
			}

			oMap.put("KART_TIPI", kartTipi);
			// Dokuman kod girilmisse kontrol et
			if (StringUtils.isNotBlank(iMap.getString("DOKUMAN_KOD"))) {
				// Basvuru
				boolean basvurudaTanimliMi = false;
				if (DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
					sorguMap.clear();
					sorguMap.put("KOD", "TFF_BASVURU_ALINAN_BELGE");
					sorguMap.put("KEY", iMap.get("SOURCE"));
					sorguMap.put("KEY2", kartTipi);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
					if (TffServicesMessages.EVET.equals(sorguMap.getString("IS_EXIST"))) {
						basvurudaTanimliMi = true;
					}
				}

				// Musteri
				boolean musterideTanimliMi = false;
				if (DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
					sorguMap.clear();
					sorguMap.put("KOD", "TFF_BASVURU_ALINAN_BELGE");
					sorguMap.put("KEY", iMap.get("SOURCE"));
					sorguMap.put("KEY2", "X");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
					if (TffServicesMessages.HAYIR.equals(sorguMap.getString("IS_EXIST"))) {
						musterideTanimliMi = true;
					}
				}
				// Kontrol
				if ((DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) && !basvurudaTanimliMi) || // basvuruda tanimli mi
				(DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) && !musterideTanimliMi) || // musteride tanimli mi
				(DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) && !(basvurudaTanimliMi || musterideTanimliMi))) {// basvuru veya musteride tanimli mi
					return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_SORGULA_DOKUMAN_KODU_HATALI);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
		return oMap;

	}

	private static GMMap musteriDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap docListMap = new GMMap();

		try {
			boolean dokumanKodVarMi = StringUtils.isNotBlank(iMap.getString("DOKUMAN_KOD"));
			// Dokumanlari var
			iMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "X", null, null));
			// Varsa alindi mi diye kontrol et
			int j = 0;
			for (int i = 0; i < iMap.getSize("DOKUMAN_LIST"); i++) {
				if (!dokumanKodVarMi || (dokumanKodVarMi && iMap.getString("DOKUMAN_KOD").equals(iMap.get("DOKUMAN_LIST", i, "NAME")))) {
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", i, "DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
					oMap.put("DOKUMAN_LIST", i, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
					j++;
				}
			}
			
			
			
			// Dokumanlari var
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "T", null, null));
			// Varsa alindi mi diye kontrol et
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
				if (!dokumanKodVarMi || (dokumanKodVarMi && iMap.getString("DOKUMAN_KOD").equals(docListMap.get("DOKUMAN_LIST", i, "NAME")))) {
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_TAMAMLAYICI_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
					j++;
				}
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static GMMap basvuruDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			boolean dokumanKodVarMi = StringUtils.isNotBlank(iMap.getString("DOKUMAN_KOD"));
			// Dokumanlari var
			iMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), iMap.getString("KART_TIPI"), null, null));
			// Varsa alindi mi diye kontrol et
			for (int i = 0; i < iMap.getSize("DOKUMAN_LIST"); i++) {
				if (!dokumanKodVarMi || (dokumanKodVarMi && iMap.getString("DOKUMAN_KOD").equals(iMap.get("DOKUMAN_LIST", i, "NAME")))) {
					// Dokuman alindi mi?
					sorguMap.clear();
					if(!"MBL01".equals(iMap.getString("SOURCE"))){
						sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
						sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
						sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI_MI", sorguMap));
						oMap.put("DOKUMAN_LIST", i, "DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
						oMap.put("DOKUMAN_LIST", i, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
					}
					else{
						oMap.put("DOKUMAN_LIST", i, "ALINDI_MI", "H");
						oMap.put("DOKUMAN_LIST", i, "DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
					}
					
					
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static GMMap p2DDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap docListMap = new GMMap();
		boolean yaziliBhs = false;
		boolean elektronikTamamlayiciBhs = false;
		
		boolean courier = true;
		
		

		try {
		
			GMMap paramSorguMap = new GMMap();
			paramSorguMap.put("KOD", "TFF_BASVURU_ALINAN_BELGE");
			paramSorguMap.put("KEY", iMap.getString("SOURCE"));
			paramSorguMap.put("KEY2", DOKUMAN_SORGU_TIPI_P2D);
			paramSorguMap.put("KEY3", "XBHS");

			paramSorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", paramSorguMap));
			if (TffServicesMessages.EVET.equals(paramSorguMap.getString("IS_EXIST"))) {
				GMMap musteriBhsSorguMap = new GMMap();
				musteriBhsSorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				musteriBhsSorguMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", musteriBhsSorguMap));
				if (TffServicesMessages.EVET.equals(musteriBhsSorguMap.getString("F_BHS"))) {
					courier = false;
					yaziliBhs = true;
				}
			}

			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "YBHS" , null));
			// Varsa alindi mi diye kontrol et
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
		
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI_MI", sorguMap));
					if("E".equals(sorguMap.getString("ALINDI_MI"))){
						yaziliBhs = true;
						
						courier = false;
						break;
					}
					else{
						yaziliBhs = false;
						courier = true;
					}
						
				
			}
			
			docListMap.clear();			
		
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "YBHS2" , null));
			// Varsa alindi mi diye kontrol et
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
		
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI_MI", sorguMap));
					if("E".equals(sorguMap.getString("ALINDI_MI"))){
						yaziliBhs = true;
						
						courier = false;
						break;
					}
					else{
						yaziliBhs = false;
						courier = true;
					}
						
				
			}
			
			docListMap.clear();		
			// Dokumanlari var
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "TEBHS", null));
			// Varsa alindi mi diye kontrol et
			int j = 0 ;
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
			
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_TAMAMLAYICI_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					if(yaziliBhs){
						oMap.put("DOKUMAN_LIST", j, "ALINDI_MI" , "E");
						
					}
					else{
						
						oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
						if("H".equals(sorguMap.getString("ALINDI_MI"))){
							elektronikTamamlayiciBhs = false;
							courier = false;
							
						}
						else{
							 courier = true;
							 elektronikTamamlayiciBhs = true;
						}
					}
					
					
						
					j++;
					
				}
			
			
			
			docListMap.clear();		
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "DCS" , null));
			// Varsa alindi mi diye kontrol et
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
				
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					if(yaziliBhs){
						oMap.put("DOKUMAN_LIST", j, "ALINDI_MI" , "E");
					}
					else{
						if(elektronikTamamlayiciBhs){
							oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
						}
						else{
							oMap.put("DOKUMAN_LIST", j, "ALINDI_MI" , "E");
						}
						
						
					}
					
					
					j++;
				}
				
			
	
			
			
			GMMap basvuruMap = new GMMap();
			basvuruMap.put("KART_TIPI" , "D");
			basvuruMap.put("SOURCE", iMap.getString("SOURCE"));
			basvuruMap.putAll(basvuruDokumanAlindiMi(basvuruMap));
			
			for (int i = 0; i < basvuruMap.getSize("DOKUMAN_LIST"); i++) {
				oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", basvuruMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
				oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", basvuruMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				j++;
			}
			
			oMap.put("KURYE", courier ? "E" : "H");
			oMap.put("ANINDA_DONUSUM", courier ? "H" : "E");
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	

	/**
	 * Tff musterisi icin kanaldan alinmasi gereken dokumanlari listeler.<br>
	 * 
	 * @author murat.el
	 * @since TY-5183
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>TFF_BASVURU_NO - Basvuru numarasi <li>MUSTERI_NO - Musteri numarasi <li>DOKUMAN_KOD - Dokuman kodu
	 * @return oMap - Sorgu sonuclari<br>
	 *         <li>ALINDI_MI - Dokumanin daha onceden alinip alinmadigi bilgisini tutar.(E:Alindi|H:Alinmadi)
	 */
	@GraymoundService("BNSPR_TFF_DOKUMAN_ALINDI_MI")
	public static GMMap dokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_tff_basvuru.BasvuruDokumanAlindiMi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, CreditCardServicesUtil.nvl(iMap.getBigDecimal("TFF_BASVURU_NO"), BigDecimal.ZERO));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(4, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();

			oMap.put("ALINDI_MI", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TFF_TAMAMLAYICI_DOKUMAN_ALINDI_MI")
	public static GMMap tamamlayiciDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_tff_basvuru.TamamlayiciDokumanAlindiMi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, CreditCardServicesUtil.nvl(iMap.getBigDecimal("TFF_BASVURU_NO"), BigDecimal.ZERO));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(4, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();

			oMap.put("ALINDI_MI", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	

	/**
	 * Tff musterisi icin kanaldan gonderilen dokumanlari ftpye kaydeder ve musteri uzerinde alindi olarak isaretler.<br>
	 * 
	 * @author murat.el
	 * @since TY-5241
	 * @param iMap
	 *            - Sorgu Kriterleri<br>
	 *            <li>SOURCE - Kanal kodu <li>ISLEM_TIPI - Basvuru mu Musteri mi(B:Basvuru|M:Musteri) <li>TCKN - TC kimlik numarasi <li>DOKUMAN_KOD - Sorgulanan dokuman kodu <li>DOKUMAN_ICERIK - Tff basvuru numarasi
	 * @return oMap - Sorgu sonuclari<br>
	 *         <li>ALINDI_MI - Dokumanin daha onceden alinip alinmadigi bilgisini tutar.(E:Alindi|H:Alinmadi)
	 */
	@GraymoundService("BNSPR_TFF_DOKUMAN_FTP_YAP")
	public static GMMap ftpDosyaAktar(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Validasyon yap
			sorguMap.putAll(validateFtpDosyaAktar(iMap));
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}

			// TCKN ile musteri bul
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
			sorguMap.put("PASSPORT_NO", iMap.get("PASAPORT_NO"));
			sorguMap.put("COUNTRY_CODE" ,iMap.get("UYRUK")); 
			
			
			
			
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
			if (sorguMap.get("CUSTOMER_NO") == null || BigDecimal.ZERO.equals(sorguMap.getBigDecimal("CUSTOMER_NO"))) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
			BigDecimal musteriNo = sorguMap.getBigDecimal("CUSTOMER_NO");

			// Dosyayi aktar
			String sorguTipi = iMap.getString("ISLEM_TIPI");
			if (DOKUMAN_ISLEM_FTP_AKTAR.equals(sorguTipi) || DOKUMAN_ISLEM_HEPSI.equals(sorguTipi)) {
				sorguMap.clear();
				sorguMap.put("PROJECT", "PASSOLIG_DOMAIN");
				sorguMap.put("REFERENCE_NO", musteriNo);
				sorguMap.put("FILE_NAME", iMap.getString("DOKUMAN_KOD") + ".pdf");
				sorguMap.put("FILE", iMap.get("DOKUMAN_ICERIK"));
				GMServiceExecuter.execute("BNSPR_FTP_DOSYA_AKTAR", sorguMap);
			}

			// Alindi olarak isaretle
			if (DOKUMAN_ISLEM_MUSTERI_ISARETLE.equals(sorguTipi) || DOKUMAN_ISLEM_HEPSI.equals(sorguTipi)) {
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriNo);
				sorguMap.put("DOC_LIST", 0 , "DOC_CODE"  , iMap.getString("DOKUMAN_KOD"));
				
				GMServiceExecuter.execute("BNSPR_RM_MUSTERI_DOKUMAN_GUNCELLE", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
		return oMap;
	}

	private static GMMap validateFtpDosyaAktar(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		Session session = null;

		try {
			// Source kontrol et
			sorguMap.clear();
			sorguMap.put("SOURCE", iMap.get("SOURCE"));
			if (!TffServicesHelper.isSourceValid(sorguMap)) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
			}

			// Sorgu tipi kontrol et
			String sorguTipi = iMap.getString("ISLEM_TIPI");
			if (!DOKUMAN_ISLEM_FTP_AKTAR.equals(sorguTipi) && !DOKUMAN_ISLEM_MUSTERI_ISARETLE.equals(sorguTipi) && !DOKUMAN_ISLEM_HEPSI.equals(sorguTipi)) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_KAYDET_ISLEM_TIPI_HATALI);
			}

			// TCKN kontrol et
			
			

			TffUyeler tffUyeler = null;
			
			if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
				sorguMap.clear();
				sorguMap.put("TCKN", iMap.get("TCKN"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_TCKN_KONTROL", sorguMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
				}
				
				session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				tffUyeler =  (TffUyeler)session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn", iMap.getBigDecimal("TCKN"))).uniqueResult();
			}
			
			
			if(!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))){
				
				
				
				// Pasaport ile TFF basvurusu yapmis mi
				session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				tffUyeler =  (TffUyeler)session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaportNo", iMap.getString("PASAPORT_NO"))).uniqueResult();
				
				
				
			}
			
			if(tffUyeler == null ){
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}

			if(tffUyeler.getBankaMusteriNo() == null || tffUyeler.getBankaMusteriNo().compareTo(BigDecimal.ZERO) == 0){
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}

			// Dokuman kod girilmisse kontrol et
			if (StringUtils.isBlank(iMap.getString("DOKUMAN_KOD"))) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_SORGULA_DOKUMAN_KODU_HATALI);
			}

			if (DOKUMAN_ISLEM_FTP_AKTAR.equals(sorguTipi) || DOKUMAN_ISLEM_HEPSI.equals(sorguTipi)) {
				if (StringUtils.isBlank(iMap.getString("DOKUMAN_ICERIK"))) {
					return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_KAYDET_DOSYA_ICERIK_HATALI);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
		return oMap;

	}

	/**
	 * Tff mobil/web/epos kanalindan alinan basvurularda ekranlardan tiklenerek
	 * kabul edilen sozelesmerleri musteri dokuman tablosuna kart tipine gore alindi
	 * olarak kaydeder.<br>
	 * 
	 * @author murat.el
	 * @since PY-8460, TY-5241
	 * @param iMap
	 *            - MUSTERI_NO - Musteri numarasi<br>
	 *            DOKUMAN_KOD - Dokuman kodu<br>
	 * @return oMap - Donen deger yok<br>
	 */
	@GraymoundService("BNSPR_TFF_DOKUMAN_ALINDI")
	public static GMMap musteriDokumanAlindi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call pkg_trn3882.rm_musteri_dokuman_guncelle(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(2, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_UPDATE_BEYAN_ADRES_BY_KURYE_TESLIM_NT")
	public static GMMap updateBeyanAdresByKuryeTeslimNt(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_UPDATE_BEYAN_ADRES_BY_KURYE_TESLIM", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_UPDATE_BEYAN_ADRES_BY_KURYE_TESLIM")
	public static GMMap updateBeyanAdresByKuryeTeslim(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		String inpKartNo = iMap.getString("CARD_NO");
		if (StringUtils.isEmpty(inpKartNo)) {
			return oMap;
		}

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		try {

		
			String teslimatAdresKod = null;
			BigDecimal kkBasvuruNo = null;
			BigDecimal tffBasvuruNo = null;
			String kartTipi = null;
			BigDecimal musteriNo = null;

			TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kartNo", inpKartNo)).uniqueResult();
			if (tffBasvuru != null) {

				if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(tffBasvuru.getKartTipi()) || CreditCardTffServices.TFF_PREPAID_KARTI.equals(tffBasvuru.getKartTipi())) {
					tffBasvuruNo = tffBasvuru.getBasvuruNo();
					kartTipi = tffBasvuru.getKartTipi();

				}
				else if (CreditCardTffServices.TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
					kkBasvuruNo = tffBasvuru.getKkBasvuruNo();
					kartTipi = tffBasvuru.getKartTipi();
				}
				musteriNo = tffBasvuru.getMusteriNo();
			}
			else {
				KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("kartNo", inpKartNo)).uniqueResult();
				if (kkBasvuru != null) {
					kkBasvuruNo = kkBasvuru.getBasvuruNo();
					kartTipi = kkBasvuru.getKartTipi();
					musteriNo = kkBasvuru.getMusteriNo();
				}

			}

			if (tffBasvuruNo == null && kkBasvuruNo == null) {
				return oMap;
			}

			if (tffBasvuruNo != null) {
				TffBasvuruAdres basvuruAdres = (TffBasvuruAdres) session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", tffBasvuruNo)).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();
				if (basvuruAdres != null) {
					teslimatAdresKod = basvuruAdres.getId().getAdresKod();
				}
			}
			else if (kkBasvuruNo != null) {
				KkBasvuruAdres basvuruAdres = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", kkBasvuruNo)).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();
				if (basvuruAdres != null) {
					teslimatAdresKod = basvuruAdres.getId().getAdresKod();
				}
				if (StringUtils.isEmpty(teslimatAdresKod) && (StringUtils.isEmpty(kartTipi) || CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi))) {
					teslimatAdresKod = "E";
				}
			}

			if (!StringUtils.isEmpty(teslimatAdresKod) && musteriNo != null) {
				if (teslimatAdresKod.equals("D")) {
					teslimatAdresKod = "W";
				}
				GnlMusteriAdres musteriAdres = (GnlMusteriAdres) session.createCriteria(GnlMusteriAdres.class).add(Restrictions.eq("id.musteriNo", musteriNo)).add(Restrictions.eq("id.adresKod", teslimatAdresKod)).uniqueResult();
				if (musteriAdres != null) {
					String adresTeyitIlkDeger = musteriAdres.getAdresTeyit();
					if (!"E".equals(adresTeyitIlkDeger)) {
						musteriAdres.setAdresTeyit("E");
						session.saveOrUpdate(musteriAdres);
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
						oMap.put("MUSTERI_NO", musteriNo);
						oMap.put("ADRES_TEYIT_ILK_DEGER" , adresTeyitIlkDeger);
						oMap.put("ADRES_TEYIT_SON_DEGER", "E");
						
					}
				}

			}

		}
		catch (Exception e) {
			oMap.put("ERROR_LOG" , e.getMessage());
			logger.error("BNSPR_UPDATE_BEYAN_ADRES_BY_KURYE_TESLIM" , e);
		}
		finally{
			if(session != null){
				session.flush();
			}
		}
		

		return oMap;
	}

	@GraymoundService("BNSPR_UPDATE_GNL_MUSTERI_DEGISEN_BY_KURYE_TESLIM_NT")
	public static GMMap updateGnlMusteriDegisenByKuryeTeslimNt(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_UPDATE_GNL_MUSTERI_DEGISEN_BY_KURYE_TESLIM", iMap));
		return oMap;
	}
	
	@GraymoundService("BNSPR_UPDATE_GNL_MUSTERI_DEGISEN_BY_KURYE_TESLIM")
	public static GMMap updateGnlMusteriDegisenByKuryeTeslim(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		if (iMap.get("TRX_NO") == null) {
			return oMap;
		}
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		oMap.put("TRX_NO", trxNo);
		Session session = null;
		try {
			session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			GnlMusteriDegisenId id = new GnlMusteriDegisenId();
			id.setTxNo(trxNo);
			id.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			id.setTabloAdi("GNL_MUSTERI_ADRES");
			id.setAlanAdi("ADRES_TEYIT");
			id.setKayitKod("1");
			GnlMusteriDegisen md = new GnlMusteriDegisen();
			md.setId(id);
			md.setAlanTipi("VARCHAR2");
			md.setYeniDeger(iMap.getString("ADRES_TEYIT_SON_DEGER"));
			md.setEskiDeger(iMap.getString("ADRES_TEYIT_ILK_DEGER"));
			md.setAciklama("Kurye teslim bilgisi ile guncellendi.");

			session.save(md);
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);

		}
		catch (Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		}
		finally {
			if (session != null) {
				session.flush();
			}
		}
		return oMap;

	}
	
	@GraymoundService("BNSPR_KK_DOKUMAN_ALINDI_MI")
	public static GMMap kkDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_kk_basvuru.BasvuruDokumanAlindiMi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, CreditCardServicesUtil.nvl(iMap.getBigDecimal("KK_BASVURU_NO"), BigDecimal.ZERO));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(4, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();

			oMap.put("ALINDI_MI", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TFF_BELGE_IPTAL")
	public static GMMap iptalTffBasvuruBelge(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TFF_BASVURU.BasvuruDokumanIptal(?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_DAGITIM_KOD")
	public static GMMap getTffDagitimKod(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_tff_basvuru.GetBasvuruDagitimKod(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			oMap.put("DAGITIM_KOD", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_DOKUMAN_LISTELE")
	public static GMMap getTffBasvuruDokumanListe(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_tff_basvuru.BasvuruDokumanListele(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, null);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap resultMap = DALUtil.rSetResults(rSet, DOCUMENT_TABLE);
			oMap.putAll(resultMap);


		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}

		return oMap;
	}
	
	private static boolean sktDenYeniBasvuruMu(TffBasvuru tffBasvuru){
		
		if (tffBasvuru.getVdBasvuruMu() != null  &&  "E".equals(tffBasvuru.getVdBasvuruMu())){
			return true;
		}
		 return false;
	}
	
	
	@GraymoundService("BNSPR_KART_DAGITIM_KODU_BUL")
	public static GMMap getDagitimKod(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap dysMap = new GMMap();
		try {
			dysMap.put("BASVURU_NO", iMap.getString("APPLICATION_NO"));

			GMMap belgeMap = new GMMap();
			belgeMap.put("BASVURU_NO", iMap.getString("APPLICATION_NO"));

			if (iMap.getBoolean("IS_TFF")) {
				if (OceanConstants.Akustik_CreditCard.equals(iMap.getString("CARD_DCI"))) {
					Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("APPLICATION_NO"))).uniqueResult();
					dysMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					belgeMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());

				}

				dysMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_DAGITIM_KOD", dysMap));
				
				if (DAGITIM_KODU_TFF_GISE.equals(dysMap.getString("DAGITIM_KOD"))) /*gi�eden ba�vuru ve belgesi eksikse gi�e �er�eve s�zle�mesi yerine kurye �er�eve s�zle�mesi ��k ��nk� gi�e s�zle�mesi kuryede mevcut de�il*/
					dysMap.put("DAGITIM_KOD" , DAGITIM_KODU_TFF_KURYE);
				
				if (!DAGITIM_KODU_BOS.equals(dysMap.getString("DAGITIM_KOD"))) {
					belgeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BELGE_KAYIT_YENILEME", belgeMap));
				}
			}
			else {

				dysMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DAGITIM_KOD", dysMap));

				if (!DAGITIM_KODU_BOS.equals(dysMap.getString("DAGITIM_KOD"))) {
					belgeMap.putAll(GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", belgeMap));
				}
			}

			oMap.put("DYS_INFO", dysMap.getString("DAGITIM_KOD"));
			oMap.put("RESPONSE", "2");
			oMap.put("RESPONSE_DATA", "Ok.");

		}
		catch (Exception e) {
			oMap.put("RESPONSE", "99");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		return oMap;
	}

}
