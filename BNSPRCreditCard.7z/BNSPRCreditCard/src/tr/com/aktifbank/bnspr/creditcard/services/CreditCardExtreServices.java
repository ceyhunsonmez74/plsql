package tr.com.aktifbank.bnspr.creditcard.services;

import tr.com.aktifbank.integration.kredikartekstre.KrediKartEkstreClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.hobim.QueryResult;

public class CreditCardExtreServices {

	/**
	 * BNSPR_CREDITCARD_GET_EXTRE_WITH_BARCODE
	 * 
	 * Response olarak d�nen byte[] datas�n�, file olarak elde edebilmek i�in a�a��daki Apache Commons IO metodu kullan�labilir. 
	 * �r: FileUtils.writeByteArrayToFile(new File("C:\\example.pdf"), fileContentAsByteArray);
	 * 
	 * @param iMap
	 *            BARCODE
	 * @return oMap
	 * 			  RESULT_DESCRIPTION (Hata varsa hata mesaj�, yoksa null) 
	 * 			  EXTRE_PDF_AS_BYTEARRAY (Hata yoksa byte[] tipinde pdf, varsa null)
	 */
	@GraymoundService("BNSPR_CREDITCARD_GET_EXTRE_WITH_BARCODE")
	public static GMMap getCCExtreWithBarcode(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			KrediKartEkstreClient krediKartEkstreClient = new KrediKartEkstreClient();
			QueryResult result = krediKartEkstreClient.getCreditCardExtre(iMap.getString("BARCODE"));
			oMap.put("EXTRE_PDF_AS_BYTEARRAY", result.getPDF());
			oMap.put("RESULT_DESCRIPTION", result.getResultDesc());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
