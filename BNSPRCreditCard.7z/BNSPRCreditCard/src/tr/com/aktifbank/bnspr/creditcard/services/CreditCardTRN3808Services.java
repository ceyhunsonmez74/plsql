package tr.com.aktifbank.bnspr.creditcard.services;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TffKartYenilemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class CreditCardTRN3808Services {
    
    @GraymoundService("BNSPR_TRN3808_SAVE")
    public static GMMap save3808(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
            
            TffKartYenilemeTx tffKartYenilemeTx = (TffKartYenilemeTx) session.createCriteria(TffKartYenilemeTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            if (tffKartYenilemeTx == null){
                tffKartYenilemeTx = new TffKartYenilemeTx();
            }
            
            tffKartYenilemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            tffKartYenilemeTx.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
            tffKartYenilemeTx.setKartNo(iMap.getString("KART_NO"));
            tffKartYenilemeTx.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
            tffKartYenilemeTx.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
            tffKartYenilemeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            tffKartYenilemeTx.setOdemeSekli(iMap.getString("ODEME_SEKLI"));
            tffKartYenilemeTx.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
            tffKartYenilemeTx.setYeniKartNo(iMap.getString("YENI_KART_NO"));
            tffKartYenilemeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
            tffKartYenilemeTx.setTcKimlikNo(iMap.getString("TCKN"));
            tffKartYenilemeTx.setOdemeRefId("IVR_KY"+iMap.getBigDecimal("TRX_NO"));
            session.saveOrUpdate(tffKartYenilemeTx);
            session.flush();
            
            iMap.put("TRX_NAME" , "3808");
            oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3808_UPDATE")
    public static GMMap update3808(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
            
            TffKartYenilemeTx tffKartYenilemeTx = (TffKartYenilemeTx) session.createCriteria(TffKartYenilemeTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            if (tffKartYenilemeTx == null){
                tffKartYenilemeTx = new TffKartYenilemeTx();
            }
            
            tffKartYenilemeTx.setYeniKartNo(iMap.getString("NEW_CARD_NO"));
            session.saveOrUpdate(tffKartYenilemeTx);
            session.flush();
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
}
