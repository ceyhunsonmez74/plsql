package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdDebitTransferBakiye;
import tr.com.aktifbank.bnspr.dao.CrdKartOdemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4405Services implements OceanMapKeys {
	@GraymoundService("BNSPR_CREDIT_CARD_PAYMENT")
	public static GMMap CreditCardPayment(GMMap iMap) {
	    GMMap oMap = new GMMap();
	    
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			CrdKartOdemeTx crdKartOdemeTx = new CrdKartOdemeTx();
			crdKartOdemeTx.setAciklama(iMap.getString("ACIKLAMA"));
			crdKartOdemeTx.setAliciAdiSoyadi(iMap.getString("ALICI_ADI_SOYADI"));
			crdKartOdemeTx.setAliciMusteriNo(iMap.getBigDecimal("ALICI_MUSTERI_NO"));
			crdKartOdemeTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			crdKartOdemeTx.setEkstreBorcuUsd(iMap.getBigDecimal("EKSTRE_BORCU_USD"));
			crdKartOdemeTx.setGonderenAdiSoyadi(iMap.getString("GONDEREN_ADI_SOYADI"));
			crdKartOdemeTx.setGonderenAdres(iMap.getString("GONDEREN_ADRES"));
			crdKartOdemeTx.setGonderenHesapNo(iMap.getBigDecimal("GONDEREN_HESAP_NO"));
			crdKartOdemeTx.setGonderenIban(iMap.getString("GONDEREN_IBAN"));
			crdKartOdemeTx.setGonderenMusteriNo(iMap.getBigDecimal("GONDEREN_MUSTERI_NO"));
			crdKartOdemeTx.setGonderenTckn(iMap.getString("GONDEREN_TCKN"));
			crdKartOdemeTx.setGonderenTelefon(iMap.getString("GONDEREN_TELEFON"));
			crdKartOdemeTx.setGuncelDonemBorcu(iMap.getBigDecimal("GUNCEL_DONEM_BORCU"));
			try {
				if (iMap.getDate("HESAP_KESIM_TARIHI")==null)
				{
					crdKartOdemeTx.setHesapKesimTarihi(null);
				}
				else
				crdKartOdemeTx.setHesapKesimTarihi(new java.sql.Date(iMap.getDate("HESAP_KESIM_TARIHI").getTime()));
			}
			catch (ParseException e) {
				crdKartOdemeTx.setHesapKesimTarihi(null);
			}
			crdKartOdemeTx.setIslemiYapan(iMap.getString("ISLEMI_YAPAN"));
			crdKartOdemeTx.setKalanEkstreBorcu(iMap.getBigDecimal("KALAN_EKSTRE_BORCU"));
			crdKartOdemeTx.setKalanEkstreBorcuUsd(iMap.getBigDecimal("KALAN_EKSTRE_BORCU_USD"));
			crdKartOdemeTx.setKalanMinOdeme(iMap.getBigDecimal("KALAN_MIN_ODEME"));
			crdKartOdemeTx.setKalanMinOdemeTutariUsd(iMap.getBigDecimal("KALAN_MIN_ODEME_USD"));
			crdKartOdemeTx.setKartDurumu(iMap.getString("KART_DURUMU"));
			crdKartOdemeTx.setKartNo(iMap.getString("KART_NO"));
			crdKartOdemeTx.setKaynak(iMap.getString("KAYNAK"));
			crdKartOdemeTx.setMinOdemeTutari(iMap.getBigDecimal("MIN_ODEME_TUTARI"));
			crdKartOdemeTx.setMinOdemeTutariUsd(iMap.getBigDecimal("MIN_ODEME_TUTARI_USD"));
			crdKartOdemeTx.setSonEkstreBorcu(iMap.getBigDecimal("SON_EKSTRE_BORCU"));
			try {
				if (iMap.getDate("SON_ODEME_TARIHI")==null)
					crdKartOdemeTx.setSonOdemeTarihi(null);
				else
					crdKartOdemeTx.setSonOdemeTarihi(new java.sql.Date(iMap.getDate("SON_ODEME_TARIHI").getTime()));
			}
			catch (ParseException e) {
				crdKartOdemeTx.setSonOdemeTarihi(null);
			}
			try {
				if (iMap.getDate("SONRAKI_EKSTRE_KESIM_TARIHI")==null)
					crdKartOdemeTx.setSonrakiEkstreKesimTarihi(null);
				else
					crdKartOdemeTx.setSonrakiEkstreKesimTarihi(new java.sql.Date(iMap.getDate("SONRAKI_EKSTRE_KESIM_TARIHI").getTime()));
			}
			catch (ParseException e) {
				crdKartOdemeTx.setSonrakiEkstreKesimTarihi(null);
			}
			try {
				if (iMap.getDate("SONRAKI_SON_ODEME_TARIHI")==null)
					crdKartOdemeTx.setSonrakiSonOdemeTarihi(null);
				else
					crdKartOdemeTx.setSonrakiSonOdemeTarihi(new java.sql.Date(iMap.getDate("SONRAKI_SON_ODEME_TARIHI").getTime()));
			}
			catch (ParseException e) {
				crdKartOdemeTx.setSonrakiSonOdemeTarihi(null);
			}
			crdKartOdemeTx.setTutar(iMap.getBigDecimal("TUTAR"));
			if (iMap.getBigDecimal("TRX_NO") == null) {
				GMMap oMapN = new GMMap();
				oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
				crdKartOdemeTx.setTxNo(oMapN.getBigDecimal("TRX_NO"));
				iMap.put("TRX_NO", oMapN.getBigDecimal("TRX_NO"));
			}
			else
				crdKartOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

			session.saveOrUpdate(crdKartOdemeTx);

			session.flush();
			iMap.put("TRX_NAME", "4405");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			oMap.put("TRX_NO" ,iMap.getBigDecimal("TRX_NO")); 
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN4405_AFTER_APPROVAL")
	public static GMMap after_Approval(GMMap iMap) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		GMMap iMapx = new GMMap();
		GMMap oMapx = new GMMap();
		GMMap oMap = new GMMap();
		String kaynak ="";
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			conn = DALUtil.getGMConnection();
			ps = conn.prepareStatement("SELECT * FROM CRD_KART_ODEME_TX where tx_no=?");
			ps.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			rs = ps.executeQuery();

			while (rs.next()) {
				GMMap oMapA = new GMMap();
				GMMap iMapA = new GMMap();
				if (rs.getString("KAYNAK").equals("HESAPTAN")) {
					iMapA.put("HESAP_NO", rs.getString("GONDEREN_HESAP_NO"));
					oMapA = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", iMapA);
					iMapx.put(ACCOUNT_BRANCH, oMapA.getString("SUBE_KODU"));
					iMapx.put(ACCOUNT_NO, rs.getString("GONDEREN_HESAP_NO"));
					
				}
				else
				{
					iMapx.put(ACCOUNT_BRANCH, "0");
					iMapx.put(ACCOUNT_NO, "0");
				}
				GMMap oMapH = new GMMap();
				oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMapA);
				iMapx.put(BRANCH_CODE, oMapH.getString("SUBE_KOD"));
				iMapx.put(REFERENCE_NO, iMap.getString("ISLEM_NO"));
				iMapx.put(CARD_NO, rs.getObject("KART_NO"));
				iMapx.put(ORIGINAL_RRN, "");
				iMapx.put(TERMINAL_ID, "9999999");
			
				GMMap oMapK = new GMMap();
				oMapK = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMapA);
				String channelCode;
				if (oMapK.getString("KANAL_KOD").equals("4") || oMapK.getString("KANAL_KOD").equals("10"))
					channelCode = OceanConstants.Channel_INT;
				else if (oMapK.getString("KANAL_KOD").equals("5"))
					channelCode = OceanConstants.Channel_IVR;
				else
					channelCode = OceanConstants.Channel_Branch;
				iMapx.put(CHANNEL_CODE, channelCode);
				String paymentType = null;
				if (rs.getObject("KAYNAK").toString().equals("KASADAN")){
					paymentType = OceanConstants.Payment_Cash;
				}
				else{
					paymentType = OceanConstants.Payment_From_Account;
				}
				iMapx.put(PAYMENT_TYPE, paymentType);
				iMapx.put(REQUEST_TYPE, OceanConstants.Request_Normal);
				iMapx.put(TXN_AMOUNT, rs.getBigDecimal("TUTAR"));
				iMapx.put(TERMINAL_TYPE,"Crt");

				GMMap oMapC = new GMMap();
				GMMap iMapC = new GMMap();
				//iMapC.put("CODE", rs.getString("DOVIZ_KODU"));
				//oMapC = GMServiceExecuter.call("BNSPR_DC_GET_OCEAN_CURRENCY_CODE_RELATED_BANK", iMapC);
				
				iMapx.put(TXN_CURR,rs.getString("DOVIZ_KODU"));
				if (rs.getObject("ACIKLAMA")==null)
					iMapx.put(TXN_DESC, "KK �DEME");
				else
					iMapx.put(TXN_DESC, rs.getObject("ACIKLAMA"));
				kaynak = rs.getObject("KAYNAK").toString();

			}
			iMapx.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
			if (kaynak.equals("HESAPTAN")){
				controlDebitEmv(iMapx);
			}
			oMapx = GMServiceExecuter.call("BNSPR_OCEAN_MAKE_CARD_PAYMENT", iMapx);
			CrdKartOdemeTx crdKartOdemeTx = new CrdKartOdemeTx();
			crdKartOdemeTx = (CrdKartOdemeTx) session.get(CrdKartOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
			if (oMapx.getInt(RETURN_CODE) == 2) {
				
				crdKartOdemeTx.setRrn(oMapx.getString(RRN));
				session.saveOrUpdate(crdKartOdemeTx);
				session.flush();
				
				return oMap;
			}
			else {
				GMMap aMap = new GMMap();
				aMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
				aMap.put(RETURN_CODE, oMapx.getString(RETURN_CODE));
				aMap.put(RETURN_DESCRIPTION, oMapx.getString(RETURN_DESCRIPTION));
				GMServiceExecuter.executeAsync("BNSPR_TRN4405_SET_OCEAN_RESULT", aMap);
				throw new GMRuntimeException(0, oMapx.getString(RETURN_DESCRIPTION));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			GMServerDatasource.close(conn);

		}

	}
	@GraymoundService("BNSPR_TRN4405_CANCEL_PAYMENT")
	public static GMMap cancelPayment (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			CrdKartOdemeTx odemeTx = (CrdKartOdemeTx) session.get(CrdKartOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
			GMMap iMapx = new GMMap();
			GMMap oMapN = new GMMap();
			oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
			
			iMapx.put("ACCOUNT_BRANCH", "998");
			iMapx.put("ACCOUNT_NO", "");

			iMapx.put("BRANCH_CODE", "998");

			iMapx.put("REFERENCE_NO", oMapN.getBigDecimal("TRX_NO"));
			iMapx.put("CARD_NO", odemeTx.getKartNo());
			iMapx.put("ORIGINAL_RRN", odemeTx.getRrn());
			iMapx.put("TERMINAL_ID", "9999999");

			GMMap oMapK = new GMMap();
			oMapK = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", oMapK);
			
			String channelCode;
			if (oMapK.getString("KANAL_KOD").equals("4") || oMapK.getString("KANAL_KOD").equals("10"))
				channelCode = OceanConstants.Channel_INT;
			else if (oMapK.getString("KANAL_KOD").equals("5"))
				channelCode = OceanConstants.Channel_IVR;
			else
				channelCode = OceanConstants.Channel_Branch;
			iMapx.put(CHANNEL_CODE, channelCode);
			String paymentType = null;
			if (odemeTx.getKaynak().equals("KASADAN")){
				paymentType = OceanConstants.Payment_Cash;
			}
			else{
				paymentType = OceanConstants.Payment_From_Account;
			}
			
			
			iMapx.put("CHANNEL_CODE", channelCode);

			iMapx.put("PAYMENT_TYPE", paymentType);
			iMapx.put("REQUEST_TYPE", "R");
			iMapx.put("TXN_AMOUNT", odemeTx.getTutar());

			iMapx.put("TXN_CURR", "TRY");
			iMapx.put("TXN_DESC", odemeTx.getAciklama() + " �PTAL");

			oMap = GMServiceExecuter.call("BNSPR_OCEAN_MAKE_CARD_PAYMENT", iMapx);
			if (oMap.getInt(RETURN_CODE) != 2) {
				throw new GMRuntimeException(0, oMap.getString(RETURN_DESCRIPTION));
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4405_SET_OCEAN_RESULT")
	public static GMMap oceanHataYaz (GMMap iMap)
	{
		Session session = DAOSession.getSession("BNSPRDal");
		CrdKartOdemeTx crdKartOdemeTx = new CrdKartOdemeTx();
		crdKartOdemeTx = (CrdKartOdemeTx) session.get(CrdKartOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
		crdKartOdemeTx.setOceanResultCode(iMap.getString(RETURN_CODE));
		crdKartOdemeTx.setOceanResultDesc(iMap.getString(RETURN_DESCRIPTION).length()>500?iMap.getString(RETURN_DESCRIPTION).substring(0,499): iMap.getString(RETURN_DESCRIPTION));
		session.saveOrUpdate(crdKartOdemeTx);
		session.flush();
		return iMap;
	}
	@GraymoundService("BNSPR_TRN4405_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap(); 
		try {
	            
	            Session session = DAOSession.getSession("BNSPRDal");
	            
	            CrdKartOdemeTx crdKartOdemeTx = (CrdKartOdemeTx) session.get(CrdKartOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
	            
	            oMap.put("ACIKLAMA", crdKartOdemeTx.getAciklama());
	            oMap.put("ALICI_ADI_SOYADI", crdKartOdemeTx.getAliciAdiSoyadi());
	            oMap.put("ALICI_MUSTERI_NO", crdKartOdemeTx.getAliciMusteriNo());
	            oMap.put("DOVIZ_KODU", crdKartOdemeTx.getDovizKodu());
	            oMap.put("EKSTRE_BORCU_USD", crdKartOdemeTx.getEkstreBorcuUsd());
	            oMap.put("GONDEREN_ADI_SOYADI", crdKartOdemeTx.getGonderenAdiSoyadi());
	            oMap.put("GONDEREN_ADRES", crdKartOdemeTx.getGonderenAdres());
	            oMap.put("GONDEREN_HESAP_NO", crdKartOdemeTx.getGonderenHesapNo());
	            oMap.put("GONDEREN_IBAN", crdKartOdemeTx.getGonderenIban());
	            oMap.put("GONDEREN_MUSTERI_NO", crdKartOdemeTx.getGonderenMusteriNo());
	            oMap.put("GONDEREN_TCKN", crdKartOdemeTx.getGonderenTckn());
	            oMap.put("GONDEREN_TELEFON", crdKartOdemeTx.getGonderenTelefon());
	            oMap.put("GUNCEL_DONEM_BORCU", crdKartOdemeTx.getGuncelDonemBorcu());
	            oMap.put("HESAP_KESIM_TARIHI", crdKartOdemeTx.getHesapKesimTarihi());
	            oMap.put("ISLEMI_YAPAN", crdKartOdemeTx.getIslemiYapan());
	            oMap.put("KALAN_EKSTRE_BORCU", crdKartOdemeTx.getKalanEkstreBorcu());
	            oMap.put("KALAN_EKSTRE_BORCU_USD", crdKartOdemeTx.getKalanEkstreBorcuUsd());
	            oMap.put("KALAN_MIN_ODEME", crdKartOdemeTx.getKalanMinOdeme());
	            oMap.put("KALAN_MIN_ODEME_USD", crdKartOdemeTx.getKalanMinOdemeTutariUsd());
	            oMap.put("KART_DURUMU", crdKartOdemeTx.getKartDurumu());
	            oMap.put("KART_NO", crdKartOdemeTx.getKartNo());
	            oMap.put("KART_TURU", crdKartOdemeTx.getKartTuru());
	            oMap.put("KAYNAK", crdKartOdemeTx.getKaynak());
	            oMap.put("MIN_ODEME_TUTARI", crdKartOdemeTx.getMinOdemeTutari());
	            oMap.put("MIN_ODEME_TUTARI_USD", crdKartOdemeTx.getMinOdemeTutariUsd());
	            oMap.put("SON_EKSTRE_BORCU", crdKartOdemeTx.getSonEkstreBorcu());
	            oMap.put("SON_ODEME_TARIHI", crdKartOdemeTx.getSonOdemeTarihi());
	            oMap.put("SONRAKI_EKSTRE_KESIM_TARIHI", crdKartOdemeTx.getSonrakiEkstreKesimTarihi());
	            oMap.put("SONRAKI_SON_ODEME_TARIHI", crdKartOdemeTx.getSonrakiSonOdemeTarihi());
	            oMap.put("TUTAR", crdKartOdemeTx.getTutar());
	            oMap.put("TRX_NO", crdKartOdemeTx.getTxNo());
	            
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	}
	public static void controlDebitEmv (GMMap iMap) throws SQLException{
		BigDecimal accountNo = iMap.getBigDecimal(ACCOUNT_NO);
		CrdDebitTransferBakiye crdDebitTransferBakiye= findTopupRecord(accountNo);
		if (crdDebitTransferBakiye != null && crdDebitTransferBakiye.getBakiye().compareTo(BigDecimal.ZERO)>0){
			Object[] hValues = new Object[10];
			int k=0;
			hValues[k++] = BnsprType.NUMBER;
			hValues[k++] = accountNo;
			hValues[k++] = BnsprType.NUMBER;
			hValues[k++] = null;
			hValues[k++] = BnsprType.STRING;
			hValues[k++] = null;
			hValues[k++] = BnsprType.STRING;
			hValues[k++] = "K";
			hValues[k++] = BnsprType.STRING;
			hValues[k++] = null;
			
			String func = "{?= call PKG_HESAP.KULLANILABILIR_BAKIYE_AL(?,?,?,?,?)}";
			
			BigDecimal tutar=iMap.getBigDecimal(TXN_AMOUNT);
			BigDecimal kullBakiye = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, hValues);
			kullBakiye = kullBakiye.add(tutar); //fi� kestikten sonra geldi�i i�in kullan�labilir bakiye de�i�iyo 
			BigDecimal bakiye = crdDebitTransferBakiye.getBakiye();
			BigDecimal klnBakiye = kullBakiye.subtract(bakiye);
			if (klnBakiye.compareTo(tutar)<0){
				BigDecimal dusBakiye = tutar.subtract(klnBakiye);
				GMMap bkyMap = new GMMap();
				bkyMap.put("HESAP_NO",accountNo);
				bkyMap.put("TUTAR",dusBakiye.multiply(BigDecimal.valueOf(-1)));
				bkyMap.put("EXTERNAL_TRX_ID", iMap.getString("ISLEM_NO"));
				GMServiceExecuter.call("BNSPR_TRANSFER_TO_DEBIT_FROM_CREDIT", bkyMap);
			}
		}
	}
	private static CrdDebitTransferBakiye findTopupRecord(BigDecimal accountNo){
		Session session = DAOSession.getSession("BNSPRDal");
		 CrdDebitTransferBakiye crdDebitTransferBakiye =
	                (CrdDebitTransferBakiye) session.createCriteria(CrdDebitTransferBakiye.class).add(Restrictions.eq("hesapNo" , accountNo))
	                        .uniqueResult();
		 return crdDebitTransferBakiye;
	}
}