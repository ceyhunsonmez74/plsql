package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TffBasvuruUyariKodPrTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruUyariKodPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3820Services {

	@GraymoundService("BNSPR_TRN3820_GET_LIST")
	public static GMMap get_tff_basvuru_uyari_kod_pr(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "PR_TABLE";

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3820.GET_TFF_BASVURU_UYARI_KOD_PR}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3820_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "PR_TABLE";
			CallableStatement stmt = null;
			Connection conn = null;
			List<?> list = (List<?>) iMap.get("PR_TABLE");

			conn = DALUtil.getGMConnection();

			for (int i = 0; i < list.size(); i++) {

				if (iMap.getString(tableName, i, "DURUM_KODU") == null || iMap.getString(tableName, i, "DURUM_KODU").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "DURUM_KODU");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if (iMap.getString(tableName, i, "UYARI_TIPI") == null || iMap.getString(tableName, i, "UYARI_TIPI").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "UYARI_TIPI");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if (iMap.getString(tableName, i, "MAX_BEKLEME_SURESI") == null || iMap.getString(tableName, i, "MAX_BEKLEME_SURESI").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "MAX_BEKLEME_SURESI");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				TffBasvuruUyariKodPrTx tffBasvuruUyariKodPrTx = new TffBasvuruUyariKodPrTx();
				TffBasvuruUyariKodPrTxId tffBasvuruUyariKodPrTxId = new TffBasvuruUyariKodPrTxId();

				tffBasvuruUyariKodPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));

				stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('TFF_BASVURU_UYARI_KOD_PR')}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.execute();

				tffBasvuruUyariKodPrTxId.setId(stmt.getBigDecimal(1));
				tffBasvuruUyariKodPrTx.setId(tffBasvuruUyariKodPrTxId);
				tffBasvuruUyariKodPrTx.setDurumKodu(iMap.getString(tableName, i, "DURUM_KODU"));
				tffBasvuruUyariKodPrTx.setUyariTipi(iMap.getString(tableName, i, "UYARI_TIPI"));
				tffBasvuruUyariKodPrTx.setTelAdres(iMap.getString(tableName, i, "TEL_ADRES"));
				tffBasvuruUyariKodPrTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				tffBasvuruUyariKodPrTx.setMaxBeklemeSuresi(iMap.getBigDecimal(tableName, i, "MAX_BEKLEME_SURESI"));
				session.save(tffBasvuruUyariKodPrTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3820");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			if (e.getCause() != null)
				throw new GMRuntimeException(0, e.getCause().getMessage());
			else
				throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3820_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		String tableName = "TABLO";

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> tffBasvuruUyariKodPrTxList = session.createCriteria(TffBasvuruUyariKodPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			int row = 0;
			for (Iterator<?> iterator = tffBasvuruUyariKodPrTxList.iterator(); iterator.hasNext(); row++) {
				TffBasvuruUyariKodPrTx tffBasvuruUyariKodPrTx = (TffBasvuruUyariKodPrTx) iterator.next();
				oMap.put(tableName, row, "TX_NO", iMap.getBigDecimal("TRX_NO"));
				oMap.put(tableName, row, "DURUM_KODU", tffBasvuruUyariKodPrTx.getDurumKodu());
				oMap.put(tableName, row, "UYARI_TIPI", tffBasvuruUyariKodPrTx.getUyariTipi());
				oMap.put(tableName, row, "TEL_ADRES", tffBasvuruUyariKodPrTx.getTelAdres());
				oMap.put(tableName, row, "ACIKLAMA", tffBasvuruUyariKodPrTx.getAciklama());
				oMap.put(tableName, row, "MAX_BEKLEME_SURESI", tffBasvuruUyariKodPrTx.getMaxBeklemeSuresi());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

		return oMap;
	}

}
