package tr.com.aktifbank.bnspr.creditcard.util;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import tr.com.aktifbank.bnspr.dao.KkSsProductMap;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.CommonDAOUtil;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class KkProductsUtil implements OceanMapKeys {
	
	private static final String SOURCE_MCHIP 		= "MCHIP";
	private static final String SOURCE_HCE 			= "HCE";
	private static final String SOURCE_NKOLAY 		= "NKOLAY";
	private static final String SOURCE_UPT			= "UPT";
	private static final String SOURCE_YIM			= "YIM";
	private static final String SOURCE_NND			= "NND";
	private static final String SUB_SOURCE_NND_V1	= "V1";
	private static final String SUB_SOURCE_NND_V2	= "V2";

	public static KkSsProductMap getProductInfoById(String productId) {
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productId);
		try{
			KkSsProductMap kkSSProductMap = (KkSsProductMap) CommonDAOUtil.getObject(KkSsProductMap.class, searchMap);
			return kkSSProductMap;
		}
		catch (Exception e) {
			try{
				List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
				Object object =  productInfoList.get(0);
				KkSsProductMap kkSsProductMap = (KkSsProductMap) object; //birden fazla kay�t varsa ilkini d�nd�r�r
				return kkSsProductMap;
			}
			catch (Exception ex) {
				return null;
			}

		}

	}
	
	@GraymoundService("BNSPR_GET_KK_PRODUCT_INFO_BY_SOURCE")
	public static GMMap getProductInfoListBySource (GMMap iMap){
		
		GMMap oMap = new GMMap();
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, iMap.getString("SOURCE"));

		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			KkSsProductMap kkSsProductMap = null;
			int i =0;
			for (Object object : productInfoList) {
				kkSsProductMap = (KkSsProductMap) object;
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_URUN_ID, kkSsProductMap.getUrunId());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_KART_GRUP_TANIM, kkSsProductMap.getKartGrupTanim());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD, kkSsProductMap.getUrunId());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_KART_TIPI, kkSsProductMap.getUrunId());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_FINANSAL_KOD, kkSsProductMap.getFinansalKod());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_URUN_ADI, kkSsProductMap.getBasvuruUrunAdi());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_PAKET, kkSsProductMap.getPaket());
			i++;
			}
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_IS_NKOLAY_PP_PRODUCT")
	public static GMMap isNkolayPPProduct (GMMap productMap){
		
		boolean isNkolay = false;
		GMMap oMap = new GMMap();
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, "IN:YIM,UPT");
		searchMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_PrepaidCard);
		searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productMap.getString(PRODUCT_ID));
		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			isNkolay = true;
		}
		if (StringUtils.isEmpty(productMap.getString(PRODUCT_ID))){
			isNkolay = false;
		}

		oMap.put("IS_NKOLAY", isNkolay ? "Y":"N");
		return oMap;
	}
	
	@GraymoundService("BNSPR_IS_MCHIP_PRODUCT")
	public static GMMap isMchipProduct (GMMap productMap){
		
		GMMap oMap = new GMMap();
		oMap.put("IS_MCHIP", isMchipProduct(productMap.getString(PRODUCT_ID)) ? "Y":"N");
		
		return oMap;
	}
	
	public static boolean isMchipProduct (String productId){

		return checkProductandSource(productId, SOURCE_MCHIP);
	}
	
	@GraymoundService("BNSPR_IS_NKOLAY_PRODUCT")
	public static GMMap isNkolayProduct (GMMap productMap){
		
		GMMap oMap = new GMMap();
		oMap.put("IS_NKOLAY", isNkolayProduct(productMap.getString(PRODUCT_ID)) ? "Y":"N");
		return oMap;
	}
	

	public static boolean isNkolayProduct (String productId){
		
		boolean isNkolay = false;
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_OZEL_TANIM, SOURCE_NKOLAY);
		searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productId);
		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			isNkolay = true;
		}

		return isNkolay;
	}
	
	public static boolean isNkolayDebitProduct (String productId, String marka){
		
		boolean isNkolay = false;
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_OZEL_TANIM, SOURCE_NKOLAY);
		searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productId);
		searchMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_Basvuru_DebitCard);
		if (!StringUtils.isEmpty(marka))
			searchMap.put(OceanConstants.URUN_TABLO_MARKA, marka);
		
		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			isNkolay = true;
		}

		return isNkolay;
	}
	
	
	public static String getSourceFromProductId(String productId) {
		try{
			HashMap<String, String> searchMap = new HashMap<String, String>();
			searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productId);
			KkSsProductMap kkSSProductMap = (KkSsProductMap) CommonDAOUtil.getObject(KkSsProductMap.class, searchMap);
			if (kkSSProductMap != null){
				return kkSSProductMap.getKaynakGrupKod();
			}
			else{
				return "";
			}
		}
		catch (Exception e) {
			 e.printStackTrace();
			 return "";
		}

	}
	
	@GraymoundService("BNSPR_GET_KK_PRODUCT_INFO_BY_DETAILS")
	public static GMMap getProductInfoListByMap (GMMap filterMap){
		
		GMMap oMap = new GMMap();
		
		HashMap<String, String> searchMap = new HashMap<String, String>();
		
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD)))
			searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, filterMap.getString(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_URUN_ID)))
			searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, filterMap.getString(OceanConstants.URUN_TABLO_URUN_ID));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_KART_GRUP_TANIM)))
			searchMap.put(OceanConstants.URUN_TABLO_KART_GRUP_TANIM, filterMap.getString(OceanConstants.URUN_TABLO_KART_GRUP_TANIM));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_KART_TIPI)))
			searchMap.put(OceanConstants.URUN_TABLO_KART_TIPI, filterMap.getString(OceanConstants.URUN_TABLO_KART_TIPI));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD)))
			searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD, filterMap.getString(OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_OZEL_TANIM)))
			searchMap.put(OceanConstants.URUN_TABLO_OZEL_TANIM, filterMap.getString(OceanConstants.URUN_TABLO_OZEL_TANIM));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_PAKET)))
			searchMap.put(OceanConstants.URUN_TABLO_PAKET, filterMap.getString(OceanConstants.URUN_TABLO_PAKET));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_MARKA)))
			searchMap.put(OceanConstants.URUN_TABLO_MARKA, filterMap.getString(OceanConstants.URUN_TABLO_MARKA));
		if (!StringUtils.isEmpty(filterMap.getString(OceanConstants.URUN_TABLO_MUSTERI_TIPI)))
			searchMap.put(OceanConstants.URUN_TABLO_MUSTERI_TIPI, filterMap.getString(OceanConstants.URUN_TABLO_MUSTERI_TIPI));
		else
			searchMap.put(OceanConstants.URUN_TABLO_MUSTERI_TIPI, "NULL");
			
		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			KkSsProductMap kkSsProductMap = null;
			int i =0;
			for (Object object : productInfoList) {
				kkSsProductMap = (KkSsProductMap) object;
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_URUN_ID, kkSsProductMap.getUrunId());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_KART_GRUP_TANIM, kkSsProductMap.getKartGrupTanim());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD, kkSsProductMap.getKaynakAltGrupKod());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_KART_TIPI, kkSsProductMap.getKartTipi());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_FINANSAL_KOD, kkSsProductMap.getFinansalKod());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_URUN_ADI, kkSsProductMap.getBasvuruUrunAdi());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_PAKET, kkSsProductMap.getPaket());
				oMap.put(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_LOGO_KOD, kkSsProductMap.getLogoKod());
			i++;
			}
		}
		return oMap;
	}
	
	public static String getProductIdByDetails (String sourceCode, String subSourceCode, String brand, String cardType){
		try{
			return  getProductIdByDetails (sourceCode, subSourceCode, brand, cardType, "");
		}
		catch (Exception e) {
			return "";
		}
	}
	
	public static String getProductIdByDetails (String sourceCode, String subSourceCode, String brand, String cardType, String specialDefinition){
		try{			
			String productId = "";
			HashMap<String, String> searchMap = new HashMap<String, String>();
			
			if (!StringUtils.isEmpty(sourceCode))
			searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, sourceCode);
			if (!StringUtils.isEmpty(subSourceCode))
			searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD, subSourceCode);
			if (!StringUtils.isEmpty(brand))
			searchMap.put(OceanConstants.URUN_TABLO_MARKA, brand);
			if (!StringUtils.isEmpty(cardType))
			searchMap.put(OceanConstants.URUN_TABLO_KART_TIPI, cardType);
			if (!StringUtils.isEmpty(specialDefinition))
				searchMap.put(OceanConstants.URUN_TABLO_OZEL_TANIM, specialDefinition);
	
			List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
			if (!productInfoList.isEmpty()) {
				KkSsProductMap kkSsProductMap = (KkSsProductMap) productInfoList.get(0);
				productId = kkSsProductMap.getUrunId();
			}
			return productId;
		}
		catch (Exception e) {
			return "";
		}
	}
	
	
	public static String getHceProductId (String subSource){
		try{				
			return getProductIdByDetails(SOURCE_HCE, subSource, null, null);
		}
		catch (Exception e) {
			return "";
		}
	}
	
	public static String getHceProductId (String hceSubSource, String specialDefinition){
		try{				
			return getProductIdByDetails(SOURCE_HCE, hceSubSource, null, null, specialDefinition);
		}
		catch (Exception e) {
			return "";
		}
	}
	
	public static List<?> getHceProducts (String subSourceCode, String specialDefinition){
		List<?> productInfoList = null;
		try{				
 			HashMap<String, String> searchMap = new HashMap<String, String>();	
 			
			searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, SOURCE_HCE);
			
			if (!StringUtils.isEmpty(subSourceCode))
			searchMap.put(OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD, subSourceCode);
			if (!StringUtils.isEmpty(specialDefinition))
			searchMap.put(OceanConstants.URUN_TABLO_OZEL_TANIM, "NVL:"+specialDefinition);
			productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		
			return productInfoList;
		}
		catch (Exception e) {
			return productInfoList;
		}
	}
	
	
	@GraymoundService("BNSPR_HCE_GET_OFFLINE_PRODUCT_ID")
	public static GMMap getHceOfflineProductId (GMMap iMap){
		GMMap oMap = new GMMap();
		try{				
			String productId = getHceProductId(OFFLINE, iMap.getString(OceanConstants.URUN_TABLO_OZEL_TANIM));
			oMap.put(PRODUCT_ID, productId);
			return oMap;
		}
		catch (Exception e) {
			return oMap;
		}
	}
	
	@GraymoundService("BNSPR_GET_NONAME_PRODUCT_ID")
	public static GMMap getNonameProductId (GMMap iMap){
		GMMap oMap = new GMMap();
		try{	
			oMap.put(PRODUCT_ID, getNoNameCardProductId(iMap.getString("VERSION",StringUtils.EMPTY)));
			return oMap;
		}
		catch (Exception e) {
			return oMap;
		}
	}

	//sanal kart m�?
	public static boolean isVirtualProduct (String productId){
		
		return productId.equals(getVirtualProductId());
	}
	
	//sanal kart �r�n kodu?
	public static String getVirtualProductId (){
		
		return getHceProductId(ECOM,null);
		
	}

	//noname kart �r�n kodu yeni g�rselli kart i�in Version 2 alt grup tan�mlad�k, default bu kart bas�lacak, eskisi V1
	public static String getNoNameCardProductId (String version){
		try{	
			if (StringUtils.isEmpty(version))
				version = SUB_SOURCE_NND_V2;
			
			return getProductIdByDetails(SOURCE_NND, version, null, null);
		}
		catch (Exception e) {
			return "";
		}
	}
	
	//hce kart m� online/offline/ecom?
	public static boolean isHceProduct (String productId, String subSource){
		
		return isHceProduct(productId, subSource, null);
	}
	
	//hce kart m�  online/offline/ecom + mara�/ankara?
	public static boolean isHceProduct(String productId, String subSource, String specialDefinition) {

		List<?> productList = getHceProducts(subSource, specialDefinition);

		for (Object product : productList) {

			KkSsProductMap kkProduct = (KkSsProductMap) product;

			if (productId.equals(kkProduct.getUrunId()))
				return true;
		}

		return false;

	}
	
	
	@GraymoundService("BNSPR_IS_HCE_PRODUCT")
	public static GMMap isHceProduct (GMMap productMap){
		
		GMMap oMap = new GMMap();
		String subSource = "";
		String specialDefinition = "";

		if (productMap.containsKey("PRODUCT_SUB_TYPE") && !StringUtils.isEmpty(productMap.getString("PRODUCT_SUB_TYPE"))){
			 subSource = productMap.getString("PRODUCT_SUB_TYPE");
		}
		if (productMap.containsKey("SPECIAL_DEFINITION") && !StringUtils.isEmpty(productMap.getString("SPECIAL_DEFINITION"))){
			 specialDefinition = productMap.getString("SPECIAL_DEFINITION");

		}
		oMap.put("IS_HCE", isHceProduct(productMap.getString(PRODUCT_ID), subSource, specialDefinition )? "Y":"N");
		
		
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_IS_VIRTUAL_PRODUCT")
	public static GMMap isVirtualProduct (GMMap productMap){
		
		GMMap oMap = new GMMap();
		oMap.put("IS_VIRTUAL", isVirtualProduct(productMap.getString(PRODUCT_ID)) ? "Y":"N");
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_IS_UPT_PRODUCT")
	public static GMMap isUptProduct (GMMap productMap){
		
		GMMap oMap = new GMMap();
		oMap.put("IS_UPT", isUptPpProduct(productMap.getString(PRODUCT_ID)) ? "Y":"N");
		
		return oMap;
	}
	
	public static boolean checkProductandSource (String productId, String source){
		
		return source.equals(getSourceFromProductId(productId));
	}
	
	@GraymoundService("BNSPR_CHECK_KK_PRODUCT_AND_SOURCE")
	public static GMMap checkProductandSource (GMMap productMap){
		
		GMMap oMap = new GMMap();
		boolean isRelated = false;
		isRelated = checkProductandSource(productMap.getString(SOURCE),productMap.getString(PRODUCT_ID));
		oMap.put("IS_RELATED", isRelated?"Y":"N");

		return oMap;
	}
	
	@GraymoundService("BNSPR_GET_KK_PRODUCT_SOURCE")
	public static GMMap getProductandSource (GMMap productMap){
		
		GMMap oMap = new GMMap();
		oMap.put("SOURCE", getSourceFromProductId (productMap.getString(PRODUCT_ID)));

		return oMap;
	}
	
	public static String p2dProductCodeToConvert (String productId){
		
		KkSsProductMap kkSSProduct = getProductInfoById(productId);
		return kkSSProduct.getP2dUrunId();
	}
	
	public static boolean isUptPpProduct (String productId){

		return checkProductandSource(productId, SOURCE_UPT);
	}
	
	public static boolean isYimPpProduct (String productId){

		return checkProductandSource(productId, SOURCE_YIM);
	}	
	
	public static boolean isTroyDebitProduct (String productId){

		boolean isTroy = false;
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productId);
		searchMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_DebitCard);
		searchMap.put(OceanConstants.URUN_TABLO_MARKA, OceanConstants.TROY);

		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			isTroy = true;
		}

		return isTroy;
	}
	
	
	@GraymoundService("BNSPR_IS_TROY_PRODUCT")
	public static GMMap isTroyDebitProduct (GMMap productMap){
		
		GMMap oMap = new GMMap();
		boolean isTroy = false;
		if (!StringUtils.isEmpty(productMap.getString(CARD_TYPE)) && OceanConstants.Akustik_DebitCard.equals(productMap.getString(CARD_TYPE)))
			isTroy = isTroyDebitProduct(productMap.getString(PRODUCT_ID));
		else if (!StringUtils.isEmpty(productMap.getString(CARD_TYPE)) && OceanConstants.Akustik_PrepaidCard.equals(productMap.getString(CARD_TYPE)))
			isTroy = isTroyPpProduct(productMap.getString(PRODUCT_ID));
		else{
			isTroy  = (isTroyDebitProduct(productMap.getString(PRODUCT_ID)) || isTroyPpProduct(productMap.getString(PRODUCT_ID)));
		}
		oMap.put("IS_TROY", isTroy? "Y":"N");	
		return oMap;
	}
	
	public static boolean isTroyPpProduct (String productId){

		boolean isTroy = false;
		HashMap<String, String> searchMap = new HashMap<String, String>();
		searchMap.put(OceanConstants.URUN_TABLO_URUN_ID, productId);
		searchMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_PrepaidCard);
		searchMap.put(OceanConstants.URUN_TABLO_MARKA, OceanConstants.TROY);

		List<?> productInfoList = CommonDAOUtil.getObjects(KkSsProductMap.class, searchMap);
		if (!productInfoList.isEmpty()) {
			isTroy = true;
		}

		return isTroy;
	}
	@GraymoundService("BNSPR_GET_ALL_CARDS_FOR_INTERNET")
	public static GMMap getAllCardsForInternet(GMMap iMap) {

		GMMap outMap = new GMMap();
		GMMap pinSetMap = new GMMap();
		BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
		String tckn = iMap.getString("TCKN");
		
		if(customerNo==null){
			 customerNo= new BigDecimal(BnsprOceanCommonFunctions.getCustomerNo(tckn, null, null));
		}

		if (!BnsprOceanCommonFunctions.isNewCard(customerNo.toString(), null, null)) {
			GMMap serviceInMap = new GMMap();
			serviceInMap.put("CUSTOMER_NO", customerNo);
			serviceInMap.put("TCKN", "");
			serviceInMap.put("CARD_BANK_STATUS", OceanConstants.Card_Bank_Status_Open);
			if (iMap.containsKey("IS_PROCEED")) {
				serviceInMap.put("IS_PROCEED", iMap.get("IS_PROCEED"));
			}
			if (iMap.containsKey("PROCEED")) {
				serviceInMap.put("PROCEED", iMap.get("PROCEED"));
			}
			GMMap creditCardMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", serviceInMap);
			int size = creditCardMap.getSize("CARD_DETAIL_INFO");
			int index = 0;
			for (int i = 0; i < size; index++, i++) {
				String cardNo = creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO");
				
				if(StringUtils.isEmpty(creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2")))
					creditCardMap.put("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2", "");
				
				String cardEmboseName = new StringBuilder().append(creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1")).append(" ").append(creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2")).toString();
				
				pinSetMap.clear();
				pinSetMap.put("CARD_NO", cardNo);
				pinSetMap = GMServiceExecuter.call("BNSPR_OCEAN_CHECK_PIN_SET", pinSetMap);

				outMap.put("TABLE", index, "CARD_DCI", creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
				outMap.put("TABLE", index, "CARD_DCI_AKUSTIK",creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
				outMap.put("TABLE", index, "PRODUCT_ID", creditCardMap.get("CARD_DETAIL_INFO", i, "PRODUCT_ID"));
				outMap.put("TABLE", index, "MASKED_CARD_NO", maskCardNumber(cardNo));
				outMap.put("TABLE", index, "CARD_NO", cardNo);
				outMap.put("TABLE", index, "CARD_EMBOSS_NAME", cardEmboseName);
				outMap.put("TABLE", index, "CARD_PRODUCT_NAME", creditCardMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME"));
				outMap.put("TABLE", index, "SYSTEM", "O");
				outMap.put("TABLE", index, "DESFIRE_ID", creditCardMap.get("CARD_DETAIL_INFO", i, "DESFIRE_ID"));
				outMap.put("TABLE", index, "IS_PIN_SET", pinSetMap.get("IS_PIN_SET"));
				outMap.put("TABLE", index, "VISA_STAT", creditCardMap.get("CARD_DETAIL_INFO", i, "VISA_STAT"));
				outMap.put("TABLE", index, "IS_PROCEED", creditCardMap.get("CARD_DETAIL_INFO", i, "IS_PROCEED"));
				outMap.put("TABLE", index, "VISA_START_DATE", creditCardMap.get("CARD_DETAIL_INFO", i, "VISA_START_DATE"));
				outMap.put("TABLE", index, "VISA_END_DATE", creditCardMap.get("CARD_DETAIL_INFO", i, "VISA_END_DATE"));

				outMap.put("TABLE", index, "CARD_AVAIL_LIMIT", creditCardMap.get("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT"));
				outMap.put("TABLE", index, "CARD_GROUP", creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_GROUP").toString().equals("1") ? "TFF" : "PASSO");
				outMap.put("TABLE", index, "KMH_LIMIT", creditCardMap.get("CARD_DETAIL_INFO", i, "KMH_LIMIT"));
				outMap.put("TABLE", index, "EXPIRY_DATE", creditCardMap.get("CARD_DETAIL_INFO", i, "EXPIRY_DATE"));
				outMap.put("TABLE", index, "CLEAR_CARD_NO", cardNo);
			}

			serviceInMap.clear();
			serviceInMap.put("CUSTOMER_NO", customerNo);
			serviceInMap.put("CARD_DCI", "A");
			serviceInMap.put("TCKN", "");
			serviceInMap.put("CARD_BANK_STATUS", OceanConstants.Card_Bank_Status_Open);

			GMMap cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", serviceInMap);
			size = cardMap.getSize("CARD_DETAIL_INFO");

			for (int i = 0; i < size; index++, i++) {
				String cardNo = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO");
				
				if(StringUtils.isEmpty(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2")))
					cardMap.put("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2", "");

				String cardEmboseName = new StringBuilder().append(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1")).append(" ").append(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2")).toString();
				
				pinSetMap.clear();
				pinSetMap.put("CARD_NO", cardNo);
				pinSetMap = GMServiceExecuter.call("BNSPR_INTRACARD_CHECK_PIN_SET", pinSetMap);

				outMap.put("TABLE", index, "CARD_DCI",  cardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
				outMap.put("TABLE", index, "CARD_DCI_AKUSTIK",cardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
				outMap.put("TABLE", index, "PRODUCT_ID", cardMap.get("CARD_DETAIL_INFO", i, "PRODUCT_ID"));
				outMap.put("TABLE", index, "MASKED_CARD_NO", maskCardNumber(cardNo));
				outMap.put("TABLE", index, "CARD_NO", cardNo);
				outMap.put("TABLE", index, "CARD_EMBOSS_NAME", cardEmboseName);
				outMap.put("TABLE", index, "CARD_PRODUCT_NAME", cardMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME"));
				outMap.put("TABLE", index, "SYSTEM", "I");
				outMap.put("TABLE", index, "DESFIRE_ID", getDesfireID(cardNo));
				outMap.put("TABLE", index, "IS_PIN_SET", pinSetMap.get("IS_PIN_SET"));
				outMap.put("TABLE", index, "VISA_STAT", cardMap.get("CARD_DETAIL_INFO", i, "VISA_STAT"));
				outMap.put("TABLE", index, "VISA_START_DATE", cardMap.get("CARD_DETAIL_INFO", i, "VISA_START_DATE"));
				outMap.put("TABLE", index, "VISA_END_DATE", cardMap.get("CARD_DETAIL_INFO", i, "VISA_END_DATE"));
				

				outMap.put("TABLE", index, "CARD_AVAIL_LIMIT", cardMap.get("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT"));
				outMap.put("TABLE", index, "CARD_GROUP", cardMap.getString("CARD_DETAIL_INFO", i, "CARD_GROUP").toString().equals("1") ? "TFF" : "PASSO");
				outMap.put("TABLE", index, "KMH_LIMIT", cardMap.get("CARD_DETAIL_INFO", i, "KMH_LIMIT"));
				outMap.put("TABLE", index, "EXPIRY_DATE", cardMap.get("CARD_DETAIL_INFO", i, "EXPIRY_DATE"));
				outMap.put("TABLE", index, "CLEAR_CARD_NO", cardNo);


			}
		}
		else {
			GMMap serviceInMap = new GMMap();
			serviceInMap.put("CUSTOMER_NO", customerNo);
			serviceInMap.put("TCKN", "");
			GMMap cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", serviceInMap);
			int size = cardMap.getSize("CARD_DETAIL_INFO");
			int index = 0;
			for (int i = 0; i < size; i++) {
				if (cardMap.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE").equals("N") && cardMap.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE").equals("N")) {
					String cardNo = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO");
					String clearCardNo = BnsprOceanCommonFunctions.getClearCardNo(cardNo);
					
					if(StringUtils.isEmpty(cardMap.getString("CARD_DETAIL_INFO", i, "EMBOSS_NAME2")))
						cardMap.put("CARD_DETAIL_INFO", i, "EMBOSS_NAME2", "");
					
					String cardEmboseName = new StringBuilder().append(cardMap.getString("CARD_DETAIL_INFO", i, "EMBOSS_NAME")).append(" ").append(cardMap.getString("CARD_DETAIL_INFO", i, "EMBOSS_NAME2")).toString();
					
					
					
					pinSetMap.clear();
					pinSetMap.put("CARD_NO", cardNo);
					pinSetMap = GMServiceExecuter.call("BNSPR_GENERAL_CHECK_PIN_SET", pinSetMap);
					boolean isIntra = isIntraInt(cardMap.getString("CARD_DETAIL_INFO", i, "SEGMENT"), cardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI")) ;
					outMap.put("TABLE", index, "CARD_DCI", BnsprOceanCommonFunctions.newDciToExistingDci(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI")));
					outMap.put("TABLE", index, "CARD_DCI_AKUSTIK",cardMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI"));
					outMap.put("TABLE", index, "PRODUCT_ID", cardMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_ID"));
					outMap.put("TABLE", index, "MASKED_CARD_NO", maskCardNumber(cardNo));
					outMap.put("TABLE", index, "CARD_NO", cardNo);
					outMap.put("TABLE", index, "CARD_EMBOSS_NAME", cardEmboseName);
					outMap.put("TABLE", index, "CARD_PRODUCT_NAME", cardMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME"));
					outMap.put("TABLE", index, "SYSTEM", isIntra ? "I" : "O");
					outMap.put("TABLE", index, "DESFIRE_ID", (isIntra) ? getDesfireID(cardNo) : StringUtils.EMPTY);
					outMap.put("TABLE", index, "IS_PIN_SET", pinSetMap.get("IS_PIN_SET"));
					outMap.put("TABLE", index, "VISA_STAT", cardMap.get("CARD_DETAIL_INFO", i, "VISA_STAT"));
					outMap.put("TABLE", index, "VISA_START_DATE", cardMap.get("CARD_DETAIL_INFO", i, "VISA_START_DATE"));
					outMap.put("TABLE", index, "VISA_END_DATE", cardMap.get("CARD_DETAIL_INFO", i, "VISA_END_DATE"));
					outMap.put("TABLE", index, "EXPIRY_DATE", cardMap.get("CARD_DETAIL_INFO", i, "EXPIRY_DATE"));
					outMap.put("TABLE", index, "CLEAR_CARD_NO", clearCardNo);
					outMap.put("TABLE", index, "IS_PROCEED", cardMap.get("CARD_DETAIL_INFO", i, "IS_PROCEED"));


					outMap.put("TABLE", index, "CARD_AVAIL_LIMIT", cardMap.get("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT"));
					outMap.put("TABLE", index, "CARD_GROUP", cardMap.getString("CARD_DETAIL_INFO", i, "SEGMENT").toString().equals("TFF") ? "TFF" : "PASSO");
					if (cardMap.get("CARD_DETAIL_INFO", i, "DEBIT_ACCOUNT_NO") != null && cardMap.getBigDecimal("CARD_DETAIL_INFO", i, "DEBIT_ACCOUNT_NO").compareTo(BigDecimal.ZERO) > 0) {
						try {
							outMap.put("TABLE", index, "KMH_LIMIT", getKMHBalance(cardMap.getBigDecimal("CARD_DETAIL_INFO", i, "DEBIT_ACCOUNT_NO")));
						}
						catch (Exception e) {
							outMap.clear();
							e.printStackTrace();
							return outMap;
						}
					}
					index = index + 1;
				}
			}
		}
		return outMap;

	}
	public static String maskCardNumber(String cardNumber) {

		return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})", "**** **** **** $3");
	}

	public static boolean isIntraInt(String segment, String cardDci) {
		if ("TFF".equals(segment) && !OceanConstants.Akustik_CreditCard.equals(cardDci))
			return true;
		else
			return false;
	}
	public static String getDesfireID(String cardNo) {
		GMMap serviceMap = new GMMap().put("CARD_NO", cardNo);
		String desfireId = GMServiceExecuter.call("BNSPR_INTRACARD_GET_DESFIRE_ID", serviceMap).getString("DESFIRE_LIST", 0, "DESFIRE_ID");

		return desfireId;
	}
	private static BigDecimal getKMHBalance(BigDecimal accountNo) throws Exception {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		BigDecimal rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KMH.kmh_limit_al(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, accountNo);
			stmt.execute();

			rSet = (BigDecimal) stmt.getObject(1);

			return rSet;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
