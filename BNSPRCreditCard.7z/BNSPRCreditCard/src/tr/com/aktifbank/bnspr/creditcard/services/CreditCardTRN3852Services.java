package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuruKararCozmeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3852Services {

	@GraymoundService("BNSPR_TRN3852_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Gerekce listesini al
			iMap.put("ISLEM_KOD", "3198");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3197_GEREKCE_LIST", iMap));
			
			//Durum combolarinin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call pkg_trn3852.Get_Durum_List(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setString(1, iMap.getString("DURUM_KOD"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(2);
			DALUtil.fillComboBox(oMap, "ESKI_DURUM_LIST", true, rSet);
			
			rSet = (ResultSet) stmt.getObject(3);
			DALUtil.fillComboBox(oMap, "YENI_DURUM_LIST", true, rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3852_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Trx kontrol
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null || BigDecimal.ZERO.compareTo(trxNo) == 0) {
				CreditCardServicesUtil.raiseGMError("330", "Islem No");
			}
			
			saveTffBasvuruKararCozmeTx(iMap);
			
			GMMap sorguMap = new GMMap();
			sorguMap.put("TRX_NAME", "3852");
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	private static void saveTffBasvuruKararCozmeTx(GMMap iMap) {
		//Session al
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		
		//Varsa kullan yoksa guncelle
		TffBasvuruKararCozmeTx tffBasvuruKararCozmeTx = (TffBasvuruKararCozmeTx)
				session.get(TffBasvuruKararCozmeTx.class, trxNo);
		if (tffBasvuruKararCozmeTx == null) {
			tffBasvuruKararCozmeTx = new TffBasvuruKararCozmeTx();
			tffBasvuruKararCozmeTx.setTxNo(trxNo);
		}
		
		tffBasvuruKararCozmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
		tffBasvuruKararCozmeTx.setEskiDurumKodu(iMap.getString("ESKI_DURUM_KODU"));
		tffBasvuruKararCozmeTx.setYeniDurumKodu(iMap.getString("YENI_DURUM_KODU"));
		tffBasvuruKararCozmeTx.setKartDurum(iMap.getString("KART_DURUM"));
		tffBasvuruKararCozmeTx.setAciklama(iMap.getString("ACIKLAMA"));
		tffBasvuruKararCozmeTx.setKararGerekce(iMap.getString("GEREKCE"));
		
		session.save(tffBasvuruKararCozmeTx);
		session.flush();
	}
	
	@GraymoundService("BNSPR_TRN3852_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Trx kontrol
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null || BigDecimal.ZERO.compareTo(trxNo) == 0) {
				CreditCardServicesUtil.raiseGMError("330", "Islem No");
			}
			
			//Session al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Datayi al
			
			TffBasvuruKararCozmeTx tffBasvuruKararCozmeTx = (TffBasvuruKararCozmeTx)
					session.get(TffBasvuruKararCozmeTx.class, trxNo);
			if (tffBasvuruKararCozmeTx != null) {
				oMap.put("TX_NO", tffBasvuruKararCozmeTx.getTxNo());
				oMap.put("BASVURU_NO", tffBasvuruKararCozmeTx.getBasvuruNo());
				oMap.put("ESKI_DURUM_KOD", tffBasvuruKararCozmeTx.getEskiDurumKodu());
				oMap.put("YENI_DURUM_KOD", tffBasvuruKararCozmeTx.getYeniDurumKodu());
				oMap.put("ACIKLAMA", tffBasvuruKararCozmeTx.getAciklama());
				oMap.put("GEREKCE", tffBasvuruKararCozmeTx.getKararGerekce());
			} else {
				oMap.put("TX_NO", StringUtils.EMPTY);
				oMap.put("BASVURU_NO", StringUtils.EMPTY);
				oMap.put("ESKI_DURUM_KOD", StringUtils.EMPTY);
				oMap.put("YENI_DURUM_KOD", StringUtils.EMPTY);
				oMap.put("ACIKLAMA", StringUtils.EMPTY);
				oMap.put("GEREKCE", StringUtils.EMPTY);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * Girilen kriterlere gore arama yapip, basvuru listesi doner.
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO, KREDI_KART_TIPI, ADI, IKINCI_ADI,
	 *             SOYADI, DURUM_LIST, BASLANGIC_TAR, BITIS_TAR, IPTAL,KANAL_KODU, BAYI_KODU
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_TRN3852_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3852.List_Basvuru(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("PASAPORT_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("TFF_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," : CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));

			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("SOURCE"));
			stmt.setString(i++, iMap.getString("URUN_SAHIP_KODU"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3852_GET_KART_DURUM_INFO_BY_BASVURU")
	public static GMMap getKartDurumInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		
		try {
			//Basvuru durumu IPTAL ya da ACIK ise kart bilgisi sorgulamasi yapilabilir.
			String durumKodu = iMap.getString("DURUM_KODU");
			if (!"IPTAL".equals(durumKodu) && !"ACIK".equals(durumKodu)) {
				oMap.put("KART_DURUM", StringUtils.EMPTY);
				oMap.put("KART_DURUM_KOD", StringUtils.EMPTY);
				return oMap;
			}
			
			//Basvuru tipi al
			String kartTipi = iMap.getString("KART_TIPI");
			BigDecimal basvuruNo = null;
			String servisAdi = null;
			if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(kartTipi) || 
					CreditCardTffServices.TFF_DEBIT_KARTI.equals(kartTipi)) {
				basvuruNo = iMap.getBigDecimal("BASVURU_NO");
				servisAdi = "BNSPR_INTRA_GET_KART_NO_BY_BASVURU_NO";
			} else if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi)) {
				basvuruNo = iMap.getBigDecimal("KK_BASVURU_NO");
				servisAdi = "BNSPR_OCEAN_GET_KART_NO_BY_BASVURU_NO";
			} else {
				oMap.put("KART_DURUM", StringUtils.EMPTY);
				oMap.put("KART_DURUM_KOD", StringUtils.EMPTY);
				return oMap;
			}
			
			//Kart bilgisini al
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.putAll(GMServiceExecuter.execute(servisAdi, sorguMap));
			if (StringUtils.isBlank(sorguMap.getString("KART_NO"))) {
				oMap.put("KART_DURUM", StringUtils.EMPTY);
				oMap.put("KART_DURUM_KOD", StringUtils.EMPTY);
				return oMap;
			}
			
			oMap.put("KART_DURUM", sorguMap.get("DURUM_ACIKLAMA"));
			oMap.put("KART_DURUM_KOD", sorguMap.getString("DURUM_KODU") + sorguMap.getString("ALT_DURUM_KODU"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
}
