/**
 * 
 */
package tr.com.aktifbank.bnspr.creditcard.util;

import java.lang.reflect.Field;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;



import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;

import com.graymound.server.servlet.context.GMContext;


public class CreditCardMessagesUtil {

	private static Logger logger = Logger.getLogger(CreditCardMessagesUtil.class);

	private final static String STRING_EN = "en";
	private final static String STRING_TR = "tr";

	private final static Locale LOCALE_EN = new Locale(STRING_EN);
	private final static Locale LOCALE_TR = new Locale(STRING_TR);

	private final static ResourceBundle RESOURCEBUNDLE_EN = ResourceBundle.getBundle("configuration/localizedApplicationMessagesEn", LOCALE_EN);
	private final static ResourceBundle RESOURCEBUNDLE_TR = ResourceBundle.getBundle("configuration/localizedApplicationMessagesTr", LOCALE_TR);
	private final static ResourceBundle RESOURCEBUNDLE_DEFAULT = ResourceBundle.getBundle("configuration/localizedApplicationMessagesTr", LOCALE_TR);


	private CreditCardMessagesUtil() {
	}

	public static String getLocalizedMessageString(String messageKey, Object... parameters) {
		if (StringUtils.isEmpty(messageKey)) {
			throw new IllegalArgumentException("The requested message key is null or empty!");
		}

		StringBuilder returnText = new StringBuilder(StringUtils.EMPTY);
		
		String language;
		try {
			language =  GMContext.getCurrentContext().getSession().getLanguage();
			if (language == null) {
				language = "default";
			}
		}
		catch (Throwable e) {
			language = "default";
		}

		try {
			if (language.equalsIgnoreCase(STRING_EN)) {
				returnText.append(RESOURCEBUNDLE_EN.getString(messageKey));
			}
			else if (language.equalsIgnoreCase(STRING_TR)) {
				returnText.append(RESOURCEBUNDLE_TR.getString(messageKey));
			}
			else {
				logger.warn("The language retrieved from session is '" + language + "'. Default message text (en) will be displayed!");
				returnText.append(RESOURCEBUNDLE_DEFAULT.getString(messageKey));
			}
		}
		catch (MissingResourceException missingResourceException) {
			//hata mesaj tan�mlar� kanal* diye yap�l�yor, bu nedenle . sonras�ndaki hata a��klamas�n� _ leri replace edip g�dteriyoruz
			return StringUtils.replace(StringUtils.substringAfter(messageKey,"*"),"_"," ");
		}

		return MessageFormat.format(returnText.toString(), parameters);
	}

	public static String getResponseDataNames(String responseCode) throws Exception {

		try {
			Field[] fieldList = TffServicesMessages.class.getFields();
			for (Field f : fieldList) {
				if ((f.get(null).toString()).equals(responseCode))
					return f.getName();
			}
		}
		catch (Exception e) {
		}
		return responseCode;
	}
}
