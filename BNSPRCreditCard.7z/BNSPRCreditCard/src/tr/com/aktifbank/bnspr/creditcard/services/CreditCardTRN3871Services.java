
package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import net.dflora.pigeon.fix.AddressOut;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteriApsTx;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdresTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDiger;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDigerId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDigerTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikDigerTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlikTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruMeslekiBilgi;
import tr.com.aktifbank.bnspr.dao.KkBasvuruMeslekiBilgiTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefonId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefonTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefonTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPr;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.IntegrationException;
import tr.com.calikbank.integration.webservices.kps.KPSUtil;
import tr.com.obss.adc.core.util.ADCSession;
import tr.gov.nvi.kpsv2.model.CuzdanModel;
import tr.gov.nvi.kpsv2.model.KisiAdresBilgileriModel;
import tr.gov.nvi.kpsv2.model.KisiModel;
import tr.gov.nvi.kpsv2.model.TarihModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.BilesikKutukModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCCuzdanBilgisiModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKKModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKisiBilgisiModel;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3871Services {
	
	public static final String veliVasiTurEs ="31";
	private static final boolean isLocal = false;//KPS icin eklendi
	 
	@GraymoundService("BNSPR_TRN3871_ESGM_SESSION_AC_KAPA")
	public static GMMap esgmSessionAcKapa(GMMap iMap) {
		GMMap oMap = new GMMap();
		if("A".equals(iMap.getString("ESGM_SESSION_AC_KAPA"))){   // means Ac, sayfa acilisinda oldugu anlam�na gelir
			ADCSession.put("WRONG_CAPTCHA_TRY_NUMBER", 0);   // initially set 0
		}
		else if("K".equals(iMap.getString("ESGM_SESSION_AC_KAPA"))){    // sayfa kapatildi, session dan kaldir
			ADCSession.remove("WRONG_CAPTCHA_TRY_NUMBER");
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3871_INSERT_TARIHCE")
	public static GMMap insertTarihce(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int i=1;
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3871.insert_tarihce(?,?,?,?,?,?)}");
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KART_LIMITI"));
			stmt.setString(i++, iMap.getString("CURRENT_DATE"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("ISLEM_SONRASI_DURUM_KODU"));
			stmt.execute();
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3871_CHECK_FIELDS")
	public static GMMap checkFields(GMMap iMap){
		GMMap oMap=new GMMap();
		String procStr="{call PKG_TRN3871.After_Control(?)}";  // default, all fields being checked
		try{
			int i = 0;
			Object [] inputValues = new Object [2];
			Object [] outputValues = new Object [0];
			
			inputValues[i++]=BnsprType.NUMBER;
			inputValues[i++]=iMap.getBigDecimal("TRX_NO");
			if("Y".equals(iMap.getString("IS_FIRST_PAGE"))){  // if first page control
				procStr="{call PKG_TRN3871.First_Control(?)}";
			}
			oMap=  (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/** Kredi Karti basvurusu icin gerekli musteri<br> bilgilerini musteri tablolar�ndan ceker
	 * 
	 * @param MUSTERI_NO - Ekrandan
	 * @return {@link GMMap}
	 */
	@GraymoundService("BNSPR_TRN3871_GET_CUSTOMER_INFO")
	public static GMMap getCustomerInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		String procStr="{call PKG_TRN3871.rc_search_customer(?,?,?,?)}";
		try{
			int i = 0;
			Object [] inputValues = new Object [2];
			Object [] outputValues= new Object [6];
			
			inputValues[i++]=BnsprType.NUMBER;
			inputValues[i++]=iMap.getBigDecimal("MUSTERI_NO");
	
			i=0;
			outputValues[i++]=BnsprType.REFCURSOR;
			outputValues[i++]="RC_CUSTOMER_GENEL";
			outputValues[i++]=BnsprType.REFCURSOR;
			outputValues[i++]="RC_CUSTOMER_ADRES";
			outputValues[i++]=BnsprType.REFCURSOR;
			outputValues[i++]="RC_CUSTOMER_TELEFON";
			
			oMap=  (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/*
	 {RC_CUSTOMER_ADRES=[{ILCE_KOD=1773, IL_KOD=003, ADRES=SD ADFSADFASDF, POSTA_KOD=null, ADRES_KOD=E},                         {ILCE_KOD=1771, IL_KOD=003, ADRES=asdas dasdasdas, POSTA_KOD=null, ADRES_KOD=E1}, {ILCE_KOD=1773, IL_KOD=003, ADRES=df asdfsdfasdf asd, POSTA_KOD=null, ADRES_KOD=E2}, {ILCE_KOD=1287, IL_KOD=004, ADRES=d asfasdfasdf, POSTA_KOD=null, ADRES_KOD=I}],
	 RC_CUSTOMER_GENEL=[{SOYADI=YILMAZ G�M��, TC_KIMLIK_NO=17414886526, VERGI_DAIRE_KODU=null, DOGUM_TARIHI=19840730,
	 BABA_ADI=ZEKER�YA, UNVAN_ADI=Asistan, KIZLIK_SOYADI=DEDEE, ES_TC_KIMLIK_NO=null, EGITIM_KOD=U,
	 UNVAN_KOD=4000, ANNE_ADI=FATMA SELDA, IKINCI_ADI=null, MESLEK_KOD=31, ADI=SEZG�, EMAIL=a@a.a,
	  ISYERI_ADI=dfasdf asdf asd, CINSIYET_KOD=K, DOGUM_YERI=ZONGULDAK, VERGI_IL_KODU=null,
	  ANNE_KIZLIK_SOYADI=WERWERW, CALISMA_SEKLI=E3}],
	 RC_CUSTOMER_TELEFON=[{TEL_TIP=1, ALAN_KOD=472, DAHILI_NO=null, TEL_NO=2342423},                                                {TEL_TIP=2, ALAN_KOD=472, DAHILI_NO=null, TEL_NO=2342342}, {TEL_TIP=3, ALAN_KOD=555, DAHILI_NO=null, TEL_NO=4443543}, {TEL_TIP=1, ALAN_KOD=272, DAHILI_NO=null, TEL_NO=2342342}, {TEL_TIP=3, ALAN_KOD=555, DAHILI_NO=null, TEL_NO=3333337}, {TEL_TIP=1, ALAN_KOD=272, DAHILI_NO=null, TEL_NO=2312332}, {TEL_TIP=3, ALAN_KOD=555, DAHILI_NO=null, TEL_NO=3434354}, {TEL_TIP=3, ALAN_KOD=555, DAHILI_NO=null, TEL_NO=3435453}]}
	 */
	
	/** Internet uzerinden kredi kart basvurusu olusturur<br>
	 * 
	 * @param MUSTERI_NO - Ekrandan
	 * @param GONDERIM_ADRESI - Ekrandan: E or I olabilir
	 * @param AYLIK_GELIR Ekrandan
	 * @return {@link GMMap}
	 */
	@GraymoundService("BNSPR_TRN3871_CREATE_KK_BASVURU_BY_INTERNET")
    public static GMMap createKkBasvuruByInternet(GMMap iMap) {    // input:MUSTERI_NO,KIMLIK_SERI_NO,KIMLIK_SIRA_NO,MEDENI_HAL,GONDERIM_ADRESI
		GMMap oMap = new GMMap();
		GMMap customerMap = new GMMap();
		
		iMap.putAll( GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));  // get TRX_NO
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_BASVURU_NO", new GMMap()));   // get basvuru no
		iMap.putAll( GMServiceExecuter.execute("BNSPR_COMMON_GET_SUBE_KOD", new GMMap()));  // get SUBE_KOD
		iMap.put("BASVURU_NO", iMap.getString("ID"));
		iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()));
		
		customerMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_GET_CUSTOMER_INFO", iMap));  // get customer info
		
		// Save basvuru
		iMap.put("KREDI_KARTI_SEVIYESI", "K");  // Kredi Kart� seviyesi
		iMap.put("TC_KIMLIK_NO", customerMap.getString("RC_CUSTOMER_GENEL", 0, "TC_KIMLIK_NO"));
		iMap.put("ANNE_KIZLIK_SOYADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "ANNE_KIZLIK_SOYADI"));
		iMap.put("EMAIL", customerMap.getString("RC_CUSTOMER_GENEL", 0, "EMAIL"));
		iMap.put("ISYERI_ADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "ISYERI_ADI"));
		iMap.put("CALISMA_SEKLI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "CALISMA_SEKLI"));
		iMap.put("UNVANI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "UNVAN_KOD"));
		iMap.put("MESLEK", customerMap.getString("RC_CUSTOMER_GENEL", 0, "MESLEK_KOD"));
		iMap.put("ISYERI_VERGI_DAIRESI_ADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "VERGI_DAIRE_KODU"));
		iMap.put("ISYERI_VERGI_DAIRESI_IL", customerMap.getString("RC_CUSTOMER_GENEL", 0, "VERGI_IL_KODU"));
		iMap.put("MESLEK_ACIKLAMA", customerMap.getString("RC_CUSTOMER_GENEL", 0, "MESLEK_ACIKLAMA"));
		iMap.put("OGRENIM_DURUMU", customerMap.getString("RC_CUSTOMER_GENEL", 0, "EGITIM_KOD"));
		iMap.put("ADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "ADI"));
		iMap.put("IKINCI_ADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "IKINCI_ADI"));
		iMap.put("SOYADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "SOYADI"));
		iMap.put("DOGUM_TARIHI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "DOGUM_TARIHI"));
		iMap.put("DOGUM_YERI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "DOGUM_YERI"));
		iMap.put("BABA_ADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "BABA_ADI"));
		iMap.put("ANNE_ADI", customerMap.getString("RC_CUSTOMER_GENEL", 0, "ANNE_ADI"));
		iMap.put("CINSIYET", customerMap.getString("RC_CUSTOMER_GENEL", 0, "CINSIYET_KOD"));
		iMap.put("ES_TCKN", customerMap.getString("RC_CUSTOMER_GENEL", 0, "ES_TC_KIMLIK_NO"));
		iMap.put("KIMLIK_SERI_NO", customerMap.getString("RC_CUSTOMER_GENEL", 0, "KIMLIK_SERI_NO"));
		iMap.put("KIMLIK_SIRA_NO", customerMap.getString("RC_CUSTOMER_GENEL", 0, "KIMLIK_SIRA_NO"));
		iMap.put("MEDENI_HAL", customerMap.getString("RC_CUSTOMER_GENEL", 0, "MEDENI_HAL"));
		iMap.put("KREDI_KARTI_EKSTRE_SECIMI", iMap.getString("GONDERIM_ADRESI"));
		iMap.put("MUSTERI_GROUP", customerMap.getString("RC_CUSTOMER_GENEL", 0, "MUSTERI_GRUP"));
		iMap.put("MUSTERI_TIPI", "100");
		iMap.put("FINANSAL_TIP", "903");
		iMap.put("LOGO_KODU", "001");

		//Kart uzerindeki isim
		StringBuilder kartUzerindekiIsim = new StringBuilder();
		kartUzerindekiIsim.append(iMap.getString("ADI"));
		kartUzerindekiIsim.append(iMap.getString(" "));
		kartUzerindekiIsim.append(iMap.getString("IKINCI_ADI"));
		kartUzerindekiIsim.append(iMap.getString(" "));
		kartUzerindekiIsim.append(iMap.getString("SOYADI"));
		if (kartUzerindekiIsim.length() <= 22) {
			iMap.put("KART_UZERINDEKI_ISIM", kartUzerindekiIsim);
		} else {
			kartUzerindekiIsim = new StringBuilder();
			kartUzerindekiIsim.append(iMap.getString("ADI"));
			kartUzerindekiIsim.append(iMap.getString(" "));
			kartUzerindekiIsim.append(iMap.getString("SOYADI"));
			if (kartUzerindekiIsim.length() <= 22) {
				iMap.put("KART_UZERINDEKI_ISIM", kartUzerindekiIsim);
			} else {
				iMap.put("KART_UZERINDEKI_ISIM", kartUzerindekiIsim.substring(0, 22));
			}
		}
				
		//Hesap Kesim Tarihi
		iMap.put("HESAP_KESIM_TARIHI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K",
				new GMMap().put("PARAMETRE", "KK_HESAP_KESIM_TARIHI")).get("DEGER"));
		
		//KARTIN UZERINE YAZILACAK ISIM
		iMap.put("IS_FULL_SAVE", "Y");   // insert all records when calling 3871save
		// telefon kaydet
		int cepTelCounter=0;int isTelCounter=0;int evTelCounter=0;
		for(int j=0;j<customerMap.getSize("RC_CUSTOMER_TELEFON");j++){
			if("3".equals(customerMap.getString("RC_CUSTOMER_TELEFON", j, "TEL_TIP"))  && cepTelCounter ==0 ){       // cep telefonu
				iMap.put("CEP_ULKE_KOD", customerMap.getString("RC_CUSTOMER_TELEFON", j, "ULKE_KOD"));
				iMap.put("CEP_TEL_KOD", customerMap.getString("RC_CUSTOMER_TELEFON", j, "ALAN_KOD"));
				iMap.put("CEP_TEL_NO", customerMap.getString("RC_CUSTOMER_TELEFON", j, "TEL_NO"));
				cepTelCounter++;
			}
			else if("2".equals(customerMap.getString("RC_CUSTOMER_TELEFON", j, "TEL_TIP"))  && isTelCounter ==0){     // is telefonu
				iMap.put("IS_TEL_KOD", customerMap.getString("RC_CUSTOMER_TELEFON", j, "ALAN_KOD"));
				iMap.put("IS_TEL_NO", customerMap.getString("RC_CUSTOMER_TELEFON", j, "TEL_NO"));
				iMap.put("IS_TEL_DAHILI", customerMap.getString("RC_CUSTOMER_TELEFON", j, "DAHILI_NO"));
				isTelCounter++;
			}
			else if("1".equals(customerMap.getString("RC_CUSTOMER_TELEFON", j, "TEL_TIP"))  && evTelCounter ==0){     // ev telefonu
				iMap.put("EV_TEL_KOD", customerMap.getString("RC_CUSTOMER_TELEFON", j, "ALAN_KOD"));
				iMap.put("EV_TEL_NO", customerMap.getString("RC_CUSTOMER_TELEFON", j, "TEL_NO"));
				evTelCounter++;
			}
		}
		// adres kaydet
		int isAdresCounter=0;int evAdresCounter=0;
		for(int j=0;j<customerMap.getSize("RC_CUSTOMER_ADRES");j++){
			if("E".equals(customerMap.getString("RC_CUSTOMER_ADRES", j, "ADRES_KOD"))  && evAdresCounter ==0 ){       // ev adres
				iMap.put("EV_IL", customerMap.getString("RC_CUSTOMER_ADRES", j, "IL_KOD"));
				iMap.put("EV_ILCE", customerMap.getString("RC_CUSTOMER_ADRES", j, "ILCE_KOD"));
				iMap.put("EV_ADRESI", customerMap.getString("RC_CUSTOMER_ADRES", j, "ADRES"));
				iMap.put("EV_POSTA_KODU", customerMap.getString("RC_CUSTOMER_ADRES", j, "POSTA_KOD"));
				evAdresCounter++;
			}
			else if("I".equals(customerMap.getString("RC_CUSTOMER_ADRES", j, "ADRES_KOD"))  && isAdresCounter ==0){     // is adres
				iMap.put("IS_IL", customerMap.getString("RC_CUSTOMER_ADRES", j, "IL_KOD"));
				iMap.put("IS_ILCE", customerMap.getString("RC_CUSTOMER_ADRES", j, "ILCE_KOD"));
				iMap.put("IS_ADRESI", customerMap.getString("RC_CUSTOMER_ADRES", j, "ADRES"));
				iMap.put("IS_POSTA_KODU", customerMap.getString("RC_CUSTOMER_ADRES", j, "POSTA_KOD"));
				isAdresCounter++;
			}
		}
		// call 3871Save
		oMap.putAll( GMServiceExecuter.executeNT("BNSPR_TRN3871_SAVE", iMap));
		
		// call 3871Check Fields
		oMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", iMap));
		
		//Daha onceden acilmis kredi karti var mi? Kart varsa basvuru iptal edilir.
		iMap.put("MUST_NO", iMap.get("MUSTERI_NO"));
		iMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR);
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KART_VAR_MI", iMap));//MUST_NO,HATA_VERILECEK_MI
		//Iptal mesajini al.
		if (oMap.getBoolean("KART_VAR_MI")) {
			oMap.put("MESSAGE", oMap.get("KART_VAR_HATA_MESAJI"));
			return oMap;
		}
		
		// call devam sorgular
		oMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_DEVAM_SORGULAR", iMap));

		// call gonder sorgular
		oMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", iMap));
		
		// send trx
		oMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", iMap));
        
		return oMap;
	}
		
	/** Internet uzerinden ek kart basvurusu olusturur<br>
	 * 
	 * @param TCK_NO - Ekrandan
	 * @param CEP_ULKE_KOD - Ekrandan
	 * @param CEP_TEL_KOD - Ekrandan
	 * @param CEP_TEL_NO - Ekrandan
	 * @param ASIL_KART_NO - Ekrandan
	 * @param ASIL_KART_MUSTERI_NO - Ekrandan
	 * @param GONDERIM_ADRESI - Ekrandan: Y or N olabilir
	 * @param KART_LIMITI - Ekrandan
	 * @return {@link GMMap}
	 * Not: update musteri no aps sorgusundan sonra yapilmalidir
	 */
	@GraymoundService("BNSPR_TRN3871_CREATE_EK_KART_BASVURU_BY_INTERNET")
    public static GMMap createEkKartBasvuruByInternet(GMMap iMap) {    //input: TCK_NO,ASIL_KART_NO, GONDERIM_ADRESI,KART_LIMITI,ASIL_KART_MUSTERI_NO,
		GMMap oMap = new GMMap();
		iMap.putAll( GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));  // get TRX_NO
		
		iMap.put("TCKNO", iMap.getString("TCK_NO"));
		iMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_SORGULAMA", iMap));  // get kimlik sorgu info
		
		iMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));  // required for aps sorgu
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_BASVURU_NO", new GMMap()));   // get basvuru no
		iMap.put("BASVURU_NO", iMap.getString("ID"));
		iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()));
		if(!"".equals(iMap.getString("TCKNO_OUT"))){   // kps sorgu basarili
			iMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KIMLIK_DOGRULAMA", iMap));  // get kimlik dogrulama info
			iMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));  // get kimlik kayip sorgu info
			if(!"".equals(iMap.getString("OLUM_TARIHI")) && iMap.getString("OLUM_TARIHI") != null){
				GMMap errorMap = new GMMap();
				errorMap.put("HATA_NO", "918");
				errorMap.put("P1", iMap.getString("OLUM_TARIHI").substring(6, 8) + "/" +
				iMap.getString("OLUM_TARIHI").substring(4, 6) + "/" + iMap.getString("OLUM_TARIHI").substring(0, 4));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", errorMap);  // hata ver
				
			}
			else if (!"1".equals(iMap.getString("DURUMU"))) {
				GMMap errorMap = new GMMap();
				errorMap.put("HATA_NO", "2087");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", errorMap);  // hata ver
			}
				
		}
		
		else{
			GMMap errorMap = new GMMap();
			errorMap.put("HATA_NO", "1009");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", errorMap);  // hata ver
			
		}
		// end of kps sorgulari
		//
		GMMap sMap = new GMMap();
		sMap.put("TRX_NO", iMap.getString("TRX_NO"));
		// get basvuru no
		sMap.put("BASVURU_NO",iMap.getString("BASVURU_NO"));
		// get kanal kod
		sMap.put("KANAL_KOD",iMap.getString("KANAL_KOD"));
		sMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
		sMap.put("ADI", iMap.getString("AD1"));
		sMap.put("IKINCI_ADI", iMap.getString("AD2"));
		sMap.put("SOYADI", iMap.getString("SOYAD"));
		sMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
		sMap.put("DOGUM_TARIHI",iMap.getString("DOGUM_TARIHI"));
		sMap.put("BABA_ADI", iMap.getString("BABA_AD"));
		sMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD", "90"));
		sMap.put("CEP_TEL_KOD", iMap.getString("CEP_TEL_KOD"));
		sMap.put("CEP_TEL_NO",  iMap.getString("CEP_TEL_NO"));
		sMap.put("KIMLIK_SERI_NO_KPS", iMap.getString("KIMLIK_SERI_NO"));
		sMap.put("KIMLIK_SIRA_NO_KPS", iMap.getString("KIMLIK_SIRA_NO"));
		sMap.put("ANNE_ADI", iMap.getString("ANNE_AD"));
		sMap.put("NUFUS_IL_KOD", iMap.getString("IL_KODU"));
		sMap.put("NUFUS_ILCE_KOD", iMap.getString("ILCE_KODU"));
		sMap.put("NUFUS_CILT_NO", iMap.getString("CILT_KODU"));
		sMap.put("NUFUS_AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
		sMap.put("NUFUS_SIRA_NO", iMap.getString("BIREY_SIRA_NO"));
		sMap.put("NUFUS_VERILIS_TARIHI", iMap.getString("VERILIS_TARIHI"));
		sMap.put("CINSIYET", iMap.getString("CINSIYET").substring(0,1));
		if("E".equals(iMap.getString("MEDENI_HALI").substring(0, 1))){
			sMap.put("MEDENI_HAL", "1");
		}
		else {sMap.put("MEDENI_HAL", "2");}
		sMap.put("KAYIP_CUZDAN_NO", iMap.getString("KAYIP_CUZDAN_NO"));
		sMap.put("KAYIP_CUZDAN_SERI", iMap.getString("KAYIP_CUZDAN_SERI"));
		sMap.put("KPS_YAPILDI", "E");
		sMap.put("NUF_VERILDIGI_YER", iMap.getString("VERILDIGI_ILCE_ADI"));
		sMap.put("NUF_VERILIS_NEDENI", iMap.getString("VERILIS_NEDENI"));
		sMap.put("APS_YAPILDIMI", iMap.getString("APS_YAPILDIMI"));
		sMap.put("ES_TCKN", iMap.getString("ES_TCKN"));
		sMap.put("NUFUS_MAHALLE", iMap.getString("MAHALLE_KOY"));
		sMap.put("KREDI_KARTI_SEVIYESI", "K");   // default asil kart
		sMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
		
		sMap.put("KREDI_KARTI_EKSTRE_SECIMI", iMap.getString("GONDERIM_ADRESI"));
		sMap.put("KART_LIMITI", iMap.getBigDecimal("KART_LIMITI"));
		sMap.put("ASIL_KART_MUSTERI_NO", iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
		sMap.put("ASIL_KART_NO", iMap.getString("ASIL_KART_NO"));
		sMap.put("IS_FULL_SAVE", "Y");   // insert all records when calling 3871save
		
		GMServiceExecuter.execute("BNSPR_TRN3871_SAVE", sMap);  //  save kimlik info

		// create musteri
		GMMap musteriMap = new GMMap();
		
		musteriMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
		musteriMap.put("ADI", iMap.getString("AD1"));
		musteriMap.put("SOYADI", iMap.getString("SOYAD"));
		musteriMap.put("ANNE_ADI", iMap.getString("ANNE_AD"));
		musteriMap.put("BABA_ADI", iMap.getString("BABA_AD"));
		musteriMap.put("IKINCI_ADI", iMap.getString("AD2"));
		musteriMap.put("CINSIYET", iMap.getString("CINSIYET"));
		musteriMap.put("MEDENI_HAL", iMap.getString("MEDENI_HALI"));
		musteriMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
		musteriMap.put("IL_KODU", iMap.getString("IL_KODU"));
		musteriMap.put("ILCE_KODU", iMap.getString("ILCE_KODU"));
		musteriMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
		musteriMap.put("KIMLIK_SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
		musteriMap.put("NUFUS_VERILIS_TARIHI", iMap.getString("VERILIS_TARIHI"));
		musteriMap.put("NUF_VERILIS_NEDENI", iMap.getString("VERILIS_NEDENI"));
		musteriMap.put("NUF_VERILDIGI_YER", iMap.getString("VERILDIGI_ILCE_ADI"));
		musteriMap.put("NUFUS_CILT_NO", iMap.getString("CILT_KODU"));
		musteriMap.put("NUFUS_AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
		musteriMap.put("NUFUS_SIRA_NO", iMap.getString("BIREY_SIRA_NO"));
		musteriMap.put("NUFUS_MAHALLE", iMap.getString("MAHALLE_KOY"));
		musteriMap.put("KANAL_ALT_KOD", iMap.getString("KANAL_ALT_KOD"));
		musteriMap.put("CEP_TEL_KOD",  iMap.getString("CEP_NO").substring(0, 3));
		musteriMap.put("CEP_TEL_NO", iMap.getString("CEP_NO").substring(3, 10));
		
		iMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_KONTAK_MUSTERI_GERCEK", musteriMap));  // get kimlik sorgu info
		
		iMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", iMap));  // get aps sorgu info
		
		GMServiceExecuter.execute("BNSPR_TRN3871_UPDATE_MUSTERI_NO", iMap);  //  save kimlik info
		GMMap apsMap=new GMMap();
		apsMap.put("TRX_NO", iMap.getString("TRX_NO"));
		apsMap.put("APS_YAPILDIMI", iMap.getString("APS_YAPILDIMI"));
		iMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3870_UPDATE_APS_INFO", apsMap));  // get aps sorgu info
		
		return oMap;
		
	}

	//SMS kanalindan gelen basvurularin 3872 ekranindan ikinci sayfaya yonelirken gerekli bilgileri tablolardan ceker
	// Input BASVURU_NO
	@GraymoundService("BNSPR_TRN3871_GET_OUTBOUND_APPLICATION_INFO")
    public static GMMap getOutBoundApplicationInfo(GMMap iMap) {
		
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();

            KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            oMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
            oMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
            oMap.put("KANAL_KOD", kkBasvuru.getKanalKod());

            KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            oMap.put("ADI", kkBasvuruKimlik.getAd());
            oMap.put("IKINCI_ADI", kkBasvuruKimlik.getIkinciAd());
            oMap.put("SOYADI", kkBasvuruKimlik.getSoyad());
            oMap.put("TC_KIMLIK_NO", kkBasvuruKimlik.getTcKimlikNo());
            oMap.put("NUFUS_VERILIS_TARIHI", kkBasvuruKimlik.getNufusVerTar());
            oMap.put("DOGUM_TARIHI", kkBasvuruKimlik.getDogumTar());
            oMap.put("CINSIYET", kkBasvuruKimlik.getCinsiyet());
            oMap.put("NUFUS_IL_KOD", kkBasvuruKimlik.getNufusIlKod());
            oMap.put("CILT_NO", kkBasvuruKimlik.getCiltNo());
            oMap.put("KPS_YAPILDI", kkBasvuruKimlik.getKpsYapildi());
            oMap.put("APS_YAPILDI", kkBasvuruKimlik.getApsYapildi());
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
	
	@GraymoundService("BNSPR_TRN3871_CHECK_SUCCESSFUL_CAPTCHA_VALIDATION")
	public static GMMap checkCaptchaValidation(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KK_BASVURU_SORGU.CHECK_ESGM_CAPTCHA_VALIDATION(?)}");  // returns Y if there is already a successfull validation
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

				oMap.put("RESULT", stmt.getString(1));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3871_ASYNCRONOUS_ESGM_PARSE_WRAPPER")
	public static GMMap asyncronousCaptchaValidationWrapper(GMMap iMap) {
		//DefaultHttpClient defaultHttpClient = WNSPREsgmSgkServices.getHttpClient();
		iMap.put("COOKIE_STORE", ADCSession.get("COOKIE_STORE"));
		GMServiceExecuter.executeAsync("BNSPR_TRN3871_ASYNCRONOUS_ESGM_PARSE", iMap);
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_TRN3871_ASYNCRONOUS_ESGM_PARSE")
	public static GMMap asyncronousEsgmParse(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
				if ( iMap.get("COOKIE_STORE") != null ){
					ADCSession.put("COOKIE_STORE", iMap.get("COOKIE_STORE"));
				}
				ADCSession.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
				GMMap tMap = new GMMap();
				tMap.put("TCKN", iMap.getString("TCKN"));
				GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_PARSE",tMap);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3871_SOLVE_CAPTCHA")
	public static GMMap asyncronousCaptchaValidation(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
				ADCSession.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				GMMap tMap = new GMMap();

				if (StringUtils.isBlank(iMap.getString("GUVENLIK_KODU"))) {
					ADCSession.put("WRONG_CAPTCHA_TRY_NUMBER", Integer.parseInt(ADCSession.get("WRONG_CAPTCHA_TRY_NUMBER").toString())+1);
					if(Integer.parseInt(ADCSession.get("WRONG_CAPTCHA_TRY_NUMBER").toString()) >= 3){   // PY-4479, 3 ten fazla giremez
						oMap.put("RESPONSE", 3);   // behave as if it is success
						return oMap;
					}
					oMap.put("RESPONSE", 0);
					oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));
					return oMap;
				}
				tMap.put("TCKN", iMap.getString("TCKN"));
				tMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
				tMap.put("IL_KODU", iMap.getString("IL_KODU"));
				tMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(iMap.getDate("DOGUM_YILI")));
				tMap.put("CILT_NO", iMap.getString("CILT_NO"));
				tMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				tMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
				iMap.putAll(GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_SOLVE_CAPTCHA", tMap));
				if (iMap.getString("RESPONSE").equals("0")) {
					ADCSession.put("WRONG_CAPTCHA_TRY_NUMBER", Integer.parseInt(ADCSession.get("WRONG_CAPTCHA_TRY_NUMBER").toString())+1);
					if(Integer.parseInt(ADCSession.get("WRONG_CAPTCHA_TRY_NUMBER").toString()) >= 3){   // PY-4479, 3 ten fazla giremez
						oMap.put("RESPONSE", 3);   // behave as if it is success
						return oMap;
					}
					oMap.put("RESPONSE", 0);
					oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));
					return oMap;
				}
				oMap.put("RESPONSE", 2);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	
	@GraymoundService("BNSPR_TRN3871_GET_BASVURU_BY_BASVURU_NO")
    public static GMMap getBasvuruBilgileriByMusteriNo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();

            KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            oMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
            oMap.put("KART_SEVIYESI", kkBasvuru.getKartSeviyesi());
            oMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
            oMap.put("ASIL_KART_NO", kkBasvuru.getAsilKartNo());
            oMap.put("BASVURU_TARIHI", kkBasvuru.getBasvuruTarihi());
            oMap.put("DURUM_KOD", kkBasvuru.getDurumKod());
            oMap.put("ASIL_KART_MUSTERI_NO", kkBasvuru.getAsilKartMusteriNo());
            oMap.put("KANAL_KOD", kkBasvuru.getKanalKod());
            if(kkBasvuru.getAsilKartMusteriNo() != null){
	            KkBasvuru kkBasvuruAsilKart = (KkBasvuru) session.createCriteria(KkBasvuru.class)
	            		.add(Restrictions.eq("musteriNo", kkBasvuru.getAsilKartMusteriNo()))
	            		.add(Restrictions.or(Restrictions.isNull("kartTipi"), Restrictions.eq("kartTipi", "KK")))
	            		.uniqueResult();
	            if(kkBasvuruAsilKart != null){
	            	 KkBasvuruKimlik kkBasvuruKimlikAsilKart = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", kkBasvuruAsilKart.getBasvuruNo())).uniqueResult();
	                 if(kkBasvuruKimlikAsilKart != null){
	     	            oMap.put("ASIL_KART_MUSTERI_ADI", kkBasvuruKimlikAsilKart.getAd() + " " +
	     	            		 (kkBasvuruKimlikAsilKart.getIkinciAd() == null ? "" : kkBasvuruKimlikAsilKart.getIkinciAd()+ " " )+ kkBasvuruKimlikAsilKart.getSoyad());
	                 }
	            }
            }
            KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            oMap.put("ADI", kkBasvuruKimlik.getAd());
                       //			oMap.put("BABA_ADI", birBasvuruKimlikTx.getBabaAd());
            //			oMap.put("CINSIYET", birBasvuruKimlikTx.getCinsiyet());
            //			oMap.put("DOGUM_TARIHI", birBasvuruKimlikTx.getDogumTar());
            //			oMap.put("DOGUM_YERI", birBasvuruKimlikTx.getDogumYeri());
            oMap.put("IKINCI_ADI", kkBasvuruKimlik.getIkinciAd());
            //			oMap.put("MEDENI_HAL", birBasvuruKimlikTx.getMedeniHal());
            oMap.put("SOYADI", kkBasvuruKimlik.getSoyad());
            oMap.put("TC_KIMLIK_NO", kkBasvuruKimlik.getTcKimlikNo());
            oMap.put("ES_TCKN", kkBasvuruKimlik.getEsTcKimlikNo());
            oMap.put("DOGUM_TARIHI", kkBasvuruKimlik.getDogumTar());
            oMap.put("CINSIYET", kkBasvuruKimlik.getCinsiyet());
            //			oMap.put("UYRUK", birBasvuruKimlikTx.getUyrukKod());
            
            KkBasvuruTelefon kkBasvuruTelefon = (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).
            		add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).
            		add(Restrictions.eq("id.tip", "3")).uniqueResult();
            
            oMap.put("CEP_TEL_ALAN_KOD", kkBasvuruTelefon.getAlanKod());
            oMap.put("CEP_TEL_NUMARA", kkBasvuruTelefon.getNumara());
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_BASVURU_DETAY_BY_BASVURU_NO")
    public static GMMap getBasvuruDetayBilgileriByMusteriNo(GMMap iMap) {
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();

            KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            if(kkBasvuru != null) {
	            oMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
	            oMap.put("KARTIN_UZERINE_YAZILACAK_ISIM", kkBasvuru.getKartinUzerineYazilacakIsim());
	            oMap.put("KART_LIMITI", kkBasvuru.getKartLimiti());
	            oMap.put("NAKIT_KART_LIMITI", kkBasvuru.getNakitKartLimiti());
	            oMap.put("EKSPRESS_KART_LIMITI", kkBasvuru.getEkspressKartLimiti());
	            oMap.put("EKSTRE_TIPI_POSTA", kkBasvuru.getEkstreTipiPosta());
	            oMap.put("EKSTRE_TIPI_EMAIL", kkBasvuru.getEkstreTipiEmail());
	            oMap.put("EKSTRE_TIPI_SMS", kkBasvuru.getEkstreTipiSms());
	            oMap.put("URUN_TIPI", kkBasvuru.getUrunTipi());
	            oMap.put("EKSTRE_SECIMI", kkBasvuru.getEkstreSecimi());
	            oMap.put("HESAP_KESIM_TARIHI", kkBasvuru.getHesapKesimTarihi());
	            oMap.put("OTOMATIK_ODEME_TALIMATI", kkBasvuru.getOtomatikOdemeTalimati());
	            oMap.put("YURTDISI_HARCAMA_EKSTRESI", kkBasvuru.getYurtdisiHarcamaEkstresi());
	            oMap.put("EK_KART_VAR_MI", kkBasvuru.getEkKartVarMi());
	            oMap.put("MUSTERI_GRUP", kkBasvuru.getMusteriGrup());
	            oMap.put("MUSTERI_TIPI", kkBasvuru.getMusteriTip());
	            oMap.put("FINANSAL_TIP", kkBasvuru.getFinansalTip());
	            oMap.put("LOGO_KODU", kkBasvuru.getLogoKod());
	            oMap.put("OTOMATIK_LIMIT_ARTIS", kkBasvuru.getOtomatikLimitArtis());
	            oMap.put("KDH_ISTIYOR_MU", kkBasvuru.getKdhIstiyorMu());
	            oMap.put("EMAIL", kkBasvuru.getEPosta());
            }
            
            KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            if(kkBasvuruKimlik != null){
            oMap.put("ANNE_KIZLIK", kkBasvuruKimlik.getAnneKizlik());
            oMap.put("KIMLIK_SERI_NO", kkBasvuruKimlik.getKimlikSeriNo());
            oMap.put("KIMLIK_SIRA_NO", kkBasvuruKimlik.getKimlikSiraNo());
            oMap.put("CILT_NO", kkBasvuruKimlik.getCiltNo());
            oMap.put("APS_TEYIT", kkBasvuruKimlik.getApsBilgileriUyumlumu());
            }
            KkBasvuruMeslekiBilgi kkBasvuruMeslekiBilgi = (KkBasvuruMeslekiBilgi) session.createCriteria(KkBasvuruMeslekiBilgi.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
            if(kkBasvuruMeslekiBilgi != null){
            oMap.put("OGRENIM_DURUMU", kkBasvuruMeslekiBilgi.getOgrenimDurumKod());
            oMap.put("MESLEK_KOD", kkBasvuruMeslekiBilgi.getMeslekKod());
            oMap.put("UNVAN", kkBasvuruMeslekiBilgi.getUnvanKod());
            oMap.put("CALISMA_SEKLI", kkBasvuruMeslekiBilgi.getCalismaSekliKod());
            
            if (kkBasvuruMeslekiBilgi.getCalismaSuresi() != null) {
                String calismaSuresiYil = kkBasvuruMeslekiBilgi.getCalismaSuresi().substring(0, 2);
                if (calismaSuresiYil.charAt(0) == '0') calismaSuresiYil = calismaSuresiYil.substring(1);
                String calismaSuresiAy = kkBasvuruMeslekiBilgi.getCalismaSuresi().substring(2, 4);
                if (calismaSuresiAy.charAt(0) == '0') calismaSuresiAy = calismaSuresiAy.substring(1);
                oMap.put("CALISMA_SURESI_YIL", calismaSuresiYil);
                oMap.put("CALISMA_SURESI_AY", calismaSuresiAy);
            } else {
                oMap.put("CALISMA_SURESI_YIL", "00");
                oMap.put("CALISMA_SURESI_AY", "00");
            }
            
            oMap.put("FAALIYET_ALANI", kkBasvuruMeslekiBilgi.getFaaliyetAlaniKod());
            oMap.put("ISYERI_ADI", kkBasvuruMeslekiBilgi.getIsyeriAdi());
            oMap.put("VERGI_DAIRE_IL", kkBasvuruMeslekiBilgi.getVergiDaireIl());
            oMap.put("VERGI_DAIRE_AD", kkBasvuruMeslekiBilgi.getVergiDaireAd());
            oMap.put("AYLIK_GELIR", kkBasvuruMeslekiBilgi.getAylikGelir());
            oMap.put("MENKUL_GELIR", kkBasvuruMeslekiBilgi.getMenkulGmenkulGeliri());
            oMap.put("ES_GELIR", kkBasvuruMeslekiBilgi.getEsGeliri());
            oMap.put("DIGER_GELIR", kkBasvuruMeslekiBilgi.getDigerGelir());
            oMap.put("IKAMET_DURUMU", kkBasvuruMeslekiBilgi.getIkametDurumKod());

            if (kkBasvuruMeslekiBilgi.getEvdeOturmaSuresi()!= null) {
                String evdeOturmaSuresiYil = kkBasvuruMeslekiBilgi.getEvdeOturmaSuresi().substring(0, 2);
                if (evdeOturmaSuresiYil.charAt(0) == '0') evdeOturmaSuresiYil = evdeOturmaSuresiYil.substring(1);
                String evdeOturmaSuresiAy = kkBasvuruMeslekiBilgi.getEvdeOturmaSuresi().substring(2, 4);
                if (evdeOturmaSuresiAy.charAt(0) == '0') evdeOturmaSuresiAy = evdeOturmaSuresiAy.substring(1);
                oMap.put("EVDE_OTURMA_SURESI_YIL", evdeOturmaSuresiYil);
                oMap.put("EVDE_OTURMA_SURESI_AY", evdeOturmaSuresiAy);
            } else {
                oMap.put("EVDE_OTURMA_SURESI_YIL", "00");
                oMap.put("EVDE_OTURMA_SURESI_AY", "00");
            }
            }
            // Get ev adresi
            KkBasvuruAdres kkBasvuruAdres = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).
            		add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.adresKod", "E")).
            		uniqueResult();
            if (kkBasvuruAdres != null){
	            oMap.put("EV_IL_KOD", kkBasvuruAdres.getIlKod());
	            oMap.put("EV_ILCE_KOD", kkBasvuruAdres.getIlceKod());
	            oMap.put("EV_ADRES", kkBasvuruAdres.getAdres());
	            oMap.put("EV_POSTA_KOD", kkBasvuruAdres.getPostaKod());
	            oMap.put("TESLIMAT_ADRESI_EV", BooleanUtils.toBoolean(
	            		CreditCardServicesUtil.nvl(kkBasvuruAdres.getTeslimatAdresiMi(),CreditCardServicesUtil.HAYIR),
	            		CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
            }  else {
            	 oMap.put("TESLIMAT_ADRESI_EV", false);
            }
            // Get is adresi
            KkBasvuruAdres kkBasvuruAdresIs = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).
            		add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.adresKod", "I")).
            		uniqueResult();
            if(kkBasvuruAdresIs != null){
	            oMap.put("IS_IL_KOD", kkBasvuruAdresIs.getIlKod());
	            oMap.put("IS_ILCE_KOD", kkBasvuruAdresIs.getIlceKod());
	            oMap.put("IS_ADRES", kkBasvuruAdresIs.getAdres());
	            oMap.put("IS_POSTA_KOD", kkBasvuruAdresIs.getPostaKod());
	            oMap.put("IS_YERI_ADI", kkBasvuruAdresIs.getIsyeriAdi());
	            oMap.put("TESLIMAT_ADRESI_IS", BooleanUtils.toBoolean(
	            		CreditCardServicesUtil.nvl(kkBasvuruAdresIs.getTeslimatAdresiMi(),CreditCardServicesUtil.HAYIR),
	            		CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
            } else {
            	oMap.put("TESLIMAT_ADRESI_IS", false);
           }
            // get ev telefon
            KkBasvuruTelefon kkBasvuruTelefonEv = (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).
            		add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.tip", "1")).
            		uniqueResult();
            if(kkBasvuruTelefonEv != null){
	            oMap.put("EV_TEL_ALAN_KOD", kkBasvuruTelefonEv.getAlanKod());
	            oMap.put("EV_TEL_NUMARA", kkBasvuruTelefonEv.getNumara());
            }
            // get is telefon
            KkBasvuruTelefon kkBasvuruTelefonIs = (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).
            		add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.tip", "2")).
            		uniqueResult();
            if(kkBasvuruTelefonIs != null){
	            oMap.put("IS_TEL_ALAN_KOD", kkBasvuruTelefonIs.getAlanKod());
	            oMap.put("IS_TEL_NUMARA", kkBasvuruTelefonIs.getNumara());
            }
            // get cep telefon
            KkBasvuruTelefon kkBasvuruTelefonCep = (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).
            		add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.tip", "3")).
            		uniqueResult();
            if(kkBasvuruTelefonCep != null){
	            oMap.put("CEP_TEL_ALAN_KOD", kkBasvuruTelefonCep.getAlanKod());
	            oMap.put("CEP_TEL_NUMARA", kkBasvuruTelefonCep.getNumara());
            }
           
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
	
    @GraymoundService("BNSPR_TRN3871_GET_BASVURU_NO")
    public static GMMap getBasvuruNo(GMMap iMap) {
        GMMap oMap = new GMMap();
       oMap.put("ID", new BigDecimal(DALUtil.getResult("select seq_bir_basvuru.nextval from dual")));
        //oMap.put("ID", "123456");
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_CINSIYET_TURLERI")
    public static GMMap getCinsiyetTurleri(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "CINSIYET_LIST", false, "select kod, aciklama from v_ml_gnl_cinsiyet_kod_pr order by 1");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_MEDENI_HAL_TURLERI")
    public static GMMap getMedeniHalTurleri(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "MEDENI_HAL_LIST", false, "select kod, aciklama from v_ml_gnl_medeni_hal_kod_pr order by 1");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_APS_INFO_BY_MUSTERI_NO")
    public static GMMap getApsBilgileri(GMMap iMap) {
    	GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TRN3871.get_aps_bilgileri(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_BASVURU")
    public static GMMap getBasvuruBilgileri(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();

            KkBasvuruTx kkBasvuruTx = (KkBasvuruTx) session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            oMap.put("BASVURU_NO", kkBasvuruTx.getBasvuruNo());
            oMap.put("KART_SEVIYESI", kkBasvuruTx.getKartSeviyesi());
            oMap.put("MUSTERI_NO", kkBasvuruTx.getMusteriNo());
            oMap.put("ASIL_KART_NO", kkBasvuruTx.getAsilKartNo());
            oMap.put("BASVURU_TARIHI", kkBasvuruTx.getBasvuruTarihi());
            oMap.put("DURUM_KOD", kkBasvuruTx.getDurumKod());
            oMap.put("ASIL_KART_MUSTERI_NO", kkBasvuruTx.getAsilKartMusteriNo());
            if(kkBasvuruTx.getAsilKartMusteriNo() != null){
	            KkBasvuruTx kkBasvuruTxAsilKart = (KkBasvuruTx) session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("musteriNo", kkBasvuruTx.getAsilKartMusteriNo())).uniqueResult();
	            if(kkBasvuruTxAsilKart != null){
		            KkBasvuruKimlikTx kkBasvuruKimlikTxAsilKart = (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", kkBasvuruTxAsilKart.getTxNo())).uniqueResult();
		            if(kkBasvuruKimlikTxAsilKart != null){
			            oMap.put("ASIL_KART_MUSTERI_ADI", kkBasvuruKimlikTxAsilKart.getAd() + " " +
			            		 (kkBasvuruKimlikTxAsilKart.getIkinciAd() == null ? "" : kkBasvuruKimlikTxAsilKart.getIkinciAd()+ " " )+ kkBasvuruKimlikTxAsilKart.getSoyad());
		            }
	            }
            }
            KkBasvuruKimlikTx kkBasvuruKimlikTx = (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            oMap.put("ADI", kkBasvuruKimlikTx.getAd());
                       //			oMap.put("BABA_ADI", birBasvuruKimlikTx.getBabaAd());
            //			oMap.put("CINSIYET", birBasvuruKimlikTx.getCinsiyet());
            //			oMap.put("DOGUM_TARIHI", birBasvuruKimlikTx.getDogumTar());
            //			oMap.put("DOGUM_YERI", birBasvuruKimlikTx.getDogumYeri());
            oMap.put("IKINCI_ADI", kkBasvuruKimlikTx.getIkinciAd());
            //			oMap.put("MEDENI_HAL", birBasvuruKimlikTx.getMedeniHal());
            oMap.put("SOYADI", kkBasvuruKimlikTx.getSoyad());
            oMap.put("TC_KIMLIK_NO", kkBasvuruKimlikTx.getTcKimlikNo());
            oMap.put("ES_TCKN", kkBasvuruKimlikTx.getEsTcKimlikNo());
            oMap.put("DOGUM_TARIHI", kkBasvuruKimlikTx.getDogumTar());
            oMap.put("CINSIYET", kkBasvuruKimlikTx.getCinsiyet());
            //			oMap.put("UYRUK", birBasvuruKimlikTx.getUyrukKod());
            
            KkBasvuruTelefonTx kkBasvuruTelefonTx = (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
            		add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
            		add(Restrictions.eq("id.tip", "3")).uniqueResult();
            
            oMap.put("CEP_TEL_ALAN_KOD", kkBasvuruTelefonTx.getAlanKod());
            oMap.put("CEP_TEL_NUMARA", kkBasvuruTelefonTx.getNumara());
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_BASVURU_DETAY")
    public static GMMap getBasvuruDetayBilgileri(GMMap iMap) {
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();

            KkBasvuruTx kkBasvuruTx = (KkBasvuruTx) session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            
            if(kkBasvuruTx != null){
            	   oMap.put("BASVURU_NO", kkBasvuruTx.getBasvuruNo());
                   oMap.put("KARTIN_UZERINE_YAZILACAK_ISIM", kkBasvuruTx.getKartinUzerineYazilacakIsim());
                   oMap.put("KART_LIMITI", kkBasvuruTx.getKartLimiti());
                   oMap.put("NAKIT_KART_LIMITI", kkBasvuruTx.getNakitKartLimiti());
                   oMap.put("EKSPRESS_KART_LIMITI", kkBasvuruTx.getEkspressKartLimiti());
                   oMap.put("EKSTRE_TIPI_POSTA", kkBasvuruTx.getEkstreTipiPosta());
                   oMap.put("EKSTRE_TIPI_EMAIL", kkBasvuruTx.getEkstreTipiEmail());
                   oMap.put("EKSTRE_TIPI_SMS", kkBasvuruTx.getEkstreTipiSms());
                   oMap.put("URUN_TIPI", kkBasvuruTx.getUrunTipi());
                   oMap.put("EKSTRE_SECIMI", kkBasvuruTx.getEkstreSecimi());
                   oMap.put("HESAP_KESIM_TARIHI", kkBasvuruTx.getHesapKesimTarihi());
                   oMap.put("OTOMATIK_ODEME_TALIMATI", kkBasvuruTx.getOtomatikOdemeTalimati());
                   oMap.put("YURTDISI_HARCAMA_EKSTRESI", kkBasvuruTx.getYurtdisiHarcamaEkstresi());
                   oMap.put("EK_KART_VAR_MI", kkBasvuruTx.getEkKartVarMi());
                   oMap.put("MUSTERI_GRUP", kkBasvuruTx.getMusteriGrup());
                   oMap.put("MUSTERI_TIPI", kkBasvuruTx.getMusteriTip());
                   oMap.put("FINANSAL_TIP", kkBasvuruTx.getFinansalTip());
                   oMap.put("LOGO_KODU", kkBasvuruTx.getLogoKod());
                   oMap.put("OTOMATIK_LIMIT_ARTIS", kkBasvuruTx.getOtomatikLimitArtis());
                   oMap.put("KDH_ISTIYOR_MU", kkBasvuruTx.getKdhIstiyorMu());
                   oMap.put("EMAIL", kkBasvuruTx.getEPosta());
            }

            KkBasvuruKimlikTx kkBasvuruKimlikTx = (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            if(kkBasvuruKimlikTx != null){
	            oMap.put("ANNE_KIZLIK", kkBasvuruKimlikTx.getAnneKizlik());
	            oMap.put("KIMLIK_SERI_NO", kkBasvuruKimlikTx.getKimlikSeriNo());
	            oMap.put("KIMLIK_SIRA_NO", kkBasvuruKimlikTx.getKimlikSiraNo());
	            oMap.put("APS_TEYIT", kkBasvuruKimlikTx.getApsBilgileriUyumlumu());
            }
            KkBasvuruMeslekiBilgiTx kkBasvuruMeslekiBilgiTx = (KkBasvuruMeslekiBilgiTx) session.createCriteria(KkBasvuruMeslekiBilgiTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            if(kkBasvuruMeslekiBilgiTx != null){
            oMap.put("OGRENIM_DURUMU", kkBasvuruMeslekiBilgiTx.getOgrenimDurumKod());
            oMap.put("MESLEK_KOD", kkBasvuruMeslekiBilgiTx.getMeslekKod());
            oMap.put("UNVAN", kkBasvuruMeslekiBilgiTx.getUnvanKod());
            oMap.put("CALISMA_SEKLI", kkBasvuruMeslekiBilgiTx.getCalismaSekliKod());
            
            if (kkBasvuruMeslekiBilgiTx.getCalismaSuresi() != null) {
                String calismaSuresiYil = kkBasvuruMeslekiBilgiTx.getCalismaSuresi().substring(0, 2);
                if (calismaSuresiYil.charAt(0) == '0') calismaSuresiYil = calismaSuresiYil.substring(1);
                String calismaSuresiAy = kkBasvuruMeslekiBilgiTx.getCalismaSuresi().substring(2, 4);
                if (calismaSuresiAy.charAt(0) == '0') calismaSuresiAy = calismaSuresiAy.substring(1);
                oMap.put("CALISMA_SURESI_YIL", calismaSuresiYil);
                oMap.put("CALISMA_SURESI_AY", calismaSuresiAy);
            } else {
                oMap.put("CALISMA_SURESI_YIL", "00");
                oMap.put("CALISMA_SURESI_AY", "00");
            }
            
            oMap.put("FAALIYET_ALANI", kkBasvuruMeslekiBilgiTx.getFaaliyetAlaniKod());
            oMap.put("ISYERI_ADI", kkBasvuruMeslekiBilgiTx.getIsyeriAdi());
            oMap.put("VERGI_DAIRE_IL", kkBasvuruMeslekiBilgiTx.getVergiDaireIl());
            oMap.put("VERGI_DAIRE_AD", kkBasvuruMeslekiBilgiTx.getVergiDaireAd());
            oMap.put("AYLIK_GELIR", kkBasvuruMeslekiBilgiTx.getAylikGelir());
            oMap.put("MENKUL_GELIR", kkBasvuruMeslekiBilgiTx.getMenkulGmenkulGeliri());
            oMap.put("ES_GELIR", kkBasvuruMeslekiBilgiTx.getEsGeliri());
            oMap.put("DIGER_GELIR", kkBasvuruMeslekiBilgiTx.getDigerGelir());
            oMap.put("IKAMET_DURUMU", kkBasvuruMeslekiBilgiTx.getIkametDurumKod());

            if (kkBasvuruMeslekiBilgiTx.getEvdeOturmaSuresi()!= null) {
                String evdeOturmaSuresiYil = kkBasvuruMeslekiBilgiTx.getEvdeOturmaSuresi().substring(0, 2);
                if (evdeOturmaSuresiYil.charAt(0) == '0') evdeOturmaSuresiYil = evdeOturmaSuresiYil.substring(1);
                String evdeOturmaSuresiAy = kkBasvuruMeslekiBilgiTx.getEvdeOturmaSuresi().substring(2, 4);
                if (evdeOturmaSuresiAy.charAt(0) == '0') evdeOturmaSuresiAy = evdeOturmaSuresiAy.substring(1);
                oMap.put("EVDE_OTURMA_SURESI_YIL", evdeOturmaSuresiYil);
                oMap.put("EVDE_OTURMA_SURESI_AY", evdeOturmaSuresiAy);
            } else {
                oMap.put("EVDE_OTURMA_SURESI_YIL", "00");
                oMap.put("EVDE_OTURMA_SURESI_AY", "00");
            }
            
            }
            // Get ev adresi
            KkBasvuruAdresTx kkBasvuruAdresTx = (KkBasvuruAdresTx) session.createCriteria(KkBasvuruAdresTx.class).
            		add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.adresKod", "E")).
            		uniqueResult();
            if (kkBasvuruAdresTx != null){
	            oMap.put("EV_IL_KOD", kkBasvuruAdresTx.getIlKod());
	            oMap.put("EV_ILCE_KOD", kkBasvuruAdresTx.getIlceKod());
	            oMap.put("EV_ADRES", kkBasvuruAdresTx.getAdres());
	            oMap.put("EV_POSTA_KOD", kkBasvuruAdresTx.getPostaKod());
	            oMap.put("TESLIMAT_ADRESI_EV", BooleanUtils.toBoolean(
	            		CreditCardServicesUtil.nvl(kkBasvuruAdresTx.getTeslimatAdresiMi(),CreditCardServicesUtil.HAYIR),
	            		CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
            } else {
            	 oMap.put("TESLIMAT_ADRESI_EV", false);
            }
            // Get is adresi
            KkBasvuruAdresTx kkBasvuruAdresTxIs = (KkBasvuruAdresTx) session.createCriteria(KkBasvuruAdresTx.class).
            		add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.adresKod", "I")).
            		uniqueResult();
            if(kkBasvuruAdresTxIs != null){
	            oMap.put("IS_IL_KOD", kkBasvuruAdresTxIs.getIlKod());
	            oMap.put("IS_ILCE_KOD", kkBasvuruAdresTxIs.getIlceKod());
	            oMap.put("IS_ADRES", kkBasvuruAdresTxIs.getAdres());
	            oMap.put("IS_POSTA_KOD", kkBasvuruAdresTxIs.getPostaKod());
	            oMap.put("IS_YERI_ADI", kkBasvuruAdresTxIs.getIsyeriAdi());
	            oMap.put("TESLIMAT_ADRESI_IS", BooleanUtils.toBoolean(
	            		CreditCardServicesUtil.nvl(kkBasvuruAdresTxIs.getTeslimatAdresiMi(),CreditCardServicesUtil.HAYIR),
	            		CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
            } else {
            	oMap.put("TESLIMAT_ADRESI_IS", false);
            }
            // get ev telefon
            KkBasvuruTelefonTx kkBasvuruTelefonTxEv = (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
            		add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.tip", "1")).
            		uniqueResult();
            if(kkBasvuruTelefonTxEv != null){
	            oMap.put("EV_TEL_ALAN_KOD", kkBasvuruTelefonTxEv.getAlanKod());
	            oMap.put("EV_TEL_NUMARA", kkBasvuruTelefonTxEv.getNumara());
            }
            // get is telefon
            KkBasvuruTelefonTx kkBasvuruTelefonTxIs = (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
            		add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.tip", "2")).
            		uniqueResult();
            if(kkBasvuruTelefonTxIs != null){
	            oMap.put("IS_TEL_ALAN_KOD", kkBasvuruTelefonTxIs.getAlanKod());
	            oMap.put("IS_TEL_NUMARA", kkBasvuruTelefonTxIs.getNumara());
            }
            // get cep telefon
            KkBasvuruTelefonTx kkBasvuruTelefonTxCep = (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
            		add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.tip", "3")).
            		uniqueResult();
            if(kkBasvuruTelefonTxCep != null){
	            oMap.put("CEP_TEL_ALAN_KOD", kkBasvuruTelefonTxCep.getAlanKod());
	            oMap.put("CEP_TEL_NUMARA", kkBasvuruTelefonTxCep.getNumara());
            }
           
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
	@GraymoundService("BNSPR_TRN3871_KPS_KIMLIK_SORGULAMA")
	public static GMMap getKimlikBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();
			sMap.put("TCKN", iMap.getString("TCKNO"));
			String tcKimlikNo = iMap.getString("TCKNO");
			try {				
				if (isLocal) {
					sMap = new GMMap(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_KPS_GET_KISI_BILGILERI", sMap));
				} else {
					sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_BILGILERI", sMap);
				}
			} catch (Exception e) {
				oMap.put("KPS_YOK_MU","E");
				return oMap;
			}

			if (sMap.getInt("HATA_KOD") == 0) {
				BilesikKutukModel kisiBilgisi = (BilesikKutukModel)sMap.get("KISI_BILGISI");
				
				if (kisiBilgisi != null) {

					TCKisiBilgisiModel tcKisiBilgisiModel = kisiBilgisi.getTcKisiBilgisiModel();
					
					if (!StringUtil.isEmpty(tcKisiBilgisiModel.getDogumTarih().toString())) {
						Calendar dogumTarihi = Calendar.getInstance();
						dogumTarihi.set(tcKisiBilgisiModel.getDogumTarih().getYil(),
								tcKisiBilgisiModel.getDogumTarih().getAy() - 1,
								tcKisiBilgisiModel.getDogumTarih().getGun());
						oMap.put("DOGUM_TARIHI", dogumTarihi.getTime());
					}
			
					oMap.put("TCKNO_OUT", tcKisiBilgisiModel.getTcKimlikNo());
					oMap.put("AD", tcKisiBilgisiModel.getAd());
					oMap.put("SOYAD", tcKisiBilgisiModel.getSoyad());
					oMap.put("CINSIYET", KPSUtil
							.getParametreAciklama(tcKisiBilgisiModel.getCinsiyet()));
					oMap.put("CINSIYET_KOD", KPSUtil
                        .getParametreKod(tcKisiBilgisiModel.getCinsiyet()));
					oMap.put("BABA_AD", tcKisiBilgisiModel.getBabaAd());
					oMap.put("ANNE_AD", tcKisiBilgisiModel.getAnneAd());
					oMap.put("KIZLIK_SOYAD", "");
					oMap.put("DOGUM_YERI", tcKisiBilgisiModel.getDogumYer());
					oMap.put("DURUMU",
							KPSUtil.getParametreKod(tcKisiBilgisiModel.getDurum())); // DURUMU_KOD
					oMap.put("DURUMU_ACIKLAMA",
                        KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getDurum()));
					oMap.put("MEDENI_HALI", KPSUtil
							.getParametreAciklama(tcKisiBilgisiModel.getMedeniHal()));
					oMap.put("MEDENI_HALI_KOD", KPSUtil
                        .getParametreKod(tcKisiBilgisiModel.getMedeniHal()));
					oMap.put("ES_TCKN", tcKisiBilgisiModel.getEsTCKimlikNo());
					oMap.put("DIN", tcKisiBilgisiModel.getDin());

					String ad = tcKisiBilgisiModel.getAd();
					String ad1;
					String ad2;
					if (ad.indexOf(" ") >= 0) {
						ad1 = ad.substring(0, ad.indexOf(" "));
						ad2 = ad.substring(ad.indexOf(" ")).trim();
					} else {
						ad1 = ad;
						ad2 = null;
					}
					oMap.put("AD1", ad1);
					oMap.put("AD2", ad2);

					String ilKodu = String.valueOf(tcKisiBilgisiModel.getIl()
							.getKod());
					if (ilKodu.length() == 2)
						ilKodu = "0" + ilKodu;
					if (ilKodu.length() == 1)
						ilKodu = "00" + ilKodu;
					oMap.put("IL_KODU", ilKodu);
					oMap.put("IL", String.valueOf(tcKisiBilgisiModel.getIl().getAciklama()));
					
					oMap.put("ILCE_KODU", String.valueOf(tcKisiBilgisiModel.getIlce().getKod()));
					oMap.put("ILCE", String.valueOf(tcKisiBilgisiModel.getIlce().getAciklama()));
					
					//oMap.put("DOGUM_ILCE_KODU", kisiBilgisi.getDogumYerKod());
					
					
					oMap.put("MAHALLE_KOY",
							tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel
									.getCilt().getAciklama() : "");
					oMap.put("CILT_KODU",
							tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel
									.getCilt().getKod() : "");
					oMap.put("CILT",
							tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel
                                .getCilt().getAciklama() : "");
					oMap.put("AILE_SIRA_NO", tcKisiBilgisiModel.getAileSiraNo());
					oMap.put("BIREY_SIRA_NO", tcKisiBilgisiModel.getBireySiraNo());

					if (!StringUtil.isEmpty(tcKisiBilgisiModel.getOlumTarih()
							.toString())) {
						Calendar olumTarihi = Calendar.getInstance();
						olumTarihi.set(tcKisiBilgisiModel.getOlumTarih().getYil(),
								tcKisiBilgisiModel.getOlumTarih().getAy() - 1,
								tcKisiBilgisiModel.getOlumTarih().getGun());

						oMap.put("OLUM_TARIHI", olumTarihi.getTime());
					}

				
					else {
						TCCuzdanBilgisiModel cuzdan = kisiBilgisi.getTcCuzdanBilgisiModel();
						TCKKModel tckk = kisiBilgisi.getTckkModel();
						
						if(cuzdan!=null && cuzdan.getSeri()!=null && !cuzdan.getSeri().isEmpty()){
							String seriNo=cuzdan.getSeriNo();
							oMap.put("TCKK", false);
							oMap.put("TC_KIMLIK_NO", cuzdan.getTcKimlikNo());
							if(seriNo != null)
							{
							oMap.put("NUFUS_CUZDANI_SERI_NO", seriNo);
							oMap.put("KIMLIK_SERI_NO", seriNo.substring(0, 3));	
							oMap.put("KIMLIK_SIRA_NO", seriNo.substring(3, seriNo.length()));	
							
							}
							if(cuzdan.getVerilmeTarih() != null && cuzdan.getVerilmeTarih().getYil() != null){
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(cuzdan.getVerilmeTarih().getYil(), cuzdan.getVerilmeTarih().getAy() - 1, cuzdan.getVerilmeTarih().getGun());
								oMap.put("VERILIS_TARIHI", verilisTarihi.getTime());
							}
		                	else
		                	{
		                		oMap.put("VERILIS_TARIHI", "");
		                	}
						
							oMap.put("OLUM_TARIHI", "");
							oMap.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(cuzdan.getCuzdanVerilmeNeden()));
							oMap.put("VERILIS_NEDENI", KPSUtil.getParametreAciklama(cuzdan.getCuzdanVerilmeNeden()));
							oMap.put("VERILIS_NEDENI_KOD", KPSUtil.getParametreKod(cuzdan.getCuzdanVerilmeNeden()));
							oMap.put("KIMLIK_KAYIT_NO", cuzdan.getCuzdanKayitNo());
							oMap.put("VERILDIGI_ILCE_KODU", KPSUtil.getParametreKod(cuzdan.getVerildigiIlce()));
							oMap.put("VERILDIGI_YER", KPSUtil.getParametreAciklama(cuzdan.getVerildigiIlce()));
							oMap.put("VERILDIGI_ILCE_ADI", KPSUtil.getParametreAciklama(cuzdan.getVerildigiIlce()));
					
						}
						else if(tckk!=null && tckk.getSeriNo()!=null && !tckk.getSeriNo().isEmpty()){
						
							String seriNo=tckk.getSeriNo();
							oMap.put("TCKK", true);
							oMap.put("TC_KIMLIK_NO", tckk.getTcKimlikNo());
							if(seriNo != null)
							{
							oMap.put("NUFUS_CUZDANI_SERI_NO", seriNo);
							oMap.put("KIMLIK_SERI_NO", seriNo.substring(0, 3));	
							oMap.put("KIMLIK_SIRA_NO", seriNo.substring(3, seriNo.length()));	
							
							}
							if(tckk.getTeslimTarih()!= null && tckk.getTeslimTarih().getYil() != null){
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(tckk.getTeslimTarih().getYil(), tckk.getTeslimTarih().getAy() - 1, tckk.getTeslimTarih().getGun());
								oMap.put("VERILIS_TARIHI", verilisTarihi.getTime());
							}
		                	else
		                	{
		                		oMap.put("VERILIS_TARIHI", "");
		                	}
							
							oMap.put("OLUM_TARIHI", "");
							oMap.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(tckk.getBasvuruNeden()));
							oMap.put("KIMLIK_KAYIT_NO", tckk.getKayitNo());
							oMap.put("TCKK_TESLIM_EDEN_BIRIM", KPSUtil.getParametreAciklama(tckk.getTeslimEdenBirim()));
							oMap.put("TCKK_VEREN_MAKAM", tckk.getVerenMakam());
						}		
					}

					ADCSession.put("KPS_MAP", oMap);
				} else {
					ADCSession.remove("KPS_MAP");
				}
				/*
				 * } else { logger.warn(sMap.getInt("HATA_KOD"));
				 * logger.warn(sMap.getString("HATA"));
				 * 
				 * oMap.put("HATA", sMap.getString("HATA"));
				 * oMap.put("HATA_KOD", sMap.getInt("HATA_KOD"));
				 * 
				 * //throw new GMRuntimeException(1, sMap.getString("HATA"));
				 * ADCSession.remove("KPS_MAP"); }
				 */
			} else if (oMap.getInt("HATA_KOD") == 1
					&& "Ki�i Bulunamad�.".equals(oMap.getString("HATA"))
					|| oMap.getInt("HATA_KOD") == 2
					&& "Arad���n�z kriterlere uygun kay�t bulunamad�."
							.equals(oMap.getString("HATA"))) {

				iMap.put("HATA_NO", "456");
				iMap.put("P1", tcKimlikNo);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

			} else {
				oMap.put("TCKNO", tcKimlikNo);
				oMap.put("KPS_LOG", "KAPALI");
			}

		}
		// catch(IntegrationException e){
		// // throw ExceptionHandler.convertException(e);
		// }
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

    @GraymoundService("BNSPR_TRN3871_GET_OGRENIM_DURUMLARI")
    public static GMMap getOgrenimDurumlari(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "OGRENIM_LIST", true, "select kod, aciklama from v_ml_gnl_egitim_kod_pr order by sira_no");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_FAALIYET_ALANLARI")
    public static GMMap getFaaliyetAlanlari(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "FAALIYET_ALAN_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'ISYERI_FAAL_KONU_KOD' order by sira_no, text");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_YURT_DISI_EKSTRE_TIPI")
    public static GMMap getYurtDisiEkstreTip(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "KREDI_KART_YURT_DISI_EKSTRE", true, "select key1, text from v_ml_gnl_param_text where kod = 'KREDI_KART_YURT_DISI_EKSTRE' order by sira_no, text");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    
    @GraymoundService("BNSPR_TRN3871_GET_KART_OTOMATIK_ODEME_TIP")
    public static GMMap getKartOtomatikOdeme(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "KREDI_KART_OTOMATIK_ODEME", true, "select key1, text from v_ml_gnl_param_text where kod = 'KREDI_KART_OTOMATIK_ODEME' order by sira_no, text");
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    /** Kredi kart urun tiplerini verilen kriterlere gore listeler<br>
	 * @author murat.el
	 * @since PY-9199
	 * @param iMap - sorgu kriterleri<br>
	 *        <li>ACTION - Ekranda islem yapiliyorsa, ekranin islem tipi
	 *        <li>KANAL_KOD - Basvurunun yapildigi kanal kodu
	 *        <li>KREDI_KARTI_SEVIYESI - Kredi karti basvurusunun hangi amacla yapildigi
	 * @return oMap - Islem sonucu<br>
	 *        <li>PRODUCT_LIST - Urun listesi
	 */
    @GraymoundService("BNSPR_TRN3871_GET_PRODUCT_LIST")
    public static GMMap getProductList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	
    	//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
    	
        try {
        	//Listleme tipine karar ver.
        	String kanalTffMi = null;
        	String action = iMap.getString("ACTION");
        	String kanalKodu = iMap.getString("KANAL_KOD");
        	String kartSeviyesi = iMap.getString("KREDI_KARTI_SEVIYESI");
        	//Ekrandan cagrilmiyorsa sadece kanal koduna bak
        	if (StringUtils.isEmpty(action)) {
        		if ("L".equals(kartSeviyesi)) {
        			kanalTffMi = StringUtils.EMPTY;
        		}
        		else {
        			kanalTffMi = CreditCardServicesUtil.HAYIR;
                	if ("40".equals(kanalKodu)) {
                		kanalTffMi = CreditCardServicesUtil.EVET;
                	}
        		}
        	} else {
        		//Limit artis basvurularinda urunlerin tamami listelenir.
        		if ("L".equals(kartSeviyesi)) {
        			kanalTffMi = StringUtils.EMPTY;
        		}
        		//Izleme ya da on onayli ise hepsini listele
        		else if ("MESAJ_KUTUSU_CAGIRDI".equals(action) || "DETAY".equals(action)) {
            		kanalTffMi = StringUtils.EMPTY;
            	} 
        		else if ("ON_ONAY_BASVURU".equals(action)) {
        			GMMap sorguMap = new GMMap();
        			sorguMap.put("PARAMETRE", "KK_ONONAY_PASSOKART_AKTIF_MI");
        			sorguMap.putAll(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
        			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEGER"))) {
        				kanalTffMi = StringUtils.EMPTY;
        			} else {
        				kanalTffMi = CreditCardServicesUtil.HAYIR;
                    	if ("40".equals(kanalKodu)) {
                    		kanalTffMi = CreditCardServicesUtil.EVET;
                    	}
        			}
        		}
        		else {
            		kanalTffMi = CreditCardServicesUtil.HAYIR;
                	if ("40".equals(kanalKodu)) {
                		kanalTffMi = CreditCardServicesUtil.EVET;
                	}
            	}
        	}
        	
        	//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3871.get_kk_urun_kodlari(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, kanalTffMi);
			stmt.execute();

			//Comboya doldurulacak hale getir.
			rSet = (ResultSet) stmt.getObject(1);
			String listName = "PRODUCT_LIST";
			
			int index = 0;
			oMap.put(listName, index, "VALUE", StringUtils.EMPTY);//ID
			oMap.put(listName, index, "NAME", " ");//ACIKLAMA
			oMap.put(listName, index, "UCRET", BigDecimal.ZERO);//UCRET			
			for (index = 1; rSet.next(); index++) {
				oMap.put(listName, index, "VALUE", rSet.getString(1));//ID
				oMap.put(listName, index, "NAME", rSet.getString(2));//ACIKLAMA
				oMap.put(listName, index, "UCRET", rSet.getString(3));//UCRET			
			}
        	/* PY-9199 ile dogrudan oceandan almak yerine tablolardan alinmaya basladi
        	oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_PRODUCT_LIST", new GMMap()));
        	GuimlUtil.wrapMyCombo(oMap, "PRODUCT_LIST", null, " ");
        	int j=1;
        	for (int i = 0; i <oMap.getSize("PRODUCT_LIST"); i++) {
        		oMap.put("PRODUCT_LIST", j,"NAME", 	 oMap.get("PRODUCT_LIST",i,"NAME"));
        		oMap.put("PRODUCT_LIST", j++,"VALUE", 	 oMap.get("PRODUCT_LIST",i,"ID"));
			}
			*/
        } 
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_CUSTOMER_GROUP_LIST")
    public static GMMap getCustomerGroupList(GMMap iMap) {
    	GMMap oMap=new GMMap();
        try {
        	oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CUSTOMER_GROUP_LIST", new GMMap()));
        	GuimlUtil.wrapMyCombo(oMap, "CUSTOMER_LISTE", null, " ");
        	int j=1;
        	for (int i = 0; i <oMap.getSize("CUSTOMER_GROUP"); i++) {
        		oMap.put("CUSTOMER_LISTE", j,"NAME", 	 oMap.get("CUSTOMER_GROUP",i,"DESCRIPTION"));
        		oMap.put("CUSTOMER_LISTE", j++,"VALUE", 	 oMap.get("CUSTOMER_GROUP",i,"TYPE"));
			}
        	return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_CUSTOMER_TYPE_LIST")
    public static GMMap getCustomerTypeList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	String tableName = "CUSTOMER_TYPE_LIST";
    	String typeList = "TYPE_LIST";
    	
        try {
        	//Oceandan musteri tipini al
        	oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CUSTOMER_TYPE_LIST", new GMMap()));
        	
        	//Comboya doldurulacak hale getir.
        	GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
        	int j=1;
        	for (int i = 0; i <oMap.getSize(typeList); i++) {
        		oMap.put(tableName, j, "NAME", oMap.get(typeList, i, "DESCRIPTION"));
        		oMap.put(tableName, j++, "VALUE", oMap.get(typeList, i, "TYPE"));
			}
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
    
    /** Verilen urune ait logo kodlari listeler<br>
	 * @author murat.el
	 * @since PY-9199
	 * @param iMap - sorgu kriterleri<br>
	 *        <li>URUN_ID - Urun id
	 * @return oMap - Islem sonucu<br>
	 *        <li>LOGO_CODE_LIST - Logo listesi
	 */
    @GraymoundService("BNSPR_TRN3871_GET_LOGO_CODE_LIST")
    public static GMMap getLogoCodeList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	
    	//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
    	
        try {
        	//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3871.get_kk_logo_kodlari(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("URUN_ID"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			DALUtil.fillComboBox(oMap, "LOGO_CODE_LIST", true, rSet);
        	/* PY-9199 ile dogrudan oceandan almak yerine tablolardan alinmaya basladi
        	//Oceandan musteri tipini al
        	oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_LOGO_CODE_LIST", new GMMap()));
        	//Comboya doldurulacak hale getir.
        	GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
        	int j=1;
        	for (int i = 0; i <oMap.getSize(typeList); i++) {
        		oMap.put(tableName, j, "NAME", oMap.get(typeList, i, "DESCRIPTION"));
        		oMap.put(tableName, j++, "VALUE", oMap.get(typeList, i, "LOGO_CODE"));
			}
			*/
        } 
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
        
        return oMap;
    }
    
    /** Verilen urune ait finansal kodlari listeler<br>
   	 * @author murat.el
   	 * @since PY-9199
   	 * @param iMap - sorgu kriterleri<br>
   	 *        <li>URUN_ID - Urun id
   	 * @return oMap - Islem sonucu<br>
   	 *        <li>FINANCIAL_TYPE_LIST - Logo listesi
   	 */
    @GraymoundService("BNSPR_TRN3871_GET_FINANCIAL_TYPE_LIST")
    public static GMMap getFinancialTypeList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	
    	//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
    	
        try {
        	//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3871.get_kk_finansal_kodlari(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("URUN_ID"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			DALUtil.fillComboBox(oMap, "FINANCIAL_TYPE_LIST", true, rSet);

			/* PY-9199 ile dogrudan oceandan almak yerine tablolardan alinmaya basladi
        	//Oceandan musteri tipini al
        	GMMap sorguMap = new GMMap();
        	sorguMap.put("CARD_DCI", "C");
        	oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_FINANCIAL_TYPE_LIST", sorguMap));
        	//Comboya doldurulacak hale getir.
        	GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
        	int j=1;
        	for (int i = 0; i <oMap.getSize(typeList); i++) {
        		oMap.put(tableName, j, "NAME", oMap.get(typeList, i, "DESCRIPTION"));
        		oMap.put(tableName, j++, "VALUE", oMap.get(typeList, i, "TYPE"));
			}
			*/
        } 
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_HESAP_KESIM_TARIHI_LIST")
    public static GMMap getHesapKesimTarihi(GMMap iMap) {
    	GMMap oMap=new GMMap();
        try {
        	oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_BILLING_CYCLE_LIST", new GMMap()));
        	GuimlUtil.wrapMyCombo(oMap, "HESAP_KESIM_LIST", null, " ");
        	int j=1;
        	for (int i = 0; i <oMap.getSize("BILL_CYCLE_LIST"); i++) {
        		oMap.put("HESAP_KESIM_LIST", j,"NAME", 	 oMap.get("BILL_CYCLE_LIST",i,"DESCRIPTION"));
        		oMap.put("HESAP_KESIM_LIST", j++,"VALUE", 	 oMap.get("BILL_CYCLE_LIST",i,"STMT_CODE"));
			}
        	return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    /*
     * @param iMap - IL_KKTC
     * @param iMap - IL_YURT_DISI
     * @param iMap - IL_DIGER
     * 
     * parametrelerinden TRUE olarak gonderilenler 
     * il listesinde gosterilir. Default olarak bu
     * iller listede bulunmaz.
     * */
    @GraymoundService("BNSPR_TRN3871_GET_ILLER")
    public static GMMap getIller(GMMap iMap) {
    	String blackList = "'-1'";
    	
    	try {

			if (!iMap.getBoolean("IL_KKTC")) {
				blackList += ", '090'";
			}
			if (!iMap.getBoolean("IL_YURT_DISI")) {
				blackList += ", '200'";
			}
			if (!iMap.getBoolean("IL_DIGER")) {
				blackList += ", '999'";
			}

			String query = "select kod, il_adi from gnl_il_kod_pr where kod not in (" + blackList + ") ORDER by il_adi";
        	
    		return DALUtil.fillComboBox(iMap, "IL_LIST", true, query);
	    } catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_CALISMA_SEKILLERI")
    public static GMMap getCalismaSekilleri(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "CALISMA_SEKLI_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and (('" + iMap.getString("KANAL_KOD")
                + "' = '8' and key1 not in ('C', 'A', 'T')) or '" + iMap.getString("KANAL_KOD") + "' <> '8') order by sira_no");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_ILCELER")
    public static GMMap getIlceler(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareStatement("select ilce_kod, ilce_adi from gnl_ilce_kod_pr where il_kod = ? order by ilce_adi");
            stmt.setString(1, iMap.getString("IL_KODU"));
            rSet = stmt.executeQuery();

            DALUtil.fillComboBox(oMap, "ILCELER_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_VERGI_DAIRESI_ADLARI")
    public static GMMap getVergiDairesiAdlari(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareStatement("select vergi_d_kod, vergi_d_adi from gnl_vergi_daire_kod_pr where il_kod = ? order by vergi_d_adi");
            stmt.setString(1, iMap.getString("VERGI_DAIRESI_IL"));
            rSet = stmt.executeQuery();

            DALUtil.fillComboBox(oMap, "VERGI_DAIRESI_AD_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    
    @GraymoundService("BNSPR_TRN3871_GET_VERGI_DAIRESI_ILLERI")
    public static GMMap getVergiDairesiIlleri(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "VERGI_DAIRESI_IL_LIST", true, "select distinct(il_kod) kod, pkg_genel_pr.il_adi(il_kod) il_adi from gnl_vergi_daire_kod_pr order by 2");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_IKAMET_TURLERI")
    public static GMMap getIkametTurleri(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "IKAMET_TURLERI_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'IKAMET_DURUM_KOD' order by sira_no");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_UNVAN_TURLERI")
    public static GMMap getUnvanTurleri(GMMap iMap) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt =
                conn.prepareStatement("select u.kod,u.ACIKLAMA from v_ml_gnl_unvan_kod_pr u,v_ml_gnl_meslek_kod_pr m where m.KOD= ? and substr(m.unvan_dizi,pkg_trn10011.unvan_indis_belirle(u.KOD),1)='1' ");
            stmt.setString(1, iMap.getString("MESLEK_KOD"));
            rSet = stmt.executeQuery();

            return DALUtil.fillComboBox(iMap, "UNVAN_TURLERI_LIST", true, rSet);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_MESLEKLER")
    public static GMMap getMeslekler(GMMap iMap) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        CallableStatement stmt3 = null;
        GMMap oMap = new GMMap();

        try {
            conn = DALUtil.getGMConnection();

            String egitimKod = iMap.getString("EGITIM_KOD");
            String calismaSekliKod = iMap.getString("CALISMA_SEKLI");

            Calendar farkTar = GregorianCalendar.getInstance();
            farkTar.setTimeInMillis(iMap.getDate("BANKA_TARIHI").getTime() - iMap.getDate("DOGUM_TARIHI").getTime());
            int yas = farkTar.get(GregorianCalendar.YEAR) - 1970;

            stmt3 = conn.prepareCall("{? = call pkg_genel_pr.Yas_Araligi_Kodu_Bul(?)}");
            stmt3.registerOutParameter(1, Types.VARCHAR);
            stmt3.setBigDecimal(2, new BigDecimal(yas));
            stmt3.execute();
            StringBuilder yasDizi = new StringBuilder("_____");
            Integer index = new Integer(stmt3.getString(1));
            yasDizi = yasDizi.replace(index - 1, index, "1");

            StringBuilder egitimDizi = new StringBuilder();
            stmt = conn.prepareStatement("select sira_no from v_ml_gnl_egitim_kod_pr where kod = ? order by sira_no");
            stmt.setString(1, egitimKod);
            rSet = stmt.executeQuery();

            while (rSet.next()) {
                Integer firstIndex = new Integer(rSet.getString("SIRA_NO"));
                egitimDizi.append("%1");
                for (int i = firstIndex; i < 6; i++)
                    egitimDizi.append('1');
            }
            GMServerDatasource.close(rSet);
            StringBuilder calismaSekliDizi = new StringBuilder("___________");
            if (calismaSekliKod != null) {
                GMServerDatasource.close(stmt);
                stmt =
                    conn.prepareStatement("select count(*) sira_no from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and sira_no <= (select sira_no from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and key1 = ?)");
                stmt.setString(1, calismaSekliKod);
                rSet = stmt.executeQuery();

                while (rSet.next()) {
                    index = new Integer(rSet.getString("SIRA_NO"));
                    calismaSekliDizi = calismaSekliDizi.replace(index - 1, index, "1");
                }
            }
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            stmt =
                conn.prepareStatement("select kod, aciklama from v_ml_gnl_meslek_kod_pr where egitim_dizi like ? and yas_dizi like ? and calisma_sekli_dizi like ? order by Decode(aciklama,'Di�er','ZZZZZZZ',aciklama)");
            stmt.setString(1, egitimDizi.toString());
            stmt.setString(2, yasDizi.toString());
            stmt.setString(3, calismaSekliDizi.toString());

            rSet = stmt.executeQuery();

            oMap.put("ADD_EMPTY_KEY", iMap.getString("BOS_ALAN"));
            oMap.put("LIST_NAME", "MESLEK_LIST");
            DALUtil.fillComboBox(oMap, rSet);
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt3);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @GraymoundService("BNSPR_TRN3871_KPS_KIMLIK_DOGRULAMA")
    public static GMMap kimlikDogrulama(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            GMMap sMap = new GMMap();
            sMap.put("TCKN", iMap.getString("TCKNO"));
            if (isLocal) {
            	sMap = new GMMap(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_KPS_GET_KISI_BILGILERI", sMap));
            } else {
            	sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_BILGILERI", sMap);
            }

            if (sMap.getInt("HATA_KOD") == 0) {
				BilesikKutukModel kisiBilgisi = (BilesikKutukModel)sMap.get("KISI_BILGISI");
				
				if (kisiBilgisi != null) {

					TCKisiBilgisiModel tcKisiBilgisiModel = kisiBilgisi.getTcKisiBilgisiModel();
					
					if (!StringUtil.isEmpty(tcKisiBilgisiModel.getDogumTarih().toString())) {
						Calendar dogumTarihi = Calendar.getInstance();
						dogumTarihi.set(tcKisiBilgisiModel.getDogumTarih().getYil(),
								tcKisiBilgisiModel.getDogumTarih().getAy() - 1,
								tcKisiBilgisiModel.getDogumTarih().getGun());
						oMap.put("DOGUM_TARIHI", dogumTarihi.getTime());
					}
			
					oMap.put("TCKNO_OUT", tcKisiBilgisiModel.getTcKimlikNo());
					oMap.put("AD", tcKisiBilgisiModel.getAd());
					oMap.put("SOYAD", tcKisiBilgisiModel.getSoyad());
					oMap.put("CINSIYET", KPSUtil
							.getParametreAciklama(tcKisiBilgisiModel.getCinsiyet()));
					oMap.put("CINSIYET_KOD", KPSUtil
                        .getParametreKod(tcKisiBilgisiModel.getCinsiyet()));
					oMap.put("BABA_AD", tcKisiBilgisiModel.getBabaAd());
					oMap.put("ANNE_AD", tcKisiBilgisiModel.getAnneAd());
					oMap.put("KIZLIK_SOYAD", "");
					oMap.put("DOGUM_YERI", tcKisiBilgisiModel.getDogumYer());
					oMap.put("DURUMU",
							KPSUtil.getParametreKod(tcKisiBilgisiModel.getDurum())); // DURUMU_KOD
					oMap.put("DURUMU_ACIKLAMA",
                        KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getDurum()));
					oMap.put("MEDENI_HALI", KPSUtil
							.getParametreAciklama(tcKisiBilgisiModel.getMedeniHal()));
					oMap.put("MEDENI_HALI_KOD", KPSUtil
                        .getParametreKod(tcKisiBilgisiModel.getMedeniHal()));
					oMap.put("ES_TCKN", tcKisiBilgisiModel.getEsTCKimlikNo());
					oMap.put("DIN", tcKisiBilgisiModel.getDin());

					String ad = tcKisiBilgisiModel.getAd();
					String ad1;
					String ad2;
					if (ad.indexOf(" ") >= 0) {
						ad1 = ad.substring(0, ad.indexOf(" "));
						ad2 = ad.substring(ad.indexOf(" ")).trim();
					} else {
						ad1 = ad;
						ad2 = null;
					}
					oMap.put("AD1", ad1);
					oMap.put("AD2", ad2);

					String ilKodu = String.valueOf(tcKisiBilgisiModel.getIl()
							.getKod());
					if (ilKodu.length() == 2)
						ilKodu = "0" + ilKodu;
					if (ilKodu.length() == 1)
						ilKodu = "00" + ilKodu;
					oMap.put("IL_KODU", ilKodu);
					oMap.put("IL", String.valueOf(tcKisiBilgisiModel.getIl().getAciklama()));
					
					oMap.put("ILCE_KODU", String.valueOf(tcKisiBilgisiModel.getIlce().getKod()));
					oMap.put("ILCE", String.valueOf(tcKisiBilgisiModel.getIlce().getAciklama()));
					
					//oMap.put("DOGUM_ILCE_KODU", kisiBilgisi.getDogumYerKod());
					
					
					oMap.put("MAHALLE_KOY",
							tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel
									.getCilt().getAciklama() : "");
					oMap.put("CILT_KODU",
							tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel
									.getCilt().getKod() : "");
					oMap.put("CILT",
							tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel
                                .getCilt().getAciklama() : "");
					oMap.put("AILE_SIRA_NO", tcKisiBilgisiModel.getAileSiraNo());
					oMap.put("BIREY_SIRA_NO", tcKisiBilgisiModel.getBireySiraNo());

					if (!StringUtil.isEmpty(tcKisiBilgisiModel.getOlumTarih()
							.toString())) {
						Calendar olumTarihi = Calendar.getInstance();
						olumTarihi.set(tcKisiBilgisiModel.getOlumTarih().getYil(),
								tcKisiBilgisiModel.getOlumTarih().getAy() - 1,
								tcKisiBilgisiModel.getOlumTarih().getGun());

						oMap.put("OLUM_TARIHI", olumTarihi.getTime());
					}

				
					else {
						TCCuzdanBilgisiModel cuzdan = kisiBilgisi.getTcCuzdanBilgisiModel();
						TCKKModel tckk = kisiBilgisi.getTckkModel();
						
						if(cuzdan!=null && cuzdan.getSeri()!=null && !cuzdan.getSeri().isEmpty()){
							String seriNo=cuzdan.getSeriNo();
							oMap.put("TCKK", false);
							oMap.put("TC_KIMLIK_NO", cuzdan.getTcKimlikNo());
							if(seriNo != null)
							{
							oMap.put("NUFUS_CUZDANI_SERI_NO", seriNo);
							oMap.put("KIMLIK_SERI_NO", seriNo.substring(0, 3));	
							oMap.put("KIMLIK_SIRA_NO", seriNo.substring(3, seriNo.length()));	
							
							}
							if(cuzdan.getVerilmeTarih() != null && cuzdan.getVerilmeTarih().getYil() != null){
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(cuzdan.getVerilmeTarih().getYil(), cuzdan.getVerilmeTarih().getAy() - 1, cuzdan.getVerilmeTarih().getGun());
								oMap.put("VERILIS_TARIHI", verilisTarihi.getTime());
							}
		                	else
		                	{
		                		oMap.put("VERILIS_TARIHI", "");
		                	}
						
							oMap.put("OLUM_TARIHI", "");
							oMap.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(cuzdan.getCuzdanVerilmeNeden()));
							oMap.put("VERILIS_NEDENI", KPSUtil.getParametreAciklama(cuzdan.getCuzdanVerilmeNeden()));
							oMap.put("VERILIS_NEDENI_KOD", KPSUtil.getParametreKod(cuzdan.getCuzdanVerilmeNeden()));
							oMap.put("KIMLIK_KAYIT_NO", cuzdan.getCuzdanKayitNo());
							oMap.put("VERILDIGI_ILCE_KODU", KPSUtil.getParametreKod(cuzdan.getVerildigiIlce()));
							oMap.put("VERILDIGI_YER", KPSUtil.getParametreAciklama(cuzdan.getVerildigiIlce()));
							oMap.put("VERILDIGI_ILCE_ADI", KPSUtil.getParametreAciklama(cuzdan.getVerildigiIlce()));
					
						}
						else if(tckk!=null && tckk.getSeriNo()!=null && !tckk.getSeriNo().isEmpty()){
						
							String seriNo=tckk.getSeriNo();
							oMap.put("TCKK", true);
							oMap.put("TC_KIMLIK_NO", tckk.getTcKimlikNo());
							if(seriNo != null)
							{
							oMap.put("NUFUS_CUZDANI_SERI_NO", seriNo);
							oMap.put("KIMLIK_SERI_NO", seriNo.substring(0, 3));	
							oMap.put("KIMLIK_SIRA_NO", seriNo.substring(3, seriNo.length()));	
							
							}
							if(tckk.getTeslimTarih()!= null && tckk.getTeslimTarih().getYil() != null){
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(tckk.getTeslimTarih().getYil(), tckk.getTeslimTarih().getAy() - 1, tckk.getTeslimTarih().getGun());
								oMap.put("VERILIS_TARIHI", verilisTarihi.getTime());
							}
		                	else
		                	{
		                		oMap.put("VERILIS_TARIHI", "");
		                	}
							
							oMap.put("OLUM_TARIHI", "");
							oMap.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(tckk.getBasvuruNeden()));
							oMap.put("KIMLIK_KAYIT_NO", tckk.getKayitNo());
							oMap.put("TCKK_TESLIM_EDEN_BIRIM", KPSUtil.getParametreAciklama(tckk.getTeslimEdenBirim()));
							oMap.put("TCKK_VEREN_MAKAM", tckk.getVerenMakam());
						}		
					}

					ADCSession.put("KPS_MAP", oMap);
				} else {
					ADCSession.remove("KPS_MAP");
				}
				/*
				 * } else { logger.warn(sMap.getInt("HATA_KOD"));
				 * logger.warn(sMap.getString("HATA"));
				 * 
				 * oMap.put("HATA", sMap.getString("HATA"));
				 * oMap.put("HATA_KOD", sMap.getInt("HATA_KOD"));
				 * 
				 * //throw new GMRuntimeException(1, sMap.getString("HATA"));
				 * ADCSession.remove("KPS_MAP"); }
				 */
			}else {
                System.err.println(sMap.getInt("HATA_KOD"));
                System.err.println(sMap.getString("HATA"));
            }

        } catch (IntegrationException e) {
            //	throw ExceptionHandler.convertException(e);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("BNSPR_TRN3871_KPS_KAYIP_KIMLIK_SORGULAMA")
    public static GMMap kayipKimlikSorgulama(GMMap iMap) {
        GMMap oMap = new GMMap();
        /*
         * try{ KayipCuzdanC kayipCuzdanBilgisi =
         * KpsServices.getKayipCuzdanBilgisi(iMap.getString("TCKNO"));
         * if(kayipCuzdanBilgisi != null) { oMap.put("KAYIP_CUZDAN_SERI",
         * kayipCuzdanBilgisi.getKayipCuzdanSeri()); oMap.put("KAYIP_CUZDAN_NO",
         * kayipCuzdanBilgisi.getKayipCuzdanNo()); } return oMap; } catch
         * (KpsBusinessException e) { KPSSorguSonucu sorguSonucu =
         * e.getSorguSonucu(); e.printStackTrace();
         * System.err.println(sorguSonucu.getHataKod());
         * System.err.println(sorguSonucu.getHata()); } catch (Exception e) { //
         * throw ExceptionHandler.convertException(e); }
         */
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_APS_SORGULAMA")
    public static GMMap getAdresBilgileri(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            GMMap sMap = new GMMap();
            GMMap i2Map = new GMMap();
            sMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
            if (isLocal) {
            	sMap = new GMMap(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_KPS_GET_KISI_ADRES_BILGISI", sMap));
            } else {
            	sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_ADRES_BILGISI", sMap);
            }
            
            if (sMap.getInt("HATA_KOD") == 0) {
                KisiAdresBilgileriModel kisiAdresBilgisi = (KisiAdresBilgileriModel) sMap.get("KISI_ADRES_BILGISI");

                oMap.put("ADRES_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getAdresNo());
                oMap.put("BUCAK", kisiAdresBilgisi.getYerlesimYeriAdresi().getBucak());
                oMap.put("BUCAK_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getBucakKodu());
                oMap.put("CSBM", kisiAdresBilgisi.getYerlesimYeriAdresi().getCsbm());
                oMap.put("CSBM_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getCsbmKodu());
                oMap.put("DIS_KAPI_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getDisKapiNo());
                oMap.put("IC_KAPI_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getIcKapiNo());
                oMap.put("IL", kisiAdresBilgisi.getYerlesimYeriAdresi().getIl());
                oMap.put("ILCE", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlce());
                oMap.put("ILCE_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlceKodu());
                oMap.put("IL_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlKodu());
                oMap.put("KOY", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoy());
                oMap.put("KOY_KAYIT_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoyKayitNo());
                oMap.put("KOY_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoyKodu());
                oMap.put("MAHALLE", kisiAdresBilgisi.getYerlesimYeriAdresi().getMahalle());
                oMap.put("MAHALLE_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getMahalleKodu());

                if (iMap.containsKey("MUSTERI_NO") && !StringUtils.isEmpty(iMap.getString("MUSTERI_NO"))){
                	i2Map.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
                }
                
                i2Map.putAll(oMap);
                i2Map.put("TRX_NO", iMap.get("TRX_NO"));

                GMServiceExecuter.execute("BNSPR_SAVE_APS", i2Map);

                oMap.put("APS_YAPILDIMI", "E");

            }  else {
                oMap.put("APS_YAPILDIMI", "H");
            }

        } catch (Exception e) {
            oMap.put("APS_YAPILDIMI", "H");
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_PORTFOY_KOD")
    public static GMMap getPortfoyKod(GMMap iMap) {
    	GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_PORTFOY.Kredi_karti_Portfoy_Bul(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			//Sonuc
			oMap.put("PORTFOY_KOD", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
    }

    @GraymoundService("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD")
    public static GMMap getPortfoySubeKod(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;

        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_PORTFOY.Sube_Bul(?) }");

            stmt.registerOutParameter(1, Types.VARCHAR);
            stmt.setString(2, iMap.getString("PORTFOY_KOD"));

            stmt.execute();
            oMap.put("PORTFOY_SUBE_KOD", stmt.getString(1));

            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_TRN3871_UPDATE_MUSTERI_NO")
    public static GMMap updateMusteriNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            //if(iMap.getBigDecimal("MUSTERI_YARATMA_TX_NO") != null){

            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{call PKG_TRN3871.updateMusteriNo(?,?,?)}");
            int i = 1;
            stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
            stmt.registerOutParameter(2, Types.BIGINT);
            stmt.execute();
            oMap.put("MUSTERI_NO", stmt.getBigDecimal(2));
            //}

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_TELEFON_KOD")
    public static GMMap getTelefonKod(GMMap iMap) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap = new GMMap();
            String kod = iMap.getString("IL_KOD");

            conn = DALUtil.getGMConnection();

            stmt = conn.prepareStatement("select kod from gnl_tel_alan_kod_pr where il_kod = ?");
            stmt.setString(1, kod);

            rSet = stmt.executeQuery();

            if (rSet.next()) oMap.put("KOD", rSet.getString("KOD"));
            if (rSet.next()) oMap.put("KOD", "");

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN3871_GET_CURRENT_TIME")
    public static GMMap getCurrentTime(GMMap iMap) {
    	try{
            GMMap oMap = new GMMap();
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            Date today = Calendar.getInstance().getTime();
            String reportDate = df.format(today);
            oMap.put("CURRENT_DATE", reportDate);
            oMap.put("TODAY", today);
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN3871_SAVE_KIMLIK")
    public static GMMap saveKimlik(GMMap iMap) {
    	GMMap oMap = new GMMap();
        try {
        	
            Session session = DAOSession.getSession("BNSPRDal");

            KkBasvuruTx kkBasvuruTx =
                (KkBasvuruTx) session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                    .uniqueResult();
            if (kkBasvuruTx == null) {
            	kkBasvuruTx = new KkBasvuruTx();
            }
            kkBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTx.setDurumKod(iMap.getString("DURUM_KOD"));
            kkBasvuruTx.setKanalKod(iMap.getString("KANAL_KOD"));
            kkBasvuruTx.setKartSeviyesi(iMap.getString("KREDI_KARTI_SEVIYESI"));
            kkBasvuruTx.setAsilKartMusteriNo(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
            kkBasvuruTx.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
            kkBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
            kkBasvuruTx.setBasvuruTarihi(iMap.getDate("BASVURU_TARIHI"));
            kkBasvuruTx.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), CreditCardServicesUtil.HAYIR));
            if("S".equals(iMap.getString("KREDI_KARTI_SEVIYESI"))){
            	kkBasvuruTx.setSanalKartVarMi("E");
            }
            kkBasvuruTx.setBayiKod(iMap.getString("BAYI_KOD"));
            session.saveOrUpdate(kkBasvuruTx);
            session.flush();
            
            KkBasvuru kkBasvuru =
                    (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                        .uniqueResult();
            if (kkBasvuru == null) {
            	kkBasvuru = new KkBasvuru();
            }
            kkBasvuru.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuru.setDurumKod(iMap.getString("DURUM_KOD"));
            kkBasvuru.setKanalKod(iMap.getString("KANAL_KOD"));
            kkBasvuru.setKartSeviyesi(iMap.getString("KREDI_KARTI_SEVIYESI"));
            kkBasvuru.setAsilKartMusteriNo(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
            kkBasvuru.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
            kkBasvuru.setSubeKod(iMap.getString("SUBE_KOD"));
            kkBasvuru.setBasvuruTarihi(iMap.getDate("BASVURU_TARIHI"));
            kkBasvuru.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), CreditCardServicesUtil.HAYIR));
            if("S".equals(iMap.getString("KREDI_KARTI_SEVIYESI"))){
            	kkBasvuru.setSanalKartVarMi("E");
            }
            kkBasvuru.setBayiKod(iMap.getString("BAYI_KOD"));
            session.saveOrUpdate(kkBasvuru);
            session.flush();
            
        
            KkBasvuruKimlikTx kkBasvuruKimlikTx =
                (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                    .uniqueResult();
            if (kkBasvuruKimlikTx == null) {
            	kkBasvuruKimlikTx = new KkBasvuruKimlikTx();
            }
            kkBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruKimlikTx.setUyrukKod("TR");
            kkBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
            kkBasvuruKimlikTx.setAd(iMap.getString("ADI"));
            kkBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
            kkBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
            kkBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
            kkBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
            kkBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
            kkBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
            kkBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
            kkBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
            kkBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
            kkBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
            kkBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
            kkBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
            kkBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
            kkBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
            kkBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
            kkBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
            kkBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
            kkBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
            kkBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
            kkBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
            kkBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
            kkBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
            kkBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
            kkBasvuruKimlikTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
            kkBasvuruKimlikTx.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
            session.saveOrUpdate(kkBasvuruKimlikTx);
            session.flush();
          
            KkBasvuruTelefonTx kkBasvuruTelefonTx =
                    (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
                    add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                    add(Restrictions.eq("id.tip", "3"))
                        .uniqueResult();
            if (kkBasvuruTelefonTx == null) {
            	kkBasvuruTelefonTx = new KkBasvuruTelefonTx();
            }
               
            KkBasvuruTelefonTxId kkBasvuruTelefonTxId = new KkBasvuruTelefonTxId();
            kkBasvuruTelefonTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruTelefonTxId.setTip("3");   // GSM
            kkBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTelefonTx.setUlkeKod(iMap.getString("CEP_ULKE_KOD", "90"));
            kkBasvuruTelefonTx.setAlanKod(iMap.getString("CEP_TEL_KOD"));
            kkBasvuruTelefonTx.setNumara(iMap.getString("CEP_TEL_NO"));
            kkBasvuruTelefonTx.setId(kkBasvuruTelefonTxId);
            session.saveOrUpdate(kkBasvuruTelefonTx);
            session.flush();
            
            if(!"N".equals(iMap.getString("IS_CONTROL_REQUIRED"))){   // to check whether control needed, kisa basvuru icin hata caselerinde gerekmiyor
	            iMap.put("IS_FIRST_PAGE", "Y");
	            GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", iMap);
            }
            KkBasvuruKimlik kkBasvuruKimlik =
                    (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                        .uniqueResult();
            if (kkBasvuruKimlik == null) {
            	kkBasvuruKimlik = new KkBasvuruKimlik();
            }
            kkBasvuruKimlik.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruKimlik.setUyrukKod("TR");
            kkBasvuruKimlik.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
            kkBasvuruKimlik.setAd(iMap.getString("ADI"));
            kkBasvuruKimlik.setIkinciAd(iMap.getString("IKINCI_ADI"));
            kkBasvuruKimlik.setSoyad(iMap.getString("SOYADI"));
            kkBasvuruKimlik.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
            kkBasvuruKimlik.setDogumYeri(iMap.getString("DOGUM_YERI"));
            kkBasvuruKimlik.setBabaAd(iMap.getString("BABA_ADI"));
            kkBasvuruKimlik.setAnneAdi(iMap.getString("ANNE_ADI"));
            kkBasvuruKimlik.setCinsiyet(iMap.getString("CINSIYET"));
            kkBasvuruKimlik.setMedeniHal(iMap.getString("MEDENI_HAL"));
            kkBasvuruKimlik.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
            kkBasvuruKimlik.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
            kkBasvuruKimlik.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
            kkBasvuruKimlik.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
            kkBasvuruKimlik.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
            kkBasvuruKimlik.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
            kkBasvuruKimlik.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
            kkBasvuruKimlik.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
            kkBasvuruKimlik.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
            kkBasvuruKimlik.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
            kkBasvuruKimlik.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
            kkBasvuruKimlik.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
            kkBasvuruKimlik.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
            kkBasvuruKimlik.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
            kkBasvuruKimlik.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
            kkBasvuruKimlik.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
            session.saveOrUpdate(kkBasvuruKimlik);
            session.flush();
              
            KkBasvuruTelefon kkBasvuruTelefon =
                    (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).
                    add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).
                    add(Restrictions.eq("id.tip", "3"))
                        .uniqueResult();
            if (kkBasvuruTelefon == null) {
            	kkBasvuruTelefon = new KkBasvuruTelefon();
            }
               
            KkBasvuruTelefonId kkBasvuruTelefonId = new KkBasvuruTelefonId();
            kkBasvuruTelefonId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTelefonId.setTip("3");   // GSM
            kkBasvuruTelefon.setUlkeKod(iMap.getString("CEP_ULKE_KOD", "90"));
            kkBasvuruTelefon.setAlanKod(iMap.getString("CEP_TEL_KOD"));
            kkBasvuruTelefon.setNumara(iMap.getString("CEP_TEL_NO"));
            kkBasvuruTelefon.setId(kkBasvuruTelefonId);
            session.saveOrUpdate(kkBasvuruTelefon);
            session.flush();
            
            // es bilgilerini sorgula ve kaydet
            if(StringUtils.isNotBlank(iMap.getString("ES_TCKN"))){ // es tckn null degilse sorgula
            	GMMap esMap=new GMMap();
	            esMap.put("ES_TCKN",iMap.getString("ES_TCKN"));
	            esMap.put("TRX_NO",iMap.getBigDecimal("TRX_NO"));
	            esMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
	            GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_ES_BILGILERI", esMap);
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3871_TFF_SAVE_KIMLIK")
    public static GMMap tffSaveKimlik(GMMap iMap) {
    	GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            KkBasvuruTx kkBasvuruTx =
                (KkBasvuruTx) session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                    .uniqueResult();
            if (kkBasvuruTx == null) {
            	kkBasvuruTx = new KkBasvuruTx();
            }
            kkBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTx.setDurumKod(iMap.getString("DURUM_KOD"));
            kkBasvuruTx.setKanalKod(iMap.getString("KANAL_KOD"));
            kkBasvuruTx.setKartSeviyesi(iMap.getString("KREDI_KARTI_SEVIYESI"));
            kkBasvuruTx.setAsilKartMusteriNo(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
            kkBasvuruTx.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
            kkBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
            kkBasvuruTx.setBasvuruTarihi(iMap.getDate("BASVURU_TARIHI"));
            kkBasvuruTx.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), CreditCardServicesUtil.HAYIR));
            if("S".equals(iMap.getString("KREDI_KARTI_SEVIYESI"))){
            	kkBasvuruTx.setSanalKartVarMi("E");
            }
            kkBasvuruTx.setBayiKod(iMap.getString("BAYI_KOD"));
            
            ///TFF on basvuru icin
            kkBasvuruTx.setKartinUzerineYazilacakIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
            kkBasvuruTx.setKartLimiti(iMap.getBigDecimal("KART_LIMITI"));
            kkBasvuruTx.setNakitKartLimiti(iMap.getBigDecimal("NAKIT_KART_LIMITI"));
            kkBasvuruTx.setEkspressKartLimiti(iMap.getBigDecimal("EKSPRESS_KART_LIMITI"));
            kkBasvuruTx.setUrunTipi(iMap.getString("KART_URUN_TIP"));
            kkBasvuruTx.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
            kkBasvuruTx.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
            kkBasvuruTx.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
            kkBasvuruTx.setEkstreSecimi(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
            kkBasvuruTx.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));
            kkBasvuruTx.setOtomatikOdemeTalimati(iMap.getString("KART_OTOMATIK_ODEME"));
            kkBasvuruTx.setYurtdisiHarcamaEkstresi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
            kkBasvuruTx.setEkKartVarMi(iMap.getString("EK_KART_VAR_MI"));
            kkBasvuruTx.setMusteriGrup(iMap.getString("MUSTERI_GROUP"));
            kkBasvuruTx.setMusteriTip(iMap.getString("MUSTERI_TIPI"));
            kkBasvuruTx.setFinansalTip(iMap.getString("FINANSAL_TIP"));
            kkBasvuruTx.setLogoKod(iMap.getString("LOGO_KODU"));
            kkBasvuruTx.setOtomatikLimitArtis(iMap.getString("OTOMATIK_LIMIT_ARTIS"));
            kkBasvuruTx.setKdhIstiyorMu(iMap.getString("KDH_ISTIYOR_MU"));
            kkBasvuruTx.setEPosta(iMap.getString("EMAIL"));
            kkBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
           ///TFF on basvuru icin
            
            session.saveOrUpdate(kkBasvuruTx);
            
            KkBasvuru kkBasvuru =
                    (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                        .uniqueResult();
            if (kkBasvuru == null) {
            	kkBasvuru = new KkBasvuru();
            }
            kkBasvuru.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuru.setDurumKod(iMap.getString("DURUM_KOD"));
            kkBasvuru.setKanalKod(iMap.getString("KANAL_KOD"));
            kkBasvuru.setKartSeviyesi(iMap.getString("KREDI_KARTI_SEVIYESI"));
            kkBasvuru.setAsilKartMusteriNo(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
            kkBasvuru.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
            kkBasvuru.setSubeKod(iMap.getString("SUBE_KOD"));
            kkBasvuru.setBasvuruTarihi(iMap.getDate("BASVURU_TARIHI"));
            kkBasvuru.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), CreditCardServicesUtil.HAYIR));
            if("S".equals(iMap.getString("KREDI_KARTI_SEVIYESI"))){
            	kkBasvuru.setSanalKartVarMi("E");
            }
            kkBasvuru.setBayiKod(iMap.getString("BAYI_KOD"));
            
            ///TFF on basvuru icin
            kkBasvuru.setKartinUzerineYazilacakIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
            kkBasvuru.setKartLimiti(iMap.getBigDecimal("KART_LIMITI"));
            kkBasvuru.setNakitKartLimiti(iMap.getBigDecimal("NAKIT_KART_LIMITI"));
            kkBasvuru.setEkspressKartLimiti(iMap.getBigDecimal("EKSPRESS_KART_LIMITI"));
            kkBasvuru.setUrunTipi(iMap.getString("KART_URUN_TIP"));
            kkBasvuru.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
            kkBasvuru.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
            kkBasvuru.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
            kkBasvuru.setEkstreSecimi(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
            kkBasvuru.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));
            kkBasvuru.setOtomatikOdemeTalimati(iMap.getString("KART_OTOMATIK_ODEME"));
            kkBasvuru.setYurtdisiHarcamaEkstresi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
            kkBasvuru.setEkKartVarMi(iMap.getString("EK_KART_VAR_MI"));
            kkBasvuru.setMusteriGrup(iMap.getString("MUSTERI_GROUP"));
            kkBasvuru.setMusteriTip(iMap.getString("MUSTERI_TIPI"));
            kkBasvuru.setFinansalTip(iMap.getString("FINANSAL_TIP"));
            kkBasvuru.setLogoKod(iMap.getString("LOGO_KODU"));
            kkBasvuru.setOtomatikLimitArtis(iMap.getString("OTOMATIK_LIMIT_ARTIS"));
            kkBasvuru.setKdhIstiyorMu(iMap.getString("KDH_ISTIYOR_MU"));
            kkBasvuru.setEPosta(iMap.getString("EMAIL"));
            kkBasvuru.setSessionIp(iMap.getString("SESSION_IP"));
           ///TFF on basvuru icin
            
            session.saveOrUpdate(kkBasvuru);
            
        
            KkBasvuruKimlikTx kkBasvuruKimlikTx =
                (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                    .uniqueResult();
            if (kkBasvuruKimlikTx == null) {
            	kkBasvuruKimlikTx = new KkBasvuruKimlikTx();
            }
            kkBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruKimlikTx.setUyrukKod("TR");
            kkBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
            kkBasvuruKimlikTx.setAd(iMap.getString("ADI"));
            kkBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
            kkBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
            kkBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
            kkBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
            kkBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
            kkBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
            kkBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
            kkBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
            kkBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
            kkBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
            kkBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
            kkBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
            kkBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
            kkBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
            kkBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
            kkBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
            kkBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
            kkBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
            kkBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
            kkBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
            kkBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
            kkBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
            kkBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
            kkBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
            kkBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
            kkBasvuruKimlikTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
            kkBasvuruKimlikTx.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
            session.saveOrUpdate(kkBasvuruKimlikTx);
          
            KkBasvuruTelefonTx kkBasvuruTelefonTx =
                    (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
                    add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                    add(Restrictions.eq("id.tip", "3"))
                        .uniqueResult();
            if (kkBasvuruTelefonTx == null) {
            	kkBasvuruTelefonTx = new KkBasvuruTelefonTx();
            }
               
            KkBasvuruTelefonTxId kkBasvuruTelefonTxId = new KkBasvuruTelefonTxId();
            kkBasvuruTelefonTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruTelefonTxId.setTip("3");   // GSM
            kkBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTelefonTx.setUlkeKod(iMap.getString("CEP_ULKE_KOD", "90"));
            kkBasvuruTelefonTx.setAlanKod(iMap.getString("CEP_TEL_KOD"));
            kkBasvuruTelefonTx.setNumara(iMap.getString("CEP_TEL_NO"));
            kkBasvuruTelefonTx.setId(kkBasvuruTelefonTxId);
            session.saveOrUpdate(kkBasvuruTelefonTx);
            
            if(StringUtils.isNotBlank(iMap.getString("CALISMA_SEKLI")))
            {
	            KkBasvuruMeslekiBilgiTx kkBasvuruMeslekiBilgiTx =
	                    (KkBasvuruMeslekiBilgiTx) session.createCriteria(KkBasvuruMeslekiBilgiTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
	                        .uniqueResult();
	            if (kkBasvuruMeslekiBilgiTx == null) {
	            	kkBasvuruMeslekiBilgiTx = new KkBasvuruMeslekiBilgiTx();
	            }
	            kkBasvuruMeslekiBilgiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
	            kkBasvuruMeslekiBilgiTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	            kkBasvuruMeslekiBilgiTx.setCalismaSekliKod(iMap.getString("CALISMA_SEKLI"));
	            kkBasvuruMeslekiBilgiTx.setOgrenimDurumKod(iMap.getString("OGRENIM_DURUMU"));
	            kkBasvuruMeslekiBilgiTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
	            session.saveOrUpdate(kkBasvuruMeslekiBilgiTx);
            }
            
            if(StringUtils.isNotBlank(iMap.getString("EV_ADRESI")))
            {
				KkBasvuruAdresTxId id = new KkBasvuruAdresTxId();
				id.setAdresKod("E");
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
	
				KkBasvuruAdresTx kkBasvuruAdresTx = (KkBasvuruAdresTx) session.get(KkBasvuruAdresTx.class, id);
				if (kkBasvuruAdresTx == null) {
					kkBasvuruAdresTx = new KkBasvuruAdresTx();
					kkBasvuruAdresTx.setId(id);
				}
	
				kkBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				kkBasvuruAdresTx.setIlKod(iMap.getString("EV_IL"));
				kkBasvuruAdresTx.setIlceKod(iMap.getString("EV_ILCE"));
				kkBasvuruAdresTx.setAdres(CreditCardServicesUtil.trimNewLine(iMap.getString("EV_ADRESI")));
				if ("E".equals(iMap.getString("TESLIMAT_ADRESI"))) {//Teslimat adresi ev mi
					kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.EVET);
				} else {//degil
					kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.HAYIR);
				}
				
				
				setAdressCompleteness(kkBasvuruAdresTx , session);
	            session.saveOrUpdate(kkBasvuruAdresTx);
            }
            
            if(StringUtils.isNotBlank(iMap.getString("IS_ADRESI")))
            {
				KkBasvuruAdresTxId id = new KkBasvuruAdresTxId();
				id.setAdresKod("I");
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
	
				KkBasvuruAdresTx kkBasvuruAdresTx = (KkBasvuruAdresTx) session.get(KkBasvuruAdresTx.class, id);
				if (kkBasvuruAdresTx == null) {
					kkBasvuruAdresTx = new KkBasvuruAdresTx();
					kkBasvuruAdresTx.setId(id);
				}
	
				kkBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				kkBasvuruAdresTx.setIlKod(iMap.getString("IS_IL"));
				kkBasvuruAdresTx.setIlceKod(iMap.getString("IS_ILCE"));
				kkBasvuruAdresTx.setAdres(CreditCardServicesUtil.trimNewLine(iMap.getString("IS_ADRESI")));
				if ("I".equals(iMap.getString("TESLIMAT_ADRESI"))) {//Teslimat adresi ev mi
					kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.EVET);
				} else {//degil
					kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.HAYIR);
				}
	
				setAdressCompleteness(kkBasvuruAdresTx , session);
				session.saveOrUpdate(kkBasvuruAdresTx);
            }
            
            if(!"N".equals(iMap.getString("IS_CONTROL_REQUIRED"))){   // to check whether control needed, kisa basvuru icin hata caselerinde gerekmiyor
	            iMap.put("IS_FIRST_PAGE", "Y");
	            GMMap sorguMap = new GMMap();
	 		    sorguMap.put("KULLANICI_KOD", "TFF");
	 		    sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
	 		    GMServiceExecuter.execute("BNSPR_KK_SET_USER_GLOBALS", sorguMap);
	 		    session.flush();
	 		    iMap.put("IS_FIRST_PAGE", "Y");
	            GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", iMap);
            }
            KkBasvuruKimlik kkBasvuruKimlik =
                    (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                        .uniqueResult();
            if (kkBasvuruKimlik == null) {
            	kkBasvuruKimlik = new KkBasvuruKimlik();
            }
            kkBasvuruKimlik.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruKimlik.setUyrukKod("TR");
            kkBasvuruKimlik.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
            kkBasvuruKimlik.setAd(iMap.getString("ADI"));
            kkBasvuruKimlik.setIkinciAd(iMap.getString("IKINCI_ADI"));
            kkBasvuruKimlik.setSoyad(iMap.getString("SOYADI"));
            kkBasvuruKimlik.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
            kkBasvuruKimlik.setDogumYeri(iMap.getString("DOGUM_YERI"));
            kkBasvuruKimlik.setBabaAd(iMap.getString("BABA_ADI"));
            kkBasvuruKimlik.setAnneAdi(iMap.getString("ANNE_ADI"));
            kkBasvuruKimlik.setCinsiyet(iMap.getString("CINSIYET"));
            kkBasvuruKimlik.setMedeniHal(iMap.getString("MEDENI_HAL"));
            kkBasvuruKimlik.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
            kkBasvuruKimlik.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
            kkBasvuruKimlik.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
            kkBasvuruKimlik.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
            kkBasvuruKimlik.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
            kkBasvuruKimlik.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
            kkBasvuruKimlik.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
            kkBasvuruKimlik.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
            kkBasvuruKimlik.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
            kkBasvuruKimlik.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
            kkBasvuruKimlik.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
            kkBasvuruKimlik.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
            kkBasvuruKimlik.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
            kkBasvuruKimlik.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
            kkBasvuruKimlik.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
            kkBasvuruKimlik.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
            kkBasvuruKimlik.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
            kkBasvuruKimlik.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
            kkBasvuruKimlik.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
            session.saveOrUpdate(kkBasvuruKimlik);
              
            KkBasvuruTelefon kkBasvuruTelefon =
                    (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).
                    add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).
                    add(Restrictions.eq("id.tip", "3"))
                        .uniqueResult();
            if (kkBasvuruTelefon == null) {
            	kkBasvuruTelefon = new KkBasvuruTelefon();
            }
               
            KkBasvuruTelefonId kkBasvuruTelefonId = new KkBasvuruTelefonId();
            kkBasvuruTelefonId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTelefonId.setTip("3");   // GSM
            kkBasvuruTelefon.setUlkeKod(iMap.getString("CEP_ULKE_KOD", "90"));
            kkBasvuruTelefon.setAlanKod(iMap.getString("CEP_TEL_KOD"));
            kkBasvuruTelefon.setNumara(iMap.getString("CEP_TEL_NO"));
            kkBasvuruTelefon.setId(kkBasvuruTelefonId);
            session.saveOrUpdate(kkBasvuruTelefon);
            
            if(StringUtils.isNotBlank(iMap.getString("CALISMA_SEKLI")))
            {
	            KkBasvuruMeslekiBilgi kkBasvuruMeslekiBilgi =
	                    (KkBasvuruMeslekiBilgi) session.createCriteria(KkBasvuruMeslekiBilgi.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
	                        .uniqueResult();
	            if (kkBasvuruMeslekiBilgi == null) {
	            	kkBasvuruMeslekiBilgi = new KkBasvuruMeslekiBilgi();
	            }
	            kkBasvuruMeslekiBilgi.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	            kkBasvuruMeslekiBilgi.setCalismaSekliKod(iMap.getString("CALISMA_SEKLI"));
	            kkBasvuruMeslekiBilgi.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
	            session.saveOrUpdate(kkBasvuruMeslekiBilgi);
            }
            
            if(StringUtils.isNotBlank(iMap.getString("EV_ADRESI")))
            {
				KkBasvuruAdresId id = new KkBasvuruAdresId();
				id.setAdresKod("E");
				id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	
				KkBasvuruAdres kkBasvuruAdres = (KkBasvuruAdres) session.get(KkBasvuruAdres.class, id);
				if (kkBasvuruAdres == null) {
					kkBasvuruAdres = new KkBasvuruAdres();
					kkBasvuruAdres.setId(id);
				}
	
				kkBasvuruAdres.setIlKod(iMap.getString("EV_IL"));
				kkBasvuruAdres.setIlceKod(iMap.getString("EV_ILCE"));
				kkBasvuruAdres.setAdres(iMap.getString("EV_ADRESI"));
				if ("E".equals(iMap.getString("TESLIMAT_ADRESI"))) {//Teslimat adresi ev mi
					kkBasvuruAdres.setTeslimatAdresiMi(CreditCardServicesUtil.EVET);
				} else {//degil
					kkBasvuruAdres.setTeslimatAdresiMi(CreditCardServicesUtil.HAYIR);
				}
	
				setAdressCompleteness(kkBasvuruAdres , session);
				session.saveOrUpdate(kkBasvuruAdres);
            }
            
            if(StringUtils.isNotBlank(iMap.getString("IS_ADRESI")))
            {
				KkBasvuruAdresId id = new KkBasvuruAdresId();
				id.setAdresKod("I");
				id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	
				KkBasvuruAdres kkBasvuruAdres = (KkBasvuruAdres) session.get(KkBasvuruAdres.class, id);
				if (kkBasvuruAdres == null) {
					kkBasvuruAdres = new KkBasvuruAdres();
					kkBasvuruAdres.setId(id);
				}
	
				kkBasvuruAdres.setIlKod(iMap.getString("IS_IL"));
				kkBasvuruAdres.setIlceKod(iMap.getString("IS_ILCE"));
				kkBasvuruAdres.setAdres(iMap.getString("IS_ADRESI"));
				if ("I".equals(iMap.getString("TESLIMAT_ADRESI"))) {//Teslimat adresi ev mi
					kkBasvuruAdres.setTeslimatAdresiMi(CreditCardServicesUtil.EVET);
				} else {//degil
					kkBasvuruAdres.setTeslimatAdresiMi(CreditCardServicesUtil.HAYIR);
				}
	
				setAdressCompleteness(kkBasvuruAdres , session);
				session.saveOrUpdate(kkBasvuruAdres);
            }
            // es bilgilerini sorgula ve kaydet
            if(StringUtils.isNotBlank(iMap.getString("ES_TCKN"))){ // es tckn null degilse sorgula
            	GMMap esMap=new GMMap();
	            esMap.put("ES_TCKN",iMap.getString("ES_TCKN"));
	            esMap.put("TRX_NO",iMap.getBigDecimal("TRX_NO"));
	            esMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
	            try {
	            	GMServiceExecuter.execute("BNSPR_TRN3871_SAVE_ES_BILGILERI", esMap);
	            } catch (Throwable e) {
	            	
	            }
            }
            
          //TFF tarafindan gelen kredi karti basvurulari sadece TFF kullanicisi ile olusturulabilir
		   GMMap sorguMap = new GMMap();
		   sorguMap.put("KULLANICI_KOD", "TFF");
		   sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
		   GMServiceExecuter.execute("BNSPR_KK_SET_USER_GLOBALS", sorguMap);
		   session.flush();
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    private static void setAdressCompleteness(KkBasvuruAdres kkBasvuruAdres , Session defaultSession) {
    	 
    	Session session = null;
    	if("E".equals(kkBasvuruAdres.getTeslimatAdresiMi())){
				// tff basvurusu mu ?
			 			
			 if(kkBasvuruAdres.getId().getBasvuruNo() != null){
				 
				 if(defaultSession == null || !defaultSession.isConnected()){
					 session = DAOSession.getSession("BNSPRDal");	
				 }
				 else{
					 session = defaultSession;
				 }
				 
				 
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", kkBasvuruAdres.getId().getBasvuruNo())).uniqueResult();
					if(tffBasvuru != null){
						kkBasvuruAdres.setVeriKontrolEdilecekMi("E"); // set default
						if(!StringUtils.isEmpty(kkBasvuruAdres.getAdres())){
							
					
						    Criteria criteria = session.createCriteria(GnlParamText.class)
						    										.add(Restrictions.eq("kod", "VERI_KONTROL_ADRES_UYGUNLUK_ORANI"))
						    										.add(Restrictions.eq("key1", "A"));
						    										
							GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
							if(gnlParamText != null && gnlParamText.getSayi() != null && gnlParamText.getSayi().intValue() >= 0){
								BigDecimal compRate =  gnlParamText.getSayi(); 
								GMMap pigeonMap = new GMMap();
								
							    criteria = session.createCriteria(GnlilKodPr.class)
							    										.add(Restrictions.eq("kod", kkBasvuruAdres.getIlKod()));
							    							
							    										
							    GnlilKodPr gnlilKodPr = (GnlilKodPr) criteria.uniqueResult();
								
							    session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
							    criteria = session.createCriteria(GnlilceKodPr.class)
							    										.add(Restrictions.eq("id.gnlilKodPr.kod", kkBasvuruAdres.getIlKod()))
							    										.add(Restrictions.eq("id.ilceKod", kkBasvuruAdres.getIlceKod())
							    										  );
				
							    										
							    GnlilceKodPr gnlilceKodPr = (GnlilceKodPr) criteria.uniqueResult();
							    
							    String acikAdres = kkBasvuruAdres.getAdres();
							    if(gnlilceKodPr != null){
							    	acikAdres = acikAdres + " " + gnlilceKodPr.getIlceAdi();
							    }
								
							    if(gnlilKodPr != null){
							    	acikAdres = acikAdres + " " + gnlilKodPr.getIlAdi();
							    }
							    
								
								pigeonMap.put("ADDRESS", acikAdres);
								pigeonMap.put("FORMAT_RESPONSE",false);
								AddressOut checkedAdress = (AddressOut) GMServiceExecuter.call("BNSPR_COMMON_DETECT_BEST_ADDRESS", pigeonMap).get("RESULT_ADDRESS");
								if(checkedAdress != null){
									BigDecimal checkedAdressDecimal = new BigDecimal(checkedAdress.getCompletenessRate().getValue());
									kkBasvuruAdres.setPigeonCompletenessRate(checkedAdressDecimal);
									kkBasvuruAdres.setVeriKontrolEdilecekMi(checkedAdressDecimal.compareTo(compRate) == -1 ? "E" : "H");
								}
								
								
								
							}
							
						}
						
					}
				}
				
				
			}
		
	}

	private static void setAdressCompleteness(KkBasvuruAdresTx kkBasvuruAdresTx , Session defaultSession) {
		
		Session session = null; 
		
		if("E".equals(kkBasvuruAdresTx.getTeslimatAdresiMi())){
				// tff basvurusu mu ?
			
				
			 if(kkBasvuruAdresTx.getBasvuruNo() != null){
				 
				 if(defaultSession == null || !defaultSession.isConnected()){
					 session = DAOSession.getSession("BNSPRDal");	
				 }
				 else{
					 session = defaultSession;
				 }
				 
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", kkBasvuruAdresTx.getBasvuruNo())).uniqueResult();
					if(tffBasvuru != null){
						kkBasvuruAdresTx.setVeriKontrolEdilecekMi("E"); // set default
						if(!StringUtils.isEmpty(kkBasvuruAdresTx.getAdres())){
							
					
						    Criteria criteria = session.createCriteria(GnlParamText.class)
						    										.add(Restrictions.eq("kod", "VERI_KONTROL_ADRES_UYGUNLUK_ORANI"))
						    										.add(Restrictions.eq("key1", "A"));
						    										
							GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
							if(gnlParamText != null && gnlParamText.getSayi() != null && gnlParamText.getSayi().intValue() >= 0){
								BigDecimal compRate =  gnlParamText.getSayi(); 
								GMMap pigeonMap = new GMMap();
								
							    criteria = session.createCriteria(GnlilKodPr.class)
							    										.add(Restrictions.eq("kod", kkBasvuruAdresTx.getIlKod()));
							    							
							    										
							    GnlilKodPr gnlilKodPr = (GnlilKodPr) criteria.uniqueResult();
								
							    session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
							    criteria = session.createCriteria(GnlilceKodPr.class)
							    										.add(Restrictions.eq("id.gnlilKodPr.kod", kkBasvuruAdresTx.getIlKod()))
							    										.add(Restrictions.eq("id.ilceKod", kkBasvuruAdresTx.getIlceKod())
							    										  );
				
							    										
							    GnlilceKodPr gnlilceKodPr = (GnlilceKodPr) criteria.uniqueResult();
							    
							    String acikAdres = kkBasvuruAdresTx.getAdres();
							    if(gnlilceKodPr != null){
							    	acikAdres = acikAdres + " " + gnlilceKodPr.getIlceAdi();
							    }
								
							    if(gnlilKodPr != null){
							    	acikAdres = acikAdres + " " + gnlilKodPr.getIlAdi();
							    }
							    
								
								pigeonMap.put("ADDRESS", acikAdres);
								pigeonMap.put("FORMAT_RESPONSE",false);
								AddressOut checkedAdress = (AddressOut) GMServiceExecuter.call("BNSPR_COMMON_DETECT_BEST_ADDRESS", pigeonMap).get("RESULT_ADDRESS");
																
								if(checkedAdress != null){
									BigDecimal checkedAdressDecimal = new BigDecimal(checkedAdress.getCompletenessRate().getValue());
									kkBasvuruAdresTx.setPigeonCompletenessRate(checkedAdressDecimal);
									kkBasvuruAdresTx.setVeriKontrolEdilecekMi(checkedAdressDecimal.compareTo(compRate) == -1 ? "E" : "H");
								}
								
							}
							
						}
						
					}
				}
				
				
			}
		
		
	}

	@SuppressWarnings("unused")
    public static String concatYilAy(String yil, String ay) {
        String yilAy = new String();

        if (yil != null && yil.isEmpty() && ay != null && ay.isEmpty()) { return null; }

        if (yil == null) {
            if (ay == null) {
                return null;
            } else if (ay.length() == 0) {
                return null;
            } else if (ay.length() == 1) {
                return "000" + ay;
            } else {
                return "00" + ay;
            }
        }

        if (ay == null) {
            if (yil == null) {
                return null;
            } else if (yil.length() == 0) {
                return null;
            } else if (yil.length() == 1) {
                return "0" + yil + "00";
            } else {
                return yil + "00";
            }
        }
        if (yil.length() == 0 || yil.equals("0")) yilAy = "00";
        else if (yil.length() == 1) yilAy = "0" + yil;
        else yilAy = yil;
        if (ay.length() == 0 || ay.equals("0")) yilAy = yilAy + "00";
        else if (ay.length() == 1) yilAy = yilAy + "0" + ay;
        else yilAy = yilAy + ay;

        return yilAy;
    }
    
    @GraymoundService("BNSPR_TRN3871_SAVE")
    public static GMMap saveTRN3871(GMMap iMap) {
    	GMMap oMap = new GMMap();
        try {
        	//islemin tamamlanip tamamlanmadi�ini kontrol eder.
        	iMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.EVET);
        	GMServiceExecuter.execute("BNSPR_KK_ISLEM_TAMAMLANDI_MI", iMap);

            Session session = DAOSession.getSession("BNSPRDal");

            KkBasvuruTx kkBasvuruTx =
                (KkBasvuruTx) session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                    .uniqueResult();
            if (kkBasvuruTx == null) {
            	kkBasvuruTx = new KkBasvuruTx();
            }

            if("IS_HAVUZU".equals(iMap.getString("ACTION")) || "OUTBOUND".equals(iMap.getString("ACTION"))
            		|| "IS_HAVUZU_BASVURU".equals(iMap.getString("ACTION")) || "OUTBOUND_TFF".equals(iMap.getString("ACTION"))
            		|| "AKTIF_NOKTA".equals(iMap.getString("ACTION")) || "ON_ONAY_BASVURU".equals(iMap.getString("ACTION"))){
            	// get info from the base table if it is outbound save
            	KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
      	
                 kkBasvuruTx.setKartSeviyesi(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_SEVIYESI"), kkBasvuru.getKartSeviyesi()));
                 kkBasvuruTx.setMusteriNo(kkBasvuru.getMusteriNo());
                 kkBasvuruTx.setAsilKartMusteriNo(kkBasvuru.getAsilKartMusteriNo());
                 kkBasvuruTx.setAsilKartNo(kkBasvuru.getAsilKartNo());
                 kkBasvuruTx.setSubeKod(kkBasvuru.getSubeKod());
                 kkBasvuruTx.setBasvuruTarihi(kkBasvuru.getBasvuruTarihi());
                 kkBasvuruTx.setSanalKartVarMi(kkBasvuru.getSanalKartVarMi());
                 kkBasvuruTx.setBayiKod(kkBasvuru.getBayiKod());
                 kkBasvuruTx.setSessionIp(kkBasvuru.getSessionIp());
                 kkBasvuruTx.setOnOnayliMi(kkBasvuru.getOnOnayliMi());
            }
            else if("Y".equals(iMap.getString("IS_FULL_SAVE"))){    // insert all records
            	 kkBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
                 kkBasvuruTx.setBayiKod(iMap.getString("BAYI_KOD"));
                 kkBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                 kkBasvuruTx.setKartSeviyesi(iMap.getString("KREDI_KARTI_SEVIYESI"));
                 kkBasvuruTx.setAsilKartMusteriNo(iMap.getBigDecimal("ASIL_KART_MUSTERI_NO"));
                 kkBasvuruTx.setAsilKartNo(iMap.getString("ASIL_KART_NO"));
                 kkBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
                 kkBasvuruTx.setBasvuruTarihi(Calendar.getInstance().getTime());
                 kkBasvuruTx.setOnOnayliMi(CreditCardServicesUtil.nvl(iMap.getString("ON_ONAYLI_MI"), CreditCardServicesUtil.HAYIR));
                 if("S".equals(iMap.getString("KREDI_KARTI_SEVIYESI"))){
                 	kkBasvuruTx.setSanalKartVarMi("E");
                 }
            }
            
            kkBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruTx.setKanalKod(iMap.getString("KANAL_KOD"));
            //kkBasvuruTx.setKartTipi("V");    // default VISA PY-4278 ile kaldirildi
            kkBasvuruTx.setDurumKod(CreditCardServicesUtil.nvl(iMap.getString("DURUM_KOD"),"BASVURU"));// default basvuru
            // tarih simdilik set edilmedi
            kkBasvuruTx.setKartinUzerineYazilacakIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
            
            if(iMap.containsKey("KART_LIMITI")){
            	
            	 if("0.00".equals(iMap.getString("KART_LIMITI")) 
                 		|| StringUtils.isEmpty(iMap.getString("KART_LIMITI"))){
                 	iMap.put("HATA_NO", new BigDecimal(660));
     				iMap.put("P1", "L�tfen ge�erli bir kart limiti giriniz.");
     				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
                 }
            	
            kkBasvuruTx.setKartLimiti(iMap.getBigDecimal("KART_LIMITI"));
            }
           
            kkBasvuruTx.setNakitKartLimiti(iMap.getBigDecimal("NAKIT_KART_LIMITI"));
            kkBasvuruTx.setEkspressKartLimiti(iMap.getBigDecimal("EKSPRESS_KART_LIMITI"));
            kkBasvuruTx.setUrunTipi(iMap.getString("KART_URUN_TIP"));
            kkBasvuruTx.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
            kkBasvuruTx.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
            kkBasvuruTx.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
            kkBasvuruTx.setEkstreSecimi(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
            kkBasvuruTx.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));
            kkBasvuruTx.setOtomatikOdemeTalimati(iMap.getString("KART_OTOMATIK_ODEME"));
            kkBasvuruTx.setYurtdisiHarcamaEkstresi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
            kkBasvuruTx.setEkKartVarMi(iMap.getString("EK_KART_VAR_MI"));
            kkBasvuruTx.setMusteriGrup(iMap.getString("MUSTERI_GROUP"));
            kkBasvuruTx.setMusteriTip(iMap.getString("MUSTERI_TIPI"));
            kkBasvuruTx.setFinansalTip(iMap.getString("FINANSAL_TIP"));
            kkBasvuruTx.setLogoKod(iMap.getString("LOGO_KODU"));
            kkBasvuruTx.setOtomatikLimitArtis(iMap.getString("OTOMATIK_LIMIT_ARTIS"));
            kkBasvuruTx.setKdhIstiyorMu(iMap.getString("KDH_ISTIYOR_MU"));
            kkBasvuruTx.setEPosta(iMap.getString("EMAIL"));
            session.saveOrUpdate(kkBasvuruTx);
            session.flush();
            
            KkBasvuruKimlikTx kkBasvuruKimlikTx =
                    (KkBasvuruKimlikTx) session.createCriteria(KkBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                        .uniqueResult();
            if (kkBasvuruKimlikTx == null) {
            	kkBasvuruKimlikTx = new KkBasvuruKimlikTx();
            }
            
            if("IS_HAVUZU".equals(iMap.getString("ACTION")) || "OUTBOUND".equals(iMap.getString("ACTION"))
            		|| "IS_HAVUZU_BASVURU".equals(iMap.getString("ACTION")) || "OUTBOUND_TFF".equals(iMap.getString("ACTION"))
            		|| "AKTIF_NOKTA".equals(iMap.getString("ACTION")) || "ON_ONAY_BASVURU".equals(iMap.getString("ACTION"))){
            	// get info from the base table if it is outbound save
            	KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
      	
                 kkBasvuruKimlikTx.setUyrukKod(kkBasvuruKimlik.getUyrukKod());
                 kkBasvuruKimlikTx.setTcKimlikNo(kkBasvuruKimlik.getTcKimlikNo());
                 kkBasvuruKimlikTx.setAd(kkBasvuruKimlik.getAd());
                 kkBasvuruKimlikTx.setIkinciAd(kkBasvuruKimlik.getIkinciAd());
                 kkBasvuruKimlikTx.setSoyad(kkBasvuruKimlik.getSoyad());
                 kkBasvuruKimlikTx.setDogumTar(kkBasvuruKimlik.getDogumTar());
                 kkBasvuruKimlikTx.setDogumYeri(kkBasvuruKimlik.getDogumYeri());
                 kkBasvuruKimlikTx.setBabaAd(kkBasvuruKimlik.getBabaAd());
                 kkBasvuruKimlikTx.setAnneAdi(kkBasvuruKimlik.getAnneAdi());
                 kkBasvuruKimlikTx.setCinsiyet(kkBasvuruKimlik.getCinsiyet());
                 kkBasvuruKimlikTx.setMedeniHal(kkBasvuruKimlik.getMedeniHal());
                 kkBasvuruKimlikTx.setEsTcKimlikNo(kkBasvuruKimlik.getEsTcKimlikNo());
                 kkBasvuruKimlikTx.setAnneKizlik(kkBasvuruKimlik.getAnneKizlik());
                 kkBasvuruKimlikTx.setKimlikSeriNoKps(kkBasvuruKimlik.getKimlikSeriNoKps());
                 kkBasvuruKimlikTx.setKimlikSiraNoKps(kkBasvuruKimlik.getKimlikSiraNoKps());
                 kkBasvuruKimlikTx.setNufusIlKod(kkBasvuruKimlik.getNufusIlKod());
                 kkBasvuruKimlikTx.setMahalleKoy(kkBasvuruKimlik.getMahalleKoy());
                 kkBasvuruKimlikTx.setNufusIlceKod(kkBasvuruKimlik.getNufusIlceKod());
                 kkBasvuruKimlikTx.setCiltNo(kkBasvuruKimlik.getCiltNo());
                 kkBasvuruKimlikTx.setAileSiraNo(kkBasvuruKimlik.getAileSiraNo());
                 kkBasvuruKimlikTx.setBireySiraNo(kkBasvuruKimlik.getBireySiraNo());
                 kkBasvuruKimlikTx.setNufusVerYer(kkBasvuruKimlik.getNufusVerYer());
                 kkBasvuruKimlikTx.setNufusVerTar(kkBasvuruKimlik.getNufusVerTar());
                 kkBasvuruKimlikTx.setNufusVerNedeni(kkBasvuruKimlik.getNufusVerNedeni());
                 kkBasvuruKimlikTx.setKayipKimlikSeriNo(kkBasvuruKimlik.getKayipKimlikSeriNo());
                 kkBasvuruKimlikTx.setKayipKimlikSiraNo(kkBasvuruKimlik.getKayipKimlikSiraNo());
                 kkBasvuruKimlikTx.setKpsYapildi(kkBasvuruKimlik.getKpsYapildi());
                 kkBasvuruKimlikTx.setApsYapildi(kkBasvuruKimlik.getApsYapildi());
            }
            else if("Y".equals(iMap.getString("IS_FULL_SAVE"))){    // insert all records
            	  kkBasvuruKimlikTx.setUyrukKod("TR");
                  kkBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
                  kkBasvuruKimlikTx.setAd(iMap.getString("ADI"));
                  kkBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
                  kkBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
                  kkBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
                  kkBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
                  kkBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
                  kkBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
                  kkBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
                  kkBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
                  kkBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
                  kkBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
                  kkBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
                  kkBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
                  kkBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
                  kkBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
                  kkBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
                  kkBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
                  kkBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
                  kkBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
                  kkBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
                  kkBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
                  kkBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
                  kkBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
                  kkBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
                  kkBasvuruKimlikTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
                  kkBasvuruKimlikTx.setApsYapildi(iMap.getString("APS_YAPILDIMI"));
            }
            
            kkBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
//                kkBasvuruKimlikTx.setMusteriNo(iMap.getBigDecimal("BASVURU_NO"));     // daha sonra atiliyor
            kkBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
            kkBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
            kkBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
            kkBasvuruKimlikTx.setApsBilgileriUyumlumu(iMap.getString("APS_TEYIT"));
            session.saveOrUpdate(kkBasvuruKimlikTx);
            session.flush();
            
                
            KkBasvuruMeslekiBilgiTx kkBasvuruMeslekiBilgiTx =
                    (KkBasvuruMeslekiBilgiTx) session.createCriteria(KkBasvuruMeslekiBilgiTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                        .uniqueResult();
            if (kkBasvuruMeslekiBilgiTx == null) {
            	kkBasvuruMeslekiBilgiTx = new KkBasvuruMeslekiBilgiTx();
            }
            kkBasvuruMeslekiBilgiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruMeslekiBilgiTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
//                    kkBasvuruKimlikTx.setMusteriNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruMeslekiBilgiTx.setOgrenimDurumKod(iMap.getString("OGRENIM_DURUMU"));
            kkBasvuruMeslekiBilgiTx.setMeslekKod(iMap.getString("MESLEK"));
            kkBasvuruMeslekiBilgiTx.setMeslekAciklama(iMap.getString("MESLEK_ACIKLAMA"));
            kkBasvuruMeslekiBilgiTx.setUnvanKod(iMap.getString("UNVANI"));
            kkBasvuruMeslekiBilgiTx.setCalismaSekliKod(iMap.getString("CALISMA_SEKLI"));
            kkBasvuruMeslekiBilgiTx.setCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
            kkBasvuruMeslekiBilgiTx.setFaaliyetAlaniKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
            kkBasvuruMeslekiBilgiTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
            kkBasvuruMeslekiBilgiTx.setVergiDaireIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
            kkBasvuruMeslekiBilgiTx.setVergiDaireAd(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
            kkBasvuruMeslekiBilgiTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
            kkBasvuruMeslekiBilgiTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
            kkBasvuruMeslekiBilgiTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI"));
            kkBasvuruMeslekiBilgiTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
            kkBasvuruMeslekiBilgiTx.setIkametDurumKod(iMap.getString("IKAMET_DURUMU"));
            kkBasvuruMeslekiBilgiTx.setEvdeOturmaSuresi(concatYilAy(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY")));
            
            session.saveOrUpdate(kkBasvuruMeslekiBilgiTx);
            session.flush();

            // Ev adresi kaydet
            KkBasvuruAdresTx kkBasvuruAdresTx =
                (KkBasvuruAdresTx) session.createCriteria(KkBasvuruAdresTx.class).
                add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                add(Restrictions.eq("id.adresKod","E"))
                    .uniqueResult();
            if (kkBasvuruAdresTx == null) {
            	kkBasvuruAdresTx = new KkBasvuruAdresTx();
            }
   
            KkBasvuruAdresTxId kkBasvuruAdresTxId=new KkBasvuruAdresTxId();
            kkBasvuruAdresTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
            kkBasvuruAdresTxId.setAdresKod("E");
            kkBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            kkBasvuruAdresTx.setIlKod(iMap.getString("EV_IL"));
            kkBasvuruAdresTx.setIlceKod(iMap.getString("EV_ILCE"));
            kkBasvuruAdresTx.setAdres(CreditCardServicesUtil.trimNewLine(iMap.getString("EV_ADRESI")));
            kkBasvuruAdresTx.setPostaKod(iMap.getString("EV_POSTA_KODU"));
            if ("E".equals(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"))){
            	kkBasvuruAdresTx.setEkstreAdresi("E");    // Ev ekstre adresi oldu, default hay�r
            }  else{
            	kkBasvuruAdresTx.setEkstreAdresi("H");
            }
            
            if ("E".equals(iMap.getString("TESLIMAT_ADRESI"))) {//Teslimat adresi ev mi
				kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.EVET);
			} else {//degil
				kkBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.HAYIR);
			}
            
            kkBasvuruAdresTx.setId(kkBasvuruAdresTxId);
            setAdressCompleteness(kkBasvuruAdresTx , session);
            session.saveOrUpdate(kkBasvuruAdresTx);
            session.flush();
               
//                // Is adresi kaydet
            if(StringUtils.isNotBlank(iMap.getString("IS_ADRESI"))){
                KkBasvuruAdresTx kkBasvuruAdresTxIs =
                        (KkBasvuruAdresTx) session.createCriteria(KkBasvuruAdresTx.class).
                        add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                        add(Restrictions.eq("id.adresKod","I"))
                            .uniqueResult();
                if (kkBasvuruAdresTxIs == null) {
                	kkBasvuruAdresTxIs = new KkBasvuruAdresTx();
                }
                
                KkBasvuruAdresTxId kkBasvuruAdresTxIdIs=new KkBasvuruAdresTxId();
                kkBasvuruAdresTxIdIs.setTxNo(iMap.getBigDecimal("TRX_NO"));
                kkBasvuruAdresTxIdIs.setAdresKod("I");
                kkBasvuruAdresTxIs.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                kkBasvuruAdresTxIs.setIlKod(iMap.getString("IS_IL"));
                kkBasvuruAdresTxIs.setIlceKod(iMap.getString("IS_ILCE"));
                kkBasvuruAdresTxIs.setAdres(CreditCardServicesUtil.trimNewLine(iMap.getString("IS_ADRESI")));
                kkBasvuruAdresTxIs.setPostaKod(iMap.getString("IS_POSTA_KODU"));
                if ("I".equals(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"))){
                	kkBasvuruAdresTxIs.setEkstreAdresi("E");    // Is ekstre adresi oldu, default hay�r
                } else{
                	kkBasvuruAdresTxIs.setEkstreAdresi("H");    // Is ekstre adresi oldu, default hay�r
                }
                
                if ("I".equals(iMap.getString("TESLIMAT_ADRESI"))) {//Teslimat adresi ev mi
                	kkBasvuruAdresTxIs.setTeslimatAdresiMi(CreditCardServicesUtil.EVET);
				} else {//degil
					kkBasvuruAdresTxIs.setTeslimatAdresiMi(CreditCardServicesUtil.HAYIR);
				}
                
                
    			
                kkBasvuruAdresTxIs.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
                kkBasvuruAdresTxIs.setId(kkBasvuruAdresTxIdIs);
                setAdressCompleteness(kkBasvuruAdresTxIs , session);
                session.saveOrUpdate(kkBasvuruAdresTxIs);
                
                session.flush();
            }
//                //   ev telefonu kaydet
            if(StringUtils.isNotBlank(iMap.getString("EV_TEL_KOD")) && StringUtils.isNotBlank(iMap.getString("EV_TEL_NO"))){
                KkBasvuruTelefonTx kkBasvuruTelefonTx =
                        (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
                        add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                        add(Restrictions.eq("id.tip", "1"))
                            .uniqueResult();
                if (kkBasvuruTelefonTx == null) {
                	kkBasvuruTelefonTx = new KkBasvuruTelefonTx();
                }
                KkBasvuruTelefonTxId  kkBasvuruTelefonTxId=new KkBasvuruTelefonTxId();
                kkBasvuruTelefonTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                kkBasvuruTelefonTxId.setTip("1");
                kkBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                kkBasvuruTelefonTx.setAlanKod(iMap.getString("EV_TEL_KOD"));
                kkBasvuruTelefonTx.setNumara(iMap.getString("EV_TEL_NO"));
                kkBasvuruTelefonTx.setUlkeKod("90");
               
                kkBasvuruTelefonTx.setId(kkBasvuruTelefonTxId);
                session.saveOrUpdate(kkBasvuruTelefonTx);
                session.flush();
            
            }
            
                // Is telefonu kaydet
            if(StringUtils.isNotBlank(iMap.getString("IS_TEL_KOD")) && StringUtils.isNotBlank(iMap.getString("IS_TEL_NO"))){
                KkBasvuruTelefonTx kkBasvuruTelefonTxIs =
                        (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
                        add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                        add(Restrictions.eq("id.tip", "2"))
                            .uniqueResult();
                if (kkBasvuruTelefonTxIs == null) {
                	kkBasvuruTelefonTxIs = new KkBasvuruTelefonTx();
                }
                  
                KkBasvuruTelefonTxId  kkBasvuruTelefonTxIdIs=new KkBasvuruTelefonTxId();
                kkBasvuruTelefonTxIdIs.setTxNo(iMap.getBigDecimal("TRX_NO"));
                kkBasvuruTelefonTxIdIs.setTip("2");
                kkBasvuruTelefonTxIs.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                kkBasvuruTelefonTxIs.setAlanKod(iMap.getString("IS_TEL_KOD"));
                kkBasvuruTelefonTxIs.setNumara(iMap.getString("IS_TEL_NO"));
                kkBasvuruTelefonTxIs.setUlkeKod("90");
               
                kkBasvuruTelefonTxIs.setId(kkBasvuruTelefonTxIdIs);
                session.saveOrUpdate(kkBasvuruTelefonTxIs);
                session.flush();
            
            }
            if("IS_HAVUZU".equals(iMap.getString("ACTION")) || "OUTBOUND".equals(iMap.getString("ACTION"))
            		|| "IS_HAVUZU_BASVURU".equals(iMap.getString("ACTION")) || "OUTBOUND_TFF".equals(iMap.getString("ACTION"))
            		|| "AKTIF_NOKTA".equals(iMap.getString("ACTION")) || "ON_ONAY_BASVURU".equals(iMap.getString("ACTION"))){
            	// get info from the base table if it is outbound save
            	KkBasvuruTelefon kkBasvuruTelefonCep = (KkBasvuruTelefon) session.createCriteria(KkBasvuruTelefon.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))). add(Restrictions.eq("id.tip", "3")).uniqueResult();
            	
            	KkBasvuruTelefonTx kkBasvuruTelefonTxCep = new KkBasvuruTelefonTx();
                KkBasvuruTelefonTxId  kkBasvuruTelefonTxIdCep=new KkBasvuruTelefonTxId();
                kkBasvuruTelefonTxIdCep.setTxNo(iMap.getBigDecimal("TRX_NO"));
                kkBasvuruTelefonTxIdCep.setTip("3");
                kkBasvuruTelefonTxCep.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                kkBasvuruTelefonTxCep.setUlkeKod(kkBasvuruTelefonCep.getUlkeKod());
                kkBasvuruTelefonTxCep.setAlanKod(kkBasvuruTelefonCep.getAlanKod());
                kkBasvuruTelefonTxCep.setNumara(kkBasvuruTelefonCep.getNumara());
               
                kkBasvuruTelefonTxCep.setId(kkBasvuruTelefonTxIdCep);
                session.saveOrUpdate(kkBasvuruTelefonTxCep);
                session.flush();
            }
            else if("Y".equals(iMap.getString("IS_FULL_SAVE"))){    // insert all records
            	 KkBasvuruTelefonTx kkBasvuruTelefonTxCep =
                         (KkBasvuruTelefonTx) session.createCriteria(KkBasvuruTelefonTx.class).
                         add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).
                         add(Restrictions.eq("id.tip", "3"))
                             .uniqueResult();
                 if (kkBasvuruTelefonTxCep == null) {
                	 kkBasvuruTelefonTxCep = new KkBasvuruTelefonTx();
                 }
                
                 KkBasvuruTelefonTxId kkBasvuruTelefonTxIdCep = new KkBasvuruTelefonTxId();
                 kkBasvuruTelefonTxIdCep.setTxNo(iMap.getBigDecimal("TRX_NO"));
                 kkBasvuruTelefonTxIdCep.setTip("3");   // GSM
                 kkBasvuruTelefonTxCep.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                 kkBasvuruTelefonTxCep.setUlkeKod(iMap.getString("CEP_ULKE_KOD", "90"));
                 kkBasvuruTelefonTxCep.setAlanKod(iMap.getString("CEP_TEL_KOD"));
                 kkBasvuruTelefonTxCep.setNumara(iMap.getString("CEP_TEL_NO"));
                 kkBasvuruTelefonTxCep.setId(kkBasvuruTelefonTxIdCep);
                 session.saveOrUpdate(kkBasvuruTelefonTxCep);
                 session.flush();
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
 
    @GraymoundService("BNSPR_TRN3871_START_TRANSACTION")
    public static GMMap startTransaction(GMMap iMap) {
        GMMap oMap = new GMMap();
        iMap.put("TRX_NAME", "3871");
        oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
        return oMap;
    }
    
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_TRN3871_GET_APS_INFO")
    public static GMMap getAdresBilgileriInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            List<KkBasvuruTx> basvuruList = session.createCriteria(KkBasvuruTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("txNo")).list();
            GnlMusteriApsTx gnlMusteriApsTx = null;
            for (KkBasvuruTx basvuru : basvuruList) {
                gnlMusteriApsTx = (GnlMusteriApsTx) session.createCriteria(GnlMusteriApsTx.class).add(Restrictions.eq("txNo", basvuru.getTxNo())).uniqueResult();
                if (gnlMusteriApsTx != null) break;
            }
            if (gnlMusteriApsTx != null) {
                oMap.put("ADRES_NO", gnlMusteriApsTx.getApsAdresNo());

                if (gnlMusteriApsTx.getApsAdresNo() != null) oMap.put("F_APS", "E");
                else oMap.put("F_APS", "H");

                oMap.put("APS_BUCAK", gnlMusteriApsTx.getApsBucak());
                oMap.put("APS_BUCAK_KOD", gnlMusteriApsTx.getApsBucakKod());
                oMap.put("APS_CSBM", gnlMusteriApsTx.getApsCsbm());
                oMap.put("APS_CSBM_KODU", gnlMusteriApsTx.getApsCsbmKodu());
                oMap.put("APS_DIS_KAPI_NO", gnlMusteriApsTx.getApsDisKapiNo());
                oMap.put("APS_IC_KAPI_NO", gnlMusteriApsTx.getApsIcKapiNo());
                oMap.put("APS_IL", gnlMusteriApsTx.getApsIl());
                oMap.put("APS_ILCE", gnlMusteriApsTx.getApsIlce());
                oMap.put("APS_ILCE_KODU", gnlMusteriApsTx.getApsIlceKodu());
                oMap.put("APS_IL_KODU", gnlMusteriApsTx.getApsIlKodu());
                oMap.put("APS_KOY", gnlMusteriApsTx.getApsKoy());
                oMap.put("APS_KOY_KAYIT_NO", gnlMusteriApsTx.getApsKoyKayitNo());
                oMap.put("APS_KOY_KOD", gnlMusteriApsTx.getApsKoyKod());
                oMap.put("APS_MAHALLE", gnlMusteriApsTx.getApsMahalle());
                oMap.put("APS_MAHALLE_KOD", gnlMusteriApsTx.getApsMahalleKod());
                oMap.put("F_APS_TEYIT", "E".equals(gnlMusteriApsTx.getFApsTeyit()) ? true : false);

            }

        } catch (Exception e) {
            ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    @GraymoundService("BNSPR_TRN3871_SAVE_KONTAK_MUSTERI_GERCEK")
    public static GMMap saveContactMusteriGercek(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        PreparedStatement pStmt = null;
        ResultSet rSet = null;
        BigDecimal customerNo = null;
        
        try {

            String kanalKod = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMap).getString("KANAL_KOD");

            conn = DALUtil.getGMConnection();
            pStmt = conn.prepareStatement("select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr where kod = ?"); // bunu sp isteyelim
            pStmt.setString(1, kanalKod);
            rSet = pStmt.executeQuery();
            
            GMMap customerMap = new GMMap();
            customerMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
            customerMap.put("MUSTERI_TURUNE_GORE_MI", true);
            
            customerNo = GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", customerMap).getBigDecimal("CUSTOMER_NO");
            if(!(customerNo == null || customerNo.equals(BigDecimal.ZERO))){
            	customerMap.put("MUSTERI_NO", customerNo);
            	customerMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", customerMap));
            }
            
            //PY-9883 - Gercek musteriler icin iki kez havuza dusme islemi engellenmesi icin 
            //ilk ekrandaki(kisa basvurudaki) guncelleme islemleri yapilmasin sitendi
            if ("3870".equals(iMap.getString("ISLEM_KODU")) && "M".equals(customerMap.getString("MUSTERI_KONTAKT"))) {
            	oMap.put("MUSTERI_NO", customerMap.getString("MUSTERI_NO"));
            	return oMap;
            }

            //PY-4110
            customerMap.put("ANNE_KIZLIK_SOYADI",iMap.getString("ANNE_KIZLIK_SOYADI"));
            customerMap.put("MESLEK_KOD",nvl(iMap.getString("MESLEK_KOD"), customerMap.getString("MESLEK_KOD")));
            customerMap.put("EGITIM_KOD",nvl(iMap.getString("EGITIM_KOD"), customerMap.getString("EGITIM_KOD")));
            customerMap.put("CALISMA_SEKLI",nvl(iMap.getString("CALISMA_SEKLI"), customerMap.getString("CALISMA_SEKLI")));
            customerMap.put("UNVAN_KOD",iMap.getString("UNVAN_KOD"));
            customerMap.put("TCKNO_IN",iMap.getString("TCKNO_IN"));
            if (StringUtils.isNotBlank(iMap.getString("TCKNO_OUT"))) {
            	customerMap.put("TCKNO_OUT",iMap.getString("TCKNO_OUT"));
            }
            customerMap.put("ADK_MUSTERISIMI","H");
            customerMap.put("MUSTERI_GRUP_KOD","1");
            customerMap.put("KIZLIK_SOYADI",nvl(iMap.getString("ONCEKI_SOYADI"), customerMap.getString("KIZLIK_SOYADI")));
            //
            
            customerMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));

            customerMap.put("ISIM", nvl(iMap.getString("ADI"), customerMap.getString("ADI")));
            customerMap.put("SOYADI", nvl(iMap.getString("SOYADI"), customerMap.getString("SOYADI")));
            customerMap.put("ANNE_ADI", nvl(iMap.getString("ANNE_ADI"), customerMap.getString("ANNE_ADI")));
            customerMap.put("BABA_ADI", nvl(iMap.getString("BABA_ADI"), customerMap.getString("BABA_ADI")));
            customerMap.put("IKINCI_ISIM", nvl(iMap.getString("IKINCI_ADI"), customerMap.getString("IKINCI_ADI")));
            customerMap.put("UYRUK_KOD", "TR");
            if (!StringUtils.isNotBlank(customerMap.getString("TICARI_UNVAN"))) customerMap.put("TICARI_UNVAN", nvl(iMap.getString("UNVAN"), customerMap.getString("TICARI_UNVAN")));

            if (StringUtils.isNotBlank(iMap.getString("CINSIYET"))) {
                customerMap.put("CINSIYET_KOD", iMap.getString("CINSIYET").substring(0, 1));
            }

            if (StringUtils.isNotBlank(iMap.getString("MEDENI_HAL"))) {
                customerMap.put("MEDENI_HAL", "E".equals(iMap.getString("MEDENI_HAL").substring(0, 1)) ? "1" : "2");
            }

            customerMap.put("DOGUM_YERI", nvl(iMap.getString("DOGUM_YERI"), customerMap.getString("DOGUM_YERI")));
            customerMap.put("DOGUM_TARIHI", nvl(iMap.getDate("DOGUM_TARIHI"), customerMap.getDate("DOGUM_TARIHI")));
            //customerMap.put("DOGUM_IL_KOD", nvl(iMap.getString("DOGUM_IL_KOD"), customerMap.getString("DOGUM_IL_KOD")));
            //customerMap.put("DOGUM_ILCE_KOD", nvl(iMap.getString("DOGUM_ILCE_KOD"), customerMap.getString("DOGUM_ILCE_KOD")));

            if (StringUtils.isNotBlank(iMap.getString("KIMLIK_SERI_NO")) && StringUtils.isNotBlank(iMap.getString("KIMLIK_SIRA_NO"))) {
                customerMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_NO") + iMap.getString("KIMLIK_SIRA_NO"));
            } else {
                customerMap.put("NUFUS_CUZDANI_SERI_NO", customerMap.getString("NUF_SERI_NO"));
            }

            if (!StringUtils.isEmpty(iMap.getString("NUFUS_VERILIS_TARIHI"))) {
                customerMap.put("VERILDIGI_TARIH", iMap.getDate("NUFUS_VERILIS_TARIHI"));
            } else {
                customerMap.put("VERILDIGI_TARIH", customerMap.getDate("NUF_VERILDIGI_TARIH"));
            }
            
            customerMap.put("NUF_VERILIS_NEDENI", nvl(iMap.getString("NUF_VERILIS_NEDENI"), customerMap.getString("NUF_VERILIS_NEDENI")));
            customerMap.put("VERILDIGI_YER", nvl(iMap.getString("NUF_VERILDIGI_YER"), customerMap.getString("NUF_VERILDIGI_YER")));
            customerMap.put("IL_KOD", nvl(iMap.getString("NUFUS_IL_KOD"), customerMap.getString("NUF_IL_KOD")));
            customerMap.put("ILCE_KOD", nvl(iMap.getString("NUFUS_ILCE_KOD"), customerMap.getString("NUF_ILCE_KOD")));
            customerMap.put("CILT_NO", nvl(iMap.getString("NUFUS_CILT_NO"), customerMap.getString("NUF_CILT_NO")));
            customerMap.put("AILE_SIRA_NO", nvl(iMap.getString("NUFUS_AILE_SIRA_NO"), customerMap.getString("NUF_AILE_SIRA_NO")));
            customerMap.put("SIRA_NO", nvl(iMap.getString("NUFUS_SIRA_NO"), customerMap.getString("NUF_SIRA_NO")));
            customerMap.put("MAHALLE_KOY", nvl(iMap.getString("NUFUS_MAHALLE"), customerMap.getString("NUF_MAHALLE_KOY")));
            if(!"@".equals(iMap.getString("EPOSTA")))
            	customerMap.put("EMAIL_KISISEL", nvl(iMap.getString("EPOSTA"), customerMap.getString("EMAIL_KISISEL")));
            else
            	customerMap.put("EMAIL_KISISEL", customerMap.getString("EMAIL_KISISEL"));
            
            GMMap adresMap = new GMMap();

            if (StringUtils.isNotBlank(iMap.getString("EV_ADRESI")) && !iMap.getBoolean("APS_TEYIT_YAPILDI_MI")) {

                adresMap.put("ADRES_KOD", "E");
                adresMap.put("ADRES", iMap.getString("EV_ADRESI"));
                if (StringUtils.isNotBlank(iMap.getString("IS_ADRESI"))) {
                	adresMap.put("EXTRE_ADRES_KOD_F", "H");
                }
                else{
                	adresMap.put("EXTRE_ADRES_KOD_F", "E");
                }
                
                adresMap.put("ULKE_KOD", "TR");
                adresMap.put("POSTA_KOD", iMap.getString("EV_POSTA_KOD"));
                adresMap.put("ADRES_IL_KOD", iMap.getString("EV_ADRES_IL"));
                adresMap.put("ADRES_ILCE_KOD", iMap.getString("EV_ADRES_ILCE"));
                customerMap.put("ADRES_LIST", customerMap.getSize("ADRES_LIST"), adresMap);

            } else if (StringUtils.isNotBlank(iMap.getString("EV_ADRESI")) && iMap.getBoolean("APS_TEYIT_YAPILDI_MI")) {

                StringBuilder sb = new StringBuilder();
                sb.append(addressAppender(iMap.getString("APS_BUCAK")));
                sb.append(addressAppender(iMap.getString("APS_CSBM")));
                sb.append(addressAppender(iMap.getString("APS_DIS_KAPI_NO"), "D�� Kap� No:"));
                sb.append(addressAppender(iMap.getString("APS_IC_KAPI_NO"), "�� Kap� No:"));
                sb.append(addressAppender(iMap.getString("APS_MAHALLE"), true));

                adresMap.put("ADRES_KOD", "E");
                adresMap.put("ADRES", sb.toString().trim());
                adresMap.put("ULKE_KOD", "TR");
                if(StringUtils.isNotBlank(iMap.getString("APS_IL"))){
                	adresMap.put("ADRES_IL_KOD", String.format("%03d", new Integer(iMap.getString("APS_IL"))));
                }
                adresMap.put("ADRES_ILCE_KOD", iMap.getString("APS_ILCE"));
                if (StringUtils.isNotBlank(iMap.getString("IS_ADRESI"))) {
                	adresMap.put("EXTRE_ADRES_KOD_F", "H");
                }
                else{
                	adresMap.put("EXTRE_ADRES_KOD_F", "E");
                }
                customerMap.put("ADRES_LIST", customerMap.getSize("ADRES_LIST"), adresMap);
                customerMap.put("F_APS_TEYIT", "true");
            }
            GMMap adresIsMap = new GMMap();
            if (StringUtils.isNotBlank(iMap.getString("IS_ADRESI"))) {
            	adresIsMap.put("ADRES_KOD", "I");
            	adresIsMap.put("ISYERI_UNVANI", iMap.getString("ISYERI_ADI"));
            	adresIsMap.put("EXTRE_ADRES_KOD_F", "E");
            	adresIsMap.put("ADRES", iMap.getString("IS_ADRESI"));
            	adresIsMap.put("ULKE_KOD", "TR");
            	adresIsMap.put("POSTA_KOD", iMap.getString("IS_POSTA_KOD"));
            	adresIsMap.put("ADRES_IL_KOD", iMap.getString("IS_ADRES_IL"));
            	adresIsMap.put("ADRES_ILCE_KOD", iMap.getString("IS_ADRES_ILCE"));
                customerMap.put("ADRES_LIST", customerMap.getSize("ADRES_LIST"), adresIsMap);
            }
            
            GMMap telefonCepMap = new GMMap();
            if (StringUtils.isNotBlank(iMap.getString("CEP_TEL_NO"))) {
            	telefonCepMap.put("TEL_TIP", "3");
            	telefonCepMap.put("ULKE_KODU", nvl(iMap.getString("CEP_ULKE_KOD"), customerMap.getString("TELEFON", 0, "ULKE_KOD")));
            	telefonCepMap.put("ALAN_KOD", nvl(iMap.getString("CEP_TEL_KOD"), customerMap.getString("TELEFON", 0, "ALAN_KOD")));
            	telefonCepMap.put("TEL_NO", nvl(iMap.getString("CEP_TEL_NO"), customerMap.getString("TELEFON", 0, "TEL_NO")));
            	telefonCepMap.put("OTPMI", false);
                customerMap.put("TELEFON_LIST", customerMap.getSize("TELEFON_LIST"), telefonCepMap);
            }
            GMMap telefonEvMap = new GMMap();
            if(StringUtils.isNotBlank(iMap.getString("EV_TEL_NO"))){
            	telefonEvMap.put("TEL_TIP", "1");
            	telefonEvMap.put("ULKE_KODU", "90");
            	telefonEvMap.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
            	telefonEvMap.put("TEL_NO", iMap.getString("EV_TEL_NO"));
                customerMap.put("TELEFON_LIST", customerMap.getSize("TELEFON_LIST"), telefonEvMap);
            }
            GMMap telefonIsMap = new GMMap();
            if(StringUtils.isNotBlank(iMap.getString("IS_TEL_NO"))){
            	telefonIsMap.put("TEL_TIP", "2");
            	telefonIsMap.put("ULKE_KODU", "90");
            	telefonIsMap.put("ALAN_KOD", iMap.getString("IS_TEL_KOD"));
            	telefonIsMap.put("TEL_NO", iMap.getString("IS_TEL_NO"));
                customerMap.put("TELEFON_LIST", customerMap.getSize("TELEFON_LIST"), telefonIsMap);
            }


            customerMap.put("TRX_ONAYSIZ_ISLEM", "E");
            if (StringUtils.isNotBlank(customerMap.getString("MUSTERI_NO")) && StringUtils.isNotBlank(customerMap.getString("TC_KIMLIK_NO"))) { //Gercek Guncelle
            	try
                {
	                GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerMap);
	                oMap.put("MUSTERI_NO", customerMap.getString("MUSTERI_NO"));
                } catch (Exception e) {
                	// TODO: handle exception
                }
            } else if (StringUtils.isNotBlank(customerMap.getString("TC_KIMLIK_NO"))) {//Gercek Yarat
                customerMap.remove("MUSTERI_NO");
                customerMap.put("KAZANIM_KANALI", kanalKod);
                if ("40".equals(kanalKod)) {
                	customerMap.put("KAZANIM_URUNU", "TFFKART");
                } else {
                	customerMap.put("KAZANIM_URUNU", "KREDKART");
                }
                customerMap.put("KANAL_KODU", iMap.getString("KANAL_ALT_KOD"));
                customerMap.put("BAGLI_KANAL_GRUBU", kanalKod);
                customerMap.put("MUSTERI_TIPI_KOD", "G");
                customerMap.put("MUSTERI_SEGMENTI", "N");
                customerMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
                customerMap.put("YERLESIM_KOD", "I");
                customerMap.put("PROFIL_KOD", "1");
                customerMap.put("HESAP_UCRETI_F", "H");
                customerMap.put("YATIRIM_EKSTRESI", "H");
                customerMap.put("MUSTERIYI_KAZANDIRAN", "127");
                customerMap.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
                customerMap.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", customerMap.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
                try
                {
	                GMMap sMap = GMServiceExecuter.call("BNSPR_CUST_CREATE_GERCEK_MUSTERI", customerMap);
	                oMap.put("MUSTERI_NO", sMap.getString("MUSTERI_NO"));
	                oMap.put("MUSTERI_YARATMA_TX_NO", sMap.getString("MUSTERI_YARAT_TX_NO"));
                } catch (Exception e) {
                	// TODO: handle exception
                }
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(pStmt);
            GMServerDatasource.close(conn);
        }
    }

    public static <T> T nvl(T a, T b) {
        if (a instanceof String) return StringUtils.isBlank((String) a) ? b : a;
        return a == null ? b : a;
    }

    private static String addressAppender(String addressElement) {
        return addressAppender(addressElement, null, false);
    }

    private static String addressAppender(String addressElement, boolean lastElement) {
        return addressAppender(addressElement, null, lastElement);
    }

    private static String addressAppender(String addressElement, String prefix) {
        return addressAppender(addressElement, prefix, false);
    }

    private static String addressAppender(String addressElement, String prefix, boolean lastElement) {
        if (StringUtils.isNotBlank(addressElement)) {
            if (StringUtils.isNotBlank(prefix)) {
                addressElement = prefix + addressElement;
            }
            if (!lastElement) {
                addressElement = addressElement + " ";
            }
        } else {
            addressElement = "";
        }
        return addressElement;
    }
    
    //---------------------------------------------------------------------
  	//******************************************************* IS HAVUZU SERVISLERI
  	//---------------------------------------------------------------------
    /** Verilen basvuru numarasina ait basvurunun bilgilerini ve
     * basvuru sahibine ait kimlik bilgilerini getirir.
  	 * 
  	 * @param iMap - BASVURU_NO
  	 * @return oMap - Basvuru Bilgileri
  	 */
    @GraymoundService("BNSPR_TRN3871_GET_BASVURU_HEPSI")
  	public static GMMap getBasvuruBilgiHepsi(GMMap iMap) {
    	//initial variables
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
				
		try {
            Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

            //Basvuru Bilgileri
            KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
            if (kkBasvuru != null) {
            	oMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
                oMap.put("KART_SEVIYESI", kkBasvuru.getKartSeviyesi());
                oMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
                oMap.put("ASIL_KART_NO", kkBasvuru.getAsilKartNo());
                oMap.put("BASVURU_TARIHI", kkBasvuru.getBasvuruTarihi());
                oMap.put("DURUM_KOD", kkBasvuru.getDurumKod());
                oMap.put("ASIL_KART_MUSTERI_NO", kkBasvuru.getAsilKartMusteriNo());
                oMap.put("KANAL_KOD", kkBasvuru.getKanalKod());
                oMap.put("KART_LIMITI", kkBasvuru.getKartLimiti());
                if(kkBasvuru.getAsilKartMusteriNo() != null){
    	            KkBasvuru kkBasvuruAsilKart = (KkBasvuru) session.createCriteria(KkBasvuru.class)
    	            		.add(Restrictions.eq("musteriNo", kkBasvuru.getAsilKartMusteriNo()))
    	            		.add(Restrictions.or(Restrictions.isNull("kartTipi"), Restrictions.eq("kartTipi", "KK")))
    	            		.uniqueResult();
    	            if(kkBasvuruAsilKart != null){
    	            	 KkBasvuruKimlik kkBasvuruKimlikAsilKart = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", kkBasvuruAsilKart.getBasvuruNo())).uniqueResult();
    	                 if(kkBasvuruKimlikAsilKart != null){
    	     	            oMap.put("ASIL_KART_MUSTERI_ADI", kkBasvuruKimlikAsilKart.getAd() + " " +
    	     	            		 (kkBasvuruKimlikAsilKart.getIkinciAd() == null ? "" : kkBasvuruKimlikAsilKart.getIkinciAd()+ " " )+ kkBasvuruKimlikAsilKart.getSoyad());
    	                 }
    	            }
                }
            }
            
            //Kimlik Bilgileri
            KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, basvuruNo);
            if (kkBasvuruKimlik !=null) {
            	//Save Kimlik
            	oMap.put("TC_KIMLIK_NO", kkBasvuruKimlik.getTcKimlikNo());
            	oMap.put("ADI", kkBasvuruKimlik.getAd());
            	oMap.put("IKINCI_ADI", kkBasvuruKimlik.getIkinciAd());
            	oMap.put("SOYADI", kkBasvuruKimlik.getSoyad());
            	oMap.put("DOGUM_YERI", kkBasvuruKimlik.getDogumYeri());
            	oMap.put("DOGUM_TARIHI", kkBasvuruKimlik.getDogumTar());
            	oMap.put("DOGUM_TARIHI_STR", new SimpleDateFormat("dd/MM/yyyy").format(kkBasvuruKimlik.getDogumTar()));
            	oMap.put("BABA_ADI", kkBasvuruKimlik.getBabaAd());
            	oMap.put("ES_TCKN", kkBasvuruKimlik.getEsTcKimlikNo());
            	oMap.put("ANNE_ADI", kkBasvuruKimlik.getAnneAdi());
                oMap.put("CINSIYET", kkBasvuruKimlik.getCinsiyet());
                oMap.put("MEDENI_HAL", kkBasvuruKimlik.getMedeniHal());
                oMap.put("KIMLIK_SERI_NO_KPS", kkBasvuruKimlik.getKimlikSeriNoKps());
                oMap.put("KIMLIK_SIRA_NO_KPS", kkBasvuruKimlik.getKimlikSiraNoKps());
                oMap.put("NUFUS_IL_KOD", kkBasvuruKimlik.getNufusIlKod());
                oMap.put("NUFUS_ILCE_KOD", kkBasvuruKimlik.getNufusIlceKod());
                oMap.put("NUFUS_CILT_NO", kkBasvuruKimlik.getCiltNo());
                oMap.put("NUFUS_AILE_SIRA_NO", kkBasvuruKimlik.getAileSiraNo());
                oMap.put("NUFUS_SIRA_NO", kkBasvuruKimlik.getBireySiraNo());
                oMap.put("NUFUS_VERILIS_TARIHI", kkBasvuruKimlik.getNufusVerTar());
                oMap.put("NUFUS_VERILDIGI_YER", kkBasvuruKimlik.getNufusVerYer());
                oMap.put("NUFUS_VERILIS_NEDENI", kkBasvuruKimlik.getNufusVerNedeni());
                oMap.put("NUFUS_MAHALLE", kkBasvuruKimlik.getMahalleKoy());
                oMap.put("KAYIP_CUZDAN_NO", kkBasvuruKimlik.getKayipKimlikSiraNo());
                oMap.put("KAYIP_CUZDAN_SERI", kkBasvuruKimlik.getKayipKimlikSeriNo());
                oMap.put("KPS_YAPILDIMI", CreditCardServicesUtil.nvl(kkBasvuruKimlik.getKpsYapildi(), CreditCardServicesUtil.HAYIR));
                oMap.put("APS_YAPILDIMI", "H");
                oMap.put("KPS_YOK_MU", CreditCardServicesUtil.HAYIR);
                //Save Kontakt
                oMap.put("ONCEKI_SOYAD", kkBasvuruKimlik.getOncekiSoyad());
            }
            
            //Telefon Bilgileri
            KkBasvuruTelefonId id = new KkBasvuruTelefonId();
            id.setBasvuruNo(basvuruNo);
            id.setTip("3");
            
            KkBasvuruTelefon kkBasvuruTelefon = (KkBasvuruTelefon) session.get(KkBasvuruTelefon.class, id);
            if (kkBasvuruTelefon !=null) {
            	 oMap.put("CEP_TEL_ALAN_KOD", kkBasvuruTelefon.getAlanKod());
                 oMap.put("CEP_TEL_NUMARA", kkBasvuruTelefon.getNumara());
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
		
		return oMap;
    }
    
    //---------------------------------------------------------------------
  	//******************************************************* KART KONTROL SERVISLERI
  	//---------------------------------------------------------------------
    /** Verilen i�lem numarasina ait i�lemin tamamlanip tamamlanmadi�ini kontrol eder.
	 * 
	 * @param iMap - TRX_NO, BASVURU_NO, TC_KIMLIK_NO, HATA_VERILECEK_MI
	 * @return oMap - DEVAM -> E:Hata Yok|H:Hata Var, HATA_MESAJI
	 */
	@GraymoundService("BNSPR_3871_BASVURU_ISLENSIN_KONTROL")
	public static GMMap basvuruIslenebilirMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String devam = CreditCardServicesUtil.HAYIR;
		
		try {
			//Basvuruya ait islem tamamlandi mi?
			oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_ISLEM_TAMAMLANDI_MI", iMap));
			
			//Tamamlanmadi ise ayni basvuruya ait farkli tckn girisi mi var
			if (CreditCardServicesUtil.HAYIR.equals(oMap.getString("ISLEM_TAMAMLANDI_MI"))) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_KONTROL_AYNI_BASVURU_FARKLI_TCKN", iMap));
				
				//Kayit var mi?
				if (CreditCardServicesUtil.HAYIR.equals(oMap.getString("BASVURU_VAR_MI"))) {
					devam = CreditCardServicesUtil.EVET;
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
        }
		
		oMap.put("DEVAM", devam);
		return oMap;
	}
	
    /** Verilen i�lem numarasina ait i�lemin tamamlanip tamamlanmadi�ini kontrol eder.
	 * 
	 * @param iMap - TRX_NO, HATA_VERILECEK_MI
	 * @return oMap - ISLEM_TAMAMLANDI_MI -> E:Tamamlandi|H:Tamamlanmadi, HATA_MESAJI
	 */
	@GraymoundService("BNSPR_KK_ISLEM_TAMAMLANDI_MI")
	public static GMMap isIslemTamamlandi(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call pkg_tx.Islem_tamamlanmis_mi(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1 , Types.INTEGER);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
            
            int isIslemTamamlandi = stmt.getInt(1);// 0 tamamlandi, 1 tamamlanmadi
            if (isIslemTamamlandi == 0) {
            	oMap.put("ISLEM_TAMAMLANDI_MI", CreditCardServicesUtil.EVET);
            	if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILECEK_MI"))) {
            		CreditCardServicesUtil.raiseGMError("2968");
            	} else {
            		iMap.put("MESSAGE_NO", "2968");
					oMap.put("HATA_MESAJI", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
            	}
            } else {
            	oMap.put("ISLEM_TAMAMLANDI_MI", CreditCardServicesUtil.HAYIR);
            }
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
				
		return oMap;
	}
	
	/** Verilen basvuru numarasina ait tx tablolarinda baska aktif kayit var mi kontrolu yapar.
	 * Kontrolu TCKN ile yapar.
	 * 
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO, HATA_VERILECEK_MI
	 * @return oMap - BASVURU_VAR_MI -> E:Tamamlandi|H:Tamamlanmadi, HATA_MESAJI
	 */
	@GraymoundService("BNSPR_KK_KONTROL_AYNI_BASVURU_FARKLI_TCKN")
	public static GMMap ayniBasvuruFarkliTcknKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call pkg_trn3871.ayni_basvuru_farkli_tckn_kntl(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1 , Types.INTEGER);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("BASVURU_NO"));
            stmt.setString(3 , iMap.getString("TC_KIMLIK_NO"));
            stmt.execute();
            
            int kayitSayisi = stmt.getInt(1);//Kayit sayisi
            if (kayitSayisi == 0) {//Yok
            	oMap.put("BASVURU_VAR_MI", CreditCardServicesUtil.HAYIR);
            } else {//Var
            	oMap.put("BASVURU_VAR_MI", CreditCardServicesUtil.EVET);
            	if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILECEK_MI"))) {
            		CreditCardServicesUtil.raiseGMError("2969");//"ba�vurunun tckn si farkl�d�r. yeni tckn ile ba�vuru girmek i�in men�den tekrar se�im yap�n�z"
            	} else {
            		iMap.put("MESSAGE_NO", "2969");
					oMap.put("HATA_MESAJI", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
            	}
            }
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
				
		return oMap;
	}

    //---------------------------------------------------------------------
  	//******************************************************* KART BASIM SERVISLERI
  	//---------------------------------------------------------------------
  	/** Basvuru islemi sonunda basvuru basim asamasinda ise karti basima gondermek icin gerekli servisler cagrilir
  	 * ve basvuru sahibine bilgilendirme amaciyla sms atilir.
  	 * 
  	 * @param iMap - ISLEM_NO
  	 */
  	@GraymoundService("BNSPR_TRN3871_AFTER_APPROVAL")
  	public static GMMap afterApproval(GMMap iMap) {
  		GMMap oMap = new GMMap();
  		GMMap sorguMap = new GMMap();
		
		try {
			//Islem numarasi verilen basvurunun giris bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuruTx kkBasvuruTx = (KkBasvuruTx)
					session.get(KkBasvuruTx.class, iMap.getBigDecimal("ISLEM_NO"));
			//Basvuru girisi islemi tamamlanmissa
  			if (kkBasvuruTx != null) {
  				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkBasvuruTx.getBasvuruNo());
  				if (kkBasvuru != null) {
  					session.refresh(kkBasvuru);
  					//HUNTER durumunda ise sorguyu yap
  					boolean isHunterBasim = false;
  					if ("HUNTER".equals(kkBasvuru.getDurumKod())) {
  	  					sorguMap.clear();
	  	  				sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
	  	  				sorguMap.put("BASVURU_TIPI", "KK");
	  	  				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_HUNTER_SEND_APPL_INFO", sorguMap));
	  	  				if ("ACCEPT".equals(sorguMap.getString("HUNTER_RESULT"))) {
	  	  					sorguMap.clear();
	  	  					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
	  	  					sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
	  	  					sorguMap.put("DURUM_KOD", "BASIM");
	  	  					sorguMap.put("ISLEM_ACIKLAMA", sorguMap.getString("HUNTER_RESULT"));
	  	  					sorguMap.put("TARIHCE_AKSIYON", "E");
	  	  					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
	  	  					isHunterBasim = true;
	  	  				}
  					}
	  	  				
  					//ve son durumu BASIM ise
  					session.refresh(kkBasvuru);
  	  				if ("BASIM".equals(kkBasvuru.getDurumKod()) || isHunterBasim) {
  	  					//Tff kanali ise
  	  					if ("40".equals(kkBasvuru.getKanalKod())) {
  	  						//Islem on onayli ise tff basvurusunu olustur, varsa hicbir sey yapmaz
  	  	  					if (CreditCardServicesUtil.EVET.equals(kkBasvuru.getOnOnayliMi())) {
  	  	  						sorguMap.clear();
  	  	  						sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
  	  	  						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_TFF_BASVURU_OLUSTUR", sorguMap));
  	  	  					}
  	  					}
  	  					//call ocean
  	  					if (isHunterBasim) {
  	  						iMap.put("ISLEM_KODU", "HUNTER");
  	  					} else {
  	  						iMap.put("ISLEM_KODU", "BASVURU");
  	  					}
	  	  				iMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
	  	  				iMap.put("DURUM_KOD", "BASIM");
						GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
						GMServiceExecuter.executeAsync("BNSPR_KK_BASVURU_SEND_SMS", iMap);
						//GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
  	  				} else {
						//TFF basvurularinda TFF Kartini Debite cevir.
  						if ("40".equals(kkBasvuru.getKanalKod())) {
  							if ("RED".equals(kkBasvuru.getDurumKod())) {
  								if (CreditCardServicesUtil.HAYIR.equals(
  										CreditCardServicesUtil.nvl(kkBasvuru.getOnOnayliMi(), CreditCardServicesUtil.HAYIR))) {
  									sorguMap.clear();
  	  	  							sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
  	  	  							sorguMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
  	  	  							sorguMap.put("ISLEM_KOD", "3871");
  	  	  							oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap));
  								}
  							} else if ("IPTAL".equals(kkBasvuru.getDurumKod())) {
  								if (CreditCardServicesUtil.HAYIR.equals(
  										CreditCardServicesUtil.nvl(kkBasvuru.getOnOnayliMi(), CreditCardServicesUtil.HAYIR))) {
  									//TFF basvurusunu al
  	  								sorguMap.clear();
  	  								sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
  	  								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
  	  								BigDecimal tffBasvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
  	  								//Tff basvurusunu al ve iptal et.
  	  								if (tffBasvuruNo != null) {
  	  									TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
  	  									session.refresh(tffBasvuru);
  	  									
  	  									sorguMap.clear();
  	  									sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
  	  	  								sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
  	  	  								sorguMap.put("ISLEM_KOD", "3871");
  	  	  								sorguMap.put("GEREKCE_KOD", "2");
  	  	  								sorguMap.put("ACIKLAMA", "Aktif basvuru/kart sebebi ile kk iptal oldugundan tff iptal edildi");
  	  	  								sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
  	  	  								oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
  	  								}
  								}
  							} else {
  								//Islem on onayli ise tff basvurusunu olustur, varsa hicbir sey yapmaz
  								if (CreditCardServicesUtil.EVET.equals(kkBasvuru.getOnOnayliMi())) {
  		  	  						sorguMap.clear();
  		  	  						sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
  		  	  						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_TFF_BASVURU_OLUSTUR", sorguMap));
  		  	  					}
  							}
  						} else {
  							if ("L".equals(kkBasvuru.getKartSeviyesi())) {
  								if ("RED".equals(kkBasvuru.getDurumKod()) || "IPTAL".equals(kkBasvuru.getDurumKod())) {
  	  								//Limit durum guncelle
  	  								sorguMap.clear();
  	  								sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
  	  								sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
  	  								sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
  	  								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
  	  							}
  							}
  						}
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
  	}
  	
  	/** Basvuru isleminde daha once musteriye kart verilmis mi kontrolu yapilir.
  	 * Verilmisse HATA_VERILECEK_MI degerine gore hata verilir.
  	 * 
  	 * @param iMap - TCKN, MUST_NO, HATA_VERILECEK_MI,BASVURU_NO,TRX_NO, KART_TIPI
  	 * @return oMap - KART_VAR_MI, DEVAM, KART_VAR_HATA_MESAJI, OCEAN_HATA_VAR_MI
  	 */
  	@GraymoundService("BNSPR_TRN3871_KART_VAR_MI")
  	public static GMMap isExistCreditCard(GMMap iMap) {
  		GMMap oMap = new GMMap();
  		GMMap sorguMap = new GMMap();
  		boolean isExistCard = false;
  		boolean isKapamaTalepAlindi = false;
  		
  		String tablo = "CARD_DETAIL_INFO";
  		String durum = "CARD_STAT_CODE";
  		String altDurum = "CARD_SUB_STAT_CODE";
  		
  		//Parametre Kontrol - TCKN yada Musteri Numarasi Verilmemisse devam et.
		if (StringUtils.isBlank(iMap.getString("TCKN")) && 
				(StringUtils.isBlank(iMap.getString("MUST_NO")) || iMap.getInt("MUST_NO") == 0)) {
			oMap.put("KART_VAR_MI", false);
			oMap.put("DEVAM", "E");
			return oMap;
		}
		
  		try {
			//Oceandan musterinin mevcut kartlarini al.
			try {
				if ("KK".equals(iMap.getString("KART_TIPI"))) {
					iMap.put("CARD_DCI", "C");
				} else if ("D".equals(iMap.getString("KART_TIPI"))) {
					iMap.put("CARD_DCI", "D");
				} else {
					iMap.put("CARD_DCI", "C");
				}
				iMap.put("CUSTOMER_NO", iMap.get("MUST_NO"));
				iMap.put("CARD_BANK_STATUS", "All");
				iMap.put("NO_NEED_INTRACARDS_CARDS", true);
				iMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", iMap));//CUSTOMER_NO, TCKN
			} catch (Exception e) {
				oMap.put("KART_VAR_MI", false);
				oMap.put("DEVAM", "E");
				oMap.put("OCEAN_HATA_VAR_MI", true);
				oMap.put("KART_VAR_HATA_MESAJI", e.getMessage());
				return oMap;
			}
			
			//Karti varsa ve kartin durumu kuryede, normal,gecici kapali ise hata ver.
			if (iMap.get(tablo) != null) {
				boolean isKartKuryede = false;
				boolean isKartNormal = false;
				boolean isKartGeciciKapali = false;
				boolean isKartDigerDurum = false;
				boolean isKartYasalTakip = false;
				
				for (int i = 0; i < iMap.getSize(tablo); i++) {
					sorguMap.clear();
					sorguMap.put("KART_NO", iMap.get(tablo, i, "CARD_NO"));
					sorguMap.put("KART_TIPI", CreditCardTffServices.TFF_KREDI_KARTI);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", sorguMap));
					if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("KAPAMA_TALEBI_VAR_MI"))) {
						isExistCard = true;
						isKapamaTalepAlindi = true;
						break;
					}
					
					isKartKuryede = "G".equals(iMap.get(tablo, i, durum)) && "J".equals(iMap.get(tablo, i, altDurum)); //KURYEDE OLAN KART
					isKartNormal = "N".equals(iMap.get(tablo, i, durum)) && "N".equals(iMap.get(tablo, i, altDurum)); //Normal
					isKartGeciciKapali = "G".equals(iMap.get(tablo, i, durum)) && 
							("N".equals(iMap.get(tablo, i, altDurum)) //GECICI KAPALI
							|| "V".equals(iMap.get(tablo, i, altDurum)) //GECICI KAPALI - VEFAT BILDIRIMI
							|| "X".equals(iMap.get(tablo, i, altDurum)) //GECICI KAPALI - UCUNCU SAHIS BILDIRIMI
							|| "M".equals(iMap.get(tablo, i, altDurum)) //MUSTERI KAYIP (GECICI)
							|| "K".equals(iMap.get(tablo, i, altDurum)) //KURYE KAYIP (GECICI)
							|| "G".equals(iMap.get(tablo, i, altDurum)) //KAYIP CALINTI KONTROL
							|| "C".equals(iMap.get(tablo, i, altDurum)) //CALINTI(GECICI)	
							|| "Y".equals(iMap.get(tablo, i, altDurum)) //VADE YENILEME
							|| "Q".equals(iMap.get(tablo, i, altDurum)) //GECICI KAPALI - VEFAT BILDIRIMI
							|| "B".equals(iMap.get(tablo, i, altDurum)) //BASIM BEKLENIYOR
							);
					
					isKartDigerDurum = "I".equals(iMap.get(tablo, i, durum)) && 
							("V".equals(iMap.get(tablo, i, altDurum)) //VEFAT
							|| "Y".equals(iMap.get(tablo, i, altDurum)) //MUKERRER KART
							);	
					
					isKartYasalTakip = "P".equals(iMap.get(tablo, i, durum)) && "P".equals(iMap.get(tablo, i, altDurum)); //YASAL TAKIP

					if(isKartKuryede || isKartNormal || isKartGeciciKapali || isKartDigerDurum || isKartYasalTakip) {
						isExistCard = true;
						break;
					}
				}
			}
			
			//Hata verilmesi isteniyorsa ver, yoksa basvuruyu sonlandir.
			if (isExistCard) {
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILECEK_MI"))) {
					CreditCardServicesUtil.raiseGMError("2958");
				} else { //sonlandir
					//Hatayi al
					iMap.put("MESSAGE_NO", "2958");
					oMap.put("KART_VAR_HATA_MESAJI", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
					
					if(iMap.getBigDecimal("BASVURU_NO") != null)
					{
						//Varsa mevcut basvuruyu iptal et.
						GMMap iptalMap = new GMMap();
						iptalMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						iptalMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
						iptalMap.put("DURUM", "IPTAL");
						iptalMap.put("AKSIYON_KOD", "C");
						iptalMap.put("AKSIYON_KARAR_KOD", "3");
						CreditCardQueriesServices.basvuruSonlandir(iptalMap);//TRX_NO,BASVURU_NO,DURUM
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("KART_VAR_MI", isExistCard);
		oMap.put("KAPAMA_TALEBI_VAR_MI", isKapamaTalepAlindi);
		oMap.put("DEVAM", BooleanUtils.toString(isExistCard, "H", "E"));
		return oMap;
  	}
  	 @GraymoundService("BNSPR_TRN3871_SAVE_ES_BILGILERI")
     public static GMMap saveEsBilgileri(GMMap iMap) {
         try {
             Session session = DAOSession.getSession("BNSPRDal");
           
             GMMap oMap = new GMMap();
             GMMap esKpsMap = new GMMap();

             
             KkBasvuruKimlikDigerTx kkBasvuruKimlikDigerTx =
                     (KkBasvuruKimlikDigerTx) session.createCriteria(KkBasvuruKimlikDigerTx.class)
                     .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
                     .add(Restrictions.eq("id.tcKimlikNo", iMap.getString("ES_TCKN")))
                     .uniqueResult()
                     ;
             
             if(kkBasvuruKimlikDigerTx == null){  // bu tckn ve txNo ile kay�t yoksa sorgu yap ve save et
            	 kkBasvuruKimlikDigerTx = new KkBasvuruKimlikDigerTx();
            	 esKpsMap.put("TCKNO", iMap.getString("ES_TCKN"));
            	 esKpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_KPS_KIMLIK_SORGULAMA", esKpsMap));
                 esKpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_KPS_KIMLIK_DOGRULAMA", esKpsMap));

                 if(StringUtils.isNotBlank(esKpsMap.getString("TCKNO_OUT"))){  // kps basarili ise save et
	                 GMMap esApsMap = new GMMap();
	                 esApsMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
	                 esApsMap.put("TC_KIMLIK_NO", iMap.getString("ES_TCKN"));
	                 if (isLocal) {
	                	 esApsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3871_APS_SORGULAMA", esApsMap));
	                 } else {
	                	 esApsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_APS_SORGULAMA", esApsMap));
	                 }
	
	                 KkBasvuruKimlikDigerTxId kkBasvuruKimlikDigerTxId = new KkBasvuruKimlikDigerTxId();
	                 kkBasvuruKimlikDigerTxId.setTcKimlikNo(esKpsMap.getString("TCKNO"));
	                 kkBasvuruKimlikDigerTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
	                 kkBasvuruKimlikDigerTx.setAd(esKpsMap.getString("AD"));
	                 kkBasvuruKimlikDigerTx.setAileSiraNo(esKpsMap.getString("AILE_SIRA_NO"));
	                 kkBasvuruKimlikDigerTx.setAnneAdi(esKpsMap.getString("ANNE_AD"));
	                 kkBasvuruKimlikDigerTx.setBabaAd(esKpsMap.getString("BABA_AD"));
	                 kkBasvuruKimlikDigerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	                 kkBasvuruKimlikDigerTx.setBireySiraNo(esKpsMap.getString("BIREY_SIRA_NO"));
	                 kkBasvuruKimlikDigerTx.setCinsiyet(("1").equals(esKpsMap.getString("CINSIYET_KOD")) ? "E" : "K");
	                 kkBasvuruKimlikDigerTx.setCinsiyetKps(esKpsMap.getString("CINSIYET"));
	                 kkBasvuruKimlikDigerTx.setCiltNo(esKpsMap.getString("CILT_KODU"));
	                 kkBasvuruKimlikDigerTx.setKimlikKayitNo(esKpsMap.getString("KIMLIK_KAYIT_NO"));// GELMIYOR
	                 kkBasvuruKimlikDigerTx.setDin(esKpsMap.getString("DIN"));
	                 kkBasvuruKimlikDigerTx.setDogumyerkod(esKpsMap.getString("DOGUM_YERI_KOD")); //GELMIYOR
	                 kkBasvuruKimlikDigerTx.setDurumkod(esKpsMap.getString("DURUMU"));
	                 kkBasvuruKimlikDigerTx.setKayityeril(esKpsMap.getString("IL"));
	                 kkBasvuruKimlikDigerTx.setVerilmenedenkod(esKpsMap.getString("VERILIS_NEDENI_KOD"));
	                 kkBasvuruKimlikDigerTx.setKayityerilce(esKpsMap.getString("ILCE"));
	                 kkBasvuruKimlikDigerTx.setMedeniHal(("2").equals(esKpsMap.getString("MEDENI_HALI_KOD")) ? "1" : "2");
	                 kkBasvuruKimlikDigerTx.setKimlikSeriNoKps(esKpsMap.getString("KIMLIK_SERI_NO"));
	                 kkBasvuruKimlikDigerTx.setKimlikSiraNoKps(esKpsMap.getString("KIMLIK_SIRA_NO"));
	                 kkBasvuruKimlikDigerTx.setDogumTar(esKpsMap.getDate("DOGUM_TARIHI"));
	                 kkBasvuruKimlikDigerTx.setDogumYeri(esKpsMap.getString("DOGUM_YERI"));
	                 kkBasvuruKimlikDigerTx.setDurum(esKpsMap.getString("DURUMU_ACIKLAMA"));
	                 kkBasvuruKimlikDigerTx.setEsTckn(esKpsMap.getString("ES_TCKN"));
	                 kkBasvuruKimlikDigerTx.setMahalleKoy(esKpsMap.getString("CILT"));
	                 kkBasvuruKimlikDigerTx.setMahalleKod(esKpsMap.getString("CILT_KODU"));
	                 kkBasvuruKimlikDigerTx.setNufusIlKod(esKpsMap.getString("IL_KODU"));
	                 kkBasvuruKimlikDigerTx.setNufusIlceKod(esKpsMap.getString("ILCE_KODU"));
	                 kkBasvuruKimlikDigerTx.setMedeniHalKps(esKpsMap.getString("MEDENI_HALI")!=null?esKpsMap.getString("MEDENI_HALI").substring(0, 1):"");
	                 if (StringUtils.isNotEmpty(esKpsMap.getString("OLUM_TARIHI")) && esKpsMap.getString("OLUM_TARIHI") != null ){
	                 kkBasvuruKimlikDigerTx.setOlumtarih(esKpsMap.getDate("OLUM_TARIHI"));
	                 }
	                 else{
	                	 kkBasvuruKimlikDigerTx.setOlumtarih(null);
	                 }
	                 kkBasvuruKimlikDigerTx.setSoyad(esKpsMap.getString("SOYAD"));
	                 kkBasvuruKimlikDigerTx.setNufusVerYer(esKpsMap.getString("VERILDIGI_ILCE_ADI"));
	                 kkBasvuruKimlikDigerTx.setVerildigiilcekod(esKpsMap.getString("VERILDIGI_ILCE_KODU"));
	                 kkBasvuruKimlikDigerTx.setNufusVerNedeni(esKpsMap.getString("VERILIS_NEDENI"));
	                 kkBasvuruKimlikDigerTx.setVerilmenedenkod(esKpsMap.getString("VERILIS_NEDENI_KOD"));
	                 kkBasvuruKimlikDigerTx.setNufusVerTar(esKpsMap.getDate("VERILIS_TARIHI"));
	                 //kkBasvuruKimlikDigerTx.setMusteriNo(outMap.getBigDecimal("MUSTERI_NO"));
	
	                 String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
	                 esApsMap.put("TCKN", esApsMap.getString("TC_KIMLIK_NO"));
	                 BigDecimal apsLogId = null;
	                 if (isLocal) {
	                	 apsLogId=new GMMap(GMConnection.getConnection("BANKINGSalacak").serviceCall(serviceName, esApsMap)).getBigDecimal("LOG_ID");
	                 } else {
	                	 apsLogId=GMServiceExecuter.call(serviceName, esApsMap).getBigDecimal("LOG_ID");
	                 }

	                 kkBasvuruKimlikDigerTx.setApsLogId(apsLogId);
	                 kkBasvuruKimlikDigerTx.setBucak(esApsMap.getString("BUCAK"));
	                 kkBasvuruKimlikDigerTx.setBucakKod(esApsMap.getString("BUCAK_KOD"));
	                 kkBasvuruKimlikDigerTx.setCsbm(esApsMap.getString("CSBM"));
	                 kkBasvuruKimlikDigerTx.setCsbmKod(esApsMap.getString("CSBM_KODU"));
	                 kkBasvuruKimlikDigerTx.setDisKapiNo(esApsMap.getString("DIS_KAPI_NO"));
	                 kkBasvuruKimlikDigerTx.setIcKapiNo(esApsMap.getString("IC_KAPI_NO"));
	                 kkBasvuruKimlikDigerTx.setIl(esApsMap.getString("IL"));
	                 kkBasvuruKimlikDigerTx.setIlce(esApsMap.getString("ILCE"));
	                 kkBasvuruKimlikDigerTx.setEvAdrIlKod(esApsMap.getString("IL_KODU"));
	                 kkBasvuruKimlikDigerTx.setEvAdrIlceKod(esApsMap.getString("ILCE_KODU"));
	                 kkBasvuruKimlikDigerTx.setKoy(esApsMap.getString("KOY"));
	                 kkBasvuruKimlikDigerTx.setKoyKayitNo(esApsMap.getString("KOY_KAYIT_NO"));
	                 kkBasvuruKimlikDigerTx.setKoyKod(esApsMap.getString("KOY_KOD"));
	                 kkBasvuruKimlikDigerTx.setMahalle(esApsMap.getString("MAHALLE"));
	                 kkBasvuruKimlikDigerTx.setMahalleKod(esApsMap.getString("MAHALLE_KOD"));
	                 kkBasvuruKimlikDigerTx.setYabanciAdres(esApsMap.getString("YABANCI_ADRES"));//GELMIYOR
	                 kkBasvuruKimlikDigerTx.setYabanciSehir(esApsMap.getString("YABANCI_SEHIR"));//GELMIYOR
	                 kkBasvuruKimlikDigerTx.setYabanciUlke(esApsMap.getString("YABANCI_ULKE"));//GELMIYOR
	                 kkBasvuruKimlikDigerTx.setYabanciUlkeKod(esApsMap.getString("YABANCI_ULKE_KOD"));//GELMIYOR
	                 kkBasvuruKimlikDigerTx.setKimIcin("E");
	
	                 kkBasvuruKimlikDigerTx.setId(kkBasvuruKimlikDigerTxId);
	                 session.saveOrUpdate(kkBasvuruKimlikDigerTx);
	                 session.flush();
	                 
	                 KkBasvuruKimlikDiger kkBasvuruKimlikDiger =
	                         (KkBasvuruKimlikDiger) session.createCriteria(KkBasvuruKimlikDiger.class)
	                         .add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
	                         .add(Restrictions.eq("id.tcKimlikNo", iMap.getString("ES_TCKN")))
	                         .uniqueResult()
	                         ;
	                 if(kkBasvuruKimlikDiger==null){  // nullsa yeni obje
	                	 kkBasvuruKimlikDiger=new KkBasvuruKimlikDiger();
	                 }
	                 // ana tablo insertleri
	                 KkBasvuruKimlikDigerId kkBasvuruKimlikDigerId = new KkBasvuruKimlikDigerId();
	                 kkBasvuruKimlikDigerId.setTcKimlikNo(esKpsMap.getString("TCKNO"));
	                 kkBasvuruKimlikDigerId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	                 kkBasvuruKimlikDiger.setAd(esKpsMap.getString("AD"));
	                 kkBasvuruKimlikDiger.setAileSiraNo(esKpsMap.getString("AILE_SIRA_NO"));
	                 kkBasvuruKimlikDiger.setAnneAdi(esKpsMap.getString("ANNE_AD"));
	                 kkBasvuruKimlikDiger.setBabaAd(esKpsMap.getString("BABA_AD"));
	                 kkBasvuruKimlikDiger.setBireySiraNo(esKpsMap.getString("BIREY_SIRA_NO"));
	                 kkBasvuruKimlikDiger.setCinsiyet(("1").equals(esKpsMap.getString("CINSIYET_KOD")) ? "E" : "K");
	                 kkBasvuruKimlikDiger.setCinsiyetKps(esKpsMap.getString("CINSIYET"));
	                 kkBasvuruKimlikDiger.setCiltNo(esKpsMap.getString("CILT_KODU"));
	                 kkBasvuruKimlikDiger.setKimlikKayitNo(esKpsMap.getString("KIMLIK_KAYIT_NO"));// GELMIYOR
	                 kkBasvuruKimlikDiger.setDin(esKpsMap.getString("DIN"));
	                 kkBasvuruKimlikDiger.setDogumyerkod(esKpsMap.getString("DOGUM_YERI_KOD")); //GELMIYOR
	                 kkBasvuruKimlikDiger.setDurumkod(esKpsMap.getString("DURUMU"));
	                 kkBasvuruKimlikDiger.setKayityeril(esKpsMap.getString("IL"));
	                 kkBasvuruKimlikDiger.setVerilmenedenkod(esKpsMap.getString("VERILIS_NEDENI_KOD"));
	                 kkBasvuruKimlikDiger.setKayityerilce(esKpsMap.getString("ILCE"));
	                 kkBasvuruKimlikDiger.setMedeniHal(("2").equals(esKpsMap.getString("MEDENI_HALI_KOD")) ? "1" : "2");
	                 kkBasvuruKimlikDiger.setKimlikSeriNoKps(esKpsMap.getString("KIMLIK_SERI_NO"));
	                 kkBasvuruKimlikDiger.setKimlikSiraNoKps(esKpsMap.getString("KIMLIK_SIRA_NO"));
	                 kkBasvuruKimlikDiger.setDogumTar(esKpsMap.getDate("DOGUM_TARIHI"));
	                 kkBasvuruKimlikDiger.setDogumYeri(esKpsMap.getString("DOGUM_YERI"));
	                 kkBasvuruKimlikDiger.setDurum(esKpsMap.getString("DURUMU_ACIKLAMA"));
	                 kkBasvuruKimlikDiger.setEsTckn(esKpsMap.getString("ES_TCKN"));
	                 kkBasvuruKimlikDiger.setMahalleKoy(esKpsMap.getString("CILT"));
	                 kkBasvuruKimlikDiger.setMahalleKod(esKpsMap.getString("CILT_KODU"));
	                 kkBasvuruKimlikDiger.setNufusIlKod(esKpsMap.getString("IL_KODU"));
	                 kkBasvuruKimlikDiger.setNufusIlceKod(esKpsMap.getString("ILCE_KODU"));
	                 kkBasvuruKimlikDiger.setMedeniHalKps(esKpsMap.getString("MEDENI_HALI")!=null?esKpsMap.getString("MEDENI_HALI").substring(0, 1):"");
	                 if (StringUtils.isNotEmpty(esKpsMap.getString("OLUM_TARIHI")) && esKpsMap.getString("OLUM_TARIHI") != null ){
		                 kkBasvuruKimlikDigerTx.setOlumtarih(esKpsMap.getDate("OLUM_TARIHI"));
		                 }
		                 else{
		                	 kkBasvuruKimlikDigerTx.setOlumtarih(null);
		                 }
	                 kkBasvuruKimlikDiger.setSoyad(esKpsMap.getString("SOYAD"));
	                 kkBasvuruKimlikDiger.setNufusVerYer(esKpsMap.getString("VERILDIGI_ILCE_ADI"));
	                 kkBasvuruKimlikDiger.setVerildigiilcekod(esKpsMap.getString("VERILDIGI_ILCE_KODU"));
	                 kkBasvuruKimlikDiger.setNufusVerNedeni(esKpsMap.getString("VERILIS_NEDENI"));
	                 kkBasvuruKimlikDiger.setVerilmenedenkod(esKpsMap.getString("VERILIS_NEDENI_KOD"));
	                 kkBasvuruKimlikDiger.setNufusVerTar(esKpsMap.getDate("VERILIS_TARIHI"));
	
	                 kkBasvuruKimlikDiger.setApsLogId(apsLogId);
	                 kkBasvuruKimlikDiger.setBucak(esApsMap.getString("BUCAK"));
	                 kkBasvuruKimlikDiger.setBucakKod(esApsMap.getString("BUCAK_KOD"));
	                 kkBasvuruKimlikDiger.setCsbm(esApsMap.getString("CSBM"));
	                 kkBasvuruKimlikDiger.setCsbmKod(esApsMap.getString("CSBM_KODU"));
	                 kkBasvuruKimlikDiger.setDisKapiNo(esApsMap.getString("DIS_KAPI_NO"));
	                 kkBasvuruKimlikDiger.setIcKapiNo(esApsMap.getString("IC_KAPI_NO"));
	                 kkBasvuruKimlikDiger.setIl(esApsMap.getString("IL"));
	                 kkBasvuruKimlikDiger.setIlce(esApsMap.getString("ILCE"));
	                 kkBasvuruKimlikDiger.setEvAdrIlKod(esApsMap.getString("IL_KODU"));
	                 kkBasvuruKimlikDiger.setEvAdrIlceKod(esApsMap.getString("ILCE_KODU"));
	                 kkBasvuruKimlikDiger.setKoy(esApsMap.getString("KOY"));
	                 kkBasvuruKimlikDiger.setKoyKayitNo(esApsMap.getString("KOY_KAYIT_NO"));
	                 kkBasvuruKimlikDiger.setKoyKod(esApsMap.getString("KOY_KOD"));
	                 kkBasvuruKimlikDiger.setMahalle(esApsMap.getString("MAHALLE"));
	                 kkBasvuruKimlikDiger.setMahalleKod(esApsMap.getString("MAHALLE_KOD"));
	                 kkBasvuruKimlikDiger.setYabanciAdres(esApsMap.getString("YABANCI_ADRES"));//GELMIYOR
	                 kkBasvuruKimlikDiger.setYabanciSehir(esApsMap.getString("YABANCI_SEHIR"));//GELMIYOR
	                 kkBasvuruKimlikDiger.setYabanciUlke(esApsMap.getString("YABANCI_ULKE"));//GELMIYOR
	                 kkBasvuruKimlikDiger.setYabanciUlkeKod(esApsMap.getString("YABANCI_ULKE_KOD"));//GELMIYOR
	                 kkBasvuruKimlikDiger.setKimIcin("E");
	
	                 kkBasvuruKimlikDiger.setId(kkBasvuruKimlikDigerId);
	                 session.saveOrUpdate(kkBasvuruKimlikDiger);
	                 session.flush();

                 }
             }
             return oMap;
             
         } catch (Exception e) {
             throw ExceptionHandler.convertException(e);
         }
     }
  	 
  	 
     @GraymoundService("BNSPR_TRN3871_GET_ES_BILGI")
     public static GMMap getEsBilgi(GMMap iMap) {
         Connection conn = null;
         CallableStatement stmt = null;
         ResultSet rSet = null;
         try {
             GMMap oMap = new GMMap();
             conn = DALUtil.getGMConnection();
             stmt = conn.prepareCall("{?=call pkg_trn3871.rc_get_kimlik_diger(?,?)}");
             int i = 1;
             stmt.registerOutParameter(i++, -10);
             stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
             stmt.setString(i++, "E");
             stmt.execute();

             rSet = (ResultSet) stmt.getObject(1);
             while(rSet.next()){
                 oMap.put("REC_DATE", rSet.getObject("REC_DATE"));
                 oMap.put("REC_OWNER", rSet.getObject("REC_OWNER"));
                 oMap.put("BASVURU_NO", rSet.getObject("BASVURU_NO"));
                 oMap.put("TCKIMLIKNO", rSet.getObject("TC_KIMLIK_NO"));
                 oMap.put("AD", rSet.getObject("AD"));
                 oMap.put("SOYAD", rSet.getObject("SOYAD"));
                 oMap.put("ANNEAD", rSet.getObject("ANNE_ADI"));
                 oMap.put("BABAAD", rSet.getObject("BABA_AD"));
                 oMap.put("DOGUMYERKOD", rSet.getObject("DOGUMYERKOD"));
                 oMap.put("DOGUMYER", rSet.getObject("DOGUM_YERI"));
                 oMap.put("DOGUMTARIH", rSet.getObject("DOGUM_TAR"));
                 oMap.put("CINSIYETKOD", rSet.getObject("CINSIYET"));
                 oMap.put("CINSIYET", rSet.getObject("CINSIYET_KPS"));
                 oMap.put("DIN", rSet.getObject("DIN"));
                 oMap.put("DURUMKOD", rSet.getObject("DURUMKOD"));
                 oMap.put("DURUM", rSet.getObject("DURUM"));
                 oMap.put("MEDENIHALKOD", rSet.getObject("MEDENI_HAL"));
                 oMap.put("MEDENIHAL", rSet.getObject("MEDENI_HAL_KPS"));
                 oMap.put("OLUMTARIH", rSet.getObject("OLUMTARIH"));
                 oMap.put("KAYITYERILKOD", rSet.getObject("NUFUS_IL_KOD"));
                 oMap.put("KAYITYERIL", rSet.getObject("KAYITYERIL"));
                 oMap.put("KAYITYERILCEKOD", rSet.getObject("NUFUS_ILCE_KOD"));
                 oMap.put("KAYITYERILCE", rSet.getObject("KAYITYERILCE"));
                 oMap.put("KAYITYERCILTKOD", rSet.getObject("CILT_NO"));
                 oMap.put("KAYITYERCILT", rSet.getObject("MAHALLE_KOY"));
                 oMap.put("AILESIRANO", rSet.getObject("AILE_SIRA_NO"));
                 oMap.put("BIREYSIRANO", rSet.getObject("BIREY_SIRA_NO"));
                 oMap.put("ESTCKIMLIKNO", rSet.getObject("ES_TCKN"));
                 oMap.put("CUZDANNO", rSet.getObject("KIMLIK_SIRA_NO_KPS"));
                 oMap.put("CUZDANSERI", rSet.getObject("KIMLIK_SERI_NO_KPS"));
                 oMap.put("VERILDIGIILCEKOD", rSet.getObject("VERILDIGIILCEKOD"));
                 oMap.put("VERILDIGIILCE", rSet.getObject("NUFUS_VER_YER"));
                 oMap.put("VERILMENEDENKOD", rSet.getObject("VERILMENEDENKOD"));
                 oMap.put("VERILMENEDEN", rSet.getObject("NUFUS_VER_NEDENI"));
                 oMap.put("VERILMETARIH", rSet.getObject("NUFUS_VER_TAR"));
                 oMap.put("BASVURU_TARIHI", rSet.getObject("BASVURU_TARIHI"));
                 oMap.put("BASVURAN_TCKN", rSet.getObject("BASVURAN_TCKN"));
                 oMap.put("BASVURAN_AD", rSet.getObject("BASVURAN_AD"));
                 
                 oMap.put("ADRES_NO", rSet.getObject("ADRES_NO"));
                 oMap.put("IL", rSet.getObject("IL"));
                 oMap.put("ILCE", rSet.getObject("ILCE"));
                 oMap.put("IL_KOD", rSet.getObject("EV_ADR_IL_KOD"));
                 oMap.put("ILCE_KOD", rSet.getObject("EV_ADR_ILCE_KOD"));
                 oMap.put("BUCAK", rSet.getObject("BUCAK"));
                 oMap.put("BUCAK_KOD", rSet.getObject("BUCAK_KOD"));
                 oMap.put("MAHALLE", rSet.getObject("MAHALLE"));
                 oMap.put("MAHALLE_KOD", rSet.getObject("MAHALLE_KOD"));
                 oMap.put("KOY", rSet.getObject("KOY"));
                 oMap.put("KOY_KOD", rSet.getObject("KOY_KOD"));
                 oMap.put("KOY_KAYIT_NO", rSet.getObject("KOY_KAYIT_NO"));
                 oMap.put("DIS_KAPI_NO", rSet.getObject("DIS_KAPI_NO"));
                 oMap.put("IC_KAPI_NO", rSet.getObject("IC_KAPI_NO"));
                 oMap.put("CSBM", rSet.getObject("CSBM"));
                 oMap.put("CSBM_KOD", rSet.getObject("CSBM_KOD"));
                 oMap.put("YABANCI_ADRES", rSet.getObject("YABANCI_ADRES"));
                 oMap.put("YABANCI_SEHIR", rSet.getObject("YABANCI_SEHIR"));
                 oMap.put("YABANCI_ULKE", rSet.getObject("YABANCI_ULKE"));
                 oMap.put("YABANCI_ULKE_KOD", rSet.getObject("EV_ADR_ULKE_KOD"));
             }
             return oMap;
         }
         catch (Exception e) {
             throw ExceptionHandler.convertException(e);
         }
         finally {
             GMServerDatasource.close(stmt);
             GMServerDatasource.close(conn);
             GMServerDatasource.close(rSet);
         }
     }

    @GraymoundService("BNSPR_TRN3871_WINDOW2_INITIALIZE")
    public static GMMap initializeWindow2(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
	
		try {
			//Banka tarihi
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", sorguMap));
			
			//Default olarak belirlenen hesap kesim tarihi
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "KK_HESAP_KESIM_TARIHI");
	    	oMap.put("KK_HESAP_KESIM_TARIHI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));
	    	
	    	//Banka personeli mi
	    	sorguMap.clear();
	    	sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
	    	sorguMap.put("REFERANS_TIPI", "KK");
	    	sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
	    	oMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_PERSONEL_MI", sorguMap));
	    	
	    	//Personel olup olmadigina gore musteri tipi ve grubu belirlenir.
	    	//Default olarak belirlenen musteri tipi
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(oMap.getString("PERSONEL_MI"))) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI");
	    	}
	    	oMap.put("KK_MUSTERI_TIPI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));

	    	//Default olarak belirlenen musteri grubu
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(oMap.getString("PERSONEL_MI"))) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP");
	    	}
	    	oMap.put("KK_MUSTERI_GRUP", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	
		return oMap;
	}
    
    @GraymoundService("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI")
  	public static GMMap kapamaTalebiVarMi(GMMap iMap) {
  		GMMap oMap = new GMMap();
		boolean kapamaTalebiVarMi = false;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_kk_basvuru.kapama_talebi_var_mi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("KART_NO"));
			stmt.setString(3, iMap.getString("KART_TIPI"));
			stmt.execute();
			if (CreditCardServicesUtil.EVET.equals(CreditCardServicesUtil.nvl(stmt.getString(1), CreditCardServicesUtil.HAYIR))) {
				kapamaTalebiVarMi = true;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("KAPAMA_TALEBI_VAR_MI", BooleanUtils.toString(kapamaTalebiVarMi, 
				CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
		return oMap;
	}
    
	   @GraymoundService("BNSPR_TRN3871_LOG_CC")
	    public static GMMap trn3871LogCC(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try{
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        }
	        return oMap;
	    }
	   
	   
	   @GraymoundService("BNSPR_TRN3871_AFTER_CONTROL")
		public static GMMap afterControl3871(GMMap iMap) {
			GMMap oMap = new GMMap();
			
			//initial database variables
			String query = null;
			Connection conn = null;
			CallableStatement stmt = null;
			
			try {
				//Islenecek kayit bilgisini al
				conn = DALUtil.getGMConnection();
				
	            query = "{call PKG_TRN3871.After_Control(?)}";
	            stmt = conn.prepareCall(query);
	            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
	            stmt.execute();
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
			
			return oMap;
		}

}
