package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffTopluBasvuru;
import tr.com.aktifbank.bnspr.dao.TffTopluBasvuruTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3804Services {

	@GraymoundService("BNSPR_TRN3804_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			// Kart Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			// Urun
			oMap.putAll(CreditCardServicesUtil.getParameterList("URUN_LIST", "TFF_BASVURU_URUN_KOD", "A", "E"));
			// Odeme Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("ODEME_TIPI_LIST", "TFF_TOPLU_ODEME_TIPI"));
			// Hesap Kesim Tarihi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_HESAP_KESIM_TARIHI_LIST", iMap));
			// Yurtdisi Harcama Ekstresi
			oMap.putAll(CreditCardServicesUtil.getParameterList("YURTDISI_EKSTRE_TIPI", "KREDI_KART_YURT_DISI_EKSTRE"));
			// Otomatik Odeme Talimati
			oMap.putAll(CreditCardServicesUtil.getParameterList("OTOMATIK_ODEME_TALIMATI", "KREDI_KART_OTOMATIK_ODEME"));
			// Kredi Karti Kaynak
			oMap.putAll(CreditCardServicesUtil.getParameterList("KAYNAK", "TFF_KART_KAYNAK"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3804_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			// Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffTopluBasvuruTx tffTopluBasvuruTx = (TffTopluBasvuruTx) session.get(TffTopluBasvuruTx.class, trxNo);
			if (tffTopluBasvuruTx == null) {
				tffTopluBasvuruTx = new TffTopluBasvuruTx();
				tffTopluBasvuruTx.setTxNo(trxNo);
			}

			// Islem bilgilerini al.
			tffTopluBasvuruTx.setDosyaAdi(iMap.getString("DOSYA_ADI"));
			tffTopluBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
			tffTopluBasvuruTx.setUrun(iMap.getString("URUN"));
			tffTopluBasvuruTx.setOdemeTipi(iMap.getString("ODEME_TIPI"));
			tffTopluBasvuruTx.setPromosyonKodu(iMap.getString("PROMOSYON_KODU"));
			tffTopluBasvuruTx.setKaynak(iMap.getString("KAYNAK"));
			tffTopluBasvuruTx.setTeslimatAdresi(iMap.getBoolean("TESLIMAT_EV") == true ? "E" : "I");
			tffTopluBasvuruTx.setOtomatikLimitArtis(iMap.getBoolean("OTOMATIK_LIMIT_ARTIS") == true ? "E" : "H");
			tffTopluBasvuruTx.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));
			tffTopluBasvuruTx.setYurtdisiHarcamaEkstresi(iMap.getString("YURTDISI_EKSTRE_TIPI"));
			tffTopluBasvuruTx.setOtomatikOdemeTalimati(iMap.getString("OTOMATIK_ODEME_TALIMATI"));
			tffTopluBasvuruTx.setKuryeTipi("S");
			tffTopluBasvuruTx.setEkstreTipiPosta(iMap.getBoolean("EKSTRE_TIPI_POSTA") == true ? "E" : "H");

			if (iMap.getBoolean("EKSTRE_TIPI_POSTA"))
				tffTopluBasvuruTx.setEkstreSecimi(iMap.getBoolean("EKSTRE_ADRES_EV") == true ? "E" : "I");

			tffTopluBasvuruTx.setEkstreTipiEmail(iMap.getBoolean("EKSTRE_TIPI_EMAIL") == true ? "E" : "H");
			tffTopluBasvuruTx.setEkstreTipiSms(iMap.getBoolean("EKSTRE_TIPI_SMS") == true ? "E" : "H");

			// Islem bilgilerini kaydet
			session.save(tffTopluBasvuruTx);
			session.flush();

			// Girilen bilgileri kontrol et
			sorguMap.clear();
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3804_AFTER_CONTROL", sorguMap));

			// Okunacak kolon sayisini al
			String excelKolonSayisi = null;
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "TFF_KK_TOPLU_BASVURU_KOLON");
			excelKolonSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");
			// Dosyayi oku
			sorguMap.clear();
			sorguMap.put("DOSYA", iMap.get("DOSYA"));
			sorguMap.put("KOLON_SAYISI", excelKolonSayisi);
			sorguMap.put("BASLIK_VAR_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXCEL_TO_LIST", sorguMap));
			// Kontrol
			Object basvuruList = null;
			if (sorguMap.get("TABLE") == null || sorguMap.getSize("TABLE") < 1) {
				CreditCardServicesUtil.raiseGMError("660", "Dosya icerisinde data bulunamadi");
			}
			else {
				basvuruList = sorguMap.get("TABLE");
			}

			// Dosyadaki bilgileri kaydet
			sorguMap.clear();
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("BASVURU_LIST", basvuruList);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3804_SAVE_BASVURU_LIST", sorguMap));

			// Alinan islem bilgileri ile islemi sonlandir.
			sorguMap.clear();
			sorguMap.put("TRX_NAME", "3804");
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3804_SAVE_BASVURU_LIST")
	public static GMMap saveBasvuruList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap odemeMap = new GMMap();

		try {
			// Kullanicinin atadigi bilgileri al
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			// Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffTopluBasvuruTx tffTopluBasvuruTx = (TffTopluBasvuruTx) session.get(TffTopluBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffTopluBasvuruTx == null) {
				CreditCardServicesUtil.raiseGMError("330", "Islem Numarasi");
			}

			// Kontrol
			String tableName = "BASVURU_LIST";
			if (iMap.get(tableName) == null || iMap.getSize(tableName) < 1) {
				CreditCardServicesUtil.raiseGMError("330", "Basvuru Bilgileri");
			}
			// Basvuru listesini kaydet
			sorguMap.put("TABLE_NAME", "TFF_TOPLU_BASVURU");
			TffTopluBasvuru tffTopluBasvuru = null;
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				tffTopluBasvuru = new TffTopluBasvuru();
				tffTopluBasvuru.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID"));
				tffTopluBasvuru.setTxNo(tffTopluBasvuruTx.getTxNo());
				tffTopluBasvuru.setDurum(BigDecimal.ZERO);// Okundu

				// Ekrandaki bilgileri tx tablodan al.
				tffTopluBasvuru.setKartTipi(tffTopluBasvuruTx.getKartTipi());
				tffTopluBasvuru.setUyruk("TR");
				tffTopluBasvuru.setUrun(tffTopluBasvuruTx.getUrun());
				tffTopluBasvuru.setKaynak(tffTopluBasvuruTx.getKaynak());
				tffTopluBasvuru.setTeslimatAdresi(tffTopluBasvuruTx.getTeslimatAdresi());
				tffTopluBasvuru.setOtomatikLimitArtis(tffTopluBasvuruTx.getOtomatikLimitArtis());
				tffTopluBasvuru.setHesapKesimTarihi(tffTopluBasvuruTx.getHesapKesimTarihi());
				tffTopluBasvuru.setYurtdisiHarcamaEkstresi(tffTopluBasvuruTx.getYurtdisiHarcamaEkstresi());
				tffTopluBasvuru.setOtomatikOdemeTalimati(tffTopluBasvuruTx.getOtomatikOdemeTalimati());
				tffTopluBasvuru.setEkstreTipiPosta(tffTopluBasvuruTx.getEkstreTipiPosta());
				tffTopluBasvuru.setEkstreTipiEmail(tffTopluBasvuruTx.getEkstreTipiEmail());
				tffTopluBasvuru.setEkstreTipiSms(tffTopluBasvuruTx.getEkstreTipiSms());
				tffTopluBasvuru.setEkstreSecimi(tffTopluBasvuruTx.getEkstreSecimi());
				tffTopluBasvuru.setKuryeTipi(tffTopluBasvuruTx.getKuryeTipi());

				// Listeden datayi exceldeki header alanlarina gore al
				tffTopluBasvuru.setTckn(iMap.getString(tableName, i, "TCKN"));
				tffTopluBasvuru.setCepUlkeKod("90");
				tffTopluBasvuru.setCepAlanKod(iMap.getString(tableName, i, "CEP_ALAN_KOD"));
				tffTopluBasvuru.setCepNo(iMap.getString(tableName, i, "CEP_NO"));
				tffTopluBasvuru.setUrunSahipKodu(iMap.getString(tableName, i, "URUN_LOGO"));
				tffTopluBasvuruTx.setUrunSahipKodu(iMap.getString(tableName, i, "URUN_LOGO"));
				tffTopluBasvuru.setTakim(iMap.getString(tableName, i, "URUN_LOGO"));
				tffTopluBasvuruTx.setTakim(iMap.getString(tableName, i, "URUN_LOGO"));
				tffTopluBasvuru.setEmail(iMap.getString(tableName, i, "EMAIL"));
				tffTopluBasvuru.setAnneKizlikSoyadi(iMap.getString(tableName, i, "ANNE_KIZLIK_SOYADI"));
				tffTopluBasvuru.setCalismaSekli(iMap.getString(tableName, i, "CALISMA_SEKLI"));
				tffTopluBasvuru.setVergiDairesi(iMap.getString(tableName, i, "VERGI_DAIRESI"));
				tffTopluBasvuru.setMeslek(iMap.getString(tableName, i, "MESLEK"));
				tffTopluBasvuru.setOgrenimDurumu(iMap.getString(tableName, i, "OGRENIM_DURUMU"));

				String aylikGelir = iMap.getString(tableName, i, "AYLIK_GELIR");
				if (StringUtils.isNotBlank(aylikGelir))
					tffTopluBasvuru.setAylikGelir(new BigDecimal(iMap.getString(tableName, i, "AYLIK_GELIR")));

				tffTopluBasvuru.setIsyeriAdi(iMap.getString(tableName, i, "ISYERI_ADI"));
				tffTopluBasvuru.setIsyeriAdresi(iMap.getString(tableName, i, "ISYERI_ADRESI"));
				tffTopluBasvuru.setIsyeriIlKod(iMap.getString(tableName, i, "ISYERI_IL_KOD"));
				tffTopluBasvuru.setIsyeriIlceKod(iMap.getString(tableName, i, "ISYERI_ILCE_KOD"));
				tffTopluBasvuru.setIsyeriPostaKod(iMap.getString(tableName, i, "ISYERI_POSTA_KOD"));
				tffTopluBasvuru.setIsTelUlkeKod("90");
				tffTopluBasvuru.setIsTelAlanKod(iMap.getString(tableName, i, "ISYERI_TELEFON_ALAN"));
				tffTopluBasvuru.setIsTelNo(iMap.getString(tableName, i, "ISYERI_TELEFON"));
				tffTopluBasvuru.setIsTelDahili(iMap.getString(tableName, i, "ISYERI_DAH�L�"));

				tffTopluBasvuru.setEvAdresi(iMap.getString(tableName, i, "EV_ADRESI"));
				tffTopluBasvuru.setEvIlKod(iMap.getString(tableName, i, "EV_IL_KOD"));
				tffTopluBasvuru.setEvIlceKod(iMap.getString(tableName, i, "EV_ILCE_KOD"));
				tffTopluBasvuru.setEvPostaKod(iMap.getString(tableName, i, "EV_POSTA_KOD"));
				tffTopluBasvuru.setEvTelUlkeKod("90");
				tffTopluBasvuru.setEvTelAlanKod(iMap.getString(tableName, i, "EV_TELEFON_ALAN"));
				tffTopluBasvuru.setEvTelNo(iMap.getString(tableName, i, "EV_TELEFON"));

				// Odeme
				String odemeTipi = tffTopluBasvuruTx.getOdemeTipi();
				String promosyonKodu = tffTopluBasvuruTx.getPromosyonKodu();
				// Ekrandan/Onceden odeme secenegi belirtilmisse ona gore hesaplama yap
				if (StringUtils.isNotBlank(odemeTipi)) {
					// Promosyon ile odeme yapilacaksa check et
					if ("P".equals(tffTopluBasvuruTx.getOdemeTipi())) {
						odemeMap.clear();
						odemeMap.put("PROMOSYON_KODU", promosyonKodu);
						odemeMap.put("URUN_SAHIP_KODU", tffTopluBasvuru.getUrunSahipKodu());
						odemeMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
						odemeMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3803_PROMOSYON_KODU_GECERLI_MI", odemeMap));
						// Promosyon kodunu kaydet
						tffTopluBasvuru.setPromosyonKodu(promosyonKodu);
					}

					// Ucretleri al
					odemeMap.clear();
					odemeMap.put("ODEME_TIPI", tffTopluBasvuruTx.getOdemeTipi());
					odemeMap.put("KART_TIPI", tffTopluBasvuru.getKartTipi());
					odemeMap.put("URUN_KODU", tffTopluBasvuru.getUrun());
					odemeMap.put("URUN_SAHIP_KODU", tffTopluBasvuru.getUrunSahipKodu());
					odemeMap.put("KURYE_TIPI", tffTopluBasvuru.getKuryeTipi());
					odemeMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3803_UCRET_HESAPLA", odemeMap));
					// Kaydet
					tffTopluBasvuru.setKartBedeli(odemeMap.getBigDecimal("KART_BEDELI"));
					tffTopluBasvuru.setVizeBedeli(odemeMap.getBigDecimal("VIZE_BEDELI"));
					tffTopluBasvuru.setLoyaltyBedeli(odemeMap.getBigDecimal("LOYALTY_BEDELI"));
					tffTopluBasvuru.setKuryeBedeli(odemeMap.getBigDecimal("KURYE_BEDELI"));
				}
				session.save(tffTopluBasvuru);
				session.update(tffTopluBasvuruTx);
			}
			// DB tarafinda kayit islemini tamamla.
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3804_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		// Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			// Varsa islem numarasina ait bilgiyi al
			TffTopluBasvuruTx tffTopluBasvuruTx = (TffTopluBasvuruTx) session.get(TffTopluBasvuruTx.class, trxNo);
			if (tffTopluBasvuruTx != null) {
				oMap.put("DOSYA_ADI", tffTopluBasvuruTx.getDosyaAdi());
				oMap.put("KART_TIPI", tffTopluBasvuruTx.getKartTipi());
				oMap.put("URUN", tffTopluBasvuruTx.getUrun());
				oMap.put("KAYNAK", tffTopluBasvuruTx.getKaynak());
				oMap.put("TESLIMAT_EV", tffTopluBasvuruTx.getTeslimatAdresi() == "E" ? true : false);
				oMap.put("TESLIMAT_IS", tffTopluBasvuruTx.getTeslimatAdresi() == "I" ? true : false);
				oMap.put("OTOMATIK_LIMIT_ARTIS", tffTopluBasvuruTx.getOtomatikLimitArtis() == "E" ? true : false);
				oMap.put("HESAP_KESIM_TARIHI", tffTopluBasvuruTx.getHesapKesimTarihi());
				oMap.put("YURTDISI_EKSTRE_TIPI", tffTopluBasvuruTx.getYurtdisiHarcamaEkstresi());
				oMap.put("OTOMATIK_ODEME_TALIMATI", tffTopluBasvuruTx.getOtomatikOdemeTalimati());
				oMap.put("EKSTRE_TIPI_POSTA", tffTopluBasvuruTx.getEkstreTipiPosta() == "E" ? true : false);
				oMap.put("EKSTRE_TIPI_EMAIL", tffTopluBasvuruTx.getEkstreTipiEmail() == "E" ? true : false);
				oMap.put("EKSTRE_TIPI_SMS", tffTopluBasvuruTx.getEkstreTipiSms() == "E" ? true : false);
				oMap.put("EKSTRE_ADRES_EV", tffTopluBasvuruTx.getEkstreSecimi() == "E" ? true : false);
				oMap.put("EKSTRE_ADRES_IS", tffTopluBasvuruTx.getEkstreSecimi() == "I" ? true : false);
				oMap.put("ODEME_TIPI", tffTopluBasvuruTx.getOdemeTipi());
				oMap.put("PROMOSYON_KODU", tffTopluBasvuruTx.getPromosyonKodu());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3804_AFTER_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			query = "{call PKG_TRN3804.After_Control(?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
