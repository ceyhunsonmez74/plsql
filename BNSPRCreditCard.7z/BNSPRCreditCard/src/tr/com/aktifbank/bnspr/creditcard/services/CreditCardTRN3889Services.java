package tr.com.aktifbank.bnspr.creditcard.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruistTcmbTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruistTcmbTxId;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruFraudTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruistTcmbKayitTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruistTcmbKayitTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CreditCardTRN3889Services {
 public static final String HUNTER_STATUS_CLEAR ="1";
 public static final String HUNTER_STATUS_MISSING_INCORRECT_DATA ="3";
 public static final String HUNTER_STATUS_SUSPECT ="5";
 public static final String HUNTER_STATUS_MERCHANT_FRAUD ="6";
 public static final String HUNTER_STATUS_FRAUD ="7";
 
	/**
	 * 3889 Fraud Ekran� a��l�rken, Fraud Karar-Gerek�e ve Kara Liste Kaynak Combobox alanlar�n� doldurur
	 * 
	 * @return oMap
	 *         - FRAUD_KARAR,
	 *         FRAUD_KARAR_2SIZ,
	 *         FRAUD_GEREKCE,
	 *         KARA_LISTE_KAYNAK_KOD
	 */
	@GraymoundService("BNSPR_TRN3889_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, "X", " ");
			GuimlUtil.wrapMyCombo(oMap, listName, "B", "Benzer");
			GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kesin");
			GuimlUtil.wrapMyCombo(oMap, listName, "Y", "Yok");
			GuimlUtil.wrapMyCombo(oMap, listName, "Z", "Kesin-Fraud Yok");

			DALUtil.fillComboBox(oMap, "FRAUD_KARAR", true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'FRAUD_SONUC_KOD' and key1 not in ('4') ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "FRAUD_KARAR_2SIZ", true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'FRAUD_SONUC_KOD' and key1 not in ('4','2') ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "FRAUD_GEREKCE", true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'FRAUD_NEDEN_KOD' ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "KARA_LISTE_KAYNAK_KOD", true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'KARA_LISTE_KAYNAK_KOD' ORDER BY SIRA_NO");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * BNSPR_TRN3889.guiml ekrani Karar combosundan secilen degere gore Iade combosunu doldurur.
	 * 
	 * @return {@link GMMap} - IADE_KOD
	 */
	@GraymoundService("BNSPR_TRN3889_GET_BASVURU_IADE_KOD")
	public static GMMap getBasvuruIadeKod(GMMap iMap) {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT t.key1,t.key1");
		query.append(" FROM v_ml_gnl_param_text t");
		query.append(" WHERE t.kod = 'KK_BASVURU_DURUM_KOD'");
		query.append(" AND t.sira_no in (2, 5)");

		GMMap oMap = new GMMap();
		try {
			DALUtil.fillComboBox(oMap, "IADE_KOD", true, query.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * Fraud Karar combobox alan�ndan se�ilen kayda g�re Fraud Gerek�esi combobox�n� doldurur
	 * 
	 * @param iMap
	 *            - FRAUD_KARAR
	 * @return oMap - FRAUD_GEREKCE
	 */
	@GraymoundService("BNSPR_TRN3889_GET_FRAUD_NEDEN_KOD")
	public static GMMap getFraudNedenKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "FRAUD_GEREKCE", true, "select key1,text from v_ml_gnl_param_text where kod = 'FRAUD_NEDEN_KOD' and key2 = '" + iMap.getString("FRAUD_KARAR") + "'  order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Fraud Karar combobox alan�ndan se�ilen kayda g�re Kara Liste Kay�t Kategorisi combobox�n� doldurur
	 * 
	 * @param iMap
	 *            - FRAUD_KARAR
	 * @return oMap - KARA_LISTE_DURUM_KOD
	 */
	@GraymoundService("BNSPR_TRN3889_GET_KARA_LISTE_KAYIT_KOD")
	public static GMMap getKaraListeKayitKategori(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			// Sahtecilik,��pheli Durum
			if ("1".equals(iMap.getString("FRAUD_KARAR")))
				DALUtil.fillComboBox(oMap, "KARA_LISTE_DURUM_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_DURUM_KOD' and key1 in ('1')  order by sira_no");
			else if ("3".equals(iMap.getString("FRAUD_KARAR")))
				DALUtil.fillComboBox(oMap, "KARA_LISTE_DURUM_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_DURUM_KOD' and key1 in ('2')  order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Kara Liste Kay�t Kategorisi combobox alan�ndan se�ilen kayda g�re Kara Liste Taraf Bilgisi combobox�n� doldurur
	 * 
	 * @param iMap
	 *            - KARA_LISTE_DURUM_KOD
	 * @return oMap - KARA_LISTE_TARAF_KOD
	 */
	@GraymoundService("BNSPR_TRN3889_GET_KARA_LISTE_TARAF_KOD")
	public static GMMap getKaraListeTarafKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			// Ma�dur, Sahtekar,��pheli secilebiliyor
			DALUtil.fillComboBox(oMap, "KARA_LISTE_TARAF_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_TARAF_KOD' and key2 = '" + iMap.getString("KARA_LISTE_DURUM_KOD") + "'  order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Kara Liste Kay�t Kategorisi combobox alan�ndan se�ilen kayda g�re Kara Liste Kay�t Sebebi combobox�n� doldurur
	 * 
	 * @param iMap
	 *            - KARA_LISTE_DURUM_KOD
	 * @return oMap - KARA_LISTE_KAYIT_SEBEP_KOD
	 */
	@GraymoundService("BNSPR_TRN3889_GET_KARA_LISTE_KAYIT_SEBEP_KOD")
	public static GMMap getKaraListeKayitSebepKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KARA_LISTE_KAYIT_SEBEP_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_KAYIT_SEBEP_KOD' and key2 = '" + iMap.getString("KARA_LISTE_DURUM_KOD") + "' order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Ba�vuru Numaras�na g�re daha �nce yap�lm�� kara liste ve �apraz sorgu kay�tlar�n� listeler
	 * 
	 * @param iMap
	 *            - BASVURU_NO
	 * @return oMap - RESULTS, CAPRAZ_MODEL, KARA_MODEL
	 */
	@GraymoundService("BNSPR_TRN3889_GET_SORGU_LIST")
	public static GMMap getSorguList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_GET_SORGU_LIST(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);

			List<?> ozetList = (List<?>) oMap.get("RESULTS");
			if (ozetList != null) {
				for (int i = 0; i < ozetList.size(); i++) {
					stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_GET_CAPRAZ_KAYIT(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet) stmt.getObject(1);

					oMap.put("RESULTS", i, "CAPRAZ_MODEL", DALUtil.rSetResults(rSet, "RESULTS").get("RESULTS"));
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);

					stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_GET_KARA_LISTE(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet) stmt.getObject(1);

					oMap.put("RESULTS", i, "KARA_MODEL", DALUtil.rSetResults(rSet, "RESULTS").get("RESULTS"));
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Ekrandaki kara liste ve �apraz liste durumlar�n� teker teker kontrol eder.
	 * Bunlar i�inde durumu kesin olan kay�t bulursa KESIN_DURUM parametresini set eder.
	 * Bu alan set edilince Fraud Karar combobox�nda "Fraud Yok" se�ene�i ��kar�l�r.
	 * 
	 * @param iMap
	 *            - OZET_TABLE
	 * @return oMap - KESIN_DURUM
	 */
	@GraymoundService("BNSPR_TRN3889_CHECK_KESIN_DURUM")
	public static GMMap checkKesinDurum(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			List<?> ozetList = (List<?>) iMap.get("OZET_TABLE");
			if (ozetList != null) {
				for (int i = 0; i < ozetList.size(); i++) {
					List<?> caprazList = (List<?>) iMap.get("OZET_TABLE", i, "CAPRAZ_MODEL");
					if (caprazList != null) {
						for (int j = 0; j < caprazList.size(); j++) {
							GMMap caprazListMap = new GMMap((HashMap<?, ?>) caprazList.get(j));
							if (caprazListMap.getString("IST_DURUM").equals("K")) {
								oMap.put("KESIN_DURUM", "K");
								return oMap;
							}
						}
					}
					List<?> karaList = (List<?>) iMap.get("OZET_TABLE", i, "KARA_MODEL");
					if (karaList != null) {
						for (int j = 0; j < karaList.size(); j++) {
							GMMap karaListMap = new GMMap((HashMap<?, ?>) karaList.get(j));
							if (karaListMap.getString("IST_DURUM").equals("K")) {
								oMap.put("KESIN_DURUM", "K");
								return oMap;
							}

						}
					}
				}
			}
			oMap.put("KESIN_DURUM", "Y");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * 3889 Fraud Ekran�ndaki �apraz sorgu listesinde veya kara listede se�ilen sorgunun detay�n� getirir.
	 * 
	 * @param iMap
	 *            - ID, SORGU_KOD, KIM_ICIN
	 * @return oMap - RESULTS
	 */
	@GraymoundService("BNSPR_TRN3889_GET_DETAY_LIST")
	public static GMMap getDetayList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_GET_DETAY_LIST(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
			stmt.setString(3, iMap.getString("SORGU_KOD"));
			stmt.setString(4, iMap.getString("KIM_ICIN"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * �l ve il�e kodlar�n� input olarak al�r, bunlara kar��l�k gelen isimleri d�nd�r�r.
	 * 
	 * @param iMap
	 *            - EV_ADR_IL_KOD, EV_ADR_ILCE_KOD, IS_ADR_IL_KOD, IS_ADR_ILCE_KOD
	 * @return oMap - EV_ADR_IL_KOD, EV_ADR_ILCE_KOD, IS_ADR_IL_KOD, IS_ADR_ILCE_KOD
	 */
	@GraymoundService("BNSPR_TRN3889_DECODE_BASVURU_FRAUD_DATA")
	public static GMMap decodeBasvuruFraudData(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			oMap.put("EV_ADR_IL_KOD", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod ='" + iMap.getString("EV_ADR_IL_KOD") + "' "));
			oMap.put("EV_ADR_ILCE_KOD", DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '" + iMap.getString("EV_ADR_IL_KOD") + "' and ilce_kod ='" + iMap.getString("EV_ADR_ILCE_KOD") + "'"));
			oMap.put("IS_ADR_IL_KOD", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod ='" + iMap.getString("IS_ADR_IL_KOD") + "' "));
			oMap.put("IS_ADR_ILCE_KOD", DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '" + iMap.getString("IS_ADR_IL_KOD") + "' and ilce_kod ='" + iMap.getString("IS_ADR_ILCE_KOD") + "'"));

			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	/**
	 * 3889 Fraud Ekran�ndan karar se�ildikten sonra save butonu bu servisi tetikler.
	 * KK_BASVURU_FRAUD_TX tablosuna ve �apraz sorgu ve kara liste sorgu i�in ilgili tablolara kay�t atar.
	 * Daha sonra 3889 i�lemi i�in start transaction servisini �a��r�r.
	 * 
	 * @param iMap - TRX_NO, BASVURU_NO, KARA_LISTEYE_EKLENSIN, KARA_LISTE_DURUM_KOD, KARA_LISTE_TARAF_KOD,
	 *            KARA_LISTE_KAYNAK_KOD, KARA_LISTE_KAYIT_SEBEP_KOD, FRAUD_KARAR, FRAUD_GEREKCE, GORUS,
	 *            OZET_TABLE, CAPRAZ_MODEL, KARA_MODEL, ANNE_KIZLIK, KIMLIK_SERI_NO, KIMLIK_SIRA_NO, IS_NUMARA
	 */
	@GraymoundService("BNSPR_TRN3889_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			KkBasvuruFraudTx kkBasvuruFraudTx = (KkBasvuruFraudTx) session.createCriteria(KkBasvuruFraudTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (kkBasvuruFraudTx == null)
				kkBasvuruFraudTx = new KkBasvuruFraudTx();

			kkBasvuruFraudTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kkBasvuruFraudTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kkBasvuruFraudTx.setKaralisteyeEklensinEh(iMap.getString("KARA_LISTEYE_EKLENSIN"));
			kkBasvuruFraudTx.setKayitKategorisi(iMap.getString("KARA_LISTE_DURUM_KOD"));
			kkBasvuruFraudTx.setTarafBilgisi(iMap.getString("KARA_LISTE_TARAF_KOD"));
			kkBasvuruFraudTx.setKaynak(iMap.getString("KARA_LISTE_KAYNAK_KOD"));
			kkBasvuruFraudTx.setKayitSebebi(iMap.getString("KARA_LISTE_KAYIT_SEBEP_KOD"));
			kkBasvuruFraudTx.setFraudSonucKod(iMap.getString("FRAUD_KARAR"));
			kkBasvuruFraudTx.setIadeKod(iMap.getString("IADE_KOD"));
			kkBasvuruFraudTx.setFraudNedenKod(iMap.getString("FRAUD_GEREKCE"));
			kkBasvuruFraudTx.setGorus(iMap.getString("GORUS"));
			kkBasvuruFraudTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK"));
			kkBasvuruFraudTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
			kkBasvuruFraudTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
			kkBasvuruFraudTx.setIsNumara(iMap.getString("IS_NUMARA"));
			session.saveOrUpdate(kkBasvuruFraudTx);

			String fraudTableName = "OZET_TABLE";
			String caprazTableName = "CAPRAZ_MODEL";
			String karaTableName = "KARA_MODEL";

			String temp;

			List<?> fraudList = (List<?>) iMap.get(fraudTableName);
			if (fraudList != null) {
				for (int i = 0; i < fraudList.size(); i++) {

					String karaSonuc = "Y";
					String caprazSonuc = "Y";

					List<?> caprazList = (List<?>) iMap.get(fraudTableName, i, caprazTableName);
					if (caprazList != null) {
						for (int j = 0; j < caprazList.size(); j++) {
							GMMap caprazListMap = new GMMap((HashMap<?, ?>) caprazList.get(j));
							if (caprazListMap.getString("IST_DURUM").equals("X")) {
								temp = caprazListMap.getString("SONUC");
							}
							else {
								temp = caprazListMap.getString("IST_DURUM");

								BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx = (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kayitId", caprazListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
								if (birBasvuruistTcmbKayitTx == null) {
									birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO"), caprazListMap.getBigDecimal("KAYIT_ID")));
								}

								birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
								birBasvuruistTcmbKayitTx.setTahsisSonuc(caprazListMap.getString("IST_DURUM"));
								birBasvuruistTcmbKayitTx.setSorguTip("E");
								birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName, i, "ID"));

								session.saveOrUpdate(birBasvuruistTcmbKayitTx);
							}
							if (temp.equals("Y") && !(caprazSonuc.equals("B") || caprazSonuc.equals("K"))) {
								caprazSonuc = "Y";
							}
							if (temp.equals("B") && !caprazSonuc.equals("K")) {
								caprazSonuc = "B";
							}
							if (temp.equals("K") || temp.equals("Z")) {
								caprazSonuc = "K";
							}

						}
					}
					List<?> karaList = (List<?>) iMap.get(fraudTableName, i, karaTableName);
					if (karaList != null) {

						for (int j = 0; j < karaList.size(); j++) {
							GMMap karaListMap = new GMMap((HashMap<?, ?>) karaList.get(j));
							if (karaListMap.getString("IST_DURUM").equals("X")) {
								temp = karaListMap.getString("DURUM");
							}
							else {
								temp = karaListMap.getString("IST_DURUM");

								BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx = (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kayitId", karaListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
								if (birBasvuruistTcmbKayitTx == null) {
									birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO"), karaListMap.getBigDecimal("KAYIT_ID")));
								}

								birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
								birBasvuruistTcmbKayitTx.setTahsisSonuc(karaListMap.getString("IST_DURUM"));
								birBasvuruistTcmbKayitTx.setSorguTip("B");
								birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName, i, "ID"));

								session.saveOrUpdate(birBasvuruistTcmbKayitTx);
							}

							if (temp.equals("Y") && !(karaSonuc.equals("B") || karaSonuc.equals("K"))) {
								karaSonuc = "Y";
							}
							if (temp.equals("B") && !karaSonuc.equals("K")) {
								karaSonuc = "B";
							}
							if (temp.equals("K") || temp.equals("Z")) {
								karaSonuc = "K";
							}

						}
					}

					if (!(karaSonuc.equals(iMap.getString(fraudTableName, i, "KARA_LISTE_SONUC")) && caprazSonuc.equals(iMap.getString(fraudTableName, i, "ESKI_BASVURU_SONUC")))) {

						BirBasvuruistTcmbTx birBasvuruistTcmbTx = (BirBasvuruistTcmbTx) session.createCriteria(BirBasvuruistTcmbTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.sorguId", iMap.getBigDecimal(fraudTableName, i, "ID"))).uniqueResult();
						if (birBasvuruistTcmbTx == null) {
							birBasvuruistTcmbTx = new BirBasvuruistTcmbTx();
							BirBasvuruistTcmbTxId birBasvuruistTcmbTxId = new BirBasvuruistTcmbTxId();
							birBasvuruistTcmbTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
							birBasvuruistTcmbTxId.setSorguId(iMap.getBigDecimal(fraudTableName, i, "ID"));
							birBasvuruistTcmbTx.setId(birBasvuruistTcmbTxId);

						}

						birBasvuruistTcmbTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birBasvuruistTcmbTx.setIslemKod("3889");
						birBasvuruistTcmbTx.setCaprazSorguSonuc(caprazSonuc);
						birBasvuruistTcmbTx.setKaraListeSonuc(karaSonuc);

						session.saveOrUpdate(birBasvuruistTcmbTx);

					}
				}
			}

			session.flush();
			if ("IS_HAVUZU".equals(iMap.getString("ACTION"))) {

				// Basvuru Akisindaki Kullanici Bilgilerini Guncelle
				GMMap akisMap = new GMMap();
				akisMap.put("ROL", "T");// Islem Tamamlandi
				akisMap.put("BASVURU_NO", kkBasvuruFraudTx.getBasvuruNo());
				akisMap.put("TX_NO", kkBasvuruFraudTx.getTxNo());
				akisMap.put("DURUM_KOD", kkBasvuruFraudTx.getIslemSonrasiDurumKodu());
				akisMap.put("ACIKLAMA", kkBasvuruFraudTx.getGorus());
				GMServiceExecuter.call("BNSPR_QRY3829_KULLANICI_ISLEM", akisMap);
			}
			if (!iMap.getBoolean("DONT_SEND_TRANSACTION")) {
				iMap.put("TRX_NAME", "3889");
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Bu method Fraud Ekran�ndan kara liste g�nder se�ilirse, i�lem bittikten sonra �al��t�r�l�r.
	 * Kara liste tablosuna ilgili trx no i�in bir kay�t atar.
	 * 
	 * @param iMap
	 *            - ISLEM_NO
	 */
	@GraymoundService("BNSPR_TRN3889_KARA_LISTE_GONDER")
	public static GMMap karaListeGonder(GMMap iMap) {
		try {
			iMap.put("TRX_NO", DALUtil.callOneParameterFunction("{? = call pkg_trn3889.KaraListeGonder(?)}", Types.DECIMAL, iMap.getBigDecimal("ISLEM_NO")));
			if (iMap.getBigDecimal("TRX_NO") != null) {
				iMap.put("TRX_NAME", "3921");
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Fraud Ekran� view modda a��l�rsa trx numaras�na g�re KK_BASVURU_FRAUD_TX tablosundan buldu�u kayd� d�ner.
	 * 
	 * @param iMap
	 *            - TRX_NO
	 * @return oMap - TRX_NO, BASVURU_NO, KARA_LISTEYE_EKLENSIN, KARA_LISTEYE_EKLENSIN_MI, KARA_LISTE_DURUM_KOD,
	 *         KARA_LISTE_TARAF_KOD, KARA_LISTE_KAYNAK_KOD, KARA_LISTE_KAYIT_SEBEP_KOD, FRAUD_KARAR, FRAUD_GEREKCE, 
	 *         GORUS, ANNE_KIZLIK, KIMLIK_SERI_NO, KIMLIK_SIRA_NO, IS_NUMARA
	 */
	@GraymoundService("BNSPR_TRN3889_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			KkBasvuruFraudTx kkBasvuruFraudTx = (KkBasvuruFraudTx) session.get(KkBasvuruFraudTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", kkBasvuruFraudTx.getTxNo());
			oMap.put("BASVURU_NO", kkBasvuruFraudTx.getBasvuruNo());
			oMap.put("KARA_LISTEYE_EKLENSIN", kkBasvuruFraudTx.getKaralisteyeEklensinEh());
			oMap.put("KARA_LISTEYE_EKLENSIN_MI", kkBasvuruFraudTx.getKaralisteyeEklensinEh() == null ? false : kkBasvuruFraudTx.getKaralisteyeEklensinEh().equals("E"));
			oMap.put("KARA_LISTE_DURUM_KOD", kkBasvuruFraudTx.getKayitKategorisi());
			oMap.put("KARA_LISTE_TARAF_KOD", kkBasvuruFraudTx.getTarafBilgisi());
			oMap.put("KARA_LISTE_KAYNAK_KOD", kkBasvuruFraudTx.getKaynak());
			oMap.put("KARA_LISTE_KAYIT_SEBEP_KOD", kkBasvuruFraudTx.getKayitSebebi());
			oMap.put("FRAUD_KARAR", kkBasvuruFraudTx.getFraudSonucKod());
			oMap.put("IADE_KOD", kkBasvuruFraudTx.getIadeKod());
			oMap.put("FRAUD_GEREKCE", kkBasvuruFraudTx.getFraudNedenKod());
			oMap.put("GORUS", kkBasvuruFraudTx.getGorus());
			oMap.put("ANNE_KIZLIK", kkBasvuruFraudTx.getAnneKizlik());
			oMap.put("KIMLIK_SERI_NO", kkBasvuruFraudTx.getKimlikSeriNo());
			oMap.put("KIMLIK_SIRA_NO", kkBasvuruFraudTx.getKimlikSiraNo());
			oMap.put("IS_NUMARA", kkBasvuruFraudTx.getIsNumara());
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	/**
	 * Fraud Ekran� call modda a��l�rsa ba�vuru numaras�na g�re KK_BASVURU_FRAUD_TX tablosundan buldu�u sonucu d�ner.
	 * 
	 * @param iMap
	 *            - BASVURU_NO
	 * @return oMap - ResultSet, KARALISTEYE_EKLENSIN_MI
	 */
	@GraymoundService("BNSPR_TRN3889_GET_FRAUD_DETAY")
	public static GMMap getInfoByBasvuru(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_GET_FRAUD_DETAY(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			GMMap oMap = DALUtil.rSetMap(rSet);
			oMap.put("KARALISTEYE_EKLENSIN_MI", oMap.get("KARALISTEYE_EKLENSIN_EH") == null ? false : oMap.getString("KARALISTEYE_EKLENSIN_EH").equals("E"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Bu servis, Fraud Ekran�ndan a��lan kontrol ekranlar�nda ge�mi� butonundan tetiklenir.
	 * Ba�vuru no ve de�er alanlar�na g�re ba�vuru tablolar�ndan kay�t �eker.
	 * 
	 * @param iMap
	 *            - BASVURU_NO, DEGER
	 * @return oMap - GECMIS_TABLE
	 */
	@GraymoundService("BNSPR_QRY3889_BASVURU_GECMIS_BILGI")
	public static GMMap getBasvuruGecmisBilgi(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3889.BasvuruGecmisDetay(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DEGER"));

			stmt.execute();

			rSet1 = (ResultSet) stmt.getObject(1);

			SimpleDateFormat outputFormatTime = new SimpleDateFormat("HHmmss");

			String tableName = "GECMIS_TABLE";

			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet1.next()) {
				oMap.put(tableName, j, "DEGER", rSet1.getString("DEGER"));
				oMap.put(tableName, j, "ISLEM_NO", rSet1.getString("ISLEM_NO"));
				oMap.put(tableName, j, "ISLEM_TARIHI", rSet1.getDate("ISLEM_TARIHI"));
				// oMap.put(tableName, j, "ISLEM_SAATI", rSet1.getString("ISLEM_SAATI"));
				oMap.put(tableName, j, "ISLEM_SAATI", outputFormatTime.format(rSet1.getTime("ISLEM_SAATI")));

				j++;
			}

			return oMap;
		}
		catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		}
		finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Ba�vuru ve m��teri numaras�na g�re m��teri ve kk ba�vuru tablolar�ndan kay�t d�ner.M��teri e�le�tirme ekran� i�in kullan�l�r.
	 * 
	 * @param iMap
	 *            - BASVURU_NO, MUSTERI_NO, KIM_ICIN
	 * @return oMap - C_BASVURU_*, C_MUSTERI_*, ROW_COUNT
	 */
	@GraymoundService("BNSPR_QRY3889_GET_MUSTERI_ESLESTIRME_INFO")
	public static GMMap getMusteriEslestirmeInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_MUSTERI_ESLESTIRME(?, ?, ?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("KIM_ICIN"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			Color differentBackground = new Color(255, 0, 64);
			Color defaultBackground = new Color(128, 255, 0);
			GMMap oMap = new GMMap();
			int row = 0;
			if (rSet.next()) {
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++) {
					oMap.put(rs.getColumnName(c), rSet.getObject(c));
					if (rs.getColumnName(c).endsWith("FARKLI")) {
						if (rSet.getString(c).equals("1")) {
							oMap.put("C_BASVURU_" + rs.getColumnName(c).substring(0, rs.getColumnName(c).lastIndexOf("_")), differentBackground);
							oMap.put("C_MUSTERI_" + rs.getColumnName(c).substring(0, rs.getColumnName(c).lastIndexOf("_")), differentBackground);
						}
						else {
							oMap.put("C_BASVURU_" + rs.getColumnName(c).substring(0, rs.getColumnName(c).lastIndexOf("_")), defaultBackground);
							oMap.put("C_MUSTERI_" + rs.getColumnName(c).substring(0, rs.getColumnName(c).lastIndexOf("_")), defaultBackground);
						}
					}
				}
				row++;
			}
			String roleID = GMContext.getCurrentContext().getSession().get("ROLE_ID").toString();
			GMMap pMap = new GMMap();
			pMap.put("KOD", "3889_AKS_GORECEK_ROLLER");
			pMap.put("KEY", roleID);
			pMap = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI", pMap);
			oMap.put("VISIBLE", pMap.getString("IS_EXIST"));
			oMap.put("ROW_COUNT", row);
			return oMap;
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Ba�vuru numaras�na g�re m��teri bilgileri d�ner.M��teri e�le�tirme ekran� i�in kullan�l�r.
	 * 
	 * @param iMap
	 *            - BASVURU_NO
	 * @return oMap - RESULTS
	 */
	@GraymoundService("BNSPR_QRY3889_GET_MUSTERI_ESLESTIRME_LIST")
	public static GMMap getMusteriEslestirmeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3889.RC_QRY3889_MUSTERI_ESLES_LIST(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
			return oMap;
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Bu servis save i�leminden sonra i�lem sonras� servis olarak �al���r.
	 * KK_BASVURU_FRAUD_TX tablosundaki kayd�n durumuna g�re ya kara liste yada bas�m servislerini �a��r�r.
	 * 
	 * @param iMap
	 *            - ISLEM_NO
	 */
	@GraymoundService("BNSPR_TRN3889_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		String func;
		String islemSonrasiDurumKodu;

		try {
			// Islem numarasi verilen basvurunun fraud bilgilerini al
			func = "{? = call pkg_trn3889.RC_QRY3889_GET_BASVURU_FRAUD(?) }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "KK_BASVURU_FRAUD_TX", BnsprType.STRING, iMap.getString("ISLEM_NO"));

			islemSonrasiDurumKodu = oMap.getString("KK_BASVURU_FRAUD_TX", 0, "ISLEM_SONRASI_DURUM_KODU");
			iMap.put("BASVURU_NO", oMap.getBigDecimal("KK_BASVURU_FRAUD_TX", 0, "BASVURU_NO"));

			// Basvuru fraud islemi varsa
			// son durumu RED ise
			if ("RED".equals(islemSonrasiDurumKodu)) {
				GMServiceExecuter.execute("BNSPR_TRN3889_KARA_LISTE_GONDER", iMap);
				
				//TFF basvurularinda TFF Kartini Debite cevir.
				//Session al.
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuru != null && "40".equals(kkBasvuru.getKanalKod())) {
					if (CreditCardServicesUtil.HAYIR.equals(
								CreditCardServicesUtil.nvl(kkBasvuru.getOnOnayliMi(), CreditCardServicesUtil.HAYIR))) {
						sorguMap.clear();
						sorguMap.put("KK_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						sorguMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
						sorguMap.put("ISLEM_KOD", "3889");
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap));
					}
				} else if (kkBasvuru != null && "L".equals(kkBasvuru.getKartSeviyesi())) {
					//Limit durum guncelle
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
					sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
				}
			} else if ("IPTAL".equals(islemSonrasiDurumKodu)) {
				//TFF basvurularinda TFF Kartini Debite cevir.
				//Session al.
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuru != null && "40".equals(kkBasvuru.getKanalKod())) {
					sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
					BigDecimal tffBasvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
					//Tff basvurusunu al ve iptal et.
					if (tffBasvuruNo != null) {
						TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
						session.refresh(tffBasvuru);
						
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
						sorguMap.put("ISLEM_KOD", "3889");
						sorguMap.put("GEREKCE_KOD", "2");
						sorguMap.put("ACIKLAMA", "kk iptal oldugundan tff iptal edildi");
						sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
					}
				} else if (kkBasvuru != null && "L".equals(kkBasvuru.getKartSeviyesi())) {
					//Limit durum guncelle
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
					sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
				}
				// ve son durumu BASIM ise
			} else if ("BASIM".equals(islemSonrasiDurumKodu)) {
				iMap.put("ISLEM_KODU", "FRAUD");
	  			iMap.put("DURUM_KOD", "BASIM");
				GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Bu servis, 118 sorgulama ekran� i�in m��teri bilgilerini ba�vuru numaras�na g�re getirir.
	 * Ba�vuru no ve de�er alanlar�na g�re ba�vuru tablolar�ndan kay�t �eker.
	 * 
	 * @param iMap
	 *            - BASVURU_NO, ISLEM
	 * @return oMap - MUSTERI_NO, AD, SOYAD, IL_KOD, TELEFON_TABLO
	 */
	@GraymoundService("BNSPR_QRY3889_MUSTERI_BILGI")
	public static GMMap musteriBilgiSorgulama(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
			oMap.put("HATA_NO", new BigDecimal(442));
			return oMap;
		}

		try {
			if ("BIR_BASVURU".equals(iMap.getString("ISLEM"))) {
				GMMap sMap = new GMMap();
				String func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.RC_KK_BASVURU_BILGI(?,?) }";
				Object[] inputValues = new Object[4];
				int i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = "KIMLIK";
				sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

				oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
				oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
				oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
				oMap.put("IL_KOD", sMap.get("KIMLIK_TABLO", 0, "IL_KOD"));

				sMap = new GMMap();
				inputValues = new Object[4];
				i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i] = "TELEFON";
				sMap = DALUtil.callOracleRefCursorFunction(func, "TELEFON_TABLO", inputValues);
				oMap.put("TELEFON_TABLO", sMap.get("TELEFON_TABLO"));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Bu servis Hunter'dan gelen yanita gore basvurunun durumunu guncelleyecektir.
	 * Ba�vuru no ve sonuc zorunlu alandir
	 * 
	 * @param iMap
	 *            - BASVURU_NO, HUNTER_RESULT
	 * @return oMap - 
	 */
	@GraymoundService("BNSPR_HUNTER_UPDATE_APP")
	public static GMMap hunterUpdateApp(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		String hunterResult = iMap.getString("HUNTER_RESULT");
		
		try {
			
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			
			if(kkBasvuru == null   ){
				throw new GMRuntimeException(0, "Basvuru bulunamadi");
			}
			if(!"HUNTER".equals(kkBasvuru.getDurumKod())){
				throw new GMRuntimeException(0, "Basvuru durumu HUNTER degil. Islem yapilamaz");
			}
			
			if(HUNTER_STATUS_CLEAR.equals(hunterResult))
			{
				//Basvuru durum guncelle
				iMap.put("DURUM_KOD", "BASIM");
				iMap.put("ISLEM_ACIKLAMA", hunterResult + "- Hunter'dan kabul aldi. Clear");
				
				//Kart basim
			}
			else if(HUNTER_STATUS_SUSPECT.equals(hunterResult))
			{
				//Basvuru durum guncelle
				iMap.put("DURUM_KOD", "RED");
				iMap.put("ISLEM_ACIKLAMA", hunterResult + "- Hunter ret etti. Suspect");
			}
			else if(HUNTER_STATUS_FRAUD.equals(hunterResult))
			{
				//Basvuru durum guncelle
				iMap.put("DURUM_KOD", "RED");
				iMap.put("ISLEM_ACIKLAMA", hunterResult + "- Hunter ret etti. Fraud");
			}
			else if(HUNTER_STATUS_MERCHANT_FRAUD.equals(hunterResult))
			{
				//Basvuru durum guncelle
				iMap.put("DURUM_KOD", "IPTAL");
				iMap.put("ISLEM_ACIKLAMA", hunterResult + "- Hunter iptal etti. Merchant Fraud");
			}
			else if(HUNTER_STATUS_MISSING_INCORRECT_DATA.equals(hunterResult))
			{
				//Basvuru durum guncelle
				iMap.put("DURUM_KOD", "BASVURU");
				iMap.put("ISLEM_ACIKLAMA", hunterResult + "- Hunter bilgi guncellemesi icin iade etti. Missing Incorrect Data");
			}
			else
			{
				//gecersiz durum
				sorguMap.clear();
				sorguMap.put("MESSAGE_NO", "786");
				sorguMap.put("P1", "Hunter Return Code");
				sorguMap.put("P1", hunterResult);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR", sorguMap));
				oMap.put("RESPONSE_DATA", sorguMap.get("ERROR_MESSAGE"));
				oMap.put("RESPONSE_DATA", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			}

			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			iMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			iMap.put("ISLEM_NO", oMap.get("TRX_NO"));
			iMap.put("TARIHCE_AKSIYON", "E");
			GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
			
			if(HUNTER_STATUS_CLEAR.equals(hunterResult))
			{
				iMap.put("ISLEM_KODU", "HUNTER");
	  			iMap.put("DURUM_KOD", "BASIM");
				GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
			}
			else if(HUNTER_STATUS_SUSPECT.equals(hunterResult) || 
					HUNTER_STATUS_FRAUD.equals(hunterResult) ||
					HUNTER_STATUS_MERCHANT_FRAUD.equals(hunterResult))
			{
				//TFF basvurularinda TFF Kartini Debite cevir.
				//Session al.
				
				if (kkBasvuru != null && "40".equals(kkBasvuru.getKanalKod())) {
					if (CreditCardServicesUtil.HAYIR.equals(
								CreditCardServicesUtil.nvl(kkBasvuru.getOnOnayliMi(), CreditCardServicesUtil.HAYIR))) {
						sorguMap.clear();
						sorguMap.put("KK_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						sorguMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
						sorguMap.put("ISLEM_KOD", "3889");
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap));
					}
				} else if (kkBasvuru != null && "L".equals(kkBasvuru.getKartSeviyesi())) {
					//Limit durum guncelle
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
					sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
				}
			}
			/* PY-11177
			else if(HUNTER_STATUS_MERCHANT_FRAUD.equals(hunterResult))
			{
				//TFF basvurularinda TFF Kartini Debite cevir.
				//Session al.
				
				if (kkBasvuru != null && "40".equals(kkBasvuru.getKanalKod())) {
					sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
					BigDecimal tffBasvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
					//Tff basvurusunu al ve iptal et.
					if (tffBasvuruNo != null) {
						TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
						session.refresh(tffBasvuru);
						
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
						sorguMap.put("ISLEM_KOD", "3889");
						sorguMap.put("GEREKCE_KOD", "2");
						sorguMap.put("ACIKLAMA", "kk iptal oldugundan tff iptal edildi");
						sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
					}
				} else if (kkBasvuru != null && "L".equals(kkBasvuru.getKartSeviyesi())) {
					//Limit durum guncelle
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
					sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
				}
			}
			*/
			oMap.put("RESPONSE_DATA", CreditCardServicesUtil.RESPONSE_BASARILI);
			
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_HUNTER_IS_APP_PROCESSED")
	public static GMMap isApplicationProcessedByHunter(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("ISLENDI_MI", CreditCardServicesUtil.HAYIR);

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3889.hunter_isledi_mi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			oMap.put("ISLENDI_MI", CreditCardServicesUtil.nvl(stmt.getString(1), CreditCardServicesUtil.HAYIR));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	

}
