package tr.com.aktifbank.bnspr.creditcard.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdKartDurumGecis;
import tr.com.aktifbank.bnspr.dao.CrdKartStatuKontrol;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardQRY4453Services {
    
    @GraymoundService("BNSPR_QRY4453_GET_CARD_LIST")
    public static GMMap getCardList(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap outMap = new GMMap();
        
        if (iMap.get("CUSTOMER_NO") == null){
            return oMap;
        }
        
        try{
            iMap.put("CARD_BANK_STATUS_CC" , true);
            iMap.put("NO_NEED_APPLICATIONS" , true);
            outMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN" , iMap);
            int s = outMap.getSize("CARD_DETAIL_INFO");
            
            for (int i = 0; i < s; i++){
                oMap.put("LIST" , i , "CARD_NO" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_NO"));
                oMap.put("LIST" , i , "CARD_DCI" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_DCI"));
                oMap.put("LIST" , i , "CARD_STAT_CODE" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CODE"));
                oMap.put("LIST" , i , "CARD_STAT_DESC" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_DESC"));
                oMap.put("LIST" , i , "EMBOSS_NAME" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_EMBOSS_NAME_1"));
                oMap.put("LIST" , i , "EXPIRY_DATE" , outMap.getString("CARD_DETAIL_INFO" , i , "EXPIRY_DATE"));
                
                if ("19000101".equals(outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CHANGE_DATE"))){
                    oMap.put("LIST" , i , "CARD_STAT_CHANGE_DATE" , "");
                } else{
                    oMap.put("LIST" , i , "CARD_STAT_CHANGE_DATE" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_STAT_CHANGE_DATE"));
                }
                oMap.put("LIST" , i , "CARD_UPDATE_USER" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_UPDATE_USER"));
                oMap.put("LIST" , i , "CARD_SUB_STAT_CODE" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_SUB_STAT_CODE"));
                oMap.put("LIST" , i , "CARD_GROUP_DESC" , outMap.getString("CARD_DETAIL_INFO" , i , "CARD_GROUP_DESC"));
                oMap.put("LIST" , i , "SYSTEM" , outMap.getString("CARD_DETAIL_INFO" , i , "SYSTEM"));
                
            }
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY4453_GET_STATU_LIST")
    public static GMMap getStatuList(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap xMap = new GMMap();
        if (iMap.getString("ILK_STATU") == null){
            throw new GMRuntimeException(0 , "Bir stat� se�iniz");
        }
        Session session = DAOSession.getSession("BNSPRDal");
        
        xMap.put("KOD" , "CRD_STATU_KOD");
        xMap.put("ADD_EMPTY_KEY" , "H");
        xMap.put
        ("RESULTS" , GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS" , xMap).get("RESULTS"));
        List<CrdKartDurumGecis> statuList =
                session.createCriteria(CrdKartDurumGecis.class).add(Restrictions.eq("ilkDurum" , iMap.getString("ILK_STATU"))).add(Restrictions.eq("rol" , iMap.getString("ROL"))).list();
        if (statuList.size() == 0){
            throw new GMRuntimeException(134 , "Bu stat� g�ncellemeye uygun de�il");
        }
        GuimlUtil.wrapMyCombo(oMap , "STATU_LIST" , "" , "");
        String statusName;
        String statusValue;
        for (CrdKartDurumGecis statu : statuList){
            for (int i = 0; i < xMap.getSize("RESULTS"); i++){
                statusName = xMap.getString("RESULTS" , i , "NAME");
                statusValue = xMap.getString("RESULTS" , i , "VALUE");
                if (statusValue.equals(statu.getYeniDurum())){
                    GuimlUtil.wrapMyCombo(oMap , "STATU_LIST" , statu.getYeniDurum() , statusName);
                    break;
                }
                
            }
            // for (Iterator I = ((ArrayList) xMap.get("RESULTS")).iterator(); I.hasNext();){
            //
            // }
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY4453_GET_ALT_STATU_LIST")
    public static GMMap getAltStatuList(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            List<CrdKartDurumGecis> kartDurumList = session.createCriteria(CrdKartDurumGecis.class).add(Restrictions.eq("ilkDurum" , iMap.getString("STATU"))).list();
            for (CrdKartDurumGecis statu : kartDurumList){
                GuimlUtil.wrapMyCombo(oMap , "ALT_STATU_LIST" , statu.getIlkDurum() , statu.getYeniDurum());
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY4453_SET_AREAS_ENABLED_OR_DISABLED")
    public static GMMap getYenilemeStatu(GMMap iMap) {
        GMMap oMap = new GMMap();
        if (iMap.getString("STATU") == null){
            oMap.put("YENILEME" , "false");
            oMap.put("YENILEME_DEFAULT" , "false");
            oMap.put("ALT_STATU_KOD" , "false");
            oMap.put("KALICI_KAPAMA" , "false");
            oMap.put("ALT_STATU_ZORUNLU" , "false");
            return oMap;
        }
        
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            CrdKartStatuKontrol statuKontrol = (CrdKartStatuKontrol) session.createCriteria(CrdKartStatuKontrol.class).add(Restrictions.eq("statuKod" , iMap.getString("STATU"))).uniqueResult();
            if (statuKontrol != null){
                oMap.put("YENILEME" , "E".equals(statuKontrol.getYenileme()) ? "true" : "false");
                oMap.put("YENILEME_DEFAULT" , "E".equals(statuKontrol.getYenilemeDefault()) ? "1" : "0");
                oMap.put("ALT_STATU_KOD" , "E".equals(statuKontrol.getAltStatuKod()) ? "true" : "false");
                oMap.put("KALICI_KAPAMA" , "E".equals(statuKontrol.getKaliciKapama()) ? "true" : "false");
                oMap.put("ALT_STATU_ZORUNLU" , "E".equals(statuKontrol.getAltStatuZorunlu()) ? "true" : "false");
                
            } else{
                oMap.put("YENILEME" , false);
                oMap.put("YENILEME_DEFAULT" , false);
                oMap.put("ALT_STATU_KOD" , false);
                oMap.put("KALICI_KAPAMA" , false);
                oMap.put("ALT_STATU_ZORUNLU" , "false");
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
}
