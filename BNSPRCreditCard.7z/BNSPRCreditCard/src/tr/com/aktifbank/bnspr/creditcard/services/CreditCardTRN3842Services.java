package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdemeTalepTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3842Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-7842
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *          <li>IS_CALL_CENTER - Islem kanali CC mi (E:Evet|H:Hayir)
	 *          <li>ODEME_TIPI_LIST - Odeme tipleri
	 *          <li>KURYE_TIPI_LIST - Kurye tipleri
	 *          <li>ADRES_TIPI_LIST - Adres tipleri
	 *          <li>IL_LIST - Iller
	 *          <li>PTT_TESLIMAT_NOKTASI - Ptt teslimat noktalari
	 *          <li>STAD_TESLIMAT_NOKTASI - Stad teslimat noktalari
	 *          <li>AKTIF_PTT_TESLIMAT_NOKTASI - Aktif Ptt teslimat noktalari
	 *          <li>AKTIF_STAD_TESLIMAT_NOKTASI - Aktif Stad teslimat noktalari
	 */
	@GraymoundService("BNSPR_TRN3842_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Call center mi?
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", sorguMap));
			if ("5".equals(sorguMap.getString("KANAL_KOD"))) {
				oMap.put("IS_CALL_CENTER", CreditCardServicesUtil.EVET);
			} else {
				oMap.put("IS_CALL_CENTER", CreditCardServicesUtil.HAYIR);
			}
			
			//Odeme tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("ODEME_TIPI_LIST", "TFF_WEBSERVIS_PARAM", "ODEME_TIPI", "E"));
			
			//Kurye Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KURYE_TIPI_LIST", "TFF_WEBSERVIS_PARAM", "KURYE_TIPI", "E"));
			
			//Adresi Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("ADRES_TIPI_LIST", "TFF_TESLIMAT_ADRES_KOD", "E"));
			
			// Il
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_ILLER", iMap));//IL_LIST
			
			//PTT/Stad Bilgisini al
	    	oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_PTT_STADIUM_LIST", iMap));
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-7842
	 * @param iMap - Sorgu kriterleri<br>
	 *         <li>BASVURU_NO - Tff basvuru numarasi
	 *         <li>MUSTERI_NO - Banka musteri numarasi
	 * @return oMap - Sorgu sonucu<br>
	 *         <li>BASVURU_LIST - Kriterlere uygun basvuru listesi
	 */
	@GraymoundService("BNSPR_TRN3842_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3842.Rc_Qry3842_Get_Basvuru(?,?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, "BASVURU_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>HESAP_NO - Odeme yapilacak hesap numarasi
	 *        <li>ODEME_TIPI - Odeme sekli
	 *        <li>ACIKLAMA - Islem aciklamasi
	 *        <li>ODEME_TRX_NO - Talebi girilen odeme islem numarasi
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3842_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Islem numarasi yoksa yeni bir islem numarasi al
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		if (trxNo == null) {
			trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap).getBigDecimal("TRX_NO");
		}

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruOdemeTalepTx tffBasvuruOdemeTalepTx = (TffBasvuruOdemeTalepTx) session.get(TffBasvuruOdemeTalepTx.class, trxNo);
			if (tffBasvuruOdemeTalepTx == null) {
				tffBasvuruOdemeTalepTx = new TffBasvuruOdemeTalepTx();
				tffBasvuruOdemeTalepTx.setTxNo(trxNo);
			}
			//Islem bilgilerini al.
			tffBasvuruOdemeTalepTx.setAciklama(CreditCardServicesUtil.nvl(iMap.getString("ACIKLAMA"), tffBasvuruOdemeTalepTx.getAciklama()));
			tffBasvuruOdemeTalepTx.setBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("BASVURU_NO"), tffBasvuruOdemeTalepTx.getBasvuruNo()));
			tffBasvuruOdemeTalepTx.setHesapNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("HESAP_NO"), tffBasvuruOdemeTalepTx.getHesapNo()));
			tffBasvuruOdemeTalepTx.setOdemeTipi(CreditCardServicesUtil.nvl(iMap.getString("ODEME_TIPI"), tffBasvuruOdemeTalepTx.getOdemeTipi()));
			tffBasvuruOdemeTalepTx.setOdemeTrxNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ODEME_TRX_NO"), tffBasvuruOdemeTalepTx.getOdemeTrxNo()));
			
			//Islem bilgilerini kaydet
			session.save(tffBasvuruOdemeTalepTx);
			session.flush();
			
			//Alinan islem bilgileri ile islemi sonlandir.
			sorguMap.clear();
			sorguMap.put("TRX_NAME", "3842");
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen iptal islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since PY-7842
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>BASVURU_NO - Basvuru numarasi
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>KURYE_TIPI - Kurye tipi
	 *         <li>TESLIMAT_ADRESI - Teslimat adresi
	 *         <li>IL - Teslimat adres ili
	 *         <li>ILCE - Teslimat adres ilcesi
	 *         <li>ACIK_ADRES - Teslimat acik adresi
	 *         <li>TESLIMAT_NOKTASI - PTT Sube/Stad Gise kodu
	 *         <li>TOPLAM_UCRET - Odenecek tutar
	 *         <li>ODEME_TIPI - Odeme tipi
	 *         <li>HESAP_NO - Odemenin alindigi hesap numarasi
	 */
	@GraymoundService("BNSPR_TRN3842_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ ? = call pkg_trn3842.Rc_Qry3842_Get_Islem_Info(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since
	 * @param iMap
	 *         <li>ISLEM_NO - Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3842_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruOdemeTalepTx tffBasvuruOdemeTalepTx = (TffBasvuruOdemeTalepTx) session.get(TffBasvuruOdemeTalepTx.class, trxNo);
			if (tffBasvuruOdemeTalepTx == null) {
				CreditCardServicesUtil.raiseGMError("330", "Islem numarasi");
			}
			//Basvuru bilgisini al
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruOdemeTalepTx.getBasvuruNo());
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", tffBasvuruOdemeTalepTx.getBasvuruNo());
			}
			//Odeme
			TffBasvuruOdemeTx tffBasvuruOdemeTx = (TffBasvuruOdemeTx) session.get(TffBasvuruOdemeTx.class, tffBasvuruOdemeTalepTx.getOdemeTrxNo());
			if (tffBasvuruOdemeTx == null) {
				CreditCardServicesUtil.raiseGMError("2999", tffBasvuruOdemeTalepTx.getOdemeTrxNo());
			}
			//Odeme yap
			GMMap sorguMap = new GMMap();
			BigDecimal odemeTrxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap).getBigDecimal("TRX_NO");
			sorguMap.put("TRX_NO", odemeTrxNo);
			sorguMap.put("BASVURU_NO", tffBasvuruOdemeTalepTx.getBasvuruNo());
			sorguMap.put("KURYE_TIPI", tffBasvuru.getKuryeTipi());
			sorguMap.put("ODEME_TIPI", tffBasvuruOdemeTalepTx.getOdemeTipi());
			sorguMap.put("KART_BEDELI", tffBasvuruOdemeTx.getKartBedeli());
			sorguMap.put("KURYE_BEDELI", tffBasvuruOdemeTx.getKuryeBedeli());
			sorguMap.put("LOYALTY_BEDELI", tffBasvuruOdemeTx.getLoyaltyBedeli());
			sorguMap.put("VIZE_BEDELI", tffBasvuruOdemeTx.getVizeBedeli());
			sorguMap.put("ODEME_REF_ID", odemeTrxNo);
			sorguMap.put("HESAP_NO", tffBasvuruOdemeTalepTx.getHesapNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3802_ODEME_YAP", sorguMap));
			String hataKodu = sorguMap.getString("RESPONSE_DATA");
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				sorguMap.clear();
				sorguMap.put("WEB_HATA_KOD", hataKodu);
				sorguMap.put("SOURCE", "GENEL");
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", sorguMap));
				throw new GMRuntimeException(0, "Odeme islemi sirasinda hata olustu : " + sorguMap.getString("HATA_MESAJI"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
