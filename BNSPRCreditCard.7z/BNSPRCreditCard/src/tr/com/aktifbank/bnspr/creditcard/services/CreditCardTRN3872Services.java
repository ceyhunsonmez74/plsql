package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.HashMap;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CreditCardTRN3872Services {

	@GraymoundService("BNSPR_TRN3872_GET_AKSIYON_KARAR")
	public static GMMap getMedeniHalTurleri(GMMap iMap) {
		try {
			String queryString = "select t.key2, t.text from v_ml_gnl_param_text t where t.kod = 'KK_BASVURU_AKSIYON_KARAR_KOD' and t.key1 = 'C' ";
			return DALUtil.fillComboBox(iMap, "AKSIYON_KARAR_LIST", false, queryString);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3872_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruGuncelleList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3871.RC_QRY3872_BASVURU_IZLEME_LIST(?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("KREDI_KART_TIPI"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));

			String a = "";
			Object[] selectedList = (Object[]) iMap.get("DURUM_LIST");

			if (selectedList != null && selectedList.length>0) {
				for (Object selected : selectedList) {
					HashMap<String, Object> selectedMap = (HashMap<String, Object>) selected;

					if (null == selectedMap.get("VALUE")) {
						a = a + "HEPSI,";
					}
					else {
						a = a + selectedMap.get("VALUE") + ",";
					}
				}
			}else{
			    a="HEPSI,";
			}
			
			stmt.setString(i++, a);
			if (iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.setString(i++, iMap.getString("KANAL_KODU"));
		    stmt.setString(i++, iMap.getString("BAYI_KODU"));
			
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3872_KK_BASVURU_DURUM_LIST")
	public static GMMap getBasvuruDurumList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1,text from gnl_param_text t where t.kod='KK_BASVURU_DURUM_KOD' and (key1='ON_BASVURU' or key1='BASVURU' or key1='KANALIADE') order by text");

			rSet = stmt.executeQuery();
			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, "HEPSI");

			while (rSet.next()) {
				if (rSet.getString(1).equals("KUL"))
					GuimlUtil.wrapMyCombo(oMap, listName, "KUL", "KULLANDIRIM");
				else
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN3872_KART_TIPI_LIST")
	public static GMMap getKartTipiList(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "KART_TIPI_LIST");
		iMap.put("LIST_QUERY", "select key1,text from gnl_param_text t where t.kod='KREDI_KART_TIPI'");
		return DALUtil.fillComboBox(iMap);
	}

	@GraymoundService("BNSPR_TRN3872_KANAL_LIST")
	public static GMMap getKanalList(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "KANAL_LIST");
		iMap.put("LIST_QUERY", "select p.kod, p.aciklama from bnspr.gnl_kanal_grup_kod_pr p order by 2");
		return DALUtil.fillComboBox(iMap);
	}

	@GraymoundService("BNSPR_TRN3872_GET_DATES")
	public static GMMap getDates(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Date toDay;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_muhasebe.Banka_Tarihi_Bul()}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			toDay = stmt.getDate(1);

			BigDecimal ayOnce = new BigDecimal(-1);
			stmt = conn.prepareCall("{? = call pkg_tarih.ay_sonra(?,?)}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, toDay);
			stmt.setBigDecimal(3, ayOnce);
			stmt.execute();
			oMap.put("BASLANGIC_TARIHI", stmt.getDate(1));
			oMap.put("BITIS_TARIHI", toDay);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
