package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4436Services implements OceanMapKeys {
    public static GMMap throwGMBusssinessException(String string) {
        GMMap exMap = new GMMap();
        exMap.put("P1" , string);
        exMap.put("HATA_NO" , "660");
        return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
    }
    
    @GraymoundService("BNSPR_GET_CAMPAIGN_LIST")
    public static GMMap getCampaignList(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap checkForDebitMap = new GMMap();
        try{
            GMMap cMap = new GMMap();
            
            cMap.put(CUSTOMER_NO , iMap.getString("CUSTOMER_NO"));
            cMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_AVAIL_INSTLIST" , cMap);
            if (cMap.getInt(RETURN_CODE) == OceanConstants.Result_Succesful){
                if (cMap.get(LIST) != null && cMap.getSize(LIST) > 0){
                    for (int i = 0; i < cMap.getSize(LIST); i++){
                        if (!"Passo Kart".equals(cMap.getString(LIST , i , CARD_GROUP_DESC))){
                            checkForDebitMap.put("CARD_NO" , cMap.getString(LIST , i , CARD_NO));
                            if (!"Debit".equals(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , checkForDebitMap).getString("CARD_DETAIL_INFO" , 0 , "CARD_DCI"))
                            && //!"912".equals(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , checkForDebitMap).getString("CARD_DETAIL_INFO" , 0 , "PRODUCT_ID"))
                            !KkProductsUtil.isUptPpProduct(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , checkForDebitMap).getString("CARD_DETAIL_INFO" , 0 , "PRODUCT_ID"))
                            // bug issue ok olduktan sonra troy da eklenecek		
                            		){
                                oMap.put("LIST" , i , "CARD_NO" , cMap.getString(LIST , i , CARD_NO));
                                oMap.put("LIST" , i , "MASKED_CARD_NO" , maskCardNumber(cMap.getString(LIST , i , CARD_NO)));
                                oMap.put("LIST" , i , "SUP_CARD_USE_FLAG" , cMap.getString(LIST , i , SUP_CARD_USE_FLAG));
                                oMap.put("LIST" , i , "DATE_END" , cMap.getDate(LIST , i , END_DATE));
                                oMap.put("LIST" , i , "DATE_START" , cMap.getString(LIST , i , START_DATE));
                                oMap.put("LIST" , i , "DESCRIPTION" , cMap.getString(LIST , i , INSTALL_DESC));
                                oMap.put("LIST" , i , "INSTALLMENT_CODE" , cMap.getString(LIST , i , INSTALL_CODE));
                                oMap.put("LIST" , i , "MAX_INSTALL_COUNT" , cMap.getString(LIST , i , MAX_INSTALL_COUNT));
                                oMap.put("LIST" , i , "MAX_TXN_AMOUNT" , cMap.getString(LIST , i , MAX_TXN_AMOUNT));
                                oMap.put("LIST" , i , "MIN_INSTALL_COUNT" , cMap.getString(LIST , i , MIN_INSTALL_COUNT));
                                oMap.put("LIST" , i , "MIN_TXN_AMOUNT" , cMap.getString(LIST , i , MIN_AMOUNT));
                                oMap.put("LIST" , i , "CARD_GROUP_DESC" , cMap.getString(LIST , i , CARD_GROUP_DESC));
                            }
                        }
                    }
                    
                }
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_GET_EXIST_CAMPAIGN_LIST")
    public static GMMap getExistCampaignList(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            GMMap cMap = new GMMap();
            GMMap checkForDebitMap = new GMMap();
            cMap.put(CUSTOMER_NO , iMap.getString("CUSTOMER_NO"));
            cMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_EXIST_INSTLIST" , cMap);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            if (cMap.getInt(RETURN_CODE) == OceanConstants.Result_Succesful){
                if (cMap.get(LIST) != null && cMap.getSize(LIST) > 0){
                    for (int i = 0; i < cMap.getSize(LIST); i++){
                        if (!"Passo Kart".equals(cMap.getString(LIST , i , CARD_GROUP_DESC))){
                            checkForDebitMap.put("CARD_NO" , cMap.getString(LIST , i , CARD_NO));
                            if (!"Debit".equals(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , checkForDebitMap).getString("CARD_DETAIL_INFO" , 0 , "CARD_DCI"))
                            &&// !"912".equals(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , checkForDebitMap).getString("CARD_DETAIL_INFO" , 0 , "PRODUCT_ID"))  // bug issue ok olduktan sonra troy da eklenecek
                            !KkProductsUtil.isUptPpProduct(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , checkForDebitMap).getString("CARD_DETAIL_INFO" , 0 , "PRODUCT_ID"))
                            		){
                                oMap.put("LIST" , i , "CARD_NO" , cMap.getString(LIST , i , CARD_NO));
                                oMap.put("LIST" , i , "MASKED_CARD_NO" , maskCardNumber(cMap.getString(LIST , i , CARD_NO)));
                                oMap.put("LIST" , i , "SUP_CARD_USE_FLAG" , cMap.getBoolean(LIST , i , SUP_CARD_USE_FLAG) ? "E" : "H");
                                oMap.put("LIST" , i , "DATE_END" , cMap.getDate(LIST , i , END_DATE));
                                oMap.put("LIST" , i , "DATE_START" , cMap.getString(LIST , i , START_DATE));
                                oMap.put("LIST" , i , "DESCRIPTION" , cMap.getString(LIST , i , INSTALL_DESC));
                                oMap.put("LIST" , i , "INSTALLMENT_CODE" , cMap.getString(LIST , i , INSTALL_CODE));
                                oMap.put("LIST" , i , "MAX_TXN_AMOUNT" , cMap.getString(LIST , i , MAX_TXN_AMOUNT));
                                oMap.put("LIST" , i , "INSTALL_COUNT" , cMap.getString(LIST , i , INSTALL_COUNT));
                                oMap.put("LIST" , i , "MIN_TXN_AMOUNT" , cMap.getString(LIST , i , MIN_AMOUNT));
                                oMap.put("LIST" , i , "INSERT_DATE_TIME" , sdf1.format(sdf.parse(cMap.getString(LIST , i , INSERT_DATE_TIME))));
                                oMap.put("LIST" , i , "CARD_GROUP_DESC" , cMap.getString(LIST , i , CARD_GROUP_DESC));
                            }
                        }
                    }
                }
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TAKSIT_SAYISI_AL")
    public static GMMap taksitSayisiAl(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            int j = 0;
            for (int i = iMap.getInt("MIN_TAKSIT"); i <= iMap.getInt("MAX_TAKSIT"); i++){
                oMap.put("TAKSIT_SAYISI" , j , "NAME" , i);
                oMap.put("TAKSIT_SAYISI" , j , "VALUE" , i);
                j++;
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN_4436_INSERT_SAVE")
    public static GMMap insertSave(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            GMMap oMapN = new GMMap();
            if (iMap.getBigDecimal("TRX_NO") == null){
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                iMap.put("TRX_NO" , trxNo);
            }
            GMMap cMap = new GMMap();
            cMap.put(INSTALL_COUNT , iMap.getString("TAKSIT_SAYISI"));
            cMap.put(INSTALL_CODE , iMap.getString("TAKSIT_KODU"));
            cMap.put(APPLY_TO_SUBCARD , iMap.getBoolean("EKKART"));
            cMap.put(CARD_NO , iMap.getString("CARD_NO"));
            
            oMapN = GMServiceExecuter.call("BNSPR_OCEAN_SAVE_CMP_INSTRC_INST" , cMap);
            
            if (oMapN.getInt(RETURN_CODE) != OceanConstants.Result_Succesful)
                throwGMBusssinessException(oMapN.getString(RETURN_DESCRIPTION));
            
            iMap.put("TRX_NAME" , "4436");
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN_4435_UPD_DEL_SAVE")
    public static GMMap updDelSave(GMMap iMap) {
        try{
            GMMap oMapN = new GMMap();
            if (iMap.getBigDecimal("TRX_NO") == null){
                
            }
            GMMap cMap = new GMMap();
            GMMap map = new GMMap();
            for (int i = 0; i < iMap.getSize("LIST"); i++){
                
                cMap.put(INSTALL_COUNT , iMap.getString("LIST" , i , "INSTALL_COUNT"));
                cMap.put(INSTALL_CODE , iMap.getString("LIST" , i , "INSTALLMENT_CODE"));
                cMap.put(APPLY_TO_SUBCARD , iMap.getString("LIST" , i , "SUP_CARD_USE_FLAG").equals("E") ? true : false);
                cMap.put(CARD_NO , iMap.getString("LIST" , i , "CARD_NO"));
                if (iMap.getString("LIST" , i , "UD").equals("D")){
                    oMapN = GMServiceExecuter.call("BNSPR_OCEAN_DELETE_CMP_INSTRC_INST" , cMap);
                    if (oMapN.getInt(RETURN_CODE) != OceanConstants.Result_Succesful){
                        throwGMBusssinessException(oMapN.getString(RETURN_DESCRIPTION));
                    }
                    oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                    BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                    iMap.put("TRX_NO" , trxNo);
                    iMap.put("TRX_NAME" , "4435");
                    map.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
                }
                
            }
            return map;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    public static String maskCardNumber(String cardNumber) {
        
        // format the number
        return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})" , "$1 **** **** $3");
    }
    
}