package tr.com.aktifbank.bnspr.creditcard.services;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanMapKeys;










import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CreditCardQRY4479Services implements OceanMapKeys{
	private static final Logger logger = Logger.getLogger(CreditCardQRY4479Services.class);

	
	@GraymoundService("BNSPR_QRY4479_BLOKE_SORGULA")
    public static GMMap ppBlokSorgula(GMMap iMap) throws SQLException {
		
        ValidateRequest(iMap);
        GMMap oMap = new GMMap();    
        try{
        	logger.info("AKTIF_BLOKE_MI"  +  iMap.getString("AKTIF_BLOKE_MI"));
        	logger.info("PASIF_BLOKE_MI"  +  iMap.getString("PASIF_BLOKE_MI"));

        	String ps_aktif ="";
        	if("E".equals(iMap.getString("AKTIF_BLOKE_MI")) && "H".equals(iMap.getString("PASIF_BLOKE_MI"))){
        		ps_aktif = "E";
        	}
        		
        	if("E".equals(iMap.getString("PASIF_BLOKE_MI")) && "H".equals(iMap.getString("AKTIF_BLOKE_MI"))){
        		ps_aktif="H";
        	}
        	
        	logger.info("ps_aktif"  +  ps_aktif);

        	String tableName = "TABLE_LIST";
        	String func = "{? = call PKG_TRN4478.get_bloke_listesi(?,?,?,?,?,?)}";
    	    Object[] inputValues =
    	            new Object[] { BnsprType.STRING, iMap.getString("MUSTERI_NO"), 
    	    		BnsprType.STRING, iMap.getString("KART_NO"), 
    	    		BnsprType.STRING, iMap.getString("BLOKE_REFERANS"), 
    	    		BnsprType.DATE, iMap.getDate("BASLANGIC_TARIH"),
    	    		BnsprType.DATE, iMap.getDate("BITIS_TARIH"),
    	    		BnsprType.STRING, ps_aktif};
    	    
    	    oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
    	    
    	    if (oMap.getSize(tableName) == 0){
    	    	throw new GMRuntimeException(447802, "Kay�t bulunamad�.");
    	    }else{
    	    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
    			String blokeCozTarih="";
    			String blokeKoyTarih="";
//    			BigDecimal bdBlokeCozTarih= BigDecimal.ZERO;
//    			BigDecimal bdBlokeKoyTarih=BigDecimal.ZERO;
    	    	for(int i=0; i<oMap.getSize(tableName);i++){
    	    		logger.info("BLOKE_KOY  "  + oMap.get(tableName, i, "BLOKE_KOY"));

    	    		if("E".equals(oMap.get(tableName, i, "BLOKE_KOY"))){
            	    	oMap.put(tableName, i, "DURUM", "Bloke Konuldu");
            	    }else{
            	    	oMap.put(tableName, i, "DURUM", "Bloke ��z�ld�");
            	    }
    	    		
    	    		logger.info("blokeCozTarih  "  + oMap.getString(tableName, i, "BLOKE_COZME_TARIHI"));
    	    		blokeCozTarih=  oMap.getString(tableName, i, "BLOKE_COZME_TARIHI");
    	    		
    	    		 if(blokeCozTarih !=null){
    	    			// blokeCozTarih = bdBlokeCozTarih.toString();
    	    	    		oMap.put(tableName, i, "BLOKE_COZME_TARIHI" , sdf1.format(sdf.parse(blokeCozTarih)));
    	    		 }
    	    		 else{
    	    			 oMap.put(tableName, i, "BLOKE_COZME_TARIHI" , "");
    	    		 }
     	    		logger.info("blokeKoyTarih  "  + oMap.getString(tableName, i, "BLOKE_KOYMA_TARIHI"));

     	    		blokeKoyTarih= oMap.getString(tableName, i, "BLOKE_KOYMA_TARIHI");
    	    		 if(blokeKoyTarih!=null){
        	    		 //blokeKoyTarih = bdBlokeKoyTarih.toString();

    	    	    		oMap.put(tableName, i, "BLOKE_KOYMA_TARIHI" , sdf1.format(sdf.parse(blokeKoyTarih)));
    	    		 }else{
 	    	    		oMap.put(tableName, i, "BLOKE_KOYMA_TARIHI" , "");

    	    		 }
    	    		
    	    	}	
    	    }   	         	
        }catch(Exception e){
        	throw ExceptionHandler.convertException(e);
        }
  
        return oMap;
    }
	
    
    private static void ValidateRequest(GMMap iMap) {
        
        if (StringUtils.isBlank(iMap.getString("KART_NO")) && StringUtils.isBlank(iMap.getString("BASLANGIC_TARIH"))
        		&& StringUtils.isBlank(iMap.getString("BITIS_TARIH"))
        		&& StringUtils.isBlank(iMap.getString("BLOKE_REFERANS"))
        		&& StringUtils.isBlank(iMap.getString("MUSTERI_NO"))){
        	
        	throw new GMRuntimeException(447801, "En az bir sorgu kriteri giriniz.");
      
        }
	
    }
    public static void main(String[] args) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");

		String blokeKoyTarih ="20210208";
		// blokeKoyTarih = bdBlokeKoyTarih.toString();
		System.out.println(blokeKoyTarih);
		String formatted= sdf1.format(sdf.parse(blokeKoyTarih));
		System.out.println(formatted);

		//SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		//System.out.println(sdf1.format(blokeKoyTarih));

		

		
	}
}
