package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuruIptalTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonGrupTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrunTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrunTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3812Services {

	private static final String ISLEM_KODU = "3812";

	@GraymoundService("BNSPR_TRN3812_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			String func = "{? = call PKG_TRN3812.Urun_Listesi}";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "GECERLI_URUN"));

			GMMap xMap = new GMMap().put("TABLE_NAME", "TFF_BASVURU_PROMOSYON_GRUP");
			BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
			oMap.put("GRUP_ID", id);

			oMap.put("TIP", 0, "NAME", "Evet");
			oMap.put("TIP", 0, "VALUE", "1");

			oMap.put("TIP", 1, "NAME", "Hay�r");
			oMap.put("TIP", 1, "VALUE", "2");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3812_GET_GRUP_ID")
	public static GMMap getGrupId(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			GMMap xMap = new GMMap().put("TABLE_NAME", "TFF_BASVURU_PROMOSYON_GRUP");
			BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
			oMap.put("GRUP_ID", id);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3812_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null) {
				trxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO").toString());
			}

			if (iMap.getBigDecimal("GRUP_ID") == null) {
				CreditCardServicesUtil.raiseGMError("4315");
			}

			if ("".equals(iMap.getString("GRUP_ADI")) || iMap.getString("GRUP_ADI") == null) {
				CreditCardServicesUtil.raiseGMError("4316");
			}

			if (iMap.getBigDecimal("ADET") == null) {
				CreditCardServicesUtil.raiseGMError("4327");
			}

			if (iMap.getDate("BASLANGIC_TARIHI") == null) {
				CreditCardServicesUtil.raiseGMError("4318");
			}

			if (iMap.getDate("BITIS_TARIHI") == null) {
				CreditCardServicesUtil.raiseGMError("4319");
			}

			if (iMap.getBigDecimal("TIP") == null) {
				CreditCardServicesUtil.raiseGMError("4324");
			}
			if (iMap.getBigDecimal("KART_BEDELI") == null) {
				CreditCardServicesUtil.raiseGMError("4320");
			}
			if (iMap.getBigDecimal("KURYE_BEDELI") == null) {
				CreditCardServicesUtil.raiseGMError("4321");
			}
			if (iMap.getBigDecimal("LOYALTY_BEDELI") == null) {
				CreditCardServicesUtil.raiseGMError("4322");
			}
			if (StringUtils.isBlank(iMap.getString("DIZIN"))) {
				CreditCardServicesUtil.raiseGMError("4349");
			}
			if (iMap.getBigDecimal("VIZE_BEDELI") == null) {
				CreditCardServicesUtil.raiseGMError("4323");
			}
			if (!iMap.getBoolean("KANAL_WEB") && !iMap.getBoolean("KANAL_MOBIL") && !iMap.getBoolean("KANAL_EPOS") && !iMap.getBoolean("KANAL_GISE") && !iMap.getBoolean("KANAL_BATCH")) {
				CreditCardServicesUtil.raiseGMError("4325");
			}
			if (!iMap.getBoolean("TIP_KK") && !iMap.getBoolean("TIP_D") && !iMap.getBoolean("TIP_P")) {
				CreditCardServicesUtil.raiseGMError("4326");
			}

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruPromosyonGrupTx grpTx = new TffBasvuruPromosyonGrupTx();
			grpTx.setTxNo(trxNo);
			grpTx.setGrupId(iMap.getBigDecimal("GRUP_ID"));
			grpTx.setGrupAdi(iMap.getString("GRUP_ADI"));
			grpTx.setKanalWeb(iMap.getBoolean("KANAL_WEB") ? BigDecimal.ONE : BigDecimal.ZERO);
			grpTx.setKanalMobil(iMap.getBoolean("KANAL_MOBIL") ? BigDecimal.ONE : BigDecimal.ZERO);
			grpTx.setKanalEpos(iMap.getBoolean("KANAL_EPOS") ? BigDecimal.ONE : BigDecimal.ZERO);
			grpTx.setKanalGise(iMap.getBoolean("KANAL_GISE") ? BigDecimal.ONE : BigDecimal.ZERO);
			grpTx.setKanalBatch(iMap.getBoolean("KANAL_BATCH") ? BigDecimal.ONE :BigDecimal.ZERO );

			grpTx.setTipKk(iMap.getBoolean("TIP_KK") ? BigDecimal.ONE : BigDecimal.ZERO);
			grpTx.setTipD(iMap.getBoolean("TIP_D") ? BigDecimal.ONE : BigDecimal.ZERO);
			grpTx.setTipP(iMap.getBoolean("TIP_P") ? BigDecimal.ONE : BigDecimal.ZERO);

			grpTx.setAdet(iMap.getBigDecimal("ADET"));

			grpTx.setBaslangicTarihi(iMap.getDate("BASLANGIC_TARIHI"));
			grpTx.setBitisTarihi(iMap.getDate("BITIS_TARIHI"));

			grpTx.setTip(iMap.getString("TIP"));

			grpTx.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
			grpTx.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
			grpTx.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
			grpTx.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));

			// Islem bilgilerini kaydet
			session.save(grpTx);
			session.flush();

			List<?> listGecerliUrun = (List<?>) iMap.get("GECERLI_URUN");
			String tableName = "GECERLI_URUN";
			if (listGecerliUrun != null) {
				for (int i = 0; i < listGecerliUrun.size(); i++) {
					if (iMap.getBoolean(tableName, i, "SEC")) {
						TffBasvuruPromosyonUrunTx urunTx = new TffBasvuruPromosyonUrunTx();
						TffBasvuruPromosyonUrunTxId urunId = new TffBasvuruPromosyonUrunTxId();

						urunId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						urunId.setGrupId(iMap.getBigDecimal("GRUP_ID"));
						urunId.setGecerliUrun(iMap.getString(tableName, i, "KOD"));
						urunTx.setId(urunId);
						session.save(urunTx);
						session.flush();
					}
				}
			}

			// Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", ISLEM_KODU);
			islemMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3812_GET_PROMOSYON_KODLARI", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3812_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		// Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			// Varsa islem numarasina ait bilgiyi al
			TffBasvuruIptalTx tffBasvuruIptalTx = (TffBasvuruIptalTx) session.get(TffBasvuruIptalTx.class, trxNo);
			if (tffBasvuruIptalTx != null) {
				oMap.put("BASVURU_NO", tffBasvuruIptalTx.getBasvuruNo());
				oMap.put("ONCEKI_DURUM_KOD", tffBasvuruIptalTx.getOncekiDurumKod());
				oMap.put("GEREKCE_KOD", tffBasvuruIptalTx.getGerekceKod());
				oMap.put("ACIKLAMA", tffBasvuruIptalTx.getAciklama());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3812_GET_PROMOSYON_KODLARI")
	public static GMMap getPromosyonKodlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			BigDecimal gi = iMap.getBigDecimal("GRUP_ID");

			String fileName = "Promosyon_" + gi.toString() + "_";
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();

			headers.put("GRUP_ID", new String[] { "Grup ID" });
			headers.put("GRUP_ADI", new String[] { "Grup Ad�" });
			headers.put("PROMOSYON_KODU", new String[] { "Promosyon Kodu" });
			headers.put("ADET", new String[] { "Adet" });
			headers.put("OLUSTURULAN_TARIH", new String[] { "Olu�turulan Tarih" });
			headers.put("SON_KULLANIM_TARIHI", new String[] { "Son Kullan�m Tarihi" });
			headers.put("GECERLI_TAKIMLAR", new String[] { "Ge�erli Tak�mlar" });

			oMap.put("HEADERS", headers);
			oMap.put("FILE_NAME", fileName);
			oMap.put("CHANGE_PAGE_DIRECTION", false);

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.flush();

			String func = "{? = call PKG_TRN3812.Promosyon_Kodu_Listesi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("GRUP_ID") };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TABLE_DATA", inputValues));

			oMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", oMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3812_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();

		// Variables

		try {
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3812_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBoolean("CHECKED")) {
				for (int i = 0; i < iMap.getSize("URUN_LISTE"); i++) {
					iMap.put("URUN_LISTE", i, "SEC", true);
				}
			}
			else {
				for (int i = 0; i < iMap.getSize("URUN_LISTE"); i++) {
					iMap.put("URUN_LISTE", i, "SEC", false);
				}
			}
			oMap.put("URUN_LISTE", iMap.get("URUN_LISTE"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}

}
