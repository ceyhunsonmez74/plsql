package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdDebitTransferBakiye;
import tr.com.aktifbank.bnspr.dao.SbaOdemeiptaliTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4496Services implements OceanMapKeys{
	

	@GraymoundService("BNSPR_TRN4496_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaOdemeiptaliTx sbaOdemeIptaliTx = new SbaOdemeiptaliTx();
			sbaOdemeIptaliTx.setAciklama(iMap.getString("ACIKLAMA"));
			sbaOdemeIptaliTx.setAliciHesapNo(iMap.getString("ALICI_DK"));
			sbaOdemeIptaliTx.setAliciHesapCinsi(iMap.getString("ALICI_HESAP_CINSI"));
			sbaOdemeIptaliTx.setAliciSube(iMap.getString("ALICI_SUBE"));
			sbaOdemeIptaliTx.setBorcHesapNo(iMap.getString("BORC_DK"));
			sbaOdemeIptaliTx.setBorcHesapCinsi(iMap.getString("BORC_HESAP_CINSI"));
			sbaOdemeIptaliTx.setBorcSube(iMap.getString("BORC_SUBE"));
			sbaOdemeIptaliTx.setIslem(iMap.getString("ISLEM"));
			sbaOdemeIptaliTx.setKartNo(iMap.getString("KART_NO"));
			sbaOdemeIptaliTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			sbaOdemeIptaliTx.setTutar(iMap.getBigDecimal("TUTAR"));
			sbaOdemeIptaliTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			sbaOdemeIptaliTx.setBankaAciklama(iMap.getString("BANKA_ACIKLAMA"));
			session.saveOrUpdate(sbaOdemeIptaliTx);
			session.flush();
			
			iMap.put("TRX_NAME" , "4496");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
	        
	       withdrawFromDebitCardTopupBalance(iMap);
		    
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4496_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaOdemeiptaliTx sbaOdemeIptaliTx = (SbaOdemeiptaliTx) session.createCriteria(SbaOdemeiptaliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("ACIKLAMA", sbaOdemeIptaliTx.getAciklama());
			oMap.put("ALICI_DK", sbaOdemeIptaliTx.getAliciHesapNo());
			oMap.put("ALICI_SUBE", sbaOdemeIptaliTx.getAliciSube());
			oMap.put("ALICI_HESAP_CINSI", sbaOdemeIptaliTx.getAliciHesapCinsi());
			oMap.put("BORC_DK", sbaOdemeIptaliTx.getBorcHesapNo());
			oMap.put("BORC_SUBE", sbaOdemeIptaliTx.getBorcSube());
			oMap.put("BORC_HESAP_CINSI", sbaOdemeIptaliTx.getBorcHesapCinsi());
			oMap.put("ISLEM", sbaOdemeIptaliTx.getIslem());
			oMap.put("KART_NO", sbaOdemeIptaliTx.getKartNo());
			oMap.put("MUSTERI_NO",sbaOdemeIptaliTx.getMusteriNo());
			oMap.put("TUTAR", sbaOdemeIptaliTx.getTutar());
			oMap.put("BANKA_ACIKLAMA", sbaOdemeIptaliTx.getBankaAciklama());
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4496_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			

			GMMap iMapx = new GMMap();
			SbaOdemeiptaliTx sbaOdemeIptaliTx = (SbaOdemeiptaliTx) session.createCriteria(SbaOdemeiptaliTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			if (sbaOdemeIptaliTx.getAliciHesapCinsi().equals("DK")){
			iMapx.put(BSMV_RATE, BigDecimal.ZERO);
			iMapx.put(KKF_RATE, BigDecimal.ZERO);
			
			iMapx.put(TXN_AMOUNT, sbaOdemeIptaliTx.getTutar());
			iMapx.put(CARD_NO, sbaOdemeIptaliTx.getKartNo());
			
			iMapx.put(TXN_CURR_CODE, "TRY");
			iMapx.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
			iMapx.put(TXN_STATE, "N");

			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			iMapx.put(TXN_DATE, format.format(new Date()));
			iMapx.put(TXN_DESC, "Passcard iadesi");
			if(sbaOdemeIptaliTx.getAliciHesapNo().equals(getGlobalParam("KK_FINANSAL_BAKIM_HESAP"))){
				iMapx = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", iMapx);
			}
			else if(sbaOdemeIptaliTx.getAliciHesapNo().equals(getGlobalParam("PP_FINANSAL_BAKIM_HESAP"))){
				iMapx = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", iMapx);
			}
			if (!iMapx.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
				throw new GMRuntimeException(4448011, "Kart Transfer : "+ iMapx.getString(RETURN_DESCRIPTION));
			}
			
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4496_ACIKLAMA_OLUSTUR")
	public static GMMap aciklamaOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		if(iMap.getString("ISLEM").equals("1")){
			iMap.put("MESSAGE_NO", "5504");
			iMap.put("P1", iMap.getString("KART_NO"));
			oMap.put("BANKA_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
			iMap.put("P1", kartMaskele(iMap.getString("KART_NO")));
			oMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
		}
		else if(iMap.getString("ISLEM").equals("2")){
			iMap.put("MESSAGE_NO", "5505");
			iMap.put("P1", iMap.getString("KART_NO"));
			oMap.put("BANKA_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
			iMap.put("P1", kartMaskele(iMap.getString("KART_NO")));
			oMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
		}
		else if (iMap.getString("ISLEM").equals("3")){
			iMap.put("MESSAGE_NO", "5506");
			oMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
			oMap.put("BANKA_ACIKLAMA", oMap.getString("ACIKLAMA"));
		}
		
		
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	private static void withdrawFromDebitCardTopupBalance(GMMap iMap) {
		
		CrdDebitTransferBakiye crdDebitTransferBakiye = findTopupRecord(iMap.getBigDecimal("HESAP_NO"));
		BigDecimal bTutar = iMap.getBigDecimal("TUTAR");
		if (crdDebitTransferBakiye != null){
			BigDecimal dusBakiye = BigDecimal.ZERO;
		    
		    if (bTutar.compareTo(crdDebitTransferBakiye.getBakiye()) > 0){
		        dusBakiye = crdDebitTransferBakiye.getBakiye();
		    } else{
		        dusBakiye = bTutar;
		    }
		    
		    GMMap bkyMap = new GMMap();
		    bkyMap.put("HESAP_NO" , iMap.getBigDecimal("HESAP_NO"));
		    bkyMap.put("TUTAR" , dusBakiye.multiply(BigDecimal.valueOf(-1)));
		    bkyMap.put("EXTERNAL_TRX_ID" , iMap.getString("TRX_NO"));
		    
		    GMServiceExecuter.call("BNSPR_TRANSFER_TO_DEBIT_FROM_CREDIT" , bkyMap);
		}
	}
    
	private static CrdDebitTransferBakiye findTopupRecord(BigDecimal accountNo) {
    Session session = DAOSession.getSession("BNSPRDal");
    CrdDebitTransferBakiye crdDebitTransferBakiye = (CrdDebitTransferBakiye) session.createCriteria(CrdDebitTransferBakiye.class).add(Restrictions.eq("hesapNo" , accountNo)).uniqueResult();
    return crdDebitTransferBakiye;
	}
	private static String kartMaskele (String kartNo){
				    // format the number
		    return kartNo.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})", "$1 **** **** $3");
	}
	@GraymoundService("BNSPR_TRN4496_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
        iMap.put("KOD", "ONUS_ISLEM_IADESI_ISLEMLERI");
        oMap.put("COMBO_OUT", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4496_GET_CARD_LIST")
	public static GMMap getCardList (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap cMap = new GMMap();
			GMMap lMap = new GMMap();
			cMap.put(INPUT_PARAMETER_TYPE, "CST");
			cMap.put(CUSTOMER_NO, iMap.getBigDecimal("MUST_NO"));
			cMap.put("NO_NEED_APPLICATIONS", true);
			lMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", cMap);
			
			int s = lMap.getSize("CARD_DETAIL_INFO"); 
			int j=0;
			for (int i = 0; i < s; i++) {
				String dci = lMap.getString("CARD_DETAIL_INFO",i,"CARD_DCI_AKUSTIK");
				
				oMap.put("TABLO",j, "CARD_NO",lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"));
				oMap.put("TABLO",j, "CUSTOMER_NO",lMap.getBigDecimal("CARD_DETAIL_INFO",i,"CUSTOMER_NO"));
				oMap.put("TABLO",j, "CARD_DCI",dci);
				oMap.put("TABLO",j, "CARD_STAT_DESC",lMap.getString("CARD_DETAIL_INFO",i,"CARD_STAT_DESC"));
				oMap.put("TABLO",j, "CARD_EMBOSS_NAME",lMap.getString("CARD_DETAIL_INFO",i,"CARD_EMBOSS_NAME_1"));
				if (dci.equals("C")){
					oMap.put("TABLO",j,"ALICI_DK",getGlobalParam("KK_FINANSAL_BAKIM_HESAP"));
					oMap.put("TABLO",j,"ALICI_SUBE",998);
					oMap.put("TABLO",j,"ALICI_HESAP_CINSI","DK");
					oMap.put("TABLO",j,"BORC_DK",getGlobalParam("TFF_BILET_BORC_KREDI_KARTI"));
					oMap.put("TABLO",j,"BORC_SUBE",998);
					oMap.put("TABLO",j,"BORC_HESAP_CINSI","DK");
				}
				else if (dci.equals("P")){
					oMap.put("TABLO",j,"ALICI_DK",getGlobalParam("PP_FINANSAL_BAKIM_HESAP"));
					oMap.put("TABLO",j,"ALICI_SUBE",997);
					oMap.put("TABLO",j,"ALICI_HESAP_CINSI","DK");
					oMap.put("TABLO",j,"BORC_DK",getGlobalParam("TFF_BILET_BORC_PREPAID"));
					oMap.put("TABLO",j,"BORC_SUBE",997);
					oMap.put("TABLO",j,"BORC_HESAP_CINSI","DK");
				}else if(dci.equals("D")){
					
		            GMMap sMap = new GMMap();
		            GMMap cardProperty = new GMMap();
		            String cardNo =lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO");
		            cardProperty.put("CARD_NO" , cardNo);
		            cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cardProperty);
		            String dest = cardProperty.getString("DESTINATION");
		            BigDecimal hesapNo= getDebitAccountNo(lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"), dest);
	            	sMap.put("HESAP_NO", hesapNo);
	            	oMap.put("TABLO",j,"ALICI_DK",hesapNo);
					oMap.put("TABLO",j,"ALICI_SUBE",GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", sMap).getString("SUBE_KODU"));
					oMap.put("TABLO",j,"ALICI_HESAP_CINSI","VS");
					oMap.put("TABLO",j,"BORC_DK",getGlobalParam("TFF_BILET_BORC_PREPAID"));
					oMap.put("TABLO",j,"BORC_SUBE",997);
					oMap.put("TABLO",j,"BORC_HESAP_CINSI","DK");
				}
				j=j+1;
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@SuppressWarnings("unchecked")
    private static BigDecimal getDebitAccountNo(String cardNo, String dest) {
        try{
            GMMap cardInfoMap = new GMMap();
            cardInfoMap.put("CARD_NO" , cardNo);
            cardInfoMap.put("CARD_DCI" , "A");
            
            if (dest.equals("O")){
                cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , cardInfoMap);
            } else{
                cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO" , cardInfoMap);
            }
            if (!cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_STAT_CODE).equals("N") || !cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_SUB_STAT_CODE).equals("N")){
            
            	return BigDecimal.ZERO;
            }
            List<GMMap> cardAccount = (List<GMMap>) cardInfoMap.get("CARD_DETAIL_INFO" , 0 , "DEBIT_ACCOUNT_LIST");
            GMMap accMap = new GMMap(cardAccount.get(0));
            
            for (int i = 0; i < accMap.getSize("DEBIT_ACCOUNT_LIST"); i++){
                
                if (accMap.getString("DEBIT_ACCOUNT_LIST" , i , "DEBIT_ACCOUNT_TYPE").equals("A")){
                    
                    return accMap.getBigDecimal("DEBIT_ACCOUNT_LIST" , i , "DEBIT_ACCOUNT_NO");
                }
            }
            return BigDecimal.ZERO;
        } catch (Exception e){
            return BigDecimal.ZERO;
        }
    }
	
}
