package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyon;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonGrup;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrun;
import tr.com.aktifbank.bnspr.dao.TffBasvuruPromosyonUrunId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruVdOdemeTx;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.dao.TffVadeYenilemeBatchislem;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import common.Logger;

public class CreditCardTRN3828Services {
	private static final Logger logger = Logger.getLogger(CreditCardTRN3828Services.class);
	
	public static final BigDecimal PROMOSYON_DURUM_UYGUN= BigDecimal.ZERO;
	public static final BigDecimal PROMOSYON_DURUM_KULLANILDI= BigDecimal.ONE;
	public static final BigDecimal PROMOSYON_DURUM_PASIF=  BigDecimal.ONE.negate();
 
	public static final String BASVURU = "BASVURU";
	
	public static final String POS_APPROVED = "Approved";
	public static final String POS_DECLINED = "Declined";
	public static final String POS_ERROR = "Error";
	public static final String POS_DEFAULT_CURRENCY = "949";
    private static final String MOBILE_SRC = "MBL01";
	private static final String CARD_DELIVERY_TYPE_POST = "P";


	@GraymoundService("BNSPR_VADE_YENILEME_ODEME_GUNCELLE")
	public static GMMap tffBasvuruSktOdemeGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		boolean islemBasarili = StringUtils.isEmpty(iMap.getString("ISLEM_BASARISIZ"))?true:("E".equals(iMap.getString("ISLEM_BASARISIZ"))?false:true);
		String islemNo = "";
		String basvuruNo = "";
		if ( StringUtils.isNotEmpty(iMap.getString("BASVURU_NO")) ){
			StringTokenizer stringTokenizer = new StringTokenizer(iMap.getString("BASVURU_NO"),"-");
			basvuruNo = stringTokenizer.nextToken();
			if ( stringTokenizer.hasMoreTokens()){
				islemNo = stringTokenizer.nextToken();
			}
			
		}
		if ( StringUtils.isNotEmpty(iMap.getString("ISLEM_NO")) ){
			islemNo =iMap.getString("ISLEM_NO") ;
			
		}
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, new BigDecimal(basvuruNo));
		if (tffBasvuru != null) {			
			TffBasvuruVdOdemeTx basvuruVdOdemeTx = (TffBasvuruVdOdemeTx)session.get(TffBasvuruVdOdemeTx.class, new BigDecimal(islemNo));			

				if ( StringUtils.isEmpty(islemNo) ){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_ISLEM_NO_EKSIK_HATASI);
					return oMap;
				}
				iMap.put("TRX_NO", islemNo);
				logger.info("----tffBasvuruVdOdemeGuncelle  TRX_NO " + iMap.getString("TRX_NO"));
				logger.info("----tffBasvuruVdOdemeGuncelle  ODEME_REF_ID " + iMap.getString("ODEME_REF_ID"));
				logger.info("----tffBasvuruVdOdemeGuncelle  BASVURU_NO " + iMap.getString("BASVURU_NO"));

				basvuruVdOdemeTx.setOdemeRefId(iMap.getString("ODEME_REF_ID"));
				session.saveOrUpdate(basvuruVdOdemeTx);
				session.flush();

				GMServiceExecuter.call("BNSPR_TRN3828_MUH_ISLEM_GUNCELLE", iMap);
				
				if (islemBasarili){
					//vade yenileme kayd�n� at�yoruz
					tffBasvuru.setVdBasvuruNo(tffBasvuru.getBasvuruNo());
					session.saveOrUpdate(tffBasvuru);
					session.flush();
					
					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "O");
					onayMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));

					List<TffBasvuruAdres> baList = session.createCriteria(TffBasvuruAdres.class)
							.add(Restrictions.eq("teslimatAdresiMi", "E")).add(Restrictions.eq("id.basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("uyeAdresNo")).list();
					if(baList.size() < 1){
						logger.info("----tffBasvuruVdOdemeGuncelle(GMMap)  TESLIMAT_ADRESI_YOK basvuru:  " + iMap.getString("BASVURU_NO"));
						
						List<TffBasvuruAdresTx> txList = session.createCriteria(TffBasvuruAdresTx.class)
								.add(Restrictions.eq("teslimatAdresiMi", "E")).add(Restrictions.eq("basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("uyeAdresNo")).list();
						if(txList.size()> 0 ){
							TffBasvuruAdresTx lastRec = txList.get(0);
							for(TffBasvuruAdres b: baList){
								if(b.getId().getAdresKod().equals(lastRec.getId().getAdresKod())){
									b.setTeslimatAdresiMi("E");
									session.save(b);
									session.flush();
									break;
								}
							}
						}
					}
				
				}
				else{
					
					GMMap onayRedMap = new GMMap();
					onayRedMap.put("ISLEM_TURU", "OR");
					onayRedMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayRedMap));

				}
				oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI);

		}
		else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_BASVURU_BULUNAMADIL_HATASI);
		}

		return oMap;

	}

	@GraymoundService("BNSPR_VADE_YENILEME_ODEME_YAP")
	public static GMMap tffBasvuruSktOdemeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
				
			// Ana tablolara kayitlari kaydet
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			boolean islemiOnayla = false;
			String odemeRefID= "";
			String kuryeTipi = "";
			
			
			if("NTS02".equals(iMap.getString("SOURCE"))){
				String giseID	= iMap.getString("GISE_ID");
				String giseUser	= iMap.getString("GISE_USER");
				
				if(StringUtils.isBlank(giseID)){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA","0219");
					return oMap;
				}
				if(StringUtils.isBlank(giseUser)){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA","0218");
					return oMap;
				}
			}
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			
			session.refresh(tffBasvuru);
			if (tffBasvuru != null) {
				if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
					GMMap tMap = new GMMap();
					tMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
					iMap.put("TRX_NO", tMap.getString("TRX_NO"));
					
				}
				
				boolean tcVatandasiMi = false;
				if (StringUtils.isNotEmpty(tffBasvuru.getTcKimlikNo())){
					tcVatandasiMi = true;
				}
				
				 kuryeTipi =  getKuryeTipi(iMap.getString("SOURCE"), iMap.getString("KURYE_TIPI",""), tcVatandasiMi);
		
				
				//TODO: SMS basvuruda teslimat kurye olmak zorunda KK oldugundan.
				//kurye tipi degisir duruma gelirse fiyat degisir, eski yarat�lan TX hatal� tutarli olur,
				//bunun iptal edilip yeni tx yaratmak lazim.
				//asagidaki islem ayni txte oldugu icin bu kontrolu pas gecer
				/*if(StringUtils.isNotBlank(tffBasvuru.getKuryeTipi()) && !tffBasvuru.getKuryeTipi().equals(kuryeTipi)){
					isKuryeTipiChanged = true;
				}*/
				
					if ( "D".equals(iMap.getString("ODEME_TIPI")) ||"S".equals(iMap.getString("ODEME_TIPI")) || "V".equals(iMap.getString("ODEME_TIPI")) ) { //  sanal pos,eupt icin trx sonlandirma, odeme bekle yap. + vodafone
						islemiOnayla = false;
					}
					else if ("I".equals(iMap.getString("ODEME_TIPI")) || "F".equals(iMap.getString("ODEME_TIPI")) || "N".equals(iMap.getString("ODEME_TIPI")) || "H".equals(iMap.getString("ODEME_TIPI")) ) {//fiziksel pos ya da nakit icin odeme zaten manuel yapilmis. islemi sonlandir.
						islemiOnayla = true;
					}
					odemeRefID = iMap.getString("ODEME_REF_ID");

			}
			else{
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_BASVURU_BULUNAMADI_HATASI);
				return oMap;
			}
			if (StringUtils.isNotEmpty(iMap.getString("TESLIMAT_ADRES_NO"))){
				BigDecimal teslimatNo = iMap.getBigDecimal("TESLIMAT_ADRES_NO");
				logger.info("----tffBasvuruOdemeYap  TESLIMAT_ADRES_NO" + iMap.getBigDecimal("TESLIMAT_ADRES_NO"));
				List<TffBasvuruAdres> baList = session.createCriteria(TffBasvuruAdres.class)
						.add(Restrictions.eq("uyeAdresNo", teslimatNo)).add(Restrictions.eq("id.basvuruNo", tffBasvuru.getBasvuruNo())).addOrder(Order.desc("id.basvuruNo")).list();
				TffBasvuruAdres ba = null;
				logger.info("----tffBasvuruOdemeYap  Adres SIZE " + baList.size());
				if(baList.size() > 0){
					ba = baList.get(0);
				}
				try {
					if (ba != null) {
						GMMap adresMap = new GMMap();
						adresMap.put("UYE_NO", tffBasvuru.getTffUyeNo());
						logger.info("----tffBasvuruOdemeYap  UYE_NO " + tffBasvuru.getTffUyeNo());
						adresMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						adresMap.put("ADRES_TIPI", ba.getId().getAdresKod());
						logger.info("----tffBasvuruOdemeYap  ADRES_TIPI " + ba.getId().getAdresKod());
						adresMap.put("ADRES_RUMUZ", new String());
						adresMap.put("IL_KOD", ba.getIlKod());
						adresMap.put("IL_AD", ba.getIlAd());
						adresMap.put("ILCE_AD", ba.getIlceAd());
						adresMap.put("ILCE_KOD", ba.getIlceKod());
						adresMap.put("ACIK_ADRES", ba.getAcikAdres());
						adresMap.put("ILETISIM_MI", ba.getIletisimMi());
						adresMap.put("TESLIMAT_ADRESI_MI", "E");
						adresMap.put("ADRES_NO", iMap.getString("TESLIMAT_ADRES_NO"));
						
						logger.info("----tffBasvuruOdemeYap  TESLIMAT_NOKTASI_KODU " + ba.getTeslimatNoktasiKodu());
						adresMap.put("TESLIMAT_NOKTASI_KODU", ba.getTeslimatNoktasiKodu());
						logger.info("----tffBasvuruOdemeYap  KURYE_TIPI " + kuryeTipi);
						adresMap.put("SOURCE", iMap.getString("SOURCE"));
						adresMap.put("MUSTERIYE_EKLE", "H");
						GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS", adresMap);
						if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
							
							if("D".equals(ba.getId().getAdresKod())){
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.KK_TESLIMAT_ADRESI_D_OLAMAZ);
								return oMap;
							}
							TffKrediKartiBasvuru krediKartiBasvuru = (TffKrediKartiBasvuru) session.get(TffKrediKartiBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
							if (krediKartiBasvuru != null) {
								krediKartiBasvuru.setTeslimatAdresi( ba.getId().getAdresKod());
								session.saveOrUpdate(krediKartiBasvuru);
								session.flush();
							}
						}
					}
				} catch (Exception e) {
					logger.error(e);
					String mailFrom = "system@aktifbank.com.tr";
					String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
					String mailSubject = "TFF ODEME TESLIMAT ADRESI HATA";
					String mailBody = "Odeme adiminda adres eklemede hata :";
					mailBody += "<br> HATA" + TffServicesHelper.getTraceAsString(e);
					mailBody += "<br> MAP" + iMap.toString();
					TffServicesHelper.sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
				}
	
			}else{}
						
			boolean islemBasarili = StringUtils.isEmpty(iMap.getString("ISLEM_BASARISIZ"))?true:("E".equals(iMap.getString("ISLEM_BASARISIZ"))?false:true);
			BigDecimal promosyonTutar =StringUtils.isNotBlank(iMap.getString("PROMOSYON_DEGERI"))?iMap.getBigDecimal("PROMOSYON_DEGERI"):BigDecimal.ZERO;
			TffBasvuruPromosyon promosyonlar = null;
			if(StringUtils.isBlank(iMap.getString("PROMOSYON_BEDELI"))){
				iMap.put("PROMOSYON_BEDELI",BigDecimal.ZERO);
			}
			if ( islemBasarili ){
			
				if (StringUtils.isNotBlank(iMap.getString("PROMOSYON_KODU"))) {
					logger.info("----tffBasvuruOdemeYap  PROMOSYON_KODU :" + iMap.getString("PROMOSYON_KODU"));
					promosyonlar = (TffBasvuruPromosyon) session.get(TffBasvuruPromosyon.class, iMap.getString("PROMOSYON_KODU"));
					if (promosyonlar != null) {
						TffBasvuruPromosyonGrup grup = (TffBasvuruPromosyonGrup) session.get(TffBasvuruPromosyonGrup.class, promosyonlar.getGrupId());
						if (grup.getBaslangicTarihi().before(new Date())){
							
							if(grup.getBitisTarihi().after(new Date())) {

								promosyonTutar = promosyonlar.getKartBedeli().add(promosyonlar.getKuryeBedeli()).add(promosyonlar.getLoyaltyBedeli()).add(promosyonlar.getVizeBedeli());
								if (TffServicesMessages.IPTAL.equals(promosyonlar.getDurum())) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_IPTAL);
									return oMap;
								}
								if (promosyonlar.getKalanAdet().intValue() == 0) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_KULLANILMISTIR);
									return oMap;
								}
								if (!TffServicesHelper.isPromosyonHasValidKartTipi(grup, tffBasvuru.getKartTipi())) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_KART_TIPI_UYGUN_DEGIL);
									return oMap;
								}

								if (!TffServicesHelper.isPromosyonHasValidSource(grup, iMap.getString("SOURCE"))) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_GECERSIZ_KANAL);
									return oMap;

								}
								TffBasvuruPromosyonUrun urun = (TffBasvuruPromosyonUrun) session.get(TffBasvuruPromosyonUrun.class, new TffBasvuruPromosyonUrunId(promosyonlar.getGrupId(), tffBasvuru.getUrunSahipKodu()));
								if (urun == null) {
									oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
									oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_KODU_GECERSIZ_URUN);
									return oMap;
								}
							}
							else {
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_BITIS_TARIHI_UYGUN_DEGIL);
								return oMap;

							}
						}
						else {
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.PROMOSYON_BASLANGIC_TARIHI_UYGUN_DEGIL);
							return oMap;

						}
					}
					else {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_PROMOSYON_KODU_BULUNAMADI_HATASI);
						return oMap;
					}

				}
			}
	
			
			GMMap kuryeMap = new GMMap();
			kuryeMap.put("KURYE_TIPI", kuryeTipi);
			
			if(!TffServicesHelper.isKuryeTipiValid(kuryeMap)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.GECERSIZ_KURYE_TIPI);
				return oMap;
			}else{
				tffBasvuru.setKuryeTipi(kuryeTipi);
			}
			TffBasvuruVdOdemeTx basvuruVdOdemeTx = new TffBasvuruVdOdemeTx();

			basvuruVdOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			basvuruVdOdemeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			basvuruVdOdemeTx.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
			basvuruVdOdemeTx.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
			basvuruVdOdemeTx.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
			basvuruVdOdemeTx.setOdemeSekli(iMap.getString("ODEME_TIPI"));
			basvuruVdOdemeTx.setPromosyonBedeli(iMap.getBigDecimal("PROMOSYON_BEDELI"));
			basvuruVdOdemeTx.setPromosyonKodu(iMap.getString("PROMOSYON_KODU"));
			basvuruVdOdemeTx.setPromosyonOrani(iMap.getBigDecimal("PROMOSYON_ORANI"));
			basvuruVdOdemeTx.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
			basvuruVdOdemeTx.setKuryeTipi(kuryeTipi);
			
			iMap.put("TOPLAM_BEDEL", iMap.getBigDecimal("KART_BEDELI").add(iMap.getBigDecimal("KURYE_BEDELI")).add(iMap.getBigDecimal("LOYALTY_BEDELI")).add(iMap.getBigDecimal("VIZE_BEDELI")));
			if("H".equals(iMap.getString("ODEME_TIPI"))){
				logger.info("----tffBasvuruOdemeYap  HESAP_NO :" + iMap.getString("HESAP_NO"));
				
				if(StringUtils.isNotBlank(iMap.getString("HESAP_NO"))){
					//Hesaptan ise kullanilabilir bakiye uygun mu?
					GMMap sorguMap = new GMMap();
					sorguMap.put("HESAP_NO", iMap.get("HESAP_NO"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", sorguMap));
					if (iMap.getBigDecimal("TOPLAM_BEDEL").compareTo(sorguMap.getBigDecimal("KULLANILABILIR_BAKIYE")) == 1) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.HESAP_BAKIYE_YETERSIZ_HATA);
						return oMap;
					}
					
					basvuruVdOdemeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
				}else{
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.HESAP_NO_BULUNAMADI);
					return oMap;
				}
			}
			basvuruVdOdemeTx.setVizeBedeli(iMap.getBigDecimal("VIZE_BEDELI"));
			
			if(promosyonlar != null){
				basvuruVdOdemeTx.setPromosyonKart(promosyonlar.getKartBedeli());
				basvuruVdOdemeTx.setPromosyonKurye(promosyonlar.getKuryeBedeli());
				basvuruVdOdemeTx.setPromosyonLoyalty(promosyonlar.getLoyaltyBedeli());
				basvuruVdOdemeTx.setPromosyonVize(promosyonlar.getVizeBedeli());

				logger.info("----tffBasvuruSktOdemeYap  promosyonKartBedeli :" + promosyonlar.getKartBedeli());
				logger.info("----tffBasvuruSktOdemeYap  promosyonKuryeBedeli :" + promosyonlar.getKuryeBedeli());
				logger.info("----tffBasvuruSktOdemeYap  promosyonLoyaltyBedeli :" + promosyonlar.getLoyaltyBedeli());
				logger.info("----tffBasvuruSktOdemeYap  promosyonVizeBedeli :" + promosyonlar.getVizeBedeli());
			}
			
			logger.info("----tffBasvuruSktOdemeYap  TRX_NO :" + iMap.getString("TRX_NO"));
			logger.info("----tffBasvuruSktOdemeYap  BASVURU_NO :" + iMap.getString("BASVURU_NO"));
			logger.info("----tffBasvuruSktOdemeYap  ODEME_TIPI :" + iMap.getString("ODEME_TIPI"));
			logger.info("----tffBasvuruSktOdemeYap  KURYE_TIPI :" + kuryeTipi);
			logger.info("----tffBasvuruSktOdemeYap  KART_BEDELI :" + iMap.getString("KART_BEDELI"));
			logger.info("----tffBasvuruSktOdemeYap  KURYE_BEDELI :" + iMap.getString("KURYE_BEDELI"));
			logger.info("----tffBasvuruSktOdemeYap  LOYALTY_BEDELI :" + iMap.getString("LOYALTY_BEDELI"));
			logger.info("----tffBasvuruSktOdemeYap  VIZE_BEDELI :" + iMap.getString("VIZE_BEDELI"));
			
			
			logger.info("----tffBasvuruSktOdemeYap  TESLIMAT_ADRES_NO :" + iMap.getString("TESLIMAT_ADRES_NO"));
			
			

			basvuruVdOdemeTx.setOdemeRefId(odemeRefID);
			basvuruVdOdemeTx.setAktifbankEkPay(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AKTIFBANK_EK_PAY"), getAktifbankEkPayInner(basvuruVdOdemeTx.getBasvuruNo())));
			session.saveOrUpdate(basvuruVdOdemeTx);
			session.flush();

			iMap.put("TRX_NAME", "3828");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			if ( islemiOnayla ){
				if ( islemBasarili){
					
					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "O");
					onayMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					onayMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));		
	
				}
				else{
					GMMap onayRedMap = new GMMap();
					onayRedMap.put("ISLEM_TURU", "OR");
					onayRedMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
					onayRedMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayRedMap));
					
				}
			}
		
			oMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

	
			
		}
		catch(Exception e){
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_GENEL_HATA);
			return oMap;
		}

		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3828_MUH_ISLEM_GUNCELLE")
	public static GMMap sktMuhIslemGuncelle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3828.Muh_Islem_Guncelle(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


	
	private static BigDecimal getAktifbankEkPayInner(BigDecimal tffBasvuruNo) {
		GMMap sorguMap = new GMMap();
		sorguMap.put("TFF_BASVURU_NO", tffBasvuruNo);
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3828_GET_AKTIFBANK_EK_PAY", sorguMap));
		return sorguMap.getBigDecimal("AKTIFBANK_EK_PAY");
	}
	
	@GraymoundService("BNSPR_TRN3828_GET_AKTIFBANK_EK_PAY")
	public static GMMap getAktifbankEkPay(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3828.Get_Aktifbank_Payi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("ODEME_ISLEM_NO"));
			stmt.execute();

			oMap.put("AKTIFBANK_EK_PAY", CreditCardServicesUtil.nvl(stmt.getBigDecimal(1), BigDecimal.ZERO));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	private static String getKuryeTipi(String source, String kuryeTipi, boolean tcVatandasi) {

		String kuryeTipiSon = kuryeTipi;
		if(MOBILE_SRC.equals(source)){

			if (tcVatandasi){
				kuryeTipiSon =	"S";
			}
			else{
				kuryeTipiSon =	"GN";
			}

		}
		return kuryeTipiSon;
		
	}

	
	@GraymoundService("BNSPR_TFF_VADE_YENILEME_PROCESS")
	public static GMMap vadeYenilemeBatchProcess(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		String batchErrorCode = "";
		String batchErrorDesc = "";
		String batchErrorStep = "";
		BigDecimal iadeTxNo = BigDecimal.ZERO;

		int paymentStatus = 0;
		int renewalStatus = 0;
		boolean vadeYenilemeIptalMi = false;
		//int maxDeneme = 0;
		//odeme servisi inputlari toparla
		GMMap odemeMap = new GMMap();
        GMMap visaMap = new GMMap();
		
	
		odemeMap.put("BASVURU_NO", iMap.getBigDecimal("APPLICATION_NO"));
		Session session = DAOSession.getSession("BNSPRDal");
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
		TffVadeYenilemeBatchislem tffVadeYenilemeBatchIslem =  (TffVadeYenilemeBatchislem) session.get(TffVadeYenilemeBatchislem.class, iMap.getBigDecimal("TX_NO"));
	
		try{
			
			if(tffVadeYenilemeBatchIslem == null){
				batchErrorCode = TffServicesMessages.RESPONSE_BASARISIZ;
				batchErrorDesc = TffServicesMessages.TFF_BASVURU_ISLEM_KAYIT_GENEL_HATA;
				batchErrorStep = "Batch Islem Tx no Bulunamadi";		
			}
			
			if(tffBasvuru == null){
				batchErrorCode = TffServicesMessages.RESPONSE_BASARISIZ;
				batchErrorDesc = TffServicesMessages.ODEME_YAP_BASVURU_BULUNAMADI_HATASI;
				batchErrorStep = "Ba�vuru Kontrol";		
				
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_YAP_BASVURU_BULUNAMADI_HATASI);
				return oMap;
			}
			
			//GMMap paramMap = CreditCardServicesUtil.getParameterListByKey("MAX_SAYI", "VADE_YENILEME", "MAX_DENEME_SAYISI", null, null , null);
			
			//if (paramMap.getSize("MAX_SAYI") > 0){
			//	maxDeneme = new Integer (paramMap.getString("MAX_SAYI", 0, "NAME"));
			//}
			
				if (BigDecimal.ZERO.equals(iMap.getBigDecimal("PAYMENT_STATUS")) && !vdOdemeMuhasebelestiMi(iMap.getBigDecimal("TX_NO"))){ 
					//odeme fi�i kesilmediyse
					//timeout nedeniyle kesilmemi� g�r�nebilir, batch ba�lamadan �nce fi� kesildi mi diye tekrar kontrol edilecek
					odemeMap.put("ISLEM_NO",  iMap.getBigDecimal("TX_NO"));
					odemeMap.put("ISLEM_BASARISIZ","");
					odemeMap.put("ODEME_REF_ID",iMap.getString("PAYMENT_REF_ID"));
					odemeMap.putAll(GMServiceExecuter.call("BNSPR_VADE_YENILEME_ODEME_GUNCELLE", odemeMap));
					
					if(TffServicesMessages.RESPONSE_BASARILI.equals(odemeMap.getString("RESPONSE"))){
						paymentStatus = 1; //�deme ba�ar�l�
					}else{
						batchErrorCode = odemeMap.getString("RESPONSE");
						batchErrorDesc = odemeMap.getString("RESPONSE_DATA");
						batchErrorStep = "BNSPR_VADE_YENILEME_ODEME_GUNCELLE";		
						//if (new BigDecimal(maxDeneme).compareTo(tffVadeYenilemeBatchIslem.getTryCount()) == 0){
							//max deneme say�s�na ula�t�p hala vade yenilemede hata al�n�yorsa vd i�lemi iptal 
						
							//vade yenileme ba�vuru flag ini iptal et
							vadeYenilemeIptalMi = true;
						//}
					}
				}
				else{ //zaten muhasebele�mi�
					paymentStatus = 1;
				}
				
				if (BigDecimal.ZERO.equals(iMap.getBigDecimal("RENEWAL_STATUS"))) {
						
					//if (new BigDecimal(maxDeneme).compareTo(tffVadeYenilemeBatchIslem.getTryCount()) >= 0){
					try {
						visaMap.put("APPLICATION_NO", iMap.getBigDecimal("APPLICATION_NO"));
						visaMap.put("BRANCH_CODE", iMap.getString("BRANCH_CODE"));
						visaMap.put("CARD_DELIVERY_TYPE", CARD_DELIVERY_TYPE_POST);
						visaMap.put("CARD_NO", iMap.getString("CARD_NO",tffBasvuru.getKartNo()));
						visaMap.put("CARD_POST_IDX", iMap.getString("CARD_POST_IDX"));
				        visaMap.put("ADDRESS_CITY", iMap.getString("ADDRESS_CITY"));
				        visaMap.put("ADDRESS_CITY_CODE", iMap.getString("ADDRESS_CITY_CODE"));
				        visaMap.put("ADDRESS_COUNTRY", iMap.getString("ADDRESS_COUNTRY"));
				        visaMap.put("ADDRESS_TOWN_CODE", iMap.getString("ADDRESS_TOWN_CODE"));
				        visaMap.put("ADDRESS_TOWN", iMap.getString("ADDRESS_TOWN"));
				        visaMap.put("ADDRESS_ZIP_CODE", iMap.getString("ADDRESS_ZIP_CODE"));
				        visaMap.put("ADDRESS1", iMap.getString("ADDRESS1"));
						visaMap.put("CUSTOMER_NO", iMap.getBigDecimal("CUSTOMER_NO",tffBasvuru.getMusteriNo()));
						visaMap.put("SOURCE", "BATCH");
						visaMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_VADE_YENILEME", visaMap));
						
						if(TffServicesMessages.RESPONSE_BASARILI.equals(visaMap.getString("RESPONSE"))){
							renewalStatus =	1;
						}
						else{
							batchErrorCode = visaMap.getString("RESPONSE");
							batchErrorDesc = visaMap.getString("RESPONSE_DATA");
							batchErrorStep = "BNSPR_INTRACARD_VADE_YENILEME";		
							//if (new BigDecimal(maxDeneme).compareTo(tffVadeYenilemeBatchIslem.getTryCount()) == 0){
								//max deneme say�s�na ula�t�p hala vade yenilemede hata al�n�yorsa �deme fi�i iptal edilir
								throw new GMRuntimeException(0,"Renewal hata, fi� iptal edilecek");
							//}
				
						}
					} catch (Exception e) {
		
						logger.error("Batch odeme guncelle sonrasi vade yenileme hata !!!!");
						logger.error(visaMap.toString());
						e.printStackTrace();
						//todo: �deme iptal ak���
		
						batchErrorCode = "Batch odeme guncelle sonrasi vade yenileme hata";
						batchErrorDesc = e.toString();
						batchErrorStep = "BNSPR_INTRACARD_VADE_YENILEME";			
						
						odemeMap.put("BASVURU_NO",  iMap.getBigDecimal("APPLICATION_NO"));
						odemeMap.put("ACIKLAMA", "Batch odeme guncelle sonras� renewal hata");
						odemeMap.put("HATA_ACIKLAMA",  e.toString());
						odemeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_VADE_YENILEME_ODEME_IPTAL", odemeMap));
						

						if(!TffServicesMessages.RESPONSE_BASARILI.equals(odemeMap.getString("RESPONSE"))){
							batchErrorCode = odemeMap.getString("RESPONSE");
							batchErrorDesc = odemeMap.getString("RESPONSE_DATA");
							batchErrorStep = "BNSPR_TFF_VADE_YENILEME_ODEME_IPTAL";				
							}
						else{
							
							//vadeYenilemeIptalMi = true;
							//iptal servisi i�inde flag zaten temizleniyor
							iadeTxNo = odemeMap.getBigDecimal("TRX_NO");

						}
							
					}
				//}
				}
				else{
						//son hatalar ezilmesin
						batchErrorCode = tffVadeYenilemeBatchIslem.getBatchErrorCode();
						batchErrorDesc = tffVadeYenilemeBatchIslem.getBatchErrorDesc();
						batchErrorStep = tffVadeYenilemeBatchIslem.getBatchErrorStep();	

				}
						
				tffVadeYenilemeBatchIslem.setBatchErrorCode(batchErrorCode);
				tffVadeYenilemeBatchIslem.setBatchErrorDesc(batchErrorDesc);
				tffVadeYenilemeBatchIslem.setBatchErrorStep(batchErrorStep);
				tffVadeYenilemeBatchIslem.setPaymentStatus(new BigDecimal(paymentStatus));
				tffVadeYenilemeBatchIslem.setRenewalStatus(new BigDecimal(renewalStatus));
				tffVadeYenilemeBatchIslem.setTryCount(BigDecimal.ONE);//tffVadeYenilemeBatchIslem.getTryCount().add(BigDecimal.ONE));
				tffVadeYenilemeBatchIslem.setLastUpdDate(Calendar.getInstance().getTime());
				tffVadeYenilemeBatchIslem.setNewTxNo(iadeTxNo);
				//vade yenileme ba�vuru flag ini iptal et
				if(vadeYenilemeIptalMi){
				tffBasvuru.setVdBasvuruNo(null);
			    session.saveOrUpdate(tffBasvuru);
				session.flush();
				}
				session.saveOrUpdate(tffVadeYenilemeBatchIslem);
				session.flush();
				
				oMap.put("RESPONSE", StringUtils.isEmpty(batchErrorCode)? TffServicesMessages.RESPONSE_BASARILI: TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", batchErrorDesc);
				
				
		}

		catch(Exception e){
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.toString());
		}
	
		return oMap;
	}
	
	
private static boolean vdOdemeMuhasebelestiMi(BigDecimal islemNo) {

	Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

	TffBasvuruVdOdemeTx basvuruVdOdemeTx = (TffBasvuruVdOdemeTx)session.get(TffBasvuruVdOdemeTx.class, islemNo);	
		if (basvuruVdOdemeTx != null)
		return "OK".equals(basvuruVdOdemeTx.getBookingStatus());
		else
			return false;
	}
}
