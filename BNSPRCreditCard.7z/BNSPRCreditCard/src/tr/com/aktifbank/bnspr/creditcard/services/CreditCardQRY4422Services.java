package tr.com.aktifbank.bnspr.creditcard.services;

import java.util.HashMap;

import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY4422Services implements OceanMapKeys {

    @GraymoundService("BNSPR_QRY4422_GET_EMAIL_LIST")
    public static GMMap getCustomerEmailList(GMMap iMap){
        
        GMMap oMap = new GMMap();

        oMap.putAll(GMServiceExecuter.call("INTERNET_GET_MUSTERI_EMAIL_LIST", iMap));
               
        int size = oMap.getSize("RESULTS");
        StringBuilder eMail = new StringBuilder();
        for (int i = 0; i < size; i++) {
            if (oMap.getString("RESULTS", i, "NAME") != null)
                eMail.append(oMap.getString("RESULTS", i, "NAME") + ",");
        }
        if (eMail.length() != 0) {
            eMail.deleteCharAt(eMail.length() - 1);
        }
        oMap.put("EMAIL", eMail.toString());

        return oMap;
    }
    
	@GraymoundService("BNSPR_QRY4422_CREDIT_CARD_STATEMENT")
	public static GMMap getCreditCardStatement(GMMap iMap){
		try {
	        GMMap oMap = new GMMap();
	        oMap.put("EXTRE_PDF_AS_BYTEARRAY", getStatementData(iMap));
	        oMap.put("STMT_EXIST", 1);
	        return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY4422_CHECK_CREDIT_CARD_STATEMENT")
	public static GMMap checkCreditCardStatement(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			ByteArrayType byteArrayType=getStatementData(iMap);
			oMap.put("STMT_EXIST", byteArrayType.getData()!=null?1:0);
		} catch (Exception e) {
			oMap.put("STMT_EXIST", 0);
		}
		return oMap;
	}
	
	private static ByteArrayType getStatementData(GMMap iMap){
		ByteArrayType byteArrayType=new ByteArrayType();
		String isInternalExtreReportAvailble = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", new GMMap().put("KOD", "INTERNAL_EXTRE_AVAILABLE")).getString("DEGER");
        if ("1".equals(isInternalExtreReportAvailble)) {
        	GMMap storageInputMap = new GMMap();
        	storageInputMap.put("STATEMENT_TYPE", "KK");
        	storageInputMap.put("INDICATOR", iMap.getString("BARCODE"));
            byteArrayType.setData((byte[])GMServiceExecuter.call("STT_GET_STATEMENT_FILE", storageInputMap).get("STATEMENT_FILE"));
        } else {
        	byteArrayType.setData((byte[])GMServiceExecuter.call("BNSPR_CREDITCARD_GET_EXTRE_WITH_BARCODE", iMap).get("EXTRE_PDF_AS_BYTEARRAY"));
        }
        return byteArrayType;
	}
	
	@GraymoundService("BNSPR_QRY4422_SEND_CREDIT_CARD_STATEMENTS")
	public static GMMap sendCrediCardStatements(GMMap iMap){
		GMMap oMap = new GMMap();
		boolean first = true;
		GMMap statementInput=new GMMap();
		for (int i = 0; i < iMap.getSize("STMT_DATES"); i++) {
			if("1".equals(iMap.getString("STMT_DATES", i, "STATEMENT_SELECTED"))) {
				if(first){
					statementInput.put("EMAIL", iMap.getString("EMAIL"));
					statementInput.put("UNVAN", GMServiceExecuter.call("BNSPR_CUST_GET_UNVAN", new GMMap().put("MUSTERI_NO", iMap.getString("CUSTOMER_NO"))).getString("UNVAN"));
					statementInput.put("MASKED_CARD_NO", iMap.getString("MASKED_CARD_NO"));
					statementInput.put("TYPE", getCreditCardTypeCode(iMap.getString("PRODUCT_ID")));					
					first=false;
				}
				statementInput.put("STMT_DATE", formatDate(iMap.getString("STMT_DATES", i, "STMT_DATE")));
				statementInput.put("DUE_DATE", formatDate(iMap.getString("STMT_DATES", i, "DUE_DATE")));
				statementInput.put("MIN_AMOUNT", iMap.getString("STMT_DATES", i, "MIN_AMOUNT"));
				statementInput.put("TOTAL_AMOUNT", iMap.getString("STMT_DATES", i, "TOTAL_AMOUNT"));
				statementInput.put("BARCODE", iMap.getString("STMT_DATES", i, "BAR_CODE"));
				oMap = GMServiceExecuter.call("BNSPR_QRY4422_SEND_CREDIT_CARD_STATEMENT_MAIL", statementInput);	
			}
		}
		return oMap;
	}
	
	private static String getCreditCardTypeCode(String productId){
		String typeCode="KK";
		if(productId.equals("901")){
			typeCode=typeCode.concat("-PASSO");
		}
		return typeCode;
	}
	
	@GraymoundService("BNSPR_QRY4422_SEND_CREDIT_CARD_STATEMENT_MAIL")
	public static GMMap sendCreditCardStatementMail(GMMap iMap){
		GMMap oMap = new GMMap();
		
		GMMap stmtMap=GMServiceExecuter.call("BNSPR_QRY4422_CREDIT_CARD_STATEMENT", iMap);
		ByteArrayType byteArrayType = (ByteArrayType)stmtMap.get("EXTRE_PDF_AS_BYTEARRAY");
		
		GMMap myMap = new GMMap();
		myMap.put("MAIL_FROM", getParametre(iMap.getString("TYPE"),"MAIL_FROM"));
		myMap.put("MAIL_TO", iMap.get("EMAIL"));
		myMap.put("IS_BODY_HTML", "E");
		myMap.put("MAIL_SUBJECT", getParametre(iMap.getString("TYPE"),"MAIL_SUBJECT"));
		myMap.put("MAIL_BODY_CLOB", generateStatementEmailBodyHtml(iMap));

		myMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", getParametre(iMap.getString("TYPE"),"FILE_NAME"));
		myMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", byteArrayType.getData());

		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", myMap);
		oMap.put("RESPONSE", 2);
		return oMap;

	}
    
	private static String getParametre(String key1, String key2){
		GMMap iMap=new GMMap();
		iMap.put("KOD", "STATEMENT_EMAIL_PARAMS");
		iMap.put("KEY", key1);
		iMap.put("KEY2", key2);
		return GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap).getString("TEXT");
	}
	
	private static String generateStatementEmailBodyHtml(GMMap iMap){
		GMMap inputMap=new GMMap();
		inputMap.put("FOLDER_NAME", getParametre(iMap.getString("TYPE"), "STT_MAIL_TEMPLATE_FOLDER"));
		inputMap.put("TEMPLATE_NAME", getParametre(iMap.getString("TYPE"), "STT_MAIL_TEMPLATE_VM"));
		inputMap.put("ENCODING", "ISO-8859-9");
		inputMap.put("INPUTS", generateMailHtmlInput(iMap));	
		return GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", inputMap).getString("HTML_DATA");
	}
	
	private static HashMap<String,Object> generateMailHtmlInput(GMMap iMap){
		HashMap<String,Object> inputs=new HashMap<String, Object>();
		inputs.put("AD", iMap.getString("UNVAN"));
		inputs.put("SOYAD", "");
		inputs.put("KART_NO", iMap.getString("MASKED_CARD_NO"));
		inputs.put("SON_ODEME_TARIHI", iMap.getString("DUE_DATE"));
		inputs.put("DONEM_BORCU", iMap.getString("TOTAL_AMOUNT"));
		inputs.put("MIN_ODEME_TUTAR", iMap.getString("MIN_AMOUNT"));
		inputs.put("PARA_BIRIMI", "TL"); 
		return inputs;
	}
	
	public static String formatDate(String yyyyMMdd) {
		if (yyyyMMdd == null || yyyyMMdd.length() != 8) {
			return "";
		}
		yyyyMMdd.trim();
		String year = yyyyMMdd.substring(0, 4);
		String month = yyyyMMdd.substring(4, 6);
		String day = yyyyMMdd.substring(6);
		return day + "/" + month + "/" + year;
	}
	
}

