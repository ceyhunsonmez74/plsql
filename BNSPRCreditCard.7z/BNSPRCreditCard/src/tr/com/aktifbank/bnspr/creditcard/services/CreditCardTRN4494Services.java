package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.SbaTakastanPpiadeTx;
import tr.com.aktifbank.bnspr.dao.SbaTakastanPpiadeTxId;
import tr.com.aktifbank.bnspr.dao.SbaUiyiadeTx;
import tr.com.aktifbank.bnspr.dao.SbaUiyiadeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4494Services implements OceanMapKeys{
	@GraymoundService("BNSPR_TRN4494_IMPORT_EXCEL")
	public static GMMap importExcel (GMMap iMap){
		GMMap oMap = new GMMap();
        try {
            byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
            } catch (Exception e) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            for (int j = 0; j < sheet.getRows(); j++) {
            	if(!StringUtils.isEmpty(sheet.getCell(0, j).getContents())){
                for (int i = 0; i < sheet.getColumns(); i++) {
                	if(i==0)
                		oMap.put("KARTLIST", j, "FISNO", sheet.getCell(i, j).getContents());
                	}	
                }
            }
            
        } catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
        } 
        return oMap;
	}
	@GraymoundService("BNSPR_TRN4494_KONTROL")
	public static GMMap kontrol(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		
		try {
			int s = iMap.getSize("KARTLIST");
			boolean isError = false; 
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			query.append("select mi.islem_kod, mf.islem_numara from bnspr.muh_islem mi join bnspr.muh_fis mf on mi.numara = mf.islem_numara where mf.tur ='G' and mf.numara=?");
			for (int i = 0; i < s; i++) {
				stmt = conn.prepareStatement(query.toString());
				stmt.setString(1, iMap.getString("KARTLIST",i,"FISNO"));
				rSet = stmt.executeQuery();
				if (rSet.next()) {
					isError=false;

					GMMap pMap= new GMMap();
					pMap.put("KOD", "4494_FIS_KESILECEK_ISLEM_KODLARI");
					pMap.put("KEY", rSet.getBigDecimal(1));
					pMap = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI", pMap);

						if(pMap.getString("IS_EXIST").equals("H")){
							iMap.put("KARTLIST",i,"ACIKLAMA", "Bu Fi�e Ters Fi� Kesemezsiniz.");
							isError=true;
							continue;
						}
					
					iMap.put("KARTLIST",i,"ISLEM_NUMARA", rSet.getBigDecimal(2));
				}else{
					iMap.put("KARTLIST",i,"ACIKLAMA", "Fi� Numaras� Bulunamad�");
					isError=true;
				}
			}
			if(isError)
				iMap.put("HATA", "1");
			else
				iMap.put("HATA", "0");
		}
         catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return iMap;
	}
	@GraymoundService("BNSPR_TRN4494_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			int s= iMap.getSize("KARTLIST");
			for (int i = 0; i < s; i++) {
				SbaUiyiadeTx iade = new SbaUiyiadeTx();
				SbaUiyiadeTxId iadeId = new SbaUiyiadeTxId();
				iadeId.setOrgFisNo(iMap.getBigDecimal("KARTLIST",i,"FISNO"));
				iadeId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				iade.setId(iadeId);
				iade.setOrgTxNo(iMap.getBigDecimal("KARTLIST",i,"ISLEM_NUMARA"));
				iade.setAciklama(iMap.getString("KARTLIST",i,"ACIKLAMA"));
				session.saveOrUpdate(iade);
			}
			session.flush();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("TRX_NAME" , "4494");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4494_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> iadeList = session.createCriteria(SbaUiyiadeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			for (Object name : iadeList) {
				SbaUiyiadeTx iade = (SbaUiyiadeTx) name;
				oMap.put("KARTLIST",i, "FISNO",iade.getId().getOrgFisNo());
				oMap.put("KARTLIST",i, "ISLEM_NUMARA",iade.getOrgTxNo());
				oMap.put("KARTLIST",i,"ACIKLAMA", iade.getAciklama());
			
				i=i+1;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_HATA_RAPORU_AL")
	public static GMMap raporAl (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call  pkg_trn4494.hata_raporu_al(?,?)}";
			Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("ILK_TARIH");
			inputValues[2] = BnsprType.DATE;
			inputValues[3] = iMap.getDate("SON_TARIH");
			oMap = DALUtil.callOracleRefCursorFunction(func, "KARTLIST", inputValues);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	 public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	
	
}
