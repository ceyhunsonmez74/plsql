package tr.com.aktifbank.bnspr.creditcard.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TffTakimOranPrTx;
import tr.com.aktifbank.bnspr.dao.TffTakimOranPrTxId;
import tr.com.aktifbank.bnspr.dao.UrunSahip;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4455Services {
    
    private static GMMap throwGMBusssinessException(String string) {
        GMMap exMap = new GMMap();
        exMap.put("P1" , string);
        exMap.put("HATA_NO" , "660");
        return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
    }
    
    @GraymoundService("BNSPR_TRN4455_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            String func = "{? = call PKG_TRN4455.get_list()}";
            Object[] inputValues = new Object[] {};
            oMap = DALUtil.callOracleRefCursorFunction(func , "LIST" , inputValues);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4455_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillCombo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            GuimlUtil.wrapMyCombo(oMap , "RESULTS" , null , " ");
            GuimlUtil.wrapMyCombo(oMap , "RESULTS" , "G" , "Giri�");
            GuimlUtil.wrapMyCombo(oMap , "RESULTS" , "D" , "D�zeltme");
            GuimlUtil.wrapMyCombo(oMap , "RESULTS" , "S" , "Silme");
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4455_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            int Size = iMap.getSize("LIST");
            for (int i = 0; i < Size; i++){
                
                TffTakimOranPrTxId id = new TffTakimOranPrTxId();
                TffTakimOranPrTx takimOran = new TffTakimOranPrTx();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setUrunSahipKod(iMap.getString("LIST" , i , "URUN_SAHIP_KOD"));
                
                takimOran.setId(id);
                takimOran.setGDS(iMap.getString("LIST" , i , "GDS"));
                takimOran.setSabitHizmetOrani(iMap.getBigDecimal("LIST" , i , "SABIT_HIZMET_ORANI"));
                takimOran.setSabitHizmetTutari(iMap.getBigDecimal("LIST" , i , "SABIT_HIZMET_TUTARI"));
                takimOran.setTakasKomisyonOrani(iMap.getBigDecimal("LIST" , i , "TAKAS_KOMISYON_ORANI"));
                takimOran.setKulupHesap(iMap.getBigDecimal("LIST", i,"KULUP_HESAP"));
                
                session.saveOrUpdate(takimOran);
                
            }
            session.flush();
            iMap.put("TRX_NAME" , "4455");
            
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN4455_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            List<?> list = session.createCriteria(TffTakimOranPrTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            int row = 0;
            String tableName = "LIST";
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++){
                TffTakimOranPrTx takimOran = (TffTakimOranPrTx) iterator.next();
                
                oMap.put(tableName , row , "URUN_SAHIP_KOD" , takimOran.getId().getUrunSahipKod());
                oMap.put(tableName , row , "GDS" , takimOran.getGDS());
                oMap.put(tableName , row , "SABIT_HIZMET_ORANI" , takimOran.getSabitHizmetOrani());
                oMap.put(tableName , row , "SABIT_HIZMET_TUTARI" , takimOran.getSabitHizmetTutari());
                oMap.put(tableName , row , "TAKAS_KOMISYON_ORANI" , takimOran.getTakasKomisyonOrani());
                UrunSahip urunSahip = (UrunSahip) session.createCriteria(UrunSahip.class).add(Restrictions.eq("kod" , takimOran.getId().getUrunSahipKod())).uniqueResult();
                oMap.put(tableName , row , "ADI" , urunSahip.getAdi());
                oMap.put(tableName, row, "KULUP_HESAP", takimOran.getKulupHesap());
            }
            oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
}
