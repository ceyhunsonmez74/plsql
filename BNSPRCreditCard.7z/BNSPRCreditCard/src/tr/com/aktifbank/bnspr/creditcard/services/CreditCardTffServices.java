package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruVdOdeme;
import tr.com.aktifbank.bnspr.dao.TffBasvuruVdOdemeiptalTx;
import tr.com.aktifbank.bnspr.dao.TffVadeYenileme;
import tr.com.aktifbank.bnspr.dao.TffVadeYenilemeBatchislem;
import tr.com.aktifbank.bnspr.dao.TffVadeYenilemeId;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTffServices implements OceanMapKeys {

	private static final Logger logger = Logger.getLogger(CreditCardTffServices.class);

	private static final String RESULTS = "RESULTS";
	public static final String TFF_KREDI_KARTI = "KK";
	public static final String TFF_DEBIT_KARTI = "D";
	public static final String TFF_PREPAID_KARTI = "P";
	public static final int TFF_KARA_LISTE_CEP_OTP = 1;
	public static final int TFF_KARA_LISTE_TCKN_VER_TARIH = 2;
	public static final int TFF_KARA_LISTE_TCKN_OTP = 3;
	private static final String VISA_FEE_PAYMENT_TYPE_VD = "U";
	private static final String EMBOSS_CODE_VD = "VD";
	private static final String EMBOSS_CODE_TYPE = "I";
	private static final String VD_YENILEME_ODEME_IPTAL_ISLEM_KOD = "3830";
	private static final String CARD_DELIVERY_TYPE_POST = "P";
	private static final String BASVURU_DAGITIM_KOD_BOS = "999";

	private static final String YES_FLAG = "Y";
	private static final String KART_TESLIMAT_ADRES_KODU = "3";
	private static final String IPTAL_STATUS = "I";

	/**
	 * TFF basvurusunun ardindan kredi karti kisa basvurusu olusturur.
	 * 
	 * @param iMap
	 *            TCK_NO
	 *            CEP_ULKE_KOD
	 *            CEP_TEL_KOD
	 *            CEP_TEL_NO
	 *            MUSTERI_NO
	 *            TFF_BASVURU_NO
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TFF_KK_KISA_BASVURU_OLUSTUR")
	public static GMMap tffKkKisaBasvuruOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// Database variables
		Connection conn = null;
		CallableStatement stmt = null;

		// Card variables
		boolean basvuruOlustuMu = false;
		boolean basvuruGecerliMi = false;
		boolean nbsmHatasiMi = false;

		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_TFF_ON_BASVURU", iMap));

			// Kredi karti basvurusu durumunu kontrol et
			basvuruOlustuMu = CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"));
			basvuruGecerliMi = CreditCardServicesUtil.EVET.equals(oMap.getString("DEVAM"));
			nbsmHatasiMi = CreditCardServicesUtil.EVET.equals(oMap.getString("NBSM_HATASI_MI"));

			// Gecerli bir kredi karti basvurusu basarili olusturulamadi ise karti DEBIT yap. Red oldu ise sms gonder
			// Olusturuldu ise kredi karti basvuru numrasini guncelle.
			BigDecimal kkBasvuruNo = null;
			if (basvuruOlustuMu) {
				kkBasvuruNo = oMap.getBigDecimal("BASVURU_NO");
				if (!basvuruGecerliMi) {// NBSM hatasi alan basvurular gecerli sayiliyor.
					// Islem tamamlandi ise 3871.afterApproval icerisinde durumunu guncelliyor.
					boolean trxTamamlandiMi = false;
					if (oMap.get("TRX_NO") != null) {
						sorguMap.clear();
						sorguMap.put("TRX_NO", oMap.get("TRX_NO"));
						sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR);
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_ISLEM_TAMAMLANDI_MI", sorguMap));
						if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("ISLEM_TAMAMLANDI_MI"))) {
							trxTamamlandiMi = true;
						}
					}

					// Islem tamamlanmadi ise durumunu guncelle.
					if (!trxTamamlandiMi && !nbsmHatasiMi) {
						// KK basvurusunun durumuna bakilir, IPTAL ise tff basvurusu iptal edilir. RED ise joba dusurulur.
						Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
						KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkBasvuruNo);
						session.refresh(kkBasvuru);
						if ("IPTAL".equals(kkBasvuru.getDurumKod())) {
							// Iptal icin tff basvurusunu al
							TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
							session.refresh(tffBasvuru);

							sorguMap.clear();
							sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
							sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
							sorguMap.put("ISLEM_KOD", "3805");
							sorguMap.put("GEREKCE_KOD", "4");// Otomatik Iptal
							sorguMap.put("ACIKLAMA", "Aktif kredi karti Basvuru/Kart sahibi oldugundan iptal edildi");
							sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
							GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap);
						}
						else if ("RED".equals(kkBasvuru.getDurumKod())) {
							sorguMap.clear();
							sorguMap.put("TFF_BASVURU_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
							sorguMap.put("KK_BASVURU_NO", kkBasvuruNo);
							sorguMap.put("ISLEM_KOD", "3805");
							sorguMap.put("ISLEM_NO", oMap.getBigDecimal("TRX_NO"));
							GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap);
						}
					}
				}
			}
			else {
				// TODO daha once bir sekilde olusup yarim kalan KKsi var mi? Bir ihtimal.
				// Tff basvurusu durumunu kredi karti olusturulamadi olarak guncelle.
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
				sorguMap.put("ISLEM_NO", oMap.get("ISLEM_NO"));
				sorguMap.put("DURUM_KOD", "KK_YOK_JOB");
				sorguMap.put("ISLEM_ACIKLAMA", "Odeme Sonrasi -- Kredi karti basvurusu olusturulurken hata olustu!!!");
				sorguMap.put("TARIHCE_AKSIYON", "E");// Ekle
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("BASVURU_OLUSTU_MU", BooleanUtils.toString(basvuruOlustuMu, CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
		oMap.put("BASVURU_GECERLI_MI", BooleanUtils.toString(basvuruGecerliMi && !nbsmHatasiMi, CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
		return oMap;
	}

	// I:TFF_BASVURU_NO, KK_BASVURU_NO, ISLEM_KOD, ISLEM_NO
	// O:
	@GraymoundService("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM")
	public static GMMap tffKkRedIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		// Degiskenler
		String yeniKartTipi = StringUtils.EMPTY;
		BigDecimal tffBasvuruNo = iMap.getBigDecimal("TFF_BASVURU_NO");
		BigDecimal kkBasvuruNo = iMap.getBigDecimal("KK_BASVURU_NO");

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			// TFF basvurunu bul
			TffBasvuru tffBasvuru = null;
			if (tffBasvuruNo != null) {
				tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
			}
			else if (kkBasvuruNo != null) {
				tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", kkBasvuruNo)).add(Restrictions.eq("kartTipi", TFF_KREDI_KARTI)).uniqueResult();
				if (tffBasvuru == null) {
					sorguMap.clear();
					sorguMap.put("KK_BASVURU_NO", kkBasvuruNo);
					tffBasvuruNo = GMServiceExecuter.call("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap).getBigDecimal("TFF_BASVURU_NO");
					if (tffBasvuruNo != null) {
						tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
					}
				}
			}
			// Tff basvurusu yoksa hata ver.
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", tffBasvuruNo);
			}
			else {
				tffBasvuruNo = tffBasvuru.getBasvuruNo();
				kkBasvuruNo = tffBasvuru.getKkBasvuruNo();
			}

			// Donusturulecek kart tipini al
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "KK_RED_TFF_KART_TIPI");
			yeniKartTipi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");

			// Basarili olusturulamadi ise debit ve prepaid cevrimi icin mevcut basvurularina bak
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("KK_BASVURU_NO", tffBasvuru.getKkBasvuruNo());
			sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
			sorguMap.put("KART_TIPI_GUNCELLENSIN_MI", CreditCardServicesUtil.HAYIR);
			if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(yeniKartTipi)) {
				sorguMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.EVET);
			}
			else {
				sorguMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.HAYIR);
			}
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TIPI_DONUSTUR", sorguMap));
			// Gecersiz iptal edilebilir bir basvurusu varsa kart tipi dolu gelir ama onceki karti var flagi set edilir.
			boolean debitBasvuruVarMi = sorguMap.getBoolean("DEBIT_KART_VAR_MI");
			boolean prepaidBasvuruVarMi = sorguMap.getBoolean("PREPAID_KART_VAR_MI");
			// Kart tipi secilmisse TFF Basvurusunu Guncelle, yoksa iptal et.
			yeniKartTipi = sorguMap.getString("KART_TIPI");
			if (StringUtils.isBlank(yeniKartTipi)) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
				sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
				sorguMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD"));
				sorguMap.put("GEREKCE_KOD", "4");// Otomatik Iptal
				sorguMap.put("ACIKLAMA", "Debit ve Prepaid Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi!!!");
				sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));

				sorguMap.clear();
				sorguMap.put("BASVURU_NO", tffBasvuru.getKkBasvuruNo());
				sorguMap.put("KART_VAR_MI", "E");
				sorguMap.put("KART_TIPI", "D");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_RED_SMS_GONDER", sorguMap));

			}
			else {
				// Gecersiz basvurulari iptal et.
				if (debitBasvuruVarMi) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("KART_TIPI", TFF_DEBIT_KARTI);
					sorguMap.put("MEVCUT_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("ONCEKI_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.EVET);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL", sorguMap));
				}

				if (prepaidBasvuruVarMi) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("KART_TIPI", TFF_PREPAID_KARTI);
					sorguMap.put("MEVCUT_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("ONCEKI_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.EVET);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL", sorguMap));
				}

				// Onceki durumu veri kontrol ise havuzdan sil
				if ("VERI_KONTROL".equals(tffBasvuru.getDurumKod())) {
					sorguMap.clear();
					sorguMap.put("TFF_BASVURU_NO", tffBasvuruNo);
					sorguMap.put("KK_BASVURU_NO", kkBasvuruNo);
					GMServiceExecuter.executeNT("BNSPR_TRN3805_DELETE_HAVUZ", sorguMap);
				}

				sorguMap.clear();
				sorguMap.put("BASVURU_NO", tffBasvuruNo);
				sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				sorguMap.put("DURUM_KOD", "KK_RED_JOB");
				sorguMap.put("ISLEM_ACIKLAMA", "KK basvurusu IPTAL/RED oldugundan degerlendirilmek uzere Job Durumunda!!!");
				sorguMap.put("TARIHCE_AKSIYON", "E");// Ekle
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", sorguMap);
				
				
				GMMap resultMap= listCreditCardJob(tffBasvuruNo) ;
				if(resultMap.getSize(RESULTS)> 0){
				for(int i=0; i<resultMap.getSize(RESULTS); i++){
					GMMap inputMap= new GMMap();
					inputMap.put("BASVURU_NO",  resultMap.getBigDecimal(RESULTS, 0,"BASVURU_NO"));
					inputMap.put("KK_BASVURU_NO",  resultMap.getString(RESULTS, 0,"KK_BASVURU_NO"));
					inputMap.put("KART_TIPI",  resultMap.getString(RESULTS, 0,"KART_TIPI"));
					inputMap.put("DURUM_KOD",  resultMap.getString(RESULTS, 0,"DURUM_KOD"));
					
					GMServiceExecuter.call("BNSPR_CREDITCARD_KK_RED_SMS_JOB_PROCESS", inputMap);
					
				}
				}
				
				
				try {
					iMap.put("TFF_BASVURU_NO", tffBasvuruNo);
					iMap.put("CRM_TYPE", CrmTypes.MAIN);
					GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
				}
				catch (Exception e) {
					e.printStackTrace();
					logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + tffBasvuruNo);
				}

			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_TIPI", yeniKartTipi);
		return oMap;
	}

	// --------------------------------------------------------RAISEGMERROR
	/**
	 * Verilen hata kodu ve parametrelerle ekrana hata mesaji verir.
	 * 
	 * @param errorCode
	 *            - GNL_Mesaj_Pr tablosunda tanimli olan Hata Kodu
	 * @param parameters
	 *            - Hata aciklamasinda yer alacak parametreler. Max.:4
	 */
	@GraymoundService("BNSPR_TFF_COMMON_HATA_YAZ")
	public static GMMap raiseTffGMError(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_TFF_BASVURU.hata_yaz(?,true,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("HATA_NO"));
			stmt.setString(2, iMap.getString("P1"));
			stmt.setString(3, iMap.getString("P2"));
			stmt.setString(4, iMap.getString("P3"));
			stmt.setString(5, iMap.getString("P4"));
			stmt.setString(6, StringUtils.isNotEmpty(iMap.getString("HATA_KODU_VAR")) ? iMap.getString("HATA_KODU_VAR") : "H");
			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	// --------------------------------------------------------RAISEGMERROR
	/**
	 * Verilen hata kodu ve parametrelerle ekrana hata mesaji verir.
	 * 
	 * @param errorCode
	 *            - GNL_Mesaj_Pr tablosunda tanimli olan Hata Kodu
	 * @param parameters
	 *            - Hata aciklamasinda yer alacak parametreler. Max.:4
	 */
	public static void raiseTffGMError(String errorCode, String hataKoduVarMi, Object... parameters) {
		HashMap<String, Object> myMap = new HashMap<String, Object>();
		myMap.put("HATA_NO", errorCode);

		if (parameters != null && parameters.length > 0) {
			int index = 0;
			while (index < parameters.length) {
				myMap.put("P" + (index + 1), parameters[index]);
				index++;
			}
		}

		try {
			String errorMessage = GMServiceExecuter.execute("BNSPR_TFF_COMMON_HATA_YAZ", myMap).get("ERROR_MESSAGE").toString();
			throw new GMRuntimeException(0, errorMessage);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR")
	public static GMMap tffErrorMEssageOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_tff_basvuru.mesajolustur(?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.setBigDecimal(2, iMap.getBigDecimal("MESSAGE_NO"));
			stmt.setString(3, iMap.getString("P1"));
			stmt.setString(4, iMap.getString("P2"));
			stmt.setString(5, iMap.getString("P3"));
			stmt.setString(6, iMap.getString("P4"));
			stmt.setString(7, StringUtils.isNotEmpty(iMap.getString("HATA_KODU_VAR")) ? iMap.getString("HATA_KODU_VAR") : "H");
			stmt.setString(8, iMap.getString("P5")); // Kanal

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("ERROR_MESSAGE", stmt.getString(1));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Verilen hata kodu ve parametrelerle ekrana hata mesaji verir.
	 * 
	 * @param errorCode
	 *            - GNL_Mesaj_Pr tablosunda tanimli olan Hata Kodu
	 * @param parameters
	 *            - Hata aciklamasinda yer alacak parametreler. Max.:4
	 */
	public static String errorMessageOlustur(String errorCode, String hataKoduVarMi, Object... parameters) {
		HashMap<String, Object> myMap = new HashMap<String, Object>();
		myMap.put("MESSAGE_NO", errorCode);
		myMap.put("HATA_KODU_VAR", StringUtils.isNotEmpty(hataKoduVarMi) ? hataKoduVarMi : "H");
		if (parameters != null && parameters.length > 0) {
			int index = 0;
			while (index < parameters.length) {
				myMap.put("P" + (index + 1), parameters[index]);
				index++;
			}
		}
		String errorMessage = GMServiceExecuter.execute("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR", myMap).get("ERROR_MESSAGE").toString();
		if (StringUtils.isNotEmpty(errorMessage) && errorMessage.startsWith("B-" + errorCode + ":")) {
			return errorMessage;
		}
		else {
			return "B-" + errorCode + ": " + errorMessage;
		}
	}

	/**
	 * TFF uzerinden kart basvurusu olusturur<br>
	 * 
	 * @param MUSTERI_NO
	 * @param TFF_BASVURU_NO
	 * @param TCK_NO
	 * @param CEP_NO
	 * @param HATA_VERILSIN_MI
	 * 
	 * @return oMap - Kredi Karti Basvurusu Durumu <li>BASVURU_NO <li>TRX_NO <li>MESSAGE: hata ya da islem <li>RESPONSE : 2 ise success, 0 ise hata oldugunu belirtir <li>NBSM_HATASI_MI: Nbsm nedeniyle mi islem basarisiz(E:Evet | H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3871_TFF_ON_BASVURU")
	public static GMMap tffOnBasvuruBasla(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);// Basvuru olustu mu?
		oMap.put("DEVAM", CreditCardServicesUtil.HAYIR);// Basvuru gecerli mi?
		oMap.put("NBSM_HATASI_MI", CreditCardServicesUtil.HAYIR);// Nbsm hatasi var mi?

		try {
			// TFF tarafindan gelen kredi karti basvurulari sadece TFF kullanicisi ile olusturulabilir
			GMMap sorguMap = new GMMap();
			sorguMap.put("KULLANICI_KOD", "TFF");
			sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
			GMServiceExecuter.call("BNSPR_KK_SET_USER_GLOBALS", sorguMap);

			// Parametre Kontrolleri
			// Islem icin Transaction No Al. KPS_JOB dolu geliyor.
			if (iMap.get("TRX_NO") == null) {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				oMap.put("TRX_NO", iMap.get("TRX_NO"));
			}

			// Islem icin Basvuru No Al. KPS_JOB dolu geliyor.
			if (iMap.get("BASVURU_NO") == null) {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_BASVURU_NO", new GMMap()));
				iMap.put("BASVURU_NO", iMap.getString("ID"));
				oMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			}

			iMap.put("ISLEM_KODU", "BASVURU");
			iMap.put("DURUM_KODU", "BASVURU");
			iMap.put("ISLEM_SONRASI_DURUM_KODU", "NBSM");

			// get current date
			GMMap paramMap = new GMMap();// bos parametre mapi
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_CURRENT_TIME", paramMap)); // CURRENT_DATE
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_SUBE_KOD", paramMap)); // SUBE_KOD

			// TFF Tablolarindan basvuruda kaydedilecek bilgileri al.
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_BASVURU_BILGI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_KK_BASVURU_BILGI", iMap));

			// Kart var mi sorgusu sirasinda OCEANda hata alirsa KK_YOK_JOBa dusmesi icin hata ver.
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
			sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_KART_VAR_MI", sorguMap));// TC_KIMLIK_NO,HATA_VERILECEK_MI
			// Oceanda hata var mi?
			Boolean kartVarMi = sorguMap.getBoolean("KART_VAR_MI");
			if (sorguMap.getBoolean("OCEAN_HATA_VAR_MI")) {
				oMap.put("MESSAGE", sorguMap.get("KART_VAR_HATA_MESAJI"));
				return oMap;
			}

			// Basvuru Kaydet
			sorguMap.clear();
			iMap.put("TFF_KK", "E");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_SAVE_BASVURU_BILGI", iMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("SAVE_KIMLIK_SONUC"))) {
				oMap.put("MESSAGE", sorguMap.get("SAVE_KIMLIK_MESAJ"));
				return oMap;
			}

			// KK basvuru no bilgisini tff tablosunda guncelle.
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("KK_BASVURU_NO", iMap.get("BASVURU_NO"));
			GMServiceExecuter.executeNT("BNSPR_TFF_KK_BASVURU_BILGI_GUNCELLE", sorguMap);
			// updateTffKKBasvuruInfo(iMap.getBigDecimal("TFF_BASVURU_NO"), iMap.getBigDecimal("BASVURU_NO"), null);
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);// Basvuru olustu mu?

			// Daha onceden acilmis kredi karti var mi? Kart varsa basvuru iptal edilir.
			if (kartVarMi) {
				// Mevcut basvuruyu iptal et.
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				sorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				sorguMap.put("DURUM", "IPTAL");
				sorguMap.put("AKSIYON_KOD", "C");
				sorguMap.put("AKSIYON_KARAR_KOD", "3");
				CreditCardQueriesServices.basvuruSonlandir(sorguMap);// TRX_NO,BASVURU_NO,DURUM

				sorguMap.clear();
				sorguMap.put("MESSAGE_NO", "2958");
				oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sorguMap).get("ERROR_MESSAGE"));
				return oMap;
			}

			// Aktif basvurusu var mi?
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", iMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				oMap.put("MESSAGE", sorguMap.get("MESSAGE"));// Iptal
				return oMap;
			}

			// daha once ayni tckn ye ait red olan basvuru var mi kontrolu...
			sorguMap.clear();
			try {
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_BASVURU_GIRIS_RED_KONTROL", iMap));
				if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("BASVURU_GIRIS_RED_KONTROL_SONUC"))) {
					oMap.put("MESSAGE", sorguMap.get("BASVURU_GIRIS_RED_KONTROL_MESAJ"));// Red
					return oMap;
				}
			}
			catch (Exception e) {
				// Herhangi bir hata olusursa mevcut basvuru iptal edilir.
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				sorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				sorguMap.put("DURUM", "IPTAL");
				sorguMap.put("AKSIYON_KOD", "C");
				sorguMap.put("AKSIYON_KARAR_KOD", "3");
				CreditCardQueriesServices.basvuruSonlandir(sorguMap);// TRX_NO,BASVURU_NO,DURUM

				// KK_YOK_YOBa dusmesi saglanarak basvurunun tekrar ilerlemesi saglanir.
				oMap.put("MESSAGE", sorguMap.get("BASVURU_GIRIS_RED_KONTROL_MESAJ"));
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);// Basvuru ON_BASVURU oldu, Teknik Hata
				oMap.put("DEVAM", CreditCardServicesUtil.HAYIR);// Devam Etme
				return oMap;
			}

			// Bu kisimda hata alirsa akis kesilmemeli
			try {
				// APS Sorgusu Yap
				iMap.put("TC_KIMLIK_NO", iMap.getString("TCK_NO"));
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", iMap));

				// Kontakt Musteri Bilgisini Guncelle
				GMServiceExecuter.execute("BNSPR_TRN3871_UPDATE_MUSTERI_NO", iMap);

				// APS Bilgilerini Guncelle
				GMServiceExecuter.execute("BNSPR_TRN3870_UPDATE_APS_INFO", iMap);
			}
			catch (Exception e) {
			}

			// Diger Sorgular
			try {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_DEVAM_SORGULAR", iMap));
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("DEVAM"))) {// ON_BASVURU
					// basvurunun durumunu NBBSM olarak guncellemeliyiz. Tam basvuruda hata alirsa JOB ile devam edebilsin.
					oMap.put("DEVAM", CreditCardServicesUtil.EVET);
					iMap.put("DURUM_KOD", "NBSM");
					iMap.put("TARIHCE_AKSIYON", "G");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
				}
				else {
					// NBSM Hatasi varsa pass et
					if (CreditCardServicesUtil.EVET.equals(iMap.getString("NBSM_HATASI_MI")) || // Hata yakalandi ise
					StringUtils.isBlank(iMap.getString("DEVAM"))) {// Hata yakalanmadi ise map bos donuyor
						oMap.put("NBSM_HATASI_MI", CreditCardServicesUtil.EVET);
					}
					else {
						oMap.put("MESSAGE", iMap.get("MESSAGE"));// IPTAL/RED
					}
				}
			}
			catch (Exception e) {
				logger.error(e);
				oMap.put("NBSM_HATASI_MI", CreditCardServicesUtil.EVET);
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
					throw ExceptionHandler.convertException(e);
				}
				else {
					oMap.put("RESPONSE_DATA", e.getMessage());
				}
			}
		}
		catch (Exception e) {
			logger.error(e);
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			}
			else {
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}

		return oMap;
	}

	/**
	 * TFF kredi karti tablosundan kaydedilen bilgileri alarak Kredi karti basvurusu olusturur.
	 * 
	 * @param iMap
	 *            - TFF_BASVURU_NO, HATA_VERILSIN_MI
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TRN3871_TFF_TAM_BASVURU")
	public static GMMap tffTamBasvuruYap(GMMap iMap) {
		// TFF tarafindan gelen kredi karti basvurulari sadece TFF kullanicisi ile olusturulabilir
		GMMap sorguMap = new GMMap();
		sorguMap.put("KULLANICI_KOD", "TFF");
		sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
		GMServiceExecuter.call("BNSPR_KK_SET_USER_GLOBALS", sorguMap);

		// basvuru bilgilerini al
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_KK_BASVURU_BILGI", iMap));

		iMap.put("IS_FULL_SAVE", "N"); // insert all records when calling 3871save
		iMap.put("IS_FIRST_PAGE", "N");
		GMMap oMap = new GMMap();
		try {
			// call 3871 Save
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_SAVE", iMap));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", iMap));

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (kkBasvuru != null) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ISLEM_NO", iMap.get("TRX_NO"));
				sorguMap.put("DURUM_KOD", "VERI_KONTROL");
				sorguMap.put("ISLEM_ACIKLAMA", "Kisa basvuru sonrasi veri kontrol");
				sorguMap.put("TARIHCE_AKSIYON", "E");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap));
			}

			// Veri kontrol havuzunda basvuruyu guncelle
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("KK_BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("KART_TIPI", TFF_KREDI_KARTI);
			sorguMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
			GMServiceExecuter.executeNT("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap);

			// Bilgilendir
			iMap.put("MESSAGE_NO", new BigDecimal(2998));
			oMap.put("RESPONSE", "2");
			oMap.put("RESPONSE_DATA", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			}
			else {
				e.printStackTrace();
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}

		return oMap;
	}

	/**
	 * Olusturulan kredi karti basvurusunun son islemlerini yapar.
	 * 
	 * @author murat.el
	 * @since 10.03.2014
	 * @param iMap
	 *            - Kredi karti basvuru bilgileri<br>
	 *            <li>BASVURU_NO - Kredi karti basvuru numarasi <li>KK_TRX_NO - Kredi karti kaydet islem numarasi <li>VERI_KONTROL_TRX_NO - Kredi karti veri kontrol islem numarasi <li>CAPTCHA - Ekranda alinan resim <li>GUVENLIK_KODU - Ekranda girilen captcha degeri
	 * @return oMap - Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_TRN3871_TFF_BASVURU_TAMAMLA")
	public static GMMap tffBasvuruTamamla(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		// Database variables
		Connection conn = null;
		CallableStatement stmt = null;
		String query = null;

		try {
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("KART_TIPI", TFF_KREDI_KARTI);
			sorguMap.put("CAPTCHA", iMap.get("CAPTCHA"));
			sorguMap.put("GUVENLIK_KODU", iMap.get("GUVENLIK_KODU"));
			sorguMap.put("CAPTCHA_DOGRULANSIN_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("ESGM_SORGU_YAPILSIN_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_ESGM_SORGU", sorguMap));

			// nbsm
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("TRX_NO", iMap.get("KK_TRX_NO"));
			sorguMap.put("DURUM_KOD", "VERI_KONTROL");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", sorguMap));

			// Bilgileri al.
			conn = DALUtil.getGMConnection();
			query = "{ ? = call PKG_KK_BASVURU.KkBasvuruDurum(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			// Redse TFF basvurusunu Debit karta cevir, degilse KK basvurusunu tamamla.
			String durum = stmt.getString(1);
			if ("RED".equals(durum)) {
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("kartTipi", TFF_KREDI_KARTI)).uniqueResult();
				if (tffBasvuru != null && "IPTAL".equals(tffBasvuru.getDurumKod())) {
					oMap.put("MESSAGE", "Kredi Karti Basvurusu Olumlu Sonuclanmadi. Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
				}
			}
			else {
				if (CreditCardServicesUtil.EVET.equals(oMap.getString("DEVAM"))) {
					// Joba dusunce islem sonlandirilmaz.
					if (!("FRAUD".equals(durum) || "LKS_JOB_1".equals(durum) || "KKB_JOB".equals(durum))) {
						iMap.put("TRX_NO", iMap.get("KK_TRX_NO"));
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", iMap));
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		// Bilgilendir
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * Kredi karti basvurusu red ya da iptal olunca kart tipi donusumu yapilir ve kart basilir.<br>
	 * 
	 * @author murat.el
	 * @since 23.01.2014
	 * @param iMap
	 *            - Kredi karti ve islem bilgileri<br>
	 *            <li>TFF_BASVURU_NO - Tff basvuru numarasi <li>KK_BASVURU_NO - KK basvuru numarasi <li>KART_TIPI - Kredi karti <li>BASVURU_IPTAL_EDILSIN_MI - Cevrilmek istenen kartlar mevcutsa basvuru iptal edilmeli mi? (E|H) <li>ISLEM_NO - Donusumun hangi ait oldugu islem numarasi <li>ISLEM_KOD - Basvuru iptal edilecekse, iptalin gerceklestigi islem kodu <li>SONRAKI_DURUM_KODU - Sonraki durum
	 *            kodu <li>YENI_KART_TIPI - Manuel olarak bir kart tipi cevrimi varsa kart tipi parametrik alinir.
	 * @return Yeni kart tipi<br>
	 *         <li>KART_TIPI - Islem sonrasi belirlenen kart tipi
	 */
	@GraymoundService("BNSPR_TFF_KK_RED_KART_TIPI_DONUSTUR")
	public static GMMap tffKKRedKartTipiDonustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kontrolMap = new GMMap();

		BigDecimal kkBasvuruNo = iMap.getBigDecimal("KK_BASVURU_NO");
		BigDecimal tffBasvuruNo = iMap.getBigDecimal("TFF_BASVURU_NO");
		String yeniKartTipi = StringUtils.EMPTY;
		String donusturKartTipi = StringUtils.EMPTY;

		try {
			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			// TFF basvurunu bul
			TffBasvuru tffBasvuru = null;
			if (tffBasvuruNo != null) {
				tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
			}
			else if (kkBasvuruNo != null) {
				tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", kkBasvuruNo)).add(Restrictions.eq("kartTipi", TFF_KREDI_KARTI)).uniqueResult();
			}
			// Tff basvurusu yoksa hata ver.
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}
			else {
				tffBasvuruNo = tffBasvuru.getBasvuruNo();
				kkBasvuruNo = tffBasvuru.getKkBasvuruNo();
			}

			// Donusturulecek kart tipini al, servis parametresine gelene oncelik var
			kontrolMap.clear();
			kontrolMap.put("PARAMETRE", "KK_RED_TFF_KART_TIPI");
			donusturKartTipi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", kontrolMap).getString("DEGER");
			// YENI_KART_TIPI - Suan icin sadece kk iptali sirasinda kullaniliyor.
			donusturKartTipi = CreditCardServicesUtil.nvl(iMap.getString("YENI_KART_TIPI"), donusturKartTipi);

			// Kart tipi donustur
			kontrolMap.clear();
			kontrolMap.put("TFF_BASVURU_NO", tffBasvuruNo);
			kontrolMap.put("KK_BASVURU_NO", kkBasvuruNo);
			kontrolMap.put("KART_TIPI", iMap.getString("KART_TIPI"));
			kontrolMap.put("KART_TIPI_GUNCELLENSIN_MI", CreditCardServicesUtil.EVET);
			if (TFF_PREPAID_KARTI.equals(donusturKartTipi)) {
				kontrolMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.EVET);
			}
			else {
				kontrolMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.HAYIR);
			}
			kontrolMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TIPI_DONUSTUR", kontrolMap));

			// Kart tipi secilmisse TFF Basvurusunu Guncelle, yoksa iptal et.
			yeniKartTipi = kontrolMap.getString("KART_TIPI");
			if (StringUtils.isBlank(yeniKartTipi)) {
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("BASVURU_IPTAL_EDILSIN_MI"))) {
					kontrolMap.clear();
					kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
					kontrolMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD"));
					kontrolMap.put("GEREKCE_KOD", "4");// Otomatik Iptal
					kontrolMap.put("ACIKLAMA", "Debit ve Prepaid Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi!!!");
					kontrolMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", kontrolMap));
				}
			}
			else {
				// Kart tipi donustukten sonra veri konrol yapilmadi ise veri kontrol durumuna,
				// yapildi ise basim durumuna ilerletilir.
				if ("BASIM".equals(iMap.getString("SONRAKI_DURUM_KODU", "BASIM"))) {
					if (!"BASIM".equals(tffBasvuru.getDurumKod())) {
						kontrolMap.clear();
						kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						kontrolMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
						kontrolMap.put("DURUM_KOD", "BASIM");
						kontrolMap.put("ISLEM_ACIKLAMA", "Kredi karti red aldigindan kart tipi donusumu yapildi.");
						kontrolMap.put("TARIHCE_AKSIYON", "E");
						GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", kontrolMap);
					}

					// Musteri Bilgilerini Guncelle
					kontrolMap.clear();
					kontrolMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("SOURCE", "TFF");
					GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", kontrolMap);

					// Karti basima gonder
					kontrolMap.clear();
					kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
					kontrolMap.put("DURUM_KOD", "BASIM");
					kontrolMap.put("KART_TIPI", yeniKartTipi);
					GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", kontrolMap);
				}
				else {
					kontrolMap.clear();
					kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
					kontrolMap.put("DURUM_KOD", iMap.getString("SONRAKI_DURUM_KODU"));
					kontrolMap.put("ISLEM_ACIKLAMA", "KK red aldi, durum guncellendi");
					kontrolMap.put("TARIHCE_AKSIYON", "E");
					GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", kontrolMap);

					// Veri kontrole dusecekse havuza ekle
					if ("VERI_KONTROL".equals(iMap.getString("SONRAKI_DURUM_KODU"))) {
						kontrolMap.clear();
						kontrolMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						kontrolMap.put("KART_TIPI", tffBasvuru.getKartTipi());
						kontrolMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
						kontrolMap.put("SOURCE", tffBasvuru.getSource());
						GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", kontrolMap);
					}
					else if ("ON_BASVURU".equals(iMap.getString("SONRAKI_DURUM_KODU"))) {
						kontrolMap.clear();
						kontrolMap.put("EVENT_TYPE_NO", CreditCardTRN3802Services.EPOS_EVENT_TYPE_NO);
						kontrolMap.put("EVENT_REF_NO", tffBasvuru.getBasvuruNo());
						GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", kontrolMap);
					}
				}

				// CRM
				try {
					kontrolMap.clear();
					kontrolMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("CRM_TYPE", CrmTypes.MAIN);
					GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", kontrolMap);
				}
				catch (Exception e) {
					e.printStackTrace();
					logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + tffBasvuru.getBasvuruNo());
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_TIPI", yeniKartTipi);
		return oMap;
	}

	/**
	 * TFF ile yapilan kredi karti basvurusu red alirsa musteriye sms gonderilir.<br>
	 * 
	 * @author murat.el
	 * @since 04.03.2014
	 * @param iMap
	 *            - Basvuru bilgileri<br>
	 *            <li>BASVURU_NO - Tff basvuru numarasi <li>KART_TIPI - Redde istinaden gonderilecek yeni kart tipi/iptale istinaden mevcut kart tipi <li>KART_VAR_MI - Mevcutta kullanilan kart var mi?(E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TFF_KK_RED_SMS_GONDER")
	public static GMMap kkRedSmsGonder(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TRN3805.Kk_Sms_Bilgisi(?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));// KK
			stmt.setString(2, iMap.getString("KART_TIPI"));// alinacak ya da mevcut kart tipi
			stmt.setString(3, iMap.getString("KART_VAR_MI"));// Mevcut karti var mi?
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.execute();
			// Bilgileri al
			String mesaj = stmt.getString(4);
			String cepNo = stmt.getString(5);

			// SMS gonder
			GMMap sorguMap = new GMMap();
			sorguMap.put("GIDEN_MESAJ", mesaj);
			sorguMap.put("CEP_NO", cepNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Debit basvurusu kart tipi donusumu yapilir ve kart basilir.<br>
	 * 
	 * @author murat.el
	 * @since 23.01.2014
	 * @param iMap
	 *            - Debit karti ve islem bilgileri<br>
	 *            <li>BASVURU_NO - Debit kart basvuru numarasi <li>KART_TIPI - Debit karti <li>BASVURU_IPTAL_EDILSIN_MI - Cevrilmek istenen kartlar mevcutsa basvuru iptal edilmeli mi? (E|H) <li>ISLEM_NO - Donusumun hangi ait oldugu islem numarasi <li>ISLEM_KOD - Basvuru iptal edilecekse, iptalin gerceklestigi islem kodu
	 * @return Yeni kart tipi<br>
	 *         <li>KART_TIPI - Islem sonrasi belirlenen kart tipi
	 */
	@GraymoundService("BNSPR_TFF_DEBIT_KART_TIPI_DONUSTUR")
	// BNSPR_KK_DEBIT_DONUSTUR
	public static GMMap tffDebitKartTipiDonustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartTipi = null;

		try {
			// TFF basvuru numarasini bul
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("kartTipi", "D")).uniqueResult();
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}

			// Kart tipi donustur
			GMMap kontrolMap = new GMMap();
			kontrolMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			kontrolMap.put("KART_TIPI", tffBasvuru.getKartTipi());
			kontrolMap.put("KART_TIPI_GUNCELLENSIN_MI", CreditCardServicesUtil.EVET);
			kontrolMap.put("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.EVET);
			kontrolMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TIPI_DONUSTUR", kontrolMap));

			// Kart tipi secilmisse TFF Basvurusunu Guncelle, yoksa iptal et.
			kartTipi = kontrolMap.getString("KART_TIPI");
			if (StringUtils.isNotBlank(kartTipi)) {
				// Durumunu basima getir.
				if (!"BASIM".equals(tffBasvuru.getDurumKod())) {
					kontrolMap.clear();
					kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
					kontrolMap.put("DURUM_KOD", "BASIM");
					kontrolMap.put("ISLEM_ACIKLAMA", "Debit/Prepaid kart donusumu yapildi.");
					kontrolMap.put("TARIHCE_AKSIYON", "E");// Yeni kayit olustur
					GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", kontrolMap);
				}

				// Karti basima gonder
				kontrolMap.clear();
				kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
				kontrolMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				kontrolMap.put("DURUM_KOD", tffBasvuru.getDurumKod());
				kontrolMap.put("KART_TIPI", kartTipi);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", kontrolMap));
			}
			else {
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("BASVURU_IPTAL_EDILSIN_MI"))) {
					kontrolMap.clear();
					kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					kontrolMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
					kontrolMap.put("ISLEM_KOD", iMap.getString("ISLEM_KOD"));
					kontrolMap.put("GEREKCE_KOD", "4");// Otomatik Iptal
					kontrolMap.put("ACIKLAMA", "Prepaid Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi!!!");
					kontrolMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", kontrolMap));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_TIPI", kartTipi);
		return oMap;
	}

	/**
	 * Basvuru no ve kart tipi verilen basvurunun kart tipi donusumunu gerceklestirir.<br>
	 * Kart tipi kredi karti ise debite, kart tipi debit ise prepaide cevrilir.<br>
	 * 
	 * @author murat.el
	 * @since 23.01.2014
	 * @param iMap
	 *            - Kart tipi degistirilecek basvuru bilgileri<br>
	 *            <li>TFF_BASVURU_NO - TFF basvuru numarasi <li>KK_BASVURU_NO - TFF basvuru numarasi <li>KART_TIPI - Basvurunun kart tipi <li>KART_TIPI_GUNCELLENSIN_MI - Islem sonrasi alinan yeni kart tipi ile basvuru guncellensin mi? (E|H) <li>URUN_KONTROL_EDILSIN_MI - Kart var mi kontrolu yapilirken urun bazli ayrim yapilsin mi(E:Evet|H:Hayir) <li>YENI_KART_TIPI - Kart tipi kk olan basvurular
	 *            icin donusturulmek istenen kart tipi
	 * @return Kart tipi bilgisi<br>
	 *         <li>KART_TIPI - Islem sonrasi alinabilecek yeni kart tipi <li>DEBIT_KART_VAR_MI - Mevcutta kullandigi/basvurdugu debit karti var mi?(true|false) <li>PREPAID_KART_VAR_MI - Mevcutta kullandigi/basvurdugu prepaid karti var mi?(true|false)
	 */
	@GraymoundService("BNSPR_TFF_KART_TIPI_DONUSTUR")
	public static GMMap kartTipiDonustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal iTffBasvuruNo = iMap.getBigDecimal("TFF_BASVURU_NO");
		BigDecimal iKkBasvuruNo = iMap.getBigDecimal("KK_BASVURU_NO");
		String iYeniKartTipi = iMap.getString("YENI_KART_TIPI");
		String iKartTipi = iMap.getString("KART_TIPI");
		String oKartTipi = null;
		boolean debitKartVarMi = false;
		boolean prepaidKartVarMi = false;
		boolean debitBasvuruVarMi = false;
		boolean prepaidBasvuruVarMi = false;

		try {
			// Session al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// TFF basvuru bilgisini al
			TffBasvuru tffBasvuru = null;
			if (TFF_KREDI_KARTI.equals(iKartTipi)) {
				if (iTffBasvuruNo != null) {
					tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iTffBasvuruNo);
				}
				else if (iKkBasvuruNo != null) {
					tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", iKkBasvuruNo)).add(Restrictions.eq("kartTipi", iKartTipi)).uniqueResult();
				}
			}
			else if (TFF_DEBIT_KARTI.equals(iKartTipi)) {
				tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iTffBasvuruNo);
			}// Prepaid kart icin daha asagisi olmayacagindan hata alir. Ihtiyac da yok.

			// TFF basvurusu bulundu mu?
			if (tffBasvuru == null || !tffBasvuru.getKartTipi().equals(iMap.getString("KART_TIPI"))) {
				CreditCardServicesUtil.raiseGMError("2999", iTffBasvuruNo);
			}

			GMMap kontrolMap = new GMMap();
			// Donusturulecek kart tipini belirle
			String donusturKartTipi = null;
			if (TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
				kontrolMap.clear();
				kontrolMap.put("PARAMETRE", "KK_RED_TFF_KART_TIPI");
				donusturKartTipi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", kontrolMap).getString("DEGER");
				// Donusturulmek istenen kart tipi var mi, varsa ve uygunsa set et.
				if (StringUtils.isNotBlank(iYeniKartTipi) && (TFF_DEBIT_KARTI.equals(iYeniKartTipi) || TFF_PREPAID_KARTI.equals(iYeniKartTipi))) {
					donusturKartTipi = CreditCardServicesUtil.nvl(iYeniKartTipi, donusturKartTipi);
				}
			}
			else if (TFF_DEBIT_KARTI.equals(tffBasvuru.getKartTipi())) {
				donusturKartTipi = TFF_PREPAID_KARTI;
			}
			else {
				donusturKartTipi = StringUtils.EMPTY;
			}

			// Bu basvurunun donusebilecegi kart tipini bul. Once debit/prepaid karti var mi diye bak.
			// Herhangi bir kart/gecerli basvuru yoksa kart tipi donusturulsun isteniyorsa onceki gecersiz basvurular
			// iptal edilerek donusturulecek kart tipi verilir. Herhangi bir aktif karti/gecerli basvurusu varsa
			// basvuru iptal edilmek uzere ust servise oKartTipi bos olarak pas edilir.
			kontrolMap.clear();
			kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			kontrolMap.put("URUN_KONTROL_EDILSIN_MI", iMap.getString("URUN_KONTROL_EDILSIN_MI", CreditCardServicesUtil.HAYIR));
			kontrolMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TIPI_KONTROL", kontrolMap));
			// Sonucu al
			debitKartVarMi = kontrolMap.getBoolean("DEBIT_KART_VAR_MI");
			prepaidKartVarMi = kontrolMap.getBoolean("PREPAID_KART_VAR_MI");
			debitBasvuruVarMi = kontrolMap.getBoolean("DEBIT_BASVURU_VAR_MI");
			prepaidBasvuruVarMi = kontrolMap.getBoolean("PREPAID_BASVURU_VAR_MI");

			// Kredi karti basvurusu ise debit ve prepaid kart/basvuru var mi
			if (TFF_KREDI_KARTI.equals(iKartTipi)) {
				// PY-5818
				// Debit/Prepaid karti varsa, kart tipi donusumu yapilmaz, mevcut basvuru iptal edilir.
				if (debitKartVarMi /*|| prepaidKartVarMi*/) { /*pp kart� varsa debit kart verilmesine engel olmas�n. PYPVD-278*/
					oKartTipi = StringUtils.EMPTY;
				}
				else {
					// Daha ileri durumlu bir debit basvuru var mi? Yoksa onceki basvurulari iptal et.
					Boolean gecerliDebitBasvuruVarmi = false;
					if (debitBasvuruVarMi) {
						kontrolMap.clear();
						kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						kontrolMap.put("KART_TIPI", TFF_DEBIT_KARTI);
						kontrolMap.put("MEVCUT_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.HAYIR);
						kontrolMap.put("ONCEKI_IPTAL_EDILEBILIR_MI", iMap.getString("KART_TIPI_GUNCELLENSIN_MI"));
						kontrolMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL", kontrolMap));
						if (CreditCardServicesUtil.HAYIR.equals(kontrolMap.getString("DEVAM"))) {
							gecerliDebitBasvuruVarmi = true;
						}
					}
					// Daha ileri durumlu bir prepaid basvuru var mi? Yoksa onceki basvurulari iptal et.
					Boolean gecerliPrepaidBasvuruVarmi = false;
					if (prepaidBasvuruVarMi) {
						kontrolMap.clear();
						kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						kontrolMap.put("KART_TIPI", TFF_PREPAID_KARTI);
						kontrolMap.put("MEVCUT_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.HAYIR);
						kontrolMap.put("ONCEKI_IPTAL_EDILEBILIR_MI", iMap.getString("KART_TIPI_GUNCELLENSIN_MI"));
						kontrolMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL", kontrolMap));
						if (CreditCardServicesUtil.HAYIR.equals(kontrolMap.getString("DEVAM"))) {
							gecerliPrepaidBasvuruVarmi = true;
						}
					}
					// Daha ileri durumlu bir debit/prepaid basvurusu varsa mevcut basvuru iptal edilecek
					if (gecerliDebitBasvuruVarmi /*|| gecerliPrepaidBasvuruVarmi*/) { /*pp ba�vurusu varsa debit kart verilmesine engel olmas�n. PYPVD-278*/
						oKartTipi = StringUtils.EMPTY;
					}
					else {
						oKartTipi = donusturKartTipi;
					}
				}
			}
			else if (TFF_DEBIT_KARTI.equals(iKartTipi)) {
				/*if (prepaidKartVarMi) {
					oKartTipi = StringUtils.EMPTY;
				} else {
					Boolean gecerliPrepaidBasvuruVarmi = false;
					if (prepaidBasvuruVarMi) {
						kontrolMap.clear();
						kontrolMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						kontrolMap.put("KART_TIPI", TFF_PREPAID_KARTI);
						kontrolMap.put("MEVCUT_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.HAYIR);
						kontrolMap.put("ONCEKI_IPTAL_EDILEBILIR_MI", iMap.getString("KART_TIPI_GUNCELLENSIN_MI"));
						kontrolMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL", kontrolMap));
						if (CreditCardServicesUtil.HAYIR.equals(kontrolMap.getString("DEVAM"))) {
							gecerliPrepaidBasvuruVarmi = true;
						} 
					}
					
					if (gecerliPrepaidBasvuruVarmi) {
						oKartTipi = StringUtils.EMPTY;
					} else {
						oKartTipi = donusturKartTipi; 
					}
				}*/

				oKartTipi = donusturKartTipi; /*pp kart� varsa debit kart verilmesine engel olmas�n. PYPVD-278*/
			}

			// Basvuru istenen kart tipine donusturulebiliyorsa donustur, yoksa es gec
			if (StringUtils.isNotBlank(oKartTipi)) {
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("KART_TIPI_GUNCELLENSIN_MI"))) {
					tffBasvuru.setKartTipi(donusturKartTipi);
					session.saveOrUpdate(tffBasvuru);
					session.flush();
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_TIPI", oKartTipi);
		oMap.put("DEBIT_KART_VAR_MI", debitKartVarMi || debitBasvuruVarMi);
		oMap.put("PREPAID_KART_VAR_MI", prepaidKartVarMi || prepaidBasvuruVarMi);
		return oMap;
	}

	/**
	 * TFF basvuru nosu verilen basvurunun kart tipi kontrolunu gerceklestirir.<br>
	 * Basvuru sahibinin daha onceden kullandigi ya da basvurdugu(gecerli statude olan) kart var mi sorgusunu gerceklesitir. <br>
	 * 
	 * @author murat.el
	 * @since 17.03.2014
	 * @param iMap
	 *            - TFF basvuru bilgileri<br>
	 *            <li>BASVURU_NO - TFF basvuru numarasi <li>URUN_KONTROL_EDILSIN_MI - Kart var mi kontrolu yapilirken urun bazli ayrım yapilsin mi(E:Evet|H:Hayir)
	 * @return Kart tipi bilgisi<br>
	 *         <li>DEBIT_KART_VAR_MI - Mevcutta kullandigi debit karti var mi?(true|false) <li>PREPAID_KART_VAR_MI - Mevcutta kullandigi prepaid karti var mi?(true|false) <li>DEBIT_BASVURU_VAR_MI - Mevcutta basvurdugu debit karti var mi?(true|false) <li>PREPAID_BASVURU_VAR_MI - Mevcutta basvurdugu prepaid karti var mi?(true|false)
	 */
	@GraymoundService("BNSPR_TFF_KART_TIPI_KONTROL")
	public static GMMap controlTFFDonusturKartTipi(GMMap iMap) {
		GMMap oMap = new GMMap();

		boolean debitKartVarMi = false;
		boolean prepaidKartVarMi = false;
		boolean debitBasvuruVarMi = false;
		boolean prepaidBasvuruVarMi = false;

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}

			// Urun Kodu Al
			String urun = null;
			String urunSahipKodu = null;
			if ("E".equals(iMap.getString("URUN_KONTROL_EDILSIN_MI"))) {
				urun = tffBasvuru.getUrun();
				urunSahipKodu = tffBasvuru.getUrunSahipKodu();
			}

			// Debit Basvurusu var mi?
			GMMap basvuruMap = new GMMap();
			basvuruMap.put("UYE_NO", tffBasvuru.getTffUyeNo());
			basvuruMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			basvuruMap.put("KART_TIPI", TFF_DEBIT_KARTI);
			basvuruMap.put("URUN", urun);
			basvuruMap.put("URUN_TIPI", urunSahipKodu);
			basvuruMap.putAll(kartBasvuruVarMi(basvuruMap));
			debitBasvuruVarMi = basvuruMap.getBoolean("BASVURU_VAR_MI");

			// Debit Karti var mi?
			GMMap kartMap = new GMMap();
			kartMap.put("KART_TIPI", TFF_DEBIT_KARTI);
			kartMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_KART_ALABILME_KONTROL", kartMap));
			if (CreditCardServicesUtil.EVET.equals(kartMap.getString("KART_VAR_MI"))) {
				debitKartVarMi = true;
			}

			// Prepaid Basvurusu var mi?
			basvuruMap.clear();
			basvuruMap.put("UYE_NO", tffBasvuru.getTffUyeNo());
			basvuruMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			basvuruMap.put("KART_TIPI", TFF_PREPAID_KARTI);
			basvuruMap.put("URUN", urun);
			basvuruMap.put("URUN_TIPI", urunSahipKodu);
			basvuruMap.putAll(kartBasvuruVarMi(basvuruMap));
			prepaidBasvuruVarMi = basvuruMap.getBoolean("BASVURU_VAR_MI");

			// Prepaid Karti var mi?
			kartMap.clear();
			kartMap.put("KART_TIPI", TFF_PREPAID_KARTI);
			kartMap.put("URUN_KODU", tffBasvuru.getUrun());
			kartMap.put("URUN_SAHIP_KODU", tffBasvuru.getUrunSahipKodu());
			kartMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_KART_ALABILME_KONTROL", kartMap));
			if (CreditCardServicesUtil.EVET.equals(kartMap.getString("KART_VAR_MI"))) {
				prepaidKartVarMi = true;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("DEBIT_KART_VAR_MI", debitKartVarMi);
		oMap.put("PREPAID_KART_VAR_MI", prepaidKartVarMi);
		oMap.put("DEBIT_BASVURU_VAR_MI", debitBasvuruVarMi);
		oMap.put("PREPAID_BASVURU_VAR_MI", prepaidBasvuruVarMi);
		return oMap;
	}

	/**
	 * Verilen uyenin mevcut basvurusu haricinde aktif verilen ozelliklerde kart basvurusu var mi kontrolunu gerceklestirir.<br>
	 * 
	 * @author murat.el
	 * @since 17.03.2014
	 * @param iMap
	 *            - TFF basvuru bilgileri<br>
	 *            <li>UYE_NO - TFF kart basvurusunu yapan uye numarasi <li>BASVURU_NO - TFF basvuru numarasi <li>KART_TIPI - Basvurulan tff kart tipi <li>URUN - Bassvurulan tff urunu <li>URUN_TIPI - Basvurulan tff kartinin urun tipi
	 * @return Kart tipi bilgisi<br>
	 *         <li>BASVURU_VAR_MI - Mevcutta basvurdugu karti var mi?(true|false)
	 */
	@GraymoundService("BNSPR_TFF_KART_TIPI_AKTIF_BASVURU_KONTROL")
	public static GMMap kartBasvuruVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean kartBasvuruVarMi = false;

		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TFF_BASVURU.get_kart_tipi_basvuru_sayisi(?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.INTEGER);
			stmt.setBigDecimal(2, iMap.getBigDecimal("UYE_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(4, iMap.getString("KART_TIPI"));
			stmt.setString(5, iMap.getString("URUN"));
			stmt.setString(6, iMap.getString("URUN_TIPI"));
			stmt.execute();

			int basvuruSayisi = stmt.getInt(1);
			if (basvuruSayisi != 0) {
				kartBasvuruVarMi = true;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("BASVURU_VAR_MI", kartBasvuruVarMi);
		return oMap;
	}

	// I:MUSTERI_NO, KART_TIPI, URUN_SAHIP_KODU
	// O:KART_VAR_MI, KART_NO
	/**
	 * Musterinin verilen kart tipinde acik/kullandigi karti var mi kontrolunu gerceklestirir.<br>
	 * 
	 * @author murat.el
	 * @since 17.03.2014
	 * @param iMap
	 *            - TFF basvuru bilgileri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>KART_TIPI - Kart tipi <li>URUN_KODU - Prepaid kart urun kodu <li>URUN_SAHIP_KODU - Prepaid kart urun sahip kodu
	 * @return Kart tipi bilgisi<br>
	 *         <li>KART_VAR_MI - Mevcutta acik/kullandigi karti var mi?(E:Evet|H:Hayir) <li>KART_NO - Mevcutta acik/kullandigi karti varsa kartin numarasi
	 */
	@GraymoundService("BNSPR_INTRA_KART_ALABILME_KONTROL")
	public static GMMap intraKartAlabilmeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartVarMi = CreditCardServicesUtil.HAYIR;
		String kartNo = null;
		String appNo = null;


		// Parametre Kontrol
		String kartTipi = iMap.getString("KART_TIPI");
		if (!(TFF_DEBIT_KARTI.equals(kartTipi) || TFF_PREPAID_KARTI.equals(kartTipi))) {
			oMap.put("KART_VAR_MI", kartVarMi);
			oMap.put("KART_NO", kartNo);
			return oMap;
		}

		try {
			GMMap dKontrol = new GMMap();
			dKontrol.put("CARD_DCI", kartTipi);
			dKontrol.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
			dKontrol.put("CARD_BANK_STATUS", "N");
			dKontrol.put("SEGMENT", OceanConstants.Card_Segment_TFF);
			dKontrol = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", dKontrol);
			// Kart listesi var mi?
			if (dKontrol == null || dKontrol.isEmpty() || dKontrol.getSize("CARD_DETAIL_INFO") < 1) {
				oMap.put("KART_VAR_MI", kartVarMi);
				oMap.put("KART_NO", kartNo);
				return oMap;
			}

			// Kart listesinde karti bul
			for (int i = 0; i < dKontrol.getSize("CARD_DETAIL_INFO"); i++) {
				// Listeden istenen kart tipi var mi?
				if (kartTipi.equals(dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI_AKUSTIK"))) {
					// Istenen kart tipi debit ise kart bulundu
					if (TFF_DEBIT_KARTI.equals(kartTipi)) {
						kartVarMi = CreditCardServicesUtil.EVET;
						kartNo = dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO");
						appNo  = dKontrol.getString("CARD_DETAIL_INFO", i, "APPLICATION_NO");

						break;
						// Istenen prepaid ise urun kontrolu yap
					}
					else if (TFF_PREPAID_KARTI.equals(kartTipi)) {
						Object[] parameters = new Object[6];
						parameters[0] = BnsprType.STRING;
						parameters[1] = dKontrol.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");
						parameters[2] = BnsprType.STRING;
						parameters[3] = dKontrol.getString("CARD_DETAIL_INFO", i, "LOGO_CODE");
						parameters[4] = BnsprType.STRING;
						parameters[5] = TFF_PREPAID_KARTI;

						String func = "{? = call pkg_trn3801.get_takim_kodu(?,?,?)}";
						String urunSahipKodu = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, parameters));

						func = "{? = call pkg_trn3801.get_urun_kodu(?,?,?)}";
						String urunKodu = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, parameters));

						// Urun ayni ise kart bulundu
						if (iMap.getString("URUN_SAHIP_KODU", StringUtils.EMPTY).equals(urunSahipKodu) && iMap.getString("URUN_KODU", StringUtils.EMPTY).equals(urunKodu)) {
							kartVarMi = CreditCardServicesUtil.EVET;
							kartNo = dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO");
							appNo  = dKontrol.getString("CARD_DETAIL_INFO", i, "APPLICATION_NO");
							break;
						}
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_VAR_MI", kartVarMi);
		oMap.put("KART_NO", kartNo);
		oMap.put("BASVURU_NO", appNo);
		return oMap;
	}

	/**
	 * KPS sonucu TFF tablolarina kaydedilen bilgileri alir.
	 * 
	 * @param iMap
	 *            - TFF_BASVURU_NO
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TFF_GET_BASVURU_BILGI")
	public static GMMap getTffBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Kaydedilecek Bilgileri Al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuruKimlik != null) {
				oMap.put("AD1", tffBasvuruKimlik.getAd());
				oMap.put("AD2", tffBasvuruKimlik.getIkinciAd());
				oMap.put("SOYAD", tffBasvuruKimlik.getSoyad());
				oMap.put("DOGUM_YERI", tffBasvuruKimlik.getDogumYeri());
				oMap.put("DOGUM_TARIHI", tffBasvuruKimlik.getDogumTar());
				oMap.put("BABA_AD", tffBasvuruKimlik.getBabaAd());
				oMap.put("KIMLIK_SERI_NO", tffBasvuruKimlik.getKimlikSeriNo());
				oMap.put("KIMLIK_SIRA_NO", tffBasvuruKimlik.getKimlikSiraNo());
				oMap.put("ANNE_AD", tffBasvuruKimlik.getAnneAdi());
				oMap.put("IL_KODU", tffBasvuruKimlik.getNufusIlKod());
				oMap.put("ILCE_KODU", tffBasvuruKimlik.getNufusIlceKod());
				oMap.put("CILT_KODU", tffBasvuruKimlik.getCiltNo());
				oMap.put("AILE_SIRA_NO", tffBasvuruKimlik.getAileSiraNo());
				oMap.put("BIREY_SIRA_NO", tffBasvuruKimlik.getBireySiraNo());
				oMap.put("VERILIS_TARIHI", tffBasvuruKimlik.getNufusVerTarKps());
				oMap.put("KAYIP_CUZDAN_NO", tffBasvuruKimlik.getKayipKimlikSiraNo());
				oMap.put("KAYIP_CUZDAN_SERI", tffBasvuruKimlik.getKayipKimlikSeriNo());
				oMap.put("VERILDIGI_ILCE_ADI", tffBasvuruKimlik.getNufusVerYer());
				oMap.put("VERILIS_NEDENI", tffBasvuruKimlik.getNufusVerNedeni());
				oMap.put("ES_TCKN", tffBasvuruKimlik.getEsTcKimlikNo());
				oMap.put("MAHALLE_KOY", tffBasvuruKimlik.getMahalleKoy());
				oMap.put("CINSIYET", tffBasvuruKimlik.getCinsiyet());
				oMap.put("MEDENI_HALI", tffBasvuruKimlik.getMedeniHal());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * TFF kredi karti tablosundan kaydedilen bilgileri alir.
	 * 
	 * @param iMap
	 *            - TFF_BASVURU_NO
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TFF_GET_KK_BASVURU_BILGI")
	public static GMMap getKkTffBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TFF_BASVURU.get_tff_basvuru_bilgi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));

			// Ekstre Tipi
			oMap.put("EKSTRE_TIPI_POSTA", BooleanUtils.toBoolean(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"), "H"), "E", "H"));
			oMap.put("EKSTRE_TIPI_EMAIL", BooleanUtils.toBoolean(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"), "H"), "E", "H"));
			oMap.put("EKSTRE_TIPI_SMS", BooleanUtils.toBoolean(CreditCardServicesUtil.nvl(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"), "H"), "E", "H"));
			// Otomatik Limit Artis
			oMap.put("OTOMATIK_LIMIT_ARTIS_B", BooleanUtils.toBoolean(CreditCardServicesUtil.nvl(iMap.getString("OTOMATIK_LIMIT_ARTIS"), "H"), "E", "H"));
			// Oturma/Calisma suresi
			oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", oMap.getString("MEVCUT_ADR_OTURMA_SURESI_YIL"));
			oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", oMap.getString("MEVCUT_ADR_OTURMA_SURESI_AY"));
			// Teslimat Adresi
			if ("E".equals(oMap.getString("TESLIMAT_ADRESI"))) {
				oMap.put("TESLIMAT_ADRESI_EV", 1);
				oMap.put("TESLIMAT_ADRESI_IS", 0);
			}
			else if ("I".equals(oMap.getString("TESLIMAT_ADRESI"))) {
				oMap.put("TESLIMAT_ADRESI_EV", 0);
				oMap.put("TESLIMAT_ADRESI_IS", 1);
			}
			else {
				oMap.put("TESLIMAT_ADRESI_EV", 0);
				oMap.put("TESLIMAT_ADRESI_IS", 0);
			}
			// Ekstre secimi
			if ("E".equals(iMap.getString("EKSTRE_SECIMI"))) {
				oMap.put("EKSTRE_ADRESI_EV", 1);
				oMap.put("EKSTRE_ADRESI_IS", 0);
			}
			else if ("I".equals(iMap.getString("EKSTRE_SECIMI"))) {
				oMap.put("EKSTRE_ADRESI_EV", 0);
				oMap.put("EKSTRE_ADRESI_IS", 1);
			}
			else {
				oMap.put("EKSTRE_ADRESI_EV", 0);
				oMap.put("EKSTRE_ADRESI_IS", 0);
			}
			// KDH
			oMap.put("KDH_ISTIYOR_MU_B", BooleanUtils.toBoolean(CreditCardServicesUtil.nvl(oMap.getString("KDH_ISTIYOR_MU"), "H"), "E", "H"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/**
	 * TFF basvurusuna ait kk basvuru bilgisini veya kart tipini gunceller. <br>
	 * 
	 * @author murat.el
	 * @since 26.02.2014
	 * @param iMap
	 *            - Basvuru bilgileri<br>
	 *            <li>TFF_BASVURU_NO - Tff basvuru numarasi <li>KK_BASVURU_NO - Kk basvuru numarasi <li>KART_TIPI - TFF kart tipi
	 * @return oMap - Output Yok.<br>
	 */
	@GraymoundService("BNSPR_TFF_KK_BASVURU_BILGI_GUNCELLE")
	public static GMMap updateTffKKBasvuruInfo(GMMap iMap) {
		return updateTffKKBasvuruInfo(iMap.getBigDecimal("TFF_BASVURU_NO"), iMap.getBigDecimal("KK_BASVURU_NO"), iMap.getString("KART_TIPI"));
	}

	/**
	 * TFF kartina ait istenen kredi karti basvurusunun durumu ile tff kart durumunu gunceller.
	 * 
	 * @param tffBasvuruNo
	 *            - TFF karti basvuru no
	 * @param kkBasvuruNo
	 *            - TFF kartinda istenen kredi karti ozelligine istinaden olustutulan kredi karti basvuru no
	 * @param kartTipi
	 *            - TFF kart tipi
	 */
	private static GMMap updateTffKKBasvuruInfo(BigDecimal tffBasvuruNo, BigDecimal kkBasvuruNo, String kartTipi) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TRN3801.updateTffKKBasvuruInfo(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, tffBasvuruNo);
			stmt.setBigDecimal(2, kkBasvuruNo);
			stmt.setString(3, kartTipi);
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * TFF basvuru tablosundan durumu aktif olan basvurulari getirir.
	 * 
	 * @param iMap
	 *            -BASVURU_NO,TC_KIMLIK_NO,MUSTERI_NO,EUPT_HESAP_NO,TFF_KART_TIPI,KART_URUN_ID
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_TFF_GET_AKTIF_BASVURU_LIST")
	public static GMMap getTffAktifBasvuruList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Aktif_Basvuru_List(?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("EUPT_HESAP_NO"));
			stmt.setString(i++, iMap.getString("TFF_KART_TIPI"));
			stmt.setString(i++, iMap.getString("UYRUK_KOD"));
			stmt.setString(i++, iMap.getString("PASAPORT_NO"));
			stmt.setString(i++, iMap.getString("KART_URUN_ID"));
			stmt.setString(i++, iMap.getString("LOGO_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MEVCUT_BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TFF basvuru tablosundan durumu odenmis olan basvurulari getirir.
	 * 
	 * @param iMap
	 *            -BASVURU_NO,TC_KIMLIK_NO,MUSTERI_NO,EUPT_HESAP_NO,TFF_KART_TIPI,KART_URUN_ID
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_TFF_GET_ODENMIS_BASVURU_LIST")
	public static GMMap getTffOdenmisBasvuruList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Odenmis_Basvuru_List(?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("EUPT_HESAP_NO"));
			stmt.setString(i++, iMap.getString("TFF_KART_TIPI"));
			stmt.setString(i++, iMap.getString("UYRUK_KOD"));
			stmt.setString(i++, iMap.getString("PASAPORT_NO"));
			stmt.setString(i++, iMap.getString("KART_URUN_ID"));
			stmt.setString(i++, iMap.getString("LOGO_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MEVCUT_BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TFF basvuru odeme tx tablosundan odeme bilgilerini doner
	 * 
	 * @param iMap
	 *            -BASVURU_NO
	 * @return oMap - ODEME_BILGILERI
	 */
	@GraymoundService("BNSPR_TFF_GET_KART_BEDELI")
	public static GMMap getTffKartBedeli(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Basvuru_Kart_Bedeli(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "ODEME_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * EUPT parametresine göre gelen ilk baþvurunun musteri no ve tckn bilgilerini döner.
	 * 
	 * @param iMap
	 *            - EUPT_HESAP_NO
	 * @return oMap - TCKN,MUSTERI_NO
	 */
	@GraymoundService("BNSPR_TFF_GET_BASVURU_BILGI_WITH_EUPT")
	public static GMMap getTffBasvuruBilgiWithEupt(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_AKTIF_BASVURU_LIST", iMap));
			oMap.put("MUSTERI_NO", iMap.getBigDecimal("BASVURU_BILGILERI", 0, "MUSTERI_NO"));
			oMap.put("TC_KIMLIK_NO", iMap.getBigDecimal("BASVURU_BILGILERI", 0, "TC_KIMLIK_NO"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * TFF basvuru tablosundan durumu acik olan basvurulari getirir.
	 * 
	 * @param iMap
	 *            -GSM_NO
	 * @return oMap - BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_TFF_GET_AKTIF_KART_LIST")
	public static GMMap getTffAktifKartList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Get_Tff_Basvuru_With_GSM(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setString(i++, iMap.getString("GSM_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TFF basvuru kart teslimat ucretleri
	 * 
	 * @return oMap - TESLIMAT_UCRETLERI
	 */
	@GraymoundService("BNSPR_TFF_KART_TESLIMAT_UCRETLERI")
	public static GMMap getTffKartTeslimatUcretleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Teslimat_Ucretleri}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "TESLIMAT_UCRETLERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TFF_KART_UCRETLERI")
	public static GMMap tffKartUcretleri(GMMap iMap) {

		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		oMap.put("KART_BEDELI", BigDecimal.ZERO);
		oMap.put("VIZE_BEDELI", BigDecimal.ZERO);
		oMap.put("LOYALTY_BEDELI", BigDecimal.ZERO);

		try {
			// kartin tipi ogrenilir
			GMMap cardProperty = new GMMap();
			GMMap cardInfo = new GMMap();
			cardProperty.put("CARD_NO", iMap.getString("KART_NO"));
			cardProperty.putAll(GMServiceExecuter.execute("BNSPR_GET_CARD_PROPERTIES", cardProperty));// KART_BILGILERI

			if (cardProperty.getString("RETURN_CODE").equals("0")) {
				String dest = cardProperty.getString("DESTINATION");
				cardProperty.put("CARD_DCI", cardProperty.getString("DCI"));
				// kart tipini bul
				if ("O".equals(dest)) {
					cardInfo.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardProperty));
				}
				else if ("I".equals(dest)) {
					cardInfo.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardProperty));
				}
				for (int i = 0; i < cardInfo.getSize("CARD_DETAIL_INFO"); i++) {
					if (StringUtils.isNotBlank(cardInfo.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID"))) {

						String productID = null;
						productID = cardInfo.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");

						conn = DALUtil.getGMConnection();

						query = "{call PKG_TFF_BASVURU.Kart_Yenileme_Ucretleri(?,?,?,?,?)}";
						stmt = conn.prepareCall(query);
						stmt.setString(1, iMap.getString("KART_NO"));
						stmt.setString(2, productID);
						stmt.registerOutParameter(3, Types.FLOAT);
						stmt.registerOutParameter(4, Types.FLOAT);
						stmt.registerOutParameter(5, Types.FLOAT);

						stmt.execute();

						oMap.put("KART_BEDELI", stmt.getBigDecimal(3));
						oMap.put("VIZE_BEDELI", stmt.getBigDecimal(4));
						oMap.put("LOYALTY_BEDELI", stmt.getBigDecimal(5));
						oMap.put("URUN_ID", productID);
					}
				}
			}

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TESLIMAT_UCRETLERI", new GMMap()));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* INTRA - GET CARD INFO
	// ---------------------------------------------------------------------
	/**
	 * Musterinin intra sistemindeki Debit/Prepaid kartlari kriterlere gore listeler.<br>
	 * 
	 * @author murat.el
	 * @since 22.04.2014
	 * @param iMap
	 *            - TFF basvuru bilgileri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>TCKN - TC kimlik numarasi <li>KART_NO - Kart numarasi <li>BASVURU_NO - Basvuru numarasi <li>KART_TIPI - Kart tipi (D:Debit|P:Prepaid|A:Hepsi) <li>DURUM - Kart durumu (N:Acik)
	 * @return Kart tipi bilgisi<br>
	 *         <li>KART_LIST - Duruma uygun kart listesi(E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_INTRA_KART_LISTELE")
	public static GMMap intraKartListele(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartList = "KART_LIST";
		String kartListIntra = "CARD_DETAIL_INFO";
		String kartDurum = CreditCardServicesUtil.nvl(iMap.getString("DURUM"), "N");
		String kartTipi = CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), "A");

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("CUSTOMER_NO", CreditCardServicesUtil.nvl(iMap.getString("MUSTERI_NO"), StringUtils.EMPTY));
			sorguMap.put("TCKN", CreditCardServicesUtil.nvl(iMap.getString("TCKN"), StringUtils.EMPTY));
			sorguMap.put("CARD_NO", CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), StringUtils.EMPTY));
			sorguMap.put("APPLICATION_NO", CreditCardServicesUtil.nvl(iMap.getString("BASVURU_NO"), StringUtils.EMPTY));
			sorguMap.put("CARD_DCI", kartTipi);
			sorguMap.put("CARD_BANK_STATUS", kartDurum);
			sorguMap.put("NO_NEED_OCEAN_CARDS", true); /*YKP i�in ocean kartlar� getirmesin*/
			sorguMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", sorguMap);
			// Kart listesi var mi?
			if (sorguMap == null || sorguMap.isEmpty() || sorguMap.getSize(kartListIntra) < 1) {
				return oMap;
			}

			// Kart listesinde karti bul
			GMMap hesapMap = new GMMap();
			String hesapNo = StringUtils.EMPTY;
			for (int i = 0, j = 0; i < sorguMap.getSize(kartListIntra); i++) {
				// Listeden istenen kart tipi var mi?
				if ("A".equals(kartTipi)) {// Hepsi
					oMap.put(kartList, i, "KART_NO", sorguMap.getString(kartListIntra, i, "CARD_NO"));
					oMap.put(kartList, i, "KART_TIPI", sorguMap.getString(kartListIntra, i, "CARD_DCI_AKUSTIK"));
					oMap.put(kartList, i, "URUN_KODU", sorguMap.getString(kartListIntra, i, "PRODUCT_ID"));
					oMap.put(kartList, i, "LOGO_KODU", sorguMap.getString(kartListIntra, i, "LOGO_CODE"));
					oMap.put(kartList, i, "DURUM_KODU", sorguMap.getString(kartListIntra, i, "CARD_STAT_CODE"));
					oMap.put(kartList, i, "ALT_DURUM_KODU", sorguMap.getString(kartListIntra, i, "CARD_SUB_STAT_CODE"));
					oMap.put(kartList, i, "BASVURU_NO", sorguMap.getString(kartListIntra, i, "APPLICATION_NO"));
					oMap.put(kartList, i, "KAYIT_TARIHI", sorguMap.getString(kartListIntra, i, "EMBOSS_DATE"));
					oMap.put(kartList, i, "DURUM_ACIKLAMA", sorguMap.getString(kartListIntra, i, "CARD_STAT_DESC"));
					// Hesap no al
					// ((List<GMMap>)sorguMap.get(kartListIntra, i, "DEBIT_ACCOUNT_LIST")).get(0).get("DEBIT_ACCOUNT_LIST", 0, "DEBIT_ACCOUNT_NO");
					hesapMap.clear();
					hesapMap.put("CARD_NO", sorguMap.getString(kartListIntra, i, "CARD_NO"));
					hesapMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_TFF_GET_DEBIT_CARD_MAIN_ACCOUNT", hesapMap));
					hesapNo = hesapMap.getString("DEBIT_ACCOUNT_NO");
					if (hesapNo != null && !"0".equals(hesapNo)) {
						oMap.put(kartList, i, "HESAP_NO", hesapNo);
					}
				}
				else {// Istenen kart tipi
					if (kartTipi.equals(sorguMap.getString(kartListIntra, i, "CARD_DCI_AKUSTIK"))) {
						oMap.put(kartList, j, "KART_NO", sorguMap.getString(kartListIntra, i, "CARD_NO"));
						oMap.put(kartList, j, "KART_TIPI", sorguMap.getString(kartListIntra, i, "CARD_DCI_AKUSTIK"));
						oMap.put(kartList, j, "URUN_KODU", sorguMap.getString(kartListIntra, i, "PRODUCT_ID"));
						oMap.put(kartList, j, "LOGO_KODU", sorguMap.getString(kartListIntra, i, "LOGO_CODE"));
						oMap.put(kartList, j, "DURUM_KODU", sorguMap.getString(kartListIntra, i, "CARD_STAT_CODE"));
						oMap.put(kartList, j, "ALT_DURUM_KODU", sorguMap.getString(kartListIntra, i, "CARD_SUB_STAT_CODE"));
						oMap.put(kartList, j, "BASVURU_NO", sorguMap.getString(kartListIntra, i, "APPLICATION_NO"));
						oMap.put(kartList, j, "KAYIT_TARIHI", sorguMap.getString(kartListIntra, i, "EMBOSS_DATE"));
						oMap.put(kartList, j, "DURUM_ACIKLAMA", sorguMap.getString(kartListIntra, i, "CARD_STAT_DESC"));
						// Hesap no al
						// ((List<GMMap>)sorguMap.get(kartListIntra, i, "DEBIT_ACCOUNT_LIST")).get(0).get("DEBIT_ACCOUNT_LIST", 0, "DEBIT_ACCOUNT_NO");
						hesapMap.clear();
						hesapMap.put("CARD_NO", sorguMap.getString(kartListIntra, i, "CARD_NO"));
						hesapMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_TFF_GET_DEBIT_CARD_MAIN_ACCOUNT", hesapMap));
						hesapNo = hesapMap.getString("DEBIT_ACCOUNT_NO");
						if (hesapNo != null && !"0".equals(hesapNo)) {
							oMap.put(kartList, j, "HESAP_NO", hesapNo);
						}
					}
				}

				/*Sanal yenilemesi yap�lan kartlar akisa dahil edilmeyeceginden eklendi*/
				if (OceanConstants.Akustik_PrepaidCard.equals(sorguMap.getString(kartListIntra, i, "CARD_DCI_AKUSTIK"))) {
					oMap.put(kartList, j, "EXT_ISSUE", sorguMap.getString(kartListIntra, i, "EXT_ISSUE"));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Musterinin intra sistemindeki gecerli Debit/Prepaid kartlari kriterlere gore listeler.<br>
	 * 
	 * @author murat.el
	 * @since 22.04.2014
	 * @param iMap
	 *            - TFF basvuru bilgileri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>TCKN - TC kimlik numarasi <li>KART_NO - Kart numarasi <li>BASVURU_NO - Basvuru numarasi <li>KART_TIPI - Kart tipi (D:Debit|P:Prepaid|A:Hepsi) <li>DURUM - Kart durumu (N:Acik)
	 * @return Kart tipi bilgisi<br>
	 *         <li>KART_LIST - Duruma uygun kart listesi(E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_INTRA_GECERLI_KART_LISTELE")
	public static GMMap intraKartListeleByDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kartMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Tum kartlarin listesini al
			sorguMap.clear();
			sorguMap.putAll(iMap);
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_KART_LISTELE", sorguMap));// KART_LIST
			// Kart listesi var mi?
			if (kartMap.getSize("KART_LIST") < 1) {
				return oMap;
			}
			// Liste icerisinde basvuru icin uygun kart var mi?
			int gecerliKartSayisi = 0;
			for (int i = 0; i < kartMap.getSize("KART_LIST"); i++) {
				// Gecerli bir kart mi
				sorguMap.clear();
				sorguMap.put("KOD", "KART_GECERSIZ_DURUM_KOD");
				sorguMap.put("KEY", kartMap.getString("KART_LIST", i, "DURUM_KODU"));
				sorguMap.put("KEY2", kartMap.getString("KART_LIST", i, "ALT_DURUM_KODU"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
				// Kontrol, gecersizse sonraki karta gec.
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
					continue;
				}
				// Gecerli ise al
				oMap.put("KART_LIST", gecerliKartSayisi++, kartMap.getMap("KART_LIST", i));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * TFF basvurusuna ait kart numarasini verilen basvuru bilgileri ile INTRA sisteminden alir<br>
	 * 
	 * @author murat.el
	 * @since PY-8847
	 * @param iMap
	 *            - Basvuru bilgileri<br>
	 *            <li>BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Kart bilgileri<br>
	 *         <li>KART_NO - Kart numarasi
	 */
	@GraymoundService("BNSPR_INTRA_GET_KART_NO_BY_BASVURU_NO")
	public static GMMap getIntraCardInfoByBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kartMap = new GMMap();
		GMMap sorguMap = new GMMap();
		String kartNo = StringUtils.EMPTY;
		String durumKodu = StringUtils.EMPTY;
		String altDurumKodu = StringUtils.EMPTY;
		String durumAciklama = StringUtils.EMPTY;

		try {
			// Tff basvurusunu al, yoksa cik.
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("KART_NO", kartNo);
				oMap.put("DURUM_KODU", durumKodu);
				oMap.put("ALT_DURUM_KODU", altDurumKodu);
				oMap.put("DURUM_ACIKLAMA", durumAciklama);
				return oMap;
			}
			// basvurudan kart bilgilerini al.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			sorguMap.put("TCKN", tffBasvuru.getTcKimlikNo());
			sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
			sorguMap.put("DURUM", "A");// Hepsi
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_GECERLI_KART_LISTELE", sorguMap));// KART_LIST
			// Kart listesi var mi?
			if (kartMap.getSize("KART_LIST") < 1) {
				oMap.put("KART_NO", kartNo);
				oMap.put("DURUM_KODU", durumKodu);
				oMap.put("ALT_DURUM_KODU", altDurumKodu);
				oMap.put("DURUM_ACIKLAMA", durumAciklama);
				return oMap;
			}
			// Liste icerisinde basvuru icin uygun kart var mi?
			for (int i = 0; i < kartMap.getSize("KART_LIST"); i++) {
				// Debit ise gecerli bir kart olmasi gerekmekte
				if (TFF_DEBIT_KARTI.equals(tffBasvuru.getKartTipi())) {
					kartNo = kartMap.getString("KART_LIST", i, "KART_NO");
					durumKodu = kartMap.getString("KART_LIST", i, "DURUM_KODU");
					altDurumKodu = kartMap.getString("KART_LIST", i, "ALT_DURUM_KODU");
					durumAciklama = kartMap.getString("KART_LIST", i, "DURUM_ACIKLAMA");
					break;
				}
				else if (TFF_PREPAID_KARTI.equals(tffBasvuru.getKartTipi())) {
					Object[] parameters = new Object[6];
					parameters[0] = BnsprType.STRING;
					parameters[1] = kartMap.getString("KART_LIST", i, "URUN_KODU");
					parameters[2] = BnsprType.STRING;
					parameters[3] = kartMap.getString("KART_LIST", i, "LOGO_KODU");
					parameters[4] = BnsprType.STRING;
					parameters[5] = TFF_PREPAID_KARTI;

					String func = "{? = call pkg_trn3801.get_takim_kodu(?,?,?)}";
					String urunSahipKodu = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, parameters));

					func = "{? = call pkg_trn3801.get_urun_kodu(?,?,?)}";
					String urunKodu = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, parameters));

					// Urun ayni ise kart bulundu
					if (tffBasvuru.getUrunSahipKodu().equals(urunSahipKodu) && tffBasvuru.getUrun().equals(urunKodu)) {
						kartNo = kartMap.getString("KART_LIST", i, "KART_NO");
						durumKodu = kartMap.getString("KART_LIST", i, "DURUM_KODU");
						altDurumKodu = kartMap.getString("KART_LIST", i, "ALT_DURUM_KODU");
						durumAciklama = kartMap.getString("KART_LIST", i, "DURUM_ACIKLAMA");
						break;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_NO", kartNo);
		oMap.put("DURUM_KODU", durumKodu);
		oMap.put("ALT_DURUM_KODU", altDurumKodu);
		oMap.put("DURUM_ACIKLAMA", durumAciklama);
		return oMap;
	}

	// ---------------------------------------------------------------------
	// ******************************************************* OCEAN - GET CARD INFO
	// ---------------------------------------------------------------------
	/**
	 * Musterinin verilen kart tipinde acik/kullandigi karti var mi kontrolunu gerceklestirir.<br>
	 * 
	 * @author murat.el
	 * @since PY-8847
	 * @param iMap
	 *            - TFF basvuru bilgileri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>TCKN - TC kimlik numarasi <li>KART_NO - Kart numarasi <li>BASVURU_NO - Basvuru numarasi <li>KART_TIPI - Kart tipi (C:Kredi Karti|A:Hepsi) <li>DURUM - Kart durumu (N:Acik|A:Hepsi)
	 * @return Kart tipi bilgisi<br>
	 *         <li>KART_LIST - Duruma uygun kart listesi(E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_OCEAN_KART_LISTELE")
	public static GMMap oceanKartListele(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartList = "KART_LIST";
		String kartListOcean = "CARD_DETAIL_INFO";
		String kartDurum = CreditCardServicesUtil.nvl(iMap.getString("DURUM"), "A");
		String kartTipi = CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), "C");

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("CUSTOMER_NO", CreditCardServicesUtil.nvl(iMap.getString("MUSTERI_NO"), StringUtils.EMPTY));
			sorguMap.put("TCKN", CreditCardServicesUtil.nvl(iMap.getString("TCKN"), StringUtils.EMPTY));
			sorguMap.put("CARD_NO", CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), StringUtils.EMPTY));
			sorguMap.put("APPLICATION_NO", CreditCardServicesUtil.nvl(iMap.getString("BASVURU_NO"), StringUtils.EMPTY));
			sorguMap.put("CARD_DCI", kartTipi);
			sorguMap.put("CARD_BANK_STATUS", kartDurum);
			sorguMap.put("NO_NEED_INTRACARDS_CARDS", true); /*YKP i�in intra kartlar� getirmesin*/
			sorguMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", sorguMap);
			// Kart listesi var mi?
			if (sorguMap == null || sorguMap.isEmpty() || sorguMap.getSize(kartListOcean) < 1) {
				return oMap;
			}

			// Kart listesinde karti bul
			for (int i = 0, j = 0; i < sorguMap.getSize(kartListOcean); i++) {
				// Listeden istenen kart tipi var mi?
				if ("A".equals(kartTipi)) {// Hepsi
					oMap.put(kartList, i, "KART_NO", sorguMap.getString(kartListOcean, i, "CARD_NO"));
					oMap.put(kartList, i, "KART_TIPI", sorguMap.getString(kartListOcean, i, "CARD_DCI_AKUSTIK"));
					oMap.put(kartList, i, "DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_STAT_CODE"));
					oMap.put(kartList, i, "ALT_DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_SUB_STAT_CODE"));
					oMap.put(kartList, i, "BASVURU_NO", sorguMap.getString(kartListOcean, i, "APPLICATION_NO"));
					oMap.put(kartList, i, "KAYIT_TARIHI", sorguMap.getString(kartListOcean, i, "EMBOSS_DATE"));
					oMap.put(kartList, i, "DURUM_ACIKLAMA", sorguMap.getString(kartListOcean, i, "CARD_STAT_DESC"));
					oMap.put(kartList, i, "PRODUCT_ID", sorguMap.getString(kartListOcean, i, "PRODUCT_ID"));
				}
				else {// Istenen kart tipi
					if (kartTipi.equals(sorguMap.getString(kartListOcean, i, "CARD_DCI_AKUSTIK"))) {
						oMap.put(kartList, j, "KART_NO", sorguMap.getString(kartListOcean, i, "CARD_NO"));
						oMap.put(kartList, j, "KART_TIPI", sorguMap.getString(kartListOcean, i, "CARD_DCI_AKUSTIK"));
						oMap.put(kartList, j, "DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_STAT_CODE"));
						oMap.put(kartList, j, "ALT_DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_SUB_STAT_CODE"));
						oMap.put(kartList, j, "BASVURU_NO", sorguMap.getString(kartListOcean, i, "APPLICATION_NO"));
						oMap.put(kartList, j, "KAYIT_TARIHI", sorguMap.getString(kartListOcean, i, "EMBOSS_DATE"));
						oMap.put(kartList, j, "DURUM_ACIKLAMA", sorguMap.getString(kartListOcean, i, "CARD_STAT_DESC"));
						oMap.put(kartList, i, "PRODUCT_ID", sorguMap.getString(kartListOcean, i, "PRODUCT_ID"));
						j++;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * KK basvurusuna ait kart numarasini OCEAN sisteminden alir<br>
	 * 
	 * @author murat.el
	 * @since PY-8847
	 * @param iMap
	 *            - Basvuru bilgileri<br>
	 *            <li>BASVURU_NO - Kk basvuru numarasi
	 * @return oMap - Kart bilgileri<br>
	 *         <li>KART_NO - Kart numarasi
	 */
	@GraymoundService("BNSPR_OCEAN_GET_KART_NO_BY_BASVURU_NO")
	public static GMMap getOceanCardInfoByBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kartMap = new GMMap();
		GMMap sorguMap = new GMMap();
		String kartNo = StringUtils.EMPTY;
		String durumKodu = StringUtils.EMPTY;
		String altDurumKodu = StringUtils.EMPTY;
		String durumAciklama = StringUtils.EMPTY;

		try {
			// Tff basvurusunu al, yoksa cik.
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (kkBasvuru == null) {
				oMap.put("KART_NO", kartNo);
				oMap.put("DURUM_KODU", durumKodu);
				oMap.put("ALT_DURUM_KODU", altDurumKodu);
				oMap.put("DURUM_ACIKLAMA", durumAciklama);
				return oMap;
			}
			// basvurudan kart bilgilerini al.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
			sorguMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
			sorguMap.put("DURUM", "A");// Hepsi
			if (kkBasvuru.getKartTipi() == null || TFF_KREDI_KARTI.equals(kkBasvuru.getKartTipi())) {
				sorguMap.put("KART_TIPI", "C");
			}
			else if (TFF_DEBIT_KARTI.equals(kkBasvuru.getKartTipi())) {
				sorguMap.put("KART_TIPI", "D");
			}
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_KART_LISTELE", sorguMap));// KART_LIST
			// Kart listesi var mi?
			if (kartMap.getSize("KART_LIST") < 1) {
				oMap.put("KART_NO", kartNo);
				oMap.put("DURUM_KODU", durumKodu);
				oMap.put("ALT_DURUM_KODU", altDurumKodu);
				oMap.put("DURUM_ACIKLAMA", durumAciklama);
				return oMap;
			}
			// Liste icerisinde basvuru icin uygun kart var mi?
			for (int i = 0; i < kartMap.getSize("KART_LIST"); i++) {
				// Gecerli bir kart mi
				sorguMap.clear();
				sorguMap.put("KOD", "KART_GECERSIZ_DURUM_KOD");
				sorguMap.put("KEY", kartMap.getString("KART_LIST", i, "DURUM_KODU"));
				sorguMap.put("KEY2", kartMap.getString("KART_LIST", i, "ALT_DURUM_KODU"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
				// Kontrol, gecersizse sonraki karta gec.
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
					continue;
				}
				else {
					kartNo = kartMap.getString("KART_LIST", i, "KART_NO");
					durumKodu = kartMap.getString("KART_LIST", i, "DURUM_KODU");
					altDurumKodu = kartMap.getString("KART_LIST", i, "ALT_DURUM_KODU");
					durumAciklama = kartMap.getString("KART_LIST", i, "DURUM_ACIKLAMA");
					break;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_NO", kartNo);
		oMap.put("DURUM_KODU", durumKodu);
		oMap.put("ALT_DURUM_KODU", altDurumKodu);
		oMap.put("DURUM_ACIKLAMA", durumAciklama);
		return oMap;
	}

	/**
	 * Musterinin verilen ocean sistemindeki bilgilerini alir.<br>
	 * 
	 * @author murat.el
	 * @since TY-4964
	 * @param iMap
	 *            - Musteri sorgulama bilgileri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>TCKN - TC kimlik numarasi
	 * @return Musteri bilgileri<br>
	 *         <li>MUSTERI_LIMIT - Musteri limiti <li>MUSTERI_GRUP - Musterinin bagli oldugu grup <li>MUSTERI_TIP - Musteri tipi
	 */
	@GraymoundService("BNSPR_OCEAN_GET_MUSTERI_BILGI")
	public static GMMap gettOceanMusteriBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Musteri bilgisini kart sisteminden al
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CUSTOMER_INFO", sorguMap));

			// Musteri var mi?
			String iTableName = "CUSTOMER_INFO_LIST";
			if (sorguMap.getSize(iTableName) == 0) {
				return oMap;
			}

			// Musteri bilgilerini al
			for (int i = 0; i < sorguMap.getSize(iTableName); i++) {
				String customerLimit = sorguMap.getString(iTableName, i, "CUSTOMER_LIMIT");
				if (StringUtils.isNotBlank(customerLimit)) {
					customerLimit = customerLimit.replace(",", ".");
				}

				oMap.put("MUSTERI_LIMIT", customerLimit);
				oMap.put("MUSTERI_GRUP", sorguMap.get(iTableName, i, "CUSTOMER_GROUP"));
				oMap.put("MUSTERI_TIP", sorguMap.get(iTableName, i, "CUSTOMER_TYPE"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_OCEAN_KART_LISTELE_PP")
	public static GMMap oceanKartListelePp(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartList = "KART_LIST";
		String kartListOcean = "CARD_DETAIL_INFO";
		String kartDurum = CreditCardServicesUtil.nvl(iMap.getString("DURUM"), "A");
		String kartTipi = CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), "C");
		int count = 0;

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("CUSTOMER_NO", CreditCardServicesUtil.nvl(iMap.getString("MUSTERI_NO"), StringUtils.EMPTY));
			sorguMap.put("TCKN", CreditCardServicesUtil.nvl(iMap.getString("TCKN"), StringUtils.EMPTY));
			sorguMap.put("CARD_NO", CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), StringUtils.EMPTY));
			sorguMap.put("APPLICATION_NO", CreditCardServicesUtil.nvl(iMap.getString("BASVURU_NO"), StringUtils.EMPTY));
			sorguMap.put("CARD_DCI", kartTipi);
			sorguMap.put("CARD_BANK_STATUS", kartDurum);
			sorguMap.put("NO_NEED_INTRACARDS_CARDS", true); /*YKP i�in intra kartlar� getirmesin*/
			sorguMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", sorguMap);
			// Kart listesi var mi?
			if (sorguMap == null || sorguMap.isEmpty() || sorguMap.getSize(kartListOcean) < 1) {
				return oMap;
			}

			count = sorguMap.getSize(kartListOcean);
			if (count == 2) {
				if (sorguMap.getString(kartListOcean, 0, "APPLICATION_NO").compareTo(sorguMap.getString(kartListOcean, 1, "APPLICATION_NO")) > 0) {
					for (int i = 0; i < sorguMap.getSize(kartListOcean); i++) {

						oMap.put(kartList, i, "KART_NO", sorguMap.getString(kartListOcean, i, "CARD_NO"));
						oMap.put(kartList, i, "KART_TIPI", sorguMap.getString(kartListOcean, i, "CARD_DCI_AKUSTIK"));
						oMap.put(kartList, i, "DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_STAT_CODE"));
						oMap.put(kartList, i, "ALT_DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_SUB_STAT_CODE"));
						oMap.put(kartList, i, "BASVURU_NO", sorguMap.getString(kartListOcean, i, "APPLICATION_NO"));
						oMap.put(kartList, i, "KAYIT_TARIHI", sorguMap.getString(kartListOcean, i, "EMBOSS_DATE"));
						oMap.put(kartList, i, "DURUM_ACIKLAMA", sorguMap.getString(kartListOcean, i, "CARD_STAT_DESC"));
						oMap.put(kartList, i, "PRODUCT_ID", sorguMap.getString(kartListOcean, i, "PRODUCT_ID"));
					}
				}
				else {
					for (int i = 0, j = 1; i < sorguMap.getSize(kartListOcean); i++, j--) {

						oMap.put(kartList, i, "KART_NO", sorguMap.getString(kartListOcean, j, "CARD_NO"));
						oMap.put(kartList, i, "KART_TIPI", sorguMap.getString(kartListOcean, j, "CARD_DCI_AKUSTIK"));
						oMap.put(kartList, i, "DURUM_KODU", sorguMap.getString(kartListOcean, j, "CARD_STAT_CODE"));
						oMap.put(kartList, i, "ALT_DURUM_KODU", sorguMap.getString(kartListOcean, j, "CARD_SUB_STAT_CODE"));
						oMap.put(kartList, i, "BASVURU_NO", sorguMap.getString(kartListOcean, j, "APPLICATION_NO"));
						oMap.put(kartList, i, "KAYIT_TARIHI", sorguMap.getString(kartListOcean, j, "EMBOSS_DATE"));
						oMap.put(kartList, i, "DURUM_ACIKLAMA", sorguMap.getString(kartListOcean, j, "CARD_STAT_DESC"));
						oMap.put(kartList, i, "PRODUCT_ID", sorguMap.getString(kartListOcean, j, "PRODUCT_ID"));
					}

				}
			}
			else {
				for (int i = 0; i < sorguMap.getSize(kartListOcean); i++) {

					oMap.put(kartList, i, "KART_NO", sorguMap.getString(kartListOcean, i, "CARD_NO"));
					oMap.put(kartList, i, "KART_TIPI", sorguMap.getString(kartListOcean, i, "CARD_DCI_AKUSTIK"));
					oMap.put(kartList, i, "DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_STAT_CODE"));
					oMap.put(kartList, i, "ALT_DURUM_KODU", sorguMap.getString(kartListOcean, i, "CARD_SUB_STAT_CODE"));
					oMap.put(kartList, i, "BASVURU_NO", sorguMap.getString(kartListOcean, i, "APPLICATION_NO"));
					oMap.put(kartList, i, "KAYIT_TARIHI", sorguMap.getString(kartListOcean, i, "EMBOSS_DATE"));
					oMap.put(kartList, i, "DURUM_ACIKLAMA", sorguMap.getString(kartListOcean, i, "CARD_STAT_DESC"));
					oMap.put(kartList, i, "PRODUCT_ID", sorguMap.getString(kartListOcean, i, "PRODUCT_ID"));
				}

			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_KART_YENILEME_UCRETLERI")
	public static GMMap kartYenilemeUcretleri(GMMap iMap) {

		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		oMap.put("KART_BEDELI", BigDecimal.ZERO);
		oMap.put("VIZE_BEDELI", BigDecimal.ZERO);
		oMap.put("LOYALTY_BEDELI", BigDecimal.ZERO);

		try {
			// kartin tipi ogrenilir
			GMMap cardProperty = new GMMap();
			GMMap cardInfo = new GMMap();
			cardProperty.put("CARD_NO", iMap.getString("KART_NO"));
			cardProperty.putAll(GMServiceExecuter.execute("BNSPR_GET_CARD_PROPERTIES", cardProperty));// KART_BILGILERI

			if (cardProperty.getString("RETURN_CODE").equals("0")) {
				String dest = cardProperty.getString("DESTINATION");
				cardProperty.put("CARD_DCI", cardProperty.getString("DCI"));
				// kart tipini bul
				if ("O".equals(dest)) {
					cardInfo.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardProperty));
				}
				else if ("I".equals(dest)) {
					cardInfo.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardProperty));
				}
				for (int i = 0; i < cardInfo.getSize("CARD_DETAIL_INFO"); i++) {
					if (StringUtils.isNotBlank(cardInfo.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID"))) {

						String productID = null;
						productID = cardInfo.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");

						conn = DALUtil.getGMConnection();

						query = "{call PKG_TFF_BASVURU.Kart_Yenileme_Ucretleri(?,?,?,?,?)}";
						stmt = conn.prepareCall(query);
						stmt.setString(1, iMap.getString("KART_NO"));
						stmt.setString(2, productID);
						stmt.registerOutParameter(3, Types.FLOAT);
						stmt.registerOutParameter(4, Types.FLOAT);
						stmt.registerOutParameter(5, Types.FLOAT);

						stmt.execute();

						oMap.put("KART_BEDELI", stmt.getBigDecimal(3));
						oMap.put("VIZE_BEDELI", stmt.getBigDecimal(4));
						oMap.put("LOYALTY_BEDELI", stmt.getBigDecimal(5));
						oMap.put("URUN_ID", productID);
					}
				}
			}

			oMap.putAll(GMServiceExecuter.execute("BNSPR_KART_YENILEME_TESLIMAT_UCRETLERI", new GMMap()));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "Islem Basarili");
		return oMap;
	}

	@GraymoundService("BNSPR_KART_YENILEME_TESLIMAT_UCRETLERI")
	public static GMMap getKartYenilemeeslimatUcretleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Yenileme_Teslimat_Ucretleri}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "TESLIMAT_UCRETLERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * 
	 * @request
	 *          CARD_NO,APPLICATION_NO
	 *          ADDRESS_CITY,ADDRESS_TOWN,ADDRESS1
	 *          CARD_DELIVERY_TYPE,ADDRESS_CITY_CODE,BRANCH_CODE,
	 *          ADDRESS_COUNTRY,ADDRESS_ZIP_CODE,ADDRESS_TOWN_CODE
	 *          CARD_POST_IDX,SOURCE_CODE
	 * 
	 * 
	 * @return
	 *         ERROR_DETAIL
	 *         NEW_CARD_NO
	 *         NEW_EXPIRY_DATE
	 *         RETURN_CODE -> 2 Ba�ar�l�
	 *         RETURN_DESCRIPTION
	 */
	@GraymoundService("BNSPR_INTRACARD_VADE_YENILEME")
	public static GMMap renewCardExpiryDate(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();

		GMMap dysMap = new GMMap();
		GMMap cardMap = new GMMap();
		GMMap deliveryMap = new GMMap();
		GMMap renewalMap = new GMMap();
		GMMap embossMap = new GMMap();
		GMMap izKaydiMap = new GMMap();
		String cardNo = "";
		BigDecimal customerNo = BigDecimal.ZERO;
		izKaydiMap.putAll(iMap);
		boolean isVisaUpdated = false;
		boolean isVisaUpToDate = false;

		oMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);

		// getcardInfo
		// mobil basvuruNo ile geliyor, basvuru �zerindeki son cardNoyu �ekelim
		Session session = DAOSession.getSession("BNSPRDal");
		TffBasvuru kaynakBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal(APPLICATION_NO));

		cardMap.put(CUSTOMER_NO, kaynakBasvuru.getMusteriNo());
		cardMap.put(APPLICATION_NO, iMap.getBigDecimal(APPLICATION_NO));
		cardMap.put(CARD_BANK_STATUS, OceanConstants.Card_Bank_Status_Open);

		// �nceki ba�vuru �zerindeki son kart numaras�n� alal�m
		cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardMap);

		isVisaUpToDate = YES_FLAG.equals(cardMap.getString(CARD_DETAIL_INFO, 0, VISA_STAT));

		if (!iMap.containsKey(CARD_NO) || StringUtils.isEmpty(iMap.getString(CARD_NO))) {
			cardNo = cardMap.getString(CARD_DETAIL_INFO, 0, CARD_NO);
		}
		else
			cardNo = iMap.getString(CARD_NO);

		if (!iMap.containsKey(CUSTOMER_NO) || StringUtils.isEmpty(iMap.getString(CUSTOMER_NO))) {
			customerNo = kaynakBasvuru.getMusteriNo();
		}
		else
			customerNo = iMap.getBigDecimal(CUSTOMER_NO);

		BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
		GMMap visaMap = new GMMap();
		GMMap pMap = new GMMap();
		pMap.put(DESTINATION, OceanConstants.Card_Source_Intracard);

		// skt ek talep: vizesi g�ncel de�ilse (visa_stat N ise vizeleme yap�ls�n)
		if (!isVisaUpToDate) {
			// updateVisa
			visaMap.put(CARD_NO, cardNo);
			visaMap.put(CUSTOMER_NO, customerNo);
			visaMap.put(VISA_FEE_PAYMENT_TYPE, VISA_FEE_PAYMENT_TYPE_VD);
			visaMap.put(VISA_FEE_TXN_TYPE, OceanConstants.Request_Normal);
			visaMap.put(CHANNEL_TX_NO, trxNo);

			CreditCardServicesUtil.getRequiredField(visaMap, CHANNEL_TX_NO, izKaydiMap, "VISA_TX_NO");

			try {
				visaMap.putAll(cardVisaUpdate(visaMap, pMap)); // kesici

				if (!OceanConstants.Ocean_Return_Success.equals(visaMap.getString(RETURN_CODE))) {

					izKaydiMap.put("VISA_STATUS", VadeYenilemeDurum.NOT_OK.getValue());
					CreditCardServicesUtil.getRequiredField(visaMap, RETURN_CODE, izKaydiMap, ERROR_CODE);
					CreditCardServicesUtil.getRequiredField(visaMap, RETURN_DESCRIPTION, izKaydiMap, ERROR_DESC);
					izKaydiMap.put("ERROR_STEP", "VISA_UPDATE");
					vadeYenilemeIzKaydiYarat(izKaydiMap);

					oMap.put(RESPONSE, visaMap.getString(RETURN_CODE));
					oMap.put(RESPONSE_DATA, visaMap.getString(RETURN_DESCRIPTION));
					return oMap;
				}
				else {
					isVisaUpdated = true;
					izKaydiMap.put("VISA_STATUS", VadeYenilemeDurum.OK.getValue());
				}
			}
			catch (Exception e) {
				izKaydiMap.put("VISA_STATUS", VadeYenilemeDurum.NOT_OK.getValue());
				izKaydiMap.put(ERROR_CODE, AkustikConstants.RESPONSE_FAIL);
				izKaydiMap.put(ERROR_DESC, e.toString());
				izKaydiMap.put("ERROR_STEP", "VISA_UPDATE");
				vadeYenilemeIzKaydiYarat(izKaydiMap);

				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
				return oMap;
			}
		}
		else {
			izKaydiMap.put("VISA_STATUS", VadeYenilemeDurum.ALREADY_HAVE.getValue());// vizesi g�ncel oldu�u i�in vizeleme yap�lmad�ysa farkl� kodla belirtelim (-2)
		}

		// m��teri adres g�ncelleme
		GMMap addressMap = new GMMap();
		addressMap.put("MUSTERI_NO", customerNo);
		addressMap.put("IL_KOD", iMap.getString(ADDRESS_CITY_CODE));
		addressMap.put("POSTA_KOD", iMap.getString(ADDRESS_ZIP_CODE));
		addressMap.put("ADRES_KOD", "W");// W teslimat adres kodu
		addressMap.put("ULKE_KOD", iMap.getString(ADDRESS_COUNTRY));
		addressMap.put("EXTRE_ADRES_KOD_F", true);
		addressMap.put("ADRES", iMap.getString(ADDRESS1));
		addressMap.put("ILCE_KOD", iMap.getString(ADDRESS_TOWN_CODE));

		addressMap.put("TRX_NO", trxNo); // async olacak
		GMServiceExecuter.executeAsync("BNSPR_TRN10061_SAVE", addressMap);// asynch

		// dysInfo
		dysMap.put("BASVURU_NO", iMap.getString(APPLICATION_NO));
		dysMap.putAll(GMServiceExecuter.call("BNSPR_TFF_DAGITIM_KOD", dysMap));
		CreditCardServicesUtil.getRequiredField(dysMap, "DAGITIM_KOD", izKaydiMap, "DYS_INFO");

		// updateCardDelivery
		// 1:Ev,2:��,3:Di�er
		String cardPostIdx = KART_TESLIMAT_ADRES_KODU;
		/*bankac�l���na W koduyla at�ld���ndan kart paketine de kar��l��� olan di�er at�l�yor hardcoded)*/
		// ""E".equals(iMap.getString(CARD_POST_IDX))? BigDecimal.ONE : ("I".equals(iMap.getString(CARD_POST_IDX))? new BigDecimal(2) : new BigDecimal(3));

		deliveryMap.put(BRANCH_CODE, iMap.getString(BRANCH_CODE, ""));
		deliveryMap.put(CARD_DELIVERY_TYPE, iMap.getString(CARD_DELIVERY_TYPE, CARD_DELIVERY_TYPE_POST));
		deliveryMap.put(CARD_NO, cardNo);
		deliveryMap.put(CARD_POST_IDX, cardPostIdx);
		deliveryMap.put("ADDRESS_TOWN", iMap.getString("ADDRESS_TOWN", ""));
		CreditCardServicesUtil.getRequiredField(iMap, ADDRESS_CITY, deliveryMap, ADDRESS_CITY);
		CreditCardServicesUtil.getRequiredField(iMap, ADDRESS_CITY_CODE, deliveryMap, ADDRESS_CITY_CODE);
		CreditCardServicesUtil.getRequiredField(iMap, ADDRESS_COUNTRY, deliveryMap, ADDRESS_COUNTRY);
		CreditCardServicesUtil.getRequiredField(iMap, ADDRESS_TOWN_CODE, deliveryMap, ADDRESS_TOWN_CODE);
		CreditCardServicesUtil.getRequiredField(iMap, ADDRESS1, deliveryMap, ADDRESS1);

		deliveryMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_UPDATE_CARD_DEIVERY_INFO", deliveryMap));

		// cardRenewal
		// exp date bitimine 2 ay kalm��sa extend et
		String expiryDate = cardMap.getString(CARD_DETAIL_INFO, 0, EXPIRY_DATE);

		renewalMap.put(CARD_NO, cardNo);
		renewalMap.put(EMBOSS_CODE, EMBOSS_CODE_VD);
		renewalMap.put(DYS_INFO, dysMap.getString("DAGITIM_KOD"));
		renewalMap.put(EXTEND_EXPIRY, isExpiryDateCloserForNewApplicationSKT(expiryDate) ? "Y" : "N");

		oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_CARD_RENEWAL", renewalMap)); // kesici

		if (!OceanConstants.Ocean_Return_Success.equals(oMap.getString(RETURN_CODE))) {
			// reversal
			if (isVisaUpdated) {
				visaMap.put("VISA_FEE_TXN_TYPE", OceanConstants.Request_Cancel);
				visaMap.putAll(cardVisaUpdate(visaMap, pMap));

				if (!OceanConstants.Ocean_Return_Success.equals(visaMap.getString(RETURN_CODE))) {

					izKaydiMap.put("VISA_STATUS", VadeYenilemeDurum.OK.getValue());
					CreditCardServicesUtil.getRequiredField(visaMap, RETURN_CODE, izKaydiMap, ERROR_CODE);
					CreditCardServicesUtil.getRequiredField(visaMap, RETURN_DESCRIPTION, izKaydiMap, ERROR_DESC);
					izKaydiMap.put("ERROR_STEP", "VISA_UPDATE_CANCEL");
					CreditCardServicesUtil.getRequiredField(visaMap, RETURN_DESCRIPTION, izKaydiMap, ERROR_DESC);

					vadeYenilemeIzKaydiYarat(izKaydiMap);
					oMap.put(RESPONSE, visaMap.getString(RETURN_CODE));
					oMap.put(RESPONSE_DATA, visaMap.getString(RETURN_DESCRIPTION));
					return oMap;
				}

				izKaydiMap.put("VISA_STATUS", VadeYenilemeDurum.ERROR.getValue()); // vizeleme yap�lamad�

			}

			izKaydiMap.put("RENEWAL_STATUS", VadeYenilemeDurum.NOT_OK.getValue());
			CreditCardServicesUtil.getRequiredField(oMap, RETURN_CODE, izKaydiMap, ERROR_CODE);
			CreditCardServicesUtil.getRequiredField(oMap, RETURN_DESCRIPTION, izKaydiMap, ERROR_DESC);
			izKaydiMap.put("ERROR_STEP", "CARD_RENEWAL");
			vadeYenilemeIzKaydiYarat(izKaydiMap);

			oMap.put(RESPONSE, oMap.getString(RETURN_CODE));
			oMap.put(RESPONSE_DATA, oMap.getString(RETURN_DESCRIPTION));
			return oMap;
		}
		else {
			izKaydiMap.put("RENEWAL_STATUS", VadeYenilemeDurum.OK.getValue());
		}

		// updateEmbossRequest
		embossMap.put(CARD_NO, cardNo);
		embossMap.put("EXT_CARD_NO", cardNo);
		embossMap.put("EXT_DATE", cardMap.getString(CARD_DETAIL_INFO, 0, EXPIRY_DATE));
		embossMap.put("TYPE", EMBOSS_CODE_TYPE);
		embossMap.put("EXT_CHANNEL", iMap.getString("SOURCE_CODE"));

		// i� kesici olmad��� i�in async �a��r�ld�
		GMServiceExecuter.executeAsync("BNSPR_INTRACARD_UPDATE_CARD_EMBOSS", embossMap); // async


		try {
			/* vade yenileme yap�lan ba�vurunun 120 g�n� a�k�n s�redir gelmemi� belgesi varsa tekrar ��k�yoruz, tekrar ��kt���m�z belgelerin rec_owner,rec_date ini g�ncelliyoruz ki
			 bir dahaki sorguda tekrar ��k�lmas�n, tff_basvuru_belge tablosunda kay�t yoksa bekleme kayd� at�yoruz*/
			updateDysInfo(iMap.getBigDecimal(APPLICATION_NO), dysMap.getString("DAGITIM_KOD"));
			
			// vade yenilendi�i i�in ba�vuru tablosundaki vd_basvuru alan� g�ncellenir
			kaynakBasvuru.setVdBasvuruNo(kaynakBasvuru.getBasvuruNo());
			session.saveOrUpdate(kaynakBasvuru);
			session.flush();
		}
		catch (Exception e) {
			izKaydiMap.put("ERROR_STEP", "UPDATE_VD_BASVURU");
			vadeYenilemeIzKaydiYarat(izKaydiMap);

			throw ExceptionHandler.convertException(e);
		}
		izKaydiMap.put("STATUS", VadeYenilemeDurum.OK.getValue());
		vadeYenilemeIzKaydiYarat(izKaydiMap);

		return oMap;
	}

	/**
	 * Vade yenileme yap�lan eski kart �zerindeki kalan vizesini yeni karta aktar�r�r
	 * 
	 * @request
	 *          KART_NO,VD_BASVURU_NO
	 * 
	 * @return
	 *         OCEAN_RESULT,RETURN_CODE,RETURN_DESCRIPTION,ERROR_DETAIL,
	 *         CARD_DCI,LOYALTY_AMOUNT,TEAM_CODE,VISA_AMOUNT,LOYALTY_BANK_AMOUNT
	 */
	@GraymoundService("BNSPR_SKT_ESKI_KART_VADESINI_EKLE")
	public static GMMap addRemainingVisaToNewCard(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		oMap.put(RESPONSE, OceanConstants.Ocean_Return_Success);

		GMMap visaMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			TffBasvuru kaynakBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("vdBasvuruNo", iMap.getBigDecimal("VD_BASVURU_NO"))).uniqueResult();

			if (kaynakBasvuru != null) {
				GMMap pMap = getCardProperties(iMap.getString("KART_NO"));
				GMMap infoMap = new GMMap();
				infoMap.put("CARD_NO", kaynakBasvuru.getKartNo());
				infoMap.put("CUSTOMER_NO", kaynakBasvuru.getMusteriNo());
				infoMap.put("TCKN", kaynakBasvuru.getTcKimlikNo());

				if (OceanConstants.Card_Source_Intracard.equals(pMap.getString("DESTINATION"))) {

					infoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", infoMap);

				}
				else {
					infoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", infoMap);
				}

				// Vade yenileme yap�lan ba�vurusunun kalan vizesi varsa o vize tarihi �zerinden 1 sene olacak �ekilde yeni kart� vizelenssin
				if (YES_FLAG.equals(infoMap.getString(CARD_DETAIL_INFO, 0, "VISA_STAT"))) {

					visaMap.put("CARD_NO", iMap.getString("KART_NO"));
					visaMap.put("VISA_FEE_TXN_TYPE", OceanConstants.Request_Normal);
					BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"); // async olacak
					visaMap.put("CHANNEL_TX_NO", trxNo);
					visaMap.put("VISA_FEE_PAYMENT_TYPE", VISA_FEE_PAYMENT_TYPE_VD);
					String visaEndDate = "";
					Calendar calVisa = Calendar.getInstance();
					try {
						calVisa.setTime(new SimpleDateFormat("yyyyMMdd").parse(infoMap.getString(CARD_DETAIL_INFO, 0, "VISA_END_DATE")));
						calVisa.add(Calendar.YEAR, 1);
						visaEndDate = new SimpleDateFormat("yyyyMMdd").format(calVisa.getTime());
					}
					catch (ParseException e) {
						oMap.put(RESPONSE, OceanConstants.Result_Akustik_Error);
						oMap.put(RESPONSE_DATA, TffServicesMessages.GECERSIZ_TARIH);
						return oMap;
					}

					visaMap.put("VISA_END_DATE", visaEndDate);
					oMap.putAll(cardVisaUpdate(visaMap, pMap));
				}

			}
			else {
				oMap.put(RESPONSE_DATA, "Kaynak basvuru bulunamadi " + iMap.getBigDecimal("VD_BASVURU_NO"));
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return oMap;
	}

	private static GMMap cardVisaUpdate(GMMap iMap, GMMap pMap) {
		GMMap oMap = new GMMap();

		if (OceanConstants.Card_Source_Ocean.equals(pMap.getString("DESTINATION"))) {

			oMap = GMServiceExecuter.call("BNSPR_OCEAN_VISA_FLAG_UPDATE", iMap);

		}
		else if (OceanConstants.Card_Source_Intracard.equals(pMap.getString("DESTINATION"))) {

			oMap = GMServiceExecuter.call("BNSPR_INTRACARD_VISA_FLAG_UPDATE", iMap);

		}

		return oMap;

	}

	public static GMMap getCardPropertiesFromBIN(String kartNo) {
		GMMap iMap2 = new GMMap();
		iMap2.put("CARD_NO", kartNo);
		GMMap cardProperty = new GMMap();
		cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap2);
		return cardProperty;
	}

	public static GMMap getCardProperties(String cardNo) {
		GMMap pMap = getCardPropertiesFromBIN(cardNo);

		if (!pMap.getString("RETURN_CODE").equals("0")) {
			throw new GMRuntimeException(44611, "Tan�ms�z BIN.");
		}

		return pMap;
	}

	private static boolean isExpiryDateCloserForNewApplicationSKT(String expiryDate) {

		String date = CreditCardServicesUtil.convertStringToDate(new Date(), "yyyyMM");
		return Integer.parseInt(expiryDate) <= (Integer.parseInt(date) + Integer.parseInt(CreditCardServicesUtil.getGlobalParam("KART_YENILEME_KALAN_AY")));

	}

	/**
	 * Vade yenileme yap�lan kart�n �demesini iptal eder, muhasebenin tersini keser
	 * 
	 * @request
	 *          TRX_NO,BASVURU_NO
	 * 
	 * @return
	 *         TRX_NO, TRX_NAME, TX_STATUS, MESSAGE
	 */
	@GraymoundService("BNSPR_TFF_VADE_YENILEME_ODEME_IPTAL")
	public static GMMap vadeYenilemeOdemeIptal(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);

			// Parametre Kontrol
			String basvuruNoStr = iMap.getString("BASVURU_NO");
			if (!NumberUtils.isNumber(basvuruNoStr)) {
				CreditCardServicesUtil.raiseGMError("3043");
			}

			// Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			// TFF Basvurusu bilgisini al
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", basvuruNo);
			}

			// Varsa islem numarasina ait bilgiyi al, yoksa olustur
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null) {
				trxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO").toString());
			}

			TffBasvuruVdOdemeiptalTx tffBasvuruVdOdemeiptalTx = (TffBasvuruVdOdemeiptalTx) session.get(TffBasvuruVdOdemeiptalTx.class, trxNo);
			if (tffBasvuruVdOdemeiptalTx == null) {
				tffBasvuruVdOdemeiptalTx = new TffBasvuruVdOdemeiptalTx();
			}
			// Islem bilgilerini al.
			tffBasvuruVdOdemeiptalTx.setTxNo(trxNo);
			tffBasvuruVdOdemeiptalTx.setBasvuruNo(basvuruNo);
			tffBasvuruVdOdemeiptalTx.setIslemKodu(VD_YENILEME_ODEME_IPTAL_ISLEM_KOD);
			tffBasvuruVdOdemeiptalTx.setAciklama(iMap.getString("ACIKLAMA"));

			if (iMap.getString("HATA_ACIKLAMA").length() > 4000)
				tffBasvuruVdOdemeiptalTx.setHataAciklama(iMap.getString("HATA_ACIKLAMA").substring(0, 3999));
			else
				tffBasvuruVdOdemeiptalTx.setHataAciklama(iMap.getString("HATA_ACIKLAMA"));

			// Islem bilgilerini kaydet
			session.save(tffBasvuruVdOdemeiptalTx);
			session.flush();

			// Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", VD_YENILEME_ODEME_IPTAL_ISLEM_KOD);
			islemMap.put("TRX_NO", trxNo);
			oMap.putAll(islemMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));

			// vade yenileme ba�vuru flag ini iptal et
			tffBasvuru.setVdBasvuruNo(null);
			session.saveOrUpdate(tffBasvuru);
			session.flush();
			// vade yenileme odeme kayd�n� sil
			TffBasvuruVdOdeme tffBasvuruVdOdeme = (TffBasvuruVdOdeme) session.get(TffBasvuruVdOdeme.class, basvuruNo);
			session.delete(tffBasvuruVdOdeme);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Vade yenileme yap�lacak olan kart bilgilerini batch i�lemle aktar�r, batch arkadan yenileme yapmay� dener
	 * 
	 */

	@GraymoundService("BNSPR_TFF_VADE_YENILEME_BATCH_ISLEM")
	public static GMMap vadeYenilemeOdemeBatch(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		try {
			TffVadeYenilemeBatchislem tffVadeYenilemeBatchIslem = new TffVadeYenilemeBatchislem();
			tffVadeYenilemeBatchIslem.setTxNo(iMap.getBigDecimal(TX_NO));
			tffVadeYenilemeBatchIslem.setApplicationNo(iMap.getBigDecimal("APPLICATION_NO"));
			tffVadeYenilemeBatchIslem.setErrorCode(iMap.getString("ERROR_CODE"));
			tffVadeYenilemeBatchIslem.setTrnType("SKT");
			tffVadeYenilemeBatchIslem.setErrorDesc(iMap.getString("ERROR_DESC"));
			tffVadeYenilemeBatchIslem.setPaymentStatus(iMap.getBigDecimal("PAYMENT_STATUS", VadeYenilemeDurum.NOT_OK.getValue()));
			tffVadeYenilemeBatchIslem.setRenewalStatus(iMap.getBigDecimal("RENEWAL_STATUS", VadeYenilemeDurum.NOT_OK.getValue()));
			tffVadeYenilemeBatchIslem.setCardNo(iMap.getString(CARD_NO));
			tffVadeYenilemeBatchIslem.setAddress1(iMap.getString(ADDRESS1));
			tffVadeYenilemeBatchIslem.setAddressCity(iMap.getString(ADDRESS_CITY));
			tffVadeYenilemeBatchIslem.setAddressCityCode(iMap.getString(ADDRESS_CITY_CODE));
			tffVadeYenilemeBatchIslem.setAddressCountry(iMap.getString(ADDRESS_COUNTRY));
			tffVadeYenilemeBatchIslem.setAddressTown(iMap.getString("ADDRESS_TOWN"));
			tffVadeYenilemeBatchIslem.setAddressTownCode(iMap.getString(ADDRESS_TOWN_CODE));
			tffVadeYenilemeBatchIslem.setAddressZipCode(iMap.getString(ADDRESS_ZIP_CODE));
			tffVadeYenilemeBatchIslem.setBranchCode(iMap.getString(BRANCH_CODE));
			tffVadeYenilemeBatchIslem.setCustomerNo(iMap.getString(CUSTOMER_NO));
			tffVadeYenilemeBatchIslem.setCardPostIdx(iMap.getString(CARD_POST_IDX));
			tffVadeYenilemeBatchIslem.setPaymentRefId(iMap.getString("PAYMENT_REF_ID"));
			tffVadeYenilemeBatchIslem.setSource(iMap.getString(SOURCE));
			tffVadeYenilemeBatchIslem.setTryCount(BigDecimal.ZERO);

			session.saveOrUpdate(tffVadeYenilemeBatchIslem);
			session.flush();
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Vade yenileme yap�lan kart aktif hale geldi�inde eskisini kapat�r
	 * 
	 * APPLICATION_NO,CARD_NO,CARD_DCI
	 * 
	 */

	@GraymoundService("BNSPR_TFF_VADE_YENILEME_ESKI_KART_IPTAL")
	public static GMMap vadeYenilemeEskiKartiIptalEt(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		TffBasvuru kaynakBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("vdBasvuruNo", iMap.getBigDecimal("APPLICATION_NO"))).uniqueResult();

		if (kaynakBasvuru != null) {
			GMMap infoMap = new GMMap();

			infoMap.put("CUSTOMER_NO", kaynakBasvuru.getMusteriNo());
			infoMap.put("APPLICATION_NO", kaynakBasvuru.getBasvuruNo());
			infoMap.put("CARD_BANK_STATUS", OceanConstants.Card_Bank_Status_Open);

			// �nceki ba�vuru �zerindeki son kart numaras�n� alal�m
			infoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", infoMap);

			GMMap embossMap = new GMMap();
			// updateEmbossRequest
			embossMap.put("CARD_NO", infoMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO"));
			embossMap.put("EXT_CARD_NO", iMap.getString("CARD_NO"));
			embossMap.put("EXT_DATE", getApplicationPaymentDate(iMap.getString("APPLICATION_NO")));
			embossMap.put("TYPE", "C");
			embossMap.put("EXT_APPLICATION", iMap.getBigDecimal("APPLICATION_NO"));
			embossMap.put("EXT_CARD_DCI", iMap.getString("CARD_DCI"));

			GMServiceExecuter.executeAsync("BNSPR_INTRACARD_UPDATE_CARD_EMBOSS", embossMap);
			// skt den gelen ba�vuru ise eski kart� iptal ediyoruz
			GMMap kartMap = new GMMap();
			kartMap.put("CARD_NO", infoMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO"));
			kartMap.put("STATUS", IPTAL_STATUS);
			kartMap.put("SUBSTATUS", IPTAL_STATUS);
			kartMap.put("EMBOSS_CODE", " ");
			kartMap.put("FREE_TEXT", "Vade Yenileme nedeniyle kart iptal edilmi�tir");

			oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_UPDATE_CARD_STATUS", kartMap));
		}
		return oMap;
	}

	private static String getApplicationPaymentDate(String appNo) {
		try {
			GMMap apMap = new GMMap();
			apMap.put("TFF_BASVURU_NO", appNo);
			apMap.putAll(GMServiceExecuter.call("BNSPR_TFF_COMMON_GET_ODEME_TARIHI", apMap));

			if (AkustikConstants.RESPONSE_SUCCESS.equals(apMap.getString("RESPONSE")))
				return apMap.getString("ODEME_TARIHI");
			else
				return "";

		}
		catch (Exception e) {
			return "";
		}
	}

	private static void vadeYenilemeIzKaydiYarat(GMMap iMap) {

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		TffVadeYenileme tffVadeYenileme = new TffVadeYenileme();
		TffVadeYenilemeId tffVadeYenilemeId = new TffVadeYenilemeId();
		tffVadeYenilemeId.setAddress1(iMap.getString(ADDRESS1));
		tffVadeYenilemeId.setAddressCity(iMap.getString(ADDRESS_CITY));
		tffVadeYenilemeId.setAddressCityCode(iMap.getString(ADDRESS_CITY_CODE));
		tffVadeYenilemeId.setAddressCountry(iMap.getString(ADDRESS_COUNTRY));
		tffVadeYenilemeId.setAddressTown(iMap.getString("ADDRESS_TOWN"));
		tffVadeYenilemeId.setAddressTownCode(iMap.getString(ADDRESS_TOWN_CODE));
		tffVadeYenilemeId.setAddressZipCode(iMap.getString(ADDRESS_ZIP_CODE));
		tffVadeYenilemeId.setApplicationNo(iMap.getBigDecimal(APPLICATION_NO));
		tffVadeYenilemeId.setBranchCode(iMap.getString(BRANCH_CODE));
		tffVadeYenilemeId.setCardNo(iMap.getString(CARD_NO));
		tffVadeYenilemeId.setCardPostIdx(iMap.getString(CARD_POST_IDX));
		tffVadeYenilemeId.setCustomerNo(iMap.getString(CUSTOMER_NO));
		tffVadeYenilemeId.setDysInfo(iMap.getString(DYS_INFO));
		tffVadeYenilemeId.setErrorCode(iMap.getString(ERROR_CODE));
		tffVadeYenilemeId.setErrorDesc(iMap.getString(ERROR_DESC));
		tffVadeYenilemeId.setErrorStep(iMap.getString("ERROR_STEP"));
		tffVadeYenilemeId.setPaymentRefId(iMap.getString("PAYMENT_REF_ID"));
		tffVadeYenilemeId.setRenewalStatus(iMap.getBigDecimal("RENEWAL_STATUS"));
		tffVadeYenilemeId.setReversalTxNo(iMap.getBigDecimal("REVERSAL_TX_NO"));
		tffVadeYenilemeId.setSource(iMap.getString(SOURCE));
		tffVadeYenilemeId.setStatus(iMap.getString(STATUS));
		tffVadeYenilemeId.setTrnType(iMap.getString("TRN_TYPE"));
		tffVadeYenilemeId.setVisaStatus(iMap.getBigDecimal("VISA_STATUS"));
		tffVadeYenilemeId.setVisaTxNo(iMap.getBigDecimal("VISA_TX_NO"));

		tffVadeYenileme.setId(tffVadeYenilemeId);
		session.saveOrUpdate(tffVadeYenileme);
		session.flush();

	}

	public static void updateDysInfo(BigDecimal applicationNo, String dagitimKod) {

		if (!BASVURU_DAGITIM_KOD_BOS.equals(dagitimKod)) {
			GMMap belgeMap = new GMMap();
			belgeMap.put("BASVURU_NO", applicationNo);
			belgeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BELGE_KAYIT", belgeMap));
		}

	}

	public enum VadeYenilemeDurum {
		OK(BigDecimal.ONE), NOT_OK(BigDecimal.ZERO), ERROR(BigDecimal.ONE.negate()), ALREADY_HAVE(new BigDecimal(2).negate());
		private BigDecimal value;

		VadeYenilemeDurum(BigDecimal value) {
			this.value = value;
		}

		public BigDecimal getValue() {
			return value;
		}
	}

	/** Joblar icin yapilacak parametresiz listeleme icin kullanilir.
	 * 
	 * @param procName - PAKET_ISMI.FUNC_ISMI formatinda olmasi gerekir
	 */
	private static GMMap listCreditCardJob(BigDecimal basvuru_no) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = new StringBuilder();
			query.append("{? = call PKG_TFF_BASVURU.listTFFKkRedSmsJob(?)}");
//			query.append(procName);
//			query.append("}");
            stmt = conn.prepareCall(query.toString());
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, basvuru_no);
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResultsPutStr(rSet, RESULTS);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}

}
