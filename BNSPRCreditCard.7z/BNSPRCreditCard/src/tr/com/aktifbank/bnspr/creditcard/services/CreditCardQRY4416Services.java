package tr.com.aktifbank.bnspr.creditcard.services;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY4416Services implements OceanMapKeys {
    
    private static final Logger logger = Logger.getLogger(CreditCardQRY4416Services.class);
    
    @GraymoundService("BNSPR_QRY4416_UPDATE_AUTO_PAYMENT")
    public static GMMap getCardList(GMMap iMap) {
        GMMap oMap = new GMMap();
        String tableName = "PAYMENT_INFO";
        try{
            if(StringUtils.isBlank(iMap.getString("AUTO_ACCOUNT_BRANCH"))){
                iMap.put("P1", "�UBE");
                iMap.put("HATA_NO" , "330");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            if(StringUtils.isBlank(iMap.getString("CARD_NO"))){
                iMap.put("P1", "KART NUMARASI");
                iMap.put("HATA_NO" , "330");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            if(StringUtils.isBlank(iMap.getString("AUTO_ACCOUNT_NO"))){
                iMap.put("P1", "HESAP NO");
                iMap.put("HATA_NO" , "330");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            if(StringUtils.isBlank(iMap.getString("AUTO_CURR_CODE"))){
                iMap.put("P1", "D�V�Z");
                iMap.put("HATA_NO" , "330");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            if(StringUtils.isBlank(iMap.getString("AUTO_PAYMENT_TYPE"))){
                iMap.put("P1", "�DEME T�P�");
                iMap.put("HATA_NO" , "330");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            
            iMap.put(tableName, 0, "AUTO_ACCOUNT_BRANCH", iMap.getString("AUTO_ACCOUNT_BRANCH"));
            iMap.put(tableName, 0, "AUTO_ACCOUNT_NO", iMap.getString("AUTO_ACCOUNT_NO"));
            iMap.put(tableName, 0, "AUTO_CURR_CODE", iMap.getString("AUTO_CURR_CODE"));
            iMap.put(tableName, 0, "AUTO_PAYMENT_TYPE", iMap.getString("AUTO_PAYMENT_TYPE"));
            return GMServiceExecuter.call("BNSPR_OCEAN_UPDATE_CREDIT_CARD_AUTO_PAYMENT", iMap);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_QRY4416_GET_HESAP_LIST")
    public static GMMap getAccountList(GMMap iMap) {
        GMMap oMap = new GMMap();
        String tableName="ACCOUNT_LIST";
        try{
            iMap.put("TABLE_NAME" , "ACCOUNT_LIST");
            oMap = (GMServiceExecuter.call("INTERNET_GET_MUSTERI_HESAP_LIST" , iMap));
            iMap.put("DOVIZ_KODU" , "TRY");
            if (oMap.getSize(tableName) == 0){
                oMap.put("RESPONSE" , "0");
                oMap.put("RESPONSE_DATA" , GMMessageFactory.getMessage("NOACCOUNT" , null));
                oMap.put("REMOVE_CURRENT" , true);
            } else{
                for (int i = 0; i < oMap.getSize(tableName); i++){
                    String accountNo = oMap.getString(tableName , i , "HESAP_NO");
                    
                    oMap.put(tableName , i , "CARD_ACC" , false);
                    oMap.put(tableName , i , "ACC_NO" , accountNo);
                    oMap.put(tableName , i , "ACC_TYPE" , oMap.getString(tableName , i , "HESAP_TIPI"));
                    oMap.put(tableName , i , "NICK" , oMap.getString(tableName , i , "RUMUZ"));
                    oMap.put(tableName , i , "BRANCH_NAME" , oMap.getString(tableName , i , "SUBE") + " - " + oMap.getString(tableName , i , "SUBE_ADI"));
                    oMap.put(tableName , i , "BRANCH_CODE" , oMap.getString(tableName , i , "SUBE_ADI"));
                    oMap.put(tableName , i , "LIMIT" , oMap.getString(tableName , i , "BAKIYE"));
                    oMap.put(tableName , i , "USEABLE_LIMIT" , oMap.getString(tableName , i , "KULLANILABILIR_BAKIYE"));
                    oMap.put(tableName , i , "KMH_LIMIT" , oMap.getString(tableName , i , "KMH_LIMIT"));
                    oMap.put(tableName , i , "EXC_CODE" , oMap.getString(tableName , i , "DOVIZ_KODU"));
                    oMap.put(tableName , i , "PRINT_EXC_CODE" , oMap.getString(tableName , i , "BASIM_DOVIZ_KODU"));
                    oMap.put(tableName , i , "CUSTOMER_NO" , oMap.getString(tableName , i , "MUSTERI_NO"));
                    oMap.put(tableName , i , "IBAN" , oMap.getString(tableName , i , "IBAN"));
                    oMap.put(tableName , i , "BRANCH" , oMap.getString(tableName , i , "SUBE"));
                }
                
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_QRY4416_GET_CARD_INFO")
    public static GMMap getCardInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap cardMap = new GMMap();
        GMMap autoPaymentMap = null;
        boolean isDebit = false;
        boolean isUptKart = false;
        boolean isTroyKart=false;
        String paymentTableName="AUTO_PAYMENT_INFO";
        try{
            cardMap = (GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , iMap));
            String productId ="";
            for(int i=0; i<cardMap.getSize(CARD_DETAIL_INFO); i++){
				productId = !StringUtils.isEmpty(cardMap.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID"))? cardMap.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID") : "";

            	isUptKart = KkProductsUtil.isUptPpProduct(productId);//"912".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID"));
            	isTroyKart = KkProductsUtil.isTroyDebitProduct(productId); //"916".equals(cardMap.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID"));
            	if(!isUptKart && !isTroyKart)
            	{
                List<GMMap> AutoPaymentList = (ArrayList<GMMap>) cardMap.get(CARD_DETAIL_INFO, i, paymentTableName);
                if (AutoPaymentList != null && AutoPaymentList.size() > 0){
                    autoPaymentMap = AutoPaymentList.get(0);
                    for (int j = 0; j < autoPaymentMap.getSize(paymentTableName); j++){
                        if ("MinimumBalance".equals(autoPaymentMap.getString(paymentTableName , j , "AUTO_PAYMENT_TYPE")))
                            cardMap.put(CARD_DETAIL_INFO , i , "AUTO_PAYMENT_TYPE_NAME" , "Asgari Bor�");
                        else if ("TotalBalance".equals(autoPaymentMap.getString(paymentTableName , j , "AUTO_PAYMENT_TYPE")))
                            cardMap.put(CARD_DETAIL_INFO , i , "AUTO_PAYMENT_TYPE_NAME" , "Toplam Bor�");
                    }
                }
                cardMap.put(CARD_DETAIL_INFO , i , MASKED_CARD_NO , maskCardNumber(cardMap.getString(CARD_DETAIL_INFO, i, "CARD_NO")));
                isDebit = "Debit".equals(cardMap.getString(CARD_DETAIL_INFO, i, "CARD_DCI"));
                if(!isDebit)
                    oMap.put(CARD_DETAIL_INFO ,  oMap.getSize(CARD_DETAIL_INFO), cardMap.getMap(CARD_DETAIL_INFO , i));
            }
            
            }   
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    public static String maskCardNumber(String cardNumber) {
        
        // format the number
        return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})" , "$1 **** **** $3");
    }
    

    
}
