package tr.com.aktifbank.bnspr.creditcard.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4463Services {
    
private static Map<String, String> visaPaymentResultMap = new HashMap<String, String>();
    
    public static final String UNDEFINED = "UNDEFINED";
    static {
        visaPaymentResultMap.put(UNDEFINED, "");
        visaPaymentResultMap.put("0", "�deme ve Vize G�ncelleme Ba�ar�l�.");
        visaPaymentResultMap.put("1", "Vize G�ncelleme Ba�ar�s�z, �deme iade edildi.");
        visaPaymentResultMap.put("2", "�demede Hata, Vize G�ncelleme Ba�ar�l�.");
        visaPaymentResultMap.put("3", "�demede Hata");
        visaPaymentResultMap.put("4", "KK Numarasi giri�inde hata yapildi.");
        visaPaymentResultMap.put("5", "CVV2 giri�inde hata yapildi.");
        visaPaymentResultMap.put("6", "Kart Son Kullan�m Tarihi giri�inde hata yapildi.");
        visaPaymentResultMap.put("7", "��lemin Devam Etmesi i�in Onay verilmedi.");
        visaPaymentResultMap.put("8", "Zamana��m� olu�tu, kart stat�s�n� kontrol ediniz.");
        visaPaymentResultMap.put("9", "Pos Bilgilerinde Hata");
        visaPaymentResultMap.put("10", "Vize g�ncelleme ba�ar�s�z, pos �creti iade edilemedi.");

    }

    @GraymoundService("BNSPR_TRN4463_GET_CARDS_VIA_TCKN_CC")
    public static GMMap getCards(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
        	iMap.put("CARD_BANK_STATUS_CC", "All");
            GMMap cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN" , iMap);
            int index = 0;
            String status = "";
            String subStatus = "";
            String cardVisaStatus = "";
    		Date cardVisaEndDate = null;
			boolean visaToRenew = false;
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			Date today = new Date();
			String todayStr = formatter.format(today);

			String cardGroup = "";
	        String cardProductId = "";
	        String system = "";
	        boolean isNKolayKart = false;
	        boolean isPassoligCard = false;
	        boolean isOcean = false;
	        boolean isUptKart = false;
	        boolean isTroyKart = false;
	        //-Hce
	        boolean isVirtualPP = false;
	        boolean isHceKart=false;
	        boolean isHceKart_2=false;
	        //-Hce
	        boolean mChipCard=false;
			iMap.put("START_DATE", todayStr);
			iMap.put("END_DATE", todayStr);
			
			boolean fromVisaPayment = iMap.getBoolean("FROM_VISA_PAYMENT", Boolean.FALSE); 
			
    		for (int i = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {
    			status = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE");
    			subStatus = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE");

    			cardVisaStatus = cardMap.getString("CARD_DETAIL_INFO", i, "VISA_STAT");
    			cardVisaEndDate = cardMap.getDate("CARD_DETAIL_INFO", i, "VISA_END_DATE");

    			visaToRenew = false;

    			if(cardVisaStatus.equals("N")){ //Vizesi yok
					visaToRenew = true;
				}else if(cardVisaStatus.equals("Y")){ // Vizesi Var, 30 gunu var
					long dateDiff = getDateDiff(cardVisaEndDate, today, TimeUnit.DAYS);
					if(dateDiff>= 0 && dateDiff <= 365L){
    					visaToRenew = true;
					}
				}
    			
    			if ( !fromVisaPayment || visaToRenew ){
    				if (		("N".equals(status) && "N".equals(subStatus))
    					 	|| 	("G".equals(status) && "J".equals(subStatus))
    					 	|| 	("P".equals(status) && "P".equals(subStatus))
    					 	|| 	("G".equals(status) && "B".equals(subStatus))) 
	    			{
    	                cardGroup = cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_GROUP");
    	                cardProductId = cardMap.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID");
    	                system = cardMap.getString("CARD_DETAIL_INFO" , i , "SYSTEM");
    	                
    	                isOcean = "O".equals(system);
    	                isPassoligCard = "1".equals(cardGroup);
    	                isNKolayKart = KkProductsUtil.isNkolayDebitProduct(cardProductId, OceanConstants.MASTERCARD);//(cardProductId);//"905".equals(cardProductId) || "906".equals(cardProductId); 
    	                isUptKart = KkProductsUtil.isUptPpProduct(cardProductId);//"912".equals(cardProductId);
    	                isTroyKart = KkProductsUtil.isTroyDebitProduct(cardProductId);//"916".equals(cardProductId);
    	                //-Hce
    	                isVirtualPP = KkProductsUtil.isVirtualProduct(cardProductId);//"914".equals(cardProductId);
    	                isHceKart= KkProductsUtil.isHceProduct(cardProductId,"ONLINE");//"920".equals(cardProductId);
    	                isHceKart_2= KkProductsUtil.isHceProduct(cardProductId,"OFFLINE");//"921".equals(cardProductId);
        	            //-Hce
    	                mChipCard=KkProductsUtil.isMchipProduct(cardProductId);//CreditCardQRY4410Services.mchipFilter(cardMap, i, 0,"CARD_DETAIL_INFO", "PRODUCT_ID");
    	                if(isPassoligCard || (!isOcean && isNKolayKart)  && (!isUptKart && !isTroyKart) && !isVirtualPP && !isHceKart && !isHceKart_2  && !mChipCard){
    	                	oMap.put("CARD_DETAIL_INFO", index++, cardMap.getMap("CARD_DETAIL_INFO", i));
    	                }
    	             					
	    			}
    			}
    		}
        } catch (Exception e){
        }
        return oMap;
    }


	public static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
	    long diffInMillies = date1.getTime() - date2.getTime();
	    return timeUnit.convert(diffInMillies,TimeUnit.MILLISECONDS);
	}

    @GraymoundService("BNSPR_TRN4463_GREEN4_GET_CARDS_VIA_TCKN_CC")
    public static GMMap getGreen4Cards(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            GMMap oMap2 = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN" , iMap);
            int index = 0;
            String visaStatus  = "";
            String system ="";
    		for (int i = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++) {
    			visaStatus = oMap2.getString("CARD_DETAIL_INFO", i, "VISA_STAT");
    			system = oMap2.getString("CARD_DETAIL_INFO", i, "SYSTEM");
    			
    			if ("Y".equals(visaStatus) || "B".equals(system))
	    			{
	    				oMap.put("CARD_DETAIL_INFO", index++, oMap2.getMap("CARD_DETAIL_INFO", i));
	    			}
    		}
        } catch (Exception e){
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4463_GET_PAYMENT_RESPONSE")
    public static GMMap getPaymentRespone(GMMap iMap) {
        GMMap oMap = new GMMap();

        iMap.put("CHANNEL", "CC");
        iMap.put("ATTRIBUTE_KEY", "IVR_RETURN_CODE");
        oMap = GMServiceExecuter.call("CNSPR_GET_FROM_CUSTOMER_SESSION", iMap);
        String returnCode = oMap.getString("RETURN_VALUE");
        oMap.put("RETURN_CODE", oMap.getString("RETURN_VALUE"));
        oMap.put("RETURN_VALUE", getPaymentResult(returnCode));

        iMap.put("ATTRIBUTE_KEY", "IVR_RETURN_CODE");
        iMap.put("ATTRIBUTE_VALUE", "");
        GMServiceExecuter.call("CNSPR_PUT_TO_CUSTOMER_SESSION", iMap);

        return oMap;
    }

    public static String getPaymentResult(String code) {
        if (code == null || code.trim().length() == 0) {
            code = UNDEFINED;
        }
        code = code.trim();
        return visaPaymentResultMap.get(visaPaymentResultMap.containsKey(code) ? code : UNDEFINED);
    }
    
    @GraymoundService("BNSPR_TRN4463_IVR_LOG")
    public static GMMap trn4463IVRLog(GMMap iMap) {
        return new GMMap();
    }
    
}
