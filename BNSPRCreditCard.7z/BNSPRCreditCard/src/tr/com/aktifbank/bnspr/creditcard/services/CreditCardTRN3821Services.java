package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTx;
import tr.com.aktifbank.bnspr.dao.KkLimitGuncelleme;
import tr.com.aktifbank.bnspr.dao.KkLimitGuncellemeTx;
import tr.com.aktifbank.bnspr.dao.KkTopluBasvuruHavuz;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/** Kredi karti limit guncelleme islemlerinin gerceklestirilmesini saglar.
 * @since PYKKBAS-242
 * @author murat.el
 * 
 */
public class CreditCardTRN3821Services {
	
	private static final String ISLEM_KODU = "3821";
	private static final String ISLEM_SONRASI_MESAJ = "ISLEM_SONRASI_MESAJ";
	private static final String EVAM_LIMIT_SENARYO_1 = "EVAM_LIMIT_GUNCELLEME_1";
	private static final String EVAM_LIMIT_SENARYO_2 = "EVAM_LIMIT_GUNCELLEME_2";
	//private static final String EVAM_LIMIT_SENARYO_3 = "EVAM_LIMIT_GUNCELLEME_3";
	private static final String KK_LIMIT_AZALT_EVENT = "51";
	
	private static final Logger logger = Logger.getLogger(CreditCardTRN3821Services.class);
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-7525
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>KANAL_KOD - Islem yapilan kanal kodu
	 *         <li>LIMIT_GUNCELLEME_NEDENI - Limit guncelleme isleminin sebepleri
	 *         <li>LIMIT_AZALTMA_NEDENI - Limit dusurme isleminin sebepleri
	 *         <li>LIMIT_ARTIRMA_NEDENI - Limit yukseltme isleminin sebepleri
	 */
	@GraymoundService("BNSPR_TRN3821_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Kanal Kod
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			//Ekrandan surekli servis cagrilmasin diye basta alindi.
			//Limit guncelleme nedenleri - tumu
			oMap.putAll(CreditCardServicesUtil.getParameterList("LIMIT_GUNCELLEME_NEDENI", "KK_LIMIT_GUNCELLEME_NEDENI", "E"));
			//Limit guncelleme nedenleri - azaltma islemleri
			oMap.putAll(CreditCardServicesUtil.getParameterList("LIMIT_AZALTMA_NEDENI", "KK_LIMIT_GUNCELLEME_NEDENI", "Z", "E"));
			//Limit guncelleme nedenleri - artirma islemleri
			oMap.putAll(CreditCardServicesUtil.getParameterList("LIMIT_ARTIRMA_NEDENI", "KK_LIMIT_GUNCELLEME_NEDENI", "A", "E"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-7525, PY-9423
	 * @param iMap - Islem bilgileri<br>
	 *         <li>TRX_NO - Islem numarasi
	 *         <li>BASVURU_NO - Kredi karti basvuru numarasi
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>CAPTCHA - Islem basarili ise ekranda goruntulenecek dogrulama resmi
	 *         <li>ESGM_YAPILDI_MI - Verilen basvuru icin esgm sorgusu yapildi mi?(Y:Evet|N:Hayir)
	 *         <li>ESGM_ENABLED - Esgm sistemi aktif mi?(A:Acik|K:Kapali)
	 */
	@GraymoundService("BNSPR_TRN3821_GET_CAPTCHA")
	public static GMMap getCaptcha(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			//Basvuru icin esgm sorgusu yapilmis mi?
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_SUCCESSFUL_CAPTCHA_VALIDATION", iMap));
			oMap.put("ESGM_YAPILDI_MI", sorguMap.get("RESULT"));
			//Esgm sorgusu yapilabilir durumda mi?
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXT_ESGMSGK_IS_WEB_QUERY_ENABLED", iMap));
			oMap.put("ESGM_ENABLED", sorguMap.getString("DEGER"));
			if ("A".equals(sorguMap.getString("DEGER"))) {
				sorguMap.clear();
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXT_ESGMSGK_GET_LOGIN_CAPTCHA", sorguMap));
				oMap.put("CAPTCHA", sorguMap.get("CAPTCHA"));
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore istenilen sonuclari listeler<br>
	 * @author murat.el
	 * @since PY-7525, PY-9701, PY-10099
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>TCKN - TC kimlik numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>KART_NO - Kart numarasi
	 *        <li>MAC_LIMITI_KONTROL_EDILSIN_MI - Kartin mac limitli olup olmadigi kontrol edilsin mi(E:Evet|H:Hayir)
	 * @return Sorgu sonuclari<br>
	 *        <li>KART_LIST - Verilen musteri numarasina ait aktif kart bilgileri
	 *        <li>MUSTERI_LIMIT - Musteriye ait toplam limit bilgisi
	 *        <li>MUSTERI_GRUP - Musteri grubu
	 *        <li>MUSTERI_TIP - Musteri tipi
	 */
	@GraymoundService("BNSPR_TRN3821_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		boolean isUptKart = false;
		try {	
			//TCKN girilmisse gecerli mi
			if (StringUtils.isNotBlank(iMap.getString("TCKN"))) {
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", iMap.get("TCKN"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", sorguMap));
				if ("0".equals(sorguMap.getString("SONUC"))) {
					CreditCardServicesUtil.raiseGMError("456", iMap.getString("TCKN"));
				}
			}
			
			//Musteri bilgisini kart sisteminden al
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CUSTOMER_INFO", sorguMap));
			
			//Musteri var mi?
			String iTableName = "CUSTOMER_INFO_LIST";
			if (sorguMap.getSize(iTableName) == 0) {
				return oMap;
			}
			
			//Musteri bilgilerini al
			for (int i = 0; i < sorguMap.getSize(iTableName); i++) {
				String customerLimit = sorguMap.getString(iTableName, i, "CUSTOMER_LIMIT");
				if (StringUtils.isNotBlank(customerLimit)) {
					customerLimit = customerLimit.replace(",", ".");
				}
				
				oMap.put("MUSTERI_LIMIT", customerLimit);
				oMap.put("MUSTERI_GRUP", sorguMap.get(iTableName, i, "CUSTOMER_GROUP"));
				oMap.put("MUSTERI_TIP", sorguMap.get(iTableName, i, "CUSTOMER_TYPE"));
			}
			
			//Mac limiti musteri tipi kontrol
			if (CreditCardServicesUtil.EVET.equals(CreditCardServicesUtil.nvl(
					iMap.getString("MAC_LIMITI_KONTROL_EDILSIN_MI"), CreditCardServicesUtil.EVET))) {
				sorguMap.clear();
				sorguMap.put("MUSTERI_TIP",  oMap.get("MUSTERI_TIP"));
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
				GMServiceExecuter.execute("BNSPR_TRN3821_MUSTERI_TIPI_MAC_LIMITLI_MI", sorguMap);
			}
			
			//Musteriye ait kart listesini al
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("CARD_NO", iMap.get("KART_NO"));
			sorguMap.put("CARD_DCI", "C");
			sorguMap.put("CARD_BANK_STATUS", "All");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", sorguMap));
			
			//Musteriye ait kart var mi?
			iTableName = "CARD_DETAIL_INFO";
			if (sorguMap.getSize(iTableName) == 0) {
				return oMap;
			}
			
			int row = 0;

			//Kart bilgilerini al
			String oTableName = "KART_LIST";
			for (int i = 0; i < sorguMap.getSize(iTableName); i++) {
				isUptKart = "912".equals(sorguMap.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID"));
				if ("C".equals(sorguMap.get(iTableName, i, "CARD_DCI_AKUSTIK")) &&
						("N".equals(sorguMap.get(iTableName, i, "CARD_STAT_CODE")) || ("G".equals(sorguMap.get(iTableName, i, "CARD_STAT_CODE")) && "N".equals(sorguMap.get(iTableName, i, "CARD_SUB_STAT_CODE")))) && !isUptKart) {
					oMap.put(oTableName, row, "KART_TIPI", "Kredi Karti");
					oMap.put(oTableName, row, "KART_NO", sorguMap.get(iTableName, i, "CARD_NO"));
					oMap.put(oTableName, row, "MUSTERI_NO", sorguMap.get(iTableName, i, "CUSTOMER_NO"));
					oMap.put(oTableName, row, "KART_NO_MASK", maskCardNumber(sorguMap.getString(iTableName, i, "CARD_NO")));
					oMap.put(oTableName, row, "AD_SOYAD", sorguMap.get(iTableName, i, "CARD_EMBOSS_NAME_1"));
					oMap.put(oTableName, row, "KART_STATU", sorguMap.get(iTableName, i, "CARD_STAT_DESC"));
					oMap.put(oTableName, row, "KART_LIMIT", sorguMap.get(iTableName, i, "CARD_LIMIT"));
					oMap.put(oTableName, row, "SON_KULLANMA_TARIHI", sorguMap.get(iTableName, i, "EXPIRY_DATE"));
					oMap.put(oTableName, row, "KART_SUBE", sorguMap.get(iTableName, i, "CARD_BRANCH"));
					oMap.put(oTableName, row, "MUSTERI_GRUP", oMap.get("MUSTERI_GRUP"));
					oMap.put(oTableName, row, "MUSTERI_TIP", oMap.get("MUSTERI_TIP"));
					oMap.put(oTableName, row, "MUSTERI_LIMIT", oMap.get("MUSTERI_LIMIT"));
					oMap.put(oTableName, row, "URUN_TIPI", sorguMap.get(iTableName, i, "PRODUCT_ID"));
					oMap.put(oTableName, row, "HESAP_KESIM_TARIHI", sorguMap.get(iTableName, i, "BILL_CYCLE_CODE"));
					oMap.put(oTableName, row, "OTOMATIK_ODEME_TALIMATI", sorguMap.get(iTableName, i, "AUTO_PAY_TYPE_TRY"));
					oMap.put(oTableName, row, "FINANSAL_TIP", sorguMap.get(iTableName, i, "FINANCIAL_TYPE"));
					oMap.put(oTableName, row, "LOGO_KOD", sorguMap.get(iTableName, i, "LOGO_CODE"));
					oMap.put(oTableName, row, "KULLANILABILIR_KART_LIMIT", sorguMap.get(iTableName, i, "CARD_AVAIL_LIMIT"));
					oMap.put(oTableName, row, "KART_RISK", sorguMap.getBigDecimal(iTableName, i, "CARD_LIMIT").subtract(sorguMap.getBigDecimal(iTableName, i, "CARD_AVAIL_LIMIT")));
					oMap.put(oTableName, row, "KART_GRUP_ACIKLAMA", sorguMap.get(iTableName, i, "CARD_GROUP_DESC"));
					//Otomatik limit artis
					if ("1".equals(sorguMap.get(iTableName, i, "AUTO_LIMIT_INCREASE"))) {
						oMap.put(oTableName, row, "OTOMATIK_LIMIT_ARTIS", "true");
					} else {
						oMap.put(oTableName, row, "OTOMATIK_LIMIT_ARTIS", "false");
					}
					
					row++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since PY-7525, PY-10099
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>KART_NO - Kart numarasi
	 *        <li>KART_LIMIT - Mevcut kart limiti
	 *        <li>KART_RISK - Kart risk limiti
	 *        <li>TALEP_EDILEN_KART_LIMITI - Istenen yeni kart limiti
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi
	 *        <li>OTOMATIK_LIMIT_ARTSIN_MI - Otomatik olarak limit artsin mi?(true|false)
	 *        <li>LIMIT_GUNCELLEME_NEDENI - Limit degisim neden kodu
	 *        <li>MUSTERI_LIMIT - Musteriye ait toplam limit
	 *        <li>ISLEM_YERI - Islemin yapildigi yer
	 *        <li>DURUM_KOD - Guncellenecek durum kodu
	 *        <li>ONCEKI_DURUM_KOD - Limit guncelleme isleminin mevcut durumu
	 *        <li>BASVURU_NO - Limit guncelleme basvuru numarasi
	 *        <li>KAMPANYA - Evamdan geliyorsa kampanya adi
	 *        <li>ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI - Kart ustundeki limit artirisilsin flagi (0:Hayir|1:Evet)
	 * @return Islem sonucu<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>ID - Limit guncelleme idsi
	 */
	@GraymoundService("BNSPR_TRN3821_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Variables
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null) {
				trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
				iMap.put("TRX_NO", trxNo);
				oMap.put("TRX_NO", trxNo);
			}
			
			BigDecimal id = iMap.getBigDecimal("ID");
			if (id == null) {
				iMap.put("TABLE_NAME", "KK_LIMIT_GUNCELLEME");
				id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", iMap).getBigDecimal("ID");
				iMap.put("ID", id);
				oMap.put("ID", id);
			}
			
			//Kontrol - BigDecimal.CompareTo patlamasin diye eklendi
			if (iMap.get("KART_LIMIT") == null) {
				CreditCardServicesUtil.raiseGMError("330", "Kart Limiti");
			}
			
			if (iMap.get("TALEP_EDILEN_KART_LIMITI") == null) {
				CreditCardServicesUtil.raiseGMError("330", "Talep Edilen Kart Limiti");
			}
			
			String limitArttiMi = null;
			if (iMap.getBigDecimal("KART_LIMIT").compareTo(iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI")) < 0) {
				limitArttiMi = CreditCardServicesUtil.EVET;
			} else if (iMap.getBigDecimal("KART_LIMIT").compareTo(iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI")) >= 0) {
				limitArttiMi = CreditCardServicesUtil.HAYIR;
				if (iMap.containsKey("BASVURU_NO")) {//Limit azaltis isleminde basvuru olusmayacagindan kaldirildi.
					iMap.remove("BASVURU_NO");
				}
			}
			iMap.put("LIMIT_ARTIS_MI", limitArttiMi);
			
			String limitOtomatikArtsinMi = CreditCardServicesUtil.HAYIR;
			if (iMap.getBoolean("OTOMATIK_LIMIT_ARTSIN_MI")) {
				limitOtomatikArtsinMi = CreditCardServicesUtil.EVET;
			}
			iMap.put("OTOMATIK_LIMIT_ARTSIN_MI", limitOtomatikArtsinMi);
			
			String oncekiLimitOtomatikArtsinMi = CreditCardServicesUtil.HAYIR;
			if (iMap.getBoolean("ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI")) {
				oncekiLimitOtomatikArtsinMi = CreditCardServicesUtil.EVET;
			}
			iMap.put("ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI", oncekiLimitOtomatikArtsinMi);
			
			//Durum kodu belirle
			String yeniDurumKodu = iMap.getString("DURUM_KOD");
			if (StringUtils.isBlank(yeniDurumKodu)) {
				if (CreditCardServicesUtil.EVET.equals(limitArttiMi)) {
					yeniDurumKodu = "KREDI_KARTI";
				} else {
					yeniDurumKodu = "LIMIT_JOB";
				}
			}
			iMap.put("DURUM_KOD", yeniDurumKodu);
			
			//Kaydet
			oMap.putAll(saveOrUpdate(iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/** Alinan bilgilerle islemi kaydet/guncelle<br>
	 * @author murat.el
	 * @since PY-8975, PY-10099
	 * @param iMap - Islem bilgileri<br>
	 * 		  <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>ID - Ana tablo islem idsi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>KART_NO - Kart numarasi
	 *        <li>KART_LIMIT - Mevcut kart limiti
	 *        <li>KART_RISK - Kart risk limiti
	 *        <li>TALEP_EDILEN_KART_LIMITI - Istenen yeni kart limiti
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi
	 *        <li>LIMIT_ARTIS_MI - Limit arttirilacak mi? (E:Evet|H:Hayir)
	 *        <li>OTOMATIK_LIMIT_ARTSIN_MI - Otomatik olarak limit artsin mi? (E:Evet|H:Hayir)
	 *        <li>LIMIT_GUNCELLEME_NEDENI - Limit degisim neden kodu
	 *        <li>MUSTERI_LIMIT - Musteriye ait toplam limit
	 *        <li>ISLEM_YERI - Islemin yapildigi yer
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>DURUM_KOD - Limit guncelleme islemi sonundaki yeni durum
	 *        <li>ONCEKI_DURUM_KOD - Limit guncelleme isleminin mevcut durumu
	 *        <li>ONAYLANAN_KART_LIMIT - Banka degerlendirmesi sonucu onaylanan kart limiti
	 *        <li>KAMPANYA - Evamdan geliyorsa kampanya adi
	 *        <li>ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI - Kart ustundeki limit artirisilsin flagi (0:Hayir|1:Evet)
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3821_SAVE_OR_UPDATE")
	public static GMMap saveOrUpdate(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			KkLimitGuncellemeTx kkLimitGuncellemeTx = (KkLimitGuncellemeTx) 
					session.get(KkLimitGuncellemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkLimitGuncellemeTx == null) {
				kkLimitGuncellemeTx = new KkLimitGuncellemeTx();
				kkLimitGuncellemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				kkLimitGuncellemeTx.setId(iMap.getBigDecimal("ID"));
			}
			
			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				KkLimitGuncelleme kkLimitGuncelleme = (KkLimitGuncelleme) 
						session.get(KkLimitGuncelleme.class, iMap.getBigDecimal("ID"));
				if (kkLimitGuncelleme == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("ID"));
				}
				
				kkLimitGuncellemeTx.setAylikGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AYLIK_GELIR"), kkLimitGuncelleme.getAylikGelir()));
				kkLimitGuncellemeTx.setBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("BASVURU_NO"), kkLimitGuncelleme.getBasvuruNo()));
				kkLimitGuncellemeTx.setKartLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KART_LIMIT"), kkLimitGuncelleme.getKartLimit()));
				kkLimitGuncellemeTx.setKartNo(CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), kkLimitGuncelleme.getKartNo()));
				kkLimitGuncellemeTx.setMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), kkLimitGuncelleme.getMusteriNo()));
				kkLimitGuncellemeTx.setYeniKartLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI"), kkLimitGuncelleme.getYeniKartLimit()));
				kkLimitGuncellemeTx.setLimitArttiMi(CreditCardServicesUtil.nvl(iMap.getString("LIMIT_ARTIS_MI"), kkLimitGuncelleme.getLimitArttiMi()));
				kkLimitGuncellemeTx.setOtomatikLimitArtsin(CreditCardServicesUtil.nvl(iMap.getString("OTOMATIK_LIMIT_ARTSIN_MI"), kkLimitGuncelleme.getOtomatikLimitArtsin()));
				kkLimitGuncellemeTx.setKartRisk(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KART_RISK"), kkLimitGuncelleme.getKartRisk()));
				kkLimitGuncellemeTx.setLimitGuncellemeNedeni(CreditCardServicesUtil.nvl(iMap.getString("LIMIT_GUNCELLEME_NEDENI"), kkLimitGuncelleme.getLimitGuncellemeNedeni()));
				kkLimitGuncellemeTx.setMusteriLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_LIMIT"), kkLimitGuncelleme.getMusteriLimit()));
				kkLimitGuncellemeTx.setIslemYeri(CreditCardServicesUtil.nvl(iMap.getString("ISLEM_YERI"), kkLimitGuncelleme.getIslemYeri()));
				kkLimitGuncellemeTx.setDurumKod(CreditCardServicesUtil.nvl(iMap.getString("DURUM_KOD"), kkLimitGuncelleme.getDurumKod()));
				kkLimitGuncellemeTx.setOncekiDurumKod(iMap.getString("ONCEKI_DURUM_KOD"));
				kkLimitGuncellemeTx.setOnaylananKartLimit(CreditCardServicesUtil.nvl(iMap.getBigDecimal("ONAYLANAN_KART_LIMIT"), kkLimitGuncelleme.getOnaylananKartLimit()));
				kkLimitGuncellemeTx.setKampanya(CreditCardServicesUtil.nvl(iMap.getString("KAMPANYA"), kkLimitGuncelleme.getKampanya()));
				kkLimitGuncellemeTx.setOncekiOtomatikLimitArtsin(CreditCardServicesUtil.nvl(iMap.getString("ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI"), kkLimitGuncelleme.getOncekiOtomatikLimitArtsin()));
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				kkLimitGuncellemeTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				kkLimitGuncellemeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				kkLimitGuncellemeTx.setKartLimit(iMap.getBigDecimal("KART_LIMIT"));
				kkLimitGuncellemeTx.setKartNo(iMap.getString("KART_NO"));
				kkLimitGuncellemeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				kkLimitGuncellemeTx.setYeniKartLimit(iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI"));
				kkLimitGuncellemeTx.setLimitArttiMi(iMap.getString("LIMIT_ARTIS_MI"));
				kkLimitGuncellemeTx.setOtomatikLimitArtsin(iMap.getString("OTOMATIK_LIMIT_ARTSIN_MI"));
				kkLimitGuncellemeTx.setKartRisk(iMap.getBigDecimal("KART_RISK"));
				kkLimitGuncellemeTx.setLimitGuncellemeNedeni(iMap.getString("LIMIT_GUNCELLEME_NEDENI"));
				kkLimitGuncellemeTx.setMusteriLimit(iMap.getBigDecimal("MUSTERI_LIMIT"));
				kkLimitGuncellemeTx.setIslemYeri(iMap.getString("ISLEM_YERI"));
				kkLimitGuncellemeTx.setDurumKod(iMap.getString("DURUM_KOD"));
				kkLimitGuncellemeTx.setOncekiDurumKod(CreditCardServicesUtil.nvl(iMap.getString("ONCEKI_DURUM_KOD"), "BASVURU"));
				kkLimitGuncellemeTx.setOnaylananKartLimit(iMap.getBigDecimal("ONAYLANAN_KART_LIMIT"));
				kkLimitGuncellemeTx.setKampanya(iMap.getString("KAMPANYA"));
				kkLimitGuncellemeTx.setOncekiOtomatikLimitArtsin(iMap.getString("ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI"));
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}
			
			//Islem bilgilerini kaydet
			session.save(kkLimitGuncellemeTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Kredi karti limit guncelleme alan kontrollerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since 11.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3821_AFTER_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3821.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Kredi karti limit guncelleme islemini sonlandirir.
	 * 
	 * @author murat.el
	 * @since 11.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Islem sonucu<br>
	 *         <li>MESSAGE - ISlem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3821_SEND_TRANSACTION")
	public static GMMap sendTransaction(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Islemi tamamla
			String screenCode = iMap.getString("SCREEN_CODE");
			
			iMap.put("TRX_NAME", !StringUtils.isEmpty(screenCode) && screenCode != null ? screenCode : ISLEM_KODU);
			iMap.put("TRX_NO", iMap.get("TRX_NO"));
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			//Iptal islemi ise iptal edildigini hata mesajina ekle
			String msg = oMap.getString("MESSAGE") + ADCSession.getString(ISLEM_SONRASI_MESAJ, StringUtils.EMPTY);
			logger.info("BNSPR_TRN3821_SEND_TRANSACTION tran result msg:" + msg);
			oMap.put("MESSAGE", msg);
			ADCSession.remove(ISLEM_SONRASI_MESAJ);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Verilen islem numarasina/IDe ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since PY-7525
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 *         <li>ID - Isleme alinmis basvuru talebi ID degeri
	 * @return Isleme ait bilgiler<br>
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>KART_LIMITI - Eski kart Limiti
	 *         <li>TALEP_EDILEN_KART_LIMITI - Yeni kart limiti
	 *         <li>AYLIK_GELIR - Aylik gelir
	 *         <li>OTOMATIK_LIMIT_ARTSIN_MI - Limit otomatik artsin mi?(true|false)
	 *         <li>LIMIT_GUNCELLEME_NEDENI - Limit degisim neden kodu
	 *         <li>MUSTERI_LIMIT - Musteriye ait toplam limit
	 *         <li>KART_LIST - Verilen musteri numarasina ait aktif kart bilgileri
	 */
	@GraymoundService("BNSPR_TRN3821_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3821.Rc_Qry3821_Get_Islem_Info(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("ID"));
			stmt.execute();
			//Sorgu sonucunu al
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
			//Listeyi al
			sorguMap.clear();
			sorguMap.put("MUSTERI_NO", oMap.get("MUSTERI_NO"));
			sorguMap.put("KART_NO",  oMap.get("KART_NO"));
			oMap.putAll(list(sorguMap));
			//Ekrandaki checkbox duzenlemesini yonet
			oMap.put("OTOMATIK_LIMIT_ARTSIN", BooleanUtils.toBoolean(
					oMap.getString("OTOMATIK_LIMIT_ARTSIN", CreditCardServicesUtil.HAYIR),
					CreditCardServicesUtil.EVET, 
					CreditCardServicesUtil.HAYIR));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since PY-7525, PY-7527, TY-5162
	 * @param iMap
	 *         <li>ISLEM_NO - Islem numarasi
	 *         <li>KK_BASVURU_NO - Kredi karti basvuru numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_DEGISIM_AKIS")
	public static GMMap limitDegisimAkisBaslat(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Varsa islem numarasina ait bilgiyi al
			KkLimitGuncellemeTx kkLimitGuncellemeTx = (KkLimitGuncellemeTx) session.get(KkLimitGuncellemeTx.class, trxNo);
			if (kkLimitGuncellemeTx == null) {
				CreditCardServicesUtil.raiseGMError("1859");
			}
			
			//Limit durumuna gore islemi tamamla
			if (CreditCardServicesUtil.EVET.equals(kkLimitGuncellemeTx.getLimitArttiMi())) {
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", kkLimitGuncellemeTx.getMusteriNo());
				sorguMap.put("KART_NO", kkLimitGuncellemeTx.getKartNo());
				sorguMap.putAll(list(sorguMap));
				
				//Kredi karti basvurusu olustur.
				sorguMap.put("LIMIT_TRX_NO", kkLimitGuncellemeTx.getTxNo());
				//sorguMap.put("MUSTERI_NO", kkLimitGuncellemeTx.getMusteriNo());
				//sorguMap.put("KART_NO", kkLimitGuncellemeTx.getKartNo());
				sorguMap.put("URUN_TIPI", sorguMap.getString("KART_LIST", 0, "URUN_TIPI"));
				sorguMap.put("HESAP_KESIM_TARIHI", sorguMap.getString("KART_LIST", 0, "HESAP_KESIM_TARIHI"));
				sorguMap.put("OTOMATIK_ODEME_TALIMATI", sorguMap.getString("KART_LIST", 0, "OTOMATIK_ODEME_TALIMATI"));
				sorguMap.put("FINANSAL_TIP", sorguMap.getString("KART_LIST", 0, "FINANSAL_TIP"));
				sorguMap.put("LOGO_KOD", sorguMap.getString("KART_LIST", 0, "LOGO_KOD"));
				sorguMap.put("KK_BASVURU_NO", CreditCardServicesUtil.nvl(iMap.get("KK_BASVURU_NO"), 
						GMServiceExecuter.call("BNSPR_TRN3871_GET_BASVURU_NO", sorguMap).get("ID")));
				sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", kkLimitGuncellemeTx.getOtomatikLimitArtsin());
				sorguMap.put("TALEP_EDILEN_KART_LIMITI", kkLimitGuncellemeTx.getYeniKartLimit());
				sorguMap.put("AYLIK_GELIR", kkLimitGuncellemeTx.getAylikGelir());
				sorguMap.remove("KART_LIST");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_ARTIR", sorguMap));
				oMap.put("BASVURU_NO", sorguMap.get("BASVURU_NO"));
				//Sonuc
				ADCSession.put(ISLEM_SONRASI_MESAJ, sorguMap.get("RESPONSE_DATA"));
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
			} else {
				//Limit azaltma islemi ise joba dusuruldu, 1 hafta sonra job ile calisacak.
				//Musteri iknasi icin arama cikilmasi saglanir.
				sorguMap.clear();
				sorguMap.put("EVENT_TYPE_NO", KK_LIMIT_AZALT_EVENT);
				sorguMap.put("EVENT_REF_NO", kkLimitGuncellemeTx.getId());
				GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Limit guncellenmesi yapilmak istenen karta ait kredi karti basvurusu olusturur, islem tamamlanmaz.<br>
	 * @author murat.el
	 * @since PY-7527, TY-5162
	 * @param iMap - Limit guncellemek icin alinan kart bilgileri<br>
	 *         <li>LIMIT_TRX_NO - Limit guncelleme islem numarasi
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>KART_NO - Kart numarasi
	 *         <li>URUN_TIPI - Kart urun tipi
	 *         <li>HESAP_KESIM_TARIHI - Karta ait hesap kesim tarihi
	 *         <li>OTOMATIK_ODEME_TALIMATI - Kart icin otomatik odeme tanimli mi
	 *         <li>FINANSAL_TIP - Kart finansal tipi
	 *         <li>LOGO_KOD - Kart logo kodu
	 *         <li>OTOMATIK_LIMIT_ARTSIN_MI - Limit otomatik artirilsin mi(E:Evet|H:Hayir)
	 *         <li>TALEP_EDILEN_KART_LIMITI - Istenen kart limiti
	 *         <li>AYLIK_GELIR - Aylik gelir
	 *         <li>KK_BASVURU_NO - Kredi karti basvuru numarasi
	 * @return oMap - Kredi karti basvuru bilgileri<br>
	 *         <li>BASVURU_NO - Musteri numarasi
	 *         <li>TRX_NO - Kart numarasi  
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_ARTIR")
	public static GMMap limitArtir(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Kart ve musteri uzerinden alinan bilgilerle ekrandan girilen yeni limiti
			//iceren yeni bir kk basvurusu olusturulur, islem tamamlanmaz.
			sorguMap.clear();
			sorguMap.put("LIMIT_TRX_NO", iMap.get("LIMIT_TRX_NO"));
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("KART_NO", iMap.get("KART_NO"));
			sorguMap.put("URUN_TIPI", iMap.get("URUN_TIPI"));
			sorguMap.put("HESAP_KESIM_TARIHI", iMap.get("HESAP_KESIM_TARIHI"));
			sorguMap.put("OTOMATIK_ODEME_TALIMATI", iMap.get("OTOMATIK_ODEME_TALIMATI"));
			sorguMap.put("FINANSAL_TIP", iMap.get("FINANSAL_TIP"));
			sorguMap.put("LOGO_KOD", iMap.get("LOGO_KOD"));
			sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
			sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", iMap.get("OTOMATIK_LIMIT_ARTSIN_MI"));
			sorguMap.put("TALEP_EDILEN_KART_LIMITI", iMap.get("TALEP_EDILEN_KART_LIMITI"));
			sorguMap.put("AYLIK_GELIR", iMap.get("AYLIK_GELIR"));
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3821_KK_BASVURU_OLUSTUR", sorguMap));
			//Gonder sorgularda KKB sorgusu yaparken otonom transaction kullaniliyor, 
			//after_approval servisi bitmediginden burada olusturulan basvuruyu gormuyordu
			//tx tablolarina kayit atilabilmesi icin executeNT yapildi.
			Session session = DAOSession.getSession("BNSPRDal");
			if (StringUtils.isBlank(sorguMap.getString("BASVURU_NO")) ||
					StringUtils.isBlank(sorguMap.getString("TRX_NO"))) {
				CreditCardServicesUtil.raiseGMError("4246");
			}
			
			//Olusturulan basvuruyu al.
			BigDecimal basvuruNo = sorguMap.getBigDecimal("BASVURU_NO");
			BigDecimal trxNo = sorguMap.getBigDecimal("TRX_NO");
			oMap.put("BASVURU_NO", basvuruNo);
			oMap.put("TRX_NO", trxNo);
			
			//Kredi karti basvurusu olusmussa limit bilgisi ile eslestir
			KkLimitGuncellemeTx kkLimitGuncellemeTx = (KkLimitGuncellemeTx) 
					session.get(KkLimitGuncellemeTx.class, iMap.getBigDecimal("LIMIT_TRX_NO"));
			if (kkLimitGuncellemeTx == null) {
				CreditCardServicesUtil.raiseGMError("1859");
			} else {
				//Olusturulan basvuru nosunu limit tablosunda guncelle
				kkLimitGuncellemeTx.setBasvuruNo(basvuruNo);
				session.saveOrUpdate(kkLimitGuncellemeTx);
				session.flush();
			}

			//LKS sorgusu yap, hata alinmasi ya da basarisiz olunmasi durumunda
			//Gonder sorgularda tekrar yapilacagi icin atlandi. Basarili olma
			//durumunda ise lksden cikan limitin uygunluk kontrolu yapilir.
			//Limit uygun degilse basvuru RED edilir ve islem sonlanir, uygunsa
			//basvuru nbsm akisina girer. Ilk defa geliniyorsa lks limit uygunlugunu kontrol et.
			if ("3821".equals(kkLimitGuncellemeTx.getIslemYeri())) {
				BigDecimal lksSorguNo = null;
				try {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", basvuruNo);
					sorguMap.put("TRX_NO", trxNo);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_LKS_ONLINE_EK_TAHSIS_SORGU_YAP", sorguMap));
					lksSorguNo = sorguMap.getBigDecimal("SORGU_NO");
				} 
				catch (Exception e) {
					sorguMap.clear();
				}
				//LKS basarili mi
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("LKS_YAPILDIMI")) && 
						CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					//LKS limiti uygun mu, degilse reddet
					sorguMap.clear();
					sorguMap.put("AKIS_TURU", "B");
					sorguMap.put("SORGU_NO", lksSorguNo);
					sorguMap.put("BASVURU_NO", basvuruNo);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LKS_LIMIT_UYGUN_MU", sorguMap));
					if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("LKS_LIMIT_UYGUN_MU", CreditCardServicesUtil.HAYIR))) {
						//Basvuru uzerinde lks red mi flagini isaretle, after approval icerisinde sms buna gore belirlenecek
						KkBasvuruTx kkBasvuruTx = (KkBasvuruTx) session.get(KkBasvuruTx.class, trxNo);
						if (kkBasvuruTx != null) {
							kkBasvuruTx.setLksRedMi(CreditCardServicesUtil.EVET);
							session.save(kkBasvuruTx);
							session.flush();
						}
						
						//Basvuruyu sonlandir
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", basvuruNo);
						sorguMap.put("TRX_NO", trxNo);
						sorguMap.put("DURUM", "RED");
						GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_SONLANDIR", sorguMap);
						
						//Limit talebinin durumunu guncelle
						kkLimitGuncellemeTx.setDurumKod("RED");
						session.saveOrUpdate(kkLimitGuncellemeTx);
						session.flush();
						
						//Ekrana mesaj goster
						sorguMap.clear();
						sorguMap.put("MESSAGE_NO", "4539");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR", sorguMap));
						oMap.put("RESPONSE_DATA", sorguMap.get("ERROR_MESSAGE"));
						return oMap;
					}
				}
			}

			//Devam sorgular, isleme devam edilmeyecekse cik.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_DEVAM_SORGULAR", sorguMap));
			//Kontrol
			String durumKodu = sorguMap.getString("DURUM");
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("NBSM_HATASI_MI"))) {
					sorguMap.clear();
					sorguMap.put("TRX_NO", trxNo);
					sorguMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap));
				} else {
					sorguMap.clear();
					sorguMap.put("MESSAGE_NO", "4482");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR", sorguMap));
					oMap.put("RESPONSE_DATA", sorguMap.get("ERROR_MESSAGE"));
				}
				
				return oMap;
			}
			
			//Gonder sorgular, kkb/lks sorgularini da yaparak nbsm islemlerini tamamla ve 
			//basvurunun giris asamasini tamamla.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("DURUM_KOD", durumKodu);
			sorguMap.put("LIMIT_ARTIS", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				sorguMap.clear();
				sorguMap.put("MESSAGE_NO", "4483");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_MESSAGE_OLUSTUR", sorguMap));
				oMap.put("RESPONSE_DATA", sorguMap.get("ERROR_MESSAGE"));
				return oMap;
			} else {
				sorguMap.clear();
				sorguMap.put("TRX_NO", trxNo);
				sorguMap.putAll( GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
				
		oMap.put("RESPONSE_DATA", sorguMap.get("MESSAGE"));
		return oMap;
	}
	
    /** Limit guncellenmesi yapilmak istenen karta ait kredi karti basvurusu olusturur, islem tamamlanmaz.<br>
	 * @author murat.el
	 * @since PY-7527, TY-5162
	 * @param iMap - Limit guncellemek icin alinan kart bilgileri<br>
	 *         <li>LIMIT_TRX_NO - Limit guncelleme islem numarasi
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>KART_NO - Kart numarasi
	 *         <li>URUN_TIPI - Kart urun tipi
	 *         <li>HESAP_KESIM_TARIHI - Karta ait hesap kesim tarihi
	 *         <li>OTOMATIK_ODEME_TALIMATI - Kart icin otomatik odeme tanimli mi
	 *         <li>FINANSAL_TIP - Kart finansal tipi
	 *         <li>LOGO_KOD - Kart logo kodu
	 *         <li>OTOMATIK_LIMIT_ARTSIN_MI - Limit otomatik artirilsin mi(E:Evet|H:Hayir)
	 *         <li>TALEP_EDILEN_KART_LIMITI - Istenen kart limiti
	 *         <li>AYLIK_GELIR - Aylik gelir
	 *         <li>KK_BASVURU_NO - Kredi karti basvuru numarasi
	 * @return oMap - Kredi karti basvuru bilgileri<br>
	 *         <li>BASVURU_NO - Musteri numarasi
	 *         <li>TRX_NO - Kart numarasi  
	 */ 
	@GraymoundService("BNSPR_TRN3821_KK_BASVURU_OLUSTUR")
	public static GMMap kkBasvuruOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = null;
		BigDecimal trxNo = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call PKG_TRN3821.Limit_Artis_Basvurusu_Olustur(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			int index = 1;
			stmt.setBigDecimal(index++, iMap.getBigDecimal("LIMIT_TRX_NO"));
			stmt.setBigDecimal(index++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(index++, iMap.getString("KART_NO"));
			stmt.setString(index++, iMap.getString("URUN_TIPI"));
			stmt.setString(index++, iMap.getString("HESAP_KESIM_TARIHI"));
			stmt.setString(index++, iMap.getString("OTOMATIK_ODEME_TALIMATI"));
			stmt.setString(index++, iMap.getString("FINANSAL_TIP"));
			stmt.setString(index++, iMap.getString("LOGO_KOD"));
			stmt.setString(index++, iMap.getString("OTOMATIK_LIMIT_ARTSIN_MI"));//pc_otomatik_limit_artsin
			stmt.setBigDecimal(index++, iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI"));//pn_yeni_kart_limit
			stmt.setBigDecimal(index++, iMap.getBigDecimal("AYLIK_GELIR"));//pn_aylik_gelir
			stmt.setBigDecimal(index, iMap.getBigDecimal("KK_BASVURU_NO"));
			stmt.registerOutParameter(index++, Types.NUMERIC);//BASVURU_NO
			stmt.registerOutParameter(index++, Types.NUMERIC);//TRX_NO
			stmt.execute();

			trxNo = stmt.getBigDecimal(--index);
			basvuruNo = stmt.getBigDecimal(--index);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("BASVURU_NO", basvuruNo);
		oMap.put("TRX_NO", trxNo);
		return oMap;
	}
	
    /** Basvurunun ya da belirtilen kriterlere sahip ozelliklerin
     *  LKS sorgusu sonucunda limit uygunluk kontrolunu yapar.<br>
	 * @author murat.el
	 * @since PY-7527, PY-8525
	 * @param iMap - Basvuru bilgisi<br>
	 *         <li>AKIS_TURU - Akis turu (B:Basvuru | P:Parametre)
	 *         <li>SORGU_NO - Lks sorgu numarasi
	 *         <li>BASVURU_NO - Basvuru numarasi
	 *         <li>AYLIK_GELIR - Aylik gelir bilgisi
	 *         <li>KART_LIMIT - Kart limit bilgisi
	 *         <li>TALEP_EDILEN_KART_LIMIT - Istenen yen kart limiti
	 * @return oMap - Uygunluk bilgisi<br>
	 *         <li>LKS_LIMIT_UYGUN_MU - LKS Limiti uygunluk kontrol sonucu (E:Uygun|H:Uygun Degil)
	 *         <li>LKS_LIMIT - Lks limiti
	 */
	@GraymoundService("BNSPR_TRN3821_LKS_LIMIT_UYGUN_MU")
	public static GMMap lksLimitUygunMu(GMMap iMap) {
		GMMap oMap = new GMMap();
		String lksLimitUygunMu = CreditCardServicesUtil.HAYIR;
		BigDecimal lksLimit = BigDecimal.ZERO;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TRN3821.Lks_Limiti_Uygun_Mu(?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			int i = 1;
			stmt.setString(i++, CreditCardServicesUtil.nvl(iMap.getString("AKIS_TURU"), "B"));//Default basvuru
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SORGU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("AYLIK_GELIR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KART_LIMIT"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TALEP_EDILEN_KART_LIMIT"));
			stmt.registerOutParameter(i++, Types.VARCHAR);//Default basvuru
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();
			
			lksLimit = stmt.getBigDecimal(--i);
			lksLimitUygunMu = CreditCardServicesUtil.nvl(stmt.getString(--i), lksLimitUygunMu);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("LKS_LIMIT_UYGUN_MU", lksLimitUygunMu);
		oMap.put("LKS_LIMIT", lksLimit);
		return oMap;
	}
	
    /** Limiti dusurulecek musterinin diger kart limitleri kontrol edilir<br>
	 * @author sezgi.yilmaz
	 * @since PY-7694
	 * @param iMap - Basvuru bilgisi<br>
	 *         <li>CUSTOMER_NO - Musteri numarasi
	 *         <li>CARD_NO - Kart numarasi
	 *         <li>LIMIT_AMOUNT - Yeni limit
	 * @return boolean - Musteri uygunluk bilgisi<br>
	 */
	private static boolean musteriLimitAzaltilsinMi(GMMap iMap) {
		GMMap sorguMap = new GMMap();

		try {				
			//Musteriye ait kart listesini al
			sorguMap.clear();
			sorguMap.put("CUSTOMER_NO", iMap.get("CUSTOMER_NO"));
			sorguMap.put("CARD_NO", iMap.get("CARD_NO"));
			sorguMap.put("CARD_DCI", "C");
			sorguMap.put("CARD_BANK_STATUS", "All");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", sorguMap));
			if  (!"2".equals(sorguMap.getString("RETURN_CODE"))) {
				throw new GMRuntimeException(0, sorguMap.getString("ORESULT") + " " + sorguMap.getString("RETURN_DESCRIPTION"));
			}
			
			//Musteriye ait kart var mi?
			String iTableName = "CARD_DETAIL_INFO";
			if (sorguMap.getSize(iTableName) == 0) {
				return false;
			}
			
			//Kart bilgilerini karsilastir
			for (int i = 0; i < sorguMap.getSize(iTableName); i++) {
				if ("C".equals(sorguMap.getString(iTableName, i, "CARD_DCI_AKUSTIK")) &&
						("N".equals(sorguMap.getString(iTableName, i, "CARD_STAT_CODE")) || ("G".equals(sorguMap.getString(iTableName, i, "CARD_STAT_CODE")) && "N".equals(sorguMap.getString(iTableName, i, "CARD_SUB_STAT_CODE"))))) 
				{
					if(iMap.getString("CARD_NO").equals(sorguMap.getString(iTableName, i, "CARD_NO")))
						continue;
					
					if(iMap.getBigDecimal("LIMIT_AMOUNT").compareTo(sorguMap.getBigDecimal(iTableName, i, "CARD_LIMIT")) <= 0)
						return false;				
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return true;
	}
		
	/** Otomatik limit azaltma surecinde OCEAN yeni limit ile guncellenir.<br>
	 * @author murat.el
	 * @since PY-7708
	 * @param iMap - Kart bilgisi<br>
	 *        <li>ID - Limit guncelleme islem numarasi
	 *        <li>TALEP_EDILEN_KART_LIMITI - Talep edilen kart limiti
	 *        <li>KART_NO - Limiti azaltilacak kart numarasi
	 *        <li>ACIKLAMA - Islem aciklamasi
	 * @return oMap - Islem sonuc bilgisi<br>
	 *        <li>RETURN_CODE - Islem sonuc kodu
	 *        <li>ORESULT - Islem sonuc durumu kodu
	 *        <li>RETURN_DESCRIPTION - Islem sonuc durumu acikalamasi
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_AZALT")
	public static GMMap limitAzalt(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Limit guncelleme talebini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkLimitGuncelleme kkLimitGuncelleme = (KkLimitGuncelleme) 
					session.get(KkLimitGuncelleme.class, iMap.getBigDecimal("ID"));
			if (kkLimitGuncelleme == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getString("ID"));
			}
			
			//Limit azaltma bilgileri al
			BigDecimal musteriNo = CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), kkLimitGuncelleme.getMusteriNo());
			String kartNo = CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), kkLimitGuncelleme.getKartNo());
			BigDecimal talepEdilenLimit = CreditCardServicesUtil.nvl(iMap.getBigDecimal("TALEP_EDILEN_KART_LIMITI"), kkLimitGuncelleme.getYeniKartLimit());
			BigDecimal kartLimit = kkLimitGuncelleme.getKartLimit();
			String limitGuncellemeNedeni = kkLimitGuncelleme.getLimitGuncellemeNedeni();
			
			//Kart riskini al
			sorguMap.clear();
			sorguMap.put("KART_NO", kkLimitGuncelleme.getKartNo());
			sorguMap.put("MUSTERI_NO", kkLimitGuncelleme.getMusteriNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_GET_KART_RISK", sorguMap));
			BigDecimal kartRisk = sorguMap.getBigDecimal("KART_RISK", BigDecimal.ZERO);
			if (kartRisk == null) {
				CreditCardServicesUtil.raiseGMError("330", "Kart Risk");
			}
			
			//Kart riski ile talep edilen limit tutarli mi? Degilse sms gonder ve akisi sonlandir
			int mesajNo = 5223;
			if (talepEdilenLimit.compareTo(kartRisk) < 0) {
				mesajNo = 5225;
				if (kartLimit.compareTo(kartRisk) > 0) {
					mesajNo = 5224;
				}

				//Limit basvurusu durum guncelle
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "G");
				sorguMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				sorguMap.put("ID", kkLimitGuncelleme.getId());
				sorguMap.put("DURUM_KOD", "IPTAL");
				sorguMap.put("ONCEKI_DURUM_KOD", kkLimitGuncelleme.getDurumKod());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
				
				//SMS gonder
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriNo);
				sorguMap.put("MESAJ_NO", mesajNo);
				sorguMap.put("TALEP_EDILEN_LIMIT", talepEdilenLimit);
				GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_AZALTIM_SMS_GONDER", sorguMap);
				
				return oMap;
			} 
			
			//Islem aciklamasini yoksa al
			String aciklama = iMap.getString("ACIKLAMA");
			if (StringUtils.isBlank(aciklama)) {
				//Limit azaltma nedenini al
				sorguMap.clear();
				sorguMap.put("KOD", "KK_LIMIT_GUNCELLEME_NEDENI");
				sorguMap.put("KEY1", kkLimitGuncelleme.getLimitGuncellemeNedeni());
				if (CreditCardServicesUtil.EVET.equals(kkLimitGuncelleme.getLimitArttiMi())) {
					sorguMap.put("KEY2", "A");
				} else {
					sorguMap.put("KEY2", "Z");
				}
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap));
				aciklama = sorguMap.getString("TEXT");
			} 
			
			
			
			//Limit azalt
			sorguMap.clear();
			sorguMap.put("LIMIT_AMOUNT", talepEdilenLimit);
			sorguMap.put("CARD_NO", kartNo);
			sorguMap.put("CUSTOMER_NO", musteriNo);
			sorguMap.put("MEMO_TEXT", aciklama);
			sorguMap.put("LIMIT_UPDATE_REASON_CODE", limitGuncellemeNedeni);
			//Limiti azalt
			if(musteriLimitAzaltilsinMi(sorguMap))
			{
				logger.debug("BNSPR_OCEAN_UPDATE_CUSTOMER_LIMIT INPUT : " + sorguMap.toString());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CUSTOMER_LIMIT", sorguMap));
				logger.debug("BNSPR_OCEAN_UPDATE_CUSTOMER_LIMIT OUTPUT : " + oMap.toString());
				if("2".equals(oMap.getString("RETURN_CODE")))
				{
					logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT INPUT : " + sorguMap.toString());
					oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CARD_LIMIT", sorguMap));
					logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT OUTPUT : " + oMap.toString());	
				}
			}
			else
			{	
				logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT INPUT : " + sorguMap.toString());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CARD_LIMIT", sorguMap));
				logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT OUTPUT : " + oMap.toString());
			}

			oMap.put("RESPONSE_DATA", oMap.getString("ORESULT") + " " + oMap.getString("RETURN_DESCRIPTION"));
			if  (!"2".equals(oMap.getString("RETURN_CODE"))) {
				throw new GMRuntimeException(0, oMap.getString("ORESULT") + " " + oMap.getString("RETURN_DESCRIPTION"));
			}
			
			//Limit basvurusu durum guncelle
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "G");
			sorguMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
			sorguMap.put("ID", kkLimitGuncelleme.getId());
			sorguMap.put("DURUM_KOD", "ONAY");
			sorguMap.put("ONCEKI_DURUM_KOD", kkLimitGuncelleme.getDurumKod());
			sorguMap.put("ONAYLANAN_KART_LIMIT", talepEdilenLimit);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
			
			//SMS gonder
			sorguMap.clear();
			sorguMap.put("MUSTERI_NO", musteriNo);
			sorguMap.put("MESAJ_NO", mesajNo);
			sorguMap.put("TALEP_EDILEN_LIMIT", talepEdilenLimit);
			GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_AZALTIM_SMS_GONDER", sorguMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Otomatik limit artis sureci tamamlandiktan sonra yeni limit bilgisi 
	 * ve alinan diger bilgiler OCEAN paketinde guncellenir.<br>
	 * @author murat.el
	 * @since PY-7527
	 * @param iMap - Basvuru bilgisi<br>
	 * 		   <li>BASVURU_NO - Kredi karti basvuru numarasi
	 * 		   <li>ISLEM_NO - Islem numarasi
	 * 		   <li>DURUM_KOD - Kredi karti durum kodu
	 * 		   <li>MUSTERI_NO - Musteri numarasi
	 * 		   <li>EVAM_MI - Evam tarafindan mi cagriliyor(E:Evet|H:Hayir)
	 * @return oMap - Islem sonuc bilgisi<br>
	 *         <li>RESPONSE - Islem sonuc kodu
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_KK_CALL_OCEAN_LIMIT")
	public static GMMap callOceanLimit(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		
		try {
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("ISLEM_NO"))) {
				iMap.put("ISLEM_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
			}
			if (StringUtils.isBlank(iMap.getString("DURUM_KOD"))) {
				iMap.put("DURUM_KOD", "BASIM");
			}
			
			//KkBasvurusu var mi?
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (kkBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getString("BASVURU_NO"));
			}
			session.refresh(kkBasvuru);
			//Limit artis talebini al
			String islemYeri = null;
			String durumKod = null;
			BigDecimal limitId = null;
			KkLimitGuncellemeTx kkLimitGuncellemeTx = null;
			KkLimitGuncelleme kkLimitGuncelleme = (KkLimitGuncelleme) 
					session.createCriteria(KkLimitGuncelleme.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
					.add(Restrictions.eq("limitArttiMi", CreditCardServicesUtil.EVET))
					.uniqueResult();
			if (kkLimitGuncelleme == null) {
				kkLimitGuncellemeTx = (KkLimitGuncellemeTx) 
						session.createCriteria(KkLimitGuncellemeTx.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.add(Restrictions.eq("limitArttiMi", CreditCardServicesUtil.EVET))
						.uniqueResult();
				if (kkLimitGuncellemeTx == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getString("BASVURU_NO"));
				} else {
					islemYeri = kkLimitGuncellemeTx.getIslemYeri();
					durumKod = kkLimitGuncellemeTx.getDurumKod();
					limitId = kkLimitGuncellemeTx.getId();							
				}
			} else {
				islemYeri = kkLimitGuncelleme.getIslemYeri();
				durumKod = kkLimitGuncelleme.getDurumKod();
				limitId = kkLimitGuncelleme.getId();
			}
			
			//Senaryoya gore islemleri baslat
			String sonrakiDurumKod = StringUtils.EMPTY;
			boolean lksYapilsinMi = Boolean.FALSE;
			boolean limitGuncellensinMi = Boolean.FALSE;
			if (EVAM_LIMIT_SENARYO_2.equals(islemYeri)) {
				if ("KREDI_KARTI".equals(durumKod)) {
					lksYapilsinMi = Boolean.FALSE;
					limitGuncellensinMi = Boolean.FALSE;
					sonrakiDurumKod = "LIMIT_JOB";
					oMap.put("RESPONSE_DATA", EVAM_LIMIT_SENARYO_2 + " icin EVAM onay bekleniyor");
				} else if ("LIMIT_JOB".equals(durumKod)) {
					lksYapilsinMi = Boolean.TRUE;
					limitGuncellensinMi = Boolean.TRUE;
					sonrakiDurumKod = "ONAY";
					oMap.put("RESPONSE_DATA", EVAM_LIMIT_SENARYO_2 + " icin islem tamamlandi");
				}
			} else if (EVAM_LIMIT_SENARYO_1.equals(islemYeri)) {
				if ("KREDI_KARTI".equals(durumKod)) {
					lksYapilsinMi = Boolean.TRUE;
					limitGuncellensinMi = Boolean.FALSE;
					sonrakiDurumKod = "LIMIT_JOB";
					oMap.put("RESPONSE_DATA", EVAM_LIMIT_SENARYO_1 + " icin EVAM onay bekleniyor");
				} else if ("LIMIT_JOB".equals(durumKod)) {
					lksYapilsinMi = Boolean.FALSE;
					limitGuncellensinMi = Boolean.TRUE;
					sonrakiDurumKod = "ONAY";
					oMap.put("RESPONSE_DATA", EVAM_LIMIT_SENARYO_1 + " icin islem tamamlandi");
				}
			} else {
				lksYapilsinMi = Boolean.TRUE;
				limitGuncellensinMi = Boolean.TRUE;
				sonrakiDurumKod = "ONAY";
				oMap.put("RESPONSE_DATA", islemYeri + " icin islem tamamlandi");
			}
			
			//LKS tahsis islemini gerceklestir, islem basarisizsa jobda bekletilir.
			String islemAciklama = StringUtils.EMPTY;
			if (lksYapilsinMi) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.putAll(limitLksYap(sorguMap));
				//Kontrol
				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) { 
					oMap.put("RESPONSE_DATA", sorguMap.getString("RESPONSE_DATA"));
					return oMap;
				}
				
				//Kart tarafini guncelle. 
				//Guncelleme islemi basarili ise basvurunun durumunu acik olarak set et, 
				//Basarisiz ise job durumunda beklet.
				if (limitGuncellensinMi) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
					sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
					sorguMap.putAll(updateCardLimit(sorguMap));
					//Kontrol
					if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
						oMap.put("RESPONSE_DATA", sorguMap.getString("RESPONSE_DATA"));
						return oMap;
					} else {
						islemAciklama = sorguMap.getString("RESPONSE_DATA");
					}
				}
			} else {
				//Kart tarafini guncelle. 
				//Guncelleme islemi basarili ise basvurunun durumunu acik olarak set et, 
				//Basarisiz ise job durumunda beklet.
				if (limitGuncellensinMi) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
					sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
					sorguMap.putAll(updateCardLimit(sorguMap));
					//Kontrol
					if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
						oMap.put("RESPONSE_DATA", sorguMap.getString("RESPONSE_DATA"));
						return oMap;
					} else {
						islemAciklama = sorguMap.getString("RESPONSE_DATA");
					}
				}
			}
			
			//logger.info("BNSPR_KK_CALL_OCEAN_LIMIT service. REC_OWNER: " + BnsprOceanCommonFunctions.getUser());//ADCSession.getString("USER_NAME")
			//Limit guncelleme islemi tamamen sonlandi ise sms gonder, havuzdan islem yapilyorsa, havuz durumunu guncelle
			if ("ONAY".equals(sonrakiDurumKod)) {  
				//KK Basvurunun durumu acik yapilir ve tarihceye kayit atilir.
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				sorguMap.put("DURUM_KOD", "ACIK");
				sorguMap.put("ISLEM_ACIKLAMA", islemAciklama);
				sorguMap.put("TARIHCE_AKSIYON", "E");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap));
				
				//Limit Durum guncelle
				sorguMap.clear();

				// Islem webden limit arttirim olarak geliyorsa kkLimitGuncellemeTx tablosunu guncelle
//				if(BnsprOceanCommonFunctions.getUser().equals("INTNG")){
//					sorguMap.put("ISLEM_FLAG", "E");
//					logger.info("BNSPR_KK_CALL_OCEAN_LIMIT service. ISLEM_FLAG: E");
//				}else{
//					sorguMap.put("ISLEM_FLAG", "G");
//					logger.info("BNSPR_KK_CALL_OCEAN_LIMIT service. ISLEM_FLAG: G");
//				}
				sorguMap.put("ISLEM_FLAG", "G");
				sorguMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				sorguMap.put("ID", limitId);
				sorguMap.put("DURUM_KOD", sonrakiDurumKod);
				sorguMap.put("ONCEKI_DURUM_KOD", durumKod);
				sorguMap.put("ONAYLANAN_KART_LIMIT", kkBasvuru.getOnaylananKartLimiti());				
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));
				
				//Havuz kaydini bul
				KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
						session.createCriteria(KkTopluBasvuruHavuz.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.add(Restrictions.eq("kkLimitGuncellemeID", limitId))
						.uniqueResult();
				if (kkTopluBasvuruHavuz != null) {
					//Havuz kaydini guncelle
					sorguMap.clear();
					sorguMap.put("ID", limitId);
					sorguMap.put("DURUM_KOD", "4");//Islem onaylandi
					sorguMap.put("DURUM_ACIKLAMA", "10");//Islem onaylandi
					sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
					sorguMap.put("SENARYO", islemYeri);
					sorguMap.put("AKIS_TURU", "L");//Limit guncelleme
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_DURUM_GUNCELLE", sorguMap));
					//Onaylanan kart limiti guncelle
					sorguMap.clear();
					sorguMap.put("ID", kkTopluBasvuruHavuz.getId());
					sorguMap.put("ONAYLANAN_LIMIT", kkBasvuru.getOnaylananKartLimiti());
					GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_GUNCELLE", sorguMap);
				} else {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("LKS_RED_MI", CreditCardServicesUtil.HAYIR);
					GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_DEGISIM_SMS_GONDER", sorguMap);
				}
			} else if ("LIMIT_JOB".equals(sonrakiDurumKod)) {
				//Limit Durum guncelle
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "G");
//				if(BnsprOceanCommonFunctions.getUser().equals("INTNG")){
//					sorguMap.put("ISLEM_FLAG", "E");
//					logger.info("BNSPR_KK_CALL_OCEAN_LIMIT service. ISLEM_FLAG: E");
//				}else{
//					sorguMap.put("ISLEM_FLAG", "G");
//					logger.info("BNSPR_KK_CALL_OCEAN_LIMIT service. ISLEM_FLAG: G");
//				}
				sorguMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				sorguMap.put("ID", limitId);
				sorguMap.put("DURUM_KOD", sonrakiDurumKod);
				sorguMap.put("ONCEKI_DURUM_KOD", durumKod);
				sorguMap.put("ONAYLANAN_KART_LIMIT", kkBasvuru.getOnaylananKartLimiti());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
				
				//Havuz kaydini bul
				KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
						session.createCriteria(KkTopluBasvuruHavuz.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.add(Restrictions.eq("kkLimitGuncellemeID", limitId))
						.uniqueResult();
				if (kkTopluBasvuruHavuz != null) {
					//Havuz kaydini guncelle
					sorguMap.clear();
					sorguMap.put("ID", limitId);
					sorguMap.put("DURUM_KOD", "5");//Islem onay bekliyor
					sorguMap.put("DURUM_ACIKLAMA", "16");//Islem onay bekliyor
					sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
					sorguMap.put("SENARYO", islemYeri);
					sorguMap.put("AKIS_TURU", "L");//Limit guncelleme
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_DURUM_GUNCELLE", sorguMap));
				}
			}
			
			//Islem basarili
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("EVAM_MI"))) {
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "BIREYSEL_KREDILER_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "EVAM Limit Artis Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", e.getMessage());
				GMServiceExecuter.executeAsync("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
			
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Otomatik limit artis sureci tamamlandiktan sonra yeni limit bilgisi icin LKS Tahsisi yapilir.<br>
	 * @author murat.el
	 * @since PY-8975
	 * @param iMap - Basvuru bilgisi<br>
	 * 		   <li>BASVURU_NO - Kredi karti basvuru numarasi
	 * 		   <li>ISLEM_NO - Islem numarasi
	 * 		   <li>DURUM_KOD - Kredi karti durum kodu
	 *         <li>MUSTERI_NO - Musteri numarasi
	 * @return oMap - Islem sonuc bilgisi<br>
	 *         <li>RESPONSE - Islem sonuc kodu
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_LKS_YAP")
	public static GMMap limitLksYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		//Islem sonucunu basarisiz olarak set et
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//1.LKS sorgusu icin datalari al, kayit bulunamazsa hata ver
			String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'04') }";
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sorguMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, sorguMap.getBigDecimal("BASVURU_NO"));
			if (sorguMap.isEmpty()){
				throw new Exception("Kayit Bulunamadi");
			}
			
			/*lks ek tahsis sorgu yap */

			sorguMap.put("SOYADI", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "SOYADI"));
			sorguMap.put("MUSTERI_NO", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "MUSTERI_NO"));
			sorguMap.put("IKINCI_ADI", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "IKINCI_ADI"));
			sorguMap.put("BABA_ADI", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "BABA_ADI"));
			sorguMap.put("TCKN", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "TCKN"));
			sorguMap.put("BASVURU_NO", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "BASVURU_NO"));
			sorguMap.put("ILK_ADI", sorguMap.getString("GIDEN_SORGU_DETAY", 0, "ILK_ADI"));
			sorguMap.put("MANUEL_SORGU", "E");
			sorguMap.put("SORGU_TIPI", "02");
			GMServiceExecuter.executeNT("BNSPR_QRY3893_LKS_MANUEL_TAHSIS_SORGU_YAP", sorguMap);

			/*TYATLAS-67 teftis bulgusu icin eklendi*/
			//GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_TX_ONAY", iMap);
			
			/*lks ek tahsis sorgu */
			//2.LKS sorgusu yap, LKS basarili ise islemi sonlandir, basarisiz ise LKS job adiminda beklet.
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_LKS_ONLINE_EK_TAHSIS_YAP", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("LKS_YAPILDIMI")) && 
					(CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE")) || "5".equals(sorguMap.getString("RESPONSE")))) {
				//Tekrar limit kontrolu yapilsin isteniyorsa
				if ("5".equals(sorguMap.getString("RESPONSE"))) {
					//Basvuru uzerinden yeni bir tx olustur
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3806_GET_KK_TRX_NO", sorguMap));
					BigDecimal kkTrxNo = sorguMap.getBigDecimal("KK_TRX_NO");
					//Basvuruyu nbsm akisina sok
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("TRX_NO", kkTrxNo);
					sorguMap.put("UST_ISLEM_TRX_NO", iMap.get("ISLEM_NO"));
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DURUM_KOD", "BASIM");
					sorguMap.put("LIMIT_ARTIS", CreditCardServicesUtil.HAYIR);
					sorguMap.put("MANUEL_SORGU", "E");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", sorguMap));
					if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEVAM")) && "BASIM".equals(sorguMap.getString("DURUM"))) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("ISLEM_KODU", iMap.get("ISLEM_KODU"));
						sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
						sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
						sorguMap.put("MANUEL_SORGU", CreditCardServicesUtil.EVET);
						oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN_SAVE", sorguMap));
					} else {
						oMap.put("MESSAGE", sorguMap.get("MESSAGE"));
					}
					
					return oMap;
				} else {
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
				}
			} else {
				//Tarihcede yazilacak hata mesajini goruntule
				StringBuilder hataMesaji = new StringBuilder();
				hataMesaji.append("LksYapildiMi:");
				hataMesaji.append(sorguMap.getString("LKS_YAPILDIMI"));
				hataMesaji.append("-");
				hataMesaji.append("Response:");
				hataMesaji.append(sorguMap.getString("RESPONSE"));
				hataMesaji.append("-");
				hataMesaji.append("ResponseMessage:");
				hataMesaji.append(sorguMap.getString("RESPONSE_MESSAGE"));
				oMap.put("RESPONSE_DATA", hataMesaji.toString());
				
				//Tarihce aksiyonu al
				sorguMap.clear();
				if ("BASIM".equals(iMap.getString("DURUM_KOD"))) {
					sorguMap.put("TARIHCE_AKSIYON", "G");
				} else if ("OCAEN_JOB".equals(iMap.getString("DURUM_KOD"))) {
					sorguMap.put("TARIHCE_AKSIYON", "E");
				}
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("DURUM_KOD", "LKS_JOB_2");
				sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				sorguMap.put("ISLEM_ACIKLAMA", hataMesaji.toString());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	//I:BASVURU_NO, ISLEM_NO, DURUM_KOD
	//O:RESPONSE, RESPONSE_DATA
	/** Otomatik limit artis sureci tamamlandiktan sonra yeni limit bilgisi ile OCEAN beslenir.<br>
	 * @author murat.el
	 * @since PY-8975
	 * @param iMap - Basvuru bilgisi<br>
	 * 		   <li>BASVURU_NO - Kredi karti basvuru numarasi
	 * 		   <li>ISLEM_NO - Islem numarasi
	 * 		   <li>DURUM_KOD - Kredi karti durum kodu
	 * @return oMap - Islem sonuc bilgisi<br>
	 *         <li>RESPONSE - Islem sonuc kodu
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_UPDATE_CARD_LIMIT")
	public static GMMap updateCardLimit(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		//Islem ilk basta basarisiz oalrak set edilir.
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
 		
		try {
			//Islem aciklamasini(Limiti guncelleme nedenini) al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkLimitGuncellemeTx kkLimitGuncellemeTx = (KkLimitGuncellemeTx) 
					session.createCriteria(KkLimitGuncellemeTx.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
					.addOrder(Order.desc("txNo"))
					.setMaxResults(1)
					.uniqueResult();
			if (kkLimitGuncellemeTx != null) {
				sorguMap.clear();
				sorguMap.put("KOD", "KK_LIMIT_GUNCELLEME_NEDENI");
				sorguMap.put("KEY1", kkLimitGuncellemeTx.getLimitGuncellemeNedeni());
				if (CreditCardServicesUtil.EVET.equals(kkLimitGuncellemeTx.getLimitArttiMi())) {
					sorguMap.put("KEY2", "A");
				} else {
					sorguMap.put("KEY2", "Z");
				}
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap));
				iMap.put("MEMO_TEXT", sorguMap.getString("TEXT"));
				iMap.put("LIMIT_UPDATE_REASON_CODE", kkLimitGuncellemeTx.getLimitGuncellemeNedeni()); ;
			}
			
			//Limit guncelleme bilgilerini al
			conn = DALUtil.getGMConnection();
			query = "{? = call PKG_KK_BASVURU.Get_Limit_Info_For_Ocean(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			//Sonuclari al
			rSet = (ResultSet) stmt.getObject(1);
			iMap.putAll(DALUtil.rSetMap(rSet));
			//Guncellenmek istenen limit musteri limitinden buyukse, musteri limitini de guncelle. 
			if (iMap.getBigDecimal("LIMIT_AMOUNT").compareTo(iMap.getBigDecimal("CUSTOMER_LIMIT")) > 0) {
				logger.debug("BNSPR_OCEAN_UPDATE_CUSTOMER_LIMIT INPUT : " + iMap.toString());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CUSTOMER_LIMIT", iMap));
				logger.debug("BNSPR_OCEAN_UPDATE_CUSTOMER_LIMIT OUTPUT : " + oMap.toString());
				//Musteri limiti guncellendi ise, kart limitini de guncelle.
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
					logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT INPUT : " + iMap.toString());
					oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CARD_LIMIT", iMap));
					logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT OUTPUT : " + oMap.toString());
				} 
			} else {
				logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT INPUT : " + iMap.toString());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CARD_LIMIT", iMap));
				logger.debug("BNSPR_OCEAN_UPDATE_CARD_LIMIT OUTPUT : " + oMap.toString());
			}
			
			//Kart tarafi islem sonucuna gore basvuru durumunu guncelle.
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
				oMap.put("RESPONSE_DATA", oMap.getString("ORESULT") + "-" + oMap.getString("RETURN_DESCRIPTION"));
			} else {
				//Onceden yapilmis lks tahsis islemi iptal edilir.
				GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_TAHSIS_IPTAL", sorguMap);
				//Basimsa tarihceyi guncelle, yoksa yeni kayit at.
				sorguMap.clear();
				if ("BASIM".equals(iMap.getString("DURUM_KOD"))) {
					sorguMap.put("TARIHCE_AKSIYON", "G");
				} else if ("LKS_JOB_2".equals(iMap.getString("DURUM_KOD"))) {
					sorguMap.put("TARIHCE_AKSIYON", "E");
				}
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				sorguMap.put("DURUM_KOD", "OCEAN_JOB");
				sorguMap.put("ISLEM_ACIKLAMA", oMap.getString("ORESULT") + "-" + oMap.getString("RETURN_DESCRIPTION"));
				GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
				//Alinan hata mail atilir.
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				oMap.put("RESPONSE_DATA", mailHata.toString());
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "KK Ocean Update Limit Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Limit degisim islemi tamamlandiginda(RED/ONAY) musteriye sms gonderilir.<br>
	 * @author murat.el
	 * @since 04.03.2014
	 * @param iMap - Basvuru bilgileri<br>
	 *         <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *         <li>LKS_RED_MI - Lks sebebiyle mi red edildi(E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_DEGISIM_SMS_GONDER")
	public static GMMap limitDegisimSmsGonder(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_TRN3821.Limit_Sms_Bilgisi(?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("LKS_RED_MI"));
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.registerOutParameter(4, Types.VARCHAR);
            stmt.execute();
            //Bilgileri al
            String mesaj = stmt.getString(3);
            String cepNo = stmt.getString(4);
            
            //SMS gonder
			GMMap sorguMap = new GMMap();
			sorguMap.put("GIDEN_MESAJ", mesaj);
			sorguMap.put("CEP_NO", cepNo);
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static String maskCardNumber(String cardNumber) {
		if (StringUtils.isNotBlank(cardNumber)) {
			return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})", "$1 **** **** $3");
		} else {
			return cardNumber;
		}
	}
	
	//--------------------------------------------------------------------------------------------
	//---------------------------------------------------------- DIS SISTEM - INTERNET BANKACILIGI
	//--------------------------------------------------------------------------------------------
	/** Internet bankaciligindan alinan limit degisim talebini alarak akisi baslatir.<br>
	 * @author murat.el
	 * @since PY-7526
	 * @param iMap - Islem bilgileri<br>
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>KART_NO - Kart numarasi
	 *        <li>TALEP_EDILEN_KART_LIMITI - Istenen yeni kart limiti
	 *        <li>AYLIK_GELIR - Aylik gelir bilgisi
	 *        <li>OTOMATIK_LIMIT_ARTSIN_MI - Otomatik olarak limit artsin mi?(true|false)
	 *        <li>LIMIT_GUNCELLEME_NEDENI - Limit degisim neden kodu
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_DEGISTIR")
	public static GMMap limitDegistir(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//1.Musteri - Kart Var mi? Varsa datasini al
			sorguMap.clear();
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("KART_NO", iMap.get("KART_NO"));
			sorguMap.put("MAC_LIMITI_KONTROL_EDILSIN_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIST", sorguMap));
			//Kontrol
			if (sorguMap.get("KART_LIST") == null || sorguMap.getSize("KART_LIST") < 1) {
				CreditCardServicesUtil.raiseGMError("4994");
			}
			
			//Gerekli datayi al
			BigDecimal kartLimit = sorguMap.getBigDecimal("KART_LIST", 0, "KART_LIMIT");
			BigDecimal kartRisk = sorguMap.getBigDecimal("KART_LIST", 0, "KART_RISK");
			BigDecimal musteriLimit = sorguMap.getBigDecimal("KART_LIST", 0, "MUSTERI_LIMIT");
			
			//2.Limit degisim talebini kaydet
			//Islem numarasi al
			sorguMap.clear();
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap).getBigDecimal("TRX_NO");
			//Alinan datayi tx tablosuna kaydet
			sorguMap.clear();
			sorguMap.put("ISLEM_FLAG", "E");//Yeni talep
			sorguMap.put("TRX_NO", trxNo);
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("KART_NO", iMap.get("KART_NO"));
			sorguMap.put("KART_LIMIT", kartLimit);
			sorguMap.put("KART_RISK", kartRisk);
			sorguMap.put("TALEP_EDILEN_KART_LIMITI", iMap.get("TALEP_EDILEN_KART_LIMITI"));
			sorguMap.put("AYLIK_GELIR", iMap.get("AYLIK_GELIR"));
			sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", iMap.get("OTOMATIK_LIMIT_ARTSIN_MI"));
			sorguMap.put("LIMIT_GUNCELLEME_NEDENI", iMap.get("LIMIT_GUNCELLEME_NEDENI"));
			sorguMap.put("MUSTERI_LIMIT", musteriLimit);
			sorguMap.put("ISLEM_YERI", "3821");//Ekrandan gelen akis
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_GUNCELLE", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3821_SORGULA_LOG")
	public static GMMap sorgulaLog(GMMap iMap) {
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_TRN3821_TARIHCE")
	public static GMMap getTffTarihce(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3821.get_tarihce(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//I:BASVURU_NO, SONRAKI_DURUM_KODU, LKS_RED_MI, URUM_GUNCELLE
	@GraymoundService("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE")
	public static GMMap limitDurumGuncelleByKkBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			BigDecimal limitId = null;
			String islemYeri = StringUtils.EMPTY;
			//Basvuru nodan limit guncelleme kaydini bul
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkLimitGuncelleme kkLimitGuncelleme = (KkLimitGuncelleme)
					session.createCriteria(KkLimitGuncelleme.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
					.uniqueResult();
			if (kkLimitGuncelleme == null) {
				KkLimitGuncellemeTx kkLimitGuncellemeTx = (KkLimitGuncellemeTx)
						session.createCriteria(KkLimitGuncellemeTx.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.uniqueResult();
				if (kkLimitGuncellemeTx == null) {
					return oMap;
				} else {
					kkLimitGuncellemeTx.setDurumKod(iMap.getString("SONRAKI_DURUM_KODU"));
					session.saveOrUpdate(kkLimitGuncellemeTx);
					session.flush();
					
					limitId = kkLimitGuncellemeTx.getId();
					islemYeri = kkLimitGuncellemeTx.getIslemYeri();
				}
			} else {
				//Durum guncelle
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "G");
				sorguMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				sorguMap.put("ID", kkLimitGuncelleme.getId());
				sorguMap.put("DURUM_KOD", iMap.get("SONRAKI_DURUM_KODU"));
				sorguMap.put("ONCEKI_DURUM_KOD", kkLimitGuncelleme.getDurumKod());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE_OR_UPDATE", sorguMap));

				String screenCode = iMap.getString("SCREEN_CODE");
				if(!StringUtils.isEmpty(screenCode) && screenCode != null){
					sorguMap.put("SCREEN_CODE", screenCode);
				}
				
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
				
				limitId = kkLimitGuncelleme.getId();
				islemYeri = kkLimitGuncelleme.getIslemYeri();
			}
 
			//Sms gonder, havuzdan islem yapilyorsa, havuz durumunu guncelle
			//Havuz kaydini bul
			KkTopluBasvuruHavuz kkTopluBasvuruHavuz = (KkTopluBasvuruHavuz) 
					session.createCriteria(KkTopluBasvuruHavuz.class)
					.add(Restrictions.eq("kkLimitGuncellemeID", limitId))
					.uniqueResult();
			if (kkTopluBasvuruHavuz != null) {
				//Havuz kaydini guncelle
				sorguMap.clear();
				sorguMap.put("ID", kkTopluBasvuruHavuz.getId());
				//Su an sadece red icin calisiyor
				if ("RED".equals(iMap.getString("SONRAKI_DURUM_KODU")) ||
						"IPTAL".equals(iMap.getString("SONRAKI_DURUM_KODU"))) {
					sorguMap.put("DURUM_KOD", "2");//Islem basarisiz
					sorguMap.put("DURUM_ACIKLAMA", "12");//Banka kriterleri nedeni ile red/iptal edildi
				}
				sorguMap.put("KODDAN_ACIKLAMA_AL", CreditCardServicesUtil.EVET);
				sorguMap.put("SENARYO", islemYeri);
				sorguMap.put("AKIS_TURU", "L");//Limit guncelleme
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TOPLU_BASVURU_DURUM_GUNCELLE", sorguMap));
			} else {
				//Limit guncelleme islemi tamamen sonlandi ise sms gonder
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("LKS_RED_MI", iMap.get("LKS_RED_MI"));
				GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_DEGISIM_SMS_GONDER", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	/** Kredi karti istenilen TFF basvurularinda ESGM sorgusu yapar.
    *
	 * @author murat.el
	 * @since PY-9423
	 * @param iMap - Esgm sorgu parametreleri
	 *         <li>BASVURU_NO
	 *         <li>TCKN
	 *         <li>MUSTERI_NO
	 *         <li>CAPTCHA
	 *         <li>GUVENLIK_KODU
	 *         <li>CAPTCHA_DOGRULANSIN_MI
	 *         <li>ESGM_SORGU_YAPILSIN_MI
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE
	 *         <li>RESPONSE_DATA
	 */
	@GraymoundService("BNSPR_TRN3821_ESGM_SORGU")
	public static GMMap esgmSorgu(GMMap iMap) {
		GMMap oMap = new GMMap();		

		try {
			//Parametre kontrolu
			String tcKimlikNo = iMap.getString("TCKN");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			if (StringUtils.isBlank(tcKimlikNo) && musteriNo == null) {
				CreditCardServicesUtil.raiseGMError("330", "Tc Kimlik No ya da Musteri No");
			}
			
			//Musteriden kimlik bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			GnlMusteriKimlik gnlMusteriKimlik = null;
			if (musteriNo != null) {
				GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, musteriNo);
				if (gnlMusteri != null) {
					tcKimlikNo = gnlMusteri.getTcKimlikNo();
					gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, gnlMusteri.getMusteriNo());
				}
			} else {
				GnlMusteri gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class)
						.add(Restrictions.eq("tcKimlikNo", tcKimlikNo))
						.uniqueResult();
				if (gnlMusteri != null) {
					musteriNo = gnlMusteri.getMusteriNo();
					gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, gnlMusteri.getMusteriNo());
				}
			}
			//Musteri bilgileri alindi mi?
			if (gnlMusteriKimlik == null) {
				CreditCardServicesUtil.raiseGMError("4232");
			}
			//Sorgula
			GMMap sorguMap = new GMMap();
			sorguMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
			sorguMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
			sorguMap.put("TCKN", tcKimlikNo);
			sorguMap.put("IL_KODU", gnlMusteriKimlik.getNufIlKod());
			sorguMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(gnlMusteriKimlik.getDogumTarihi()));
			sorguMap.put("CILT_NO", gnlMusteriKimlik.getNufCiltNo());
			sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			//Guvenlik kodu dogrulamasi
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("CAPTCHA_DOGRULANSIN_MI"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_SOLVE_CAPTCHA", sorguMap));
				//Sorgu Kontrol
				if ("0".equals(oMap.getString("RESPONSE"))) {
					oMap.put("RESPONSE", 0);
					oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));
					return oMap;
				}
			}
			//Esgm sorgusu
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("ESGM_SORGU_YAPILSIN_MI"))) {
				ADCSession.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_PARSE", sorguMap);
				ADCSession.remove("BASVURU_NO");
			}

			oMap.put("RESPONSE", 2);
			oMap.put("RESPONSE_DATA", "");
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3821_LIMIT_GUNCELLE")
	public static GMMap limitGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Bilgileri kaydet
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SAVE", iMap));
			//Bilgileri kontrol et
			sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_AFTER_CONTROL", sorguMap));
			//Limit degisim akisini baslat
			sorguMap.clear();
			sorguMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
			sorguMap.put("KK_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIMIT_DEGISIM_AKIS", sorguMap));
			//Akis basarili sekilde bitti ise islemi sonlandir
			sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_SEND_TRANSACTION", sorguMap));
			//Eger limit artis flagi degisti ise limit artis flagini ocean tarafinda guncelle
			if (iMap.getBoolean("OTOMATIK_LIMIT_ARTSIN_MI") != iMap.getBoolean("ONCEKI_OTOMATIK_LIMIT_ARTSIN_MI")) {
				sorguMap.clear();
				sorguMap.put("KART_NO", iMap.get("KART_NO"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("GUNCELLEME_TIPI", "K");//TODO ne zaman musteri olur
				sorguMap.put("OTOMATIK_LIMIT_ARTSIN_MI", iMap.get("OTOMATIK_LIMIT_ARTSIN_MI"));
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_OTOMATIK_LIMIT_ARTIS_FLAG_GUNCELLE", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen musteri tipi mac limitli mi?
    *
	 * @author murat.el
	 * @since PY-9701
	 * @param iMap - Esgm sorgu parametreleri
	 *         <li>MUSTERI_TIP - Musteri tipi
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi(E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu
	 *         <li>MAC_LIMITLI_MI - Mac limitli musteri mi(E:Evet|H:Hayir)
	 *         <li>MAC_LIMITI_ARTIRILABILIR_MI
	 */
	@GraymoundService("BNSPR_TRN3821_MUSTERI_TIPI_MAC_LIMITLI_MI")
	public static GMMap maclimitliMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("MAC_LIMITLI_MI", CreditCardServicesUtil.HAYIR);
		oMap.put("MAC_LIMITI_ARTIRILABILIR_MI", CreditCardServicesUtil.HAYIR);

		try {
			//Mac limitli mi?
			sorguMap.clear();
			sorguMap.put("KOD", "KK_MAC_LIMIT_MUSTERI_TIPI");
			sorguMap.put("KEY", iMap.get("MUSTERI_TIP"));
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
				oMap.put("MAC_LIMITLI_MI", CreditCardServicesUtil.EVET);
				//Mac limitlilere artis yapilabilir mi?
				sorguMap.clear();
				sorguMap.put("PARAMETRE", "KK_MAC_LIMIT_ARTIS_VAR_MI");
				sorguMap.putAll(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEGER"))) {
					oMap.put("MAC_LIMITI_ARTIRILABILIR_MI", CreditCardServicesUtil.EVET);
				} else {
					//Mac limitliler icin limit artis islemi yapilamaz.
					if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
						CreditCardServicesUtil.raiseGMError("4899");
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlerle musteri/karta ait otomatik limit artirim flagini gunceller.
     *
	 * @author murat.el
	 * @since PY-10099
	 * @param iMap - Otomatil limit artis icin gerekli paramtreler
	 *         <li>KART_NO - Kart no
	 *         <li>MUSTERI_NO - Musteri no
	 *         <li>GUNCELLEME_TIPI - Guncellenecek data (M:Musteri, K:Kart, H:Hepsi)
	 *         <li>OTOMATIK_LIMIT_ARTSIN_MI - Limit otomatik olarak arttirilabilsin mi? (true:Evet|false:Hayir)
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi(E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE - Islem basarili mi?(2:Evet|0:Hayir)
	 *         <li>RESPONSE_DATA - Islem aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3821_OTOMATIK_LIMIT_ARTIS_FLAG_GUNCELLE")
	public static GMMap otomatikLimitArtisFlagGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Guncelleme tipini belirle
			String guncellemeTipi = iMap.getString("GUNCELLEME_TIPI");
			if ("M".equals(guncellemeTipi)) {
				guncellemeTipi = "Customer";
			} else if ("K".equals(guncellemeTipi)) {
				guncellemeTipi = "Card";
			} else if ("H".equals(guncellemeTipi)) {
				guncellemeTipi = "All";
			} else {
				guncellemeTipi = StringUtils.EMPTY;
			}
			//limit artis parametresini belirle
			String otomatikLimitArtsinMi = CreditCardServicesUtil.NO;
			if (iMap.getBoolean("OTOMATIK_LIMIT_ARTSIN_MI")) {
				otomatikLimitArtsinMi = CreditCardServicesUtil.YES;
			}
			//Guncelle
			GMMap sorguMap = new GMMap();
			sorguMap.put("CARD_NO", iMap.get("KART_NO"));
			sorguMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("CARD_CUSTOMER_FLAG", guncellemeTipi);
			sorguMap.put("AUTO_LIMIT_INCREASE", otomatikLimitArtsinMi);
			logger.debug("BNSPR_OCEAN_UPDATE_AUTO_CARD_LIMIT_INCREASE : " + sorguMap.toString());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_AUTO_CARD_LIMIT_INCREASE", sorguMap));
			logger.debug("BNSPR_OCEAN_UPDATE_AUTO_CARD_LIMIT_INCREASE : " + sorguMap.toString());
			//Kontrol
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RETURN_CODE"))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			} else {
				oMap.put("RESPONSE_DATA", sorguMap.getString("ORESULT") + "-" + sorguMap.getString("RETURN_DESCRIPTION"));
			}
		}
		catch (Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE_DATA", e.toString());
			}
		}

		return oMap;
	}
	
	/** Verilen musterinin kartina ait risk bilgisini doner.
	 * @author murat.el
	 * @since TY-4862
	 * @param iMap - Otomatil limit artis icin gerekli paramtreler
	 *         <li>KART_NO - Kart no
	 *         <li>MUSTERI_NO - Musteri no
	 * @return oMap - Islem sonucu
	 *         <li>KART_RISK - Karta ait risk bilgisi
	 */
	@GraymoundService("BNSPR_TRN3821_GET_KART_RISK")
	public static GMMap getKartRisk(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal kartRisk = BigDecimal.ZERO;

		try {
			//Kartin riskini bul
			GMMap sorguMap = new GMMap();
			sorguMap.put("KART_NO", iMap.get("KART_NO"));
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("MAC_LIMITI_KONTROL_EDILSIN_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_LIST", sorguMap));
			//Kontrol
			if (sorguMap.get("KART_LIST") == null || sorguMap.getSize("KART_LIST") < 1) {
				CreditCardServicesUtil.raiseGMError("4994");
			}
			
			kartRisk = sorguMap.getBigDecimal("KART_LIST", 0, "KART_RISK");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KART_RISK", kartRisk);
		return oMap;
	}
	
	//MUSTERI_NO, MESAJ_NO, TALEP_EDILEN_LIMIT
	/** Verilen musteriye istenen mesaji gonderir.
	 * @author murat.el
	 * @since TY-4862
	 * @param iMap - Otomatil limit artis icin gerekli paramtreler
	 *         <li>MUSTERI_NO - Musteri no
	 *         <li>MESAJ_NO - Gonderilecek mesaja ait parametre kodu
	 *         <li>TALEP_EDILEN_LIMIT - Yeni limit
	 * @return oMap - Islem sonucu
	 */
	@GraymoundService("BNSPR_TRN3821_LIMIT_AZALTIM_SMS_GONDER")
	public static GMMap limitAzaltimSmsGonder(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Ad Soyad al
			GMMap sorguMap = new GMMap();
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_UNVAN", sorguMap));
			String unvan = sorguMap.getString("UNVAN");
			
			//Mesaj
			String mesaj = CreditCardServicesUtil.errorMessageOlustur(iMap.getString("MESAJ_NO"), 
					unvan, iMap.getString("TALEP_EDILEN_LIMIT"));
			
			//Cep tel al
			sorguMap.clear();
			sorguMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("FORMAT", "UAT");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", sorguMap));
			String cepNo = sorguMap.getString("PHONE_NUMBER");
			
			//SMS gonder
			sorguMap.clear();
			sorguMap.put("GIDEN_MESAJ", mesaj);
			sorguMap.put("CEP_NO", cepNo);
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3821_LIMIT_TX_ONAY")
	public static GMMap limitOnay(GMMap iMap) {
		BigDecimal islemNo = iMap.getBigDecimal("ISLEM_NO");
		try{
			Connection conn = null;
			CallableStatement stmt = null;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3871.After_Approval(?)}");
			stmt.setBigDecimal(1, islemNo);
			stmt.execute();
			logger.info("BNSPR_TRN3821_LIMIT_TX_ONAY, islemNo: " + islemNo.toString());
		}catch (Exception e) {
			logger.error("BNSPR_TRN3821_LIMIT_TX_ONAY islemNo: "+ islemNo.toString() + " Hata: " + e);
			e.printStackTrace();
		}
		return new GMMap();
	}
}