package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KartKuryeUcretPrTx;
import tr.com.aktifbank.bnspr.dao.KartKuryeUcretPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3860Services {

	@GraymoundService("BNSPR_TRN3860_GET_LIST")
	public static GMMap getCourierFeeList(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "PR_TABLE";

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3860.GET_COURIER_FEE_LIST}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3860_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "PR_TABLE";
			CallableStatement stmt = null;
			Connection conn = null;
			List<?> list = (List<?>) iMap.get("PR_TABLE");

			conn = DALUtil.getGMConnection();

			for (int i = 0; i < list.size(); i++) {

				if (iMap.getString(tableName, i, "BASIM_TIPI") == null || iMap.getString(tableName, i, "BASIM_TIPI").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "BASIM_TIPI");
					CreditCardServicesUtil.raiseGMError("330");
				}
				
				if (iMap.getString(tableName, i, "FIRMA_ADI") == null || iMap.getString(tableName, i, "FIRMA_ADI").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "FIRMA_ADI");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if (iMap.getString(tableName, i, "KANAL_KOD") == null || iMap.getString(tableName, i, "KANAL_KOD").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "KANAL_KOD");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				KartKuryeUcretPrTx kartKuryeUcretPrTx = new KartKuryeUcretPrTx();
				KartKuryeUcretPrTxId kartKuryeUcretPrTxId = new KartKuryeUcretPrTxId();
				kartKuryeUcretPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));

				stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('KART_KURYE_UCRET_PR')}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.execute();

				kartKuryeUcretPrTxId.setId(stmt.getBigDecimal(1));
				kartKuryeUcretPrTx.setId(kartKuryeUcretPrTxId);
				kartKuryeUcretPrTx.setBasimTipi(iMap.getString(tableName, i, "BASIM_TIPI"));
				kartKuryeUcretPrTx.setFirmaAdi(iMap.getString(tableName, i, "FIRMA_ADI"));
				kartKuryeUcretPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				kartKuryeUcretPrTx.setKartGonderimTipi(iMap.getString(tableName, i, "KART_GONDERIM_TIPI"));
				kartKuryeUcretPrTx.setKartTipi(iMap.getString(tableName, i, "KART_TIPI"));
				kartKuryeUcretPrTx.setUcret(iMap.getBigDecimal(tableName, i, "UCRET"));
				kartKuryeUcretPrTx.setUrunKodu(iMap.getString(tableName, i, "URUN_KODU"));
				kartKuryeUcretPrTx.setYerliYabanci(iMap.getBoolean(tableName, i, "YERLI_YABANCI") ? "1" : "0");

				session.save(kartKuryeUcretPrTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3860");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			if (e.getCause() != null)
				throw new GMRuntimeException(0, e.getCause().getMessage());
			else
				throw new GMRuntimeException(0, e);
		}
	}
}
