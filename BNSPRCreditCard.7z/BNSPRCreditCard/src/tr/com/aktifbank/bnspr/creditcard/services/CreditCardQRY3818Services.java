package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** TFF kk,debit ve prepaid kart basvuru surecinde tum adimlarda bekleme surelerinin listelenmesini saglar.
 * @author murat.el
 * @since PYTFFKBS-492
 */
public class CreditCardQRY3818Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since PY-7408
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>DURUM_LIST - Tff basvuru durumlari
	 *         <li>KART_TIPI_LIST - Tff kart tipleri
	 *         <li>SOURCE_LIST - Tff basvuru yerleri
	 *         <li>KANAL_LIST - Tff basvuru kanallari
	 *         <li>BASLANGIC_TARIHI - Arama araligi baslangic tarihi default degeri
	 *         <li>BITIS_TARIHI - Arama araligi bitis tarihi default degeri       
	 */
	@GraymoundService("BNSPR_QRY3818_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Durum
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM_LIST", "TFF_BASVURU_DURUM_KOD", "HEPSI"));
			// Kart tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("KART_TIPI_LIST", "TFF_KART_TIPI", "E"));
			// Source
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3183_TFF_SOURCE_LIST", iMap));
			// Kanal Listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3183_TFF_KANAL_LIST", iMap));
			// baslang�c bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore TFF kk,debit ve prepaid kart basvuru surecinde 
	 * son adimdaki bekleme surelerini listeler<br>
	 * @author murat.el
	 * @since PY-7408
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO
	 *        <li>TC_KIMLIK_NO
	 *        <li>MUSTERI_NO
	 *        <li>ADI
	 *        <li>IKINCI_ADI
	 *        <li>SOYADI
	 *        <li>BASLANGIC_TAR
	 *        <li>BITIS_TAR
	 *        <li>TFF_KART_TIPI
	 *        <li>DURUM_LIST
	 *        <li>KANAL_KODU
	 *        <li>SOURCE
	 *        <li>BAS_SURE
	 *        <li>BIT_SURE
	 * @return Sorgu sonuclari<br>
	 *        <li>BASVURU_LIST
	 */
	@GraymoundService("BNSPR_QRY3818_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			int parameterIndex = 1;
			query = "{? = call PKG_RC3818.Rc_Qry3818_List_Basvuru(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(parameterIndex++, -10); // ref cursor
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(parameterIndex++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(parameterIndex++, iMap.getString("PASAPORT_NO"));
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(parameterIndex++, iMap.getString("TFF_KART_TIPI"));
			stmt.setString(parameterIndex++, iMap.getString("ADI"));
			stmt.setString(parameterIndex++, iMap.getString("IKINCI_ADI"));
			stmt.setString(parameterIndex++, iMap.getString("SOYADI"));
			stmt.setString(parameterIndex++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," : CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));

			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(parameterIndex++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			} else {
				stmt.setDate(parameterIndex++, null);
			}
			
			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(parameterIndex++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			} else {
				stmt.setDate(parameterIndex++, null);
			}
			
			stmt.setString(parameterIndex++, iMap.getString("KANAL_KODU"));
			stmt.setString(parameterIndex++, iMap.getString("SOURCE"));
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("BAS_SURE"));
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("BIT_SURE"));
			stmt.execute();
			//Ekran formatina cevir
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResultsPutStr(rSet, "BASVURU_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
}
