package tr.com.aktifbank.bnspr.creditcard.services;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.com.aktifbank.bnspr.dao.CrdBakiyeHataliKartlar;
import tr.com.aktifbank.bnspr.dao.CrdCcFundingFileProcess;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.pojo.ServiceClass;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.service.loader.GMServiceUtil;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public final class CreditCardServicesUtil {
	
	//Degiskenler
	public static final String GM_DATASOURCE = "java:/GraymoundDS";
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String EVET = "E";
	public static final String HAYIR = "H";
	
	public final static String RESPONSE_BASARISIZ = "0";
	public final static String RESPONSE_BASARILI = "2";
	
	//Eventler
	public static final String KDH_SONUC_EVENT_TYPE_NO = "56";
	
	private static final Logger logger = LoggerFactory.getLogger(CreditCardServicesUtil.class);
	
	//--------------------------------------------------------SETUSERGLOBALS
	/** Verilen kullanicinin bilgilerini db sessiona set eder.<br>
	 * @author murat.el
	 * @since 12.02.2014
	 * @param iMap - Kullanici Bilgileri<br>
	 *        <li>KULLANICI_KOD - Basvuru durum kodu
	 *        <li>HATA_VERILSIN_MI - Hatayi firlatarak yapilan islemleri iptal eder
	 * @return Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_KK_SET_USER_GLOBALS")
	public static GMMap setUserGlobals(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call pkg_global.SET_USER_GLOBALS2(?,?,?,?,?,?,?)}";
			
			int i = 1;
			stmt = conn.prepareCall(query);
			stmt.setString(i++, iMap.getString("KULLANICI_KOD"));
			stmt.setString(i++, null);
			stmt.setString(i++, null);
			stmt.setString(i++, null);
			stmt.setString(i++, null);
			stmt.setString(i++, null);
			stmt.setString(i++, null);
			stmt.execute();
		}
		catch (Exception e) {
			if (EVET.equals(iMap.getString("HATA_VERILSIN_MI", EVET))) {
				throw ExceptionHandler.convertException(e);
			} else {
				logger.error(e.getMessage());
				oMap.put("RESPONSE", RESPONSE_BASARISIZ);
			}
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("RESPONSE", RESPONSE_BASARILI);
		return oMap;
	}
	
	//--------------------------------------------------------SMSGONDER
	@GraymoundService("BNSPR_KK_BASVURU_SEND_SMS")
    public static GMMap sendSMS(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//TODO KK icin sendsms proc.u degisecek, degistigi zaman acilabilir.
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

        try {
            conn = DALUtil.getGMConnection();
            
            query = "{ call PKG_KK_BASVURU.Kk_Sms_Bilgisi(?,?,?) }";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
            stmt.registerOutParameter(2, Types.VARCHAR);
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            
            // Numarayi ve Mesaji al. Gonderilecek mesaj varsa sms at.
            String mesaj = stmt.getString(2);
            String cepTel = stmt.getString(3);

            if (mesaj != null) {
                iMap.put("MSISDN", cepTel);
                iMap.put("CONTENT", mesaj);
                GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS_ASYNC", iMap);
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }
	
	/** Mail gonder.
	 * @since PY-9105
	 * @param iMap - Mail Bilgileri<br>
	 *        <li>MAIL_TO_PARAM : Mail gonderilecek adresleri iceren parametre
	 *        <li>MAIL_FROM : Maili gonderen adres
	 *        <li>MAIL_SUBJECT : Mail konusu
	 *        <li>MAIL_BODY : Mail icerigi
	 *        <li>MAIL_ATTACHMENT_LIST : Mailde yer alan ek dosyalar
	 * @return oMap - Islem sonucu<br>
	 */
	@GraymoundService("BNSPR_KK_BASVURU_SEND_MAIL")
	public static GMMap sendMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			sorguMap.clear();
			sorguMap.put("PARAMETRE", iMap.get("MAIL_TO_PARAM"));
			String mailTo = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");
			if (StringUtils.isBlank(mailTo)) {
				return oMap;
			}

			sorguMap.clear();
			sorguMap.put("MAIL_BODY_CLOB", iMap.get("MAIL_BODY"));
			sorguMap.put("MAIL_FROM", iMap.get("MAIL_FROM"));
			sorguMap.put("MAIL_SUBJECT", iMap.get("MAIL_SUBJECT"));
			sorguMap.put("IS_BODY_HTML", "H");
			sorguMap.put("MAIL_TO", mailTo);
			sorguMap.put("MAIL_ATTACHMENT_LIST", iMap.get("MAIL_ATTACHMENT_LIST"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", sorguMap));
		}
		catch (Exception e) {
			//Mail sirasinda hata alinirsa akis kesilmeyecek.
		}
		
		return oMap;
	}
	
	//--------------------------------------------------------KKTFFBASVURUNOAL
	/** Verilen kredi karti basvurusunun bagli oldugu tff basvurusunu bulur.
	 * 
	 * @param iMap - Kredi karti basvurusu<br>
	 *        <li>KK_BASVURU_NO - Kredi karti basvuru no
	 * @return oMap - Tff basvurusu<br>
	 * 		  <li>TFF_BASVURU_NO - TFF basvuru no
	 */
	@GraymoundService("BNSPR_KK_TFF_BASVURU_NO_AL")
	public static GMMap kkTffBasvuruNoAl(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			query = "{ ? = call PKG_KK_BASVURU.kk_tff_basvuru_no_al (?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KK_BASVURU_NO"));;
			stmt.execute();
			oMap.put("TFF_BASVURU_NO", stmt.getBigDecimal(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//--------------------------------------------------------KANALKODUAL
	/** Verilen basvuru numarasina ait basvurunun yapildigi kanal bilgisini bulur.
	 * 
	 * @author murat.el
	 * @param iMap - BASVURU_NO - Basvuru Numarasi
	 * @return kanalKodu- Basvurunun yapildigi kanal kodu
	 */
    @GraymoundService("BNSPR_CREDITCARD_GET_KANAL_KODU")
	public static GMMap getKanalKoduByBasvuruNo(GMMap iMap) {
    	GMMap oMap = new GMMap();
		String kanalKodu = null;
		
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (kkBasvuru != null) {
				kanalKodu = kkBasvuru.getKanalKod();
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("KANAL_KODU", kanalKodu);
		return oMap;
	}
	
	//--------------------------------------------------------LISTPARAMETER
	/** Verilen kod ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.
	 * 
	 * @param tableName - Parametre listesi adi:Ekrana input
	 * @param kod - Parametre Adi
	 * @return {@link GMMap}
	 */
	public static GMMap getParameterList(String tableName, String kod) {
		return getParameterList(tableName, kod, null, null);
	}

	/** Verilen kod ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.<br>
	 *  addOption secenegi set edilmisse listeye yeni bir satir ekler.
	 * 
	 * @param tableName - Parametre listesi adi:Ekrana input
	 * @param kod - Parametre Adi
	 * @param addOption - "E":Bos Satir Eklensin, "Hepsi":Hepsi Satiri Eklensin
	 * @return {@link GMMap}
	 */
	public static GMMap getParameterList(String tableName, String kod, String isAddEmptKey) {
		return getParameterList(tableName, kod, null, isAddEmptKey);
	}
	
	/** Verilen kod ve key ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.<br>
	 *  addOption secenegi set edilmisse listeye yeni bir satir ekler.
	 * 
	 * @param tableName - Parametre listesi adi:Ekrana input
	 * @param kod - Parametre Adi
	 * @param key - Parametre Kriteri
	 * @param addOption - "E":Bos Satir Eklensin, "Hepsi":Hepsi Satiri Eklensin
	 * @return {@link GMMap}
	 */
	public static GMMap getParameterList(String tableName, String kod,
			String key, String addOption) {
		GMMap inMap = new GMMap();
		GMMap outMap = new GMMap();
		
		try {
			//Default RESULTS
			if (tableName != null) {
				inMap.put("TABLE_NAME", tableName);
			}
			//Default null, E:Bos, Hepsi:Hepsi
			if (addOption != null) {
				inMap.put("ADD_EMPTY_KEY", addOption);
			}
			//Dolu Olmali
			if (kod != null) {
				inMap.put("KOD", kod);
			}
			//Default null
			if (key != null) {
				inMap.put("KEY2", key);
			}
			
			outMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", inMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}
	
	//--------------------------------------------------------LISTPARAMETERBYKEY
	/** Verilen kod,keyler ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.<br>
	 *  addOption secenegi set edilmisse listeye yeni bir satir ekler.
	 * 
	 * @param tableName - Parametre listesi adi:Ekrana input
	 * @param kod - Parametre Adi
	 * @param key2 - Parametre Kriteri 2
	 * @param key3 - Parametre Kriteri 3
	 * @return {@link GMMap}
	 */
	public static GMMap getParameterListByKey(String tableName, String kod, 
			String key2, String key3) {
		return getParameterListByKey(tableName, kod, key2, key3, null);
	}
	
	/** Verilen kod,keyler ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.<br>
	 *  addOption secenegi set edilmisse listeye yeni bir satir ekler.
	 * 
	 * @param tableName - Parametre listesi adi:Ekrana input
	 * @param kod - Parametre Adi
	 * @param key2 - Parametre Kriteri 2
	 * @param key3 - Parametre Kriteri 3
	 * @param addOption - "E":Bos Satir Eklensin, "Hepsi":Hepsi Satiri Eklensin
	 * @return {@link GMMap}
	 */
	public static GMMap getParameterListByKey(String tableName, String kod, 
			String key2, String key3, String isAddEmptKey) {
		return getParameterListByKey(tableName, kod, null, key2, key3, isAddEmptKey);
	}
	
	/** Verilen kod ve key ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.<br>
	 *  addOption secenegi set edilmisse listeye yeni bir satir ekler.
	 * 
	 * @param tableName - Parametre listesi adi:Ekrana input
	 * @param kod - Parametre Adi
	 * @param key1 - Parametre Kriteri 1
	 * @param key2 - Parametre Kriteri 2
	 * @param key3 - Parametre Kriteri 3
	 * @param addOption - "E":Bos, "HEPSI":Hepsi Satiri Eklensin
	 * @return {@link GMMap}
	 */
	public static GMMap getParameterListByKey(String tableName, String kod,
			String key1, String key2, String key3, String addOption) {
		GMMap inMap = new GMMap();
		GMMap outMap = new GMMap();
		
		try {
			//Default RESULTS
			if (tableName != null) {
				inMap.put("TABLE_NAME", tableName);
			}
			//Default null, E:Bos, Hepsi:Hepsi
			if (addOption != null) {
				inMap.put("ADD_EMPTY_KEY", addOption);
			}
			//Dolu Olmali
			if (kod != null) {
				inMap.put("KOD", kod);
			}
			//Default null
			if (key1 != null) {
				inMap.put("KEY1", key1);
			}
			if (key2 != null) {
				inMap.put("KEY2", key2);
			}
			if (key3 != null) {
				inMap.put("KEY3", key3);
			}
			
			outMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_KEY", inMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}
	
	//--------------------------------------------------------PARAMTEXTVARMI
	/** Verilen koda ait verilen kriter mevcut mu?
	 * 
	 * @param iMap KOD - Parametre Adi, KEY - Parametre Kriteri, KEY2 - Parametre Kriteri, KEY3 - Parametre Kriteri
	 * @return oMap IS_EXIST - E:Deger Var, H:Deger Yok
	 */
	@GraymoundService("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT")
	public static GMMap isExistParamText(GMMap iMap) {
		GMMap oMap = new GMMap();
		String isExistParamText = HAYIR;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call pkg_parametre.ParamTextDegerVarMi (?,?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("KOD"));
			stmt.setString(3, iMap.getString("KEY"));
			stmt.setString(4, iMap.getString("KEY2"));
			stmt.setString(5, iMap.getString("KEY3"));
			stmt.execute();
			
			isExistParamText = nvl(stmt.getString(1), HAYIR);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		oMap.put("IS_EXIST", isExistParamText);
		return oMap;
	}
	
	//--------------------------------------------------------GETPARAMTEXT
	/** Verilen koda ait verilen kriterlere gore kayit var mi?
	 * 
	 * @param iMap KOD - Parametre Adi, KEY1 - Parametre Kriteri, KEY2 - Parametre Kriteri, KEY3 - Parametre Kriteri
	 * @return oMap TEXT - Parametre Degeri
	 */
	@GraymoundService("BNSPR_CREDITCARD_GET_PARAM_TEXT")
	public static GMMap getParamText(GMMap iMap) {
		GMMap oMap = new GMMap();
		String paramText = null;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call pkg_parametre.paramtextal (?,?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("KOD"));
			stmt.setString(3, iMap.getString("KEY1"));
			stmt.setString(4, iMap.getString("KEY2"));
			stmt.setString(5, iMap.getString("KEY3"));
			stmt.execute();
			
			paramText = stmt.getString(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		oMap.put("TEXT", paramText);
		return oMap;
	}
	
	//--------------------------------------------------------GETPARAMTEXT
	/** Verilen koda ait verilen kriterlere gore kayit var mi?
	 * 
	 * @param iMap KOD - Parametre Adi, KEY1 - Parametre Kriteri, KEY2 - Parametre Kriteri, KEY3 - Parametre Kriteri
	 * @return oMap TEXT - Parametre Degeri
	 */
	@GraymoundService("BNSPR_CREDITCARD_GET_PARAM_SAYI")
	public static GMMap getParamSayi(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal paramSayi = null;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call pkg_parametre.paramsayial (?,?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("KOD"));
			stmt.setString(3, iMap.getString("KEY1"));
			stmt.setString(4, iMap.getString("KEY2"));
			stmt.setString(5, iMap.getString("KEY3"));
			stmt.execute();
			
			paramSayi = stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		oMap.put("SAYI", paramSayi);
		return oMap;
	}

	//--------------------------------------------------------RAISEGMERROR
	/** Verilen hata kodu ve parametrelerle ekrana hata mesaji verir.
	 * 
	 * @param errorCode - GNL_Mesaj_Pr tablosunda tanimli olan Hata Kodu
	 * @param parameters - Hata aciklamasinda yer alacak parametreler. Max.:4
	 */
	public static void raiseGMError(String errorCode, Object...parameters) {
		HashMap<String, Object> myMap = new HashMap<String, Object>();
        myMap.put("HATA_NO", errorCode);
        
        if (parameters != null && parameters.length > 0) {
        	int index = 0;
        	while (index < parameters.length) {
        		 myMap.put("P" + (index+1), parameters[index]);
        		 index++;
			}
        }
        
        try {
        	String errorMessage =
        			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap).get("ERROR_MESSAGE").toString();
        	throw new GMRuntimeException(0, errorMessage);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
	}
	/** Verilen hata kodu ve parametrelerle ekrana hata mesaji verir.
	 * 
	 * @param errorCode - GNL_Mesaj_Pr tablosunda tanimli olan Hata Kodu
	 * @param parameters - Hata aciklamasinda yer alacak parametreler. Max.:4
	 */
	public static String errorMessageOlustur(String errorCode, Object...parameters) {
		HashMap<String, Object> myMap = new HashMap<String, Object>();
        myMap.put("MESSAGE_NO", errorCode);
        
        if (parameters != null && parameters.length > 0) {
        	int index = 0;
        	while (index < parameters.length) {
        		 myMap.put("P" + (index+1), parameters[index]);
        		 index++;
			}
        }
        

        	return  GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE").toString();

	}
	
	//--------------------------------------------------------TFFHATAMESAJIAL
	/** Tff web tarafinda hata kodu verilen durumun hata mesajini getirir ya da hata olarak firlatilir<br>
	 * @author murat.el
	 * @since 21.04.2014
	 * @param iMap - Sorgu Bilgileri<br>
	 *         <li>WEB_HATA_KOD - Tff web tarafi hata kodu
	 *         <li>SOURCE - hata kodunu kullanan kaynak bilgisi
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi (E|H)
	 * @return Hataya ait bilgiler<br>
	 *         <li>HATA_MESAJI - Hata verilmeyecekse hata mesaji
	 */
	@GraymoundService("BNSPR_TFF_HATA_MESAJI_AL")
	public static GMMap tffHataMesajiAl(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		String hataMesaji = StringUtils.EMPTY;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			query = "{? = call PKG_TFF_BASVURU.tff_hata_mesaji_al(?,?,?) }";
			stmt = conn.prepareCall(query);
			
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("WEB_HATA_KOD"));
			stmt.setString(i++, iMap.getString("SOURCE"));
			stmt.setString(i++, iMap.getString("HATA_VERILSIN_MI"));
			stmt.execute();
			
			hataMesaji = stmt.getString(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		oMap.put("HATA_MESAJI", hataMesaji);
		return oMap;
	}
	
	//--------------------------------------------------------YETKIVARMI
	/** Verilen isleme ait verilen kullanicinin yetkisi var mi? <br>
	 * Kullanici kodu bos gelirse sorguyu calistiran kullanicinin yetki kontrolu yapilir<br>
	 * @author murat.el
	 * @since 20.01.2014
	 * @param iMap - Islem Bilgileri<br>
	 *        <li>ISLEM_KODU - Yapilacak islemin kodu
	 *        <li>KULLANICI_KODU - Islemi yapacak kullanici kodu
	 * @return oMap - Yetki Bilgisi
	 *         <li>YETKI_VAR_MI - Kullanicinin isleme yetkisi var mi? (E|H)
	 */
	@GraymoundService("BNSPR_CREDITCARD_ISLEM_YETKISI_VAR_MI")
	public static GMMap isAuthanticated(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_rc3813.islem_yetki_var_mi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_KODU"));
			stmt.setString(3, iMap.getString("KULLANICI_KODU"));
			stmt.execute();

			String yetkiVarMi =  stmt.getString(1);
			oMap.put("YETKI_VAR_MI", BooleanUtils.toBoolean(yetkiVarMi, EVET, HAYIR));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	//--------------------------------------------------------PERSONEL_MI
	/** Sorgulanan personelin/basvurunun banka personeli olup olmadigini doner<br>
	 * @author murat.el
	 * @category PY-6284
	 * @since 10.03.2014
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>TC_KIMLIK_NO - TC kimlik numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>REFERANS_TIPI - Basvurunun hangi projeye ait oldugu(TFF|KK)
	 *        <li>HATA_VERILSIN_MI - Hata verilecek mi? (E:Evet | H:Hayir)
	 * @return Islem sonucu<br>
	 *        <li>PERSONEL_MI - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_CREDITCARD_PERSONEL_MI")
	public static GMMap isPersonel(GMMap iMap) {
		GMMap oMap = new GMMap();
		String personelMi = StringUtils.EMPTY;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			
			query = "{? = call pkg_kk_basvuru.personel_mi(?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(5, iMap.getString("REFERANS_TIPI"));
			stmt.execute();

			personelMi = stmt.getString(1);
		}
		catch (Exception e) {
			if (EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				personelMi = HAYIR;
			}
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("PERSONEL_MI", personelMi);
		return oMap;
	}
	
	//--------------------------------------------------------KDH Services
	/** Kk kdh basvurusu onaylandi mi<br>
	 * @author murat.el
	 * @category PY-10141
	 * @since 23.03.2015
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO - KK basvuru numarasi
	 * @return Islem sonucu<br>
	 *        <li>ONAYLANDI_MI - Kdh basvurusu onaylandi mi(E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_CREDITCARD_KDH_BASVURU_ONAYLANDI_MI")
	public static GMMap kdhBasvuruOnaylandiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String onaylandiMi = HAYIR;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			
			query = "{? = call pkg_kk_basvuru.kk_kdh_onaylandi_mi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			onaylandiMi = stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("ONAYLANDI_MI", onaylandiMi);
		return oMap;
	}
	
	/** Kk kdh basvurusu red mi<br>
	 * @author murat.el
	 * @category PY-10141
	 * @since 23.03.2015
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO - KK basvuru numarasi
	 * @return Islem sonucu<br>
	 *        <li>RED_MI - Kdh basvurusu red mi(E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_CREDITCARD_KDH_BASVURU_RED_MI")
	public static GMMap kdhBasvuruRedMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String redMi = HAYIR;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			
			query = "{? = call pkg_kk_basvuru.kk_kdh_red_mi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			redMi = stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("ONAYLANDI_MI", redMi);
		return oMap;
	}
	
	//--------------------------------------------------------Service Registry
	@GraymoundService("BNSPR_CREDITCARD_OTO_SERVICE_REGISTRY")
	public static GMMap deneme(GMMap iMap) {
		GMMap sorguMap = new GMMap();
		Session session = DAOSession.getSession("ADCCore");
		List<?> list = session.createCriteria(ServiceClass.class).list();

		for (Iterator<?> iterC = list.iterator(); iterC.hasNext();) {
			ServiceClass service = (ServiceClass) iterC.next();
			try {
				Class<?> serviceClass = Class.forName(service.getClassName());

				List<Method> serviceMethods = GMServiceUtil.listGraymoundServices(serviceClass);
				for (Iterator<Method> iterM = serviceMethods.iterator(); iterM.hasNext();) {
					Method serviceMethod = iterM.next();
					GraymoundService graymoundService = serviceMethod.getAnnotation(GraymoundService.class);
					String serviceName = graymoundService.value();

					Boolean eklensinMi = false;
					if (StringUtils.isNotBlank(iMap.getString("SERVIS_ISMI")) && iMap.getString("SERVIS_ISMI").equals(serviceName)) {
						eklensinMi = true;
					}
					else if (StringUtils.isNotBlank(iMap.getString("SINIF_ISMI")) && iMap.getString("SINIF_ISMI").equals(serviceClass.getName())) {// paketle																													// beraber
						eklensinMi = true;
					}
					else if (StringUtils.isNotBlank(iMap.getString("PAKET_ISMI")) && iMap.getString("PAKET_ISMI").equals(serviceClass.getPackage().getName())) {
						eklensinMi = true;
					}
					else {
						System.out.println("Hatali giris");
					}

					if (eklensinMi) {
						sorguMap.clear();
						sorguMap.put("SERVIS_ISMI", serviceName);
						sorguMap.put("SERVIS_SORUMLUSU", iMap.getString("SERVIS_SORUMLUSU", "36"));//Kullanici kodunu bul(36-Murat)
						sorguMap.put("PROJE_ISMI", iMap.getString("PROJE_ISMI", "68"));//Proje kodunu bul(68-KK)
						sorguMap.put("SERVIS_TANIMI", serviceName);
						sorguMap.put("SERVIS_DURUMU", "1");
						sorguMap.put("PAKET_ISMI", serviceClass.getName());
						sorguMap.put("METHOD_ISMI", serviceMethod.getName());
						sorguMap.put("SEND_EMAIL_FLAG", "H");
						sorguMap.put("ACCOUNTING_FLAG", "H");
						sorguMap.put("JOB_FLAG", "H");
						sorguMap.put("WS_FLAG", "H");
						sorguMap.put("THRESHOLD", "0");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN9997_SAVE_SERVICE", sorguMap));
						System.out.println("GMServiceName:" + serviceName);
					}

					/*
					System.out.println("Paket:" + serviceClass.getPackage().getName());
					System.out.println("Class:" + serviceClass.getName());
					System.out.println("Method:" + serviceMethod.getName());
					System.out.println("GMServiceName:" + serviceName);
					*/
				}
			}
			catch (ClassNotFoundException e) {
				System.out.println("Class bulunamadi:" + service.getClassName());
			}
		}

		return sorguMap;
	}
	
	//--------------------------------------------------------OPERATIONS
	/** Verilen deger nullsa default degeri atar degilse kendisini dondurur.
	 * 
	 * @param value - Kontrol edilecek deger
	 * @param defaultValue - Kontrol edilen deger nullsa donecek sonuc
	 */
	public static <T> T nvl(T value, T defaultValue) {
		if (value instanceof String) {
			return StringUtils.isBlank((String) value) ? defaultValue : value;
		}

		return value == null ? defaultValue : value;
	}
	
	/** Ekranda kullanilan List componentinden secili degerleri alarak
	 * query'de string olarak kullanilabilecek (IN) durumda geri doner.
	 * 
	 * @param gmSelectedList - Ekrandaki listeden secilen kayitlar
	 * @return Listedeki secili degerlerin virgul ile ayrilmis hali. Orn: a,b,c
	 */
	@SuppressWarnings("unchecked")
	public static String convertGMListToString(Object gmSelectedList) {
		String returnValue = "";
		
		Object[] selectedList = null;
		if (gmSelectedList instanceof Object[]) {
			selectedList = (Object[]) gmSelectedList;
		}
		
		if (selectedList != null && selectedList.length > 0) {
			HashMap<String, Object> selectedMap = null;
			for (Object selected : selectedList) {
				selectedMap = (HashMap<String, Object>) selected ;

				if (null == selectedMap.get("VALUE")) {
					returnValue = returnValue + "HEPSI,";
				} else {
					returnValue = returnValue + selectedMap.get("VALUE") + ",";
				}
			}
		}
		
		return returnValue;
	}
	
	/** Verilen stringdeki turkce karakterleri ingilizce versiyonlari ile degistirir.
	 * 
	 * @param text - Turkce karakter iceren string
	 * @return Ingilizce karakterler cevrilmis string
	 */
	public static String convertStringTrToEn(String text) {
		String trStr = "������������";
		String enStr = "cigousCIGOUS";
		char trArr[] = trStr.toCharArray();
		char enArr[] = enStr.toCharArray();

		String str = text;

		if (str != null) {
			for (int i = 0; i < trStr.length(); i++) {
				str = str.replace(trArr[i], enArr[i]);
			}
		}

		return str;
	}
	
	public static boolean hunterAktifMi()
	{
		GMMap sorguMap =  new GMMap();
		sorguMap.put("PARAMETRE", "HUNTER_AKTIF_MI");
		return "E".equals(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER"));
	}
	
	public static boolean hunterDevredeMi()
	{
		GMMap sorguMap =  new GMMap();
		sorguMap.put("PARAMETRE", "HUNTER_DEVREDE_MI");
		return "E".equals(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER"));
	}
	
	@GraymoundService("BNSPR_APS_ACIK_ADRES")
	public static GMMap getApsAcikAdres(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder adres = new StringBuilder();
		String ayrac = " ";

		if (!"0".equals(iMap.getString("ADRES_NO")) && iMap.getString("YABANCI_ULKE_KOD") == null) {
			// Acik adres
			if (StringUtils.isNotBlank(iMap.getString("BUCAK"))) {
				adres.append(iMap.getString("BUCAK")).append(ayrac);
			}
			if (StringUtils.isNotBlank(iMap.getString("KOY"))) {
				adres.append(iMap.getString("KOY")).append(ayrac);
			}
			if (StringUtils.isNotBlank(iMap.getString("MAHALLE"))) {
				adres.append(iMap.getString("MAHALLE")).append(ayrac);
			}
			if (StringUtils.isNotBlank(iMap.getString("CSBM"))) {
				adres.append(iMap.getString("CSBM")).append(ayrac);
			}
			if (StringUtils.isNotBlank(iMap.getString("DIS_KAPI_NO"))) {
				adres.append("NO:").append(iMap.getString("DIS_KAPI_NO")).append(ayrac);
			}
			if (StringUtils.isNotBlank(iMap.getString("IC_KAPI_NO"))) {
				adres.append("DAIRE:").append(iMap.getString("IC_KAPI_NO"));
			}
			oMap.put("ACIK_ADRES", adres.toString().trim());
			// il kodu
			String ilKodu = iMap.getString("IL_KODU");
			if (StringUtils.isNotBlank(ilKodu)) {
				ilKodu = StringUtils.leftPad(ilKodu, 3, "0");
			}
			oMap.put("IL_KODU", ilKodu);
			// Ilce Kodu
			oMap.put("ILCE_KODU", iMap.getString("ILCE_KODU"));
		}

		return oMap;
	}
	
	/** Trims new line characters from given string<br>
	 * 
	 * @author murat.el
	 * @since TY-3554
	 * @param value - String new line characters will be removed
	 * @return String has no new line characters
	 */
	public static String trimNewLine(String value) {
		return trimNewLine(value, null);
	}
	
	/** Trims new line characters from given string<br>
	 * 
	 * @author murat.el
	 * @since TY-3554
	 * @param value - String new line characters will be removed
	 * @param replaceString - String new line characters will be replaced
	 * @return String has no new line characters
	 */
	public static String trimNewLine(String value, String replaceString) {
		if (StringUtils.isBlank(replaceString)) {
			replaceString = " ";
		}
		
		return StringUtils.isBlank(value) == true ? value : value.replaceAll("[\\t\\n\\r]+", replaceString);
	}
	
	public static GMMap getErrorResponse(String errorMessage) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", RESPONSE_BASARISIZ);
		oMap.put("RESPONSE_DATA", errorMessage);

		/*Hata mesaj i�eri�i dolu ise d�ner, hata al�n�rsa bu alan bos d�ner*/
		try {
			oMap.put("RESPONSE_ERROR_DESC", findVariableNameFromValue(errorMessage));
		}
		catch (Exception e) {
			oMap.put("RESPONSE_ERROR_DESC", "");
		}

		return oMap;
	}
	
	public static GMMap getSuccessResponse(String successMessage) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", successMessage);

		return oMap;
	}

	/*
	 * Reflection ile interface'deki field'lar al�nd� ve field de�erleri icinde responseData arand�.
	 * E�er var ise field name alan� replace edilerek d�nd�r�ld�.
	 * 1601 VD - *1.06.2018
	 * */
	public static String findVariableNameFromValue(String responseData) throws Exception {

		String ErrorDesc = null;
		try {
			Field[] fList = TffServicesMessages.class.getFields();
			for (Field f : fList) {
				if ((f.get(null).toString()).equals(responseData))
					ErrorDesc = (f.getName().replace("_", " "));
			}
	
		}
		// Bulunamadi ise null doner
		catch (Exception e) {

		}
		return ErrorDesc;

	}
	
	public static String getGlobalParam(String param) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", param);
		String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return batchNo;
	}

	public static String convertStringToDate(Date indate, String simpleDateFormat) {
		String dateString = null;
		SimpleDateFormat sdfr = new SimpleDateFormat(simpleDateFormat);
		try {
			dateString = sdfr.format(indate);
		}
		catch (Exception ex) {

		}
		return dateString;
	}
	
	/*
	 * Zorunlu alan kontrol�, dolu ise source mapten dest mape atar
	 * */
    public static void getRequiredField(GMMap sourceMap, String sourceField, GMMap destinationMap, String destinationField) {
        Object value = sourceMap.get(sourceField);
        if (isNullOrEmpty(value)) {
        	CreditCardServicesUtil.raiseGMError("330", sourceField);
        }
        destinationMap.put(destinationField, value);
    }
    
    public static boolean isNullOrEmpty(Object o) {
        if ((o == null) || o.toString().trim().isEmpty()) {
            return true;
        }
        return false;
    }
    
    @GraymoundService("BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK")
	   public static GMMap updateTokenizedCardsForKk(GMMap iMap){
		   GMMap oMap= new GMMap();
		   Session session = DAOSession.getSession("BNSPRDal");
		   try {
			List<KkBasvuru> kkBasvuruList = new ArrayList<KkBasvuru>();
			
			do {
				kkBasvuruList = session.createCriteria(KkBasvuru.class).add(Restrictions.eq("isTokenized", false)).add(Restrictions.isNotNull("kartNo")).setMaxResults(500).list();
				if(kkBasvuruList.size()>0){
					updateTokenizedCardsForKK(kkBasvuruList);
				}
			}
			while (kkBasvuruList.size()>0);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		   
		   return oMap;
	   
	}
     public static GMMap updateTokenizedCardsForKK(List<KkBasvuru> kkBasvuruList){
		
		GMMap inputMap= new GMMap();
		GMMap iMap1= new GMMap();
		GMMap iMap2= new GMMap();
		GMMap iMap3= new GMMap();
		GMMap iMap4= new GMMap();
		GMMap iMap5= new GMMap();
		ArrayList<GMMap> taskList=new ArrayList<GMMap>();
		
		 boolean devam=true;

			int s=0;
			for (int i = 0; i < 100; i++) {
				if(kkBasvuruList.size()<=i){
					devam=false;
					break;
				}
					
				iMap1.put("BASVURU_LIST", s,"BASVURU_NO", kkBasvuruList.get(i).getBasvuruNo());
				
			}
			iMap1.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK_BASVURU");
			iMap1.put("SERVICE_ID", "1");
			taskList.add(iMap1);
			s=0;
			if(devam){
				for (int i =100; i < 200; i++){
					if(kkBasvuruList.size()<=i){
						devam=false;
						break;
					}
					iMap2.put("BASVURU_LIST", s,"BASVURU_NO", kkBasvuruList.get(i).getBasvuruNo());
				}
				iMap2.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK_BASVURU");
				iMap2.put("SERVICE_ID", "2");
				taskList.add(iMap2);
			}
			s=0;
			if(devam){
				for(int i=200; i<300; i++){
					if(kkBasvuruList.size()<=i){
						devam=false;
						break;
					}
					iMap3.put("BASVURU_LIST", s,"BASVURU_NO", kkBasvuruList.get(i).getBasvuruNo());
					}
				iMap3.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK_BASVURU");
				iMap3.put("SERVICE_ID", "3");
				taskList.add(iMap3);
			}
			s=0;	
			if(devam){
				for (int i =300; i < 400; i++) {
					if(kkBasvuruList.size()<=i){
						devam=false;
						break;
					}
					iMap4.put("BASVURU_LIST", s,"BASVURU_NO",kkBasvuruList.get(i).getBasvuruNo());
				}
				iMap4.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK_BASVURU");
				iMap4.put("SERVICE_ID", "4");
				taskList.add(iMap4);
			}
			 s=0;
			 if(devam){
				for (int i =400; i < 500; i++) {
					if(kkBasvuruList.size()<=i){
						break;
					}
					iMap5.put("BASVURU_LIST", s,"BASVURU_NO", kkBasvuruList.get(i).getBasvuruNo());
				}
				iMap5.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK_BASVURU");
				iMap5.put("SERVICE_ID", "5");
				taskList.add(iMap5);
			}
			 inputMap.put("T_TASKS", taskList);
			 GMMap outputMap = GMServiceExecuter.callParallel(inputMap);
		
		return outputMap;
	}
     @GraymoundService("BNSPR_UPDATE_TOKENIZED_CARDS_FOR_KK_BASVURU")
 	public static GMMap updateTokenizedCardForKKBasvuru(GMMap iMap){
 		GMMap oMap= new GMMap();
 		String tokenizedCardNo ="";
 		// Boolean isTokenized=true;
 		Session session = DAOSession.getSession("BNSPRDal");
 		int j = 0;
 		for (int i = 0; i < iMap.getSize("BASVURU_LIST"); i++){
 			try {
 				tokenizedCardNo = "";
 				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_LIST",i,"BASVURU_NO"));
 				
 				if(!StringUtils.isNumeric(kkBasvuru.getKartNo())){//tokenlanm�� ise
 					//isTokenized=false;
 					kkBasvuru.setIsTokenized(true);
 				}else{
 					tokenizedCardNo = BnsprOceanCommonFunctions.getTokenizedCardNo(kkBasvuru.getKartNo().toString());
 					kkBasvuru.setKartNo(tokenizedCardNo);
 					kkBasvuru.setIsTokenized(false);
 				}
 				session.saveOrUpdate(kkBasvuru);
 				j=j+1;
 				if(j==10){
 					session.flush();
 					j=0;
 				}
 				
 			}
 			catch (Exception e) {
 				e.printStackTrace();
 				continue;
 				}
 		}
 		session.flush();
 		System.out.println("SERVICE_ID"+iMap.getString("SERVICE_ID"));
         oMap.put("PARALLEL_CALL_RESULT", "X");
 		
 		return oMap;
 	}
     
     
     
     /** PP2D Balans Transfer <br>
 	 * @author caglar.saribiyik
 	 * @since 26.10.2020
 	 * @param iMap - Sorgu kriterleri<br>
 	 *        <li>CARD_NO
 	 *        <li>METHOD_NAME
 	 * @return Islem sonucu<br>
 	 */
    @GraymoundService("BNSPR_CALL_PREPAID_TO_DEBIT_BALANCE_TRANSFER_SERVICE")
  	public static GMMap sendPrepaidToDebitBalanceTransferService(GMMap iMap){
    	// Balans Transfer
    	GMMap processMapResult = new GMMap();
		try{
			GMMap ibMap = new GMMap();
			ibMap.put("CARD_NO", iMap.getString("CARD_NO"));
			processMapResult.putAll(GMServiceExecuter.execute("BNSPR_GENERAL_PREPAID_TO_DEBIT_BALANCE_TRANSFER",ibMap));
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(processMapResult.getString("RETURN_CODE"))) {
					throw new Exception("BNSPR_GENERAL_PREPAID_TO_DEBIT_BALANCE_TRANSFER servisinde hata. KartNo: "+ iMap.getString("CARD_NO") +" Hata: "+processMapResult.toString());
			}	
		}catch(Exception e){
			logger.error(iMap.getString("METHOD_NAME") + " BalansTransfer Hata ", e);
			processMapResult.put("RETURN_CODE", "1");
            GMMap mailMap = new GMMap();
            mailMap.put("MAIL_TO_PARAM", "KART_BCKOFFICE_ENTGRTN_MAIL_TO"); // "KART_ENTEGRATION_MAIL_TO", "KART_BACKOFFICE_MAIL_TO"
            mailMap.put("MAIL_FROM", "System@aktifbank.com.tr"); // "kartentegrasyonug@aktifbank.com.tr" 
            mailMap.put("MAIL_SUBJECT", "D�n���m Bakiye Transfer Hatas�");
            mailMap.put("MAIL_BODY",  iMap.getString("CARD_NO") +" nolu kart�n d�n���m�nde bakiye transferi yapilamadi.");
            GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
            
            // Hata alan islemler job'a (BNSPR_CALL_PREPAID_TO_DEBIT_BALANCE_JOB_TRANSFER_SERVICE) teslim edilir
            Session sessionOne = DAOSession.getSession("BNSPRDal");
            CrdBakiyeHataliKartlar bakiyeAktarim = new CrdBakiyeHataliKartlar();
            bakiyeAktarim.setDenemeSayisi(BigDecimal.ZERO);
            bakiyeAktarim.setDenemeTarihi(new Date());
            bakiyeAktarim.setDurumKod(BigDecimal.ONE);
            bakiyeAktarim.setHataKodu("001");
            String errMsg = (e.getMessage()+" "+e.getStackTrace().toString()).length() > 4000 ? (e.getMessage()+" "+e.getStackTrace().toString()).substring(1, 3999) : e.getMessage()+" "+e.getStackTrace().toString();
            bakiyeAktarim.setHataAciklama(errMsg);
            bakiyeAktarim.setKartNo(iMap.getString("CARD_NO"));
            sessionOne.save(bakiyeAktarim);
            sessionOne.flush();
		}
		return processMapResult;
     }
    
    /** PP2D Balans Hatali Kartlarin Transferi <br>
 	 * @author caglar.saribiyik
 	 * @since 10.12.2020
 	 */
    @GraymoundService("BNSPR_CALL_PREPAID_TO_DEBIT_BALANCE_JOB_TRANSFER_SERVICE")
  	public static GMMap sendPrepaidToDebitBalanceJobTransferService(GMMap iMap){
    	try{
    		Session session = DAOSession.getSession("BNSPRDal");
    		List<?> listFileData = session.createCriteria(CrdBakiyeHataliKartlar.class).add(Restrictions.eq("durumKod" , BigDecimal.ONE)).list();
    		if(listFileData == null)return new GMMap();
    		
    		for (int i = 0; i < listFileData.size(); i++) {
    			CrdBakiyeHataliKartlar bakiyeAktarim = (CrdBakiyeHataliKartlar) listFileData.get(i);
    			BigDecimal denemeSayisi = bakiyeAktarim.getDenemeSayisi().add(BigDecimal.ONE);
    			GMMap processMapResult = new GMMap();
    			GMMap ibMap = new GMMap();
    			ibMap.put("CARD_NO", bakiyeAktarim.getKartNo());
    			try{
    				processMapResult.putAll(GMServiceExecuter.execute("BNSPR_GENERAL_PREPAID_TO_DEBIT_BALANCE_TRANSFER",ibMap));	
    				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(processMapResult.getString("RETURN_CODE"))) throw new Exception("Hata: "+processMapResult.toString());	
    				bakiyeAktarim.setDenemeTarihi(new Date());
    				bakiyeAktarim.setDurumKod(BigDecimal.ZERO);
    				//bakiyeAktarim.setHataKodu("");
    				//bakiyeAktarim.setHataAciklama("");
    			}catch(Exception e){
    				logger.error("BNSPR_CALL_PREPAID_TO_DEBIT_BALANCE_JOB_TRANSFER_SERVICE Hata ", e);
    				String errMsg = (e.getMessage()+" "+e.getStackTrace().toString()).length() > 4000 ? (e.getMessage()+" "+e.getStackTrace().toString()).substring(1, 3999) : e.getMessage()+" "+e.getStackTrace().toString();
    				bakiyeAktarim.setDenemeSayisi(denemeSayisi);
    				bakiyeAktarim.setDenemeTarihi(new Date());
    				bakiyeAktarim.setHataKodu("002");
    				bakiyeAktarim.setHataAciklama(errMsg);
    				
    				if(denemeSayisi.intValueExact() % 5 == 0) {
    					GMMap mailMap = new GMMap();
    		            mailMap.put("MAIL_TO_PARAM", "KART_BCKOFFICE_ENTGRTN_MAIL_TO");
    		            mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");  
    		            mailMap.put("MAIL_SUBJECT", "D�n���m Bakiye Job Transfer Hatas�");
    		            mailMap.put("MAIL_BODY",  bakiyeAktarim.getKartNo() +" nolu kart�n d�n���m�nde job ile bakiye transferi yapilamadi. Deneme sayisi: " + denemeSayisi.intValueExact());
    		            GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
    				}
    			}
    			session.saveOrUpdate(bakiyeAktarim);
    		}
    		session.flush();
    		return new GMMap();
    	}catch(Exception e){
    		logger.error("BNSPR_CALL_PREPAID_TO_DEBIT_BALANCE_JOB_TRANSFER_SERVICE Hata: ", e);
    		throw ExceptionHandler.convertException(e);
    	}
    }
}

