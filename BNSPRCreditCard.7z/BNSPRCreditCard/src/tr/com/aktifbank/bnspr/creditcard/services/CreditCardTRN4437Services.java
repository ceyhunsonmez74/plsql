package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.CrdTxninstallmentsTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4437Services implements OceanMapKeys {
    public static GMMap throwGMBusssinessException(String string) {
        GMMap exMap = new GMMap();
        exMap.put("P1" , string);
        exMap.put("HATA_NO" , "660");
        return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
    }
    
    @GraymoundService("BNSPR_GET_TRX_LIST_FOR_INSTALLMENT")
    public static GMMap getTrxListForInstallment(GMMap iMap) throws Exception {
        try{
            GMMap inputMap = new GMMap();
            GMMap outputMap = new GMMap();
            inputMap.put(CARD_NO , iMap.getString(CARD_NO));
            inputMap.put(CYCLE_TYPE , iMap.get(CYCLE_TYPE) == null ? "" : iMap.getString(CYCLE_TYPE));
            outputMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_TRX_LIST_FOR_INSTALLMENT" , inputMap);
            return outputMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_GET_INSTALLMENT_DEF")
    public static GMMap getInstallmentDef(GMMap iMap) throws Exception {
        try{
            GMMap oMap = new GMMap();
            oMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_INSTALLMENT_DEF" , iMap);
            int maxTaksit = oMap.getInt(LIST , 0 , "MAX_INSTALL_COUNT");
            int minTaksit = oMap.getInt(LIST , 0 , "MIN_INSTALL_COUNT");
            int j = 0;
            for (int i = minTaksit; i <= maxTaksit; i++){
                oMap.put("TAKSIT_SAYISI" , j , "NAME" , i);
                oMap.put("TAKSIT_SAYISI" , j , "VALUE" , i);
                j++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_MAKE_INSTALLMENT")
    public static GMMap makeInstallment(GMMap iMap) throws Exception {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            CrdTxninstallmentsTx crdTxninstallmentsTx = new CrdTxninstallmentsTx();
            crdTxninstallmentsTx.setInstallCode(iMap.getString("INSTALL_CODE"));
            crdTxninstallmentsTx.setInstallCount(iMap.getBigDecimal("INSTALL_COUNT"));
            crdTxninstallmentsTx.setKartNo(iMap.getString("CARD_NO"));
            crdTxninstallmentsTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            crdTxninstallmentsTx.setProvisionCode(iMap.getString("PROVISION_CODE"));
            crdTxninstallmentsTx.setTxnGuid(iMap.getString("TXN_GUID"));
            
            if (iMap.getBigDecimal("TRX_NO") == null){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                crdTxninstallmentsTx.setTxNo(trxNo);
                iMap.put("TRX_NO" , trxNo);
            } else crdTxninstallmentsTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            
            crdTxninstallmentsTx.setTxnOrigin(iMap.getString("TXN_SOURCE"));
            session.saveOrUpdate(crdTxninstallmentsTx);
            
            session.flush();
            
            iMap.put("TRX_NAME" , "4437");
            GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            
            return GMServiceExecuter.call("BNSPR_OCEAN_MAKE_INSTALLMENT" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_QUERY_OF_PAYMENT_PLAN")
    public static GMMap installmentSimulate(GMMap iMap) throws Exception {
        try{
            ValidateCardInstallmentData(iMap);
            GMMap oMap = new GMMap();
            GMMap pMap = new GMMap();
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date date = new Date();
            
            pMap.put(CARD_NO , iMap.get(CARD_NO) == null ? " " : iMap.getString(CARD_NO));
            pMap.put(CARD_LEVEL , iMap.get(CARD_LEVEL) == null ? " " : iMap.getString(CARD_LEVEL));
            pMap.put(COUNTRY_CODE , iMap.get(COUNTRY_CODE) == null ? "TR" : iMap.getString(COUNTRY_CODE));
            
            pMap.put(OTC , iMap.getString(OTC));
            pMap.put(OTS , iMap.getString(OTS));
            pMap.put(REQUEST_DATE , dateFormat.format(date));
            pMap.put(TXN_DATE , dateFormat.format(date));
            pMap.put(TXN_INSTALL_TYPE , iMap.getString(TXN_INSTALL_TYPE));
            pMap.put(TXN_SOURCE , iMap.getString(TXN_SOURCE));
            pMap.put(TXN_TRM , iMap.get(TXN_TRM) == null ? " " : iMap.getString(TXN_TRM));
            
            pMap.put(TXN_AMOUNT , iMap.getBigDecimal("TUTAR" , new BigDecimal(0)));
            pMap.put(INSTALL_COUNT , iMap.getInt("INSTALL_COUNT" , 0));
            pMap.put(PRODUCT_ID , iMap.get(PRODUCT_ID) == null ? " " : iMap.getString(PRODUCT_ID));
            
            pMap.put(MCC , iMap.getInt("MCC"));
            
            oMap = GMServiceExecuter.call("BNSPR_OCEAN_QUERY_OF_PAYMENT_PLAN" , pMap);
            int installCount = oMap.getSize("LIST");
            
            if (installCount > 0){
                oMap.put("ILK_ODEME_TARIHI" , oMap.getDate("LIST" , 0 , "INSTALL_DATE"));
                oMap.put("TOPLAM_TUTAR" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_AMOUNT"));
                oMap.put("ISLEM_UCRETI" , oMap.getBigDecimal("LIST" , 0 , "INSTALL_FEE"));
                oMap.put("TAKSIT_TUTARI" , oMap.getBigDecimal("LIST" , 0 , "INSTALL_AMOUNT"));
                oMap.put("SON_ODEME_TARIHI" , oMap.getDate("LIST" , installCount - 1 , "INSTALL_DATE"));
                oMap.put("FAIZ_ORANI" , oMap.getString("LIST" , installCount - 1 , "INTEREST_RATE"));
                oMap.put("TOPLAM_KKDF" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_KKDF_AMOUNT"));
                oMap.put("TOPLAM_BSMV" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_BSMV_AMOUNT"));
                oMap.put("FEE_BASIC" , oMap.getBigDecimal("LIST" , 0 , "FEE_BASIC"));
                
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    private static void ValidateCardInstallmentData(GMMap iMap) {
        try{
           
            if (iMap.get("CARD_NO") == null || iMap.getString("CARD_NO").isEmpty()){
                GMMap exMap = new GMMap();
                exMap.put("P1" , "Kart No  bo� olamaz");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
            
            if (!(iMap.getBigDecimal("TUTAR" , BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0)){
                GMMap exMap = new GMMap();
                exMap.put("P1" , "Tutar alan� s�f�rdan b�y�k olmal�!");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
            if (!(iMap.getBigDecimal("INSTALL_COUNT" , BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0)){
                GMMap exMap = new GMMap();
                exMap.put("P1" , "Taksit say�s� s�f�rdan b�y�k olmal�d�r!");
                exMap.put("HATA_NO" , "660");
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
}
