package tr.com.aktifbank.bnspr.creditcard.services;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY4413Services implements OceanMapKeys {
    
    @GraymoundService("BNSPR_QRY4413_GET_CARDS")
    public static GMMap getCardList(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap iMap2 = new GMMap();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        SimpleDateFormat sdf2 = new SimpleDateFormat("MM/yyyy");
        SimpleDateFormat sdf3 = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss");
        SimpleDateFormat sdf4 = new SimpleDateFormat("yyyyMMdd");
        iMap2.put(CUSTOMER_NO , iMap.getString("MUST_NO"));
        iMap2.put(CARD_NO , "");
        iMap2.put(CARD_DCI , iMap.getString("CARD_DCI"));
        //        iMap2.put("CARD_TYPE" , "ALL");
        iMap2.put("INPUT_PARAMETER_TYPE" , "CST");
        iMap2.put("NO_NEED_APPLICATIONS" , true);
        iMap2.put("CARD_BANK_STATUS_CC" , true);
        iMap2.put("PROCEED" , iMap.getString("PROCEED"));
        String offlinePin="";
        String offlinePinDesc="";
        GMMap oMapH = new GMMap();
        
        //-Hce
        boolean isVirtualPP = false;
        boolean isHceKart = false;
        boolean isHceKart_2 = false;
        boolean isKahramanKart = false;
        boolean isMchip = false;
        //-Hce
        
        oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , iMap);
        iMap2.put(CARD_BRANCH , oMapH.getString("SUBE_KOD"));
        try{
            
            GMMap oMap2 = new GMMap();
            oMap2 = (GMMap) GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN" , iMap2);
            String productId = "";
            for (int i = 0, k = 0; i < oMap2.getSize("CARD_DETAIL_INFO"); i++){
            	
				productId = !StringUtils.isEmpty(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID))? oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID) : "";

            	 //-Hce
            	isVirtualPP = KkProductsUtil.isVirtualProduct(productId);//"914".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));              
				isHceKart= KkProductsUtil.isHceProduct(productId, ONLINE);//"920".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart_2=  KkProductsUtil.isHceProduct(productId, OFFLINE,"ANKARA");//"921".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isKahramanKart=  KkProductsUtil.isHceProduct(productId, OFFLINE,"MARAS");//"922".equals(oMap2.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isMchip = KkProductsUtil.isMchipProduct(productId);//CreditCardQRY4410Services.mchipFilter(oMap2, i, 1,"CARD_DETAIL_INFO", PRODUCT_ID))
            	 //-Hce
            	
                if (("Debit".equals(oMap2.getString("CARD_DETAIL_INFO" , i , CARD_DCI)) || "Prepaid".equals(oMap2.getString("CARD_DETAIL_INFO" , i , CARD_DCI)) || 
                		KkProductsUtil.isUptPpProduct(productId) ||//"912".equals(oMap2.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID) )||
                		KkProductsUtil.isTroyDebitProduct(productId)||//"916".equals(oMap2.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID)) || 
                		isVirtualPP || isMchip )&& (!isHceKart && !isHceKart_2) && !isKahramanKart){
                	
                    String cardNo = oMap2.getString("CARD_DETAIL_INFO" , i , CARD_NO);
                    oMap.put("TABLO" , k , "CARD_NO" , cardNo);
                    oMap.put("TABLO" , k , "MASKED_CARD_NO" , CreditCardGeneralServices.maskCardNumberFirst6Last4(cardNo));
                    oMap.put("TABLO" , k , "OLD_CARD_NO" , oMap2.getString("CARD_DETAIL_INFO" , i , OLD_CARD_NO));
                    oMap.put("TABLO" , k , "CARD_DCI" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_DCI));
                    oMap.put("TABLO" , k , "EMBOSS_NAME" , oMap2.getString("CARD_DETAIL_INFO" , i , NAME));
                    oMap.put("TABLO" , k , "CARD_STAT_DESC" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_STAT_DESC));
                    oMap.put("TABLO" , k , "CARD_AVAIL_LIMIT" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_AVAIL_LIMIT));
                    oMap.put("TABLO" , k , "AVAILABLE_POINT" , oMap2.getString("CARD_DETAIL_INFO" , i , AVAILABLE_POINT));
                    oMap.put("TABLO" , k , "CARD_BRANCH" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_BRANCH));
                    oMap.put("TABLO" , k , "STATUS" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_STAT_CODE));
                    oMap.put("TABLO" , k , "SUBSTATUS" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_SUB_STAT_CODE));
                    oMap.put("TABLO" , k , "SYSTEM" , oMap2.getString("CARD_DETAIL_INFO" , i , SYSTEM));
                    oMap.put("TABLO" , k , "KMH_LIMIT" , oMap2.getString("CARD_DETAIL_INFO" , i , "KMH_LIMIT"));
                    oMap.put("TABLO" , k , "PRODUCT_ID" , oMap2.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID"));
                    
                    
                    try {
                        GMMap subeMap = getBranchName(oMap2.getString(CARD_DETAIL_INFO,i,CARD_BRANCH));
            			oMap.put("TABLO" , k , "CARD_BRANCH_NAME", subeMap.getString("SUBE_ADI"));						
					} catch (Exception e) {
						e.printStackTrace();
					}
                    
                    oMap.put("TABLO" , k , "EMBOSS_DATE" , oMap2.getString("CARD_DETAIL_INFO" , i , EMBOSS_DATE));
                    oMap.put("TABLO" , k , "STATUS" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_STAT_CODE));
                    oMap.put("TABLO" , k , "SUB_STATUS" , oMap2.getString("CARD_DETAIL_INFO" , i , CARD_SUB_STAT_CODE));
                    oMap.put("TABLO" , k , "SYSTEM" , oMap2.getString("CARD_DETAIL_INFO" , i , SYSTEM));
                    oMap.put("TABLO" , k, "CARD_BRANCH", oMap2.getString("CARD_DETAIL_INFO", i, CARD_BRANCH));
                    oMap.put("TABLO" , k, "PIN_RETRY_COUNT", oMap2.getString("CARD_DETAIL_INFO", i, PIN_RETRY_COUNT));
                    offlinePin=oMap2.getString("CARD_DETAIL_INFO", i, OFFLINE_PIN);
                    if("0".equals(offlinePin) || "1".equals(offlinePin))
                    	offlinePinDesc = "Normal";
                    else if ("2".equals(offlinePin) || "3".equals(offlinePin))
                    	offlinePinDesc = "Bloke";
                    else if ("-1".equals(offlinePin))
                    	offlinePinDesc = "Inaktif";
                    else
                    	offlinePinDesc = "Bilinmiyor";
                   	oMap.put("TABLO" , k, "OFFLINE_PIN", offlinePinDesc);
                    oMap.put("TABLO" , k, "DAILY_CASH_ADVANCE_LIMIT", oMap2.getString("CARD_DETAIL_INFO", i, DAILY_CASH_ADVANCE_LIMIT));
                    oMap.put("TABLO" , k, "DAILY_CASH_ADVANCE_LIMIT", oMap2.getString("CARD_DETAIL_INFO", i, DAILY_CASH_ADVANCE_LIMIT));
                    oMap.put("TABLO" , k, "MAX_AMOUNT_CASH_LOAD", oMap2.getString("CARD_DETAIL_INFO", i, MAX_AMOUNT_CASH_LOAD));
                    oMap.put("TABLO" , k, "ACCOUNT_NO", oMap2.getString("CARD_DETAIL_INFO", i, ACCOUNT_NO));
                    
                    if (StringUtils.isNotBlank(oMap2.getString("CARD_DETAIL_INFO" , i , LAST_PIN_TRY_DATE))){
                        oMap.put("TABLO" , k , "LAST_PIN_TRY_DATE" , sdf4.format(sdf3.parse(oMap2.getString("CARD_DETAIL_INFO" , i , LAST_PIN_TRY_DATE))));
                    }
                    
                    if (StringUtils.isNotBlank(oMap2.getString("CARD_DETAIL_INFO" , i , EXPIRY_DATE))){
                        oMap.put("TABLO" , k , "EXPIRY_DATE" , sdf2.format(sdf.parse(oMap2.getString("CARD_DETAIL_INFO" , i , EXPIRY_DATE))));
                    }
                    if (StringUtils.isNotBlank(oMap2.getString("CARD_DETAIL_INFO" , i , "ONCEKI_SKT"))){
                        oMap.put("TABLO" , k , "ONCEKI_SKT" , sdf2.format(sdf.parse(oMap2.getString("CARD_DETAIL_INFO" , i , "ONCEKI_SKT"))));
                    }
                    oMap.put("TABLO" , k, "DAILY_CASH_ADVANCE_LIMIT", oMap2.getString("CARD_DETAIL_INFO", i, "DAILY_CASH_ADVANCE_LIMIT"));
                    oMap.put("TABLO" , k, "MAX_AMOUNT_CASH_LOAD", oMap2.getString("CARD_DETAIL_INFO", i, "MAX_AMOUNT_CASH_LOAD"));
                    oMap.put("TABLO" , k, "CARD_EMBOSS_NAME_1", oMap2.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1"));
                    oMap.put("TABLO" , k, "CARD_STATUS_CHANGE_REASON", oMap2.getString("CARD_DETAIL_INFO", i, "CARD_STATUS_CHANGE_REASON"));
                    
                    boolean isEmbossRequested = GMServiceExecuter.call("BNSPR_INTRACARD_GET_EMBOSS_REQUEST" , new GMMap().put("CARD_NO", oMap.getString("TABLO", k, "CARD_NO")))
                            .getBoolean("IS_EMBOSS_REQUEST");
                    
                    oMap.put("TABLO" , k, "EMBOSS_REQUEST", isEmbossRequested);
                    oMap.put("TABLO" , k, "EMBOSS_REQUEST_DESC", isEmbossRequested ? "Yenilendi" : "");
                    oMap.put("TABLO" , k, "CARD_GROUP_DESC", oMap2.getString("CARD_DETAIL_INFO", i, "CARD_GROUP_DESC"));
                    k++;
                }
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    
	private static GMMap getBranchName(String subeKodu) {
		GMMap subeMap = new GMMap();
		subeMap.put("SUBE_KODU",subeKodu );
		subeMap = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_ADI" , subeMap);
		return subeMap;
	}

	
	
    @GraymoundService("BNSPR_QRY4413_GET_ACCOUNT_DETAILS")
    public static GMMap getCardAccount(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap nMap= new GMMap();
        Object[] inputValues;
        String funcStr;
        int i = 0;
        
        try{
                       
            oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", iMap));
            oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_ADI" , oMap));
            oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE" , iMap));           
            nMap=GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_LIST" , iMap);
                        
            oMap.put("BAKIYE", nMap.get("RESULTS",0, "BAKIYE"));
            oMap.put("KMH_LIMIT", nMap.get("RESULTS",0, "KMH_LIMIT"));
            
            funcStr = "{? = call pkg_hesap.durum_kodu(?)}";
            inputValues = new Object [2];
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("HESAP_NO");
            oMap.put("DURUM",(String)DALUtil.callOracleFunction(funcStr, BnsprType.STRING, inputValues));
            i = 0;
            
        } catch (Exception e){
            oMap.put("KULLANILABILIR_BAKIYE", "");
            oMap.put("SUBE_ADI", "");
            oMap.put("SUBE_KODU", "" );
            oMap.put("DURUM", "REZERVE");
            oMap.put("MUSTERI_TUR_KOD","" );
        }
        return oMap;
    }
    @GraymoundService("BNSPR_QRY4413_GET_MUSTERI_TUR")
    public static GMMap getMusteriTur(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
        try{
            GnlMusteri gnlMusteri = (GnlMusteri)session.get(GnlMusteri.class , iMap.getBigDecimal("MUSTERI_NO"));
            if(gnlMusteri!=null){
                oMap.put("MUSTERI_TUR_KOD" , "G".equals(gnlMusteri.getMusteriTurKod()) ? "Bireysel" : "Kurumsal");
            }
            
        } catch (Exception e){
            ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
	private static String maskCardNumber(String cardNumber) {
		return cardNumber.replaceAll("(\\w{1,6})(\\w{1,6})(\\w{1,4})" , "$1 ** **** $3");
	}


}
