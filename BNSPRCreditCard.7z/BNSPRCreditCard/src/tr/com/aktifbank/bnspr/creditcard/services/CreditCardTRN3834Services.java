package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.File;
import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruFotoGuncellemeTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3834Services {
	
	private static final String ISLEM_KODU = "3834";
	
	private static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-tff.properties");

	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	private static final Logger logger = Logger.getLogger(CreditCardTRN3834Services.class);

	@GraymoundService("BNSPR_TRN3834_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		
		BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		BigDecimal oncekiBasvuruNo = iMap.getBigDecimal("ONCEKI_BASVURU_NO");
		String fotoString = iMap.getString("FOTO_ARRAY");
		String serverPath = iMap.getString("SERVER_PATH");
		String onayliFotoGuncelle = "true".equals(iMap.getString("ONAYLI_FOTO_GUNCELLE")) ? "E" : "H";

		if (txNo == null) {
			CreditCardServicesUtil.raiseGMError("4183");
			logger.error("txNo bulunamadi");

		}
		if (basvuruNo == null) {
			logger.error("txNo bulunamadi. Tx No: " + txNo + "  Basvuru no: " + basvuruNo);
			CreditCardServicesUtil.raiseGMError("4675");
			
		}

		if (oncekiBasvuruNo == null && StringUtils.isBlank(serverPath)) {
			logger.error("basvuruNo bulunamadi. Tx No: " + txNo + "  Basvuru no: " + basvuruNo + "  Onceki Basvuru no: " + oncekiBasvuruNo);
			CreditCardServicesUtil.raiseGMError("4183");

		}
		if(oncekiBasvuruNo != null){
			TffBasvuru oncekiBasvuru = (TffBasvuru) session.get(TffBasvuru.class, oncekiBasvuruNo);
			if("IPTAL".equals(oncekiBasvuru.getDurumKod()) || "BASVURU".equals(oncekiBasvuru.getDurumKod())  || "FOTO".equals(oncekiBasvuru.getDurumKod())  || "FOTO_EKSIK".equals(oncekiBasvuru.getDurumKod())){
				logger.error("--------onceki basvuruda foto yok "+ "  Onceki Basvuru no: " + oncekiBasvuruNo + "   Basvuru no: " + basvuruNo);
				CreditCardServicesUtil.raiseGMError("4963");

			}
		}
		TffBasvuru  basvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
		if("IPTAL".equals(basvuru.getDurumKod()) || "BASVURU".equals(basvuru.getDurumKod())){
			CreditCardServicesUtil.raiseGMError("4674");
		}
		TffBasvuruFotoGuncellemeTx fotoTx = new TffBasvuruFotoGuncellemeTx();
		fotoTx.setTxNo(txNo);
		fotoTx.setBasvuruNo(basvuruNo);
		fotoTx.setOncekiBasvuruNo(oncekiBasvuruNo);
		fotoTx.setOnayliFotoGuncelle(onayliFotoGuncelle);
		fotoTx.setFotoPathTmp(serverPath);

		session.save(fotoTx);
		session.flush();
		GMMap islemMap = new GMMap();
		islemMap.put("TRX_NAME", ISLEM_KODU);
		islemMap.put("TRX_NO", txNo);
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3834_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		// Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		try {

			// Varsa islem numarasina ait bilgiyi al
			TffBasvuruFotoGuncellemeTx fotoTx = (TffBasvuruFotoGuncellemeTx) session.get(TffBasvuruFotoGuncellemeTx.class, trxNo);
			oMap.put("TX_NO", fotoTx.getTxNo());
			oMap.put("BASVURU_NO", fotoTx.getBasvuruNo());
			oMap.put("ONCEKI_BASVURU_NO", fotoTx.getOncekiBasvuruNo());
			oMap.put("ONAYLI_FOTO_GUNCELLEME", fotoTx.getOnayliFotoGuncelle());
			oMap.put("FOTO_PATH_TMP", fotoTx.getFotoPathTmp());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3834_GET_BASVURU_BILGILERI")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

		String basvuru = "SELECT basvuru_no,basvuru_no adi FROM BNSPR.tff_basvuru where  musteri_no=" + musteriNo;
		DALUtil.fillComboBox(oMap, "ONCEKI_BASVURU_NO", true, basvuru);
		oMap.put("ONCEKI_BASVURU_NO", 0, "NAME", "Se�im");
		oMap.put("ONCEKI_BASVURU_NO", 0, "VALUE", "0");
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3834_GET_BASVURU_INFO")
	public static GMMap getBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
		if(tffBasvuru == null){
			return oMap;
		}
		TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, basvuruNo);
		oMap.put("AD", tffBasvuruKimlik.getAd());
		oMap.put("SOYAD", tffBasvuruKimlik.getSoyad());
		oMap.put("KART_TIPI", tffBasvuru.getKartTipi());
		oMap.put("YAS", tffBasvuruKimlik.getDogumTar());
		oMap.put("CINSIYET", tffBasvuruKimlik.getCinsiyet());
		oMap.put("KANAL", tffBasvuru.getSource());
		oMap.put("DURUM_KOD", tffBasvuru.getDurumKod());
		oMap.put("TCKN", tffBasvuru.getTcKimlikNo());
		
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3834_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffBasvuruFotoGuncellemeTx fotoTx = (TffBasvuruFotoGuncellemeTx) session.get(TffBasvuruFotoGuncellemeTx.class, trxNo);
		if(fotoTx != null){
			session.refresh(fotoTx);
		}else{
			logger.error("FOTO_TX bos ");
		}
		
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, fotoTx.getBasvuruNo());
		GMMap fMap = new GMMap();

		fMap.put("TFF_BASVURU_NO", fotoTx.getBasvuruNo());
		fMap = GMServiceExecuter.call("BNSPR_TFF_FOTO_PATH_VER", fMap);
		String updatedPath = fMap.getString("PATH");

		if (fotoTx.getOncekiBasvuruNo() != null) {

			try {

				fMap.put("TFF_BASVURU_NO", fotoTx.getOncekiBasvuruNo());
				fMap = GMServiceExecuter.call("BNSPR_TFF_FOTO_PATH_VER", fMap);
				String newPath = fMap.getString("PATH");

				// eski fotoyu yedekle
				File yedek = new File(updatedPath);
				if(yedek.exists()){
					TffServicesHelper.copyFile(new File(updatedPath), new File(updatedPath + "_backup.jpg"));
				}

				// onceki basvurudan fotyu digerine kopyala
				TffServicesHelper.copyFile(new File(newPath), new File(updatedPath));

			} catch (Exception e) {
				e.printStackTrace();
				CreditCardServicesUtil.raiseGMError("4183");
			}

		} else {
			// eski fotoyu yedekle
			File yedek = new File(updatedPath);
			if(yedek.exists()){
				TffServicesHelper.copyFile(new File(updatedPath), new File(updatedPath + "_backup.jpg"));
			}

			// onceki basvurudan fotyu digerine kopyala
			TffServicesHelper.copyFile(new File(fotoTx.getFotoPathTmp()), new File(updatedPath));
		}
		fMap.put("TFF_BASVURU_NO", fotoTx.getBasvuruNo());
		if ("E".equals(fotoTx.getOnayliFotoGuncelle())) {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GISE_FOTO_GUNCELLE", fMap));
		}
		
		if ("FOTO_EKSIK".equals(tffBasvuru.getDurumKod())) {
			
			
			if( "KK".equals(tffBasvuru.getKartTipi()))
			{
				if("SMS".equals(tffBasvuru.getSource()) && tffBasvuru.getKkBasvuruNo() == null){
					GMMap kkBasvuru = new GMMap();
					kkBasvuru.put("KULLANICI_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", null).getString("KULLANICI_KOD"));
					kkBasvuru.put("UYE_NO", tffBasvuru.getTffUyeNo());
					kkBasvuru.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					//GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU", kkBasvuru);
					GMServiceExecuter.executeAsync("BNSPR_TFF_KK_BASVURU", kkBasvuru);
				}else{
					GMMap kkMap = new GMMap();
					kkMap.put("BASVURU_NO", tffBasvuru.getKkBasvuruNo());
					//kkMap.put("ISLEM_NO", oMap.get("TRX_NO"));
					kkMap.put("DURUM_KOD",  "VERI_KONTROL");
					kkMap.put("ISLEM_ACIKLAMA", "3834 Eksik/Hatali foto yuklendi");
					kkMap.put("TARIHCE_AKSIYON", "E");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", kkMap);
				}
			}
			
			GMMap durumMap = new GMMap();
			durumMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			durumMap.put("DURUM_KOD", "VERI_KONTROL");
			durumMap.put("ISLEM_ACIKLAMA", "3834 Foto eklendi");
			durumMap.put("TARIHCE_AKSIYON", "E");
			GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);

			// Veri kontrol havuzuna ekle

			GMMap sorguMap = new GMMap();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("KK_BASVURU_NO", tffBasvuru.getKkBasvuruNo());
			sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
			sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			sorguMap.put("SOURCE", tffBasvuru.getSource());
			GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap);

		} else if ("FOTO".equals(tffBasvuru.getDurumKod())) {

			GMMap durumMap = new GMMap();
			durumMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			durumMap.put("DURUM_KOD", "ODEME");
			durumMap.put("ISLEM_ACIKLAMA", "3834 Foto eklendi");
			durumMap.put("TARIHCE_AKSIYON", "E");
			GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3834_GET_FOTO")
	public static GMMap getFoto(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		try {

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru != null) {
				TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));

				iMap.put("TC_KIMLIK_NO", tffBasvuruKimlik.getTcKimlikNo());
				iMap.put("PASAPORT_NO", tffBasvuruKimlik.getPasaportNo());
				iMap.put("UYRUK_KOD", tffBasvuruKimlik.getUyrukKod());
				oMap = GMServiceExecuter.call("BNSPR_TRN3805_GET_FOTO", iMap);
			} else {
				oMap.put("FOTO_PATH", "");
				oMap.put("FOTO_DEGER_BASE64", "");
				oMap.put("FOTO_DEGER", "");
			}
		} catch (Exception e) {
			oMap.put("FOTO_PATH", "");
			oMap.put("FOTO_DEGER_BASE64", "");
			oMap.put("FOTO_DEGER", "");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		return oMap;
	}

}
