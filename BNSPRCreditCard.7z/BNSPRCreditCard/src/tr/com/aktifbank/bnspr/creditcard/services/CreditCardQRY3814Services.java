package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


/** TFF Basvuru Izleme Ekrani Servisleri
 * 
 * @author murat.el
 * @since 24.02.2014
 */
public class CreditCardQRY3814Services {

	/** Girilen kriterlere gore istenen tff basvurularini listeler.
	 * @author murat.el
	 * @since 24.02.2014
	 * @param iMap - Sorgu Kriterleri<br>
	 *        <li>BASVURU_NO
	 *        <li>TC_KIMLIK_NO
	 *        <li>MUSTERI_NO
	 *        <li>TFF_KART_TIPI
	 *        <li>ADI
	 *        <li>IKINCI_ADI
	 *        <li>SOYADI
	 *        <li>DURUM_LIST
	 *        <li>BASLANGIC_TAR
	 *        <li>BITIS_TAR
	 *        <li>KANAL_KODU
	 *        <li>CEP_TEL_ALAN
	 *        <li>CEP_TEL_NUMARA
	 *        <li>EUPT_HESAP_NO
	 *        <li>SOURCE
	 * @return oMap - Basvuru Listesi<br>
	 *         <li>BASVURU_BILGILERI
	 */
	@GraymoundService("BNSPR_QRY3814_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruIzlemeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3813.Rc_Qry3814_List_Basvuru()}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	
}
