package tr.com.aktifbank.bnspr.creditcard.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdServiceMap;
import tr.com.aktifbank.bnspr.dao.CrdServiceMapId;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardPAR4409Services implements OceanMapKeys {
	
	@GraymoundService("BNSPR_PAR4409_INITIALIZE")
	public static GMMap initiazlize(GMMap iMap) {
		try {
			
			GMMap oMap = new GMMap();
			
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
	}
	
	@GraymoundService("BNSPR_PAR4409_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
        try{
        	Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(CrdServiceMap.class);
            criteria.add(Restrictions.eq("id.serviceCode", iMap.getString("SERVICE_CODE")));
            criteria.addOrder(Order.asc("id.siraNo"));

            String tableName= "TABLE_PARAMETRE";
            
            int i=0;
            @SuppressWarnings("unchecked")
			List<CrdServiceMap> list = criteria.list();
            Iterator iter = list.iterator();
            while(iter.hasNext()){
            	CrdServiceMap crdServiceMapDelete= (CrdServiceMap) iter.next();
                session.delete(crdServiceMapDelete);
                session.flush();
                
            }
            
            while(i < iMap.getSize(tableName)){
            	CrdServiceMapId id = new CrdServiceMapId();
            	CrdServiceMap crdServiceMap= new CrdServiceMap();

                id.setServiceCode(iMap.getString(tableName, i, "SERVICE_CODE"));
                id.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));
                id.setSourceCode(iMap.getString(tableName, i, "SOURCE_CODE"));                
                
                crdServiceMap.setId(id);
                crdServiceMap.setBA(iMap.getString(tableName,   i, "B_A"));
                crdServiceMap.setHesapNo(iMap.getString(tableName,   i, "HESAP_NO"));
                crdServiceMap.setTutarFrom(iMap.getString(tableName,   i, "TUTAR_FROM"));       

                session.saveOrUpdate(crdServiceMap);
                session.flush();
                i++;
            }    
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
        oMap.put("MESSAGE", "��leminiz ba�ar�l� bir �ekilde ger�ekle�tirildi.");
        return oMap;
    }
	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR4409_SET_TABLE")
	public static GMMap setTable(GMMap iMap) {
		try {
			
			GMMap oMap = new GMMap();
			
			Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(CrdServiceMap.class);
            criteria.add(Restrictions.eq("id.serviceCode", iMap.getString("SERVICE_CODE")));
            criteria.addOrder(Order.asc("id.siraNo"));

            List<CrdServiceMap> list = criteria.list();
            List siraNoList = new ArrayList<Integer>();
            Iterator iter = list.iterator();
            int i = 0;
            String tableName= "TABLE_PARAMETRE";
            while (iter.hasNext()){
            	CrdServiceMap crdServiceMap = (CrdServiceMap) iter.next();
                oMap.put(tableName, i, "B_A"              , crdServiceMap.getBA());
                oMap.put(tableName, i, "HESAP_NO"         , crdServiceMap.getHesapNo());
                oMap.put(tableName, i, "TUTAR_FROM"       , crdServiceMap.getTutarFrom());
                oMap.put(tableName, i, "SERVICE_CODE"     , crdServiceMap.getId().getServiceCode());
                oMap.put(tableName, i, "SIRA_NO"          , crdServiceMap.getId().getSiraNo());
                siraNoList.add(crdServiceMap.getId().getSiraNo());
                oMap.put(tableName, i, "SOURCE_CODE"      , crdServiceMap.getId().getSourceCode());
                i++;
            }
            
            if(siraNoList != null && siraNoList.size() > 0){
            	Collections.sort(siraNoList);
            	oMap.put("MAX_SIRA_NO", siraNoList.get(siraNoList.size() - 1) );
            }
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
	}
	
	@GraymoundService("BNSPR_PAR4409_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();

        iMap.put("KOD", "CRD_MAP_TUTAR_FROM");
        oMap.put("COMBO_OUT", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
	
	
	
	@SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_PAR4409_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        try{
        	
        	GMMap oMap = new GMMap();
			
			Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(CrdServiceMap.class);
            criteria.add(Restrictions.eq("id.serviceCode", iMap.getString("SERVICE_CODE")));
            criteria.addOrder(Order.asc("id.siraNo"));

            List<CrdServiceMap> list = criteria.list();
            Iterator iter = list.iterator();
            int i = 0;
            String tableName= "TABLE_PARAMETRE";
        	
            while (iter.hasNext()){
            	CrdServiceMap crdServiceMap = (CrdServiceMap) iter.next();
                oMap.put(tableName, i, "B_A"          , crdServiceMap.getBA());
                oMap.put(tableName, i, "ALAN_TIPI"    , crdServiceMap.getHesapNo());
                oMap.put(tableName, i, "ALAN_TIPI"    , crdServiceMap.getTutarFrom());     

                oMap.put(tableName, i, "SERVICE_CODE" , crdServiceMap.getId().getServiceCode());
                oMap.put(tableName, i, "SIRA_NO"      , crdServiceMap.getId().getSiraNo());
                oMap.put(tableName, i, "SOURCE_CODE"  , crdServiceMap.getId().getSourceCode());
                i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }

}

