package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.lang.BooleanUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasvuruFraudTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdeme;
import tr.com.aktifbank.bnspr.dao.TffOtpBlackList;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** TFF Karti FRAUD islemlerini gerceklestiren servisleri icerir.
 * 
 * @author murat.el
 * @since 26.11.2013
 */
public class CreditCardTRN3807Services {
	
	/** Ekran ilk degerlerini al
	 *
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap
	 * @return oMap - AKSIYON_KOD
	 */
	@GraymoundService("BNSPR_TRN3807_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//FRAUD AKSIYON
			oMap.putAll(CreditCardServicesUtil.getParameterList("FRAUD_AKSIYON_KOD", "TFF_FRAUD_SONUC_KOD", "F", "E"));
			
			//BLOKE_AKSIYON
			oMap.putAll(CreditCardServicesUtil.getParameterList("BLOKE_AKSIYON_KOD", "TFF_FRAUD_SONUC_KOD", "B", "E"));
			
			//KILITLENME SEBEBI
			oMap.putAll(CreditCardServicesUtil.getParameterList("KILITLENME_SEBEBI", "TFF_WEBSERVIS_PARAM", "KARA_LISTE_TIPI", "HEPSI"));
			
			//DURUM
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            StringBuilder query = new StringBuilder("{? = call PKG_TRN3807.ComboTextAl(?,?)}");
            stmt = conn.prepareCall(query.toString());
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, "TFF_WEBSERVIS_PARAM");
            stmt.setString(3, "KARA_LISTE_DURUM");
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap.putAll(DALUtil.rSetResults(rSet, "DURUM"));
            GuimlUtil.wrapMyCombo(oMap, "DURUM", null, "Hepsi");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

		return oMap;
	}
	
	/** Verilen sorgulama kriterlerini alarak FRAUD durumunda ya da kara listeye dusmus basvurulari listeler.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO, PASAPORT_NO, CEP_TEL_ALAN, CEP_TEL_NUMARA, IP, KARA_LISTE_ID
	 * @return oMap - FRAUD_LIST
	 */
	@GraymoundService("BNSPR_TRN3807_LISTELE")
	public static GMMap listBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3807.Rc_Qry3807_List_Basvuru(?,?,?,?,?,?,?,?,?,?)}";
            int i = 1;
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
            stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
            stmt.setString(i++, iMap.getString("PASAPORT_NO"));
            stmt.setString(i++, iMap.getString("CEP_TEL_ALAN"));
            stmt.setString(i++, iMap.getString("CEP_TEL_NUMARA"));
            stmt.setString(i++, iMap.getString("IP"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("KARA_LISTE_ID"));
            stmt.setString(i++, iMap.getString("DURUM"));
            stmt.setString(i++, iMap.getString("KILITLENME_SEBEBI"));
            stmt.setString(i++, BooleanUtils.toString(iMap.getBoolean("AKSIYON_VAR_MI"), CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, "FRAUD_LIST");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

		return oMap;
	}
	
	/** Kara liste ya da FRAUDa dusen basvurular hakkinda alinan aksiyonu kaydeder.
	 * Alinan aksiyona gore islemler yapar.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - TRX_NO, KARA_LISTE_ID, AKSIYON_KOD, ACIKLAMA
	 * @return oMap - MESSAGE
	 */
	@GraymoundService("BNSPR_TRN3807_SAVE")
	public static GMMap save3807(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			//Sessiondan nesne al yoksa olustur
			TffBasvuruFraudTx tffBasvuruFraudTx = (TffBasvuruFraudTx)
					session.get(TffBasvuruFraudTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruFraudTx == null) {
				tffBasvuruFraudTx = new TffBasvuruFraudTx();
			}
			
			//Degerleri Kaydet
			tffBasvuruFraudTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tffBasvuruFraudTx.setKaraListeId(iMap.getBigDecimal("KARA_LISTE_ID"));
			tffBasvuruFraudTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			tffBasvuruFraudTx.setGorus(iMap.getString("ACIKLAMA"));
			session.saveOrUpdate(tffBasvuruFraudTx);
			session.flush();
			
			// Ana tablolara kayitlari kaydet
			iMap.put("TRX_NAME", "3807");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Kara liste ya da FRAUDa dusen basvurular hakkinda alinan aksiyonu verilen islem numarasi ile goruntuler.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - TRX_NO
	 * @return oMap - KARA_LISTE_ID, AKSIYON_KOD, ACIKLAMA, FRAUD_LIST
	 */
	@GraymoundService("BNSPR_TRN3807_GET_ISLEM_BILGI")
	public static GMMap getIslemBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			//Sessiondan nesne al yoksa olustur
			TffBasvuruFraudTx tffBasvuruFraudTx = (TffBasvuruFraudTx)
					session.get(TffBasvuruFraudTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruFraudTx != null) {
				oMap.put("KARA_LISTE_ID", tffBasvuruFraudTx.getKaraListeId());
				oMap.put("AKSIYON_KOD", tffBasvuruFraudTx.getAksiyonKod());
				oMap.put("ACIKLAMA", tffBasvuruFraudTx.getGorus());
			}
			
			iMap.put("KARA_LISTE_ID", tffBasvuruFraudTx.getKaraListeId());
			oMap.putAll(listBasvuruInfo(iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Islem sonrasi yapilacak islemleri gerceklestirir<br>
	 * @author murat.el
	 * @since 03.02.2014
	 * @param iMap - Islem bilgileri<br>
	 *         <li>ISLEM_NO - Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3807_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");
		StringBuilder mailBody = null;

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruFraudTx tffBasvuruFraudTx = (TffBasvuruFraudTx) session.get(TffBasvuruFraudTx.class, trxNo);
			if (tffBasvuruFraudTx != null && "1".equals(tffBasvuruFraudTx.getAksiyonKod())) {
				//Red edilen bilgi bir basvuruya mi ait
				TffOtpBlackList tffOtpBlackList = (TffOtpBlackList) session.get(TffOtpBlackList.class, tffBasvuruFraudTx.getKaraListeId());
				if (tffOtpBlackList != null && tffOtpBlackList.getBasvuruNo() != null) {
					//Odeme Bilgilerini Al
					TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, tffOtpBlackList.getBasvuruNo());
					if (tffBasvuruOdeme != null) {
						//Odeme Iade Et
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuruOdeme.getBasvuruNo());
						sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_KARTA_UCRET_IADE", sorguMap));
						
						//IAde islemi Basarisizsa Mail At.
						if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
							String iadeAciklama = sorguMap.getString("RESPONSE_DATA");

							sorguMap.clear();
							sorguMap.put("KOD", "TFF_WEBSERVIS_PARAM");
							sorguMap.put("KEY1", tffBasvuruOdeme.getOdemeSekli());
							sorguMap.put("KEY2", "ODEME_TIPI");
							String odemeSekli = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");

							mailBody = new StringBuilder();
							mailBody.append(tffBasvuruOdeme.getBasvuruNo());
							mailBody.append(" no'lu TFF basvurusunun ");
							mailBody.append(odemeSekli);
							mailBody.append(" ile yapilan ");
							mailBody.append(tffBasvuruOdeme.getOdemeRefId());
							mailBody.append(" referansli islemi iptal edilmistir.");
							mailBody.append(" Manuel iade surecini baslatiniz.");
							mailBody.append("\n");
							mailBody.append(" Islem Aciklamasi: ");
							mailBody.append("\n");
							mailBody.append(tffBasvuruFraudTx.getGorus());
							mailBody.append("\n");
							mailBody.append(" Iade Aciklamasi: ");
							mailBody.append("\n");
							mailBody.append(iadeAciklama);
						}
						
						//Mail atilacaksa gonder.
						if (mailBody != null) {
							sorguMap.clear();
							sorguMap.put("MAIL_TO_PARAM", "TFF_BASVURU_IPTAL_MAIL_TO");
							sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
							sorguMap.put("MAIL_SUBJECT", "TFF Basvuru Red - " + tffOtpBlackList.getBasvuruNo().toString());
							sorguMap.put("MAIL_BODY", mailBody);
							GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
						}
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
