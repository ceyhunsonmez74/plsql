package tr.com.aktifbank.bnspr.creditcard.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class CreditCardQRY3890Services {
	/**
	 * Project : PROJECT_NAME
	 * Used In : WHERE_WILL_BE_USED
	 * 
	 * DESC : DESCRIPTION
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            MUSTERI_NO
	 *            BASVURU_NO
	 *            TCKN
	 *            VKN
	 *            SORGU_NO
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         PARAM_O
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_QRY3890_LKS_SORGU_GELEN_DETAY")
	public static GMMap lksSorguGelenDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call BNSPR.PKG_LKS_ISLEM.rc_get_lks_sorgu_gelen_detay(?) }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GELEN_SORGU_LISTE", BnsprType.STRING, iMap.getString("SORGU_NO"));
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_QRY3890_LKS_SORGU_GIDEN_DETAY")
	public static GMMap lksSorguGidenDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call BNSPR.PKG_LKS_ISLEM.RC_GET_LKS_giden_sorgu_list(?) }";
			GMMap tMap = new GMMap();
			tMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_LISTE", BnsprType.STRING, iMap.getString("SORGU_NO"));
			oMap.putAll(tMap.getMap("GIDEN_SORGU_LISTE", 0));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	/**
	 * Project : LKS
	 * Used In : LKS Detay ekrani
	 * 
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            MUSTERI_NO
	 *            BASVURU_NO
	 *            TCKN
	 *            VKN
	 *            SORGU_NO
	 * 
	 * @return oMap (GMMap)
	 *         SORGU_LISTE
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_QRY3890_GET_LKS_SORGU_LISTE")
	public static GMMap getLksSorguListe(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call BNSPR.PKG_LKS_ISLEM.RC_GET_LKS_sorgu_list(?,?,?,?,?) }";

			oMap = DALUtil.callOracleRefCursorFunction(func, "SORGU_LISTE", BnsprType.STRING, iMap.getString("BASVURU_NO"), BnsprType.STRING, iMap.getString("MUSTERI_NO"), BnsprType.STRING, iMap.getString("SORGU_NO"), BnsprType.STRING, iMap.getString("TCKN"), BnsprType.STRING, iMap.getString("VKN"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
