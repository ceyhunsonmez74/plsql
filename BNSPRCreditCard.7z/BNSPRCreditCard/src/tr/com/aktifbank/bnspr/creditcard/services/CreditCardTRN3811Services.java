package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTxId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruGuncellemeTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlikTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgi;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgiTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdemeDegisenTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonTxId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.service.GMServiceException;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3811Services {
	
	private static final String ISLEM_SONRASI_MESAJ = "ISLEM_SONRASI_MESAJ";
	private static final Logger logger = Logger.getLogger(CreditCardTRN3811Services.class);
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>P1
	 *         <li>P2
	 */
	@GraymoundService("BNSPR_TRN3811_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Aksiyon Kod KK
			oMap.putAll(CreditCardServicesUtil.getParameterList("AKSIYON_KOD",
					"TFF_GUNCELLEME_AKSIYON_KOD", CreditCardServicesUtil.EVET));
			
			//Aksiyon TFF
			oMap.putAll(CreditCardServicesUtil.getParameterList("AKSIYON_KOD_TFF",
					"TFF_GUNCELLEME_AKSIYON_KOD", "TFF", CreditCardServicesUtil.EVET));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen musteri numarasina ait EPOS basvurularini listeler.<br>
	 * @param iMap - Musteri bilgileri<br>
	 *        <li>MUSTERI_NO - Islem numarasi
	 * @return Basvuru listesi<br>
	 *        <li>BASVURU_LIST - Musterinin EPOS kanalindan yapilan basvurulari
	 */
	@GraymoundService("BNSPR_TRN3811_LISTELE")
	public static GMMap listele(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3811.Rc_Qry3811_Get_Basvuru(?,?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, "BASVURU_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Alinan bilgilerle basvuru guncelleme islemi sonucu alinan karara gore islemleri gerceklestirir.<br>
	 * @param iMap - Basvuru guncelleme bilgileri<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 *        <li>TFF_TRX_NO - Tff basvuru kaydet/guncelle islem numarasi
	 *        <li>KK_TRX_NO - Kredi karti basvuru kaydet/guncelle islem numarasi
	 *        <li>AKSIYON_KOD - Basvuru guncellendikten sonra alinacak aksiyon
	 *        <li>ACIKLAMA - Islem aciklamasi
	 *        <li>ODEME_SEKLI - Odemenin yapildigi yer: Sanal Pos/EUPT
	 *        <li>ODEME_REF_ID - Odeme islem numarasi
	 *        <li>UCRET_LIST - Urun/Kurye degisikliginden dogan fark kalemleri
	 *        <li>TOPLAM_FARK - Toplam alinan ucret
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3811_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("TFF_TRX_NO"))) {
				CreditCardServicesUtil.raiseGMError("4141");
			}
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruGuncellemeTx tffBasvuruGuncellemeTx = (TffBasvuruGuncellemeTx)
					session.get(TffBasvuruGuncellemeTx.class, trxNo);
			if (tffBasvuruGuncellemeTx == null) {
				tffBasvuruGuncellemeTx = new TffBasvuruGuncellemeTx();
			}
			//Islem bilgilerini al.
			tffBasvuruGuncellemeTx.setTxNo(trxNo);
			tffBasvuruGuncellemeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tffBasvuruGuncellemeTx.setTffTrxNo(iMap.getBigDecimal("TFF_TRX_NO"));
			tffBasvuruGuncellemeTx.setKkTrxNo(iMap.getBigDecimal("KK_TRX_NO"));
			tffBasvuruGuncellemeTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			tffBasvuruGuncellemeTx.setAciklama(CreditCardServicesUtil.trimNewLine(iMap.getString("ACIKLAMA")));
			
			//Islem bilgilerini kaydet
			session.save(tffBasvuruGuncellemeTx);
			session.flush();
			
			//Odeme bilgilerini kaydet
			/*
			//Iade varsa al
			if (iMap.getBigDecimal("TOPLAM_FARK").compareTo(BigDecimal.ZERO) < 0) {
				saveOdemeDegisen(iMap);
			//Ek odeme gerekiyorsa odeme bilgilerini al
			} else if (iMap.getBigDecimal("TOPLAM_FARK").compareTo(BigDecimal.ZERO) > 0) {
				if (StringUtils.isNotBlank(iMap.getString("ODEME_REF_ID"))) {
					saveOdemeDegisen(iMap);
				} else {
					CreditCardServicesUtil.raiseGMError("4143");
				}
			}
			*/
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle basvuru guncelleme islemi sonucu alinan karara gore islemleri gerceklestirir.<br>
	 * @param iMap - Basvuru guncelleme bilgileri<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>BASVURU_NO - Tff basvuru numarasi
	 *        <li>ODEME_SEKLI - Odemenin yapildigi yer: Sanal Pos/EUPT
	 *        <li>ODEME_REF_ID - Odeme islem numarasi
	 *        <li>UCRET_LIST - Urun/Kurye degisikliginden dogan fark kalemleri
	 *        <li>TOPLAM_FARK - Toplam alinan ucret
	 * @return Islem sonucu<br>
	 */
	@GraymoundService("BNSPR_TRN3811_SAVE_ODEME_DEGISEN")
	public static GMMap saveOdemeDegisen(GMMap iMap) {
		GMMap oMap = new GMMap();
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			//Odeme bilgilerini kaydet
			TffBasvuruOdemeDegisenTx tffBasvuruOdemeDegisenTx = (TffBasvuruOdemeDegisenTx)
					session.get(TffBasvuruOdemeDegisenTx.class, trxNo);
			if (tffBasvuruOdemeDegisenTx == null) {
				tffBasvuruOdemeDegisenTx = new TffBasvuruOdemeDegisenTx();
			}
			//Islem bilgilerini al.
			tffBasvuruOdemeDegisenTx.setTxNo(trxNo);
			tffBasvuruOdemeDegisenTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tffBasvuruOdemeDegisenTx.setIslemKodu("3811");
			tffBasvuruOdemeDegisenTx.setOdemeSekli(iMap.getString("ODEME_SEKLI"));
			tffBasvuruOdemeDegisenTx.setOdemeRefId(iMap.getString("ODEME_REF_ID"));
			
			String listName = "UCRET_LIST";
			String alanKodu = "ALAN_KODU";
			BigDecimal eskiUcret = null;
			BigDecimal yeniUcret = null;
			for (int i = 0; i < iMap.getSize(listName); i++) {
				//Ucretleri al
				eskiUcret = iMap.getBigDecimal(listName, i, "ESKI_UCRET");
				yeniUcret = iMap.getBigDecimal(listName, i, "YENI_UCRET");
				//Ata
				if ("KART_BEDELI".equals(iMap.getString(listName, i, alanKodu))) {
					tffBasvuruOdemeDegisenTx.setEskiKartBedeli(eskiUcret);
					tffBasvuruOdemeDegisenTx.setYeniKartBedeli(yeniUcret);
				} else if ("VIZE_BEDELI".equals(iMap.getString(listName, i, alanKodu))) {
					tffBasvuruOdemeDegisenTx.setEskiVizeBedeli(eskiUcret);
					tffBasvuruOdemeDegisenTx.setYeniVizeBedeli(yeniUcret);
				} else if ("LOYALTY_BEDELI".equals(iMap.getString(listName, i, alanKodu))) {
					tffBasvuruOdemeDegisenTx.setEskiLoyaltyBedeli(eskiUcret);
					tffBasvuruOdemeDegisenTx.setYeniLoyaltyBedeli(yeniUcret);
				} else if ("KURYE_BEDELI".equals(iMap.getString(listName, i, alanKodu))) {
					tffBasvuruOdemeDegisenTx.setEskiKuryeBedeli(eskiUcret);
					tffBasvuruOdemeDegisenTx.setYeniKuryeBedeli(yeniUcret);
				}
			}
			
			//Islem bilgilerini kaydet
			session.save(tffBasvuruOdemeDegisenTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/** Tff guncelleme isleminin alan kontrollerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since 11.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3811_AFTER_CONTROL")
	public static GMMap afterControl3811(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3811.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Tff basvurusu guncelleme islemini sonlandirir.
	 * 
	 * @author murat.el
	 * @since 11.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Islem sonucu<br>
	 *         <li>MESSAGE - ISlem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3811_SEND_TRANSACTION")
	public static GMMap sendTransaction3811(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Islemi tamamla
			iMap.put("TRX_NAME", "3811");
			iMap.put("TRX_NO", iMap.get("TRX_NO"));
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			//Iptal islemi ise iptal edildigini hata mesajina ekle
			oMap.put("MESSAGE", oMap.getString("MESSAGE") + ADCSession.getString(ISLEM_SONRASI_MESAJ, StringUtils.EMPTY));
			ADCSession.remove(ISLEM_SONRASI_MESAJ);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Islem sonrasi yapilacak isleri tamamlar.<br>
	 * @author murat.el
	 * @since 11.03.2014
	 * @param iMap
	 *         <li>ISLEM_NO - Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3811_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasvuruGuncellemeTx tffBasvuruGuncellemeTx = (TffBasvuruGuncellemeTx)
					session.get(TffBasvuruGuncellemeTx.class, trxNo);
			if (tffBasvuruGuncellemeTx == null) {
				return oMap;
			}
			//Kart tipi kredi karti ise KK basvuru numarasini al
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruGuncellemeTx.getBasvuruNo());
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", tffBasvuruGuncellemeTx.getBasvuruNo().toString());
			}
			
			//Kredi karti basvurunu bul
			KkBasvuru kkBasvuru = null;
			if (CreditCardTffServices.TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
				kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, tffBasvuru.getKkBasvuruNo());
				if (kkBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", tffBasvuru.getKkBasvuruNo());
				}
			}
			
			//Iptal/Fraud olmayacaksa Tff basvuru bilgisini kaydet
			if (!"I".equals(tffBasvuruGuncellemeTx.getAksiyonKod()) &&
					!"A".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {
				//Kredi karti red oldu kart tipi donusumu yapilacak
				if ("KK_RED_JOB".equals(tffBasvuru.getDurumKod()) || 
						"IPTAL".equals(tffBasvuru.getDurumKod()) ||
						"BASIM".equals(tffBasvuru.getDurumKod())) {
					TffBasvuruTx tffBasvuruTx = (TffBasvuruTx) session.get(TffBasvuruTx.class, tffBasvuruGuncellemeTx.getTffTrxNo());
					if (tffBasvuruTx != null) {
						tffBasvuruTx.setDurumKod(tffBasvuru.getDurumKod());
						session.saveOrUpdate(tffBasvuruTx);
						session.flush();
					}
				}
				
				sorguMap.clear();
				sorguMap.put("TRX_NAME", "3801");
				sorguMap.put("TRX_NO", tffBasvuruGuncellemeTx.getTffTrxNo());
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", sorguMap);
				
				//Musteri Bilgilerini Guncelle
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
				sorguMap.put("SOURCE", "TFF");
				GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
			}
			
			//Kredi karti red oldu, kart tipi donusumu yapilamaz, iptal oldu.
			if ("IPTAL".equals(tffBasvuru.getDurumKod())) {
				ADCSession.put(ISLEM_SONRASI_MESAJ, "Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
				return oMap;
			}
			
			//Onayli foto guncelle
			if ("K".equals(tffBasvuruGuncellemeTx.getAksiyonKod()) ||
					"O".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {				
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GISE_FOTO_GUNCELLE", sorguMap));
				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
					logger.error("BASVURU NO:" + tffBasvuruGuncellemeTx.getBasvuruNo() +" Onayli foto guncellenemedi");
					throw new GMServiceException("Onayli foto guncellenemedi");
				}
			}
			
			//Basvuru aksiyonuna gore islemleri gerceklestir.
			//Foto Eksik
			if ("F".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {
				//KK basvuru ise red oldu mu, olmadi ise durum Guncelle
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
					if ("IPTAL".equals(kkBasvuru.getDurumKod())) {
						ADCSession.put(ISLEM_SONRASI_MESAJ, "Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
					} else if ("RED".equals(kkBasvuru.getDurumKod())) {
						ADCSession.put(ISLEM_SONRASI_MESAJ, "Kredi karti red oldugundan degerlendirme beklemektedir.");
					} else {
						//Kredi kart� durumunu guncelle.
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuru.getKkBasvuruNo());
						sorguMap.put("DURUM_KOD", "VERI_KONTROL");
						sorguMap.put("ISLEM_NO", tffBasvuruGuncellemeTx.getKkTrxNo());
						sorguMap.put("ISLEM_ACIKLAMA", tffBasvuruGuncellemeTx.getAciklama());
						sorguMap.put("TARIHCE_AKSIYON", "N");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap));
						//Tff durumunu guncelle.
						durumGuncelle(tffBasvuruGuncellemeTx.getBasvuruNo(),
								tffBasvuruGuncellemeTx.getTffTrxNo(),
								"FOTO_EKSIK_ONAY",
								tffBasvuruGuncellemeTx.getAciklama(),
								"G");
						//Veri kontrol havuzuna kayit at
						sorguMap.clear();
						sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						sorguMap.put("KK_BASVURU_NO", tffBasvuru.getKkBasvuruNo());
						sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
						sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
						sorguMap.put("HATALI_MI", CreditCardServicesUtil.HAYIR);
						sorguMap.put("ISLEM_KODU", "3825");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap));
					}
				} else {
					durumGuncelle(tffBasvuruGuncellemeTx.getBasvuruNo(),
							tffBasvuruGuncellemeTx.getTffTrxNo(),
							"FOTO_EKSIK_ONAY",
							tffBasvuruGuncellemeTx.getAciklama(),
							"G");
					//Veri kontrol havuzuna kayit at
					sorguMap.clear();
					sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
					sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
					sorguMap.put("HATALI_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("ISLEM_KODU", "3825");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap));
				}
			//Onaylandi
			} else if ("O".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {
				//KK basvuru ise sadece durum Guncelle
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
					//KK basvuru ise red oldu mu, olmadi ise durum Guncelle
					if ("IPTAL".equals(kkBasvuru.getDurumKod())) {
						ADCSession.put(ISLEM_SONRASI_MESAJ, "Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
					} else if ("RED".equals(kkBasvuru.getDurumKod())) {
						ADCSession.put(ISLEM_SONRASI_MESAJ, "Kredi karti red oldugundan degerlendirme beklemektedir.");
					} else if ("BASIM".equals(kkBasvuru.getDurumKod())){
						ADCSession.put(ISLEM_SONRASI_MESAJ, "Kredi karti basari ile basilmistir.");
					} else {
						durumGuncelle(tffBasvuruGuncellemeTx.getBasvuruNo(),
								tffBasvuruGuncellemeTx.getTffTrxNo(),
								"KREDI_KARTI",
								tffBasvuruGuncellemeTx.getAciklama(),
								"G");
					}
				//TFF basvuru ise basima gonder
				} else {
					//basim servislerini cagir
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
					sorguMap.put("ISLEM_NO", tffBasvuruGuncellemeTx.getTffTrxNo());
					sorguMap.put("DURUM_KOD", "BASIM");
					sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
					oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", sorguMap));
				}
			//Kredi karti istemiyor
			} else if ("K".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(tffBasvuru.getKartTipi())) {
					//KK basvurusunun durumunu iptale cek
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
					sorguMap.put("ISLEM_KOD", "3811");
					sorguMap.put("GEREKCE_KOD", "2");
					sorguMap.put("ACIKLAMA", tffBasvuruGuncellemeTx.getAciklama());
					sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
					//TFF basvurusunda kart donusumu yap.
					sorguMap.clear();
					sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
					sorguMap.put("BASVURU_IPTAL_EDILSIN_MI", CreditCardServicesUtil.EVET);
					sorguMap.put("ISLEM_NO", tffBasvuruGuncellemeTx.getTffTrxNo());
					sorguMap.put("ISLEM_KOD", "3811");
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_RED_KART_TIPI_DONUSTUR", sorguMap));
					//Kart tipine gore islem sonrasi mesaj duzenle
					if (StringUtils.isBlank(oMap.getString("KART_TIPI"))) {
						ADCSession.put(ISLEM_SONRASI_MESAJ, "Prepaid/Debit Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi");
					}
				} else {
					//basim servislerini cagir
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
					sorguMap.put("ISLEM_NO", tffBasvuruGuncellemeTx.getTffTrxNo());
					sorguMap.put("DURUM_KOD", "BASIM");
					sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
					oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", sorguMap));
				}
			//Iptal
			} else if ("I".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
				sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
				sorguMap.put("ISLEM_KOD", "3811");
				sorguMap.put("GEREKCE_KOD", "2");
				sorguMap.put("ACIKLAMA", tffBasvuruGuncellemeTx.getAciklama());
				sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.EVET);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
			//Fraud
			} else if ("A".equals(tffBasvuruGuncellemeTx.getAksiyonKod())) {
				durumGuncelle(tffBasvuruGuncellemeTx.getBasvuruNo(),
						tffBasvuruGuncellemeTx.getTffTrxNo(),
						"FRAUD",
						tffBasvuruGuncellemeTx.getAciklama(),
						"E");
			}
			
			try {
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
				sorguMap.put("CRM_TYPE", CrmTypes.MAIN);
				GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", sorguMap);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CRM adres guncellemesi yapilamadi BASVURU_NO:" + iMap.get("TFF_BASVURU_NO"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen islem numarasina ait yapilan tff basvuru guncelleme islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>BASVURU_NO - Tff basvuru numarasi
	 *         <li>TFF_TRX_NO - Tff basvuru kaydet/guncelle islem numarasi
	 *         <li>KK_TRX_NO - Kredi karti basvuru kaydet/guncelle islem numarasi
	 *         <li>AKSIYON_KOD - Tff basvurusu guncellendikten sonra alinan aksiyon
	 *         <li>ACIKLAMA - Islem aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3811_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Varsa islem numarasina ait bilgiyi al
			TffBasvuruGuncellemeTx tffBasvuruGuncellemeTx = (TffBasvuruGuncellemeTx)
					session.get(TffBasvuruGuncellemeTx.class, trxNo);
			if (tffBasvuruGuncellemeTx != null) {
				oMap.put("BASVURU_NO", tffBasvuruGuncellemeTx.getBasvuruNo());
				oMap.put("TFF_TRX_NO", tffBasvuruGuncellemeTx.getTffTrxNo());
				oMap.put("KK_TRX_NO", tffBasvuruGuncellemeTx.getKkTrxNo());
				oMap.put("AKSIYON_KOD", tffBasvuruGuncellemeTx.getAksiyonKod());
				oMap.put("ACIKLAMA", tffBasvuruGuncellemeTx.getAciklama());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static void durumGuncelle(BigDecimal basvuruNo, BigDecimal trxNo,
			String yeniDurum, String aciklama, String aksiyon) {
		GMMap kontrolMap = new GMMap();
		kontrolMap.put("BASVURU_NO", basvuruNo);
		kontrolMap.put("ISLEM_NO", trxNo);
		kontrolMap.put("DURUM_KOD", yeniDurum);
		kontrolMap.put("ISLEM_ACIKLAMA", aciklama);
		kontrolMap.put("TARIHCE_AKSIYON", aksiyon);
		GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", kontrolMap);
	}
	
	/** Kurye tipi veya urun degisikliklerinden dogabilecek ucret degisikliklerini hesaplar.<br>
	 * @author murat.el
	 * @since 30.03.2014
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO - Tff Basvuru numarasi
	 *        <li>URUN_ID - Urun id numarasi
	 *        <li>KURYE_TIPI - Kurye tipi
	 *        <li>UCRET_LIST - Mevcut yapilan degisiklikler
	 * @return Islem sonucu<br>
	 *        <li>UCRET_LIST - Son ucret hesap listesi
	 *        <li>TOPLAM_FARK - Ucret hesaplandiktan sonra bulunan toplam tutar
	 */
	@GraymoundService("BNSPR_TRN3811_UCRET_HESAPLA")
	public static GMMap ucretHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap ucretMap = new GMMap();
		String tableName = "UCRET_LIST";

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3811.Ucret_Hesapla(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("URUN_ID"));
			stmt.setString(4, iMap.getString("KURYE_TIPI"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			ucretMap = DALUtil.rSetMap(rSet);
			oMap.put("TOPLAM_FARK", ucretMap.get("TOPLAM_FARK"));
			
			//Bedel listesini olustur.
			oMap.put(tableName, iMap.get(tableName));
			int i = 0;
			if (StringUtils.isNotBlank(iMap.getString("URUN_ID"))) {
				//Kart Bedeli
				oMap.put(tableName, i, "ALAN_KODU", "KART_BEDELI");
				oMap.put(tableName, i, "ALAN_ADI", "Kart Bedeli");
				oMap.put(tableName, i, "ESKI_UCRET", ucretMap.get("ESKI_KART_BEDELI"));
				oMap.put(tableName, i, "YENI_UCRET", ucretMap.get("YENI_KART_BEDELI"));
				oMap.put(tableName, i++, "FARK", ucretMap.get("KART_BEDELI_FARK"));
				//Vize Bedeli
				oMap.put(tableName, i, "ALAN_KODU", "VIZE_BEDELI");
				oMap.put(tableName, i, "ALAN_ADI", "Vize Bedeli");
				oMap.put(tableName, i, "ESKI_UCRET", ucretMap.get("ESKI_VIZE_BEDELI"));
				oMap.put(tableName, i, "YENI_UCRET", ucretMap.get("YENI_VIZE_BEDELI"));
				oMap.put(tableName, i++, "FARK", ucretMap.get("VIZE_BEDELI_FARK"));
				//Vize Bedeli
				oMap.put(tableName, i, "ALAN_KODU", "LOYALTY_BEDELI");
				oMap.put(tableName, i, "ALAN_ADI", "Loyalty Bedeli");
				oMap.put(tableName, i, "ESKI_UCRET", ucretMap.get("ESKI_LOYALTY_BEDELI"));
				oMap.put(tableName, i, "YENI_UCRET", ucretMap.get("YENI_LOYALTY_BEDELI"));
				oMap.put(tableName, i++, "FARK", ucretMap.get("LOYALTY_BEDELI_FARK"));
			}
			//Kurye Bedeli
			if (StringUtils.isNotBlank(iMap.getString("KURYE_TIPI"))) {
				oMap.put(tableName, i, "ALAN_KODU", "KURYE_BEDELI");
				oMap.put(tableName, i, "ALAN_ADI", "Kurye Bedeli");
				oMap.put(tableName, i, "ESKI_UCRET", ucretMap.get("ESKI_KURYE_BEDELI"));
				oMap.put(tableName, i, "YENI_UCRET", ucretMap.get("YENI_KURYE_BEDELI"));
				oMap.put(tableName, i++, "FARK", ucretMap.get("KURYE_BEDELI_FARK"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	//--------------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------- 3801 REFACTORING
	//--------------------------------------------------------------------------------------------
	/** Alinan bilgilerle aktif nokta tff basvuru ve uye kaydini olusturur/gunceller.<br>
	 * @param iMap - Uye/Basvuru bilgileri<br>
	 *		  @see {@link tr.com.aktifbank.bnspr.tff.services.TffCommonServices#createOrUpdateMember(GMMap)}
	 *		  @see {@link tr.com.aktifbank.bnspr.tff.services.TffCommonServices#addOrUpdateMemberPhone(GMMap)}
	 *		  @see {@link tr.com.aktifbank.bnspr.tff.services.TffCommonServices#addOrUpdateMemberAddress(GMMap)}
	 *	      @see {@link tr.com.aktifbank.bnspr.tff.services.TffCommonServices#addOrUpdateMemberOccupation(GMMap)}
	 *        @see {@link #saveBasvuru(GMMap)}
	 *        @see {@link #saveKimlik(GMMap)}
	 *        @see {@link #saveAdres(GMMap)}
	 *        @see {@link #saveTelefon(GMMap)}
	 *        @see {@link #saveMeslek(GMMap)}
	 * @return Islem sonucu<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_AKTIF_NOKTA")
	public static GMMap saveAktifNokta(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap uyeMap = new GMMap();

		try {
			//Default degerleri ata
			//Email alanini kontrol et.
			if ("@".equals(iMap.getString("EMAIL"))) {
				iMap.put("EMAIL", StringUtils.EMPTY);
			}
			//Meslek secilmemisse Diger olsun
			if (StringUtils.isBlank(iMap.getString("MESLEK"))) {
				iMap.put("MESLEK", "14");
			}
			
			//Uye Olustur/Guncelle
			uyeMap.clear();
			uyeMap.putAll(saveOrUpdateUye(iMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(uyeMap.getString("RESPONSE"))) {
				if (StringUtils.isBlank(uyeMap.getString("RESPONSE_DATA"))) {
					throw new GMRuntimeException(0, "Uye bilgileri guncellenirken hata olustu");
				} else {
					sorguMap.clear();
					sorguMap.put("WEB_HATA_KOD", uyeMap.getString("RESPONSE_DATA"));
					sorguMap.put("SOURCE", "GENEL");
					sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_HATA_MESAJI_AL", sorguMap));
					throw new GMRuntimeException(0, "Uye bilgileri guncellenirken hata olustu : " + sorguMap.getString("HATA_MESAJI"));
				}
			} else {
				if (StringUtils.isBlank(uyeMap.getString("UYE_NO"))) {
					throw new GMRuntimeException(0, "Uye Kaydi Olusturulamadi");
				}
			}
			
			//Basvuru Olustur/Guncelle
			save3801(iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("UYE_NO", uyeMap.get("UYE_NO"));
		return oMap;
	}

	/** Alinan bilgilerle tff uye kaydini olusturur/gunceller.<br>
	 * @param iMap - Uye bilgileri<br>
	 *        <li>UYE_NO
	 *        <li>UYRUK_KOD
	 *        <li>TCKN
	 *        <li>PASAPORT_NO
	 *        <li>TFF_BASVURU_NO
	 *        <li>DOGUM_TARIHI
	 *        <li>SOURCE
	 *        <li>CEP_ULKE_KOD
	 *        <li>CEP_ALAN_KOD
	 *        <li>CEP_NUMARA
	 *        <li>EMAIL
	 *        <li>TAKIM
	 *        <li>ANNE_KIZLIK_SOYADI
	 *        <li>EGITIM
	 *        <li>CALISMA_SEKLI
	 *        <li>AD1
	 *        <li>AD2
	 *        <li>SOYAD
	 *        <li>DOGUM_TARIHI
	 *		  <li>CLIENT_IP
	 * @return Islem sonucu<br>
	 *        <li>RESPONSE
	 *        <li>RESPONSE_DATA
	 *        <li>UYE_NO
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_UYE")
	public static GMMap saveOrUpdateUye(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Temel uye bilgilerini guncelle
			sorguMap.clear();
			sorguMap.put("UYE_NO", iMap.get("UYE_NO"));
			sorguMap.put("UYRUK", iMap.get("UYRUK_KOD"));
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("PASAPORT_NO", iMap.get("PASAPORT_NO"));
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("WEB_DOGUM_TARIHI", iMap.get("DOGUM_TARIHI"));
			sorguMap.put("SOURCE", iMap.get("SOURCE"));
			sorguMap.put("CEP_ULKE_KOD", iMap.get("CEP_ULKE_KOD"));
			sorguMap.put("CEP_ALAN_KOD", iMap.get("CEP_ALAN_KOD"));
			sorguMap.put("CEP_NUMARA", iMap.get("CEP_NUMARA"));
			sorguMap.put("EPOSTA", iMap.get("EMAIL"));
			sorguMap.put("EMAIL", iMap.get("EMAIL"));
			sorguMap.put("TAKIM", iMap.get("TAKIM"));
			sorguMap.put("ANNE_KIZLIK_SOYADI", iMap.get("ANNE_KIZLIK_SOYADI"));
			sorguMap.put("OGRENIM_DURUMU", iMap.get("EGITIM"));
			sorguMap.put("CALISMA_SEKLI", iMap.get("CALISMA_SEKLI"));
			sorguMap.put("WEB_ADI", iMap.get("AD1"));
			sorguMap.put("WEB_IKINCI_ADI", iMap.get("AD2"));
			sorguMap.put("WEB_SOYADI", iMap.get("SOYAD"));
			sorguMap.put("WEB_DOGUM_TARIHI", iMap.get("DOGUM_TARIHI"));
			sorguMap.put("CLIENT_IP", iMap.get("CLIENT_IP"));
			sorguMap.put("ONAYLANDI_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_CREATE_OR_UPDATE_MEMBER", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("UYE_NO", sorguMap.get("UYE_NO"));
				oMap.put("MUSTERI_NO", sorguMap.get("MUSTERI_NO"));
				oMap.put("EUPT_REF_ID", sorguMap.get("EUPT_REF_ID"));
			} else {
				oMap.put("RESPONSE", sorguMap.get("RESPONSE"));
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Alinan bilgilerle aktif nokta tff basvuru kaydini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        @see {@link #saveBasvuru(GMMap)}
	 *        @see {@link #saveKimlik(GMMap)}
	 *        @see {@link #saveAdres(GMMap)}
	 *        @see {@link #saveTelefon(GMMap)}
	 *        @see {@link #saveMeslek(GMMap)}
	 * @return Islem sonucu<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE")
	public static GMMap save3801(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
			//Basvuru Olustur/Guncelle
			saveBasvuru(iMap);
			//Basvuru Kimlik Kaydet
			saveKimlik(iMap);
			//Basvuru Adres Kaydet
			//Ev
			if (StringUtils.isNotBlank(iMap.getString("EV_IL_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("EV_ILCE_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("EV_ACIK_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", "E");//Ev
				sorguMap.put("IL_KOD", iMap.get("EV_IL_KOD"));
				sorguMap.put("IL_AD", iMap.get("EV_IL_AD"));
				sorguMap.put("ILCE_KOD", iMap.get("EV_ILCE_KOD"));
				sorguMap.put("ILCE_AD", iMap.get("EV_ILCE_AD"));
				sorguMap.put("ACIK_ADRES", iMap.get("EV_ACIK_ADRES"));
				sorguMap.put("TESLIMAT_ADRESI_MI", "E".equals(iMap.getString("TESLIMAT_ADRESI_TIPI"))?"E":"H");
				sorguMap.put("ILETISIM_MI", "E".equals(iMap.getString("ILETISIM_TIPI"))?"E":"H");
				GMMap adresMap = saveAdres(sorguMap);
				oMap.put("EV_ADRES_NO", adresMap.getString("EV_ADRES_NO"));
			}
			//Is
			if (StringUtils.isNotBlank(iMap.getString("IS_IL_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("IS_ILCE_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("IS_ACIK_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", "I");//Is
				sorguMap.put("IL_KOD", iMap.get("IS_IL_KOD"));
				sorguMap.put("IL_AD", iMap.get("IS_IL_AD"));
				sorguMap.put("ILCE_KOD", iMap.get("IS_ILCE_KOD"));
				sorguMap.put("ILCE_AD", iMap.get("IS_ILCE_AD"));
				sorguMap.put("ACIK_ADRES", iMap.get("IS_ACIK_ADRES"));
				sorguMap.put("TESLIMAT_ADRESI_MI", "I".equals(iMap.getString("TESLIMAT_ADRESI_TIPI"))?"E":"H");
				sorguMap.put("ILETISIM_MI", "I".equals(iMap.getString("ILETISIM_TIPI"))?"E":"H");
				GMMap adresMap = saveAdres(sorguMap);
				oMap.put("IS_ADRES_NO", adresMap.getString("IS_ADRES_NO"));

			}
			//Diger
			if (StringUtils.isNotBlank(iMap.getString("DIGER_IL_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("DIGER_ILCE_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("DIGER_ACIK_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", "D");//Diger
				sorguMap.put("IL_KOD", iMap.get("DIGER_IL_KOD"));
				sorguMap.put("IL_AD", iMap.get("DIGER_IL_AD"));
				sorguMap.put("ILCE_KOD", iMap.get("DIGER_ILCE_KOD"));
				sorguMap.put("ILCE_AD", iMap.get("DIGER_ILCE_AD"));
				sorguMap.put("ACIK_ADRES", iMap.get("DIGER_ACIK_ADRES"));
				sorguMap.put("ACIK_ADRES", iMap.get("DIGER_ACIK_ADRES"));
				sorguMap.put("TESLIMAT_ADRESI_MI", "D".equals(iMap.getString("TESLIMAT_ADRESI_TIPI"))?"E":"H");
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.HAYIR);
				saveAdres(sorguMap);
			}
			//Nokta
			if (StringUtils.isNotBlank(iMap.getString("NOKTA_IL_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("NOKTA_ILCE_KOD")) ||
					StringUtils.isNotBlank(iMap.getString("NOKTA_ACIK_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", iMap.getString("TESLIMAT_ADRESI_TIPI"));
				sorguMap.put("IL_KOD", iMap.get("NOKTA_IL_KOD"));
				sorguMap.put("IL_AD", iMap.get("NOKTA_IL_AD"));
				sorguMap.put("ILCE_KOD", iMap.get("NOKTA_ILCE_KOD"));
				sorguMap.put("ILCE_AD", iMap.get("NOKTA_ILCE_AD"));
				sorguMap.put("ACIK_ADRES", iMap.get("NOKTA_ACIK_ADRES"));
				sorguMap.put("TESLIMAT_NOKTASI_KODU", iMap.get("NOKTA_KODU"));
				if ("TN".equals(iMap.getString("TESLIMAT_ADRESI_TIPI")) ||
						"GN".equals(iMap.getString("TESLIMAT_ADRESI_TIPI"))) {
					sorguMap.put("TESLIMAT_ADRESI_MI", "E");
				} else {
					sorguMap.put("TESLIMAT_ADRESI_MI", "H");
				}
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.HAYIR);
				saveAdres(sorguMap);
			}
			//Basvuru Telefon Kaydet
			//Cep
			//Iletisim tipi secilmezse cep telefonu otomatik olarak atanir.
			if (StringUtils.isNotBlank(iMap.getString("CEP_NUMARA"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("TELEFON_TIPI", "C");//Cep
				sorguMap.put("ALAN_KOD", iMap.get("CEP_ALAN_KOD"));
				sorguMap.put("NUMARA", iMap.get("CEP_NUMARA"));
				sorguMap.put("ULKE_KOD", iMap.get("CEP_ULKE_KOD"));
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.EVET);
				saveTelefon(sorguMap);
			}
			//Ev
			if (StringUtils.isNotBlank(iMap.getString("EV_NUMARA"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("TELEFON_TIPI", "E");//Ev
				sorguMap.put("ALAN_KOD", iMap.get("EV_ALAN_KOD"));
				sorguMap.put("NUMARA", iMap.get("EV_NUMARA"));
				sorguMap.put("ULKE_KOD", iMap.get("EV_ULKE_KOD"));
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.HAYIR);
				saveTelefon(sorguMap);
			}
			//Is
			if (StringUtils.isNotBlank(iMap.getString("IS_NUMARA"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", iMap.get("ISLEM_FLAG"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("TELEFON_TIPI", "I");//Is
				sorguMap.put("ALAN_KOD", iMap.get("IS_ALAN_KOD"));
				sorguMap.put("NUMARA", iMap.get("IS_NUMARA"));
				sorguMap.put("ULKE_KOD", iMap.get("IS_ULKE_KOD"));
				sorguMap.put("DAHILI", iMap.get("DAHILI"));
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.HAYIR);
				saveTelefon(sorguMap);
			}
			//Basvuru Meslek Kaydet
			saveMeslek(iMap);
			//KK basvuru Kaydet
			if (CreditCardTffServices.TFF_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
				saveKrediKarti(iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/** Alinan bilgilerle tff basvuru bilgisini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>CALISMA_SEKLI
	 *        <li>DURUM_KODU
	 *        <li>EMAIL
	 *        <li>EUPT_REF_ID - Ekrandan gelmiyor nerden alcaz???
	 *        <li>KANAL_KODU - Ekrandan gelmiyor/servis icerisinden al
	 *        <li>KART_NO
	 *        <li>KART_TIPI
	 *        <li>KK_BASVURU_NO
	 *        <li>KURYE_TIPI
	 *        <li>MUSTERI_NO
	 *        <li>CLIENT_IP
	 *        <li>SOURCE
	 *        <li>TAKIM
	 *        <li>TCKN
	 *        <li>UYE_NO
	 *        <li>URUN_KODU
	 *        <li>URUN_SAHIP_KODU
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_BASVURU")
	public static GMMap saveBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al
			TffBasvuruTx tffBasvuruTx = (TffBasvuruTx) session.get(TffBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruTx == null){
				tffBasvuruTx = new TffBasvuruTx();
				tffBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				tffBasvuruTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			}
			
			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}
				
				tffBasvuruTx.setCalismaSekli(CreditCardServicesUtil.nvl(iMap.getString("CALISMA_SEKLI"), tffBasvuru.getCalismaSekli()));
				tffBasvuruTx.setDurumKod(CreditCardServicesUtil.nvl(iMap.getString("DURUM_KODU"), tffBasvuru.getDurumKod()));
				tffBasvuruTx.setEPosta(CreditCardServicesUtil.nvl(iMap.getString("EMAIL"), tffBasvuru.getEPosta()));
				tffBasvuruTx.setEuptUserId(CreditCardServicesUtil.nvl(iMap.getString("EUPT_REF_ID"), tffBasvuru.getEuptUserId()));
				tffBasvuruTx.setKanalKod(CreditCardServicesUtil.nvl(iMap.getString("KANAL_KODU"), tffBasvuru.getKanalKod()));
				tffBasvuruTx.setKartNo(CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), tffBasvuru.getKartNo()));
				tffBasvuruTx.setKartTipi(CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), tffBasvuru.getKartTipi()));
				tffBasvuruTx.setKkBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KK_BASVURU_NO"), tffBasvuru.getKkBasvuruNo()));
				tffBasvuruTx.setKuryeTipi(CreditCardServicesUtil.nvl(iMap.getString("KURYE_TIPI"), tffBasvuru.getKuryeTipi()));
				tffBasvuruTx.setMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), tffBasvuru.getMusteriNo()));
				tffBasvuruTx.setSessionIp(CreditCardServicesUtil.nvl(iMap.getString("CLIENT_IP"), tffBasvuru.getSessionIp()));
				tffBasvuruTx.setSource(CreditCardServicesUtil.nvl(iMap.getString("SOURCE"), tffBasvuru.getSource()));
				tffBasvuruTx.setTakim(CreditCardServicesUtil.nvl(iMap.getString("TAKIM"), tffBasvuru.getTakim()));
				tffBasvuruTx.setTcKimlikNo(CreditCardServicesUtil.nvl(iMap.getString("TCKN"), tffBasvuru.getTcKimlikNo()));
				tffBasvuruTx.setTffUyeNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("UYE_NO"), tffBasvuru.getTffUyeNo()));
				tffBasvuruTx.setUrun(CreditCardServicesUtil.nvl(iMap.getString("URUN_KODU"), tffBasvuru.getUrun()));
				tffBasvuruTx.setUrunSahipKodu(CreditCardServicesUtil.nvl(iMap.getString("URUN_SAHIP_KODU"), tffBasvuru.getUrunSahipKodu()));
				tffBasvuruTx.setGiseId(CreditCardServicesUtil.nvl(iMap.getString("GISE_ID"), tffBasvuru.getGiseId()));
				tffBasvuruTx.setGiseUser(CreditCardServicesUtil.nvl(iMap.getString("GISE_USER"), tffBasvuru.getGiseUser()));
				tffBasvuruTx.setUrunId(CreditCardServicesUtil.nvl(iMap.getBigDecimal("URUN_ID"), tffBasvuru.getUrunId()));
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				//Kanal Kodu Belirle
				if (StringUtils.isBlank(iMap.getString("KANAL_KODU"))) {
					iMap.put("KANAL_KODU", GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMap).getString("KANAL_KOD"));
				}
				
				tffBasvuruTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
				tffBasvuruTx.setDurumKod(iMap.getString("DURUM_KODU"));
				tffBasvuruTx.setEPosta(iMap.getString("EMAIL"));
				tffBasvuruTx.setEuptUserId(iMap.getString("EUPT_REF_ID"));
				tffBasvuruTx.setKanalKod(iMap.getString("KANAL_KODU"));
				tffBasvuruTx.setKartNo(iMap.getString("KART_NO"));
				tffBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
				tffBasvuruTx.setKkBasvuruNo(iMap.getBigDecimal("KK_BASVURU_NO"));
				tffBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
				tffBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				tffBasvuruTx.setSessionIp(iMap.getString("CLIENT_IP"));
				tffBasvuruTx.setSource(iMap.getString("SOURCE"));
				tffBasvuruTx.setTakim(iMap.getString("TAKIM"));
				tffBasvuruTx.setTcKimlikNo(iMap.getString("TCKN"));
				tffBasvuruTx.setTffUyeNo(iMap.getBigDecimal("UYE_NO"));
				tffBasvuruTx.setUrun(iMap.getString("URUN_KODU"));
				tffBasvuruTx.setUrunSahipKodu(iMap.getString("URUN_SAHIP_KODU"));
				tffBasvuruTx.setGiseId(iMap.getString("GISE_ID"));
				tffBasvuruTx.setGiseUser(iMap.getString("GISE_USER"));
				tffBasvuruTx.setUrunId(iMap.getBigDecimal("URUN_ID"));
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(tffBasvuruTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle tff basvuru kimlik bilgisini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>UYRUK_KOD
	 *        <li>ANNE_KIZLIK_SOYADI
	 *        <li>AD1
	 *        <li>AILE_SIRA_NO
	 *        <li>ANNE_AD
	 *        <li>BABA_AD
	 *        <li>BIREY_SIRA_NO
	 *        <li>CILT_KODU
	 *        <li>CINSIYET
	 *        <li>DOGUM_TARIHI
	 *        <li>DOGUM_YERI
	 *        <li>ES_TCKN
	 *        <li>AD2
	 *        <li>KAYIP_CUZDAN_SERI_NO
	 *        <li>KAYIP_CUZDAN_SIRA_NO
	 *        <li>KIMLIK_SERI_NO
	 *        <li>KIMLIK_SIRA_NO
	 *        <li>MAHALLE_KOY
	 *        <li>MEDENI_HALI
	 *        <li>ILCE_KODU
	 *        <li>IL_KODU
	 *        <li>VERILIS_NEDENI
	 *        <li>VERILIS_TARIHI
	 *        <li>VERILDIGI_ILCE_ADI
	 *        <li>KIZLIK_SOYAD
	 *        <li>SOYAD
	 *        <li>TCKN
	 *        <li>PASAPORT_NO
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_KIMLIK")
	public static GMMap saveKimlik(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al
			TffBasvuruKimlikTx tffBasvuruKimlikTx = (TffBasvuruKimlikTx)
					session.get(TffBasvuruKimlikTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruKimlikTx == null){
				tffBasvuruKimlikTx = new TffBasvuruKimlikTx();
				tffBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				tffBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			}
			
			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik)
						session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffBasvuruKimlik == null){
					CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}
				
				tffBasvuruKimlikTx.setUyrukKod(iMap.getString("UYRUK_KOD", tffBasvuruKimlik.getUyrukKod()));
				if ("TR".equals(tffBasvuruKimlikTx.getUyrukKod())) {
					tffBasvuruKimlikTx.setAnneKizlik(CreditCardServicesUtil.nvl(iMap.getString("ANNE_KIZLIK_SOYADI"), tffBasvuruKimlik.getAnneKizlik()));
					tffBasvuruKimlikTx.setAd(CreditCardServicesUtil.nvl(iMap.getString("AD1"), tffBasvuruKimlik.getAd()));
					tffBasvuruKimlikTx.setAileSiraNo(CreditCardServicesUtil.nvl(iMap.getString("AILE_SIRA_NO"), tffBasvuruKimlik.getAileSiraNo()));
					tffBasvuruKimlikTx.setAnneAdi(CreditCardServicesUtil.nvl(iMap.getString("ANNE_AD"), tffBasvuruKimlik.getAnneAdi()));
					tffBasvuruKimlikTx.setBabaAd(CreditCardServicesUtil.nvl(iMap.getString("BABA_AD"), tffBasvuruKimlik.getBabaAd()));
					tffBasvuruKimlikTx.setBireySiraNo(CreditCardServicesUtil.nvl(iMap.getString("BIREY_SIRA_NO"), tffBasvuruKimlik.getBireySiraNo()));
					tffBasvuruKimlikTx.setCiltNo(CreditCardServicesUtil.nvl(iMap.getString("CILT_KODU"), tffBasvuruKimlik.getCiltNo()));
					tffBasvuruKimlikTx.setCinsiyet(CreditCardServicesUtil.nvl(iMap.getString("CINSIYET"), tffBasvuruKimlik.getCinsiyet()));
					tffBasvuruKimlikTx.setDogumTar(CreditCardServicesUtil.nvl(iMap.getDate("DOGUM_TARIHI"), tffBasvuruKimlik.getDogumTar()));
					tffBasvuruKimlikTx.setDogumYeri(CreditCardServicesUtil.nvl(iMap.getString("DOGUM_YERI"), tffBasvuruKimlik.getDogumYeri()));
					tffBasvuruKimlikTx.setEsTcKimlikNo(CreditCardServicesUtil.nvl(iMap.getString("ES_TCKN"), tffBasvuruKimlik.getEsTcKimlikNo()));
					tffBasvuruKimlikTx.setIkinciAd(CreditCardServicesUtil.nvl(iMap.getString("AD2"), tffBasvuruKimlik.getIkinciAd()));
					tffBasvuruKimlikTx.setKayipKimlikSeriNo(CreditCardServicesUtil.nvl(iMap.getString("KAYIP_CUZDAN_SERI_NO"), tffBasvuruKimlik.getKayipKimlikSeriNo()));
					tffBasvuruKimlikTx.setKayipKimlikSiraNo(CreditCardServicesUtil.nvl(iMap.getString("KAYIP_CUZDAN_SIRA_NO"), tffBasvuruKimlik.getKayipKimlikSiraNo()));
					tffBasvuruKimlikTx.setKimlikSeriNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO"), tffBasvuruKimlik.getKimlikSeriNo()));
					tffBasvuruKimlikTx.setKimlikSiraNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO"), tffBasvuruKimlik.getKimlikSiraNo()));
					tffBasvuruKimlikTx.setMahalleKoy(CreditCardServicesUtil.nvl(iMap.getString("MAHALLE_KOY"), tffBasvuruKimlik.getMahalleKoy()));
					tffBasvuruKimlikTx.setMedeniHal(CreditCardServicesUtil.nvl(iMap.getString("MEDENI_HALI"), tffBasvuruKimlik.getMedeniHal()));
					tffBasvuruKimlikTx.setNufusIlceKod(CreditCardServicesUtil.nvl(iMap.getString("ILCE_KODU"), tffBasvuruKimlik.getNufusIlceKod()));
					tffBasvuruKimlikTx.setNufusIlKod(CreditCardServicesUtil.nvl(iMap.getString("IL_KODU"), tffBasvuruKimlik.getNufusIlKod()));
					tffBasvuruKimlikTx.setNufusVerNedeni(CreditCardServicesUtil.nvl(iMap.getString("VERILIS_NEDENI"), tffBasvuruKimlik.getNufusVerNedeni()));
					tffBasvuruKimlikTx.setNufusVerTar(CreditCardServicesUtil.nvl(iMap.getDate("VERILIS_TARIHI"), tffBasvuruKimlik.getNufusVerTar()));
					tffBasvuruKimlikTx.setNufusVerYer(CreditCardServicesUtil.nvl(iMap.getString("VERILDIGI_ILCE_ADI"), tffBasvuruKimlik.getNufusVerYer()));
					tffBasvuruKimlikTx.setOncekiSoyad(CreditCardServicesUtil.nvl(iMap.getString("KIZLIK_SOYAD"), tffBasvuruKimlik.getOncekiSoyad()));
					tffBasvuruKimlikTx.setSoyad(CreditCardServicesUtil.nvl(iMap.getString("SOYAD"), tffBasvuruKimlik.getSoyad()));
					tffBasvuruKimlikTx.setTcKimlikNo(CreditCardServicesUtil.nvl(iMap.getString("TCKN"), tffBasvuruKimlik.getTcKimlikNo()));
				} else {
					tffBasvuruKimlikTx.setAd(CreditCardServicesUtil.nvl(iMap.getString("AD1"), tffBasvuruKimlik.getAd()));
					tffBasvuruKimlikTx.setIkinciAd(CreditCardServicesUtil.nvl(iMap.getString("AD2"), tffBasvuruKimlik.getIkinciAd()));
					tffBasvuruKimlikTx.setPasaportNo(CreditCardServicesUtil.nvl(iMap.getString("PASAPORT_NO"), tffBasvuruKimlik.getPasaportNo()));
					tffBasvuruKimlikTx.setSoyad(CreditCardServicesUtil.nvl(iMap.getString("SOYAD"), tffBasvuruKimlik.getSoyad()));
					tffBasvuruKimlikTx.setDogumTar(CreditCardServicesUtil.nvl(iMap.getDate("DOGUM_TARIHI"), tffBasvuruKimlik.getDogumTar()));
				}
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				tffBasvuruKimlikTx.setUyrukKod(iMap.getString("UYRUK_KOD"));
				if ("TR".equals(tffBasvuruKimlikTx.getUyrukKod())) {
					tffBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
					tffBasvuruKimlikTx.setAd(iMap.getString("AD1"));
					tffBasvuruKimlikTx.setAileSiraNo(iMap.getString("AILE_SIRA_NO"));
					tffBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_AD"));
					tffBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_AD"));
					tffBasvuruKimlikTx.setBireySiraNo(iMap.getString("BIREY_SIRA_NO"));
					tffBasvuruKimlikTx.setCiltNo(iMap.getString("CILT_KODU"));
					tffBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
					tffBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
					tffBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
					tffBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
					tffBasvuruKimlikTx.setIkinciAd(iMap.getString("AD2"));
					tffBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI_NO"));
					tffBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_SIRA_NO"));
					tffBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
					tffBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
					tffBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
					tffBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HALI"));
					tffBasvuruKimlikTx.setNufusIlceKod(iMap.getString("ILCE_KODU"));
					tffBasvuruKimlikTx.setNufusIlKod(iMap.getString("IL_KODU"));
					tffBasvuruKimlikTx.setMahalleKoy(iMap.getString("MAHALLE_KOY"));
					tffBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("VERILIS_NEDENI"));
					tffBasvuruKimlikTx.setNufusVerTar(iMap.getDate("VERILIS_TARIHI"));
					tffBasvuruKimlikTx.setNufusVerTarKps(iMap.getDate("VERILIS_TARIHI"));
					tffBasvuruKimlikTx.setNufusVerYer(iMap.getString("VERILDIGI_ILCE_ADI"));
					tffBasvuruKimlikTx.setOncekiSoyad(iMap.getString("KIZLIK_SOYAD"));
					tffBasvuruKimlikTx.setSoyad(iMap.getString("SOYAD"));
					tffBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TCKN"));
				} else {
					tffBasvuruKimlikTx.setAd(iMap.getString("AD1"));
					tffBasvuruKimlikTx.setIkinciAd(iMap.getString("AD2"));
					tffBasvuruKimlikTx.setPasaportNo(iMap.getString("PASAPORT_NO"));
					tffBasvuruKimlikTx.setSoyad(iMap.getString("SOYAD"));
					tffBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
				}
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(tffBasvuruKimlikTx);
			session.flush();
		}
		catch (Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}

	/** Alinan bilgilerle tff basvuru adres bilgisini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>ADRES_TIPI
	 *        <li>IL_KOD
	 *        <li>IL_AD
	 *        <li>ILCE_KOD
	 *        <li>ILCE_AD
	 *        <li>ACIK_ADRES
	 *        <li>UYE_ADRES_NO
	 *        <li>TESLIMAT_ADRESI_MI
	 *        <li>TESLIMAT_NOKTASI_KODU
	 *        <li>ILETISIM_MI
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_ADRES")
	public static GMMap saveAdres(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al
			TffBasvuruAdresTxId id = new TffBasvuruAdresTxId();
			id.setAdresKod(iMap.getString("ADRES_TIPI"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			TffBasvuruAdresTx tffBasvuruAdresTx = (TffBasvuruAdresTx) session.get(TffBasvuruAdresTx.class, id);
			if (tffBasvuruAdresTx == null) {
				tffBasvuruAdresTx = new TffBasvuruAdresTx();
				tffBasvuruAdresTx.setId(id);
				tffBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			}

			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				TffBasvuruAdresId adresId = new TffBasvuruAdresId();
				adresId.setAdresKod(iMap.getString("ADRES_TIPI"));
				adresId.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
				
				TffBasvuruAdres tffBasvuruAdres = (TffBasvuruAdres) session.get(TffBasvuruAdres.class, adresId);
				if (tffBasvuruAdres == null) {
					tffBasvuruAdres = new TffBasvuruAdres();
					//CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}
				
				tffBasvuruAdresTx.setIlKod(CreditCardServicesUtil.nvl(iMap.getString("IL_KOD"), tffBasvuruAdres.getIlKod()));
				tffBasvuruAdresTx.setIlAd(CreditCardServicesUtil.nvl(iMap.getString("IL_AD"), tffBasvuruAdres.getIlAd()));
				tffBasvuruAdresTx.setIlceKod(CreditCardServicesUtil.nvl(iMap.getString("ILCE_KOD"), tffBasvuruAdres.getIlceKod()));
				tffBasvuruAdresTx.setIlceAd(CreditCardServicesUtil.nvl(iMap.getString("ILCE_AD"), tffBasvuruAdres.getIlceAd()));
				tffBasvuruAdresTx.setAcikAdres(CreditCardServicesUtil.trimNewLine(CreditCardServicesUtil.nvl(iMap.getString("ACIK_ADRES"), tffBasvuruAdres.getAcikAdres())));
				tffBasvuruAdresTx.setUyeAdresNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("UYE_ADRES_NO"), tffBasvuruAdres.getUyeAdresNo()));
				tffBasvuruAdresTx.setTeslimatAdresiMi(CreditCardServicesUtil.nvl(iMap.getString("TESLIMAT_ADRESI_MI"), tffBasvuruAdres.getTeslimatAdresiMi()));
				tffBasvuruAdresTx.setTeslimatNoktasiKodu(CreditCardServicesUtil.nvl(iMap.getString("TESLIMAT_NOKTASI_KODU"), tffBasvuruAdres.getTeslimatNoktasiKodu()));
				tffBasvuruAdresTx.setIletisimMi(CreditCardServicesUtil.nvl(iMap.getString("ILETISIM_MI"), tffBasvuruAdres.getIletisimMi()));
				if ("E".equals(iMap.getString("ADRES_TIPI")))
					oMap.put("EV_ADRES_NO", CreditCardServicesUtil.nvl(iMap.getBigDecimal("UYE_ADRES_NO"), tffBasvuruAdres.getUyeAdresNo()));
				else if ("I".equals(iMap.getString("ADRES_TIPI")))
					oMap.put("IS_ADRES_NO", CreditCardServicesUtil.nvl(iMap.getBigDecimal("UYE_ADRES_NO"), tffBasvuruAdres.getUyeAdresNo()));
				
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				//yoksa, adres numarasi al
				if (iMap.get("UYE_ADRES_NO") == null) {
					sorguMap.clear();
					sorguMap.put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_ADRESLER);
					sorguMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap));
				}
				
				tffBasvuruAdresTx.setIlKod(iMap.getString("IL_KOD"));
				tffBasvuruAdresTx.setIlAd(iMap.getString("IL_AD"));
				tffBasvuruAdresTx.setIlceKod(iMap.getString("ILCE_KOD"));
				tffBasvuruAdresTx.setIlceAd(iMap.getString("ILCE_AD"));
				tffBasvuruAdresTx.setAcikAdres(CreditCardServicesUtil.trimNewLine(iMap.getString("ACIK_ADRES")));
				tffBasvuruAdresTx.setUyeAdresNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("UYE_ADRES_NO"), sorguMap.getBigDecimal("ID")));
				tffBasvuruAdresTx.setTeslimatAdresiMi(iMap.getString("TESLIMAT_ADRESI_MI"));
				tffBasvuruAdresTx.setTeslimatNoktasiKodu(iMap.getString("TESLIMAT_NOKTASI_KODU"));
				tffBasvuruAdresTx.setIletisimMi(iMap.getString("ILETISIM_MI"));
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(tffBasvuruAdresTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/** Alinan bilgilerle tff basvuru adres bilgisini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>TELEFON_TIPI
	 *        <li>ALAN_KOD
	 *        <li>DAHILI
	 *        <li>ILETISIM_MI
	 *        <li>NUMARA
	 *        <li>ULKE_KOD
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_TELEFON")
	public static GMMap saveTelefon(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Telefon tipini al
			String tip = iMap.getString("TELEFON_TIPI");
			if ("E".equals(tip) || "1".equals(tip)) {
				tip = "1";
			} else if("I".equals(tip) || "2".equals(tip)){
				tip = "2";
			} else if("C".equals(tip) || "3".equals(tip)) {
				tip = "3";
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al
			TffBasvuruTelefonTxId id = new TffBasvuruTelefonTxId();
			id.setTip(tip);
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			TffBasvuruTelefonTx tffBasvuruTelefonTx = (TffBasvuruTelefonTx)
					session.get(TffBasvuruTelefonTx.class, id);
			if (tffBasvuruTelefonTx == null) {
				tffBasvuruTelefonTx = new TffBasvuruTelefonTx();
				tffBasvuruTelefonTx.setId(id);
				tffBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			}

			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				TffBasvuruTelefonId telefonId = new TffBasvuruTelefonId();
				telefonId.setTip(tip);
				telefonId.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
				
				TffBasvuruTelefon tffBasvuruTelefon = (TffBasvuruTelefon) session.get(TffBasvuruTelefon.class, telefonId);
				if (tffBasvuruTelefon == null){
					tffBasvuruTelefon = new TffBasvuruTelefon();
					//CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}
				
				tffBasvuruTelefonTx.setAlanKod(CreditCardServicesUtil.nvl(iMap.getString("ALAN_KOD"), tffBasvuruTelefon.getAlanKod()));
				tffBasvuruTelefonTx.setDahili(CreditCardServicesUtil.nvl(iMap.getString("DAHILI"), tffBasvuruTelefon.getDahili()));
				tffBasvuruTelefonTx.setIletisim(CreditCardServicesUtil.nvl(iMap.getString("ILETISIM_MI"), tffBasvuruTelefon.getIletisim()));
				tffBasvuruTelefonTx.setNumara(CreditCardServicesUtil.nvl(iMap.getString("NUMARA"), tffBasvuruTelefon.getNumara()));
				tffBasvuruTelefonTx.setUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("ULKE_KOD"), tffBasvuruTelefon.getUlkeKod()));
				tffBasvuruTelefonTx.setUlkeKod(CreditCardServicesUtil.nvl(tffBasvuruTelefonTx.getUlkeKod(), "90"));
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				tffBasvuruTelefonTx.setAlanKod(iMap.getString("ALAN_KOD"));
				tffBasvuruTelefonTx.setDahili(iMap.getString("DAHILI"));
				tffBasvuruTelefonTx.setIletisim(iMap.getString("ILETISIM_MI","H"));
				tffBasvuruTelefonTx.setNumara(iMap.getString("NUMARA"));
				tffBasvuruTelefonTx.setUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("ULKE_KOD"), "90"));
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(tffBasvuruTelefonTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle tff basvuru meslek bilgisini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>AYLIK_GELIR
	 *        <li>CALISMA_SEKLI
	 *        <li>ISYERI_ADI
	 *        <li>ISYERI_FAALIYET_ALANI
	 *        <li>ISYERI_VERGI_DAIRESI_ADI
	 *        <li>ISYERI_VERGI_DAIRESI_IL
	 *        <li>MESLEK
	 *        <li>UNVANI
	 *        <li>EGITIM
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_MESLEK")
	public static GMMap saveMeslek(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al
			TffBasvuruMeslekiBilgiTx tffBasvuruMeslekiBilgiTx = (TffBasvuruMeslekiBilgiTx)
					session.get(TffBasvuruMeslekiBilgiTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruMeslekiBilgiTx == null){
				tffBasvuruMeslekiBilgiTx = new TffBasvuruMeslekiBilgiTx();
				tffBasvuruMeslekiBilgiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				tffBasvuruMeslekiBilgiTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			}
			
			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				TffBasvuruMeslekiBilgi tffBasvuruMeslekiBilgi = (TffBasvuruMeslekiBilgi)
						session.get(TffBasvuruMeslekiBilgi.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffBasvuruMeslekiBilgi == null){
					tffBasvuruMeslekiBilgi = new TffBasvuruMeslekiBilgi();
					//CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("TFF_BASVURU_NO"));
				}
				
				tffBasvuruMeslekiBilgiTx.setAylikGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AYLIK_GELIR"), tffBasvuruMeslekiBilgi.getAylikGelir()));
				tffBasvuruMeslekiBilgiTx.setCalismaSekli(CreditCardServicesUtil.nvl(iMap.getString("CALISMA_SEKLI"), tffBasvuruMeslekiBilgi.getCalismaSekli()));
				tffBasvuruMeslekiBilgiTx.setIsyeriAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_ADI"), tffBasvuruMeslekiBilgi.getIsyeriAdi()));
				tffBasvuruMeslekiBilgiTx.setIsyeriFaaliyetAlani(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_FAALIYET_ALANI"), tffBasvuruMeslekiBilgi.getIsyeriFaaliyetAlani()));
				tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"), tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiAdi()));
				tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiIl(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"), tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiIl()));
				tffBasvuruMeslekiBilgiTx.setMeslek(CreditCardServicesUtil.nvl(iMap.getString("MESLEK"), tffBasvuruMeslekiBilgi.getMeslek()));
				tffBasvuruMeslekiBilgiTx.setUnvani(CreditCardServicesUtil.nvl(iMap.getString("UNVANI"), tffBasvuruMeslekiBilgi.getUnvani()));
				tffBasvuruMeslekiBilgiTx.setEgitimKod(CreditCardServicesUtil.nvl(iMap.getString("EGITIM"), tffBasvuruMeslekiBilgi.getEgitimKod()));
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				tffBasvuruMeslekiBilgiTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				tffBasvuruMeslekiBilgiTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
				tffBasvuruMeslekiBilgiTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
				tffBasvuruMeslekiBilgiTx.setIsyeriFaaliyetAlani(iMap.getString("ISYER_FAALIYET_ALANI"));
				tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiAdi(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
				tffBasvuruMeslekiBilgiTx.setMeslek(iMap.getString("MESLEK"));
				tffBasvuruMeslekiBilgiTx.setUnvani(iMap.getString("UNVANI"));
				tffBasvuruMeslekiBilgiTx.setEgitimKod(iMap.getString("EGITIM"));
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(tffBasvuruMeslekiBilgiTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle tff basvuru bilgisini olusturur/gunceller.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>ISLEM_FLAG - Yeni kayit mi guncelleme islemi mi? (E:Ekle | G:Guncelle)
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>Kredi karti basvuru bilgileri
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_SAVE_OR_UPDATE_KREDI_KARTI")
	public static GMMap saveKrediKarti(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Default deger ata
		if (StringUtils.isBlank(iMap.getString("AYLIK_GELIR"))) {
			iMap.put("AYLIK_GELIR", BigDecimal.ZERO);
		}

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa kk basvurusuna ait bilgileri al
			//TODO TffKrediKartiBasvuruId adinda bir class var kalksin mi?
			TffKrediKartiBasvuru tffKrediKartiBasvuru = (TffKrediKartiBasvuru)
					session.get(TffKrediKartiBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffKrediKartiBasvuru == null) {
				tffKrediKartiBasvuru = new TffKrediKartiBasvuru();
				tffKrediKartiBasvuru.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			}
			
			//Islem guncelleme islemi ise basvuru tablosundaki bilgileri al.
			if ("G".equals(iMap.getString("ISLEM_FLAG"))) {
				tffKrediKartiBasvuru.setAnneKizlikSoyad(CreditCardServicesUtil.nvl(iMap.getString("ANNE_KIZLIK_SOYADI"), tffKrediKartiBasvuru.getAnneKizlikSoyad()));
				tffKrediKartiBasvuru.setAylikGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AYLIK_GELIR"), tffKrediKartiBasvuru.getAylikGelir()));
				tffKrediKartiBasvuru.setCalismaSekli(CreditCardServicesUtil.nvl(iMap.getString("CALISMA_SEKLI"),tffKrediKartiBasvuru.getCalismaSekli()));
				tffKrediKartiBasvuru.setCepTelKod(CreditCardServicesUtil.nvl(iMap.getString("CEP_ALAN_KOD"),tffKrediKartiBasvuru.getCepTelKod()));
				tffKrediKartiBasvuru.setCepTelNo(CreditCardServicesUtil.nvl(iMap.getString("CEP_NUMARA"), tffKrediKartiBasvuru.getCepTelNo()));
				tffKrediKartiBasvuru.setEkstreSecim(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI", tffKrediKartiBasvuru.getEkstreSecim()));
				tffKrediKartiBasvuru.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL", tffKrediKartiBasvuru.getEkstreTipiEmail()));
				tffKrediKartiBasvuru.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA", tffKrediKartiBasvuru.getEkstreTipiPosta()));
				tffKrediKartiBasvuru.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS", tffKrediKartiBasvuru.getEkstreTipiSms()));
				tffKrediKartiBasvuru.setEmail(CreditCardServicesUtil.nvl(iMap.getString("EMAIL"), tffKrediKartiBasvuru.getEmail()));
				tffKrediKartiBasvuru.setEvTelKod(CreditCardServicesUtil.nvl(iMap.getString("EV_ALAN_KOD"), tffKrediKartiBasvuru.getEvTelKod()));
				tffKrediKartiBasvuru.setEvTelNo(CreditCardServicesUtil.nvl(iMap.getString("EV_NUMARA"), tffKrediKartiBasvuru.getEvTelNo()));
				tffKrediKartiBasvuru.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI", tffKrediKartiBasvuru.getHesapKesimTarihi()));
				tffKrediKartiBasvuru.setIsTelDahili(CreditCardServicesUtil.nvl(iMap.getString("IS_DAHILI"), tffKrediKartiBasvuru.getIsTelDahili()));
				tffKrediKartiBasvuru.setIsTelKod(CreditCardServicesUtil.nvl(iMap.getString("IS_ALAN_KOD"), tffKrediKartiBasvuru.getIsTelKod()));
				tffKrediKartiBasvuru.setIsTelNo(CreditCardServicesUtil.nvl(iMap.getString("IS_NUMARA"), tffKrediKartiBasvuru.getIsTelNo()));
				tffKrediKartiBasvuru.setIsyeriAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_ADI"), tffKrediKartiBasvuru.getIsyeriAdi()));
				tffKrediKartiBasvuru.setIsyeriVergiDairesiAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"), tffKrediKartiBasvuru.getIsyeriVergiDairesiAdi()));
				tffKrediKartiBasvuru.setIsyeriVergiDairesiIl(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"), tffKrediKartiBasvuru.getIsyeriVergiDairesiIl()));
				tffKrediKartiBasvuru.setIsyeriFaaliyetAlani(iMap.getString("ISYER_FAALIYET_ALANI", tffKrediKartiBasvuru.getIsyeriFaaliyetAlani()));
				tffKrediKartiBasvuru.setKartOtomatikOdeme(iMap.getString("KART_OTOMATIK_ODEME", tffKrediKartiBasvuru.getKartOtomatikOdeme()));
				tffKrediKartiBasvuru.setKartTipi(CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), tffKrediKartiBasvuru.getKartTipi()));
				tffKrediKartiBasvuru.setKartUzerindekiIsim(iMap.getString("KART_UZERINDEKI_ISIM", tffKrediKartiBasvuru.getKartUzerindekiIsim()));
				tffKrediKartiBasvuru.setKimlikSeriNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO"), tffKrediKartiBasvuru.getKimlikSeriNo()));
				tffKrediKartiBasvuru.setKimlikSiraNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO"), tffKrediKartiBasvuru.getKimlikSiraNo()));
				tffKrediKartiBasvuru.setKkBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KK_BASVURU_NO"), tffKrediKartiBasvuru.getKkBasvuruNo()));
				tffKrediKartiBasvuru.setMeslekKod(CreditCardServicesUtil.nvl(iMap.getString("MESLEK"), tffKrediKartiBasvuru.getMeslekKod()));
				tffKrediKartiBasvuru.setOgrenimDurumu(CreditCardServicesUtil.nvl(iMap.getString("EGITIM"), tffKrediKartiBasvuru.getOgrenimDurumu()));
				tffKrediKartiBasvuru.setOtomatikLimitArtimi(iMap.getString("OTOMATIK_LIMIT_ARTIMI", tffKrediKartiBasvuru.getOtomatikLimitArtimi()));
				tffKrediKartiBasvuru.setSource(CreditCardServicesUtil.nvl(iMap.getString("SOURCE"), tffKrediKartiBasvuru.getSource()));
				tffKrediKartiBasvuru.setTckn(CreditCardServicesUtil.nvl(iMap.getBigDecimal("TCKN"), tffKrediKartiBasvuru.getTckn()));
				tffKrediKartiBasvuru.setUnvanKod(CreditCardServicesUtil.nvl(iMap.getString("UNVANI"), tffKrediKartiBasvuru.getUnvanKod()));
				tffKrediKartiBasvuru.setYurtdisiEkstreTipi(iMap.getString("YURT_DISI_EKSTRE_TIP", tffKrediKartiBasvuru.getYurtdisiEkstreTipi()));
				tffKrediKartiBasvuru.setEvAdresi(CreditCardServicesUtil.nvl(iMap.getString("EV_ACIK_ADRES"), tffKrediKartiBasvuru.getEvAdresi()));
				tffKrediKartiBasvuru.setEvIl(CreditCardServicesUtil.nvl(iMap.getString("EV_IL_KOD"), tffKrediKartiBasvuru.getEvIl()));
				tffKrediKartiBasvuru.setEvIlce(CreditCardServicesUtil.nvl(iMap.getString("EV_ILCE_KOD"), tffKrediKartiBasvuru.getEvIlce()));
				tffKrediKartiBasvuru.setEvPostaKodu(CreditCardServicesUtil.nvl(iMap.getString("EV_POSTA_KODU"), tffKrediKartiBasvuru.getEvPostaKodu()));
				tffKrediKartiBasvuru.setIsAdresi(CreditCardServicesUtil.nvl(iMap.getString("IS_ACIK_ADRES"), tffKrediKartiBasvuru.getIsAdresi()));
				tffKrediKartiBasvuru.setIsIl(CreditCardServicesUtil.nvl(iMap.getString("IS_IL_KOD"), tffKrediKartiBasvuru.getIsIl()));
				tffKrediKartiBasvuru.setIsIlce(CreditCardServicesUtil.nvl(iMap.getString("IS_ILCE_KOD"), tffKrediKartiBasvuru.getIsIlce()));
				tffKrediKartiBasvuru.setIsPostaKodu(CreditCardServicesUtil.nvl(iMap.getString("IS_POSTA_KODU"), tffKrediKartiBasvuru.getIsPostaKodu()));
				tffKrediKartiBasvuru.setTeslimatAdresi(CreditCardServicesUtil.nvl(iMap.getString("TESLIMAT_ADRESI_TIPI"), tffKrediKartiBasvuru.getTeslimatAdresi()));
			} else if ("E".equals(iMap.getString("ISLEM_FLAG"))) {
				//TODO CalismaSuresiAy, CalismasuresiYil, OturmaSuresiYil, OturmaSuresiAy
				tffKrediKartiBasvuru.setAnneKizlikSoyad(iMap.getString("ANNE_KIZLIK_SOYADI"));
				tffKrediKartiBasvuru.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				tffKrediKartiBasvuru.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
				tffKrediKartiBasvuru.setCepTelKod(iMap.getString("CEP_ALAN_KOD"));
				tffKrediKartiBasvuru.setCepTelNo(iMap.getString("CEP_NUMARA"));
				tffKrediKartiBasvuru.setEkstreSecim(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
				tffKrediKartiBasvuru.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
				tffKrediKartiBasvuru.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
				tffKrediKartiBasvuru.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
				tffKrediKartiBasvuru.setEmail(iMap.getString("EMAIL"));
				tffKrediKartiBasvuru.setEvTelKod(iMap.getString("EV_ALAN_KOD"));
				tffKrediKartiBasvuru.setEvTelNo(iMap.getString("EV_NUMARA"));
				tffKrediKartiBasvuru.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));
				tffKrediKartiBasvuru.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
				tffKrediKartiBasvuru.setIsTelKod(iMap.getString("IS_ALAN_KOD"));
				tffKrediKartiBasvuru.setIsTelNo(iMap.getString("IS_NUMARA"));
				tffKrediKartiBasvuru.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
				tffKrediKartiBasvuru.setIsyeriVergiDairesiAdi(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				tffKrediKartiBasvuru.setIsyeriVergiDairesiIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
				tffKrediKartiBasvuru.setIsyeriFaaliyetAlani(iMap.getString("ISYER_FAALIYET_ALANI"));
				tffKrediKartiBasvuru.setKartOtomatikOdeme(iMap.getString("KART_OTOMATIK_ODEME"));
				tffKrediKartiBasvuru.setKartTipi(iMap.getString("KART_TIPI"));
				tffKrediKartiBasvuru.setKartUzerindekiIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
				tffKrediKartiBasvuru.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
				tffKrediKartiBasvuru.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
				tffKrediKartiBasvuru.setKkBasvuruNo(iMap.getBigDecimal("KK_BASVURU_NO"));
				tffKrediKartiBasvuru.setMeslekKod(iMap.getString("MESLEK"));
				tffKrediKartiBasvuru.setOgrenimDurumu(iMap.getString("EGITIM"));
				tffKrediKartiBasvuru.setOtomatikLimitArtimi(CreditCardServicesUtil.nvl(iMap.getString("OTOMATIK_LIMIT_ARTIMI"),"H"));
				tffKrediKartiBasvuru.setSource(iMap.getString("SOURCE"));
				tffKrediKartiBasvuru.setTckn(iMap.getBigDecimal("TCKN"));
				tffKrediKartiBasvuru.setUnvanKod(iMap.getString("UNVANI"));
				tffKrediKartiBasvuru.setYurtdisiEkstreTipi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
				tffKrediKartiBasvuru.setEvAdresi(iMap.getString("EV_ACIK_ADRES"));
				tffKrediKartiBasvuru.setEvIl(iMap.getString("EV_IL_KOD"));
				tffKrediKartiBasvuru.setEvIlce(iMap.getString("EV_ILCE_KOD"));
				tffKrediKartiBasvuru.setEvPostaKodu(iMap.getString("EV_POSTA_KODU"));
				tffKrediKartiBasvuru.setIsAdresi(iMap.getString("IS_ACIK_ADRES"));
				tffKrediKartiBasvuru.setIsIl(iMap.getString("IS_IL_KOD"));
				tffKrediKartiBasvuru.setIsIlce(iMap.getString("IS_ILCE_KOD"));
				tffKrediKartiBasvuru.setIsPostaKodu(iMap.getString("IS_POSTA_KODU"));
				tffKrediKartiBasvuru.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRESI_TIPI"));
			} else {
				CreditCardServicesUtil.raiseGMError("3488");
			}

			session.saveOrUpdate(tffKrediKartiBasvuru);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Tff basvurusu kayit/guncelleme isleminin alan kontrollerini gerceklestirir.
	 * 
	 * @author murat.el
	 * @since 10.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3801_AFTER_CONTROL")
	public static GMMap afterControl3801(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Islenecek kayit bilgisini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3801.After_Control(?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Tff basvurusu kayit/guncelleme islemini sonlandirir.
	 * 
	 * @author murat.el
	 * @since 10.03.2014
	 * @param iMap - Islem bilgisi<br>
	 *         <li>TRX_NO - Islem numarasi
	 * @return oMap - Islem sonucu<br>
	 *         <li>MESSAGE - ISlem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3801_SEND_TRANSACTION")
	public static GMMap sendTransaction3801(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			iMap.put("TRX_NAME", "3801");
			iMap.put("TRX_NO", iMap.get("TRX_NO"));
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** TFFden yapilan basvurular icin kredi karti kisa basvurusu yapar,
	 * kredi karti alinip alinamayacagini belirler.<br>
	 * @author murat.el
	 * @since 11.03.2014
	 * @param iMap - Kredi karti kisa basvuru islemi bilgileri<br>
	 *        <li>TFF_BASVURU_NO - Tff Basvuru numarasi
	 *        <li>TCKN - TC Kimlik Numarasi
	 *        <li>CEP_NO - Cep telefonu numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>TFF_TRX_NO - Tff basvurusu tamamlanmadan kk olusturuldu ise tff kaydet islem numarasi
	 * @return Islem sonucu<br>
	 *        <li>DEVAM - Kredi karti basvurusunun durumu
	 *                   (E:Basari ile olustu|H:Olusamadi ya da olusup red/iptal aldi)
	 *        <li>BASVURU_OLUSTU_MU - KK basvurusu olusturuldu mu?(E:Evet|H:Hayir)
	 *        <li>BASVURU_GECERLI_MI - KK basvurusu gecerli mi?(E:Evet|H:Hayir)
	 *        <li>HATA_MESAJI - Devam edilemeyecekse nedeni
	 *
	@GraymoundService("BNSPR_TFF_KREDI_KARTI_KISA_BASVURU_YAP")
	public static GMMap tffKrediKartiKisaBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			sorguMap.put("TCK_NO", iMap.get("TCKN"));
			sorguMap.put("CEP_NO", iMap.get("CEP_NO"));
			sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
			sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_TFF_ON_BASVURU", sorguMap));
			//Kredi karti basvurusu durumunu kontrol et
			BigDecimal kkBasvuruNo = sorguMap.getBigDecimal("BASVURU_NO");
			boolean basvuruOlustuMu = CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"));
			boolean basvuruGecerliMi = CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEVAM"));
			boolean nbsmHatasiMi = CreditCardServicesUtil.EVET.equals(sorguMap.getString("NBSM_HATASI_MI"));
			//Basvuru durumunu al
			oMap.put("BASVURU_NO", kkBasvuruNo);
			oMap.put("BASVURU_OLUSTU_MU", BooleanUtils.toString(basvuruOlustuMu,
					CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
			oMap.put("BASVURU_GECERLI_MI", BooleanUtils.toString(basvuruGecerliMi&&!nbsmHatasiMi,
					CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
			
			//Basvuru bilgileri doldurulmaya devam edilecek mi? Evet ise tff basvuru alinan bilgilerle guncelle.
			BigDecimal kkTrxNo = sorguMap.getBigDecimal("TRX_NO");
			if (basvuruOlustuMu && basvuruGecerliMi && !nbsmHatasiMi) {
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("BASVURU_NO", kkBasvuruNo);
				sorguMap.put("TRX_NO", kkTrxNo);
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_TFF_TAM_BASVURU", sorguMap));
				//Kredi karti basvurusu durumunu kontrol et
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE")) &&
						CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEVAM"))) {
					oMap.put("DEVAM", "E");
				} else {
					oMap.put("DEVAM", "H");
					oMap.put("HATA_MESAJI", "Kredi Karti Basvurusu: " + sorguMap.getString("RESPONSE_DATA", sorguMap.getString("MESSAGE")));
				}
			} else {
				oMap.put("DEVAM", "H");
				oMap.put("HATA_MESAJI", "Kredi Karti Basvurusu: " + sorguMap.getString("RESPONSE_DATA", sorguMap.getString("MESSAGE")));
			}
			//Basvuru olustu ise tff bilgisini guncelle
			if (basvuruOlustuMu && kkBasvuruNo != null) {
				sorguMap.clear();
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				sorguMap.put("KK_BASVURU_NO", kkBasvuruNo);
				sorguMap.put("ISLEM_FLAG", "G");
				sorguMap.put("TRX_NO", iMap.get("TFF_TRX_NO"));
				saveBasvuru(sorguMap);
				saveKrediKarti(sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	*/
}
