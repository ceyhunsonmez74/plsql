package tr.com.aktifbank.bnspr.creditcard.services;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/** BNSPR_QRY3829 Kredi Karti Basvuru 118 Sorgu Sonuclari Izleme Ekrani Servisleri<br>
 * 
 * @author murat.el
 * @since 21/10/2013
 */
public class CreditCardQRY3858Services {
		
	//---------------------------------------------------------------------
	//******************************************************* 3858 Ekrani
	//---------------------------------------------------------------------
	/** 
	 * Ekran acilisinda alinacak degerleri bulur. 
	 */
	@GraymoundService("BNSPR_QRY3858_INITIALIZE")
	public static GMMap fillInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			StringBuilder query = new StringBuilder();
			
			//Sorgu Turu
			query.append(" SELECT key1, text");
			query.append(" FROM bnspr.v_ml_gnl_param_text");
			query.append(" WHERE kod = 'PARAM_REF_TUR'");
			query.append(" AND key1 in ('GNL_MUSTERI', 'KK_BASVURU')");
			query.append(" ORDER BY text");
			oMap.putAll(DALUtil.fillComboBox(iMap, "SORGU_TURU", true, query.toString()));
			
			//Il Listesi
			query.delete(0, query.length());
			query.append(" SELECT kod, il_adi");
			query.append(" FROM bnspr.gnl_il_kod_pr");
			query.append(" WHERE kod != 200");
			query.append(" ORDER BY il_adi");
			oMap.putAll(DALUtil.fillComboBox(iMap, "IL", true, query.toString()));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3858_MUSTERI_BILGI")
	public static GMMap musteriBilgiSorgulama(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			if ("GNL_MUSTERI".equals(iMap.getString("ISLEM"))) {
				GMMap sMap = new GMMap();
				String func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.RC_MUSTERI_BILGI(?,?) }";
				Object[] inputValues = new Object[4];
				int i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = "KIMLIK";
				sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

				oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
				oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
				oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
				oMap.put("IL_KOD", sMap.get("KIMLIK_TABLO", 0, "IL_KOD"));

				sMap = new GMMap();
				inputValues = new Object[4];
				i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i] = "TELEFON";
				sMap = DALUtil.callOracleRefCursorFunction(func, "TELEFON_TABLO", inputValues);
				oMap.put("TELEFON_TABLO", sMap.get("TELEFON_TABLO"));

			} else if ("KK_BASVURU".equals(iMap.getString("ISLEM"))) {
				GMMap sMap = new GMMap();
				String func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.RC_KK_BASVURU_BILGI(?,?) }";
				Object[] inputValues = new Object[4];
				int i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = "KIMLIK";
				sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

				oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
				oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
				oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
				oMap.put("IL_KOD", sMap.get("KIMLIK_TABLO", 0, "IL_KOD"));

				sMap = new GMMap();
				inputValues = new Object[4];
				i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i] = "TELEFON";
				sMap = DALUtil.callOracleRefCursorFunction(func, "TELEFON_TABLO", inputValues);
				oMap.put("TELEFON_TABLO", sMap.get("TELEFON_TABLO"));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3858_BILINMEYEN_NUMARA_SORGU_MANUEL")
	public static GMMap sorguBilinmeyenNumaraManuel(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3858_BILINMEYEN_NUMARA_SORGU", iMap));
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3858_BILINMEYEN_NUMARA_SORGU_ISLEM")
	public static GMMap sorguBilinmeyenNumaraIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Kontrol
		String islemTuru = iMap.getString("ISLEM_TUR");
		if (StringUtils.isBlank(islemTuru)) {
			CreditCardServicesUtil.raiseGMError("330", "Sorgu T�r�");
		} else if ("KK_BASVURU".equals(islemTuru) && StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
			CreditCardServicesUtil.raiseGMError("330", "Ba�vuru No");
		} else if ("GNL_MUSTERI".equals(islemTuru) && StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
			CreditCardServicesUtil.raiseGMError("330", "M��teri No");
		}
		
		//Sorgula
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3858_BILINMEYEN_NUMARA_SORGU", iMap));
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3858_BILINMEYEN_NUMARA_SORGU")
	public static GMMap sorguBilinmeyenNumara(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		String[] services = { "AVEA", "TURKCELL", "TURK_TELEKOM", "VODAFONE" };
		int rowPhoneBookType = 0;
		for (String serviceName : services) {
			if (iMap.getBoolean("SERVIS_" + serviceName)) {
				sorguMap.put("PHONEBOOK_TYPE_SET", rowPhoneBookType++, "PHONEBOOK_TYPE", serviceName);
			}
		}

		String sorguTuru = iMap.getString("SORGU_TUR");
		if (StringUtils.isBlank(sorguTuru)) {
			throw new GMRuntimeException(0, "Bilinmeyen numara sorgulma sekli secili olmalidir, Kisi ya da Secili Numara.");
		}

		if ("NUMARA".equals(sorguTuru) && (StringUtils.isBlank(iMap.getString("TEL_NO")) || iMap.getString("TEL_NO").length() != 10)) {
			throw new GMRuntimeException(0, "Numara ile sorgulamada telefon bilgisi secili/ dogru tanimli olmalidir.");
		}

		if ("KISI".equals(sorguTuru)) {
			if (StringUtils.isBlank(iMap.getString("AD")) || StringUtils.isBlank(iMap.getString("IL_KOD"))) {
				throw new GMRuntimeException(0, "Kisi ile sorgulamada ad / unvan, soyad ve il tanimli olmalidir.");
			}

			if (rowPhoneBookType == 0) {
				throw new GMRuntimeException(0, "Kisi ile sorgulamada en az bir servis secili olmalidir.");
			}
		}

		if (StringUtils.isNotBlank(iMap.getString("BASVURU_NO"))) {
			sorguMap.put("PARAM_REF_TUR", "KK_BASVURU");
			sorguMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
		} else if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
			sorguMap.put("PARAM_REF_TUR", "GNL_MUSTERI");
			sorguMap.put("PARAM_REF_ID", iMap.getString("MUSTERI_NO"));
		} else if (StringUtils.isNotBlank(iMap.getString("AD"))) {
			sorguMap.put("PARAM_REF_TUR", "GENEL");
			sorguMap.put("PARAM_REF_ID", CreditCardServicesUtil.convertStringTrToEn(iMap.getString("AD") + " " + iMap.getString("SOYAD")));
		} else if (StringUtils.isNotBlank(iMap.getString("TEL_NO"))) {
			sorguMap.put("PARAM_REF_TUR", "GENEL");
			sorguMap.put("PARAM_REF_ID", iMap.getString("TEL_NO"));
		}

		sorguMap.put("PHONE_NUMBER", iMap.getString("TEL_NO"));
		sorguMap.put("CLIENT_QUERY_NO", "1");
		sorguMap.put("FIRST_NAME", iMap.getString("AD"));
		sorguMap.put("LAST_NAME", iMap.getString("SOYAD"));
		sorguMap.put("CITY_CODE", iMap.getString("IL_KOD"));
		sorguMap.put("DISTRICT_NAME", "");
		sorguMap.put("CONTACT_TYPE_ENUM_VALUE", (iMap.getString("SOYAD") != null) ? "PERSON" : "CORPORATION");
		sorguMap.put("PAGE_NUMBER", "");

		try {
			if ("NUMARA".equals(sorguTuru)) {
				GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", sorguMap);
			} else if ("KISI".equals(sorguTuru)) {
				GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NAME", sorguMap);
			}
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3858_BILINMEYEN_NUMARA_LISTELE", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3858_BILINMEYEN_NUMARA_LISTELE_MANUEL")
	public static GMMap sorguBilinmeyenNumaraListeleManuel(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3858_BILINMEYEN_NUMARA_LISTELE", iMap));
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3858_BILINMEYEN_NUMARA_LISTELE_ISLEM")
	public static GMMap sorguBilinmeyenNumaraListeleIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3858_BILINMEYEN_NUMARA_LISTELE", iMap));
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3858_BILINMEYEN_NUMARA_LISTELE")
	public static GMMap sorguBilinmeyenNumaraListele(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (StringUtils.isBlank(iMap.getString("PARAM_REF_TUR"))) {
			if (StringUtils.isNotBlank(iMap.getString("BASVURU_NO"))) {
				iMap.put("PARAM_REF_TUR", "KK_BASVURU");
				iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
			} else if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
				iMap.put("PARAM_REF_TUR", "GNL_MUSTERI");
				iMap.put("PARAM_REF_ID", iMap.getString("MUSTERI_NO"));
			} else if (StringUtils.isNotBlank(iMap.getString("AD"))) {
				iMap.put("PARAM_REF_TUR", "GENEL");
				iMap.put("PARAM_REF_ID", CreditCardServicesUtil.convertStringTrToEn(iMap.getString("AD") + " " + iMap.getString("SOYAD")));
			} else if (StringUtils.isNotBlank(iMap.getString("TEL_NO"))) {
				iMap.put("PARAM_REF_TUR", "GENEL");
				iMap.put("PARAM_REF_ID", iMap.getString("TEL_NO"));
			} else {
				return oMap;
			}
		}

		String func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.rc_ist_bilinmeyen_numara_cevap(?,?) }";
		Object[] inputValues = new Object[4];
		int i = 0;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("PARAM_REF_ID");
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("PARAM_REF_TUR");

		try {
			oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE", inputValues);
			oMap.put("SONUC", "Sorgu sonucu toplam " + oMap.getSize("TABLE") + " rehber kaydi bulunmustur.");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
}
