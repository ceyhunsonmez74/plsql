package tr.com.aktifbank.bnspr.creditcard.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaEftGelenUcretler;
import tr.com.aktifbank.bnspr.dao.SbaKkfonAktarim;
import tr.com.aktifbank.bnspr.dao.SbaTakastanPpiadeTx;
import tr.com.aktifbank.bnspr.dao.SbaTakastanPpiadeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4490Services implements OceanMapKeys{
	private static final String Debit_Main_Account    = "A";
	@GraymoundService("BNSPR_TRN4490_IMPORT_EXCEL")
	public static GMMap importExcel (GMMap iMap){
		GMMap oMap = new GMMap();
        try {
            byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
            } catch (Exception e) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            for (int j = 0; j < sheet.getRows(); j++) {
            	if(!StringUtils.isEmpty(sheet.getCell(0, j).getContents())){
                for (int i = 0; i < sheet.getColumns(); i++) {
                	if(i==0)
                		oMap.put("HESAPLIST", j, "KKFONHESAPNO", sheet.getCell(i, j).getContents());
                	if(i==1)
                		oMap.put("HESAPLIST", j, "KARTNO", sheet.getCell(i, j).getContents());
                	if(i==2)
                		oMap.put("HESAPLIST", j, "HESAPNO", sheet.getCell(i, j).getContents());
                	if(i==3)
                		oMap.put("HESAPLIST", j, "IBAN", sheet.getCell(i, j).getContents());
                	if(i==4)
                		oMap.put("HESAPLIST", j, "TUTAR", sheet.getCell(i, j).getContents().replace(",", "."));
                	if(i==5)
                		oMap.put("HESAPLIST", j, "ACIKLAMA", sheet.getCell(i, j).getContents());
                	}	
                }
            }
            
        } catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
        } 
        return oMap;
	}
	@GraymoundService("BNSPR_TRN4490_KONTROL")
	public static GMMap kontrol(GMMap iMap){
		
		GMMap cardMap = new GMMap();
		GMMap cMap = new GMMap();
		BigDecimal musteriNo = BigDecimal.ZERO;
		BigDecimal cardLimit;
		BigDecimal cardAvailLimit;
		BigDecimal kkFonBakiye = BigDecimal.ZERO;
		BigDecimal bakiye;
		try {
			int s = iMap.getSize("HESAPLIST");
			boolean isError = false; 
			for (int i = 0; i < s; i++) {
				
				if (StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"KKFONHESAPNO"))) {
						 iMap.put("HATA_NO", new BigDecimal(660));
			                iMap.put("P1", "KKFON Hesap numaras� bo� olamaz. Sat�r No: " + (i+1));
			                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						
					}
				if (StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"KARTNO")) && StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"HESAPNO")) && StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"IBAN"))) {
					 iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Hesap numaras�, IBAN ya da Kart numaras� ayn� anda bo� olamaz. Sat�r No: " + (i+1));
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				if (StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"TUTAR"))) {
					 iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Tutar bo� olamaz. Sat�r No: " + (i+1));
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				if(acikMi(iMap.getBigDecimal("HESAPLIST",i,"KKFONHESAPNO")).equals("E")){
				if(!getUrunSinif(iMap.getBigDecimal("HESAPLIST",i,"KKFONHESAPNO")).equals("KKART FON")){
					iMap.put("HESAPLIST",i, "HATAACIKLAMA","Bu hesap KKFON hesab� de�il");
					isError=true;
					continue;
				}
				else{
					kkFonBakiye =bakiyeAl(iMap.getBigDecimal("HESAPLIST",i,"KKFONHESAPNO")); 
					if(kkFonBakiye.compareTo(iMap.getBigDecimal("HESAPLIST",i,"TUTAR")) <0){
						iMap.put("HESAPLIST",i, "HATAACIKLAMA","Hesap bakiyesi yeterli de�il");
						isError=true;
						continue;
					}
					musteriNo = getMusteriNo(iMap.getBigDecimal("HESAPLIST",i,"KKFONHESAPNO"));
					iMap.put("HESAPLIST",i, "HATAACIKLAMA","");
				}}else{
					iMap.put("HESAPLIST",i, "HATAACIKLAMA","KKFON Hesab� bulunamad�");
					isError=true;
					continue;
				}
				if(!hesapHareketKontrol(iMap.getBigDecimal("HESAPLIST",i,"KKFONHESAPNO"))){
					iMap.put("HESAPLIST",i, "HATAACIKLAMA","KKFON Hesab�na Bor�/Alacak girilemez!");
					isError=true;
					continue;
				}
				
				if(!StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"KARTNO"))){
					cardMap.clear(); 
					cardMap.put("CARD_NO", iMap.getString("HESAPLIST",i,"KARTNO"));
					cardMap = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cardMap);
					if (!cardMap.getString("RETURN_CODE").equals("0")){
						iMap.put("HESAPLIST",i, "HATAACIKLAMA","Kart Bulunamad�");
						isError=true;
						continue;
					}
					else{
						String dest=cardMap.getString("DESTINATION");
						String dci = cardMap.getString("DCI");
						if (dest.equals("O") && dci.equals("C")){
							iMap.put("HESAPLIST",i,"ALICIHESAPNO", getGlobalParam("KK_FINANSAL_BAKIM_HESAP"));
							iMap.put("HESAPLIST",i,"ALICIHESAPSUBE", "998");
							iMap.put("HESAPLIST",i,"ALICIHESAPCINSI", "DK");
						}
						else if(dest.equals("I") && dci.equals("P")){
							iMap.put("HESAPLIST",i,"ALICIHESAPNO", getGlobalParam("PP_FINANSAL_BAKIM_HESAP"));
							iMap.put("HESAPLIST",i,"ALICIHESAPSUBE", "997");
							iMap.put("HESAPLIST",i,"ALICIHESAPCINSI", "DK");
						}
						else if (dci.equals("D")){
						GMMap cardInfoMap = new GMMap();
		                cardInfoMap.put("CARD_NO" , iMap.getString("HESAPLIST",i,"KARTNO"));
		                cardInfoMap.put("CARD_DCI" , "A");
		                if (dest.equals("I")){
		                	cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO" , cardInfoMap);
		                } else{
		                	cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , cardInfoMap);
		                }
		                List<GMMap> cardAccount = (List<GMMap>) cardInfoMap.get("CARD_DETAIL_INFO" , 0 , "DEBIT_ACCOUNT_LIST");
                        GMMap accMap = new GMMap(cardAccount.get(0));
                        
                        for (int j = 0; j < accMap.getSize("DEBIT_ACCOUNT_LIST"); j++){
                            
                            if (accMap.getString("DEBIT_ACCOUNT_LIST" , j , "DEBIT_ACCOUNT_TYPE").equals(Debit_Main_Account)){
                                
                           	iMap.put("HESAPLIST",i,"ALICIHESAPNO", accMap.getBigDecimal("DEBIT_ACCOUNT_LIST" , j , "DEBIT_ACCOUNT_NO"));
                           	iMap.put("HESAPLIST",i,"ALICIHESAPCINSI", "VS");
				            iMap.put("HESAPLIST",i,"ALICIHESAPSUBE", getSubeKodu(accMap.getBigDecimal("DEBIT_ACCOUNT_LIST" , j , "DEBIT_ACCOUNT_NO")));
                           	break; 
                            }
                        }
						
						}
						
						iMap.put("HESAPLIST",i, "HATAACIKLAMA","");
					}
				}
				
				if(!StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"IBAN"))){
					if(ibanCheck(iMap.getString("HESAPLIST",i,"IBAN")).equals("0")){
						iMap.put("HESAPLIST",i, "HATAACIKLAMA","Hatal� IBAN");
						isError=true;
						continue;
					}
					else{
						iMap.put("HESAPLIST", i, "ALICIHESAPNO", getGlobalParam("4487_EFT_HESABI"));
						iMap.put("HESAPLIST", i, "ALICIHESAPCINSI","VS");
						iMap.put("HESAPLIST", i, "ALICIHESAPSUBE",getSubeKodu(BigDecimal.valueOf(Long.valueOf(getGlobalParam("4487_EFT_HESABI")))));
						iMap.put("HESAPLIST",i, "HATAACIKLAMA","");
					}
						
				}
				if(!StringUtils.isEmpty(iMap.getString("HESAPLIST",i,"HESAPNO"))){
					if(getUrunSinif(iMap.getBigDecimal("HESAPLIST",i,"HESAPNO")).equals("KKART FON")){
						iMap.put("HESAPLIST",i, "HATAACIKLAMA","Bu hesap KKFON hesab�d�r");
						isError=true;
						continue;
					}else{
						if(!hesapHareketKontrol(iMap.getBigDecimal("HESAPLIST",i,"HESAPNO"))){
							iMap.put("HESAPLIST",i, "HATAACIKLAMA","Al�c� Hesaba Bor�/Alacak girilemez!");
							isError=true;
							continue;
						}
						if(musteriNo.compareTo(getMusteriNo(iMap.getBigDecimal("HESAPLIST",i,"HESAPNO")))!=0){
							iMap.put("HESAPLIST",i, "HATAACIKLAMA","Bu hesap KKFON hesab� m��terisine ait de�ildir");
							isError=true;
							continue;
						}else{
							
							iMap.put("HESAPLIST", i, "ALICIHESAPNO",iMap.getBigDecimal("HESAPLIST",i,"HESAPNO"));
							iMap.put("HESAPLIST", i, "ALICIHESAPCINSI","VS");
							iMap.put("HESAPLIST", i, "ALICIHESAPSUBE",getSubeKodu(iMap.getBigDecimal("HESAPLIST",i,"HESAPNO")));
							iMap.put("HESAPLIST",i, "HATAACIKLAMA","");
						}
					}
				}
				
				/*cMap.put("CARD_NO", iMap.getString("HESAPLIST",i,"KARTNO"));
				cMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cMap);
				cardAvailLimit = cMap.getBigDecimal("CARD_DETAIL_INFO",0,"CARD_AVAIL_LIMIT");
				cardLimit = cMap.getBigDecimal("CARD_DETAIL_INFO",0,"CARD_LIMIT");
				bakiye = cardAvailLimit.subtract(cardLimit);
				
				iMap.put("HESAPLIST", i,"KKFONBAKIYE",bakiye);
				if(bakiye.compareTo(iMap.getBigDecimal("HESAPLIST",i,"TUTAR"))<0){
					iMap.put("HESAPLIST",i, "HATAACIKLAMA","Yetersiz Fon Bakiyesi");
					isError=true;
					continue;
				}*/
				
			}
			if(isError)
				iMap.put("HATA", "1");
			else
				iMap.put("HATA", "0");
		}
          catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	@GraymoundService("BNSPR_TRN4490_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			int s= iMap.getSize("HESAPLIST");
			for (int i = 0; i < s; i++) {
				SbaKkfonAktarim kkFon = new SbaKkfonAktarim();
				
				kkFon.setMainTxNo(iMap.getBigDecimal("TRX_NO"));
				kkFon.setTxNo(createTx());
				kkFon.setAciklama(iMap.getString("HESAPLIST",i,"ACIKLAMA"));
				kkFon.setAlckHesapCinsi(iMap.getString("HESAPLIST",i,"ALICIHESAPCINSI"));
				kkFon.setAlckHesapNo(iMap.getString("HESAPLIST",i,"ALICIHESAPNO"));
				kkFon.setAlckSubeKodu(iMap.getString("HESAPLIST",i,"ALICIHESAPSUBE"));
				kkFon.setHesapNo(iMap.getBigDecimal("HESAPLIST",i,"HESAPNO"));
				kkFon.setIban(iMap.getString("HESAPLIST",i,"IBAN"));
				kkFon.setKartNo(iMap.getString("HESAPLIST",i,"KARTNO"));
				kkFon.setKkfonhesapno(iMap.getBigDecimal("HESAPLIST",i,"KKFONHESAPNO"));
				kkFon.setTutar(iMap.getBigDecimal("HESAPLIST",i,"TUTAR"));
				session.saveOrUpdate(kkFon);
			}
			session.flush();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("TRX_NAME" , "4490");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4491_AFTER_APPROVAL")
	public static GMMap afterApproval (GMMap iMap){
		GMMap oMap =new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaKkfonAktarim kkFon = (SbaKkfonAktarim) session.createCriteria(SbaKkfonAktarim.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			GMMap cardMap = new GMMap();
			GMMap cardRespMap = new GMMap();
			
			if(!StringUtils.isEmpty(kkFon.getKartNo()) && kkFon.getAlckHesapCinsi().equals("DK") ){
			cardMap.put(BSMV_RATE, BigDecimal.ZERO);
			cardMap.put(KKF_RATE, BigDecimal.ZERO);
			
			cardMap.put(TXN_AMOUNT, kkFon.getTutar());
			cardMap.put(CARD_NO, kkFon.getKartNo());
			
			cardMap.put(TXN_CURR_CODE, "TRY");
			cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
			cardMap.put(TXN_STATE, "N");

			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			cardMap.put(TXN_DATE, format.format(new Date()));
			cardMap.put(TXN_DESC, "Kredi kart� art� bakiye iadesi");
			if(kkFon.getAlckSubeKodu().equals("998")){
				cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
			}
			else if(kkFon.getAlckSubeKodu().equals("997")){
				cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
			}
			if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
				throw new GMRuntimeException(4448011, "Kart Transfer : "+ cardRespMap.getString(RETURN_DESCRIPTION));
			}
			
			cardRespMap.put(TX_NO, iMap.getBigDecimal("ISLEM_NO"));
			cardRespMap.put(OCEAN_RESULT, cardRespMap.getString("OCEAN_RESULT"));
			
			GMServiceExecuter.executeNT("BNSPR_CRD_INSERT_TOPUP_RRN_LOG", cardRespMap);
			
		}
		
			oMap.put("MESSAGE", "��lem Ba�ar�yla Tamamland�");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4490_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> kkFonList = session.createCriteria(SbaKkfonAktarim.class).add(Restrictions.eq("mainTxNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			for (Object name : kkFonList) {
				SbaKkfonAktarim kkFon = (SbaKkfonAktarim) name;
				oMap.put("HESAPLIST", i,"KARTNO",kkFon.getKartNo());
				oMap.put("HESAPLIST", i,"ACIKLAMA",kkFon.getAciklama());
				oMap.put("HESAPLIST", i,"ALICIHESAPCINSI",kkFon.getAlckHesapCinsi());
				oMap.put("HESAPLIST", i,"ALICIHESAPNO",kkFon.getAlckHesapNo());
				oMap.put("HESAPLIST", i,"ALICIHESAPSUBE",kkFon.getAlckSubeKodu());
				oMap.put("HESAPLIST", i,"HESAPNO",kkFon.getHesapNo());
				oMap.put("HESAPLIST", i,"IBAN",kkFon.getIban());
				oMap.put("HESAPLIST", i,"KKFONHESAPNO",kkFon.getKkfonhesapno());
				oMap.put("HESAPLIST", i,"TUTAR",kkFon.getTutar());
			
				i=i+1;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4490_AFTER_APPROVAL")
	public static GMMap afterApproval4490 (GMMap iMap){
		GMMap oMap =new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<?> kkFonList = session.createCriteria(SbaKkfonAktarim.class).add(Restrictions.eq("mainTxNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			for (Object name : kkFonList) {
				SbaKkfonAktarim kkFon = (SbaKkfonAktarim) name;
				iMap.put("TRX_NO", kkFon.getTxNo());
				iMap.put("TRX_NAME" , "4491");
		        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	  
	 public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	
	 public static String getUrunSinif (BigDecimal hesapNo){
		 Object[] input = new Object[2];
		 input[0] = BnsprType.NUMBER;
		 input[1] = hesapNo;
		 String func = "{? = call PKG_HESAP.urun_sinif_kod(?)}";
		 String urunSinif = (String) DALUtil.callOneParameterFunction(func, Types.CHAR, hesapNo);
		 return urunSinif;
	 }	
	 public static String acikMi (BigDecimal hesapNo){
		 String acikMi;
		 Object[] input = new Object[2];
		 input[0] = BnsprType.NUMBER;
		 input[1] = hesapNo;
		 String func = "{? = call PKG_HESAP.acik_mi(?)}";
		 try {
			acikMi = (String) DALUtil.callOneParameterFunction(func, Types.CHAR, hesapNo);
		}
		catch (Exception e) {
			acikMi="H";
		}
		 
		 return acikMi;
	 }
	 public static BigDecimal bakiyeAl(BigDecimal hesapNo){
		 BigDecimal tutar;
		 BigDecimal fonTutar = BigDecimal.ZERO;
		 BigDecimal bakiye = BigDecimal.ZERO;
		 String func = "{? = call pkg_fon_wrapper.HesapNetFonDeger(?)}";
		 fonTutar = (BigDecimal) DALUtil.callOneParameterFunction(func, Types.NUMERIC, hesapNo);
		 func = "{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?)}";
		 bakiye = (BigDecimal) DALUtil.callOneParameterFunction(func, Types.NUMERIC, hesapNo);
		 tutar = fonTutar.add(bakiye);
		 return tutar;
	 }
	 public static BigDecimal getMusteriNo(BigDecimal hesapNo){
		 GMMap hMap = new GMMap();
		 hMap.put("HESAP_NO", hesapNo);
		 hMap = GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", hMap);
		 return hMap.getBigDecimal("MUSTERI_NO");
	 }
	 public static String ibanCheck (String iban){
		GMMap iMap =  new GMMap();
		iMap.put("IBAN", iban);
		iMap = GMServiceExecuter.call("BNSPR_IBAN_KONTROL_WITH_NO_ERROR", iMap);
		return iMap.getString("ibanControl");
	 }
	 public static BigDecimal getSubeKodu(BigDecimal hesapNo){
		 GMMap hMap = new GMMap();
		 hMap.put("HESAP_NO", hesapNo);
		 hMap = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", hMap);
		 return hMap.getBigDecimal("SUBE_KODU");
	 }
	 public static BigDecimal createTx(){
	    	GMMap oMapN = new GMMap();
			oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
			return oMapN.getBigDecimal("TRX_NO");
	}
	 public static boolean hesapHareketKontrol(BigDecimal hesapNo){
		 boolean control = false;
		 GMMap iMap = new GMMap();
		 iMap.put("hesapNo", hesapNo);
		 iMap = GMServiceExecuter.call("BNSPR_CURRENT_ACCOUNTS_GET_HESAP_HAREKET_KODU", iMap);
		 if (iMap.getString("HESAP_HAREKET_KODU").equals("1")){
			 control=true;
		 }
		 return control;
	 }
}
