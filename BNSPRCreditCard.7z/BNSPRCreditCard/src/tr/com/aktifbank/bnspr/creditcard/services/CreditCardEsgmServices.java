package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** Genel olarak kullanilan ESGM ara katman servislerini icerir.
 * 
 * @author murat.el
 * @since BT-6629
 */
public class CreditCardEsgmServices {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since BT-6629
	 * @param iMap - Islem bilgileri<br>
	 *         <li>TRX_NO - Islem numarasi
	 *         <li>BASVURU_NO - Kredi karti basvuru numarasi
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 * 		   <li>ESGM_YAPILDI_MI - Verilen basvuru icin esgm sorgusu yapildi mi?(Y:Evet|N:Hayir)
	 *         <li>ESGM_AKTIF_MI - Esgm sistemi aktif mi?(A:Acik|K:Kapali)
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>CAPTCHA - Islem basarili ise ekranda goruntulenecek dogrulama resmi
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_GET_CAPTCHA")
	public static GMMap getCaptcha(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		//Output parametreler
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		oMap.put("ESGM_YAPILDI_MI", CreditCardServicesUtil.NO);
		oMap.put("ESGM_AKTIF_MI", "A");
		
		try {
			//Basvuru icin esgm sorgusu yapilmis mi? Yapildi ise tekrar yapma
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_ESGM_CHECK_VALIDATION", sorguMap));
			if (CreditCardServicesUtil.YES.equals(sorguMap.getString("RESULT"))) {
				oMap.put("ESGM_YAPILDI_MI", CreditCardServicesUtil.YES);
				return oMap;
			}
			
			//Esgm sorgusu yapilabilir durumda mi? Sistem kapali ise esgm sorgusu yapilmaz
			sorguMap.clear();
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXT_ESGMSGK_IS_WEB_QUERY_ENABLED", sorguMap));
			if ("K".equals(sorguMap.getString("DEGER"))) {
				oMap.put("ESGM_AKTIF_MI", "K");
				return oMap;
			}
			
			//Sorgu yapilabilir ise, captchayi al
			sorguMap.clear();
			sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_EXT_ESGMSGK_GET_LOGIN_CAPTCHA", sorguMap));
			if ("2".equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("CAPTCHA", sorguMap.get("CAPTCHA"));
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since BT-6629
	 * @param iMap - Islem bilgileri<br>
	 *         <li>BASVURU_NO - ESGM sorgusu yapildi mi kontrolu yapilacak basvuru numarasi
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>RESULT - Verilen basvuru icin esgm sorgusu yapildi mi?(Y:Evet|N:Hayir)
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_CHECK_VALIDATION")
	public static GMMap checkCaptchaValidation(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KK_BASVURU_SORGU.CHECK_ESGM_CAPTCHA_VALIDATION(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("RESULT", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen musteriye ESGM captcha dogrulamasi ve/veya ESGM sorgusu yapar.
     *
	 * @author murat.el
	 * @since BT-6629, BT-6638
	 * @param iMap - Esgm sorgu parametreleri
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>BASVURU_NO - Basvuru numarasi(Esgm sorgusu yapilacaksa zorunlu)
	 *         <li>CAPTCHA - Captcha
	 *         <li>GUVENLIK_KODU - Guvenlik Kodu
	 *         <li>CAPTCHA_DOGRULANSIN_MI - Captcha ve guvenlik kodu kontrolu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>ESGM_SORGU_YAPILSIN_MI - Captcha ile esgm sorgusu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>CAPTCHA_DENEME_SAYISI - Guvenlik kodu giris max sayisi
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_SORGU_BY_MUSTERI")
	public static GMMap esgmSorguByMusteri(GMMap iMap) {
		GMMap oMap = new GMMap();	

		try {
			//Parametre kontrolu
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			if (musteriNo == null) {
				CreditCardServicesUtil.raiseGMError("330", "Musteri No");
			}
			
			//Musteriden kimlik bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			GnlMusteriKimlik gnlMusteriKimlik = null;
			GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, musteriNo);
			if (gnlMusteri != null) {
				gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, gnlMusteri.getMusteriNo());
			}
			
			//Musteri bilgileri alindi mi?
			if (gnlMusteri == null || gnlMusteriKimlik == null) {
				CreditCardServicesUtil.raiseGMError("4232");
			}
			
			//Sorgula
			GMMap sorguMap = new GMMap();
			sorguMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
			sorguMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
			sorguMap.put("TCKN", gnlMusteri.getTcKimlikNo());
			sorguMap.put("IL_KODU", gnlMusteriKimlik.getNufIlKod());
			sorguMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(gnlMusteriKimlik.getDogumTarihi()));
			sorguMap.put("CILT_NO", gnlMusteriKimlik.getNufCiltNo());
			sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sorguMap.put("CAPTCHA_DOGRULANSIN_MI", iMap.get("CAPTCHA_DOGRULANSIN_MI"));
			sorguMap.put("ESGM_SORGU_YAPILSIN_MI", iMap.get("ESGM_SORGU_YAPILSIN_MI"));
			sorguMap.put("CAPTCHA_DENEME_SAYISI", iMap.get("CAPTCHA_DENEME_SAYISI"));
			oMap.putAll(esgmSorgu(sorguMap));
		} catch(Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}
		
		return oMap;
	}
	
	/** Verilen kimlik numarasi ile ESGM captcha dogrulamasi ve/veya ESGM sorgusu yapar.
     *
	 * @author murat.el
	 * @since BT-6629, BT-6638
	 * @param iMap - Esgm sorgu parametreleri
	 *         <li>TCKN - Musteriye ait kimlik numarasi
	 *         <li>BASVURU_NO - Basvuru numarasi(Esgm sorgusu yapilacaksa zorunlu)
	 *         <li>CAPTCHA - Captcha
	 *         <li>GUVENLIK_KODU - Guvenlik Kodu
	 *         <li>CAPTCHA_DOGRULANSIN_MI - Captcha ve guvenlik kodu kontrolu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>ESGM_SORGU_YAPILSIN_MI - Captcha ile esgm sorgusu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>CAPTCHA_DENEME_SAYISI - Guvenlik kodu giris max sayisi
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_SORGU_BY_TCKN")
	public static GMMap esgmSorguByTckn(GMMap iMap) {
		GMMap oMap = new GMMap();		

		try {
			//Parametre kontrolu
			String tcKimlikNo = iMap.getString("TCKN");
			if (StringUtils.isBlank(tcKimlikNo)) {
				CreditCardServicesUtil.raiseGMError("330", "Tc Kimlik No");
			}
			
			//Musteriden kimlik bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			GnlMusteriKimlik gnlMusteriKimlik = null;
			GnlMusteri gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class)
					.add(Restrictions.eq("tcKimlikNo", tcKimlikNo))
					.uniqueResult();
			if (gnlMusteri != null) {
				gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, gnlMusteri.getMusteriNo());
			}
			
			//Musteri bilgileri alindi mi?
			if (gnlMusteri == null || gnlMusteriKimlik == null) {
				CreditCardServicesUtil.raiseGMError("4232");
			}
			
			//Sorgula
			GMMap sorguMap = new GMMap();
			sorguMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
			sorguMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
			sorguMap.put("TCKN", tcKimlikNo);
			sorguMap.put("IL_KODU", gnlMusteriKimlik.getNufIlKod());
			sorguMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(gnlMusteriKimlik.getDogumTarihi()));
			sorguMap.put("CILT_NO", gnlMusteriKimlik.getNufCiltNo());
			sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sorguMap.put("CAPTCHA_DOGRULANSIN_MI", iMap.get("CAPTCHA_DOGRULANSIN_MI"));
			sorguMap.put("ESGM_SORGU_YAPILSIN_MI", iMap.get("ESGM_SORGU_YAPILSIN_MI"));
			sorguMap.put("CAPTCHA_DENEME_SAYISI", iMap.get("CAPTCHA_DENEME_SAYISI"));
			oMap.putAll(esgmSorgu(sorguMap));
		} catch(Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}
		
		return oMap;
	}
	
	/** Verilen kredi karti basvuru numarasi ile ESGM captcha dogrulamasi ve/veya ESGM sorgusu yapar.
    *
	 * @author murat.el
	 * @since BT-6629, BT-6638
	 * @param iMap - Esgm sorgu parametreleri
	 *         <li>BASVURU_NO - Kredi karti basvuru numarasi
	 *         <li>CAPTCHA - Captcha
	 *         <li>GUVENLIK_KODU - Guvenlik Kodu
	 *         <li>CAPTCHA_DOGRULANSIN_MI - Captcha ve guvenlik kodu kontrolu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>ESGM_SORGU_YAPILSIN_MI - Captcha ile esgm sorgusu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>CAPTCHA_DENEME_SAYISI - Guvenlik kodu giris max sayisi
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_SORGU_BY_KK_BASVURU")
	public static GMMap esgmSorguByKkBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();		

		try {
			//Parametre kontrolu
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			if (basvuruNo == null) {
				CreditCardServicesUtil.raiseGMError("330", "Basvuru No");
			}
			
			//Basvurudan kimlik bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, basvuruNo);
			//Basvuru bilgileri alindi mi?
			if (kkBasvuruKimlik == null) {
				CreditCardServicesUtil.raiseGMError("4232");
			}

			//Sorgula
			GMMap sorguMap = new GMMap();
			sorguMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
			sorguMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
			sorguMap.put("TCKN", kkBasvuruKimlik.getTcKimlikNo());
			sorguMap.put("IL_KODU", kkBasvuruKimlik.getNufusIlKod());
			sorguMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(kkBasvuruKimlik.getDogumTar()));
			sorguMap.put("CILT_NO", kkBasvuruKimlik.getCiltNo());
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("CAPTCHA_DOGRULANSIN_MI", iMap.get("CAPTCHA_DOGRULANSIN_MI"));
			sorguMap.put("ESGM_SORGU_YAPILSIN_MI", iMap.get("ESGM_SORGU_YAPILSIN_MI"));
			sorguMap.put("CAPTCHA_DENEME_SAYISI", iMap.get("CAPTCHA_DENEME_SAYISI"));
			oMap.putAll(esgmSorgu(sorguMap));
		} catch(Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}
		
		return oMap;
	}
	
	/** Verilen tff basvuru numarasi ile ESGM captcha dogrulamasi ve/veya ESGM sorgusu yapar.
    *
	 * @author murat.el
	 * @since BT-6629, BT-6638
	 * @param iMap - Esgm sorgu parametreleri
	 *         <li>BASVURU_NO - Tff basvuru numarasi
	 *         <li>CAPTCHA - Captcha
	 *         <li>GUVENLIK_KODU - Guvenlik Kodu
	 *         <li>CAPTCHA_DOGRULANSIN_MI - Captcha ve guvenlik kodu kontrolu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>ESGM_SORGU_YAPILSIN_MI - Captcha ile esgm sorgusu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>CAPTCHA_DENEME_SAYISI - Guvenlik kodu giris max sayisi
	 *         <li>HATA_VERILSIN_MI - Hata verilsin mi? (E:Evet|H:Hayir)
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_SORGU_BY_TFF_BASVURU")
	public static GMMap esgmSorguByTffBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();		

		try {
			//Parametre kontrolu
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			if (basvuruNo == null) {
				CreditCardServicesUtil.raiseGMError("330", "Basvuru No");
			}
			
			//Basvurudan kimlik bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, basvuruNo);
			//Basvuru bilgileri alindi mi?
			if (tffBasvuruKimlik == null) {
				CreditCardServicesUtil.raiseGMError("4232");
			}

			//Sorgula
			GMMap sorguMap = new GMMap();
			sorguMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
			sorguMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
			sorguMap.put("TCKN", tffBasvuruKimlik.getTcKimlikNo());
			sorguMap.put("IL_KODU", tffBasvuruKimlik.getNufusIlKod());
			sorguMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(tffBasvuruKimlik.getDogumTar()));
			sorguMap.put("CILT_NO", tffBasvuruKimlik.getCiltNo());
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("CAPTCHA_DOGRULANSIN_MI", iMap.get("CAPTCHA_DOGRULANSIN_MI"));
			sorguMap.put("ESGM_SORGU_YAPILSIN_MI", iMap.get("ESGM_SORGU_YAPILSIN_MI"));
			sorguMap.put("CAPTCHA_DENEME_SAYISI", iMap.get("CAPTCHA_DENEME_SAYISI"));
			oMap.putAll(esgmSorgu(sorguMap));
		} catch(Exception e) {
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", e.getMessage());
			}
		}
		
		return oMap;
	}
	
	/** Verilen parametreler ile ESGM captcha dogrulamasi ve/veya ESGM sorgusu yapar.
    *
	 * @author murat.el
	 * @since BT-6629, BT-6638
	 * @param iMap - Esgm sorgu parametreleri
	 * 		   <li>TCKN - Tc kimlik numarasi
	 * 		   <li>IL_KODU - Nufusun bagli oldugu il kodu
	 * 		   <li>DOGUM_YILI - Dogum yili
	 * 		   <li>CILT_NO - Nufus cilt numarasi
	 *         <li>CAPTCHA - Captcha
	 *         <li>ANSWER - Guvenlik Kodu
	 *         <li>BASVURU_NO - Basvuru numarasi
	 *         <li>CAPTCHA_DOGRULANSIN_MI - Captcha ve guvenlik kodu kontrolu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>ESGM_SORGU_YAPILSIN_MI - Captcha ile esgm sorgusu yapilsin mi? (E:Evet|H:Hayir)
	 *         <li>CAPTCHA_DENEME_SAYISI - Guvenlik kodu giris max sayisi
	 * @return oMap - Islem sonucu
	 *         <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 *         <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_CREDITCARD_ESGM_SORGU")
	public static GMMap esgmSorgu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		int captchaDenemeSayisi = (Integer) CreditCardServicesUtil.nvl(iMap.getInt("CAPTCHA_DENEME_SAYISI"), 0);

		try {
			//Guvenlik kodu dogrulamasi
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("CAPTCHA_DOGRULANSIN_MI"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_SOLVE_CAPTCHA", iMap));
				//Session degeri al
				Integer yanlisDenemeSayisi = (Integer) CreditCardServicesUtil.nvl(ADCSession.get("CAPTCHA_YANLIS_DENEME_SAYISI"), 0);
				//Sorgu Kontrol
				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
					yanlisDenemeSayisi++;
					if (captchaDenemeSayisi == 0 || yanlisDenemeSayisi <= captchaDenemeSayisi) {
						ADCSession.put("CAPTCHA_YANLIS_DENEME_SAYISI", yanlisDenemeSayisi);
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));
						return oMap;
					} else {
						if (ADCSession.get("CAPTCHA_YANLIS_DENEME_SAYISI") != null) {
							ADCSession.remove("CAPTCHA_YANLIS_DENEME_SAYISI");
						}
					}
				} else {
					if (ADCSession.get("CAPTCHA_YANLIS_DENEME_SAYISI") != null) {
						ADCSession.remove("CAPTCHA_YANLIS_DENEME_SAYISI");
					}
				}
			}
			//Esgm sorgusu
			if (CreditCardServicesUtil.EVET.equals(iMap.getString("ESGM_SORGU_YAPILSIN_MI"))) {
				ADCSession.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_PARSE", iMap);
				ADCSession.remove("BASVURU_NO");
			}
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
}
