package tr.com.aktifbank.bnspr.creditcard.services;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.axis.encoding.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;

import tr.com.aktifbank.bnspr.dao.KartBasvuruVeriKntlDtyTx;
import tr.com.aktifbank.bnspr.dao.KartBasvuruVeriKntlDtyTxId;
import tr.com.aktifbank.bnspr.dao.KartBasvuruVeriKntlTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffVeriKontrolHavuz;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** TFF Karti veri kontrol islemlerini gerceklestiren servisleri icerir.
 * 
 * @author murat.el
 * @since 26.11.2013
 */
public class CreditCardTRN3805Services {
	
	/** Veri kontrol sonucu uygun */
	private static final String UYGUN = "1";
	/** Veri kontrol sonucu uygun degil*/
	private static final String UYGUN_DEGIL = "2";
	/** Veri kontrol sonucu eksik */
	private static final String EKSIK = "3";
	/**Kart Hosgeldin Event*/
	private static final String KART_HOSGELDIN_EVENT_TYPE_NO = "17";
	/**EVAM event type*/
	private static final String FOTO_EKSIK_EVENT_TYPE_NO = "27";
	/**INTRA JOB hata mesaj*/
	private static final String INTRA_JOB_HATA_MESAJ = "Kart paketine aktar�m hatas� alm��t�r: ";
	/** Veri kontrolu yapilabilecek alanlari iceren key*/
	private static final String VK_ALAN_TABLE = "VK_ALAN_TABLE";
	//Logger
	private static final Logger logger = Logger.getLogger(CreditCardTRN3805Services.class);
	
	private static final String IssuingExceptionApplicationNoUsedBefore = "Issuing.Exception.ApplicationNoUsedBefore";

	/** Verilen sorgulama kriterlerini alarak belirlenmis kriterlere uygun ilk kaydi veri kontrolu yapmak uzere listeler.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - BASVURU_NO, KART_TIPI, MUSTERI_NO, EKRAN_KOD
	 * @return oMap - Alan degerleri
	 */
	@GraymoundService("BNSPR_TRN3805_GET_BASVURU_INFO")
	public static GMMap getBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3805.Rc_Qry3805_Get_Basvuru(?,?,?,?,?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
            stmt.registerOutParameter(2, Types.VARCHAR);
            stmt.setString(2, iMap.getString("KART_TIPI"));
            stmt.registerOutParameter(3, Types.NUMERIC);
            stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.registerOutParameter(4, -10);
            stmt.setString(5, iMap.getString("EKRAN_KOD"));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(4);
            oMap = DALUtil.rSetMap(rSet);
            
            if (oMap.getBigDecimal("BASVURU_NO") == null) {
            	BigDecimal basvuruNo = stmt.getBigDecimal(1);
            	String kartTipi = stmt.getString(2);
            	if (basvuruNo != null) {
            		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
            		String durumKod = "";
					if("KK".equals(kartTipi)){
						KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
						durumKod  = kkBasvuru!= null ? kkBasvuru.getDurumKod() : "";
					}else{
						TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
						durumKod  = tffBasvuru != null ? tffBasvuru.getDurumKod() : "" ;
					}
            		if (("3805".equals(iMap.getString("EKRAN_KOD")) && "FOTO_EKSIK_ONAY".equals(durumKod)) ||
            			("3825".equals(iMap.getString("EKRAN_KOD")) && "VERI_KONTROL".equals(durumKod))) {
            			//Do nothing
            		} else {
            			//Havuzda hatali olarak guncelle
                		sorguMap.clear();
                		if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi)) {
                			sorguMap.put("KK_BASVURU_NO", basvuruNo);
                		} else {
                			sorguMap.put("TFF_BASVURU_NO", basvuruNo);
                		}
                		sorguMap.put("KART_TIPI", kartTipi);
                		sorguMap.put("HATALI_MI", CreditCardServicesUtil.EVET);
                		sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap));
                		//Hata maili gonder
                		StringBuilder mailBody = new StringBuilder();
                		mailBody.append("Veri kontrol havuzuna dusen basvuru hatali. Basvuru bilgileri:").append("\n");
                		mailBody.append("Basvuru No : ").append(basvuruNo).append("\n");
    					mailBody.append("Kart tipi : ").append(kartTipi);
    					
                		sorguMap.clear();
    					sorguMap.put("MAIL_TO_PARAM", "TFF_MUSTERI_YAP_HATA_MAIL_TO");
    					sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
    					sorguMap.put("MAIL_SUBJECT", "Veri Kontrol Hatali Basvuru");
    					sorguMap.put("MAIL_BODY", mailBody.toString() );
    					GMServiceExecuter.executeNT("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
            		}
            	}
            	
            	CreditCardServicesUtil.raiseGMError("1053");
            }
            
            //Basvuruyu kilitle
            String durumKodu = StringUtils.EMPTY;
            if ("3805".equals(iMap.getString("EKRAN_KOD"))) {
            	durumKodu = "VERI_KONTROL";
            } else if ("3825".equals(iMap.getString("EKRAN_KOD"))) {
            	durumKodu = "FOTO_EKSIK_ONAY";
            }
            sorguMap.clear();
            sorguMap.put("ROL", "R");
            sorguMap.put("BASVURU_NO", oMap.getBigDecimal("TFF_BASVURU_NO"));
            sorguMap.put("DURUM_KOD", durumKodu);
            sorguMap.put("AKIS_TIPI", "TFF");
            GMServiceExecuter.execute("BNSPR_QRY3829_KULLANICI_ISLEM", sorguMap);

            //FOTOyu al
            oMap.putAll(getBasvuruFoto(oMap));
            
            //Ekranda kontrol edilecek alanlari enable et.
            oMap.put("EKRAN_KOD", iMap.get("EKRAN_KOD"));
            oMap.putAll(getVeriKontrolAlan(oMap));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}

	/** Pathi verilen ya da default olarak olusturulan pathdeki resmi alarak string formatinda encode ederek doner.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - FILE_PATH, TC_KIMLIK_NO, PASAPORT_NO, UYRUK_KOD, TFF_BASVURU_NO
	 * @return oMap - FOTO_DEGER, FOTO_PATH
	 */
	@GraymoundService("BNSPR_TRN3805_GET_FOTO")
	public static GMMap getBasvuruFoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		String filePath = iMap.getString("FILE_PATH");
		String fotoBase64 = null;
		
		try {
			//File path parametre olarak geldi ise al
			if (StringUtils.isBlank(filePath)) {
				//Uyruk alanina gore kimlik alanina degeri ata.
				if ("TR".equals(iMap.getString("UYRUK_KOD"))) {
					iMap.put("KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
				} else {
					iMap.put("KIMLIK_NO", iMap.getString("PASAPORT_NO"));
				}
				
				//Foto pathi al.
				try {
					GMMap fMap = new GMMap();
					fMap.put("KIMLIK_NO", iMap.getString("KIMLIK_NO"));
					fMap.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_FOTO_PATH_VER", fMap));
				} catch (Exception e) {
					logger.error(e);
					filePath = null;
				}
				
				//Foto pathi hatali isec default deger ata, yoksa pathi al.
				if (oMap.getInt("RESPONSE") == 1 || oMap.get("PATH") == null) {
					logger.debug("path yok");
					filePath = null;
				} else {
					filePath = oMap.getString("PATH");
					logger.debug("path:" + filePath);
				}
			}
			
			//resmi belirtilen dizinden oku ve string olarak al.
			//TODO filePath = "default_kisi.gif";
			if (filePath != null) {
				BufferedImage foto = null;
				try {
					foto = ImageIO.read(new File(filePath));
					fotoBase64 = getBufferedImageAsString(foto);
				} catch (IOException e) {
					logger.error(e);
					fotoBase64 = null;
				}
			}
			
			oMap.put("FOTO_PATH", filePath);
			oMap.put("FOTO_DEGER_BASE64", fotoBase64);
			if (fotoBase64 == null) {
				oMap.put("FOTO_DEGER", fotoBase64);
			} else {
				oMap.put("FOTO_DEGER", "data:image/jpeg;base64," + fotoBase64);
			}
		} catch (Exception e) {
			logger.error(e);
			oMap.put("FOTO_PATH", filePath);
			oMap.put("FOTO_DEGER_BASE64", fotoBase64);
			oMap.put("FOTO_DEGER", fotoBase64);
		}
		
		return oMap;
	}
	
	/** Verilen foto objesini encode ederek string olarak geri doner.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param foto - Image olarak fotograf objesi
	 * @return image - String olarak fotograf objesi
	 * @throws IOException
	 */
	private static String getBufferedImageAsString(BufferedImage foto) throws IOException {
		//Byte array haline getir.
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write( foto, "jpg", baos );
		baos.flush();
		byte[] imageBytes = baos.toByteArray();
		baos.close();
		
		//Byte array olan resmi string olarak formatla.
		String base64ImgStr = Base64.encode(imageBytes);
		base64ImgStr = base64ImgStr.trim().replaceAll("\n", "");
		return base64ImgStr;
	}
	
	/** Veri kontrolu yapilacak alanlari ekrana gonderir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - BASVURU_NO, KART_TIPI, EKRAN_KOD
	 * @return VK_ALAN_TABLE:Alanlar, Alan Durumlari(0:Kontrol Etme/1:Kontrol Edilecek)
	 */
	public static GMMap getVeriKontrolAlan(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Sonuclari Al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3805.Rc_Qry3805_Get_Veri_Kntl_Alan(?,?,?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
            stmt.setString(3, iMap.getString("KART_TIPI"));
            stmt.setString(4, iMap.getString("EKRAN_KOD"));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetMap(rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Veri kontrolu yapilabilecek tum alanlari ekrana gonderir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap
	 * @return VK_ALAN_TABLE:Alanlar
	 */
	public static GMMap getVeriKontrolAlanAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Sonuclari Al
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_TRN3805.Rc_Qry3805_Get_Alan_Adi}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            DALUtil.rSetResults(rSet, VK_ALAN_TABLE, oMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}

	/** Tamamlanmis veri kontrol islemine ait kararlari getirir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param TRX_NO
	 * @return Alanlar, Alan Durumlari(0:Kontrol Etme/1:Kontrol Edilecek)
	 */
	@GraymoundService("BNSPR_TRN3805_GET_VERI_KONTROL_INFO")
	public static GMMap getVeriKontrolInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		String uygunStr = "_UYGUN";
		String uygunDegilStr = "_UYGUN_DEGIL";
		String eksikStr = "_EKSIK";
		String degerStr = "_DEGER";
		String aciklamaStr = "_ACIKLAMA";
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Bilgileri al.
			KartBasvuruVeriKntlTx kartBasvuruVeriKntlTx = (KartBasvuruVeriKntlTx)
					session.get(KartBasvuruVeriKntlTx.class, trxNo);
			if (kartBasvuruVeriKntlTx != null) {
				//BAsvuru no al
				oMap.put("BASVURU_NO", kartBasvuruVeriKntlTx.getBasvuruNo());
				
				//Save edilebilir tum alanlari al
				iMap.putAll(getVeriKontrolAlanAdi(iMap));
				
				//Alanlarin default ekran gosterimlerini al
				int row = 0;
				String alanKodu = null;
				while(iMap.getSize(VK_ALAN_TABLE) > row) {
					alanKodu = iMap.getString(VK_ALAN_TABLE, row, "ALAN_KODU");//Orn:FOTO
					oMap.put(alanKodu + degerStr, "");
					oMap.put(alanKodu + uygunStr, 0);
					oMap.put(alanKodu + uygunDegilStr, 0);
					oMap.put(alanKodu + eksikStr, 0);
					oMap.put(alanKodu + aciklamaStr, "");
					row++;
				}
				
				//Kontrol edilen alanlari al
				List<?> veriKontrolList = session.createCriteria(KartBasvuruVeriKntlDtyTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				//Kontrol edilen alanlari ekranda set et.
				for (Object object : veriKontrolList) {
					KartBasvuruVeriKntlDtyTx tx = (KartBasvuruVeriKntlDtyTx) object;
					
					oMap.put(tx.getId().getAlanKodu() + degerStr, tx.getDeger());
					oMap.put(tx.getId().getAlanKodu() + aciklamaStr, tx.getAciklama());
					if (UYGUN.equals(tx.getDurum())) {
						oMap.put(tx.getId().getAlanKodu() + uygunStr, 1);
						oMap.put(tx.getId().getAlanKodu() + uygunDegilStr, 0);
						oMap.put(tx.getId().getAlanKodu() + eksikStr, 0);
					} else if (UYGUN_DEGIL.equals(tx.getDurum())) {
						oMap.put(tx.getId().getAlanKodu() + uygunStr, 0);
						oMap.put(tx.getId().getAlanKodu() + uygunDegilStr, 1);
						oMap.put(tx.getId().getAlanKodu() + eksikStr, 0);
					} else if (EKSIK.equals(tx.getDurum())) {
						oMap.put(tx.getId().getAlanKodu() + uygunStr, 0);
						oMap.put(tx.getId().getAlanKodu() + uygunDegilStr, 0);
						oMap.put(tx.getId().getAlanKodu() + eksikStr, 1);
					} else {
						oMap.put(tx.getId().getAlanKodu() + uygunStr, 0);
						oMap.put(tx.getId().getAlanKodu() + uygunDegilStr, 0);
						oMap.put(tx.getId().getAlanKodu() + eksikStr, 0);
					}
				}
				
				//FOTOyu al
				iMap.put("FILE_PATH", oMap.get("FOTO_DEGER"));
				oMap.putAll(getBasvuruFoto(iMap));

				//Adres alanini parcala
				oMap.putAll(parseAdresToAlanlar(oMap.getString("ADRES1_DEGER"), "1", "/"));
				oMap.putAll(parseAdresToAlanlar(oMap.getString("ADRES2_DEGER"), "2", "/"));
				oMap.putAll(parseAdresToAlanlar(oMap.getString("ADRES3_DEGER"), "3", "/"));
				
				//Basvuru uzerinden yas ve cinsiyet degerlerini al
				oMap.putAll(getBasvuruIzlemeInfo(trxNo));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	private static GMMap getBasvuruIzlemeInfo(BigDecimal trxNo) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Sonuclari Al
			conn = DALUtil.getGMConnection();
			
            query = "{ call PKG_TRN3805.Rc_Qry3805_Get_Izleme_Info(?,?,?,?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, trxNo);
            stmt.registerOutParameter(2, Types.NUMERIC);
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.registerOutParameter(4, Types.VARCHAR);
            stmt.execute();
            
            oMap.put("YAS", stmt.getBigDecimal(2));
            oMap.put("CINSIYET", stmt.getString(3));
            oMap.put("TESLIMAT_ADRES_TIPI", stmt.getString(4));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}

	/** Veri kontrol sonuclarini kaydeder.
	 * Ekrandan gelen iMap parametre adlari veri kontrolu yapilacak alanlarin kodlari birbirine bagimlidir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - Veri Kontrol Bilgileri
	 * @return oMap - MESSAGE
	 */
	@GraymoundService("BNSPR_TRN3805_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartTipi = iMap.getString("KART_TIPI");
		String degerStr = "_DEGER";
		String durumStr = "_DURUM";
		String aciklamaStr = "_ACIKLAMA";
		
		try {
			//Musteri getir butonuna basildi mi?
			if (StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
				CreditCardServicesUtil.raiseGMError("1064");//Musteri seciniz.
			}
			
			//KK ise ESGM Sorgusu Yap, Yapilamazsa hata ver.
			if (iMap.getBoolean("ESGM_YAPILACAK_MI")) {
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi)) {
					iMap.put("CAPTCHA_DOGRULANSIN_MI", CreditCardServicesUtil.EVET);
					iMap.put("ESGM_SORGU_YAPILSIN_MI", CreditCardServicesUtil.HAYIR);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_ESGM_SORGU", iMap));
				} else if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(kartTipi)) {//KDH isteniyorsa
					iMap.put("CAPTCHA_DOGRULANSIN_MI", CreditCardServicesUtil.EVET);
					iMap.put("ESGM_SORGU_YAPILSIN_MI", CreditCardServicesUtil.EVET);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_ESGM_SORGU", iMap));
				}
				//Captcha sonuc kontrol
				if ("0".equals(oMap.getString("RESPONSE"))) {
					return oMap;
				}
			}
			
			//Kararlari Al.
			oMap.putAll(setVeriKontrolDurum(iMap));
			
			//Save edilebilir tum alanlari al
			oMap.putAll(getVeriKontrolAlanAdi(iMap));
			
			//Kararlara gore islemleri kaydet
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			
			//Detay tablosuna kontrol edilen alanlari kaydet
			int row = 0;
			String alanKodu = null;
			String deger = null;
			String durum = null;
			String aciklama = null;
			boolean isVeriTamamlandi = true;
			while(oMap.getSize(VK_ALAN_TABLE) > row) {
				alanKodu = oMap.getString(VK_ALAN_TABLE, row, "ALAN_KODU");//Orn:FOTO
				deger = iMap.getString(alanKodu + degerStr);//Ekrandan:FOTO_DEGER
				durum = oMap.getString(alanKodu + durumStr);//Ekrandan:FOTO_DURUM
				aciklama = iMap.getString(alanKodu + aciklamaStr);//Ekrandan:FOTO_ACIKLAMA
				
				//Durum secilmisse kaydet
				if (StringUtils.isNotBlank(durum)) {
					saveVeriKontrolDetay(txNo, alanKodu, deger, durum, aciklama);
				}
				
				//Durum foto degilse ve tum alanlar uygun degilse basvuru tamamlanmaz.
				if (!"FOTO".equals(alanKodu)) {
					if (isVeriTamamlandi && StringUtils.isNotBlank(durum) && !UYGUN.equals(durum)) {
						isVeriTamamlandi = false;
					}
				}
				
				row++;
			}
			
			BigDecimal tffBasvuruNo = basvuruNo;
			if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi)) {
				TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
						.add(Restrictions.eq("kkBasvuruNo", basvuruNo)).uniqueResult();
				if (tffBasvuru != null) {
					tffBasvuruNo = tffBasvuru.getBasvuruNo();
				}
			}
			
			//Islem durumu belirle
			durum = null;
			if (UYGUN.equals(oMap.getString("FOTO_DURUM"))) {
				if (isVeriTamamlandi) {
					durum = "T";//Islem Tamamlandi(T)
				} else {
					durum = "V";//Islem Veri Eksik(V)
				}
			} else {
				if (isVeriTamamlandi) {
					durum = "F";//Foto Eksik(F)
				} else {
					durum = "FV";//Foto Eksik + Veri Eksik(FV)
				}
				
				TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
						.add(Restrictions.eq("basvuruNo", tffBasvuruNo)).uniqueResult();
				tffBasvuru.setFotoDurum("E");
				session.save(tffBasvuru);
				//foto eksik icin event yaratilmasi
				if ("3825".equals(iMap.getString("EKRAN_KOD"))) {
					iMap.put("EVENT_TYPE_NO", FOTO_EKSIK_EVENT_TYPE_NO);
					iMap.put("EVENT_REF_NO", tffBasvuruNo);
					GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
				}
			}
			
			//Foto uygun olarak isaretlendi ise fotograf dizinini guncelle.
			if ("T".equals(durum) || "V".equals(durum)) {				
				GMMap tmpMap = new GMMap();
				tmpMap.put("TFF_BASVURU_NO", tffBasvuruNo);
				tmpMap = GMServiceExecuter.call("BNSPR_TFF_GISE_FOTO_GUNCELLE", tmpMap);
				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE"))) {
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", "Onayli foto guncellenemedi");
					logger.error("BASVURU NO:" + tffBasvuruNo +" Onayli foto guncellenemedi");
					return oMap;
				}
			}
			
			//Kaydet
			saveVeriKontrol(txNo, basvuruNo, durum, kartTipi, iMap.getString("EKRAN_KOD"));
			
			//Islemi tamamla
			session.flush();
			iMap.put("TRX_NAME", "3805");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			//Onay sonrasi servis bulunmaktadir.
			
			//Kredi karti basvurusunu tamamla. Bu islemde captcha ve guvenlik kodu parametre olarak pass
			//edildiginden after approval servisi icerisine tasinamadi.
			if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi) && "T".equals(durum)) {
				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", basvuruNo);
				sorguMap.put("KK_TRX_NO", GMServiceExecuter.executeNT("BNSPR_TRN3806_GET_KK_TRX_NO", sorguMap).get("KK_TRX_NO"));
				sorguMap.put("VERI_KONTROL_TRX_NO", txNo);
				sorguMap.put("CAPTCHA", iMap.get("CAPTCHA"));
				sorguMap.put("GUVENLIK_KODU", iMap.get("GUVENLIK_KODU"));
				GMServiceExecuter.execute("BNSPR_TRN3871_TFF_BASVURU_TAMAMLA", sorguMap);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Kredi karti istenilen TFF basvurularinda ESGM sorgusu yapar.
     *
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - BASVURU_NO, KART_TIPI, CAPTCHA, GUVENLIK_KODU, CAPTCHA_DOGRULANSIN_MI, ESGM_SORGU_YAPILSIN_MI
	 * @return oMap - RESPONSE, RESPONSE_DATA
	 */
	@GraymoundService("BNSPR_TRN3805_ESGM_SORGU")
	public static GMMap esgmSorgu(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Parametre kontrolu
			if (basvuruNo == null) {
				CreditCardServicesUtil.raiseGMError("330", "Ba�vuru No");
			}
			
			//Session al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Kart tipine gore kimlik bilgilerini al
			String tcKimlikNo = null;
			String ciltNo = null;
			String nufusIlKod = null;
			Date dogumTarihi = null;
			if (CreditCardTffServices.TFF_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
				KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik)
						session.get(KkBasvuruKimlik.class, basvuruNo);
				if (kkBasvuruKimlik != null) {
					tcKimlikNo = kkBasvuruKimlik.getTcKimlikNo();
					ciltNo = kkBasvuruKimlik.getCiltNo();
					nufusIlKod = kkBasvuruKimlik.getNufusIlKod();
					dogumTarihi = kkBasvuruKimlik.getDogumTar();
				}
			} else if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(iMap.getString("KART_TIPI"))) {
				TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik)
						session.get(TffBasvuruKimlik.class, basvuruNo);
				if (tffBasvuruKimlik != null) {
					tcKimlikNo = tffBasvuruKimlik.getTcKimlikNo();
					ciltNo = tffBasvuruKimlik.getCiltNo();
					nufusIlKod = tffBasvuruKimlik.getNufusIlKod();
					dogumTarihi = tffBasvuruKimlik.getDogumTar();
				}
			}

			//Kimlik bilgisi varsa esgm sorgu servisini calistir
			if(tcKimlikNo != null) {
				//Sorgula
				GMMap tMap = new GMMap();
				tMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
				tMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));
				tMap.put("TCKN", tcKimlikNo);
				tMap.put("IL_KODU", nufusIlKod);
				tMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(dogumTarihi));
				tMap.put("CILT_NO", ciltNo);
				tMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

				if (CreditCardServicesUtil.EVET.equals(iMap.getString("CAPTCHA_DOGRULANSIN_MI"))) {
					oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_SOLVE_CAPTCHA", tMap));
					//Sorgu Kontrol
					if ("0".equals(oMap.getString("RESPONSE"))) {
						oMap.put("RESPONSE", 0);
						oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));
						return oMap;
					}
				}
				
				//Response Parse
				if (CreditCardServicesUtil.EVET.equals(iMap.getString("ESGM_SORGU_YAPILSIN_MI"))) {
					ADCSession.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_PARSE", tMap);
					ADCSession.remove("BASVURU_NO");
				}
			}

			oMap.put("RESPONSE", 2);
			oMap.put("RESPONSE_DATA", "");

		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** Ekrandan yapilan kontrol sonuclarini istenilen duruma getirerek bu degerleri doner.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - Karari alinacak veri kontrol durumlari
	 * @return oMap - Kontrol sonuclari
	 */
	private static GMMap setVeriKontrolDurum(final GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Foto
		String fotoDurum = StringUtils.EMPTY;
		if (iMap.getBoolean("FOTO_UYGUN")) {
			fotoDurum = UYGUN;
		} else if (iMap.getBoolean("FOTO_UYGUN_DEGIL")) {
			fotoDurum = UYGUN_DEGIL;
		} else if (iMap.getBoolean("FOTO_EKSIK")) {
			fotoDurum = EKSIK;
		}
		
		
		
		//Adres3
		String adres3Durum = StringUtils.EMPTY;
		if (iMap.getBoolean("ADRES3_UYGUN")) {
			adres3Durum = UYGUN;
		} else if (iMap.getBoolean("ADRES3_UYGUN_DEGIL")) {
			adres3Durum = UYGUN_DEGIL;
		} else if (iMap.getBoolean("ADRES3_EKSIK")) {
			adres3Durum = EKSIK;
		}

		
		
		//Sonuclari Al
		oMap.put("FOTO_DURUM", fotoDurum);
	
		oMap.put("ADRES3_DURUM", adres3Durum);
		
		return oMap;
	}
	
	/** Veri kontrol sonuc bilgisini kaydeder.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param txNo - Veri kontrol islem numarasi
	 * @param basvuruNo - Kontrol edilen basvuru numarasi
	 * @param durum - Veri kontrol sonucu
	 * @param kartTipi - Kontrol edilen basvuruya ait kart tipi
	 * @param islemYeri - Kontrol isleminin yapildigi islem kodu
	 * 
	 */
	private static void saveVeriKontrol(BigDecimal txNo, BigDecimal basvuruNo, String durum, String kartTipi, String islemYeri) {
		//Session ac
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		//Bilgileri islem tablosuna kaydet
		KartBasvuruVeriKntlTx tx = (KartBasvuruVeriKntlTx) session.get(KartBasvuruVeriKntlTx.class, txNo);
		if (tx == null) {
			tx = new KartBasvuruVeriKntlTx();
		}
		
		tx.setTxNo(txNo);
		tx.setBasvuruNo(basvuruNo);
		tx.setKartTipi(kartTipi);
		tx.setDurum(durum);
		tx.setIslemYeri(islemYeri);
		
		session.saveOrUpdate(tx);
	}
	
	/** Veri kontrolu yapilan alan bilgisini kaydeder.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param txNo - Veri kontrol islem numarasi
	 * @param alanKodu - Kontrol edilen alan
	 * @param deger - Kontrol edilen deger
	 * @param durum - Kontrol sonucu
	 */
	public static void saveVeriKontrolDetay(BigDecimal txNo, String alanKodu, String deger,
			String durum, String aciklama) {
		//Session ac
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		
		KartBasvuruVeriKntlDtyTxId id = new KartBasvuruVeriKntlDtyTxId();
		id.setAlanKodu(alanKodu);
		id.setTxNo(txNo);

		//Bilgileri islem tablosuna kaydet
		KartBasvuruVeriKntlDtyTx tx = (KartBasvuruVeriKntlDtyTx) session.get(KartBasvuruVeriKntlDtyTx.class, id);
		if (tx == null) {
			tx = new KartBasvuruVeriKntlDtyTx();
		}
		
		tx.setId(id);
		tx.setDeger(CreditCardServicesUtil.trimNewLine(deger));
		tx.setDurum(durum);
		tx.setAciklama(aciklama);
		
		session.saveOrUpdate(tx);
	}
	
	//---------------------------------------------------------------------
	//******************************************************* ISLEM SONRASI SERVIS
	//---------------------------------------------------------------------
	/** TFF basvurusu veri kontrol islemi tamamlandiktan sonra kart basima gonderilir,
	 * musteri kaydi olusturulur ve musteriye bilgilendirme smsi gonderilir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param iMap - ISLEM_NO
	 * @return oMap
	 */
	@GraymoundService("BNSPR_TRN3805_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		TffBasvuru tffBasvuru = null;
		
		try {
			//Islem numarasi verilen basvurunun tahsis bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			KartBasvuruVeriKntlTx kartBasvuruVeriKntlTx = (KartBasvuruVeriKntlTx)
					session.get(KartBasvuruVeriKntlTx.class, iMap.getBigDecimal("ISLEM_NO"));
			if(kartBasvuruVeriKntlTx != null) {
				//Tff basvurusunu al
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
							.add(Restrictions.eq("kkBasvuruNo", kartBasvuruVeriKntlTx.getBasvuruNo()))
							.uniqueResult();
				} else {
					tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, kartBasvuruVeriKntlTx.getBasvuruNo());
				}
				//TFF basvurusu bulanamadi ise hata ver
				if (tffBasvuru == null) {
					CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
				}
				
				//Veri kontrol isleminde tum datalar uygunsa musteri bilgilerini guncelle
				if ("T".equals(kartBasvuruVeriKntlTx.getDurum())) {
					sorguMap.clear();
					sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					sorguMap.put("SOURCE", "TFF");
					GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap);
				}
				
				//Veri kontrol havuz guncellemesi yap. Foto eksik onayina dustu ise guncelle yoksa sil
				String kartTipiKey = "TFF_BASVURU_NO";
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					kartTipiKey = "KK_BASVURU_NO";
				}
//				if ("FOTO_EKSIK_ONAY".equals(tffBasvuru.getDurumKod())) {
//					sorguMap.clear();
//					sorguMap.put(kartTipiKey, kartBasvuruVeriKntlTx.getBasvuruNo());
//					sorguMap.put("ISLEM_KODU", "3825");
//					GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap);
//				} else {
//					sorguMap.clear();
//					sorguMap.put(kartTipiKey, kartBasvuruVeriKntlTx.getBasvuruNo());
//					GMServiceExecuter.execute("BNSPR_TRN3805_DELETE_HAVUZ", sorguMap);
//				}
				
				sorguMap.clear();
				sorguMap.put(kartTipiKey, kartBasvuruVeriKntlTx.getBasvuruNo());
				GMServiceExecuter.execute("BNSPR_TRN3805_DELETE_HAVUZ", sorguMap);
				
				
				//Basvuruyu basim olarak isaretle
				if (!CreditCardTffServices.TFF_KREDI_KARTI.equals(kartBasvuruVeriKntlTx.getKartTipi())) {
					if ("BASIM".equals(tffBasvuru.getDurumKod())) {
						iMap.put("BASVURU_NO", kartBasvuruVeriKntlTx.getBasvuruNo());
						iMap.put("ISLEM_NO", kartBasvuruVeriKntlTx.getTxNo());
						iMap.put("DURUM_KOD", "BASIM");
						iMap.put("KART_TIPI", kartBasvuruVeriKntlTx.getKartTipi());
						GMServiceExecuter.execute("BNSPR_KK_CALL_INTRACARD", iMap);
					}
				}
			}
			
			//CRM datasini besle
			try {
				iMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
				iMap.put("CRM_TYPE", CrmTypes.MAIN);
				GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM", iMap);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + iMap.containsKey("TFF_BASVURU_NO"));
			}
			
			//Veri kontrolde hatali data varsa basvuru sahibine sms at. Hata alirsa patlatmiyor.
			if ("3805".equals(kartBasvuruVeriKntlTx.getIslemYeri())) {
				logger.info("��lem yeri 3805 geldi.");
				logger.info("ba�vuru no " +kartBasvuruVeriKntlTx.getBasvuruNo());

				if ("V".equals(kartBasvuruVeriKntlTx.getDurum()) || "F".equals(kartBasvuruVeriKntlTx.getDurum())) {
					logger.info("durum kodu " +kartBasvuruVeriKntlTx.getDurum());
					logger.info("ba�vuru no " +kartBasvuruVeriKntlTx.getBasvuruNo());

					smsGonder(kartBasvuruVeriKntlTx.getTxNo());
				}
			} else {
				logger.info("��lem yeri 3805 gelmedi.");
				logger.info("ba�vuru no " +kartBasvuruVeriKntlTx.getBasvuruNo());

				if (!"T".equals(kartBasvuruVeriKntlTx.getDurum())) {
					smsGonder(kartBasvuruVeriKntlTx.getTxNo());
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CREATE_INTRACARD_CUSTOMER")
	public static GMMap createIntraCardCustomer(GMMap iMap)
	{
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		ResultSet 			rSet2 = null;
 		GMMap oMap = new GMMap();
		try {
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call PKG_TFF_BASVURU.Get_Customer_Info_For_Intra(?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(2);
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet2 = (ResultSet)stmt.getObject(3);
			iMap.putAll(DALUtil.rSetResults(rSet2, "ADRESS_LIST"));
			
			logger.debug("BNSPR_INTRACARD_CREATE_CUSTOMER INPUT : " + iMap.toString());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_CREATE_CUSTOMER", iMap));
			oMap.put("EMBOSS_NAME", iMap.getString("EMBOSS_NAME"));
			logger.debug("BNSPR_INTRACARD_CREATE_CUSTOMER OUTPUT : " + oMap.toString());
			
			if (("BASIM".equals(iMap.getString("DURUM_KOD")) || "KREDI_KARTI".equals(iMap.getString("DURUM_KOD")))
					&& !"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "TFF Intra Customer Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet2);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	@GraymoundService("BNSPR_CREATE_INTRACARD_CARD")
	public static GMMap createIntraCard(GMMap iMap)
	{
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap oMap = new GMMap();
		try {
			//BNSPR_OCEAN_CREATE_CARD
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Get_Card_Info_For_Intra(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			GMMap sorguMap = new GMMap();
			sorguMap.put("TFF_UYE_NO", iMap.getString("TFF_UYE_NO"));
			sorguMap.put("TARGET", "SS");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_APPROVED_PHOTO_PATH", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
				iMap.put("PHOTO_PATH", sorguMap.getString("TFF_APPROVED_IMAGE_PATH"));
			}
			
			logger.debug("BNSPR_INTRACARD_CREATE_CARD INPUT : " + iMap.toString());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_CREATE_CARD", iMap));
			oMap.put("PRODUCT_ID", iMap.getString("PRODUCT_ID"));
			logger.debug("BNSPR_INTRACARD_CREATE_CARD OUTPUT : " + oMap.toString());
			
			//vade yenilemeden geliyorsa kalan vade s�resi kadar uzat, eski vade tarihini al�p 1 sene ekliyoruz
			//Basvuruyu al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}
			else{
				if ("E".equals(tffBasvuru.getVdBasvuruMu())){
					GMMap visaMap = new GMMap();
					visaMap.put("KART_NO", oMap.getString("CARD_NO"));
					visaMap.put("VD_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				    GMServiceExecuter.executeAsync("BNSPR_SKT_ESKI_KART_VADESINI_EKLE" , visaMap);
				}
			}
			if (("BASIM".equals(iMap.getString("DURUM_KOD")) || "KREDI_KARTI".equals(iMap.getString("DURUM_KOD")))
					&& !"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "TFF Intra Card Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	@GraymoundService("BNSPR_KK_CALL_INTRACARD")
	public static GMMap callIntraCard(GMMap iMap) {
		GMMap oMap = new GMMap();
		String intraJob = "INTRA_JOB";
		String basim = "BASIM";
		String durumKod = "DURUM_KOD";
		String kartNo = null;
		String productId = null;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Basvuruyu al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			session.clear();
			TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
					.add(Restrictions.eq("kartTipi", iMap.getString("KART_TIPI")))
					.uniqueResult();
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}
			
			//Basilmis Karti var mi? Varsa duruma gore eski/mevcut basvuruyu iptal et.
			GMMap sorguMap = new GMMap();
			sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
			sorguMap.put("MEVCUT_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.EVET);
			sorguMap.put("ONCEKI_IPTAL_EDILEBILIR_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM"))) {
				oMap.putAll(sorguMap);
				return oMap;
			}

			String custResult = null;
			String custResultDesc = null;
			String cardResult = null;
			String cardResultDesc = null;
			String cardResultError = null;
		
			//Musteri kaydini olustur.
			oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_INTRACARD_CUSTOMER", iMap));
			custResult = oMap.getString("ORESULT");
			custResultDesc = oMap.getString("RETURN_DESCRIPTION");
			
			//Musteri basarili bir sekilde olusturuldu ise karti olustur.
			if(CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
				//Debit kart olusturulmadan once musterinin hesabi yoksa yeni bir rezerv hesap acilir.
				if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(iMap.getString("KART_TIPI"))) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("HESAP_KAYDEDILSIN_MI", CreditCardServicesUtil.EVET);
					sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TFF_REZERV_HESAP_AL", sorguMap));
				}
				
				//Kart olustur
				oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_INTRACARD_CARD", iMap));
				cardResult = oMap.getString("ORESULT");
				cardResultDesc = oMap.getString("RETURN_DESCRIPTION");
				cardResultError = oMap.getString("ERROR_DETAIL");
				productId = oMap.getString("PRODUCT_ID");
				
				//Kart olusturulamadi ise
				if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
					//Tekrar kullan�ld� hatasi aldi ise basvuru no ile kart no bilgisini all ve devam et
					//Hata mesaji:ORESULT=SystemError, ERROR_DETAIL=System.Exception: Girilen ApplicationNo 
					//ve Customer bilgileriyle basvuru daha once yapilmistir.CardNo:  6711210163228796
					//if (cardResultError.indexOf("ApplicationNo") > 0 && cardResultError.indexOf("CardNo") > 0) {
					if (BnsprOceanCommonFunctions.convertNewReturnCodeToOld(IssuingExceptionApplicationNoUsedBefore).equals(oMap.getString("RETURN_CODE"))){
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_GET_KART_NO_BY_BASVURU_NO", sorguMap));
						//Kontrol
						if (StringUtils.isNotBlank(sorguMap.getString("KART_NO"))) {
							kartNo = sorguMap.getString("KART_NO");
						}
					}
					
					//Basimsa durumlari guncelle, intro_job dan geliyorsa sadece aciklamayi guncelle
					if (StringUtils.isBlank(kartNo)) {
						GMMap durumMap = new GMMap();
						durumMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
						durumMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
						durumMap.put(durumKod, intraJob);
						durumMap.put("ISLEM_ACIKLAMA", INTRA_JOB_HATA_MESAJ + cardResult + '-' + cardResultDesc);
						
						if ("KREDI_KARTI".equals(iMap.getString(durumKod))) {
							durumMap.put("TARIHCE_AKSIYON", "E");//Son Kaydin durumunu guncelle
						} else {
							durumMap.put("TARIHCE_AKSIYON", "G");//Son Kaydin durumunu guncelle
						}

						GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
						return oMap;
					}
				} else {
					kartNo = oMap.getString("CARD_LIST", 0, "CARD_NO");
					iMap.put("EVENT_TYPE_NO", KART_HOSGELDIN_EVENT_TYPE_NO);
					iMap.put("EVENT_REF_NO", iMap.getBigDecimal("BASVURU_NO"));
					GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
				}
			} else { //Hatali ise joba duser.
				//Basimsa tarihceyi guncelle, intro_job dan geliyorsa ayni kalacak
				GMMap durumMap = new GMMap();
				durumMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				durumMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
				durumMap.put(durumKod, intraJob);
				durumMap.put("ISLEM_ACIKLAMA", INTRA_JOB_HATA_MESAJ + custResult + '-' + custResultDesc);
				
				if ("KREDI_KARTI".equals(iMap.getString(durumKod))) {
					durumMap.put("TARIHCE_AKSIYON", "E");//Yeni kayit olustur
				} else {
					durumMap.put("TARIHCE_AKSIYON", "G");//Son Kaydin durumunu guncelle
				}
				
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
				return oMap;
			}
						
			// kart olusturuldu ise kart nosunu kk_basvuruya koy
			conn = DALUtil.getGMConnection();
			
			if (StringUtils.isBlank(kartNo)) {
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "KK Ocean Card Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", "Kart no olusturulamam�st�r.");
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			} else {
				query = "{ call PKG_TFF_BASVURU.update_tff_kart_info(?,?,?) }";
				stmt = conn.prepareCall(query);
				stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(2, kartNo);
				stmt.setString(3, productId);
				stmt.execute();
				GMServerDatasource.close(stmt);
			}
			
			//Basvuru durumu JOB ise durumu guncelle
			if (!basim.equals(iMap.getString(durumKod))) {
				GMMap durumMap = new GMMap();
				durumMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				durumMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
				durumMap.put(durumKod, basim);
				durumMap.put("ISLEM_ACIKLAMA", custResult + '-' + custResultDesc);
				durumMap.put("TARIHCE_AKSIYON", "E");//Yeni kayit ekle
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
			}
			
			//Belgeleri kaydet.
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BELGE_KAYIT", iMap));
			
			//KDH istemisse KDH sonuc bilgilendirmesi yap
			if (CreditCardServicesUtil.EVET.equals(tffBasvuru.getKdhIstiyorMu())) {
				//KKsi var mi, varsa kk basvurusundan kdh sonucunu al
				if (tffBasvuru.getKkBasvuruNo() != null) {
					//varsa kk basvurusunu al
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, tffBasvuru.getKkBasvuruNo());
					if (kkBasvuru != null) {
						//aksiyon almis ve iptal etmemisse(Red/Onay ise)
						//Onay mi
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_KDH_BASVURU_ONAYLANDI_MI", sorguMap));
						String onaylandimi = sorguMap.getString("ONAYLANDI_MI");
						//Red mi
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_KDH_BASVURU_RED_MI", sorguMap));
						String redMi = sorguMap.getString("RED_MI");
						//Kontrol - Onay veya redse
						if (CreditCardServicesUtil.EVET.equals(onaylandimi) || CreditCardServicesUtil.EVET.equals(redMi)) {
							//KDH sonuc bilgilendirmesi yap(SMS1)
							sorguMap.clear();
							sorguMap.put("EVENT_TYPE_NO", CreditCardServicesUtil.KDH_SONUC_EVENT_TYPE_NO);
							sorguMap.put("EVENT_REF_NO", "KK_" + kkBasvuru.getBasvuruNo());
							GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap);
						}
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** Verilen basvuru veya islem numarasina ait basvurunun durumunu verilen degerle gunceller.
	 * 
	 * @param iMap - BASVURU_NO, ISLEM_NO, DURUM_KOD
	 */
	@GraymoundService("BNSPR_TFF_DURUM_GUNCELLE")
	public static GMMap durumGuncelle(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			query = "{ call PKG_TFF_BASVURU.Durum_Guncelle (?,?,?,?,?,?,?) }";
			stmt = conn.prepareCall(query);

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KOD"));
			stmt.setString(i++, iMap.getString("AKSIYON_KOD"));
			stmt.setString(i++, iMap.getString("AKSIYON_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("ISLEM_ACIKLAMA"));
			stmt.setString(i++, iMap.getString("TARIHCE_AKSIYON"));
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		/*
		 * De�i�en kart durum bilgileri i�in netmeray� besleyen asenkron servis �a�r�s�
		 * 1601VD
		 * */
		GMServiceExecuter.executeAsync("BNSPR_PUSH_KART_DURUM_GUNCELLE_EVENT", iMap);
		return oMap;
	}
	//---------------------------------------------------------------------
	//******************************************************* VERI KONTROL HAVUZ
	//---------------------------------------------------------------------
	/** Veri kontrol durumuna gelen basvurular icin veri kontrol havuzuna kayit atilmasini/guncellenmesini saglar.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>KK_BASVURU_NO - Kk basvuru numarasi
	 *        <li>KART_TIPI - Kart tipi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>HATALI_MI - Veri kontrol havuzundaki kayi hatali mi? (H:Hayir|E:Evet)
	 *        <li>ISLEM_KODU - 3805:Veri Kontrol | 3825:Foto Eksik
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ")
	public static GMMap saveOrUpdateVeriKontrolHavuz(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al ve guncelle, yoksa yeni kayit olustur
			TffVeriKontrolHavuz tffVeriKontrolHavuz = null;
			if (StringUtils.isNotBlank(iMap.getString("TFF_BASVURU_NO"))) {
				tffVeriKontrolHavuz = (TffVeriKontrolHavuz)
						session.get(TffVeriKontrolHavuz.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffVeriKontrolHavuz == null) {
					tffVeriKontrolHavuz = (TffVeriKontrolHavuz) session.createCriteria(TffVeriKontrolHavuz.class)
							.add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("KK_BASVURU_NO")))
							.uniqueResult();
				}
			} else if (StringUtils.isNotBlank(iMap.getString("KK_BASVURU_NO"))) {
				tffVeriKontrolHavuz = (TffVeriKontrolHavuz) session.createCriteria(TffVeriKontrolHavuz.class)
						.add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("KK_BASVURU_NO")))
						.uniqueResult();
			}
			//Kontrol
			if (tffVeriKontrolHavuz == null) {
				tffVeriKontrolHavuz = new TffVeriKontrolHavuz();
				tffVeriKontrolHavuz.setTffBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
				tffVeriKontrolHavuz.setKkBasvuruNo(iMap.getBigDecimal("KK_BASVURU_NO"));
				tffVeriKontrolHavuz.setKartTipi(iMap.getString("KART_TIPI"));
				tffVeriKontrolHavuz.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				tffVeriKontrolHavuz.setHataliMi(CreditCardServicesUtil.nvl(iMap.getString("HATALI_MI"), CreditCardServicesUtil.HAYIR));
				tffVeriKontrolHavuz.setIslemKodu(CreditCardServicesUtil.nvl(iMap.getString("ISLEM_KODU"), "3805"));
				//Oncelik al
				BigDecimal oncelik = null;
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
					oncelik = BigDecimal.ONE;
				} else if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(iMap.getString("KART_TIPI"))) {
					oncelik = new BigDecimal("2");
				} else if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(iMap.getString("KART_TIPI"))) {
					oncelik = new BigDecimal("3");
				} else {
					oncelik = new BigDecimal("4");
				}
				tffVeriKontrolHavuz.setOncelik(oncelik);
			} else {
				tffVeriKontrolHavuz.setKkBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KK_BASVURU_NO"), tffVeriKontrolHavuz.getKkBasvuruNo()));
				tffVeriKontrolHavuz.setKartTipi(CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), tffVeriKontrolHavuz.getKartTipi()));
				tffVeriKontrolHavuz.setMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), tffVeriKontrolHavuz.getMusteriNo()));
				//Oncelik guncellenemez
				tffVeriKontrolHavuz.setLastUpdatedDate(Calendar.getInstance().getTime());
				tffVeriKontrolHavuz.setHataliMi(CreditCardServicesUtil.nvl(iMap.getString("HATALI_MI"), tffVeriKontrolHavuz.getHataliMi()));
				tffVeriKontrolHavuz.setIslemKodu(CreditCardServicesUtil.nvl(iMap.getString("ISLEM_KODU"), tffVeriKontrolHavuz.getIslemKodu()));
			}

			session.saveOrUpdate(tffVeriKontrolHavuz);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Veri kontrol havuzundan kayitlarin silinmesini saglar.<br>
	 * @param iMap - Basvuru bilgileri<br>
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>KK_BASVURU_NO - Kk basvuru numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3805_DELETE_HAVUZ")
	public static GMMap deleteVeriKontrolHavuz(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa isleme ait bilgileri al ve guncelle, yoksa yeni kayit olustur
			TffVeriKontrolHavuz tffVeriKontrolHavuz = null;
			if (StringUtils.isNotBlank(iMap.getString("TFF_BASVURU_NO"))) {
				tffVeriKontrolHavuz = (TffVeriKontrolHavuz)
						session.get(TffVeriKontrolHavuz.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffVeriKontrolHavuz != null) {
					session.delete(tffVeriKontrolHavuz);
					session.flush();
				} else {
					tffVeriKontrolHavuz = (TffVeriKontrolHavuz) session.createCriteria(TffVeriKontrolHavuz.class)
							.add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("KK_BASVURU_NO")))
							.uniqueResult();
					if (tffVeriKontrolHavuz != null) {
						session.delete(tffVeriKontrolHavuz);
						session.flush();
					}
				}
			} else if (StringUtils.isNotBlank(iMap.getString("KK_BASVURU_NO"))) {
				tffVeriKontrolHavuz = (TffVeriKontrolHavuz) session.createCriteria(TffVeriKontrolHavuz.class)
						.add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("KK_BASVURU_NO")))
						.uniqueResult();
				if (tffVeriKontrolHavuz != null) {
					session.delete(tffVeriKontrolHavuz);
					session.flush();
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	

	//---------------------------------------------------------------------
	//******************************************************* UTIL
	//---------------------------------------------------------------------
	/** Verilen adresi belirtilen ayraca gore parcalayarak il, ilce, acik adres alanlarini bulur.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param adres - Adres Bilgisi
	 * @param adresTipi - Adres Tipi
	 * @param ayrac - Adres icersinde kullanilan ayrac
	 * @return IL_DEGER, ILCE_DEGER, ACIK_ADRES_DEGER
	 */
	public static GMMap parseAdresToAlanlar(String adres, String adresTipi, String ayrac) {
		GMMap oMap = new GMMap();
		String degerStr = adresTipi + "_DEGER";
		
		if (StringUtils.isBlank(adres)) {
			oMap.put("IL" + degerStr, "");
			oMap.put("ILCE" + degerStr, "");
			oMap.put("ACIK_ADRES" + degerStr, "");
			
			return oMap;
		}
		
		//Parametreler dogru ise
		int fromIndex = 0;
		int toIndex = adres.indexOf(ayrac, fromIndex);
		oMap.put("IL" + degerStr, adres.substring(fromIndex, toIndex));
		
		fromIndex = toIndex + 1;
		toIndex =  adres.indexOf(ayrac, fromIndex);
		oMap.put("ILCE" + degerStr, adres.substring(fromIndex, toIndex));
		
		fromIndex = toIndex + 1;
		toIndex =  adres.length();
		oMap.put("ACIK_ADRES" + degerStr, adres.substring(fromIndex, toIndex));
		
		return oMap;
	}
	
	/** Verilen islem numarasina ait kontrol sonucu veri ve/veya foto tamamlanmamis ise sms gonderilir.
	 * 
	 * @author murat.el
	 * @since 26.11.2013
	 * @param veriKontrolIslemNo - Veri kontrol islem numarasi
	 * @return oMap
	 */
	private static GMMap smsGonder(BigDecimal veriKontrolIslemNo) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			
            query = "{call PKG_TRN3805.Sms_Bilgisi(?,?,?)}";
            stmt = conn.prepareCall(query);
            stmt.setBigDecimal(1, veriKontrolIslemNo);
            stmt.registerOutParameter(2, Types.VARCHAR);
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            //Bilgileri al
            String mesaj = stmt.getString(2);
            String cepNo = stmt.getString(3);
            
            //SMS gonder
            GMMap sorguMap = new GMMap();
            sorguMap.put("GIDEN_MESAJ", mesaj);
            sorguMap.put("CEP_NO", cepNo);
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", sorguMap));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SMS gonderilemedi VERI KONTROL ISLEM NO:" + veriKontrolIslemNo);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Bir musterinin verilen basvurusu ile verilen kart tipinde ayni urunde olan 
	 * baska basvurusu/karti var mi kontrolu yapilir. Baska basvurusu varsa 
	 * eski basvurular iptal edilir, mevcut basvuru ilerletilir.
	 * Mevcutta karti varsa mevcut basvuru iptal edilir, isleme devam edilmez.
	 * 
	 * @author murat.el
	 * @since PY-8682
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>KART_TIPI - Kontrol edilmek istenen kart tipi   
	 *        <li>MEVCUT_IPTAL_EDILEBILIR_MI - Bulunan sonuca gore mevcut basvuru iptal edilsin mi?(E:Evet|H:Hayir) 
	 *        <li>ONCEKI_IPTAL_EDILEBILIR_MI - Bulunan sonuca gore onceki basvurular iptal edilsin mi?(E:Evet|H:Hayir) 
	 * @return oMap - Islem sonucu<br>
	 *        <li>DEVAM - Mevcut basvuru gecerli mi (E:Evet|H:Hayir)
	 *        <li>MESSAGE - Mevcut basvuru iptal edilmisse gosterilecek mesaj
	 */
	@GraymoundService("BNSPR_TRN3805_BASIM_AYNI_URUN_KONTROL")
	public static GMMap basimAyniUrunKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("DEVAM", CreditCardServicesUtil.EVET);

		try {
			//Basvuruyu al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (tffBasvuru == null) {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}
			//Aktif basvurusu var mi
			sorguMap.clear();
			sorguMap.put("UYE_NO", tffBasvuru.getTffUyeNo());
			sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("KART_TIPI", CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), tffBasvuru.getKartTipi()));
			sorguMap.put("URUN", tffBasvuru.getUrun());
			sorguMap.put("URUN_TIPI", tffBasvuru.getUrunSahipKodu());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KART_TIPI_AKTIF_BASVURU_KONTROL", sorguMap));
			//Eski basvurusu varsa eski basvurusunu iptal et, yoksa aktif karti var mi diye bak
			if (sorguMap.getBoolean("BASVURU_VAR_MI")) {
				//Durumu IPTAL,RED,ACIK haric olan eski basvurularini al
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
				sorguMap.put("KART_TIPI", CreditCardServicesUtil.nvl(iMap.getString("KART_TIPI"), tffBasvuru.getKartTipi()));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_AYNI_URUN_BASVURU_LISTELE", sorguMap));
				//Kontrol- Eski basvuru varsa(Yukarida emin olundu ama hata olmamasi icin tekrar kontrol edildi)
				if (sorguMap.get("BASVURU_LIST") != null && sorguMap.getSize("BASVURU_LIST") > 0) {
					//Durumu basim olan basvurusu varsa, mevcut basvuruyu iptal et ve cik, yoksa eski basvuruyu iptal et
					GMMap iptalMap = new GMMap();
					for (int i = 0; i < sorguMap.getSize("BASVURU_LIST"); i++) {
						if ("BASIM".equals(sorguMap.get("BASVURU_LIST", i, "DURUM_KOD"))) {
							if (CreditCardServicesUtil.EVET.equals(iMap.getString("MEVCUT_IPTAL_EDILEBILIR_MI"))) {
								iptalMap.clear();
								iptalMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
								iptalMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
								iptalMap.put("ISLEM_KOD", "3805");
								iptalMap.put("GEREKCE_KOD", "4");//Otomatik Iptal
								iptalMap.put("ACIKLAMA", "Basim Sonrasi -- Debit ve Prepaid Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi!!!");
								iptalMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);
								iptalMap.put("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.EVET);
								oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", iptalMap));
							}
							oMap.put("DEVAM", CreditCardServicesUtil.HAYIR);
							break;
						} else {
							if (CreditCardServicesUtil.EVET.equals(iMap.getString("ONCEKI_IPTAL_EDILEBILIR_MI"))) {
								iptalMap.clear();
								iptalMap.put("BASVURU_NO", sorguMap.get("BASVURU_LIST", i, "BASVURU_NO"));
								iptalMap.put("ONCEKI_DURUM_KOD", sorguMap.get("BASVURU_LIST", i, "DURUM_KOD"));
								iptalMap.put("ISLEM_KOD", "3805");
								iptalMap.put("GEREKCE_KOD", "4");//Otomatik Iptal
								iptalMap.put("ACIKLAMA", "Basim Sonrasi -- Debit ve Prepaid Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi!!!");
								iptalMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR);
								iptalMap.put("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.EVET);
								iptalMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", iptalMap));
								logger.info("Iptal edilen basvuru no : " + sorguMap.get("BASVURU_LIST", i, "BASVURU_NO"));
							}
						}
					}
				}
			} else {
				sorguMap.clear();
				sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
				sorguMap.put("URUN_KODU", tffBasvuru.getUrun());
				sorguMap.put("URUN_SAHIP_KODU", tffBasvuru.getUrunSahipKodu());
				sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_KART_ALABILME_KONTROL", sorguMap));
				//Aktif karti varsa mevcut basvuruyu iptal et.
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("KART_VAR_MI"))) {
					if (!StringUtils.isEmpty(sorguMap.getString("BASVURU_NO")) && !(iMap.getString("BASVURU_NO").equals(sorguMap.getString("BASVURU_NO")))) {
						/* ayn� ba�vurudan kart olu�mu� ise (timeout vb) iptal etmeyip i�leme devam edelim*/
						if (CreditCardServicesUtil.EVET.equals(iMap.getString("MEVCUT_IPTAL_EDILEBILIR_MI"))) {
							sorguMap.clear();
							sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
							sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
							sorguMap.put("ISLEM_KOD", "3805");
							sorguMap.put("GEREKCE_KOD", "4");// Otomatik Iptal
							sorguMap.put("ACIKLAMA", "Basim Sonrasi -- Debit ve Prepaid Kart ya da Basvurusu Bulundugundan Basvuru Iptal Edildi!!!");
							sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);
							sorguMap.put("MUHASEBE_YAPILSIN_MI", CreditCardServicesUtil.EVET);
							oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
						}
						oMap.put("DEVAM", CreditCardServicesUtil.HAYIR);}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Bir musterinin verilen basvurusu ile ayni urune sahip basvurularini listeler.
	 * 
	 * @author murat.el
	 * @since PY-8682
	 * @param iMap - BASVURU_NO : Basvuru numarasi, KART_TIPI : Kontrol edilmek istenen kart tipi
	 * @return oMap - BASVURU_LIST : Ayni urune sahip basvuru listesi<br>
	 */
	@GraymoundService("BNSPR_TRN3805_AYNI_URUN_BASVURU_LISTELE")
	public static GMMap ayniUrunBasvuruListele(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_tff_basvuru.ayni_urun_basvuru_listele(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("KART_TIPI"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "BASVURU_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

}
