package tr.com.aktifbank.bnspr.creditcard.services;

import org.apache.commons.lang.StringUtils;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4426Services {

	private static String maskCardNumber(String cardNumber) {
		return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})","$1 **** **** $3");
	}

	@GraymoundService("BNSPR_TRN4426_GET_CARD_INFO")
	public static GMMap getTrnGetCardInfo(GMMap iMap) {
		GMMap cardMap = new GMMap();
		GMMap oMap = new GMMap();
		String cardGroup = "";
        String cardProductId = "";
        String system = "";
        boolean isNKolayKart = false;
        boolean isPassoligCard = false;
        boolean isOcean = false;
        boolean isUptKart = false;
        boolean isTroyKart = false;
        //-Hce
        boolean isVirtualPP = false;
        boolean isHceKart=false;
        boolean isHceKart_2=false;
        //-Hce
        boolean mchipCard=false;
		cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
		for (int i = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {

			if (!"B".equals(cardMap.getString("CARD_DETAIL_INFO", i, "SYSTEM"))) {
				cardMap.put("CARD_DETAIL_INFO", i, "MASKED_CARD_NO", maskCardNumber(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO")));
			} else {
				cardMap.put("CARD_DETAIL_INFO", i, "MASKED_CARD_NO", cardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO")); //BASVURU_NO
			}

            cardGroup = cardMap.getString("CARD_DETAIL_INFO" , i , "CARD_GROUP");
            cardProductId = cardMap.getString("CARD_DETAIL_INFO" , i , "PRODUCT_ID");
            system = cardMap.getString("CARD_DETAIL_INFO" , i , "SYSTEM");
            
            isOcean = "O".equals(system);
            isPassoligCard = "1".equals(cardGroup);
            isNKolayKart = KkProductsUtil.isNkolayDebitProduct(cardProductId, OceanConstants.MASTERCARD);//"905".equals(cardProductId) || "906".equals(cardProductId); 
            isUptKart = KkProductsUtil.isUptPpProduct(cardProductId);//"912".equals(cardProductId);
            isTroyKart = KkProductsUtil.isTroyDebitProduct(cardProductId); //"916".equals(cardProductId); 
            //-Hce
            isVirtualPP = KkProductsUtil.isVirtualProduct(cardProductId);// "914".equals(cardProductId);
            isHceKart= KkProductsUtil.isHceProduct(cardProductId, "ONLINE");//"920".equals(cardProductId);
            isHceKart_2= KkProductsUtil.isHceProduct(cardProductId,"OFFLINE");//"921".equals(cardProductId);
	        //-Hce
            mchipCard = KkProductsUtil.isMchipProduct(cardProductId);//CreditCardQRY4410Services.mchipFilter(cardMap, i, 0,"CARD_DETAIL_INFO", "PRODUCT_ID");
            if(isPassoligCard || isNKolayKart && !isUptKart && !isTroyKart && !isVirtualPP && !isHceKart && !isHceKart_2 && !mchipCard){
            	
            	oMap.put("CARD_DETAIL_INFO", oMap.getSize("CARD_DETAIL_INFO"), cardMap.getMap("CARD_DETAIL_INFO", i));
            }
		}
		return oMap;
	}
}
