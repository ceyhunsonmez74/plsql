package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TffBasOdemeTamamlaTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** Kredi karti limit guncelleme islemlerinin gerceklestirilmesini saglar.
 * @since PYKKBAS-242
 * @author murat.el
 * 
 */
public class CreditCardTRN3832Services {
		
	@GraymoundService("BNSPR_TRN3832_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Variables
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null) {
				trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
			}

			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			TffBasOdemeTamamlaTx tffBasOdemeTamamlaTx = (TffBasOdemeTamamlaTx) 
					session.get(TffBasOdemeTamamlaTx.class, trxNo);
			if (tffBasOdemeTamamlaTx == null) {
				tffBasOdemeTamamlaTx = new TffBasOdemeTamamlaTx();
				tffBasOdemeTamamlaTx.setTxNo(trxNo);
			}
			//Islem bilgilerini al.
			tffBasOdemeTamamlaTx.setOdemeTxNo(iMap.getBigDecimal("ODEME_TX_NO"));
			tffBasOdemeTamamlaTx.setOdemeRefId(iMap.getString("ODEME_REF_ID"));
			tffBasOdemeTamamlaTx.setAciklama(iMap.getString("ACIKLAMA"));

			//Islem bilgilerini kaydet
			session.save(tffBasOdemeTamamlaTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3832");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	

	@GraymoundService("BNSPR_TRN3832_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al
			TffBasOdemeTamamlaTx tffBasOdemeTamamlaTx = (TffBasOdemeTamamlaTx) 
					session.get(TffBasOdemeTamamlaTx.class, trxNo);
			if (tffBasOdemeTamamlaTx != null) {			
				//Degerleri al
				oMap.put("ODEME_TX_NO", tffBasOdemeTamamlaTx.getOdemeTxNo());
				oMap.put("ODEME_REF_ID", tffBasOdemeTamamlaTx.getOdemeRefId());
				oMap.put("ACIKLAMA", tffBasOdemeTamamlaTx.getAciklama());
			} else {
				oMap.put("ODEME_TX_NO", StringUtils.EMPTY);
				oMap.put("ODEME_REF_ID", StringUtils.EMPTY);
				oMap.put("ACIKLAMA", StringUtils.EMPTY);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	

	@GraymoundService("BNSPR_TRN3832_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasOdemeTamamlaTx tffBasOdemeTamamlaTx = (TffBasOdemeTamamlaTx)
					session.get(TffBasOdemeTamamlaTx.class, iMap.getBigDecimal("ISLEM_NO"));
			if (tffBasOdemeTamamlaTx != null) {
				GMMap tMap = new GMMap();
				
				tMap.put("ISLEM_NO", tffBasOdemeTamamlaTx.getOdemeTxNo());
				TffBasvuruOdemeTx tffBasvuruOdemeTx = (TffBasvuruOdemeTx) session.get(TffBasvuruOdemeTx.class, tffBasOdemeTamamlaTx.getOdemeTxNo());
				tMap.put("BASVURU_NO", tffBasvuruOdemeTx.getBasvuruNo());
				tMap.put("ODEME_REF_ID", tffBasOdemeTamamlaTx.getOdemeRefId());
				
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3802_TFF_BASVURU_ODEME_GUNCELLE", tMap));
			}	

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

		
}
