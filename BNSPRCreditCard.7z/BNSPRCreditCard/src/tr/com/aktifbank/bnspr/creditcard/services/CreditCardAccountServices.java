package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruHesap;
import tr.com.aktifbank.bnspr.dao.KkBasvuruHesapId;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezerv;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezervId;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruHesap;
import tr.com.aktifbank.bnspr.dao.TffBasvuruHesapId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


/** Kart hesap acilis/kontrol islemleri
 * @author murat.el
 * @since BT-7181
 */
public class CreditCardAccountServices {
	
	/** Ocean debit/kredi karti veya Tff kredi karti basvurusu yapan musterinin 
	 * kart icin kullanilacak hesap bilgisini bulur ve bunu istenirse tabloya kullanmak uzere kaydeder.<br>
	 * 
	 * <br>Hesap bulma algoritmasi:<br>
	 * Mevcutta ptt icin kullanilmayan ve cati hesabi olamayan bir vadesiz hesabi arar, varsa kullanir,
	 * yoksa ptt icin kullanilmayacak olan rezerv hesap arar, varsa kullanir,
	 * yoksa yeni bir rezerv hesap acar.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru no
	 *        <li>HESAP_KAYDEDILSIN_MI - Yeni hesap acilacaksa kaydedilsin mi(E:Evet|H:Hayir)
	 * @return oMap - Islem sonuc bilgileri<br>
	 * 		  <li>HESAP_NO - Hesap numarasi
	 *        <li>RESPONSE_DATA - Islem detayi
	 */
	@GraymoundService("BNSPR_KK_REZERV_HESAP_AL")
	public static GMMap createMuhHesapRezervKK(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal hesapNo = null;
		
		try {
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
				oMap.put("RESPONSE_DATA", "Basvuru no bos");
				return oMap;
			}
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			//Basvuruyu al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
			if (kkBasvuru == null) {
				oMap.put("RESPONSE_DATA", "Basvuru bulunamadi");
				return oMap;
			}
			
			//Basvuruda musteri numarasi var mi
			if (kkBasvuru.getMusteriNo() == null || BigDecimal.ZERO.compareTo(kkBasvuru.getMusteriNo()) >= 0) {
				oMap.put("RESPONSE_DATA", "Musteri nuamrasi gecersiz");
				return oMap;
			}
			
			//Hesap bilgisini al
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
			sorguMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_REZERV_HESAP_AL", sorguMap));
			hesapNo = sorguMap.getBigDecimal("HESAP_NO");
				
			//Hesap tablosuna kaydet.
			String hesapKaydedilsinMi = CreditCardServicesUtil.nvl(iMap.getString("HESAP_KAYDEDILSIN_MI"), CreditCardServicesUtil.HAYIR);
			if (CreditCardServicesUtil.EVET.equals(hesapKaydedilsinMi) && hesapNo != null && BigDecimal.ZERO.compareTo(hesapNo) < 0) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", basvuruNo);
				sorguMap.put("HESAP_NO", hesapNo);
				sorguMap.put("HESAP_TIPI", "V");
				GMServiceExecuter.execute("BNSPR_SAVE_KK_BASVURU_HESAP", sorguMap);//BASVURU_NO,HESAP_NO,HESAP_TIPI
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("HESAP_NO", hesapNo);
		return oMap;
	}
	
	/** Tff debit basvurusu yapan musterinin kart icin kullanilacak hesap bilgisini bulur 
	 * ve bunu istenirse tabloya kullanmak uzere kaydeder.<br>
	 * 
	 * <br>Hesap bulma algoritmasi:<br>
	 * Mevcutta ptt icin kullanilmayan ve cati hesabi olamayan bir vadesiz hesabi arar, varsa kullanir,
	 * yoksa ptt icin kullanilmayacak olan rezerv hesap arar, varsa kullanir,
	 * yoksa yeni bir rezerv hesap acar.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Kredi karti basvuru no
	 *        <li>HESAP_KAYDEDILSIN_MI - Yeni hesap acilacaksa kaydedilsin mi(E:Evet|H:Hayir)
	 * @return oMap - Islem sonuc bilgileri<br>
	 * 		  <li>HESAP_NO - Hesap numarasi
	 *        <li>RESPONSE_DATA - Islem detayi
	 */
	@GraymoundService("BNSPR_TFF_REZERV_HESAP_AL")
	public static GMMap createMuhHesapRezervTFF(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal hesapNo = null;
		
		try {
			//Parametre Kontrol
			if (StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
				oMap.put("RESPONSE_DATA", "Basvuru no bos");
				return oMap;
			}
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			//Basvuruyu al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			if (tffBasvuru == null) {
				oMap.put("RESPONSE_DATA", "Basvuru bulunamadi");
				return oMap;
			}
			
			//Basvuruda musteri numarasi var mi
			if (tffBasvuru.getMusteriNo() == null || BigDecimal.ZERO.compareTo(tffBasvuru.getMusteriNo()) >= 0) {
				oMap.put("RESPONSE_DATA", "Musteri nuamrasi gecersiz");
				return oMap;
			}
			
			//Hesap bilgisini al
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_REZERV_HESAP_AL", sorguMap));
			hesapNo = sorguMap.getBigDecimal("HESAP_NO");
				
			//Hesap tablosuna kaydet.
			String hesapKaydedilsinMi = CreditCardServicesUtil.nvl(iMap.getString("HESAP_KAYDEDILSIN_MI"), CreditCardServicesUtil.HAYIR);
			if (CreditCardServicesUtil.EVET.equals(hesapKaydedilsinMi) && hesapNo != null && BigDecimal.ZERO.compareTo(hesapNo) < 0) {
				sorguMap.clear();
				sorguMap.put("BASVURU_NO", basvuruNo);
				sorguMap.put("HESAP_NO", hesapNo);
				sorguMap.put("HESAP_TIPI", "V");
				GMServiceExecuter.execute("BNSPR_SAVE_TFF_BASVURU_HESAP", sorguMap);//BASVURU_NO,HESAP_NO,HESAP_TIPI
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("HESAP_NO", hesapNo);
		return oMap;
	}
	
	/** Mevcutta ptt icin kullanilmayan ve cati hesabi olamayan bir vadesiz hesabi arar, varsa kullanir,
	 * yoksa ptt icin kullanilmayacak olan rezerv hesap arar, varsa kullanir,
	 * yoksa yeni bir rezerv hesap acar.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru no
	 *        <li>MUSTERI_NO - Musteri no
	 * @return oMap - Islem sonuc bilgileri<br>
	 * 		  <li>HESAP_NO - Hesap numarasi
	 *        <li>RESPONSE_DATA - Islem detayi
	 */
	@GraymoundService("BNSPR_CREDITCARD_REZERV_HESAP_AL")
	public static GMMap createMuhHesapRezerv(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal hesapNo = null;
		
		try {
			//Parametre Kontrol - Basvuru No
			if (StringUtils.isBlank(iMap.getString("BASVURU_NO"))) {
				oMap.put("RESPONSE_DATA", "Basvuru no bos");
				return oMap;
			}
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			
			//Parametre Kontrol - Musteri No
			if (StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
				oMap.put("RESPONSE_DATA", "Musteri no bos");
				return oMap;
			}
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			
			//Alinan musteri numarasinin vadesiz hesabi var mi? Varsa hesap numarasini al.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", basvuruNo);
			sorguMap.put("MUSTERI_NO", musteriNo);
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_KOD", sorguMap));//PORTFOY_KOD
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD", sorguMap));//PORTFOY_SUBE_KOD
			sorguMap.put("SUBE_KODU", sorguMap.getString("PORTFOY_SUBE_KOD"));
			sorguMap.putAll(vadesizHesapVarMi(sorguMap));
			
			//vadesiz hesabi varsa kullan
			if (sorguMap.getBigDecimal("HESAP_NO") != null && BigDecimal.ZERO.compareTo(sorguMap.getBigDecimal("HESAP_NO")) != 0) {
				hesapNo = sorguMap.getBigDecimal("HESAP_NO");
			} else {
				//Alinan musteri numarasinin gecerli rezerv hesabi var mi? Varsa kullan 
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				List<?> muhHesapRezervList = session.createCriteria(MuhHesapRezerv.class)
						.add(Restrictions.eq("id.musteriNo", musteriNo))
						.add(Restrictions.eq("durumKodu", "A"))
						.list();
				MuhHesapRezerv muhHesapRezerv = null;
				for (Object o : muhHesapRezervList) {
					muhHesapRezerv = (MuhHesapRezerv) o;
					//Basvuru numarasi yoksa kullan ve isaretle
					if (muhHesapRezerv.getBasvuruNo() == null) {
						muhHesapRezerv.setBasvuruNo(basvuruNo);
						session.saveOrUpdate(muhHesapRezerv);
						session.flush();
						
						hesapNo = muhHesapRezerv.getId().getHesapNo();
						break;
					//Basvuru numarasi varsa kullanilabilir mi?
					} else {
						//Bireysel Kredi Ptt musterilerine hesap acilamasin isteniyor
						BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, muhHesapRezerv.getBasvuruNo());
						if (birBasvuru != null && birBasvuru.getMusteriNo() != null && birBasvuru.getMusteriNo().compareTo(musteriNo) == 0) {
							if ("7".equals(birBasvuru.getKanalKodu()) || "E".equals(birBasvuru.getPttEmekliPttBildir())) {
								continue;
							} else {
								hesapNo = muhHesapRezerv.getId().getHesapNo();
								break;
							}
						} else {
							hesapNo = muhHesapRezerv.getId().getHesapNo();
							break;
						}
					}
				}
				
				//Hesap bulunamadi ise rezerv hesap olustur
				if (hesapNo == null) {
					sorguMap.clear();
					sorguMap.put("TABLE_NAME", "HESAP.VDSZ");
					sorguMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap));
					MuhHesapRezervId muhHesapRezervId = new MuhHesapRezervId();
					muhHesapRezervId.setHesapNo(sorguMap.getBigDecimal("ID"));
					muhHesapRezervId.setMusteriNo(musteriNo);
					
					sorguMap.clear();
					sorguMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_LOCAL_CUR", sorguMap));
					muhHesapRezerv = new MuhHesapRezerv();
					muhHesapRezerv.setId(muhHesapRezervId);
					muhHesapRezerv.setDovizKodu(sorguMap.getString("DOVIZ_KODU"));
					muhHesapRezerv.setDurumKodu("A");
					muhHesapRezerv.setIban(getIbanNo(muhHesapRezervId.getHesapNo()));
					muhHesapRezerv.setAciklama("Kart basim oncesi rezerve");
					muhHesapRezerv.setBasvuruNo(basvuruNo);
					
					session.save(muhHesapRezerv);
					session.flush();
					
					hesapNo = muhHesapRezerv.getId().getHesapNo();
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.put("HESAP_NO", hesapNo);
		return oMap;
	}
	
	/** Istenilen musteri ve sube icin mevcutta ptt icin kullanilmayan veya 
	 * cati hesabi olamayan bir vadesiz hesabi var mi? Varsa hesap numarasini doner.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>SUBE_KODU - Sube Kodu
	 *        <li>MUSTERI_NO - Musteri no
	 * @return oMap - Islem sonuc bilgileri<br>
	 * 		  <li>HESAP_NO - Hesap numarasi
	 *        <li>RESPONSE_DATA - Islem detayi
	 */
	@GraymoundService("BNSPR_CREDITCARD_VADESIZ_HESAP_VAR_MI")
	public static GMMap vadesizHesapVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TFF_BASVURU.VadesizHesapNo(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("SUBE_KODU"));
			stmt.setString(4, "TRY");
			stmt.execute();

			oMap.put("HESAP_NO", stmt.getBigDecimal(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** Hesap numarasina ait IBAN bilgisini bulur.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param hesapNo - Hesap numarasi
	 * @return IBAN bilgisi
	 */
	private static String getIbanNo(BigDecimal hesapNo) {
		String iban = null;
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call Pkg_Iban.sp_IBAN_al(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, hesapNo);
			stmt.execute();
			
			iban = stmt.getString(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return iban;
	}
	
	/** TFF Kredi karti veya Banka KrediKarti/Debit karti icin kullanilacak hesap bilgisini basvuru uzerine kaydeder.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru no
	 *        <li>HESAP_NO - Hesap no
	 *        <li>HESAP_TIPI - Hesap tipi(V:Vadesiz|F:Fon)
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_SAVE_KK_BASVURU_HESAP")
	public static GMMap saveKkBasvuruHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			KkBasvuruHesapId id = new KkBasvuruHesapId();
			id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			id.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			id.setHesapTipi(iMap.getString("HESAP_TIPI"));
			
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuruHesap kkBasvuruHesap = (KkBasvuruHesap) session.get(KkBasvuruHesap.class, id);
			if (kkBasvuruHesap == null) {
				kkBasvuruHesap = new KkBasvuruHesap();
			}
			
			kkBasvuruHesap.setId(id);
			
			session.saveOrUpdate(kkBasvuruHesap);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** TFF Debit karti icin kullanilacak hesap bilgisini basvuru uzerine kaydeder.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru no
	 *        <li>HESAP_NO - Hesap no
	 *        <li>HESAP_TIPI - Hesap tipi(V:Vadesiz|F:Fon)
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_SAVE_TFF_BASVURU_HESAP")
	public static GMMap saveTffBasvuruHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			TffBasvuruHesapId id = new TffBasvuruHesapId();
			id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			id.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			id.setHesapTipi(iMap.getString("HESAP_TIPI"));
			
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruHesap tffBasvuruHesap = (TffBasvuruHesap) session.get(TffBasvuruHesap.class, id);
			if (tffBasvuruHesap == null) {
				tffBasvuruHesap = new TffBasvuruHesap();
			}
			
			tffBasvuruHesap.setId(id);
			
			session.saveOrUpdate(tffBasvuruHesap);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Kart basvurulari icin vadesiz hesap acilis islemini gerceklestirir.<br>
	 * Islemi detayi:<br>
	 * Rezerv hesap tablosunda basvuru uzerine kaydedilen hesap var mi kontrolu yapilir,
	 * yoksa vadesiz hesabi vardir kabulu ile hareket edilir ve hesap acilmadan basvuru uzerindeki hesap bilgileri donulur,
	 * varsa rezerv hesap bilgisi ile vadesiz hesap acilir.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>MUSTERI_NO - Musteri no
	 *        <li>SUBE_KODU - Sube kodu
	 *        <li>BASVURU_HESAP_NO - Basvuru uzerine kaydedilen daha onceden kart tarafina bildirilen hesap no
	 * @return oMap - Hesap bilgileri<br>
	 * 		  <li>HESAP_NO - Vadesiz hesap no
	 *        <li>HESAP_TIPI - Hesap tipi
	 *        <li>VH_MESSAGE - Islem sonuc mesaji
	 *        <li>HESAP_VAR_MI_HESAP_NO - Vadesiz hesap sorgu sonucu
	 */
	@GraymoundService("BNSPR_CREDITCARD_VADESIZ_HESAP_AC")
	public static GMMap vadesizHesapAc(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		//Olusturulan hesap bilgilerini geri don.
		BigDecimal hesapNo = null;
		
		try {
			//Kart tarafina verilen hesap numarasi alinacagindan once muhhesaprezerve bakilir
			//Rezerv hesap bilgisi varsa al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Alinan musteri numarasinin gecerli rezerv hesabi var mi? Varsa kullan 
			List<?> muhHesapRezervList = session.createCriteria(MuhHesapRezerv.class)
					.add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO")))
					.add(Restrictions.eq("durumKodu", "A"))
					.list();
			MuhHesapRezerv muhHesapRezerv = null;
			for (Object o : muhHesapRezervList) {
				muhHesapRezerv = (MuhHesapRezerv) o;
				//Hesabi buldu isek kullan
				if (muhHesapRezerv.getId().getHesapNo().compareTo(iMap.getBigDecimal("BASVURU_HESAP_NO")) == 0) {
					hesapNo = muhHesapRezerv.getId().getHesapNo();
					break;
				}
			}
			
			//Rezervde kaydi varsa hesap acilir, yoksa zaten vadesiz hesabi vardir ya da cevrilmistir.
			if (hesapNo == null) {
				oMap.put("HESAP_VAR_MI_HESAP_NO", vadesizHesapVarMi(iMap).get("HESAP_NO"));
				oMap.put("HESAP_NO", iMap.get("BASVURU_HESAP_NO"));
				oMap.put("HESAP_TIPI", "V");
			} else {
				//rezerv hesabi varsa vadesiz hesap yap
				conn = DALUtil.getGMConnection();
				
				query = "{ call pkg_hesap.vadesiz_hesap_acilis(?,?,?,?,?,?,?,?) }";
				stmt = conn.prepareCall(query);
	  			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
				stmt.setString(2, "VADESIZ");
				stmt.setString(3, "MUSTAK-TP");
				stmt.setString(4, "SABIT FAIZ");
				stmt.setString(5, iMap.getString("SUBE_KODU"));
				stmt.setString(6, "TRY");
				stmt.setString(7, null);
				stmt.setBigDecimal(8, hesapNo);
				stmt.registerOutParameter(8, Types.NUMERIC);
				stmt.execute();
				
			    oMap.put("HESAP_NO", hesapNo);
			    oMap.put("HESAP_TIPI", "V");
			}

			iMap.put("MESSAGE_NO", new BigDecimal(1754));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("P2", hesapNo);
			oMap.put("VH_MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/**  KKART FON hesabi acar.
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>MUSTERI_NO - Musteri no
	 *        <li>SUBE_KODU - Sube kodu
	 * @return oMap - Hesap bilgileri<br>
	 * 		  <li>HESAP_NO - Fon hesap no
	 *        <li>HESAP_TIPI - Hesap tipi
	 *        <li>VH_MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_CREDITCARD_FON_HESAP_AC")
	public static GMMap fonHesapAc(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ call pkg_hesap.vadesiz_hesap_acilis(?,?,?,?,?,?,?,?) }";
			stmt = conn.prepareCall(query);
  			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(2, "VADESIZ");
			stmt.setString(3, "MUSTAK-TP");
			stmt.setString(4, "KKART FON");
			stmt.setString(5, iMap.getString("SUBE_KODU"));
			stmt.setString(6, "TRY");
			stmt.setString(7, null);
			stmt.setBigDecimal(8, null);
			stmt.registerOutParameter(8, Types.NUMERIC);
			stmt.execute();
			
			BigDecimal hesapNo = stmt.getBigDecimal(8);
			oMap.put("HESAP_NO", hesapNo);
		    oMap.put("HESAP_TIPI", "F");
			
			iMap.put("MESSAGE_NO", new BigDecimal(1754));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("P2", hesapNo);
			oMap.put("VF_MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** Verilen hesaba cati ozelligi ekler, hesap yoksa cati ozellikli yeni bir hesap acar. 
	 * 
	 * @author murat.el
	 * @since BT-7181
	 * @param iMap - Islem bilgileri<br>
	 *        <li>MUSTERI_NO - Musteri no
	 *        <li>SUBE_KODU - Sube kodu
	 *        <li>HESAP_NO - Vadesiz hesap no
	 * @return oMap - Hesap bilgileri<br>
	 * 		  <li>HESAP_NO - Cati hesap no
	 *        <li>HESAP_TIPI - Hesap tipi
	 *        <li>VH_MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_CREDITCARD_CATI_HESAP_AC")
	public static GMMap catiHesapAc(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call pkg_card.cati_hesap_tanim(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
  			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("SUBE_KODU"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("HESAP_NO"));
			stmt.execute();
			
			BigDecimal hesapNo = stmt.getBigDecimal(1);
			oMap.put("HESAP_NO", hesapNo);
		    oMap.put("HESAP_TIPI", "C");
			
			iMap.put("MESSAGE_NO", new BigDecimal(1754));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("P2", hesapNo);
			oMap.put("VC_MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

}
