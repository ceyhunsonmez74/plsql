package tr.com.aktifbank.bnspr.creditcard.services;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaPpKkiadeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4487Services implements OceanMapKeys{
	
	@GraymoundService("BNSPR_TRN4487_GET_CARD_LIST")
	public static GMMap getCardList (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap cMap = new GMMap();
			GMMap lMap = new GMMap();
			cMap.put(INPUT_PARAMETER_TYPE, "CST");
			cMap.put(CUSTOMER_NO, iMap.getBigDecimal("MUST_NO"));
			cMap.put("NO_NEED_APPLICATIONS", true);
			cMap.put("CARD_BANK_STATUS_CC", iMap.getString("STATUS"));
			cMap.put("PROCEED", "INCLUDE");
			String cardNo =StringUtil.isEmpty(iMap.getString("CARD_NO"))?"":iMap.getString("CARD_NO");
			lMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", cMap);
			int j=0;
			int s = lMap.getSize("CARD_DETAIL_INFO"); 
			for (int i = 0; i < s; i++) {
				String dci = lMap.getString("CARD_DETAIL_INFO",i,"CARD_DCI_AKUSTIK");
				if (!dci.equals("D") && !cardNo.equals(lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"))){
				oMap.put("TABLO",j, "CARD_NO",lMap.getString("CARD_DETAIL_INFO",i,"CARD_NO"));
				oMap.put("TABLO",j, "CUSTOMER_NO",lMap.getBigDecimal("CARD_DETAIL_INFO",i,"CUSTOMER_NO"));
				oMap.put("TABLO",j, "CARD_DCI",dci);
				oMap.put("TABLO",j, "CARD_STAT_DESC",lMap.getString("CARD_DETAIL_INFO",i,"CARD_STAT_DESC"));
				oMap.put("TABLO",j, "CARD_EMBOSS_NAME",lMap.getString("CARD_DETAIL_INFO",i,"CARD_EMBOSS_NAME_1"));
				j=j+1;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4487_SAVE")
	public static GMMap save(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaPpKkiadeTx sbaPpKkiadeTx = new SbaPpKkiadeTx();
			sbaPpKkiadeTx.setAciklama(iMap.getString("ACIKLAMA"));
			String aliciHesapNo;
			GMMap cProperty = new GMMap();
			cProperty.put("CARD_NO", iMap.getString("KART_NO"));
			cProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cProperty);
			String kartDci = cProperty.getString("DCI");
			String dest = cProperty.getString("DESTINATION");

			if (iMap.getBoolean("EFT")){
				aliciHesapNo =getGlobalParam("4487_EFT_HESABI"); 
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("VS");
				sbaPpKkiadeTx.setAliciHesapSube(getHesapSubeKod(aliciHesapNo));
				sbaPpKkiadeTx.setIslem("EFT");
				sbaPpKkiadeTx.setAliciAdSoyad(iMap.getString("ALICI_AD_SOYAD"));
			}else if(iMap.getBoolean("HESABA")){
				aliciHesapNo =iMap.getString("HESAP_NO");
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("VS");
				sbaPpKkiadeTx.setAliciHesapSube(getHesapSubeKod(aliciHesapNo));
				sbaPpKkiadeTx.setIslem("HESABA");
			}else if(iMap.getBoolean("KARTA")){
				GMMap cardProperty = new GMMap();
				cardProperty.put("CARD_NO", iMap.getString("ALICI_KART_NO"));
				cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cardProperty);
				if(cardProperty.getString("DCI").equals("C")){
					aliciHesapNo =getGlobalParam("KK_FINANSAL_BAKIM_HESAP");
					sbaPpKkiadeTx.setAliciHesapSube("998");
				}else if(cardProperty.getString("DESTINATION").equals("O") && cardProperty.getString("DCI").equals("P")){
					aliciHesapNo =getGlobalParam("PP_FINANSAL_BAKIM_HESAP");
					sbaPpKkiadeTx.setAliciHesapSube("998");
				}
				else{
					aliciHesapNo =getGlobalParam("PP_FINANSAL_BAKIM_HESAP");
					sbaPpKkiadeTx.setAliciHesapSube("997");
				}
				sbaPpKkiadeTx.setAliciKartNo(iMap.getString("ALICI_KART_NO"));
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("DK");
				sbaPpKkiadeTx.setIslem("KARTA");
			}else if(iMap.getBoolean("KAMPANYA")){
				if (kartDci.equals("C")){
					aliciHesapNo =getGlobalParam("4487_KAMPANYA_ALICI_HESAP_KK");
					sbaPpKkiadeTx.setAliciHesapSube("998");
				}else{
					aliciHesapNo =getGlobalParam("4487_KAMPANYA_ALICI_HESAP_PP");	
					sbaPpKkiadeTx.setAliciHesapSube("997");
				}
				
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("DK");
				sbaPpKkiadeTx.setIslem("KAMPANYA");
			}else if(iMap.getBoolean("SANALPOS")){
				aliciHesapNo =getGlobalParam("POS_143_HAVUZ_HESABI");
				sbaPpKkiadeTx.setAliciHesapSube("997");
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("DK");
				sbaPpKkiadeTx.setIslem("SANALPOS");
			}else if(iMap.getBoolean("AKTIFBANK")){
				aliciHesapNo =iMap.getString("HESAP_NO");
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("VS");
				sbaPpKkiadeTx.setAliciHesapSube(getHesapSubeKod(aliciHesapNo));
				sbaPpKkiadeTx.setIslem("AKTIFBANK");
			}else if(iMap.getBoolean("GISEVIZE")){
			aliciHesapNo =iMap.getString("HESAP_NO");
			sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
			sbaPpKkiadeTx.setAliciHesapCinsi("VS");
			sbaPpKkiadeTx.setAliciHesapSube(getHesapSubeKod(aliciHesapNo));
			sbaPpKkiadeTx.setIslem("GISEVIZE");
			}else if(iMap.getBoolean("GISETOPUP")){
				aliciHesapNo =iMap.getString("HESAP_NO");
				sbaPpKkiadeTx.setAliciHesap(aliciHesapNo);
				sbaPpKkiadeTx.setAliciHesapCinsi("VS");
				sbaPpKkiadeTx.setAliciHesapSube(getHesapSubeKod(aliciHesapNo));
				sbaPpKkiadeTx.setIslem("GISETOPUP");
				}
			
			sbaPpKkiadeTx.setBankaAciklama(iMap.getString("BANKA_ACIKLAMA"));
			if(kartDci.equals("C")){
				sbaPpKkiadeTx.setBorcluHesap(getGlobalParam("KK_FINANSAL_BAKIM_HESAP"));
				sbaPpKkiadeTx.setBorcluHesapCinsi("DK");
				sbaPpKkiadeTx.setBorcluHesapSube("998");
			}else if(kartDci.equals("P") && dest.equals("O")){
				sbaPpKkiadeTx.setBorcluHesap(getGlobalParam("PP_FINANSAL_BAKIM_HESAP"));
				sbaPpKkiadeTx.setBorcluHesapCinsi("DK");
				sbaPpKkiadeTx.setBorcluHesapSube("998");
			}
			else{
				sbaPpKkiadeTx.setBorcluHesap(getGlobalParam("PP_FINANSAL_BAKIM_HESAP"));
				sbaPpKkiadeTx.setBorcluHesapCinsi("DK");
				sbaPpKkiadeTx.setBorcluHesapSube("997");
			}
		sbaPpKkiadeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
		sbaPpKkiadeTx.setIban(iMap.getString("IBAN"));
		sbaPpKkiadeTx.setKartNo(iMap.getString("KART_NO"));
		sbaPpKkiadeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
		sbaPpKkiadeTx.setTutar(iMap.getBigDecimal("TUTAR"));
		sbaPpKkiadeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		sbaPpKkiadeTx.setFisReferans("FIS_REFERANS");
		session.saveOrUpdate(sbaPpKkiadeTx);	
		session.flush();
		iMap.put("TRX_NAME" , "4487");
		oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4487_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaPpKkiadeTx sbaPpKkiadeTx = (SbaPpKkiadeTx) session.createCriteria(SbaPpKkiadeTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO") )).uniqueResult();
			oMap.put("ACIKLAMA", sbaPpKkiadeTx.getAciklama());
			oMap.put("HESAP_NO", sbaPpKkiadeTx.getHesapNo());
			oMap.put("KART_NO", sbaPpKkiadeTx.getKartNo());
			oMap.put("MUSTERI_NO", sbaPpKkiadeTx.getMusteriNo());
			oMap.put("TUTAR", sbaPpKkiadeTx.getTutar());
			oMap.put("BANKA_ACIKLAMA", sbaPpKkiadeTx.getBankaAciklama());
			oMap.put("EFT", sbaPpKkiadeTx.getIslem().equals("EFT"));
			oMap.put("HESABA", sbaPpKkiadeTx.getIslem().equals("HESABA"));
			oMap.put("KARTA", sbaPpKkiadeTx.getIslem().equals("KARTA"));
			oMap.put("KAMPANYA", sbaPpKkiadeTx.getIslem().equals("KAMPANYA"));
			oMap.put("SANALPOS",sbaPpKkiadeTx.getIslem().equals("SANALPOS"));
			oMap.put("AKTIFBANK",sbaPpKkiadeTx.getIslem().equals("AKTIFBANK"));
			oMap.put("GISEVIZE",sbaPpKkiadeTx.getIslem().equals("GISEVIZE"));
			oMap.put("GISETOPUP",sbaPpKkiadeTx.getIslem().equals("GISETOPUP"));
			oMap.put("ALICI_KART_NO", sbaPpKkiadeTx.getAliciKartNo());
			oMap.put("IBAN", sbaPpKkiadeTx.getIban());
			oMap.put("FIS_REFERANS", sbaPpKkiadeTx.getFisReferans());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4487_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaPpKkiadeTx sbaPpKkiadeTx = (SbaPpKkiadeTx) session.createCriteria(SbaPpKkiadeTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("ISLEM_NO") )).uniqueResult();
			String kartNo = sbaPpKkiadeTx.getKartNo();
			GMMap cProperty = new GMMap();
			cProperty.put("CARD_NO", kartNo);
			cProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cProperty);
			String kartDci = cProperty.getString("DCI");
			String dest = cProperty.getString("DESTINATION"); 
			GMMap cardMap = new GMMap();
			GMMap cardRespMap = new GMMap();
			
			cardMap.put(BSMV_RATE, BigDecimal.ZERO);
			cardMap.put(KKF_RATE, BigDecimal.ZERO);
			
			cardMap.put(TXN_AMOUNT, sbaPpKkiadeTx.getTutar());
			cardMap.put(CARD_NO, sbaPpKkiadeTx.getKartNo());
			cardMap.put(TXN_DESC, "Bakiye Aktar�m�");
			cardMap.put(TXN_CURR_CODE, "TRY");
			cardMap.put(TXN_TYPE, getGlobalParam("4487_FINANSAL_BAKIM").replace("?", "~"));
			cardMap.put(TXN_STATE, "N");

			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			cardMap.put(TXN_DATE, format.format(new Date()));
			
			if (kartDci.equals("P") && dest.equals("I")) {
				//Prepaid 
				cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
				
			}else if (kartDci.equals("C") || (kartDci.equals("P") && dest.equals("O"))) {
				//Kredi kart� 
				cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
			}
			if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
				throw new GMRuntimeException(4448011, "Kart Transfer Hata : "+ cardRespMap.getString(RETURN_DESCRIPTION));
			}
			if(sbaPpKkiadeTx.getIslem().equals("KARTA")){
				String aliciKartNo = sbaPpKkiadeTx.getAliciKartNo();
				GMMap cardProperty = new GMMap();
				cardProperty.put("CARD_NO", aliciKartNo);
				cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", cardProperty);
				String dci = cardProperty.getString("DCI");
				String dest2 = cardProperty.getString("DESTINATION");
				cardMap.clear();	
				cardMap.put(BSMV_RATE, BigDecimal.ZERO);
				cardMap.put(KKF_RATE, BigDecimal.ZERO);
				
				cardMap.put(TXN_AMOUNT, sbaPpKkiadeTx.getTutar());
				cardMap.put(CARD_NO, sbaPpKkiadeTx.getAliciKartNo());
				cardMap.put(TXN_DESC, "Bakiye Aktar�m�");
				cardMap.put(TXN_CURR_CODE, "TRY");
				cardMap.put(TXN_TYPE, getGlobalParam("TAKAS_IADE_FIN_ADJ_PP").replace("?", "~"));
				cardMap.put(TXN_STATE, "N");

				format = new SimpleDateFormat("yyyyMMdd");
				cardMap.put(TXN_DATE, format.format(new Date()));
				
				if (dci.equals("P")) {
					//Prepaid 
					cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
					
				}else if (dci.equals("C") || (dci.equals("P") && dest2.equals("O"))) {
					//Kredi kart� 
					cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
				}
				
				
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4487_ACIKLAMA_OLUSTUR")
	public static GMMap aciklamaOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		String kartNo = iMap.getString("KART_NO");
		String kartNoGizli = kartMaskele(kartNo);
		if(iMap.getBoolean("HESABA")){
			oMap.put("ACIKLAMA", getMessage(kartNoGizli, "5271", ""));
			oMap.put("BANKAACIKLAMA", getMessage(kartNo, "5271", ""));
		}else if(iMap.getBoolean("KARTA")){
			String aliciKartNo = iMap.getString("ALICI_KART_NO");
			String gizliAliciKartNo = kartMaskele(aliciKartNo);
			oMap.put("ACIKLAMA", getMessage(kartNoGizli, "5272", gizliAliciKartNo));
			oMap.put("BANKAACIKLAMA", getMessage(kartNo, "5272", aliciKartNo));
		}else if(iMap.getBoolean("KAMPANYA")){
			oMap.put("ACIKLAMA", getMessage(kartNoGizli, "5273", ""));
			oMap.put("BANKAACIKLAMA", getMessage(kartNo, "5273", ""));
		}else if(iMap.getBoolean("SANALPOS")){
			oMap.put("ACIKLAMA", getMessage(kartNoGizli, "5274", ""));
			oMap.put("BANKAACIKLAMA", getMessage(kartNo, "5274", ""));
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4487_GET_AKTIF_HESAP")
	public static GMMap getAktifHesap(GMMap iMap){
		GMMap oMap = new GMMap();
		if(iMap.getBoolean("AKTIFBANK")){
		oMap.put("AKTIF_HESAP", getGlobalParam("4487_AKTIFBANK_HESABI"));
		}else if(iMap.getBoolean("GISEVIZE")){
			oMap.put("AKTIF_HESAP", getGlobalParam("4487_GISE_VIZE_HESABI"));
		}else if(iMap.getBoolean("GISETOPUP")){
			oMap.put("AKTIF_HESAP", getGlobalParam("4487_GISE_TOPUP_HESABI"));
		} 
		
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
	        GMMap iMapG = new GMMap();
	        iMapG.put("KOD" , batchParamCode);
	        iMapG.put("TRIM_QUOTES" , true);
	        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
	        return batchNo;
	    }
	public static String getHesapSubeKod(String hesapNo){
	String subeKod;
	GMMap oMap = new GMMap();
	oMap.put("HESAP_NO", hesapNo);
	subeKod = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", oMap).getString("SUBE_KODU");
	return subeKod;
	}
	public static String getMessage(String P1,String mesajNo, String P2){
		GMMap kodMap = new GMMap();
		kodMap.put("P1",P1);
		kodMap.put("P2",P2);
		kodMap.put("MESSAGE_NO", mesajNo);
		kodMap = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", kodMap);
		return kodMap.getString("ERROR_MESSAGE");
	}
	private static String kartMaskele (String kartNo){
	    // format the number
		return kartNo.replaceAll("(\\w{1,6})(\\w{1,6})(\\w{1,4})", "$1 ** **** $3");
	}
}
