package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.KkTahsisDegerTx;
import tr.com.aktifbank.bnspr.dao.KkTahsisDogrulamaTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.tff.services.CrmTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** Kredi Karti Basvurusu TAHSIS Islemleri.<br>
 * BNSPR_TRN3874 ile baslayan ekranlarin servislerini icerir.
 * 
 * @author murat.el
 * @since 03/09/2013
 */
public class CreditCardTRN3874Services {
	
	private static final String RESULTS = "RESULTS";
	/**Kart Hosgeldin Event*/
	private static final String KART_HOSGELDIN_EVENT_TYPE_NO = "17";
	//Logger
	private static final Logger logger = Logger.getLogger(CreditCardTRN3874Services.class);

	private static final String IssuingExceptionApplicationNoUsedBefore = "Issuing.Exception.ApplicationNoUsedBefore";

	//---------------------------------------------------------------------
	//******************************************************* 3874 Ekrani
	//---------------------------------------------------------------------
	/**
	 * BNSPR_TRN3874.guiml ekrani acilisinda alinacak degerleri ekrana aktarir.
	 */
	@GraymoundService("BNSPR_TRN3874_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		String query = null;
		
		try {
			// Basvuru turu
			oMap.putAll(CreditCardServicesUtil.getParameterListByKey("KART_SEVIYESI", "KREDI_KART_SEVIYESI_KOD", "E", "I"));

			//Cinsiyet
			oMap.putAll(CreditCardServicesUtil.getParameterList("CINSIYET", "CINSIYET"));

			//Medeni Hal
			query = "SELECT kod, aciklama FROM gnl_medeni_hal_kod_pr";
			DALUtil.fillComboBox(oMap, "MEDENI_HAL", false, query);
			
			// Ogrenim Durumu
			query = "select kod, aciklama from gnl_egitim_kod_pr";
			DALUtil.fillComboBox(oMap, "OGRENIM_DURUM_KOD", false, query);
			
			//Calisma Sekli
			oMap.putAll(CreditCardServicesUtil.getParameterList("CALISMA_SEKLI_KOD", "CALISMA_SEKLI"));
			
			//Meslek
			query = "SELECT kod, aciklama FROM gnl_meslek_kod_pr";
			DALUtil.fillComboBox(oMap, "MESLEK_KOD", false, query);
			
			//Unvan
			query = "SELECT kod,aciklama FROM gnl_unvan_kod_pr";
			DALUtil.fillComboBox(oMap, "UNVAN_KOD", false, query);
			
			//PTT Unvan
			query = "SELECT ptt_unvan_kod, ptt_unvan FROM clks_ptt_banka_unvan_karsilik";
			DALUtil.fillComboBox(oMap, "PTT_UNVAN_KOD", false, query);

			//Ikamet Durum
			oMap.putAll(CreditCardServicesUtil.getParameterList("IKAMET_DURUM_KOD", "IKAMET_DURUM_KOD"));
			
			//Isyeri Faaliyet Alani
			oMap.putAll(CreditCardServicesUtil.getParameterList("FAALIYET_ALANI_KOD", "ISYERI_FAAL_KONU_KOD"));
			
			//Karar
			oMap.putAll(CreditCardServicesUtil.getParameterList("AKSIYON_KOD", "KK_BASVURU_AKSIYON_KOD"));

			//KDH Karar
			oMap.putAll(CreditCardServicesUtil.getParameterList("KDH_AKSIYON_KOD", "KK_KDH_BASVURU_AKSIYON_KOD"));
			
			//Iade-Dogrulama
			oMap.putAll(CreditCardServicesUtil.getParameterList("MUS_DOG_IADE_KOD", "BAS_DOG_AKSIYON_KOD", "M", null));
			
			//Ocean Musteri Tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("TAHSIS_OCEAN_MUSTERI_TIPI", "TAHSIS_OCEAN_MUSTERI_TIPI"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * BNSPR_TRN3874.guiml ekrani Karar combosundan secilen degere gore Iade combosunu doldurur.
	 * 
	 * @param iMap - DURUM_KODU
	 * @return {@link GMMap} - IADE_KOD
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BASVURU_IADE_KOD")
	public static GMMap getBasvuruIadeKod(GMMap iMap) {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT t.key1,t.key1");
		query.append(" FROM v_ml_gnl_param_text t");
		query.append(" WHERE t.kod = 'KK_BASVURU_DURUM_KOD'");
		query.append(" AND t.sira_no > 1");
		query.append(" AND t.sira_no <");
		query.append(" (");
		query.append(" SELECT sira_no");
		query.append(" FROM v_ml_gnl_param_text");
		query.append(" WHERE kod = 'KK_BASVURU_DURUM_KOD'");
		query.append(" AND key1 = '");
		query.append(iMap.getString("DURUM_KODU"));
		query.append("')");

		GMMap oMap = new GMMap();
		try {
			DALUtil.fillComboBox(oMap, "IADE_KOD", true, query.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * BNSPR_TRN3874.guiml ekrani Iade combosunu doldurur.
	 * 
	 * @return {@link GMMap} - IADE_KOD
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BASVURU_IADE_KOD_ALL")
	public static GMMap getBasvuruIadeKodAll(GMMap iMap) {
		StringBuilder query = new StringBuilder();
		query.append(" SELECT t.key1,t.key1");
		query.append(" FROM v_ml_gnl_param_text t");
		query.append(" WHERE t.kod = 'KK_BASVURU_DURUM_KOD'");
		
		GMMap oMap = new GMMap();
		try {
			DALUtil.fillComboBox(oMap, "IADE_KOD", true, query.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekrani Karar combosundan (Iade secildi ise iade koduna gore)
	 * secilen degere gore Gerekce combosunu doldurur.<br>
	 * 
	 * @param iMap - DURUM_KODU
	 * @return {@link GMMap} - IADE_KOD
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BASVURU_AKSIYON_KARAR_KOD")
	public static GMMap getBasvuruAksiyonKararKod(GMMap iMap) {
		//select hazirla..
		StringBuilder query = new StringBuilder();
		query.append(" SELECT key2,text");
		query.append(" FROM v_ml_gnl_param_text");
		query.append(" WHERE kod = 'KK_BASVURU_AKSIYON_KARAR_KOD'");
		query.append(" AND ((key2 not in ('3','4','5') and key1 = 'C') or key1 <> 'C')");
		query.append(" AND key1 = '");
		query.append(iMap.getString("KARAR"));
		query.append("'");																																															// IPTAL
		
		if (iMap.getString("IADE_KOD") != null) {
			query.append(" AND key3 = '");
			query.append(iMap.getString("IADE_KOD"));
			query.append("'");
		}
		
		query.append(" ORDER BY 1");
		
		//execute
		GMMap oMap = new GMMap();
		try {
			DALUtil.fillComboBox(oMap, "AKSIYON_KARAR_KOD", true, query.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekrani Karar combosundan (Iade secildi ise iade koduna gore)
	 * secilen degere gore Gerekce combosunu doldurur.<br>
	 * 
	 * @param iMap - DURUM_KODU
	 * @return {@link GMMap} - IADE_KOD
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BASVURU_KDH_AKSIYON_KARAR_KOD")
	public static GMMap getBasvuruKdhAksiyonKararKod(GMMap iMap) {
		//select hazirla..
		StringBuilder query = new StringBuilder();
		query.append(" SELECT key2,text");
		query.append(" FROM v_ml_gnl_param_text");
		query.append(" WHERE kod = 'KDH_BASVURU_AKSIYON_KARAR_KOD'");
		query.append(" AND ((key2 not in ('3','4','5') and key1 = 'C') or key1 <> 'C')");
		query.append(" AND key1 = '");
		query.append(iMap.getString("KDH_KARAR"));
		query.append("'");
		query.append(" ORDER BY 1");
		
		//execute
		GMMap oMap = new GMMap();
		try {
			DALUtil.fillComboBox(oMap, "KDH_AKSIYON_KARAR_KOD", true, query.toString());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	
	/** BNSPR_TRN3874.guiml ekraninda secilen basvuru numarasina gore
	 * basvuru bilgilerini(kredi, kullanici, kisisel, meslek, belge) listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BASVURU")
	public static GMMap getBasvuruDetay(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			//Islem numarasi ile geliniyorsa basvuru numarasini al.
			if (iMap.getBigDecimal("TRX_NO") != null) {
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				KkTahsisDegerTx kkTahsisDegerTx = (KkTahsisDegerTx)
						session.get(KkTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));
				
				if (kkTahsisDegerTx != null) {
					basvuruNo = kkTahsisDegerTx.getBasvuruNo();
				}
			}
			
			//basvuru detay bilgilerini al.
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TRN3874.RC_QRY3874_GET_BASVURU(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			//basvuru belgelerini ve goruslerini al.
			oMap.put("TAHSIS_GORUS_LIST", getTahsisGorusList(basvuruNo, null).get("TAHSIS_GORUS_LIST"));
			oMap.put("BELGE_LIST", getBasvuruBelgeList(basvuruNo).get("BELGE_LIST"));
			
			//Checkbox null alinca patliyordu.
			if (oMap.get("KONTAKT_MUSTERI") == null) {
				oMap.put("KONTAKT_MUSTERI", false);
			}
			
			if (oMap.get("MUSTERI_BLOKESI_VAR") == null) {
				oMap.put("MUSTERI_BLOKESI_VAR", false);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekraninda secilen basvuru numarasina gore
	 * basvuru bilgilerini(kredi, kullanici, kisisel, meslek, belge) listeler.
	 * 
	 * @param iMap - BASVURU_NO, TRX_NO
	 * @return {@link GMMap} - Basvuru Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BASVURU_TAHSIS")
	public static GMMap getBasvuruTahsisDetay(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TRN3874.RC_QRY3874_GET_BASVURU_TAHSIS(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			// Iade - Dogrulama Kontrolleri
			String kararKodu = oMap.getString("AKSIYON_KOD");
			if(kararKodu != null && "I".equals(kararKodu)) {
				String iadeKodu = oMap.getString("IADE_KOD");
				if(iadeKodu != null && "DOGRULAMA".equals(iadeKodu)) {
					oMap.put("MUSTERI_ISYERI_DOG_IADE", "Not Required");
					oMap.put("MUSTERI_WEB_DOG_IADE", "N");
				}
				
				//Dogrulamaya iade edilen basvurunun iade bilgilerini al.
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				KkTahsisDogrulamaTx kkTahsisDogrulamaTx = (KkTahsisDogrulamaTx)
						session.get(KkTahsisDogrulamaTx.class, oMap.getBigDecimal("TX_NO"));
				
				if (kkTahsisDogrulamaTx != null) {
					String nbsmDogSonucStr = kkTahsisDogrulamaTx.getNbsmDogSonucStr();
					if (!StringUtil.isEmpty(nbsmDogSonucStr)) {
						int size = nbsmDogSonucStr.split("-").length;
						for (int i = 0; i < size; i++) {
							if (nbsmDogSonucStr.split("-")[i].contains("MEmptVer")) {
								oMap.put("MUSTERI_ISYERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
							} else if (nbsmDogSonucStr.split("-")[i].contains("MWebVer")) {
								oMap.put("MUSTERI_WEB_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekraninda Es Bilgilerini Gostermek Amaciyla
	 * basvuru sahibinin medeni durumunu verilen basvuru numarasina gore bulur.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - EVLI_MI:true|false
	 */
	@GraymoundService("BNSPR_TRN3874_EVLI_MI")
	public static GMMap isEvli(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		//basvuru detay bilgilerini al.
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{? = call PKG_TRN3874.RC_QRY3874_GET_MEDENI_HAL(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			String medeniDurumKod = stmt.getString(1);
            oMap.put("EVLI_MI", "1".equals(medeniDurumKod));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		 return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekraninda secilen basvuru/islem numarasina gore
	 * daha onceden tahsis asamasinda girilmis aciklamalari listeler.
	 * 
	 * @param iMap - BASVURU_NO, TRX_NO
	 * @return {@link GMMap} - Tahsis Gorusleri
	 */
	private static GMMap getTahsisGorusList(BigDecimal basvuruNo, BigDecimal trxNo) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			//TODO Proc. icerisinde select cekilen tablolar kontrol edilecek.
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_GET_TAHSIS_GORUS(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.setBigDecimal(3, trxNo);
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			DALUtil.fillComboBox(oMap, "TAHSIS_GORUS_LIST", false, rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekraninda secilen basvuru numarasina gore
	 * basvuru sirasinda istenecek belgeleri listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru icin Gerekli Belgeler
	 */
	public static GMMap getBasvuruBelgeList(BigDecimal basvuruNo) {
		//initial variables
		GMMap oMap = new GMMap();
				
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			//TODO Proc. icerisinde select cekilen tablolar kontrol edilecek.
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_GET_BASVURU_BELGE(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "BELGE_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/** BNSPR_TRN3874.guiml ekranindan girilen tahsis ve belge bilgilerini kaydeder.
	 * 
	 * @param iMap - Ekrandaki tum bilgiler
	 * @return oMap - Islem sonucu
	 */
	@GraymoundService("BNSPR_TRN3874_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Kredi Karti Basvurusu Tahsis Degerleri Objesi Olustur
			KkTahsisDegerTx kkTahsisDegerTx = saveKkTahsisDeger(session, iMap);
			
			//Kredi Karti Basvurusu Gerekli Belgeler Objesi Olustur
			saveKkBasvuruBelgeList(session, iMap);

			//Basvuru Akisindaki Kullanici Bilgilerini Guncelle.
			//Onaya dusecekse tarihceye kayit at
			if ("IS_HAVUZU".equals(iMap.getString("ACTION"))) {
				saveIsHavuzuIslem(kkTahsisDegerTx.getTxNo());
			}
			
			//Kaydet
			iMap.put("TRX_NAME", "3874");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	public static String getPrevNbsmOutputValue(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM_7RSL.get_prev_nbsm_output_value (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setString(i++, iMap.getString("NBSM_KEY"));

			stmt.execute();

			return stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	/** BNSPR_TRN3874.guiml ekranindan girilen tahsis bilgilerini kaydeder.
	 * 
	 * @param iMap - Ekrandaki tahsis bilgileri
	 * @return kkTahsisDegerTx - Kaydedilen Tahsis Bilgileri
	 */
	private static KkTahsisDegerTx saveKkTahsisDeger(Session session, GMMap iMap) {
		String kararKodu = iMap.getString("AKSIYON_KOD");
		String iadeKodu = iMap.getString("IADE_KOD");
		
		KkTahsisDegerTx kkTahsisDegerTx = null;
		
		try {
			kkTahsisDegerTx = (KkTahsisDegerTx) session.get(KkTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkTahsisDegerTx == null) {
				kkTahsisDegerTx = new KkTahsisDegerTx();
			}
				
			kkTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kkTahsisDegerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kkTahsisDegerTx.setDurumKod(iMap.getString("DURUM_KOD"));
			kkTahsisDegerTx.setAksiyonKod(kararKodu);
			kkTahsisDegerTx.setKdhAksiyonKod(iMap.getString("KDH_AKSIYON_KOD"));
			kkTahsisDegerTx.setOnaylananKartLimiti(iMap.getBigDecimal("ONAYLANAN_KART_LIMITI"));
			kkTahsisDegerTx.setOnaylananKdhLimiti(iMap.getBigDecimal("ONAYLANAN_KDH_LIMITI"));
			kkTahsisDegerTx.setOnaylananNakitKartLimiti(iMap.getBigDecimal("ONAYLANAN_NAKIT_KART_LIMITI"));
			kkTahsisDegerTx.setOnaylananEkspressKartLimiti(iMap.getBigDecimal("ONAYLANAN_EKSPRESS_KART_LIMITI"));
			kkTahsisDegerTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
			kkTahsisDegerTx.setKdhAksiyonKararKod(iMap.getString("KDH_AKSIYON_KARAR_KOD"));
			kkTahsisDegerTx.setIadeKod(iadeKodu);
			kkTahsisDegerTx.setOceanMusteriTipi(iMap.getString("OCEAN_MUSTERI_TIPI"));
			
			if (StringUtils.isNotBlank(iMap.getString("ACIKLAMA"))) {
				kkTahsisDegerTx.setAciklama(iMap.getString("ACIKLAMA").trim());
			}
			
			if (StringUtils.isNotBlank(iMap.getString("TAHSIS_GORUS"))) {
				kkTahsisDegerTx.setTahsisGorus(iMap.getString("TAHSIS_GORUS").trim());
			}
			
			//Iade Degilse sonraki durumu belirle
			if(kararKodu != null) {
				if(!("I".equals(kararKodu) && iadeKodu == null)) {
					
					if("O".equals(kararKodu))
					{
						KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
						if ("L".equals(kkBasvuru.getKartSeviyesi())) {
							kkTahsisDegerTx.setIslemSonrasiDurumKodu("BASIM");
						} else {
							if (CreditCardServicesUtil.hunterDevredeMi() && CreditCardServicesUtil.hunterAktifMi()) {
								kkTahsisDegerTx.setIslemSonrasiDurumKodu("HUNTER");
							} else {
								GMMap pMap = new GMMap();
								pMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
								pMap.put("SORGU_SEVIYESI", "R");
								pMap.put("NBSM_KEY", "SMFraudStrategyFraudQueueYN");
			
								String fraudQueueYN = getPrevNbsmOutputValue(pMap);
								if (fraudQueueYN == null || fraudQueueYN.isEmpty()) {
									pMap.put("SORGU_SEVIYESI", "F");
									fraudQueueYN = getPrevNbsmOutputValue(pMap);
								}
								
								if("Y".equals(fraudQueueYN)) {
									kkTahsisDegerTx.setIslemSonrasiDurumKodu("FRAUD");
								} else {
									kkTahsisDegerTx.setIslemSonrasiDurumKodu("BASIM");
								}
							}	
						}
					}
					else
						kkTahsisDegerTx.setIslemSonrasiDurumKodu(getIslemSonrasiDurumKodu(kararKodu, iadeKodu));
				}
				
				if("I".equals(kararKodu) && iadeKodu != null && "DOGRULAMA".equals(iadeKodu)) {
					String nbsmDogSonucStr = "";
					nbsmDogSonucStr = nbsmDogSonucStr + "MEmptVer:" + (iMap.getString("MUSTERI_ISYERI_DOG_IADE") == null ? "Not Required" : iMap.getString("MUSTERI_ISYERI_DOG_IADE")) + "-";
					nbsmDogSonucStr = nbsmDogSonucStr + "MWebVer:" + (iMap.getString("MUSTERI_WEB_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_WEB_DOG_IADE"));
					
					kkTahsisDegerTx.setNbsmDogSonucStrM(nbsmDogSonucStr);
					
					//Dogrulamaya iade olacak tahsis objesini kaydet
					KkTahsisDogrulamaTx kkTahsisDogrulamaTx = (KkTahsisDogrulamaTx)
							session.get(KkTahsisDogrulamaTx.class, iMap.getBigDecimal("TRX_NO"));
					
					//Yoksa yeni obje olustur
					if (kkTahsisDogrulamaTx == null) {
						kkTahsisDogrulamaTx = new KkTahsisDogrulamaTx();
						kkTahsisDogrulamaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
					}
					
					//Degerleri Set Et
					kkTahsisDogrulamaTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					kkTahsisDogrulamaTx.setNbsmDogSonucStr(nbsmDogSonucStr);
					session.saveOrUpdate(kkTahsisDogrulamaTx);
				}
			}

			session.saveOrUpdate(kkTahsisDegerTx);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return kkTahsisDegerTx;
	}
	
	/** BNSPR_TRN3874.guiml ekranindan girilen belge bilgilerini kaydeder.
	 * 
	 * @param session - {@link Session}
	 * @param iMap - Ekrandaki belge bilgileri
	 */
	private static void saveKkBasvuruBelgeList(Session session, GMMap iMap) {
		try {
			//Mevcut Listeyi Temizle.
			List<?> mevcutBelgeList =
					session.createCriteria(KkBasvuruBelgeTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
					.add(Restrictions.eq("id.barkodNumarasi", iMap.getString("BARKOD_NUMARASI")))
					.list();
			
			if (mevcutBelgeList != null && !mevcutBelgeList.isEmpty()) {
				for (Object belge : mevcutBelgeList) {
					KkBasvuruBelgeTx kkBasvuruBelgeTx = (KkBasvuruBelgeTx) belge;
					session.delete(kkBasvuruBelgeTx);
				}
				session.flush();
			}

			//Yeni Listeyi Kaydet.
			String ekranTableName = "BELGE_LIST";
			List<?> yeniBelgeList = (List<?>) iMap.get(ekranTableName);
		
			if (yeniBelgeList != null && !yeniBelgeList.isEmpty()) {
				for (int i = 0; i < yeniBelgeList.size(); i++) {
					KkBasvuruBelgeTxId kkBasvuruBelgeTxId = new KkBasvuruBelgeTxId();
					kkBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					kkBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					kkBasvuruBelgeTxId.setDokumanKod(iMap.getString(ekranTableName, i, "BELGE_KOD"));
					kkBasvuruBelgeTxId.setBarkodNumarasi(iMap.getString(ekranTableName, i, "BARKOD_NUMARASI"));

					KkBasvuruBelgeTx kkBasvuruBelgeTx = new KkBasvuruBelgeTx();
					kkBasvuruBelgeTx.setId(kkBasvuruBelgeTxId);
					session.save(kkBasvuruBelgeTx);
				}
				
				session.flush();
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/** IS_HAVUZU modunda yapilan islemlerde islemin atandigi kullanicidan islem kaldirilir ve
	 * islem onaya dusecekse tarihce kaydi olusturulur.
	 * 
	 * @param txNo - Islem Numarasi
	 */
	private static void saveIsHavuzuIslem(BigDecimal txNo) {
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			//sorgu sonuclari
			query = "{ call PKG_TRN3874.Rc_Qry3874_Is_Havuzu_Islem(?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, txNo);
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/** Verilen karar koduna(karar iade ise iade koduna da gore) tahsis isleminden sonraki durumu bulur.
	 * 
	 * @param kararKod - Basvurunun tahsis asamasindaki karar durumu
	 * @param iadeKod -  Basvurunun tahsis asamasinda iade edilecek ise hangi asamaya iade edildigi
	 * @return durumKodu - Tahsis islemi sonrasi basvuru durumu
	 */
	private static String getIslemSonrasiDurumKodu(String kararKod, String iadeKod) {
		String durumKodu = null;
		
		if ("S".equals(kararKod)) {//Sakla
			durumKodu = "TAHSIS";
		} else if ("I".equals(kararKod)) {//Iade
			durumKodu = iadeKod;
		} else if ("R".equals(kararKod)) {//Red
			durumKodu = "RED";
		/*} else if ("O".equals(kararKod)) {//Onay
			durumKodu = "BASIM";*/
		} else if ("C".equals(kararKod)) {//Iptal
			durumKodu = "IPTAL";
		} else if ("F".equals(kararKod)) {//Fraud
			if(CreditCardServicesUtil.hunterAktifMi())
				durumKodu = "HUNTER";
			else
				durumKodu = "FRAUD";	
		}

		return durumKodu;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3874_SORGU_SONUC Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_SORGU_SONUC.guiml ekraninda
	 * verilen basvuru numarasina gore basvuru sahibi hakkinda yapilan sorgulama sonuclarini listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru Sahibi Sorgulama Sonuclari
	 */
	@GraymoundService("BNSPR_TRN3874_GET_BRM_SORGU_SONUC")
	public static GMMap getSorguSonuclari(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
				
		//initial database variables
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			//sorgu sonuclari
			query = "{ ? = call PKG_TRN3874.Rc_Qry3874_Get_Sorgu_Sonuc(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	//---------------------------------------------------------------------
	//******************************************************* 3874_KIMLIK_BILGILERI Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_KIMLIK_BILGILERI.guiml ekraninda
	 * verilen basvuru numarasina gore basvuru sahibinin kimlik bilgilerini listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru Sahibi Kimlik Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3874_KIMLIK_BILGILERI")
	public static GMMap getKimlikBilgileri(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
				
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_KIMLIK_BILGILERI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap =  DALUtil.rSetMap(rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3874_ONCEKI_BASVURULAR Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_ONCEKI_BASVURULAR.guiml ekraninda
	 * verilen basvuru numarasi ve TC kimlik numaralarina gore basvuru sahibinin
	 * daha once yaptigi basvurulari listeler.
	 * 
	 * @param iMap - BASVURU_NO, TC_KIMLIK_NO
	 * @return {@link GMMap} - Onceki Basvurular
	 */
	@GraymoundService("BNSPR_TRN3874_GET_ONCEKI_BASVURU_LIST")
	public static GMMap getOncekiBasvuruList(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
				
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_LIST_ONCEKI_BASVURU(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("TC_KIMLIK_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, RESULTS);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3874_ONCEKI_BASVURULAR_DETAY Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_ONCEKI_BASVURULAR_DETAY.guiml ekraninda
	 * verilen daha once yapilmis basvuruya ait basvuru numarasina gore basvuru bilgilerini listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Onceki Basvuru Bilgisi
	 */
	@GraymoundService("BNSPR_TRN3874_GET_ONCEKI_BASVURU_DETAY")
	public static GMMap getOncekiBasvuruDetay(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_GET_BASVURU_DETAY(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3874_HESAP_BILGILERI Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_HESAP_BILGILERI.guiml ekraninda
	 * verilen basvuru numarasina gore musteri hesap bilgilerini listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru Sahibi Hesap Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3874_HESAP_BILGILERI")
	public static GMMap getHesapBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ call PKG_TRN3874.RC_QRY3874_HESAP_BILGILERI(?,?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.registerOutParameter(4, -10);
			stmt.execute();
			
			//Kredi bilgileri
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetResults(rSet, "KREDI_BILGI"));
			GMServerDatasource.close(rSet);
			
			//KMH bilgileri
			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetResults(rSet, "KMH_BILGI"));
			GMServerDatasource.close(rSet);

			//Musteri Bilgileri
			rSet = (ResultSet) stmt.getObject(4);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);
			
			iMap.put("TAHSIS_IZLEME", "E");
			iMap.put("MUSTERI_NO", oMap.getString("MUSTERI_NO"));
			oMap.put("KREDI_KART_BILGI", GMServiceExecuter.execute("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap).get("KREDI_KART_BILGI"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
				
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3874_ILETISIM_BILGILERI Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_ILETISIM_BILGILERI.guiml ekraninda
	 * verilen basvuru numarasina gore adres/tel/aps bilgilerini listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 * @return {@link GMMap} - Basvuru Sahibi Iletisim Bilgileri
	 */
	@GraymoundService("BNSPR_TRN3874_ILETISIM_BILGILERI")
	public static GMMap getIletisimBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_ILETISIM_BILGILERI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
	
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			
			query = "{ ? = call PKG_TRN3874.RC_QRY3874_APS_BILGILERI(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
				
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3874_WEB_LINKLERI Ekrani
	//---------------------------------------------------------------------
	/** BNSPR_TRN3874_WEB_LINKLERI.guiml ekraninda
	 * sorgulama amaciyla kullanilabilecek faydali linkleri listeler.
	 * 
	 * @return {@link GMMap} - Web Adresleri
	 */
	@GraymoundService("BNSPR_TRN3874_WEB_LINK")
	public static GMMap getWebLink(GMMap iMap) {
		//initialize variables
		GMMap oMap = new GMMap();
		
		String serviceName = "BNSPR_GET_PARAMETRE_DEGER_AL_K";
		String resultName = "DEGER";
		String mapKey = "PARAMETRE";
		
		try {
			iMap.put(mapKey, "SSK_REHBERLIK_LINK");
			oMap.put("SSK_REHBERLIK_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "SSK_TCKN_LINK");
			oMap.put("SSK_TCKN_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "SSK_AD_SOYAD_LINK");
			oMap.put("SSK_AD_SOYAD_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "SSK_EMEKLI_LINK");
			oMap.put("SSK_EMEKLI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "SSK_EMEKLI_AYLIGI_LINK");
			oMap.put("SSK_EMEKLI_AYLIGI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "BAGKUR_AD_SOYAD_TCKN_LINK");
			oMap.put("BAGKUR_AD_SOYAD_TCKN_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "BAGKUR_BORC_BILGISI_LINK");
			oMap.put("BAGKUR_BORC_BILGISI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "BAGKUR_EMEKLI_LINK");
			oMap.put("BAGKUR_EMEKLI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "EMEK_SAN_TCKN_LINK");
			oMap.put("EMEK_SAN_TCKN_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "AVUKAT_SORGULAMA_LINK");
			oMap.put("AVUKAT_SORGULAMA_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "TC_SANAYI_ODASI_LINK");
			oMap.put("TC_SANAYI_ODASI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "ITO_UNVAN_LINK");
			oMap.put("ITO_UNVAN_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "ITO_AD_SOYAD_LINK");
			oMap.put("ITO_AD_SOYAD_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "ITO_TICARET_SICIL_NO_LINK");
			oMap.put("ITO_TICARET_SICIL_NO_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "BTSO_LINK");
			oMap.put("BTSO_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "KTSO_LINK");
			oMap.put("KTSO_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "TICARET_SICIL_GAZETESI_LINK");
			oMap.put("TICARET_SICIL_GAZETESI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "TT_REHBER_LINK");
			oMap.put("TT_REHBER_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "E_VERGI_LINK");
			oMap.put("E_VERGI_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "ARAC_SORGULAMA_LINK");
			oMap.put("ARAC_SORGULAMA_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "KASKO_DEGER_LISTESI");
			oMap.put("KASKO_DEGER_LISTESI", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "TRAMER_LINK");
			oMap.put("TRAMER_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "SABAS_LINK");
			oMap.put("SABAS_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.put(mapKey, "GOOGLE_LINK");
			oMap.put("GOOGLE_LINK", GMServiceExecuter.execute(serviceName, iMap).get(resultName));

			iMap.putAll(getKimlikBilgileri(iMap));

			StringBuilder sgkLink = new StringBuilder();
			sgkLink.append("https://esgm.sgk.gov.tr/Esgm/KimlikSorgulama?mernisNo=");
			sgkLink.append(iMap.getString("TCKN"));
			sgkLink.append("&ilKodu=");
			sgkLink.append(iMap.getString("NUFUS_IL_KOD").substring(1));
			sgkLink.append("&ciltNo=");
			sgkLink.append(iMap.getString("CILT_NO"));
			sgkLink.append("&dYil=");
			sgkLink.append(19);
			
			Calendar c = Calendar.getInstance();
			c.setTime(iMap.getDate("YIL"));
			sgkLink.append(c.get(Calendar.YEAR) - 1900);
			sgkLink.append("&guvenlikKodu=");

			oMap.put("SSK_TCKN_LINK", sgkLink);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* OCEAN
	//---------------------------------------------------------------------
	/** Tahsis islemi(onay asamasi da dahil) tamamlandiktan sonra kart basima gonderilir, musteri kaydi olusturulur
	 * ve musteriye bilgilendirme smsi gonderilir.
	 * 
	 * @author murat.el
	 * @param iMap - ISLEM_NO
	 */
	@GraymoundService("BNSPR_TRN3874_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Islem numarasi verilen basvurunun tahsis bilgilerini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkTahsisDegerTx kkTahsisDegerTx = (KkTahsisDegerTx)
					session.get(KkTahsisDegerTx.class, iMap.getBigDecimal("ISLEM_NO"));
			if (kkTahsisDegerTx != null) {
				//HUNTER durumunda ise sorguyu yap
				boolean isHunterBasim = false;
				if ("HUNTER".equals(kkTahsisDegerTx.getIslemSonrasiDurumKodu())) {
  					sorguMap.clear();
	  				sorguMap.put("BASVURU_NO", kkTahsisDegerTx.getBasvuruNo());
	  				sorguMap.put("BASVURU_TIPI", "KK");
	  				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_HUNTER_SEND_APPL_INFO", sorguMap));
	  				if ("ACCEPT".equals(sorguMap.getString("HUNTER_RESULT"))) {
	  					sorguMap.clear();
	  					sorguMap.put("BASVURU_NO", kkTahsisDegerTx.getBasvuruNo());
	  					sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
	  					sorguMap.put("DURUM_KOD", "BASIM");
	  					sorguMap.put("ISLEM_ACIKLAMA", sorguMap.getString("HUNTER_RESULT"));
	  					sorguMap.put("TARIHCE_AKSIYON", "E");
	  					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
	  					isHunterBasim = true;
	  				}
				}
					
				//Basvuru tahsis isleminde onaylandiysa
				if ("BASIM".equals(kkTahsisDegerTx.getIslemSonrasiDurumKodu()) || isHunterBasim) {
					if (isHunterBasim) {
						iMap.put("ISLEM_KODU", "HUNTER");
					} else {
						iMap.put("ISLEM_KODU", "TAHSIS");
					}
					iMap.put("BASVURU_NO", kkTahsisDegerTx.getBasvuruNo());
  	  				iMap.put("DURUM_KOD", "BASIM");
					GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN", iMap);
					GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_SMS", iMap);
				} 
				else {
					//KK basvurusunu al
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkTahsisDegerTx.getBasvuruNo());
					if (kkBasvuru != null) {
						session.refresh(kkBasvuru);
						if ("40".equals(kkBasvuru.getKanalKod())) {
							if ("RED".equals(kkBasvuru.getDurumKod())) {
								if (CreditCardServicesUtil.HAYIR.equals(
  										CreditCardServicesUtil.nvl(kkBasvuru.getOnOnayliMi(), CreditCardServicesUtil.HAYIR))) {
									sorguMap.clear();
									sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
									sorguMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
									sorguMap.put("ISLEM_KOD", "3874");
									oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU_GECERSIZ_ISLEM", sorguMap));
								}
							} else if ("IPTAL".equals(kkBasvuru.getDurumKod())) {
								//TFF basvurusunu al
								sorguMap.clear();
								sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
								BigDecimal tffBasvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
								//Tff basvurusunu al ve iptal et.
								if (tffBasvuruNo != null) {
									TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
									session.refresh(tffBasvuru);
									
									sorguMap.clear();
									sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
	  								sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
	  								sorguMap.put("ISLEM_KOD", "3874");
	  								sorguMap.put("GEREKCE_KOD", "2");
	  								sorguMap.put("ACIKLAMA", "kk iptal oldugundan tff iptal edildi");
	  								sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
	  								oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap));
								}
							}	
						} else {
							if ("L".equals(kkBasvuru.getKartSeviyesi())) {
  								if ("RED".equals(kkBasvuru.getDurumKod()) || "IPTAL".equals(kkBasvuru.getDurumKod())) {
  	  								//Limit durum guncelle
  	  								sorguMap.clear();
  	  								sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
  	  								sorguMap.put("SONRAKI_DURUM_KODU", kkBasvuru.getDurumKod());
  	  								sorguMap.put("LKS_RED_MI", kkBasvuru.getLksRedMi());
  	  								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
  	  							}
  							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_KK_CALL_OCEAN")
	public static GMMap callOcean(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Kredi karti basvuru bilgisini al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (kkBasvuru != null) {
				session.refresh(kkBasvuru);
				if ("L".equals(kkBasvuru.getKartSeviyesi())) {
					iMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
					iMap.put("LIMIT_ARTTIRIM", "E");
					oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN_LIMIT", iMap));
				} else {
					iMap.put("MUSTERI_NO", kkBasvuru.getMusteriNo());
					oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN_SAVE", iMap));
					//KDH istemisse
					if (CreditCardServicesUtil.EVET.equals(kkBasvuru.getKdhIstiyorMu()) &&
							CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
						//Onay mi
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_KDH_BASVURU_ONAYLANDI_MI", sorguMap));
						String onaylandimi = sorguMap.getString("ONAYLANDI_MI");
						//Red mi
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_KDH_BASVURU_RED_MI", sorguMap));
						String redMi = sorguMap.getString("RED_MI");
						//Kontrol - Onay veya redse
						if (CreditCardServicesUtil.EVET.equals(onaylandimi) || CreditCardServicesUtil.EVET.equals(redMi)) {
							//KDH sonuc bilgilendirmesi yap(SMS1)
							sorguMap.clear();
							sorguMap.put("EVENT_TYPE_NO", CreditCardServicesUtil.KDH_SONUC_EVENT_TYPE_NO);
							sorguMap.put("EVENT_REF_NO", "KK_" + kkBasvuru.getBasvuruNo());
							GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap);
						}
					}
				}
				if ("40".equals(kkBasvuru.getKanalKod())) {
					sorguMap.clear();
					sorguMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TFF_BASVURU_NO_AL", sorguMap));
					BigDecimal tffBasvuruNo = sorguMap.getBigDecimal("TFF_BASVURU_NO");
					// Tff basvurusunu al ve iptal et.
					if (tffBasvuruNo != null) {
						TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruNo);
						session.refresh(tffBasvuru);
						try {
							sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
							sorguMap.put("CRM_TYPE", CrmTypes.MAIN);
							GMServiceExecuter.execute("BNSPR_TFF_SEND_APPLICATION_TO_CRM",sorguMap);
						} catch (Exception e) {
							e.printStackTrace();
							logger.error("CRM guncellemesi yapilamadi BASVURU_NO:" + sorguMap.containsKey("TFF_BASVURU_NO"));
						}
					}
				}
			} else {
				CreditCardServicesUtil.raiseGMError("2999", iMap.getBigDecimal("BASVURU_NO"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_KK_CALL_OCEAN_SAVE")
	public static GMMap callOceanForSave(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		GMMap sorguMap = new GMMap();
		String oceanJob = "OCEAN_JOB";
		String lksJob2 = "LKS_JOB_2";
		String basim = "BASIM";
		String durumKod = "DURUM_KOD";
		String kartNo = null;
		String productId = null;
		BigDecimal oldLksSektorLimit;
		BigDecimal newLksSektorLimit;
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			String custResult = null;
			String custResultDesc = null;
			String cardResult = null;
			String cardResultDesc = null;
			String cardResultError = null;
			
			/*Sekt�r limiti de�i�ti mi kontrol� yap�l�yor, bunun i�in en son yap�lan sorgunun sekt�r limiti ile
			 * yeni yap�lan 01 tahsis sorgusundaki sekt�r limiti kontrol ediliyor.
			 * Sekt�r limitleri ayn� ise online tahsis i�lemi yap�l�r ve ocean �a�r�s� yap�l�r,
			 * sekt�r limiti de�i�mi� ise tekrar Tahsis ad�m�na g�nderilir ve tarihceye kay�t at�l�r 
			 * */

			//LKS sorgusu icin datalari al.
			oldLksSektorLimit = getGuncelLimitFromLks(iMap.getBigDecimal("BASVURU_NO"));

			tahsisSorguYap(iMap.getBigDecimal("BASVURU_NO"));

			newLksSektorLimit = getGuncelLimitFromLks(iMap.getBigDecimal("BASVURU_NO"));

			if (oldLksSektorLimit.compareTo(newLksSektorLimit) != 0) {

				sorguMap.clear();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
				sorguMap.put("DURUM_KOD", "TAHSIS");
				sorguMap.put("TARIHCE_AKSIYON", "G"); // Tarihce tablosundaki islem g�ncellenecek
				sorguMap.put("ISLEM_ACIKLAMA", "LKS SEKTOR LIMIT DEGISIKLIGI" + " ESKI SEKTOR LIMITI = " + oldLksSektorLimit + " YENI SEKTOR LIMITI = " + newLksSektorLimit);
				GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
			}
			else {

				String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'03') }";
				oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
				if (oMap.isEmpty()) {
					throw new Exception("Kayit Bulunamadi");
				}
			


				// LKS sorgusu yap
				GMMap lMap = new GMMap();
				oMap.put("MANUEL_SORGU", iMap.get("MANUEL_SORGU"));
				lMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_ONLINE_TAHSIS_YAP", oMap));

				tahsisSorguYap(iMap.getBigDecimal("BASVURU_NO"));
			
				// LKS sorgusu sonucu basarili ise
				oMap = new GMMap();
				if ("2".equals(lMap.getString("LKS_YAPILDIMI")) && ("2".equals(lMap.getString("RESPONSE")) || "5".equals(lMap.getString("RESPONSE")))) {
					// Tekrar limit kontrolu yapilsin isteniyorsa
					if ("5".equals(lMap.getString("RESPONSE"))) {
						// Basvuru uzerinden yeni bir tx olustur
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3806_GET_KK_TRX_NO", sorguMap));
						BigDecimal kkTrxNo = sorguMap.getBigDecimal("KK_TRX_NO");
						// Basvuruyu nbsm akisina sok
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("TRX_NO", kkTrxNo);
						sorguMap.put("UST_ISLEM_TRX_NO", iMap.get("ISLEM_NO"));
						sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
						sorguMap.put("DURUM_KOD", "BASIM");
						sorguMap.put("LIMIT_ARTIS", CreditCardServicesUtil.HAYIR);
						sorguMap.put("MANUEL_SORGU", "E");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GONDER_SORGULAR", sorguMap));
						if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("DEVAM")) && "BASIM".equals(sorguMap.getString("DURUM"))) {
							sorguMap.clear();
							sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
							sorguMap.put("ISLEM_KODU", iMap.get("ISLEM_KODU"));
							sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
							sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
							sorguMap.put("MANUEL_SORGU", CreditCardServicesUtil.EVET);
							oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CALL_OCEAN_SAVE", sorguMap));
						}
						else {
							oMap.put("MESSAGE", sorguMap.get("MESSAGE"));
						}

						return oMap;
					}
				
					// Musteri kaydini olustur.
					oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_CREDIT_CARD_CUSTOMER", iMap));
					custResult = oMap.getString("ORESULT");
					custResultDesc = oMap.getString("RETURN_DESCRIPTION");
				
					// Musteri basarili bir sekilde olusturuldu ise karti olustur.
					if ("2".equals(oMap.getString("RETURN_CODE"))) {
						// Kart olusturulmadan once musterinin hesabi yoksa yeni bir rezerv hesap acilir.
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("HESAP_KAYDEDILSIN_MI", CreditCardServicesUtil.EVET);
						sorguMap.putAll(GMServiceExecuter.executeNT("BNSPR_KK_REZERV_HESAP_AL", sorguMap));

						oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_CREDIT_CARD", iMap));
						cardResult = oMap.getString("ORESULT");
						cardResultDesc = oMap.getString("RETURN_DESCRIPTION");
						cardResultError = oMap.getString("ERROR_DETAIL");
					
						productId = oMap.getString("PRODUCT_ID");
					
						// Kart olusturulamadi ise
						if (!"2".equals(oMap.getString("RETURN_CODE"))) {
							// Tekrar kullan�ld� hatasi aldi ise basvuru no ile kart no bilgisini all ve devam et
							// 1.Hata mesaji:ORESULT=SystemError, ERROR_DETAIL=System.Exception: Girilen ApplicationNo
							// ve Customer bilgileriyle basvuru daha once yapilmistir.CardNo: 6711210163228796
							// 2.Hata mesaji:ORESULT=Error, ERROR_DETAIL=This application no is used before :3082517
							//if ((cardResultError.indexOf("ApplicationNo") > 0 && cardResultError.indexOf("CardNo") > 0) || cardResultDesc.indexOf("This application no is used before") > 0) {
							if (BnsprOceanCommonFunctions.convertNewReturnCodeToOld(IssuingExceptionApplicationNoUsedBefore).equals(oMap.getString("RETURN_CODE"))){
								sorguMap.clear();
								sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_KART_NO_BY_BASVURU_NO", sorguMap));
								// Kontrol
								if (StringUtils.isNotBlank(sorguMap.getString("KART_NO"))) {
									kartNo = sorguMap.getString("KART_NO");
								}
							}

							// Basimsa durumlari guncelle, ocean_job dan geliyorsa sadece aciklamayi guncelle
							if (StringUtils.isBlank(kartNo)) {
								GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_TAHSIS_IPTAL", lMap);
								// Basimsa tarihceyi guncelle, yoksa yeni kayit at.
								if (basim.equals(iMap.getString(durumKod))) {
									iMap.put(durumKod, oceanJob);
									iMap.put("TARIHCE_AKSIYON", "G");
									iMap.put("ISLEM_ACIKLAMA", cardResult + "-" + cardResultDesc);
									GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
								}
								else if (lksJob2.equals(iMap.getString(durumKod))) {
									sorguMap.clear();
									sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
									sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
									sorguMap.put("DURUM_KOD", oceanJob);
									sorguMap.put("TARIHCE_AKSIYON", "E");
									sorguMap.put("ISLEM_ACIKLAMA", cardResult + "-" + cardResultDesc);
									GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
								}
							
								return oMap;
							}
						}
						else {
							kartNo = oMap.getString("CARD_LIST", 0, "CARD_NO");
							iMap.put("EVENT_TYPE_NO", KART_HOSGELDIN_EVENT_TYPE_NO);
							iMap.put("EVENT_REF_NO", iMap.getBigDecimal("BASVURU_NO"));
							GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
						}
					}
					else { // Hatali ise joba duser.
						GMServiceExecuter.executeNT("BNSPR_TRN3871_LKS_TAHSIS_IPTAL", lMap);
						// Basimsa tarihceyi guncelle, yoksa yeni kayit at.
						if (basim.equals(iMap.getString(durumKod))) {
							iMap.put(durumKod, oceanJob);
							iMap.put("TARIHCE_AKSIYON", "G");
							iMap.put("ISLEM_ACIKLAMA", custResult + "-" + custResultDesc);
							GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
						}
						else if (lksJob2.equals(iMap.getString(durumKod))) {
							sorguMap.clear();
							sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
							sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
							sorguMap.put("DURUM_KOD", oceanJob);
							sorguMap.put("TARIHCE_AKSIYON", "E");
							sorguMap.put("ISLEM_ACIKLAMA", custResult + "-" + custResultDesc);
							GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
						}

						return oMap;
					}

					// kart olusturuldu ise kart nosunu kk_basvuruya koy
					conn = DALUtil.getGMConnection();

					if (StringUtils.isBlank(kartNo)) {
						sorguMap.clear();
						sorguMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
						sorguMap.put("MAIL_FROM", "System@aktifbank.com.tr");
						sorguMap.put("MAIL_SUBJECT", "KK Ocean Card Hata - " + iMap.getString("BASVURU_NO"));
						sorguMap.put("MAIL_BODY", "Kart no olusturulamam�st�r.");
						GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", sorguMap);
					} else {
						query = "{ call PKG_TRN3874.update_kart_no(?,?) }";
						stmt = conn.prepareCall(query);
						stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
						stmt.setString(2, kartNo);
						stmt.execute();
						GMServerDatasource.close(stmt);
					}

					// Hata alinmamissa Kart basim datalarini guncelle.
					query = "{ call PKG_KK_BASVURU.Update_Ocean_Service_Info(?,?,?,?,?) }";
					stmt = conn.prepareCall(query);

					int i = 1;
					stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
					stmt.setString(i++, custResult);
					stmt.setString(i++, custResultDesc);
					stmt.setString(i++, cardResult);
					stmt.setString(i++, cardResultDesc);
					stmt.execute();
					GMServerDatasource.close(stmt);

					// Basvuru durumu JOB ise durumu guncelle
					if (!basim.equals(iMap.getString(durumKod))) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
						sorguMap.put("DURUM_KOD", basim);
						sorguMap.put("TARIHCE_AKSIYON", "E");
						sorguMap.put("ISLEM_ACIKLAMA", custResult + "-" + cardResult);
						GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
					}
				
					// Basvuru TFF'ye aitse Durum Guncellemesi Yap.
					query = "{ call PKG_TRN3874.update_tff_kart_info(?,?,?) }";
					stmt = conn.prepareCall(query);
					stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
					stmt.setString(2, kartNo);
					stmt.setString(3, productId);
					stmt.execute();
				
					// Sonuc
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
				}
				else {
					if (basim.equals(iMap.getString(durumKod))) {
						iMap.put(durumKod, lksJob2);
						iMap.put("TARIHCE_AKSIYON", "G");
						iMap.put("ISLEM_ACIKLAMA", lMap.get("RESPONSE_MESSAGE"));
						GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", iMap);
					}
					else if (oceanJob.equals(iMap.getString(durumKod))) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("ISLEM_NO", iMap.get("ISLEM_NO"));
						sorguMap.put("DURUM_KOD", lksJob2);
						sorguMap.put("TARIHCE_AKSIYON", "E");
						sorguMap.put("ISLEM_ACIKLAMA", lMap.get("RESPONSE_MESSAGE"));
						GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
					}
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CREATE_CREDIT_CARD")
	public static GMMap createCreditCard(GMMap iMap)
	{
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap oMap = new GMMap();
		try {
			//BNSPR_OCEAN_CREATE_CARD
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_KK_BASVURU.Get_Card_Info_For_Ocean(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			if (StringUtils.isNotBlank(iMap.getString("TFF_UYE_NO"))) {
				GMMap sorguMap = new GMMap();
				sorguMap.put("TFF_UYE_NO", iMap.getString("TFF_UYE_NO"));
				sorguMap.put("TARGET", "SS");
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_APPROVED_PHOTO_PATH", sorguMap));
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					iMap.put("PHOTO_PATH", sorguMap.getString("TFF_APPROVED_IMAGE_PATH"));
				}
			}
			
			logger.debug("BNSPR_OCEAN_CREATE_CREDIT_CARD INPUT : " + iMap.toString());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_CREDIT_CARD", iMap));
			oMap.put("PRODUCT_ID", iMap.getString("PRODUCT_ID"));
			logger.debug("BNSPR_OCEAN_CREATE_CREDIT_CARD OUTPUT : " + oMap.toString());
			
			//vade yenilemeden geliyorsa kalan vade s�resi kadar uzat, eski vade tarihini al�p 1 sene ekliyoruz
			//Basvuruyu al
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			List<TffBasvuru> basvuruList = (List<TffBasvuru>) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kkBasvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			if (!basvuruList.isEmpty()){
				
				TffBasvuru tffBasvuru = basvuruList.get(0) ;
			
				if ("E".equals(tffBasvuru.getVdBasvuruMu())){
					GMMap visaMap = new GMMap();
					visaMap.put("KART_NO", oMap.getString("CARD_LIST", 0, "CARD_NO"));
					visaMap.put("VD_BASVURU_NO", tffBasvuru.getBasvuruNo());
				    GMServiceExecuter.executeAsync("BNSPR_SKT_ESKI_KART_VADESINI_EKLE" , visaMap);
				}
			}
			
			if ("BASIM".equals(iMap.getString("DURUM_KOD")) && !"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "KK Ocean Card Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
						
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	@GraymoundService("BNSPR_CREATE_CREDIT_CARD_CUSTOMER")
	public static GMMap createCreditCardCustomer(GMMap iMap)
	{
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
 		GMMap oMap = new GMMap();
		try {
			//BNSPR_OCEAN_CREATE_CUSTOMER
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_KK_BASVURU.Get_Customer_Info_For_Ocean(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			
			iMap.put("APPLICATION_NO", iMap.getBigDecimal("BASVURU_NO"));
			logger.debug("BNSPR_OCEAN_CREATE_CUSTOMER INPUT : " + iMap.toString());
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_CUSTOMER", iMap));
			logger.debug("BNSPR_OCEAN_CREATE_CUSTOMER OUTPUT : " + oMap.toString());
			
			if ("BASIM".equals(iMap.getString("DURUM_KOD")) && !"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "KK Ocean Customer Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	public static BigDecimal getGuncelLimitFromLks(BigDecimal basvuruNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_KK_NBSM_5KKB.lks_bilgi (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, basvuruNo);
			stmt.setBigDecimal(i++, BigDecimal.ZERO);
			stmt.setBigDecimal(i++, BigDecimal.valueOf(2));

			stmt.execute();

			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static void tahsisSorguYap(BigDecimal basvuruNo) {

		try {
			// LKS sorgusu yap
			GMMap oMap = new GMMap();


			String func = "{? = call pkg_kk_basvuru_sorgu.RC_GET_LKS_TAHSIS_DATA(?,'01') }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "GIDEN_SORGU_DETAY", BnsprType.NUMBER, basvuruNo);
			if (oMap.isEmpty()) {
				throw new Exception("Kayit Bulunamadi");
			}

			oMap.put("SOYADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "SOYADI"));
			oMap.put("MUSTERI_NO", oMap.getString("GIDEN_SORGU_DETAY", 0, "MUSTERI_NO"));
			oMap.put("IKINCI_ADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "IKINCI_ADI"));
			oMap.put("BABA_ADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "BABA_ADI"));
			oMap.put("TCKN", oMap.getString("GIDEN_SORGU_DETAY", 0, "TCKN"));
			oMap.put("BASVURU_NO", oMap.getString("GIDEN_SORGU_DETAY", 0, "BASVURU_NO"));
			oMap.put("ILK_ADI", oMap.getString("GIDEN_SORGU_DETAY", 0, "ILK_ADI"));
			oMap.put("MANUEL_SORGU", "E");
			oMap.put("SORGU_TIPI", "01");
			GMServiceExecuter.executeNT("BNSPR_QRY3893_LKS_MANUEL_TAHSIS_SORGU_YAP", oMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	
}
