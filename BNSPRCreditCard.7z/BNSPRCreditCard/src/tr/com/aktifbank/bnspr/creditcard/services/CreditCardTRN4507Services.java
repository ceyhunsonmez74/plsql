package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.StdOrderVisaPayment;
import tr.com.aktifbank.bnspr.dao.TalimatliVizeiptalTx;
import tr.com.aktifbank.bnspr.dao.TalimatliVizeiptalTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4507Services {

	@GraymoundService("BNSPR_TRN4507_SAVE")
	public static GMMap trn4507_save(GMMap iMap){
		GMMap oMap= new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			TalimatliVizeiptalTx iptaTx = new TalimatliVizeiptalTx();
			iptaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			iptaTx.setCardNo(iMap.getString("CARD_NO"));
			iptaTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			String status="";
			if(iMap.getString("STATUS").equals("true")){
				status="1";	
			}else{
				status="0";	
			}
			iptaTx.setStatus(status);
			iptaTx.setAdiSoyad(iMap.getString("AD_SOYAD"));
			session.saveOrUpdate(iptaTx);
			session.flush();
			
    		iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			iMap.put("TRX_NAME" , "4507");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		
		catch (Exception e) {
			 throw ExceptionHandler.convertException(e);	
			 }
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4507_GET_INFO")
	public static GMMap trn4507_getInfo (GMMap iMap){
		GMMap oMap= new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		try {
			List<?> iptalTx = session.createCriteria(TalimatliVizeiptalTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i=0;
			for (Object name : iptalTx){
				TalimatliVizeiptalTx iptal= (TalimatliVizeiptalTx) name;
				//oMap.put("TRX_NO", iptal.getTxNo());
				oMap.put("CARD_NO" , iptal.getCardNo());
				oMap.put("MUSTERI_NO", iptal.getMusteriNo());
				oMap.put("STATUS" , iptal.getStatus());
				oMap.put("AD_SOYAD" , iptal.getAdiSoyad());
				i=i+1;
			}
		}
		catch (Exception e) {
			 throw ExceptionHandler.convertException(e);	
			 }
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4507_SORGULA")
	public static GMMap trn4507_sorgula (GMMap imap){
		GMMap oMap= new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			String customerNo="";
			GMMap inputMap = new GMMap();
			inputMap.put("CARD_NO", imap.getString("CARD_NO"));
			GMMap cardMap = new GMMap();
			cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", inputMap);
			// girilen kart numaras� var m�?
			if(cardMap==null){
				oMap.put("RESPONSE", "01");
				oMap.put("RESPONSE_DATA", "kart numaras� bulunmamaktad�r");
				return oMap;
			}
			for (int i = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {
			if(imap.getString("CARD_NO").equals(cardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO")));
			customerNo=(cardMap.getString("CARD_DETAIL_INFO", i, "CUSTOMER_NO"));
			oMap.put("MUSTERI_NO" ,customerNo);
		    BigDecimal bDcustomerNo= new BigDecimal(customerNo);
			
			GnlMusteri musteri =  (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", bDcustomerNo)).uniqueResult();
			if (musteri == null) {
				oMap.put("RESPONSE", "02");
				oMap.put("RESPONSE_DATA", "M��teri Numaras� Bulunamad�.");
				return oMap;
			}
			oMap.put("AD_SOYAD",musteri.getAdi()+ " " +musteri.getSoyadi());
			
			StdOrderVisaPayment payment= (StdOrderVisaPayment) session.createCriteria(StdOrderVisaPayment.class).add(Restrictions.eq("cardNo", imap.getString("CARD_NO"))).uniqueResult();
			if(payment==null){
				oMap.put("RESPONSE", "03");
				oMap.put("RESPONSE_DATA", "Kart Numaras� Bulunamad�.");
				return oMap;
			}
			oMap.put("STATUS", payment.isStatus());
			
			}
		}
		catch (Exception e) {
			 throw ExceptionHandler.convertException(e);	
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4507_AFTER_APPROVAL")
	public static GMMap trn4507_afterApproval (GMMap iMap){
		GMMap oMap= new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		try {
			
			TalimatliVizeiptalTx iptalTx = (TalimatliVizeiptalTx) session.createCriteria(TalimatliVizeiptalTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			  if(iptalTx== null){
		        	oMap.put("RESPONSE_DATA", "Girilen i�lem numaras� ile kay�t bulunamad�.");
		        	oMap.put("RESPONSE", "05");
		        	return oMap;
		        }
			
			
			StdOrderVisaPayment payment = (StdOrderVisaPayment) session.createCriteria(StdOrderVisaPayment.class).add(Restrictions.eq("cardNo", iptalTx.getCardNo())).add(Restrictions.eq("status", true)).uniqueResult();
			if(payment== null){
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Kart bulunamad� ya da daha �nce otomatik vizeleme iptal yap�ld�.");
				oMap.put("RESPONSE_DATA", "Kart bulunamad� ya da daha �nce otomatik vizeleme iptal yap�ld�.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			payment.setStatus(false);
			session.saveOrUpdate(payment);
			session.flush();
			iptalTx.setStatus("0");
			session.saveOrUpdate(iptalTx);
			session.flush();
			
			
			oMap.put("RESPONSE_DATA", "Otomatik vizeleme talimat� iptal edildi.");
			oMap.put("RESPONSE", "2");

		}
		catch (Exception e) {
			 throw ExceptionHandler.convertException(e);			}
		
		
		return oMap;
	}
	
}
