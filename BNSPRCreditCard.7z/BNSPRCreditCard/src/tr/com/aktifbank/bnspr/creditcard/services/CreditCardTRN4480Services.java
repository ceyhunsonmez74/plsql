package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaDty;
import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4480Services{
	@GraymoundService("BNSPR_TRN4480_INSERT_DATA")
	public static GMMap insertData (GMMap iMap){
		GMMap oMap =new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaBkmTakasKapamaTx stx = (SbaBkmTakasKapamaTx) session.createCriteria(SbaBkmTakasKapamaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (stx !=null){
				session.delete(stx);
				session.flush();
			}
			
			SbaBkmTakasKapamaTx kapama = new SbaBkmTakasKapamaTx();
			kapama.setBankaNetIslemTutari(iMap.getBigDecimal("BANKA_NET_ISLEM_TUTARI"));
			kapama.setEftGonderilsinMi(iMap.getBoolean("EFT_GONDERILSIN_MI")==true?"E":"H");
			kapama.setGelenBankaKartiAdet(iMap.getBigDecimal("GELEN_BANKA_KARTI_ADET"));
			kapama.setGelenBankaKartiTakas(iMap.getBigDecimal("GELEN_BANKA_KARTI_TAKAS"));
			kapama.setGelenBankaKartiTutar(iMap.getBigDecimal("GELEN_BANKA_KARTI_TUTAR"));
			kapama.setGelenBankaKomYuvarlama(iMap.getBigDecimal("GELEN_BANKA_KOM_YUVARLAMA"));
			kapama.setGelenKrediKartiAdet(iMap.getBigDecimal("GELEN_KREDI_KARTI_ADET"));
			kapama.setGelenKrediKartiTakas(iMap.getBigDecimal("GELEN_KREDI_KARTI_TAKAS"));
			kapama.setGelenKrediKartiTutar(iMap.getBigDecimal("GELEN_KREDI_KARTI_TUTAR"));
			kapama.setGelenKrediKomYuvarlama(iMap.getBigDecimal("GELEN_KREDI_KOM_YUVARLAMA"));
			kapama.setGelenToplamAdet(iMap.getBigDecimal("GELEN_TOPLAM_ADET"));
			kapama.setGelenToplamTakas(iMap.getBigDecimal("GELEN_TOPLAM_TAKAS"));
			kapama.setGelenToplamTutar(iMap.getBigDecimal("GELEN_TOPLAM_TUTAR"));
			kapama.setGidenBankaKartiAdet(iMap.getBigDecimal("GIDEN_BANKA_KARTI_ADET"));
			kapama.setGidenBankaKartiTakas(iMap.getBigDecimal("GIDEN_BANKA_KARTI_TAKAS"));
			kapama.setGidenBankaKartiTutar(iMap.getBigDecimal("GIDEN_BANKA_KARTI_TUTAR"));
			kapama.setGidenBankaKomYuvarlama(iMap.getBigDecimal("GIDEN_BANKA_KOM_YUVARLAMA"));
			kapama.setGidenKrediKartiAdet(iMap.getBigDecimal("GIDEN_KREDI_KARTI_ADET"));
			kapama.setGidenKrediKartiTakas(iMap.getBigDecimal("GIDEN_KREDI_KARTI_TAKAS"));
			kapama.setGidenKrediKartiTutar(iMap.getBigDecimal("GIDEN_KREDI_KARTI_TUTAR"));
			kapama.setGidenKrediKomYuvarlama(iMap.getBigDecimal("GIDEN_KREDI_KOM_YUVARLAMA"));
			kapama.setGidenToplamAdet(iMap.getBigDecimal("GIDEN_TOPLAM_ADET"));
			kapama.setGidenToplamTakas(iMap.getBigDecimal("GIDEN_TOPLAM_TAKAS"));
			kapama.setGidenToplamTutar(iMap.getBigDecimal("GIDEN_TOPLAM_TUTAR"));
			kapama.setKrediNetIslemTutari(iMap.getBigDecimal("KREDI_NET_ISLEM_TUTARI"));
			kapama.setTarih(iMap.getDate("TARIH"));
			kapama.setToplamNetIslemTutari(iMap.getBigDecimal("TOPLAM_NET_ISLEM_TUTARI"));
			kapama.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kapama.setYuvarlamaFarki(iMap.getBigDecimal("YUVARLAMA_FARKI"));
			session.saveOrUpdate(kapama);
			session.flush();
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4480_FIS_OLUSTUR")
	public static GMMap fisOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal gidenBankaTutar= BigDecimal.ZERO;
			BigDecimal gidenKrediKartiTutar= BigDecimal.ZERO;
			BigDecimal gelenBankaTutar= BigDecimal.ZERO;
			BigDecimal gelenKrediKartiTutar= BigDecimal.ZERO;
			int i = 0;
			SbaBkmTakasKapamaTx stx = (SbaBkmTakasKapamaTx) session.createCriteria(SbaBkmTakasKapamaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			List<?> dtx = session.createCriteria(SbaBkmTakasKapamaDty.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for(Object name:dtx){
				SbaBkmTakasKapamaDty detay =(SbaBkmTakasKapamaDty)name;
				session.delete(detay);
			}
			session.flush();
			SbaBkmTakasKapamaDty dty = new SbaBkmTakasKapamaDty();
			gidenBankaTutar = stx.getGidenBankaKartiTutar().add(stx.getGidenBankaKartiTakas());
			if (gidenBankaTutar.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("SBA_BKM_DEBIT_DESC"));
				
				dty.setDkhesapno(getGlobalParam("SBA_BKM_DEBIT_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));

				if(gidenBankaTutar.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(gidenBankaTutar);
				}
				else{
					dty.setBa("B");
					dty.setTutar(gidenBankaTutar.multiply(BigDecimal.valueOf(-1)));
				}
				session.saveOrUpdate(dty);
			}
			gidenKrediKartiTutar = stx.getGidenKrediKartiTutar().add(stx.getGidenKrediKartiTakas());
			if(gidenKrediKartiTutar.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("SBA_BKM_KREDI_DESC"));
				dty.setDkhesapno(getGlobalParam("SBA_BKM_KREDI_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(gidenKrediKartiTutar.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(gidenKrediKartiTutar);
				}
				else{
					dty.setBa("B");
					dty.setTutar(gidenKrediKartiTutar.multiply(BigDecimal.valueOf(-1)));
				}
				session.saveOrUpdate(dty);
			}
			gelenBankaTutar = stx.getGelenBankaKartiTutar().add(stx.getGelenBankaKartiTakas());
			if(gelenBankaTutar.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("SBA_BKM_TFF_DESC"));
				dty.setDkhesapno(getGlobalParam("SBA_BKM_TFF_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(gelenBankaTutar.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(gelenBankaTutar);
				}
				else{
					dty.setBa("B");
					dty.setTutar(gelenBankaTutar.multiply(BigDecimal.valueOf(-1)));
				}
				session.saveOrUpdate(dty);
			}
			gelenKrediKartiTutar = stx.getGelenKrediKartiTutar().add(stx.getGelenKrediKartiTakas());
			if(gelenKrediKartiTutar.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("SBA_BKM_KK_DESC"));
				dty.setDkhesapno(getGlobalParam("SBA_BKM_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(gelenKrediKartiTutar.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(gelenKrediKartiTutar);
				}
				else{
					dty.setBa("B");
					dty.setTutar(gelenKrediKartiTutar.multiply(BigDecimal.valueOf(-1)));
				}
				session.saveOrUpdate(dty);
			}
			
			BigDecimal tutar = BigDecimal.ZERO;
			BigDecimal bankaYuvarlama = BigDecimal.ZERO;
			BigDecimal krediYuvarlama = BigDecimal.ZERO;
			
			bankaYuvarlama = stx.getGelenBankaKomYuvarlama().add(stx.getGidenBankaKomYuvarlama());
			krediYuvarlama = stx.getGelenKrediKomYuvarlama().add(stx.getGidenKrediKomYuvarlama());
			
			tutar= stx.getToplamNetIslemTutari().add(stx.getYuvarlamaFarki().add(bankaYuvarlama.add(krediYuvarlama)));
			if(tutar.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_HESAP_DESC"));
				dty.setHesapno(BigDecimal.valueOf(Long.valueOf(getGlobalParam("BKM_HESAP"))));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("VS");
				dty.setSubekodu("998");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(tutar.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("B");
					dty.setTutar(stx.getToplamNetIslemTutari());
				}
				else{
					dty.setBa("A");
					dty.setTutar(stx.getToplamNetIslemTutari().multiply(BigDecimal.valueOf(-1)));
				}
				session.saveOrUpdate(dty);
			}
			if(stx.getYuvarlamaFarki().compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_DESC"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(stx.getYuvarlamaFarki().compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(stx.getYuvarlamaFarki());
					dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_ARTI"));
				}
				else{
					dty.setBa("B");
					dty.setTutar(stx.getYuvarlamaFarki().multiply(BigDecimal.valueOf(-1)));
					dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_EKSI"));
				}
				session.saveOrUpdate(dty);
			}
			if(bankaYuvarlama.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_FARKI_DEBIT_DESC"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(bankaYuvarlama.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(bankaYuvarlama);
					dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_ARTI"));
				}
				else{
					dty.setBa("B");
					dty.setTutar(bankaYuvarlama.multiply(BigDecimal.valueOf(-1)));
					dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_EKSI"));
				}
				session.saveOrUpdate(dty);
			}
			if(bankaYuvarlama.compareTo(BigDecimal.ZERO)>0){
				dty = new SbaBkmTakasKapamaDty();
				BigDecimal bsmvTutar = BigDecimal.ZERO;
				GMMap bMap = new GMMap();
				bMap.put("TUTAR", bankaYuvarlama);
				bMap = GMServiceExecuter.call("BNSPR_BSMV_HESAPLA", bMap);
				bsmvTutar= bMap.getBigDecimal("BSMV_TUTAR");
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_FARKI_DBT_DSC_B"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("A");
				dty.setTutar(bsmvTutar);
				dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_BSMV"));
				
				session.saveOrUpdate(dty);
				
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_FARKI_DBT_DSC_B"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bsmvTutar);
				dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_BSMV_GIDER"));
				
				session.saveOrUpdate(dty);
			}
			if(krediYuvarlama.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_FARKI_KRD_DSC_B"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				if(krediYuvarlama.compareTo(BigDecimal.ZERO)>0){
					dty.setBa("A");
					dty.setTutar(krediYuvarlama);
					dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_ARTI"));
				}
				else{
					dty.setBa("B");
					dty.setTutar(krediYuvarlama.multiply(BigDecimal.valueOf(-1)));
					dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_EKSI"));
				}
				session.saveOrUpdate(dty);
			}
			if(krediYuvarlama.compareTo(BigDecimal.ZERO)>0){
				dty = new SbaBkmTakasKapamaDty();
				BigDecimal bsmvTutar = BigDecimal.ZERO;
				GMMap bMap = new GMMap();
				bMap.put("TUTAR", krediYuvarlama);
				bMap = GMServiceExecuter.call("BNSPR_BSMV_HESAPLA", bMap);
				bsmvTutar= bMap.getBigDecimal("BSMV_TUTAR");
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_FARKI_KREDI_B_DESC"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("A");
				dty.setTutar(bsmvTutar);
				dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_BSMV"));
				
				session.saveOrUpdate(dty);
				
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama(getGlobalParam("BKM_YUVARLAMA_FARKI_KREDI_B_DESC"));
				
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(stx.getTxNo());
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bsmvTutar);
				dty.setDkhesapno(getGlobalParam("BKM_YUVARLAMA_DK_BSMV_GIDER"));
				
				session.saveOrUpdate(dty);
			}
			session.flush();
			String func = "{? = call PKG_TRN4480.fis_satirlarini_getir(?)}";
            Object[] inputValues = new Object[2] ;
            inputValues[0]=BnsprType.NUMBER;
            inputValues[1]=iMap.getBigDecimal("TRX_NO");
            oMap = DALUtil.callOracleRefCursorFunction(func , "FISBILGISI" , inputValues);
            int s = oMap.getSize("FISBILGISI");
            BigDecimal LC_ALACAK = BigDecimal.ZERO;
            BigDecimal LC_BORC = BigDecimal.ZERO;
            BigDecimal LC_BALANS = BigDecimal.ZERO;
            		
            for (int j = 0; j < s; j++) {
            	if (oMap.getString("FISBILGISI",j,"BA").equals("A")){
            		LC_ALACAK = LC_ALACAK.add(oMap.getBigDecimal("FISBILGISI",j,"TUTAR"));
            	}
            	else if (oMap.getString("FISBILGISI",j,"BA").equals("B")){
            		LC_BORC = LC_BORC.add(oMap.getBigDecimal("FISBILGISI",j,"TUTAR"));
            	}
			}
            LC_BALANS = LC_ALACAK.subtract(LC_BORC);
            LC_BORC = LC_BORC.multiply(BigDecimal.valueOf(-1));
            oMap.put("LC_ALACAK", LC_ALACAK);
            oMap.put("LC_BORC", LC_BORC);
            oMap.put("LC_BALANS", LC_BALANS);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4480_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaBkmTakasKapamaTx stx = (SbaBkmTakasKapamaTx) session.createCriteria(SbaBkmTakasKapamaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			stx.setLcAlacak(iMap.getBigDecimal("LC_ALACAK"));
			stx.setLcBalans(iMap.getBigDecimal("LC_BALANS"));
			stx.setLcBorc(iMap.getBigDecimal("LC_BORC"));
			session.saveOrUpdate(stx);
			List<?> dtx = session.createCriteria(SbaBkmTakasKapamaDty.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for(Object name:dtx){
				SbaBkmTakasKapamaDty detay =(SbaBkmTakasKapamaDty)name;
				session.delete(detay);
			}
			int s=0;
			s = iMap.getSize("FISBILGISI");
			SbaBkmTakasKapamaDty dty = null;
			for (int i = 0; i < s; i++) {
				dty = new SbaBkmTakasKapamaDty();
				dty.setAciklama(iMap.getString("FISBILGISI",i,"ACIKLAMA"));
				dty.setBa(iMap.getString("FISBILGISI",i,"BA"));
				dty.setDkhesapno(iMap.getString("FISBILGISI",i,"DKHESAPNO"));
				dty.setDovizcinsi(iMap.getString("FISBILGISI",i,"DOVIZCINSI"));
				dty.setHesapno(iMap.getBigDecimal("FISBILGISI",i,"HESAPNO"));
				dty.setHesaptur(iMap.getString("FISBILGISI",i,"HESAPTUR"));
				dty.setSiraNo(BigDecimal.valueOf(Long.valueOf(i+1)));
				dty.setSubekodu(iMap.getString("FISBILGISI",i,"SUBEKODU"));
				dty.setTutar(iMap.getBigDecimal("FISBILGISI",i,"TUTAR"));
				dty.setTxNo(iMap.getBigDecimal("TRX_NO"));
				session.saveOrUpdate(dty);
			}
			session.flush();
			iMap.put("TRX_NAME" , "4480");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4480_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap =new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaBkmTakasKapamaTx stx = (SbaBkmTakasKapamaTx) session.createCriteria(SbaBkmTakasKapamaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("BANKA_NET_ISLEM_TUTARI",stx.getBankaNetIslemTutari());
			oMap.put("EFT_GONDERILSIN_MI",stx.getEftGonderilsinMi().equals("E")? true:false);
			oMap.put("GELEN_BANKA_KARTI_ADET",stx.getGelenBankaKartiAdet());
			oMap.put("GELEN_BANKA_KARTI_TUTAR",stx.getGelenBankaKartiTutar());
			oMap.put("GELEN_BANKA_KARTI_TAKAS",stx.getGelenBankaKartiTakas());
			oMap.put("GELEN_BANKA_KOM_YUVARLAMA",stx.getGelenBankaKomYuvarlama());
			oMap.put("GELEN_KREDI_KARTI_ADET",stx.getGelenKrediKartiAdet());
			oMap.put("GELEN_KREDI_KARTI_TAKAS",stx.getGelenKrediKartiTakas());
			oMap.put("GELEN_KREDI_KARTI_TUTAR",stx.getGelenKrediKartiTutar());
			oMap.put("GELEN_KREDI_KOM_YUVARLAMA",stx.getGelenKrediKomYuvarlama());
			oMap.put("GELEN_TOPLAM_ADET",stx.getGelenToplamAdet());
			oMap.put("GELEN_TOPLAM_TAKAS",stx.getGelenToplamTakas());
			oMap.put("GELEN_TOPLAM_TUTAR",stx.getGelenToplamTutar());
			oMap.put("GIDEN_BANKA_KARTI_ADET",stx.getGidenBankaKartiAdet());
			oMap.put("GIDEN_BANKA_KARTI_TAKAS",stx.getGidenBankaKartiTakas());
			oMap.put("GIDEN_BANKA_KARTI_TUTAR",stx.getGidenBankaKartiTutar());
			oMap.put("GIDEN_BANKA_KOM_YUVARLAMA",stx.getGidenBankaKomYuvarlama());
			oMap.put("GIDEN_KREDI_KARTI_ADET",stx.getGidenKrediKartiAdet());
			oMap.put("GIDEN_KREDI_KARTI_TAKAS",stx.getGidenKrediKartiTakas());
			oMap.put("GIDEN_KREDI_KARTI_TUTAR",stx.getGidenKrediKartiTutar());
			oMap.put("GIDEN_KREDI_KOM_YUVARLAMA",stx.getGidenKrediKomYuvarlama());
			oMap.put("GIDEN_TOPLAM_ADET",stx.getGidenToplamAdet());
			oMap.put("GIDEN_TOPLAM_TAKAS",stx.getGidenToplamTakas());
			oMap.put("GIDEN_TOPLAM_TUTAR",stx.getGidenToplamTutar());
			oMap.put("KREDI_NET_ISLEM_TUTARI",stx.getKrediNetIslemTutari());
			oMap.put("TARIH",stx.getTarih());
			oMap.put("TOPLAM_NET_ISLEM_TUTARI",stx.getToplamNetIslemTutari());
			oMap.put("YUVARLAMA_FARKI",stx.getYuvarlamaFarki());
			oMap.put("LC_ALACAK",stx.getLcAlacak());
			oMap.put("LC_BALANS",stx.getLcBalans());
			oMap.put("LC_BORC",stx.getLcBorc());
			GMMap oMap2 = new GMMap();
			String func = "{? = call PKG_TRN4480.fis_satirlarini_getir(?)}";
            Object[] inputValues = new Object[2] ;
            inputValues[0]=BnsprType.NUMBER;
            inputValues[1]=iMap.getBigDecimal("TRX_NO");
            oMap2 = DALUtil.callOracleRefCursorFunction(func , "FISBILGISI" , inputValues);
            oMap.put("FISBILGISI", oMap2.get("FISBILGISI"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", batchParamCode);
		String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return batchNo;
	}
	@GraymoundService("BNSPR_TRN4480_FIS_HESAPLA")
	public static GMMap hesapla (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			BigDecimal lcAlacak = BigDecimal.ZERO;
			BigDecimal lcBorc = BigDecimal.ZERO;
			BigDecimal lcBalans = BigDecimal.ZERO;
			int s= iMap.getSize("FISBILGISI");
			for (int i = 0; i < s; i++) {
				if (iMap.getString("FISBILGISI", i , "BA").equals("A")){
					lcAlacak = lcAlacak.add(iMap.getBigDecimal("FISBILGISI",i,"TUTAR"));
				}
				else if(iMap.getString("FISBILGISI", i , "BA").equals("B")){
					lcBorc = lcBorc.add(iMap.getBigDecimal("FISBILGISI",i,"TUTAR"));
				}
					
			}
			lcBalans = lcAlacak.subtract(lcBorc);
			oMap.put("LC_ALACAK", lcAlacak);
			oMap.put("LC_BORC", lcBorc);
			oMap.put("LC_BALANS", lcBalans);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4480_DK_BAKIYE_GETIR")
	public static GMMap dkBakiyeGetir(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(iMap.getDate("TARIH"));
			cal.add(Calendar.DAY_OF_YEAR, -1);
			Date tarih = cal.getTime();
			String hesap_no = "278900200";
			String sube = "998";
			BigDecimal ttr278900200 = getDkBakiye(hesap_no, sube, tarih);
			hesap_no="278900210";
			BigDecimal ttr278900210 = getDkBakiye(hesap_no, sube, tarih);
			hesap_no="390909010";
			BigDecimal ttr390909010 = getDkBakiye(hesap_no, sube, tarih);
			sube="997";
			hesap_no="390909032";
			BigDecimal ttr390909032 = getDkBakiye(hesap_no, sube, tarih);
			
			oMap.put("TTR278900200", ttr278900200);
			oMap.put("TTR278900210", ttr278900210);
			oMap.put("TTR390909010", ttr390909010);
			oMap.put("TTR390909032", ttr390909032);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	public static BigDecimal getDkBakiye(String hesapNo, String sube, Date tarih){
		try {

			Object[] inputValues = new Object[8];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = hesapNo;
			inputValues[2] = BnsprType.STRING;
			inputValues[3] = sube;
			inputValues[4] = BnsprType.DATE;
			inputValues[5] = tarih;
			inputValues[6] = BnsprType.STRING;
			inputValues[7] = "TRY";
			String func = "{? = call  pkg_hp.DevirBakiye(?,?,?,?)}";
			
			return (BigDecimal)DALUtil.callOracleFunction(func,BnsprType.NUMBER , inputValues);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}

}
