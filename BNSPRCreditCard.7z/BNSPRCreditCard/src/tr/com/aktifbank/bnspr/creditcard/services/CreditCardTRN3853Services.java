package tr.com.aktifbank.bnspr.creditcard.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SamanBankListe;
import tr.com.aktifbank.bnspr.dao.SamanBankListeId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN3853Services {
    
    @GraymoundService("BNSPR_TRN3853_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        oMap.put("RESPONSE" , AkustikConstants.RESPONSE_FAIL);
        
        try{
            /* if (iMap.get("DOSYA") == null) {
                CreditCardServicesUtil.raiseGMError("330", "Dosya");
            } */
            if (iMap.get("DOSYA") != null){
                
          
            
            // 2. Excel kolon sayisi kontrol
            
            // kart no, adi,ikinci adi, soyadi, pasaport, telefon no
            int kolonSayisi = 9;
            // 3. Excelden datalari al
            GMMap excelMap = new GMMap();
            excelMap.put("DOSYA" , iMap.get("DOSYA"));
            excelMap.put("KOLON_SAYISI" , kolonSayisi);
            excelMap.put("BASLIK_VAR_MI" , CreditCardServicesUtil.EVET);
            excelMap.putAll(GMServiceExecuter.execute("BNSPR_EXCEL_TO_LIST" , excelMap));// TABLE
            // Kontrol
            String excelTableName = "TABLE";
            if (excelMap.get(excelTableName) == null || excelMap.getSize(excelTableName) < 1){
                CreditCardServicesUtil.raiseGMError("660" , "Dosya icerisinde data bulunamadi");
            }
            
            // 4. Alinan datalari havuza kaydet
           // Session session = DAOSession.getSession("BNSPRDal");
            for (int i = 0; i < excelMap.getSize(excelTableName); i++){
                
                try{
                    
                    SamanBankListeId id = new SamanBankListeId();
                    id.setCardNo(excelMap.getString(excelTableName , i , "CARD_NO").trim());
                    // id.setMusteriNo(excelMap.getBigDecimal(excelTableName, i, "MUSTERI_NO"));
                    id.setPasaportNo(excelMap.getString(excelTableName , i , "PASAPORT_NO").trim());
                    SamanBankListe samanBankRecord = new SamanBankListe();
                    samanBankRecord.setId(id);
                    samanBankRecord.setAdi(StringUtils.isNotBlank(excelMap.getString(excelTableName , i , "ADI")) ? excelMap.getString(excelTableName , i , "ADI").trim() : "");
                    samanBankRecord.setIkinciAdi(StringUtils.isNotBlank(excelMap.getString(excelTableName , i , "IKINCI_ADI")) ? excelMap.getString(excelTableName , i , "IKINCI_ADI").trim() : "");
                    samanBankRecord.setSoyadi(StringUtils.isNotBlank(excelMap.getString(excelTableName , i , "SOYADI")) ? excelMap.getString(excelTableName , i , "SOYADI").trim() : "");
                    samanBankRecord.setTelefon(StringUtils.isNotBlank(excelMap.getString(excelTableName , i , "TELEFON")) ? excelMap.getString(excelTableName , i , "TELEFON").trim() : "");
                    samanBankRecord.setPasaportVerTarih(StringUtils.isNotBlank(excelMap.getString(excelTableName , i , "PASAPORT_VERILME_TARIHI")) ? excelMap.getString(excelTableName , i ,
                            "PASAPORT_VERILME_TARIHI").trim() : "");
                    samanBankRecord.setPasaportVerYer(StringUtils.isNotBlank(excelMap.getString(excelTableName , i , "PAS_VERILDIGI_YER")) ? excelMap.getString(excelTableName , i ,
                            "PAS_VERILDIGI_YER").trim() : "");
                    samanBankRecord.setStatus("1"); // Eklendi
                    samanBankRecord.setCinsiyet(excelMap.getString(excelTableName , i , "CINSIYET").trim()); // Eklendi
                    
                    // session.saveOrUpdate(samanBankRecord);
                    
                    GMMap saveMap = new GMMap();
                    saveMap.clear();
                    saveValuesFirstTimeNT(saveMap , samanBankRecord);
                } catch (Exception e){
                    // TODO Auto-generated catch block
                    throw new GMRuntimeException(38531 , e.getMessage());
                }
                
            }
           }
            
         GMServiceExecuter.call("BNSPR_TRN3853_START_PROCESS" , iMap);
        } catch (Exception e){
            
            throw new GMRuntimeException(38532 , e.getMessage());
        }
        
        oMap.put("RESPONSE" , AkustikConstants.RESPONSE_SUCCESS);
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3853_START_PROCESS")
    public static GMMap startProcess(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        // ilk asamada Eklenen kartlar�n kontakt musterilini olusturuyoruz
        List<SamanBankListe> musteriOlusturulacakListe = session.createCriteria(SamanBankListe.class).add(Restrictions.eq("status" , "1")).list();
        GMMap kontaktMap = new GMMap();
        GMMap createCustomerMap = new GMMap();
        GMMap matchCardAndCustomerMap = new GMMap();
        GMMap saveMap = new GMMap();
        DateFormat formatter = new SimpleDateFormat("ddMMyyyy");
        
        for (SamanBankListe samanBankListe : musteriOlusturulacakListe){
            try{
                kontaktMap.clear();
                
                // M��teri yarat BNSPR_CUST_CREATE_GERCEK_MUSTERI
                kontaktMap.put("MUSTERI_KONTAKT" , "K");
                kontaktMap.put("UYRUK_KOD" , "IR");
                kontaktMap.put("ISIM" , samanBankListe.getAdi());
                kontaktMap.put("SOYADI" , samanBankListe.getSoyadi());
                kontaktMap.put("IKINCI_ISIM" , samanBankListe.getIkinciAdi());
                kontaktMap.put("PASAPORT_NO" , samanBankListe.getId().getPasaportNo());
                kontaktMap.put("PAS_VERILDIGI_YER" , samanBankListe.getPasaportVerYer());
                kontaktMap.put("PAS_VERILDIGI_TARIH" , formatter.parse(samanBankListe.getPasaportVerTarih()));
                
                kontaktMap.putAll(GMServiceExecuter.executeNT("BNSPR_CUST_CREATE_GERCEK_MUSTERI" , kontaktMap));
                
                samanBankListe.setStatus("2"); // m��teri acildi
          
                // id.setMusteriNo(iMa) m�steri no doldur
                samanBankListe.setMusteriNo(kontaktMap.getBigDecimal("MUSTERI_NO"));
                
            } catch (Exception e){
                e.printStackTrace();
                
                samanBankListe.setErrorDesc("Musteri Acilamadi " + e.getMessage());
            } finally{
                saveMap.clear();
                saveValuesNT(saveMap , samanBankListe);
                
            }
        }
    //    session.flush();
        
        List<SamanBankListe> kartTarafindaMusteriAcilacakListe = session.createCriteria(SamanBankListe.class).add(Restrictions.eq("status" , "2")).list();
        for (SamanBankListe samanBankListe : kartTarafindaMusteriAcilacakListe){
            try{
                createCustomerMap.clear();
                
                createCustomerMap.put("CUSTOMER_NO" , samanBankListe.getMusteriNo());
                createCustomerMap.put("NAME" , samanBankListe.getAdi());
                createCustomerMap.put("MID_NAME" , samanBankListe.getIkinciAdi());
                createCustomerMap.put("SUR_NAME" , samanBankListe.getSoyadi());
                createCustomerMap.put("ADRS_HOME_CITY" , "�STANBUL");
                createCustomerMap.put("ADRS_HOME_COUNTRY" , "IR");
                createCustomerMap.put("ADRS_HOME1" , "Aktifbank");
                createCustomerMap.put("GENDER" , samanBankListe.getCinsiyet());
                createCustomerMap.put("SEND_EMAIL" , OceanConstants.No);
                createCustomerMap.put("SEND_SMS" , OceanConstants.No);
                createCustomerMap.put("CUSTOMER_TYPE" , "100");
                createCustomerMap.put("CUSTOMER_GROUP" , "N");
                createCustomerMap.put("MAIN_BRANCH" , "444");
                createCustomerMap.put("ADRS_HOME_CITY_CODE" , "999");
                createCustomerMap.put("NATIONALITY" , "IR");
                createCustomerMap.put("ADRS_WORK1" , " ");
                createCustomerMap.put("ADRS_WORK2" , " ");
                createCustomerMap.put("ADRS_WORK3" , " ");
                createCustomerMap.put( "CARD_NO" , samanBankListe.getId().getCardNo());
                
                createCustomerMap = GMServiceExecuter.call("BNSPR_OCEAN_CREATE_CUSTOMER" , createCustomerMap);
                
                if ("2".equals(createCustomerMap.getString("RETURN_CODE"))){
                    samanBankListe.setStatus("3");
                } else{
                    samanBankListe.setErrorDesc(createCustomerMap.getString("RETURN_DESCRIPTION"));
                }
                
                // kart tarafinda musteri yaratildi
                
                // id.setMusteriNo(iMa) m�steri no doldur
                
            } catch (Exception e){
                e.printStackTrace();
                
                samanBankListe.setErrorDesc("Kart tarafinda musteri acilamadi " + e.getMessage());
            } finally{
                saveMap.clear();
                saveValuesNT(saveMap , samanBankListe);
                
            }
        }
        
       /// session.flush();
        
        List<SamanBankListe> matchCardAndCustomerList = session.createCriteria(SamanBankListe.class).add(Restrictions.eq("status" , "3")).list();
        for (SamanBankListe samanBankListe : matchCardAndCustomerList){
            try{
                // M��teri ac
                
                matchCardAndCustomerMap.clear();
                
             //   matchCardAndCustomerMap = GMServiceExecuter.call("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER" , matchCardAndCustomerMap);
               // matchCardAndCustomerMap.put("CUSTOMER_NO" , samanBankListe.getId().getMusteriNo());
                matchCardAndCustomerMap.put("CUSTOMER_NO" , samanBankListe.getMusteriNo());
                matchCardAndCustomerMap.put("BANK_ACCOUNT_NO" , "0");
                matchCardAndCustomerMap.put("APPLICATION_NO" , "0");
                matchCardAndCustomerMap.put("BOX_OFFICE_ID" , "123");
                matchCardAndCustomerMap.put("TXN_TYPE" , "N");
                matchCardAndCustomerMap.put("CARD_NO" , samanBankListe.getId().getCardNo());
  
                matchCardAndCustomerMap.put("NAME" , samanBankListe.getAdi()+" "+samanBankListe.getSoyadi());
                matchCardAndCustomerMap = GMServiceExecuter.call("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER" , matchCardAndCustomerMap);
                
                samanBankListe.setStatus("4");
                
                // MATCH CARD AND CUSTOMER oldu
                
                // id.setMusteriNo(iMa) m�steri no doldur
                
            } catch (Exception e){
                e.printStackTrace();
                
                samanBankListe.setErrorDesc("match card and customer calismadi " + e.getMessage());
                
            } finally{
                saveMap.clear();
                saveValuesNT(saveMap , samanBankListe);
                
            }
        }
        
      //  session.flush();
        oMap.put("MESSAGE" , "PROCESS BITTI ");
        return oMap;
    }
    
    private static void saveValuesNT(GMMap saveMap, SamanBankListe samanBankListe) {
        saveMap.put("ADI" , samanBankListe.getAdi());
        saveMap.put("ERROR_DESC" , samanBankListe.getErrorDesc());
        saveMap.put("IKINCI_ADI" , samanBankListe.getIkinciAdi());
        saveMap.put("PASAPORT_VER_TAR" , samanBankListe.getPasaportVerTarih());
        saveMap.put("PASAPORT_VER_YER" , samanBankListe.getPasaportVerYer());
        saveMap.put("SOYADI" , samanBankListe.getSoyadi());
        saveMap.put("STATUS" , samanBankListe.getStatus());
        saveMap.put("TELEFON" , samanBankListe.getTelefon());
        saveMap.put("CARD_NO" , samanBankListe.getId().getCardNo());
        saveMap.put("MUSTERI_NO" , samanBankListe.getMusteriNo());
        saveMap.put("PASAPORT_NO" , samanBankListe.getId().getPasaportNo());
        saveMap.put("CINSIYET" , samanBankListe.getCinsiyet());
        GMServiceExecuter.executeNT("BNSPR_TRN3853_PERSISTENCE_UPDATE" , saveMap);
        
    }
    
    private static void saveValuesFirstTimeNT(GMMap saveMap, SamanBankListe samanBankListe) {
        saveMap.put("ADI" , samanBankListe.getAdi());
        saveMap.put("ERROR_DESC" , samanBankListe.getErrorDesc());
        saveMap.put("IKINCI_ADI" , samanBankListe.getIkinciAdi());
        saveMap.put("PASAPORT_VER_TAR" , samanBankListe.getPasaportVerTarih());
        saveMap.put("PASAPORT_VER_YER" , samanBankListe.getPasaportVerYer());
        saveMap.put("SOYADI" , samanBankListe.getSoyadi());
        saveMap.put("STATUS" , samanBankListe.getStatus());
        saveMap.put("TELEFON" , samanBankListe.getTelefon());
        saveMap.put("CARD_NO" , samanBankListe.getId().getCardNo());
        saveMap.put("MUSTERI_NO" , samanBankListe.getMusteriNo());
        saveMap.put("PASAPORT_NO" , samanBankListe.getId().getPasaportNo());
        saveMap.put("CINSIYET" , samanBankListe.getCinsiyet());
        GMServiceExecuter.executeNT("BNSPR_TRN3853_PERSISTENCE_SAVE" , saveMap);
        
    }
    
    
    @GraymoundService("BNSPR_TRN3853_PERSISTENCE_SAVE")
    public static GMMap persistenceSave(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
           
          
                SamanBankListe samanBankRecord = new SamanBankListe();
                samanBankRecord.setAdi(iMap.getString("ADI"));
                samanBankRecord.setErrorDesc(iMap.getString("ERROR_DESC"));
                samanBankRecord.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                SamanBankListeId id = new SamanBankListeId();
                id.setCardNo(iMap.getString("CARD_NO"));
                //id.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                id.setPasaportNo(iMap.getString("PASAPORT_NO"));
                samanBankRecord.setIkinciAdi(iMap.getString("IKINCI_ADI"));
                samanBankRecord.setPasaportVerTarih(iMap.getString("PASAPORT_VER_TAR"));
                samanBankRecord.setPasaportVerYer(iMap.getString("PASAPORT_VER_YER"));
                samanBankRecord.setSoyadi(iMap.getString("SOYADI"));
                samanBankRecord.setStatus(iMap.getString("STATUS"));
                samanBankRecord.setTelefon(iMap.getString("TELEFON"));
                samanBankRecord.setCinsiyet(iMap.getString("CINSIYET"));
                samanBankRecord.setId(id);
                session.save(samanBankRecord);
               // session.flush();
     
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        finally {
           
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3853_PERSISTENCE_UPDATE")
    public static GMMap persistenceUpdate(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
           
               SamanBankListe samanBankList = (SamanBankListe) session.createCriteria(SamanBankListe.class).add(Restrictions.eq("id.pasaportNo" , iMap.getString("PASAPORT_NO"))).uniqueResult();
       
                samanBankList.setAdi(iMap.getString("ADI"));
                samanBankList.setErrorDesc(iMap.getString("ERROR_DESC"));
                samanBankList.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                
                SamanBankListeId id = new SamanBankListeId();
                id.setCardNo(iMap.getString("CARD_NO"));
               // id.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                id.setPasaportNo(iMap.getString("PASAPORT_NO"));
                samanBankList.setIkinciAdi(iMap.getString("IKINCI_ADI"));
                samanBankList.setPasaportVerTarih(iMap.getString("PASAPORT_VER_TAR"));
                samanBankList.setPasaportVerYer(iMap.getString("PASAPORT_VER_YER"));
                samanBankList.setSoyadi(iMap.getString("SOYADI"));
                samanBankList.setStatus(iMap.getString("STATUS"));
                samanBankList.setTelefon(iMap.getString("TELEFON"));
                samanBankList.setCinsiyet(iMap.getString("CINSIYET"));
                samanBankList.setId(id);
                session.saveOrUpdate(samanBankList);
                //session.flush();
         
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        finally {
        
        }
        return oMap;
    }
    
}
