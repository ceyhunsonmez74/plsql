package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import joptsimple.internal.Column;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.cfg.Mappings.ColumnNames;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriAdres;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.OceanMapKeys;



import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardQRY4410Services implements OceanMapKeys {

	enum CardSmartSoftStatus {
		CC, GN, GV, GY, GQ, IK, IR, IC, IF, IB, CT, KK, IU, IM, IV, IY, SS, PP, KM, KT, GX, NN, BB, GJ, II, GB, GM, GC, GK, GA, AM, IT
	}

	public static final String UNDEFINED = "UNDEFINED";

	private static Map<String, String> paymentResultMap = new HashMap<String, String>();
	private static Map<String, String> addressTypeMap = new HashMap<String, String>();

	static {
		paymentResultMap.put(UNDEFINED, "");
		paymentResultMap.put("0", "�deme ve Stat� G�ncelleme Ba�ar�l�.");
		paymentResultMap.put("1", "Stat� G�ncelleme Ba�ar�s�z, �deme iade edildi.");
		paymentResultMap.put("2", "�deme Ba�ar�s�z, Stat� G�ncelleme Ba�ar�l�.");
		paymentResultMap.put("3", "�deme ve Stat� G�ncelleme Ba�ar�s�z.");
		paymentResultMap.put("4", "KK Numarasi giri�inde hata yapildi.");
		paymentResultMap.put("5", "CVV2 giri�inde hata yapildi.");
		paymentResultMap.put("6", "Kart Son Kullan�m Tarihi giri�inde hata yapildi.");
		paymentResultMap.put("7", "��lemin Devam Etmesi i�in Onay verilmedi.");
		paymentResultMap.put("8", "Zamana��m� olu�tu, kart stat�s�n� kontrol ediniz.");

		addressTypeMap.put("", "");
	}

	@GraymoundService("BNSPR_TRN4410_GET_CC_STATUS_COMBO")
	public static GMMap getCCStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("KEY2", iMap.getString("PRESENT_STATUS"));
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("KK_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4410_GET_CC_SUB_STATUS_COMBO")
	public static GMMap getCCSubStatus(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY2 = ? AND KEY3 = ? ORDER BY SIRA_NO");
			stmt.setString(2, iMap.getString("STATUS"));
			stmt.setString(3, iMap.getString("PRESENT_STATUS"));

			stmt.setString(1, iMap.getString("KOD"));

			rSet = stmt.executeQuery();
			GuimlUtil.wrapMyCombo(oMap, "KK_ALT_STATU", null, " ");
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "KK_ALT_STATU", rSet.getString(1), rSet.getString(2));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TRN4410_GET_CC_REASON_COMBO")
	public static GMMap getCCReason(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("KOD", "KK_IPTAL_SEBEP_CC");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("KK_REASON", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_GET_CARD_INFO")
	public static GMMap getCardList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap oMap2 = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM/yy");

		boolean isEmbossRequested = false;
		boolean isCreditCard = false;
		boolean isDebitCard = false;
		boolean isPrepaidCard = false;
		boolean isUptKart = false;
		boolean isTroyKart= false;
		boolean isHceKart=false;
		boolean isHceKart_2=false;
		boolean isVirtualPP=false;
		boolean isKahramanKart=false;
		String  lastFourCardNo="************";
		
		iMap.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap.put(CARD_NO, "");
		iMap.put(CARD_DCI, iMap.getString("CARD_DCI"));
		iMap.put("INPUT_PARAMETER_TYPE", "CST");
		iMap.put("NO_NEED_APPLICATIONS", true);
				
		iMap.put("CARD_BANK_STATUS_CC", "All");
		iMap.put(CARD_BRANCH, GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap).getString("SUBE_KOD"));

		int mSize=0;
		try {
			oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
			mSize=oMap.getSize("CARD_DETAIL_INFO");
			String productId = "";
			int iCount=0;
			for (int i = 0; i < mSize; i++) {

				productId = !StringUtils.isEmpty(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID))? oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID) : "";
				isCreditCard = "Credit".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				isDebitCard = "Debit".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				isPrepaidCard = "Prepaid".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				isUptKart = KkProductsUtil.isUptPpProduct(productId);//"912".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isTroyKart = KkProductsUtil.isTroyDebitProduct(productId); //"916".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isVirtualPP=  KkProductsUtil.isVirtualProduct(productId);//"914".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart=  KkProductsUtil.isHceProduct(productId, ONLINE); //"920".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart_2= KkProductsUtil.isHceProduct(productId, OFFLINE,"ANKARA"); //"921".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));				
				isKahramanKart=KkProductsUtil.isHceProduct(productId, OFFLINE,"MARAS"); //"922".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				
				if(isHceKart)
				{
					
					lastFourCardNo+=oMap.getString("CARD_DETAIL_INFO", i, CARD_NO).substring(12);
				
				}
				
				if(!isHceKart && !isHceKart_2 && !isKahramanKart)
				{
				boolean isOcean = "O".equals(oMap.getString("CARD_DETAIL_INFO", i, SYSTEM));
				
				oMap2.put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
				
				oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
				
				if (isOcean)
					isEmbossRequested = GMServiceExecuter.call("BNSPR_OCEAN_GET_EMBOSS_REQUEST", oMap2).getBoolean("IS_EMBOSS_REQUEST");
				else
					isEmbossRequested = GMServiceExecuter.call("BNSPR_INTRACARD_GET_EMBOSS_REQUEST", oMap2).getBoolean("IS_EMBOSS_REQUEST");

				if (isCreditCard)
					oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_DCI_DESC", "Kredi Kart�");
				else if (isPrepaidCard)
					oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_DCI_DESC", "Prepaid");
				else if (isDebitCard)
					oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_DCI_DESC", "Debit");
				
				//if(isUptKart)
				//	oMap.put("CARD_DETAIL_INFO", iCount, "CARD_GROUP_DESC", "Upt");
				//else if(isTroyKart)
				//	oMap.put("CARD_DETAIL_INFO", iCount, "CARD_GROUP_DESC", "TroyDebit");

				oMap2.put("CARD_DETAIL_INFO", iCount, "OLD_CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, OLD_CARD_NO));
				
				oMap2.put("CARD_DETAIL_INFO", iCount, "CUSTOMER_NO", oMap.getString("CARD_DETAIL_INFO", i, CUSTOMER_NO));
				oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_DCI", oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_GROUP_DESC", oMap.getString("CARD_DETAIL_INFO", i, CARD_GROUP_DESC));
				oMap2.put("CARD_DETAIL_INFO", iCount, "SYSTEM", oMap.getString("CARD_DETAIL_INFO", i, SYSTEM));
				oMap2.put("CARD_DETAIL_INFO", iCount, "PRODUCT_ID", oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				oMap2.put("CARD_DETAIL_INFO", iCount, "EMBOSS_NAME", oMap.getString("CARD_DETAIL_INFO", i, NAME));
				oMap2.put("CARD_DETAIL_INFO", iCount, "STATUS_DESC", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
				oMap2.put("CARD_DETAIL_INFO", iCount, "STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE));
				oMap2.put("CARD_DETAIL_INFO", iCount, "SUB_STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE));
				oMap2.put("CARD_DETAIL_INFO", iCount, "MASKED_CARD_NO", maskCardNumber(oMap.getString("CARD_DETAIL_INFO", i, CARD_NO)));
				oMap2.put("CARD_DETAIL_INFO", iCount, "TEAM_NAME", oMap.getString("CARD_DETAIL_INFO", i, "TEAM_NAME"));
				oMap2.put("CARD_DETAIL_INFO", iCount, "CARD_STAT_CHANGE_DATE", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE));
				
				if(isVirtualPP)
					oMap2.put("CARD_DETAIL_INFO", iCount, "LAST_FOUR_CARD_NO", lastFourCardNo);
				

				if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE))) {
					if ("19000101".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE)))
						oMap2.put("CARD_DETAIL_INFO", iCount, CARD_STAT_CHANGE_DATE, (Date) null);
				}

				if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
					oMap2.put("CARD_DETAIL_INFO", iCount, "EXPIRE_DATE", sdf2.format(sdf.parse(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
				}
				if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, "ONCEKI_SKT"))) {
					oMap2.put("CARD_DETAIL_INFO", iCount, "ONCEKI_SKT", sdf2.format(sdf.parse(oMap.getString("CARD_DETAIL_INFO", i, "ONCEKI_SKT"))));
				}
				oMap2.put("CARD_DETAIL_INFO", iCount, "EMBOSS_REQUEST", isEmbossRequested);
				oMap2.put("CARD_DETAIL_INFO", iCount, "EMBOSS_REQUEST_DESC", isEmbossRequested ? "Yenilendi" : "");
				oMap2.put("CARD_DETAIL_INFO", iCount, "BASIM_BEKLENIYORMU", "GB".equals((oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE)+oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)))?"Evet":"Hay�r");
				GMMap panSeqMap = new GMMap();
			    panSeqMap.put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i,"CARD_NO"));
			    panSeqMap.put("CARD_STAT_CODE", oMap.getString("CARD_DETAIL_INFO", i,"CARD_STAT_CODE"));
			    panSeqMap.put("CARD_SUB_STAT_CODE", oMap.getString("CARD_DETAIL_INFO", i,"CARD_SUB_STAT_CODE"));
			    panSeqMap.put("EMBOSS_CODE", oMap.getString("CARD_DETAIL_INFO", i,EMBOSS_CODE));
				oMap2.put("CARD_DETAIL_INFO", iCount,"EMBOSS_COUNT_SAME_CARD_NO",(GMServiceExecuter.call((isOcean?"BNSPR_OCEAN_GET_CARD_FEE":"BNSPR_INTRACARD_GET_CARD_FEE"),panSeqMap).getInt("PAN_SEQ"))-1);
				
			    	iCount++;
				}
				
		}
			return oMap2;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_QRY4410_OPEN_GET_CARD_INFO")
	public static GMMap getCardListOpen(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM/yy");

		boolean isEmbossRequested = false;
		boolean isCreditCard = false;
		boolean isDebitCard = false;
		boolean isPrepaidCard = false;
		boolean isStatControlled = false;
		boolean isUptKart = false;
		boolean isTroyKart = false;
		boolean isVirtualPP=false;
		boolean isHceKart=false;
		boolean isHceKart_2=false;
		boolean isKahramanKart=false;
		boolean mchipCard=false;
		

		iMap.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap.put(CARD_NO, "");
		iMap.put(CARD_DCI, iMap.getString("CARD_DCI"));
		iMap.put("INPUT_PARAMETER_TYPE", "CST");
		iMap.put("NO_NEED_APPLICATIONS", true);
		iMap.put("CARD_BANK_STATUS_CC", "All");
		iMap.put(CARD_BRANCH, GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap).getString("SUBE_KOD"));

		try {
			oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
			String productId = "";

			for (int i = 0, k = 0; i < oMap.getSize("CARD_DETAIL_INFO"); i++) {
				productId = !StringUtils.isEmpty(oMap.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID))? oMap.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID) : "";

				isUptKart = KkProductsUtil.isUptPpProduct(productId);//"912".equals(oMap.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID));
				isTroyKart = KkProductsUtil.isTroyDebitProduct(productId);//"916".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isVirtualPP = KkProductsUtil.isVirtualProduct(productId);// "914".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart= KkProductsUtil.isHceProduct(productId, "ONLINE");//"920".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart_2= KkProductsUtil.isHceProduct(productId, "OFFLINE","ANKARA");//"921".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isKahramanKart= KkProductsUtil.isHceProduct(productId, "OFFLINE","MARAS");//"922".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				mchipCard=KkProductsUtil.isMchipProduct(productId);//mchipFilter(oMap,i,1,"CARD_DETAIL_INFO",PRODUCT_ID);
				
				if (("G".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE))) && ("X".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)) || "N".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)) || "V".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)) || "A".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)))
						&& (!isVirtualPP && !isHceKart && !isHceKart_2 && !isKahramanKart))
						 
						 {

					isCreditCard = "Credit".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
					isDebitCard = "Debit".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
					isPrepaidCard = "Prepaid".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
					
					boolean isOcean = "O".equals(oMap.getString("CARD_DETAIL_INFO", i, SYSTEM));

					oMap.put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));

					if (isCreditCard)
						oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_DCI_DESC", "Kredi Kart�");
					else if (isPrepaidCard)
						oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_DCI_DESC", "Prepaid");
					else if (isDebitCard)
						oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_DCI_DESC", "Debit");
					
				//	if (isUptKart)
				//	oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_GROUP_DESC", "Upt");
				//	else if (isTroyKart)
				//		oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_GROUP_DESC", "TroyDebit");
					
					
					if (isOcean)
						isEmbossRequested = GMServiceExecuter.call("BNSPR_OCEAN_GET_EMBOSS_REQUEST", oMap).getBoolean("IS_EMBOSS_REQUEST");
					else
						isEmbossRequested = GMServiceExecuter.call("BNSPR_INTRACARD_GET_EMBOSS_REQUEST", oMap).getBoolean("IS_EMBOSS_REQUEST");

					oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "MASKED_CARD_NO", maskCardNumber(oMap.getString("CARD_DETAIL_INFO", i, CARD_NO)));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_DCI", oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "EMBOSS_NAME", oMap.getString("CARD_DETAIL_INFO", i, NAME));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "STATUS_DESC", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "SUB_STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "OLD_STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "OLD_SUB_STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE));

					if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE))) {
						if ("19000101".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE))) {
							oMap.put("CARD_DETAIL_INFO_OPEN", k, CARD_STAT_CHANGE_DATE, (Date) null);
						} else {
							oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_STAT_CHANGE_DATE", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE));
						}
					}

					if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
						oMap.put("CARD_DETAIL_INFO_OPEN", k, "EXPIRE_DATE", sdf2.format(sdf.parse(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
					}

					oMap.put("CARD_DETAIL_INFO_OPEN", k, "EMBOSS_REQUEST", isEmbossRequested);
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "EMBOSS_REQUEST_DESC", isEmbossRequested ? "Yenilendi" : "");

					oMap.put("CARD_DETAIL_INFO_OPEN", k, "SYSTEM", oMap.getString("CARD_DETAIL_INFO", i, SYSTEM));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "CUSTOMER_NO", oMap.getString("CARD_DETAIL_INFO", i, CUSTOMER_NO));

					oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_UPDATE_USER", oMap.getString("CARD_DETAIL_INFO", i, "CARD_UPDATE_USER"));

					if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
						oMap.put("CARD_DETAIL_INFO_OPEN", k, "EXPIRE_DATE", sdf2.format(sdf.parse(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
					}
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_GROUP_DESC", oMap.getString("CARD_DETAIL_INFO", i, "CARD_GROUP_DESC"));

					if (isOcean)
						isStatControlled = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_STATUS_CONTROL", new GMMap().put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, "CARD_NO"))).getBoolean("CARD_STATUS_CONTROL");
					else
						isStatControlled = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_STATUS_CONTROL", new GMMap().put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, "CARD_NO"))).getBoolean("CARD_STATUS_CONTROL");

					oMap.put("CARD_DETAIL_INFO_OPEN", k, "CARD_STATUS_CONTROL", isStatControlled);
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "OLD_CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, "OLD_CARD_NO"));
					oMap.put("CARD_DETAIL_INFO_OPEN", k, "EMBOSS_CODE", oMap.getString("CARD_DETAIL_INFO", i, "EMBOSS_CODE"));
					k++;
				}

			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unused")
	public static String assignProductTypeUsingProductBin(String cardNo) {
		cardNo = cardNo.substring(0, 6);
		if (cardNo.equals("441115") || cardNo.equals("515456") || cardNo.equals("441147") || cardNo.equals("441118") || cardNo.equals("517343") || cardNo.equals("671155")) {
			return "PASSO";
		} else {
			return "PASSOL�G";
		}
	}

	@GraymoundService("KART_ACMA_JUST_FOR_LOG")
	public static GMMap kartAcmaLog(GMMap iMap) {
		return new GMMap();
	}

	@GraymoundService("KART_TARIHCE_JUST_FOR_LOG")
	public static GMMap kartTarihceLog(GMMap iMap) {
		return new GMMap();
	}

	@GraymoundService("BNSPR_QRY4410_GET_RENEWABLE_CARDS")
	public static GMMap getRenewableCardList(GMMap iMap) {

		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM/yy");
		
		CardSmartSoftStatus currentStatus =null;
		boolean isRenewable = false;
		boolean isEmbossRequested = false;
		boolean isCreditCard = false;
		boolean isDebitCard = false;
		boolean isPrepaidCard = false;
		boolean isVirtualPP = false;
		boolean isUptKart = false;
		boolean isTroyKart=false;
		boolean isHceKart=false;
		boolean isHceKart_2=false;
		boolean mchipFilterCard=false;
		boolean isKahramanKart=false;
		
		iMap.put(CUSTOMER_NO, iMap.getString("MUST_NO"));
		iMap.put(CARD_NO, "");
		iMap.put(CARD_DCI, iMap.getString("CARD_DCI"));
		iMap.put("INPUT_PARAMETER_TYPE", "CST");
		iMap.put("NO_NEED_APPLICATIONS", true);
		iMap.put("CARD_BANK_STATUS_CC", "All");
		iMap.put(CARD_BRANCH, GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap).getString("SUBE_KOD"));
		try {
			int j = 0;
			oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
			String productId ="";
			for (int i = 0; i < oMap.getSize("CARD_DETAIL_INFO"); i++) {
				for(CardSmartSoftStatus status : CardSmartSoftStatus.values())
				{
					if((oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE) + oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)).equals(status.toString()))
					{
						currentStatus =status;
						break;
					}
						
				}
					
				isRenewable = true;
				switch (currentStatus) {
				case GC:
					break;
				case GM:
					break;
				case GK:
					break;
				case GA:
					break;
				case NN:
					break;
				default:
					isRenewable = false;
					break;
				}

				productId = !StringUtils.isEmpty(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID))? oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID) : "";

				isCreditCard = "Credit".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				isDebitCard = "Debit".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				isPrepaidCard = "Prepaid".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
				isVirtualPP = KkProductsUtil.isVirtualProduct(productId);//"914".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isUptKart =KkProductsUtil.isUptPpProduct(productId);//"912".equals(oMap.getString("CARD_DETAIL_INFO" , i , PRODUCT_ID));
				isTroyKart = KkProductsUtil.isTroyDebitProduct(productId);//"916".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart= KkProductsUtil.isHceProduct(productId, "ONLINE");//"920".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isHceKart_2= KkProductsUtil.isHceProduct(productId, "OFFLINE","ANKARA");//"921".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				isKahramanKart= KkProductsUtil.isHceProduct(productId, "OFFLINE","MARAS");//"922".equals(oMap.getString("CARD_DETAIL_INFO", i, PRODUCT_ID));
				boolean isOcean = "O".equals(oMap.getString("CARD_DETAIL_INFO", i, SYSTEM));
				mchipFilterCard=mchipFilter(oMap,i,0,"CARD_DETAIL_INFO",PRODUCT_ID);
				
				oMap.put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));

				if (isOcean)
					isEmbossRequested = GMServiceExecuter.call("BNSPR_OCEAN_GET_EMBOSS_REQUEST", oMap).getBoolean("IS_EMBOSS_REQUEST");
				else
					isEmbossRequested = GMServiceExecuter.call("BNSPR_INTRACARD_GET_EMBOSS_REQUEST", oMap).getBoolean("IS_EMBOSS_REQUEST");

				 
					if ((StringUtils.isNotBlank(iMap.getString("CLOSED_CARD_NO")) && oMap.getString("CARD_NO").equals(iMap.getString("CLOSED_CARD_NO")) && !isUptKart && !isVirtualPP && !isHceKart && !isHceKart_2 && !isKahramanKart && !mchipFilterCard) 
					        || (StringUtils.isBlank(iMap.getString("CLOSED_CARD_NO")) && isRenewable  &&  !isUptKart && !isVirtualPP && !isHceKart && !isHceKart_2 && !isKahramanKart && !mchipFilterCard )) {

					
				
					if (isCreditCard)
						oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_DCI_DESC", "Kredi Kart�");
					else if (isPrepaidCard)
						oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_DCI_DESC", "Prepaid");
					else if (isDebitCard)
						oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_DCI_DESC", "Debit");
					
				//	if (isUptKart)
				//		oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_GROUP_DESC", "Upt");
				//	else if (isTroyKart)
				//		oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_GROUP_DESC", "TroyDebit");

					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_DCI", oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "EMBOSS_NAME", oMap.getString("CARD_DETAIL_INFO", i, NAME));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "STATUS_DESC", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "SUB_STATUS", oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "MASKED_CARD_NO", maskCardNumber(oMap.getString("CARD_DETAIL_INFO", i, CARD_NO)));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CUSTOMER_NO", oMap.getString("CARD_DETAIL_INFO", i, CUSTOMER_NO));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "SYSTEM", oMap.getString("CARD_DETAIL_INFO", i, SYSTEM));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_STAT_CHANGE_DATE", oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_UPDATE_USER", oMap.getString("CARD_DETAIL_INFO", i, "CARD_UPDATE_USER"));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "EMBOSS_COUNT_BY_CUSTOMER_CAUSE", oMap.getString("CARD_DETAIL_INFO", i, "EMBOSS_COUNT_BY_CUSTOMER_CAUSE"));

					if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE))) {
						if ("19000101".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CHANGE_DATE)))
							oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, CARD_STAT_CHANGE_DATE, (Date) null);
					}

					if (StringUtils.isNotBlank(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))) {
						oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "EXPIRE_DATE", sdf2.format(sdf.parse(oMap.getString("CARD_DETAIL_INFO", i, EXPIRY_DATE))));
					}

					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "EMBOSS_REQUEST", isEmbossRequested);
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "EMBOSS_REQUEST_DESC", isEmbossRequested ? "Yenilendi" : "");
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "CARD_GROUP_DESC", oMap.getString("CARD_DETAIL_INFO", i, "CARD_GROUP_DESC"));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, OLD_CARD_NO, oMap.getString("CARD_DETAIL_INFO", i, OLD_CARD_NO));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, EMBOSS_CODE, oMap.getString("CARD_DETAIL_INFO", i, EMBOSS_CODE));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j, "BASIM_BEKLENIYORMU", "GB".equals((oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_CODE)+oMap.getString("CARD_DETAIL_INFO", i, CARD_SUB_STAT_CODE)))?"Evet":"Hay�r");
					GMMap panSeqMap = new GMMap();
				    panSeqMap.put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i,"CARD_NO"));
				    panSeqMap.put("CARD_STAT_CODE", oMap.getString("CARD_DETAIL_INFO", i,"CARD_STAT_CODE"));
				    panSeqMap.put("CARD_SUB_STAT_CODE", oMap.getString("CARD_DETAIL_INFO", i,"CARD_SUB_STAT_CODE"));
				    panSeqMap.put("EMBOSS_CODE", oMap.getString("CARD_DETAIL_INFO", i,EMBOSS_CODE));
					oMap.put("RENEWABLE_CARD_DETAIL_INFO", j,"EMBOSS_COUNT_SAME_CARD_NO",(GMServiceExecuter.call((isOcean?"BNSPR_OCEAN_GET_CARD_FEE":"BNSPR_INTRACARD_GET_CARD_FEE"),panSeqMap).getInt("PAN_SEQ"))-1);
					j++;
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_QRY4410_UPDATE_DEFECT_CARD")
	public static GMMap updateDefectCard(GMMap iMap) {
		GMMap oMap = new GMMap();
		String ServiceName = "";
		BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
		boolean isOcean = "O".equals(iMap.getString("SYSTEM"));
        boolean isSourceOfDefectBank = "B".equals(iMap.getString("SUBSTATUS"));
        boolean isSourceOfDefectCustomer = "M".equals(iMap.getString("SUBSTATUS"));
		boolean hasSourceOfDefect = (isSourceOfDefectBank || isSourceOfDefectCustomer);
		boolean isPaymentOk = false;
		boolean isRenewalOk = false;
		boolean isKartBedeliPaymentOk = false;
		boolean isKuryeBedeliPaymentOk = false;
		boolean isKartBedeliExists = BigDecimal.ZERO.compareTo(iMap.getBigDecimal("KART_BEDELI"))!=0;
		boolean isKuryeBedeliExists = BigDecimal.ZERO.compareTo(iMap.getBigDecimal("KURYE_BEDELI"))!=0;
		String newCardNo =null;
		
		try {
			if (!hasSourceOfDefect) {
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(330));
				iMap.put("P1", "ARIZA KAYNAGI");
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				throw new GMRuntimeException(0, message);
			}

			
			if (isSourceOfDefectCustomer) {
			    //ilk �nce kart bedeli e�er ki s�f�rdan b�y�kse finansal bak�m ge�iyoruz.
			    if(isKartBedeliExists)
			    {
			    iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KART_BEDELI"));
			    iMap.put("TXN_DESC", "Kart Yenileme - Bas�m �creti");
			    iMap.put("ADJUSTMENT_TYPE", "KART_BEDELI");
			    
				iMap.putAll(GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap));
				oMap.put("KART_BEDELI", iMap.getBigDecimal("KART_BEDELI"));
				isKartBedeliPaymentOk = "2".equals(iMap.getString("RETURN_CODE"));
			    }
			    
				if(!isKartBedeliPaymentOk && isKartBedeliExists)
				{
				    throw new GMRuntimeException(0, "�deme al�namad�");
				}
				
				//Kart Bedeli varsa �dendiyse veya yoksa kurye bedelini kontrol ediyoruz
			    if (isKuryeBedeliExists){
                    
                    iMap.put("TXN_TYPE" , iMap.getString("FIN_ADJ_TXN_TYPE_KURYE_BEDELI"));
                    iMap.put("TXN_DESC", "Kart Yenileme - Kurye �creti");
                    iMap.put("ADJUSTMENT_TYPE", "KURYE_BEDELI");
                    iMap.putAll(GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT" , iMap));
                    oMap.put("KURYE_BEDELI" , iMap.getBigDecimal("KURYE_BEDELI"));
                    isKuryeBedeliPaymentOk = "2".equals(iMap.getString("RETURN_CODE"));
                    
                    //Kurye bedeli herhangi bir sebepten dolay� al�namad�ysa ama kart bedelini ald�ysak kart bedelini iade edelim
                    if(!isKuryeBedeliPaymentOk && isKartBedeliPaymentOk)
                    {
                        iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KART_BEDELI_REVERSE"));
                        iMap.put("TXN_DESC", "Kart Yenileme - Bas�m �cret �ptali");
                        iMap.put("ADJUSTMENT_TYPE", "KART_BEDELI");
                        GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap);
                        throw new GMRuntimeException(3 , "�deme al�namad�.");
                    }
                    
                    //Kart bedeliyle yoksa fakat kurye bedelinde hata ald�ysak. Mesaj veriyoruz
                    if(!isKuryeBedeliPaymentOk && isKuryeBedeliExists)
                    {
                        throw new GMRuntimeException(4 , "�deme al�namad�."); 
                    }
                    
                }
			   
			    
			}
			
			isPaymentOk = ((isKuryeBedeliPaymentOk ||!isKuryeBedeliExists) && (isKartBedeliPaymentOk||!isKartBedeliExists));
            
			if (isSourceOfDefectCustomer && !isPaymentOk)
				throw new GMRuntimeException(0, "�deme al�namad�");

			if (isOcean && !isSourceOfDefectCustomer ) {
				ServiceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
			} else if (!isOcean && !isSourceOfDefectCustomer ) {
				ServiceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";
			}
			
			if (isSourceOfDefectCustomer)
			{  
				 iMap.put("EMBOSS_CODE", (iMap.getString("STATUS")+iMap.getString("SUBSTATUS")));
				 if (isOcean){
				     iMap.put("EXTEND_EXPIRY" , "Y");
				     ServiceName = "BNSPR_OCEAN_CARD_RENEWAL";
				 }
		         else
		            	ServiceName = "BNSPR_INTRACARD_CARD_RENEWAL";
		     }
			
			try {
				oMap = GMServiceExecuter.call(ServiceName, iMap);
				
			} catch (Exception e) {
				e.printStackTrace();
				oMap.put("RETURN_CODE", "0");
			}
			isRenewalOk = "2".equals(oMap.getString("RETURN_CODE"));

			if (!isRenewalOk && isSourceOfDefectCustomer) {
				if(isKartBedeliExists)
				{
			    iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KART_BEDELI_REVERSE"));
				iMap.put("TXN_DESC", "Kart Yenileme - Bas�m �cret �ptali");
				iMap.put("ADJUSTMENT_TYPE", "KART_BEDELI");
				GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap);
				}
				if(isKuryeBedeliExists)
				{
				    iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KURYE_BEDELI_REVERSE"));
	                iMap.put("TXN_DESC", "Kart Yenileme - Kurye �cret �ptali");
	                iMap.put("ADJUSTMENT_TYPE", "KURYE_BEDELI");
	                GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap);
				}
			    throw new GMRuntimeException(10, oMap.getString("RETURN_DESCRIPTION"));
				
			} else if (isRenewalOk) {
				try {
					iMap.put("TRX_NO", txNo);
					iMap.put("NEW_CARD_NO", iMap.getString("CARD_NO"));
					GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST", iMap);

					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "O");
					onayMap.put("ISLEM_NO", txNo);
					oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			oMap.put("NEW_CARD_NO", oMap.getString("NEW_CARD_NO")!=null?oMap.getString("NEW_CARD_NO"):iMap.getString("CARD_NO"));

			if (!isRenewalOk) {
				throw new GMRuntimeException(0, oMap.getString("RETURN_DESCRIPTION"));
			}

			return oMap;
			
		} catch (Exception e) {
			oMap.put("RETURN_CODE", "0");
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_QRY4410_UPDATE_STOLEN_BROKEN_CARD")
	public static GMMap updateStolenCard(GMMap iMap) {
		String ServiceName = "";
		boolean isOcean = "O".equals(iMap.getString("SYSTEM"));
		boolean isPaymentOk = false;
		boolean isRenewalOk = false;
		boolean isLostByCourrier = "GK".equals(iMap.getString("CURRENT_STATUS"));
		boolean isNeedPayment  = BigDecimal.ZERO.compareTo(iMap.getBigDecimal("TOPLAM"))==0?false:true;
		GMMap oMap = new GMMap();
		BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
	    boolean isKartBedeliPaymentOk = false;
        boolean isKuryeBedeliPaymentOk = false;
        boolean isKartBedeliExists = BigDecimal.ZERO.compareTo(iMap.getBigDecimal("KART_BEDELI"))!=0;
        boolean isKuryeBedeliExists = BigDecimal.ZERO.compareTo(iMap.getBigDecimal("KURYE_BEDELI"))!=0;
        
		if (isOcean) {
			ServiceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
		} else {
			ServiceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";
		}
		try {
			if (isLostByCourrier) {
				iMap.put("STATUS", "K");
				oMap.putAll(GMServiceExecuter.call(ServiceName, iMap));
				isRenewalOk = "2".equals(oMap.getString("RETURN_CODE"));
				if (!isRenewalOk) {
					throw new GMRuntimeException(0, oMap.getString("RETURN_DESCRIPTION"));
				} else {
					try {
						iMap.put("TRX_NO", txNo);
						iMap.put("NEW_CARD_NO", oMap.getString("NEW_CARD_NO"));
						GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST", iMap);

						GMMap onayMap = new GMMap();
						onayMap.put("ISLEM_TURU", "O");
						onayMap.put("ISLEM_NO", txNo);
						oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			
			else if (!isNeedPayment)
			{
				if ("A".equals(iMap.getString("SUBSTATUS"))) {
					iMap.put("STATUS", "I");
					iMap.put("SUBSTATUS", "M");
				} else if ("C".equals(iMap.getString("SUBSTATUS")))
					iMap.put("STATUS", "C");
				else if ("M".equals(iMap.getString("SUBSTATUS")))
					iMap.put("STATUS", "K");

				oMap.putAll(GMServiceExecuter.call(ServiceName, iMap));

				isRenewalOk = "2".equals(oMap.getString("RETURN_CODE"));
				if (!isRenewalOk) {
				
					throw new GMRuntimeException(0, oMap.getString("RETURN_DESCRIPTION"));
					
				} else {
					try {
                    
						iMap.put("TRX_NO", txNo);
						iMap.put("NEW_CARD_NO", oMap.getString("NEW_CARD_NO"));
						GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST", iMap);

						GMMap onayMap = new GMMap();
						onayMap.put("ISLEM_TURU", "O");
						onayMap.put("ISLEM_NO", txNo);
						oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			else {
			    
			    
			    if(isKartBedeliExists)
                {
                iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KART_BEDELI"));
                iMap.put("TXN_DESC", "Kart Yenileme - Bas�m �creti");
                iMap.put("ADJUSTMENT_TYPE", "KART_BEDELI");
                iMap.putAll(GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap));
                oMap.put("KART_BEDELI", iMap.getBigDecimal("KART_BEDELI"));
                isKartBedeliPaymentOk = "2".equals(iMap.getString("RETURN_CODE"));
                }
                
                if(!isKartBedeliPaymentOk && isKartBedeliExists)
                {
                    throw new GMRuntimeException(0, "�deme al�namad�");
                }
                    if (isKuryeBedeliExists){
                    
                    iMap.put("TXN_TYPE" , iMap.getString("FIN_ADJ_TXN_TYPE_KURYE_BEDELI"));
                    iMap.put("TXN_DESC", "Kart Yenileme Kurye �creti");
                    iMap.put("ADJUSTMENT_TYPE", "KURYE_BEDELI");
                    iMap.putAll(GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT" , iMap));
                    oMap.put("KURYE_BEDELI" , iMap.getBigDecimal("KURYE_BEDELI"));
                    isKuryeBedeliPaymentOk = "2".equals(iMap.getString("RETURN_CODE"));
                    
                    //Kurye bedeli herhangi bir sebepten dolay� al�namad�ysa ama kart bedelini ald�ysak kart bedelini iade edelim
                    if(!isKuryeBedeliPaymentOk && isKartBedeliPaymentOk)
                    {
                        iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KART_BEDELI_REVERSE"));
                        iMap.put("TXN_DESC", "Kart Yenileme - Bas�m �creti �ptali");
                        iMap.put("ADJUSTMENT_TYPE", "KART_BEDELI");
                        GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap);
                        throw new GMRuntimeException(3 , "�deme al�namad�.");
                    }
                    
                    //Kart bedeliyle yoksa fakat kurye bedelinde hata ald�ysak. Mesaj veriyoruz
                    if(!isKuryeBedeliPaymentOk)
                    {
                        throw new GMRuntimeException(4 , "�deme al�namad�."); 
                    }
                    
                }

                isPaymentOk = ((isKuryeBedeliPaymentOk ||!isKuryeBedeliExists) && (isKartBedeliPaymentOk||!isKartBedeliExists));

				if (!isPaymentOk)
					throw new GMRuntimeException(0, "�deme al�namad�");

				if ("A".equals(iMap.getString("SUBSTATUS"))) {
					iMap.put("STATUS", "I");
					iMap.put("SUBSTATUS", "M");
				} else if ("C".equals(iMap.getString("SUBSTATUS")))
					iMap.put("STATUS", "C");
				else if ("M".equals(iMap.getString("SUBSTATUS")))
					iMap.put("STATUS", "K");

				oMap.putAll(GMServiceExecuter.call(ServiceName, iMap));

				isRenewalOk = "2".equals(oMap.getString("RETURN_CODE"));

				if (!isRenewalOk) {
				    if(isKartBedeliExists)
	                {
	                iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KART_BEDELI_REVERSE"));
	                iMap.put("TXN_DESC", "Kart Yenileme - Bas�m �creti �ptali");
	                iMap.put("ADJUSTMENT_TYPE", "KART_BEDELI");
	                GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap);
	                }
	                if(isKuryeBedeliExists)
	                {
	                    iMap.put("TXN_TYPE", iMap.getString("FIN_ADJ_TXN_TYPE_KURYE_BEDELI_REVERSE"));
	                    iMap.put("TXN_DESC", "Kart Yenileme Kurye �creti �ptali");
	                    iMap.put("ADJUSTMENT_TYPE", "KURYE_BEDELI");
	                    GMServiceExecuter.call("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT", iMap);
	                }
					throw new GMRuntimeException(10, oMap.getString("RETURN_DESCRIPTION"));
				} else {
					try {

						iMap.put("TRX_NO", txNo);
						iMap.put("NEW_CARD_NO", oMap.getString("NEW_CARD_NO"));
						GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST", iMap);

						GMMap onayMap = new GMMap();
						onayMap.put("ISLEM_TURU", "O");
						onayMap.put("ISLEM_NO", txNo);
						oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_KART_KAPAMA")
	public static GMMap updateCardInfoKapama(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap funcMap = new GMMap();
		String ServiceName = "";
		boolean isOcean = "O".equals(iMap.getString("SYSTEM"));
		boolean isDefectCard = false;
		boolean hasNewStatus = StringUtils.isNotBlank(iMap.getString("NEW_STATUS"));
		boolean hasCancelCode = StringUtils.isNotBlank(iMap.getString("CANCEL_CODE"));
		boolean mchipCard=false;
		
	
		
		try {

			funcMap.put("MCHIP", 0, PRODUCT_ID, iMap.getString(PRODUCT_ID));
			
			mchipCard=mchipFilter(funcMap,0,1,"MCHIP",PRODUCT_ID);
			
			isDefectCard = StringUtils.isNotBlank(iMap.getString("CAUSE_OF_DEFECT"));

			if (isDefectCard && !mchipCard)
				return oMap;

			if (!hasNewStatus) {
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(660));
				iMap.put("P1", "Stat� ve Alt Stat� Se�iniz");
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				throw new GMRuntimeException(0, message);
			}

			if ("GA".equals(iMap.getString("NEW_STATUS")) && !hasCancelCode) {
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(660));
				iMap.put("P1", "Stat� ve Alt Stat� Se�iniz");
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				throw new GMRuntimeException(0, message);
			}

			iMap.put("STATUS", iMap.getString("NEW_STATUS").substring(0, 1));
			iMap.put("SUBSTATUS", iMap.getString("NEW_STATUS").substring(1, 2));

			if (isOcean) {
				ServiceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
			} else {
				ServiceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";
			}
			iMap.putAll(GMServiceExecuter.call(ServiceName, iMap));

			if (!"2".equals(iMap.getString("RETURN_CODE"))) {
				throw new GMRuntimeException(0, iMap.getString("RETURN_DESCRIPTION"));
			}
			oMap.putAll(iMap);

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e.getMessage());
		}

	}

	@GraymoundService("BNSPR_QRY4410_UPDATE_CUSTOMER_REQUEST")
	public static GMMap updateCardInfoCustomer(GMMap iMap) {
		String ServiceName = "";
		GMMap oMap = new GMMap();
		boolean isCreditCard = "Credit".equals(iMap.getString("CARD_DCI"));
		boolean hasNewStatus = StringUtils.isNotBlank(iMap.getString("NEW_STATUS"));
		boolean isCanceledByCustomer = "IM".equals(iMap.getString("NEW_STATUS"));
		boolean hasCancelCode = StringUtils.isNotBlank(iMap.getString("DESCRIPTION"));
		try {
			if (!hasNewStatus) {
				iMap.put("MESSAGE_NO", BigDecimal.valueOf(330));
				iMap.put("P1", "STAT�");
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				throw new GMRuntimeException(0, message);
			}
			if (isCanceledByCustomer) {
				if (!hasCancelCode) {
					iMap.put("MESSAGE_NO", BigDecimal.valueOf(330));
					iMap.put("P1", "Stat� De�i�iklik Sebebi");
					String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
					throw new GMRuntimeException(0, message);
				}
			}
			if ("NN".equals(iMap.getString("NEW_STATUS")) && "IM".equals(iMap.getString("OLD_STATUS"))) {
				iMap.put("PARAMETRE", "INTRACARD_IM_NN_MAX_DAYS");
				int maxDaysAllowedForIMtoNN = (isCreditCard ? 0 : GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", iMap).getInt("DEGER"));
				if (daysBetween(iMap.getDate("CARD_STAT_CHANGE_DATE"), new Date()) > maxDaysAllowedForIMtoNN) {
					iMap.put("MESSAGE_NO", BigDecimal.valueOf(660));
					iMap.put("P1", isCreditCard ? "Kart Stat�s� sadece ayn� g�n i�inde normal yap�labilir" : "�ptal edilmesi �zerinden " + maxDaysAllowedForIMtoNN + " g�nden fazla ge�ti�i i�in, Normal stat�ye al�namaz.");
					String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
					throw new GMRuntimeException(0, message);
				}
			}
			iMap.put("STATUS", iMap.getString("NEW_STATUS").substring(0, 1));
			iMap.put("SUBSTATUS", iMap.getString("NEW_STATUS").substring(1, 2));

			if (isCreditCard) {
				ServiceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
			} else {
				ServiceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";
			}
			iMap.putAll(GMServiceExecuter.call(ServiceName, iMap));

			if (!"2".equals(iMap.getString("RETURN_CODE"))) {
				throw new GMRuntimeException(0, iMap.getString("RETURN_DESCRIPTION"));
			}
			oMap.putAll(iMap);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN4410_ENABLE_PANELS_YENILEME")
	public static GMMap enablePanelsYenileme(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean sourceOfDefectEnabled;
		boolean statusChangeEnabled;
		switch (CardSmartSoftStatus.valueOf(iMap.getString("STATUS") + iMap.getString("SUBSTATUS"))) {
		case NN:
			sourceOfDefectEnabled = true;
			break;
		default:
			sourceOfDefectEnabled = false;
		}
		oMap.put("SOURCE_OF_DEFECT_ENABLED", sourceOfDefectEnabled);

		switch (CardSmartSoftStatus.valueOf(iMap.getString("STATUS") + iMap.getString("SUBSTATUS"))) {

		case NN:
			statusChangeEnabled = true;
			break;
		case GN:
			statusChangeEnabled = true;
			break;
		case GV:
			statusChangeEnabled = true;
			break;
		case GJ:
			statusChangeEnabled = true;
			break;
		case GX:
			statusChangeEnabled = true;
			break;
		default:
			statusChangeEnabled = false;
		}
		oMap.put("STATUS_CHANGE_ENABLED", statusChangeEnabled);

		return oMap;
	}

	@GraymoundService("BNSPR_TRN4410_ENABLE_PANELS_KAPAMA")
	public static GMMap enablePanelsKapama(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean statusChangeEnabled;
		switch (CardSmartSoftStatus.valueOf(iMap.getString("STATUS") + iMap.getString("SUBSTATUS"))) {

		case NN:
			statusChangeEnabled = true;
			break;
		case GN:
			statusChangeEnabled = true;
			break;
		case GB:
			statusChangeEnabled = true;
			break;
		case GJ:
			statusChangeEnabled = true;
			break;
		case GX:
			statusChangeEnabled = true;
			break;
		default:
			statusChangeEnabled = false;
		}
		oMap.put("STATUS_CHANGE_ENABLED", statusChangeEnabled);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_ENABLE_PANELS_GUNCELLEME")
	public static GMMap enablePanelsGuncelleme(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean statusChangeEnabled;
		switch (CardSmartSoftStatus.valueOf(iMap.getString("STATUS") + iMap.getString("SUBSTATUS"))) {

		case NN:
			statusChangeEnabled = true;
			break;
		case GN:
			statusChangeEnabled = true;
			break;
		case GV:
			statusChangeEnabled = true;
			break;
		case GJ:
			statusChangeEnabled = true;
			break;
		case GX:
			statusChangeEnabled = true;
			break;
		case GB:
			statusChangeEnabled = true;
			break;
		case IM:
			statusChangeEnabled = true;
			break;
		default:
			statusChangeEnabled = false;
		}
		oMap.put("STATUS_CHANGE_ENABLED", statusChangeEnabled);

		return oMap;
	}

	@GraymoundService("BNSPR_TRN4410_GET_TEBLIGAT_ADRES")
	public static GMMap getCCAdres(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder stb;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GnlMusteriAdres record = (GnlMusteriAdres) session.createCriteria(GnlMusteriAdres.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("extreAdresiMi", "E")).uniqueResult();

			if (record != null) {
				stb = new StringBuilder();
				stb.append(StringUtils.isNotBlank(record.getIsyeriUnvani()) ? record.getIsyeriUnvani() : "");
				stb.append(" ");
				stb.append(record.getAdres());
				stb.append(" ");
				stb.append(StringUtils.isNotBlank(record.getSemt()) ? record.getSemt() : "");
				stb.append(" ");
				stb.append(LovHelper.diLov(record.getIlceKod(), record.getIlKod(), "10011/LOV_ADRES_ILCE", "ILCE_ADI"));
				stb.append(" ");
				stb.append(LovHelper.diLov(record.getIlKod(), "10011/LOV_ADRES_IL", "IL_ADI"));
				stb.append(" ");
				stb.append(LovHelper.diLov(record.getUlkeKod(), "10011/LOV_ULKE", "ULKE_ADI"));
				oMap.put("TEBLIGAT_ADRESI", stb.toString());
				oMap.put("TEBLIGAT_ADRES_TIP", record.getId().getAdresKod());
				oMap.put("UPD_DATE" , record.getUpdDate());
				oMap.put("ADDRESS1" , record.getAdres());
				oMap.put("ADDRESS_CITY" , LovHelper.diLov(record.getIlKod(), "10011/LOV_ADRES_IL", "IL_ADI"));
				oMap.put("ADDRESS_CITY_CODE" , record.getIlKod());
				oMap.put("ADDRESS_COUNTRY" , record.getUlkeKod());
				oMap.put("ADDRESS_TOWN" , LovHelper.diLov(record.getIlceKod(), record.getIlKod(), "10011/LOV_ADRES_ILCE", "ILCE_ADI"));
				oMap.put("ADDRESS_TOWN_CODE", record.getIlceKod());
				oMap.put("ADDRESS_ZIP_CODE" , record.getPostaKod());

			} else {
				oMap.put("TEBLIGAT_ADRESI", "Adres bulunamad�.");
			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN4410_SET_SESSION")
	public static GMMap setSession(GMMap iMap) {
		if ("B".equals(iMap.getString("SUBSTATUS")))
			iMap.put("STATUS", "I");
		else if ("C".equals(iMap.getString("SUBSTATUS")))
			iMap.put("STATUS", "C");
		else if ("K".equals(iMap.getString("SUBSTATUS")) || "M".equals(iMap.getString("SUBSTATUS")))
			iMap.put("STATUS", "K");
	   boolean isDefectCard = StringUtils.isNotBlank(iMap.getString("CAUSE_OF_DEFECT"));
	   boolean isSourceOfDefectCustomer = false;
	   if(isDefectCard)
        {
            isSourceOfDefectCustomer = "M".equals(iMap.getString("CAUSE_OF_DEFECT").substring(1,2));
            
            if(isSourceOfDefectCustomer)
            {
                iMap.put("EMBOSS_CODE",iMap.getString("CAUSE_OF_DEFECT"));
            }
        }
		iMap.put("PUT_MAP_TO_SESSION", true);
		iMap.put("CHANNEL", "CC");
		iMap.put("ATTRIBUTE_KEY", "4410_UPDATE_INFO");
		GMServiceExecuter.call("CNSPR_PUT_TO_CUSTOMER_SESSION", iMap);
		return new GMMap();
	}

	private static String maskCardNumber(String cardNumber) {
		return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})", "$1 **** **** $3");
	}

	@GraymoundService("BNSPR_GET_OCEAN_CARD_FOR_PAYMENT")
	public static GMMap getOceanCardForPayment(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap));
		try {
			for (int i = 0; i < oMap.getSize("CARD_DETAIL_INFO"); i++) {
				if(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI).equals("Credit")){
					GMMap stmtMap = GMServiceExecuter.call("BNSPR_GET_CC_CARD_LAST_STATEMENT", new GMMap().put("CARD_NO", oMap.getString("CARD_DETAIL_INFO", i, "CARD_NO")));
					oMap.put("CARD_DETAIL_INFO", i, "MASKED_CARD_NO", maskCardNumber(oMap.getString("CARD_DETAIL_INFO", i, CARD_NO)));
					oMap.put("CARD_DETAIL_INFO", i, "STMT_DATE", stmtMap.getDate("STMT_DATE"));
					oMap.put("CARD_DETAIL_INFO", i, "DUE_DATE", stmtMap.getDate("DUE_DATE"));
				}
			}
		} catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_GET_INTRA_CARD_FOR_PAYMENT")
	public static GMMap getIntraCardForPayment(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap));
		int j = 0;
		for (int i = 0; i < oMap.getSize("CARD_DETAIL_INFO"); i++) {
			if ("Prepaid".equals(oMap.getString("CARD_DETAIL_INFO", i, CARD_DCI))) {
				oMap.put("CARD_DETAIL_INFO_PP", j, MASKED_CARD_NO, maskCardNumber(oMap.getString("CARD_DETAIL_INFO", i, CARD_NO)));
				oMap.put("CARD_DETAIL_INFO_PP", j, CARD_EMBOSS_NAME_1, oMap.getString("CARD_DETAIL_INFO", i, CARD_EMBOSS_NAME_1));
				oMap.put("CARD_DETAIL_INFO_PP", j, CARD_NO, oMap.getString("CARD_DETAIL_INFO", i, CARD_NO));
				oMap.put("CARD_DETAIL_INFO_PP", j, CARD_STAT_DESC, oMap.getString("CARD_DETAIL_INFO", i, CARD_STAT_DESC));
				oMap.put("CARD_DETAIL_INFO_PP", j, CARD_AVAIL_LIMIT, oMap.getString("CARD_DETAIL_INFO", i, CARD_AVAIL_LIMIT));
				j++;
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_PAYMENT_RESPONSE")
	public static GMMap getPaymentRespone(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("CHANNEL", "CC");
		iMap.put("ATTRIBUTE_KEY", "IVR_RETURN_CODE");
		oMap = GMServiceExecuter.call("CNSPR_GET_FROM_CUSTOMER_SESSION", iMap);
		String returnCode = oMap.getString("RETURN_VALUE");
		oMap.put("RESPONSE", getPaymentResult(returnCode));
		oMap.put("RESPONSE_CODE", returnCode);
		iMap.put("ATTRIBUTE_KEY", "IVR_RETURN_CODE");
		iMap.put("ATTRIBUTE_VALUE", "");
		GMServiceExecuter.call("CNSPR_PUT_TO_CUSTOMER_SESSION", iMap);

		return oMap;
	}

	public static String getPaymentResult(String code) {
		if (code == null || code.trim().length() == 0) {
			code = UNDEFINED;
		}
		code = code.trim();
		return paymentResultMap.get(paymentResultMap.containsKey(code) ? code : UNDEFINED);
	}

	@GraymoundService("BNSPR_QRY4410_GET_INITIAL_FEE")
	public static GMMap getInitialFee(GMMap iMap) {

        boolean isJestCustomer = iMap.getBoolean("IS_JEST_CUSTOMER");
        boolean isLostByCourrier = "GK".equals(iMap.getString("CURRENT_STATUS"));
        boolean isDefectCard = StringUtils.isNotBlank(iMap.getString("CAUSE_OF_DEFECT"));
        boolean isSourceOfDefectBank = false;
      if (isDefectCard)    
      {  
          //Burada m��teri veya banka kaynakl� ar�zalardaki stat�lerle �cret sorguluyoruz.
          iMap.put("CARD_STAT_CODE", iMap.getString("CAUSE_OF_DEFECT").substring(0 , 1));
          iMap.put("CARD_SUB_STAT_CODE",iMap.getString("CAUSE_OF_DEFECT").substring(1,2));
          isSourceOfDefectBank = "B".equals(iMap.getString("CARD_SUB_STAT_CODE"));
      }
      else 
      {
          //Burada broken, stolen durumunda alabilecek stat�lerle fiyat bilgisi al�yoruz.
            if ("A".equals(iMap.getString("CARD_SUB_STAT_CODE"))) {
                iMap.put("CARD_STAT_CODE", "I");
                iMap.put("CARD_SUB_STAT_CODE", "M");
            } else if ("C".equals(iMap.getString("CARD_SUB_STAT_CODE")))
            {
                iMap.put("CARD_STAT_CODE", "C");
            }
            else if ("M".equals(iMap.getString("CARD_SUB_STAT_CODE")))
            {
                iMap.put("CARD_STAT_CODE", "K");
            }
            if(isLostByCourrier)
            {
                iMap.put("CARD_STAT_CODE", "K");
            }
      }

		GMMap oMap = new GMMap();
		String kuryeTipi = iMap.getString("KURYE_TIPI", "");
		GMMap feeMap = GMServiceExecuter.call("BNSPR_KART_YENILEME_UCRETLERI", iMap);
		//BigDecimal kartBedeli = feeMap.getBigDecimal("KART_BEDELI");
		BigDecimal kuryeUcreti = BigDecimal.ZERO;
		BigDecimal toplamUcret = BigDecimal.ZERO;

		String teslimatUcretleri = "TESLIMAT_UCRETLERI";
        if(!isSourceOfDefectBank && !isLostByCourrier )
        {
		for (int i = 0; i < feeMap.getSize(teslimatUcretleri); i++) {
			if (feeMap.getString(teslimatUcretleri, i, "KURYE_TIPI").equals(kuryeTipi)){
				
				if ((!StringUtil.isEmpty(feeMap.getString(teslimatUcretleri, i, "URUN_ID"))) && (feeMap.getString("URUN_ID").equals(feeMap.getString(teslimatUcretleri, i, "URUN_ID")))){
					kuryeUcreti = feeMap.getBigDecimal(teslimatUcretleri, i, "UCRET");
					break;
				}
				if (StringUtil.isEmpty(feeMap.getString(teslimatUcretleri, i, "URUN_ID"))){
					kuryeUcreti = feeMap.getBigDecimal(teslimatUcretleri, i, "UCRET");
				}
			}
			
		}
	
        }
	//	toplamUcret = kartBedeli.add(loyaltyBedeli).add(kuryeUcreti);
       
	   oMap.put("KURYE_BEDELI",BigDecimal.ZERO);//tff_kart_yenileme_tx tablosu not null. Exception almas�n diye.
	   oMap.put("VIZE_BEDELI", BigDecimal.ZERO); //tff_kart_yenileme_tx tablosu not null. Exception almas�n diye.
	   oMap.put("LOYALTY_BEDELI", BigDecimal.ZERO);//tff_kart_yenileme_tx tablosu not null. Exception almas�n diye.
	    
	   if (!isJestCustomer && !"BB".equals(iMap.getString("CAUSE_OF_DEFECT"))) {
		//	oMap.put("KART_BEDELI", kartBedeli); Kenan D�zg�n : Kart Bedelini art�k get_card_fee'ten alacagiz.
			oMap.put("KURYE_BEDELI", kuryeUcreti);
		
		}
	 
	    GMMap kartBedeliMap;
	   
	  /* if ("O".equals(iMap.getString("SYSTEM")))
	   {*/
		 iMap.put(CARD_NO, iMap.getString("KART_NO"));
		 if ("NN".equals(iMap.getString("CURRENT_STATUS")))
		 { 
			 iMap.put("EMBOSS_CODE",isSourceOfDefectBank?"AB":"AM");
			 iMap.put("CARD_STAT_CODE", "");
			 iMap.put("CARD_SUB_STAT_CODE", "");
			 
		 }
		 else
		 {
			 iMap.put("EMBOSS_CODE","");
		 }
	    // kartBedeliMap =GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_FEE",iMap);
	     kartBedeliMap =GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_FEE",iMap);

	/*   }
	   else 
	   {
		   iMap.put(CARD_NO, iMap.getString("KART_NO"));
	       kartBedeliMap =GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_FEE", iMap);
	   }*/
	
	   
	   if (StringUtils.isEmpty( kartBedeliMap.getString("CARD_FEE")))
	   {
	       kartBedeliMap.put("CARD_FEE", BigDecimal.ZERO);
	   }
		   
	  
	    toplamUcret =   kartBedeliMap.getBigDecimal("CARD_FEE").add(oMap.getBigDecimal("KURYE_BEDELI"));
        
	    oMap.put("KART_BEDELI" , kartBedeliMap.getBigDecimal("CARD_FEE"));
	    oMap.put("COUNT",kartBedeliMap.getString("COUNT"));
	    oMap.put("TOPLAM", toplamUcret);
	    
		oMap.put("PUT_MAP_TO_SESSION", true);
		oMap.put("CHANNEL", "CC");
		oMap.put("ATTRIBUTE_KEY", "4410_MUHASEBE_INFO");
		GMServiceExecuter.call("CNSPR_PUT_TO_CUSTOMER_SESSION", oMap);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_FINANCIAL_ADJUSTMENT")
	public static GMMap financialAdjustment(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		GMMap oMap = new GMMap();

		iMap.put("CHANNEL", "CC");
		iMap.put("GET_MAP_FROM_SESSION", true);
		iMap.put("ATTRIBUTE_KEY", "4410_MUHASEBE_INFO");
		oMap = GMServiceExecuter.call("CNSPR_GET_FROM_CUSTOMER_SESSION", iMap);
		GMMap muhasebeMap = oMap.getMap("RETURN_VALUE");
		   
		iMap.put("BSMV_RATE", BigDecimal.ZERO);
	    iMap.put("KKF_RATE", BigDecimal.ZERO);
	    iMap.put("TXN_CURR_CODE", "TRY");
	    iMap.put("TXN_DATE", sdf.format(new Date()));
	    iMap.put("TXN_STATE", "4");
		
        if ( "KURYE_BEDELI".equals(iMap.getString("ADJUSTMENT_TYPE")))
        {
            iMap.put("TXN_AMOUNT", muhasebeMap.getBigDecimal("KURYE_BEDELI").divide(new BigDecimal(Double.valueOf("1.05")),2,RoundingMode.HALF_UP));
            iMap.put("BSMV_RATE","-1");
        }
        else if ("KART_BEDELI".equals(iMap.getString("ADJUSTMENT_TYPE")))
        {
            iMap.put("TXN_AMOUNT", muhasebeMap.getBigDecimal("KART_BEDELI"));
        }
        else
        {
            iMap.put("TXN_AMOUNT", muhasebeMap.getBigDecimal("TOPLAM"));
        }
	

		oMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", iMap));
         
        if ("KURYE_BEDELI".equals(iMap.getString("ADJUTMENT_TYPE"))){
            oMap.put("KURYE_BEDELI", muhasebeMap.getBigDecimal("KURYE_BEDELI"));
        } else
            if ("KART_BEDELI".equals(iMap.getString("ADJUTMENT_TYPE"))){
                oMap.put("KART_BEDELI", muhasebeMap.getBigDecimal("KART_BEDELI"));

            } else{
                oMap.put("TOPLAM", muhasebeMap.getBigDecimal("TOPLAM"));
            }
	     
	
		return oMap;
	}

	public static int daysBetween(Date d1, Date d2) {
		return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
	}

	@GraymoundService("BNSPR_QRY4410_PAYMENT_VIA_ACCOUNT")
	public static GMMap paymentViaAccount(GMMap iMap) {
		GMMap oMap = new GMMap();
		String serviceName = null;
        boolean isSourceOfDefectCustomer = "M".equals(iMap.getString("CAUSE_OF_DEFECT"));
		BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");

		iMap.put("CHANNEL", "CC");
		iMap.put("GET_MAP_FROM_SESSION", true);
		iMap.put("ATTRIBUTE_KEY", "4410_MUHASEBE_INFO");
		oMap = GMServiceExecuter.call("CNSPR_GET_FROM_CUSTOMER_SESSION", iMap);
		GMMap muhasebeMap = oMap.getMap("RETURN_VALUE");

		muhasebeMap.put("KART_NO", iMap.getString("CARD_NO"));
		muhasebeMap.put("HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
		muhasebeMap.put("TRX_NO", txNo);
		muhasebeMap.put("ODEME_SEKLI", "H");
		muhasebeMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
		muhasebeMap.put("TCKN", iMap.getBigDecimal("TCKN"));

		try {
			muhasebeMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3808_SAVE", muhasebeMap));
		} catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		GMMap onayMap = new GMMap();
		onayMap.put("ISLEM_TURU", "O");
		onayMap.put("ISLEM_NO", txNo);
		
		if (isSourceOfDefectCustomer)
		{
		    iMap.put("EMBOSS_CODE", "AM");
		    iMap.put("EXTEND_EXPIRY" , "Y");
            
		    if ("O".equals(iMap.getString("SYSTEM")) )
		    {
		    	serviceName = "BNSPR_OCEAN_CARD_RENEWAL";
		    }
		    else
		    {
		    	serviceName = "BNSPR_INTRACARD_CARD_RENEWAL";
		    }
		}
		else
		{
		    if ("C".equals(iMap.getString("SUBSTATUS"))) {
	            iMap.put("STATUS", "C");
	        } else if ("K".equals(iMap.getString("SUBSTATUS")) || "M".equals(iMap.getString("SUBSTATUS"))) {
	            iMap.put("STATUS", "K");
	        } else if ("N".equals(iMap.getString("SUBSTATUS"))) {
	            iMap.put("STATUS", "A");
	            iMap.put("SUBSTATUS", iMap.getString("CAUSE_OF_DEFECT"));
	        }
		    
		    if ("O".equals(iMap.getString("SYSTEM")) )
		    {
		    	iMap.put("DESCRIPTION", "");
		    	serviceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
		    }
		    else
		    {
		    	serviceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";
		    }
		}
		

	
		oMap.putAll(GMServiceExecuter.call(serviceName, iMap));
		if (!"2".equals(oMap.getString("RETURN_CODE"))) {
			throw new GMRuntimeException(0, oMap.getString("RETURN_DESCRIPTION"));
		} else {
			oMap.put("TRX_NO", txNo);
			oMap.putAll(GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_UPDATE_NEW_CARD_NO", oMap));
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_GET_AKTIF_HESAP")
	public static GMMap getAktifHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_AKTIF_HESAP", iMap));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_ACCOUNTING_ZERO_COST")
	public static GMMap qry4410AccountingZeroCost(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap muhasebeMap = new GMMap();
		BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		try {
			muhasebeMap.put("TRX_NO", txNo);
			muhasebeMap.put("KART_BEDELI", BigDecimal.ZERO);
			muhasebeMap.put("KURYE_BEDELI", BigDecimal.ZERO);
			muhasebeMap.put("LOYALTY_BEDELI", BigDecimal.ZERO);
			muhasebeMap.put("VIZE_BEDELI", BigDecimal.ZERO);
			muhasebeMap.put("KART_NO", iMap.getString("CARD_NO"));
			muhasebeMap.put("YENI_KART_NO", iMap.getString("NEW_CARD_NO"));
			muhasebeMap.put("ODEME_SEKLI", "S");
			muhasebeMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
			muhasebeMap.put("TCKN", iMap.getString("TCKN"));
			muhasebeMap.putAll(GMServiceExecuter.call("BNSPR_TRN3808_SAVE", muhasebeMap));

			GMMap onayMap = new GMMap();
			onayMap.put("ISLEM_TURU", "O");
			onayMap.put("ISLEM_NO", txNo);

			oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
		}
		catch (Exception e) {
			e.printStackTrace(); //zaten onayl� hatas� al�nca hata f�rlatmas�n. bu yap� de�i�meli 0774SB 23.01.2020
		}
		

		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_ACCOUNTING_UPDATE_NEW_CARD_NO")
	public static GMMap qry4410AccountingUpdateNewCardNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap muhasebeMap = new GMMap();
		BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		muhasebeMap.putAll(GMServiceExecuter.call("BNSPR_TRN3808_UPDATE", iMap));

		/* Kart yenileme hatas� onay hatas� i�in commentlendi 26.12.2017
		GMMap onayMap = new GMMap();
		onayMap.put("ISLEM_TURU", "O");
		onayMap.put("ISLEM_NO", txNo);

		oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap));
		*/
		
		return oMap;
		
	}

	@GraymoundService("BNSPR_QRY4410_UPDATE_FREE_CARD")
    public static GMMap updateFreeCard(GMMap iMap) {
        GMMap oMap = new GMMap();
       
        boolean isCreditCard = "Credit".equals(iMap.getString("CARD_DCI"));
        boolean renew = "N".equals(iMap.getString("SUBSTATUS"));
        boolean isBankProblem = iMap.getBoolean("IS_BANK_PROBLEM"); 
        try{
        String serviceName ="";
        if(isBankProblem){
            iMap.put("STATUS", "B");
            iMap.put("SUBSTATUS", "B");
            if (isCreditCard)
                serviceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
            else
                serviceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";
        }
        else if (renew) {
            if (isCreditCard)
                serviceName = "BNSPR_OCEAN_CARD_RENEWAL";
            else
                serviceName = "BNSPR_INTRACARD_CARD_RENEWAL";
            
            oMap.put("NEW_CARD_NO" , iMap.getString("CARD_NO"));
        } else {

            if ("C".equals(iMap.getString("SUBSTATUS")))
                iMap.put("STATUS", "C");
            else if ("K".equals(iMap.getString("SUBSTATUS"))|| "M".equals(iMap.getString("SUBSTATUS")))
                iMap.put("STATUS", "K");
            if (isCreditCard)
                serviceName = "BNSPR_OCEAN_UPDATE_CARD_STATUS";
            else
                serviceName = "BNSPR_INTRACARD_UPDATE_CARD_STATUS";

        }
        
        oMap.putAll(GMServiceExecuter.call(serviceName , iMap));
        
        }catch(Exception e){
            ExceptionHandler.convertException(e);
        }
        
        if("2".equals(oMap.getString("RETURN_CODE"))){
            iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , iMap).getBigDecimal("TRX_NO"));
            iMap.put("NEW_CARD_NO", oMap.getString("NEW_CARD_NO"));
            try {
                GMServiceExecuter.call("BNSPR_QRY4410_ACCOUNTING_ZERO_COST", iMap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
       
        return oMap;
    }

	@GraymoundService("BNSPR_TRN4410_ENABLE_RENEWAL_CHECK")
	public static GMMap enableRenewalCheck(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean isRenewEnabled = false;
		boolean isRenewDefault = false;
		oMap.put("IS_RENEW_ENABLED", isRenewEnabled);
		oMap.put("IS_RENEW_DEFAULT", isRenewDefault);
		boolean isVirtualPP = "914".equals(iMap.getString("PRODUCT_ID"));
		
		if(isVirtualPP){
			return oMap;
		}

		if (StringUtils.isBlank(iMap.getString("STATUS")) || StringUtils.isBlank(iMap.getString("SUBSTATUS")) || StringUtils.isBlank(iMap.getString("TARGET_STATUS"))) {
			return oMap;
		}
		CardSmartSoftStatus currentStatus = CardSmartSoftStatus.valueOf(iMap.getString("STATUS") + iMap.getString("SUBSTATUS"));
		CardSmartSoftStatus targetStatus = CardSmartSoftStatus.valueOf(iMap.getString("TARGET_STATUS"));

		switch (currentStatus) {

		case NN:
			switch (targetStatus) {
			case BB:
				isRenewEnabled = false;
				isRenewDefault = true;
				break;
			case AM:
				isRenewEnabled = false;
				isRenewDefault = true;
				break;
			case GC:
				isRenewEnabled = true;
				isRenewDefault = false;
				break;
			case GM:
				isRenewEnabled = true;
				isRenewDefault = false;
				break;
			default: // GN GX GA
				break;
			}
			break;
		case GN:
			isRenewEnabled = true;
			isRenewDefault = false;
			break;
		case GJ:
			switch (targetStatus) {
			case GC:
				isRenewEnabled = true;
				isRenewDefault = false;
				break;
			case GM:
				isRenewEnabled = true;
				isRenewDefault = false;
				break;
			case GK:
				isRenewEnabled = false;
				isRenewDefault = true;
				break;
			default: // GV ve GA
			}
			break;
		case GX:
			isRenewEnabled = true;
			isRenewDefault = false;
			break;
		default:
		}
		oMap.put("IS_RENEW_ENABLED", isRenewEnabled);
		oMap.put("IS_RENEW_DEFAULT", isRenewDefault);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY4410_INTRACARD_GET_CARD_MEMO")
	public static GMMap qry4410AMemo(GMMap iMap) {
		String serviceName = "";
		serviceName = "I".equals(iMap.getString("SYSTEM")) ? "BNSPR_INTRACARD_GET_CARD_MEMO" : "BNSPR_OCEAN_GET_CARD_MEMO";
		GMMap oMap = GMServiceExecuter.call(serviceName, iMap);

		for (int i = 0; i < oMap.getSize(MEMO_LIST); i++) {
			oMap.put(MEMO_LIST, i, "OLD_CARD_NO", iMap.getString("OLD_CARD_NO"));
			if (StringUtils.isNotBlank(oMap.getString(MEMO_LIST, i, "UPDATE_DATE")) && oMap.getString(MEMO_LIST, i, "UPDATE_DATE").length() == 14) {
				oMap.put(MEMO_LIST, i, "PROCESS_DATE", oMap.getString(MEMO_LIST, i, "UPDATE_DATE").substring(0, 8));
				oMap.put(MEMO_LIST, i, "PROCESS_TIME", oMap.getString(MEMO_LIST, i, "UPDATE_DATE").substring(8, 14));
			}

		}
		return oMap;
	}
	
	 public static boolean mchipFilter(GMMap cardMap,int index,int listedCardsStateInput, String ArrayName, String ParamName)
	  {

		  boolean listedCardsState=false;
		
	      if(listedCardsStateInput == 1 && ("44".equals(cardMap.getString(ArrayName , index , ParamName)) 
				 				         || "55".equals(cardMap.getString(ArrayName , index , ParamName))
				 				         || "99".equals(cardMap.getString(ArrayName , index , ParamName))))
			   listedCardsState=true;
		  
		  if(listedCardsStateInput == 0 && ("44".equals(cardMap.getString(ArrayName , index , ParamName)) 
									     || "55".equals(cardMap.getString(ArrayName , index , ParamName))
									     || "99".equals(cardMap.getString(ArrayName , index , ParamName))))
			   listedCardsState=false;
		  
		  
		  return listedCardsState;
	  }

}
