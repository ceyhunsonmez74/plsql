package tr.com.aktifbank.bnspr.creditcard.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KkTahsisDegerTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** BNSPR_TRN3829 Kredi Karti Basvuru Havuzu Izleme Ekrani Servisleri<br>
 *  BNSPR_TRN3829_AKIS_HAREKETLERI Kredi Karti Islem Akisi Izleme Ekrani Servisleri
 * 
 * @author murat.el
 * @since 23/08/2013
 */
public class CreditCardQRY3829Services {
	
	//---------------------------------------------------------------------
	//******************************************************* 3829 Ekrani
	//---------------------------------------------------------------------
	/**
	 * Ekran acilisinda alinacak degerleri bulur.
	 */
	@GraymoundService("BNSPR_QRY3829_INITIALIZE")
	public static GMMap fillInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Durum
			oMap.putAll(CreditCardServicesUtil.getParameterList("DURUM_LIST", "KK_AKIS_DURUM_KOD", "HEPSI"));
			//Durum On Basvuru
			GuimlUtil.wrapMyCombo(oMap, "DURUM_LIST_ON_BASVURU", "ON_BASVURU", "On Basvuru");
			
			//Baslang�c ve bitis tarihleri
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3873_GET_START_FINISH_DATES", iMap));
			
			//Kullan�c� kodu
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap));
			
			//Kanal Listesi
			StringBuilder query = new StringBuilder();
			query.append(" SELECT b.kanal_kod, bnspr.pkg_genel_pr.kanal_adi(b.kanal_kod) kanal_adi");
			query.append(" FROM bnspr.kk_basvuru b");
			query.append(" GROUP BY b.kanal_kod");
			query.append(" ORDER BY 2");
			oMap.putAll(DALUtil.fillComboBox(iMap, "KANAL", true, query.toString()));
			
			//Hunter aktif mi
			iMap.put("PARAMETRE", "KK_MAC_LIMIT_ARTIS_VAR_MI");
			oMap.put("HUNTER_AKTIF_MI", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * Ekrandan girilen kriterlere uygun olarak basvurulari listeler.
	 */
	@GraymoundService("BNSPR_QRY3829_LISTELE")
	public static GMMap listBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_RC3829.Rc_Qry3829_List_Basvuru(?,?,?,?,?,?,?,?,?,?,?,?)}";
            stmt = conn.prepareCall(query);
            
            int parameterIndex = 1;
            
            stmt.registerOutParameter(parameterIndex++, -10);
            stmt.setString(parameterIndex++, iMap.getString("ROL"));
            stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("BASVURU_NO"));
            stmt.setString(parameterIndex++, CreditCardServicesUtil.nvl(iMap.getString("TC_KIMLIK_NO").trim(), null));
            stmt.setString(parameterIndex++, CreditCardServicesUtil.nvl(iMap.getString("AD").trim(), null));
            stmt.setString(parameterIndex++, CreditCardServicesUtil.nvl(iMap.getString("IKINCI_AD").trim(), null));
            stmt.setString(parameterIndex++, CreditCardServicesUtil.nvl(iMap.getString("SOYAD").trim(), null));
            stmt.setString(parameterIndex++, iMap.getString("KANAL"));
            stmt.setString(parameterIndex++, StringUtils.isBlank(CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST"))) ? "HEPSI," :
                CreditCardServicesUtil.convertGMListToString(iMap.get("DURUM_LIST")));
            
            Date basTarih = iMap.getDate("BASLANGIC_TARIHI");
            if (basTarih != null) {
            	stmt.setDate(parameterIndex++, new java.sql.Date(basTarih.getTime()));
            } else {
            	stmt.setDate(parameterIndex++, null);
            }
            
            Date bitTarih = iMap.getDate("BITIS_TARIHI");
            if (bitTarih != null) {
            	stmt.setDate(parameterIndex++, new java.sql.Date(bitTarih.getTime()));
            } else {
            	stmt.setDate(parameterIndex++, null);
            }
            stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("KART_LIMITI_ALT_SINIR"));
            stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("KART_LIMITI_UST_SINIR"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResultsPutStr(rSet, "BASVURU_LIST");
            oMap.put("TOPLAM_KAYIT", oMap.getSize("BASVURU_LIST"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	
	/** Basvurunun durumuna gore islem gorecegi ekranin adini bulur.<br>
	 * Izleme Paneli -> ISLEMI_GETIR Butonu
	 * 
	 * @param iMap - DURUM_KOD
	 */
	@GraymoundService("BNSPR_QRY3829_GET_EKRAN_ADI_BY_DURUM")
	public static GMMap getEkranAdiByDurumKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		StringBuilder query = new StringBuilder();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
            query.append(" SELECT key3");
            query.append(" FROM v_ml_gnl_param_text");
            query.append(" WHERE kod = 'KK_AKIS_DURUM_KOD'");
            query.append(" AND key1 = ?");
            
            stmt = conn.prepareCall(query.toString());
            stmt.setString(1, iMap.getString("DURUM_KOD"));
            rSet = stmt.executeQuery();
            
            if(rSet.next()) {
            	oMap.put("ISLEM_EKRAN_ADI", rSet.getString(1));
            }
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Basvuruya ait islemlerin hareketlerini kullanicilara atar ya da kullanicidan alir.<br>
	 * Izleme Paneli -> KULLANICI_ISLEM Butonu
	 * 
	 * @param iMap <li> ROL->U:Uzerimdeki Isler(Iade Et)
	 *                       R:Rolumdeki Isler(Uzerime Al)
	 *                       T:Uzerimdeki Isi Tamamla
	 *             <li> BASVURU_NO: Basvuru Numarasi
	 *             <li> DURUM_KOD: Basvuru Durumu
	 *             <li> TX_NO: Basvuruya ait islem tamamlaninca alinan islem numarasi
	 *             <li> ACIKLAMA: Islem Aciklamasi
	 *             <li> KULLANICI_KONTROL: Islem Aciklamasi
	 */
	@GraymoundService("BNSPR_QRY3829_KULLANICI_ISLEM")
	public static GMMap setKullaniciIslemDurumu(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			//Kullanicinin islemi almasi-birakmasi
			conn = DALUtil.getGMConnection();
			
			String islemTipi = iMap.getString("ROL");
			String akisTipi = iMap.getString("AKIS_TIPI", "KK");
			if ("U".equals(islemTipi)) {//Uzerinde ise iade edebilirsin
				query = "{call PKG_RC3829.Rc_Qry3829_Islemi_Iade_Et(?,?,?,?)}";
				stmt = conn.prepareCall(query);
	            stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
	            stmt.setString(2, iMap.getString("DURUM_KOD"));
	            stmt.setString(3, akisTipi);
	            stmt.setString(4, iMap.getString("KULLANICI_KONTROL", CreditCardServicesUtil.EVET));
			} else if ("R".equals(islemTipi)) {//Uzerinde degilse alabilirsin
				query = "{call PKG_RC3829.Rc_Qry3829_Islemi_Uzerime_Al(?,?,?)}";
				stmt = conn.prepareCall(query);
	            stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
	            stmt.setString(2, iMap.getString("DURUM_KOD"));
	            stmt.setString(3, akisTipi);
			} else if ("T".equals(islemTipi)) {//Uzerinde ise islemi tamamlayabilirsin
				query = "{call PKG_RC3829.Rc_Qry3829_Islemi_Tamamla(?,?,?,?,?)}";
				stmt = conn.prepareCall(query);
	            stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
	            stmt.setBigDecimal(2, iMap.getBigDecimal("TX_NO"));
	            stmt.setString(3, iMap.getString("DURUM_KOD"));
	            stmt.setString(4, iMap.getString("ACIKLAMA"));
	            stmt.setString(5, akisTipi);
			} else {
				CreditCardServicesUtil.raiseGMError("250", "��lem Tipi");
			}

            stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Verilen basvuru numarasinin basvuru bilgileri girisi tamamlanmis mi?<br>
	 * @author murat.el
	 * @since 04.02.2014
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>BASVURU_NO - Basvuru Numarasi
	 * @return Sorgu sonuclari<br>
	 *        <li>BASVURU_ALINDI_MI - Basvuru Bilgileri Alinmis Mi? (E|H)
	 */
	@GraymoundService("BNSPR_QRY3829_BASVURU_ALINDI_MI")
	public static GMMap basvuruAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String basvuruAlindiMi = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_RC3829.Rc_Qry3829_Basvuru_Alindi_Mi(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			basvuruAlindiMi = stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("BASVURU_ALINDI_MI", basvuruAlindiMi);
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3829_AKIS_HAREKETLERI Ekrani
	//---------------------------------------------------------------------
	/** Istenilen basvuruya ait basvuru akisindaki kullanici islemlerini listeler.
	 * 
	 * @param iMap - BASVURU_NO
	 */
	@GraymoundService("BNSPR_QRY3829_AKIS_HAREKET_LISTELE")
	public static GMMap listBasvuruAkisHareket(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
            query = "{? = call PKG_RC3829.Rc_Qry3829_List_Akis_Hareket(?)}";
            stmt = conn.prepareCall(query);
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResultsPutStr(rSet, "AKIS_HAREKET_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	//---------------------------------------------------------------------
	//******************************************************* 3829_MESAJ_KUTUSU_ISLEM Ekrani
	//---------------------------------------------------------------------
	/** Istenilen TAHSIS islemine ait sonraki durum bilgisini getirir.
	 * 
	 * @param iMap - TRX_NO
	 */
	@GraymoundService("BNSPR_QRY3829_GET_TAHSIS_SONRAKI_DURUM")
	public static GMMap getTahsisSonrakiDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			KkTahsisDegerTx kkTahsisDegerTx =
					(KkTahsisDegerTx) session.get(KkTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kkTahsisDegerTx != null) {
				if (StringUtils.isNotBlank(iMap.getString("ACIKLAMA"))) {
					kkTahsisDegerTx.setAciklama(iMap.getString("ACIKLAMA"));
					session.save(kkTahsisDegerTx);
					session.flush();
				}
				
				oMap.put("SONRAKI_DURUM_KODU", kkTahsisDegerTx.getIslemSonrasiDurumKodu());
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/** Ayni durumda kaliyorsa tarihceye kayit at.
	 * 
	 * @param iMap - BASVURU_NO, TRX_NO, DURUM_KOD
	 */
	@GraymoundService("BNSPR_QRY3829_TARIHCE_KAYDET")
	public static GMMap gelenKutusuTarhiceKaydet(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			if ("3874".equals(iMap.getString("ISLEM_KODU"))) {
				query = "{ call PKG_TRN3874.Rc_Qry3874_Tarihce_Kaydet(?) }";
				stmt = conn.prepareCall(query);
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
				
	            stmt.execute();
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3829_ISLEM_UZERIMDE_MI")
	public static GMMap islemUzerimdeMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_RC3829.Rc_Qry3829_Islem_Uzerimde_Mi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, CreditCardServicesUtil.nvl(iMap.getString("AKIS_TIPI"), "KK"));
			stmt.setString(4, iMap.getString("KULLANICI_KODU"));
			stmt.execute();

			String islemUzerimdeMi = stmt.getString(1);
			oMap.put("ISLEM_UZERIMDE_MI", CreditCardServicesUtil.nvl(islemUzerimdeMi, CreditCardServicesUtil.HAYIR));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Tff musterisi icin kanaldan alinmasi gereken dokumanlari listeler.<br>
	 * @author murat.el
	 * @since TY-5195
	 * @param iMap - Sorgu Kriterleri<br>
	 * 			<li>BASVURU_NO - Kredi karti basvuru numarasi
	 * 			<li>HATA_VERILSIN_MI - Islem sonucunda yakin ise hata verilsin mi(E:Evet|H:Hayir)
	 * @return oMap - Sorgu sonuclari<br>
	 * 			<li>YAKIN_MI - Basvuran islemcinin yakini mi(E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_QRY3829_BASVURAN_ISLEMCI_YAKINI_MI")
	public static GMMap musteriIslemciYakiniMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_rc3829.basvuran_islemci_yakini_mi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("HATA_VERILSIN_MI"));
			stmt.execute();

			oMap.put("YAKIN_MI", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	   @GraymoundService("BNSPR_QRY3829_LOG_CC")
	    public static GMMap qry3829LogCC(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try{
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        }
	        return oMap;
	    }
}
