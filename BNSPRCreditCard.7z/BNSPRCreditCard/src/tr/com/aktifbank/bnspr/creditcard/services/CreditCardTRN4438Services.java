package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdKartNakitAvansTx;
import tr.com.aktifbank.bnspr.dao.CrdTnaTaksitListesiTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardTRN4438Services implements OceanMapKeys {
    
    public static boolean isNotExistAndNull(GMMap iMap, String key) {
        
        if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0){
            return true;
        } else{
            return false;
        }
    }
    
    @GraymoundService("BNSPR_CREDIT_CARD_INSTALLMENT_CASH_ADVANCE_FOR_EVAM")
    public static GMMap CreditCardInstallmentCashAdvanceForEvam(GMMap iMap) {
         GMMap oMap = new GMMap();
        try{
            
         
            
            iMap.put("HESAP_NO",DALUtil.callOneParameterFunction("{? = call PKG_TRN4438.get_hesap_no(?)}", Types.NUMERIC, iMap.getBigDecimal("MUSTERI_NO")));
            
            Session session = DAOSession.getSession("BNSPRDal");
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                iMap.put("TRX_NO" , trxNo);
            }
            
            CrdKartNakitAvansTx crdTaksitliNakitAvansTx = new CrdKartNakitAvansTx();
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                crdTaksitliNakitAvansTx.setTxNo(trxNo);
                iMap.put("TRX_NO" , trxNo);
            } else crdTaksitliNakitAvansTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            
            GMMap aciklamaMap = new GMMap();
            aciklamaMap.put("MESSAGE_NO" , "4328");
            aciklamaMap.put("P1" , iMap.getString("CARD_NO"));
            aciklamaMap.put("P2" , iMap.getString("TRX_NO"));
            GMMap channelMap = new GMMap();
            channelMap.put("KANAL_KODU" , (String) GMContext.getCurrentContext().getSession().get("CHANNEL_CODE"));
            aciklamaMap.put("P3" , GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_ADI" , channelMap).getString("KANAL_ADI"));
            String aciklama = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE" , aciklamaMap).get("ERROR_MESSAGE");
            
           
            
            crdTaksitliNakitAvansTx.setAciklama(aciklama);
            crdTaksitliNakitAvansTx.setAliciAdiSoyadi(iMap.getString("ADI_SOYADI"));
            
            crdTaksitliNakitAvansTx.setAliciHesapNo(iMap.getBigDecimal("HESAP_NO"));
            crdTaksitliNakitAvansTx.setAliciMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            crdTaksitliNakitAvansTx.setAsilKartNo(iMap.getString("CARD_NO"));
            crdTaksitliNakitAvansTx.setCvv2(new BigDecimal(123));
            crdTaksitliNakitAvansTx.setCvv2Exists("N");
            crdTaksitliNakitAvansTx.setDovizKodu("TRY");
            crdTaksitliNakitAvansTx.setHesapDovizKodu("TRY");
            crdTaksitliNakitAvansTx.setKartNo(iMap.getString("CARD_NO"));
            crdTaksitliNakitAvansTx.setKaynak("HESABA");
            crdTaksitliNakitAvansTx.setKullanabilirNaLimit(iMap.getBigDecimal("KULL_NA_LIMIT"));
            crdTaksitliNakitAvansTx.setSonKullanmaTarihi(iMap.getBigDecimal("SON_KULL_TARIHI"));
            crdTaksitliNakitAvansTx.setTutar(iMap.getBigDecimal("TUTAR"));
            crdTaksitliNakitAvansTx.setInstallCount(iMap.getBigDecimal("INSTALL_COUNT"));
            
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                crdTaksitliNakitAvansTx.setTxNo(trxNo);
                iMap.put("TRX_NO" , trxNo);
            } else crdTaksitliNakitAvansTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            
            session.saveOrUpdate(crdTaksitliNakitAvansTx);
            
            session.flush();
            iMap.put("TRX_NAME" , "4438");
            oMap =  GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            oMap.put("HESAP_NO" , iMap.getBigDecimal("HESAP_NO"));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_CREDIT_CARD_GET_INSTALL_SIMULATE_DATA_FOR_EVAM")
    public static GMMap GetInstallSimulateDataForEvam(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            int row = 0;
            GMMap pMap = new GMMap();
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date date = new Date();
            
            pMap.put(CARD_NO , iMap.getString("CARD_NO" , " "));
            GMMap cardMap = new GMMap();
            pMap.put(CARD_DCI , "All");
            cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS" , pMap);
            pMap.put(CARD_LEVEL , cardMap.get(CARD_DETAIL_INFO , row , CARD_LEVEL) == null ? " " : cardMap.getString(CARD_DETAIL_INFO , row , CARD_LEVEL));
            pMap.put(COUNTRY_CODE , "TR");
            
            pMap.put(OTC , "11");
            pMap.put(OTS , "10");
            pMap.put(REQUEST_DATE , dateFormat.format(date));
            pMap.put(TXN_DATE , dateFormat.format(date));
            pMap.put(TXN_INSTALL_TYPE , "T");
            pMap.put(TXN_SOURCE , "O");
            pMap.put(TXN_TRM , iMap.get(TXN_TRM) == null ? "CT" : iMap.getString(TXN_TRM));
            
            pMap.put(TXN_AMOUNT , iMap.getBigDecimal("TUTAR" , new BigDecimal(0)));
            pMap.put(INSTALL_COUNT , iMap.getInt("INSTALL_COUNT" , row));
            pMap.put(PRODUCT_ID , cardMap.get(CARD_DETAIL_INFO , row , PRODUCT_ID) == null ? " " : cardMap.get(CARD_DETAIL_INFO , 0 , PRODUCT_ID));
            
            pMap.put(MCC , iMap.getInt("MCC" , 0));
            
            oMap = GMServiceExecuter.call("BNSPR_GENERAL_QUERY_OF_PAYMENT_PLAN" , pMap);
            
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                iMap.put("TRX_NO" , trxNo);
                oMap.put("TRX_NO" , trxNo);
            }
            int installCount = oMap.getSize("LIST");
            
            if (installCount > 0){
                oMap.put("ILK_ODEME_TARIHI" , oMap.getDate("LIST" , 0 , "INSTALL_DATE"));
                oMap.put("TOPLAM_TUTAR" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_AMOUNT"));
                oMap.put("ISLEM_UCRETI" , oMap.getBigDecimal("LIST" , 0 , "INSTALL_FEE"));
                oMap.put("TAKSIT_TUTARI" , oMap.getBigDecimal("LIST" , 0 , "INSTALL_AMOUNT"));
                oMap.put("SON_ODEME_TARIHI" , oMap.getDate("LIST" , installCount - 1 , "INSTALL_DATE"));
                oMap.put("FAIZ_ORANI" , oMap.getString("LIST" , installCount - 1 , "INTEREST_RATE"));
                oMap.put("TOPLAM_KKDF" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_KKDF_AMOUNT"));
                oMap.put("TOPLAM_BSMV" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_BSMV_AMOUNT"));
                oMap.put("FEE_BASIC" , oMap.getBigDecimal("LIST" , 0 , "FEE_BASIC"));
                oMap.put("FEE_BSMV" , oMap.getBigDecimal("LIST" , 0 , "FEE_BSMV"));
            }
            Session session = DAOSession.getSession("BNSPRDal");
            List<CrdTnaTaksitListesiTx> crdTnaTaksitList = session.createCriteria(CrdTnaTaksitListesiTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            for (CrdTnaTaksitListesiTx c : crdTnaTaksitList){
                session.delete(c);
            }
            session.flush();
            
            for (int i = 0; i < installCount; i++){
                CrdTnaTaksitListesiTx crdTnaTaksitListesiTx = new CrdTnaTaksitListesiTx();
                crdTnaTaksitListesiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
                crdTnaTaksitListesiTx.setInstallNo(oMap.getBigDecimal("LIST" , i , "INSTALL_NO"));
                crdTnaTaksitListesiTx.setInstallDate(oMap.getDate("LIST" , i , "INSTALL_DATE"));
                crdTnaTaksitListesiTx.setInstallAmount(oMap.getBigDecimal("LIST" , i , "INSTALL_AMOUNT"));
                crdTnaTaksitListesiTx.setInstallBasicAmount(oMap.getBigDecimal("LIST" , i , "INSTALL_BASIC_AMOUNT"));
                crdTnaTaksitListesiTx.setInstallFee(oMap.getBigDecimal("LIST" , i , "INSTALL_FEE"));
                crdTnaTaksitListesiTx.setBsmvAmount(oMap.getBigDecimal("LIST" , i , "BSMV_AMOUNT"));
                crdTnaTaksitListesiTx.setInterestAmount(oMap.getBigDecimal("LIST" , i , "INTEREST_AMOUNT"));
                crdTnaTaksitListesiTx.setKkdfAmount(oMap.getBigDecimal("LIST" , i , "KKDF_AMOUNT"));
                crdTnaTaksitListesiTx.setFeeBasic(oMap.getBigDecimal("LIST" , i , "FEE_BASIC"));
                crdTnaTaksitListesiTx.setFeeBsmv(oMap.getBigDecimal("LIST" , i , "FEE_BASIC"));
                crdTnaTaksitListesiTx.setRemainAmount(oMap.getBigDecimal("LIST" , i , "REMAIN_AMOUNT"));
                crdTnaTaksitListesiTx.setRemainInterestAmount(oMap.getBigDecimal("LIST" , i , "REMAIN_INTEREST_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalBsmvAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_BSMV_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalInterestAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_INTEREST_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalKkdfAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_KKDF_AMOUNT"));
                crdTnaTaksitListesiTx.setInterestRate(oMap.getBigDecimal("LIST" , i , "INTEREST_RATE"));
                
                session.save(crdTnaTaksitListesiTx);
            }
            session.flush();
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_CREDIT_CARD_GET_INSTALL_SIMULATE_DATA")
    public static GMMap GetInstallSimulateData(GMMap iMap) {
        try{
            ValidateCardInstallmentData(iMap);
            
            GMMap oMap = new GMMap();
            GMMap pMap = new GMMap();
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date date = new Date();
            
            pMap.put(CARD_NO , iMap.getString("CARD_NO" , " "));
            
            pMap.put(CARD_LEVEL , iMap.get(CARD_LEVEL) == null ? " " : iMap.getString(CARD_LEVEL));
            pMap.put(COUNTRY_CODE , iMap.get(COUNTRY_CODE) == null ? " " : iMap.getString(COUNTRY_CODE));
            
            pMap.put(OTC , "11");
            pMap.put(OTS , "10");
            pMap.put(REQUEST_DATE , dateFormat.format(date));
            pMap.put(TXN_DATE , dateFormat.format(date));
            pMap.put(TXN_INSTALL_TYPE , "T");
            pMap.put(TXN_SOURCE , "O");
            pMap.put(TXN_TRM , iMap.get(TXN_TRM) == null ? " " : iMap.getString(TXN_TRM));
            
            pMap.put(TXN_AMOUNT , iMap.getBigDecimal("TUTAR" , new BigDecimal(0)));
            pMap.put(INSTALL_COUNT , iMap.getInt("INSTALL_COUNT" , 0));
            pMap.put(PRODUCT_ID , iMap.get(PRODUCT_ID) == null ? " " : iMap.getString(PRODUCT_ID));
            
            pMap.put(MCC , iMap.getInt("MCC" , 0));
            
            oMap = GMServiceExecuter.call("BNSPR_GENERAL_QUERY_OF_PAYMENT_PLAN" , pMap);
			
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                iMap.put("TRX_NO" , trxNo);
                oMap.put("TRX_NO" , trxNo);
            }
            
            int installCount = oMap.getSize("LIST");
            
            if (installCount > 0){
                oMap.put("ILK_ODEME_TARIHI" , oMap.getDate("LIST" , 0 , "INSTALL_DATE"));
                oMap.put("TOPLAM_TUTAR" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_AMOUNT"));
                oMap.put("ISLEM_UCRETI" , oMap.getBigDecimal("LIST" , 0 , "INSTALL_FEE"));
                oMap.put("TAKSIT_TUTARI" , oMap.getBigDecimal("LIST" , 0 , "INSTALL_AMOUNT"));
                oMap.put("SON_ODEME_TARIHI" , oMap.getDate("LIST" , installCount - 1 , "INSTALL_DATE"));
                oMap.put("FAIZ_ORANI" , oMap.getString("LIST" , installCount - 1 , "INTEREST_RATE"));
                oMap.put("TOPLAM_KKDF" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_KKDF_AMOUNT"));
                oMap.put("TOPLAM_BSMV" , oMap.getBigDecimal("LIST" , 0 , "TOTAL_BSMV_AMOUNT"));
                oMap.put("FEE_BASIC" , oMap.getBigDecimal("LIST" , 0 , "FEE_BASIC"));
                oMap.put("FEE_BSMV" , oMap.getBigDecimal("LIST" , 0 , "FEE_BSMV"));
            }
            Session session = DAOSession.getSession("BNSPRDal");
            List<CrdTnaTaksitListesiTx> crdTnaTaksitList = session.createCriteria(CrdTnaTaksitListesiTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            for (CrdTnaTaksitListesiTx c : crdTnaTaksitList){
                session.delete(c);
            }
            session.flush();
            
            for (int i = 0; i < installCount; i++){
                CrdTnaTaksitListesiTx crdTnaTaksitListesiTx = new CrdTnaTaksitListesiTx();
                crdTnaTaksitListesiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
                crdTnaTaksitListesiTx.setInstallNo(oMap.getBigDecimal("LIST" , i , "INSTALL_NO"));
                crdTnaTaksitListesiTx.setInstallDate(oMap.getDate("LIST" , i , "INSTALL_DATE"));
                crdTnaTaksitListesiTx.setInstallAmount(oMap.getBigDecimal("LIST" , i , "INSTALL_AMOUNT"));
                crdTnaTaksitListesiTx.setInstallBasicAmount(oMap.getBigDecimal("LIST" , i , "INSTALL_BASIC_AMOUNT"));
                crdTnaTaksitListesiTx.setInstallFee(oMap.getBigDecimal("LIST" , i , "INSTALL_FEE"));
                crdTnaTaksitListesiTx.setBsmvAmount(oMap.getBigDecimal("LIST" , i , "BSMV_AMOUNT"));
                crdTnaTaksitListesiTx.setInterestAmount(oMap.getBigDecimal("LIST" , i , "INTEREST_AMOUNT"));
                crdTnaTaksitListesiTx.setKkdfAmount(oMap.getBigDecimal("LIST" , i , "KKDF_AMOUNT"));
                crdTnaTaksitListesiTx.setFeeBasic(oMap.getBigDecimal("LIST" , i , "FEE_BASIC"));
                crdTnaTaksitListesiTx.setFeeBsmv(oMap.getBigDecimal("LIST" , i , "FEE_BASIC"));
                crdTnaTaksitListesiTx.setRemainAmount(oMap.getBigDecimal("LIST" , i , "REMAIN_AMOUNT"));
                crdTnaTaksitListesiTx.setRemainInterestAmount(oMap.getBigDecimal("LIST" , i , "REMAIN_INTEREST_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalBsmvAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_BSMV_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalInterestAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_INTEREST_AMOUNT"));
                crdTnaTaksitListesiTx.setTotalKkdfAmount(oMap.getBigDecimal("LIST" , i , "TOTAL_KKDF_AMOUNT"));
                crdTnaTaksitListesiTx.setInterestRate(oMap.getBigDecimal("LIST" , i , "INTEREST_RATE"));
                
                session.save(crdTnaTaksitListesiTx);
            }
            session.flush();
            if(!"2".equals(oMap.getString("RETURN_CODE"))){
            	if(!StringUtils.isEmpty(oMap.getString("IRC_CODE")))
            	oMap.put("RETURN_DESCRIPTION", getParamText(oMap.getString("IRC_CODE"), "IRC_CODE_EXPLANATIONS"));
            }
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    private static void ValidateCardInstallmentData(GMMap iMap) {
        
        if (iMap.get("CARD_NO") == null || iMap.getString("CARD_NO").isEmpty()){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Kart No  bo� olamaz");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (!(iMap.getBigDecimal("TUTAR" , BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0)){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Tutar alan� s�f�rdan b�y�k olmal�!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if ((iMap.getBigDecimal("KULL_NA_LIMIT" , BigDecimal.ZERO).compareTo(iMap.getBigDecimal("TUTAR" , BigDecimal.ZERO)) < 0)){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Tutar  taksitli nakit avans limitinden b�y�k olamaz!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (iMap.get("MUSTERI_NO") == null || iMap.getString("MUSTERI_NO").isEmpty()){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "M��teri Numaras� bo� olamaz");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (!(iMap.getBigDecimal("KULL_NA_LIMIT" , BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0)){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Nakit Avans Limiti s�f�rdan b�y�k olmal�!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (StringUtils.isBlank(iMap.getString("INSTALL_COUNT"))){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Taksit say�s� giriniz!!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (iMap.get("HESAP_NO") == null || iMap.getString("HESAP_NO").isEmpty()){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Hesap No Bo� olamaz!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
        if (!(iMap.getBigDecimal("SON_KULL_TARIHI" , BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0)){
            GMMap exMap = new GMMap();
            exMap.put("P1" , "Son kullanma tarihini giriniz!");
            exMap.put("HATA_NO" , "660");
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
        }
        
    }
    
    @GraymoundService("BNSPR_CREDIT_CARD_INSTALLMENT_CASH_ADVANCE")
    public static GMMap CreditCardInstallmentCashAdvance(GMMap iMap) {
        try{
            
            ValidateCardInstallmentData(iMap);
            Session session = DAOSession.getSession("BNSPRDal");
            
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                iMap.put("TRX_NO" , trxNo);
            }
            
            CrdKartNakitAvansTx crdTaksitliNakitAvansTx = new CrdKartNakitAvansTx();
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                crdTaksitliNakitAvansTx.setTxNo(trxNo);
                iMap.put("TRX_NO" , trxNo);
            } else crdTaksitliNakitAvansTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            
            GMMap aciklamaMap = new GMMap();
            aciklamaMap.put("MESSAGE_NO" , "4328");
            aciklamaMap.put("P1" , maskCardNumber(iMap.getString("CARD_NO")));
            aciklamaMap.put("P2" , iMap.getString("TRX_NO"));
            GMMap channelMap = new GMMap();
            channelMap.put("KANAL_KODU" , (String) GMContext.getCurrentContext().getSession().get("CHANNEL_CODE"));
            aciklamaMap.put("P3" , GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_ADI" , channelMap).getString("KANAL_ADI"));
            String aciklama = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE" , aciklamaMap).get("ERROR_MESSAGE");
            
            crdTaksitliNakitAvansTx.setAciklama(aciklama);
            crdTaksitliNakitAvansTx.setAliciAdiSoyadi(iMap.getString("ADI_SOYADI"));
            crdTaksitliNakitAvansTx.setAliciHesapNo(iMap.getBigDecimal("HESAP_NO"));
            crdTaksitliNakitAvansTx.setAliciMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            crdTaksitliNakitAvansTx.setAsilKartNo(iMap.getString("CARD_NO"));
            crdTaksitliNakitAvansTx.setCvv2(iMap.getBigDecimal("CVV2" , new BigDecimal(123)));
            crdTaksitliNakitAvansTx.setCvv2Exists(iMap.getString("CVV2_EXISTS"));
            crdTaksitliNakitAvansTx.setDovizKodu(iMap.getString("HESAP_DOVIZ_KODU"));
            crdTaksitliNakitAvansTx.setHesapDovizKodu(iMap.getString("HESAP_DOVIZ_KODU"));
            crdTaksitliNakitAvansTx.setKartNo(iMap.getString("CARD_NO"));
            crdTaksitliNakitAvansTx.setKaynak("HESABA");
            crdTaksitliNakitAvansTx.setKullanabilirNaLimit(iMap.getBigDecimal("KULL_NA_LIMIT"));
            crdTaksitliNakitAvansTx.setSonKullanmaTarihi(iMap.getBigDecimal("SON_KULL_TARIHI"));
            crdTaksitliNakitAvansTx.setTutar(iMap.getBigDecimal("TUTAR"));
            crdTaksitliNakitAvansTx.setInstallCount(iMap.getBigDecimal("INSTALL_COUNT"));
            
            if (!isNotExistAndNull(iMap , "TRX_NO")){
                GMMap oMapN = new GMMap();
                oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , oMapN);
                BigDecimal trxNo = oMapN.getBigDecimal("TRX_NO");
                
                crdTaksitliNakitAvansTx.setTxNo(trxNo);
                iMap.put("TRX_NO" , trxNo);
            } else crdTaksitliNakitAvansTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            
            session.saveOrUpdate(crdTaksitliNakitAvansTx);
            
            session.flush();
            iMap.put("TRX_NAME" , "4438");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN4438_AFTER_APPROVAL")
    public static GMMap after_Approval(GMMap iMap) {
       // Connection conn = null;
        //PreparedStatement ps = null;
       // ResultSet rs = null;
        GMMap iMapx = new GMMap();
        GMMap oMapx = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            
            CrdKartNakitAvansTx nakitAvansTx = new CrdKartNakitAvansTx(); 
            nakitAvansTx = (CrdKartNakitAvansTx) session.get(CrdKartNakitAvansTx.class, iMap.getBigDecimal("ISLEM_NO"));
        	//conn = DALUtil.getGMConnection();
            //ps = conn.prepareStatement("SELECT * FROM CRD_KART_NAKIT_AVANS_TX where tx_no=?");
            //ps.setBigDecimal(1 , iMap.getBigDecimal("ISLEM_NO"));
           // rs = ps.executeQuery();
            
            if(nakitAvansTx != null){
                
                GMMap oMapH = new GMMap();
                oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , oMapH);
                
                iMapx.put(CARD_NO , nakitAvansTx.getKartNo());
                iMapx.put(ACCOUNT_BRANCH_ID , oMapH.getString("SUBE_KOD"));
                iMapx.put(RRN , "");
                iMapx.put(REQUEST_TYPE , OceanConstants.Request_Normal);
                GMMap oMapK = new GMMap();
                oMapK = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , oMapK);
                String channelCode;
                if (oMapK.getString("KANAL_KOD").equals("4") || oMapK.getString("KANAL_KOD").equals("10"))
                    channelCode = OceanConstants.Channel_INT;
                else
                    if (oMapK.getString("KANAL_KOD").equals("5"))
                        channelCode = OceanConstants.Channel_IVR;
                    else channelCode = OceanConstants.Channel_Branch;
                iMapx.put(CHANNEL , channelCode);
                iMapx.put(TERMINAL_ID , "9999999");
                iMapx.put(TERMINAL_TYPE , "Crt");
                iMapx.put(CVV2_EXISTS , nakitAvansTx.getCvv2Exists());
                
                iMapx.put(TXN_DESC , StringUtils.isEmpty(nakitAvansTx.getAciklama())?  "Nakit Avans" : nakitAvansTx.getAciklama());
                iMapx.put(TXN_AMOUNT , nakitAvansTx.getTutar());
                iMapx.put(CVV2 , nakitAvansTx.getCvv2());
                iMapx.put(CARD_EXPIRE_DATE , nakitAvansTx.getSonKullanmaTarihi());
                iMapx.put(TXN_CURR , nakitAvansTx.getDovizKodu());
                iMapx.put(SIMULATION_FLAG , "");
                iMapx.put(RRN , "");
                iMapx.put(INSTALLMENT_COUNT , nakitAvansTx.getInstallCount());
                
            }
            oMapx = GMServiceExecuter.call("BNSPR_GENERAL_MAKE_INSTALLMENT_CASH_ADVANCE" , iMapx);
            if (oMapx.getInt(RETURN_CODE) == 2){
                CrdKartNakitAvansTx crdKartNakitAvansTx = new CrdKartNakitAvansTx();
                crdKartNakitAvansTx = (CrdKartNakitAvansTx) session.get(CrdKartNakitAvansTx.class , iMap.getBigDecimal("ISLEM_NO"));
                crdKartNakitAvansTx.setRrn(oMapx.getString(RRN));
                crdKartNakitAvansTx.setAurthorizationCode(oMapx.getString(AUTHORIZATION_CODE));
                session.saveOrUpdate(crdKartNakitAvansTx);
                session.flush();
                
                return oMapx;
            } else{
            	throw new GMRuntimeException(0, getParamText(oMapx.getString("IRC_CODE"), "IRC_CODE_EXPLANATIONS"));
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } 
    }
    
    @GraymoundService("BNSPR_TRN4438_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            Session session = DAOSession.getSession("BNSPRDal");
            
            List<?> taksitList = session.createCriteria(CrdTnaTaksitListesiTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            BigDecimal installCount = new BigDecimal(taksitList.size());
            BigDecimal bigOne = new BigDecimal(1);
            int i = 0;
            for (Object name : taksitList){
                CrdTnaTaksitListesiTx crdTnaTaksitListesiTx = (CrdTnaTaksitListesiTx) name;
                if (crdTnaTaksitListesiTx.getInstallNo().equals(bigOne)){
                    oMap.put("TAKSIT_TUTARI" , crdTnaTaksitListesiTx.getInstallAmount());
                    oMap.put("ISLEM_UCRETI" , crdTnaTaksitListesiTx.getInstallFee());
                    oMap.put("TAKSIT_ILK_ODEME_TARIHI" , crdTnaTaksitListesiTx.getInstallDate());
                    oMap.put("TOPLAM_TUTAR" , crdTnaTaksitListesiTx.getTotalAmount());
                    oMap.put("TRX_NO" , crdTnaTaksitListesiTx.getTxNo());
                    
                    oMap.put("FAIZ_ORANI" , crdTnaTaksitListesiTx.getInterestRate());
                    oMap.put("TOPLAM_KKDF" , crdTnaTaksitListesiTx.getTotalKkdfAmount());
                    oMap.put("TOPLAM_BSMV" , crdTnaTaksitListesiTx.getTotalBsmvAmount());
                }
                
                if (crdTnaTaksitListesiTx.getInstallNo().equals(installCount)){
                    
                    oMap.put("TAKSIT_SON_ODEME_TARIHI" , crdTnaTaksitListesiTx.getInstallDate());
                }
                
                oMap.put(LIST , i , INSTALL_NO , crdTnaTaksitListesiTx.getInstallNo());
                oMap.put(LIST , i , INSTALL_DATE , crdTnaTaksitListesiTx.getInstallDate());
                oMap.put(LIST , i , INSTALL_AMOUNT , crdTnaTaksitListesiTx.getInstallAmount());
                oMap.put(LIST , i , INSTALL_BASIC_AMOUNT , crdTnaTaksitListesiTx.getInstallBasicAmount());
                oMap.put(LIST , i , INSTALL_FEE , crdTnaTaksitListesiTx.getInstallFee());
                oMap.put(LIST , i , BSMV_AMOUNT , crdTnaTaksitListesiTx.getBsmvAmount());
                oMap.put(LIST , i , INTEREST_AMOUNT , crdTnaTaksitListesiTx.getInterestAmount());
                oMap.put(LIST , i , KKDF_AMOUNT , crdTnaTaksitListesiTx.getKkdfAmount());
                oMap.put(LIST , i , FEE_BASIC , crdTnaTaksitListesiTx.getFeeBasic());
                oMap.put(LIST , i , FEE_BSMV , crdTnaTaksitListesiTx.getFeeBsmv());
                oMap.put(LIST , i , REMAIN_AMOUNT , crdTnaTaksitListesiTx.getRemainAmount());
                oMap.put(LIST , i , REMAIN_INTEREST_AMOUNT , crdTnaTaksitListesiTx.getRemainInterestAmount());
                oMap.put(LIST , i , TOTAL_AMOUNT , crdTnaTaksitListesiTx.getTotalAmount());
                oMap.put(LIST , i , TOTAL_BSMV_AMOUNT , crdTnaTaksitListesiTx.getTotalBsmvAmount());
                oMap.put(LIST , i , TOTAL_KKDF_AMOUNT , crdTnaTaksitListesiTx.getTotalKkdfAmount());
                oMap.put(LIST , i , INTEREST_RATE , crdTnaTaksitListesiTx.getInterestRate());
                
                i++;
            }
            
            CrdKartNakitAvansTx crdKartNakitAvansTx = (CrdKartNakitAvansTx) session.get(CrdKartNakitAvansTx.class , iMap.getBigDecimal("TRX_NO"));
            oMap.put(CUSTOMER_NO , crdKartNakitAvansTx.getAliciMusteriNo());
            oMap.put(CARD_NO , crdKartNakitAvansTx.getAsilKartNo());
            oMap.put(CARD_DCI , "All");
            GMMap outMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , oMap);
            oMap.put("SON_ODEME_TARIHI" , outMap.getBigDecimal(CARD_DETAIL_INFO , 0 , LAST_PAYMENT_DATE));
            oMap.put("HESAP_KESIM_TARIHI" , outMap.getBigDecimal(CARD_DETAIL_INFO , 0 , LAST_STMT_DATE));
            
            oMap.put("ACIKLAMA" , crdKartNakitAvansTx.getAciklama());
            oMap.put("ALICI_ADI_SOYADI" , crdKartNakitAvansTx.getAliciAdiSoyadi());
            oMap.put("ALICI_HESAP_NO" , crdKartNakitAvansTx.getAliciHesapNo());
            oMap.put("ALICI_MUSTERI_NO" , crdKartNakitAvansTx.getAliciMusteriNo());
            oMap.put("ASIL_KART_NO" , crdKartNakitAvansTx.getAsilKartNo());
            oMap.put("CVV2" , "***");
            oMap.put("DOVIZ_KODU" , crdKartNakitAvansTx.getDovizKodu());
            oMap.put("GONDEREN_ADI_SOYADI" , crdKartNakitAvansTx.getGonderenAdiSoyadi());
            oMap.put("GONDEREN_MUSTERI_NO" , crdKartNakitAvansTx.getGonderenMusteriNo());
            oMap.put("HESAP_DOVIZ_KODU" , crdKartNakitAvansTx.getHesapDovizKodu());
            oMap.put("KULL_NA_LIMIT" , crdKartNakitAvansTx.getKullanabilirNaLimit());
            oMap.put("TAKSIT_SAYISI" , crdKartNakitAvansTx.getInstallCount());
            oMap.put("TUTAR" , crdKartNakitAvansTx.getTutar());
            oMap.put("HESAP_NO" , crdKartNakitAvansTx.getAliciHesapNo());
            oMap.put("TRX_NO" , crdKartNakitAvansTx.getTxNo());
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
	private static String maskCardNumber(String cardNumber) {
		return cardNumber.replaceAll("(\\w{1,4})(\\w{1,8})(\\w{1,4})", "$1 **** **** $3");
	}
	   public static String getParamText(String key, String kod){
			GMMap pMap = new GMMap();
			pMap.put("KOD", kod);
			pMap.put("KEY", key);
			String text="";
			try {
				pMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", pMap);
				text = pMap.getString("TEXT");
			}
			catch (Exception e) {
				text="Teknik bir Hata Olu�tu!";
			}
			
			return text;
			
		}
}
