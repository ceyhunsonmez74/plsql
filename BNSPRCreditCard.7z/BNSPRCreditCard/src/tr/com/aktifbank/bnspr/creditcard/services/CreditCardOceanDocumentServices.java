package tr.com.aktifbank.bnspr.creditcard.services;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.math.BigDecimal;
import java.net.URLConnection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.apache.axis.encoding.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.hibernate.Session;
import org.joda.time.DateTime;
import org.joda.time.Years;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.tff.document.type.CardDocument;
import tr.com.aktifbank.bnspr.tff.document.type.DocumentCreator;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import common.Logger;

public class CreditCardOceanDocumentServices extends TffServicesHelper {

	private static final Logger logger = Logger.getLogger(CreditCardOceanDocumentServices.class);

	private static final String KONTAKT_MUSTERI = "K";
	private static final String DOKUMAN_SORGU_TIPI_BASVURU = "B";
	private static final String DOKUMAN_SORGU_TIPI_MUSTERI = "M";
	private static final String DOKUMAN_SORGU_TIPI_HEPSI = "H";
	private static final String DOKUMAN_SORGU_TIPI_P2D = "P2D";
	private static final String DOKUMAN_ISLEM_FTP_AKTAR = "F";
	private static final String DOKUMAN_ISLEM_MUSTERI_ISARETLE = "M";
	private static final String DOKUMAN_ISLEM_HEPSI = "H";
	private static final String YIM_CERCEVE_SOZLESME_KOD = "776";
	private static final String UPT_CERCEVE_SOZLESME_KOD = "887";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-tff.properties");
	/*EVAM event type*/
	protected static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	
	



	/**
	 * Basim asamasindaki basvurularin tamamlanabilmesi icin gerekli belgeleri bulur ve
	 * gereken belgeleri basvuru uzerine kaydeder.
	 * 
	 * @author murat.el
	 * @param iMap
	 *            - BASVURU_NO Zorunlu
	 */
	@GraymoundService("BNSPR_KK_DAGITIM_KOD")
	public static GMMap getKkDagitimKod(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query =  "{? = call pkg_kk_basvuru.GetBasvuruDagitimKod(?, ?)}"; 
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("KART_SIRASINDA_MI", "E"));

			stmt.execute();
			
			oMap.put("DAGITIM_KOD", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	
	@GraymoundService("BNSPR_KK_BELGE_KAYIT")
	public static GMMap saveKkBasvuruBelge(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_KK_BASVURU.BasvuruDokumanKaydet(?, ?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("KART_SIRASINDA_MI","E"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	/**
	 * Tff musterisi icin kanaldan alinmasi gereken dokumanlari listeler.<br>
	 * 
	 * @author murat.el
	 * @since TY-5183
	 * @param iMap
	 *            - Sorgu Kriterleri<br>
	 *            <li>SOURCE - Kanal kodu <li>SORGU_TIPI - Basvuru mu Musteri mi(B:Basvuru|M:Musteri) <li>TCKN - TC kimlik numarasi <li>TFF_BASVURU_NO - Tff basvuru numarasi <li>DOKUMAN_KOD - Sorgulanan dokuman kodu
	 * @return oMap - Sorgu sonuclari<br>
	 *         <li>DOKUMAN_LIST - Dokumanin daha onceden alinip alinmadigi bilgisini tutar
	 *         <ul>
	 *         DOKUMAN_KOD<br>
	 *         ALINDI_MI
	 */
	@GraymoundService("BNSPR_KK_DOKUMAN_ALINDI_MI_BY_KANAL")
	public static GMMap dokumanAlindiMiByKanal(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Validasyon yap
			iMap.put("KK_BASVURU_NO", nvl(iMap.get("KK_BASVURU_NO"), iMap.get("BASVURU_NO")));
			sorguMap.putAll(validateDokumanAlindiMi(iMap));
			
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				
				// dokuman sorgulama servisi NTS01 ya da NTS02 den cagirildiysa 18 yasindan kucuk ya da yabanci uyruklu olma durumunu hata mesaji ile atmayacagiz bunun yerine 
				// basarili response donulecek 
				
				if("YIM".equals(iMap.getString("SOURCE")) ){
					if(TffServicesMessages.ONSEKIZ_YAS_KK_D_KONTROLU.equals(sorguMap.getString("RESPONSE_DATA"))){
						oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
						return oMap;
					}
				}
				
				
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}
			String kartTipi = sorguMap.getString("KART_TIPI");
			String uyruk = sorguMap.getString("UYRUK");

			// TCKN ile musteri bul
			BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("UYRUK"), iMap.getString("TCKN"), iMap.getString("PASAPORT_NO"));
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
		

			// Alinacak dokumanlari listele
			// Basvuru
			String sorguTipi = iMap.getString("SORGU_TIPI");
			if (DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				if (StringUtils.isNotBlank(kartTipi)) {
					// Basvuru uzerindekileri al
					sorguMap.clear();
					sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
					sorguMap.put("KART_TIPI", kartTipi);
					sorguMap.put("SOURCE", iMap.get("SOURCE"));
					sorguMap.put("MUSTERI_NO", musteriNo);
					sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_KOD"));
					sorguMap.put("UYRUK", uyruk);
					oMap.putAll(basvuruDokumanAlindiMi(sorguMap));
				}
			}
			// Musteri
			if (DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				// Musteri uzerindekileri al
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriNo);
				sorguMap.put("SOURCE", iMap.get("SOURCE"));
				sorguMap.put("UYRUK", uyruk);
				sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_KOD"));
				
				sorguMap.putAll(musteriDokumanAlindiMi(sorguMap));
				int resultSize = oMap.getSize("DOKUMAN_LIST");
				for (int i = 0; i < sorguMap.getSize("DOKUMAN_LIST"); i++) {
					oMap.put("DOKUMAN_LIST", resultSize + i, "DOKUMAN_KOD", sorguMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
					oMap.put("DOKUMAN_LIST", resultSize + i, "ALINDI_MI", sorguMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				}
			}
			
			if (DOKUMAN_SORGU_TIPI_P2D.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				// Musteri uzerindekileri al
				sorguMap.clear();
				sorguMap.put("MUSTERI_NO", musteriNo);
				sorguMap.put("SOURCE", iMap.get("SOURCE"));
				sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_KOD"));
				sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
				sorguMap.putAll(p2DDokumanAlindiMi(sorguMap));
				int resultSize = oMap.getSize("DOKUMAN_LIST");
				for (int i = 0; i < sorguMap.getSize("DOKUMAN_LIST"); i++) {
					oMap.put("DOKUMAN_LIST", resultSize + i, "DOKUMAN_KOD", sorguMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
					oMap.put("DOKUMAN_LIST", resultSize + i, "ALINDI_MI", sorguMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				}
				
				oMap.put("KURYE", sorguMap.get("KURYE"));
				oMap.put("ANINDA_DONUSUM", sorguMap.get("ANINDA_DONUSUM"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
		return oMap;
	}

	private static GMMap validateDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		Session session = null;
		
		BigDecimal customerNo = null;

		try {
			// Source kontrol et
			sorguMap.clear();
			sorguMap.put("SOURCE", iMap.get("SOURCE"));
			if (!CardServicesHelper.isSourceValid(sorguMap)) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
			}

			// Sorgu tipi kontrol et
			String sorguTipi = iMap.getString("SORGU_TIPI");
			if (!DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) && !DOKUMAN_SORGU_TIPI_P2D.equals(sorguTipi)) {
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_SORGULA_SORGU_TIPI_HATALI);
			}
			
			// Pasaport kontrol et
			
			

			// TCKN kontrol et
			sorguMap.clear();
			
			if(StringUtils.isEmpty(iMap.getString("TCKN")) && StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))){
				return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
			if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
				sorguMap.put("TCKN", iMap.get("TCKN"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_TCKN_KONTROL", sorguMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
				}
				
			}
				
			

			

			// Basvuru bilgilerini kontrol et
			String kartTipi = StringUtils.EMPTY;
			boolean basvuruOkMi = true;
			boolean musteriOkMi = true;
			String hataKodu = null;
			String uyrukKod =  StringUtils.EMPTY;
			
			if (DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				if (StringUtils.isBlank(iMap.getString("KK_BASVURU_NO"))) {
					basvuruOkMi = false;
					hataKodu = TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI;
				}
				else {
					session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("KK_BASVURU_NO"));
					if (kkBasvuru == null) {
						basvuruOkMi = false;
						hataKodu = TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI;
						
					}
					else{
						kartTipi = kkBasvuru.getKartTipi();
						customerNo = kkBasvuru.getMusteriNo();
					}

					
					
					KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("KK_BASVURU_NO"));
					if (kkBasvuruKimlik == null) {
						basvuruOkMi = false;
						hataKodu = TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI;
						
					}
					else{
						uyrukKod  = kkBasvuruKimlik.getUyrukKod();
					}
					
					
				}
			}
			// Musteri bilgilerini kontrol et
			if (DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
				// Musteri var mi
				customerNo = CardServicesHelper.searchCustomer(iMap.getString("UYRUK"), iMap.getString("TCKN"), iMap.getString("PASAPORT_NO"));
				if(customerNo == null || customerNo.intValue() == 0){
					musteriOkMi = false;
					hataKodu = TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI;
				}
				else{
					
				session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, customerNo);
				if (gnlMusteri == null) {
					musteriOkMi = false;
					hataKodu = TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI;
				}
				else{
					uyrukKod = gnlMusteri.getUyrukKod();
					boolean musteriGecerliMi = false;
					
					// Varsa  18 yasindan buyuk mu
					
					GnlMusteriKimlik gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, gnlMusteri.getMusteriNo());
						DateTime dogumTarihi = new DateTime(gnlMusteriKimlik.getDogumTarihi());
						DateTime simdi = new DateTime(Calendar.getInstance().getTime());
						if (Years.yearsBetween(dogumTarihi, simdi).getYears() >= 18) {
							musteriGecerliMi = true;
						}
					

					if (!musteriGecerliMi) {
						musteriOkMi = false;
						hataKodu = TffServicesMessages.ONSEKIZ_YAS_KK_D_KONTROLU;
					}
				}
				
				}
				
				
				
				
				
			}
			// Kontrol
			if ((DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) && !basvuruOkMi) || // basvuruda sikinti var mi
			(DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) && !musteriOkMi) || // musteride sikinti mi
			(DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) && !(basvuruOkMi || musteriOkMi))) {// basvuru veya musteri sikinti mi
				return CreditCardServicesUtil.getErrorResponse(hataKodu);
			}

			oMap.put("KART_TIPI", kartTipi);
			oMap.put("UYRUK", uyrukKod);
			// Dokuman kod girilmisse kontrol et
			if (StringUtils.isNotBlank(iMap.getString("DOKUMAN_KOD"))) {
				// Basvuru
				boolean basvurudaTanimliMi = false;
				if (DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
					sorguMap.clear();
					sorguMap.put("KOD", "KK_BASVURU_ALINAN_BELGE");
					sorguMap.put("KEY", iMap.get("SOURCE"));
					sorguMap.put("KEY2", kartTipi);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
					if (TffServicesMessages.EVET.equals(sorguMap.getString("IS_EXIST"))) {
						basvurudaTanimliMi = true;
					}
				}

				// Musteri
				boolean musterideTanimliMi = false;
				if (DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) || DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi)) {
					sorguMap.clear();
					sorguMap.put("KOD", "KK_BASVURU_ALINAN_BELGE");
					sorguMap.put("KEY", iMap.get("SOURCE"));
					sorguMap.put("KEY2", "X");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
					if (TffServicesMessages.HAYIR.equals(sorguMap.getString("IS_EXIST"))) {
						musterideTanimliMi = true;
					}
				}
				// Kontrol
				if ((DOKUMAN_SORGU_TIPI_BASVURU.equals(sorguTipi) && !basvurudaTanimliMi) || // basvuruda tanimli mi
				(DOKUMAN_SORGU_TIPI_MUSTERI.equals(sorguTipi) && !musterideTanimliMi) || // musteride tanimli mi
				(DOKUMAN_SORGU_TIPI_HEPSI.equals(sorguTipi) && !(basvurudaTanimliMi || musterideTanimliMi))) {// basvuru veya musteride tanimli mi
					return CreditCardServicesUtil.getErrorResponse(TffServicesMessages.DOKUMAN_SORGULA_DOKUMAN_KODU_HATALI);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.putAll(CreditCardServicesUtil.getSuccessResponse(TffServicesMessages.ISLEM_BASARILI));
		return oMap;

	}

	private static GMMap musteriDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap docListMap = new GMMap();

		try {
			boolean dokumanKodVarMi = StringUtils.isNotBlank(iMap.getString("DOKUMAN_KOD"));
			// Dokumanlari var
			iMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "X", null, null));
			// Varsa alindi mi diye kontrol et
			int j = 0;
			for (int i = 0; i < iMap.getSize("DOKUMAN_LIST"); i++) {
				if (!dokumanKodVarMi || (dokumanKodVarMi && iMap.getString("DOKUMAN_KOD").equals(iMap.get("DOKUMAN_LIST", i, "NAME")))) {
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", i, "DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
					oMap.put("DOKUMAN_LIST", i, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
					j++;
				}
			}
			
			// Dokumanlari var
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "T", null, null));
			// Varsa alindi mi diye kontrol et
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
				if (!dokumanKodVarMi || (dokumanKodVarMi && iMap.getString("DOKUMAN_KOD").equals(docListMap.get("DOKUMAN_LIST", i, "NAME")))) {
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TAMAMLAYICI_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
					j++;
					}
				}
		
			
			
			
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static GMMap basvuruDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap docListMap = new GMMap();

		try {
			boolean dokumanKodVarMi = StringUtils.isNotBlank(iMap.getString("DOKUMAN_KOD"));
			// Dokumanlari var
			iMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), iMap.getString("KART_TIPI"), null , null));
			// Varsa alindi mi diye kontrol et
			int j = 0 ;
			

			// Dokumanlari var
			String param3 = null;
			if("TR".equals(iMap.getString("UYRUK"))){
				param3 = "YERLI";
			}
			else{
				param3 = "YABANCI";
			}
			
			for (int i = 0; i < iMap.getSize("DOKUMAN_LIST"); i++) {
				if (!dokumanKodVarMi || (dokumanKodVarMi && iMap.getString("DOKUMAN_KOD").equals(iMap.get("DOKUMAN_LIST", i, "NAME")))) {
					// Dokuman alindi mi?
						sorguMap.clear();
					
						sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
						sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
						sorguMap.put("DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
						String uyrukAlan = iMap.getString("DOKUMAN_LIST", i, "KEY3");
			
						if (StringUtils.isNotEmpty(uyrukAlan)){
							if(uyrukAlan.contains("YERLI") || uyrukAlan.contains("YABANCI")){
								if(uyrukAlan.contains(param3)){
									sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI", sorguMap));
									oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
									oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
									j++;
								}
								else{
									continue;
								}
								
							}
							else{
								sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI", sorguMap));
								oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", iMap.get("DOKUMAN_LIST", i, "NAME"));
								oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
								j++;
							}
						}
					
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	


	


	
	
	@GraymoundService("BNSPR_KK_DOKUMAN_ALINDI_MI")
	public static GMMap kkDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_kk_basvuru.BasvuruDokumanAlindiMi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();

			oMap.put("ALINDI_MI", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_KK_GET_DOCUMENT_TEMPLATES")
	public static GMMap getKkDocumentTemplates(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		iMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), null, null, null));
		
		
		try {
			
			if(iMap.get("DOKUMAN_LIST") != null && iMap.getSize("DOKUMAN_LIST") > 0){
				int j=0 ;
				for(int i = 0 ; i< iMap.getSize("DOKUMAN_LIST") ; i ++){
					int code = iMap.getInt("DOKUMAN_LIST", i, "NAME");
					CardDocument cardDocument = DocumentCreator.createCardDocument(code);
					if(cardDocument == null){
						continue;
					}
					oMap.put("DOC_LIST", j, "CODE", code);
					iMap.put("FOLDER_NAME", cardDocument.getFolderName());
					iMap.put("TEMPLATE_NAME", cardDocument.getTemplateName());
					oMap.put("DOC_LIST", j, "NAME", getDocumentName(code));
					oMap.put("DOC_LIST", j, "TEMPLATE", GMServiceExecuter.call("BNSPR_GET_DOCUMENT_TEMPLATE", iMap).get("XSL"));
					j++;
				}
			}
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
			
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_KK_CARD_DOCUMENT_TEMPLATE_DATA")
	public static GMMap getKkCardDocumentTemplateData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {

			int j=0;	
			for (int i = 0; i < iMap.getSize("DOC_LIST"); i++) {
				int dokumanKod = iMap.getInt("DOC_LIST" , i , "DOC_CODE");
				CardDocument cardDocument = DocumentCreator.createCardDocument(dokumanKod);
				if(cardDocument == null){
					continue;
				}
				oMap.put("DOC_LIST", j, "CODE", dokumanKod);
				oMap.put("DOC_LIST", j, "NAME", getDocumentName(dokumanKod));
				
				if (iMap.containsKey("QRCODE") && StringUtils.isNotEmpty(iMap.getString("QRCODE")))
				cardDocument.generatePdf(iMap.getString("BASVURU_NO") , iMap.getString("BARKOD_NO") , iMap.getString("QRCODE"));
				else
					cardDocument.generatePdf(iMap.getString("BASVURU_NO") , iMap.getString("BARKOD_NO"));
				
				oMap.put("DOC_LIST", j, "BYTE_ARRAY", cardDocument.getPdfByteArray());
				j++;
			}

		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_KK_CARD_DOCUMENT_DATA")
	public static GMMap getKkCardDocumentData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {

			int j=0;
					
			for (int i = 0; i < iMap.getSize("DOC_LIST"); i++) {
				int dokumanKod = iMap.getInt("DOC_LIST" , i , "DOC_CODE");
				CardDocument cardDocument = DocumentCreator.createCardDocument(dokumanKod);
				if(cardDocument == null){
					continue;
				}
				oMap.put("DOC_LIST", j, "CODE", dokumanKod);	
				oMap.put("DOC_LIST", j, "NAME", getDocumentName(dokumanKod));
				if (StringUtils.isNotEmpty(iMap.getString("BARKOD_NO")) && StringUtils.isNotEmpty(iMap.getString("QRCODE"))){
					oMap.put("DOC_LIST", j, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO") , iMap.getString("BARKOD_NO") , iMap.getString("QRCODE")));
				}
				else if (StringUtils.isNotEmpty(iMap.getString("BARKOD_NO"))){
					oMap.put("DOC_LIST", j, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO") , iMap.getString("BARKOD_NO")));
				}	
				else{
					oMap.put("DOC_LIST", j, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO")));
				}
				j++;
			}

		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	
	private static String getDocumentName(int documentCode) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("SELECT ACIKLAMA FROM v_ml_gnl_dokuman_kod_pr WHERE KOD = ?");
			stmt.setString(1, String.valueOf(documentCode));
			rSet = stmt.executeQuery();

			if (rSet.next()) {
				return rSet.getString(1);
			}
			throw new GMRuntimeException(0, "Gecersiz Dokuman Kodu!");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_KK_SAVE_AGREEMENT_DOCUMENTS")
	public static GMMap saveKkAgreementDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if(!CardServicesHelper.isSourceValid(iMap)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			long start = System.currentTimeMillis();
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			
			if ( kkBasvuru == null ){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			
			
			start = System.currentTimeMillis() ;
			byte[] bytes = decode64ByteArray(iMap.getString("DOC_CONTENT"));
			
			start = System.currentTimeMillis() ;
			
			String musteriNo=kkBasvuru.getMusteriNo()+ "";
			
			double fileSize = bytes.length;
			
			if (fileSize > Integer.valueOf(conf.getProperty("tff-foto-max-size")) * 1024 * 1024) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_BOYUT_HATASI);
				return oMap;
			}
			
		    

			start = System.currentTimeMillis() ;
			ImageInputStream iis = ImageIO.createImageInputStream(new ByteArrayInputStream(bytes));
			Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);

			ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
			String type = "jpg";
			String sourceMimeType = URLConnection.guessContentTypeFromStream(bis);
			if (StringUtils.isEmpty(sourceMimeType)) {
				sourceMimeType ="application/pdf";
			}
			GMMap t = new GMMap();
			t.put("image/png", "png");
			t.put("image/jpeg", "jpg");
			t.put("application/pdf", "pdf");
			
			if (StringUtils.isEmpty(t.getString(sourceMimeType)))
			{
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_TIPI_TANIMLAMASI_HATASI);
				return oMap;
			}
			
			type = t.getString(sourceMimeType);
			

			ImageReader reader = readers.next();
		
			reader.setInput(iis, true);
			ImageReadParam param = reader.getDefaultReadParam();

			Image image = reader.read(0, param);
			// got an image file

			String folderPath = ROOT + File.separator + "files";
			String isWindows = "H";
			
		
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				start = System.currentTimeMillis() ;
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "KK_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
			
			if(SystemUtils.IS_OS_WINDOWS){
				isWindows="E";
			}else{
				isWindows="H";
			}
			
			File klasor = null;
			boolean isFirst = false;
			String approved ="";
			Runtime runtime =Runtime.getRuntime ();
			
			start = System.currentTimeMillis() ;
			if(TffServicesHelper.isWindowsReservedFilename(musteriNo))
					folderPath = String.format("%s/%s", folderPath,"XXX");	
				else
					folderPath = String.format("%s/%s", folderPath,musteriNo);
				
				klasor = new File(folderPath);
				if (!klasor.exists()){
					if ( isWindows.equals("E") )
						klasor.mkdir();
					else{
						String[] cmdLine = {"mkdir", folderPath};
		                Process p =runtime.exec ( cmdLine );
		                p.waitFor();
					}
				}
			
			folderPath = String.format("%s/%s", folderPath,iMap.getString("DOC_CODE"));
			klasor = new File(folderPath);
			if (!klasor.exists()){
				if ( isWindows.equals("E") )
					klasor.mkdir();
				else{
					String[] cmdLine = {"mkdir", folderPath};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
				//ilk basvurusu
				isFirst = true;
				approved = String.format("%s/%s", folderPath,conf.getProperty("gise_foto_folder"));
				File app = new File(approved);
				if ( isWindows.equals("E") )
					app.mkdirs();
				else{
					String[] cmdLine = {"mkdir", approved};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
			}
			BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
			// bufferedImage is the RenderedImage to be written

			Graphics2D g2 = bufferedImage.createGraphics();
			g2.drawImage(image, null, null);
			start = System.currentTimeMillis() ;
			File imageFile = new File(folderPath + File.separator + musteriNo + "_" + iMap.getString("DOC_CODE") + "_" + iMap.getInt("PAGE_NO")+"." + type);
			ImageIO.write(bufferedImage, type, imageFile);
			//ilk basvuru ise yuklenen resim approved klasorune aktarilir
			if(isFirst){
				start = System.currentTimeMillis() ;
				File appImage = new File(approved + File.separator + musteriNo + "_" + iMap.getString("DOC_CODE") + "_" + iMap.getInt("PAGE_NO")+ "." + type);
				ImageIO.write(bufferedImage, type, appImage);
			}
			
			start = System.currentTimeMillis() ;
			//tffBasvuru.setFotoDurum("T");
			//session.save(tffBasvuru);
			//session.flush();
			
			logger.info(" FOTO KK DURUM GUNCELLE  :"+ (System.currentTimeMillis() -start) );
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "BASARILI");
			
		
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
			return oMap;
		}
		
		return oMap;
		
		
	}
	
	
	@GraymoundService("BNSPR_KK_GET_CUSTOMER_DOCUMENTS")
	public static GMMap getCustomerDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if(!CardServicesHelper.isSourceValid(iMap)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			
			
			String musteriNo=iMap.getString("MUSTERI_NO");
			
			
			String folderPath = ROOT + File.separator + "files";
			
			
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "KK_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
		
			
		
			
			File klasor = null;
			
			
			folderPath = String.format("%s/%s", folderPath,musteriNo);
				
			klasor = new File(folderPath);
			if(klasor.exists()){
				String[] names = klasor.list();
				if(names != null && names.length > 0){
					Set<String> namesSet = new HashSet<String>();
					namesSet.addAll(Arrays.asList(names));
					oMap.put("FILE_NAME_LIST" , namesSet);
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
				}
			}
			
		
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			
		}
		
		return oMap;
		
		
	}
	
	
	@GraymoundService("BNSPR_KK_SAVE_AGREEMENT_DOCUMENTS_PDF")
	public static GMMap saveKkAgreementDocumentsPdf(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if(!CardServicesHelper.isSourceValid(iMap)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			long start = System.currentTimeMillis();
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			
			if ( kkBasvuru == null ){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			
			
			start = System.currentTimeMillis() ;
			byte[] bytes = decode64ByteArray(iMap.getString("DOC_CONTENT"));
			
			start = System.currentTimeMillis() ;
			
			String musteriNo=kkBasvuru.getMusteriNo()+ "";
			
			double fileSize = bytes.length;
			
			if (fileSize > Integer.valueOf(conf.getProperty("tff-foto-max-size")) * 1024 * 1024) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_BOYUT_HATASI);
				return oMap;
			}
			
		    

			start = System.currentTimeMillis() ;
			

			String folderPath = ROOT + File.separator + "files";
			String isWindows = "H";
			
		
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				start = System.currentTimeMillis() ;
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "KK_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}

			catch (Exception e) {
				e.printStackTrace();
			}
			
			
			if(SystemUtils.IS_OS_WINDOWS){
				isWindows="E";
			}else{
				isWindows="H";
			}
			
			
			File klasor = null;
			boolean isFirst = false;
			String approved ="";
			Runtime runtime =Runtime.getRuntime ();
			
			start = System.currentTimeMillis() ;
			if(TffServicesHelper.isWindowsReservedFilename(musteriNo))
					folderPath = String.format("%s/%s", folderPath,"XXX");	
				else
					folderPath = String.format("%s/%s", folderPath,musteriNo);
				
				klasor = new File(folderPath);
				if (!klasor.exists()){
					if ( isWindows.equals("E") )
						klasor.mkdir();
					else{
						String[] cmdLine = {"mkdir", folderPath};
		                Process p =runtime.exec ( cmdLine );
		                p.waitFor();
					}
				}
			
			folderPath = String.format("%s/%s", folderPath,iMap.getString("DOC_CODE"));
			klasor = new File(folderPath);
			if (!klasor.exists()){
				if ( isWindows.equals("E") )
					klasor.mkdir();
				else{
					String[] cmdLine = {"mkdir", folderPath};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
				approved = String.format("%s/%s", folderPath,conf.getProperty("gise_foto_folder"));
				File app = new File(approved);
				if ( isWindows.equals("E") )
					app.mkdirs();
				else{
					String[] cmdLine = {"mkdir", approved};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
			}
			

			File pdfFile = new File(folderPath + File.separator + musteriNo + "_" + iMap.getString("DOC_CODE") + "_" + iMap.getInt("PAGE_NO")+"." + "pdf");
			
			if(isFirst){
				start = System.currentTimeMillis() ;
				 pdfFile = new File(approved + File.separator + musteriNo + "_" + iMap.getString("DOC_CODE") + "_" + iMap.getInt("PAGE_NO")+ "." + "pdf");
		
			}

			FileUtils.writeByteArrayToFile(pdfFile,bytes);
			
	
			
			logger.info(" FOTO KK DURUM GUNCELLE  :"+ (System.currentTimeMillis() -start) );
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "BASARILI");
			
		
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
			return oMap;
		}
		
		return oMap;
		
		
	}
	
	
	
	
	protected static byte[] decode64ByteArray(String textToDecode) throws Exception {
		byte[] decodedDocByteArray = null;
		decodedDocByteArray = Base64.decode(textToDecode);
		return decodedDocByteArray;
	}
	public static String getFotoExtension(String fileName){
		if(!"".equals(fileName) && fileName != null){
			String[] res = fileName.split("\\.");
			if(res.length>1)
				return res[res.length-1];
		}

		return null;
	}
	
	@GraymoundService("BNSPR_KK_SEARCH_AGREEMENT_DOCUMENTS")
	public static GMMap searchKkAgreementDocumentsPdf(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String musteriNo = iMap.getString("CUSTOMER_NO");
			String folderPath = ROOT + File.separator + "files";
			String yimFolderPath = ROOT + File.separator + "files";
			String uptFolderPath = ROOT + File.separator + "files";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			Boolean isExistsYim = false;
			Boolean isExistsUpt = false;
			try {
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "KK_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}

			catch (Exception e) {
				e.printStackTrace();
			}

			File klasorYim = null;
			File klasorUpt = null;
			if(TffServicesHelper.isWindowsReservedFilename(musteriNo))
					folderPath = String.format("%s/%s", folderPath,"XXX");	
				else
					folderPath = String.format("%s/%s", folderPath, musteriNo);
				
			yimFolderPath = String.format("%s/%s", folderPath, YIM_CERCEVE_SOZLESME_KOD);
			klasorYim = new File(yimFolderPath);
				if (!klasorYim.exists()){
					isExistsYim = false;
				}
				else{
					isExistsYim = true;
				}
			
			uptFolderPath = String.format("%s/%s", folderPath, UPT_CERCEVE_SOZLESME_KOD);
			klasorUpt = new File(uptFolderPath);
				
				if (!klasorUpt.exists()){
					isExistsUpt = false;
				}
				else{
					isExistsUpt = true;
				}
				
			if (isExistsYim || isExistsUpt)
			{
				oMap.put("IS_EXISTS", "Y");
			}
			else{
				oMap.put("IS_EXISTS", "N");
			}
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "BASARILI");
			
		
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			return oMap;
		}
		
		return oMap;
		
		
	}
	
	@GraymoundService("BNSPR_KK_TAMAMLAYICI_DOKUMAN_ALINDI_MI")
	public static GMMap tamamlayiciDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_kk_basvuru.TamamlayiciDokumanAlindiMi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, CreditCardServicesUtil.nvl(iMap.getBigDecimal("KK_BASVURU_NO"), BigDecimal.ZERO));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(4, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();

			oMap.put("ALINDI_MI", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_KK_BELGE_IPTAL")
	public static GMMap iptalKkBasvuruBelge(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_KK_BASVURU.BasvuruDokumanIptal(?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static GMMap p2DDokumanAlindiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		GMMap docListMap = new GMMap();
		boolean yaziliBhs = false;
		boolean elektronikTamamlayiciBhs = false;
		
		boolean courier = true;
		
		

		try {
		
			GMMap paramSorguMap = new GMMap();
			paramSorguMap.put("KOD", "KK_BASVURU_ALINAN_BELGE");
			paramSorguMap.put("KEY", iMap.getString("SOURCE"));
			paramSorguMap.put("KEY2", DOKUMAN_SORGU_TIPI_P2D);
			paramSorguMap.put("KEY3", "XBHS");

			paramSorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", paramSorguMap));
			if (TffServicesMessages.EVET.equals(paramSorguMap.getString("IS_EXIST"))) {
				GMMap musteriBhsSorguMap = new GMMap();
				musteriBhsSorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				musteriBhsSorguMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", musteriBhsSorguMap));
				if (TffServicesMessages.EVET.equals(musteriBhsSorguMap.getString("F_BHS"))) {
					courier = false;
					yaziliBhs = true;
				}
			}

			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "YBHS", null));
			// Varsa alindi mi diye kontrol et
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
		
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI", sorguMap));
					if("E".equals(sorguMap.getString("ALINDI_MI"))){
						yaziliBhs = true;
						
						courier = false;
						break;
					}
					else{
						yaziliBhs = false;
						courier = true;
					}
						
				
			}
			
			docListMap.clear();			
		
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "YBHS2", null));
			// Varsa alindi mi diye kontrol et
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
		
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI", sorguMap));
					if("E".equals(sorguMap.getString("ALINDI_MI"))){
						yaziliBhs = true;
						
						courier = false;
						break;
					}
					else{
						yaziliBhs = false;
						courier = true;
					}
						
				
			}
			
			docListMap.clear();		
			// Dokumanlari var
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "TEBHS", null));
			// Varsa alindi mi diye kontrol et
			int j = 0 ;
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
			
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TAMAMLAYICI_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					if(yaziliBhs){
						oMap.put("DOKUMAN_LIST", j, "ALINDI_MI" , "E");
						
					}
					else{
						
						oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
						if("H".equals(sorguMap.getString("ALINDI_MI"))){
							elektronikTamamlayiciBhs = false;
							courier = false;
							
						}
						else{
							 courier = true;
							 elektronikTamamlayiciBhs = true;
						}
					}
					
					
						
					j++;
					
				}
			
			
			
			docListMap.clear();		
			docListMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "KK_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), "P2D", "DCS", null));
			// Varsa alindi mi diye kontrol et
			
			for (int i = 0; i < docListMap.getSize("DOKUMAN_LIST"); i++) {
				
					// Dokuman alindi mi?
					sorguMap.clear();
					sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					sorguMap.put("DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI", sorguMap));
					oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", docListMap.get("DOKUMAN_LIST", i, "NAME"));
					if(yaziliBhs){
						oMap.put("DOKUMAN_LIST", j, "ALINDI_MI" , "E");
					}
					else{
						if(elektronikTamamlayiciBhs){
							oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", sorguMap.get("ALINDI_MI"));
						}
						else{
							oMap.put("DOKUMAN_LIST", j, "ALINDI_MI" , "E");
						}
						
						
					}
					
					
					j++;
				}
				
			
	
			
			
			GMMap basvuruMap = new GMMap();
			basvuruMap.put("KART_TIPI" , "D");
			basvuruMap.put("SOURCE", iMap.getString("SOURCE"));
			basvuruMap.putAll(basvuruDokumanAlindiMi(basvuruMap));
			
			for (int i = 0; i < basvuruMap.getSize("DOKUMAN_LIST"); i++) {
				oMap.put("DOKUMAN_LIST", j, "DOKUMAN_KOD", basvuruMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
				oMap.put("DOKUMAN_LIST", j, "ALINDI_MI", basvuruMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				j++;
			}
			
			oMap.put("KURYE", courier ? "E" : "H");
			oMap.put("ANINDA_DONUSUM", courier ? "H" : "E");
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	

}

