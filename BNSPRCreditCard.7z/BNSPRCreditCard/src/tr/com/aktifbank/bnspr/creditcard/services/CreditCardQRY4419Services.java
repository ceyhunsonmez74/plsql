package tr.com.aktifbank.bnspr.creditcard.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardQRY4419Services implements OceanMapKeys {

	@GraymoundService("BNSPR_QRY4419_SET_TABLE")
	public static GMMap setTable(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			
			String func = "{? = call PKG_RC4419.RC_MAPPING_LIST(?,?,?,?)}";
			Object[] inputValues = new Object[]{BnsprType.STRING, iMap.getString("SOURCE_CODE"), BnsprType.STRING, iMap.getString("SERVICE_CODE"),
			                                        BnsprType.STRING, iMap.getString("SYSTEM_CODE"), BnsprType.STRING,  iMap.getString("PRODUCT_CODE")};

			oMap = DALUtil.callOracleRefCursorFunction(func, "RC_RESULTSET", inputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY4419_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("KOD", "CRD_MAP_TUTAR_FROM");
		oMap.put("COMBO_OUT", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		return oMap;
	}
}

