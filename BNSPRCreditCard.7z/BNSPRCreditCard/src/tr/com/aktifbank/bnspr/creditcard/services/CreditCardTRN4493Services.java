package tr.com.aktifbank.bnspr.creditcard.services;
import java.util.Calendar;
import java.util.Date;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.SbaBasvuruiadeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4493Services implements OceanMapKeys{
	@GraymoundService("BNSPR_TRN4493_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			SbaBasvuruiadeTx sbaBasvuruiadeTx = new SbaBasvuruiadeTx();
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			int cmonth = cal.get(Calendar.MONTH);
			int cday = cal.get(Calendar.DAY_OF_MONTH);
			int cyear = cal.get(Calendar.YEAR);
			cal.setTime(iMap.getDate("ODEME_TARIHI"));
			int tmonth = cal.get(Calendar.MONTH);
			int tyear = cal.get(Calendar.YEAR);
			
			if (cmonth == tmonth){
				sbaBasvuruiadeTx.setOdemeGunu("Y");
			}
			else if (cmonth == tmonth+1 && cday<=10 ){
				sbaBasvuruiadeTx.setOdemeGunu("Y");
			}
			else if (cyear== tyear+1 && cmonth==0 && tmonth==11 && cday<=10){
				sbaBasvuruiadeTx.setOdemeGunu("Y");
			}
			else{
				sbaBasvuruiadeTx.setOdemeGunu("E");
			}
			sbaBasvuruiadeTx.setEkPay(iMap.getBigDecimal("EK_PAY"));
			sbaBasvuruiadeTx.setKartBedeli(iMap.getBigDecimal("KART_BEDELI"));
			sbaBasvuruiadeTx.setKuryeBedeli(iMap.getBigDecimal("KURYE_BEDELI"));
			sbaBasvuruiadeTx.setLoyaltyBedeli(iMap.getBigDecimal("LOYALTY_BEDELI"));
			sbaBasvuruiadeTx.setOdemeSekli(iMap.getString("ODEME_SEKLI"));
			sbaBasvuruiadeTx.setOdemeSekliTxt(iMap.getString("ODEME_SEKLI_TXT"));
			sbaBasvuruiadeTx.setOdemeTarihi(iMap.getDate("ODEME_TARIHI"));
			sbaBasvuruiadeTx.setOdemeTxNo(iMap.getBigDecimal("ODEME_TX_NO"));
			sbaBasvuruiadeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			sbaBasvuruiadeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			session.saveOrUpdate(sbaBasvuruiadeTx);
			
			session.flush();
			iMap.put("TRX_NAME" , "4493");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4493_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap=new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			SbaBasvuruiadeTx sbaBasvuruiadeTx = (SbaBasvuruiadeTx) session.createCriteria(SbaBasvuruiadeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			oMap.put("EK_PAY", sbaBasvuruiadeTx.getEkPay());
			oMap.put("KART_BEDELI", sbaBasvuruiadeTx.getKartBedeli());
			oMap.put("KURYE_BEDELI", sbaBasvuruiadeTx.getKuryeBedeli());
			oMap.put("LOYALTY_BEDELI", sbaBasvuruiadeTx.getLoyaltyBedeli());
			oMap.put("ODEME_SEKLI", sbaBasvuruiadeTx.getOdemeSekli());
			oMap.put("ODEME_SEKLI_TXT", sbaBasvuruiadeTx.getOdemeSekliTxt());
			oMap.put("ODEME_TARIHI", sbaBasvuruiadeTx.getOdemeTarihi());
			oMap.put("ODEME_TX_NO", sbaBasvuruiadeTx.getOdemeTxNo());
			oMap.put("TRX_NO", sbaBasvuruiadeTx.getTxNo());
			oMap.put("BASVURU_NO", sbaBasvuruiadeTx.getBasvuruNo());
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	 
}
