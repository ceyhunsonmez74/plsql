package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkYetkiLimitPr;
import tr.com.aktifbank.bnspr.dao.KkYetkiLimitPrTx;
import tr.com.aktifbank.bnspr.dao.KkYetkiLimitPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4417Services {

	@GraymoundService("BNSPR_TRN4417_FILL_TABLE_COMBOBOX")
	public static GMMap fillTableComboBox(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			oMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("LIST_NAME", "KANAL_KODLARI");
			oMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by to_number(kod)");
			DALUtil.fillComboBox(oMap);

			String listName = "TEMINATLI";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "EVET");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "HAYIR");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4417_GET_CODE")
	public static GMMap getCode(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('KK_YETKI_LIMIT_PR')}");
			stmt.registerOutParameter(1, Types.NUMERIC);

			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("CODE", code);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN4417_SAVE")
	public static Map<?, ?> saveTRN8005(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listkkYetkiLimit = (List<?>) session.createCriteria(KkYetkiLimitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = listkkYetkiLimit.iterator(); iterator.hasNext();) {
				KkYetkiLimitPrTx kkYetkiLimit = (KkYetkiLimitPrTx) iterator.next();
				session.delete(kkYetkiLimit);
			}
			session.flush();

			String tableName = "KK_YETKI_LIMIT";
			ArrayList<?> list = (ArrayList<?>) iMap.get(tableName);
			if(list.size()>0){
			for (int i = 0; i < list.size(); i++) {
				KkYetkiLimitPrTx kkYetkiLimit = new KkYetkiLimitPrTx();
				KkYetkiLimitPrTxId id = new KkYetkiLimitPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				kkYetkiLimit.setId(id);
				kkYetkiLimit.setRol(iMap.getBigDecimal("ROL"));
				kkYetkiLimit.setKanal(iMap.getBigDecimal(tableName, i, "KANAL"));
				kkYetkiLimit.setTeminatli(iMap.getString(tableName, i, "TEMINATLI"));
				kkYetkiLimit.setYetkiLimit(iMap.getBigDecimal(tableName, i, "YETKI_LIMITI"));
				kkYetkiLimit.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				kkYetkiLimit.setTeminatliGenelLimit(iMap.getBigDecimal("GENEL_LIMIT_TEMINATLI"));
				kkYetkiLimit.setTeminatsizGenelLimit(iMap.getBigDecimal("GENEL_LIMIT_TEMINATSIZ"));

				session.save(kkYetkiLimit);
			}
			//Tabloda b�t�n kay�tlar silindiyse, ayn� TRX_NO'da KOD s�f�r olarak at�l�r.
			}else{
				KkYetkiLimitPrTx kkYetkiLimit = new KkYetkiLimitPrTx();
				KkYetkiLimitPrTxId id = new KkYetkiLimitPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(new BigDecimal(0));
				kkYetkiLimit.setId(id);
				kkYetkiLimit.setRol(iMap.getBigDecimal("ROL"));
				kkYetkiLimit.setKanal(new BigDecimal(0));
				kkYetkiLimit.setTeminatli("H");
				kkYetkiLimit.setYetkiLimit(new BigDecimal(0));
				kkYetkiLimit.setTeminatliGenelLimit(new BigDecimal(0));
				kkYetkiLimit.setTeminatsizGenelLimit(new BigDecimal(0));
				session.save(kkYetkiLimit);
			}
			session.flush();

			iMap.put("TRX_NAME", "4417");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4417_GET_INFO")
	public static GMMap getInfoTRN8005(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listkkYetkiLimit = null;
			BigDecimal rol = null;
			BigDecimal genelLimitTeminatli = new BigDecimal(0);
			BigDecimal genelLimitTeminatsiz = new BigDecimal(0);
			String rolAciklama = null;
			if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
				listkkYetkiLimit = (List<?>) session.createCriteria(KkYetkiLimitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
				rol = ((KkYetkiLimitPrTx) listkkYetkiLimit.get(0)).getRol();
				genelLimitTeminatli = ((KkYetkiLimitPrTx) listkkYetkiLimit.get(0)).getTeminatliGenelLimit();
				genelLimitTeminatsiz = ((KkYetkiLimitPrTx) listkkYetkiLimit.get(0)).getTeminatsizGenelLimit();
				rolAciklama = LovHelper.diLov(rol, "4417/LOV_ROL", "TANIM");
			}
			else {
				listkkYetkiLimit = (List<?>) session.createCriteria(KkYetkiLimitPr.class).add(Restrictions.eq("rol", iMap.getBigDecimal("ROL"))).list();
				if (listkkYetkiLimit.size() > 0){
					genelLimitTeminatli = ((KkYetkiLimitPr) listkkYetkiLimit.get(0)).getTeminatliGenelLimit();
				    genelLimitTeminatsiz= ((KkYetkiLimitPr) listkkYetkiLimit.get(0)).getTeminatsizGenelLimit();
				}
			} 
				String tableName = "KK_YETKI_LIMIT";
				int row = 0;
				for (Iterator<?> iterator = listkkYetkiLimit.iterator(); iterator.hasNext(); row++) {

					if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
						KkYetkiLimitPrTx kkYetkiLimit = (KkYetkiLimitPrTx) iterator.next();
						// KOD=0 at�lan kay�tlar�n ekrana getirilmemesi i�in bu i�lem yap�lm��t�r. 
						if(kkYetkiLimit.getId().getKod().intValue()==0){
							row--;
						}
						else{
						oMap.put(tableName, row, "KOD", kkYetkiLimit.getId().getKod());
						oMap.put(tableName, row, "KANAL", kkYetkiLimit.getKanal());
						oMap.put(tableName, row, "TEMINATLI", kkYetkiLimit.getTeminatli());
						oMap.put(tableName, row, "YETKI_LIMITI", kkYetkiLimit.getYetkiLimit());
						oMap.put(tableName, row, "ACIKLAMA", kkYetkiLimit.getAciklama());
						}
					}
					else {
						KkYetkiLimitPr kkYetkiLimitPr = (KkYetkiLimitPr) iterator.next();

						oMap.put(tableName, row, "KOD", kkYetkiLimitPr.getKod());
						oMap.put(tableName, row, "KANAL", kkYetkiLimitPr.getKanal());
						oMap.put(tableName, row, "TEMINATLI", kkYetkiLimitPr.getTeminatli());
						oMap.put(tableName, row, "YETKI_LIMITI", kkYetkiLimitPr.getYetkiLimit());
						oMap.put(tableName, row, "ACIKLAMA", kkYetkiLimitPr.getAciklama());
					}
				}

			oMap.put("ROL", rol);
			oMap.put("GENEL_LIMIT_TEMINATLI", genelLimitTeminatli);
			oMap.put("GENEL_LIMIT_TEMINATSIZ", genelLimitTeminatsiz);
			oMap.put("ROL_ACIKLAMA", rolAciklama);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
