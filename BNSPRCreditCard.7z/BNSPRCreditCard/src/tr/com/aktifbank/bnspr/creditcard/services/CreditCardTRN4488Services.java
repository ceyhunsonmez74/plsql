package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.SbaBkmTakasKapamaDty;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.SbaBkmFaturaGiderTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN4488Services{
	@GraymoundService("BNSPR_TRN4488_SAVE")
	public static GMMap save (GMMap iMap){
		GMMap oMap =new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaBkmFaturaGiderTx gider = new SbaBkmFaturaGiderTx(); 
			gider.setBk3ds(iMap.getBigDecimal("BK_3DS"));
			gider.setBkCdys(iMap.getBigDecimal("BK_CDYS"));
			gider.setBkDiger(iMap.getBigDecimal("BK_DIGER"));
			gider.setBkNh(iMap.getBigDecimal("BK_NH"));
			gider.setBkPg(iMap.getBigDecimal("BK_PG"));
			gider.setBkSiu(iMap.getBigDecimal("BK_SIU"));
			gider.setBkSu(iMap.getBigDecimal("BK_SU"));
			gider.setBkTest(iMap.getBigDecimal("BK_TEST"));
			gider.setBkYth(iMap.getBigDecimal("BK_YTH"));
			gider.setBkYu(iMap.getBigDecimal("BK_YU"));
			gider.setBul(iMap.getBigDecimal("BUL"));
			gider.setCdys(iMap.getBigDecimal("CDYS"));
			gider.setFaturaTutar(iMap.getBigDecimal("FATURA_TUTAR"));
			gider.setKk3ds(iMap.getBigDecimal("KK_3DS"));
			gider.setKkBul(iMap.getBigDecimal("KK_BUL"));
			gider.setKkCdys(iMap.getBigDecimal("KK_CDYS"));
			gider.setKkDiger(iMap.getBigDecimal("KK_DIGER"));
			gider.setKkNh(iMap.getBigDecimal("KK_NH"));
			gider.setKkPg(iMap.getBigDecimal("KP_PG"));
			gider.setKkSiu(iMap.getBigDecimal("KK_SIU"));
			gider.setKkSu(iMap.getBigDecimal("KK_SU"));
			gider.setKkTest(iMap.getBigDecimal("KK_TEST"));
			gider.setKkYth(iMap.getBigDecimal("KK_YTH"));
			gider.setKkYu(iMap.getBigDecimal("KK_YU"));
			gider.setMiv(iMap.getBigDecimal("MIV"));
			gider.setNh(iMap.getBigDecimal("NH"));
			gider.setPosCdys(iMap.getBigDecimal("POS_CDYS"));
			gider.setPosDiger(iMap.getBigDecimal("POS_DIGER"));
			gider.setPosMiv(iMap.getBigDecimal("POS_MIV"));
			gider.setPosNh(iMap.getBigDecimal("POS_NH"));
			gider.setPosPg(iMap.getBigDecimal("POS_PG"));
			gider.setPosSgk(iMap.getBigDecimal("POS_SGK"));
			gider.setPosSiu(iMap.getBigDecimal("POS_SIU"));
			gider.setPosSu(iMap.getBigDecimal("POS_SU"));
			gider.setPosTest(iMap.getBigDecimal("POS_TEST"));
			gider.setPosYth(iMap.getBigDecimal("POS_YTH"));
			gider.setPosYu(iMap.getBigDecimal("POS_YU"));
			gider.setSgk(iMap.getBigDecimal("SGK"));
			gider.setSu(iMap.getBigDecimal("SU"));
			gider.setTarih(iMap.getDate("TARIH"));
			gider.setTds(iMap.getBigDecimal("3DS"));
			gider.setToplamTutar(iMap.getBigDecimal("TOPLAM_TUTAR"));
			gider.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gider.setYu(iMap.getBigDecimal("YU"));
						
			session.saveOrUpdate(gider);
			session.flush();
			
			iMap.put("TRX_NAME" , "4488");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN4488_FIS_OLUSTUR")
	public static GMMap fisOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			int i = 0;
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			List<?> dtx = session.createCriteria(SbaBkmTakasKapamaDty.class).add(Restrictions.eq("txNo", txNo)).list();
			
			for(Object name:dtx){
				SbaBkmTakasKapamaDty detay =(SbaBkmTakasKapamaDty)name;
				session.delete(detay);
			}
			session.flush();
			Date date = iMap.getDate("TARIH");
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			int cmonth = cal.get(Calendar.MONTH);
			int cyear = cal.get(Calendar.YEAR);
			BigDecimal totalAmount= BigDecimal.ZERO;
			SbaBkmTakasKapamaDty dty = new SbaBkmTakasKapamaDty();
			BigDecimal posPG = iMap.getBigDecimal("POS_PG");
			if (posPG.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Pazar Geli�tirme �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posPG);
				totalAmount = totalAmount.add(posPG);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkPG = iMap.getBigDecimal("KK_PG");
			if(kkPG.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Pazar Geli�tirme �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkPG);
				totalAmount = totalAmount.add(kkPG);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkPG = iMap.getBigDecimal("BK_PG");
			if(bkPG.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Pazar Geli�tirme �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkPG);
				totalAmount = totalAmount.add(bkPG);
				session.saveOrUpdate(dty);
			}
			BigDecimal posSIU = iMap.getBigDecimal("POS_SIU");
			if(posSIU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura SIU �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posSIU);
				totalAmount = totalAmount.add(posSIU);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkSIU = iMap.getBigDecimal("KK_SIU");
			if(kkSIU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura SIU �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkSIU);
				totalAmount = totalAmount.add(kkSIU);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkSIU = iMap.getBigDecimal("BK_SIU");
			if(bkSIU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura SIU �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkSIU);
				totalAmount = totalAmount.add(bkSIU);
				session.saveOrUpdate(dty);
			}
			BigDecimal posYTH = iMap.getBigDecimal("POS_YTH");
			if(posYTH.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Yurti�i Takas Hesapla�ma �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posYTH);
				totalAmount = totalAmount.add(posYTH);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkYTH = iMap.getBigDecimal("KK_YTH");
			if(kkYTH.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Yurti�i Takas Hesapla�ma �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkYTH);
				totalAmount = totalAmount.add(kkYTH);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkYTH = iMap.getBigDecimal("BK_YTH");
			if(bkYTH.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Yurti�i Takas Hesapla�ma �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkYTH);
				totalAmount = totalAmount.add(bkYTH);
				session.saveOrUpdate(dty);
			}
			BigDecimal posTest = iMap.getBigDecimal("POS_TEST");
			if(posTest.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Test �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posTest);
				totalAmount = totalAmount.add(posTest);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkTest = iMap.getBigDecimal("KK_TEST");
			if(kkTest.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Test �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkTest);
				totalAmount = totalAmount.add(kkTest);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkTest = iMap.getBigDecimal("BK_TEST");
			if(bkTest.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Test �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkTest);
				totalAmount = totalAmount.add(bkTest);
				session.saveOrUpdate(dty);
			}
			BigDecimal posNH = iMap.getBigDecimal("POS_NH");
			if(posNH.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Net HesapLa�ma �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posNH);
				totalAmount = totalAmount.add(posNH);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkNH = iMap.getBigDecimal("KK_NH");
			if(kkNH.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Net HesapLa�ma �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkNH);
				totalAmount = totalAmount.add(kkNH);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkNH = iMap.getBigDecimal("BK_NH");
			if(bkNH.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Net HesapLa�ma �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkNH);
				totalAmount = totalAmount.add(bkNH);
				session.saveOrUpdate(dty);
			}
			BigDecimal posMIV = iMap.getBigDecimal("POS_MIV");
			if(posMIV.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura MIV �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posMIV);
				totalAmount = totalAmount.add(posMIV);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkBUL = iMap.getBigDecimal("KK_BUL");
			if(kkBUL.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura BUL �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkBUL);
				totalAmount = totalAmount.add(kkBUL);
				session.saveOrUpdate(dty);
			}
			BigDecimal posSGK = iMap.getBigDecimal("POS_SGK");
			if(posSGK.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura SGK �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posSGK);
				totalAmount = totalAmount.add(posSGK);
				session.saveOrUpdate(dty);
			}
			BigDecimal posSU = iMap.getBigDecimal("POS_SU");
			if(posSU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Sabit �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posSU);
				totalAmount = totalAmount.add(posSU);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkSU = iMap.getBigDecimal("KK_SU");
			if(kkSU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Sabit �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkSU);
				totalAmount = totalAmount.add(kkSU);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkSU = iMap.getBigDecimal("BK_SU");
			if(bkSU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Sabit �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkSU);
				totalAmount = totalAmount.add(bkSU);
				session.saveOrUpdate(dty);
			}
			BigDecimal kk3DS = iMap.getBigDecimal("KK_3DS");
			if(kk3DS.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura 3D Secure �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kk3DS);
				totalAmount = totalAmount.add(kk3DS);
				session.saveOrUpdate(dty);
			}
			BigDecimal bk3DS = iMap.getBigDecimal("BK_3DS");
			if(bk3DS.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura 3D Secure �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bk3DS);
				totalAmount = totalAmount.add(bk3DS);
				session.saveOrUpdate(dty);
			}
			BigDecimal posCDYS = iMap.getBigDecimal("POS_CDYS");
			if(posCDYS.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura CDYS �creti");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posCDYS);
				totalAmount = totalAmount.add(posCDYS);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkCDYS = iMap.getBigDecimal("KK_CDYS");
			if(kkCDYS.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura CDYS �creti");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkCDYS);
				totalAmount = totalAmount.add(kkCDYS);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkCDYS = iMap.getBigDecimal("BK_CDYS");
			if(bkCDYS.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura CDYS �creti");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkCDYS);
				totalAmount = totalAmount.add(bkCDYS);
				session.saveOrUpdate(dty);
			}
			BigDecimal posYU = iMap.getBigDecimal("POS_YU");
			if(posYU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Y�ll�k �cret");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posYU);
				totalAmount = totalAmount.add(posYU);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkYU = iMap.getBigDecimal("KK_YU");
			if(kkYU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Y�ll�k �cret");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkYU);
				totalAmount = totalAmount.add(kkYU);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkYU = iMap.getBigDecimal("BK_YU");
			if(bkYU.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Y�ll�k �cret");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkYU);
				totalAmount = totalAmount.add(bkYU);
				session.saveOrUpdate(dty);
			}
			BigDecimal posDiger = iMap.getBigDecimal("POS_DIGER");
			if(posDiger.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Di�er �cretler");
				dty.setDkhesapno(getGlobalParam("4488_POS_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(posDiger);
				totalAmount = totalAmount.add(posDiger);
				session.saveOrUpdate(dty);
			}
			BigDecimal kkDiger = iMap.getBigDecimal("KK_DIGER");
			if(kkDiger.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Di�er �cretler");
				dty.setDkhesapno(getGlobalParam("4488_KK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(kkDiger);
				totalAmount = totalAmount.add(kkDiger);
				session.saveOrUpdate(dty);
			}
			BigDecimal bkDiger = iMap.getBigDecimal("BK_DIGER");
			if(bkDiger.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Di�er �cretler");
				dty.setDkhesapno(getGlobalParam("4488_BK_DK"));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("DK");
				dty.setSubekodu("997");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("B");
				dty.setTutar(bkDiger);
				totalAmount = totalAmount.add(bkDiger);
				session.saveOrUpdate(dty);
			}
			
			if(totalAmount.compareTo(BigDecimal.ZERO)!=0){
				dty = new SbaBkmTakasKapamaDty();
				i=i+1;
				dty.setAciklama((cmonth+1) + "/" + cyear +  " BKM Fatura Toplam �cret");
				dty.setHesapno(BigDecimal.valueOf(Long.valueOf(getGlobalParam("BKM_HESAP"))));
				dty.setDovizcinsi("TRY");
				dty.setHesaptur("VS");
				dty.setSubekodu("998");
				dty.setTxNo(txNo);
				dty.setSiraNo(BigDecimal.valueOf(i));
				dty.setBa("A");
				dty.setTutar(totalAmount);
				session.saveOrUpdate(dty);
			}
			session.flush();
			String func = "{? = call PKG_TRN4480.fis_satirlarini_getir(?)}";
            Object[] inputValues = new Object[2] ;
            inputValues[0]=BnsprType.NUMBER;
            inputValues[1]=iMap.getBigDecimal("TRX_NO");
            oMap = DALUtil.callOracleRefCursorFunction(func , "FISBILGISI" , inputValues);
            oMap.put("TOPLAM_TUTAR", totalAmount);
            if(iMap.getBigDecimal("FATURA_TUTAR").compareTo(totalAmount)!=0){
            	oMap.put("HATA", "1");
            }else{
            	oMap.put("HATA", "0");
            }
            
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4488_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap =new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SbaBkmFaturaGiderTx stx = (SbaBkmFaturaGiderTx) session.createCriteria(SbaBkmFaturaGiderTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("BK_3DS",stx.getBk3ds());
			oMap.put("BK_CDYS",stx.getBkCdys());
			oMap.put("BK_DIGER",stx.getBkDiger());
			oMap.put("BK_NH",stx.getBkNh());
			oMap.put("BK_PG",stx.getBkPg());
			oMap.put("BK_SIU",stx.getBkSiu());
			oMap.put("BK_SU",stx.getBkSu());
			oMap.put("BK_TEST",stx.getBkTest());
			oMap.put("BK_YTH",stx.getBkYth());
			oMap.put("BK_YU",stx.getBkYu());
			oMap.put("BUL",stx.getBul());
			oMap.put("CDYS",stx.getCdys());
			oMap.put("FATURA_TUTAR",stx.getFaturaTutar());
			oMap.put("KK_3DS",stx.getKk3ds());
			oMap.put("KK_BUL",stx.getKkBul());
			oMap.put("KK_CDYS",stx.getKkCdys());
			oMap.put("KK_DIGER",stx.getKkDiger());
			oMap.put("KK_NH",stx.getKkNh());
			oMap.put("KK_PG",stx.getKkPg());
			oMap.put("KK_SIU",stx.getKkSiu());
			oMap.put("KK_SU",stx.getKkSu());
			oMap.put("KK_TEST",stx.getKkTest());
			oMap.put("KK_YTH",stx.getKkYth());
			oMap.put("KK_YU",stx.getKkYu());
			oMap.put("MIV",stx.getMiv());
			oMap.put("NH",stx.getNh());
			oMap.put("POS_CDYS",stx.getPosCdys());
			oMap.put("POS_DIGER",stx.getPosDiger());
			oMap.put("POS_MIV",stx.getPosMiv());
			oMap.put("POS_NH",stx.getPosNh());
			oMap.put("POS_PG",stx.getPosPg());
			oMap.put("POS_SGK",stx.getPosSgk());
			oMap.put("POS_SIU",stx.getPosSiu());
			oMap.put("POS_SU",stx.getPosSu());
			oMap.put("POS_TEST",stx.getPosTest());
			oMap.put("POS_YTH",stx.getPosYth());
			oMap.put("POS_YU",stx.getPosYu());
			oMap.put("POS_SGK",stx.getSgk());
			oMap.put("POS_SU",stx.getSu());
			oMap.put("TARIH",stx.getTarih());
			oMap.put("3DS",stx.getTds());
			oMap.put("TOPLAM_TUTAR",stx.getToplamTutar());
			oMap.put("TRX_NO",stx.getTxNo());
			oMap.put("YU",stx.getYu());
			
			GMMap oMap2 = new GMMap();
			String func = "{? = call PKG_TRN4480.fis_satirlarini_getir(?)}";
            Object[] inputValues = new Object[2] ;
            inputValues[0]=BnsprType.NUMBER;
            inputValues[1]=iMap.getBigDecimal("TRX_NO");
            oMap2 = DALUtil.callOracleRefCursorFunction(func , "FISBILGISI" , inputValues);
            oMap.put("FISBILGISI", oMap2.get("FISBILGISI"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", batchParamCode);
		String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return batchNo;
	}
	@GraymoundService("BNSPR_TRN4488_HESAPLA")
	public static GMMap hesapla (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			oMap.put("POS_NH", iMap.getBigDecimal("NH").divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("KK_NH", iMap.getBigDecimal("NH").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("BK_NH", iMap.getBigDecimal("NH").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("POS_MIV", iMap.getBigDecimal("MIV"));
			oMap.put("KK_BUL", iMap.getBigDecimal("BUL"));
			oMap.put("POS_SGK", iMap.getBigDecimal("SGK"));
			oMap.put("POS_SU", iMap.getBigDecimal("SU").divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("KK_SU", iMap.getBigDecimal("SU").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("BK_SU", iMap.getBigDecimal("SU").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("KK_3DS", iMap.getBigDecimal("3DS").divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("BK_3DS", iMap.getBigDecimal("3DS").divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("POS_CDYS", iMap.getBigDecimal("CDYS").divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("KK_CDYS", iMap.getBigDecimal("CDYS").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("BK_CDYS", iMap.getBigDecimal("CDYS").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("POS_YU", iMap.getBigDecimal("YU").divide(BigDecimal.valueOf(2), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("KK_YU", iMap.getBigDecimal("YU").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
			oMap.put("BK_YU", iMap.getBigDecimal("YU").divide(BigDecimal.valueOf(4), 2, BigDecimal.ROUND_HALF_UP));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	

}
