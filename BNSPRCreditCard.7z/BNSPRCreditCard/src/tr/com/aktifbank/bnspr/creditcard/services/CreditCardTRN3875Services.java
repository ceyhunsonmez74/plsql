package tr.com.aktifbank.bnspr.creditcard.services;

import java.math.BigDecimal;

import org.apache.commons.lang.BooleanUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruIptalTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreditCardTRN3875Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since 17.01.2014
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>GEREKCE_KOD_LIST - Secilebilecek iptal gerekceleri
	 *         <li>ONCEKI_DURUM_KOD_LIST - Iptal edilebilecek basvuru durumlari
	 */
	@GraymoundService("BNSPR_TRN3875_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//TFF kart tipi
			oMap.putAll(CreditCardServicesUtil.getParameterList("TFF_KART_TIPI_LIST", "TFF_DONUSTUR_KART_TIPI", "A", "E"));

			//Gerekce listesi
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3872_GET_AKSIYON_KARAR", iMap));//AKSIYON_KARAR_LIST

			//Durum listesi
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT");
			query.append(" FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = 'KK_BASVURU_DURUM_KOD'");
			query.append(" ORDER BY SIRA_NO");
			DALUtil.fillComboBox(oMap, "ONCEKI_DURUM_KOD_LIST", true, query.toString());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since 20.02.2014
	 * @param iMap - Kk basvuru iptal islemi bilgileri<br>
	 *        <li>BASVURU_NO - Basvuru numarasi
	 *        <li>ONCEKI_DURUM_KOD - Basvuru durum kodu
	 *        <li>ISLEM_KOD - Iptalin hangi ekran ya da islemden yapildigi.
	 *        <li>GEREKCE_KOD - Iptal gerekcesi
	 *        <li>ACIKLAMA - Iptal aciklamasi
	 *        <li>TFF_BASVURU_IPTAL_MI - TFF basvurusu varsa iptal edilsin mi (E:Evet | H:Hayir)
	 *        <li>TFF_KART_TIPI - TFF basvurusu var ve iptal edilmiyorsa hangi kart tipine donusum yapilacagi.
	 *        <li>BASIM_ACIK_IPTAL_MI - Basim, Acik statusundeki basvurular iptal edilsin mi (E:Evet|H:Hayir)
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3875_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo == null) {
				trxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO").toString());
			}
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			KkBasvuruIptalTx kkBasvuruIptalTx = (KkBasvuruIptalTx) session.get(KkBasvuruIptalTx.class, trxNo);
			if (kkBasvuruIptalTx == null) {
				kkBasvuruIptalTx = new KkBasvuruIptalTx();
			}
			//Islem bilgilerini al.
			kkBasvuruIptalTx.setTxNo(trxNo);
			kkBasvuruIptalTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kkBasvuruIptalTx.setIslemKodu(iMap.getString("ISLEM_KOD"));
			kkBasvuruIptalTx.setGerekceKod(iMap.getString("GEREKCE_KOD"));
			kkBasvuruIptalTx.setOncekiDurumKod(iMap.getString("ONCEKI_DURUM_KOD"));
			kkBasvuruIptalTx.setAciklama(iMap.getString("ACIKLAMA"));
			kkBasvuruIptalTx.setTffBasvuruIptalMi(CreditCardServicesUtil.nvl(iMap.getString("TFF_BASVURU_IPTAL_MI"), CreditCardServicesUtil.HAYIR));
			kkBasvuruIptalTx.setTffKartTipi(iMap.getString("TFF_KART_TIPI"));
			kkBasvuruIptalTx.setBasimAcikIptalMi(CreditCardServicesUtil.nvl(iMap.getString("BASIM_ACIK_IPTAL_MI"), CreditCardServicesUtil.HAYIR));
			
			//Islem bilgilerini kaydet
			session.save(kkBasvuruIptalTx);
			session.flush();
			
			//Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", "3875");
			islemMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));
			oMap.put("TRX_NO", trxNo);
			GMServiceExecuter.executeAsync("BNSPR_KK_BELGE_IPTAL", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kk iptal islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since 20.02.2014
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>BASVURU_NO - Basvuru numarasi
	 *         <li>ONCEKI_DURUM_KOD - Basvuru durum kodu
	 *         <li>ISLEM_KOD - Iptalin hangi ekran ya da islemden yapildigi.
	 *         <li>GEREKCE_KOD - Iptal gerekcesi
	 *         <li>ACIKLAMA - Iptal aciklamasi
	 *         <li>TFF_BASVURU_IPTAL_MI - TFF basvurusu varsa iptal edilsin mi (E:Evet | H:Hayir)
	 *         <li>TFF_KART_TIPI - TFF basvurusu var ve iptal edilmiyorsa hangi kart tipine donusum yapilacagi.
	 *         <li>BASIM_ACIK_IPTAL_MI -BASIM ACIK durumu iptal edilsin mi (E:Evet | H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3875_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al
			KkBasvuruIptalTx kkBasvuruIptalTx = (KkBasvuruIptalTx) session.get(KkBasvuruIptalTx.class, trxNo);
			if (kkBasvuruIptalTx != null) {
				oMap.put("BASVURU_NO", kkBasvuruIptalTx.getBasvuruNo());
				oMap.put("ONCEKI_DURUM_KOD", kkBasvuruIptalTx.getOncekiDurumKod());
				oMap.put("GEREKCE_KOD", kkBasvuruIptalTx.getGerekceKod());
				oMap.put("ACIKLAMA", kkBasvuruIptalTx.getAciklama());
				oMap.put("TFF_BASVURU_IPTAL_MI", BooleanUtils.toBoolean(kkBasvuruIptalTx.getTffBasvuruIptalMi(),
						CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
				oMap.put("TFF_KART_TIPI", kkBasvuruIptalTx.getTffKartTipi());
				oMap.put("BASIM_ACIK_IPTAL_MI", BooleanUtils.toBoolean(kkBasvuruIptalTx.getBasimAcikIptalMi(),
						CreditCardServicesUtil.EVET, CreditCardServicesUtil.HAYIR));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Iptal islemi sonrasi tff basvurusu varsa onay sonrasi islemleri gerceklestirir.<br>
	 * @author murat.el
	 * @since 27.02.2014
	 * @param iMap - Islem bilgileri<br>
	 *         <li>ISLEM_NO - Islem numarasi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN3875_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			KkBasvuruIptalTx kkBasvuruIptalTx = (KkBasvuruIptalTx) session.get(KkBasvuruIptalTx.class, trxNo);
			if (kkBasvuruIptalTx != null) {
				//Limit artis basvurusu ise limit tablolarini besle
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, kkBasvuruIptalTx.getBasvuruNo());
				if (kkBasvuru != null && "L".equals(kkBasvuru.getKartSeviyesi())) {
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					sorguMap.put("SONRAKI_DURUM_KODU", "IPTAL");
					sorguMap.put("LKS_RED_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3821_KKDAN_DURUM_GUNCELLE", sorguMap));
				}
				//Iliskili TFF basvurusu varsa iptal edilsin mi
				if (CreditCardServicesUtil.EVET.equals(kkBasvuruIptalTx.getTffBasvuruIptalMi())) {
					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
							.add(Restrictions.eq("kkBasvuruNo", kkBasvuruIptalTx.getBasvuruNo()))
							.uniqueResult();
					if (tffBasvuru != null && !"IPTAL".equals(tffBasvuru.getDurumKod())) {
						sorguMap.clear();
						sorguMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
						sorguMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
						sorguMap.put("ISLEM_KOD", "3875");
						sorguMap.put("GEREKCE_KOD", "4");//Otomatik Iptal
						sorguMap.put("ACIKLAMA", kkBasvuruIptalTx.getAciklama());
						sorguMap.put("KK_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
						sorguMap.put("BASIM_ACIK_IPTAL_MI", kkBasvuruIptalTx.getBasimAcikIptalMi());
						GMServiceExecuter.execute("BNSPR_TRN3809_SAVE", sorguMap);
					}
				} else {
					if (kkBasvuruIptalTx.getTffKartTipi() != null) {
						TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class)
								.add(Restrictions.eq("kkBasvuruNo", kkBasvuruIptalTx.getBasvuruNo()))
								.uniqueResult();
						if (tffBasvuru != null) {
							sorguMap.clear();
							sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
							sorguMap.put("KK_BASVURU_NO", kkBasvuruIptalTx.getBasvuruNo());
							sorguMap.put("KART_TIPI", CreditCardTffServices.TFF_KREDI_KARTI);
							sorguMap.put("BASVURU_IPTAL_EDILSIN_MI", CreditCardServicesUtil.EVET);
							sorguMap.put("ISLEM_NO", kkBasvuruIptalTx.getTxNo());
							sorguMap.put("ISLEM_KOD", "3875");
							sorguMap.put("SONRAKI_DURUM_KODU", "BASIM");
							sorguMap.put("YENI_KART_TIPI", kkBasvuruIptalTx.getTffKartTipi());
							oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KK_RED_KART_TIPI_DONUSTUR", sorguMap));
						}
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
