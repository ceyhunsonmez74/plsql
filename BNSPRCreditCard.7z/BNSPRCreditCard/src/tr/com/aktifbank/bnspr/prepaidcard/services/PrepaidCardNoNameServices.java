package tr.com.aktifbank.bnspr.prepaidcard.services;

import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.Constants;
import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlMusteriAps;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkPpBasvuruSmsBildirim;
import tr.com.aktifbank.bnspr.dao.KkPpBasvuruSmsBildirimId;
import tr.com.aktifbank.bnspr.dao.KkSsProductMap;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class PrepaidCardNoNameServices implements OceanMapKeys, Constants {
	
	/** Noname prepaid kart icin girilen talebi alarak basvuru olusturur.
	 *  Islem sonucuna gore talebi gunceller.<br>
	 * @author murat.el
	 * @since 
	 * @param iMap - Sorgu kriterleri<br>
	 * 			<li>Talepten alinan basvuru olusturmak icin gerekli bilgiler
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>BASVURU_NO - prepaid basvuru no
	 *          <li>KART_NO - prepaid kart no
	 *          <li>DURUM_KOD - Islem durum kodu
	 */
	
	private static final String firstNumberOfTroyCard ="9";
	private static final String SMS_HEADER ="Aktif Bank";

	
	@GraymoundService("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS")
	public static GMMap updateApplicationStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		
		//Urun bilgilerini al
		KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		
		if(kkBasvuru != null){
			kkBasvuru.setDurumKod(iMap.getString("DURUM_KOD"));
			session.saveOrUpdate(kkBasvuru);
			
		}
		
		GMMap sorguMap = new GMMap();
	
		sorguMap.put("ISLEM_KODU", "TALEP");
		sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
		sorguMap.put("DURUM_KODU", "TALEP");
		sorguMap.put("ISLEM_SONRASI_DURUM_KODU", iMap.get("DURUM_KOD"));
		sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
		sorguMap.put("BAS_TARIHI", Calendar.getInstance().getTime());
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", sorguMap));
		
		return oMap;
	}
	
	/** No Name debit kart icin girilen talebi alarak basvuru surecini tamamlar<br>
	 * @author murat.el
	 * @since 
	 * @param iMap - Basvuru bilgileri<br>
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_PREPAID_NONAME_CREATE_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Todo Ayni TCKNye ait prepaid basvuru veya kart var mi?
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("KAYNAK", "NONAME");
			//sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_NKOLAY_VALIDATE_APPLICATION", sorguMap));
			
			//KPS datasini al
			
			if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
				sorguMap.put("TCK_NO", iMap.get("TCKN"));
				sorguMap.put("KPS_JOB_AKTIF_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_KPS_SORGULA", sorguMap));
				sorguMap.put("KIMLIK_SERI_NO", sorguMap.get("KIMLIK_SERI_NO_KPS"));
				sorguMap.put("KIMLIK_SIRA_NO", sorguMap.get("KIMLIK_SIRA_NO_KPS"));
				sorguMap.remove("TCK_NO");
				sorguMap.remove("KPS_JOB_AKTIF_MI");
			}
			
			else{
				
				sorguMap.put("UYRUK_KOD", iMap.getString("COUNTRY_CODE"));
				sorguMap.put("PASAPORT_NO", iMap.getString("PASSPORT_NO"));
				sorguMap.put("ADI", iMap.getString("NAME"));
				sorguMap.put("IKINCI_ADI", iMap.getString("SECOND_NAME"));
				sorguMap.put("SOYADI", iMap.get("SURNAME"));
				sorguMap.put("DOGUM_TARIHI", iMap.get("BIRTH_DATE"));
				sorguMap.put("CINSIYET", iMap.get("GENDER"));
				//upt i�in eklendi yabanc� uyruklular i�in
				sorguMap.put("ANNE_ADI", iMap.get("MOTHER_NAME"));
				sorguMap.put("BABA_ADI", iMap.get("FATHER_NAME"));
				sorguMap.put("DOGUM_YERI", iMap.get("BIRTH_PLACE"));
				
			}
			
			
			if (!basvuruYasKontrol(iMap.getString(SOURCE),sorguMap.getString("DOGUM_TARIHI"))){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ONSEKIZ_YAS_KK_D_KONTROLU);
				return oMap;
			}
			
			
			// adres bilgilerini al
			
			if("TR".equals(iMap.getString("COUNTRY_CODE"))){
				// aps adres bilgisi al
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				
				//Urun bilgilerini al
				GnlMusteriAps gnlMusteriAps = (GnlMusteriAps) session.createCriteria(GnlMusteriAps.class)
						.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
			
				if (gnlMusteriAps != null){
					sorguMap.put("DIGER_ADRES", getApsAcikAdres(gnlMusteriAps));
					sorguMap.put("DIGER_IL",  StringUtil.lPad(gnlMusteriAps.getApsIlKodu()+ "" ,3));
					sorguMap.put("DIGER_ILCE", gnlMusteriAps.getApsIlceKodu());

					sorguMap.put("ILETISIM_ADRES_KOD", "D");
					sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("TESLIMAT_ADRES_KOD", "D");
				}
	
			}
			
			
			else{
				// basvuruda gelen adresi al
				
				if("E".equals(iMap.getString("DELIVERY_ADRESS_TYPE"))){
					sorguMap.put("EV_ADRES", iMap.getString("DELIVERY_ADRESS"));
					sorguMap.put("EV_IL", StringUtil.isEmpty(iMap.getString("DELIVERY_ADRESS_CITY")) ? StringUtils.EMPTY : StringUtil.lPad(iMap.getString("DELIVERY_ADRESS_CITY") , 3));
					sorguMap.put("EV_ILCE", iMap.getString("DELIVERY_ADRESS_DISTRICT"));
					
					sorguMap.put("ILETISIM_ADRES_KOD", "E");
					sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("TESLIMAT_ADRES_KOD", "E");
				}
				else if("I".equals(iMap.getString("DELIVERY_ADRESS_TYPE"))){
					sorguMap.put("IS_ADRES", iMap.getString("DELIVERY_ADRESS"));
					sorguMap.put("IS_IL", StringUtil.isEmpty(iMap.getString("DELIVERY_ADRESS_CITY")) ? StringUtils.EMPTY : StringUtil.lPad(iMap.getString("DELIVERY_ADRESS_CITY") , 3));
					sorguMap.put("IS_ILCE", iMap.getString("DELIVERY_ADRESS_DISTRICT"));
					sorguMap.put("ILETISIM_ADRES_KOD", "I");
					sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("TESLIMAT_ADRES_KOD", "I");
				}
		
				else if("D".equals(iMap.getString("DELIVERY_ADRESS_TYPE"))){
					sorguMap.put("DIGER_ADRES", iMap.getString("DELIVERY_ADRESS"));
					sorguMap.put("DIGER_IL", StringUtil.isEmpty(iMap.getString("DELIVERY_ADRESS_CITY")) ? StringUtils.EMPTY : StringUtil.lPad(iMap.getString("DELIVERY_ADRESS_CITY") , 3));
					sorguMap.put("DIGER_ILCE", iMap.getString("DELIVERY_ADRESS_DISTRICT"));
					sorguMap.put("ILETISIM_ADRES_KOD", "D");
					sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
					sorguMap.put("TESLIMAT_ADRES_KOD", "D");
				}
				
				
				
			}
			
			// telefon bilgisini al
			
			sorguMap.put("TELEFON_TIPI", "C");//Cep tel
			
			sorguMap.put("CEP_ULKE_KOD",iMap.getString("PHONE_COUNTRY_CODE"));
			sorguMap.put("CEP_TEL_KOD", iMap.getString("PHONE_OPERATOR_CODE"));
			sorguMap.put("CEP_TEL_NO",   iMap.getString("PHONE_NUMBER"));
			sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.EVET);
			sorguMap.put("KURYE_TIPI", "TN");
			
			
			//Basvurunun talepten gelmeyen alanlarini al
			GMMap paramMap = new GMMap();
			paramMap.put("ADI", sorguMap.getString("ADI"));
			paramMap.put("IKINCI_ADI", sorguMap.getString("IKINCI_ADI"));
			paramMap.put("SOYADI", sorguMap.get("SOYADI"));
			paramMap.putAll(iMap);
			sorguMap.putAll(getNoNameApplicationParameters(paramMap));
			
			//Talepten gelen datalari al
			sorguMap.putAll(iMap);
			
			//Basvuru datasini kaydet
			sorguMap.put("ISLEM_FLAG", "E");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_SAVE_OR_UPDATE_APPLICATION", sorguMap));//BASVURU_NO, TRX_NO
			oMap.put("BASVURU_NO", sorguMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", sorguMap.get("TRX_NO"));
			
			//Basvuruyu datasini kontrol et
			
			//GMServiceExecuter.execute("BNSPR_TRN3870_AFTER_CONTROL", sorguMap);
			//GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", sorguMap);
			
			//Basvuruyu tamamla
			GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap);
			
			//Tarihceye kayit at
			//Tarihceye NBSMe gonderildi kaydi at
			sorguMap.clear();
			sorguMap.put("ISLEM_KODU", "TALEP");
			sorguMap.put("BASVURU_NO", oMap.get("BASVURU_NO"));
			sorguMap.put("DURUM_KODU", "TALEP");
			sorguMap.put("ISLEM_SONRASI_DURUM_KODU", "BASVURU");
			sorguMap.put("TRX_NO", oMap.get("TRX_NO"));
			sorguMap.put("BAS_TARIHI", Calendar.getInstance().getTime());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	
	
	/** NKolay debit kart icin girilen talebte yer almayan 
	 * nkolay debit basvurusuna ozel degerleri alir.<br>
	 * @author murat.el
	 * @since TY-4783
	 * @param iMap - Basvuru bilgileri<br>
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>BASVURU_TARIHI<li>KANAL_KOD<li>KREDI_KARTI_SEVIYESI
	 *          <li>KART_TIPI<li>SESSION_IP<li>FINANSAL_TIP
	 *          <li>LOGO_KODU<li>KART_URUN_TIP<li>KART_UZERINDEKI_ISIM
	 *          <li>MUSTERI_TIPI<li>MUSTERI_GROUP<li>SUBE_KOD
	 */
	private static GMMap getNoNameApplicationParameters(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Default degerleri ata
			oMap.put("BASVURU_TARIHI", Calendar.getInstance().getTime());
			
			String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
			
			oMap.put("KANAL_KOD", kanalKodu);//yim-bayi
			oMap.put("KREDI_KARTI_SEVIYESI", "K");//Kart basvurusu
			oMap.put("KART_TIPI", "P");
			oMap.put("SESSION_IP", ADCSession.getString("CLIENT_IP"));
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			//Urun bilgilerini al
			String urunId = iMap.getString("URUN_ID");
			if(StringUtils.isEmpty(urunId)){
				
				//YIM'den TROY da bas�labilecek. KartNo 9 ile ba�l�yorsa TROY'dur, 
				String marka = "";
				if (SOURCE_YIM.equals(iMap.getString(SOURCE))){
						marka = OceanConstants.MASTERCARD;
					if (firstNumberOfTroyCard.equals(StringUtils.substring(iMap.getString(CARD_NO), 0, 1))){
						marka = OceanConstants.TROY;	
					}
				}
				urunId = KkProductsUtil.getProductIdByDetails(iMap.getString(SOURCE), null, marka, OceanConstants.Akustik_PrepaidCard);
			}
		
			KkSsProductMap kkSsProductMap = KkProductsUtil.getProductInfoById(urunId);
			
			if (kkSsProductMap != null) {
				oMap.put("FINANSAL_TIP", kkSsProductMap.getFinansalKod());
				oMap.put("LOGO_KODU", kkSsProductMap.getLogoKod());
				oMap.put("KART_URUN_TIP", kkSsProductMap.getUrunId());
			}

			//Musteri bilgilerini al
			oMap.put("KART_UZERINDEKI_ISIM", CreditCardApplicationServices.getKartUzerindekiIsim
					(iMap.getString("ADI"), iMap.getString("IKINCI_ADI"), iMap.getString("SOYADI")));
			
			//Banka personeli mi
			String personelMi = null;
	 
	    		GMMap sorguMap = new GMMap();
		    	sorguMap.put("TC_KIMLIK_NO", iMap.get("TCKN"));
		    	sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
		    	sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
		    	sorguMap.put("REFERANS_TIPI", "KK");
		    	personelMi = GMServiceExecuter.call("BNSPR_CREDITCARD_PERSONEL_MI", sorguMap).getString("PERSONEL_MI");
	    	
		
	    	
	    	//Personel olup olmadigina gore musteri tipi ve grubu belirlenir.
	    	//Default olarak belirlenen musteri tipi
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI");
	    	}
	    	oMap.put("MUSTERI_TIPI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));

	    	//Default olarak belirlenen musteri grubu
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP");
	    	}
	    	oMap.put("MUSTERI_GROUP", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));
	    	
	    	//Sube kodu bilgisini musteri uzerinden al
	    	GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("MUSTERI_NO"));
	    	if (gnlMusteri != null) {
	    		oMap.put("SUBE_KOD", gnlMusteri.getSubeKodu());
	    	}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static String getApsAcikAdres(GnlMusteriAps aps) {
		
		StringBuilder adres = new StringBuilder();
		String ayrac = " ";
		
	  
	    	//Acik adres
	    	if (StringUtils.isNotBlank(aps.getApsBucak())) {
	    		adres.append(aps.getApsBucak()).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(aps.getApsKoy())) {
	    		adres.append(aps.getApsKoy()).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(aps.getApsMahalle())) {
	    		adres.append(aps.getApsMahalle()).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(aps.getApsCsbm())) {
	    		adres.append(aps.getApsCsbm()).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(aps.getApsDisKapiNo())) {
	    		adres.append("NO:").append(aps.getApsDisKapiNo()).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(aps.getApsIcKapiNo())) {
	    		adres.append("DAIRE:").append(aps.getApsIcKapiNo());
	    	}
	    	
	    
	    	return adres.toString().trim();
	}
	
	public static boolean basvuruYasKontrol (String source, String dogumTar){
		
		boolean basvuruYapabilir = true;
		try{
		GMMap paramMap = new GMMap();
		paramMap.put("KOD", "PP_KART_BASVURU_YAS_SINIRI");
		paramMap.put("KEY", source);
		paramMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
		paramMap.getString("TEXT"); 
		
		if (!StringUtils.isEmpty(paramMap.getString("TEXT"))){
			
			int yasSiniri = new Integer (paramMap.getString("TEXT"));
			
			if(tr.com.aktifbank.bnspr.tff.services.TffServicesHelper.getYas(dogumTar) < yasSiniri) {
				basvuruYapabilir = false;
			}
		}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return basvuruYapabilir;
	}
	
	@GraymoundService("BNSPR_KK_PP_BASVURU_SMS_BILDIRIM")
	public static GMMap basvuruBildirimSms(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);

		try{
			KkPpBasvuruSmsBildirim kkBasvuruSms = new KkPpBasvuruSmsBildirim();
			KkPpBasvuruSmsBildirimId kkBasvuruSmsId = new KkPpBasvuruSmsBildirimId();
	
			GMMap msgMap =  new GMMap();
		    String mesaj = CreditCardServicesUtil.errorMessageOlustur(iMap.getString("MESAJ_NO"));
			msgMap.put("CONTENT", mesaj);
		    msgMap.put("MSISDN", iMap.getString("TEL_NO"));
		    msgMap.put("MUSTERI_NO" , iMap.getString("MUSTERI_NO"));
		    msgMap.put("HEADER" ,  iMap.getString("BASLIK", SMS_HEADER));	
	    
		    GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC" , msgMap);
	
		    kkBasvuruSmsId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
		    kkBasvuruSmsId.setKaynak(iMap.getString("KAYNAK"));
		    kkBasvuruSmsId.setMesaj(mesaj);
		    kkBasvuruSmsId.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
		    kkBasvuruSmsId.setTelNo(iMap.getString("TEL_NO"));
		    kkBasvuruSms.setId(kkBasvuruSmsId);
		    
	        session.saveOrUpdate(kkBasvuruSms);
	        session.flush();
		}
		
		catch (Exception e) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", e.toString());
			e.printStackTrace();
		}
		finally{
			if(session != null){
				session.flush();
			}
		}
		return oMap;
	}

}
