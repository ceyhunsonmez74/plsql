package tr.com.aktifbank.bnspr.prepaidcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.runtime.directive.ForeachScope;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.Constants;
import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.KkSsProductMap;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class PrepaidCardCommonServices extends TffServicesHelper implements TffServicesMessages , OceanMapKeys, Constants  {

	// Logger
	private static final Logger logger = Logger.getLogger(PrepaidCardCommonServices.class);
	private static final String BAYI_KANAL = "2";

	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_CARD_REQUEST")
	public static GMMap validatePrepaidCardRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		Session session = null;
				
		
		try {

			// Kanal
			if (StringUtils.isBlank(iMap.getString(SOURCE))) {
				CreditCardServicesUtil.raiseGMError("330", "Islem Kanali");
			}

			if (StringUtils.isBlank(iMap.getString("COUNTRY_CODE"))) {
				CreditCardServicesUtil.raiseGMError("330", "Uyruk");
			}

			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
				if (StringUtils.isBlank(iMap.getString("TCKN"))) {
					CreditCardServicesUtil.raiseGMError("330", "TCKN");
				}

				// TCKN
				if (iMap.containsKey("TCKN_RAISE_ERROR") && false == iMap.getBoolean("TCKN_RAISE_ERROR")){
					String sonuc = tcknKontrol(iMap.getString("TCKN"));
					if (!StringUtils.isEmpty(sonuc)){
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", sonuc);
						return oMap;
					}
				}
				else{
					sorguMap.clear();
					sorguMap.put("TCKN", iMap.get("TCKN"));
					sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
					GMServiceExecuter.execute("BNSPR_TRN3870_TCKN_KONTROL", sorguMap);
					session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				}
				
			}
			else {
				if (StringUtils.isBlank(iMap.getString("PASSPORT_NO"))) {
					CreditCardServicesUtil.raiseGMError("330", "Pasaport No");
				}
			}
			
			session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
			
			

			if(musteriNo != null && musteriNo.compareTo(BigDecimal.ZERO) != 0){
				// check duplicate
				String[] durumKodList = {"BASVURU"}; 
				String[] urunTipiList = null;
				ArrayList<String> urunList = new ArrayList();
				String cardNo = "";
				if (iMap.containsKey(SOURCE) && SOURCE_NKOLAYAPP.equals(iMap.getString(SOURCE))){
					GMMap cMap = new GMMap();
			   	 	cMap.put(CARD_DCI, OceanConstants.Akustik_AllCardDci);
			        cMap.put(CUSTOMER_NO, musteriNo);
			        cMap.put(TCKN, iMap.getString(TCKN));
			        cMap.put(CARD_BANK_STATUS, OceanConstants.Card_Bank_Status_Open);
			       
			        cMap.putAll( GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO" , cMap));
			        boolean aktifKartVar = false;
			        for (int i = 0; i < cMap.getSize(CARD_DETAIL_INFO); i++){
			        	
			        	if (KkProductsUtil.getVirtualProductId().equals(cMap.get(CARD_DETAIL_INFO , i , PRODUCT_ID))){
			        		aktifKartVar = true;
			        		cardNo = cMap.getString(CARD_DETAIL_INFO , i , CARD_NO);
			        		break;
			        	}
			        
			        }
			        
					if(aktifKartVar){
						oMap.put(CARD_NO, cardNo);
						return oMap;
					}				
				} 
				else{
					GMMap urunFilterMap = new GMMap();
					//String urunTipi = (PrepaidCardSource.YIM.equals(iMap.getString(SOURCE))) ? "910":(PrepaidCardSource.EGOMBL.equals(iMap.getString(SOURCE)) ? "914" :"912");
					//�r�n kodlar� parametrik hale getirildi
					String source = iMap.getString(SOURCE);
					List<KkBasvuru> kkBasvuruList = null;
					if (SOURCE_EGOMBL.equals(source) || SOURCE_MRSMBL.equals(source)){
						HCEOfflineCardSource hce = HCEOfflineCardSource.getByName(source);
						List<?> list = KkProductsUtil.getHceProducts(null, hce.getSpecialDefinition());
						KkSsProductMap kkProduct = null;
						
						for (Object o: list){
							kkProduct =(KkSsProductMap) o;
							urunList.add(kkProduct.getUrunId());
						}
					}

					else{
						urunFilterMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, source);
						urunFilterMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_PrepaidCard);
						urunFilterMap.putAll(KkProductsUtil.getProductInfoListByMap(urunFilterMap));
		
					
						for (int i = 0; i < urunFilterMap.getSize(OceanConstants.KK_PRODUCT_LIST); i++) {
							 urunTipiList = !StringUtils.isEmpty(urunFilterMap.getString(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_URUN_ID)) ? urunFilterMap.getString(OceanConstants.KK_PRODUCT_LIST, i, OceanConstants.URUN_TABLO_URUN_ID).split(",") : null;
							 if (urunTipiList != null && urunTipiList.length > 0) {
									urunList.addAll(new ArrayList<String>(Arrays.asList(urunTipiList)));
								}
							 }	
						}
					
					
					kkBasvuruList = (List<KkBasvuru>) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo))
						.add(Restrictions.in("durumKod", durumKodList)).add(Restrictions.in("urunTipi", urunList)).list();
					
					if(kkBasvuruList != null && kkBasvuruList.size() > 0){
						
						String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
						//bayi yeni ak��tan geldiyse mevcut ba�vuru otomatik iptal edilsin
						if (BAYI_KANAL.equals(kanalKodu))
						{
							GMMap cancelMap = new GMMap();
							cancelMap.put("APPLICATION_NO", kkBasvuruList.get(0).getBasvuruNo());
							cancelMap.put("TXN_CODE", "" );
							cancelMap.put("TXN_DESC", "" );
							if(SOURCE_UPT.equals(iMap.getString(SOURCE))){
								
								cancelMap.putAll(GMServiceExecuter.execute("BNSPR_UPT_CANCEL_APPLICATION", cancelMap));
								if (! cancelMap.getString("RESPONSE").equals(AkustikConstants.RESPONSE_SUCCESS)){
									oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
									oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_GENEL_HATA);
								}
								
							}
							
							else if(SOURCE_YIM.equals(iMap.getString(SOURCE))){
								
								cancelMap.putAll(GMServiceExecuter.execute("BNSPR_YIM_CANCEL_APPLICATION", cancelMap));
								if (! cancelMap.getString("RESPONSE").equals(AkustikConstants.RESPONSE_SUCCESS)){
									oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
									oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_GENEL_HATA);
								}
							}
								
							else{
									CreditCardServicesUtil.raiseGMError("50016");
							}
									
						}
						else{
							for (KkBasvuru kkBasvuru: kkBasvuruList){
							if (SOURCE_EGOMBL.equals(iMap.getString(SOURCE)) || SOURCE_MRSMBL.equals(iMap.getString(SOURCE)) ||  KkProductsUtil.getVirtualProductId().equals(kkBasvuru.getUrunTipi())){
								GMMap cancelMap = new GMMap();
							//	for (KkBasvuru kkBasvuru: kkBasvuruList){
									cancelMap.put("APPLICATION_NO", kkBasvuru.getBasvuruNo());
									cancelMap.put("TXN_CODE", "" );
									cancelMap.put("TXN_DESC", "" );
									cancelMap.putAll(GMServiceExecuter.execute("BNSPR_EKENT_CANCEL_APPLICATION", cancelMap));
										if (! cancelMap.getString("RESPONSE").equals(AkustikConstants.RESPONSE_SUCCESS)){
											oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
											oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_GENEL_HATA);
										}
										
								}
							else 
								CreditCardServicesUtil.raiseGMError("50016");
							}
							
							
						}
						
				     }
				}
			}
			if (!StringUtils.isBlank(iMap.getString("PASSPORT_NO"))) {
				if (StringUtils.isBlank("NAME")) {
					CreditCardServicesUtil.raiseGMError("330", "Ad");
				}
				if (StringUtils.isBlank("SURNAME")) {
					CreditCardServicesUtil.raiseGMError("330", "Soyad");
				}
				if (StringUtils.isBlank("GENDER")) {
					CreditCardServicesUtil.raiseGMError("330", "Cinsiyet");
				}

				if (StringUtils.isBlank("DELIVERY_ADRESS_CITY")) {
					CreditCardServicesUtil.raiseGMError("330", "�ehir");
				}

				if (StringUtils.isBlank("DELIVERY_ADRESS_DISTRICT")) {
					CreditCardServicesUtil.raiseGMError("330", "�l�e");
				}

				if (StringUtils.isBlank("DELIVERY_ADRESS")) {
					CreditCardServicesUtil.raiseGMError("330", "Adres");
				}

				if (StringUtils.isBlank("DELIVERY_ADRESS_TYPE")) {
					CreditCardServicesUtil.raiseGMError("330", "Teslimat Adres Tipi");
				}

			}

			if ((! (SOURCE_EGOMBL.equals(iMap.getString(SOURCE)) || SOURCE_NKOLAYAPP.equals(iMap.getString(SOURCE)) || SOURCE_MRSMBL.equals(iMap.getString(SOURCE)))) && (StringUtils.isBlank(iMap.getString("CARD_NO")))) {
				CreditCardServicesUtil.raiseGMError("330", "Prepaid Kart No");
			}

			if (StringUtils.isBlank(iMap.getString("BIRTH_DATE"))) {
				CreditCardServicesUtil.raiseGMError("330", "Do�um Tarihi");
			}
		
			
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);

		
		}
		catch (GMRuntimeException e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		
		catch (Exception e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		finally{
			if(session != null){
				session.flush();
			}
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_IS_VALID_OCEAN_REQUEST")
	public static GMMap isValidOceanRequest(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			GMMap sorguMap = new GMMap();

			sorguMap.put("TCKN", iMap.getString("TCKN"));
			sorguMap.put("PASSPORT_NO", iMap.getString("PASSPORT_NO"));
			sorguMap.put("CARD_NO", iMap.getString("CARD_NO"));
			sorguMap.put("DEALER_ID", iMap.getInt("BOX_OFFICE_ID"));
			sorguMap.put("COUNTRY_CODE", iMap.getString("COUNTRY_CODE"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO_FOR_MATCH_TXN", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))){
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
			}
			else{	
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			}
			

		}
		catch (Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}

	
	


	

	


	 
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_MATCH_CARD_CUSTOMER")
	public static GMMap matchCardAndCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = null;
		BigDecimal customerNo = BigDecimal.ZERO;
		
		BigDecimal prepaidAppNo = BigDecimal.ZERO;
		String boxOfficeId = null;
		BigDecimal bankAccountNo = BigDecimal.ZERO;
		String cardNo = StringUtils.EMPTY;
		String customerName = StringUtils.EMPTY;
		boolean isMatchCustomer = false;

		try {
			

			
			
			session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
	   		KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
	   		KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", kkBasvuru.getBasvuruNo())).uniqueResult();
	   			
	   		cardNo = kkBasvuru.getKartNo();

			GnlMusteri customer = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", kkBasvuru.getMusteriNo())).uniqueResult();
			if (customer == null) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "M��teri kayd� bulunamad�");
				return oMap;
			}

			

			customerName = customer.getAdi() + (StringUtils.isEmpty(customer.getIkinciAdi()) ? " " : (" " + customer.getIkinciAdi() + " ")) + customer.getSoyadi();
			customerNo = customer.getMusteriNo();
		
			boxOfficeId = kkBasvuru.getBayiKod();
			prepaidAppNo = iMap.getBigDecimal("BASVURU_NO");
			if (prepaidAppNo == null || prepaidAppNo.compareTo(BigDecimal.ZERO) == 0){
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			}
			

			GMMap paramMap = new GMMap();//bos parametre mapi
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_CURRENT_TIME", paramMap));  // CURRENT_DATE
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_SUBE_KOD", paramMap));  // SUBE_KOD
			
			// match card && customer
			GMMap queryMap = new GMMap();
			iMap.put("MUSTERI_NO", customerNo);
			iMap.put("TCKN",kkBasvuruKimlik.getTcKimlikNo());
			iMap.put("PASSPORT_NO", kkBasvuruKimlik.getPasaportNo());
			iMap.put("COUNTRY_CODE", kkBasvuruKimlik.getUyrukKod());
			iMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			queryMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CARD_CUSTOMER", iMap));
			String custResult = queryMap.getString("ORESULT");
			String custResultDesc = queryMap.getString("RETURN_DESCRIPTION");

			if (!OceanConstants.Ocean_Result_Success.equals(custResult)) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", custResult + "-" + custResultDesc);
				GMMap cancelMap = new GMMap();
				cancelMap.put("APPLICATION_NO", prepaidAppNo);
				GMServiceExecuter.executeAsync("BNSPR_PREPAID_PREPERSO_COMMON_CANCEL_APPLICATION", cancelMap);
				return oMap;
			}

			queryMap.clear();
			queryMap.put("CUSTOMER_NO", customerNo);
			queryMap.put("BANK_ACCOUNT_NO" , "0");
			queryMap.put("CARD_NO", cardNo);
			queryMap.put("NAME", customerName);
			queryMap.put("APPLICATION_NO", prepaidAppNo);
			queryMap.put("BOX_OFFICE_ID", boxOfficeId);
			queryMap.put("TXN_TYPE", "N");
			
			
			KkBasvuruAdres kkBasvuruAdres = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();
			
			if (kkBasvuruAdres == null ){
				if (!( iMap.containsKey(SOURCE) && "EKENT".equals(iMap.getString(SOURCE)))){ 
					// ekent i�in aps bulunamazsa ba�vuruya adres bilgisi yaz�lm�yor, bu durumda hata f�rlatmas�n 
					queryMap.put("CARD_POST_IDX", "OTHER");
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_TESLIMAT_ADRESI_BULUNAMADI_HATASI);
					return oMap;
				}
					
			}
			else{
				if("E".equals(kkBasvuruAdres.getId().getAdresKod())){
					queryMap.put("CARD_POST_IDX", "HOME");
				}
				else if("I".equals(kkBasvuruAdres.getId().getAdresKod())){
					queryMap.put("CARD_POST_IDX", "WORK");
				}
				else if("D".equals(kkBasvuruAdres.getId().getAdresKod())){
					queryMap.put("CARD_POST_IDX", "OTHER");
				}
				else{
					queryMap.put("CARD_POST_IDX", "OTHER");
				}
			}
			
			queryMap.put("CARD_DCI", kkBasvuru.getKartTipi());
			
			try{
				queryMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER", queryMap));
				custResult = queryMap.getString("RETURN_CODE");
				custResultDesc = queryMap.getString("RETURN_DESCRIPTION");

			if (!("Success".equals(custResult) ||  CreditCardServicesUtil.RESPONSE_BASARILI.equals(custResult))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", custResult + "-" + custResultDesc);
				 GMMap cancelMap = new GMMap();
				 cancelMap.put("APPLICATION_NO", prepaidAppNo);
					GMServiceExecuter.executeAsync("BNSPR_PREPAID_PREPERSO_COMMON_CANCEL_APPLICATION", cancelMap);
				return oMap;
			}
				else {
					String kartNo = queryMap.getString(CARD_NO, StringUtils.EMPTY);
					isMatchCustomer = true;
					if (!StringUtils.isEmpty(kartNo)) {
						kkBasvuru.setKartNo(kartNo);
						session.saveOrUpdate(kkBasvuru);
						session.flush();
					}
				}
			}
			catch(Exception e){
				GMMap cancelMap = new GMMap();
				cancelMap.put("CUSTOMER_NO", customerNo);
				cancelMap.put("BANK_ACCOUNT_NO", bankAccountNo);
				cancelMap.put("CARD_NO", cardNo);
				cancelMap.put("NAME", customerName);
				cancelMap.put("APPLICATION_NO", prepaidAppNo);
				cancelMap.put("BOX_OFFICE_ID", boxOfficeId);
				cancelMap.put("TXN_TYPE", "C");
				cancelMap.put("CARD_POST_IDX", "OTHER");
				GMServiceExecuter.executeAsync("BNSPR_PREPAID_PREPERSO_COMMON_CANCEL_APPLICATION", cancelMap);
				GMServiceExecuter.call("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER", cancelMap);
				
			}
			

			session.flush();
			oMap.put("APPLICATION_NO", prepaidAppNo);
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
			oMap.put("RESPONSE_DATA", "M��teri kart e�le�tirme i�lemi ba�ar�yla ger�ekle�tirilmi�tir.");
		}
		catch (Exception e) {
			GMMap cancelMap = new GMMap();
			cancelMap.put("APPLICATION_NO", prepaidAppNo);
			GMServiceExecuter.executeAsync("BNSPR_PREPAID_PREPERSO_COMMON_CANCEL_APPLICATION", cancelMap);
			if (isMatchCustomer) {
				GMMap queryMap = new GMMap();
				queryMap.put("CUSTOMER_NO", customerNo);
				queryMap.put("BANK_ACCOUNT_NO", bankAccountNo);
				queryMap.put("CARD_NO", cardNo);
				queryMap.put("NAME", customerName);
				queryMap.put("APPLICATION_NO", prepaidAppNo);
				queryMap.put("BOX_OFFICE_ID", boxOfficeId);
				queryMap.put("TXN_TYPE", "C");
				queryMap.put("CARD_POST_IDX", "OTHER");
				
				GMServiceExecuter.call("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER", queryMap);

			}

				String message = e.getMessage();
				logger.error(message);
				oMap.put("RESPONSE" , AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", message);
				
			}

		return oMap;
	}

	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CARD_CUSTOMER")
	public static GMMap createCreditCardCustomer(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		String query = null;
		;
		try {
			GMMap oceanCustomerMap = new GMMap();
			
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_kk_basvuru.Get_Customer_Info_For_Ocean(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
		//	stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oceanCustomerMap.putAll(DALUtil.rSetMap(rSet));
			
			
			// todo fill list
			if(iMap.getString("COUNTRY_CODE").equals("TR")){
				
				oceanCustomerMap.put("TCKN" , iMap.getString("TCKN"));
				
				
			}
			
			else{
				oceanCustomerMap.put("PASAPORT_NO" , iMap.getString("PASSPORT_NO"));
			}
			
			
			oceanCustomerMap.put("APPLICATION_NO", iMap.getBigDecimal("BASVURU_NO"));
			logger.debug("BNSPR_OCEAN_CREATE_CUSTOMER INPUT : " + oceanCustomerMap.toString());
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_CUSTOMER", oceanCustomerMap));
			logger.debug("BNSPR_OCEAN_CREATE_CUSTOMER OUTPUT : " + oMap.toString());

			

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CUSTOMER")
	public static GMMap createCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kpsMap = new GMMap();
		GMMap customerContactMap = new GMMap();
		if (iMap.getString("COUNTRY_CODE").equals("TR")) {
			kpsMap = new GMMap();
			kpsMap.put("TCKN", iMap.getString("TCKN"));
			kpsMap.put("TCK_NO", iMap.getString("TCKN"));
			kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
				return oMap;
			}
		
			oMap.put("KPS_MAP",kpsMap);
		}

		try {

			customerContactMap.put("MUSTERI_KONTAKT" , "K");
			customerContactMap.put("UYRUK_KOD", iMap.getString("COUNTRY_CODE"));
			customerContactMap.put("UYRUK", iMap.getString("COUNTRY_CODE"));
			customerContactMap.put("EMAIL_KISISEL", iMap.getString("EMAIL"));
			customerContactMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			customerContactMap.put("ANNE_KIZLIK_SOYADI", kpsMap.getString("ANNE_KIZLIK_SOYADI"));
			customerContactMap.put("ANNE_ADI", kpsMap.getString("ANNE_AD"));
			customerContactMap.put("BABA_ADI", kpsMap.getString("BABA_AD"));
			customerContactMap.put("VERILDIGI_TARIH", kpsMap.getString("VERILIS_TARIHI"));
			customerContactMap.put("MEDENI_HAL_KOD", ("2").equals(kpsMap.getString("MEDENI_HALI_KOD")) ? "1" : "2");
			customerContactMap.put("SIRA_NO", kpsMap.getString("KIMLIK_SIRA_NO"));
			customerContactMap.put("IL_KOD", kpsMap.getString("IL_KODU"));
			customerContactMap.put("ILCE_KOD", kpsMap.getString("ILCE_KODU"));
			customerContactMap.put("CILT_NO", kpsMap.getString("CILT_KODU"));
			customerContactMap.put("NUFUS_CUZDANI_SERI_NO", kpsMap.getString("KIMLIK_SERI_NO"));
			
			String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
		
			if (BAYI_KANAL.equals(kanalKodu)){
				customerContactMap.put("BAGLI_KANAL_KOD"  , iMap.getString("BOX_OFFICE_ID"));
				customerContactMap.put("KANAL_KODU", iMap.getString("BOX_OFFICE_ID"));
			}
			else{
				customerContactMap.put("BAGLI_KANAL_KOD"  , "");
				customerContactMap.put("KANAL_KODU", "");
			}
			customerContactMap.put("BAGLI_KANAL_GRUBU", kanalKodu);	
			
			customerContactMap.put("KAZANIM_KANALI", kanalKodu);
			customerContactMap.put("MUSTERIYI_KAZANDIRAN", "514");

			
			customerContactMap.put("KAYNAK",  iMap.getString(SOURCE));
		//	customerContactMap.put("TUR", "TFFKART");
			
			customerContactMap.put("ADK_MUSTERISIMI", "H");
			customerContactMap.put(SOURCE,  iMap.getString(SOURCE));
		
			customerContactMap.put("PROFIL_KOD", "1");
			customerContactMap.put("MUSTERI_GRUP_KOD", "1");
			customerContactMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
			customerContactMap.put("BOLUM_KODU", "444");

			String kazanimUrun = StringUtils.EMPTY;
			String portfoyKod = StringUtils.EMPTY;
			try {
				kazanimUrun = SOURCE_KAZANIM_URUNU.getBySource(iMap.getString(SOURCE)).getUrun();
				portfoyKod = SOURCE_KAZANIM_URUNU.getBySource(iMap.getString(SOURCE)).getPortfoyKod();
			}
			catch (Exception e) {
			}
			customerContactMap.put("KAZANIM_URUNU", kazanimUrun);
			customerContactMap.put("PORTFOY_KOD", portfoyKod);

			customerContactMap.put("YERLESIM_KOD", "I");
			customerContactMap.put("HESAP_UCRETI_F", "H");
			
			if(!StringUtils.isEmpty(iMap.getString("WORKING_STATUS"))){
				customerContactMap.put("CALISMA_SEKLI", iMap.getString("WORKING_STATUS"));
			}
			if(!StringUtils.isEmpty(iMap.getString("JOB_INFO"))){
				customerContactMap.put("MESLEK_KOD", iMap.getString("JOB_INFO"));
			}
			
			
			if (iMap.getString("PHONE_COUNTRY_CODE") != null && iMap.getString("PHONE_OPERATOR_CODE") != null && iMap.getString("PHONE_NUMBER") != null) {
				GMMap telefonCepMap = new GMMap();
				
				
				telefonCepMap.put("TEL_TIP", "3");
            	telefonCepMap.put("ULKE_KODU",iMap.getString("PHONE_COUNTRY_CODE"));
            	telefonCepMap.put("ALAN_KOD", iMap.getString("PHONE_OPERATOR_CODE"));
            	telefonCepMap.put("TEL_NO",   iMap.getString("PHONE_NUMBER"));
            	telefonCepMap.put("OTPMI", true);
            	telefonCepMap.put("F_ILETISIM", "E");
            	
            	customerContactMap.put("TELEFON_LIST", 0, telefonCepMap);
				
			}
			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
				customerContactMap.putAll(kpsMap);
				customerContactMap.put("NUFUS_CUZDANI_SERI_NO", kpsMap.getString("KIMLIK_SERI_NO"));
				customerContactMap.put("CINSIYET_KOD", kpsMap.getString("CINSIYET"));
				customerContactMap.put("SOYADI", kpsMap.getString("SOYAD"));
				customerContactMap.put("ISIM" , kpsMap.getString("AD1"));
				customerContactMap.put("IKINCI_ISIM" , kpsMap.getString("AD2"));
				
				customerContactMap.put("F_KPS", "E");
				customerContactMap.put("KPS_TARIH", iMap.getDate("SORGU_TARIHI"));
				customerContactMap.put("TC_KIMLIK_NO",iMap.getString("TCKN"));
				
				GMMap adresSorguMap = new GMMap();
				adresSorguMap.put("TC_KIMLIK_NO",iMap.getString("TCKN"));
				adresSorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				adresSorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", adresSorguMap));
				
				
				boolean apsYapildi = true; 
				if("E".equals(adresSorguMap.getString("APS_YAPILDIMI"))){
					
						customerContactMap.putAll(adresSorguMap);
						adresSorguMap.putAll(getApsAcikAdres(adresSorguMap));
						if(StringUtils.isEmpty(adresSorguMap.getString("ACIK_ADRES"))
								||StringUtils.isEmpty(adresSorguMap.getString("IL_KODU"))
								||StringUtils.isEmpty(adresSorguMap.getString("ILCE_KODU"))
								){
							apsYapildi = false;
							/*oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.APS_YAPILAMADI);
							return oMap;*/
						}
						else{
							GMMap adresMap = new GMMap();
							adresMap.put("ADRES_KOD", "A");
			                adresMap.put("ADRES", adresSorguMap.getString("ACIK_ADRES"));
			                adresMap.put("EXTRE_ADRES_KOD_F", "E");
			                adresMap.put("ULKE_KOD", "TR");
			                adresMap.put("ADRES_IL_KOD", adresSorguMap.getString("IL_KODU"));
			                adresMap.put("ADRES_ILCE_KOD", adresSorguMap.getString("ILCE_KODU"));
			                
			                customerContactMap.put("ADRES_LIST", 0, adresMap);
						
			                oMap.put("ADRES_SORGU_MAP", adresSorguMap);
						}
			            
				}
				
				else{
					apsYapildi = false;
					/*oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.APS_YAPILAMADI);
					return oMap;*/
					
				}
			
				if (!apsYapildi){
					if (!(iMap.containsKey("SKIP_APS") && iMap.getBoolean("SKIP_APS"))){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.APS_YAPILAMADI);
						return oMap;
					}
				}
			}
			else {
				customerContactMap.put("PASAPORT_NO", StringUtils.deleteWhitespace(iMap.getString("PASSPORT_NO")));
				customerContactMap.put("AD1", iMap.getString("NAME"));
				customerContactMap.put("AD2", iMap.getString("SECOND_NAME"));
				customerContactMap.put("SOYAD", iMap.getString("SURNAME"));
				customerContactMap.put("ISIM" , iMap.getString("NAME"));
				customerContactMap.put("IKINCI_ISIM" , iMap.getString("SECOND_NAME"));
				customerContactMap.put("SOYADI" , iMap.getString("SURNAME"));
				customerContactMap.put("DOGUM_TARIHI", iMap.getString("BIRTH_DATE"));
				customerContactMap.put("CINSIYET_KOD", iMap.getString("GENDER"));
				
				// todo yabanci musteri icin adres
				
				
				GMMap adresMap = new GMMap();
				
				if("D".equals(iMap.getString("DELIVERY_ADRESS_TYPE"))){
					adresMap.put("ADRES_KOD", "W");
				}
				else{
					adresMap.put("ADRES_KOD", iMap.getString("DELIVERY_ADRESS_TYPE"));
				}
				
				
                adresMap.put("ADRES", iMap.getString("DELIVERY_ADRESS"));
                adresMap.put("EXTRE_ADRES_KOD_F", "E");
                adresMap.put("ULKE_KOD", iMap.getString("COUNTRY_CODE"));
                adresMap.put("ADRES_IL_KOD", iMap.getString("DELIVERY_ADRESS_CITY"));
                adresMap.put("ADRES_ILCE_KOD", iMap.getString("DELIVERY_ADRESS_DISTRICT"));
                
                
                customerContactMap.put("ADRES_LIST", 0, adresMap);

			}
 
			GMMap tMap = new GMMap();
			
			// todo execute NT
			 tMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_CREATE_GERCEK_MUSTERI", customerContactMap));
			if (tMap.getBigDecimal("MUSTERI_NO").compareTo(BigDecimal.ZERO) > 0) {
				BigDecimal musteriNo = tMap.getBigDecimal("MUSTERI_NO");
				oMap.put("MUSTERI_NO", musteriNo);
				oMap.put("RESPONSE" , TffServicesMessages.RESPONSE_BASARILI);
				
				

			}
			else {
				String mailFrom = "system@aktifbank.com.tr";
				String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
				String mailSubject = "TFF MUSTERI YARATMA HATA";
				String mailBody = "hata alan kimlik bilgileri:";
				mailBody += "<br>" + "Uyruk:" + iMap.getString("UYRUK");
				if ("TR".equals(iMap.getString("UYRUK"))) {
					mailBody += "<br>" + "Tckn:" + iMap.getString("TCKN");
				}
				else {
					mailBody += "<br>" + "Pasaport No:" + iMap.getString("PASSPORT_NO");
				}
				mailBody += "<br>" + "Ad:" + iMap.getString("NAME");
				mailBody += "<br>" + "Soyad:" + iMap.getString("SURNAME");
				mailBody += "<br>" + "MAP:" + customerContactMap.toString();
				sendMail(mailFrom, mailToParametre, mailSubject, mailBody);

				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
				logger.error("---------- createMember : uye tablosuna yazarken hata olustu");
				return oMap;

			}
		}
		catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF MUSTERI YARATMA HATA";
			String mailBody = "hata alan kimlik bilgileri:";
			mailBody += "<br>" + "Uyruk:" + iMap.getString("UYRUK");
			if ("TR".equals(iMap.getString("UYRUK"))) {
				mailBody += "<br>" + "Tckn:" + iMap.getString("TCKN");
			}
			else {
				mailBody += "<br>" + "Pasaport No:" + iMap.getString("PASSPORT_NO");
			}
			mailBody += "<br>" + "Ad:" + iMap.getString("NAME");
			mailBody += "<br>" + "Soyad:" + iMap.getString("SURNAME");

			sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
			return oMap;
		}
		
		return oMap;

	}
	
	
	private static GMMap getApsAcikAdres(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder adres = new StringBuilder();
		String ayrac = " ";
		
	    if(!"0".equals(iMap.getString("ADRES_NO")) && iMap.getString("YABANCI_ULKE_KOD") == null) {
	    	//Acik adres
	    	if (StringUtils.isNotBlank(iMap.getString("BUCAK"))) {
	    		adres.append(iMap.getString("BUCAK")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("KOY"))) {
	    		adres.append(iMap.getString("KOY")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("MAHALLE"))) {
	    		adres.append(iMap.getString("MAHALLE")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("CSBM"))) {
	    		adres.append(iMap.getString("CSBM")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("DIS_KAPI_NO"))) {
	    		adres.append("NO:").append(iMap.getString("DIS_KAPI_NO")).append(ayrac);
	    	}
	    	if (StringUtils.isNotBlank(iMap.getString("IC_KAPI_NO"))) {
	    		adres.append("DAIRE:").append(iMap.getString("IC_KAPI_NO"));
	    	}
	    	oMap.put("ACIK_ADRES", adres.toString().trim());
	    	//il kodu
	    	String ilKodu = iMap.getString("IL_KODU");
	    	if (StringUtils.isNotBlank(ilKodu)) {
	    		ilKodu = StringUtils.leftPad(ilKodu, 3, "0");
	    	}
	    	oMap.put("IL_KODU", ilKodu);
	    	//Ilce Kodu
	    	oMap.put("ILCE_KODU", iMap.getBigDecimal("ILCE_KODU"));
	    }
	    
	    return oMap;
	}
	
	
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER_APS_ADRESS")
	public static GMMap updateCustomerApsAdress(GMMap iMap) {
	
	GMMap oMap = new GMMap();	
	GMMap adresSorguMap = new GMMap();
	adresSorguMap.put("TC_KIMLIK_NO",iMap.getString("TCKN"));
	adresSorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
	adresSorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", adresSorguMap));
	boolean apsYapildi = true;
	
	if(!"E".equals(adresSorguMap.getString("APS_YAPILDIMI"))){
		apsYapildi = false;
	}
	
	adresSorguMap.putAll(getApsAcikAdres(adresSorguMap));
	
	if(StringUtils.isEmpty(adresSorguMap.getString("ACIK_ADRES"))
			||StringUtils.isEmpty(adresSorguMap.getString("IL_KODU"))
			||StringUtils.isEmpty(adresSorguMap.getString("ILCE_KODU"))
			){
		apsYapildi = false;
	}
	
	if (!apsYapildi){
		if (!(iMap.containsKey("SKIP_APS") && iMap.getBoolean("SKIP_APS"))){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.APS_YAPILAMADI);
			return oMap;
		}
	}
	 
     Connection conn = null;
     CallableStatement stmt = null;
     try {
       

         conn = DALUtil.getGMConnection();

         stmt = conn.prepareCall("{call PKG_TRN3871.save_aps_bilgileri(?,?)}");
         int i = 1;
         stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
         stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
         
        
         stmt.execute();
         oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
       
         return oMap;
     } catch (Exception e) {
         throw ExceptionHandler.convertException(e);
     } finally {
         GMServerDatasource.close(stmt);
         GMServerDatasource.close(conn);
     }
	
	
	
	
	}
	
	
	
	@GraymoundService("BNSPR_KK_COMMON_GET_APPLICATION_SUMMARY_INFO")
	public static GMMap getKkApplicationSummaryInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		String RESULT_TABLE = "RESULT_TABLE";
		String APPLICATION_SUMMARY_INFO = "APPLICATION_SUMMARY_INFO";
		String basimAcikIptalMi = iMap.getString("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR);

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String query = null;
		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", "Gecersiz kanal tipi");
				return oMap;
			}
			
			String applicationStartDate = iMap.getString("APPLICATION_START_DATE");
			String applicationEndDate = iMap.getString("APPLICATION_END_DATE");
		
			if(applicationStartDate != null){
				applicationStartDate = applicationStartDate.trim();
			}
			
			if(applicationEndDate != null){
				applicationEndDate = applicationEndDate.trim();
			}
			
			
			

			conn = DALUtil.getGMConnection();
			query = "{call PKG_KK_BASVURU.listBasvuruOzetBilgi(?,?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);

			
			stmt.setString(1, iMap.getString("TCKN"));
			stmt.setString(2, iMap.getString("PASSPORT_NO"));
			stmt.setString(3, iMap.getString("APPLICATION_NO"));
			stmt.setString(4, applicationStartDate);
			stmt.setString(5, applicationEndDate);
			stmt.setString(6, iMap.getString("BASVURU_URUN_ADI"));
			stmt.registerOutParameter(7, -10);
			stmt.registerOutParameter(8, Types.CHAR);
			stmt.registerOutParameter(9, Types.CHAR);
			stmt.registerOutParameter(10, Types.CHAR);
			stmt.registerOutParameter(11, Types.CHAR);
			stmt.registerOutParameter(12, Types.CHAR);
			

			stmt.execute();
			String ad = stmt.getString(10);
								
			if(StringUtils.isEmpty(ad)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OZET_BILGI_KAYIT_BULUNAMADI);
				return oMap;
			}
			rSet = (ResultSet) stmt.getObject(7);
			GMMap resultMap = DALUtil.rSetResults(rSet, RESULT_TABLE);

			if (resultMap == null || resultMap.isEmpty() || resultMap.getSize(RESULT_TABLE) == 0) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OZET_BILGI_KAYIT_BULUNAMADI);
				return oMap;
			}
			
			oMap.put("TCKN", stmt.getString(8));
			oMap.put("PASSPORT_NO" , stmt.getString(9));
			oMap.put("NAME", ad);
			oMap.put("SECOND_NAME", stmt.getString(11));
			oMap.put("SURNAME", stmt.getString(12));
			

			
			

			for (int i = 0; i < resultMap.getSize(RESULT_TABLE); i++) {
				String kartNo = resultMap.getString(RESULT_TABLE, i, "KART_NO");
				String kuryeTipi = resultMap.getString(RESULT_TABLE, i, "KURYE_TIPI");
				String durumKod = resultMap.getString(RESULT_TABLE, i, "DURUM_KOD");
				String source = resultMap.getString(RESULT_TABLE, i, SOURCE);
				
				oMap.put(APPLICATION_SUMMARY_INFO, i, "APPLICATION_NO", resultMap.getBigDecimal(RESULT_TABLE, i, "BASVURU_NO"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "APPLICATION_STATUS", durumKod);
				oMap.put(APPLICATION_SUMMARY_INFO, i, "PRODUCT_ID", resultMap.getString(RESULT_TABLE, i, "KART_URUN_ID"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "LOGO_CODE", resultMap.getString(RESULT_TABLE, i, "LOGO_KODU"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "CARD_DCI", getCardDciByKartTipi(resultMap.getString(RESULT_TABLE, i, "KART_TIPI")));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "APPLICATION_DATE", resultMap.getString(RESULT_TABLE, i, "BASVURU_TARIH"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "BOX_OFFICE_ID", resultMap.getString(RESULT_TABLE, i, "BAYI_KOD"));
				
				oMap.put(APPLICATION_SUMMARY_INFO, i, SOURCE, source);
				
				boolean isReversible = basvuruIptalEdilebilirMi(durumKod, kuryeTipi, kartNo, source, basimAcikIptalMi);
				oMap.put(APPLICATION_SUMMARY_INFO, i, "IS_REVERSIBLE", isReversible);
				if (!isReversible) {
					GMMap messageMap = new GMMap();
					messageMap.put("MESSAGE_NO", 50008);
					messageMap.put("P1", resultMap.getString(RESULT_TABLE, i, "DURUM_KOD_TEXT"));
					String reasonDef = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE");
					oMap.put(APPLICATION_SUMMARY_INFO, i, "IRREVERSIBLE_REASON", reasonDef);
				}
				
				if(CreditCardServicesUtil.EVET.equals(iMap.getString("CARD_DETAIL"))  && !StringUtils.isEmpty(kartNo)){
				
					oMap.put(APPLICATION_SUMMARY_INFO, i, "CARD_NO", kartNo);
					
					GMMap oceanResponseInpMap = new GMMap();
					GMMap oceanResponseOutMap = new GMMap();
					oceanResponseInpMap.put("CARD_NO", kartNo);
					oceanResponseOutMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", oceanResponseInpMap));
					if (oceanResponseOutMap.getInt("RETURN_CODE") == 2){
							
						    
						    oMap.put(APPLICATION_SUMMARY_INFO, i, "CARD_STAT_CODE", oceanResponseOutMap.getString("CARD_DETAIL_INFO", 0, "CARD_STAT_CODE"));
							oMap.put(APPLICATION_SUMMARY_INFO, i, "CARD_SUB_STAT_CODE", oceanResponseOutMap.getString("CARD_DETAIL_INFO", 0, "CARD_SUB_STAT_CODE"));
							oMap.put(APPLICATION_SUMMARY_INFO, i, "CARD_STAT_DESC", oceanResponseOutMap.getString("CARD_DETAIL_INFO", 0, "CARD_STAT_DESC"));
							oMap.put(APPLICATION_SUMMARY_INFO, i, "IS_RENEWAL", "");
				    }
				}
			}
			
			

			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

		return oMap;
	}
	
	
	
	


	private static String getCardDciByKartTipi(String kartTipi) {

		if ("D".equals(kartTipi)) {
			return OceanConstants.Akustik_DebitCard;
		}

		else if ("P".equals(kartTipi)) {
			return OceanConstants.Akustik_PrepaidCard;
		}

		else if ("KK".equals(kartTipi)) {
			return OceanConstants.Akustik_CreditCard;
		}
		else {
			return kartTipi;
		}
	}
	
	private static boolean basvuruIptalEdilebilirMi(KkBasvuru basvuru , String basimAcikIptalMi){
		return basvuruIptalEdilebilirMi(basvuru.getDurumKod(), basvuru.getKuryeTipi(),basvuru.getKartNo() ,basvuru.getSource() , basimAcikIptalMi);
	}
	
	private static boolean basvuruIptalEdilebilirMi(String durumKod , String kuryeTipi , String kartNo , String source , String basimAcikIptalMi){
	  boolean iptalEdilebilir = true;
		if (!"BASVURU".equals(durumKod) && !"FOTO".equals(durumKod) && !"ODEME".equals(durumKod) && !"ODEME_BEKLE".equals(durumKod) && !"ODEME_BASARISIZ".equals(durumKod)) {
			if ("BASIM".equals(durumKod)) {
				if (CreditCardServicesUtil.HAYIR.equals(basimAcikIptalMi)) {
					if (!("NTS01".equals(source) && StringUtils.isEmpty(kartNo) && "A".equals(kuryeTipi))) {
						iptalEdilebilir = false;
					}

				}
			}
			else if ("ACIK".equals(durumKod)) {
				if (CreditCardServicesUtil.HAYIR.equals(basimAcikIptalMi)){
					iptalEdilebilir = false;
				}

			}
			else {
				iptalEdilebilir = false;
			}

		}
	  
	  return iptalEdilebilir ;
	}
	
	@GraymoundService("BNSPR_KK_COMMON_CONVERT_RESPONSE_DATA_BY_SOURCE")
	public static GMMap convertResponseDataBySource(GMMap iMap) {
		
		String messageCode = null ;
		String source = iMap.getString(SOURCE);
		 
		GMMap oMap  = new GMMap();
		if(!StringUtils.isEmpty(source) && !StringUtils.isEmpty(iMap.getString("RESPONSE_DATA"))){
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		    Criteria criteria = session.createCriteria(GnlParamText.class)
		    										.add(Restrictions.eq("kod", "KK_SERVIS_SONUC_MESAJ"))
		    										.add(Restrictions.eq("key1", source))
		    										.add(Restrictions.eq("key2", iMap.getString("RESPONSE_DATA")));
			GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
			if(gnlParamText != null && !StringUtils.isEmpty(gnlParamText.getKey3())){
				messageCode =  gnlParamText.getKey3() ; 
			}
			session.flush();				
			
		}
		
		if(!StringUtils.isEmpty(messageCode)){
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", messageCode);
			String messageText = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE");
			if(!StringUtils.isEmpty(messageText)){
				oMap.put("RESPONSE_DATA", messageText);
			}
			
		}
		
		return oMap;
		
	}
	
	
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER")
	public static GMMap updateCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kpsMap = new GMMap();
		GMMap customerContactMap = new GMMap();
		if (iMap.getString("COUNTRY_CODE").equals("TR")) {
			kpsMap = new GMMap();
			kpsMap.put("TCKN", iMap.getString("TCKN"));
			kpsMap.put("TCK_NO", iMap.getString("TCKN"));
			kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
				return oMap;
			}
		
			oMap.put("KPS_MAP",kpsMap);
		}

		try {

			//customerContactMap.put("MUSTERI_KONTAKT" , "K");
			customerContactMap.put("UYRUK_KOD", iMap.getString("COUNTRY_CODE"));
			customerContactMap.put("UYRUK", iMap.getString("COUNTRY_CODE"));
			customerContactMap.put("EMAIL_KISISEL", iMap.getString("EMAIL"));
			customerContactMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			customerContactMap.put("ANNE_KIZLIK_SOYADI", kpsMap.getString("ANNE_KIZLIK_SOYADI"));
			
			
			String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
			
			if (BAYI_KANAL.equals(kanalKodu)){
				customerContactMap.put("BAGLI_KANAL_KOD"  , iMap.getString("BOX_OFFICE_ID"));
				customerContactMap.put("KANAL_KODU", iMap.getString("BOX_OFFICE_ID"));
			}
			else{
				customerContactMap.put("BAGLI_KANAL_KOD"  , "");
				customerContactMap.put("KANAL_KODU", "");
			}
			customerContactMap.put("BAGLI_KANAL_GRUBU", kanalKodu);	
			
			//customerContactMap.put("KAZANIM_KANALI", kanalKodu);
			//customerContactMap.put("MUSTERIYI_KAZANDIRAN", "514");

			customerContactMap.put("KAYNAK",  iMap.getString(SOURCE));
		//	customerContactMap.put("TUR", "TFFKART");
			
			customerContactMap.put("ADK_MUSTERISIMI", "H");
			customerContactMap.put(SOURCE,  iMap.getString(SOURCE));
		
			customerContactMap.put("PROFIL_KOD", "1");
			customerContactMap.put("MUSTERI_GRUP_KOD", "1");
			customerContactMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
			customerContactMap.put("BOLUM_KODU", "444");
			customerContactMap.put("KAZANIM_URUNU", SOURCE_KAZANIM_URUNU.getBySource(iMap.getString(SOURCE)).getUrun());
			customerContactMap.put("PORTFOY_KOD", SOURCE_KAZANIM_URUNU.getBySource(iMap.getString(SOURCE)).getPortfoyKod());
			
			customerContactMap.put("YERLESIM_KOD", "I");
			customerContactMap.put("HESAP_UCRETI_F", "H");
			
			
			if (iMap.getString("PHONE_COUNTRY_CODE") != null && iMap.getString("PHONE_OPERATOR_CODE") != null && iMap.getString("PHONE_NUMBER") != null) {
				GMMap telefonCepMap = new GMMap();
				
				
				telefonCepMap.put("TEL_TIP", "3");
            	telefonCepMap.put("ULKE_KODU",iMap.getString("PHONE_COUNTRY_CODE"));
            	telefonCepMap.put("ALAN_KOD", iMap.getString("PHONE_OPERATOR_CODE"));
            	telefonCepMap.put("TEL_NO",   iMap.getString("PHONE_NUMBER"));
            	telefonCepMap.put("OTPMI", true);
            	telefonCepMap.put("F_ILETISIM", "E");
            	
            	customerContactMap.put("TELEFON_LIST", 0, telefonCepMap);
				
			}
			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
				customerContactMap.putAll(kpsMap);
				customerContactMap.put("CINSIYET_KOD", kpsMap.getString("CINSIYET"));
				customerContactMap.put("SOYADI", kpsMap.getString("SOYAD"));
				customerContactMap.put("ISIM" , kpsMap.getString("AD1"));
				customerContactMap.put("IKINCI_ISIM" , kpsMap.getString("AD2"));
				
				customerContactMap.put("F_KPS", "E");
				customerContactMap.put("KPS_TARIH", iMap.getDate("SORGU_TARIHI"));
				customerContactMap.put("TC_KIMLIK_NO",iMap.getString("TCKN"));
				
				GMMap adresSorguMap = new GMMap();
				adresSorguMap.put("TC_KIMLIK_NO",iMap.getString("TCKN"));
				adresSorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				adresSorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", adresSorguMap));
								
				
				if("E".equals(adresSorguMap.getString("APS_YAPILDIMI"))){
					
						customerContactMap.putAll(adresSorguMap);
						adresSorguMap.putAll(getApsAcikAdres(adresSorguMap));
						if(StringUtils.isEmpty(adresSorguMap.getString("ACIK_ADRES"))
								||StringUtils.isEmpty(adresSorguMap.getString("IL_KODU"))
								||StringUtils.isEmpty(adresSorguMap.getString("ILCE_KODU"))
								){
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.APS_YAPILAMADI);
							return oMap;
						}
						
						
						
						GMMap adresMap = new GMMap();
						adresMap.put("ADRES_KOD", "A");
		                adresMap.put("ADRES", adresSorguMap.getString("ACIK_ADRES"));
		                adresMap.put("EXTRE_ADRES_KOD_F", "E");
		                adresMap.put("ULKE_KOD", "TR");
		                adresMap.put("ADRES_IL_KOD", adresSorguMap.getString("IL_KODU"));
		                adresMap.put("ADRES_ILCE_KOD", adresSorguMap.getString("ILCE_KODU"));
		                
		                
		                customerContactMap.put("ADRES_LIST", 0, adresMap);
					
					
					   oMap.put("ADRES_SORGU_MAP", adresSorguMap);
			            
				}
				
				else{
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
					return oMap;
				}

			}
			else {
				customerContactMap.put("PASAPORT_NO", StringUtils.deleteWhitespace(iMap.getString("PASSPORT_NO")));
				customerContactMap.put("AD1", iMap.getString("NAME"));
				customerContactMap.put("AD2", iMap.getString("SECOND_NAME"));
				customerContactMap.put("SOYAD", iMap.getString("SURNAME"));
				customerContactMap.put("ISIM" , iMap.getString("NAME"));
				customerContactMap.put("IKINCI_ISIM" , iMap.getString("SECOND_NAME"));
				customerContactMap.put("SOYADI" , iMap.getString("SURNAME"));
				customerContactMap.put("DOGUM_TARIHI", iMap.getString("BIRTH_DATE"));
				customerContactMap.put("CINSIYET_KOD", iMap.getString("GENDER"));
				
				// todo yabanci musteri icin adres
				
				
				GMMap adresMap = new GMMap();
				
				if("D".equals(iMap.getString("DELIVERY_ADRESS_TYPE"))){
					adresMap.put("ADRES_KOD", "W");
				}
				else{
					adresMap.put("ADRES_KOD", iMap.getString("DELIVERY_ADRESS_TYPE"));
				}
				
				
                adresMap.put("ADRES", iMap.getString("DELIVERY_ADRESS"));
                adresMap.put("EXTRE_ADRES_KOD_F", "E");
                adresMap.put("ULKE_KOD", iMap.getString("COUNTRY_CODE"));
                adresMap.put("ADRES_IL_KOD", iMap.getString("DELIVERY_ADRESS_CITY"));
                adresMap.put("ADRES_ILCE_KOD", iMap.getString("DELIVERY_ADRESS_DISTRICT"));
                
                
                customerContactMap.put("ADRES_LIST", 0, adresMap);

			}
 
			if(!StringUtils.isEmpty(iMap.getString("JOB_INFO"))){
				customerContactMap.put("MESLEK_KOD", iMap.getString("JOB_INFO"));
			}
			if(!StringUtils.isEmpty(iMap.getString("WORKING_STATUS"))){
				customerContactMap.put("CALISMA_SEKLI", iMap.getString("WORKING_STATUS"));
			}
			
			
			GMMap tMap = new GMMap();
			
			// todo execute NT
			try{
			 customerContactMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			 tMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerContactMap));
			 
			}
			catch(Exception e )
			{
				oMap.put("RESPONSE_DESC", e.toString());
				 
				 oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				 return oMap;
			}
			 
			 oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			 return oMap;
			 
		}
		catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF BASVURUDAN MUSTERI GUNCELLEME HATA";
			String mailBody = "hata alan BASVURU bilgileri:";
			mailBody += "BASVURU NO:" + iMap.getString("TFF_BASVURU_NO");
			mailBody += ":  " + e.getMessage();
			mailBody += ":  " + getTraceAsString(e);
			mailBody += "customerContactMap :  " + customerContactMap.toString();
			mailBody += "iMap :  " + iMap.toString();
			sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
			return oMap;
		}
		
		

	}
	
	@GraymoundService("BNSPR_PREPAID_APPLICATION_PHONE_CONTROL")
	public static GMMap controlApplicationPhone(GMMap iMap) {
	GMMap oMap = new GMMap();
	Connection conn = null;
	CallableStatement stmt = null;
	oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
	//telefon kontrolleri
		try{
			conn = DALUtil.getGMConnection();
			
			if (iMap.containsKey(SOURCE) && (SOURCE_EGOMBL.equals(iMap.getString(SOURCE)) || SOURCE_MRSMBL.equals(iMap.getString(SOURCE)) )){
				
				stmt = conn.prepareCall("{call pkg_kk_basvuru.kontrolHCEBasvuruTelefon(?, ?, ?, ?, ?, ?)}");
			}
			else if (iMap.containsKey(SOURCE) && SOURCE_NKOLAYAPP.equals(iMap.getString(SOURCE,""))){
				
				stmt = conn.prepareCall("{call pkg_kk_basvuru.kontrolNkolayBasvuruTelefon(?, ?, ?, ?, ?, ?)}");
			}
			else{
				stmt = conn.prepareCall("{call pkg_kk_basvuru.kontrolPPBasvuruTelefon(?, ?, ?, ?, ?, ?)}");
			}
				int pc = 1;
				stmt.setString(pc++, iMap.getString("CUSTOMER_NO"));
				stmt.setString(pc++, iMap.getString("PHONE_COUNTRY_CODE"));
				stmt.setString(pc++, iMap.getString("PHONE_OPERATOR_CODE"));
				stmt.setString(pc++, iMap.getString("PHONE_NUMBER"));
				stmt.registerOutParameter(pc++, Types.VARCHAR);
				stmt.registerOutParameter(pc++, Types.VARCHAR);
				
				stmt.execute();
								
				if(stmt.getString(5) != null){
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", stmt.getString(5));
					if (!StringUtils.isEmpty(stmt.getString(6))){
						oMap.put("OTP_PHONE_NUMBER", stmt.getString(6));
					}
					return oMap;
				}
		}
		catch(Exception e){
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		finally{
			if (conn != null) {
				try {
					conn.close();
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	return oMap;
	}
	
	
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_CANCEL_APPLICATION")
	public static GMMap cancelApplication(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
		
		if(basvuruNo == null || basvuruNo.intValue() == 0){
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", "Ba�vuru no alan� bo�");
			return oMap;
		}

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, basvuruNo);
			if (kkBasvuru == null) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", "Ba�vuru bulunamad�");
				return oMap;
			}
			
			

			sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
			sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
			sorguMap.put("ISLEM_KOD", "SS");
			if (StringUtils.isEmpty(iMap.getString("TXN_CODE"))) {
				sorguMap.put("GEREKCE_KOD", "1");// kanal talebi
			}
			else {
				sorguMap.put("GEREKCE_KOD", iMap.getString("TXN_CODE"));
			}
			if (StringUtils.isEmpty(iMap.getString("TXN_DESC"))) {
				sorguMap.put("ACIKLAMA", "Kart iptal talebi");// kanal talebi
			}
			else {
				sorguMap.put("ACIKLAMA", iMap.getString("TXN_DESC"));
			}

			sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}
	

	public static String tcknKontrol(String tcKimlikNo) {

		try {
			//TCKN validasyon
			//Zorunluluk kontrolu
			if (StringUtils.isBlank(tcKimlikNo)) {
				return TffServicesMessages.TCKN_KONTROL_KARAKTER_SAYISI_HATASI;
				//CreditCardServicesUtil.raiseGMError("330", "Tc Kimlik No");
			}
			//Uzunluk kontrolu
			if (tcKimlikNo.length() != 11) {
				return TffServicesMessages.TCKN_KONTROL_KARAKTER_SAYISI_HATASI;
				//CreditCardServicesUtil.raiseGMError("2328");
			}
			//Format kontrolu - Yabanci mi
			if ("9".equals(tcKimlikNo.substring(0, 1))) {
				return TffServicesMessages.YABANCI_UYRUKLU_TCKN_GIRILEMEZ;
				//CreditCardServicesUtil.raiseGMError("1033");
			}
			//Format kontrolu - Digit
			GMMap sorguMap = new GMMap();
			sorguMap.put("TC_KIMLIK_NO", tcKimlikNo);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", sorguMap));
			if ("0".equals(sorguMap.getString("SONUC"))) {
				return TffServicesMessages.TCKN_KONTROL_CHECK_DIGIT_HATASI;
				//CreditCardServicesUtil.raiseGMError("456", tcKimlikNo);
			}
			
			return "";
		}
		catch (Exception e) {
			return e.getMessage();
		}

	}
}
