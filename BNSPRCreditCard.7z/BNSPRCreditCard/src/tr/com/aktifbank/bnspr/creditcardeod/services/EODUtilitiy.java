package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.GnlSifre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.zehon.sftp.SFTPClient;

public class EODUtilitiy {
	public static GMMap getLineFromFTM(long start, long end, BigDecimal ftmTransferId) {
		
		 String fetchQuery = String.format("SELECT ffc.line_number,ffc.line FROM ftm.ftm_file_content ffc " +
								 		"WHERE ffc.ftm_process_oid=%s AND ffc.line_number >= %s and ffc.line_number <= %s " +
								 		"order by ffc.line_number",
				 ftmTransferId, start, end);
			final String tableName = "FILE_LINE";
		
		return  DALUtil.getResults(fetchQuery, tableName);
	}
	
	public static GMMap getFileNameFromFTM(BigDecimal ftmTransferId) {
		String fetchQuery = String.format("SELECT p.oid, p.ftm_file_definition_oid line, p.file_name " +
		 								   "FROM ftm.ftm_process p " +
								 		   "WHERE p.oid = %s ", ftmTransferId);
		final String tableName = "FILE_LIST";
		
		return  DALUtil.getResults(fetchQuery, tableName);
	}

	public static Hashtable<String, String> getCurrencyCodes() {
		GMMap output = DALUtil.getResults("select kod,ocean_kod from bnspr.gnl_doviz_kod_pr where ocean_kod is not null", "CURRENCY");
		
		Hashtable<String, String> crHs = new Hashtable<String, String>();
		int s = output.getSize("CURRENCY");
	
		for (int i = 0; i < s; i++) {
			crHs.put(output.getString("CURRENCY", i, "OCEAN_KOD"), output.getString("CURRENCY", i, "KOD"));
		}
		
		return crHs;
	}
	
	public static Connection getDSConnection() throws SQLException {
		return DALUtil.getGMConnection();
	}
	

	public static String getOid() throws SQLException {
		return UUID.randomUUID().toString().substring(0, 32);
	}
	
	
	public static void callFundingBatch(String batchParamCode) {			
		try {
			String batchNo = getGlobalParam(batchParamCode);
			
			GMMap batchMap = new GMMap();	
			batchMap.put("GRUP_NO", batchNo);
			GMServiceExecuter.executeNT("BNSPR_PAR9943_BATCH_ISLEM_YARAT", batchMap);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public static String getGlobalParam(String batchParamCode) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", batchParamCode);
		String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return batchNo;
	}

	
	public static BigDecimal getNextValueOfFTMProcessId() {
		
		Session session = DAOSession.getSession("BNSPRDal");
		return new BigDecimal(((Number) session
				.createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual")
				.uniqueResult()).longValue());
	}


	public static void ftmTransferFile(String ftmId, BigDecimal ftmProcessId, String date, int i) throws IOException {
		GMMap input = new GMMap();
		input.put("FILE_DEF_ID", ftmId);
		input.put("PROCESS_ID", ftmProcessId);
		input.put("PROCESS_DATE", date);
		input.put("PROCESS_NO", i);
		GMConnection connection = GMConnection.getConnection("FTM");
		connection.serviceCall("BNSPR_FTM_CREATE_AND_TRANSFER_FILE", input);
	}
	
	
	public static GMMap sendMail(String batchName, String message) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "AUTOPYMNT_BATCH_MAIL_GRUP")).uniqueResult();
			GMMap iMap = new GMMap();
			iMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			iMap.put("MAIL_SUBJECT", batchName);
			iMap.put("MAIL_BODY", message);
			iMap.put("IS_BODY_HTML", "H");
			iMap.put("MAIL_TO", parametre.getDeger());
			GMServiceExecuter.executeAsync("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", iMap);
			return iMap;
		}
		catch (Exception e) {
			//
		}

		return oMap;
	}

	public static GMMap sendMail(String subject, String message, String mailTo) {
		GMMap oMap = new GMMap();
		
		try {
			oMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			oMap.put("MAIL_SUBJECT", subject);
			oMap.put("MAIL_BODY", message);
			oMap.put("IS_BODY_HTML", "H");
			oMap.put("MAIL_TO", mailTo);
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", oMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	public static BigDecimal getCurrencyField(String line, int startIdx, int endIdx) {
		String amountStr = line.substring(startIdx, endIdx).trim();
		int negateIndis = amountStr.lastIndexOf("-");
		BigDecimal amount = BigDecimal.ZERO;
		if (negateIndis > -1) {
			amount = BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx+negateIndis+1, endIdx).trim())).negate();
		}else {
			amount = BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx, endIdx).trim()));
		}
		return amount;
	}
	
	public static BigDecimal getBigDecimalValue(String line, int startIdx, int endIdx) throws SQLException {
		return BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx, endIdx).trim()));
	}

	public static String getStringValue(GMMap iMap, String key, int length) {
		String value = "";
		if (isNotExistAndNull(iMap,key)) {
			value = iMap.getString(key);
			value = value.length()> length ? value.substring(0,length-1) : value;
		}
		return value;
	}

	public static boolean isNotExistAndNull(GMMap iMap, String key){
		
		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length()>0) {
			return true;
		}else {
			return false;
		}
	
	}
	
	public static GMMap getConnectionInfo(String ftpCode) throws Exception{
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			GnlSifre connInfo = (GnlSifre) session.get(GnlSifre.class, ftpCode);
			
			oMap.put("IP", connInfo.getIp());
			oMap.put("PORT", connInfo.getPort());
			oMap.put("PATH", connInfo.getPath());
			oMap.put("USERNAME", connInfo.getUserName());
			oMap.put("PASSWORD", connInfo.getDeger());
		}
		catch (Exception e) {
			throw new Exception("Ba�lant� bilgileri al�n�rken hata olu�tu!");
		}
        
        return oMap;
	}
	
	public static boolean fileExistsOnSFtp(String ftpCode, String fileName) throws Exception{
		GMMap connMap = getConnectionInfo(ftpCode);
		SFTPClient sFtpClient = null;
		
		try {
			sFtpClient = new SFTPClient(connMap.getString("IP"), connMap.getString("USERNAME"), connMap.getString("PASSWORD"));
			
			if(!sFtpClient.fileExists(connMap.getString("PATH"), fileName)){
				return false;
			}
		}
		catch (Exception e) {
			throw new Exception("Dosya kontrol� esnas�nda hata olu�tu!");
		}
		
		return true;
	}
	
}
