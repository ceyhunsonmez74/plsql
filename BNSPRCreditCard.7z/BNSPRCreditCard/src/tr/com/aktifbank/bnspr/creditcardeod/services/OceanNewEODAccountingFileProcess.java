package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdCardAccountingFile;
import tr.com.aktifbank.bnspr.dao.CrdCardAccountingFilePrcss;
import tr.com.aktifbank.bnspr.dao.CrdCardAccountingTempPrcss;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanNewEODAccountingFileProcess {

	@GraymoundService("BNSPR_CRD_LOAD_NEW_OCEAN_ACCOUNTING_FILE")
	public static GMMap loadAccountingFile(GMMap iMap) throws Exception {

		GMMap oMap = new GMMap();

		try {
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CRD_INSERT_NEW_OCEAN_ACCOUNTING_FILE", iMap));
			Date fileDate = oMap.getDate("fileDate");
			BigDecimal fileNo = oMap.getBigDecimal("fileNo");

			if (fileNo != BigDecimal.ZERO) {

				if (sameFileResend(fileDate, fileNo)) {
					updateProcessedRecord(fileDate);
				}

				insertAccFileRecord(fileDate, fileNo);
				EODUtilitiy.callFundingBatch("CREDIT_NEW_CARD_ACCNTING_BATCH");
			}

		}
		catch (Exception e) {
			EODUtilitiy.sendMail("Yeni Ocean Muhasebe Dosya Y�kleme", e.getMessage());
			e.printStackTrace();
			throw e;
		}

		return oMap;
	}

	private static BigDecimal getCurrencyField(String line, int startIdx, int endIdx) {
		String amountStr = line.substring(startIdx, endIdx).trim();
		int negateIndis = amountStr.lastIndexOf("-");
		BigDecimal amount = BigDecimal.ZERO;
		if (negateIndis > -1) {
			amount = BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx + negateIndis + 1, endIdx).trim())).negate();
		}
		else {
			amount = BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx, endIdx).trim()));
		}
		return amount;
	}

	private static void updateProcessedRecord(Date fileDate) {

		String query1 = String.format("update bnspr.crd_card_accounting_file_prcss p " + "set p.status = 'E', p.bank_response_code = '0' ,p.bank_response_desc ='Dublicate Ocean RRN.' " + "where p.status = 'A' " + "and exists (select p2.ocean_ref_no from bnspr.crd_card_accounting_file_prcss p2 " + "where p2.status = 'K' and p2.ocean_ref_no = p.ocean_ref_no)");

		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();

	}

	@SuppressWarnings("unchecked")
	private static Boolean sameFileResend(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		List<CrdCardAccountingFile> caf = (List<CrdCardAccountingFile>) session.createCriteria(CrdCardAccountingFile.class).add(Restrictions.ne("status", "D")).add(Restrictions.eq("fileDate", fileDate)).add(Restrictions.eq("fileNo", fileNo)).list();

		return caf.size() > 0 ? true : false;
	}

	@GraymoundService("BNSPR_CRD_NEW_DELETE_WAITED_ACCOUNTING_RECORDS")
	public static GMMap defineFundingAccountfForNewCard(GMMap iMap) {

		String query1 = String.format("update bnspr.crd_card_accounting_file_prcss set status ='D' where status='A'");

		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();

		session.clear();

		String query2 = String.format("update bnspr.crd_card_accounting_file set status ='D' where status='A'");
		session.createSQLQuery(query2).executeUpdate();

		String query3 = String.format("update bnspr.crd_card_accounting_temp_prcss set status ='D' where status='A'");
		session.createSQLQuery(query3).executeUpdate();

		return iMap;
	}

	private static void insertAccFileRecord(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		CrdCardAccountingFile accountingFile = new CrdCardAccountingFile();

		accountingFile.setStatus("A");
		accountingFile.setFileDate(fileDate);
		accountingFile.setFileNo(fileNo);

		session.save(accountingFile);
		session.flush();
	}

	@GraymoundService("BNSPR_CRD_INSERT_NEW_OCEAN_ACCOUNTING_FILE")
	public static GMMap insertAccountingFile(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		try {
			long start = 1;
			long interval = 1000;
			long end = interval;
			String segment = "";
			String cardNo = "";
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			GMMap cMap = new GMMap();
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}

			String line = "";

			// Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
			String rowId = "";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Session session = DAOSession.getSession("BNSPRDal");
			String serviceCode = "";
			String sourceCode = "";
			Date fileDate = new Date();
			BigDecimal fileNo = BigDecimal.ZERO;

			// delete waited records
			GMServiceExecuter.executeNT("BNSPR_CRD_NEW_DELETE_WAITED_ACCOUNTING_RECORDS", iMap);

			do {
				int k = fileMap.getSize("FILE_LINE");

				for (int i = 0; i < k; i++) {

					line = fileMap.getString("FILE_LINE", i, "LINE");
					rowId = line.substring(0, 1);

					if (rowId.equals("H")) {

						fileDate = dateFormat.parse(line.substring(1, 9));
						fileNo = BigDecimal.valueOf(Double.parseDouble(line.substring(9, 25)));

					}
					else if (rowId.equals("F")) {
						// no need for now
					}
					else {

						try {
							serviceCode = line.substring(24, 27).trim();
							sourceCode = line.substring(170, 172).trim();
							segment = line.substring(93, 97).trim();
							if ("TFF".equals(segment) && ("BI".equals(sourceCode) || "MI".equals(sourceCode))) {
								CrdCardAccountingTempPrcss tempProcess = (CrdCardAccountingTempPrcss) session.createCriteria(CrdCardAccountingTempPrcss.class).add(Restrictions.eq("fileNo", fileNo)).add(Restrictions.eq("serviceCode", serviceCode)).add(Restrictions.eq("sourceCode", sourceCode)).add(Restrictions.eq("status", "A")).uniqueResult();

								// CrdCardAccountingTempPrcss tempProcess = (CrdCardAccountingTempPrcss) session.get(CrdCardAccountingTempPrcss.class, tempProcessId);
								if (tempProcess == null) {
									CrdCardAccountingTempPrcss tempProcess1 = new CrdCardAccountingTempPrcss();
									tempProcess1.setServiceCode(serviceCode);
									tempProcess1.setSourceCode(sourceCode);
									tempProcess1.setFileNo(fileNo);
									tempProcess1.setFileDate(fileDate);
									tempProcess1.setProcessDate(dateFormat.parse(line.substring(0, 8).trim()));
									tempProcess1.setRefkey(line.substring(8, 24).trim());
									tempProcess1.setCurrencyCode(line.substring(27, 30).trim());

									tempProcess1.setAmount(getCurrencyField(line, 30, 51));
									tempProcess1.setComAmount(getCurrencyField(line, 51, 72));
									tempProcess1.setTaxAmount(getCurrencyField(line, 72, 93));

									tempProcess1.setSanalBranchCode(segment);
									tempProcess1.setBranchCode(line.substring(97, 101).trim());
									tempProcess1.setCardBranchCode(line.substring(101, 105).trim());

									tempProcess1.setRateAmount(getCurrencyField(line, 105, 126));

									tempProcess1.setExplanation(line.substring(126, 166));
									tempProcess1.setBankCode(line.substring(166, 170).trim());

									tempProcess1.setIkpAmount(getCurrencyField(line, 173, 193));
									tempProcess1.setBkpAmount(getCurrencyField(line, 193, 214));
									tempProcess1.setServiceAmount(getCurrencyField(line, 214, 235));
									tempProcess1.setAnapara(getCurrencyField(line, 235, 256));
									tempProcess1.setFaiz(getCurrencyField(line, 256, 277));
									tempProcess1.setUcret(getCurrencyField(line, 277, 298));
									tempProcess1.setKartUcret(getCurrencyField(line, 298, 319));
									tempProcess1.setVergi1(getCurrencyField(line, 319, 340));
									tempProcess1.setVergi2(getCurrencyField(line, 340, 361));

									tempProcess1.setCustomerNo(BigDecimal.valueOf(Double.parseDouble(line.substring(361, 371))));

									cardNo = line.substring(371, 391).trim();
									tempProcess1.setPrepaidCardNo(cardNo);
									tempProcess1.setProductCode(segment);

									tempProcess1.setOceanRefNo(BigDecimal.valueOf(Double.parseDouble(line.substring(401, 422))));
									tempProcess1.setRrn(line.substring(422, 434).trim());
									if (!StringUtil.isEmpty(cardNo)) {
										cMap.clear();
										cMap.put("CARD_NO", cardNo);
										cMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_EMBOSS_STATUS", cMap);
										tempProcess1.setCardDci(cMap.getString("CARD_EMBOSS_STATUS", 0, "CARD_DCI"));
									}
									tempProcess1.setStatus("A");
									session.save(tempProcess1);
								}
								else {
									tempProcess.setAmount(tempProcess.getAmount().add(getCurrencyField(line, 30, 51)));
									tempProcess.setComAmount(tempProcess.getComAmount().add(getCurrencyField(line, 51, 72)));
									tempProcess.setTaxAmount(tempProcess.getTaxAmount().add(getCurrencyField(line, 72, 93)));
									tempProcess.setRateAmount(tempProcess.getRateAmount().add(getCurrencyField(line, 105, 126)));

									tempProcess.setIkpAmount(tempProcess.getIkpAmount().add(getCurrencyField(line, 172, 193)));
									tempProcess.setBkpAmount(tempProcess.getBkpAmount().add(getCurrencyField(line, 193, 214)));
									tempProcess.setServiceAmount(tempProcess.getServiceAmount().add(getCurrencyField(line, 214, 235)));
									tempProcess.setAnapara(tempProcess.getAnapara().add(getCurrencyField(line, 235, 256)));
									tempProcess.setFaiz(tempProcess.getFaiz().add(getCurrencyField(line, 256, 277)));
									tempProcess.setUcret(tempProcess.getUcret().add(getCurrencyField(line, 277, 298)));
									tempProcess.setKartUcret(tempProcess.getKartUcret().add(getCurrencyField(line, 298, 319)));
									tempProcess.setVergi1(tempProcess.getVergi1().add(getCurrencyField(line, 319, 340)));
									tempProcess.setVergi2(tempProcess.getVergi2().add(getCurrencyField(line, 340, 361)));

									session.saveOrUpdate(tempProcess);

								}

							}
							else {
								CrdCardAccountingFilePrcss fileProcess = new CrdCardAccountingFilePrcss();
								try {

									fileProcess.setFileDate(fileDate);
									fileProcess.setFileNo(fileNo);
									fileProcess.setProcessDate(dateFormat.parse(line.substring(0, 8).trim()));
									fileProcess.setRefkey(line.substring(8, 24).trim());
									fileProcess.setServiceCode(line.substring(24, 27).trim());
									// fileProcess.setCurrencyCode(crHs.get(line.substring(26,29).trim()));
									fileProcess.setCurrencyCode(line.substring(27, 30).trim());

									fileProcess.setAmount(getCurrencyField(line, 30, 51));
									fileProcess.setComAmount(getCurrencyField(line, 51, 72));
									fileProcess.setTaxAmount(getCurrencyField(line, 72, 93));

									fileProcess.setSanalBranchCode(segment);
									fileProcess.setBranchCode(line.substring(97, 101).trim());
									fileProcess.setCardBranchCode(line.substring(101, 105).trim());

									fileProcess.setRateAmount(getCurrencyField(line, 105, 126));

									fileProcess.setExplanation(line.substring(126, 166));
									fileProcess.setBankCode(line.substring(166, 170).trim());
									fileProcess.setSourceCode(line.substring(170, 172).trim());

									fileProcess.setIkpAmount(getCurrencyField(line, 172, 193));
									fileProcess.setBkpAmount(getCurrencyField(line, 193, 214));
									fileProcess.setServiceAmount(getCurrencyField(line, 214, 235));
									fileProcess.setAnapara(getCurrencyField(line, 235, 256));
									fileProcess.setFaiz(getCurrencyField(line, 256, 277));
									fileProcess.setUcret(getCurrencyField(line, 277, 298));
									fileProcess.setKartUcret(getCurrencyField(line, 299, 319));
									fileProcess.setVergi1(getCurrencyField(line, 319, 340));
									fileProcess.setVergi2(getCurrencyField(line, 340, 361));

									fileProcess.setCustomerNo(BigDecimal.valueOf(Double.parseDouble(line.substring(361, 371))));

									cardNo = line.substring(371, 391).trim();
									fileProcess.setPrepaidCardNo(cardNo);
									if ("TFF".equals(segment)) {
										fileProcess.setProductCode(segment);
									}
									else {
										fileProcess.setProductCode(line.substring(391, 401).trim());
									}
									fileProcess.setOceanRefNo(BigDecimal.valueOf(Double.parseDouble(line.substring(401, 422))));
									fileProcess.setRrn(line.substring(422, 434).trim());
									if (!StringUtil.isEmpty(cardNo)) {
										cMap.clear();
										cMap.put("CARD_NO", cardNo);
										cMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_EMBOSS_STATUS", cMap);
										fileProcess.setCardDci(cMap.getString("CARD_EMBOSS_STATUS", 0, "CARD_DCI"));
									}
									fileProcess.setStatus("A");

								}
								catch (Exception e) {
									fileProcess.setStatus("E");
									fileProcess.setBankResponseDesc("Dosya format�na uymayan hatal� sat�r.");
								}
								session.save(fileProcess);
							}
						}
						catch (Exception e) {
							e.printStackTrace();
						}

					}
				}

				session.flush();

				
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			}
			while (fileMap.get("FILE_LINE") != null);
			
			List<?> tempFileList = session.createCriteria(CrdCardAccountingTempPrcss.class).add(Restrictions.eq("fileNo", fileNo)).add(Restrictions.eq("status", "A")).list();
			for (int i = 0; i < tempFileList.size(); i++) {
				CrdCardAccountingTempPrcss tempFile = (CrdCardAccountingTempPrcss) tempFileList.get(i);
				CrdCardAccountingFilePrcss fileProcess = new CrdCardAccountingFilePrcss();
				fileProcess.setFileDate(fileDate);
				fileProcess.setFileNo(fileNo);
				fileProcess.setProcessDate(tempFile.getProcessDate());
				fileProcess.setRefkey(tempFile.getRefkey());
				fileProcess.setServiceCode(tempFile.getServiceCode());
				// fileProcess.setCurrencyCode(crHs.get(line.substring(26,29).trim()));
				fileProcess.setCurrencyCode(tempFile.getCurrencyCode());

				fileProcess.setAmount(tempFile.getAmount());
				fileProcess.setComAmount(tempFile.getComAmount());
				fileProcess.setTaxAmount(tempFile.getTaxAmount());

				fileProcess.setSanalBranchCode(tempFile.getSanalBranchCode());
				fileProcess.setBranchCode(tempFile.getBranchCode());
				fileProcess.setCardBranchCode(tempFile.getCardBranchCode());

				fileProcess.setRateAmount(tempFile.getRateAmount());

				fileProcess.setExplanation(tempFile.getExplanation());
				fileProcess.setBankCode(tempFile.getBankCode());
				fileProcess.setSourceCode(tempFile.getSourceCode());

				fileProcess.setIkpAmount(tempFile.getIkpAmount());
				fileProcess.setBkpAmount(tempFile.getBkpAmount());
				fileProcess.setServiceAmount(tempFile.getServiceAmount());
				fileProcess.setAnapara(tempFile.getAnapara());
				fileProcess.setFaiz(tempFile.getFaiz());
				fileProcess.setUcret(tempFile.getUcret());
				fileProcess.setKartUcret(tempFile.getKartUcret());
				fileProcess.setVergi1(tempFile.getVergi1());
				fileProcess.setVergi2(tempFile.getVergi2());
				fileProcess.setCustomerNo(tempFile.getCustomerNo());
				fileProcess.setPrepaidCardNo(tempFile.getPrepaidCardNo());
				fileProcess.setProductCode(tempFile.getProductCode());

				fileProcess.setOceanRefNo(tempFile.getOceanRefNo());
				fileProcess.setRrn(tempFile.getRrn());
				fileProcess.setCardDci(tempFile.getCardDci());
				fileProcess.setStatus("A");
				session.saveOrUpdate(fileProcess);
			}
			session.flush();
			oMap.put("fileNo", fileNo);
			oMap.put("fileDate", fileDate);
		}
		catch (Exception e) {
			EODUtilitiy.sendMail("Yeni Ocean Muhasebe Dosya Y�kleme", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return oMap;
	}

}
