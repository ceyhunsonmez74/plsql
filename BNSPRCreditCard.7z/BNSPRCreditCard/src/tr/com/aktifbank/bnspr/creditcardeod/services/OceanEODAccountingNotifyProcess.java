package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.CrdAccountingFile;
import tr.com.aktifbank.bnspr.dao.CrdAccountingFileProcess;
import tr.com.aktifbank.bnspr.dao.CrdAccountingNotifyLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanEODAccountingNotifyProcess {
	
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_CRD_START_TO_NOTIFY_OCEAN_ACCOUNTING_RESULT")
	public static GMMap startToSendOceanAccountingNotify (GMMap iMap) throws Exception {
	
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<CrdAccountingFile> fileList = null;
					
			if (iMap.containsKey("FILE_DATE") && iMap.get("FILE_DATE") != null) {
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
				Date fileDate = dateFormat.parse(iMap.getString("FILE_DATE"));
				fileList = (List<CrdAccountingFile>) session.createCriteria(CrdAccountingFile.class).add(Restrictions.eq("status", "K"))
																									.add(Restrictions.eq("fileDate", fileDate)).list();
				
			}else if (iMap.containsKey("FILE_NO") && iMap.get("FILE_NO") != null) {
				
				fileList = (List<CrdAccountingFile>) session.createCriteria(CrdAccountingFile.class).add(Restrictions.eq("fileNo", iMap.getBigDecimal("FILE_NO"))).list();
				
			}else{
				
				fileList = (List<CrdAccountingFile>) session.createCriteria(CrdAccountingFile.class).add(Restrictions.eq("status", "K")).list();
			}
			
			String ftmId = EODUtilitiy.getGlobalParam("CRD_CC_ACCOUNT_NOTIFY_FTM_ID");
			
			int i = 1;
			
			for (CrdAccountingFile file : fileList) {
				
				CrdAccountingNotifyLog notifyLog = new CrdAccountingNotifyLog();
				
				notifyLog.setFileDate(file.getFileDate());
				notifyLog.setFileNo(file.getFileNo());
				notifyLog.setStatus("A");
				
				try {
					
					BigDecimal ftmProcessId = EODUtilitiy.getNextValueOfFTMProcessId();
					notifyLog.setFtmProcessId(ftmProcessId);
					GMMap fileMap = prepareAccMap(file, ftmProcessId);
					GMServiceExecuter.executeNT("BNSPR_CRD_NOTIFY_OCEAN_ACCOUNTING_RESULT", fileMap);
					
					EODUtilitiy.ftmTransferFile(ftmId, ftmProcessId, dateFormat.format(file.getFileDate()),i);
					
					updateAccountingFile(file.getOid());
					
					i = i +1;
					
				} catch (Exception e) {
					e.printStackTrace();
					notifyLog.setStatus("E");
					notifyLog.setErrorCode("10");
					notifyLog.setErrorDesc(e.getMessage().toString().length() > 300 ? 
											e.getMessage().toString().substring(1,300):
											e.getMessage().toString());
				}
				
				session.save(notifyLog);
				session.flush();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return iMap;
	}

	
	private static void updateAccountingFile(String oid) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		CrdAccountingFile file = (CrdAccountingFile) session.createCriteria(CrdAccountingFile.class).add(Restrictions.eq("oid", oid)).uniqueResult();
		file.setStatus("R");
		session.update(file);
		session.flush();
		
	}


	private static GMMap prepareAccMap(CrdAccountingFile file, BigDecimal ftmProcessId) {
		
		GMMap outMap = new GMMap();
		outMap.put("FILE_DATE", file.getFileDate());
		outMap.put("FILE_NO", file.getFileNo());
		outMap.put("FTM_PROCESS_ID", ftmProcessId);
		
		return outMap;
	}
	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_CRD_NOTIFY_OCEAN_ACCOUNTING_RESULT")
	public static GMMap notifyOceanAccountingNotify (GMMap iMap) throws Exception {
	
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal ftmProcessId = iMap.getBigDecimal("FTM_PROCESS_ID");
			BigDecimal lineNumber = BigDecimal.ONE;
			
			String header = prepareHeader(iMap);
			
			FtmFileContent headerLine = new FtmFileContent();
			headerLine.setOid(lineNumber.toString());
			headerLine.setFtmProcessOid(ftmProcessId);
			headerLine.setLine(header);
			headerLine.setLineNumber(lineNumber);
			session.save(headerLine);
			session.flush();
			
			List<CrdAccountingFileProcess> accList = (List<CrdAccountingFileProcess>) session.createCriteria(CrdAccountingFileProcess.class)
					.add(Restrictions.eq("fileNo", iMap.getBigDecimal("FILE_NO"))).list();
			
			BigDecimal amount = BigDecimal.ZERO;
			long count = 0;
			
			for (CrdAccountingFileProcess acc : accList ) {
				
				lineNumber = lineNumber.add(BigDecimal.ONE);
				
				FtmFileContent fileContent = new FtmFileContent();
				
				String detailLine = prepareDetail(acc);
				
				fileContent.setOid(lineNumber.toString());
				fileContent.setFtmProcessOid(ftmProcessId);
				fileContent.setLine(detailLine);
				fileContent.setLineNumber(lineNumber);
				
				session.save(fileContent);
				
				amount = amount.add(acc.getAmount());
				count = count +1;
			}
			session.flush();
			
			lineNumber = lineNumber.add(BigDecimal.ONE);
			String footer = prepareFooter(amount, count, iMap.getString("FILE_DATE"));
			
			FtmFileContent footerLine = new FtmFileContent();
			footerLine.setOid(lineNumber.toString());
			footerLine.setFtmProcessOid(ftmProcessId);
			footerLine.setLine(footer);
			footerLine.setLineNumber(lineNumber);
			
			session.save(footerLine);
			session.flush();
			
		} catch (Exception e) {
			EODUtilitiy.sendMail("Ocean Muhasebe Dosya Sonu� G�nderim", e.getMessage());
			GMMap eMap = new GMMap();
			eMap.put("HATA_NO", "660");
			eMap.put("P1", e.getMessage().toString());
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", eMap);
		}
		
		return iMap;
	}

	private static String prepareFooter(BigDecimal amount, long count,	String fileDate) {

		StringBuilder sb = new StringBuilder();
		sb.append("F").append(fileDate);
		sb.append(String.format("%010d", count));
		sb.append(String.format("%17s", amount.toString()).replaceAll(" ", "0"));
		
		return sb.toString();
	}

	
	private static String prepareDetail(CrdAccountingFileProcess acc) {
		
		StringBuilder dsBuffer = new StringBuilder();

		dsBuffer.append(String.format("%16s", acc.getOceanRefNo() == null ? "0": acc.getOceanRefNo().toString())
						.replaceAll(" ", "0"));
		dsBuffer.append(String.format("%16s", acc.getBankRefNo() == null ? "0" : acc.getBankRefNo().toString())
						.replaceAll(" ", "0"));
		
		if (acc.getBankResponseDate() == null) {
			dsBuffer.append(String.format("%08d",0));
		}else {
			dsBuffer.append(dateFormat.format(acc.getBankResponseDate()));
		}
		dsBuffer.append(String.format("%7s", acc.getBankResponseCode() == null ? " " : acc.getBankResponseCode() ));		
		String bnkRspDesc = "";
		if (acc.getBankResponseDesc() !=null && acc.getBankResponseDesc().length() > 100) {
			bnkRspDesc = acc.getBankResponseDesc().substring(1,100);
		}else {
			bnkRspDesc = String.format("%100s", acc.getBankResponseDesc() == null ? "": acc.getBankResponseDesc());
		}
		
		dsBuffer.append(bnkRspDesc);
		
		return dsBuffer.toString();
	}

	
	private static String prepareHeader(GMMap iMap) throws ParseException {

		StringBuilder sb = new StringBuilder();
		sb.append("H").append(dateFormat.format(iMap.getDate("FILE_DATE"))).append(String.format("%016d", iMap.getLong("FILE_NO")));
		return sb.toString();
	}
}