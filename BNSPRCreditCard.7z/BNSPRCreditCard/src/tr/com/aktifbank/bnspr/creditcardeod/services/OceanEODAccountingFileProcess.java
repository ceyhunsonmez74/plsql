package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdAccountingFile;
import tr.com.aktifbank.bnspr.dao.CrdAccountingFileProcess;
import tr.com.aktifbank.bnspr.dao.CrdOceanppAccFilePrss;
import tr.com.aktifbank.bnspr.dao.CrdOceanppAccountingFile;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanEODAccountingFileProcess {

	
	@GraymoundService("BNSPR_CRD_LOAD_OCEAN_ACCOUNTING_FILE")
	public static GMMap loadAccountingFile(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		
		try {
			
			long start = 1;
			long interval = 1000;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}
			
			String line = "";
	
			//Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
			String rowId = "";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date fileDate = new Date();
			BigDecimal fileNo = BigDecimal.ZERO;
			
			//delete waited records
			GMServiceExecuter.executeNT("BNSPR_CRD_DELETE_WAITED_ACCOUNTING_RECORDS", iMap);
			
			do {
				int k = fileMap.getSize("FILE_LINE");
				
				for (int i = 0; i < k; i++) {
					
					line = fileMap.getString("FILE_LINE", i, "LINE");
					rowId = line.substring(0, 1);
					
					if (rowId.equals("H")) {
						
						fileDate = dateFormat.parse(line.substring(1, 9));
						fileNo = BigDecimal.valueOf(Double.parseDouble(line.substring(9, 25)));
						
					}else if(rowId.equals("F")) {
						//no need for now
					}else {
						CrdAccountingFileProcess fileProcess = new CrdAccountingFileProcess();
						fileProcess.setFileDate(fileDate);
						fileProcess.setFileNo(fileNo);
						try {
							fileProcess.setProcessDate(dateFormat.parse(line.substring(0,8).trim()));
							fileProcess.setRefkey(line.substring(8,23).trim());
							fileProcess.setServiceCode(line.substring(23, 26).trim());
							//fileProcess.setCurrencyCode(crHs.get(line.substring(26,29).trim()));
							fileProcess.setCurrencyCode(line.substring(26,29).trim());
							
							fileProcess.setAmount(getCurrencyField(line, 29, 50));
							fileProcess.setComAmount(getCurrencyField(line, 50, 71));
							fileProcess.setTaxAmount(getCurrencyField(line, 71, 92));
							
							fileProcess.setSanalBranchCode(line.substring(92, 96).trim());
							fileProcess.setBranchCode(line.substring(96,100).trim());
							fileProcess.setCardBranchCode(line.substring(100,104).trim());
							
							fileProcess.setRateAmount(getCurrencyField(line, 104, 125));
							
							fileProcess.setExplanation(line.substring(125, 165));
							fileProcess.setBankCode(line.substring(165, 169).trim());
							fileProcess.setSourceCode(line.substring(169,171).trim());
							
							fileProcess.setIkpAmount(getCurrencyField(line, 171, 192));
							fileProcess.setBkpAmount(getCurrencyField(line, 192, 213));
							fileProcess.setServiceAmount(getCurrencyField(line, 213, 234));
							fileProcess.setAnapara(getCurrencyField(line, 234, 255));
							fileProcess.setFaiz(getCurrencyField(line, 255, 276));
							fileProcess.setUcret(getCurrencyField(line, 276, 297));
							fileProcess.setKartUcret(getCurrencyField(line, 297, 318));
							fileProcess.setVergi1(getCurrencyField(line, 318, 339));
							fileProcess.setVergi2(getCurrencyField(line, 339, 360));
							
							fileProcess.setCustomerNo(BigDecimal.valueOf(Double.parseDouble(line.substring(360, 370))));
							fileProcess.setPrepaidCardNo(line.substring(370, 390).trim());
							fileProcess.setProductCode(line.substring(390, 400).trim());
							fileProcess.setOceanRefNo(BigDecimal.valueOf(Double.parseDouble(line.substring(400, 416))));
							
							fileProcess.setStatus("A");
						} catch (Exception e) {
							fileProcess.setStatus("E");
							fileProcess.setBankResponseDesc("Dosya format�na uymayan hatal� sat�r.");
						}
						
						session.save(fileProcess);
					}
				}
				
				session.flush();
				
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			} while (fileMap.get("FILE_LINE") != null);
			
			if (fileNo != BigDecimal.ZERO) {
				
				if (sameFileResend(fileDate, fileNo)) {
					updateProcessedRecord(fileDate);
				}
				
				insertAccFileRecord(fileDate, fileNo);
				EODUtilitiy.callFundingBatch("CREDIT_CARD_ACCOUNTING_BATCH");	
			}
			
		} catch (Exception e) {
			EODUtilitiy.sendMail("Ocean Muhasebe Dosya Y�kleme", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		
		return oMap;
	}

	private static BigDecimal getCurrencyField(String line, int startIdx, int endIdx) {
		String amountStr = line.substring(startIdx, endIdx).trim();
		int negateIndis = amountStr.lastIndexOf("-");
		BigDecimal amount = BigDecimal.ZERO;
		if (negateIndis > -1) {
			amount = BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx+negateIndis+1, endIdx).trim())).negate();
		}else {
			amount = BigDecimal.valueOf(Double.parseDouble(line.substring(startIdx, endIdx).trim()));
		}
		return amount;
	}
	
	
	private static void updateProcessedRecord(Date fileDate) {

		String query1 = String.format("update bnspr.crd_accounting_file_process p " +
				"set p.status = 'E', p.bank_response_code = '0' ,p.bank_response_desc ='Dublicate Ocean RRN.' " +
				"where p.status = 'A' " +
				"and exists (select p2.ocean_ref_no from bnspr.crd_accounting_file_process p2 " +
				"where p2.status = 'K' and p2.ocean_ref_no = p.ocean_ref_no)");
		
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
		
	}


	@SuppressWarnings("unchecked")
	private static Boolean sameFileResend(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		List<CrdAccountingFile> caf = (List<CrdAccountingFile>) 
				session.createCriteria(CrdAccountingFile.class)
					.add(Restrictions.ne("status", "D"))
					.add(Restrictions.eq("fileDate", fileDate))
					.add(Restrictions.eq("fileNo", fileNo)).list();
		
		return caf.size() > 0 ? true : false;
	}


	@GraymoundService("BNSPR_CRD_DELETE_WAITED_ACCOUNTING_RECORDS")
	public static GMMap defineFundingAccountfForNewCard(GMMap iMap) {

		String query1 = String.format("update bnspr.crd_accounting_file_process set status ='D' where status='A'");
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
		
		session.clear();
		
		String query2 = String.format("update bnspr.crd_accounting_file set status ='D' where status='A'");
		session.createSQLQuery(query2).executeUpdate();
		
		return iMap;
	}
	
	private static void insertAccFileRecord(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		CrdAccountingFile accountingFile = new CrdAccountingFile();
		
		accountingFile.setStatus("A");
		accountingFile.setFileDate(fileDate);
		accountingFile.setFileNo(fileNo);
		
		session.save(accountingFile);
		session.flush();
	}

	@GraymoundService("BNSPR_CRD_LOAD_OCEANPP_ACCOUNTING_FILE")
	public static GMMap loadOceanPPAccountingFile(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		
		try {
			
			long start = 1;
			long interval = 1000;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}
			
			String line = "";
	
			//Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
			String rowId = "";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date fileDate = new Date();
			BigDecimal fileNo = BigDecimal.ZERO;
			
			//delete waited records
			GMServiceExecuter.executeNT("BNSPR_CRD_DELETE_WAITED_OCEANPP_ACC_RECORDS", iMap);
			
			do {
				int k = fileMap.getSize("FILE_LINE");
				
				for (int i = 0; i < k; i++) {
					
					line = fileMap.getString("FILE_LINE", i, "LINE");
					rowId = line.substring(0, 1);
					
					if (rowId.equals("H")) {
						
						fileDate = dateFormat.parse(line.substring(1, 9));
						fileNo = BigDecimal.valueOf(Double.parseDouble(line.substring(9, 25)));
						
					}else if(rowId.equals("F")) {
						//no need for now
					}else {
						CrdOceanppAccFilePrss fileProcess = new CrdOceanppAccFilePrss();
						fileProcess.setFileDate(fileDate);
						fileProcess.setFileNo(fileNo);
						try {
							fileProcess.setProcessDate(dateFormat.parse(line.substring(0,8).trim()));
							fileProcess.setRefkey(line.substring(8,23).trim());
							fileProcess.setServiceCode(line.substring(23, 26).trim());
							//fileProcess.setCurrencyCode(crHs.get(line.substring(26,29).trim()));
							fileProcess.setCurrencyCode(line.substring(26,29).trim());
							
							fileProcess.setAmount(getCurrencyField(line, 29, 50));
							fileProcess.setComAmount(getCurrencyField(line, 50, 71));
							fileProcess.setTaxAmount(getCurrencyField(line, 71, 92));
							
							fileProcess.setSanalBranchCode(line.substring(92, 96).trim());
							fileProcess.setBranchCode(line.substring(96,100).trim());
							fileProcess.setCardBranchCode(line.substring(100,104).trim());
							
							fileProcess.setRateAmount(getCurrencyField(line, 104, 125));
							
							fileProcess.setExplanation(line.substring(125, 165));
							fileProcess.setBankCode(line.substring(165, 169).trim());
							fileProcess.setSourceCode(line.substring(169,171).trim());
							
							fileProcess.setIkpAmount(getCurrencyField(line, 171, 192));
							fileProcess.setBkpAmount(getCurrencyField(line, 192, 213));
							fileProcess.setServiceAmount(getCurrencyField(line, 213, 234));
							fileProcess.setAnapara(getCurrencyField(line, 234, 255));
							fileProcess.setFaiz(getCurrencyField(line, 255, 276));
							fileProcess.setUcret(getCurrencyField(line, 276, 297));
							fileProcess.setKartUcret(getCurrencyField(line, 297, 318));
							fileProcess.setVergi1(getCurrencyField(line, 318, 339));
							fileProcess.setVergi2(getCurrencyField(line, 339, 360));
							
							fileProcess.setCustomerNo(BigDecimal.valueOf(Double.parseDouble(line.substring(360, 370))));
							fileProcess.setPrepaidCardNo(line.substring(370, 390).trim());
							fileProcess.setProductCode(line.substring(390, 400).trim());
							fileProcess.setOceanRefNo(BigDecimal.valueOf(Double.parseDouble(line.substring(400, 416))));
							fileProcess.setRrn(line.substring(416, 428).trim());
							
							fileProcess.setStatus("A");
						} catch (Exception e) {
							fileProcess.setStatus("E");
							fileProcess.setBankResponseDesc("Dosya format�na uymayan hatal� sat�r.");
						}
						
						session.save(fileProcess);
					}
				}
				
				session.flush();
				
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			} while (fileMap.get("FILE_LINE") != null);
			
			if (fileNo != BigDecimal.ZERO) {
				
				if (sameOceanppFileResend(fileDate, fileNo)) {
					updateOceanppProcessedRecord(fileDate);
				}
				
				insertOceanppAccFileRecord(fileDate, fileNo);
				EODUtilitiy.callFundingBatch("OCEAN_PPAID_ACCOUNTING_BATCH");	
			}
			
		} catch (Exception e) {
			EODUtilitiy.sendMail("Ocean PrePaid Muhasebe Dosya Y�kleme", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		
		return oMap;
	}	

	@GraymoundService("BNSPR_CRD_DELETE_WAITED_OCEANPP_ACC_RECORDS")
	public static GMMap deleteWaitedOceanppAccRecords(GMMap iMap) {

		String query1 = String.format("update bnspr.crd_oceanpp_acc_file_prss set status ='D' where status='A'");
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
		
		session.clear();
		
		String query2 = String.format("update bnspr.crd_oceanpp_accounting_file set status ='D' where status='A'");
		session.createSQLQuery(query2).executeUpdate();
		
		return iMap;
	}
	
	private static void insertOceanppAccFileRecord(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		CrdOceanppAccountingFile accountingFile = new CrdOceanppAccountingFile();
		
		accountingFile.setStatus("A");
		accountingFile.setFileDate(fileDate);
		accountingFile.setFileNo(fileNo);
		
		session.save(accountingFile);
		session.flush();
	}	

	
	private static void updateOceanppProcessedRecord(Date fileDate) {

		String query1 = String.format("update bnspr.crd_oceanpp_acc_file_prss p " +
				"set p.status = 'E', p.bank_response_code = '0' ,p.bank_response_desc ='Dublicate Ocean RRN.' " +
				"where p.status = 'A' " +
				"and exists (select p2.ocean_ref_no from bnspr.crd_oceanpp_acc_file_prss p2 " +
				"where p2.status = 'K' and p2.ocean_ref_no = p.ocean_ref_no)");
		
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
		
	}

	@SuppressWarnings("unchecked")
	private static Boolean sameOceanppFileResend(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		List<CrdOceanppAccountingFile> caf = (List<CrdOceanppAccountingFile>) 
				session.createCriteria(CrdOceanppAccountingFile.class)
					.add(Restrictions.ne("status", "D"))
					.add(Restrictions.eq("fileDate", fileDate))
					.add(Restrictions.eq("fileNo", fileNo)).list();
		
		return caf.size() > 0 ? true : false;
	}	
}
