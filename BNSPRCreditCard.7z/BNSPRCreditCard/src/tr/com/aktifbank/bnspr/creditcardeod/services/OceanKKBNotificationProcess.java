package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.CrdKkbNotificationProcess;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanKKBNotificationProcess {

	private static final Logger logger = Logger.getLogger(OceanKKBNotificationProcess.class);
	
	@GraymoundService("BNSPR_CRD_LOAD_KKB_NOTIFICATION_FILE_DAILY")
	public static GMMap loadKKBNotificationFileDaily(GMMap iMap) throws Exception {
		iMap.put("TYPE", "D");
		loadKKBNotificationFile(iMap);
		return GMServiceExecuter.call("BNSPR_QRY3915_RUN_KKB_KK_BILDIRIM_GUNLUK", iMap);
	}
	
	@GraymoundService("BNSPR_CRD_LOAD_KKB_NOTIFICATION_FILE_MONTHLY")
	public static GMMap loadKKBNotificationFileMonthly(GMMap iMap) throws Exception {
		iMap.put("TYPE", "M");
		loadKKBNotificationFile(iMap);
		return GMServiceExecuter.call("BNSPR_QRY3915_RUN_KKB_KK_BILDIRIM", iMap);
	}
	
	private static GMMap loadKKBNotificationFile(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();
		try {
			long start = 1;
			long interval = 1000;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}
			
			String line,type;
			BigDecimal lineNumber;
			
			type=iMap.getString("TYPE");
			
			Session session = DAOSession.getSession("BNSPRDal");
			do {
				int recordCount = fileMap.getSize("FILE_LINE");
				
				for (int index = 0; index < recordCount; index++) {
					
					line = fileMap.getString("FILE_LINE", index, "LINE");
					lineNumber = fileMap.getBigDecimal("FILE_LINE", index, "LINE_NUMBER");
					
					CrdKkbNotificationProcess fileProcess = new CrdKkbNotificationProcess();
					fileProcess.setProcessId(ftmTransferId);
					fileProcess.setType(type);
					fileProcess.setLineNumber(lineNumber);
					fileProcess.setLine(line);
					fileProcess.setStatus(false);

					session.save(fileProcess);
				}
				
				session.flush();
				
				fileMap.clear();
				start = start + interval;
				end = end + interval;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			} while (fileMap.get("FILE_LINE") != null);
			
		} catch (Exception exp) {
			logger.error(exp);
			EODUtilitiy.sendMail("Ocean KKB Dosyas� Y�kleme", exp.getMessage());
			throw exp;
		}
		
		return oMap;
	}
	
	
}
