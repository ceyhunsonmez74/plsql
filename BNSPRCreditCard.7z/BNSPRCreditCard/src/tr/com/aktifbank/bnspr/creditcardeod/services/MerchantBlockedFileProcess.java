package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdMerchantAccFileProcess;
import tr.com.aktifbank.bnspr.dao.CrdMerchantAccountingFile;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MerchantBlockedFileProcess {
	
	
	@GraymoundService("BNSPR_CC_LOAD_MERCHANT_BLOCKED_FILE")
	public static GMMap loadMerchantBlockedFile(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			
			long start = 1;
			long interval = 1000;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}
			
			String line = "";
			Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
			
			//delete waited records
			GMServiceExecuter.executeNT("BNSPR_CRD_DELETE_WAITED_MERCHANT_FILE_RECORDS", iMap);
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Date fileDate = new Date();
			
			String lineType = "";
			BigDecimal fileNo = BigDecimal.ZERO;
			
			do {
				int k = fileMap.getSize("FILE_LINE");

				for (int i = 0; i < k; i++) {
					
					line = fileMap.getString("FILE_LINE", i, "LINE");
					lineType = line.substring(0, 1);
					
					if (lineType.equals("H")) {
						fileDate = dateFormat.parse(line.substring(1,9));
						fileNo = BigDecimal.valueOf(Double.valueOf(line.substring(9,18)));
						
					}else if (!lineType.equals("F")) {
						CrdMerchantAccFileProcess process = new CrdMerchantAccFileProcess();
						
						process.setFileDate(fileDate);
						process.setFileNo(fileNo);
						try {
						    process.setRecordNo(EODUtilitiy.getBigDecimalValue(line,1, 11));
                            process.setBlockType(line.substring(11, 12));
                            process.setCardSourceCode(line.substring(12, 14));
                            process.setTaksitSayisi(EODUtilitiy.getBigDecimalValue(line,14, 16));
                            process.setBlockNumber(EODUtilitiy.getBigDecimalValue(line,16, 26));
                            process.setMerchantNumber(EODUtilitiy.getBigDecimalValue(line,26, 41));
                            process.setServiceCode(line.substring(41, 44));
                            process.setBlockDate(dateFormat.parse(line.substring(44, 52)));
                            process.setValueDate(dateFormat.parse(line.substring(44, 52)));
    
                            process.setCurrencyCode(crHs.get(line.substring(60, 63)).toString());
                            process.setBorcHesapSube(line.substring(63, 67));
                            process.setBorcHesapNo(EODUtilitiy.getBigDecimalValue(line,67, 75));
                            //(75,79)BORC HESAP EKNO no need    
                            
                            process.setAlacHesapSube(line.substring(79, 83));
                            process.setAlacHesapNo(EODUtilitiy.getBigDecimalValue(line,83, 91));
                            //(91,95) ALACAK HESAP EKNO no need
                            process.setAmount(EODUtilitiy.getCurrencyField(line, 95, 115));
                            
                            process.setComAmountType(line.substring(115, 116));
                            process.setComAmount(EODUtilitiy.getCurrencyField(line, 116, 136));
                            
                            process.setTaxAmountType(line.substring(136, 137));
                            process.setTaxAmount(EODUtilitiy.getCurrencyField(line, 137, 157));
                            
                            process.setIkpAmountType(line.substring(157, 158));
                            process.setIkpAmount(EODUtilitiy.getCurrencyField(line, 158, 178));
                            
                            process.setBkpAmountType(line.substring(178, 179));
                            process.setBkpAmount(EODUtilitiy.getCurrencyField(line, 179, 199));
    
                            process.setBlkHesapSube(line.substring(199, 203));
                            process.setBlkHesapNo(EODUtilitiy.getBigDecimalValue(line,203, 211));
                            //(211,215) BLOKE HESAP EKNO no need
                                
                            process.setCariHesapSube(line.substring(215, 219));
                            process.setCariHesapNo(EODUtilitiy.getBigDecimalValue(line,219, 227));
                            //(227,231) CARI HESAP EKNO no need 
                            
                            try {
								process.setTaksitHesapSube(line.substring(231, 235));
								process.setTaksitHesapNo(EODUtilitiy.getBigDecimalValue(line,235, 243));
								process.setSrvAmount(EODUtilitiy.getCurrencyField(line, 247, 267));
							} catch (Exception e) {

							}
                            
                            process.setStatus("A");
							
						} catch (Exception e) {
							process.setStatus("E");
							process.setBankResponseDesc("Dosya format�na uymayan hatal� sat�r.");
						}
						
						session.save(process);
					}
				}

				session.flush();
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			} while (fileMap.get("FILE_LINE") != null);

			if (!fileNo.equals("0")) {
				
				if (sameFileResend(fileDate, fileNo)) {
					updateProcessedRecord(fileDate);
				}
				
				insertAccFileRecord(fileDate, fileNo);
				EODUtilitiy.callFundingBatch("MERCHANT_BLOCKED_ACC_BATCH");	
			}
			
		} catch (Exception e) {
			
			EODUtilitiy.sendMail( "�ye i� yeri bloke dosyas� y�kleme hatas�",e.getMessage());
			e.printStackTrace();
			throw e;
			
		}
		
		return oMap;
	}
	
	@SuppressWarnings("unchecked")
	private static Boolean sameFileResend(Date fileDate, BigDecimal fileNo) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		List<CrdMerchantAccountingFile> caf = session.createCriteria(CrdMerchantAccountingFile.class)
        	.add(Restrictions.ne("status", "D"))
        	.add(Restrictions.eq("fileDate", fileDate))
        	.add(Restrictions.eq("fileNo", fileNo)).list();
		
		return caf.size() > 0 ? true : false;
	}
	

	private static void updateProcessedRecord(Date fileDate) {

		String query1 = String.format("update bnspr.CRD_MERCHANT_ACC_FILE_PROCESS p " +
				"set p.status = 'E', p.bank_response_code = '0' ,p.bank_response_desc ='Dublicate Block Number.' " +
				"where p.status = 'A' and " +
				"exists (select p2.block_number " +
				"from bnspr.CRD_MERCHANT_ACC_FILE_PROCESS p2 " +
				"where p2.status = 'K' and p2.block_number = p.block_number)");
		
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
	}
	
	private static void insertAccFileRecord(Date fileDate, BigDecimal fileNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		CrdMerchantAccountingFile accountingFile = new CrdMerchantAccountingFile();
		
		accountingFile.setStatus("A");
		accountingFile.setFileDate(fileDate);
		accountingFile.setFileNo(fileNo);
		
		session.save(accountingFile);
		session.flush();
	}

	@GraymoundService("BNSPR_CRD_DELETE_WAITED_MERCHANT_FILE_RECORDS")
	public static GMMap deleteWaitedMerchanFileRecords(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		String query1 = String.format("update bnspr.CRD_MERCHANT_ACCOUNTING_FILE set status = 'E' where status = 'A'");
		session.createSQLQuery(query1).executeUpdate();
		
		String query2 = String.format("update bnspr.Crd_Merchant_Acc_File_Process set status = 'E' where status = 'A' and file_no in (select a.file_no from  bnspr.CRD_MERCHANT_ACCOUNTING_FILE a" +
				" where a.status = 'E')");
		session.createSQLQuery(query2).executeUpdate();
		
		return iMap;
	}

}

