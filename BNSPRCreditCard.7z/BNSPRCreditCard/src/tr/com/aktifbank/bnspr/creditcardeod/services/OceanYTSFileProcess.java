package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.CrdLksFileProcess;
import tr.com.aktifbank.bnspr.dao.CrdYtsFileProcess;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanYTSFileProcess {
		
	@GraymoundService("BNSPR_CRD_LOAD_OCEAN_YTS_FILE")
	public static GMMap loadYTSFile(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		
		try {
			
			long start = 1;
			long interval = 1000;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}
			
			String line = "";
	
			//Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
			String rowId = "";
			Session session = DAOSession.getSession("BNSPRDal");
			
			//delete waited records
			GMServiceExecuter.executeNT("BNSPR_CRD_DELETE_WAITED_YTS_RECORDS", iMap);
			
			do {
				int k = fileMap.getSize("FILE_LINE");
				
				for (int i = 0; i < k; i++) {
					
					line = fileMap.getString("FILE_LINE", i, "LINE");
					rowId = line.substring(0, 1);
					
				    if(rowId.equals("D")) {
						CrdYtsFileProcess fileProcess = new CrdYtsFileProcess();
						try {
							fileProcess.setStatus("A");
							
							fileProcess.setCustomerNumber(BigDecimal.valueOf(Double.parseDouble(line.substring(1, 11).trim())));
							fileProcess.setMainCardNumber(BigDecimal.valueOf(Double.parseDouble(line.substring(11,30).trim())));
							
							fileProcess.setPaymentAmount(BigDecimal.valueOf(Double.parseDouble(line.substring(30,48).trim())));
							fileProcess.setMainBalance(BigDecimal.valueOf(Double.parseDouble(line.substring(48,66).trim())));
							fileProcess.setCreditInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(66,84).trim())));
							fileProcess.setCashInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(84,102).trim())));
							fileProcess.setDueInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(102,120).trim())));
							fileProcess.setOverLimitInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(120,138).trim())));
							fileProcess.setYdktInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(138,156).trim())));
							fileProcess.setFee(BigDecimal.valueOf(Double.parseDouble(line.substring(156,174).trim())));
							fileProcess.setInstallCashDueInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(174,192).trim())));
							fileProcess.setInstallSaleDueInterest(BigDecimal.valueOf(Double.parseDouble(line.substring(192,210).trim())));
							fileProcess.setBsmv(BigDecimal.valueOf(Double.parseDouble(line.substring(210,228).trim())));
							fileProcess.setKkdf(BigDecimal.valueOf(Double.parseDouble(line.substring(228,246).trim())));
							
						} catch (Exception e) {
							fileProcess.setStatus("E");
							fileProcess.setBankResponseCode("0");
							fileProcess.setBankResponseDesc("Dosya format�na uymayan hatal� sat�r.");
						}
						
						session.save(fileProcess);
					}
				}
				
				session.flush();
				
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			} while (fileMap.get("FILE_LINE") != null);
			
			
			EODUtilitiy.callFundingBatch("CREDIT_CARD_YTS_BATCH");	
			
		} catch (Exception e) {
			EODUtilitiy.sendMail("Ocean YTS Dosya Y�kleme", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		
		return oMap;
	}


	@GraymoundService("BNSPR_CRD_DELETE_WAITED_YTS_RECORDS")
	public static GMMap deleteWaitedYTSRecords(GMMap iMap) {

		String query1 = String.format("update bnspr.crd_yts_file_process set status ='E' where status='A'");
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
		return iMap;
	}
	
	/**
	 * LKS limiti azaltilan ya da karti kapatilan musterilerin lks bildirimi yapilmasi icin
	 * gerekli datayi FTMden alarak kaydeder.
	 * 
	 * Dosya Formati(Alan,Baslangic,Uzunluk):<br>
	 * <li>RECORD FLAG			1	1
	 * <li>CUSTOMER NUMBER		2	10
	 * <li>MAIN CARD NUMBER		12	19
	 * <li>OLD CUSTOMER LIMIT	31	18
	 * <li>NEW CUTOMER LIMIT	49	18
	 * <li>LIMIT CHANGE DATE	67	8
	 * <li>LIMIT CHANGE TIME	75	6
	 * <li>LIMIT CHANGE REASON	81	2
	 * <li>LIMIT CLOSE DATE		83	8
	 * <li>LIMIT CLOSE TIME		91	6
	 * <li>LIMIT CLOSE REASON	97	2
	 * <li>LIMIT UPDATE USER	99	30
	 * 
	 * @author murat.el
	 * @since PY-7793, TY-4113
	 * @param iMap - FTM Bilgisi<br>
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_CRD_LOAD_OCEAN_LKS_FILE")
	public static GMMap loadLKSFile(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap fileMap = new GMMap();
		
		try {
			long start = 1;
			long interval = 1000;
			long end = interval;
			
			//Dosyadan kayitlari al
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			fileMap.putAll(EODUtilitiy.getLineFromFTM(start, end, ftmTransferId));

			//Okunan kayitlari isle, kayit yoksa cik.
			//Herhangi kayitta hata alinirsa en bastan islenecek sekilde yapildi. Ya Hep Ya Hic
			Session session = DAOSession.getSession("BNSPRDal");
			String line = null;
			// Kayitlari belirlenen adette(interval) cek
			CrdLksFileProcess crdLksFileProcess = null;
			while (fileMap.get("FILE_LINE") != null) {//1000lik map
				//Okunan kayitlari isle
				for (int index = 0; index < fileMap.getSize("FILE_LINE"); index++) {//her satir
					//Satiri al, satir uzunlugu dogru degilse hata ver
					line = fileMap.getString("FILE_LINE", index, "LINE");
					if (line == null || line.trim().length() == 0) {
						throw new Exception("Bos satir");
					}
					//Satirin tipini al:H-Header, D-Detail, F:Footer
					if ("D".equals(line.substring(0, 1))) {
						if (line.length() != 128) {
							throw new Exception("Satir uzunlugu hatali:" + line.length());
						}
						
						crdLksFileProcess = new CrdLksFileProcess();
						crdLksFileProcess.setCustomerNumber(BigDecimal.valueOf(Double.parseDouble(line.substring(1, 11).trim())));
						crdLksFileProcess.setMainCardNumber(line.substring(11,30).trim());
						crdLksFileProcess.setOldCustomerLimit(BigDecimal.valueOf(Double.parseDouble(line.substring(30,48).trim())));
						crdLksFileProcess.setNewCustomerLimit(BigDecimal.valueOf(Double.parseDouble(line.substring(48,66).trim())));
						crdLksFileProcess.setLimitChangeDate(line.substring(66,74).trim());
						crdLksFileProcess.setLimitChangeTime(line.substring(74,80).trim());
						crdLksFileProcess.setLimitChangeReason(line.substring(80,82).trim());
						crdLksFileProcess.setLimitCloseDate(line.substring(82,90).trim());
						crdLksFileProcess.setLimitCloseTime(line.substring(90,96).trim());
						crdLksFileProcess.setLimitCloseReason(line.substring(96,98).trim());
						crdLksFileProcess.setLimitUpdateUser(line.substring(98,128).trim());
						crdLksFileProcess.setStatus("0");//Kayit okundu
						
						//Hata Kontrolleri(TY-4113)
						StringBuilder hataAciklama = new StringBuilder();
						//Limit dosyasinda gelmemesi gereken artislar geldiginden pass gecilmesi saglandi.
						if (crdLksFileProcess.getNewCustomerLimit() != null &&
								BigDecimal.ZERO.compareTo(crdLksFileProcess.getNewCustomerLimit()) != 0 && 
								crdLksFileProcess.getOldCustomerLimit() != null &&
								crdLksFileProcess.getNewCustomerLimit().compareTo(crdLksFileProcess.getOldCustomerLimit()) > 0 ) {
							//Kayit hatali, mail aciklamasini olustur
							hataAciklama.append("\n");
							hataAciklama.append("LKS Dosyasinda Limit Artis Kaydi Mevcut");
							hataAciklama.append("\n");
							hataAciklama.append("Musteri No : ");
							hataAciklama.append(crdLksFileProcess.getCustomerNumber());
							//Durumu Guncelle
							crdLksFileProcess.setStatus("2");//Hatali
						}
						
						//Limit dosyasinda nedenler hatali geldiginden kontrol eklendi
						//01-Musteri Talebi, 02-Uye Degerlendirmesi
						if (StringUtils.isNotBlank(crdLksFileProcess.getLimitChangeReason()) &&
								!"01".equals(crdLksFileProcess.getLimitChangeReason()) &&
								!"02".equals(crdLksFileProcess.getLimitChangeReason())) {
							//Kayit hatali, mail aciklamasini olustur
							hataAciklama.append("\n");
							hataAciklama.append("LKS Dosyasinda Tenzil Nedeni Hatali");
							hataAciklama.append("\n");
							hataAciklama.append("Musteri No : ");
							hataAciklama.append(crdLksFileProcess.getCustomerNumber());
							hataAciklama.append("\n");
							hataAciklama.append("Gelen Bilgi : ");
							hataAciklama.append(crdLksFileProcess.getLimitChangeReason());
							//Degeri default ile guncelle
							crdLksFileProcess.setLimitChangeReason("01");//Hatali gelirse musteri talebi olarak degerlendir.
						}
						
						//01-Musteri Kaynakli, 02-Vefat, 03-Uye Kaynakli(Odeme Disi), 04-Uye Kaynakli(Odeme)
						if (StringUtils.isNotBlank(crdLksFileProcess.getLimitCloseReason()) &&
								!"01".equals(crdLksFileProcess.getLimitCloseReason()) &&
								!"02".equals(crdLksFileProcess.getLimitCloseReason()) &&
								!"03".equals(crdLksFileProcess.getLimitCloseReason()) &&
								!"04".equals(crdLksFileProcess.getLimitCloseReason())) {
							//Kayit hatali, mail aciklamasini olustur
							hataAciklama.append("\n");
							hataAciklama.append("LKS Dosyasinda Kapama Nedeni Hatali");
							hataAciklama.append("\n");
							hataAciklama.append("Musteri No : ");
							hataAciklama.append(crdLksFileProcess.getCustomerNumber());
							hataAciklama.append("\n");
							hataAciklama.append("Gelen Bilgi : ");
							hataAciklama.append(crdLksFileProcess.getLimitCloseReason());
							//Durumu Guncelle
							crdLksFileProcess.setLimitCloseReason("01");//Hatali gelirse musteri talebi olarak degerlendir.
						}
						
						//Mail Gonder
						if (hataAciklama.length() != 0) {
							lksHataMailGonder(hataAciklama.toString());
						}
									
						session.save(crdLksFileProcess);
					}
				}
				
				//Bir sonraki aralik grubunu al.
				fileMap.clear();
				start += interval;
				end += interval;
				fileMap.putAll(EODUtilitiy.getLineFromFTM(start, end, ftmTransferId));
			}
			//Kaydet
			session.flush();
		} catch (Exception e) {
			//Hata alinirsa bilgi maili gonder
			lksHataMailGonder(e.getMessage());
			//Hata firlat
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static void lksHataMailGonder(String mailBody) {
		GMMap mailMap = new GMMap();
		mailMap.put("MAIL_TO_PARAM", "LKS_HATA_BILDIR_MAIL");
		mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
		mailMap.put("MAIL_SUBJECT", "Ocean LKS Dosya Y�kleme Hata");
		mailMap.put("MAIL_BODY", mailBody);
		GMServiceExecuter.executeAsync("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
	}
}
