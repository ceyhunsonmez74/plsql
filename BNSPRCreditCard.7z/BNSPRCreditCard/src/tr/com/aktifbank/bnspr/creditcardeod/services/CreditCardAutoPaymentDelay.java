package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdCcAutoDelayPaymentFile;
import tr.com.aktifbank.bnspr.dao.CrdCcAutoPaymentFile;
import tr.com.aktifbank.bnspr.dao.CrdCcAutoPaymentPrcssLog;
import tr.com.aktifbank.bnspr.dao.CrdCcAutoPaymentProcess;
import tr.com.aktifbank.bnspr.dao.CrdCcDelayPaymentPrcssLog;
import tr.com.aktifbank.bnspr.dao.CrdCcDelayPaymentProcess;
import tr.com.aktifbank.bnspr.dao.CrdCcPaymentTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditCardAutoPaymentDelay {

	@GraymoundService("BNSPR_CRD_UPLOAD_CC_DELAY_DEBT_FILE")
	public static GMMap uploadCCAutoDelayDebtFile(GMMap iMap) throws Exception {
		
		try {
			
			long start = 1;
			long interval = 10;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				throw new GMRuntimeException(4425001, "FTM i�erik tablosunda i�lenecek kay�t bulunamad�.");
			}
			
			String line = "";
			String lineFlag = "";
			String fileOid = "";
			Session session = DAOSession.getSession("BNSPRDal");
			
			GMServiceExecuter.call("BNSPR_CRD_DELETE_WAITED_CC_DELAY_DEBT_RECORDS", iMap);
			
			do {
				int k = fileMap.getSize("FILE_LINE");
				
				for (int i = 0; i < k; i++) {
					
					line = fileMap.getString("FILE_LINE", i, "LINE");
					lineFlag = line.substring(0, 1);
					
					if (lineFlag.equals("H")) {
						
						if (fileOid.isEmpty()) {
							fileOid = insertHeader(line);	
						}else {
							throw new GMRuntimeException(4425002, "Dosyada tekrarlayan header sat�r� var.");
						}
						
					}else if (lineFlag.equals("D")) {
						
						insertDetail(session, line,fileOid);
						
					}if (lineFlag.equals("F")) {
						//no need to 
					}
				}
				
				session.flush();
				
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
				
			} while (fileMap.get("FILE_LINE") != null);
			
			//GMServiceExecuter.call("BNSPR_DELAY_PAYMENT_PROCESS", iMap);
		} catch (Exception e) {
			EODUtilitiy.sendMail("Kredi Kart� Gecikmeli Bor� Dosyas� Y�kleme Hatas�", e.getMessage());
			throw new GMRuntimeException(4425004, e.getMessage());
		}
		return iMap;
	}
	
	
	private static void insertDetail(Session session,String line, String fileOid) {

		CrdCcDelayPaymentProcess process = new CrdCcDelayPaymentProcess();
		
		process.setTxNo(BigDecimal.ZERO);
		process.setTxStatus("A");	
		process.setFileOid(fileOid);
		
		try {
			
			process.setCardNo(line.substring(1, 20).trim());
			process.setCurrencyCode(line.substring(20, 23));
			
			process.setAmount(BigDecimal.valueOf(Double.parseDouble(line.substring(24, 44))).divide(BigDecimal.valueOf(100)));
			
			process.setPaymentDate(line.substring(44,52));
			process.setAccountBranch1(BigDecimal.valueOf(Double.parseDouble(line.substring(52, 56))));
			process.setAccountNo1(BigDecimal.valueOf(Double.parseDouble(line.substring(56, 64))));
			process.setAccountNo2(BigDecimal.valueOf(Double.parseDouble(line.substring(64, 67))));
			
			process.setAccountBranch2(BigDecimal.valueOf(Double.parseDouble(line.substring(70,74))));
			
			process.setCustomerNo(BigDecimal.valueOf(Double.parseDouble(line.substring(74,124))));
			process.setReferansNo(line.substring(124, 174).trim());
			
		} catch (Exception e) {
			process.setTxStatus("E");
			process.setErrorCode("4425003");
			process.setErrorDesc("Hatal� format.");
		}
		
		session.save(process);
	}


	private static String insertHeader(String line) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		CrdCcAutoDelayPaymentFile file = new CrdCcAutoDelayPaymentFile();
		
		file.setSystemDate(line.substring(1, 9));
		file.setSystemTime(line.substring(9, 15));
		
		file.setSystemYear(line.substring(16, 20));
		file.setSystemDay(line.substring(20, 23));
		
		file.setTxStatus("A");
		
		session.save(file);
		session.flush();
		
		return file.getOid();
	}

	@GraymoundService("BNSPR_CRD_DELETE_WAITED_CC_DELAY_DEBT_RECORDS")
	public static GMMap deleteWaitedCcDelayDebtRecords (GMMap iMap) {

		String query1 = "update bnspr.CRD_CC_AUTO_DELAY_PAYMENT_FILE set TX_STATUS ='D' where TX_STATUS='A'";
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
		
		session.clear();
		
		String query2 = "update bnspr.CRD_CC_DELAY_PAYMENT_PROCESS set TX_STATUS ='D' where TX_STATUS='A'";
		session.createSQLQuery(query2).executeUpdate();
		
		return iMap;
	}
	
	@GraymoundService("BNSPR_DELAY_PAYMENT_PROCESS")
	public static GMMap paymentProcess(GMMap iMap) throws Exception {
		iMap.put("LAST_CHECK", true);
		String fileOid = getFile();
		
		if (fileOid == null) {
			EODUtilitiy.sendMail("Kredi kart� gecikmeli oto. bor� �deme", "Tahsil edilecek bor� dosyas� bulunamad�.");
		}
		
		GMMap fileMap = getDebt(fileOid);
		
		if (fileMap.get("LIST") == null) {
			EODUtilitiy.sendMail("Kredi kart� gecikmeli oto. bor� �deme", "Tahsil edilecek bor� bulunamad�.");
		}
		
		int k = fileMap.getSize("LIST");
		
		for (int i = 0; i < k; i++) {
			try {
				GMMap dMap = new GMMap();
				dMap.put("CustomerNo", 	fileMap.getString("LIST", i, "CUSTOMER_NO"));
				dMap.put("AccountNo", 	fileMap.getString("LIST", i, "ACCOUNT_NO_1"));
				dMap.put("CurrencyCode",fileMap.getString("LIST", i, "CURRENCY_CODE"));
				dMap.put("CardNo", 		fileMap.getString("LIST", i, "CARD_NO"));
				dMap.put("Amount", 		fileMap.getString("LIST", i, "AMOUNT"));
				dMap.put("PROCESS_OID", fileMap.getString("LIST", i, "OID"));
				dMap.put("ACCOUNT_BRANCH_1", fileMap.getString("LIST", i, "ACCOUNT_BRANCH_1"));
				
				dMap.put("LAST_CHECK", iMap.getBoolean("LAST_CHECK"));
				dMap.put("RequestType", "N");
				dMap.put("FUND_ACCOUNT_NO","0");
				dMap.put("CANCEL_TX_NO", "0");
				
				GMServiceExecuter.executeNT("BNSPR_CRD_CC_AUTO_DELAY_DEBT_PAYMENT", dMap);
			} catch (Exception e) {
				//No need to action
			}
		}
			
		if (iMap.getBoolean("LAST_CHECK")) {
			updateFile(fileOid);
		}

		EODUtilitiy.sendMail("Kredi kart� oto. bor� �deme", "Dosya i�leme job� tamamland�");
	   return iMap;
	}
	
	
	private static void updateFile(String fileOid) {
		
		String query1 = String.format("update bnspr.CRD_CC_AUTO_DELAY_PAYMENT_FILE set TX_STATUS ='M' where OID='%s'", fileOid);
		
		Session session = DAOSession.getSession("BNSPRDal");
		session.createSQLQuery(query1).executeUpdate();
	}

	
	private static String getFile() {
		String fetchQuery = "select OID from bnspr.CRD_CC_AUTO_DELAY_PAYMENT_FILE where tx_status ='A'";
		return	DALUtil.getResults(fetchQuery, "FILE").getString("FILE",0, "OID");
	}
	
	
	private static GMMap getDebt(String fileOid) {
		
		 String fetchQuery = String.format("select  OID,FILE_OID,CUSTOMER_NO,CARD_NO,AMOUNT,CURRENCY_CODE,PAYMENT_DATE,ACCOUNT_NO_1,ACCOUNT_BRANCH_1" +
		 									" from bnspr.CRD_CC_DELAY_PAYMENT_PROCESS p where p.tx_status = 'A' " +
		 									" and p.file_oid = '%s'",
		 								  fileOid);
		 
		final String tableName = "LIST";
		
		return  DALUtil.getResults(fetchQuery, tableName);
	}

	
	


	@GraymoundService("BNSPR_CRD_CC_AUTO_DELAY_DEBT_PAYMENT")
	public static GMMap payAutoCreditCartDebt(GMMap iMap) throws Exception {
		BigDecimal txNo = BigDecimal.ZERO;
		String processOid = iMap.getString("PROCESS_OID");
		BigDecimal balance = BigDecimal.ZERO;
		BigDecimal accountNo = BigDecimal.ZERO;
		BigDecimal amount = BigDecimal.ZERO;
		try {
			
			accountNo = iMap.getBigDecimal("AccountNo");
			amount = iMap.getBigDecimal("Amount");
					//BNSPR_WEBEXT_OCEAN_GET_CUSTOMER_ACCOUNTS
			
			balance = checkBalance(accountNo);
			txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			if(amount.compareTo(balance)<=0){
				
				iMap.put("TX_NO", txNo);
				doPayment(iMap,accountNo, amount);
				amount= BigDecimal.ZERO;
			}else if(amount.compareTo(balance)>0){
				if(balance.compareTo(BigDecimal.ZERO)>0){
					iMap.put("TX_NO", txNo);
					doPayment(iMap,accountNo, balance);
					amount = amount.subtract(balance);
					amount = accountPayment(iMap,amount);
				}else{
					amount = accountPayment(iMap,amount);
				}
				
				
			}
			
			String aciklama="";
			if(amount.compareTo(BigDecimal.ZERO)<=0){
				aciklama = "Ba�ar�l� tahsilat.";
			}else if(amount.compareTo(BigDecimal.ZERO)>0 && amount.compareTo(iMap.getBigDecimal("Amount"))<0){
				aciklama = "K�smi Ba�ar�l� tahsilat.";
			}else{
				aciklama = "Tahsil edilecek bakiye yok";
			}
			updateDebtProcessRecord(processOid, txNo,"M","0",aciklama);
			insertProcessLog(processOid, BigDecimal.ZERO, txNo, "M", aciklama);
			
			return iMap;
			
		} catch (Exception e) {

			String eCode = "99";
			String txStatus = "A";
			
			if (e instanceof GMRuntimeException) {
				eCode = String.valueOf(((GMRuntimeException) e).getCode());
			}
			if (iMap.getBoolean("LAST_CHECK")) {
				//son tahsilat denemesi ise
				txStatus = "E";
			}
			
			updateDebtProcessRecord(processOid, txNo,txStatus, eCode, e.getMessage());
			insertProcessLog(processOid, balance, txNo, "E", eCode + " :: " +e.getMessage());
			
			throw e;
		}
	}

	
	
	
	private static void insertProcessLog(String processOid,
			BigDecimal totalBalance, BigDecimal txNo, String processStatus,
			String processDesc) {
		
		GMMap logMap = new GMMap();
		logMap.put("PROCESS_DESC", processDesc);
		logMap.put("PROCESS_OID", processOid);
		logMap.put("PROCESS_STATUS", processStatus);
		logMap.put("ACCOUNT_BALANCE", totalBalance);
		logMap.put("TX_NO", txNo);
		GMServiceExecuter.call("BNSPR_CRD_CC_DELAY_PAYMENT_INSERT_PROCESS_LOG", logMap);
		
	}

	@GraymoundService("BNSPR_CRD_CC_DELAY_PAYMENT_INSERT_PROCESS_LOG")
	public static GMMap  insertCCDebtPaymentProcessLog(GMMap iMap) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		CrdCcDelayPaymentPrcssLog log = new CrdCcDelayPaymentPrcssLog();
		
		log.setProcessDesc(EODUtilitiy.getStringValue(iMap, "PROCESS_DESC", 300));
		log.setProcessOid(iMap.getString("PROCESS_OID"));
		log.setProcessStatus(iMap.getString("PROCESS_STATUS"));
		log.setTotalAccountBalance(iMap.getBigDecimal("ACCOUNT_BALANCE"));
		log.setTxNo(iMap.getBigDecimal("TX_NO"));
		
		session.save(log);
		session.flush();
		
		return iMap;
	}

	private static void  updateDebtProcessRecord(String oID, BigDecimal txNo,
			String txStatus, String errorCode, String errorDesc) {
		
		GMMap pMap = new GMMap();
		pMap.put("OID", oID);
		pMap.put("TX_NO", txNo);
		pMap.put("TX_STATUS", txStatus);
		pMap.put("ERROR_CODE", errorCode);
		pMap.put("ERROR_DESC", errorDesc);
		
		GMServiceExecuter.call("BNSPR_CRD_CC_UPDATE_AUTO_DELAY_DEBT_PAYMENT_RECORD", pMap);
	}
	

	@GraymoundService("BNSPR_CRD_CC_UPDATE_AUTO_DELAY_DEBT_PAYMENT_RECORD")
	public static GMMap p(GMMap iMap) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		CrdCcDelayPaymentProcess process = (CrdCcDelayPaymentProcess) session.createCriteria(CrdCcDelayPaymentProcess.class)
				.add(Restrictions.eq("oid", iMap.getString("OID"))).uniqueResult();
		
		process.setTxNo(iMap.getBigDecimal("TX_NO"));
		process.setTxStatus(iMap.getString("TX_STATUS"));
		process.setErrorCode(EODUtilitiy.getStringValue(iMap, "ERROR_CODE", 10));
		process.setErrorDesc(EODUtilitiy.getStringValue(iMap, "ERROR_DESC", 300));
		
		session.update(process);
		session.flush();
		
		return iMap;
	}

	private static BigDecimal checkBalance(BigDecimal account) throws SQLException {
		
		GMMap bMap = new GMMap();
		bMap.put("HESAP_NO", account);
		bMap.put("KMHSIZ", "E");
		bMap =GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", bMap);
		
		return bMap.getBigDecimal("KULLANILABILIR_BAKIYE");
		
	}


	public static GMMap doPayment(GMMap iMap, BigDecimal accountNo, BigDecimal amount) {
		
	
		//iMap.put("CollectedAmount", collectedAmount);
		
		//if (collectedAmount.compareTo(BigDecimal.ZERO)>0) {
			
			GMMap ocMap = new GMMap();

			ocMap.put("ACCOUNT_BRANCH", iMap.getString("ACCOUNT_BRANCH_1"));
			ocMap.put("ACCOUNT_NO", 	accountNo);
			ocMap.put("REFERENCE_NO", 	iMap.getString("TX_NO"));
			ocMap.put("CARD_NO", 		iMap.getString("CardNo"));
			ocMap.put("TERMINAL_ID", 	"9999999");
			ocMap.put("PAYMENT_TYPE", 	OceanConstants.Payment_Automatic);
			ocMap.put("REQUEST_TYPE",	OceanConstants.Request_Normal);
			ocMap.put("TXN_AMOUNT",		amount);
			ocMap.put("TERMINAL_TYPE",	"Crt");
			ocMap.put("TXN_CURR",		iMap.getString("CurrencyCode"));
			ocMap.put("TXN_DESC",		"Otomatik kredi kart� bor� �demesi.");

			ocMap = GMServiceExecuter.call("BNSPR_OCEAN_MAKE_CARD_PAYMENT", ocMap);
			
			if (ocMap.getInt("RETURN_CODE") != OceanConstants.Result_Succesful) {
				throw new GMRuntimeException(4425205, "Ocean Servis Hatas�: "+ocMap.getString("ERROR_DETAIL"));
			}
			GMMap sMap = startTrx(iMap,accountNo,amount,ocMap);
	//	}else {
	//		throw new GMRuntimeException(4425215, "Bakiye yetersiz.");
	//	}
		
		return iMap;
	}
	
	private static GMMap startTrx(GMMap iMap, BigDecimal accountNo, BigDecimal amount,GMMap ocMap) {
		
		try {
			saveTrx(iMap,accountNo,amount);	
			GMMap trxMap = new GMMap();
			trxMap.put("TRX_NAME", "4425");
			trxMap.put("TRX_NO", iMap.getString("TX_NO"));
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", trxMap);
			
		} catch (Exception e) {
			GMMap cMap = new GMMap();
			BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			cMap.put("ACCOUNT_BRANCH", iMap.getString("ACCOUNT_BRANCH_1"));
			cMap.put("ACCOUNT_NO", 	accountNo);
			cMap.put("REFERENCE_NO", 	txNo);
			cMap.put("CARD_NO", 		iMap.getString("CardNo"));
			cMap.put("TERMINAL_ID", 	"9999999");
			cMap.put("PAYMENT_TYPE", 	OceanConstants.Payment_Automatic);
			cMap.put("REQUEST_TYPE",	OceanConstants.Request_Cancel);
			cMap.put("TXN_AMOUNT",		amount);
			cMap.put("ORIGINAL_RRN",    ocMap.getString("RRN"));
			cMap.put("TERMINAL_TYPE",	"Crt");
			cMap.put("TXN_CURR",		iMap.getString("CurrencyCode"));
			cMap.put("TXN_DESC",		"Otomatik kredi kart� bor� �demesi iptali.");

			cMap = GMServiceExecuter.call("BNSPR_OCEAN_MAKE_CARD_PAYMENT", cMap);
			
			throw new GMRuntimeException(4425202,e.getMessage());
		}
		
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", "0");
		oMap.put("RESPONSE_DATA", "Ba�ar�l� i�lem.");
		oMap.put("ContractNo", iMap.getString("TX_NO"));
		
		/*BigDecimal collectedAmount =  (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_trn4425.tahsil_tutar(?)}", 
										Types.NUMERIC, 
										iMap.getBigDecimal("TX_NO"));
		
		oMap.put("CollectionAmount", collectedAmount);*/
		
		return oMap;
	}


	private static Session saveTrx(GMMap iMap, BigDecimal accountNo, BigDecimal amount) {
		Session session = DAOSession.getSession("BNSPRDal");
						
		CrdCcPaymentTx ccPaymentTx = new CrdCcPaymentTx();
		ccPaymentTx.setTxStatus("A");
		ccPaymentTx.setReqType(iMap.getString("RequestType"));
		ccPaymentTx.setTxNo(iMap.getBigDecimal("TX_NO"));
		ccPaymentTx.setCollectedAmount(BigDecimal.ZERO);
		ccPaymentTx.setAccountNo(accountNo);
		ccPaymentTx.setCardNo(iMap.getString("CardNo"));
		
		ccPaymentTx.setCustomerNo(iMap.getBigDecimal("CustomerNo"));
		ccPaymentTx.setDebtAmount(amount);
		ccPaymentTx.setRrn(iMap.getString("RRN"));
		
		ccPaymentTx.setOrjinalRrn(iMap.getString("OriginalRRN"));
		ccPaymentTx.setCancelTxNo(iMap.getBigDecimal("CANCEL_TX_NO"));
		ccPaymentTx.setFundAccount(iMap.getBigDecimal("FUND_ACCOUNT_NO"));
		ccPaymentTx.setDkAccountNo(BigDecimal.ZERO);
		ccPaymentTx.setFundAccountBalance(BigDecimal.ZERO);
		ccPaymentTx.setCurrencyCode(iMap.getString("CurrencyCode"));
		
//		ccPaymentTx.setBankResponseCode(iMap.getString("RESPONSE"));
//		ccPaymentTx.setBankResponseDesc(iMap.getString("RESPONSE_DATA"));
	
		session.save(ccPaymentTx);
		session.flush();
		return session;
	}
	/*
	
	@GraymoundService("BNSPR_CRD_CC_GET_AUTO_DEBT_PAYMENT_LIST")
	public static GMMap getCCAoutoPaymentLogList(GMMap iMap) {
		
		 String query = "select M.MUSTERI_NO as CUSTOMER_NO, M.ADI||' '||M.SOYADI as NAME, P.CARD_NO, P.PAYMENT_DATE as LAST_PAYMENT_DATE, " +
		 									"F.SYSTEM_DATE as FILE_DATE, F.SYSTEM_TIME as FILE_TIME, P.AMOUNT as DEBT_AMOUNT, nvl(T.COLLECTED_AMOUNT,0) AS COLLECTION_AMOUNT, " +
		 									"CASE WHEN P.TX_STATUS = 'M' then 'Tahsilat' when P.TX_STATUS = 'A' then 'Bekliyor' " +
		 									"when P.TX_STATUS ='E' then 'Hata' when P.TX_STATUS ='D' then 'Islenmemis' else 'Belirsiz' end as TX_STATUS, " +
		 									"P.ERROR_DESC as ERROR_DESC, P.ACCOUNT_NO_1 as OTO_ACCOUNT_NO, P.REFERANS_NO as REFERANS_NO, F.OID as FILE_OID, P.OID as PROCESS_OID " +
		 									"from BNSPR.CRD_CC_AUTO_PAYMENT_FILE f, " +
		 									"bnspr.gnl_musteri m, " +
		 									"BNSPR.CRD_CC_AUTO_PAYMENT_PROCESS p, BNSPR.CRD_CC_PAYMENT_TX t " +
		 									"where F.OID = P.FILE_OID and T.TX_NO(+) = P.TX_NO and P.CUSTOMER_NO = M.MUSTERI_NO ";
		 								
		boolean isParamSet = false;
		
		if (iMap.get("CUSTOMER_NO") != null && iMap.getString("CUSTOMER_NO").length() > 0) {
			query = query + String.format(" and P.CUSTOMER_NO = %s ", iMap.getBigDecimal("CUSTOMER_NO"));
			isParamSet = true;
		}
		
		if (iMap.get("FILE_DATE") != null && iMap.getString("FILE_DATE").length() > 0) {
			query = query + String.format(" and f.SYSTEM_DATE = '%s' ", iMap.getString("FILE_DATE"));
			isParamSet = true;
		}
		
		if (iMap.get("CARD_NO") != null && iMap.getString("CARD_NO").length() > 0) {
			query = query + String.format(" and P.CARD_NO = '%s' ", iMap.getString("CARD_NO"));
			isParamSet = true;
		}
		 
		if (!isParamSet) {
			throw new GMRuntimeException(87, "Sorgu kriterlerinden en az biri girilmelidir.");
		}
		
		query = query + "order by F.REC_DATE desc,P.REC_DATE desc";
		
		GMMap outMap =  DALUtil.getResults(query, "DEBT_LIST");
		
		if (outMap.getSize("DEBT_LIST") == 0) {
			throw new GMRuntimeException(88, "Kay�t bulunamad�.");
		}
		
		return outMap;
	}
	
	*/
	/*@GraymoundService("BNSPR_CRD_CC_GET_AUTO_DEBT_PAYMENT_DETAIL_LOG_LIST")
	public static GMMap getCCAoutoPaymentDetailLogList(GMMap iMap) {
		
		 String query =String.format("select nvl(f.tx_no, 0) as TX_NO, nvl(L.RRN, 0) as RRN, " +
		 		"nvl(L.PROVISION_CODE, 0) as PROVISION_CODE, " +
		 		"CASE WHEN f.PROCESS_STATUS='M' then 'Tahsil' " +
		 		"when f.PROCESS_STATUS = 'A' then 'Bekliyor' " +
		 		"when f.PROCESS_STATUS ='E' then 'Hata' " +
		 		"when f.PROCESS_STATUS ='D' then 'Islenmemis' else 'Belirsiz' end as TX_STATUS, " +
		 		"nvl(f.total_account_balance,0) as ACCOUNT_BALANCE, " +
		 		"to_char(f.REC_DATE,'yyyy-mm-dd HH24:MI') as REC_DATE, f.process_desc as TX_STATUS_DESC, f.PROCESS_OID " +
		 		"from BNSPR.CRD_CC_AUTO_PAYMENT_PROCESS p, bnspr.CRD_CC_AUTO_PAYMENT_PRCSS_LOG f, BNSPR.CRD_CC_DEBTPAYMENT_OCEAN_LOG L " +
		 		"WHERE P.OID = f.process_oid and L.TX_NO (+) = f.tx_no " +
		 		"and P.OID = '%s' order by rec_date desc", iMap.getString("PROCESS_OID"));
		 								
		
		GMMap outMap =  DALUtil.getResults(query, "LOG_LIST");
		
		if (outMap.getSize("LOG_LIST") == 0) {
			throw new GMRuntimeException(88, "Kay�t bulunamad�.");
		}
		
		return outMap;
	}*/
	public static BigDecimal accountPayment(GMMap iMap, BigDecimal amount){
		BigDecimal accountNo=BigDecimal.ZERO;
		BigDecimal balance = BigDecimal.ZERO;
		BigDecimal txNo = BigDecimal.ZERO;
		try {
			GMMap aMap = new GMMap();
			aMap.put("CustomerNo", iMap.getBigDecimal("CustomerNo"));
			aMap = GMServiceExecuter.call("BNSPR_WEBEXT_OCEAN_GET_CUSTOMER_ACCOUNTS", aMap);
			for (int i = 0; i < aMap.getSize("AccountList"); i++) {
				try{
				accountNo = aMap.getBigDecimal("AccountList",i,"AccountNo");
				balance = checkBalance(accountNo);
				if(balance.compareTo(BigDecimal.ZERO)>0){
					if(amount.compareTo(balance)<=0){
						txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
						iMap.put("TX_NO", txNo);
						doPayment(iMap,accountNo, amount);
						amount=BigDecimal.ZERO;
						break;
					}else{
						txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
						iMap.put("TX_NO", txNo);
						doPayment(iMap,accountNo, balance);
						amount = amount.subtract(balance);
					}
				}
				}
				catch(Exception e){
					continue;
				}
			}
			return amount;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(87, "accountPayment Hata");
		}
	}
	

	
	
}
