package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.axis.utils.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.jsoup.helper.StringUtil;

import tr.com.aktifbank.bnspr.dao.CrdCcFundAccount;
import tr.com.aktifbank.bnspr.dao.CrdCcFundingFileProcess;
import tr.com.aktifbank.bnspr.dao.CrdCcNoFundaccountProcess;
import tr.com.aktifbank.bnspr.dao.LksFtpGelenDosya;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditFundingProcess implements OceanMapKeys{
    
    public static final String DEBIT  = "D";
    public static final String CREDIT = "C";
    private static final Logger logger = Logger.getLogger(CreditFundingProcess.class);
    
    @GraymoundService("BNSPR_CC_LOAD_CREDIT_FUNDING_FILE")
    public static GMMap loadCreditFundingFile(GMMap iMap) throws Exception {
        
        /**
         * Format : KartNo|Tarih|Art�Tutar|D�vizKodu|EskiKartNo
         * 0005223475213048188|20130920|000000000007602000|949|0000000000000000000 KartNo: As�l kart no, ek kartlar i�in
         * ek kart�n ba�l� oldu�u as�l kart numaras�. VARCHAR2(19 ) D�vizKodu: ocean d�viz kodlar�. NUMBER(3) Tarih :
         * format� olarak yyyymmdd bekliyoruz. NUMBER(8) Art�Tutar : tutar*100 olarak bekliyoruz.NUMBER(18) EskiKartNo:
         * EskiKartNo alan� bo� gelmemeli, bu bilgi yok ise s�f�r bekliyoruz. VARCHAR2(19 )
         **/
        
        GMMap oMap = new GMMap();
        Connection connection = EODUtilitiy.getDSConnection();
        Statement statement = connection.createStatement();
        try{
            
            long start = 1;
            long interval = 1000;
            long end = interval;
            
            BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
            
            GMMap fileMap = EODUtilitiy.getLineFromFTM(start , end , ftmTransferId);
            
            if (fileMap.get("FILE_LINE") == null){
                return oMap;
            }
            
            String line = "";
            Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
            
            // delete waited records
            GMServiceExecuter.executeNT("BNSPR_CRD_DELETE_WAITED_FUNDING_RECORDS" , iMap);
            
            GMMap insertMap = new GMMap();
            int insertI = 0;
            
            do{
                int k = fileMap.getSize("FILE_LINE");
                
                for (int i = 0; i < k; i++){
                    
                    String cardNo = null;
                    String exCardNo;
                    BigDecimal accountNo = BigDecimal.ZERO;
                    String status = "A";
                    BigDecimal amount = BigDecimal.ZERO;
                    String currencyCode = "";
                    String processDate = "19000101";
                    String errorCode = "";
                    String errorDesc = "";
                    String debitCreditSign = "";
                    String debitCreditFlag = "";
                    
                    try{
                        
                        line = fileMap.getString("FILE_LINE" , i , "LINE");
                        StringTokenizer strLine = new StringTokenizer(line , "|");
                        cardNo = StringUtils.stripStart(strLine.nextToken().trim(),"0");
                        processDate = strLine.nextToken().trim();
                        debitCreditSign = strLine.nextToken().trim();
                        if (debitCreditSign.equals("-")){
                            debitCreditFlag = CreditFundingProcess.DEBIT;
                        } else
                            if (debitCreditSign.equals("+")){
                                debitCreditFlag = CreditFundingProcess.CREDIT;
                            }
                        
                        amount = BigDecimal.valueOf(Long.valueOf(strLine.nextToken())).divide(BigDecimal.valueOf(100));
                        currencyCode = crHs.get(strLine.nextToken()).toString();
                        exCardNo = (strLine.nextToken().trim());
                        
                        accountNo = getCardFundingAccount(cardNo);
                        
                        if (accountNo == BigDecimal.ZERO){
                            
                            accountNo = getCardFundingAccount(exCardNo.toString());
                            
                            if (accountNo == BigDecimal.ZERO){
                                errorCode = "10";
                                errorDesc = "Fon hesab� bulunamad�.";
                                status = "E";
                                GMMap noFundMap = new GMMap();
                                noFundMap.put("TX_NO" , BigDecimal.ZERO);
                                noFundMap.put("TX_STATUS" , "A");
                                noFundMap.put("FILE_PROCESS_DATE" , processDate);
                                noFundMap.put("AMOUNT" , amount);
                                noFundMap.put("DEBIT_CREDIT_FLAG" , debitCreditFlag);
                                noFundMap.put("FTM_TRANSFER_ID" , ftmTransferId);
                                noFundMap.put("CURRENCY_CODE" , currencyCode);
                                
                                GMServiceExecuter.executeNT("BNSPR_CRD_CC_NO_FUND_ACCOUNT_PROCESS" , noFundMap);
                                
                            } else{
                                insertMap.put("INSERT_LIST" , insertI , "EX_CARD_NO" , exCardNo);
                                insertMap.put("INSERT_LIST" , insertI , "CARD_NO" , cardNo);
                                insertMap.put("INSERT_LIST" , insertI , "ACCOUNT_NO" , accountNo);
                                insertI = insertI + 1;
                            }
                        }
                        
                    } catch (Exception e){
                        errorCode = "20";
                        errorDesc = String.valueOf(i + 1) + " numaral� sat�rda format hatas�.";
                        status = "E";
                        e.printStackTrace();
                    }
                    
                    String insertQ =
                            String.format("insert into bnspr.crd_cc_funding_file_process"
                                    + " (OID, PROCESS_STATUS,PROCESS_DATE,ACCOUNT_NO,CURRENCY_CODE,AMOUNT,ERROR_CODE,ERROR_DESC,DEBIT_CREDIT_FLAG,CARD_NO)"
                                    + " VALUES('%s','%s',to_date('%s','yyyymmdd'),%s,'%s',%s,'%s','%s','%s','%s')" , EODUtilitiy.getOid() , status , processDate , accountNo , currencyCode , amount ,
                                    errorCode , errorDesc , debitCreditFlag , StringUtils.stripStart(cardNo , "0"));
                    
                    statement.addBatch(insertQ);
                    
                }
                
                statement.executeBatch();
                fileMap.clear();
                start = interval + start;
                end = interval + end;
                fileMap = EODUtilitiy.getLineFromFTM(start , end , ftmTransferId);
                
            } while (fileMap.get("FILE_LINE") != null);
            
            if (insertMap.getSize("INSERT_LIST") > 0){
                GMServiceExecuter.executeAsync("BNSPR_CC_DEFINE_FUNDING_ACCOUNT_FOR_NEW_CARD" , insertMap);
            }
            
            EODUtilitiy.callFundingBatch("CREDIT_CARD_FUNDING_BATCH_NO");
            
        } catch (Exception e){
            
            EODUtilitiy.sendMail("Ocean M�stakriz Dosya Y�kleme" , e.getMessage());
            e.printStackTrace();
            throw e;
            
        } finally{
            
            if (connection != null){
                connection.close();
            }
            
            if (statement != null){
                statement.close();
            }
            
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_CC_DEFINE_FUNDING_ACCOUNT_FOR_NEW_CARD")
    public static GMMap defineFundingAccountfForNewCard(GMMap insertMap) {
        GMMap outMap = new GMMap();
        GMMap dMap = new GMMap();
        
        int s = insertMap.getSize("INSERT_LIST");
        for (int i = 0; i < s; i++){
           // dMap.put("CARD_NO" , insertMap.getString("INSERT_LIST" , i , "EX_CARD_NO"));
           // GMServiceExecuter.call("BNSPR_CC_CANCEL_FUNDING_ACCOUNT" , dMap);
            
            dMap.put("CARD_NO" , insertMap.getString("INSERT_LIST" , i , "CARD_NO"));
            dMap.put("ACCOUNT_NO" , insertMap.getString("INSERT_LIST" , i , "ACCOUNT_NO"));
            GMServiceExecuter.call("BNSPR_CC_INSERT_FUNDING_ACCOUNT" , dMap);
        }
        return outMap;
    }
    
    private static BigDecimal getCardFundingAccount(String cardNo) {
        Session session = DAOSession.getSession("BNSPRDal");
        CrdCcFundAccount fundAccount;
        if(!StringUtil.isNumeric(cardNo)){
        	fundAccount = (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("tokenizedCardNo" , cardNo)).uniqueResult();
        }else{
        fundAccount = (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("cardNo" , BigDecimal.valueOf(Long.valueOf(cardNo)))).uniqueResult();
		}
        if (fundAccount == null){
            return BigDecimal.ZERO;
        } else{
            return fundAccount.getFundAccount();
        }
    }
    
    @GraymoundService("BNSPR_CRD_DELETE_WAITED_FUNDING_RECORDS")
    public static GMMap deleteWaitedFundRecords(GMMap iMap) {
        
        String query1 = String.format("update bnspr.crd_cc_funding_file_process set process_status = 'E' where process_status = 'A'");
        Session session = DAOSession.getSession("BNSPRDal");
        session.createSQLQuery(query1).executeUpdate();
        
        return iMap;
    }

	@GraymoundService("BNSPR_CC_INSERT_FUNDING_ACCOUNT")
	public static GMMap insertCardFundingAccount(GMMap iMap) {

		String tokenizedCardNo = "";
		if (!isNumeric(iMap.getString("CARD_NO"))) {
			tokenizedCardNo = iMap.getString("CARD_NO");
			iMap.put("CARD_NO", BnsprOceanCommonFunctions.getClearCardNo(iMap.getString("CARD_NO")));
		}
		controlBeforeInsertCardFundingAccount(iMap);

		if (iMap.getString("RESULT").equals("1")) {

			Session session = DAOSession.getSession("BNSPRDal");
			CrdCcFundAccount fundAccount = new CrdCcFundAccount();
			fundAccount.setStatus("1");
			fundAccount.setCardNo(iMap.getBigDecimal("CARD_NO"));
			fundAccount.setFundAccount(iMap.getBigDecimal("ACCOUNT_NO"));
			fundAccount.setTokenizedCardNo(!StringUtils.isEmpty(tokenizedCardNo) ? tokenizedCardNo : BnsprOceanCommonFunctions.getTokenizedCardNo(iMap.getString("CARD_NO")));

			session.save(fundAccount);
			session.flush();

			return iMap;

		}
		else {
			return iMap;
		}

	}
    
    private static void controlBeforeInsertCardFundingAccount(GMMap iMap) {
        
        Session session = DAOSession.getSession("BNSPRDal");
      
        CrdCcFundAccount fundAccount =
                (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("cardNo" , iMap.getBigDecimal("CARD_NO"))).uniqueResult();
        
        iMap.put("RESULT" , "1");
        
        if (fundAccount == null){
            
            fundAccount =
                    (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("fundAccount" , iMap.getBigDecimal("ACCOUNT_NO")))
                            .uniqueResult();
            
            if (fundAccount != null){
                iMap.put("RESULT" , "0");
                iMap.put("RESULT_DESC" , "Account is used for an other credit card.");
            }
        } else{
            iMap.put("RESULT" , "0");
            iMap.put("RESULT_DESC" , "Card already has a funding account.");
        }
        
    }
    
    @GraymoundService("BNSPR_CC_CANCEL_FUNDING_ACCOUNT")
    public static GMMap cancelCardFundingAccount(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        CrdCcFundAccount fundAccount =
                (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("cardNo" , iMap.getBigDecimal("CARD_NO"))).uniqueResult();
        
        if (fundAccount == null){
            oMap.put("RESULT" , "0");
            oMap.put("RESULT_DESC" , "No record found.");
        } else{
            fundAccount.setStatus("0");
            session.save(fundAccount);
            session.flush();
            oMap.put("RESULT" , "1");
            oMap.put("RESULT_DESC" , "Transaction is completed.");
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_CC_GET_CARD_FUNDING_ACCOUNT")
    public static GMMap getCardFundingAccount(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        CrdCcFundAccount fundAccount;
        String cardNo=iMap.getString("CARD_NO");
        if(!StringUtil.isNumeric(cardNo)){
        	fundAccount = (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("tokenizedCardNo" , cardNo)).uniqueResult();
        }else{
        	fundAccount = (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("cardNo" , BigDecimal.valueOf(Long.valueOf(cardNo)))).uniqueResult();
		}
       // CrdCcFundAccount fundAccount =
       //         (CrdCcFundAccount) session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status" , "1")).add(Restrictions.eq("cardNo" , iMap.getBigDecimal("CARD_NO"))).uniqueResult();
        
        if (fundAccount == null){
            oMap.put("RESULT" , "0");
            oMap.put("RESULT_DESC" , "No record found.");
            oMap.put("ACCOUNT_NO" , "0");
        } else{
            oMap.put("RESULT" , "1");
            oMap.put("RESULT_DESC" , "Transaction is completed.");
            oMap.put("ACCOUNT_NO" , fundAccount.getFundAccount());
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_CRD_CC_NO_FUND_ACCOUNT_PROCESS")
    public static GMMap noFundAccountProcess(GMMap iMap) {
        GMMap oMap = new GMMap();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            
            CrdCcNoFundaccountProcess noFund = new CrdCcNoFundaccountProcess();
            noFund.setAmount(iMap.getBigDecimal("AMOUNT"));
            noFund.setCardNo(iMap.getString("CARD_NO"));
            noFund.setCurrencyCode(iMap.getString("CURRENCY_CODE"));
            noFund.setDebitCreditFlag(iMap.getString("DEBIT_CREDIT_FLAG"));
            
            noFund.setFileProcessDate(dateFormat.parse(iMap.getString("FILE_PROCESS_DATE")));
            noFund.setFtmTransferId(iMap.getBigDecimal("FTM_TRANSFER_ID"));
            noFund.setTxNo(iMap.getBigDecimal("TX_NO"));	
            noFund.setTxStatus(iMap.getString("TX_STATUS"));
            session.save(noFund);
            session.flush();
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
 
    
    
	@GraymoundService("BNSPR_CRD_CC_FUND_BALANCE_CONVERSION_TRANSFER_TO_CARD")
	public static GMMap fundBalanceConversionTransferToCard(GMMap iMap) throws SQLException {
		
		GMMap oMap = new GMMap();
		
		String procStr= "{? = call PKG_CARD.GETCONVERSIONLIST(?)}";
		
		Object [] inputValues = new Object [2];
		inputValues[0]=BnsprType.STRING;
		inputValues[1]="F";
		
		GMMap txMap = (GMMap) DALUtil.callOracleRefCursorFunction(procStr, LIST, inputValues);
		
		int s = txMap.getSize(LIST);
		
		if (txMap.getSize(LIST) == 0) {
			throw new GMRuntimeException(445801, "Kay�t Bulunamad�.");
		}
		
		boolean doCardTransfer = true;
		
		if (iMap.containsKey("CARD_TRANSFER") && iMap.getString("CARD_TRANSFER").equals("0")) {
			doCardTransfer = false;
		}
		
		boolean doAccounting = true;
		
		if (iMap.containsKey("DO_ACCOUNTING") && iMap.getString("DO_ACCOUNTING").equals("0")) {
			doAccounting = false;
		}
		
		String otc = EODUtilitiy.getGlobalParam("TFF_4448_FIN_ADJUSTMENT").replace("?", "~");
		
		for (int i = 0; i < s; i++) {
			
			if (doCardTransfer) {
				GMMap cardMap = new GMMap();
				
				cardMap.put(TXN_AMOUNT, txMap.getString(LIST, i, "ACCOUNT_BALANCE"));
				cardMap.put(CARD_NO, txMap.getString(LIST, i , CARD_NO));
				cardMap.put(TX_NO, txMap.getString(LIST, i , TX_NO));
				cardMap.put("OTC", otc);	
			
				GMServiceExecuter.call("BNSPR_CRD_CC_FUND_BALANCE_TRANSFER_TO_CARD", cardMap);
			}
			
			if (doAccounting) {
				
				GMMap accdMap = new GMMap();
				accdMap.put(TX_NO, txMap.getBigDecimal(LIST, i, TX_NO));
				GMServiceExecuter.executeNT("BNSPR_CRD_CC_FUND_BALANCE_TRANSFER_TO_CARD_ACCOUNTING", accdMap);
			}
		}
		
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_CRD_CC_FUND_BALANCE_TRANSFER_TO_CARD_ACCOUNTING")
	public static GMMap fundBalanceTransferToCardAccounting(GMMap iMap) throws SQLException {
		
		DALUtil.callOneParameterFunction("{? = call PKG_CARD.ccFundConversionAccounting(?)}",  
				 Types.DECIMAL,  
				 iMap.getBigDecimal(TX_NO));

		
		return iMap;
	}
	

	@GraymoundService("BNSPR_CRD_CC_FUND_UPDATE_ACCOUNT")	
	public static GMMap fundCostumerAccount(GMMap iMap) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");			
			GMMap crdFundAccountMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<CrdCcFundingFileProcess> addedData = new ArrayList<CrdCcFundingFileProcess>(); 
			session.createSQLQuery("delete bnspr.crd_cc_fund_account where oid in (select min(oid) from bnspr.crd_cc_fund_account group by tokenized_card_no having count(tokenized_card_no) > 1)").executeUpdate();
			session.flush();
			
			session = DAOSession.getSession("BNSPRDal");
			List<?> listFileData = session.createCriteria(CrdCcFundingFileProcess.class).add(Restrictions.eq("processStatus", "E")).add(Restrictions.ge("processDate",format.parse("01.01.2020"))).list();
			for (int i = 0; i < listFileData.size(); i++) {
				CrdCcFundingFileProcess crdFndngFlPrcss = (CrdCcFundingFileProcess) listFileData.get(i);
					// same data control
					if(CheckSameAccount(addedData, crdFndngFlPrcss)) 
						continue;	
					
					// crd_cc_fund_account table control
					if(BigDecimal.ZERO.equals(crdFndngFlPrcss.getAccountNo()) || crdFndngFlPrcss.getAccountNo() == null){
						
						CrdCcFundAccount fundAccount = null;
						if(StringUtil.isNumeric(crdFndngFlPrcss.getCardNo())){
							fundAccount = CallFundAccountService("cardNo", new BigDecimal(crdFndngFlPrcss.getCardNo()), session);
						}else{
							fundAccount = CallFundAccountService("tokenizedCardNo", crdFndngFlPrcss.getCardNo(), session);
						}
						
						if(fundAccount != null && fundAccount.getFundAccount() != null){
							if(!BigDecimal.ZERO.equals(fundAccount.getFundAccount())){
								crdFndngFlPrcss.setAccountNo(fundAccount.getFundAccount());
								crdFndngFlPrcss.setProcessStatus("A");
								// update data
								session.saveOrUpdate(crdFndngFlPrcss);
								addedData.add(crdFndngFlPrcss);
								
								logger.info("BNSPR_CRD_CC_FUND_UPDATE_ACCOUNT guncellenen yeni account ccFundAccount : " + fundAccount.getFundAccount());
							}
						}else{
							// Recursive Service Call
							String crdNo = crdFndngFlPrcss.getCardNo();
							while(true){
								crdFundAccountMap = CallCustomerCardDetailService(crdNo);
								if (crdFundAccountMap != null && crdFundAccountMap.getString("RETURN_CODE").equals("2")){
									String oldCardNo = crdFundAccountMap.getString("CARD_DETAIL_INFO", 0,"OLD_CARD_NO");
									if (oldCardNo != null && !StringUtils.isEmpty(oldCardNo) && !BigDecimal.ZERO.equals(oldCardNo)){
										CrdCcFundAccount reFundAccount = CallFundAccountService("tokenizedCardNo", oldCardNo, session);
										if(reFundAccount != null && reFundAccount.getFundAccount() != null){
											if(!BigDecimal.ZERO.equals(reFundAccount.getFundAccount())){
												crdFndngFlPrcss.setAccountNo(reFundAccount.getFundAccount());
												crdFndngFlPrcss.setProcessStatus("A");
												session.saveOrUpdate(crdFndngFlPrcss);
												addedData.add(crdFndngFlPrcss);
												// Add crdCcFundAccount table
												CrdCcFundAccount crdCcFundAccount = new CrdCcFundAccount();
												crdCcFundAccount.setCardNo(StringUtil.isNumeric(crdNo) ? new BigDecimal(crdFndngFlPrcss.getCardNo()) : new BigDecimal(0));
												crdCcFundAccount.setFundAccount(reFundAccount.getFundAccount());
												crdCcFundAccount.setStatus("1");
												crdCcFundAccount.setTokenizedCardNo(crdNo);
												session.saveOrUpdate(crdCcFundAccount);
												
												logger.info("BNSPR_CRD_CC_FUND_UPDATE_ACCOUNT guncellenen yeni account reFundAccount: " + reFundAccount.getFundAccount());
												break;
											}
										}else{
											crdNo = oldCardNo;
										}
									}else{
										crdFndngFlPrcss.setProcessStatus("X");
										session.saveOrUpdate(crdFndngFlPrcss);
										break; // old_card_no is null
									} 
								}else{
									break; // return_code != 2
								} 
							}
						}
					}
			}
			logger.info("BNSPR_CRD_CC_FUND_UPDATE_ACCOUNT islenen veri adedi: " + addedData.size());
			addedData = null;
			session.flush();
			
			session = DAOSession.getSession("BNSPRDal");
			session.createSQLQuery("update bnspr.crd_cc_funding_file_process set process_status = 'H' where debit_credit_flag ='D' and process_status = 'A'").executeUpdate();
			session.flush();
			EODUtilitiy.callFundingBatch("ARTI_BAKIYE_AKTARIM_BATCH");
			
			session = DAOSession.getSession("BNSPRDal");
			session.createSQLQuery("update bnspr.crd_cc_funding_file_process set process_status = 'A' where debit_credit_flag ='D' and process_status = 'H'").executeUpdate();
			session.flush();
			EODUtilitiy.callFundingBatch("ARTI_BAKIYE_AKTARIM_BATCH");
		}
		catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
	
	private static GMMap CallCustomerCardDetailService(String cardNo){
		GMMap iMap= new GMMap();
		iMap.put(CARD_NO, cardNo);
		return GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", iMap);
	}
	
	private static CrdCcFundAccount CallFundAccountService(String key, String cardNo, Session session){
		return (CrdCcFundAccount)session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq(key, cardNo)).uniqueResult();
	}
	
	private static CrdCcFundAccount CallFundAccountService(String key, BigDecimal cardNo, Session session){
		return (CrdCcFundAccount)session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq(key, cardNo)).uniqueResult();
	}
	
	private static Boolean CheckSameAccount(List<CrdCcFundingFileProcess> accounts, CrdCcFundingFileProcess prevAccount){
		Boolean isSameAccount = false;
		for (CrdCcFundingFileProcess fileProcess : accounts){
			if (fileProcess.getAmount() == prevAccount.getAmount() && fileProcess.getProcessDate() == prevAccount.getProcessDate() && fileProcess.getCardNo() == prevAccount.getCardNo()) 
				isSameAccount = true;
		}
		return isSameAccount;
	}
	
	
	@GraymoundService("BNSPR_CRD_CC_FUND_BALANCE_TRANSFER_TO_CARD")
	public static GMMap fundBalanceTransferToCard(GMMap iMap) throws SQLException {
		
		GMMap cardMap = new GMMap();
		GMMap cardRespMap = new GMMap();
		
		cardMap.put(BSMV_RATE, BigDecimal.ZERO);
		cardMap.put(KKF_RATE, BigDecimal.ZERO);
		
		cardMap.put(TXN_AMOUNT, iMap.getString(TXN_AMOUNT));
		cardMap.put(CARD_NO, iMap.getString(CARD_NO));
		cardMap.put(TXN_DESC, "M�stakriz hesap bakiye aktar�m�");
		cardMap.put(TXN_CURR_CODE, "TRY");
		cardMap.put(TXN_TYPE,  iMap.getString("OTC"));
		cardMap.put(TXN_STATE, "N");

		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		cardMap.put(TXN_DATE, format.format(new Date()));
		
		cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
		
		cardRespMap.put(TX_NO, iMap.getBigDecimal(TX_NO));
		cardRespMap.put(OCEAN_RESULT, cardRespMap.getString("OCEAN_RESULT"));
		
		GMServiceExecuter.executeNT("BNSPR_CRD_INSERT_TOPUP_RRN_LOG", cardRespMap);
		
		if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
			//throw new GMRuntimeException(4458002, "Finansal Bak�m Hata : "+ cardRespMap.getString(RETURN_DESCRIPTION));
		}
		
		
		return cardRespMap;
	}
	@GraymoundService("BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT")
	public static GMMap updateTokenizedCard(GMMap iMap){
		GMMap oMap= new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
	
			List<CrdCcFundAccount> fundAccountList = new ArrayList<CrdCcFundAccount>();
			do{
				fundAccountList = session.createCriteria(CrdCcFundAccount.class).add(Restrictions.eq("status", "1")).add(Restrictions.isNull("tokenizedCardNo")).setMaxResults(500).list();
				if(fundAccountList.size()>0){
					updateTokenizedCardS(fundAccountList);
				}
			}while(fundAccountList.size()>0);

			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	public static GMMap updateTokenizedCardS(List<CrdCcFundAccount> fundAccountList){
		GMMap iMap1 = new GMMap();
		GMMap iMap2 = new GMMap();
		GMMap iMap3 = new GMMap();
		GMMap iMap4 = new GMMap();
		GMMap iMap5 = new GMMap();
		GMMap inputMap=new GMMap();
        ArrayList<GMMap> taskList=new ArrayList<GMMap>();
        boolean devam=true;

		int s=0;
		for (int i = 0; i < 100; i++) {
			if(fundAccountList.size()<=i){
				devam=false;
				break;
			}
				
			iMap1.put("OID_LIST", s,"OID", fundAccountList.get(i).getOid());
			
		}
		iMap1.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT_P");
		iMap1.put("SERVICE_ID", "1");
		taskList.add(iMap1);
		s=0;
		if(devam){
			for (int i =100; i < 200; i++) {
				if(fundAccountList.size()<=i){
					devam=false;
					break;
				}
				iMap2.put("OID_LIST", s,"OID", fundAccountList.get(i).getOid());
			}
			iMap2.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT_P");
			iMap2.put("SERVICE_ID", "2");
			taskList.add(iMap2);
		}
		s=0;
		if(devam){
			for (int i =200; i < 300; i++) {
				if(fundAccountList.size()<=i){
					devam=false;
					break;
				}
				iMap3.put("OID_LIST", s,"OID", fundAccountList.get(i).getOid());
			}
			iMap3.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT_P");
			iMap3.put("SERVICE_ID", "3");
			taskList.add(iMap3);
		}
		s=0;
		if(devam){
			for (int i =300; i < 400; i++) {
				if(fundAccountList.size()<=i){
					devam=false;
					break;
				}
				iMap4.put("OID_LIST", s,"OID",fundAccountList.get(i).getOid());
			}
			iMap4.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT_P");
			iMap4.put("SERVICE_ID", "4");
			taskList.add(iMap4);
		}
		s=0;
		if(devam){
			for (int i =400; i < 500; i++) {
				if(fundAccountList.size()<=i){
					break;
				}
				iMap5.put("OID_LIST", s,"OID", fundAccountList.get(i).getOid());
			}
			iMap5.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT_P");
			iMap5.put("SERVICE_ID", "5");
			taskList.add(iMap5);
		}
        inputMap.put("T_TASKS", taskList);
        GMMap outputMap = GMServiceExecuter.callParallel(inputMap);

		return outputMap;
	}
	@GraymoundService("BNSPR_UPDATE_TOKENIZED_CARDS_FOR_FUND_ACCOUNT_P")
	public static GMMap updateTokenizedCardP(GMMap iMap){
		String tokenizedCardNo ="";
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		for (int i = 0; i < iMap.getSize("OID_LIST"); i++) {
			try {
				tokenizedCardNo = "";
				CrdCcFundAccount fundAccount = (CrdCcFundAccount) session.get(CrdCcFundAccount.class, iMap.getString("OID_LIST",i,"OID"));
				tokenizedCardNo = BnsprOceanCommonFunctions.getTokenizedCardNo(fundAccount.getCardNo().toString());
				fundAccount.setTokenizedCardNo(tokenizedCardNo);
				session.flush();
			}
			catch (Exception e) {
				e.printStackTrace();
				continue;
			}
		}
        System.out.println("SERVICE_ID"+iMap.getString("SERVICE_ID"));
        oMap.put("PARALLEL_CALL_RESULT", "X");

		return oMap;
	}
	
	public static boolean isNumeric(String str) {
		  return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
		}
	
	
	
}
