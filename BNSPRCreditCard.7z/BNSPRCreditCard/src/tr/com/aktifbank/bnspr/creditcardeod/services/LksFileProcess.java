package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.creditcard.util.Constants;
import tr.com.aktifbank.bnspr.dao.LksFtpGelenDosya;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import org.apache.commons.lang.StringUtils;


public class LksFileProcess implements Constants{
	
	private static final Logger logger = Logger.getLogger(LksFileProcess.class);
	
	@GraymoundService("BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE")
	public static GMMap lksGetCardFirstUsedDateFile(GMMap iMap) throws Exception{
		
		try {
			long start = 1;
			long interval = 10;
			long end = interval;
			
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			String line = "";
			
			String kayitTuru = "";
			String kurumKodu = "";
			String kimlikNo = "";
			String ilkAdi = "";
			String ikinciAdi = "";
			String soyadi = "";
			String musteriNo = "";
			String kartIlkKullanimTarihi = "";
			String bildirimGostergesi = "";
			String ekAlan = "";
			int errorCounter = 0;
			String errorMsg = "";
			String year = ""; String month = ""; String day = "";
			
			if (fileMap.get("FILE_LINE") == null) {
				throw new GMRuntimeException(4425001, "FTM icerik tablosunda islenecek kayit bulunamadi");
			}
			
			while (fileMap.get("FILE_LINE") != null) {
				for (int index = 0; index < fileMap.getSize("FILE_LINE"); index++) {
					BigDecimal mNo = null;
					line = fileMap.getString("FILE_LINE", index, "LINE");
					if (line.length() != 120) {
						throw new Exception("Satir uzunlugu hatali: " + line.length());
					}
					
					kayitTuru = line.substring(0, 5).trim();
					kurumKodu = line.substring(5, 10).trim();
					kimlikNo = line.substring(10, 21).trim();
					ilkAdi = line.substring(21, 36).trim();
					ikinciAdi = line.substring(36, 51).trim();
					soyadi = line.substring(51, 81).trim();
					musteriNo = line.substring(81, 101).trim();
					kartIlkKullanimTarihi = line.substring(101, 109).trim();
					bildirimGostergesi = line.substring(109, 110).trim();
					ekAlan = line.substring(110, 120).trim();
					
					if(kimlikNo.length() <= 0 || kartIlkKullanimTarihi.length() <= 0) {
						errorCounter = errorCounter + 1;
						errorMsg = "BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE , Zorunlu alan hatasi, kimlikNo: " + kimlikNo + " ilkAdi: " + ilkAdi + " soyadi: "+soyadi+" musteriNo: "+musteriNo+" kartIlkKullanimTarihi: "+kartIlkKullanimTarihi;
						saveLKSFirstUsedDate(kayitTuru, kurumKodu, kimlikNo, ilkAdi, ikinciAdi, soyadi, musteriNo, kartIlkKullanimTarihi, bildirimGostergesi, ekAlan,"0003",errorMsg);
						logger.error(errorMsg);
						continue;
				    }
					
					saveLKSFirstUsedDate(kayitTuru, kurumKodu, kimlikNo, ilkAdi, ikinciAdi, soyadi, musteriNo, kartIlkKullanimTarihi, bildirimGostergesi, ekAlan,"","");
					
					// musteriNo al
					String fetchQuery = 
							String.format("SELECT kk.musteri_no as MUSTERI_NO FROM bnspr.kk_basvuru kk where kk.musteri_no = '%s' and nvl(kk.kart_tipi,'KK') = 'KK' and kk.rec_date = (select max(kp.rec_date) from bnspr.kk_basvuru kp where nvl(kp.kart_tipi,'KK') = 'KK' and kk.musteri_no = kp.musteri_no)", 
									musteriNo); 
					mNo = DALUtil.getResults(fetchQuery, "BASVURU").getBigDecimal("BASVURU", 0, "MUSTERI_NO");
					
					if(BigDecimal.ZERO.equals(mNo) || mNo == null){
						
						String fQuery = 
								String.format("select MAX(gg.musteri_no) as MUSTERI_NO from bnspr.kk_basvuru gg where gg.basvuru_no IN (select km.basvuru_no from bnspr.v_kk_basvuru_kimlik km where km.tc_kimlik_no = '%s' and km.BASVURU_NO IS NOT NULL)", 
										kimlikNo.trim()); 
						mNo = DALUtil.getResults(fQuery, "BASVURU").getBigDecimal("BASVURU", 0, "MUSTERI_NO");
						
						if(BigDecimal.ZERO.equals(mNo) || mNo == null){
							errorCounter = errorCounter + 1;
							errorMsg = "BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE musteriNo: "+ musteriNo +" Hata: BasvuruNo bos olamaz";
							logger.error(errorMsg);
							saveLKSFirstUsedDate(kayitTuru, kurumKodu, kimlikNo, ilkAdi, ikinciAdi, soyadi, musteriNo, kartIlkKullanimTarihi, bildirimGostergesi, ekAlan,"0000",errorMsg);
							continue;	
						}
					}
					
					// musteri bilgilerini al
					/* CallableStatement 	stmt = null;
					Connection 			conn = DALUtil.getGMConnection();
					ResultSet 			rSet = null;
					stmt = conn.prepareCall("{? = call PKG_KK_BASVURU.Get_Customer_Info_For_Ocean(?)}");
					int i = 1;
					stmt.registerOutParameter(i++, -10);
					stmt.setBigDecimal(i++, basvuruNo);
					stmt.execute();
					rSet = (ResultSet)stmt.getObject(1);
					oMap = new GMMap();
					oMap.putAll(DALUtil.rSetMap(rSet));
					conn.close(); stmt.close();	rSet.close(); */
					
					// check date format
					SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
					format.parse(kartIlkKullanimTarihi);
					year = kartIlkKullanimTarihi.substring(0,4);
					month = kartIlkKullanimTarihi.substring(4,6);
					day = kartIlkKullanimTarihi.substring(6,8);
					
					try{
						GMMap inMap = new GMMap();
						String newFUD = year+"."+month+"."+day;
						inMap.put("LKS_CARD_FIRST_USAGE", newFUD);
						inMap.put("CUSTOMER_NO", mNo);
						GMMap resultMap = GMServiceExecuter.call("BNSPR_GENERAL_UPDATE_FIRST_USED_DATE", inMap);
						if(!"2".equals(resultMap.getString("RETURN_CODE"))){
							errorMsg = resultMap.getString("RETURN_DESCRIPTION") != null && resultMap.getString("RETURN_DESCRIPTION").trim().length() > 0 ? resultMap.getString("RETURN_DESCRIPTION") : "";
							errorMsg += resultMap.getString("ERROR_DETAIL") != null && resultMap.getString("ERROR_DETAIL").trim().length() > 0 ? resultMap.getString("ERROR_DETAIL") : "";
							logger.error("BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE musteriNo: "+ musteriNo +" Hata: " + errorMsg);
							saveLKSFirstUsedDate(kayitTuru, kurumKodu, kimlikNo, ilkAdi, ikinciAdi, soyadi, musteriNo, kartIlkKullanimTarihi, bildirimGostergesi, ekAlan,"0001",errorMsg);
							errorCounter = errorCounter + 1;
						}
					}catch(Exception e){
						errorCounter = errorCounter + 1;
						errorMsg = "BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE exception_: "+ e.getMessage();
						String err = errorMsg+"// //"+e;
						logger.error(err);
						saveLKSFirstUsedDate(kayitTuru, kurumKodu, kimlikNo, ilkAdi, ikinciAdi, soyadi, musteriNo, kartIlkKullanimTarihi, bildirimGostergesi, ekAlan,"0002",err);
						StringWriter sw = new StringWriter();
						e.printStackTrace(new PrintWriter(sw));
						continue;
					}
					
				}
				fileMap.clear();
				start += interval;
				end += interval;
				fileMap.putAll(EODUtilitiy.getLineFromFTM(start, end, ftmTransferId));
			}
			if(errorCounter != 0){
				String hataAciklama = "BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE servisinde "+ errorCounter +" kayit UpdateCustomer hatasi almistir ";
				logger.error(hataAciklama);
				EODUtilitiy.sendMail("BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE Hata", hataAciklama, "caglar.saribiyik@aktifbank.com.tr");
			}
			//session.flush();
		}
		catch (Exception e) {
			logger.error("BNSPR_LKS_GET_CARD_FIRST_USED_DATE_FILE exception: "+ e.getMessage());
			throw ExceptionHandler.convertException(e);
		}
		
		return new GMMap();
	}
	
	public static void saveLKSFirstUsedDate(String kayitTuru, String kurumKodu, String kimlikNo, String ilkAdi, 
			String ikinciAdi, String soyadi, String musteriNo, String kartIlkKullanimTarihi, String bildirimGostergesi, String ekAlan,
				String hataKodu, String hataAciklama){
		GMMap lMap = new GMMap();
		lMap.put("KAYIT_TURU", kayitTuru);
		lMap.put("KURUM_KODU", kurumKodu);
		lMap.put("KIMLIK_NO", kimlikNo);
		lMap.put("ILK_ADI", ilkAdi);
		lMap.put("IKINCI_ADI", ikinciAdi);
		lMap.put("SOYADI", soyadi);
		lMap.put("MUSTERI_NO", musteriNo);
		lMap.put("ILK_KULLANIM_TARIHI", kartIlkKullanimTarihi);
		lMap.put("BILDIRIM_GOSTERGESI", bildirimGostergesi);
		lMap.put("EK_ALAN", ekAlan);
		lMap.put("HATA_KODU", hataKodu);
		lMap.put("HATA_ACIKLAMA", hataAciklama);
		GMServiceExecuter.execute("BNSPR_LKS_FIRST_USED_DATE_SAVE", lMap);
	}
	
	@GraymoundService("BNSPR_LKS_FIRST_USED_DATE_SAVE")
	public static GMMap lksFirstUsedDateSave(GMMap iMap) throws Exception{
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			LksFtpGelenDosya ftpDosya = new LksFtpGelenDosya();
			ftpDosya.setKayitTuru(iMap.getString("KAYIT_TURU") == null || StringUtils.isEmpty(iMap.getString("KAYIT_TURU")) ? "" : iMap.getString("KAYIT_TURU"));
			ftpDosya.setKurumKodu(iMap.getString("KURUM_KODU") == null || StringUtils.isEmpty(iMap.getString("KURUM_KODU")) ? "" : iMap.getString("KURUM_KODU"));
			ftpDosya.setTcKimlikNumara(iMap.getString("KIMLIK_NO") == null || StringUtils.isEmpty(iMap.getString("KIMLIK_NO")) ? "" : iMap.getString("KIMLIK_NO"));
			ftpDosya.setIlkAdi(iMap.getString("ILK_ADI") == null || StringUtils.isEmpty(iMap.getString("ILK_ADI")) ? "" : iMap.getString("ILK_ADI"));
			ftpDosya.setIkinciAdi(iMap.getString("IKINCI_ADI") == null || StringUtils.isEmpty(iMap.getString("IKINCI_ADI")) ? "" : iMap.getString("IKINCI_ADI"));
			ftpDosya.setSoyadi(iMap.getString("SOYADI") == null || StringUtils.isEmpty(iMap.getString("SOYADI")) ? "" : iMap.getString("SOYADI"));
			ftpDosya.setMusteriNumarasi(iMap.getString("MUSTERI_NO") == null || StringUtils.isEmpty(iMap.getString("MUSTERI_NO")) ? "" : iMap.getString("MUSTERI_NO"));
			ftpDosya.setKartIlkKullanimTarihi(iMap.getString("ILK_KULLANIM_TARIHI") == null || StringUtils.isEmpty(iMap.getString("ILK_KULLANIM_TARIHI")) ? "" : iMap.getString("ILK_KULLANIM_TARIHI"));
			ftpDosya.setBildirimGostergesi(iMap.getString("BILDIRIM_GOSTERGESI") == null || StringUtils.isEmpty(iMap.getString("BILDIRIM_GOSTERGESI")) ? "" : iMap.getString("BILDIRIM_GOSTERGESI"));
			ftpDosya.setFiller(iMap.getString("EK_ALAN") == null || StringUtils.isEmpty(iMap.getString("EK_ALAN")) ? "" : iMap.getString("EK_ALAN"));
			ftpDosya.setHataKodu(iMap.getString("HATA_KODU") == null || StringUtils.isEmpty(iMap.getString("HATA_KODU")) ? "" : iMap.getString("HATA_KODU"));
			ftpDosya.setHataAciklama(iMap.getString("HATA_ACIKLAMA") == null || StringUtils.isEmpty(iMap.getString("HATA_ACIKLAMA")) ? "" : iMap.getString("HATA_ACIKLAMA"));
			session.save(ftpDosya);
			session.flush();
		}
		catch (Exception e) {
			throw e;
		}
		
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_LKS_VALIDATION_REPORT_DRKD_EXIST_CONTROL")
	public static GMMap lksReportExistControl4DRKD(GMMap iMap) throws Exception{
		String bankDate = null;
		
		try {
			bankDate = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getString(BANKA_TARIH);
			iMap.put(FILE_NAME, "DRKD" + bankDate);
			GMServiceExecuter.call("BNSPR_LKS_VALIDATION_REPORT_EXIST_CONTROL", iMap);
		}
		catch (Exception e) {
			throw e;
		}
		
		return new GMMap();
	}

	@GraymoundService("BNSPR_LKS_VALIDATION_REPORT_GRKI_EXIST_CONTROL")
	public static GMMap lksReportExistControl4GRKI(GMMap iMap) throws Exception{
		String bankDate = null;
		
		try {
			bankDate = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getString(BANKA_TARIH);
			iMap.put(FILE_NAME, "GRKI" + bankDate);
			GMServiceExecuter.call("BNSPR_LKS_VALIDATION_REPORT_EXIST_CONTROL", iMap);
		}
		catch (Exception e) {
			throw e;
		}
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_LKS_VALIDATION_REPORT_EXIST_CONTROL")
	public static GMMap lksValidationReportExistControl(GMMap iMap) throws Exception{
		boolean isExists = false;
		GMMap mailMap = new GMMap();
		String mailTo = null;
		String fileName = null;
		
		try {
			mailMap.put(KOD, "LKS_BILDIRIM_VALIDASYON_MAIL");
			mailTo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", mailMap).getString(DEGER);

			fileName = iMap.getString(FILE_NAME);
			
			isExists = EODUtilitiy.fileExistsOnSFtp("LKS_VAL_RP", fileName);
			if(!isExists){
				EODUtilitiy.sendMail("LKS FTP Bildirim Validasyon Raporu Hk. - AKT�F BANK - HATA", "Sunucuda " + fileName + " isimli dosya bulunamad�!", mailTo);
			}
		}
		catch (Exception e) {
			EODUtilitiy.sendMail("LKS FTP Bildirim Validasyon Raporu Hk. - AKT�F BANK - HATA", "Dosya kontrol� esnas�nda hata olu�tu!", mailTo);
			throw new Exception("LKS Dosya Kontrolu esnas�nda hata olu�tu!");
		}
		
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_READ_LKS_VALIDATION_REPORT_FROM_FTM")
	public static GMMap readLksValidationReportDrkd(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();
		String mailTo = null;
		
		try {
			long start = 1;
			long end = 100;
			long interval = 100;
			int refusedCount = CONST_NUMERIC_ZERO;
			String line = "";
			BigDecimal ftmTransferId = iMap.getBigDecimal(PROCESS_ID);
			
			GMMap mailMap = new GMMap();
			mailMap.put(KOD, "LKS_BILDIRIM_VALIDASYON_MAIL");
			mailTo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", mailMap).getString(DEGER);
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			String fileName = EODUtilitiy.getFileNameFromFTM(ftmTransferId).getString(FILE_LIST, 0, FILE_NAME);
			
			if (fileMap.get(FILE_LINE) == null) {
				EODUtilitiy.sendMail("LKS FTP Bildirim Validasyon Raporu Hk. - AKT�F BANK - HATA", "Gelen Lks Bildirim Validasyon Raporu bo�!", mailTo);
				return oMap;
			}
			
			while(fileMap.get(FILE_LINE) != null){
				int lineCount = fileMap.getSize(FILE_LINE);
				
				for (int i = 0; i < lineCount; i++){
					line = fileMap.getString(FILE_LINE, i, LINE);
					
					if(fileName.startsWith("DRKD")){
						refusedCount += getRefusedCountFromLksValidateReportDrkd(line);
					}else if (fileName.startsWith("GRKI")) {
						refusedCount += isRefusedLineFromLksValidateReport(line) ? CONST_NUMERIC_ONE : CONST_NUMERIC_ZERO;
					}
				}
				
				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			}
			
			String mailBody = "LKS FTP Bildirim Validasyon Raporu Ba�ar�l� �ekilde Okundu." + " Dosya Ad� : " + fileName + " Reddedilen Kay�t Say�s� : " + refusedCount;
			EODUtilitiy.sendMail("LKS FTP Bildirim Validasyon Raporu Hk. - AKT�F BANK -B�LG�", mailBody, mailTo);
		}
		catch (Exception e) {
			logger.error(e);
			EODUtilitiy.sendMail("LKS FTP Bildirim Validasyon Raporu Hk. - AKT�F BANK -HATA", "Dosya Okuma S�ras�nda Hata Olu�tu!", mailTo);
			throw e;
		}
		
		return new GMMap();
	}
	
	private static int getRefusedCountFromLksValidateReportDrkd(String line){
		int lineLenght = 0;
		int refusedCount = 0;
		
		lineLenght = (line != null ? line.length() : CONST_NUMERIC_ZERO);
				
		if(lineLenght == DRKD_REFUSED_RECORD_LINE_LENGHT && line.substring(0, 23).equals(REDDEDILEN_KAYIT_SAYISI)){
			refusedCount = Integer.parseInt(line.substring(39, 47));
		}
		
		return refusedCount;
	}
	
	private static boolean isRefusedLineFromLksValidateReport(String line){
		return line.contains(" R ") ? true : false;
	}
	
}
