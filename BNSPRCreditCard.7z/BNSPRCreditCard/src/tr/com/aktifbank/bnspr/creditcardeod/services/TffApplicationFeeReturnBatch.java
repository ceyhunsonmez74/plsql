package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.CrdTffAppFeeReturn;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TffApplicationFeeReturnBatch implements OceanMapKeys{
	
	
	@GraymoundService("BNSPR_CRD_TFF_APPLICCATION_FEE_RETURN_BATCH")
	public static GMMap applicationFeeReturnBatch(GMMap iMap) throws Exception {
		
		try {
			
			GMMap appMap = new GMMap();
			
			appMap = getApplicationList();
			
				int s = appMap.getSize(LIST);
				for (int i = 0; i < s; i++) {
					
					GMMap trxMap = new GMMap();

					trxMap.put(CUSTOMER_NO, appMap.getBigDecimal(LIST, i, CUSTOMER_NO));
					trxMap.put(APPLICATION_NO, appMap.getBigDecimal(LIST, i, APPLICATION_NO));
					trxMap.put(CARD_NO, appMap.getBigDecimal(LIST, i, CARD_NO));
					trxMap.put(CARD_DCI, appMap.getString(LIST, i, CARD_DCI));
					trxMap.put(AMOUNT, appMap.getBigDecimal(LIST, i, AMOUNT));
					
					try {
						
						GMServiceExecuter.executeNT("BNSPR_CRD_TFF_APPLICCATION_FEE_RETURN", trxMap);
						
					} catch (Exception e) {
						int eCode = 99;
						if (e instanceof GMRuntimeException){
							GMRuntimeException gmExc = (GMRuntimeException) e;
							eCode = gmExc.getCode();
						}
						
						trxMap.put(ERROR_CODE, eCode);
						trxMap.put(ERROR_DESC, e.getMessage());
						trxMap.put(STATUS, "E");
						
						GMServiceExecuter.executeNT("BNSPR_CRD_TFF_SAVE_APPLICCATION_FEE_RETURN", trxMap);
					}
				}
				
				appMap.clear();
			
		} catch (Exception e) {
			EODUtilitiy.sendMail("TFF Ba�vuru bedeli iade batch hata ald�", e.getMessage());
			throw new GMRuntimeException(4452001, e.getMessage());
		}
		
		return iMap;
	}
	
	
	private static GMMap getApplicationList() throws SQLException {
		
		String queryStr = "{? =call PKG_TFF_BASVURU.Basvuru_Odeme_Iade_Listesi()}";
		Object [] inputValues = new Object [0];

		return DALUtil.callOracleRefCursorFunction(queryStr, LIST, inputValues);
		
	}


	@GraymoundService("BNSPR_CRD_TFF_APPLICCATION_FEE_RETURN")
	public static GMMap applicationFeeReturn(GMMap iMap) throws Exception {
		
		iMap.put(TX_NO, GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
		checkRequest(iMap);
		
		String cardDci = iMap.getString(CARD_DCI);
		setAccountingPrm(iMap, cardDci);
		
		doFinancialAdjustmentOperation(cardDci, false, iMap);
		
		try {
		    iMap.put(STATUS, "A");
			saveTrx(iMap);	
			GMMap trxMap = new GMMap();
			trxMap.put("TRX_NAME", "4452");
			trxMap.put("TRX_NO", iMap.getString("TX_NO"));
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", trxMap);
			
		} catch (Exception e) {
			
			doFinancialAdjustmentOperation(cardDci, true, iMap);
			
			throw new GMRuntimeException(4452101,e.getMessage());
			
		}

		return iMap;
	}
	
	
	private static void doFinancialAdjustmentOperation(String cardDci, boolean isReverse ,GMMap iMap) {
		
		if (!cardDci.equals("D")) {

			if (isReverse) {
				
				doFinancialAdjustment(cardDci, EODUtilitiy.getGlobalParam("TFF_4452_FIN_ADJUSTMENT_RVRS").replace("?", "~"),
										"�PTAL - PASSOL�G BA�VURU BEDEL� �ADES�.", iMap);
			}else {

				doFinancialAdjustment(cardDci, EODUtilitiy.getGlobalParam("TFF_4452_FIN_ADJUSTMENT").replace("?", "~"),
										"PASSOL�G BA�VURU BEDEL� �ADES�.", iMap);
			}
		}
	}
	private static void doFinancialAdjustment(String cardDci, String txnType, String txnDesc ,GMMap iMap) {
			
			GMMap cardMap = new GMMap();
			GMMap cardRespMap = new GMMap();
			
			cardMap.put(BSMV_RATE, BigDecimal.ZERO);
			cardMap.put(KKF_RATE, BigDecimal.ZERO);
			
			cardMap.put(TXN_AMOUNT, iMap.getBigDecimal(AMOUNT));
			cardMap.put(CARD_NO, iMap.getString(CARD_NO));
			cardMap.put(TXN_DESC, txnDesc);
			cardMap.put(TXN_CURR_CODE, "TRY");
			cardMap.put(TXN_TYPE, txnType);
			cardMap.put(TXN_STATE, "N");

			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			cardMap.put(TXN_DATE, format.format(new Date()));
			
			if (cardDci.equals("P")) {
				//Prepaid 
				cardRespMap = GMServiceExecuter.call("BNSPR_INTRACARD_FINANCIAL_ADJUSTMENT", cardMap);
				
			}else if (cardDci.equals("KK")) {
				//Kredi kart� 
				cardRespMap = GMServiceExecuter.call("BNSPR_OCEAN_FINANCIAL_ADJUSTMENT", cardMap);
			}
			
			if (!cardRespMap.getString(RETURN_CODE).equals(OceanConstants.Ocean_Return_Success)) {
				throw new GMRuntimeException(4452110, "Kart paketi hatas� : "+ cardRespMap.getString(RETURN_DESCRIPTION));
			}
			
			cardRespMap.put(TX_NO, iMap.getBigDecimal("TX_NO"));
			cardRespMap.put(OCEAN_RESULT, cardRespMap.getString("OCEAN_RESULT"));
			
			GMServiceExecuter.executeNT("BNSPR_CRD_INSERT_TOPUP_RRN_LOG", cardRespMap);
	}

	private static void setAccountingPrm(GMMap iMap, String cardDci) {
		
		if (cardDci.equals("KK")) {
			
			iMap.put(CREDIT_ACCOUNT_NO, EODUtilitiy.getGlobalParam("TFF_4452_CC_CREDIT"));
			iMap.put(CREDIT_ACCOUNT_TYPE, "DK");
			iMap.put("CREDIT_BRANCH", OceanConstants.Ocean_Branch);
			
		}else if (cardDci.equals("P")) {
			
			iMap.put(CREDIT_ACCOUNT_NO, EODUtilitiy.getGlobalParam("TFF_4452_PP_PREPAID"));
			iMap.put(CREDIT_ACCOUNT_TYPE, "DK");
			iMap.put("CREDIT_BRANCH", OceanConstants.Intracard_Branch);
			
		}else if (cardDci.equals("D")) {
			
			iMap.put(CREDIT_ACCOUNT_NO, getDebitCardAccount(iMap.getString(CARD_NO)));
			iMap.put(CREDIT_ACCOUNT_TYPE, "VS");
		}
		
		iMap.put(DEBIT_ACCOUNT_NO, EODUtilitiy.getGlobalParam("TFF_4452_DEBIT"));
		iMap.put(DEBIT_ACCOUNT_TYPE, "DK");
		iMap.put(DEBIT_BRANCH, OceanConstants.Intracard_Branch);
	}
	
	private static void checkRequest(GMMap iMap) throws SQLException {
		
		if (!EODUtilitiy.isNotExistAndNull(iMap, CUSTOMER_NO)) {
			throw new GMRuntimeException(4452103, "CUSTOMER_NO null olamaz.");
		}
		
		if (!EODUtilitiy.isNotExistAndNull(iMap, CARD_DCI)) {
			throw new GMRuntimeException(4452109, "CARD_DCI null olamaz.");
		}
		
		if (!EODUtilitiy.isNotExistAndNull(iMap, CARD_NO)) {
			throw new GMRuntimeException(4452104, "CARD_NO null olamaz.");
		}
		
		if (!EODUtilitiy.isNotExistAndNull(iMap, APPLICATION_NO)) {
			throw new GMRuntimeException(4452105, "APPLICATION_NO null olamaz.");
		}
		
		if (EODUtilitiy.isNotExistAndNull(iMap, AMOUNT)) {
			if (iMap.getBigDecimal(AMOUNT).compareTo(BigDecimal.ZERO) <= 0) {
				throw new GMRuntimeException(4452106, "AMOUNT s�f�rdan �y�k olmal�.");
			}
		}else {
			throw new GMRuntimeException(4452107, "AMOUNT null olamaz.");
		}
		
		isDublicateFeeReturnTrx(iMap.getBigDecimal(APPLICATION_NO));
		
	}

	private static void isDublicateFeeReturnTrx(BigDecimal appNo) throws SQLException {
		
		String func = "{? =call PKG_TRN4452.getAppFeeReturnRecord(?)}";
		Object [] inputValues = new Object [2];
		inputValues[0] = BnsprType.NUMBER;
		inputValues[1] = appNo;
		
		BigDecimal txNo = (BigDecimal)
				DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
		
		if (txNo.compareTo(BigDecimal.ZERO) != 0) {
			throw new GMRuntimeException(4452108, "Ayn� ba�vuruya ait iade i�lemi var. ��lem No :" + txNo);
		}
	}

	private static String getDebitCardAccount(String cardNo) {
		
		GMMap acMap = new GMMap();
		acMap.put(CARD_NO, cardNo);
		acMap.put(SYSTEM, "I");
		acMap = GMServiceExecuter.call("BNSPR_DC_GET_TFF_DEBIT_CARD_MAIN_ACCOUNT", acMap);
		
		if (acMap.getBigDecimal(DEBIT_ACCOUNT_NO).compareTo(BigDecimal.ZERO) == 0) {
			throw new GMRuntimeException(4452102, "Debit kart�n ana hesab� bulunamad�.");
		}
		
		return acMap.getString(DEBIT_ACCOUNT_NO);
	}

	private static void saveTrx(GMMap iMap) {
		
		CrdTffAppFeeReturn feeReturn = new CrdTffAppFeeReturn();
		Session session = DAOSession.getSession("BNSPRDal");
		
		feeReturn.setAmount(iMap.getBigDecimal(AMOUNT));
		feeReturn.setAppNo(iMap.getBigDecimal(APPLICATION_NO));
		feeReturn.setBankVoucherDesc(EODUtilitiy.getStringValue(iMap, "BANK_VOUCHER_DESC", 500));
		feeReturn.setCardDci(iMap.getString(CARD_DCI));
		feeReturn.setCardNo(iMap.getString(CARD_NO));
		feeReturn.setCreditAccountNo(EODUtilitiy.getStringValue(iMap, CREDIT_ACCOUNT_NO, 30));
		feeReturn.setCreditBranch(EODUtilitiy.getStringValue(iMap, "CREDIT_BRANCH", 10));
		feeReturn.setCreditAccountType(EODUtilitiy.getStringValue(iMap, CREDIT_ACCOUNT_TYPE, 2));
		feeReturn.setCustomerNo(iMap.getBigDecimal(CUSTOMER_NO));
		feeReturn.setDebitAccountNo(EODUtilitiy.getStringValue(iMap, DEBIT_ACCOUNT_NO, 30));
		feeReturn.setDebtBranch(EODUtilitiy.getStringValue(iMap, "DEBIT_BRANCH", 10));
		feeReturn.setDebitAccountType(EODUtilitiy.getStringValue(iMap, DEBIT_ACCOUNT_TYPE, 2));
		feeReturn.setErrorCode(EODUtilitiy.getStringValue(iMap, ERROR_CODE, 10));
		feeReturn.setErrorDesc(EODUtilitiy.getStringValue(iMap, ERROR_DESC, 300));
		feeReturn.setTxNo(iMap.getBigDecimal(TX_NO));
		feeReturn.setTxStatus(iMap.getString(STATUS));
		feeReturn.setVoucherDesc(EODUtilitiy.getStringValue(iMap, "VOUCHER_DESC", 500));
		
		session.save(feeReturn);
		session.flush();
		
	}

	@GraymoundService("BNSPR_CRD_TFF_SAVE_APPLICCATION_FEE_RETURN")
	public static GMMap saveApplicationFeeReturn(GMMap iMap) throws Exception {
		
		saveTrx(iMap);
		
		return iMap;
	}
	
}
