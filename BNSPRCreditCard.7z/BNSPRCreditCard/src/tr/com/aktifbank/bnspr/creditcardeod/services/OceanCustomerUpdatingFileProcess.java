package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.hibernate.Session;
import tr.com.aktifbank.bnspr.dao.CrdCustUpdateFileProcess;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanCustomerUpdatingFileProcess {

	
	@GraymoundService("BNSPR_CRD_LOAD_OCEAN_CUST_UPDATING_FILE")
	public static GMMap loadCustUpdatingFile(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		
		try {
			
			GMMap oMap3 = new GMMap();
			oMap3.putAll(GMServiceExecuter.executeNT("BNSPR_CRD_LOAD_OCEAN_CUST_FILE", iMap));
			BigDecimal fileNo = oMap3.getBigDecimal("FILE_NO");
			fileNo= oMap3.getBigDecimal("FILE_NO");
			
			if (fileNo != BigDecimal.ZERO) {
				
				BigDecimal ftmProcessId = EODUtilitiy.getNextValueOfFTMProcessId();

				GMMap iMap2 = new GMMap();
				iMap2.put("FILE_NO", fileNo);
				iMap2.put("PROCESS_ID", ftmProcessId);
				
				GMServiceExecuter.executeNT("BNSPR_CRD_GET_UPDATE_CUSTOMER",iMap2);
				
				putFile(ftmProcessId);
			}
			
		} catch (Exception e) {
			EODUtilitiy.sendMail( "Ocean M��teri Bilgi Dosyas� G�nderimi Ba�lang��", e.getMessage());
			throw e;
		}
		
		return oMap;
	}

	private static void putFile(BigDecimal ftmProcessId) throws Exception {
		
		GMConnection connection = GMConnection.getConnection("FTM");
		try {
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			GMMap input = new GMMap();
			input.put("FILE_DEF_ID", Integer.valueOf(EODUtilitiy.getGlobalParam("CRD_CC_UPDATE_CUSTOMER_FTM_ID")));
			input.put("PROCESS_ID", ftmProcessId);
			input.put("PROCESS_DATE", sdf.format(new Date()));

			connection = GMConnection.getConnection("FTM");
			connection.serviceCall("BNSPR_FTM_CREATE_AND_TRANSFER_FILE", input);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			connection.close();
		}
	}
	
	@GraymoundService("BNSPR_CRD_LOAD_OCEAN_CUST_FILE")
	public static GMMap loadCustFile(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		
		try {
			
			long start = 1;
			long end = 1000;
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");
			
			GMMap fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);
			
			if (fileMap.get("FILE_LINE") == null) {
				return oMap;
			}
			
			String line = "";
	
			//Hashtable<String, String> crHs = EODUtilitiy.getCurrencyCodes();
			String rowId = "";
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date fileDate = new Date();
			BigDecimal fileNo = BigDecimal.ZERO;
			
			//delete waited records
			//GMServiceExecuter.executeNT("BNSPR_CRD_DELETE_WAITED_RECORDS", iMap);
			
			do {
				int k = fileMap.getSize("FILE_LINE");
				
				for (int i = 0; i < k; i++) {
					
					line = fileMap.getString("FILE_LINE", i, "LINE");
					rowId = line.substring(0, 1);
					
					if (rowId.equals("H")) {
						
						fileDate = dateFormat.parse(line.substring(1, 9));
						fileNo = BigDecimal.valueOf(Double.parseDouble(line.substring(10, 22)));
						
					}else if(rowId.equals("T")) {
						//no need for now
					}else {
						CrdCustUpdateFileProcess fileProcess = new CrdCustUpdateFileProcess();
						fileProcess.setFileDate(fileDate);
						fileProcess.setFileNo(fileNo);
						try {
							fileProcess.setCustomerNo(BigDecimal.valueOf(Double.parseDouble(line.trim())));
							fileProcess.setStatus("A");
						} catch (Exception e) {
							fileProcess.setStatus("E");
							fileProcess.setErrorDesc("Dosya format�na uymayan hatal� sat�r.");
						}
						
						session.save(fileProcess);
					}
				}
				
				session.flush();
				
				fileMap.clear();
				start = start+1000;
				end = end + 1000;
				fileMap = EODUtilitiy.getLineFromFTM(start, end, ftmTransferId);

			} while (fileMap.get("FILE_LINE") != null);
				oMap.put("FILE_NO", fileNo);
				oMap.put("FILE_DATE", fileDate);
			}
		
			catch (Exception e) {
				EODUtilitiy.sendMail("Ocean M��teri Bilgi Dosyas� G�nderimi", e.getMessage());
				e.printStackTrace();
				throw e;
			}
			
			return oMap;
		
		}
	
	@GraymoundService("BNSPR_CRD_GET_UPDATE_CUSTOMER")
	public static GMMap getUpdateCustomer(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		try {
				Object[] objArray = new Object[4];
				objArray[0] = BnsprType.NUMBER;
				objArray[1] = iMap.getBigDecimal("FILE_NO");
				String func="{? = call PKG_OCEAN.GET_UPDATE_CUSTOMER_INFO(?) }";
				oMap= DALUtil.callOracleRefCursorFunction(func, "TABLO", objArray);
	
				Session session = DAOSession.getSession("BNSPRDal");
				BigDecimal ftmProcessId = iMap.getBigDecimal("PROCESS_ID");
				
				GMMap fileMap = new GMMap();
				fileMap.put("FTM_PROCESS_ID", ftmProcessId);
				long count = 0;
				BigDecimal lineNumber = BigDecimal.ZERO;
				
				for (int i = 0; i < oMap.getSize("TABLO"); i++) {
	
					lineNumber = lineNumber.add(BigDecimal.ONE);
					
					FtmFileContent fileContent = new FtmFileContent();
					
					fileContent.setOid(lineNumber.toString());
					fileContent.setFtmProcessOid(ftmProcessId);
					fileContent.setLine(oMap.getString("TABLO",i,"LINE"));
					fileContent.setLineNumber(lineNumber);
					
					session.save(fileContent);
					count = count +1;
				}
				session.flush();
				DecimalFormat df=new DecimalFormat("0000000000");
				String footer = "T"+df.format(lineNumber.longValue()-1)+"+000000000000000000000";
				lineNumber = lineNumber.add(BigDecimal.ONE);
				
				
				FtmFileContent footerLine = new FtmFileContent();
				footerLine.setOid(lineNumber.toString());
				footerLine.setFtmProcessOid(ftmProcessId);
				footerLine.setLine(footer);
				footerLine.setLineNumber(lineNumber);
				
				session.save(footerLine);
				session.flush();
				oMap.put("FTM_PROCESS_ID", ftmProcessId);
				
				return oMap;
		}
		catch (Exception e) {
			throw e;
		}
	}

	@GraymoundService("BNSPR_INSERT_TO_FTM")
	public static GMMap bnsprInsertToFtm(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		BigDecimal ftmProcessId = EODUtilitiy.getNextValueOfFTMProcessId();
		
		GMMap fileMap = new GMMap();
		fileMap.put("FTM_PROCESS_ID", ftmProcessId);
		long count = 0;
		BigDecimal lineNumber = BigDecimal.ZERO;
		for (int i = 0; i < iMap.getSize("TABLO"); i++) {

			lineNumber = lineNumber.add(BigDecimal.ONE);
			
			FtmFileContent fileContent = new FtmFileContent();
			
			fileContent.setOid(lineNumber.toString());
			fileContent.setFtmProcessOid(ftmProcessId);
			fileContent.setLine(iMap.getString("TABLO",i,"LINE"));
			fileContent.setLineNumber(lineNumber);
			
			session.save(fileContent);
			count = count +1;
		}
		session.flush();
		DecimalFormat df=new DecimalFormat("0000000000");
		String footer = "T"+df.format(lineNumber.longValue()-1)+"+000000000000000000000";
		lineNumber = lineNumber.add(BigDecimal.ONE);
		
		
		FtmFileContent footerLine = new FtmFileContent();
		footerLine.setOid(lineNumber.toString());
		footerLine.setFtmProcessOid(ftmProcessId);
		footerLine.setLine(footer);
		footerLine.setLineNumber(lineNumber);
		
		session.save(footerLine);
		session.flush();
		oMap.put("FTM_PROCESS_ID", ftmProcessId);
		
		
		
		return oMap;
	}
		
}

