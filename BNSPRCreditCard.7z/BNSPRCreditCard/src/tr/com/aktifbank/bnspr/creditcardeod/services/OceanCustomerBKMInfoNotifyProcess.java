package tr.com.aktifbank.bnspr.creditcardeod.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OceanCustomerBKMInfoNotifyProcess {
	
	@GraymoundService("BNSPR_CRD_NOTIFY_OCEAN_CUSTOMER_BKM_INFO")
	public static GMMap notifyOceanAccountingNotify (GMMap iMap) throws Exception {
		
		Connection connection = EODUtilitiy.getDSConnection();
		Statement statement = connection.createStatement();
		Statement insertStatement = null;
		ResultSet rs = null;
		try {
			String sql = "select mt.musteri_no,mt.alan_kod||mt.tel_no as cep_tel from  " +
					"bnspr.gnl_musteri_telefon mt where mt.otp_mi = 'E' and mt.tel_tip = '3' " +
					"and mt.sira_no =1 and exists (select 1 from bnspr.customer_card_info cc " +
					"where CC.CUSTOMER_NUMBER = MT.MUSTERI_NO and cc.status = '1')";
			
			statement.executeQuery(sql);
			rs = statement.getResultSet();
			
			long i = 1;
			long count = 0;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String dateStr = dateFormat.format(new Date());
			insertStatement = connection.createStatement();
			BigDecimal ftmProcessId = EODUtilitiy.getNextValueOfFTMProcessId();
			
			String insertH = String.format("insert into ftm.ftm_file_content (oid,ftm_process_oid,line_number,line) " +
					"values(%s,%s,%s,'%s')", i, ftmProcessId, i, "H"+dateStr);
			
			insertStatement.addBatch(insertH);
			insertStatement.executeBatch();
			
			if (rs != null) {

				long interval = 1000;
				rs.next();
				
				do {
					i = i+1;
					count = count +1;
					String detail = rs.getString(1)+"|"+rs.getString(2);
					String insertQ = String.format("insert into ftm.ftm_file_content (oid,ftm_process_oid,line_number,line) " +
							"values(%s,%s,%s,'%s')", i, ftmProcessId, i, detail);
					insertStatement.addBatch(insertQ);
					
					if (i % interval == 1) {
						insertStatement.executeBatch();
					}
					
				} while (rs.next());
				
				insertStatement.executeBatch();
				
				String ftmId = EODUtilitiy.getGlobalParam("CRD_CC_CUSTOMER_BKM_INFO_FTMID");
				EODUtilitiy.ftmTransferFile(ftmId, ftmProcessId, dateStr,1);
			}
			
			String insertF = String.format("insert into ftm.ftm_file_content (oid,ftm_process_oid,line_number,line) " +
					"values(%s,%s,%s,'%s')", i, ftmProcessId, i, "F"+String.valueOf(count));
			insertStatement.addBatch(insertF);
			insertStatement.executeBatch();
			
		} catch (Exception e) {
			EODUtilitiy.sendMail("Ocean M��teri Telefon Dosyas� G�nderimi",e.getMessage());
			GMMap eMap = new GMMap();
			eMap.put("HATA_NO", "660");
			eMap.put("P1", e.getMessage().toString());
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", eMap);
			
		}finally{
			
			if (rs != null) {
				rs.close();
			}
			
			if (statement != null) {
				statement.close();
			}
			
			if (insertStatement != null) {
				insertStatement.close();
			}
			
			if (connection != null) {
				connection.close();
			}
		}
		
		return iMap;
	}
}
