package tr.com.aktifbank.bnspr.triptek.services;

import tr.com.aktifbank.bnspr.dao.TffMobilOdemeMutabakat;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.server.dao.DAOSession;

import org.hibernate.Session;


public class TriptekServices {


	
	@GraymoundService("BNSPR_TRIPTEK_GET_TRANSACTION_LIST")
	public static GMMap getTransactionList(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			Session session = DAOSession.getSession("BNSPRDal");
			try {
				
				for (int i = 0; i < iMap.getSize("ISLEM_LISTESI"); i++) {
				
				TffMobilOdemeMutabakat tffMutabakat = new TffMobilOdemeMutabakat();
				tffMutabakat.setIslemTar(iMap.getDate("ISLEM_LISTESI", i, "ISLEM_TAR"));
				tffMutabakat.setIslemNo(iMap.getString("ISLEM_LISTESI", i, "ISLEM_NO"));
				tffMutabakat.setTutar(iMap.getBigDecimal("ISLEM_LISTESI", i, "TUTAR"));
				tffMutabakat.setKartBasvuruSahibiTckn(iMap.getString("ISLEM_LISTESI", i, "KART_BASVURU_SAHIBI_TCKN"));
				tffMutabakat.setKartBasvuruSahibiAd(iMap.getString("ISLEM_LISTESI", i, "KART_BASVURU_SAHIBI_AD"));
				tffMutabakat.setKartBasvuruSahibiTel(iMap.getString("ISLEM_LISTESI", i, "KART_BASVURU_SAHIBI_TEL"));
				tffMutabakat.setOdemeYapanTckn(iMap.getString("ISLEM_LISTESI", i, "ODEME_YAPAN_TCKN"));
				tffMutabakat.setOdemeYapanAd(iMap.getString("ISLEM_LISTESI", i, "ODEME_YAPAN_AD"));
				tffMutabakat.setOdemeYapanTel(iMap.getString("ISLEM_LISTESI", i, "ODEME_YAPAN_TEL"));
				tffMutabakat.setOperator(iMap.getString("ISLEM_LISTESI", i, "OPERATOR"));
				tffMutabakat.setIslemTipi(iMap.getString("ISLEM_LISTESI", i, "ISLEM_TIPI"));
				tffMutabakat.setIslemUcreti(iMap.getBigDecimal("ISLEM_LISTESI", i, "ISLEM_UCRETI"));
				
				session.save(tffMutabakat);
				session.flush();
				}
			}
		

		catch (Exception ex) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", ex.toString());
			return oMap;
		}
			return oMap;

	}
	

	

}
