package tr.com.aktifbank.bnspr.compay.services;

import javax.ws.rs.core.MediaType;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.google.gson.Gson;
import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;

public class CompayPaymentServices {
	
	private static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-compay.properties");
	private static Client client = Client.create(getJerseyClientConfiguration());
	
	@GraymoundService("BNSPR_COMPAY_PAYMENT_UPDATE_PAYMENT")
	public static GMMap updatePayment(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			UpdatePaymentRequest requestObj = new UpdatePaymentRequest();
			requestObj.setAcquirerId(conf.getProperty("compay.resource.acquirerIdUAT"));
			requestObj.setAcquirerPassword(conf.getProperty("compay.resource.AcquirerPasswordUAT"));
			requestObj.setTransactionId(iMap.getString("TRANSACTION_ID"));
			
			String request = convertObjectToJson(requestObj);
			WebResource webResource = client.resource(conf.getProperty("compay.resource.url.update.payment"));
			WebResource.Builder builder = webResource.type(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);
			ClientResponse response = builder.post(ClientResponse.class, request);
			if (response.getStatus() == 200) {
				String entity = response.getEntity(String.class);
				Gson gson = new Gson();
				UpdatePaymentResponse responseObj=gson.fromJson(entity, UpdatePaymentResponse.class);
				oMap.put("RETURN_CODE", responseObj.getReturnCode());
				oMap.put("RETURN_MESSAGE", responseObj.getReturnMessage());
			}else{
				
				throw new RuntimeException("Failed Login Services HTTP status code : " + response.getStatus());
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static ClientConfig getJerseyClientConfiguration() {
		ClientConfig clientConfig = new DefaultClientConfig();
		clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, true);
		clientConfig.getProperties().put(ClientConfig.PROPERTY_READ_TIMEOUT, Integer.valueOf(conf.getProperty("compay.resource.read.timeout")));
		clientConfig.getProperties().put(ClientConfig.PROPERTY_CONNECT_TIMEOUT, Integer.valueOf(conf.getProperty("compay.resource.connect.timeout")));
		return clientConfig;
	}
	
	private static String convertObjectToJson(Object object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}
}
