package tr.com.aktifbank.bnspr.compay.services;

public class UpdatePaymentRequest {

	 private String acquirerId;
	 private String acquirerPassword;
	 private String transactionId;
	 
	 
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getAcquirerId() {
		return acquirerId;
	}
	public void setAcquirerId(String acquirerId) {
		this.acquirerId = acquirerId;
	}
	public String getAcquirerPassword() {
		return acquirerPassword;
	}
	public void setAcquirerPassword(String acquirerPassword) {
		this.acquirerPassword = acquirerPassword;
	}
	 
	 
}
