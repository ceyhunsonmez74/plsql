package tr.com.aktifbank.bnspr.bayiportal.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PrepaidBayiServices {
	
	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	
	@GraymoundService("BNSPR_BAYI_PREPAID_APPLICATION_CONTROL")
	public static GMMap controlBayiPrepaidApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap validateMap = new GMMap();
		validateMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_CARD_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(validateMap.getString("RESPONSE"))) {
			return validateMap;
		}

		GMMap barkodResponseMap = new GMMap();
		barkodResponseMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_IS_VALID_OCEAN_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(barkodResponseMap.getString("RETURN_CODE"))) {
			oMap.put("RESPONSE", barkodResponseMap.getString("RETURN_CODE"));
			oMap.put("RESPONSE_DATA", barkodResponseMap.getString("RETURN_DESCRIPTION"));

			return oMap;
		}


		BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
		//do�um tarihi kontrol�
		String gercekDogumTar = "";
		if (BigDecimal.ZERO.compareTo(musteriNo) == 0){
			GMMap kpsMap = new GMMap();
			kpsMap.put("TCKN", iMap.getString("TCKN"));
			kpsMap.put("TCK_NO", iMap.getString("TCKN"));
			kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
				return oMap;
			}
			gercekDogumTar = kpsMap.getString("DOGUM_TARIHI");
			
		}
		else
		{
			Session session = DAOSession.getSession("BNSPRDal");
			GnlMusteriKimlik kimlik = (GnlMusteriKimlik) session.createCriteria(GnlMusteriKimlik.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();
			if(kimlik.getDogumTarihi()== null){
				
				GMMap kimlikMap= new GMMap();
				kimlikMap.put("TCKN", iMap.getString("TCKN"));
				kimlikMap.put("TCK_NO", iMap.getString("TCKN"));
				kimlikMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kimlikMap));
				gercekDogumTar=kimlikMap.getString("DOGUM_TARIHI");
				
			}else{
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        	gercekDogumTar = dateFormat.format(kimlik.getDogumTarihi());
			}
		}
		
		String birthDate = iMap.getString("BIRTH_DATE");
		if (birthDate.length() == 7){
			birthDate  = StringUtils.substring(iMap.getString("BIRTH_DATE"), 0, 6)+"0"+StringUtils.substring(iMap.getString("BIRTH_DATE"), 6, 7);
		}
		if (!birthDate.equals(gercekDogumTar))
		{
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.DOGUM_TARIHI_HATALI);
			return oMap;
		}
		
		//telefon kontrolleri
		GMMap phoneMap = new GMMap();
		phoneMap.put("CUSTOMER_NO", musteriNo);
		phoneMap.put("PHONE_COUNTRY_CODE", iMap.getString("PHONE_COUNTRY_CODE"));
		phoneMap.put("PHONE_OPERATOR_CODE", iMap.getString("PHONE_OPERATOR_CODE"));
		phoneMap.put("PHONE_NUMBER", iMap.getString("PHONE_NUMBER"));
		phoneMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_APPLICATION_PHONE_CONTROL", phoneMap));

		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(phoneMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", TffServicesMessages.UYE_TELEFON_EKLE_GENEL_HATA);
			oMap.put("RESPONSE_DATA", phoneMap.getString("RESPONSE_DATA"));

			return oMap;
		}
		
		oMap.put("MUSTERI_NO", musteriNo);
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;

	}

	
	
	
	@GraymoundService("BNSPR_BAYI_START_PREPAID_APPLICATION")
	public static GMMap startBayiPrepaidApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");

		if (iMap.get("TRX_NO") == null) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		}
		if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {

			GMMap customerMap = new GMMap();

			customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CUSTOMER", iMap));
			musteriNo = customerMap.getBigDecimal("MUSTERI_NO");
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
				return customerMap;
			}

		}

		else {
			// update aps adress if necessary
			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
				GMMap customerMap = new GMMap();
				customerMap.put("TCKN", iMap.getString("TCKN"));
				customerMap.put("TRX_NO", iMap.get("TRX_NO"));
				customerMap.put("MUSTERI_NO", musteriNo);
				customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER_APS_ADRESS", customerMap));
				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(customerMap.getString("RESPONSE"))) {
					return customerMap;
				}
			}

		}

		BigDecimal prepaidAppNo = GMServiceExecuter.call("BNSPR_TRN3871_GET_BASVURU_NO", iMap).getBigDecimal("ID");

		GMMap createKkBasvuruMap = new GMMap();
		createKkBasvuruMap.putAll(iMap);
		createKkBasvuruMap.put("BASVURU_NO", prepaidAppNo);
		createKkBasvuruMap.put("MUSTERI_NO", musteriNo);
		createKkBasvuruMap.put("TCKN", iMap.getString("TCKN"));
		createKkBasvuruMap.put("PASAPORT_NO", iMap.getString("PASSPORT_NO"));
		createKkBasvuruMap.put("UYRUK", iMap.getString("COUNTRY_CODE"));
		createKkBasvuruMap.put("BAYI_KOD", iMap.getString("BOX_OFFICE_ID"));
		createKkBasvuruMap.put("TRX_NO", iMap.get("TRX_NO"));
		createKkBasvuruMap.put("KART_NO", iMap.get("CARD_NO"));

		GMMap createKkMap = new GMMap();
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_CREATE_APPLICATION", createKkBasvuruMap));

		if (!AkustikConstants.RESPONSE_SUCCESS.equals(createKkMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", createKkMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", createKkMap.getString("RESPONSE_DATA"));
			return oMap;
		}
		
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DAGITIM_KOD", createKkBasvuruMap));

		// sozlesme ak��� zorunlulu�u kald�r�ld� direk kayit ac

		iMap.put("MUSTERI_NO", musteriNo);
		GMMap matchCustomerMap = new GMMap();
		iMap.put("BASVURU_NO", prepaidAppNo);
		matchCustomerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_MATCH_CARD_CUSTOMER", iMap));

		if (!AkustikConstants.RESPONSE_SUCCESS.equals(matchCustomerMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", matchCustomerMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", matchCustomerMap.getString("RESPONSE_DATA"));
			return oMap;
		}

		
		createKkBasvuruMap.put("DURUM_KOD", "ACIK");
		oMap.put("APPLICATION_STATUS", "ACIK");
		GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", createKkBasvuruMap);
		

		if (!StringUtils.isEmpty(createKkMap.getString("DAGITIM_KOD")) && !BASVURU_DAGITIM_KOD_BOS.equals(createKkMap.getString("DAGITIM_KOD"))) {

			// istenen belgeleri bul
			
			createKkBasvuruMap.put("SORGU_TIPI", "B");
			GMMap documentMap = new GMMap();
			documentMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DOKUMAN_ALINDI_MI_BY_KANAL", createKkBasvuruMap));
			int resultSize = documentMap.getSize("DOKUMAN_LIST");
			if (resultSize > 0) {
				for (int i = 0; i < resultSize; i++) {
					oMap.put("DOCUMENT_LIST", i, "DOC_CODE", documentMap.get("DOKUMAN_LIST", i, "DOKUMAN_KOD"));
					oMap.put("DOCUMENT_LIST", i, "IS_OWNER", documentMap.get("DOKUMAN_LIST", i, "ALINDI_MI"));
				}
			}

			GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", iMap);

		}
		
		GMMap uptMap = new GMMap();
		uptMap.put("BASVURU_NO", prepaidAppNo);
		uptMap.putAll(GMServiceExecuter.execute("BNSPR_UPT_CARD_CREATE", uptMap));
		
		
		GMMap oceanMap = new GMMap();
		oceanMap.put("CARD_NO", iMap.get("CARD_NO"));
		oceanMap.put("EXT_SYS_ACCOUNT_NO", uptMap.getString("EXT_SYS_ACCOUNT_NO"));
		oceanMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CARD_ACCOUNT_DETAIL_INSERT", oceanMap));

		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		oMap.put("APPLICATION_NO", prepaidAppNo);
		oMap.put("CUSTOMER_NO", musteriNo);

		return oMap;

	}

	
	@GraymoundService("BNSPR_BAYI_SAVE_AGREEMENT_DOCUMENTS")
	public static GMMap saveAgreementDocumentsBayi(GMMap iMap) {

		GMMap oMap = new GMMap();
		if (iMap.getString("SOURCE").equals("UPT"))
			oMap.putAll(GMServiceExecuter.execute("BNSPR_UPT_SAVE_AGREEMENT_DOCUMENTS", iMap));	
		else if (iMap.getString("SOURCE").equals("YIM"))
			oMap.putAll(GMServiceExecuter.execute("BNSPR_YIM_SAVE_AGREEMENT_DOCUMENTS", iMap));	
			
		
		return oMap;
	
	}
	

	@GraymoundService("BNSPR_BAYI_CANCEL_APPLICATION")
	public static GMMap cancelApplicationBayi(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (iMap.getString("SOURCE").equals("UPT"))
			oMap.putAll(GMServiceExecuter.execute("BNSPR_UPT_CANCEL_APPLICATION", iMap));	
		else if (iMap.getString("SOURCE").equals("YIM"))
			oMap.putAll(GMServiceExecuter.execute("BNSPR_YIM_CANCEL_APPLICATION", iMap));	
			
		return oMap;
	}
	

	@GraymoundService("BNSPR_BAYI_GET_DOCUMENT_TEMPLATE_DATA")
	public static GMMap getBayiDocumentTemplateData(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (iMap.getString("SOURCE").equals("UPT"))
			oMap.putAll(GMServiceExecuter.execute("BNSPR_UPT_GET_DOCUMENT_TEMPLATE_DATA", iMap));	
		else if (iMap.getString("SOURCE").equals("YIM"))
			oMap.putAll(GMServiceExecuter.execute("BNSPR_YIM_GET_DOCUMENT_TEMPLATE_DATA", iMap));	
			
		return oMap;
	
	}

	@GraymoundService("BNSPR_BAYI_GET_APPLICATION_REPORT")
	public static GMMap getBayiApplicationReport(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		String tableName = "APPLICATION_LIST";
		String tableName2 = "DOC_LIST";
		try {
			conn = DALUtil.getGMConnection();
		
			query = "{? = call PKG_KK_BASVURU.rc_get_basvuru_info_by_bayi(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("BOX_OFFICE_ID"));
			if (!(iMap.get("START_DATE") == null)) {
				java.sql.Date baslangicTar = new java.sql.Date(iMap.getDate("START_DATE").getTime());
				stmt.setDate(3, baslangicTar);
			}
			else{
				stmt.setDate(3, null);}
		
			if (!(iMap.get("END_DATE") == null)) {
				java.sql.Date bitisTar = new java.sql.Date(iMap.getDate("END_DATE").getTime());
				stmt.setDate(4, bitisTar);
			}
			else{
				stmt.setDate(4, null);}
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
		    int  i = 0;
	            while (rSet.next()){
	                oMap.put(tableName , i , "CARD_NO" , rSet.getString("CARD_NO"));
	                oMap.put(tableName , i , "USER_CODE" , rSet.getString("USER_CODE"));
	                oMap.put(tableName , i , "PHONE_NUMBER" , rSet.getString("PHONE_NUMBER"));
	                oMap.put(tableName , i , "TCKN" , rSet.getString("TCKN"));
	                oMap.put(tableName , i , "NAME" , rSet.getString("NAME"));
	                oMap.put(tableName , i , "STATUS" , rSet.getString("STATUS"));
	                oMap.put(tableName , i , "APPLICATION_DATE" , rSet.getString("APPLICATION_DATE"));
	                oMap.put(tableName , i , "APPLICATION_NO" , rSet.getString("APPLICATION_NO"));
	                oMap.put(tableName , i , "CUSTOMER_NO" , rSet.getString("CUSTOMER_NO"));
	                
	                if (!rSet.getString("STATUS").equals("BASVURU"))
	                {
	        			query = "{? = call PKG_KK_BASVURU.bayiBasvuruBelgeDurumListe(?) }";
	        			stmt2 = conn.prepareCall(query);
	        			stmt2.registerOutParameter(1, -10);
	        			stmt2.setBigDecimal(2, new BigDecimal(rSet.getString("APPLICATION_NO")));
	        			stmt2.execute();
	        			rSet2 = (ResultSet) stmt2.getObject(1);
	        			
	        			
	    				ArrayList<HashMap<String, Object>> docList = new ArrayList<HashMap<String, Object>>();
	                            
	    				while (rSet2.next()) {
	    					int y = 1;
	    					HashMap<String, Object> rowData = new HashMap<String, Object>();

	    					rowData.put("DOC_CODE", rSet2.getString(y++));
	    					rowData.put("DOC_STATUS", rSet2.getString(y++));

	    					docList.add(rowData);
	    				}
	    				oMap.put(tableName, i, tableName2, docList);
	    				GMServerDatasource.close(rSet2);	              
	                }
	                i++;
	            }
	            
	    		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
	    		
		} catch(Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}


		return oMap;
	
	}
	
	@GraymoundService("BNSPR_BAYI_GET_PERFORMANCE_REPORT")
	public static GMMap getBayiPerformanceReport(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KK_BASVURU.rc_get_performance_by_bayi(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("BOX_OFFICE_ID"));
			if (!(iMap.get("START_DATE") == null)) {
				java.sql.Date baslangicTar = new java.sql.Date(iMap.getDate("START_DATE").getTime());
				stmt.setDate(3, baslangicTar);
			}
			else{
				stmt.setDate(3, null);}
		
			if (!(iMap.get("END_DATE") == null)) {
				java.sql.Date bitisTar = new java.sql.Date(iMap.getDate("END_DATE").getTime());
				stmt.setDate(4, bitisTar);
			}
			else{
				stmt.setDate(4, null);}
		
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()){
	        oMap.put("SATILAN_KART_ADET" , rSet.getString("SATILAN_KART_ADET"));
	        oMap.put("ONAY_BEKLEYEN_EVRAK_ADET" , rSet.getString("ONAY_BEKLEYEN_EVRAK_ADET"));
	        oMap.put("EKSIK_EVRAKLI_BASVURU_ADET" , rSet.getString("EKSIK_EVRAKLI_BASVURU_ADET"));
	        oMap.put("ONAYLANMIS_EVRAK_ADET" , rSet.getString("ONAYLANMIS_EVRAK_ADET"));
	        oMap.put("IPTAL_EVRAK" , rSet.getString("IPTAL_EVRAK"));
			}
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);

		} catch(Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	
	}
	

	@GraymoundService("BNSPR_BAYI_IS_EXISTS_PREPAID_APPLICATION")
	public static GMMap getBayiIsExistsApplication(GMMap iMap) {

		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		try {
		String[] sourceList = {"YIM","UPT"};

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		BigDecimal musteriNo = iMap.getBigDecimal("CUSTOMER_NO");
		
		List<KkBasvuru> kkBasvuruList = (List<KkBasvuru>) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo)).add(Restrictions.or(Restrictions.and(Restrictions.eq("durumKod", "IPTAL"), Restrictions.eq("aksiyonKod","C")), Restrictions.eq("durumKod", "ACIK")))
				.add(Restrictions.in("source", sourceList)).list();
		
		if(kkBasvuruList != null && kkBasvuruList.size() > 0){
				oMap.put("IS_EXISTS", "Y");
		}else{
			oMap.put("IS_EXISTS", "N");
			}

		} catch(Exception e) {
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
		oMap.put("RESPONSE_DATA", e.getMessage());
		}
		return oMap;
	}
	
}
	
	
	
	
	
	
	
	
	
	
	

