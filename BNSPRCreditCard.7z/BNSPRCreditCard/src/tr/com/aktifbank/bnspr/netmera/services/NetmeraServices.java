package tr.com.aktifbank.bnspr.netmera.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdKartaParaYukleTx;
import tr.com.aktifbank.bnspr.dao.PrepaidTopupProcessTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.google.gson.Gson;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class NetmeraServices {

	private static final int RUNTIME_EXCEPTION_CODE = 99;
	private static final int SUCCEEDED_CODE = 0;
	private static final String SUCCEEDED_DESC = "BASARILI_ISLEM";
	private static final String GECERSIZ_EVENT = "GECERSIZ EVENT TIPI";
	private static final String KIMLIK_BILGISI_BULUNAMADI = "BASVURU UZERINDE TCKN/PASAPORT NO BILGISI BULUNAMADI";
	private static final String ACIK_KART = "ACIK";
	private static final String UYGUN_OLMAYAN_KART_STATUS = "KREDI KARTLARI ICIN SADECE ACIK VE BASIM STATULERI BILDIRILIR";
	private static final String BASVURU_BULUNAMADI = "BASVURU BULUNAMADI";
	private static final String BASVURU_BOS_OLAMAZ = "BASVURU NUMARASI BOS OLAMAZ";
	private static final String BASVURU_VEYA_KART_BOS_OLAMAZ = "BASVURU NUMARASI VEYA KART NUMARASI BOS OLAMAZ";
	private static final String AKUSTIK_KREDI_KARTI_GOSTERIM = "KK";
	private static final String NETMERA_KREDI_KARTI_GOSTERIM = "C";
	private static final String BASVURU = "B";
	private static final String KART_BASIMDA = "BASIM";
	private static final String TOPUP_BULUNAMADI = "TOPUP ISLEMI BULUNAMADI";
	private static final String TOPUP_ODEME = "N";
	private static final String TX_NO_BOS_OLAMAZ = "TX_NO BO� VE SIFIR OLAMAZ";
	private static final String DEBIT_CARD_DCI = "D";
	private static final String TUTAR_BOS_OLAMAZ = "TUTAR BILGISI BOS OLAMAZ";

	/**
	 * Netmera'ya bildirim i�in haz�rlanan servis -- 1601VD
	 * HashMap i�erisinde gelen key - value ikilileri List i�ine at�larak, Json object olusturulur
	 * APP -> Netmera�ya iletilecek api keyi belirten uygulama ad�.
	 * JSON_DATA -> Netmera�ya iletilecek JSON objesinin string de�eri
	 * PRIORITY -> 0 ile 99 aras�nda bir �ncelik de�eri, zorunlu de�ildir.
	 * SERVICE_ID
	 * -> Set Attribute i�in 1,
	 * ->Push Notification i�in 2,
	 * ->Fire Events i�in 3
	 *
	 */

	/**
	 * EVENT_TYPE
	 * KART_DURUM
	 * KIMLIK_NO -> TCKN || (ULKE_KODU + PASOPORT NO)
	 * CARD_TYPE -> P(Prepaid) ,D (Debit) , C(Kredi Kart�) , B (Topup i�in Basvuru)
	 * TUTAR
	 * 
	 * @return
	 *         RESPONSE_CODE -> 0 Ba�ar�l�, 99 ba�ar�s�z
	 *         RESPONSE_DESC
	 */

	@GraymoundService("BNSPR_KK_SEND_EVENT_TO_NETMERA")
	public static GMMap kkSendEventToNetmera(GMMap iMap) {
		GMMap oMap = new GMMap();
		Gson gson = new Gson();
		Object objEventDetail = null;
		List<Object> objList = new ArrayList<Object>();

		try {

			if (StringUtils.isEmpty(iMap.getString("EVENT_TYPE")))
				throw new RuntimeException(GECERSIZ_EVENT);

			EventTypeEnum eventType = EventTypeEnum.valueOf(iMap.getString("EVENT_TYPE"));


			if (eventType == EventTypeEnum.KartDurumGuncelleEvent) {
				KartDurumEventDetail eventDetail = new KartDurumEventDetail();
				eventDetail.setKartDurum(iMap.getString("KART_DURUM"));
				eventDetail.setKimlikNo(iMap.getString("KIMLIK_NO"));
				eventDetail.setCardType(iMap.getString("CARD_TYPE"));
				eventDetail.setName(eventType.getEventName());
				objEventDetail = eventDetail;


			}
			else if (eventType == EventTypeEnum.TopupEvent) {
				ParaTransferEventDetail eventDetail = new ParaTransferEventDetail();
				eventDetail.setKimlikNo(iMap.getString("KIMLIK_NO"));
				eventDetail.setCardType(iMap.getString("CARD_TYPE"));
				eventDetail.setTutar(iMap.getBigDecimal("TUTAR").floatValue());
				eventDetail.setName(eventType.getEventName());
				objEventDetail = eventDetail;

			}
			else if (eventType == EventTypeEnum.DebitBakiyeEvent) {
				Profile profile = new Profile();
				profile.setCardLimit(iMap.getBigDecimal("TUTAR").setScale(0, RoundingMode.DOWN).intValueExact());

				DebitBakiyeEventDetail eventDetail = new DebitBakiyeEventDetail();
				eventDetail.setKimlikNo(iMap.getString("KIMLIK_NO"));
				eventDetail.setProfile(profile);
				objEventDetail = eventDetail;

			}
			else
				throw new RuntimeException(GECERSIZ_EVENT);

			/*Pojo �zerideki alanlar�n bos olmamas� kontrol�*/
			((INullController) (objEventDetail)).checkNull();

			/*Json'a �evrilecek list olusturuluyor*/
			objList.add(objEventDetail);

			iMap.clear();
			iMap.put("APP", eventType.getAppName());

			// Event i�in olu�turulan arraylist, json format�na �evriliyor.
			iMap.put("JSON_DATA", gson.toJson(objList));
			iMap.put("SERVICE_ID", eventType.getServiceId());

			GMServiceExecuter.call("BNSPR_PUSH_MESSAGE_INSERT_INTO_SAF", iMap);

		}
		catch (IllegalArgumentException e) {
			System.out.println(StringUtils.left(e.getMessage(), 200));
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", GECERSIZ_EVENT);

			return oMap;
		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));

			return oMap;
		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;


	}

	/**
	 * BASVURU_NO
	 * DURUM_KOD
	 * 
	 * @return
	 *         RESPONSE_CODE -> 0 Ba�ar�l�, 99 ba�ar�s�z
	 *         RESPONSE_DESC
	 */


	@GraymoundService("BNSPR_PUSH_KART_DURUM_GUNCELLE_EVENT")
	public static GMMap pushKartDurumGuncelleEvent(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			
			String basvuruNo = iMap.getString("BASVURU_NO");
			String durum_kod = iMap.getString("DURUM_KOD");
			String kart_tipi;

			if (StringUtils.isEmpty(basvuruNo))
				throw new Exception(BASVURU_BOS_OLAMAZ);

			iMap.clear();

			kart_tipi = findKartTipi(basvuruNo);

			/*Kredi kartlar� sadece Ac�k ve Bas�m statusunde ise Netmerey� besleyecek*/
			if (NETMERA_KREDI_KARTI_GOSTERIM.equals(kart_tipi) && !(ACIK_KART.equals(durum_kod) || KART_BASIMDA.equals(durum_kod)))
				throw new Exception(UYGUN_OLMAYAN_KART_STATUS);
			else {
				iMap.put("EVENT_TYPE", EventTypeEnum.KartDurumGuncelleEvent.toString());
				iMap.put("KIMLIK_NO", findKimlikNo(basvuruNo));
				iMap.put("KART_DURUM", durum_kod);
				iMap.put("CARD_TYPE", kart_tipi);
				oMap.putAll(GMServiceExecuter.call("BNSPR_KK_SEND_EVENT_TO_NETMERA", iMap));
				if (String.valueOf(RUNTIME_EXCEPTION_CODE).equals(oMap.getString("RESPONSE_CODE")))
					throw new Exception(oMap.getString("RESPONSE_DESC"));
			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));
			return oMap;

		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;

	}

	/**
	 * 
	 * 
	 * CARD_NO
	 * BASVURU_NO
	 * TUTAR
	 * 
	 * @return
	 *         RESPONSE_CODE -> 0 Ba�ar�l�, 99 ba�ar�s�z
	 *         RESPONSE_DESC
	 */

	@GraymoundService("BNSPR_PUSH_TFF_TOPUP_EVENT")
	public static GMMap pushTffTopupEvent(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String cardNo = iMap.getString("CARD_NO");
			String basvuruNo = iMap.getString("BASVURU_NO");
			String kimlikNo;
			String kart_tipi;


			if (!StringUtils.isEmpty(cardNo)) {
				String kartBasvuruNo;
				kartBasvuruNo = findBasvuruNoFromCard(cardNo);
				kimlikNo = findKimlikNo(kartBasvuruNo);
				kart_tipi = findKartTipi(kartBasvuruNo);
			}
			else if (!StringUtils.isEmpty(basvuruNo)) {
				kimlikNo = findKimlikNo(basvuruNo);
				kart_tipi = BASVURU;
			}
			else
				throw new Exception(BASVURU_VEYA_KART_BOS_OLAMAZ);

			iMap.put("EVENT_TYPE", EventTypeEnum.TopupEvent.toString());
			iMap.put("KIMLIK_NO", kimlikNo);
			iMap.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			iMap.put("CARD_TYPE", kart_tipi);
			oMap.putAll(GMServiceExecuter.call("BNSPR_KK_SEND_EVENT_TO_NETMERA", iMap));
			if (String.valueOf(RUNTIME_EXCEPTION_CODE).equals(oMap.getString("RESPONSE_CODE")))
				throw new Exception(oMap.getString("RESPONSE_DESC"));

		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));
			return oMap;

		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;

	}

	/**
	 * 1601VD
	 * BNSPR_KARTA_PARA_YUKLE ve BNSPR_KARTA_PARA_YUKLE_PTT servisinden yap�lan topuplar i�in crd_karta_para_yukle_tx tablosundan tx_no ile topup �demelerini (iptal istenmedi)
	 * bildiren servis
	 * 
	 * @return
	 *         RESPONSE_CODE -> 0 Ba�ar�l�, 99 ba�ar�s�z
	 *         RESPONSE_DESC
	 */

	@GraymoundService("BNSPR_FEED_NETMERA_WITH_TOPUP_PROCESS")
	public static GMMap feedNetmeraFromTopup(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			CrdKartaParaYukleTx topupIslem = null;
			Session session = null;
			iMap.clear();

			if (txNo.equals(BigDecimal.ZERO) || txNo == null)
				throw new Exception(TX_NO_BOS_OLAMAZ);

			/*Hibernate thread safe sa�lamak i�in*/

			for (int i = 0; i < 5; i++) {
				if (topupIslem == null) {
					Thread.sleep(1000);
					session = DAOSession.getSession("BNSPRDal");
					topupIslem = (CrdKartaParaYukleTx) session.get(CrdKartaParaYukleTx.class, txNo);
				}
				else
					break;
			}
			

			if(topupIslem == null)
				throw new Exception(TOPUP_BULUNAMADI);

			if (TOPUP_ODEME.equals(topupIslem.getIslemCinsi())) {
				iMap.put("CARD_NO", topupIslem.getKartNo());
				iMap.put("TUTAR", topupIslem.getTutar());
				iMap.put("BASVURU_NO", topupIslem.getBasvuruNo());
				oMap.putAll(GMServiceExecuter.call("BNSPR_PUSH_TFF_TOPUP_EVENT", iMap));
				if (String.valueOf(RUNTIME_EXCEPTION_CODE).equals(oMap.getString("RESPONSE_CODE")))
					throw new Exception(oMap.getString("RESPONSE_DESC"));
				}

		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));
			return oMap;

		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;

	}

	/**
	 * 1601VD
	 * POS'tan yap�lan i�lemlerde smartsoft servisinden beslenen topuplar i�in prepaid_topup_process_tx tablosundan tx_no ile topup �demelerini (iptal istenmedi)
	 * bildiren servis
	 * 
	 * @return
	 *         RESPONSE_CODE -> 0 Ba�ar�l�, 99 ba�ar�s�z
	 *         RESPONSE_DESC
	 */

	@GraymoundService("BNSPR_FEED_NETMERA_WITH_TOPUP_FROM_POS")
	public static GMMap feedNetmeraTopupFromPos(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			PrepaidTopupProcessTx topupIslem = null;
			Session session = null;

			if (txNo.equals(BigDecimal.ZERO) || txNo == null)
				throw new Exception(TX_NO_BOS_OLAMAZ);

			/*Hibernate thread safe sa�lamak i�in*/

			for (int i = 0; i < 5; i++) {
				if (topupIslem == null) {
					Thread.sleep(1000);
					session = DAOSession.getSession("BNSPRDal");
					topupIslem = (PrepaidTopupProcessTx) session.get(PrepaidTopupProcessTx.class, txNo);
				}
				else
					break;
			}
			iMap.clear();
			
			if(topupIslem == null)
				throw new Exception(TOPUP_BULUNAMADI);

			iMap.put("CARD_NO", topupIslem.getTopupCardNo());
			iMap.put("TUTAR", topupIslem.getTopupAmount());
			oMap.putAll(GMServiceExecuter.call("BNSPR_PUSH_TFF_TOPUP_EVENT", iMap));
			if (String.valueOf(RUNTIME_EXCEPTION_CODE).equals(oMap.getString("RESPONSE_CODE")))
				throw new Exception(oMap.getString("RESPONSE_DESC"));

		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));
			return oMap;

		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;

	}

	/**
	 * 1601VD
	 * Da��t�m kanallar�na login olundu�unda, evam taraf�ndan tetiklenen bu servis,
	 * m��terinin varsa hesab�ndaki kmh'l� limiti netmeraya besler
	 *
	 * TCKN
	 * 
	 * @return
	 *         RESPONSE_CODE -> 0 Ba�ar�l�, 99 ba�ar�s�z
	 *         RESPONSE_DESC
	 */

	@GraymoundService("BNSPR_PUSH_NETMERA_FROM_EVAM_FOR_DEBIT_AVAILABLE_LIMIT")
	public static GMMap pushNetmeraFromEvamForLimit(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			final String tckn = iMap.getString("TCKN");

			try {
				GMServiceExecuter.call("BNSPR_TRN8000_NETMERA_EVENT", iMap);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			try {
				GMServiceExecuter.call("BNSPR_INTRACARD_PASSO_APP_LOGIN_NOTIFY", iMap);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			try {
				GMServiceExecuter.call("BNSPR_OCEAN_PASSO_APP_LOGIN_NOTIFY", iMap);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			try {
				GMServiceExecuter.call("BNSPR_MENKUL_BONO_BILGI", iMap);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			try {
				GMServiceExecuter.call("BNSPR_EGO_LOGIN_PUSH_NOTIFICATION", iMap);
			}
			catch (Exception e) {
				e.printStackTrace();
			}	
			iMap.clear();


			if (StringUtils.isEmpty(tckn) && StringUtils.isEmpty(tckn))
				throw new RuntimeException(UYGUN_OLMAYAN_KART_STATUS);
			else {
				BigDecimal tutar = findKMHLimit(tckn);
				if (tutar == null)
					throw new Exception(TUTAR_BOS_OLAMAZ);
				iMap.put("EVENT_TYPE", EventTypeEnum.DebitBakiyeEvent.toString());
				iMap.put("KIMLIK_NO", tckn);
				iMap.put("TUTAR", tutar);
				oMap.putAll(GMServiceExecuter.call("BNSPR_KK_SEND_EVENT_TO_NETMERA", iMap));
				if (String.valueOf(RUNTIME_EXCEPTION_CODE).equals(oMap.getString("RESPONSE_CODE")))
					throw new Exception(oMap.getString("RESPONSE_DESC"));
			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));
			return oMap;

		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;

	}



	private static String findKimlikNo(String basvuruNo) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		String kimlikNo = null;
		
		
		TffBasvuruKimlik basvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, new BigDecimal(basvuruNo));
		session.clear();
		
		if (basvuruKimlik == null)
			throw new RuntimeException(KIMLIK_BILGISI_BULUNAMADI);

		// TCKN veya ULKE_KODU + PASOPORT NO
		kimlikNo = (!StringUtils.isEmpty(basvuruKimlik.getTcKimlikNo())) ? basvuruKimlik.getTcKimlikNo() : (basvuruKimlik.getUyrukKod() + basvuruKimlik.getPasaportNo());
		
		return kimlikNo;
	}

	private static String findKartTipi(String basvuruNo) {

		Session session = DAOSession.getSession("BNSPRDal");
		String kart_tipi;

		TffBasvuru basvuru = (TffBasvuru) session.get(TffBasvuru.class, new BigDecimal(basvuruNo));

		if (basvuru == null)
			throw new RuntimeException(BASVURU_BULUNAMADI);

		kart_tipi = basvuru.getKartTipi();

		return (AKUSTIK_KREDI_KARTI_GOSTERIM.equals(kart_tipi) ? NETMERA_KREDI_KARTI_GOSTERIM : kart_tipi);

	}

	private static String findBasvuruNoFromCard(String cardNo) {

		Session session = DAOSession.getSession("BNSPRDal");

		TffBasvuru basvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kartNo", cardNo)).uniqueResult();

		if (basvuru == null)
			throw new RuntimeException(BASVURU_BULUNAMADI);

		return basvuru.getBasvuruNo().toString();
	}

	// Tff debit kart�ndaki kmh'l� tutar� d�ner
	private static BigDecimal findKMHLimit(String tckn) {
		GMMap iMap = new GMMap();
		GMMap oMap = new GMMap();
		iMap.put("TCKN", tckn);
		iMap.put("CARD_DCI", DEBIT_CARD_DCI);
		oMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", iMap));

		return oMap.getBigDecimal("CARD_DETAIL_INFO", 0, "CARD_AVAIL_LIMIT");
	}

	public static final String INTEGRATION_CONF_FILE = "aktifbank-int-cardintegration.properties";
	private static String url = "";

	public static Configurator loadIntegrationConfigurationFile() {
		return loadConfigurationFile(INTEGRATION_CONF_FILE);
	}

	public static Configurator loadConfigurationFile(String confFile) {
		return Configurator.createConfiguratorFromProperties(confFile);
	}

	protected static Object messageSender(String serviceName) {

		String output = null;

		try {
			// Class<?> pojo = Class.forName("tr.com.aktifbank.bnspr.cardintegration.model." + serviceName);
			ClientConfig config = new DefaultClientConfig();
			Client client = Client.create(config);
			Configurator conf = loadIntegrationConfigurationFile();
			url = conf.getProperty("url") + "/" + serviceName;
			WebResource webResource = client.resource(url);
			WebResource.Builder builder = webResource.accept("application/json");
			builder.header("ad", "volkan");

			ClientResponse response = builder.get(ClientResponse.class);
			// ClientResponse response = builder.post(ClientResponse.class, requestBody);
			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
			output = response.getEntity(String.class);


			// return new Gson().fromJson(output, pojo);
		}
		catch (Exception e) {

			e.printStackTrace();

		}
		return output;

	}




}
