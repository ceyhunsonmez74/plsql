package tr.com.aktifbank.bnspr.netmera.services;

public interface INullController {

	public void checkNull();

}
