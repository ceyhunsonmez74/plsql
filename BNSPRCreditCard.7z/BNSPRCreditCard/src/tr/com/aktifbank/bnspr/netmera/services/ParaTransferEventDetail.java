package tr.com.aktifbank.bnspr.netmera.services;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;
import com.graymound.util.GMRuntimeException;

public class ParaTransferEventDetail implements INullController {

	@SerializedName("extId")
	private String kimlikNo;

	@SerializedName("tutar")
	private Float tutar;

	@SerializedName("cardType")
	private String cardType;

	@SerializedName("name")
	private String name;


	public String getKimlikNo() {
		return kimlikNo;
	}

	public void setKimlikNo(String kimlikNo) {
		this.kimlikNo = kimlikNo;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public Float getTutar() {
		return tutar;
	}

	public void setTutar(Float tutar) {
		this.tutar = tutar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public void checkNull() {
		Field fields[] = this.getClass().getDeclaredFields();
		for (Field f : fields) {
			try {
				Object value = f.get(this);
				if (value == null) {
					throw new GMRuntimeException(99, f.getName().toUpperCase() + " degeri bos olamaz");
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GMRuntimeException(99, e.getMessage());
			}

		}

	}



}
