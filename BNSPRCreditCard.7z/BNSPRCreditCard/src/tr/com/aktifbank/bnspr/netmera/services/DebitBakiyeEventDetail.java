package tr.com.aktifbank.bnspr.netmera.services;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;
import com.graymound.util.GMRuntimeException;

public class DebitBakiyeEventDetail implements INullController {

	@SerializedName("extId")
	private String kimlikNo;

	private Profile profile;

	public String getKimlikNo() {
		return kimlikNo;
	}

	public void setKimlikNo(String kimlikNo) {
		this.kimlikNo = kimlikNo;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	@Override
	public String toString() {
		return "ClassPojo [extId = " + kimlikNo + ", profile = " + profile + "]";
	}

	public void checkNull() {
		Field fields[] = this.getClass().getDeclaredFields();
		for (Field f : fields) {
			try {
				Object value = f.get(this);
				if (value == null) {
					throw new GMRuntimeException(99, f.getName().toUpperCase() + " degeri bos olamaz");
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GMRuntimeException(99, e.getMessage());
			}

		}

	}


}
