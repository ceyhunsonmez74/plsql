package tr.com.aktifbank.bnspr.netmera.services;

/*1601VD
 * serviceId-> "2" profile attribute , "3" push event*/
public enum EventTypeEnum {
	KartDurumGuncelleEvent("KartDurumEvent", "3", "PASSO"),

	TopupEvent("ParaTransferEvent", "3", "PASSO"),

	DebitBakiyeEvent("1", "PASSO");

	private String eventName;
	private String serviceId;
	private String appName;

	private EventTypeEnum(String eventName, String serviceId, String appName) {
		this.eventName = eventName;
		this.serviceId = serviceId;
		this.appName = appName;
	}
	
	private EventTypeEnum(String serviceId, String appName) {
		this.serviceId = serviceId;
		this.appName = appName;
	}
	
	public String getEventName() {
		return eventName;
	}
	
	public String getServiceId() {
		return serviceId;
	}

	public String getAppName() {
		return appName;
	}

}
