package tr.com.aktifbank.bnspr.netmera.services;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;
import com.graymound.util.GMRuntimeException;

public class Profile implements INullController {

	@SerializedName("debitKullanilabilirBakiye")
	private int cardLimit;

	public int getCardLimit() {
		return cardLimit;
	}

	public void setCardLimit(int cardLimit) {
		this.cardLimit = cardLimit;
	}

	@Override
	public String toString() {
		return "ClassPojo [cardLimit = " + cardLimit + "]";
	}

	public void checkNull() {
		Field fields[] = this.getClass().getDeclaredFields();
		for (Field f : fields) {
			try {
				Object value = f.get(this);
				if (value == null) {
					throw new GMRuntimeException(99, f.getName().toUpperCase() + " degeri bos olamaz");
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GMRuntimeException(99, e.getMessage());
			}

		}

	}
}