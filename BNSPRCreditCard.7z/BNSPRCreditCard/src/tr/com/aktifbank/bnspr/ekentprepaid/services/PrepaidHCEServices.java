package tr.com.aktifbank.bnspr.ekentprepaid.services;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.Constants;
import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDef;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.CommonDAOUtil;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.calikbank.bnspr.util.OceanMapKeys;

public class PrepaidHCEServices  implements OceanMapKeys,Constants {
	
private static final Logger logger = Logger.getLogger(PrepaidHCEServices.class);

private static final String IssuingExceptionApplicationNoUsedBefore = "Issuing.Exception.ApplicationNoUsedBefore";


	@GraymoundService("BNSPR_CREATE_OCEAN_HCE_CUSTOMER")
	public static GMMap createOceanHceCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		
		oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			
			//Musteri olustur
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.getString(APPLICATION_NO_ECOMMERCE));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_CREDIT_CARD_CUSTOMER", sorguMap));
			String custResult = sorguMap.getString("ORESULT");
			String custResultDesc = sorguMap.getString(RETURN_DESCRIPTION);
			//Kontrol
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString(RETURN_CODE))) {
				oMap.put(RESPONSE_DATA, custResult + "-" + custResultDesc);
				return oMap;
			}
			// Sonuc
			oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_CREATE_HCE_CARD")
	public static GMMap createHceCard(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KK_BASVURU.Get_HCE_Card_Info_For_Ocean(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			//Karti olustur
			logger.info("BNSPR_OCEAN_CREATE_HCE_CARD INPUT : " + iMap.toString());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_HCE_CARD", iMap));
			logger.info("BNSPR_OCEAN_CREATE_HCE_CARD OUTPUT : " + oMap.toString());
			
			//Hata varsa mail at
			if (!"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "Debit Ocean Card Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CREATE_OCEAN_HCE_CARD")
	public static GMMap createOceanHceCard(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARISIZ);


		try {
		
			// Kart olustur
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.getString(APPLICATION_NO_ECOMMERCE));

			if (!StringUtils.isEmpty( iMap.getString(WALLET_ID))){
				sorguMap.put(WALLET_ID, iMap.getString(WALLET_ID));
			}
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_HCE_CARD", sorguMap));
			// Kontrol
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString(RETURN_CODE))) {
				oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARISIZ);
				oMap.put(RESPONSE_DATA,sorguMap.getString(RETURN_DESCRIPTION));
				return oMap;
			}
			
			// Kart no olusmamissa cik.
			if (StringUtils.isBlank(sorguMap.getString(CARD_NO_ECOMMERCE))) {
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ );
				oMap.put("RESPONSE_DATA", TffServicesMessages.KART_NO_BOS);
				return oMap;
			}

			oMap.put(CARD_NO_ECOMMERCE, sorguMap.getString(CARD_NO_ECOMMERCE));
			oMap.put(CARD_NO_OFFLINE, sorguMap.getString(CARD_NO_OFFLINE));
			oMap.put(CARD_NO_ONLINE, sorguMap.getString(CARD_NO_ONLINE));
			oMap.put(PRODUCT_NO_ECOMMERCE, sorguMap.getString(PRODUCT_NO_ECOMMERCE));
			oMap.put(PRODUCT_NO_OFFLINE, sorguMap.getString(PRODUCT_NO_OFFLINE));
			oMap.put(PRODUCT_NO_ONLINE, sorguMap.getString(PRODUCT_NO_ONLINE));
			oMap.put(APPLICATION_NO_ECOMMERCE, iMap.getString(APPLICATION_NO_ECOMMERCE));
			oMap.put(APPLICATION_NO_OFFLINE, iMap.getString(APPLICATION_NO_OFFLINE));
			oMap.put(APPLICATION_NO_ONLINE, iMap.getString(APPLICATION_NO_ONLINE));
			oMap.put(PUSH_NOTIFICATION_MESSAGE, sorguMap.getString(PUSH_NOTIFICATION_MESSAGE));
			oMap.put(PUSH_NOTIFICATION_MESSAGE_2, sorguMap.getString(PUSH_NOTIFICATION_MESSAGE_2));

			// Kart no guncelle
			    int rowNo = 0;
				Session session =  DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			    String[][] appArray = new String[3][2];
			    if (StringUtils.isNotEmpty(iMap.getString(APPLICATION_NO_ONLINE))){
				    appArray[rowNo][0] =iMap.getString(APPLICATION_NO_ONLINE);
				    appArray[rowNo][1] = sorguMap.getString(CARD_NO_ONLINE);
				    rowNo++;
			    }
			    if (StringUtils.isNotEmpty(iMap.getString(APPLICATION_NO_OFFLINE))){
				    appArray[rowNo][0] = iMap.getString(APPLICATION_NO_OFFLINE);
				    appArray[rowNo][1] = sorguMap.getString(CARD_NO_OFFLINE);
				    rowNo++;
			    }
			    if (StringUtils.isNotEmpty(iMap.getString(APPLICATION_NO_ECOMMERCE))){
				    appArray[rowNo][0] = iMap.getString(APPLICATION_NO_ECOMMERCE);
				    appArray[rowNo][1] = sorguMap.getString(CARD_NO_ECOMMERCE);
				    rowNo++;
			    }
			    
			    for(int i = 0; i < rowNo; i++){
					KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, new BigDecimal(appArray[i][0]));
					if (kkBasvuru != null ) {
						kkBasvuru.setKartNo(appArray[i][1]);
						session.saveOrUpdate(kkBasvuru);
						session.flush();
					}
				}

			// Sonuc
			oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	

	@GraymoundService("BNSPR_START_VIRTUAL_PREPAID_APPLICATION")
	public static GMMap startVirtualPrepaidApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap outMap  = new GMMap();
		
		String virtualPPUrunId = KkProductsUtil.getVirtualProductId();
		
		BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString(COUNTRY_CODE), iMap.getString(TCKN), iMap.getString(PASSPORT_NO));
	
		if (iMap.get(TRX_NO) == null) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		}
		if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {

			GMMap customerMap = new GMMap();

			customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CUSTOMER", iMap));
			musteriNo = customerMap.getBigDecimal("MUSTERI_NO");
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
				return customerMap;
			}

		}

		else {
			// update aps adress if necessary
			if ("TR".equals(iMap.getString(COUNTRY_CODE))) {
				GMMap customerMap = new GMMap();
				customerMap.put(TCKN, iMap.getString(TCKN));
				customerMap.put(TRX_NO, iMap.get(TRX_NO));
				customerMap.put("MUSTERI_NO", musteriNo);
				customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER_APS_ADRESS", customerMap));
				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(customerMap.getString(RESPONSE))) {
					return customerMap;
				}
			}

		}

		GMMap applicationMap = new GMMap();
		applicationMap.putAll(iMap);
		applicationMap.put("MUSTERI_NO", musteriNo);
		
    	GMMap cMap = new GMMap();
   	 	cMap.put(CARD_DCI, OceanConstants.Akustik_AllCardDci);
        cMap.put(CUSTOMER_NO, musteriNo);
        cMap.put(TCKN, iMap.getString(TCKN));
        cMap.put(CARD_BANK_STATUS, OceanConstants.Card_Bank_Status_Open);
       
		try {
			cMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cMap));
		}
		catch (Exception e) {
			oMap.put(RESPONSE, OceanConstants.Result_Akustik_Error);
			oMap.put(RESPONSE_DATA, TffServicesMessages.BASVURU_KART_BILGI_VER_INTRACARD_HATASI);
			return oMap;
		}
        boolean aktifKartVar = false;
        for (int i = 0; i < cMap.getSize(CARD_DETAIL_INFO); i++){
        	
        	if (virtualPPUrunId.equals(cMap.get(CARD_DETAIL_INFO , i , PRODUCT_ID))){
        		aktifKartVar = true;
        		break;
        	}
        
        }
        
		if(aktifKartVar){
			oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			oMap.put(RESPONSE_DATA,TffServicesMessages.AKTIF_BASVURU_VAR_HATASI );
			return oMap;
		}

		applicationMap.put("URUN_ID", virtualPPUrunId);
		applicationMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		applicationMap.putAll(PrepaidEkentMobilServices.createApplicationRecord(applicationMap));

		// ss createcustomer and createhcecard
		oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_OCEAN_VIRTUAL_CARD_AND_CUSTOMER", applicationMap));

		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString(RESPONSE))) {
			return oMap;
		}
		
		
		//Basvuru durumunu guncelle
		GMMap sorguMap = new GMMap();
		sorguMap.put("BASVURU_NO", applicationMap.get(APPLICATION_NO));
		sorguMap.put("ISLEM_NO", applicationMap.get(TRX_NO));
		sorguMap.put("DURUM_KOD", "ACIK");
		sorguMap.put("TARIHCE_AKSIYON", "E");
		GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
		
		outMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
		outMap.put(CUSTOMER_NO, musteriNo);
		outMap.put(MASKED_CARD_NO, oMap.getString(MASKED_CARD_NO));
		outMap.put(CARD_NO, oMap.getString(CARD_NO));


		return outMap;

	}
	
	
	@GraymoundService("BNSPR_CREATE_OCEAN_VIRTUAL_CARD_AND_CUSTOMER")
	public static GMMap createOceanVirtualCardAndCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Musteri olustur
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get(APPLICATION_NO));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_CREDIT_CARD_CUSTOMER", sorguMap));
			String custResult = sorguMap.getString("ORESULT");
			String custResultDesc = sorguMap.getString(RETURN_DESCRIPTION);
			//Kontrol
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString(RETURN_CODE))) {
				oMap.put(RESPONSE_DATA, custResult + "-" + custResultDesc);
				return oMap;
			}

			//kart yaratma
			ResultSet rSet = null;
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KK_BASVURU.Get_Virtual_PP_Info_For_Ocean(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal(APPLICATION_NO));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			//Karti olustur
			iMap.put(CARD_DCI, OceanConstants.Akustik_PrepaidCard);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_DEBIT_CARD", iMap));

			
			String kartNo =  oMap.getString(CARD_NO);
			String cardResult = oMap.getString("ORESULT");
			String cardResultDesc = oMap.getString(RETURN_DESCRIPTION);
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString(RETURN_CODE))) {
				//Tekrar kullan�ld� hatasi aldi ise basvuru no ile kart no bilgisini all ve devam et
				//1.Hata mesaji:ORESULT=SystemError, ERROR_DETAIL=System.Exception: Girilen ApplicationNo 
				//ve Customer bilgileriyle basvuru daha once yapilmistir.CardNo:  6711210163228796
				//2.Hata mesaji:ORESULT=Error, ERROR_DETAIL=This application no is used before :3082517
				//String cardResultError = sorguMap.getString("ERROR_DETAIL");
				//if ( (cardResultError.indexOf("ApplicationNo") > 0 && cardResultError.indexOf("CardNo") > 0) || 
				//		cardResultDesc.indexOf("This application no is used before") > 0) {
				if (BnsprOceanCommonFunctions.convertNewReturnCodeToOld(IssuingExceptionApplicationNoUsedBefore).equals(oMap.getString("RETURN_CODE"))){

					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get(APPLICATION_NO));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_KART_NO_BY_BASVURU_NO", sorguMap));
					//Kontrol
					if (StringUtils.isNotBlank(sorguMap.getString("KART_NO"))) {
						kartNo = sorguMap.getString("KART_NO");
					}
				}
			}
			
			//Kart no olusmamissa cik.
			if (StringUtils.isBlank(kartNo)) {
				oMap.put(RESPONSE_DATA, cardResult + "-" + cardResultDesc + "-" + "KartNo:" + kartNo);
				return oMap;
			}
			
			//Kart no guncelle
			Session session =  DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal(APPLICATION_NO));
			if (kkBasvuru != null ) {
				kkBasvuru.setKartNo(kartNo);
				session.saveOrUpdate(kkBasvuru);
				session.flush();
			}
			
			//Sonuc
			oMap.put(RESPONSE, CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
  

	public static void main(String[] args) {
		String virtualPPUrunId = KkProductsUtil.getVirtualProductId();

		System.out.println( virtualPPUrunId);
	}
}
