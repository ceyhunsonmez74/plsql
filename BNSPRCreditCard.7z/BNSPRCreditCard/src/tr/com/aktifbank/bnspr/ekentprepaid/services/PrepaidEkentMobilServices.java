package tr.com.aktifbank.bnspr.ekentprepaid.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.aktifbank.bnspr.prepaidcard.services.PrepaidCardNoNameServices;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.AkustikConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.calikbank.bnspr.util.OceanMapKeys;


public class PrepaidEkentMobilServices implements OceanMapKeys {


	@GraymoundService("BNSPR_EKENTMOBIL_CONTROL_PREPAID_APPLICATION")
	public static GMMap controlPrepaidApplicationEkentMobil(GMMap iMap) {
		GMMap oMap = new GMMap();
		String name="";
		String secondName="";
		String surname="";

	
		GMMap validateMap = new GMMap();
		iMap.put("TCKN_RAISE_ERROR", false);
		validateMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_CARD_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(validateMap.getString("RESPONSE"))) {
			return validateMap;
		}
		else if (validateMap.containsKey("CARD_NO") && !StringUtils.isEmpty(validateMap.getString("CARD_NO"))){
			oMap.put("CARD_NO", validateMap.getString("CARD_NO"));
		}

		BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
		// do�um tarihi kontrol�
		String gercekDogumTar = "";
		if (BigDecimal.ZERO.compareTo(musteriNo) == 0) {
			GMMap kpsMap = new GMMap();
			kpsMap.put("TCKN", iMap.getString("TCKN"));
			kpsMap.put("TCK_NO", iMap.getString("TCKN"));
			kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
				return oMap;
			}
			gercekDogumTar = kpsMap.getString("DOGUM_TARIHI");
			name = kpsMap.getString("AD1");
			secondName = kpsMap.getString("AD2");	
			surname =kpsMap.getString("SOYAD");	
		}
		else {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlMusteriKimlik gnlMusteriKimlik = (GnlMusteriKimlik) session.createCriteria(GnlMusteriKimlik.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();
			if (gnlMusteriKimlik != null)
			{
				if (gnlMusteriKimlik.getDogumTarihi()!= null){
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
					gercekDogumTar = dateFormat.format(gnlMusteriKimlik.getDogumTarihi());
				}
				else{
					
					GMMap kpsMap = new GMMap();
					kpsMap.put("TCKN", iMap.getString("TCKN"));
					kpsMap.put("TCK_NO", iMap.getString("TCKN"));
					kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
					if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
						return oMap;
					}
					gercekDogumTar = kpsMap.getString("DOGUM_TARIHI");					
				}
			}
			GnlMusteri gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();

			if(gnlMusteri != null){
				name = gnlMusteri.getAdi();
				secondName = gnlMusteri.getIkinciAdi();	
				surname = gnlMusteri.getSoyadi();	
			}
		}

		String birthDate = iMap.getString("BIRTH_DATE");
		if (birthDate.length() == 7) {
			birthDate = StringUtils.substring(iMap.getString("BIRTH_DATE"), 0, 6) + "0" + StringUtils.substring(iMap.getString("BIRTH_DATE"), 6, 7);
		}
		if (!birthDate.equals(gercekDogumTar)) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.DOGUM_TARIHI_HATALI);
			return oMap;
		}

		if (!PrepaidCardNoNameServices.basvuruYasKontrol(iMap.getString("SOURCE"),gercekDogumTar)){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_YAS_KONTROLU);
			return oMap;
		}

		// telefon kontrolleri
		GMMap phoneMap = new GMMap();
		phoneMap.put("CUSTOMER_NO", musteriNo);
		phoneMap.put("PHONE_COUNTRY_CODE", iMap.getString("PHONE_COUNTRY_CODE"));
		phoneMap.put("PHONE_OPERATOR_CODE", iMap.getString("PHONE_OPERATOR_CODE"));
		phoneMap.put("PHONE_NUMBER", iMap.getString("PHONE_NUMBER"));
		phoneMap.put(SOURCE, iMap.getString(SOURCE));
		phoneMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_APPLICATION_PHONE_CONTROL", phoneMap));

		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(phoneMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", phoneMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", phoneMap.getString("RESPONSE_DATA"));
			if (!StringUtils.isEmpty(phoneMap.getString("OTP_PHONE_NUMBER"))){
				oMap.put("OTP_PHONE_NUMBER", phoneMap.getString("OTP_PHONE_NUMBER"));
				}
			return oMap;
		}

		oMap.put("CUSTOMER_NO", musteriNo);
		oMap.put("NAME", name);
		oMap.put("SECOND_NAME", secondName);	
		oMap.put("SURNAME", surname);
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;

	}
	
	@GraymoundService("BNSPR_EKENTMOBIL_START_PREPAID_APPLICATION")
	public static GMMap startPrepaidApplicationEkentMobil(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		String ECOMMERCE_URUN_ID = KkProductsUtil.getHceProductId(ECOM);
		String ONLINE_URUN_ID = KkProductsUtil.getHceProductId(ONLINE);
		
		HCEOfflineCardSource hceOffline = HCEOfflineCardSource.getByName(iMap.getString(SOURCE));
		String OFFLINE_URUN_ID = KkProductsUtil.getHceProductId(hceOffline.getSubSource(), hceOffline.getSpecialDefinition());
		
		BigDecimal musteriNo = iMap.getBigDecimal("CUSTOMER_NO");
		
		if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
			musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
		}

		if (iMap.get("TRX_NO") == null) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		}
		if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {

			GMMap customerMap = new GMMap();
			
			iMap.put("SKIP_APS", true);
			customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CUSTOMER", iMap));
			musteriNo = customerMap.getBigDecimal("MUSTERI_NO");
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
				return customerMap;
			}

		}

		else {
			// update aps adress if necessary
			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
				GMMap customerMap = new GMMap();
				customerMap.put("TCKN", iMap.getString("TCKN"));
				customerMap.put("TRX_NO", iMap.get("TRX_NO"));
				customerMap.put("MUSTERI_NO", musteriNo);
				customerMap.put("SKIP_APS", true);
				customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER_APS_ADRESS", customerMap));
				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(customerMap.getString("RESPONSE"))) {
					return customerMap;
				}
			}

		}
		
		GMMap kkApplicationMap = new GMMap();
		GMMap applicationMap = new GMMap();
		GMMap statusMap = new GMMap();
		applicationMap.putAll(iMap);
		applicationMap.put("MUSTERI_NO", musteriNo);
		
						
			Session session = DAOSession.getSession("BNSPRDal");
			List<KkBasvuru> kkBasvuruEcom = (List<KkBasvuru>) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo)).add(Restrictions.eq("urunTipi", ECOMMERCE_URUN_ID)).add(Restrictions.eq("durumKod", "ACIK")).list();			
			if(kkBasvuruEcom != null && kkBasvuruEcom.size() > 0 ){
				kkApplicationMap.put(OceanMapKeys.APPLICATION_NO_ECOMMERCE, kkBasvuruEcom.get(0).getBasvuruNo());
				kkApplicationMap.put("URUN_ID", ECOMMERCE_URUN_ID);
				statusMap.remove("TRX_NO");
				statusMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				statusMap.put("TRX_NO_ECOMMERCE",statusMap.getBigDecimal("TRX_NO"));

			}
			else{
				applicationMap.remove("URUN_ID");	
				applicationMap.put("URUN_ID", ECOMMERCE_URUN_ID);
				applicationMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				statusMap.put("TRX_NO_ECOMMERCE",applicationMap.getBigDecimal("TRX_NO"));
				kkApplicationMap.putAll(createApplicationRecord(applicationMap));
				kkApplicationMap.put(OceanMapKeys.APPLICATION_NO_ECOMMERCE, kkApplicationMap.getBigDecimal("APPLICATION_NO"));
			}

			List<KkBasvuru> kkBasvuruOnline = (List<KkBasvuru>) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo)).add(Restrictions.eq("urunTipi", ONLINE_URUN_ID)).add(Restrictions.eq("durumKod", "ACIK")).list();
			if(kkBasvuruOnline != null && kkBasvuruOnline.size() > 0){
				kkApplicationMap.put(OceanMapKeys.APPLICATION_NO_ONLINE, kkBasvuruOnline.get(0).getBasvuruNo());
				kkApplicationMap.put("URUN_ID", ONLINE_URUN_ID);
				statusMap.remove("TRX_NO");
				statusMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				statusMap.put("TRX_NO_ONLINE",statusMap.getBigDecimal("TRX_NO"));
			}
			else{
				applicationMap.remove("URUN_ID");	
				applicationMap.put("URUN_ID", ONLINE_URUN_ID);
				applicationMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				statusMap.put("TRX_NO_ONLINE",applicationMap.getBigDecimal("TRX_NO"));
				kkApplicationMap.putAll(createApplicationRecord(applicationMap));
				kkApplicationMap.put(OceanMapKeys.APPLICATION_NO_ONLINE, kkApplicationMap.getBigDecimal("APPLICATION_NO"));
			}

			List<KkBasvuru> kkBasvuruOffline = (List<KkBasvuru>) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo)).add(Restrictions.eq("urunTipi", OFFLINE_URUN_ID)).add(Restrictions.eq("durumKod", "ACIK")).list();
			if(kkBasvuruOffline != null && kkBasvuruOffline.size() > 0){
				kkApplicationMap.put(OceanMapKeys.APPLICATION_NO_OFFLINE, kkBasvuruOffline.get(0).getBasvuruNo());
				kkApplicationMap.put("URUN_ID", OFFLINE_URUN_ID);
				statusMap.remove("TRX_NO");
				statusMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				statusMap.put("TRX_NO_OFFLINE",statusMap.getBigDecimal("TRX_NO"));
			}
			else{
				applicationMap.remove("URUN_ID");	
				applicationMap.put("URUN_ID", OFFLINE_URUN_ID);
				applicationMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				statusMap.put("TRX_NO_OFFLINE",applicationMap.getBigDecimal("TRX_NO"));
				kkApplicationMap.putAll(createApplicationRecord(applicationMap));
				kkApplicationMap.put(OceanMapKeys.APPLICATION_NO_OFFLINE, kkApplicationMap.getBigDecimal("APPLICATION_NO"));
			}

		if (StringUtils.isEmpty(kkApplicationMap.getString(OceanMapKeys.APPLICATION_NO_ONLINE)) || StringUtils.isEmpty(kkApplicationMap.getString(OceanMapKeys.APPLICATION_NO_OFFLINE))
				 || StringUtils.isEmpty(kkApplicationMap.getString(OceanMapKeys.APPLICATION_NO_ECOMMERCE))){
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put(" RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}
		
		// ss createcustomer and createhcecard
		statusMap.remove("TRX_NO");
		statusMap.put(OceanMapKeys.APPLICATION_NO_ECOMMERCE, kkApplicationMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_ECOMMERCE));
		statusMap.put(OceanMapKeys.APPLICATION_NO_OFFLINE, kkApplicationMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_OFFLINE));
		statusMap.put(OceanMapKeys.APPLICATION_NO_ONLINE, kkApplicationMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_ONLINE));
		oMap.putAll(statusMap);
		
		GMMap oceanCustMap = new GMMap();
		oceanCustMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_OCEAN_HCE_CUSTOMER", statusMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oceanCustMap.getString("RESPONSE"))) {
			return oceanCustMap;
		}

		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		oMap.put("CUSTOMER_NO", musteriNo);

		return oMap;

	}


	@GraymoundService("BNSPR_EKENTMOBIL_CREATE_HCE_CARD")
	public static GMMap createHceCardEkentMobil(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_OCEAN_HCE_CARD", iMap));

		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}

		updateApplicationStatus(iMap);
		
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);

		return oMap;

	}

	@GraymoundService("BNSPR_EKENTMOBIL_GET_DOCUMENT_TEMPLATES")
	public static GMMap getDocumentTemplatesEkentMobil(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_GET_DOCUMENT_TEMPLATES", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_EKENTMOBIL_GET_DOCUMENT_DATA")
	public static GMMap getDocumentDataEkentMobil(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
		if (kkBasvuru == null) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}

		KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.get(KkBasvuruKimlik.class, iMap.getBigDecimal("APPLICATION_NO"));

		if (kkBasvuruKimlik == null) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}

		iMap.put("BASVURU_NO", iMap.get("APPLICATION_NO"));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_CARD_DOCUMENT_DATA", iMap));
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;
	}

	@GraymoundService("BNSPR_EKENTMOBIL_SAVE_AGREEMENT_DOCUMENTS")
	public static GMMap saveAgreementDocumentsEkentMobil(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			if (kkBasvuru == null) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
				return oMap;
			}

			GMMap dMap = new GMMap();
			dMap.put("DYS_TRANSFER", true);
			dMap.put("MAIL_TRANSFER", false);
			dMap.put("APPLICATION_NO", iMap.get("APPLICATION_NO"));

			dMap.put("DOC_LIST", iMap.get("DOC_LIST"));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_KK_CARD_DOCUMENTS", dMap));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_EKENTMOBIL_CANCEL_APPLICATION")
	public static GMMap cancelApplicationEkentMobil(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap cancelMap = new GMMap();
		
		cancelMap.put("APPLICATION_NO", iMap.getString(OceanMapKeys.APPLICATION_NO_ECOMMERCE));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_EKENT_CANCEL_APPLICATION", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		cancelMap.remove("APPLICATION_NO");
		cancelMap.put("APPLICATION_NO", iMap.getString(OceanMapKeys.APPLICATION_NO_OFFLINE));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_EKENT_CANCEL_APPLICATION", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		cancelMap.remove("APPLICATION_NO");
		cancelMap.put("APPLICATION_NO", iMap.getString(OceanMapKeys.APPLICATION_NO_ONLINE));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_EKENT_CANCEL_APPLICATION", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		return oMap;
	}


	protected static GMMap createApplicationRecord(GMMap iMap) {

		GMMap oMap = new GMMap();
		BigDecimal prepaidAppNo = GMServiceExecuter.call("BNSPR_TRN3871_GET_BASVURU_NO", iMap).getBigDecimal("ID");

		GMMap createKkBasvuruMap = new GMMap();
		createKkBasvuruMap.putAll(iMap);
		createKkBasvuruMap.put("BASVURU_NO", prepaidAppNo);
		createKkBasvuruMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
		createKkBasvuruMap.put("TCKN", iMap.getString("TCKN"));
		createKkBasvuruMap.put("PASAPORT_NO", iMap.getString("PASSPORT_NO"));
		createKkBasvuruMap.put("UYRUK", iMap.getString("COUNTRY_CODE"));
		createKkBasvuruMap.put("TRX_NO", iMap.get("TRX_NO"));
		createKkBasvuruMap.put("KART_NO", iMap.get("CARD_NO"));
		createKkBasvuruMap.put("URUN_ID", iMap.get("URUN_ID"));

		GMMap createKkMap = new GMMap();
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_CREATE_APPLICATION", createKkBasvuruMap));

		if (!AkustikConstants.RESPONSE_SUCCESS.equals(createKkMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", createKkMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", createKkMap.getString("RESPONSE_DATA"));
			return oMap;
		}
	
		oMap.put("APPLICATION_STATUS", "BASVURU");
		oMap.put("APPLICATION_NO", prepaidAppNo);

		return oMap;
	}
	
	private static GMMap updateApplicationStatus(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap statusMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		KkBasvuru kkBasvuruEcom = (KkBasvuru) session.createCriteria(KkBasvuru.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_ECOMMERCE))).uniqueResult();
		if(kkBasvuruEcom != null){
			if (!"ACIK".equals(kkBasvuruEcom.getDurumKod())){
				statusMap.put("DURUM_KOD", "ACIK");
				statusMap.put("BASVURU_NO", iMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_ECOMMERCE));
				statusMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO_ECOMMERCE"));
				statusMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", statusMap));
			}
		}
		statusMap.clear();
		
		//online daha �nce a��lm�� olabilir
		KkBasvuru kkBasvuruOnline = (KkBasvuru) session.createCriteria(KkBasvuru.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_ONLINE))).uniqueResult();
		
			if(kkBasvuruOnline != null){
				if (!"ACIK".equals(kkBasvuruOnline.getDurumKod())){
				statusMap.put("DURUM_KOD", "ACIK");
				statusMap.put("BASVURU_NO", iMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_ONLINE));
				statusMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO_ONLINE"));
				statusMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", statusMap));
				}
			}
		statusMap.clear();
		
		KkBasvuru kkBasvuruOffline = (KkBasvuru) session.createCriteria(KkBasvuru.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_OFFLINE))).uniqueResult();
		
			if(kkBasvuruOffline != null){
				if (!"ACIK".equals(kkBasvuruOffline.getDurumKod())){
				statusMap.put("DURUM_KOD", "ACIK");
				statusMap.put("BASVURU_NO", iMap.getBigDecimal(OceanMapKeys.APPLICATION_NO_OFFLINE));
				statusMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO_OFFLINE"));
				statusMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", statusMap));

				}
			}
		return oMap;
	}

	
	public static String getChannelCode (){
		
		return GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()).get("KANAL_KOD").toString();
	}

	
}
