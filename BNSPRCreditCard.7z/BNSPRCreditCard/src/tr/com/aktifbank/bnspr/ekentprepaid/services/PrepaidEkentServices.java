package tr.com.aktifbank.bnspr.ekentprepaid.services;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.CreditCardMessagesUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkSsProductMap;
import tr.com.aktifbank.bnspr.prepaidcard.services.PrepaidCardNoNameServices;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys.EKENT_PRODUCT;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class PrepaidEkentServices {

	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	private static final String BAYI_KANAL = "2";
	/*EVAM ANKARAKAT ba�vuru tamamland� event type*/
	private static final String ANKARAKART_ACTIVATION_EVENT_TYPE_NO = "77";
	private final static String EVENT_INTEGRATION_TYPE_SYNC = 	"S";
	
	@GraymoundService("BNSPR_EKENT_START_PREPAID_APPLICATION")
	public static GMMap startEkentPrepaidApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_EKENT_START_UNMATCH_PREPAID_APPLICATION", iMap));
		if (AkustikConstants.RESPONSE_SUCCESS.equals(oMap.getString("RESPONSE"))) {
			GMMap matchCustomerMap = new GMMap();
			matchCustomerMap.put("MUSTERI_NO", oMap.get("CUSTOMER_NO"));
			matchCustomerMap.put("BASVURU_NO", oMap.get("APPLICATION_NO"));
			matchCustomerMap.put("SOURCE", iMap.getString("SOURCE"));
			matchCustomerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_MATCH_CARD_CUSTOMER", matchCustomerMap));

			if (!AkustikConstants.RESPONSE_SUCCESS.equals(matchCustomerMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", matchCustomerMap.getString("RESPONSE"));
				//oMap.put("RESPONSE_DATA", matchCustomerMap.getString("RESPONSE_DATA"));
				oMap.put("RESPONSE_DATA", getLocalizedMessageText(matchCustomerMap.getString("RESPONSE_DATA","")));
				return oMap;

			}
				else {
					// islem Basar�l� ise Evam'a bildirim yap�lmas� Volkan Demir 04.2018
					iMap.put("BASVURU_NO", oMap.get("APPLICATION_NO"));
					iMap.put("MUSTERI_NO", oMap.get("CUSTOMER_NO"));
					createEventForAnkarakart(iMap);
				}
		}
		}
		catch (Exception e) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		oMap.put("RESPONSE_DATA", getLocalizedMessageText(oMap.getString("RESPONSE_DATA","")));
		return oMap;
		}



		
	

	@GraymoundService("BNSPR_EKENT_START_UNMATCH_PREPAID_APPLICATION")
	public static GMMap startEkentUnMatchPrepaidApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap validateMap = new GMMap();
		validateMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_EKENT_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(validateMap.getString("RESPONSE"))) {
			validateMap.put("RESPONSE_DATA", getLocalizedMessageText(validateMap.getString("RESPONSE_DATA","")));
			return validateMap;
		}
		
		validateMap.clear();
		validateMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_IS_VALID_PROCEED_REQUEST", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(validateMap.getString("RETURN_CODE"))) {
			oMap.put("RESPONSE", validateMap.getString("RETURN_CODE"));
			//oMap.put("RESPONSE_DATA", validateMap.getString("RETURN_DESCRIPTION"));
			oMap.put("RESPONSE_DATA", getLocalizedMessageText(validateMap.getString("RETURN_DESCRIPTION","")));
			return oMap;
		}

		if (iMap.get("TRX_NO") == null) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		}
		BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
		Session session = null;
		if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {

			GMMap customerMap = new GMMap();

			iMap.put("SKIP_APS", true);
			customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_CREATE_CUSTOMER", iMap));
			musteriNo = customerMap.getBigDecimal("MUSTERI_NO");
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) == 0) {
				customerMap.put("RESPONSE_DATA", getLocalizedMessageText(customerMap.getString("RESPONSE_DATA","")));
				return customerMap;
			}

		}

		else {

			//session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();
			// update aps adress if necessary
			//sadece kontaksa de�il ger�ekse de aps yap�ls�n
			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {//&& "K".equals(musteri.getMusteriKontakt())) {
				GMMap customerMap = new GMMap();
				customerMap.put("TCKN", iMap.getString("TCKN"));
				customerMap.put("TRX_NO", iMap.get("TRX_NO"));
				customerMap.put("MUSTERI_NO", musteriNo);
				customerMap.put("SKIP_APS", true);
				customerMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_UPDATE_CUSTOMER_APS_ADRESS", customerMap));
				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(customerMap.getString("RESPONSE"))) {
					customerMap.put("RESPONSE_DATA", getLocalizedMessageText(customerMap.getString("RESPONSE_DATA","")));
					return customerMap;
				}
			}

		}

		BigDecimal prepaidAppNo = GMServiceExecuter.call("BNSPR_TRN3871_GET_BASVURU_NO", iMap).getBigDecimal("ID");

		GMMap createKkBasvuruMap = new GMMap();
		createKkBasvuruMap.put("BASVURU_NO", prepaidAppNo);
		createKkBasvuruMap.put("MUSTERI_NO", musteriNo);
		createKkBasvuruMap.put("TCKN", iMap.getString("TCKN"));
		createKkBasvuruMap.put("PASAPORT_NO", iMap.getString("PASSPORT_NO"));
		createKkBasvuruMap.put("UYRUK", iMap.getString("COUNTRY_CODE"));
		createKkBasvuruMap.put("BAYI_KOD", iMap.getString("BOX_OFFICE_ID"));
		createKkBasvuruMap.put("TRX_NO", iMap.get("TRX_NO"));
		createKkBasvuruMap.put("KART_NO", iMap.get("CARD_NO"));
		// upt i�in eklendi
		createKkBasvuruMap.put("MOTHER_NAME", iMap.get("MOTHER_NAME"));
		createKkBasvuruMap.put("FATHER_NAME", iMap.get("FATHER_NAME"));
		createKkBasvuruMap.put("BIRTH_PLACE", iMap.get("BIRTH_PLACE"));
		createKkBasvuruMap.put("URUN_ID", iMap.get("PRODUCT_TYPE"));
		createKkBasvuruMap.put("PAKET", "PROCEED");
		createKkBasvuruMap.putAll(iMap);

		GMMap createKkMap = new GMMap();
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_CREATE_APPLICATION", createKkBasvuruMap));
		
		if (!AkustikConstants.RESPONSE_SUCCESS.equals(createKkMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", createKkMap.getString("RESPONSE"));
			oMap.put("RESPONSE_DATA", getLocalizedMessageText(createKkMap.getString("RESPONSE_DATA","")));
			return oMap;
		}
		createKkMap.putAll(GMServiceExecuter.execute("BNSPR_KK_DAGITIM_KOD", createKkBasvuruMap));

		// kaydi acalim

		iMap.put("MUSTERI_NO", musteriNo);
		iMap.put("BASVURU_NO", prepaidAppNo);

		createKkBasvuruMap.put("DURUM_KOD", "ACIK");

		GMServiceExecuter.execute("BNSPR_PREPAID_NONAME_UPDATE_APPLICATION_STATUS", createKkBasvuruMap);

		   if (!StringUtils.isEmpty(createKkMap.getString("DAGITIM_KOD")) && !BASVURU_DAGITIM_KOD_BOS.equals(createKkMap.getString("DAGITIM_KOD"))) {

			// istenen belgeleri bul
			GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", iMap);

			//

		}
		oMap.put("APPLICATION_STATUS", "ACIK");
		oMap.put("APPLICATION_NO", prepaidAppNo);
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		oMap.put("CUSTOMER_NO", musteriNo);

		return oMap;
	}

	

	@GraymoundService("BNSPR_EKENT_CANCEL_APPLICATION")
	public static GMMap cancelApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		KkBasvuru kkBasvuru = null;

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			if (kkBasvuru == null) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", "Ba�vuru bulunamad�");
				return oMap;
			}
		

			sorguMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
			sorguMap.put("ONCEKI_DURUM_KOD", kkBasvuru.getDurumKod());
			sorguMap.put("ISLEM_KOD", "SS");
			if (StringUtils.isEmpty(iMap.getString("TXN_CODE"))) {
				sorguMap.put("GEREKCE_KOD", "1");// kanal talebi
			}
			else {
				sorguMap.put("GEREKCE_KOD", iMap.getString("TXN_CODE"));
			}
			if (StringUtils.isEmpty(iMap.getString("TXN_DESC"))) {
				sorguMap.put("ACIKLAMA", "Kart iptal talebi");// kanal talebi
			}
			else {
				sorguMap.put("ACIKLAMA", iMap.getString("TXN_DESC"));
			}

			sorguMap.put("TFF_BASVURU_IPTAL_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.put("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.EVET);

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3875_SAVE", sorguMap));
			
			String card_no = kkBasvuru.getKartNo();
			if(!StringUtils.isEmpty(card_no)){
				iMap.put("CARD_NO" , card_no);
				iMap.put("STATUS", "I");
				iMap.put("SUBSTATUS", "I");
				iMap.put("DESCRIPTION", sorguMap.getString("GEREKCE_KOD"));
				iMap.put("FREE_TEXT", sorguMap.getString("GEREKCE_KOD"));
				iMap.put("EMBOSS_CODE", "");
				iMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_UPDATE_CARD_STATUS", iMap));
				if (!"2".equals(iMap.getString("RETURN_CODE"))) {
					throw new GMRuntimeException(0, iMap.getString("RETURN_DESCRIPTION"));
				}
			}
			
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e.getMessage());
			//oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			//oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_EKENT_GET_APPLICATION_SUMMARY_INFO")
	public static GMMap getApplicationSummaryInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (!CardServicesHelper.isSourceValid(iMap)) {
			oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
			oMap.put("RESPONSE_DATA", "Gecersiz kanal tipi");
			return oMap;
		}
		iMap.put("BASVURU_URUN_ADI", "EKENT PREPAID KART");
		iMap.put("CARD_DETAIL", "E");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_KK_COMMON_GET_APPLICATION_SUMMARY_INFO", iMap));
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			GMMap responseDataInpMap = new GMMap();
			responseDataInpMap.put("SOURCE", iMap.getString("SOURCE"));
			responseDataInpMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
			GMMap responseDataMap = new GMMap();
			responseDataMap.putAll(GMServiceExecuter.execute("BNSPR_KK_COMMON_CONVERT_RESPONSE_DATA_BY_SOURCE", responseDataInpMap));
			if (!StringUtils.isEmpty(responseDataMap.getString("RESPONSE_DATA"))) {
				oMap.put("RESPONSE_DATA", responseDataMap.getString("RESPONSE_DATA"));
			}
		}

		return oMap;
	}
	
	
	
	
	
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_EKENT_REQUEST")
	public static GMMap validatePrepaidCardEkentRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		Session session = null;
		String urunId = iMap.getString("PRODUCT_TYPE");
		String source = iMap.getString("SOURCE");
		String countryCode = iMap.getString("COUNTRY_CODE");
		String ssPaketProceed = "PROCEED";
		String kartNo = iMap.getString("CARD_NO");
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
				
		
		try {

			if (!StringUtils.isEmpty(iMap.getString("PASSPORT_NO"))) {
				if (StringUtils.isEmpty("NAME")) {
					CreditCardServicesUtil.raiseGMError("330", "Ad");
				}
				if (StringUtils.isEmpty("SURNAME")) {
					CreditCardServicesUtil.raiseGMError("330", "Soyad");
				}
				if (StringUtils.isEmpty("GENDER")) {
					CreditCardServicesUtil.raiseGMError("330", "Cinsiyet");
				}

				if (StringUtils.isEmpty("DELIVERY_ADRESS_CITY")) {
					CreditCardServicesUtil.raiseGMError("330", "�ehir");
				}

				if (StringUtils.isEmpty("DELIVERY_ADRESS_DISTRICT")) {
					CreditCardServicesUtil.raiseGMError("330", "�l�e");
				}

				if (StringUtils.isEmpty("DELIVERY_ADRESS")) {
					CreditCardServicesUtil.raiseGMError("330", "Adres");
				}

				if (StringUtils.isEmpty("DELIVERY_ADRESS_TYPE")) {
					CreditCardServicesUtil.raiseGMError("330", "Teslimat Adres Tipi");
				}

			}

		    GMMap validateMap = new GMMap();
		    validateMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_IDENTITY_PRODUCT_TYPE_CARD", iMap));
		    if(AkustikConstants.RESPONSE_FAIL.equals(validateMap.getString("RESPONSE"))){
		    	return validateMap;
		    }
			
			
			BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
			
			if(musteriNo != null && musteriNo.compareTo(BigDecimal.ZERO) != 0){

				GMMap phoneMap = new GMMap();
				phoneMap.put("CUSTOMER_NO", musteriNo);
				phoneMap.put("PHONE_COUNTRY_CODE", iMap.getString("PHONE_COUNTRY_CODE"));
				phoneMap.put("PHONE_OPERATOR_CODE", iMap.getString("PHONE_OPERATOR_CODE"));
				phoneMap.put("PHONE_NUMBER", iMap.getString("PHONE_NUMBER"));
				phoneMap.put("SOURCE", "EGOMBL");
				phoneMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_APPLICATION_PHONE_CONTROL", phoneMap));

				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(phoneMap.getString("RESPONSE"))) {
					
					if (TffServicesMessages.KONTAKT_MUSTERI_UZERINDE_KAYITLI_TEL_YOK.equals((phoneMap.getString("RESPONSE_DATA",""))) ||
						TffServicesMessages.KONTAKT_MUSTERI_UZERINDEKI_TEL_BASVURUDAN_FARKLI.equals((phoneMap.getString("RESPONSE_DATA",""))))
					{
						
						//kart� var m�?
						boolean kartiVar = false;
						GMMap cardMap = new GMMap();
						cardMap.put("CARD_DCI","A");
						cardMap.put("CUSTOMER_NO",musteriNo);
						cardMap.put("PROCEED","INCLUDE");
						cardMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardMap);
						if( cardMap.getSize("CARD_DETAIL_INFO") > 0){
							kartiVar = true;
						}
						else{
							cardMap.clear();
							cardMap.put("CARD_DCI","A");
							cardMap.put("CUSTOMER_NO",musteriNo);
							cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardMap);
							if( cardMap.getSize("CARD_DETAIL_INFO") > 0){
								kartiVar = true;
							}
						}
						
						if (!kartiVar){
							GMMap otpMap = new GMMap();
							otpMap.put("MUSTERI_NO", musteriNo);
							otpMap.put("ALAN_KOD",iMap.getString("PHONE_OPERATOR_CODE") );
							otpMap.put("TEL_NO",iMap.getString("PHONE_NUMBER"));
							otpMap.put("ULKE_KODU",iMap.getString("PHONE_COUNTRY_CODE"));
							otpMap = GMServiceExecuter.call("BNSPR_MBL_CHANGE_CUSTOMER_OTP", otpMap);
							if (!"00".equals(otpMap.getString("RESPONSE"))){
								oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
								oMap.put("RESPONSE_DATA", otpMap.getString("ERR_DESC",""));
							}
							oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
							return oMap;
						}
						
					}

					oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
					oMap.put("RESPONSE_DATA", phoneMap.getString("RESPONSE_DATA",""));
					return oMap;
				}
			}
			
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);

		
		}
		catch (GMRuntimeException e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		
		catch (Exception e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		finally{
			if(session != null){
				session.flush();
			}
		}
		
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_IS_VALID_PROCEED_REQUEST")
	public static GMMap isValidProceedRequest(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			GMMap sorguMap = new GMMap();
			String urunId = iMap.getString("PRODUCT_TYPE");

			
			sorguMap.put("CARD_NO", iMap.getString("CARD_NO"));
			sorguMap.put("BOX_OFFICE_ID", iMap.getString("BOX_OFFICE_ID"));
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_PROCEED_GET_UNMATCH_INSTANCE_CARD_INFO", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))){
				if(urunId.equals(oMap.getString("PRODUCT_ID"))){
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
				}
				else{
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA" , "Girilen urun tipi ile kart paketi urun tipi farkl�");
				}
				
				
				
			}
			else{	
				oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				//oMap.put("RESPONSE_DATA", oMap.getString("RETURN_DESCRIPTION"));
				oMap.put("RESPONSE_DATA", getLocalizedMessageText(oMap.getString("RETURN_DESCRIPTION","")));
				
			}
			

		}
		catch (Exception e) {
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_IDENTITY_PRODUCT_TYPE")
	public static GMMap validateIdentityProductType(GMMap iMap) {

		
		GMMap oMap = new GMMap();
		String requestedProductId = iMap.getString("PRODUCT_TYPE");
		String source = iMap.getString("SOURCE");
		String countryCode = iMap.getString("COUNTRY_CODE");
		String passport = iMap.getString("PASSPORT_NO");
		String tckn = iMap.getString("TCKN");
		String ssPaketProceed = "PROCEED";
		Session session = null;
		
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		
		try{
		if (StringUtils.isEmpty(source)) {
			CreditCardServicesUtil.raiseGMError("330", "Islem Kanali");
		}
		if (StringUtils.isEmpty(requestedProductId)) {
			CreditCardServicesUtil.raiseGMError("330", "Urun Tipi");
		}
		
		session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		
		KkSsProductMap kkSsProductMap = (KkSsProductMap) session.createCriteria(KkSsProductMap.class).add(Restrictions.eq("urunId",requestedProductId)).add(Restrictions.eq("paket",ssPaketProceed)).uniqueResult();
		if(kkSsProductMap == null){
			CreditCardServicesUtil.raiseGMError("50021", "�r�n Tipi");
		}

		if (StringUtils.isEmpty(countryCode)) {
			CreditCardServicesUtil.raiseGMError("330", "Uyruk");
		}
		
		if ("TR".equals(countryCode)) {
			if (StringUtils.isEmpty(tckn)) {
				CreditCardServicesUtil.raiseGMError("330", "TCKN");
			}

			// TCKN
			GMMap sorguMap = new GMMap();
			sorguMap.put("TCKN", tckn);
			sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
			GMServiceExecuter.execute("BNSPR_TRN3870_TCKN_KONTROL", sorguMap);
			
			GMMap kpsMap = new GMMap();
			kpsMap.put("TCKN", tckn);
			kpsMap.put("TCK_NO", tckn);
			kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				//oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
				oMap.put("RESPONSE_DATA", getLocalizedMessageText(kpsMap.getString("RESPONSE_DATA","")));
				return oMap;
			}

			if (!PrepaidCardNoNameServices.basvuruYasKontrol(iMap.getString("SOURCE"),kpsMap.getString("DOGUM_TARIHI"))){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				//oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_YAS_KONTROLU);
				oMap.put("RESPONSE_DATA", getLocalizedMessageText(TffServicesMessages.BASVURU_YAS_KONTROLU));
				return oMap;
			}
			
		}
		else {
			if (StringUtils.isEmpty(passport)) {
				CreditCardServicesUtil.raiseGMError("Pasaport No");
			}
		}
		
		BigDecimal musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
		
		if(musteriNo != null && musteriNo.compareTo(BigDecimal.ZERO) != 0){
			GMMap proceedResponseInpMap = new GMMap();
			GMMap proceedResponseOutMap = new GMMap();
			proceedResponseInpMap.put("CUSTOMER_NO", musteriNo);
			proceedResponseInpMap.put("PROCEED", "ONLY");
			proceedResponseOutMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", proceedResponseInpMap));
			
			
			if (proceedResponseOutMap.getInt("RETURN_CODE") == 2){
				boolean acikOgrenciKartVar = false;
				boolean acikTamKartVar = false;
				boolean acikOgretmenKartVar = false ;
				boolean geciciKapaliOgrenciKartVar = false;
				boolean geciciKapaliOgretmenKartVar = false;
				boolean geciciKapaliTamKartVar = false ;
				boolean arizaOgrenciKartVar = false;
				boolean arizaTamKartVar = false;
				boolean arizaOgretmenKartVar = false ;
				BigDecimal acikTamKartBasvuruNo = BigDecimal.ZERO;
				BigDecimal arizaTamKartBasvuruNo = BigDecimal.ZERO;
				
				for (int i = 0; i < proceedResponseOutMap.getSize("CARD_DETAIL_INFO"); i++) {
					String cardStatCode =      proceedResponseOutMap.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE");
					
					String cardSubStatCode =   proceedResponseOutMap.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE");
					String productId =         proceedResponseOutMap.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");
		
					
					if( cardStatCode.equals("N") ){
						if(EKENT_PRODUCT.OGRENCI.getCode().equals(productId)){
							acikOgrenciKartVar = true;
						}
						else if(EKENT_PRODUCT.OGRETMEN.getCode().equals(productId)){
							acikOgretmenKartVar = true;
						}
						else if(EKENT_PRODUCT.TAM.getCode().equals(productId)){
							acikTamKartVar = true;
							acikTamKartBasvuruNo = proceedResponseOutMap.getBigDecimal("CARD_DETAIL_INFO", i, "APPLICATION_NO");
						}
					}
					
					else if ((cardStatCode.equals("G") && !(cardSubStatCode.equals("J") || cardSubStatCode.equals("B"))))
					{
						if(EKENT_PRODUCT.OGRENCI.getCode().equals(productId)){
							geciciKapaliOgrenciKartVar = true;
						}
						else if(EKENT_PRODUCT.OGRETMEN.getCode().equals(productId)){
							geciciKapaliOgretmenKartVar = true;
						}
						else if(EKENT_PRODUCT.TAM.getCode().equals(productId)){
							geciciKapaliTamKartVar = true;
						}
					}
					
					
					else if (cardStatCode.equals("B") &&  cardSubStatCode.equals("B"))
					{
						if(EKENT_PRODUCT.OGRENCI.getCode().equals(productId)){
							arizaOgrenciKartVar = true;
						}
						else if(EKENT_PRODUCT.OGRETMEN.getCode().equals(productId)){
							arizaOgretmenKartVar = true;
						}
						else if(EKENT_PRODUCT.TAM.getCode().equals(productId)){
							arizaTamKartVar = true;
							arizaTamKartBasvuruNo = proceedResponseOutMap.getBigDecimal("CARD_DETAIL_INFO", i, "APPLICATION_NO");
						}
					}
					
					else{
						continue;
					}
					
					
				}
						
				
				 if(EKENT_PRODUCT.OGRENCI.getCode().equals(requestedProductId)){
					if(acikOgrenciKartVar){
						CreditCardServicesUtil.raiseGMError("50026","A��k" , EKENT_PRODUCT.OGRENCI.getValue() ,   EKENT_PRODUCT.OGRENCI.getValue() );
					}
					if(geciciKapaliOgrenciKartVar){
						CreditCardServicesUtil.raiseGMError("50026","Ge�ici Kapal�" , EKENT_PRODUCT.OGRENCI.getValue() ,   EKENT_PRODUCT.OGRENCI.getValue() );
					}
					
					if(acikOgretmenKartVar){
						CreditCardServicesUtil.raiseGMError("50026","A��k" , EKENT_PRODUCT.OGRETMEN.getValue() ,   EKENT_PRODUCT.OGRENCI.getValue() );
					}
					if(geciciKapaliOgretmenKartVar){
						CreditCardServicesUtil.raiseGMError("50026","Ge�ici Kapal�" , EKENT_PRODUCT.OGRETMEN.getValue() ,   EKENT_PRODUCT.OGRENCI.getValue() );
					}
					if (arizaOgrenciKartVar){
						
						if (arizaTamKartBasvuruNo.compareTo(BigDecimal.ZERO) > 0 && arizaTamKartBasvuruNo.compareTo(acikTamKartBasvuruNo) > 0 ){
							oMap.put("RESPONSE", "3");
						}
					}
				}
				
				else if(EKENT_PRODUCT.OGRETMEN.getCode().equals(requestedProductId)){
					if(acikOgretmenKartVar){
						CreditCardServicesUtil.raiseGMError("50026","A��k" , EKENT_PRODUCT.OGRETMEN.getValue() ,   EKENT_PRODUCT.OGRETMEN.getValue() );
					}
					if(geciciKapaliOgretmenKartVar){
						CreditCardServicesUtil.raiseGMError("50026","Ge�ici Kapal�" , EKENT_PRODUCT.OGRETMEN.getValue() ,   EKENT_PRODUCT.OGRETMEN.getValue() );
					}
					
					if(acikOgrenciKartVar){
						CreditCardServicesUtil.raiseGMError("50026","A��k" , EKENT_PRODUCT.OGRENCI.getValue() ,   EKENT_PRODUCT.OGRETMEN.getValue() );
					}
					if(geciciKapaliOgretmenKartVar){
						CreditCardServicesUtil.raiseGMError("50026","Ge�ici Kapal�" , EKENT_PRODUCT.OGRENCI.getValue() ,   EKENT_PRODUCT.OGRETMEN.getValue() );
					}
					if (arizaOgretmenKartVar){
						oMap.put("RESPONSE", "3");
					}
				}
				else if(EKENT_PRODUCT.TAM.getCode().equals(requestedProductId)){ 
					if (arizaTamKartVar){
						oMap.put("RESPONSE", "3");
					}
				}
				
		    }
			
			else{
				if("Kart Sistemde Bulunamad�".equals(proceedResponseOutMap.getString("RETURN_DESCRIPTION"))){
					oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
					return oMap;
				}
			}
			
			
			
		}
		

		
	}
	catch (GMRuntimeException e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		
		catch (Exception e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		finally{
			if(session != null){
				session.flush();
			}
		}
		return oMap;
	}
	

	@GraymoundService("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_IDENTITY_PRODUCT_TYPE_CARD")
	public static GMMap validateIdentityProductTypeCard(GMMap iMap) {

		
		GMMap oMap = new GMMap();
		
		String ssPaketProceed = "PROCEED";
		String cardNo =  iMap.getString("CARD_NO");
		String boxOfficeId = iMap.getString("BOX_OFFICE_ID");
		
		Session session = null;
		
		try{

		if (StringUtils.isEmpty(boxOfficeId)) {
			CreditCardServicesUtil.raiseGMError("330", "Gi�e Numaras�");
		}
		if (StringUtils.isEmpty(cardNo)) {
			CreditCardServicesUtil.raiseGMError("330", "Kart numaras�");
		}
		
		 session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		
		 String cardBin = cardNo.substring(0, 6);
		 Criteria criteria = session.createCriteria(GnlParamText.class)
					.add(Restrictions.eq("kod", "KART_BIN_SS_PACKAGE"))
					.add(Restrictions.eq("key1", cardBin));
		 GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
		 
		 if(gnlParamText == null){
			 CreditCardServicesUtil.raiseGMError("50021", "Kart numaras�");
		 }
			 
		 
		 String paket = gnlParamText.getText();
		 if(!ssPaketProceed.equals(paket)){
			 
			 CreditCardServicesUtil.raiseGMError("50025");
		 }
		
		
		GMMap sorguMap = new GMMap();
		
		
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_VALIDATE_IDENTITY_PRODUCT_TYPE", iMap));
		
		if(AkustikConstants.RESPONSE_FAIL.equals(sorguMap.getString("RESPONSE"))){
			sorguMap.put("RESPONSE_DATA", getLocalizedMessageText(sorguMap.getString("RESPONSE_DATA","")));
			return sorguMap;
		}
		
		sorguMap.clear();
        sorguMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_PREPERSO_COMMON_IS_VALID_PROCEED_REQUEST", iMap));
		
		if(AkustikConstants.RESPONSE_FAIL.equals(sorguMap.getString("RESPONSE"))){
			sorguMap.put("RESPONSE_DATA", getLocalizedMessageText(sorguMap.getString("RESPONSE_DATA","")));
			return sorguMap;
		}
		
		
		
		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		}
		
		catch (GMRuntimeException e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		
		catch (Exception e) {
			
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			
		}
		finally{
			if(session != null){
				session.flush();
			}
		}
		
		return oMap;
	}
	
	/***
	 * Ankara kart event olu�turma
	 * Data_map g�nderilerek event catelogue'da collect servisi belirtme ve tan�mlamaya gerek kalmam��t�r
	 * Catelogue'da Consumer'da tan�ml� olan BNSPR_EXT_CAMPAIGN_DATA_CONSUMER_WITH_KEY servis evam'a bildirim yapacakt�r.
	 * EVENT ADI NK_ANKARAKART_ACTIVATION
	 * SENARYO_KEY MUSTERI_NO
	 * 
	 * 
	 * 
	 * -- Volkan Demir 04.2018
	 * */
	public static void createEventForAnkarakart(GMMap iMap) {
		GMMap eventMap = new GMMap();
		GMMap dataMap = new GMMap();

		eventMap.put("EVENT_TYPE_NO", ANKARAKART_ACTIVATION_EVENT_TYPE_NO);
		eventMap.put("EVENT_REF_NO", iMap.get("BASVURU_NO"));
		dataMap.put("SCENARIO_KEY", iMap.get("MUSTERI_NO"));
		dataMap.put("CARD_NO", iMap.get("CARD_NO"));
		dataMap.put("TCKN", iMap.get("TCKN"));
		dataMap.put("CARD_TYPE", iMap.get("PRODUCT_TYPE"));
		dataMap.put("AD", iMap.get("NAME"));
		dataMap.put("SOYAD", iMap.get("SURNAME"));
		dataMap.put("CEP", iMap.getString("PHONE_COUNTRY_CODE") + iMap.getString("PHONE_OPERATOR_CODE") + iMap.getString("PHONE_NUMBER"));
		dataMap.put("EMAIL", iMap.getString("EMAIL"));
		eventMap.put("DATA_MAP", dataMap);
		/*INtegration type -> S g�nderilerek, dispatcher servisi senkron �a�r�l�yor
		 Dispatch servisinin �a�r�lmas�, event catelogue'da tan�ml� consumer servisinin hemen tetiklenmesini sa�l�yor
		 */
		eventMap.put("INTEGRATION_TYPE", EVENT_INTEGRATION_TYPE_SYNC);
		GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", eventMap);
	}

	public static String getLocalizedMessageText (String responseDataCode) {
	
	   EkentLocalizedMessages.Error.Generic[] enumConstants = EkentLocalizedMessages.Error.Generic.class.getEnumConstants();
       for (int i = 0; i < enumConstants.length; i++) {
            try {
				if(enumConstants[i].name().equals(CreditCardMessagesUtil.getResponseDataNames(responseDataCode))) {
					return  enumConstants[i].format();
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        //lokalize mesaj / mesaj kodlardan biri de�ilse ayn� hatay� d�ns�n
		return responseDataCode;
	
	}
	
}
