package tr.com.aktifbank.bnspr.tff.document.type;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.tff.document.type.Enums;

public class DijitalCerceveSozlesmeMarasMobil  extends CardDocument {

	public DijitalCerceveSozlesmeMarasMobil() {
		super("dijitalCerceveSozlesmeMarasMobil", "dijitalCerceveSozlesmeMarasMobil", Enums.CardDocTypes.DIJITAL_CERCEVE_SOZLESME_MARASMOBIL.getCode());
	}

	@Override
	public String generateXml(String applicationNo) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<MUSTERI_BILGILERI>");
		builder.append(GMServiceExecuter.call("BNSPR_KK_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		builder.append("</MUSTERI_BILGILERI>");

		return builder.toString();
	}

}
