package tr.com.aktifbank.bnspr.tff.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgi;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdeme;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.TffCrmSaf;
import tr.com.aktifbank.bnspr.dao.TffTopluBasvuru;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.util.GMToolkit;

public class TffBatchServices extends TffServicesHelper {

	private static final Logger logger = Logger.getLogger(TffBatchServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-tff.properties");
	
	
	/*EVAM event type*/
	private static final String EVENT_TYPE_NO = "17";

	@GraymoundService("BNSPR_TFF_BATCH_MUSTERI_YARAT")
	public static GMMap tffBatchMusteriYarat(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		List<TffUyeler> tffUyeler = (List<TffUyeler>) session.createCriteria(TffUyeler.class).add(Restrictions.or(Restrictions.isNull("bankaMusteriNo"), Restrictions.eq("bankaMusteriNo", new BigDecimal(0)))).addOrder(Order.asc("uyeNo")).setFetchSize(100).list();
		logger.info("MUSTERI NO yaratilacak UYE SAYISI : " + tffUyeler.size());
		int success = 0;
		int fail = 0;
		for (TffUyeler uye : tffUyeler) {
			try {
				BigDecimal customerNo = searchCustomer(uye.getUyruk(), String.valueOf(uye.getTckn()), uye.getPasaportNo());
				if (customerNo != null && customerNo.compareTo(new BigDecimal(0)) > 0) {
					uye.setBankaMusteriNo(customerNo);
					session.save(uye);
					session.flush();
					GMMap crmMap = new GMMap();
					crmMap.put("MUSTERI_NO", customerNo);
					crmMap = GMServiceExecuter.call("BNSPR_TFF_UPDATE_CUSTOMER_RECORDS_FOR_CRM", crmMap);
				}
				else {
					GMMap uyeMap = new GMMap();
					logger.info("BATCH MUSTERI YARAT - UYE_NO : " + uye.getUyeNo());
					uyeMap.put("UYE_NO", uye.getUyeNo());
					// uyeMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
					uyeMap.put("UYRUK", uye.getUyruk());
					uyeMap.put("CLIENT_IP", "0.0.0.0");
					uyeMap.put("CEP_ULKE_KOD", uye.getCepUlkeKod());
					uyeMap.put("CEP_ALAN_KOD", uye.getCepAlanKod());
					uyeMap.put("CEP_NUMARA", uye.getCepNumara());
					uyeMap.put("EPOSTA", uye.getEposta());
					if ("TR".equals(uye.getUyruk())) {
						uyeMap.put("TCKN", uye.getTckn());
						uyeMap.put("AD2", uye.getIkinciAdi());
						uyeMap.put("AD1", uye.getAdi());
						uyeMap.put("SOYAD", uye.getSoyadi());
						uyeMap.put("DOGUM_TARIHI", sdf.format(uye.getDogumTarihi()));
						uyeMap.put("CINSIYET", uye.getCinsiyet());
						uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", uyeMap));
						if (!"2".equals(uyeMap.getString("RESPONSE"))) {
							logger.error("KPS HATASI" + uyeMap.getString("RESPONSE_DATA"));
						}

					}
					else {
						uyeMap.put("PASAPORT_NO", uye.getPasaportNo());
						uyeMap.put("AD2", uye.getIkinciAdi());
						uyeMap.put("AD1", uye.getAdi());
						uyeMap.put("SOYAD", uye.getSoyadi());
						uyeMap.put("DOGUM_TARIHI", sdf.format(uye.getDogumTarihi()));
					}
					GMMap tmpMap = new GMMap();

					tmpMap = GMServiceExecuter.call("BNSPR_TFF_CREATE_CUSTOMER", uyeMap);
					if (tmpMap.getBigDecimal("MUSTERI_NO") == null || tmpMap.getBigDecimal("MUSTERI_NO").compareTo(new BigDecimal(0)) == 0) {
						logger.info("BATCH MUSTERI YARATAMADI - UYE_NO : " + uye.getUyeNo());
						fail++;
						continue;
					}
					else {

						uye.setBankaMusteriNo(tmpMap.getBigDecimal("MUSTERI_NO"));
						session.save(uye);
						session.flush();
						success++;
					}
				}
			}
			catch (Exception e) {
				logger.info("BATCH MUSTERI YARATAMADI (catch) - UYE_NO : " + uye.getUyeNo());
				fail++;
				continue;
			}

		}

		logger.info("BATCH MUSTERI YARATAMA SONUC - SUCCESS : " + success + " FAIL :" + fail);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BATCH_BASVURU_BILGILERINDEN_MUSTERI_GUNCELLE")
	public static GMMap tffBatchBasvurudanMusteriGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = null;
		Connection con = null;
		ResultSet res = null;
		PreparedStatement p = null;
		PreparedStatement u = null;
		try {
			con = DALUtil.getGMConnection();
			p = con.prepareStatement("SELECT BASVURU_NO FROM BNSPR.TFF_BATCH_MUSTERI_GUNCELLE WHERE DURUM IN (0,1) ORDER BY REC_DATE DESC");
			u = con.prepareStatement("UPDATE BNSPR.TFF_BATCH_MUSTERI_GUNCELLE SET DURUM = ? WHERE BASVURU_NO=?");
			p.setFetchSize(50);
			p.execute();
			res = p.getResultSet();

			while (res.next()) {
				basvuruNo = res.getBigDecimal("BASVURU_NO");
				GMMap tmpMap = new GMMap();
				tmpMap.put("TFF_BASVURU_NO", basvuruNo);
				tmpMap.putAll(GMServiceExecuter.executeNT("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", tmpMap));
				u.setInt(1, 2);
				u.setBigDecimal(2, basvuruNo);
				u.executeUpdate();
			}

			con.close();
		}
		catch (Exception e) {
			logger.info("BATCH MUSTERI GUNCELLEME HATASI " + basvuruNo);
			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(res);
			GMServerDatasource.close(p);
			GMServerDatasource.close(u);
			GMServerDatasource.close(con);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BATCH_EUPT_YARAT")
	public static GMMap tffBatchEuptYarat(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		List<TffUyeler> tffUyeler = session.createCriteria(TffUyeler.class).add(Restrictions.isNull("euptNo")).addOrder(Order.desc("uyeNo")).setMaxResults(10).list();
		logger.info("EUPT yaratilacak UYE SAYISI : " + tffUyeler.size());
		for (TffUyeler uye : tffUyeler) {
			try {
				GMMap uyeMap = new GMMap();
				logger.info("BATCH EUPT YARAT - UYE_NO : " + uye.getUyeNo());
				uyeMap.put("UYE_NO", uye.getUyeNo());
				uyeMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
				uyeMap.put("UYRUK", uye.getUyruk());
				uyeMap.put("CLIENT_IP", "0.0.0.0");
				uyeMap.put("CEP_ULKE_KOD", uye.getCepUlkeKod());
				uyeMap.put("CEP_ALAN_KOD", uye.getCepAlanKod());
				uyeMap.put("CEP_NUMARA", uye.getCepNumara());
				uyeMap.put("EPOSTA", uye.getEposta());
				if ("TR".equals(uye.getUyruk())) {
					uyeMap.put("TCKN", uye.getTckn());
					uyeMap.put("AD2", uye.getIkinciAdi());
					uyeMap.put("AD1", uye.getAdi());
					uyeMap.put("SOYAD", uye.getSoyadi());
					uyeMap.put("DOGUM_TARIHI", sdf.format(uye.getDogumTarihi()));
					uyeMap.put("CINSIYET", uye.getCinsiyet());
					uyeMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", uyeMap));
					if (!"2".equals(uyeMap.getString("RESPONSE"))) {
						logger.error("KPS HATASI" + uyeMap.getString("RESPONSE_DATA"));
					}

				}
				else {
					uyeMap.put("PASAPORT_NO", uye.getPasaportNo());
					uyeMap.put("AD2", uye.getIkinciAdi());
					uyeMap.put("AD1", uye.getAdi());
					uyeMap.put("SOYAD", uye.getSoyadi());
					uyeMap.put("DOGUM_TARIHI", sdf.format(uye.getDogumTarihi()));
				}
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_EUPT_YARAT_INNER", uyeMap);

			}
			catch (Exception e) {
				logger.error("EUPT yaratmada hata : UYE NO+" + uye.getUyeNo());
			}

		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BATCH_EUPT_YARAT_INNER")
	public static GMMap tffBatchEuptYaratInner(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffUyeler uye = (TffUyeler) session.createCriteria(TffUyeler.class).add(Restrictions.eq("uyeNo", iMap.getBigDecimal("UYE_NO"))).uniqueResult();

		iMap = GMServiceExecuter.call("BNSPR_TFF_EUPT_HESABI_OLUSTUR", iMap);
		String eupt = iMap.getString("USERID");
		if (eupt != null && !"".equals(eupt)) {
			uye.setEuptNo(eupt);
			List<TffBasvuru> tffbasvuruList = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("tffUyeNo", uye.getUyeNo())).add(Restrictions.isNull("euptUserId")).list();
			for (TffBasvuru b : tffbasvuruList) {
				b.setEuptUserId(eupt);
				session.save(b);
				session.flush();
			}
			session.save(uye);
			session.flush();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_SEND_APPLICATION_TO_CRM")
	public static GMMap sendApplicationToCRM(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			session.refresh(tffBasvuru);
			BigDecimal uyeNo = tffBasvuru.getTffUyeNo();
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			session.refresh(tffBasvuruKimlik);
			List<TffBasvuruAdres> adreslerList = session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).list();
			GMMap customerContactMap = new GMMap();
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, uyeNo);
			session.refresh(tffUyeler);
			String gonderme = "E";
			BigDecimal basvuruNo = iMap.getBigDecimal("TFF_BASVURU_NO");
			switch (iMap.getInt("CRM_TYPE")) {
			case CrmTypes.MAIN:
				sendCRMMain(basvuruNo);
				break;
			case CrmTypes.PAYMENT:
				sendCRMPayment(basvuruNo);
				break;
			case CrmTypes.ADDRESS:
				sendCRMAddress(basvuruNo);
				break;
			case CrmTypes.STATUS_UPDATE:
				sendCRMStatusUpdate(basvuruNo);
				break;
			default:
				break;
			}
			
			
			if (StringUtils.isBlank(iMap.getString("DURUM_KOD"))) {
				iMap.put("DURUM_KOD", tffBasvuru.getDurumKod());

			}

			try {
				String func = "{? = call Pkg_parametre.ParamTextDegerVarMi (?,?,?)}";
				gonderme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_CRM_GONDERIM", BnsprType.STRING, "DURUM_KOD", BnsprType.STRING, iMap.getString("DURUM_KOD")));
			}
			catch (Exception e) {
				gonderme = "H";
			}

			if ("E".equals(gonderme)) {
				logger.info("Gonderim yapilmayacak DURUM_KOD uygun degil " + iMap.getString("DURUM_KOD"));
				return oMap;
			}
			tmpMap.put("TFF_UYE_NO", tffBasvuru.getTffUyeNo());
			tmpMap = GMServiceExecuter.call("BNSPR_TFF_GET_APPROVED_PHOTO", tmpMap);

			customerContactMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());

			customerContactMap.put("TC_KIMLIK_NO", tffBasvuru.getTcKimlikNo());
			customerContactMap.put("UYRUK_KOD", tffUyeler.getUyruk());
			customerContactMap.put("PASAPORT_NO", tffUyeler.getPasaportNo());
			customerContactMap.put("NATIONALID", tffBasvuru.getTcKimlikNo());
			customerContactMap.put("NATIONALITY", tffUyeler.getUyruk());
			customerContactMap.put("PASSPORTSERIALNUMBER", tffUyeler.getPasaportNo());
			customerContactMap.put("CARDAPPLICATIONSTATUS", nvl(iMap.getString("DURUM_KOD"), tffBasvuru.getDurumKod()));
			customerContactMap.put("CARDDCI", tffBasvuru.getKartTipi());
			customerContactMap.put("CARDLEVEL", "M");// TODO:ASIL KART. EK KART GELDIGINDE PARAMETRIK OLACAK
			customerContactMap.put("CARDPHOTO", tmpMap.getString("TFF_APPROVED_IMAGE"));
			customerContactMap.put("COURIERTYPE", tffBasvuru.getKuryeTipi());
			customerContactMap.put("EMAILADDRESS", tffUyeler.getEposta());
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			customerContactMap.put("CARDAPPLICATIONSTATUSDATE",sdf.format(new Date()));
			 
			logger.info("Uye bilgileri OK");
			String otpDenemeSayisi = "";

			String func1 = "{? = call PKG_TRN3801.getProductId(?)}";
			String productId = "";
			try {
				productId = String.valueOf(DALUtil.callOracleFunction(func1, BnsprType.STRING, BnsprType.NUMBER, tffBasvuru.getBasvuruNo()));

			}
			catch (SQLException e) {
				productId = "";
			}
			customerContactMap.put("PRODUCTID", productId);
			logger.info("PRODUCTID bilgileri OK");
			String getTeamCode = "";
			String func2 = "{? = call PKG_TRN3801.getTeamCode(?)}";
			try {
				getTeamCode = (String) DALUtil.callOracleFunction(func2, BnsprType.STRING, BnsprType.STRING, tffBasvuru.getUrunSahipKodu());
			}
			catch (SQLException e) {
				getTeamCode = "";
			}
			customerContactMap.put("TEAMCODE", getTeamCode);
			logger.info("TEAMCODE bilgileri OK");
			String func3 = "{? = call PKG_TRN3801.getTeamCode(?)}";
			String sTeamCode = "";
			try {
				sTeamCode = (String) DALUtil.callOracleFunction(func3, BnsprType.STRING, BnsprType.STRING, tffUyeler.getTakim());

			}
			catch (SQLException e) {
				sTeamCode = "";
			}
			customerContactMap.put("SUPPORTEDTEAM", sTeamCode);

			String func = "{? = call PKG_TRN3801.getLogoCode(?)}";
			String logoCode = "";
			try {
				logoCode = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, tffBasvuru.getBasvuruNo());

			}
			catch (SQLException e) {
				logoCode = "";
			}
			customerContactMap.put("LOGOCODE", logoCode);
			logger.info("LOGOCODE bilgileri OK");
			customerContactMap.put("NATIONALID", tffBasvuruKimlik.getTcKimlikNo());
			customerContactMap.put("FIRSTNAME", tffBasvuruKimlik.getAd());
			customerContactMap.put("SURNAME", tffBasvuruKimlik.getSoyad());
			customerContactMap.put("SECONDNAME", tffBasvuruKimlik.getIkinciAd());
			customerContactMap.put("GENDER", tffBasvuruKimlik.getCinsiyet());
			customerContactMap.put("MARITALSTATUS", tffBasvuruKimlik.getMedeniHal());
			customerContactMap.put("BIRTHPLACE", tffBasvuruKimlik.getDogumYeri());
			customerContactMap.put("GSMNUMBER", tffUyeler.getCepTel());
			customerContactMap.put("PASSPORTSERIALNUMBER", tffBasvuruKimlik.getPasaportNo());
			customerContactMap.put("BIRTHDATE", tffBasvuruKimlik.getDogumTar());
			customerContactMap.put("NATIONALID", tffBasvuruKimlik.getTcKimlikNo());
			logger.info("basvuru1 bilgileri OK");
			{
				TffBasvuruMeslekiBilgi tffBasvuruMeslekiBilgi = (TffBasvuruMeslekiBilgi) session.get(TffBasvuruMeslekiBilgi.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				session.refresh(tffBasvuruMeslekiBilgi);
				if (tffBasvuruMeslekiBilgi != null) {
					customerContactMap.put("OCCUPATIONTYPE", tffBasvuruMeslekiBilgi.getCalismaSekli());
					customerContactMap.put("COMPANYNAME", tffBasvuruMeslekiBilgi.getIsyeriAdi());
					// customerContactMap.put("EGITIM_KOD",
					// tffBasvuruMeslekiBilgi.getEgitimKod());
				}
			}

			int adresIndex = 0;
			boolean adresEkle = false;
			boolean ekstreAdresiSecildi = false;
			for (TffBasvuruAdres tffBasvuruAdres : adreslerList) {
				if ("D".equals(tffBasvuruAdres.getId().getAdresKod())) {
					adresEkle = false;
					if ("E".equals(tffBasvuruAdres.getTeslimatAdresiMi())) {
						if (tffBasvuruAdres.getUyeAdresNo() != null) {
							adresEkle = true;
						}
					}
				}
				else if ("TN".equals(tffBasvuruAdres.getId().getAdresKod()) || "GN".equals(tffBasvuruAdres.getId().getAdresKod())) {
					adresEkle = true;
				}
				else {
					adresEkle = true;
				}

				if (adresEkle) {

					if ("E".equals(tffBasvuruAdres.getId().getAdresKod())) {
						customerContactMap.put("HOMEADDRESS", tffBasvuruAdres.getAcikAdres());
						customerContactMap.put("HOMEADDRESSCITYCODE", tffBasvuruAdres.getIlKod());
						customerContactMap.put("HOMEADDRESSCITYNAME", tffBasvuruAdres.getIlAd());
						customerContactMap.put("HOMEADDRESSTOWNCODE", tffBasvuruAdres.getIlceKod());
						customerContactMap.put("HOMEADDRESSTOWNNAME", tffBasvuruAdres.getIlceAd());
					}
					else if ("I".equals(tffBasvuruAdres.getId().getAdresKod())) {

						customerContactMap.put("WORKADDRESS", tffBasvuruAdres.getAcikAdres());
						customerContactMap.put("WORKADDRESSCITYCODE", tffBasvuruAdres.getIlKod());
						customerContactMap.put("WORKADDRESSCITYNAME", tffBasvuruAdres.getIlAd());
						customerContactMap.put("WORKADDRESSTOWNCODE", tffBasvuruAdres.getIlceKod());
						customerContactMap.put("WORKADDRESSTOWNNAME", tffBasvuruAdres.getIlceAd());

					}
					if ("E".equals(tffBasvuruAdres.getTeslimatAdresiMi())) {

						customerContactMap.put("DELIVERYADDRESS", tffBasvuruAdres.getAcikAdres());
						customerContactMap.put("DELIVERYADDRESSCITYCODE", tffBasvuruAdres.getIlKod());
						customerContactMap.put("DELIVERYADDRESSCITYNAME", tffBasvuruAdres.getIlAd());
						customerContactMap.put("DELIVERYADDRESSTOWNCODE", tffBasvuruAdres.getIlceKod());
						customerContactMap.put("DELIVERYADDRESSTOWNNAME", tffBasvuruAdres.getIlceAd());

					}

					if ("E".equals(tffBasvuruAdres.getIletisimMi()) && !ekstreAdresiSecildi) {
						customerContactMap.put("CONTACTADDRESSTYPE", tffBasvuruAdres.getId().getAdresKod());
						ekstreAdresiSecildi = true;
					}
					if (!ekstreAdresiSecildi && adreslerList.size() - 1 == adresIndex) {
						customerContactMap.put("CONTACTADDRESSTYPE", tffBasvuruAdres.getId().getAdresKod());
					}
					adresIndex++;
				}
			}
			logger.info("adres bilgileri OK");
			List<TffBasvuruTelefon> tffBasvuruTelefonListe = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).list();
			int index = 0;
			// cepepepepepep
			for (TffBasvuruTelefon tffBasvuruTelefon : tffBasvuruTelefonListe) {
				session.refresh(tffBasvuruTelefon);
				if ("1".equals(tffBasvuruTelefon.getId().getTip())) {
					customerContactMap.put("HOMEPHONENUMBER", tffBasvuruTelefon.getUlkeKod() + "" + tffBasvuruTelefon.getAlanKod() + "" + tffBasvuruTelefon.getNumara());
				}
				else if ("2".equals(tffBasvuruTelefon.getId().getTip())) {
					customerContactMap.put("WORKPHONENUMBER", tffBasvuruTelefon.getUlkeKod() + "" + tffBasvuruTelefon.getAlanKod() + "" + tffBasvuruTelefon.getNumara());
				}
				if ("E".equals(tffBasvuruTelefon.getIletisim())) {
					customerContactMap.put("CONTACTPHONENUMBER", tffBasvuruTelefon.getUlkeKod() + "" + tffBasvuruTelefon.getAlanKod() + "" + tffBasvuruTelefon.getNumara());
				}
				index++;
			}
			logger.info("telefon bilgileri OK");
			//GMServiceExecuter.execute("BNSPR_TFF_CRM_TFF_BASVURU_UPDATE", customerContactMap);
			logger.info("BNSPR_TFF_CRM_TFF_BASVURU_UPDATE bilgileri OK");
			return customerContactMap;
		}
		catch (Exception e) {
			logger.error("CRMSAF kaydi yapilamad�");
			logger.error(getTraceAsString(e));
		}

		return oMap;
	}

	private static void sendCRMStatusUpdate(BigDecimal basvuruNo) {
		// TODO Auto-generated method stub
		
	}

	private static void sendCRMAddress(BigDecimal basvuruNo) {
		// TODO Auto-generated method stub
		
	}

	private static void sendCRMPayment(BigDecimal basvuruNo) {
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, basvuruNo);
		session.refresh(tffBasvuruOdeme);
		GMMap crmMap = new GMMap();
		crmMap.put("APPLICATIONNO",tffBasvuruOdeme.getBasvuruNo()  );
		crmMap.put("APPLICATIONAMOUNT", tffBasvuruOdeme.getKartBedeli() );
		crmMap.put("PAYMENTTYPE",tffBasvuruOdeme.getOdemeSekli() );
		crmMap.put("OPERATIONTYPE","N");
		crmMap.put("LOYALTYAMOUNT",tffBasvuruOdeme.getLoyaltyBedeli());
		crmMap.put("COURIERAMOUNT",  tffBasvuruOdeme.getKuryeBedeli());
		crmMap.put("PROMOTIONCODE", tffBasvuruOdeme.getPromosyonKodu() );
		crmMap.put("PROMOTIONRATE",tffBasvuruOdeme.getPromosyonOrani() );
		crmMap.put("COURIERTYPE", tffBasvuruOdeme.getKuryeTipi());
		crmMap.put("PROMOTIONLOYALTY",tffBasvuruOdeme.getPromosyonLoyalty()  );
		crmMap.put("PROMOTIONAMOUNT", tffBasvuruOdeme.getPromosyonKart() );
		crmMap.put("PROMOTIONCOURIER", tffBasvuruOdeme.getPromosyonKurye());
		crmMap.put("BOXOFFICEUSER",  tffBasvuruOdeme.getGiseUser());
		crmMap.put("BOXOFFICECODE",  tffBasvuruOdeme.getGiseId());
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss"); 
		crmMap.put("PROCESSDATE",sdf.format(new Date()));
		
		GMServiceExecuter.call("BNSPR_TFF_CRM_SEND_APPLICATION_PAYMENT", crmMap);
		
	}

	private static void sendCRMMain(BigDecimal basvuruNo) {
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
		session.refresh(tffBasvuru);
		GMMap tmpMap = new GMMap();
		GMMap crmMap = new GMMap();
		crmMap.put("APPLICATIONNO", tffBasvuru.getBasvuruNo());
		crmMap.put("CUSTOMERNO", tffBasvuru.getMusteriNo());
		crmMap.put("CARDDCI", tffBasvuru.getKartTipi());
		
		//    PRODUCT ID
		String func1 = "{? = call PKG_TRN3801.getProductId(?)}";
		String productId = "";
		try {
			productId = String.valueOf(DALUtil.callOracleFunction(func1, BnsprType.STRING, BnsprType.NUMBER, tffBasvuru.getBasvuruNo()));

		}
		catch (SQLException e) {
			productId = "";
		}
		crmMap.put("PRODUCTID", productId);
		
		
		// LOGO KODU
		String func = "{? = call PKG_TRN3801.getLogoCode(?)}";
		String logoCode = "";
		try {
			logoCode = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, tffBasvuru.getBasvuruNo());

		}
		catch (SQLException e) {
			logoCode = "";
		}
		crmMap.put("LOGOCODE", logoCode);
		
		// TAKIM
		crmMap.put("TEAMCODE", tffBasvuru.getUrunSahipKodu());
		
		
		crmMap.put("STATUS", tffBasvuru.getDurumKod());
		crmMap.put("CREDITCARDAPPNO", tffBasvuru.getKkBasvuruNo());
		crmMap.put("CARDNO", tffBasvuru.getKartNo());
		crmMap.put("COURIERTYPE", tffBasvuru.getKuryeTipi());
		crmMap.put("SOURCE", tffBasvuru.getSource());
		crmMap.put("BOXOFFICECODE", tffBasvuru.getGiseId());
		crmMap.put("BOXOFFICEUSER", tffBasvuru.getGiseUser());
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		crmMap.put("INSERTDATE",sdf.format(new Date()));
		
		
		tmpMap.put("TFF_UYE_NO", tffBasvuru.getTffUyeNo());
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_GET_APPROVED_PHOTO", tmpMap);
		if(!TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE"))){
			crmMap.put("PHOTO", tmpMap.getString("TFF_APPROVED_IMAGE"));
		}else{
			crmMap.put("PHOTO", "");
		}
		
		/*Netmera durum kodu bildirmek icin asenkron cagri*/

		GMMap inputMap = new GMMap();
		inputMap.put("BASVURU_NO", crmMap.getBigDecimal("APPLICATIONNO"));
		inputMap.put("DURUM_KOD", crmMap.getString("STATUS"));
		GMServiceExecuter.executeAsync("BNSPR_PUSH_KART_DURUM_GUNCELLE_EVENT", inputMap);

		GMServiceExecuter.call("BNSPR_TFF_CRM_SEND_APPLICATION_MAIN", crmMap);
		

	}

	@GraymoundService("BNSPR_TFF_TOPLU_VERI_KONTROL")
	public static GMMap topluVeriKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		/*	String databaseAdi = GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", iMap).getString("DATABASE_ADI");
			if(databaseAdi.equals("PROD")){
				return oMap;
			}
			GMMap tmpMap = new GMMap();
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			List <TffBasvuru> tffBasvuru ;
			if(org.apache.commons.lang.StringUtils.isNotBlank(iMap.getString("BASVURU_NO"))){
				tffBasvuru = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo",iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("durumKod","VERI_KONTROL")).addOrder(Order.desc("recDate")).setMaxResults(1).list();
			}else{
				
				tffBasvuru = session.createCriteria(TffBasvuru.class).add(Restrictions.in("kartTipi",new String[]{"P","D"})).add(Restrictions.eq("durumKod","VERI_KONTROL")).addOrder(Order.desc("recDate")).setMaxResults(1).list();
			}
			for(TffBasvuru b: tffBasvuru){
				try {
					
				
				tmpMap.put("MUSTERI_NO", b.getMusteriNo());
				tmpMap.put("KART_TIPI", b.getKartTipi());
				tmpMap.put("BASVURU_NO", b.getBasvuruNo());
				tmpMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", tmpMap));
				tmpMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_GET_BASVURU_INFO", tmpMap));
				tmpMap.put("FOTO_UYGUN", true);
				tmpMap.put("ADRES1_UYGUN", true);
				tmpMap.put("ADRES2_UYGUN", true);
				tmpMap.put("ADRES3_UYGUN", true);
				tmpMap.put("AKS_UYGUN", true);
				tmpMap.put("EV_TEL_UYGUN", true);
				tmpMap.put("IS_TEL_UYGUN", true);
				tmpMap.put("ISYERI_ADI_UYGUN", true);
				tmpMap.put("FOTO_DEGER", tmpMap.getString("FOTO"));
				tmpMap.put("ADRES1_DEGER", tmpMap.getString("ADRES1"));
				tmpMap.put("ADRES2_DEGER", tmpMap.getString("ADRES2"));
				tmpMap.put("ADRES3_DEGER", tmpMap.getString("ADRES3"));
				tmpMap.put("AKS_DEGER", tmpMap.getString("AKS"));
				tmpMap.put("EV_TEL_DEGER", tmpMap.getString("EV_TEL"));
				tmpMap.put("IS_TEL_DEGER", tmpMap.getString("IS_TEL"));
				tmpMap.put("ISYERI_ADI_DEGER", tmpMap.getString("ISYERI_ADI"));
				tmpMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_SAVE", tmpMap));
				} catch (Exception e) {
					logger.error("VERI_KONTROLHATA "+ b.getBasvuruNo());
				}
			}
			*/
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BATCH_APPLICATION_VALIDATION")
	public static GMMap createBatchApplicationValidation(GMMap iMap) {
		GMMap oMap = new GMMap();

		/* 1 CREATE MEMBER */
		String uyruk = iMap.getString("NATIONALITY");
		String pasaportNo = iMap.getString("PASSPORT_NO");
		String tckn = iMap.getString("TCKN");
		String kartTipi = iMap.getString("CARD_TYPE");
		String urun = iMap.getString("PRODUCT");
		String urunSahip = iMap.getString("PRODUCT_OWNER");
		String adi = iMap.getString("NAME");
		String soyadi = iMap.getString("SURNAME");
		String ikinciAdi = iMap.getString("MIDDLE_NAME");
		String annekizlikSoyadi = iMap.getString("MOTHER_MAIDEN_SURNAME");
		String birthDate = iMap.getString("BIRTHDATE");
		String email = iMap.getString("EMAIL");
		String foto = iMap.getString("PHOTO_BYTE_ARRAY");
		String kuryeTipi = iMap.getString("COURIER_TYPE");
		String kartBedeli = iMap.getString("CARD_FEE");
		String kuryeBedeli = iMap.getString("COURIER_FEE");
		String sadakatBedeli = iMap.getString("LOYALTY_FEE");
		String vizeBedeli = iMap.getString("SUBSCRIPTION_FEE");
		String paymentType = iMap.getString("PAYMENT_TYPE");
		String kartNo = iMap.getString("CARD_NO");
		String source = iMap.getString("SOURCE");

		String tip = iMap.getString("PHONE_TYPE");
		String ulkeKod = iMap.getString("PHONE_COUNTRY_CODE");
		String alanKod = iMap.getString("PHONE_AREA_CODE");
		String numara = iMap.getString("PHONE_NUMBER");

		try {
			String procStr = "{call BNSPR.PKG_TRN3801.validation_batch_application(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[36];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("NATIONALITY");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASSPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CARD_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PRODUCT");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PRODUCT_OWNER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("NAME");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SURNAME");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BIRTHDATE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("EMAIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("COURIER_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PAYMENT_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CARD_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_COUNTRY_CODE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_AREA_CODE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_NUMBER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");

			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BATCH_BASVURU_HATA);
		}
		return oMap;

		/* 2 CREATE APPLICATION  */
		/* 3 PAYMENT   */

		/* 4 ACTIVATION  */

	}

	/**
	 * Toplu basvuru icin atomik basvuru servisidir her kayit icin cagrilir.
	 * Saf bu servisi cagiri ve sifirdan basvuru olusturur.
	 * 
	 * hata alirsa log tablosuna kaydeder
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_CREATE_APPLICATION_FOR_BATCH")
	public static GMMap createApplicationForBatch(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();

		GMMap globals = new GMMap();
		globals.put("KULLANICI_KOD", "TFF");
		CreditCardServicesUtil.setUserGlobals(globals);
		logger.info("TOPLU_BASVURU| USER_NAME:" + ADCSession.getString("USER_NAME"));
		logger.info("TOPLU_BASVURU| BRANCH_ID:" + ADCSession.getString("BRANCH_ID"));
		String uyruk = iMap.getString("NATIONALITY");
		String pasaportNo = iMap.getString("PASSPORT_NO");
		String tckn = iMap.getString("TCKN");
		String kartTipi = iMap.getString("CARD_TYPE");
		String urun = iMap.getString("PRODUCT");
		String urunSahip = iMap.getString("PRODUCT_OWNER");
		String adi = iMap.getString("NAME");
		String soyadi = iMap.getString("SURNAME");
		String ikinciAdi = iMap.getString("MIDDLE_NAME");
		String annekizlikSoyadi = iMap.getString("MOTHER_MAIDEN_SURNAME");
		String dogumTarihi = iMap.getString("BIRTHDATE");
		String email = iMap.getString("EMAIL");
		String calismaSekli = iMap.getString("WORK_TYPE");
		String foto = iMap.getString("PHOTO_BYTE_ARRAY");
		String kuryeTipi = iMap.getString("COURIER_TYPE");
		String promosyonKodu = iMap.getString("PROMOSYON_KODU");
		String kartBedeli = iMap.getString("CARD_FEE");
		String kuryeBedeli = iMap.getString("COURIER_FEE");
		String sadakatBedeli = iMap.getString("LOYALTY_FEE");
		String vizeBedeli = iMap.getString("SUBSCRIPTION_FEE");
		String odemeTipi = iMap.getString("PAYMENT_TYPE");
		String odemeRefId = iMap.getString("PAYMENT_REF_ID");
		String kartNo = iMap.getString("CARD_NO");
		String source = iMap.getString("SOURCE");

		String tip = iMap.getString("PHONE_TYPE");
		String ulkeKod = iMap.getString("PHONE_COUNTRY_CODE");
		String alanKod = iMap.getString("PHONE_AREA_CODE");
		String numara = iMap.getString("PHONE_NUMBER");

		String adresTipi = iMap.getString("ADDRESS_TYPE");
		String acikAdres = iMap.getString("ADDRESS");
		String ilKodu = iMap.getString("CITY_CODE");
		String ilceKodu = iMap.getString("TOWN_CODE");
		String teslimatNoktasiKodu = iMap.getString("DELIVERY_PCODE");

		BigDecimal basvuruNo = null;
		BigDecimal uyeNo = null;
		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " BNSPR_TFF_BATCH_APPLICATION_VALIDATION");
		tmpMap.putAll(GMServiceExecuter.call("BNSPR_TFF_BATCH_APPLICATION_VALIDATION", iMap));
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);

			return tmpMap;
		}
		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " VALIDATION OK");

		// 1 CREATE MEMBER
		GMMap uyeMap = new GMMap();
		uyeMap.put("TCKN", tckn);
		uyeMap.put("PASAPORT_NO", pasaportNo);
		uyeMap.put("UYRUK", uyruk);

		uyeMap.putAll(findUye(uyeMap));
		uyeNo = uyeMap.getBigDecimal("UYE_NO");
		if (!uyeMap.containsKey("UYE_NO")) {
			uyeMap.put("UYRUK", uyruk);
			uyeMap.put("TCKN", tckn);
			uyeMap.put("TAKIM", urunSahip);
			uyeMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
			uyeMap.put("CALISMA_SEKLI", calismaSekli);
			uyeMap.put("ILETISIM_TEL_TIP", tip);
			if ("C".equals(tip)) {

				uyeMap.put("CEP_ULKE_KOD", ulkeKod);
				uyeMap.put("CEP_ALAN_KOD", alanKod);
				uyeMap.put("CEP_NUMARA", numara);
			}
			uyeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			uyeMap.put("WEB_ADI", adi);
			uyeMap.put("WEB_SOYADI", soyadi);
			uyeMap.put("WEB_IKINCI_ADI", ikinciAdi);
			uyeMap.put("WEB_DOGUM_TARIHI", dogumTarihi);
			uyeMap.put("EMAIL", email);
			uyeMap.put("SOURCE", source);

			uyeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_MEMBER", uyeMap));
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(uyeMap.getString("RESPONSE"))) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", uyeMap.getString("RESPONSE_DATA"));
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, uyeMap.getString("RESPONSE_DATA"));
			}
			else {
				uyeNo = uyeMap.getBigDecimal("UYE_NO");
			}
		}
		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " UYE OK UYE_NO:" + uyeNo);
		// 1 CREATE MEMBER

		// 2 CREATE APPLICATION
		GMMap basvuruMap = new GMMap();
		String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
		basvuruMap.put("KANAL_KOD", kanalKodu);

		// basvuruMap.put("ISYERI_ADI",iMap.getString("ISYERI_ADI"));
		basvuruMap.put("UYE_NO", uyeMap.getString("UYE_NO"));
		basvuruMap.put("KART_TIPI", kartTipi);
		basvuruMap.put("URUN_KODU", urun);
		basvuruMap.put("URUN_SAHIP_KODU", urunSahip);
		basvuruMap.put("EUPT_YARAT", "E");
		basvuruMap.put("SOURCE", source);
		basvuruMap.put("CALISMA_SEKLI", calismaSekli);
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));

		iMap.put("KURYE_TIPI", kuryeTipi);
		if (!isKuryeTipiValid(iMap)) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", "0155");
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, "0155");
		}
		basvuruMap.put("KURYE_TIPI", kuryeTipi);
		basvuruMap.put("ILETISIM_TEL_TIP", tip);

		if ("E".equals(tip)) {
			basvuruMap.put("EV_ULKE_KOD", ulkeKod);
			basvuruMap.put("EV_TEL_KOD", alanKod);
			basvuruMap.put("EV_TEL_NO", numara);
		}
		else if ("I".equals(tip)) {
			basvuruMap.put("IS_ULKE_KOD", ulkeKod);
			basvuruMap.put("IS_TEL_KOD", alanKod);
			basvuruMap.put("IS_TEL_NO", numara);
		}

		basvuruMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
		if (("TN".equals(kuryeTipi) || "GN".equals(kuryeTipi)) && ("D".equals(kartTipi) || "KK".equals(kartTipi))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", "0155");
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, "0155");
		}

		tmpMap.clear();
		TffUyeler uye = findUye(uyruk, StringUtils.isBlank(tckn) ? null : new BigDecimal(tckn), pasaportNo);
		iMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
		iMap.put("UYE_NO", uye.getUyeNo());
		iMap.put("TCKN", tckn);
		iMap.put("KART_TIPI", kartTipi);
		iMap.put("URUN_KODU", urun);
		iMap.put("URUN_SAHIP_KODU", urunSahip);
		tmpMap.putAll(GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap));
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		tmpMap.clear();
		tmpMap.put("DIRECT_CALL", true);
		tmpMap.put("URUN_SAHIP_KODU", urunSahip);
		tmpMap.put("URUN_KODU", urun);
		tmpMap.put("UYE_NO", uyeNo);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", tmpMap);
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		else {
			int su = tmpMap.getSize("KART_UYGUNLUK");
			for (int i = 0; i < su; i++) {
				String ktip = tmpMap.getString("KART_UYGUNLUK", i, "KART_TIPI");
				String uygunluk = tmpMap.getString("KART_UYGUNLUK", i, "UYGUNLUK");
				if (kartTipi.equals(ktip) && "H".equals(uygunluk)) {
					tmpMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					if ("KK".equals(iMap.getString("KART_TIPI"))) {
						tmpMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
					}
					else if ("D".equals(iMap.getString("KART_TIPI"))) {
						tmpMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
					}
					else if ("P".equals(iMap.getString("KART_TIPI"))) {
						tmpMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
					}

					iMap.put("DURUM", new BigDecimal(2));
					iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
					GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
					throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
				}
			}

		}

		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " BASVURU OLTURMAYA BASLA");
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", basvuruMap);
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		basvuruNo = tmpMap.getBigDecimal("TFF_BASVURU_NO");

		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " BASVURU OK NO:" + basvuruNo);
		// 2 CREATE APPLICATION
		// 3 PHOTO

		tmpMap.clear();
		GMMap photoMap = new GMMap();
		photoMap.put("TFF_BASVURU_NO", basvuruNo);
		photoMap.put("SOURCE", source);
		if (StringUtils.isBlank(foto)) {
			if ("TR".equals(uyruk)) {
				tmpMap.put("PHOTO_BYTE_ARRAY", getPhotoForBatchApplication(tckn));
			}
			else {
				tmpMap.put("PHOTO_BYTE_ARRAY", getPhotoForBatchApplication(uyruk + pasaportNo));
			}
		}
		else {
			photoMap.put("FOTO_BYTE_ARRAY", foto);
		}

		tmpMap = GMServiceExecuter.call("BNSPR_TFF_FOTO_YUKLE", photoMap);
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}

		GMMap uyeAdres = new GMMap();
		uyeAdres.put("UYE_NO", uye.getUyeNo());
		uyeAdres.put("TFF_BASVURU_NO", basvuruNo);
		uyeAdres.put("ADRES_TIPI", adresTipi);
		uyeAdres.put("ACIK_ADRES", acikAdres);
		uyeAdres.put("IL_AD", "");
		uyeAdres.put("IL_KOD", ilKodu);
		uyeAdres.put("ILCE_KOD", ilceKodu);
		uyeAdres.put("ILCE_AD", ilceKodu);
		uyeAdres.put("ADRES_RUMUZ", "TESLIMAT_NOKTASI");
		uyeAdres.put("SOURCE", iMap.getString("SOURCE"));
		uyeAdres.put("TESLIMAT_ADRESI_MI", "E");
		uyeAdres.put("ILETISIM_MI", "H");
		uyeAdres.put("TESLIMAT_NOKTASI_KODU", teslimatNoktasiKodu);
		uyeAdres.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS", uyeAdres));

		if (!"2".equals(uyeAdres.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", uyeAdres.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, uyeAdres.getString("RESPONSE_DATA"));
		}
		String teslimatAdresNo = uyeAdres.getString("ADRES_NO");
		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " ADRES OK. NO:" + teslimatAdresNo);
		// 4 PAYMENT
		GMMap odemeMap = new GMMap();
		boolean usePromosyon = false;
		if (StringUtils.isNotBlank(promosyonKodu)) {
			GMMap pMap = new GMMap();
			pMap.put("PROMOSYON_KODU", promosyonKodu);
			pMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_PROMOSYON_DETAY_SORGU", pMap));
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(pMap.getString("RESPONSE"))) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", pMap.getString("RESPONSE_DATA"));
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, pMap.getString("RESPONSE_DATA"));
			}
			else {
				usePromosyon = true;
				BigDecimal kb = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "KART_BEDELI");
				BigDecimal kub = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "KURYE_BEDELI");
				BigDecimal lb = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "LOYALTY_BEDELI");
				BigDecimal vb = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "VIZE_BEDELI");

				odemeMap.put("PROMOSYON_KODU", promosyonKodu);

				BigDecimal kartBedeliNum = new BigDecimal(kartBedeli);
				BigDecimal kuryeBedeliNum = new BigDecimal(kuryeBedeli);
				BigDecimal sadakatBedeliNum = new BigDecimal(sadakatBedeli);
				BigDecimal vizeBedeliNum = new BigDecimal(vizeBedeli);

				odemeMap.put("KART_BEDELI", kartBedeliNum);
				odemeMap.put("KURYE_BEDELI", kuryeBedeliNum);
				odemeMap.put("LOYALTY_BEDELI", sadakatBedeliNum);
				odemeMap.put("VIZE_BEDELI", vizeBedeliNum);

				odemeMap.put("PROMOSYON_BEDELI", kb.add(kub).add(lb).add(vb));
			}

		}

		odemeMap.put("BASVURU_NO", basvuruNo);
		odemeMap.put("SOURCE", source);
		odemeMap.put("KURYE_TIPI", kuryeTipi);
		odemeMap.put("ODEME_TIPI", odemeTipi);
		odemeMap.put("ODEME_REF_ID", odemeRefId);
		odemeMap.put("TESLIMAT_ADRES_NO", teslimatAdresNo);
		if (!usePromosyon) {
			odemeMap.put("PROMOSYON_KODU", "");
			odemeMap.put("KART_BEDELI", kartBedeli);
			odemeMap.put("KURYE_BEDELI", kuryeBedeli);
			odemeMap.put("LOYALTY_BEDELI", sadakatBedeli);
			odemeMap.put("VIZE_BEDELI", vizeBedeli);
			odemeMap.put("PROMOSYON_BEDELI", 0);
		}

		tmpMap.clear();
		tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_ODEME_YAP", odemeMap);
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "");
		oMap.put("APPLICATION_NO", basvuruNo);
		iMap.put("DURUM", new BigDecimal(1));
		iMap.put("BASVURU_NO", basvuruNo);
		iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
		logger.info("TOPLU_BASVURU| TCKN:" + tckn + " TOPLU_BASVURU OK. NO:" + basvuruNo);
		GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);

		GMMap durumMap = new GMMap();
		String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
		try {
			String oto = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_TOPLU_BASVURU", BnsprType.STRING, "ODEME", BnsprType.STRING, "VERI_KONTROL"));
			if ("H".equals(oto)) {
				durumMap.put("BASVURU_NO", basvuruNo);
				durumMap.put("DURUM_KOD", "INTRA_JOB");
				durumMap.put("ISLEM_ACIKLAMA", "Toplu basvurudan otomatik ilerletme");
				durumMap.put("TARIHCE_AKSIYON", "E");
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
			}
		}
		catch (SQLException e) {
			logger.info("TOPLU_BASVURU| TCKN:" + tckn + " TOPLU_BASVURU OK. NO:" + basvuruNo);
			e.printStackTrace();
		}

		oMap.put("ERROR_CODE", "0");
		oMap.put("ERROR_DESC", "");
		return oMap;
	}

	/**
	 * Toplu basvuru icin okunan bilgilri saf tablosuna kaydeder.
	 * 
	 * @param iMap
	 * @return
	 * @throws Exception
	 */
	@GraymoundService("BNSPR_TFF_APPLICATION_PUT_SAF")
	public static GMMap putApplicationToSaf(GMMap iMap) throws Exception {

		Session session = DAOSession.getSession("BNSPRDal");

		String safKey = "";

		if (iMap.get("TCKN") != null && iMap.get("TCKN").toString().length() > 0) {

			safKey = iMap.getString("TCKN") + "_" + iMap.getString("REF_ID");

		}
		else if (iMap.get("PASSPORT_NO") != null && iMap.get("PASSPORT_NO").toString().length() > 0 && iMap.get("NATIONALITY") != null && iMap.get("NATIONALITY").toString().length() > 0) {

			safKey = iMap.getString("NATIONALITY") + iMap.getString("PASSPORT_NO") + "_" + iMap.getString("REF_ID");

		}
		else {

			iMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			iMap.put("MAIL_SUBJECT", "TOPLU_BASVURU_HATA - TCKN :" + iMap.get("TCKN"));
			iMap.put("MAIL_BODY", "Saf Key generate edilemedi. �nput : " + iMap.toString());
			iMap.put("IS_BODY_HTML", "H");
			iMap.put("MAIL_TO", "erdogan.demir@aktifbank.com.tr");
			GMServiceExecuter.executeAsync("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", iMap);
			return iMap;
		}

		iMap.put("SAF_KEY", safKey);

		SimpleDateFormat firstSendDate = new SimpleDateFormat("yyyyMMddHHmmssSSSS");

		TffCrmSaf saf = new TffCrmSaf();
		saf.setSafKey(safKey);
		saf.setFirstSendDate(Long.parseLong(firstSendDate.format(new Date())));
		saf.setNextSendDate(0l);
		if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("CARD_TYPE")))
			saf.setWebServiceName("BNSPR_TFF_CREATE_KK_APPLICATION_FOR_BATCH");
		else
			saf.setWebServiceName("BNSPR_TFF_CREATE_APPLICATION_FOR_BATCH");
		saf.setRunning((byte) 0);
		saf.setSendStatus("10");
		saf.setStatus(true);
		saf.setTryCount(Short.parseShort("10"));

		Clob parameters = new ClobImpl(new String(Base64.encodeBase64(GMToolkit.serialize(iMap))));
		Clob parametersString = new ClobImpl(iMap.toString());

		saf.setParameters(parameters);
		saf.setParametersString(parametersString);
		saf.setWaitTime(180000l);

		session.save(saf);
		iMap.put("DURUM", BigDecimal.TEN);
		iMap.put("ACIKLAMA", "SAF kayd� yap�ld�");
		GMServiceExecuter.execute("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
		return iMap;
	}

	/**
	 * Toplu basvuru girilen tablodan verileri okur ve tek tek basvuru saf kayitlarini
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_BATCH_APPLICATION")
	public static GMMap batchApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		ScrollableResults scrollableResults = session.createQuery("from TffTopluBasvuru where durum = 0").setFetchSize(500).scroll(ScrollMode.FORWARD_ONLY);
		try {

			GMMap tmpMap = new GMMap();
			int count = 0;
			while (scrollableResults.next()) {
				tmpMap.clear();
				TffTopluBasvuru topluBasvuru = (TffTopluBasvuru) scrollableResults.get()[0];
				System.out.println(count + " Ba�vuru : " + topluBasvuru.getUyruk() + " " + topluBasvuru.getTckn() + " " + topluBasvuru.getPasaportNo());
				if (++count > 0 && count % 50 == 0) {
					logger.info("TOPLU_BASVURU Fetched " + count + " entities");
					session.clear();
					session.flush();

				}

				tmpMap.put("REF_ID", topluBasvuru.getId());
				logger.info("TOPLU_BASVURU ekleniyor  REF_ID :" + topluBasvuru.getId());
				tmpMap.put("NATIONALITY", topluBasvuru.getUyruk());
				tmpMap.put("PASSPORT_NO", topluBasvuru.getPasaportNo());
				tmpMap.put("TCKN", topluBasvuru.getTckn());
				tmpMap.put("CARD_TYPE", topluBasvuru.getKartTipi());
				tmpMap.put("PRODUCT", topluBasvuru.getUrun());
				tmpMap.put("PRODUCT_OWNER", topluBasvuru.getUrunSahipKodu());
				tmpMap.put("NAME", topluBasvuru.getAd());
				tmpMap.put("SURNAME", topluBasvuru.getSoyad());
				tmpMap.put("MIDDLE_NAME", topluBasvuru.getIkinciAd());
				tmpMap.put("MOTHER_MAIDEN_SURNAME", topluBasvuru.getIkinciAd());

				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				if (topluBasvuru.getDogumTarihi() == null) {
					tmpMap.put("BIRTHDATE", "19800101");
				}
				else {
					tmpMap.put("BIRTHDATE", sdf.format(topluBasvuru.getDogumTarihi()));
				}
				// tmpMap.put("EMAIL",topluBasvuru.get);

				// Bu tel tipini parametrik yapabiliriz ilk gelen exceli degistimek lazim
				tmpMap.put("PHONE_TYPE", "C");
				tmpMap.put("PHONE_COUNTRY_CODE", topluBasvuru.getCepUlkeKod());
				tmpMap.put("PHONE_AREA_CODE", topluBasvuru.getCepAlanKod());
				tmpMap.put("PHONE_NUMBER", topluBasvuru.getCepNo());

				tmpMap.put("ADDRESS_TYPE", topluBasvuru.getTeslimatAdresi());
				tmpMap.put("ADDRESS", topluBasvuru.getAcikAdres());
				tmpMap.put("CITY_CODE", topluBasvuru.getIl());
				tmpMap.put("TOWN_CODE", topluBasvuru.getIlce());
				tmpMap.put("DELIVERY_PCODE", topluBasvuru.getTeslimatNoktaKodu());

				// tmpMap.put("WORK_TYPE","14");

				if ("TR".equals(topluBasvuru.getUyruk())) {
					tmpMap.put("PHOTO_BYTE_ARRAY", getPhotoForBatchApplication(topluBasvuru.getTckn()));
				}
				else {
					tmpMap.put("PHOTO_BYTE_ARRAY", getPhotoForBatchApplication(topluBasvuru.getUyruk() + topluBasvuru.getPasaportNo()));
				}

				// TFF_TOPLU_BASVURU dan alinabilir bu fiyatlar
				tmpMap.put("PROMOSYON_KODU", topluBasvuru.getPromosyonKodu());
				tmpMap.put("COURIER_TYPE", topluBasvuru.getKuryeTipi());
				tmpMap.put("CARD_FEE", topluBasvuru.getKartBedeli());
				tmpMap.put("COURIER_FEE", topluBasvuru.getKuryeBedeli());
				tmpMap.put("LOYALTY_FEE", topluBasvuru.getLoyaltyBedeli());
				tmpMap.put("SUBSCRIPTION_FEE", topluBasvuru.getVizeBedeli());
				tmpMap.put("PAYMENT_TYPE", "N");
				// tmpMap.put("PAYMENT_REF_ID","");
				// tmpMap.put("CARD_NO","");
				tmpMap.put("SOURCE", "BATCH");

				// TFF kredi kart alanlari
				tmpMap.put("TRX_NO", topluBasvuru.getTxNo());
				tmpMap.put("KART_TIPI", topluBasvuru.getKartTipi());
				tmpMap.put("ANNE_KIZLIK_SOYADI", topluBasvuru.getAnneKizlikSoyadi());
				tmpMap.put("KK_KAYNAK", topluBasvuru.getKaynak());
				tmpMap.put("OTOMATIK_LIMIT_ARTIMI", topluBasvuru.getOtomatikLimitArtis());
				tmpMap.put("HESAP_KESIM_TARIHI", topluBasvuru.getHesapKesimTarihi());
				tmpMap.put("YURT_DISI_EKSTRE_TIP", topluBasvuru.getYurtdisiHarcamaEkstresi());
				tmpMap.put("KART_OTOMATIK_ODEME", topluBasvuru.getOtomatikOdemeTalimati());
				tmpMap.put("KREDI_KARTI_EKSTRE_TIPI_POSTA", topluBasvuru.getEkstreTipiPosta());
				tmpMap.put("KREDI_KARTI_EKSTRE_TIPI_EMAIL", topluBasvuru.getEkstreTipiEmail());
				tmpMap.put("KREDI_KARTI_EKSTRE_TIPI_SMS", topluBasvuru.getEkstreTipiSms());
				tmpMap.put("KREDI_KARTI_EKSTRE_SECIMI", topluBasvuru.getEkstreSecimi());
				tmpMap.put("EMAIL", topluBasvuru.getEmail());
				tmpMap.put("MESLEK", topluBasvuru.getMeslek());
				tmpMap.put("AYLIK_GELIR", topluBasvuru.getAylikGelir());
				tmpMap.put("OGRENIM_DURUMU", topluBasvuru.getOgrenimDurumu());
				tmpMap.put("TESLIMAT_ADRES_TIPI", topluBasvuru.getTeslimatAdresi());
				tmpMap.put("ILETISIM_ADRES_TIPI", topluBasvuru.getTeslimatAdresi());

				tmpMap.put("CALISMA_SEKLI", topluBasvuru.getCalismaSekli());
				tmpMap.put("ISYERI_VERGI_DAIRESI_ADI", topluBasvuru.getVergiDairesi());
				tmpMap.put("ISYERI_ADI", topluBasvuru.getIsyeriAdi());
				tmpMap.put("IS_ACIK_ADRES", topluBasvuru.getIsyeriAdresi());
				tmpMap.put("IS_IL_KOD", topluBasvuru.getIsyeriIlKod());
				tmpMap.put("IS_ILCE_KOD", topluBasvuru.getIsyeriIlceKod());
				tmpMap.put("ISYERI_POSTA_KOD", topluBasvuru.getIsyeriPostaKod());
				tmpMap.put("IS_ULKE_KOD", topluBasvuru.getIsTelUlkeKod());
				tmpMap.put("IS_TEL_KOD", topluBasvuru.getIsTelAlanKod());
				tmpMap.put("IS_TEL_NO", topluBasvuru.getIsTelNo());
				tmpMap.put("IS_TEL_DAHILI", topluBasvuru.getIsTelDahili());

				tmpMap.put("EV_ACIK_ADRES", topluBasvuru.getEvAdresi());
				tmpMap.put("EV_IL_KOD", topluBasvuru.getEvIlKod());
				tmpMap.put("EV_ILCE_KOD", topluBasvuru.getEvIlceKod());
				tmpMap.put("EV_POSTA_KOD", topluBasvuru.getEvPostaKod());
				tmpMap.put("EV_ULKE_KOD", topluBasvuru.getEvTelUlkeKod());
				tmpMap.put("EV_TEL_KOD", topluBasvuru.getEvTelAlanKod());
				tmpMap.put("EV_TEL_NO", topluBasvuru.getEvTelNo());

				tmpMap.put("CEP_ULKE_KOD", topluBasvuru.getCepUlkeKod());
				tmpMap.put("CEP_TEL_KOD", topluBasvuru.getCepAlanKod());
				tmpMap.put("CEP_TEL_NO", topluBasvuru.getCepNo());

				GMServiceExecuter.executeAsync("BNSPR_TFF_APPLICATION_PUT_SAF", tmpMap);

			}
		}
		catch (Exception e) {
			logger.error("Toplu basvuru okuma hatasi");
			e.printStackTrace();
		}
		finally {
			scrollableResults.close();
		}

		return oMap;

	}

	@GraymoundService("BNSPR_TFF_BATCH_UPDATE_STATUS")
	public static GMMap setTopluBasvuruStatus(GMMap iMap) {
		GMMap globals = new GMMap();
		globals.put("KULLANICI_KOD", "TFF");
		CreditCardServicesUtil.setUserGlobals(globals);
		GMMap oMap = new GMMap();
		BigDecimal id = iMap.getBigDecimal("REF_ID");
		BigDecimal durum = iMap.getBigDecimal("DURUM");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		String aciklama = iMap.getString("ACIKLAMA");
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		try {
			TffTopluBasvuru tffTopluBasvuru = (TffTopluBasvuru) session.get(TffTopluBasvuru.class, id);
			tffTopluBasvuru.setDurum(durum);
			tffTopluBasvuru.setDurumAciklama(aciklama);

			if (new BigDecimal(1).compareTo(durum) == 0) {
				tffTopluBasvuru.setBasvuruNo(basvuruNo);
			}
			session.save(tffTopluBasvuru);
			session.flush();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;

	}

	@GraymoundService("BNSPR_TFF_BATCH_APP_TEST")
	public static GMMap testTopluBasvuru(GMMap iMap) {
		GMMap globals = new GMMap();
		globals.put("KULLANICI_KOD", "TFF");
		CreditCardServicesUtil.setUserGlobals(globals);
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		List<TffCrmSaf> res = session.createCriteria(TffCrmSaf.class).add(Restrictions.eq("webServiceName", "BNSPR_TFF_CREATE_APPLICATION_FOR_BATCH")).list();
		for (TffCrmSaf r : res) {
			try {
				GMMap p = (GMMap) GMToolkit.deserialize(Base64.decodeBase64(GMToolkit.read(r.getParameters().getAsciiStream())));
				iMap.putAll(p);
				GMServiceExecuter.call("BNSPR_TFF_CREATE_APPLICATION_FOR_BATCH", iMap);
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return globals;
	}

	/**
	 * Toplu basvuru icin atomik basvuru servisidir her kayit icin cagrilir.
	 * Saf bu servisi cagiri ve sifirdan basvuru olusturur.
	 * 
	 * hata alirsa log tablosuna kaydeder
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_CREATE_KK_APPLICATION_FOR_BATCH")
	public static GMMap createAllApplicationForBatch(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TFF_BATCH_APPLICATION_INNER", iMap));
		
		BigDecimal basvuruNo = oMap.getBigDecimal("TFF_BASVURU_NO");
		BigDecimal uyeNo =oMap.getBigDecimal("UYE_NO");
		//KK basvuru olustur
		try {
			GMMap kkBasvuru = new GMMap();
			kkBasvuru.put("KULLANICI_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", null).getString("KULLANICI_KOD"));
			
			kkBasvuru.put("UYE_NO", uyeNo);
			kkBasvuru.put("TFF_BASVURU_NO", basvuruNo);
			//GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU", kkBasvuru);
			GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU", kkBasvuru);
		} catch (Exception e) {
			GMMap durumMap = new GMMap();
			durumMap.put("BASVURU_NO", basvuruNo);
			durumMap.put("DURUM_KOD", "KK_YOK_JOB");
			durumMap.put("ISLEM_ACIKLAMA", "Toplu KK basvurudan otomatik ilerletme");
			durumMap.put("TARIHCE_AKSIYON", "E");
			GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
		}


		
/*		GMMap durumMap = new GMMap();
		String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
		try {
			String oto = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_TOPLU_BASVURU", BnsprType.STRING, "ODEME", BnsprType.STRING, "VERI_KONTROL"));
			if ("H".equals(oto)) {
				durumMap.put("BASVURU_NO", basvuruNo);
				durumMap.put("DURUM_KOD", "INTRA_JOB");
				durumMap.put("ISLEM_ACIKLAMA", "Toplu basvurudan otomatik ilerletme");
				durumMap.put("TARIHCE_AKSIYON", "E");
				GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
			}
		}
		catch (SQLException e) {
			logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " KK_TOPLU_BASVURU OK. NO:" + basvuruNo);
			e.printStackTrace();
		}
*/
		oMap.put("ERROR_CODE", "0");
		oMap.put("ERROR_DESC", "");
		return oMap;
	}
	@GraymoundService("BNSPR_TFF_BATCH_APPLICATION_INNER")
	public static GMMap createApplicationForBatchInner(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		GMMap kpsMap = new GMMap();

		GMMap globals = new GMMap();
		globals.put("KULLANICI_KOD", "TFF");
		CreditCardServicesUtil.setUserGlobals(globals);
		logger.info("KK_TOPLU_BASVURU| USER_NAME:" + ADCSession.getString("USER_NAME"));
		logger.info("KK_TOPLU_BASVURU| BRANCH_ID:" + ADCSession.getString("BRANCH_ID"));

		String tckn = iMap.getString("TCKN");
		// KPS yapiliyor.
		kpsMap.put("TCKN", tckn);
		kpsMap.put("TCK_NO", tckn);
		kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
		if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", kpsMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, kpsMap.getString("RESPONSE_DATA"));
		}
		iMap.putAll(kpsMap);
		String kimlikTipi = "N";
		String kimlikSeriNo = iMap.getString("KIMLIK_SERI_NO");
		String kimlikSiraNo = iMap.getString("KIMLIK_SIRA_NO");
		String nufusVerilisTarihi = iMap.getString("VERILIS_TARIHI");
		String adi = iMap.getString("AD1");
		String soyadi = iMap.getString("SOYAD");
		String ikinciAdi = iMap.getString("AD2");
		String annekizlikSoyadi = iMap.getString("ANNE_KIZLIK_SOYADI");
		String dogumTarihi = iMap.getString("DOGUM_TARIHI");
		String uyruk = iMap.getString("NATIONALITY");
		String pasaportNo = iMap.getString("PASSPORT_NO");

		String kartTipi = iMap.getString("KART_TIPI");
		String urun = iMap.getString("PRODUCT");
		String urunSahip = iMap.getString("PRODUCT_OWNER");
		String email = iMap.getString("EMAIL");
		String calismaSekli = iMap.getString("CALISMA_SEKLI");
		String otomatikLimitArtimi = iMap.getString("OTOMATIK_LIMIT_ARTIMI");
		String hesapKesimTarihi = iMap.getString("HESAP_KESIM_TARIHI");
		String yurtDisiEkstreTip = iMap.getString("YURT_DISI_EKSTRE_TIP");
		String kkOtomatikOdeme = iMap.getString("KART_OTOMATIK_ODEME");
		String kkEkstreSecim = iMap.getString("KREDI_KARTI_EKSTRE_SECIMI");
		String kkEkstreEmail = iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL");
		String kkEkstrePosta = iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA");
		String kkEkstreSms = iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS");
		String aylikGelir = iMap.getString("AYLIK_GELIR");

		String foto = iMap.getString("PHOTO_BYTE_ARRAY");
		String kuryeTipi = iMap.getString("COURIER_TYPE");
		String promosyonKodu = iMap.getString("PROMOSYON_KODU");
		String kartBedeli = iMap.getString("CARD_FEE");
		String kuryeBedeli = iMap.getString("COURIER_FEE");
		String sadakatBedeli = iMap.getString("LOYALTY_FEE");
		String vizeBedeli = iMap.getString("SUBSCRIPTION_FEE");
		String odemeTipi = iMap.getString("PAYMENT_TYPE");
		String odemeRefId = iMap.getString("PAYMENT_REF_ID");
		String kartNo = iMap.getString("CARD_NO");
		String source = iMap.getString("SOURCE");

		String isyeriAdi = iMap.getString("ISYERI_ADI");
		String isyeriVergiDairesi = iMap.getString("ISYERI_VERGI_DAIRESI_ADI");
		String isyeriVergiDairesiIl = iMap.getString("ISYERI_VERGI_DAIRESI_IL");

		// Vergi dairesi il bilgisi bulunuyor.
		if (("S".equals(calismaSekli) || "E2".equals(calismaSekli)) && StringUtils.isNotBlank(isyeriVergiDairesi)) {
			try {
				iMap.put("ISYERI_VERGI_DAIRESI_IL", DALUtil.getResult("select il_kod from gnl_vergi_daire_kod_pr where vergi_d_kod = " + isyeriVergiDairesi));
				isyeriVergiDairesiIl = iMap.getString("ISYERI_VERGI_DAIRESI_IL");
			}
			catch (Exception e) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", TffServicesMessages.VERGI_DAIRESI_IL_BILGISI_ALINAMADI);
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, TffServicesMessages.VERGI_DAIRESI_IL_BILGISI_ALINAMADI);
			}
		}

		String ogrenimDurumu = iMap.getString("OGRENIM_DURUMU");
		String oturmaYil = iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL");
		String oturmaAy = iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY");
		String isyerindeCalismaYil = iMap.getString("ISYERINDE_CALISMA_SURESI_YIL");
		String isyerindeCalismaAy = iMap.getString("ISYERINDE_CALISMA_SURESI_AY");
		String isyeriFaaliyet = iMap.getString("ISYERI_FAALIYET_ALANI");
		String unvan = iMap.getString("UNVANI");
		String meslek = iMap.getString("MESLEK");

		String destekHesapVarMi = iMap.getString("DESTEK_HESAP_VAR_MI");
		String destekEkstreSecim = iMap.getString("DESTEK_HESAP_EKSTRE_SECIMI");
		String destekEkstreEmail = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_EMAIL");
		String destekEkstrePosta = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_POSTA");
		String destekEkstreOtoLimitArtis = iMap.getString("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI");

		String cepUlkeKod = iMap.getString("CEP_ULKE_KOD");
		String cepTelKod = iMap.getString("CEP_TEL_KOD");
		String cepTelNo = iMap.getString("CEP_TEL_NO");

		String isUlkeKod = iMap.getString("IS_ULKE_KOD");
		String isTelKod = iMap.getString("IS_TEL_KOD");
		String isTelNo = iMap.getString("IS_TEL_NO");
		String isTelDahili = iMap.getString("IS_TEL_DAHILI");

		String evUlkeKod = iMap.getString("EV_ULKE_KOD");
		String evTelKod = iMap.getString("EV_TEL_KOD");
		String evTelNo = iMap.getString("EV_TEL_NO");

		String iletisimAdresTipi = iMap.getString("ILETISIM_ADRES_TIPI");
		String teslimatAdresTipi = iMap.getString("TESLIMAT_ADRES_TIPI");
		String teslimatNoktasiKodu = iMap.getString("DELIVERY_PCODE");

		String isIlKod = iMap.getString("IS_IL_KOD");
		String isIlAd = iMap.getString("IS_IL_AD");
		String isIlceKod = iMap.getString("IS_ILCE_KOD");
		String isIlceAd = iMap.getString("IS_ILCE_AD");
		String isIsMatched = "H";
		String isAcikAdres = iMap.getString("IS_ACIK_ADRES");
		String isAdresNo = "";

		String evIlKod = iMap.getString("EV_IL_KOD");
		String evIlAd = iMap.getString("EV_IL_AD");
		String evIlceKod = iMap.getString("EV_ILCE_KOD");
		String evIlceAd = iMap.getString("IS_ILCE_AD");
		String evAcikAdres = iMap.getString("EV_ACIK_ADRES");
		String evIsMatched = "H";
		String evAdresNo = "";

		// APS yapiliyor.
		if ("E".equals(teslimatAdresTipi) || "A".equals(calismaSekli) || "C".equals(calismaSekli) || "E".equals(calismaSekli) || "T".equals(calismaSekli) || "E".equals(kkEkstreSecim)) {
			if (StringUtils.isBlank(evAcikAdres) || StringUtils.isBlank(evIlKod) || StringUtils.isBlank(evIlceKod)) {
				GMMap adresMap = new GMMap();
				adresMap.put("TC_KIMLIK_NO", tckn);
				adresMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				adresMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", adresMap));
				if (adresMap.getString("APS_YAPILDIMI").equals("H")) {
					iMap.put("DURUM", new BigDecimal(2));
					iMap.put("ACIKLAMA", TffServicesMessages.APS_YAPILAMADI);
					GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
					throw new GMRuntimeException(0, TffServicesMessages.APS_YAPILAMADI);
				}
				// Acik adres formatlaniyor.
				adresMap.putAll(CreditCardServicesUtil.getApsAcikAdres(adresMap));
				evAcikAdres = adresMap.getString("ACIK_ADRES");
				iMap.put("EV_IL_KOD", adresMap.getString("IL_KODU"));
				evIlKod = adresMap.getString("IL_KODU");
				evIlAd = adresMap.getString("IL");
				evIlceKod = adresMap.getString("ILCE_KODU");
				evIlAd = adresMap.getString("ILCE");
			}
		}

		BigDecimal basvuruNo = null;
		BigDecimal uyeNo = null;

		// 1 CREATE MEMBER
		GMMap uyeMap = new GMMap();
		uyeMap.put("TCKN", tckn);
		uyeMap.put("PASAPORT_NO", pasaportNo);
		uyeMap.put("UYRUK", uyruk);

		uyeMap.putAll(findUye(uyeMap));
		uyeNo = uyeMap.getBigDecimal("UYE_NO");
		if (!uyeMap.containsKey("UYE_NO")) {

			uyeMap.put("UYRUK", uyruk);
			uyeMap.put("TCKN", tckn);
			uyeMap.put("TAKIM", urunSahip);
			uyeMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
			uyeMap.put("CALISMA_SEKLI", calismaSekli);
			uyeMap.put("ILETISIM_TEL_TIP", "C");
			uyeMap.put("CEP_ULKE_KOD", cepUlkeKod);
			uyeMap.put("CEP_ALAN_KOD", cepTelKod);
			uyeMap.put("CEP_NUMARA", cepTelNo);
			uyeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			uyeMap.put("WEB_ADI", adi);
			uyeMap.put("WEB_SOYADI", soyadi);
			uyeMap.put("WEB_IKINCI_ADI", ikinciAdi);
			uyeMap.put("WEB_DOGUM_TARIHI", dogumTarihi);
			uyeMap.put("EMAIL", email);
			uyeMap.put("SOURCE", source);

			uyeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_OR_UPDATE_MEMBER", uyeMap));
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(uyeMap.getString("RESPONSE"))) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", uyeMap.getString("RESPONSE_DATA"));
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, uyeMap.getString("RESPONSE_DATA"));
			}
			else {
				uyeNo = uyeMap.getBigDecimal("UYE_NO");
			}
		}
		oMap.put("UYE_NO", uyeNo);
		logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " UYE OK UYE_NO:" + uyeNo);
		// 1 CREATE MEMBER

		// 2 CREATE APPLICATION
		GMMap basvuruMap = new GMMap();
		String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
		basvuruMap.put("KANAL_KOD", kanalKodu);

		basvuruMap.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
		basvuruMap.put("UYE_NO", uyeMap.getString("UYE_NO"));
		basvuruMap.put("BASVURU_NO", basvuruNo);
		basvuruMap.put("TFF_BASVURU_NO", basvuruNo);
		basvuruMap.put("KART_TIPI", kartTipi);
		basvuruMap.put("URUN_KODU", urun);
		basvuruMap.put("URUN_SAHIP_KODU", urunSahip);

		basvuruMap.put("KIMLIK_SERI_NO", kimlikSeriNo);
		basvuruMap.put("KIMLIK_SIRA_NO", kimlikSiraNo);
		basvuruMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
		basvuruMap.put("EMAIL", email);
		basvuruMap.put("KREDI_KARTI_EKSTRE_SECIMI", kkEkstreSecim);
		basvuruMap.put("KREDI_KARTI_EKSTRE_TIPI_EMAIL", kkEkstreEmail);
		basvuruMap.put("KREDI_KARTI_EKSTRE_TIPI_POSTA", kkEkstrePosta);
		basvuruMap.put("KREDI_KARTI_EKSTRE_TIPI_SMS", kkEkstreSms);
		basvuruMap.put("CALISMA_SEKLI", calismaSekli);
		basvuruMap.put("AYLIK_GELIR", aylikGelir);
		basvuruMap.put("ISYERI_ADI", isyeriAdi);
		basvuruMap.put("HESAP_KESIM_TARIHI", hesapKesimTarihi);
		basvuruMap.put("KART_OTOMATIK_ODEME", kkOtomatikOdeme);
		basvuruMap.put("OTOMATIK_LIMIT_ARTIMI", otomatikLimitArtimi);
		basvuruMap.put("YURT_DISI_EKSTRE_TIP", yurtDisiEkstreTip);
		basvuruMap.put("OGRENIM_DURUMU", ogrenimDurumu);
		basvuruMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", oturmaYil);
		basvuruMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", oturmaAy);
		basvuruMap.put("ISYERINDE_CALISMA_SURESI_YIL", isyerindeCalismaYil);
		basvuruMap.put("ISYERINDE_CALISMA_SURESI_AY", isyerindeCalismaAy);
		basvuruMap.put("ISYERI_FAALIYET_ALANI", isyeriFaaliyet);
		basvuruMap.put("UNVANI", unvan);
		basvuruMap.put("MESLEK", meslek);
		basvuruMap.put("DESTEK_HESAP_VAR_MI", destekHesapVarMi);
		basvuruMap.put("DESTEK_HESAP_EKSTRE_SECIMI", destekEkstreSecim);
		basvuruMap.put("DESTEK_HESAP_EKSTRE_TIPI_EMAIL", destekEkstreEmail);
		basvuruMap.put("DESTEK_HESAP_EKSTRE_TIPI_POSTA", destekEkstrePosta);
		basvuruMap.put("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI", destekEkstreOtoLimitArtis);
		basvuruMap.put("ISYERI_VERGI_DAIRESI_ADI", isyeriVergiDairesi);
		basvuruMap.put("ISYERI_VERGI_DAIRESI_IL", isyeriVergiDairesiIl);

		basvuruMap.put("ILETISIM_TEL_TIP", "C");
		basvuruMap.put("CEP_ULKE_KOD", cepUlkeKod);
		basvuruMap.put("CEP_TEL_KOD", cepTelKod);
		basvuruMap.put("CEP_TEL_NO", cepTelNo);

		basvuruMap.put("IS_ULKE_KOD", isUlkeKod);
		basvuruMap.put("IS_TEL_KOD", isTelKod);
		basvuruMap.put("IS_TEL_NO", isTelNo);
		basvuruMap.put("IS_TEL_DAHILI", isTelDahili);

		basvuruMap.put("EV_ULKE_KOD", evUlkeKod);
		basvuruMap.put("EV_TEL_KOD", evTelKod);
		basvuruMap.put("EV_TEL_NO", evTelNo);

		basvuruMap.put("EV_IL_KOD", evIlKod);
		basvuruMap.put("EV_IL_AD", evIlAd);
		basvuruMap.put("EV_ILCE_KOD", evIlceKod);
		basvuruMap.put("EV_ILCE_AD", evIlceAd);
		basvuruMap.put("EV_IS_MATCHED", evIsMatched);
		basvuruMap.put("EV_ACIK_ADRES", evAcikAdres);

		basvuruMap.put("IS_IL_KOD", isIlKod);
		basvuruMap.put("IS_IL_AD", isIlAd);
		basvuruMap.put("IS_ILCE_KOD", isIlceKod);
		basvuruMap.put("IS_ILCE_AD", isIlceAd);
		basvuruMap.put("IS_IS_MATCHED", isIsMatched);
		basvuruMap.put("IS_ACIK_ADRES", isAcikAdres);

		basvuruMap.put("ILETISIM_ADRES_TIPI", iletisimAdresTipi);
		basvuruMap.put("TESLIMAT_ADRES_TIPI", teslimatAdresTipi);

		basvuruMap.put("EUPT_YARAT", "E");
		basvuruMap.put("SOURCE", source);
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));

		iMap.put("KURYE_TIPI", kuryeTipi);
		if (!isKuryeTipiValid(iMap)) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", "0155");
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, "0155");
		}

		if (("TN".equals(kuryeTipi) || "GN".equals(kuryeTipi)) && ("D".equals(kartTipi) || "KK".equals(kartTipi))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", "0155");
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, "0155");
		}

		tmpMap.clear();

		TffUyeler uye = findUye(uyruk, StringUtils.isBlank(tckn) ? null : new BigDecimal(tckn), pasaportNo);
		iMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
		iMap.put("UYE_NO", uye.getUyeNo());
		iMap.put("TCKN", tckn);
		iMap.put("KART_TIPI", kartTipi);
		iMap.put("URUN_KODU", urun);
		iMap.put("URUN_SAHIP_KODU", urunSahip);
		tmpMap.putAll(GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap));
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		tmpMap.clear();
		tmpMap.put("DIRECT_CALL", true);
		tmpMap.put("URUN_SAHIP_KODU", urunSahip);
		tmpMap.put("URUN_KODU", urun);
		tmpMap.put("UYE_NO", uyeNo);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", tmpMap);
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		else {
			int su = tmpMap.getSize("KART_UYGUNLUK");
			for (int i = 0; i < su; i++) {
				String ktip = tmpMap.getString("KART_UYGUNLUK", i, "KART_TIPI");
				String uygunluk = tmpMap.getString("KART_UYGUNLUK", i, "UYGUNLUK");
				if (kartTipi.equals(ktip) && "H".equals(uygunluk)) {
					tmpMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					if ("KK".equals(iMap.getString("KART_TIPI"))) {
						tmpMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
					}
					else if ("D".equals(iMap.getString("KART_TIPI"))) {
						tmpMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
					}
					else if ("P".equals(iMap.getString("KART_TIPI"))) {
						tmpMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
					}

					iMap.put("DURUM", new BigDecimal(2));
					iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
					GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
					throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
				}
			}
		}

		logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " BNSPR_TFF_KK_D_INPUT_KONTROLLERI");
		// Alan kontrolleri yapiliyor.
		tmpMap.putAll(GMServiceExecuter.call("BNSPR_TFF_KK_D_INPUT_KONTROLLERI", iMap));
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " VALIDATION OK");

		logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " BASVURU OLUSTURMAYA BASLA");
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", basvuruMap);
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		basvuruNo = tmpMap.getBigDecimal("TFF_BASVURU_NO");
		evAdresNo = tmpMap.getString("EV_ADRES_NO");
		isAdresNo = tmpMap.getString("IS_ADRES_NO");

		logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " BASVURU OK NO:" + basvuruNo);
		// 2 CREATE APPLICATION
		// 3 PHOTO

		tmpMap.clear();
		GMMap photoMap = new GMMap();
		photoMap.put("TFF_BASVURU_NO", basvuruNo);
		oMap.put("TFF_BASVURU_NO", basvuruNo);
		photoMap.put("SOURCE", source);
		photoMap.put("FOTO_BYTE_ARRAY", foto);

		tmpMap = GMServiceExecuter.call("BNSPR_TFF_FOTO_YUKLE", photoMap);
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}
		String teslimatAdresNo;
		if ("E".equals(teslimatAdresTipi)) {
			GMMap uyeAdres = new GMMap();
			uyeAdres.put("UYE_NO", uye.getUyeNo());
			uyeAdres.put("TFF_BASVURU_NO", basvuruNo);
			uyeAdres.put("ADRES_TIPI", "E");
			uyeAdres.put("ACIK_ADRES", iMap.getString("EV_ACIK_ADRES"));
			uyeAdres.put("IL_AD", iMap.getString("EV_IL_AD"));
			uyeAdres.put("IL_KOD", iMap.getString("EV_IL_KOD"));
			uyeAdres.put("ILCE_KOD", iMap.getString("EV_ILCE_KOD"));
			uyeAdres.put("ILCE_AD", iMap.getString("EV_ILCE_AD"));
			uyeAdres.put("ADRES_RUMUZ", "EV");
			uyeAdres.put("SOURCE", iMap.getString("SOURCE"));
			uyeAdres.put("TESLIMAT_ADRESI_MI", "E");
			uyeAdres.put("ILETISIM_MI", "E".equals(iMap.getString("ILETISIM_ADRES_TIPI")) ? "E" : "H");
			uyeAdres.put("TESLIMAT_NOKTASI_KODU", "");
			uyeAdres.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ADRES_EKLE", uyeAdres));
			if (!"2".equals(uyeAdres.getString("RESPONSE"))) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", uyeAdres.getString("RESPONSE_DATA"));
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, uyeAdres.getString("RESPONSE_DATA"));
			}
			evAdresNo = uyeAdres.getString("ADRES_NO");
			teslimatAdresNo = evAdresNo;

			logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " ADRES OK. NO:" + teslimatAdresNo);
		}
		else if ("I".equals(teslimatAdresTipi)) {
			GMMap uyeAdres = new GMMap();
			uyeAdres.put("UYE_NO", uye.getUyeNo());
			uyeAdres.put("TFF_BASVURU_NO", basvuruNo);
			uyeAdres.put("ADRES_TIPI", "I");
			uyeAdres.put("ACIK_ADRES", iMap.getString("IS_ACIK_ADRES"));
			uyeAdres.put("IL_AD", iMap.getString("IS_IL_AD"));
			uyeAdres.put("IL_KOD", iMap.getString("IS_IL_KOD"));
			uyeAdres.put("ILCE_KOD", iMap.getString("IS_ILCE_KOD"));
			uyeAdres.put("ILCE_AD", iMap.getString("IS_ILCE_AD"));
			uyeAdres.put("ADRES_RUMUZ", "IS");
			uyeAdres.put("SOURCE", iMap.getString("SOURCE"));
			uyeAdres.put("TESLIMAT_ADRESI_MI", "E");
			uyeAdres.put("ILETISIM_MI", "I".equals(iMap.getString("ILETISIM_ADRES_TIPI")) ? "E" : "H");
			uyeAdres.put("TESLIMAT_NOKTASI_KODU", "");
			uyeAdres.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ADRES_EKLE", uyeAdres));
			if (!"2".equals(uyeAdres.getString("RESPONSE"))) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", uyeAdres.getString("RESPONSE_DATA"));
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, uyeAdres.getString("RESPONSE_DATA"));
			}
			isAdresNo = uyeAdres.getString("ADRES_NO");
			teslimatAdresNo = isAdresNo;

			logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " ADRES OK. NO:" + teslimatAdresNo);
		}
		else {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
		}

		// 3 PHOTO
		// 4 PAYMENT
		GMMap odemeMap = new GMMap();
		boolean usePromosyon = false;
		if (StringUtils.isNotBlank(promosyonKodu)) {
			GMMap pMap = new GMMap();
			pMap.put("PROMOSYON_KODU", promosyonKodu);
			pMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_PROMOSYON_DETAY_SORGU", pMap));
			if (TffServicesMessages.RESPONSE_BASARISIZ.equals(pMap.getString("RESPONSE"))) {
				iMap.put("DURUM", new BigDecimal(2));
				iMap.put("ACIKLAMA", pMap.getString("RESPONSE_DATA"));
				GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
				throw new GMRuntimeException(0, pMap.getString("RESPONSE_DATA"));
			}
			else {
				usePromosyon = true;
				BigDecimal kb = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "KART_BEDELI");
				BigDecimal kub = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "KURYE_BEDELI");
				BigDecimal lb = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "LOYALTY_BEDELI");
				BigDecimal vb = pMap.getBigDecimal("PROMOSYON_DEGER", 0, "VIZE_BEDELI");

				odemeMap.put("PROMOSYON_KODU", promosyonKodu);

				BigDecimal kartBedeliNum = new BigDecimal(kartBedeli);
				BigDecimal kuryeBedeliNum = new BigDecimal(kuryeBedeli);
				BigDecimal sadakatBedeliNum = new BigDecimal(sadakatBedeli);
				BigDecimal vizeBedeliNum = new BigDecimal(vizeBedeli);

				odemeMap.put("KART_BEDELI", kartBedeliNum);
				odemeMap.put("KURYE_BEDELI", kuryeBedeliNum);
				odemeMap.put("LOYALTY_BEDELI", sadakatBedeliNum);
				odemeMap.put("VIZE_BEDELI", vizeBedeliNum);

				odemeMap.put("PROMOSYON_BEDELI", kb.add(kub).add(lb).add(vb));
			}
		}

		odemeMap.put("BASVURU_NO", basvuruNo);
		odemeMap.put("SOURCE", source);
		odemeMap.put("KURYE_TIPI", kuryeTipi);
		odemeMap.put("ODEME_TIPI", odemeTipi);
		odemeMap.put("ODEME_REF_ID", odemeRefId);
		odemeMap.put("TESLIMAT_ADRES_NO", teslimatAdresNo);
		if (!usePromosyon) {
			odemeMap.put("PROMOSYON_KODU", "");
			odemeMap.put("KART_BEDELI", kartBedeli);
			odemeMap.put("KURYE_BEDELI", kuryeBedeli);
			odemeMap.put("LOYALTY_BEDELI", sadakatBedeli);
			odemeMap.put("VIZE_BEDELI", vizeBedeli);
			odemeMap.put("PROMOSYON_BEDELI", 0);
		}

		tmpMap.clear();
		tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_ODEME_YAP", odemeMap);
		if (!"2".equals(tmpMap.getString("RESPONSE"))) {
			iMap.put("DURUM", new BigDecimal(2));
			iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
			GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);
			throw new GMRuntimeException(0, tmpMap.getString("RESPONSE_DATA"));
		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "");
		oMap.put("APPLICATION_NO", basvuruNo);
		iMap.put("DURUM", new BigDecimal(1));
		iMap.put("BASVURU_NO", basvuruNo);
		iMap.put("ACIKLAMA", tmpMap.getString("RESPONSE_DATA"));
		logger.info("KK_TOPLU_BASVURU| TCKN:" + tckn + " TOPLU_BASVURU OK. NO:" + basvuruNo);
		GMServiceExecuter.executeAsync("BNSPR_TFF_BATCH_UPDATE_STATUS", iMap);


		return oMap;

	}

}
