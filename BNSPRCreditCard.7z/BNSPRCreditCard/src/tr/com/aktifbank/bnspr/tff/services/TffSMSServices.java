package tr.com.aktifbank.bnspr.tff.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpHost;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.ProxyHost;
import org.apache.commons.httpclient.methods.MultipartPostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang.StringUtils;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruSmsLink;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TffSMSServices extends TffServicesHelper {
	private static final Logger logger = Logger.getLogger(TffSMSServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-tff.properties");
	/* EVAM event type */
	//private static final String EVENT_TYPE_NO = "17";

	/**
	 * 
	 * @param iMap
	 * @return RESPONSE, RESPONSE_DATA, BASVURU_NO
	 */
	@GraymoundService("BNSPR_TFF_SMS_APPLICATION_VALIDATION")
	public static GMMap createSmsApplicationValidation(GMMap iMap) {
		GMMap oMap = new GMMap();

		/* 1 CREATE MEMBER */
		/*
		String uyruk = iMap.getString("NATIONALITY");
		String pasaportNo = iMap.getString("PASSPORT_NO");
		String tckn = iMap.getString("TCKN");
		String kartTipi = iMap.getString("CARD_TYPE");
		String urun = iMap.getString("PRODUCT");
		String urunSahip = iMap.getString("PRODUCT_OWNER");
		String adi = iMap.getString("NAME");
		String soyadi = iMap.getString("SOYADI");
		String ikinciAdi = iMap.getString("MIDDLE_NAME");
		String annekizlikSoyadi = iMap.getString("MOTHER_MAIDEN_SURNAME");
		String birthDate = iMap.getString("BIRTHDATE");
		String email = iMap.getString("EMAIL");
		String foto = iMap.getString("PHOTO_BYTE_ARRAY");
		String kuryeTipi = iMap.getString("COURIER_TYPE");
		String kartBedeli = iMap.getString("CARD_FEE");
		String kuryeBedeli = iMap.getString("COURIER_FEE");
		String sadakatBedeli = iMap.getString("LOYALTY_FEE");
		String vizeBedeli = iMap.getString("SUBSCRIPTION_FEE");
		String paymentType = iMap.getString("PAYMENT_TYPE");
		String kartNo = iMap.getString("CARD_NO");
		String source = iMap.getString("SOURCE");

		String tip = iMap.getString("PHONE_TYPE");
		String ulkeKod = iMap.getString("PHONE_COUNTRY_CODE");
		String alanKod = iMap.getString("PHONE_AREA_CODE");
		String numara = iMap.getString("PHONE_NUMBER");
		 */
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.validation_instant_application(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[36];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("NATIONALITY");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASSPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CARD_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PRODUCT");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PRODUCT_OWNER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("NAME");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SURNAME");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BIRTHDATE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("EMAIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("COURIER_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PAYMENT_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CARD_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_COUNTRY_CODE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_AREA_CODE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_NUMBER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");

			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FIZIKI_BASVURU_ALAN_KONTROL_GENEL_HATA);
		}

		return oMap;

		/* 2 CREATE APPLICATION */
		/* 3 PAYMENT */

		/* 4 ACTIVATION */

	}

	/**
	 * 
	 * @param iMap
	 * BASVURU_NO
UYRUK
KIMLIK_TIPI
KIMLIK_SERI_NO
NUFUS_VER_TAR
PASAPORT_NO 
TCKN
KART_TIPI
URUN_KODU
URUN_SAHIP_KODU
WEB_ADI
WEB_SOYADI
WEB_IKINCI_ADI
ANNE_KIZLIK_SOYADI
DOGUM_TARIHI
EMAIL
CALISMA_SEKLI
KREDI_KARTI_EKSTRE_SECIMI
KREDI_KARTI_EKSTRE_TIPI_EMAIL
KREDI_KARTI_EKSTRE_TIPI_POSTA
KREDI_KARTI_EKSTRE_TIPI_SMS
AYLIK_GELIR
ISYERI_ADI
HESAP_KESIM_TARIHI
KART_OTOMATIK_ODEME
YURT_DISI_EKSTRE_TIP
OGRENIM_DURUMU
MEVCUT_ADRESTE_OTURMA_SURESI_YIL
MEVCUT_ADRESTE_OTURMA_SURESI_AY
ISYERINDE_CALISMA_SURESI_YIL
ISYERINDE_CALISMA_SURESI_AY
ISYERI_FAALIYET_ALANI
UNVANI
MESLEK
DESTEK_HESAP_VAR_MI
DESTEK_HESAP_EKSTRE_SECIMI
DESTEK_HESAP_EKSTRE_TIPI_EMAIL
DESTEK_HESAP_EKSTRE_TIPI_POSTA
DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI
ISYERI_VERGI_DAIRESI_ADI
ISYERI_VERGI_DAIRESI_IL
PHOTO_BYTE_ARRAY
KURYE_TIPI
KART_BEDELI
KURYE_BEDELI
LOYALTY_BEDELI
VIZE_BEDELI
ODEME_TIPI
ODEME_REF_ID
SOURCE
	 * @return RESPONSE, RESPONSE_DATA, BASVURU_NO
	 */
	@GraymoundService("BNSPR_TFF_SMS_BASVURU_YAP")
	public static GMMap smsBasvuruYap(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		BigDecimal basvuruNo	= iMap.getBigDecimal("BASVURU_NO");
		String uyruk 		= iMap.getString("UYRUK");
		//String kimlikTipi = iMap.getString("KIMLIK_TIPI");
		String kimlikSeriNo = iMap.getString("KIMLIK_SERI_NO");
		String kimlikSiraNo = iMap.getString("KIMLIK_SIRA_NO");
		//String nufusVerilisTarihi = iMap.getString("NUFUS_VER_TAR");
		String pasaportNo 	= iMap.getString("PASAPORT_NO"); 
		String tckn			= iMap.getString("TCKN");
		String kartTipi		= iMap.getString("KART_TIPI");
		String urun			= iMap.getString("URUN_KODU");
		String urunSahip	= iMap.getString("URUN_SAHIP_KODU");
		String takim		= iMap.getString("TAKIM");
		String adi			= iMap.getString("WEB_ADI");
		String soyadi		= iMap.getString("WEB_SOYADI");
		String ikinciAdi	= iMap.getString("WEB_IKINCI_ADI");
		String annekizlikSoyadi	= iMap.getString("ANNE_KIZLIK_SOYADI");
		String dogumTarihi	= iMap.getString("DOGUM_TARIHI");
		String email		= iMap.getString("EMAIL");
		String calismaSekli	= iMap.getString("CALISMA_SEKLI");
		String otomatikLimitArtimi = iMap.getString("OTOMATIK_LIMIT_ARTIMI");
		String hesapKesimTairihi = iMap.getString("HESAP_KESIM_TARIHI");
		String kkEkstreSecim = iMap.getString("KREDI_KARTI_EKSTRE_SECIMI");
		String kkEkstreEmail = iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL");
		String kkEkstrePosta = iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA");
		String kkEkstreSms = iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS");
		String kkOtomatikOdeme = iMap.getString("KART_OTOMATIK_ODEME");

		String aylikGelir = iMap.getString("AYLIK_GELIR");
		String isyeriAdi = iMap.getString("ISYERI_ADI");
		String isyeriVergiDairesi = iMap.getString("ISYERI_VERGI_DAIRESI_ADI");
		String isyeriVergiDairesiIl = iMap.getString("ISYERI_VERGI_DAIRESI_IL");


		String yurtDisiEkstreTip = iMap.getString("YURT_DISI_EKSTRE_TIP");
		String ogrenimDurumu = iMap.getString("OGRENIM_DURUMU");
		String oturmaYil = iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL");
		String oturmaAy = iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY");
		String isyerindeCalismaYil = iMap.getString("ISYERINDE_CALISMA_SURESI_YIL");
		//String isyerindeCalismaAy =iMap.getString("ISYERINDE_CALISMA_SURESI_AY");
		String isyeriFaaliyet = iMap.getString("ISYERI_FAALIYET_ALANI");
		String unvan = iMap.getString("UNVANI");
		String meslek = iMap.getString("MESLEK");

		String destekHesapVarMi = iMap.getString("DESTEK_HESAP_VAR_MI");
		String destekEkstreSecim = iMap.getString("DESTEK_HESAP_EKSTRE_SECIMI");
		String destekEkstreEmail = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_EMAIL");
		String destekEkstrePosta = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_POSTA");
		String destekEkstreOtoLimitArtis = iMap.getString("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI");
		String destekHesapKKOtoOdeme = iMap.getString("DESTEK_HESAP_KK_OTOMATIK_ODEME");
		String destekHesapBKOtoOdeme = iMap.getString("DESTEK_HESAP_BK_OTOMATIK_ODEME");
		String destekHesapSIGOtoOdeme = iMap.getString("DESTEK_HESAP_SIG_OTOMATIK_ODEME");
		String destekHesapOOTOtoOdeme = iMap.getString("DESTEK_HESAP_OOT_OTOMATIK_ODEME");
		String destekHesapDOTOtoOdeme = iMap.getString("DESTEK_HESAP_DOT_OTOMATIK_ODEME");
		
		/* basvuru telefon bilgileri*/
		String cepUlkeKod = iMap.getString("CEP_ULKE_KOD");
		String cepTelKod = iMap.getString("CEP_TEL_KOD");
		String cepTelNo = iMap.getString("CEP_TEL_NO");

		String isUlkeKod = iMap.getString("IS_ULKE_KOD");
		String isTelKod = iMap.getString("IS_TEL_KOD");
		String isTelNo = iMap.getString("IS_TEL_NO");
		String isTelDahili = iMap.getString("IS_TEL_DAHILI");

		String evUlkeKod = iMap.getString("EV_ULKE_KOD");
		String evTelKod = iMap.getString("EV_TEL_KOD");
		String evTelNo = iMap.getString("EV_TEL_NO");

		//String iletisimTelTipi = iMap.getString("ILETISIM_TELEFON_TIPI");
		/* basvuru adres bilgileri */

		String evIlKod = iMap.getString("EV_IL_KOD");
		String evIlAd = iMap.getString("EV_IL_AD");
		String evIlceKod = iMap.getString("EV_ILCE_KOD");
		String evIlceAd = iMap.getString("EV_ILCE_AD");
		String evIsMatched = iMap.getString("EV_IS_MATCHED","0");
		String evAcikAdres = iMap.getString("EV_ACIK_ADRES");
		String evAdresNo ="";

		String isIlKod = iMap.getString("IS_IL_KOD");
		String isIlAd = iMap.getString("IS_IL_AD");
		String isIlceKod = iMap.getString("IS_ILCE_KOD");
		//String isIlceAd = iMap.getString("IS_ILCE_AD");
		String isIsMatched = iMap.getString("IS_IS_MATCHED","0");
		String isAcikAdres = iMap.getString("IS_ACIK_ADRES");
		String isAdresNo ="";
		
		String digerIlKod = iMap.getString("DIGER_IL_KOD");
		String digerIlAd = iMap.getString("DIGER_IL_AD");
		String digerIlceKod = iMap.getString("DIGER_ILCE_KOD");
		String digerIlceAd = iMap.getString("DIGER_ILCE_AD");
		String digerIsMatched = iMap.getString("DIGER_IS_MATCHED","0");
		String digerAcikAdres = iMap.getString("DIGER_ACIK_ADRES");
		String digerAdresNo = StringUtils.EMPTY;
		
		String noktaIlKod = iMap.getString("NOKTA_IL_KOD");
		String noktaIlAd = iMap.getString("NOKTA_IL_AD");
		String noktaIsMatched = iMap.getString("NOKTA_IS_MATCHED","0");
		String noktaAcikAdres = iMap.getString("NOKTA_ACIK_ADRES");
		String noktaKodu = iMap.getString("NOKTA_KODU");
		String noktaAdresNo = StringUtils.EMPTY;

		String iletisimAdresTipi = iMap.getString("ILETISIM_ADRES_TIPI");
		String teslimatAdresTipi = iMap.getString("TESLIMAT_ADRES_TIPI");

		String kuryeTipi 	= iMap.getString("KURYE_TIPI");
		String kartBedeli	= iMap.getString("KART_BEDELI");
		String kuryeBedeli	= iMap.getString("KURYE_BEDELI");
		String sadakatBedeli= iMap.getString("LOYALTY_BEDELI");
		String vizeBedeli 	= iMap.getString("VIZE_BEDELI");
		//String odemeTipi 	= iMap.getString("ODEME_TIPI");
		String odemeRefId 	= iMap.getString("ODEME_REF_ID");
		String source	 	= iMap.getString("SOURCE");
		String promosyonKodu = iMap.getString("PROMOSYON_KODU");

		BigDecimal uyeNo = null;
		/*
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_SMS_APPLICATION_VALIDATION", iMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			return tmpMap;
		}
		 */
		if(StringUtils.isBlank(takim)){
			throw new GMRuntimeException(0,TffServicesMessages.TUTULAN_TAKIM_BOS_OLAMAZ);
		}
		/* 1 CREATE MEMBER  */
		GMMap uyeMap=new GMMap();
		uyeMap.put("TCKN", tckn);
		uyeMap.put("PASAPORT_NO", pasaportNo);
		uyeMap.put("UYRUK", uyruk);

		uyeMap.putAll(findUye(uyeMap));
		uyeNo = uyeMap.getBigDecimal("UYE_NO");

		uyeMap.put("UYRUK", uyruk);
		uyeMap.put("TCKN", tckn);
		uyeMap.put("TAKIM", StringUtils.isBlank(takim) ? urunSahip : takim);
		uyeMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
		uyeMap.put("CALISMA_SEKLI", calismaSekli);
		uyeMap.put("ILETISIM_TEL_TIP","C");
		uyeMap.put("CEP_ULKE_KOD", cepUlkeKod);
		uyeMap.put("CEP_ALAN_KOD", cepTelKod);
		uyeMap.put("CEP_NUMARA", cepTelNo);

		uyeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
		uyeMap.put("WEB_ADI", adi);
		uyeMap.put("WEB_SOYADI", soyadi);
		uyeMap.put("WEB_IKINCI_ADI", ikinciAdi);
		uyeMap.put("WEB_DOGUM_TARIHI",dogumTarihi );
		uyeMap.put("EMAIL", email);
		uyeMap.put("SOURCE", source);

		uyeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_OR_UPDATE_MEMBER", uyeMap));
		if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(uyeMap.getString("RESPONSE") )){
			throw new GMRuntimeException(0,uyeMap.getString("RESPONSE_DATA"));
		}else{
			uyeNo = uyeMap.getBigDecimal("UYE_NO");
		}

		/* 1 CREATE MEMBER  */


		/* 2 CREATE APPLICATION  */
		GMMap basvuruMap=new GMMap();
		String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
		basvuruMap.put("KANAL_KOD", kanalKodu);

		//		basvuruMap.put("ISYERI_ADI",iMap.getString("ISYERI_ADI"));
		basvuruMap.put("UYE_NO",uyeMap.getString("UYE_NO"));
		basvuruMap.put("BASVURU_NO",basvuruNo);
		basvuruMap.put("TFF_BASVURU_NO",basvuruNo);
		basvuruMap.put("KART_TIPI", kartTipi);
		basvuruMap.put("URUN_KODU", urun);
		basvuruMap.put("URUN_SAHIP_KODU", urunSahip);

		basvuruMap.put("KIMLIK_SERI_NO", kimlikSeriNo);
		basvuruMap.put("KIMLIK_SIRA_NO",kimlikSiraNo  );
		basvuruMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi );
		basvuruMap.put("EMAIL", email );
		basvuruMap.put("KREDI_KARTI_EKSTRE_SECIMI", kkEkstreSecim  );
		basvuruMap.put("KREDI_KARTI_EKSTRE_TIPI_EMAIL",kkEkstreEmail  );
		basvuruMap.put("KREDI_KARTI_EKSTRE_TIPI_POSTA",kkEkstrePosta  );
		basvuruMap.put("KREDI_KARTI_EKSTRE_TIPI_SMS", kkEkstreSms );
		basvuruMap.put("CALISMA_SEKLI", calismaSekli  );
		basvuruMap.put("AYLIK_GELIR", aylikGelir );
		basvuruMap.put("ISYERI_ADI", isyeriAdi );
		basvuruMap.put("HESAP_KESIM_TARIHI", hesapKesimTairihi );
		basvuruMap.put("KART_OTOMATIK_ODEME", kkOtomatikOdeme);
		basvuruMap.put("OTOMATIK_LIMIT_ARTIMI", otomatikLimitArtimi);
		basvuruMap.put("YURT_DISI_EKSTRE_TIP", yurtDisiEkstreTip );
		basvuruMap.put("OGRENIM_DURUMU", ogrenimDurumu );
		basvuruMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL",oturmaYil  );
		basvuruMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", oturmaAy );
		basvuruMap.put("ISYERINDE_CALISMA_SURESI_YIL", isyerindeCalismaYil );
		basvuruMap.put("ISYERINDE_CALISMA_SURESI_AY", isyerindeCalismaYil );
		basvuruMap.put("ISYERI_FAALIYET_ALANI", isyeriFaaliyet );
		basvuruMap.put("UNVANI", unvan );
		basvuruMap.put("MESLEK", meslek );
		basvuruMap.put("DESTEK_HESAP_VAR_MI", destekHesapVarMi );
		basvuruMap.put("DESTEK_HESAP_EKSTRE_SECIMI", destekEkstreSecim );
		basvuruMap.put("DESTEK_HESAP_EKSTRE_TIPI_EMAIL", destekEkstreEmail );
		basvuruMap.put("DESTEK_HESAP_EKSTRE_TIPI_POSTA", destekEkstrePosta );
		basvuruMap.put("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI", destekEkstreOtoLimitArtis );
		basvuruMap.put("ISYERI_VERGI_DAIRESI_ADI", isyeriVergiDairesi );
		basvuruMap.put("ISYERI_VERGI_DAIRESI_IL", isyeriVergiDairesiIl );
		basvuruMap.put("CEP_ULKE_KOD", cepUlkeKod);
		basvuruMap.put("CEP_TEL_KOD", cepTelKod );
		basvuruMap.put("CEP_TEL_NO", cepTelNo );
		basvuruMap.put("IS_ULKE_KOD", isUlkeKod );
		basvuruMap.put("IS_TEL_KOD",isTelKod  );
		basvuruMap.put("IS_TEL_NO",  isTelNo);
		basvuruMap.put("IS_TEL_DAHILI", isTelDahili );

		basvuruMap.put("EV_ULKE_KOD", evUlkeKod );
		basvuruMap.put("EV_TEL_KOD",evTelKod  );
		basvuruMap.put("EV_TEL_NO", evTelNo );
		basvuruMap.put("EV_IL_KOD", evIlKod );
		basvuruMap.put("EV_IL_AD",  evIlAd);

		basvuruMap.put("EV_ILCE_KOD", evIlceKod );
		basvuruMap.put("EV_ILCE_AD",evIlceAd  );
		basvuruMap.put("EV_IS_MATCHED", evIsMatched );
		basvuruMap.put("EV_ACIK_ADRES", evAcikAdres );

		basvuruMap.put("IS_IL_KOD",isIlKod  );
		basvuruMap.put("IS_IL_AD", isIlAd );
		basvuruMap.put("IS_ILCE_KOD",isIlceKod );
		basvuruMap.put("IS_ILCE_AD", isIlAd );
		basvuruMap.put("IS_IS_MATCHED", isIsMatched );
		basvuruMap.put("IS_ACIK_ADRES",isAcikAdres  );
		basvuruMap.put("ILETISIM_ADRES_TIPI",iletisimAdresTipi  );
		basvuruMap.put("TESLIMAT_ADRES_TIPI", teslimatAdresTipi );

		basvuruMap.put("EUPT_YARAT", "E");
		basvuruMap.put("SOURCE", source);
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));

		iMap.put("KURYE_TIPI", kuryeTipi);
		if(!isKuryeTipiValid(iMap)){
			throw new GMRuntimeException(0,"0155");
		}
		basvuruMap.put("KURYE_TIPI", kuryeTipi);
		basvuruMap.put("ILETISIM_TEL_TIP", "C");


		basvuruMap.put("EV_ULKE_KOD", evUlkeKod);
		basvuruMap.put("EV_TEL_KOD",evTelKod);
		basvuruMap.put("EV_TEL_NO", evTelNo);

		basvuruMap.put("IS_ULKE_KOD", isUlkeKod);
		basvuruMap.put("IS_TEL_KOD", isTelKod);
		basvuruMap.put("IS_TEL_NO", isTelNo);


		basvuruMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
		if( ("D".equals(kartTipi) || "KK".equals(kartTipi)) && ("TN".equals(kuryeTipi) || "GN".equals(kuryeTipi))){
			throw new GMRuntimeException(0,TffServicesMessages.GECERSIZ_KURYE_TIPI);
		}
		tmpMap.clear();

		TffBasvuru tffbasvuru = (TffBasvuru) session.get(TffBasvuru.class,basvuruNo);
		if(tffbasvuru != null && !"SMS".equals(tffbasvuru.getSource())){
			throw new GMRuntimeException(0,TffServicesMessages.SMS_BASVURU_GUNCELLENEMEZ);
		}
		if(tffbasvuru == null){// guncelleme durumunda bu kontrolleri gececek
			TffUyeler uye = findUye(uyruk, StringUtils.isBlank(tckn) ? null : new BigDecimal(tckn), pasaportNo);
			iMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
			iMap.put("TCKN", tckn);
			tmpMap = GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap);
			if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE")) ){
				throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
			}
			tmpMap.clear();
			tmpMap.put("DIRECT_CALL", true);
			tmpMap.put("URUN_SAHIP_KODU", urunSahip);
			tmpMap.put("URUN_KODU", urun);
			tmpMap.put("UYE_NO", uyeNo);
			tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", tmpMap);
			if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE")) ){
				throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
			}else{
				int su = tmpMap.getSize("KART_UYGUNLUK");
				for (int i =0 ; i < su; i++){
					String ktip = tmpMap.getString("KART_UYGUNLUK", i,"KART_TIPI");
					String uygunluk = tmpMap.getString("KART_UYGUNLUK", i,"UYGUNLUK");
					if(ktip.equals(kartTipi) && ("H".equals(uygunluk) || "U".equals(uygunluk))){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						if("KK".equals(iMap.getString("KART_TIPI"))){
							oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
						}else if("D".equals(iMap.getString("KART_TIPI"))){
							oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
						}else if("P".equals(iMap.getString("KART_TIPI"))){
							oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
						}
						throw new GMRuntimeException(0, oMap.getString("RESPONSE_DATA"));
					}
				}

			}
		}
		
		if (!"P".equals(iMap.getString("KART_TIPI"))){
			GMMap kontrolMap = GMServiceExecuter.call("BNSPR_TFF_KK_D_INPUT_KONTROLLERI", basvuruMap);
			if(!"2".equals(kontrolMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0,kontrolMap.getString("RESPONSE_DATA"));
			}
		} else {
			//Teslimat adres kontrol
			if (StringUtils.isBlank(noktaKodu) && ("TN".equals(teslimatAdresTipi) || "GN".equals(teslimatAdresTipi))) {
				throw new GMRuntimeException(0, TffServicesMessages.BASVURU_OLUSTUR_TESLIMAT_ADRESI_BULUNAMADI_HATASI);
			}
			
			if (StringUtils.isBlank(digerIlKod) && "D".equals(teslimatAdresTipi)) {
				throw new GMRuntimeException(0, TffServicesMessages.BASVURU_OLUSTUR_TESLIMAT_ADRESI_BULUNAMADI_HATASI);
			}
		}

		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", basvuruMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}
		basvuruNo = tmpMap.getBigDecimal("TFF_BASVURU_NO");
		evAdresNo = tmpMap.getString("EV_ADRES_NO");
		isAdresNo = tmpMap.getString("IS_ADRES_NO");


		/* Nokta veya Diger adres ekle*/
		GMMap adresMap = new GMMap();
		if (StringUtils.isNotBlank(digerIlKod)) {
			adresMap.clear();
			adresMap.put("UYE_NO", uyeNo);
			adresMap.put("TFF_BASVURU_NO", basvuruNo);
			adresMap.put("ADRES_TIPI", "D");
			adresMap.put("IL_KOD", digerIlKod);
			adresMap.put("IL_AD",  digerIlAd);
			adresMap.put("ILCE_KOD", digerIlceKod);
			adresMap.put("ILCE_AD",  digerIlceAd);
			adresMap.put("ACIK_ADRES",  digerAcikAdres);
			adresMap.put("IS_MATCHED",  digerIsMatched);
			adresMap.put("TESLIMAT_ADRESI_MI",  "D".equals(teslimatAdresTipi) == true ? "E" : "H");
			adresMap.put("ILETISIM_MI",  "H");
			adresMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS", adresMap));
			//Kontrol
			if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(adresMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0, adresMap.getString("RESPONSE_DATA"));
			}
			digerAdresNo = adresMap.getString("ADRES_NO");
		}
		
		if (StringUtils.isNotBlank(noktaIlKod) && ("TN".equals(teslimatAdresTipi) || "GN".equals(teslimatAdresTipi))) {
			adresMap.clear();
			adresMap.put("UYE_NO", uyeNo);
			adresMap.put("TFF_BASVURU_NO", basvuruNo);
			adresMap.put("ADRES_TIPI", teslimatAdresTipi);
			adresMap.put("IL_KOD", noktaIlKod);
			adresMap.put("IL_AD",  noktaIlAd);
			adresMap.put("ACIK_ADRES",  noktaAcikAdres);
			adresMap.put("IS_MATCHED",  noktaIsMatched);
			adresMap.put("TESLIMAT_ADRESI_MI", "E");
			adresMap.put("ILETISIM_MI",  "H");
			adresMap.put("TESLIMAT_NOKTASI_KODU", noktaKodu);
			adresMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS", adresMap));
			//Kontrol
			if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(adresMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0, adresMap.getString("RESPONSE_DATA"));
			}
			noktaAdresNo = adresMap.getString("ADRES_NO");
		}

		
		/*kdh basvuru bilgileri tamamla*/
		if (CreditCardServicesUtil.EVET.equals(destekHesapVarMi)) {
			GMMap kdhMap = new GMMap();
			kdhMap.put("TFF_BASVURU_NO", basvuruNo);
			kdhMap.put("TRX_NO", basvuruNo);
			kdhMap.put("AYLIK_GELIR", aylikGelir);
			kdhMap.put("DESTEK_HESAP_EKSTRE_SECIMI", destekEkstreSecim);
			kdhMap.put("DESTEK_HESAP_EKSTRE_TIPI_EMAIL", destekEkstreEmail);
			kdhMap.put("DESTEK_HESAP_EKSTRE_TIPI_POSTA", destekEkstrePosta);
			kdhMap.put("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI", destekEkstreOtoLimitArtis);
			kdhMap.put("DESTEK_HESAP_KK_OTOMATIK_ODEME", destekHesapKKOtoOdeme);
			kdhMap.put("DESTEK_HESAP_BK_OTOMATIK_ODEME", destekHesapBKOtoOdeme);
			kdhMap.put("DESTEK_HESAP_SIG_OTOMATIK_ODEME", destekHesapSIGOtoOdeme);
			kdhMap.put("DESTEK_HESAP_OOT_OTOMATIK_ODEME", destekHesapOOTOtoOdeme);
			kdhMap.put("DESTEK_HESAP_DOT_OTOMATIK_ODEME", destekHesapDOTOtoOdeme);
			kdhMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_KDH", kdhMap));
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(kdhMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0, kdhMap.getString("RESPONSE_DATA"));
			}
		}

		/* 3 PHOTO  */
		//Basvuru bilgileri basarili olusturuldu ise onayli fotosunu alip 
		//basvuru uzerine fotografi yukle
		try {
			GMMap fotoMap = new GMMap();
			fotoMap.put("TFF_BASVURU_NO", basvuruNo);
			fotoMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_FOTO_YUKLE_FROM_APPROVED_FOTO", fotoMap));
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(fotoMap.getString("RESPONSE"))){
				logger.info("-- SMS FOTO YUKLE HATA OLUSTU -- " + fotoMap.getString("RESPONSE_DATA"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("-- SMS FOTO YUKLE HATA OLUSTU -- " + e.getMessage());
		}
		logger.info("-- SMS FOTO YUKLE BASARILI -- ");
		
		
		tmpMap.clear();

		/*		
		GMMap photoMap = new GMMap();
		photoMap.put("TFF_BASVURU_NO", basvuruNo);
		photoMap.put("SOURCE", source);
		photoMap.put("FOTO_BYTE_ARRAY", foto);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_FOTO_YUKLE", photoMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}
		 */
		/* 4 Nakit �deme default payment   */
		GMMap odemeMap = new GMMap();
		odemeMap.put("BASVURU_NO", basvuruNo);
		odemeMap.put("KURYE_TIPI", kuryeTipi);
		odemeMap.put("ODEME_TIPI", "D");
		if("E".equals(teslimatAdresTipi)){
			odemeMap.put("TESLIMAT_ADRES_NO", evAdresNo);
		}else if("I".equals(teslimatAdresTipi)){
			odemeMap.put("TESLIMAT_ADRES_NO", isAdresNo);
		}
		odemeMap.put("PROMOSYON_KODU", promosyonKodu);
		odemeMap.put("ODEME_REF_ID", odemeRefId);
		odemeMap.put("KART_BEDELI", kartBedeli);
		odemeMap.put("KURYE_BEDELI", kuryeBedeli);
		odemeMap.put("LOYALTY_BEDELI", sadakatBedeli);
		odemeMap.put("VIZE_BEDELI", vizeBedeli);
		odemeMap.put("PROMOSYON_BEDELI", 0);
		tmpMap.clear();
		tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_ODEME_YAP", odemeMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}


		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "");
		oMap.put("TFF_BASVURU_NO", basvuruNo);
		oMap.put("EV_ADRES_NO", evAdresNo);
		oMap.put("IS_ADRES_NO", isAdresNo);
		oMap.put("DIGER_ADRES_NO", digerAdresNo);
		oMap.put("NOKTA_ADRES_NO", noktaAdresNo);
		oMap.put("ODEME_TX_NO", tmpMap.getString("ISLEM_NO"));
		tmpMap.clear();

		GMMap trxMap = new GMMap();
		if(StringUtils.isBlank(iMap.getString("TRX_NO"))){

			trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
			iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
		}



		TffBasvuruSmsLink smsLink = new TffBasvuruSmsLink();
		smsLink.setId(trxMap.getBigDecimal("TRX_NO"));
		smsLink.setBasvuruNo(basvuruNo);
		smsLink.setTckn(new BigDecimal(tckn));
		smsLink.setCepTel(cepUlkeKod+cepTelKod+cepTelNo);
		smsLink.setCode(UUID.randomUUID().toString().replace("-", ""));
		session.save(smsLink);
		return oMap;
	}
	@GraymoundService("BNSPR_SMS_TEST")
	public static GMMap testSMSBasvuru(GMMap iMap){

		iMap.put("BASVURU_NO","");
		iMap.put("UYRUK","TR");
		iMap.put("KIMLIK_TIPI","");
		iMap.put("KIMLIK_SERI_NO","D11");
		iMap.put("KIMLIK_SIRA_NO","050128");
		iMap.put("NUFUS_VER_TAR","");
		iMap.put("PASAPORT_NO",""); 
		iMap.put("TCKN","54817638260");
		iMap.put("KART_TIPI","KK");
		iMap.put("URUN_KODU","TFFSTD");
		iMap.put("URUN_SAHIP_KODU","TFF13");
		iMap.put("WEB_ADI","");
		iMap.put("WEB_SOYADI","");
		iMap.put("WEB_IKINCI_ADI","");
		iMap.put("ANNE_KIZLIK_SOYADI","AKS");
		iMap.put("DOGUM_TARIHI","19840101");
		iMap.put("EMAIL","IOZEREN@GMAIL.COM");
		iMap.put("CALISMA_SEKLI","O");

		iMap.put("HESAP_KESIM_TARIHI","26");
		iMap.put("KREDI_KARTI_EKSTRE_SECIMI","H");
		iMap.put("KREDI_KARTI_EKSTRE_TIPI_EMAIL","E");
		iMap.put("KREDI_KARTI_EKSTRE_TIPI_POSTA","H");
		iMap.put("KREDI_KARTI_EKSTRE_TIPI_SMS","H");
		iMap.put("KART_OTOMATIK_ODEME","E");

		iMap.put("AYLIK_GELIR","5555");
		iMap.put("ISYERI_ADI","AKT�FBANK");
		iMap.put("ISYERI_VERGI_DAIRESI_ADI","");
		iMap.put("ISYERI_VERGI_DAIRESI_IL","");


		iMap.put("YURT_DISI_EKSTRE_TIP","H");
		iMap.put("OGRENIM_DURUMU","L");
		iMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL","");
		iMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY","");
		iMap.put("ISYERINDE_CALISMA_SURESI_YIL","");
		iMap.put("ISYERINDE_CALISMA_SURESI_AY","");
		iMap.put("ISYERI_FAALIYET_ALANI","");
		iMap.put("UNVANI","");
		iMap.put("MESLEK","26");

		iMap.put("DESTEK_HESAP_VAR_MI","H");
		iMap.put("DESTEK_HESAP_EKSTRE_SECIMI","H");
		iMap.put("DESTEK_HESAP_EKSTRE_TIPI_EMAIL","H");
		iMap.put("DESTEK_HESAP_EKSTRE_TIPI_POSTA","H");
		iMap.put("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI","H");

		iMap.put("CEP_ULKE_KOD","90");
		iMap.put("CEP_TEL_KOD","532");
		iMap.put("CEP_TEL_NO","7607530");

		iMap.put("IS_ULKE_KOD","90");
		iMap.put("IS_TEL_KOD","380");
		iMap.put("IS_TEL_NO","3408518");
		iMap.put("IS_TEL_DAHILI","");

		iMap.put("EV_ULKE_KOD","90");
		iMap.put("EV_TEL_KOD","380");
		iMap.put("EV_TEL_NO","3408518");

		iMap.put("ILETISIM_TELEFON_TIPI","C");

		iMap.put("EV_IL_KOD","081");
		iMap.put("EV_IL_AD","D�ZCE");
		iMap.put("EV_ILCE_KOD","1116");
		iMap.put("EV_ILCE_AD","AK�AKOCA");
		iMap.put("EV_IS_MATCHED","H");
		iMap.put("EV_ACIK_ADRES","Ayazl� mah. �mitkent sit. B2 No3");


		iMap.put("IS_IL_KOD","081");
		iMap.put("IS_IL_AD","D�ZCE");
		iMap.put("IS_ILCE_KOD","1116");
		iMap.put("IS_ILCE_AD","AK�AKOCA");
		iMap.put("IS_IS_MATCHED","H");
		iMap.put("IS_ACIK_ADRES","AYAZLI MAH. �MRAN CAD. NO.9 �MRAN �EL�K BORU");

		iMap.put("ILETISIM_ADRES_TIPI","I");
		iMap.put("TESLIMAT_ADRES_TIPI","I");

		iMap.put("KURYE_TIPI","S");
		iMap.put("KART_BEDELI","15");
		iMap.put("KURYE_BEDELI","5.5");
		iMap.put("LOYALTY_BEDELI","10");
		iMap.put("VIZE_BEDELI","0");
		iMap.put("ODEME_TIPI","D");
		iMap.put("ODEME_REF_ID","IVRODEME-REF");
		iMap.put("SOURCE","SMS");
		iMap.put("PROMOSYON_KODU","");



		GMMap tmpMap = GMServiceExecuter.call("BNSPR_TFF_SMS_BASVURU_YAP", iMap);
		System.out.println(tmpMap.toString());
		return tmpMap;
	}
	@GraymoundService("BNSPR_TFF_COMMON_GET_SMS_BASVURU_KOD")
	public static GMMap getSMSBasvuruKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		try {
			if(StringUtils.isBlank(iMap.getString("TCKN"))){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_KIMLIK_BILGISI_HATASI);
				return oMap;
			}
			if(StringUtils.isBlank(iMap.getString("CODE"))){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.SMS_FOTO_YUKLE_KOD_BULUNAMADI);
				return oMap;
			}

			TffBasvuruSmsLink tffBasvuruSmsLink = (TffBasvuruSmsLink) session.createCriteria(TffBasvuruSmsLink.class).add(Restrictions.eq("code",iMap.getString("CODE"))).add(Restrictions.eq("tckn",iMap.getBigDecimal("TCKN"))).uniqueResult();
			TffBasvuru tffbasvuru = (TffBasvuru) session.get(TffBasvuru.class, tffBasvuruSmsLink.getBasvuruNo());
			oMap.put("TCKN", tffBasvuruSmsLink.getTckn());
			oMap.put("CODE",tffBasvuruSmsLink.getCode());
			oMap.put("CEP_TEL",tffBasvuruSmsLink.getCepTel());
			oMap.put("BASVURU_NO",tffBasvuruSmsLink.getBasvuruNo());
			oMap.put("UYE_NO",tffbasvuru.getTffUyeNo());
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.SMS_FOTO_YUKLE_KOD_BULUNAMADI);
		}
		return oMap;
	}

	/**
	 * CODE
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_COMMON_GET_LINK")
	public static GMMap getLink(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		try {
			if(!StringUtils.isBlank(iMap.getString("BASVURU_NO"))){
				TffBasvuruSmsLink tffBasvuruSmsLink = (TffBasvuruSmsLink) session.createCriteria(TffBasvuruSmsLink.class).add(Restrictions.eq("basvuruNo",iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id")).list().get(0);
				if(tffBasvuruSmsLink == null){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.SMS_FOTO_YUKLE_KOD_BULUNAMADI);
					return oMap;
				}
				iMap.put("CODE", tffBasvuruSmsLink.getCode());
			}else{
				if(StringUtils.isBlank(iMap.getString("CODE"))){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.SMS_FOTO_YUKLE_KOD_BULUNAMADI);
					return oMap;
				}
			}
			String endpoint = conf.getProperty("short-url-endpoint");
			String authkey = conf.getProperty("short-url-authkey");
			String targetUrl = conf.getProperty("short-url-target");

			String code = iMap.getString("CODE");
			String link = targetUrl+code;
			oMap.put("FULL_LINK", link);
			HttpClient client = new HttpClient();
			if(TffCommonServices.isLocal()){
				ProxyHost ph = new ProxyHost("wcg.aktifbank.com.tr", 8080);
				client.getHostConfiguration().setProxyHost(ph);
				client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, new HttpHost("wcg.aktifbank.com.tr", 8080));
				client.setTimeout(3000);
			}
			MultipartPostMethod method = new MultipartPostMethod(endpoint);
			method.setRequestHeader("Content-Type", "multipart/form-data"); 
			method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, 
					new DefaultHttpMethodRetryHandler(3, false));

			method.addParameter("authkey", authkey);
			method.addParameter("url", link);

			logger.info("---SMS SHORTER CODE-- : "+ code);
			//  method.setRequestEntity(new StringRequestEntity(req.toString(),"application/json","UTF-8"));
			try {
				int statusCode = client.executeMethod(method);

				if (statusCode != HttpStatus.SC_OK) {
					System.err.println("Method failed: " + method.getStatusLine());
				}

				byte[] responseBody = method.getResponseBody();
				JSONObject json = (JSONObject) JSONSerializer.toJSON(new String(responseBody,"UTF-8"));
				if(json != null){
					String status = json.getString("status");
					if("200".equals(status)){
						String msg = json.getString("msg");
						logger.info("---SMS SHORTER LINK RESPONSE-- : "+ msg);
						if(msg != null){
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
							oMap.put("LINK", msg.toString());
							return oMap;

						}
					}
				}




			} catch (HttpException e) {
				logger.info("---HttpException-- : "+ e.getMessage());
				e.printStackTrace();
			} catch (IOException e) {
				logger.info("---IOException-- : "+ e.getMessage());
				e.printStackTrace();
			} finally {
				method.releaseConnection();
			}  



		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.SMS_FOTO_YUKLE_KOD_BULUNAMADI);
		}
		return oMap;
	}
}
