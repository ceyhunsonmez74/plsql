package tr.com.aktifbank.bnspr.tff.services.test;

import java.math.BigDecimal;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TffServicesTest {

}
