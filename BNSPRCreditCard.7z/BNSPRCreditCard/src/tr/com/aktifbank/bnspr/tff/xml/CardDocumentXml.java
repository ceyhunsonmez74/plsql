package tr.com.aktifbank.bnspr.tff.xml;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkBasvuruKimlik;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class CardDocumentXml {

	
	
	
	@GraymoundService("BNSPR_TFF_BASVURU_MUSTERI_BILGI_XML")
	public static GMMap getTffBasvuruMusteriBilgiXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KART_DOKUMAN_XML.basvuruMusteriBilgi(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_KK_YIM_BASVURU_MUSTERI_BILGI_XML")
	public static GMMap getKkBasvuruMusteriBilgiXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KART_DOKUMAN_XML.basvuruMusteriBilgiYim(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	

	@GraymoundService("BNSPR_KK_UPT_BASVURU_MUSTERI_BILGI_XML")
	public static GMMap getKkBasvuruMusteriBilgiXmlUpt(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
        Session session = DAOSession.getSession("BNSPRDal");

		try {

            KkBasvuruKimlik kkBasvuruKimlik = (KkBasvuruKimlik) session.createCriteria(KkBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

            if (kkBasvuruKimlik!=null){
				conn = DALUtil.getGMConnection();
            	if("TR".equals(kkBasvuruKimlik.getUyrukKod())){
            		stmt = conn.prepareCall("{? = call PKG_KART_DOKUMAN_XML.basvuruMusteriBilgiUpt(?)}");
            	}
            	else{
            		stmt = conn.prepareCall("{? = call PKG_KART_DOKUMAN_XML.basvuruMusteriBilgiUptIng(?)}");
            	}

				stmt.registerOutParameter(1, Types.CLOB);
				stmt.setLong(2, iMap.getLong("BASVURU_NO"));
				
				stmt.execute();
				
				Clob clob=stmt.getClob(1);
				if(clob!=null){
					oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
				}
            }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_KK_BASVURU_MUSTERI_BILGI_XML")
	public static GMMap getKkDigerBasvuruMusteriBilgiXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KART_DOKUMAN_XML.basvuruMusteriBilgiDigerKK(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
}
