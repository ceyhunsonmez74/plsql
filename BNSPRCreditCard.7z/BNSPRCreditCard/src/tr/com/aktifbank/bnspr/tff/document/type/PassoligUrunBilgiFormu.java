package tr.com.aktifbank.bnspr.tff.document.type;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PassoligUrunBilgiFormu extends CardDocument{
	public PassoligUrunBilgiFormu() {
		super("passoligUrunBilgiFormu", "passoligUrunBilgiFormu", Enums.CardDocTypes.PASSOLIG_URUN_BILGI_FORMU.getCode());
	}

	@Override
	public String generateXml(String applicationNo) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<DOCUMENT_INFO>");
		builder.append(GMServiceExecuter.call("BNSPR_TFF_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		
		builder.append("</DOCUMENT_INFO>");

		return builder.toString();
	}

}
