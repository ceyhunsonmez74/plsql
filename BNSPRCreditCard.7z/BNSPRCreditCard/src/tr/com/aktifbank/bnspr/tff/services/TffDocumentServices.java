package tr.com.aktifbank.bnspr.tff.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardTffServices;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.tff.document.type.CardDocument;
import tr.com.aktifbank.bnspr.tff.document.type.DocumentCreator;
import tr.com.aktifbank.bnspr.tff.document.type.Enums.CardDocTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TffDocumentServices {
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";

	@GraymoundService("BNSPR_TFF_GET_DOCUMENT_TEMPLATES")
	public static GMMap getTffDocumentTemplates(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			iMap.putAll(CreditCardServicesUtil.getParameterListByKey("DOKUMAN_LIST", "TFF_BASVURU_ALINAN_BELGE", iMap.getString("SOURCE"), null, null, null));
			
		
			
			if(iMap.get("DOKUMAN_LIST") != null && iMap.getSize("DOKUMAN_LIST") > 0){
				int j = 0 ;
				for(int i = 0 ; i< iMap.getSize("DOKUMAN_LIST") ; i ++){
					int code = iMap.getInt("DOKUMAN_LIST", i, "NAME");
					
					CardDocument cardDocument = DocumentCreator.createCardDocument(code);
					if(cardDocument == null){
						continue;
					}
					oMap.put("DOC_LIST", j, "CODE", code);
					iMap.put("FOLDER_NAME", cardDocument.getFolderName());
					iMap.put("TEMPLATE_NAME", cardDocument.getTemplateName());
					oMap.put("DOC_LIST", j, "NAME", getDocumentName(code));
					oMap.put("DOC_LIST", j, "TEMPLATE", GMServiceExecuter.call("BNSPR_GET_DOCUMENT_TEMPLATE", iMap).get("XSL"));
					j++;
				}
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_CARD_DOCUMENT_DATA")
	public static GMMap getTffCardDocumentData(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartTipi = "";
		int j = 0 ;
		try {
   
			 // inputta doc list varsa sadece onlari don yok ise basvuru numarasina g�re kart tipi dokumanlarini don , mobil ba�vuru tarafi etkilenmesin diye boyle yapildi.
			
	   if(iMap.get("TABLE") != null ){
		   for (int i = 0; i < iMap.getSize("TABLE"); i++) {
				int dokumanKod = iMap.getInt("TABLE" , i , "DOCUMENT_CODE");
				CardDocument cardDocument = DocumentCreator.createCardDocument(dokumanKod);
				if(cardDocument == null){
					continue;
				}
				oMap.put("DOC_LIST", j, "CODE", dokumanKod);	
				oMap.put("DOC_LIST", j, "NAME", getDocumentName(dokumanKod));
				if (StringUtils.isNotEmpty(iMap.getString("BARKOD_NO")) && StringUtils.isNotEmpty(iMap.getString("QRCODE"))){
					oMap.put("DOC_LIST", j, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO") , iMap.getString("BARKOD_NO") , iMap.getString("QRCODE")));
				}
				else if (StringUtils.isNotEmpty(iMap.getString("BARKOD_NO"))){
					oMap.put("DOC_LIST", j, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO") , iMap.getString("BARKOD_NO")));
				}	
				else{
					oMap.put("DOC_LIST", j, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO")));
				}
				j++;
			}
	   }
			
			
			
			
			
			
		else {
			if(iMap.get("BASVURU_NO") == null){
				throw new Exception("Gecersiz Ba�vuru Numaras�!");
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));

			if (tffBasvuru != null) {
				kartTipi = tffBasvuru.getKartTipi();
			}
			else{
				throw new Exception("Ba�vuru Bulunamad�!");
			}
			List<CardDocTypes> list = Arrays.asList(CardDocTypes.values());
			int i = 0;
			int dokumanKod;
			for (CardDocTypes cardDocTypes : list) {
				dokumanKod = cardDocTypes.getCode();
				if (CreditCardTffServices.TFF_KREDI_KARTI.equals(kartTipi)) {
					if (dokumanKod == CardDocTypes.KK_SOZLESME_ONCESI_BILGI_FORMU.getCode() || dokumanKod == CardDocTypes.KK_URUN_BILGI_FORMU.getCode()) {
						CardDocument cardDocument = DocumentCreator.createCardDocument(dokumanKod);
						if(cardDocument == null){
							continue;
						}
						oMap.put("DOC_LIST", i, "CODE", dokumanKod);
						oMap.put("DOC_LIST", i, "NAME", getDocumentName(dokumanKod));
						oMap.put("DOC_LIST", i, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO")));
						i++;
					}

				}
				else if (CreditCardTffServices.TFF_DEBIT_KARTI.equals(kartTipi)) {
					if (dokumanKod == CardDocTypes.DEBIT_SOZLESME_ONCESI_BILGI_FORMU.getCode() || dokumanKod == CardDocTypes.DEBIT_URUN_BILGI_FORMU.getCode()) {
						CardDocument cardDocument = DocumentCreator.createCardDocument(dokumanKod);
						if(cardDocument == null){
							continue;
						}
						oMap.put("DOC_LIST", i, "CODE", dokumanKod);
						oMap.put("DOC_LIST", i, "NAME", getDocumentName(dokumanKod));
						oMap.put("DOC_LIST", i, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO")));
						i++;
					}
				}
				
				else if (CreditCardTffServices.TFF_PREPAID_KARTI.equals(kartTipi)) {
					if (dokumanKod == CardDocTypes.DIJITAL_CERCEVE_SOZLESME.getCode() ) {
						CardDocument cardDocument = DocumentCreator.createCardDocument(dokumanKod);
						if(cardDocument == null){
							continue;
						}
						oMap.put("DOC_LIST", i, "CODE", dokumanKod);
						oMap.put("DOC_LIST", i, "NAME", getDocumentName(dokumanKod));
						oMap.put("DOC_LIST", i, "XML", cardDocument.generateXml(iMap.getString("BASVURU_NO")));
						i++;
					}
				}
			}
		}
		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static String getDocumentName(int documentCode) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("SELECT ACIKLAMA FROM v_ml_gnl_dokuman_kod_pr WHERE KOD = ?");
			stmt.setString(1, String.valueOf(documentCode));
			rSet = stmt.executeQuery();

			if (rSet.next()) {
				return rSet.getString(1);
			}
			throw new GMRuntimeException(0, "Gecersiz Dokuman Kodu!");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TFF_SAVE_AGREEMENT_DOCUMENTS")
	public static GMMap  saveTffAggrementDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap dMap = new GMMap();
			dMap.put("DYS_TRANSFER", true);
			dMap.put("MAIL_TRANSFER", false);
			dMap.put("APPLICATION_NO", iMap.get("BASVURU_NO"));
			
			
			for (int i = 0; i < iMap.getSize("TBL_BELGE"); i++) {				
				
				dMap.put("DOC_LIST", i, "CODE", iMap.get("TBL_BELGE", i, "BELGE_KODU"));
				
			}
			
			GMServiceExecuter.execute("BNSPR_CREATE_CARD_DOCUMENTS", dMap);
			
			
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	

}
