package tr.com.aktifbank.bnspr.tff.services;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.xml.bind.DatatypeConverter;

import org.apache.axis.encoding.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import sun.misc.BASE64Decoder;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TffFotoServices extends TffServicesHelper {
	
	private static final Configurator conf = Configurator.createConfiguratorFromProperties ("configuration/aktifbank-int-tff.properties");
	private static final Logger logger = Logger.getLogger(TffFotoServices.class);
	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	/** Verilen dosyayi server uzerinde temp directory icerisine kopyalar.<br>
	 * @author murat.el
	 * @since PY-7119
	 * @param iMap - Dosya Bilgileri<br>
	 *        <li>FILE - Kopyalanacak dosya
	 *        <li>FILE_NAME - Kopyalanacak dosya adi
	 * @return Islem sonucu<br>
	 * 		  <li>SERVER_PATH - Kopyalandigi dosya yolu
	 */
	@GraymoundService("BNSPR_TFF_COPY_FILE_TO_SERVER_TEMP")
	public static GMMap copyFileToServerTemp(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		InputStream inputStream = null;
		OutputStream outputStream = null;
		try {
			//Kopyalanacak dosyayi al.
			inputStream = new ByteArrayInputStream((byte[]) iMap.get("FILE"));
			//Kopyalanacagi dizini al.
			File destFile = new File(ROOT + File.separator + "files" + File.separator + iMap.getString("FILE_NAME"));
			outputStream = new FileOutputStream(destFile);
			//Kopyala
			IOUtils.copy(inputStream, outputStream);
			oMap.put("SERVER_PATH", destFile.getAbsoluteFile());
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			try {
				if(outputStream != null) {
					outputStream.close();
				}
				if(inputStream != null) {
					inputStream.close();
				}
			} catch(IOException e){
				logger.error(e);
			}
		}
		
		return oMap;
	}
	
	/** Verilen basvuru bilgileri ile fotograf ekler.<br>
	 * @author murat.el
	 * @since PY-7119
	 * @param iMap - Tff basvuru islemi bilgileri<br>
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 *        <li>UYRUK_KOD - Basvuran uyrugu
	 *        <li>TC_KIMLIK_NO - Basvuran tc kimlik numarasi
	 *        <li>PASAPORT_NO - Basvuran pasaport numarasi
	 *        <li>FOTO_BYTE_ARRAY - Fotograf
	 * @return Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu
	 *        <li>RESPONSE_DATA - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TFF_CORE_FOTO_YUKLE")
	public static GMMap fotoYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		try {
			//Inputlari al
			String basvuruNo = iMap.getString("TFF_BASVURU_NO");
			if (StringUtils.isBlank(basvuruNo)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			
			//Uyruk alanina gore kimlik no al.
			String uyrukKod = CreditCardServicesUtil.nvl(iMap.getString("UYRUK_KOD"), "TR");
			String kimlikNo = StringUtils.EMPTY;
			if ("TR".equals(uyrukKod)) {
				kimlikNo = iMap.getString("TC_KIMLIK_NO");
			} else {
				kimlikNo = iMap.getString("PASAPORT_NO");
			}
			
			//kimlik no alindi mi, alinamadi ise hata ver, alindi ise uppercase.
			String kimlikNoLpad = StringUtils.EMPTY;
			if (StringUtils.isBlank(kimlikNo)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
				return oMap;
			} else {
				kimlikNo = kimlikNo.trim().toUpperCase();
				kimlikNoLpad = StringUtil.lPad(kimlikNo, 12);
			}
			
			//Fotografi al
			byte[] fotoArray = Base64.decode(iMap.getString("FOTO_BYTE_ARRAY"));
			//Fotografin buyuklugu yeterli mi
			if (fotoArray == null || fotoArray.length > Integer.valueOf(conf.getProperty("tff-foto-max-size")) * 1024 * 1024) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_BOYUT_HATASI);
				return oMap;
			}
			//Fotograf gecerli mi
			sorguMap.clear();
			sorguMap.putAll(getFotoValidity(fotoArray));
			if (sorguMap.getBoolean("VALID_MI", true)) {
				fotoArray = (byte[]) sorguMap.get("VALID_FOTO_BYTE_ARRAY");
				oMap.put("VALID_FOTO_BYTE_ARRAY", Base64.encode(fotoArray));
			} else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_YUZ_TANIMA_HATASI);
				return oMap;
			}
			
			//Dosyanin uzantisini al.
			String sourceMimeType = "image/jpeg";//URLConnection.guessContentTypeFromStream(bis);
			sorguMap.clear();
			sorguMap.put("image/png", "png");
			sorguMap.put("image/jpeg", "jpg");
			String fotoType = "jpg";
			if (StringUtils.isBlank(sorguMap.getString(sourceMimeType))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_TIPI_TANIMLAMASI_HATASI);
				return oMap;
			} else{
				fotoType = sorguMap.getString(sourceMimeType);
			}
			
			//Fograf dosyasini yaz.
			//Dizini al
			String folderPath = ROOT + File.separator + "files";
			try {
				sorguMap.clear();
				sorguMap.put("KOD", "TFF_WEBSERVIS_PARAM");
				sorguMap.put("KEY1", "K");
				sorguMap.put("KEY2", "RESIM_PATH");
				folderPath = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");
			} catch (Exception e) {
				logger.error(e);
			}
			
			//Isletim sistemini al
			String isWindows = CreditCardServicesUtil.HAYIR;
			if(SystemUtils.IS_OS_WINDOWS){
				isWindows = CreditCardServicesUtil.EVET;
			} else{
				isWindows = CreditCardServicesUtil.HAYIR;
			}
			
			//Yazilacak dosya dizinini olustur
			String[] sp = kimlikNoLpad.split("(?<=\\G.{3})");
			File klasor = null;
			boolean isFirst = false;
			String approved = StringUtils.EMPTY;
			Runtime runtime = Runtime.getRuntime();
			//folderPath = String.format("/%s/%s/%s/%s/%s/", folderPath,sp[0],sp[1],sp[2],kimlikNo);
			for (int i = 0; i < sp.length-1 && i < 3; i++) {
				if(TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath,"XXX");	
				else
					folderPath = String.format("%s/%s", folderPath,sp[i]);
				klasor = new File(folderPath);
				if (!klasor.exists()) {
					if (CreditCardServicesUtil.EVET.equals(isWindows)) {
						klasor.mkdir();
					} else {
						String[] cmdLine = {"mkdir", folderPath};
		                Process p =runtime.exec ( cmdLine );
		                p.waitFor();
					}
				}
			}
			
			folderPath = String.format("%s/%s", folderPath, kimlikNo);
			klasor = new File(folderPath);
			if (!klasor.exists()){
				if (CreditCardServicesUtil.EVET.equals(isWindows)) {
					klasor.mkdir();
				} else {
					String[] cmdLine = {"mkdir", folderPath};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
				//ilk basvurusu
				isFirst = true;
				approved = String.format("%s/%s", folderPath,conf.getProperty("gise_foto_folder"));
				File app = new File(approved);
				if (CreditCardServicesUtil.EVET.equals(isWindows)) {
					app.mkdirs();
				} else {
					String[] cmdLine = {"mkdir", approved};
	                Process p =runtime.exec ( cmdLine );
	                p.waitFor();
				}
			}
			
			//Dosyayi yaz
			ImageInputStream iis = ImageIO.createImageInputStream(new ByteArrayInputStream(fotoArray));
			Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);
			ImageReader reader = readers.next();
			reader.setInput(iis, true);
			ImageReadParam param = reader.getDefaultReadParam();
			Image image = reader.read(0, param);
			
			BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
			Graphics2D g2 = bufferedImage.createGraphics();
			g2.drawImage(image, null, null);

			File imageFile = new File(folderPath + File.separator + kimlikNo + "_" + basvuruNo + "." + fotoType);
			ImageIO.write(bufferedImage, fotoType, imageFile);
			
			//ilk basvuru ise yuklenen resim approved klasorune aktarilir
			if (isFirst) {
				File appImage = new File(approved + File.separator + kimlikNo + "." + fotoType);
				ImageIO.write(bufferedImage, fotoType, appImage);
			}
		}
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
			return oMap;
		}
		
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "BASARILI");
		return oMap;
	}
	
	private static GMMap getFotoValidity(byte[] fotoData) {
		GMMap oMap = new GMMap();
		boolean isValid = true;

		if ("1".equals(conf.getProperty("tff-foto-validity-control-state"))) {
			OutputStream outputStream = null;
			InputStream inputStream = null;
			
			try {
				//Fotuyu urlden check et.
				URL postURL = new URL(conf.getProperty("tff-foto-check-url"));
				HttpURLConnection connection = (HttpURLConnection) postURL.openConnection();
				connection.setDoOutput(true);
				connection.setDoInput(true);
				connection.setRequestMethod("POST"); 
				
				outputStream = connection.getOutputStream();
				outputStream.write(fotoData);
				outputStream.flush();
				
				inputStream = connection.getInputStream();
				if (TffServicesMessages.FACE_VALIDATION_SUCCESS.equals(connection.getHeaderField("FACE_STATUS"))) {
					isValid = true;
				} else {
					isValid = false;
				}
				
				ByteArrayOutputStream bufferStream = new ByteArrayOutputStream();
				byte[] data = new byte[16384];
				int nRead;
				while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
					bufferStream.write(data, 0, nRead);
				}
				
				bufferStream.flush();
				if (bufferStream.toByteArray() != null) {
					oMap.put("VALID_FOTO_BYTE_ARRAY", bufferStream.toByteArray());
				} else {
					oMap.put("VALID_FOTO_BYTE_ARRAY", fotoData);
				}
			} 
			catch (Exception e) {
				oMap.put("VALID_FOTO_BYTE_ARRAY",fotoData);
				logger.error(e);
			}  finally {
				try {
					if(outputStream!=null)
						outputStream.close();
					if(inputStream!=null)
						inputStream.close();
				} catch(IOException e){
					logger.error(e);
				}
			}
		} else {
			oMap.put("VALID_FOTO_BYTE_ARRAY",fotoData);
		}
		
		oMap.put("VALID_MI",isValid);
		return oMap;
	}
	
	/** Verilen kimlik bilgileri ile kisiye ait mevcutta var olan onayli fotoyu alir.
	 * Alinan fotoyu yeni olusturulan basvuru icin kullanmak uzere ilgili dizinlere yazar.<br>
	 * @author murat.el
	 * @since PY-8907
	 * @param iMap - Tff basvuru islemi bilgileri<br>
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 * @return Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu
	 *        <li>RESPONSE_DATA - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TFF_CREATE_FOTO_FROM_APPROVED_FOTO")
	public static GMMap createFotoFromApprovedFoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Input kontrol
			String basvuruNo = iMap.getString("TFF_BASVURU_NO");
			if (StringUtils.isBlank(basvuruNo)) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			//Tff basvuru bilgilerini al
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, tffBasvuru.getBasvuruNo());
			if (tffBasvuruKimlik == null) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			//Onayli fotoyu al
			Object approvedFotoByteArray = null;
			sorguMap.clear();
			sorguMap.put("TFF_UYE_NO", tffBasvuru.getTffUyeNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_APPROVED_PHOTO", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			} else {
				approvedFotoByteArray = sorguMap.get("TFF_APPROVED_IMAGE");
			}
			//Alinan onayli fotoyu verilen basvuru icin yukle
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("UYRUK_KOD", tffBasvuruKimlik.getUyrukKod().trim().toUpperCase());
			sorguMap.put("TC_KIMLIK_NO", tffBasvuru.getTcKimlikNo());
			if (StringUtils.isBlank(tffBasvuruKimlik.getPasaportNo())) {
				sorguMap.put("PASAPORT_NO", StringUtils.EMPTY);
			} else {
				sorguMap.put("PASAPORT_NO", tffBasvuruKimlik.getPasaportNo().trim().toUpperCase());
			}
			sorguMap.put("FOTO_BYTE_ARRAY", approvedFotoByteArray);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_CORE_FOTO_YUKLE", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_GET_TEMP_FOTO")
	public static GMMap getTempFoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		String filePath = iMap.getString("SERVER_PATH");
		String folderPath = ROOT + File.separator + "files";
		
		String fotoBase64="";

		if (filePath != null) {
			BufferedImage foto = null;
			try {
				//foto = ImageIO.read(new File(filePath));
				byte[] fileContent = FileUtils.readFileToByteArray(new File(filePath));
				fotoBase64 = DatatypeConverter.printBase64Binary(fileContent);

//				ByteArrayOutputStream baos = new ByteArrayOutputStream();
//				ImageIO.write( foto, "jpg", baos );
//				baos.flush();
//				byte[] imageBytes = baos.toByteArray();
//				baos.close();
//				
//				//Byte array olan resmi string olarak formatla.
//				fotoBase64 = Base64.encode(imageBytes);
//				fotoBase64 = fotoBase64.trim().replaceAll("\n", "");
			} catch (IOException e) {
				logger.error(e);
				fotoBase64 = null;
			}
		}
		
		oMap.put("FOTO_PATH", filePath);
		//oMap.put("FOTO_DEGER_BASE64", fotoBase64);
		if (fotoBase64 == null) {
			oMap.put("FOTO_DEGER", fotoBase64);
		} else {
			oMap.put("FOTO_DEGER", "data:image/jpeg;base64," + fotoBase64);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_TFF_FOTO_PATH_VER")
	public static GMMap fotoPathVer(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		String basvuruNo =iMap.getString("TFF_BASVURU_NO");
				
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);

		TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		
		String kimlikNo = tffBasvuruKimlik.getTcKimlikNo();
		if(!"TR".equals(tffBasvuruKimlik.getUyrukKod())){
			kimlikNo = tffBasvuruKimlik.getPasaportNo(); 
		}
		
		String kimlikNoGercek = kimlikNo;
		kimlikNo = StringUtil.lPad(kimlikNo, 12);
		String folderPath = ROOT + File.separator + "files";
		try {

			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		String[] sp = kimlikNo.split("(?<=\\G.{3})");
		
		// folderPath = String.format("/%s/%s/%s/%s/%s/",
		// folderPath,sp[0],sp[1],sp[2],kimlikNo);
		for (int i = 0; i < sp.length - 1 && i < 3; i++) {
			if (TffServicesHelper.isWindowsReservedFilename(sp[i]))
				folderPath = String.format("%s/%s", folderPath, "XXX");
			else
				folderPath = String.format("%s/%s", folderPath, sp[i]);
			
		}
		folderPath = String.format("%s/%s", folderPath, kimlikNoGercek);
		
		// klasor.mkdir();
		String type = "jpg";
		
		String imageFile = folderPath + File.separator + kimlikNoGercek + "_" + basvuruNo + "." + type;

		oMap.put("PATH", imageFile);
		return oMap;
	}
	@GraymoundService("BNSPR_TFF_GET_APPROVED_PHOTO_PATH")
	public static GMMap tffGetApprovedPhotoPath(GMMap iMap){
		GMMap oMap = new GMMap();
		boolean forSS = false;
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = (TffUyeler)session.get(TffUyeler.class, iMap.getBigDecimal("TFF_UYE_NO"));
			if ( tffUyeler == null ){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.GET_APPROVED_PHOTO_UYE_MEVCUT_DEGIL);
				return oMap;
			}
			String folderPath = ROOT + File.separator + "files";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}
			
			catch (Exception e) {
				e.printStackTrace();
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
				return oMap;
			}
			if(StringUtils.isNotBlank(iMap.getString("TARGET")) && "SS".equals(iMap.getString("TARGET"))){
				try {
					folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "SS", BnsprType.STRING, "RESIM_PATH"));
					forSS = true;
				}
				
				catch (Exception e) {
					e.printStackTrace();
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA",TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
					return oMap;
				}
			}
			String[] sp;
			String kimlikNo= "";
			if ( "TR".equals(tffUyeler.getUyruk() )){
				kimlikNo = tffUyeler.getTckn().toString();
			}
			else{
				kimlikNo = tffUyeler.getPasaportNo();
			}
			String kimlikNoLpad =  StringUtil.lPad(kimlikNo, 12);
			sp = kimlikNoLpad.split("(?<=\\G.{3})");
		
			for (int i = 0; i < sp.length-1 && i < 3; i++) {
				if(TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath,"XXX");	
				else
					folderPath = String.format("%s/%s", folderPath,sp[i]);
				
			}
			folderPath = String.format("%s/%s", folderPath,kimlikNo);
			folderPath +=  "/" +conf.getProperty("gise_foto_folder")+ "/"+kimlikNo+ ".jpg";
			if(forSS){
				folderPath = folderPath.replace("/", "\\");
			}
			oMap.put("TFF_APPROVED_IMAGE_PATH", folderPath);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA",TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
		}
		return oMap;
		
	}
	
	
	
	/**
	 * BASVURU_NO
	 * TCKN
	 * PASAPORT_NO
	 * UYRUK_KOD
	 * */
	@GraymoundService("BNSPR_TFF_UPDATE_APPROVED_PHOTO")
	public static GMMap updateApprovedPhoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		String uyrukKod = iMap.getString("UYRUK_KOD");
		BigDecimal tckn = iMap.getBigDecimal("TCKN");
		String pasaportNo = iMap.getString("PASAPORT_NO");
		
		String path="";
		String approvedPath="";
		try {
			 path 			= TffServicesHelper.generatePhotoPath(basvuruNo, uyrukKod, tckn, pasaportNo, false);
			 approvedPath 	= TffServicesHelper.generatePhotoPath(basvuruNo, uyrukKod, tckn, pasaportNo, true);
		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GISE_FOTO_GUNCELLENEMEDI);
			oMap.put("RESPONSE_DESC",e.getMessage());
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "BNSPR_TFF_UPDATE_APPROVED_PHOTO "+iMap.getBigDecimal("BASVURU_NO");
			String mailBody = "hata alan kimlik bilgileri:";
			mailBody += "<br>" + "BNSPR_TFF_UPDATE_APPROVED_PHOTO: patladi";
			mailBody += "<br>" + "BASVURU_NO:" + iMap.getBigDecimal("BASVURU_NO");
			mailBody += "<br>" + "HATA :" + e.getMessage();
			mailBody += "<br>" + "IMAP :" + iMap.toString();
			mailBody += "<br>" + "path :" + path;
			mailBody += "<br>" + "approvedPath :" + approvedPath;
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			mailBody += "<br>" + "TRACE :" + sw.toString();
					
			sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
			
			
			logger.error(e.getMessage());
			return oMap;
		}
		
		boolean result = TffServicesHelper.copyFile(new File(path), new File(approvedPath));
		
		if (result) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "");
		}else{
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GISE_FOTO_GUNCELLENEMEDI);
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "BNSPR_TFF_UPDATE_APPROVED_PHOTO "+iMap.getBigDecimal("BASVURU_NO");
			String mailBody = "hata alan kimlik bilgileri:";
			mailBody += "<br>" + "BNSPR_TFF_UPDATE_APPROVED_PHOTO: patladi";
			mailBody += "<br>" + "BASVURU_NO:" + iMap.getBigDecimal("TFF_BASVURU_NO");
		
			mailBody += "<br>" + "IMAP :" + iMap.toString();
			mailBody += "<br>" + "path :" + path;
			mailBody += "<br>" + "approvedPath :" + approvedPath;
			
					
			sendMail(mailFrom, mailToParametre,mailSubject , mailBody);
		
		}
		
		return oMap;
	}
	
	/** Verilen kimlik bilgileri ile kisiye ait mevcutta var olan onayli fotoyu alir.
	 * Alinan fotoyu yeni olusturulan basvuru uzerine yuleyerek basvuru durumunu ilerletir<br>
	 * @author murat.el
	 * @since PY-8907
	 * @param iMap - Tff basvuru islemi bilgileri<br>
	 *        <li>TFF_BASVURU_NO - Tff basvuru numarasi
	 * @return Islem sonucu<br>
	 *        <li>RESPONSE - Islem sonuc kodu
	 *        <li>RESPONSE_DATA - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TFF_FOTO_YUKLE_FROM_APPROVED_FOTO")
	public static GMMap loadTffPhotoFromApprovedFoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Input kontrol
			String basvuruNo = iMap.getString("TFF_BASVURU_NO");
			if (StringUtils.isBlank(basvuruNo)) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			//Tff basvuru bilgilerini al
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, tffBasvuru.getBasvuruNo());
			if (tffBasvuruKimlik == null) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			//Onayli fotoyu al
			Object approvedFotoByteArray = null;
			sorguMap.clear();
			sorguMap.put("TFF_UYE_NO", tffBasvuru.getTffUyeNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_APPROVED_PHOTO", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			} else {
				approvedFotoByteArray = sorguMap.get("TFF_APPROVED_IMAGE");
			}
			//Alinan onayli fotoyu verilen basvuru icin yukle
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("FOTO_BYTE_ARRAY", approvedFotoByteArray);
			sorguMap.put("SOURCE", tffBasvuru.getSource());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_FOTO_YUKLE", sorguMap));
			if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_GET_PHOTO")
	public static GMMap tffGetPhoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
		
			String folderPath = ROOT + File.separator + "files";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}

			catch (Exception e) {
				e.printStackTrace();
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
				return oMap;
			}
			File klasor = null;
			String[] sp;
			String kimlikNo = "";
			if ("TR".equals(iMap.getString("COUNTRY_CODE"))) {
				kimlikNo = iMap.getString("TCKN");
			}
			else {
				kimlikNo = iMap.getString("PASSPORT_NO");
			}
			String kimlikNoLpad = StringUtil.lPad(kimlikNo, 12);
			sp = kimlikNoLpad.split("(?<=\\G.{3})");

			for (int i = 0; i < sp.length - 1 && i < 3; i++) {
				if (TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath, "XXX");
				else
					folderPath = String.format("%s/%s", folderPath, sp[i]);
				klasor = new File(folderPath);
				if (!klasor.exists()) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
					return oMap;
				}
			}
			folderPath = String.format("%s/%s", folderPath, kimlikNo);
			folderPath += "/" + conf.getProperty("gise_foto_folder") + "/" + kimlikNo + ".jpg";
				String imageInByte ="";
			File file = new File(folderPath);
			if (!file.exists() || !file.isFile()) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
				return oMap;
			}
//			BufferedImage originalImage = ImageIO.read(file);
//
//			// convert BufferedImage to byte array
//			ByteArrayOutputStream baos = new ByteArrayOutputStream();
//			ImageIO.write(originalImage, "jpg", baos);
//			baos.flush();
//			imageInByte = baos.toByteArray();
//			baos.close();
			byte[] fileContent = FileUtils.readFileToByteArray(file);

			imageInByte = DatatypeConverter.printBase64Binary(fileContent);

			oMap.put("TFF_APPROVED_IMAGE", imageInByte);//encode64ByteArray(imageInByte));
			oMap.put("TFF_APPROVED_IMAGE_PATH", folderPath);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
		}
		return oMap;

	}
	
	
	/**
	* Vadesi dolan kartlar i�in yeni ba�vuruda ya da 
	* vade yenileme yap�ld���nda g�nderilen foto ile 
	* approved klas�r� alt�ndaki fotoyu de�i�tirir
	*/
	@GraymoundService("BNSPR_SKT_KANAL_FOTO_GUNCELLE")
	public static GMMap tffSktFotoGuncelle(GMMap iMap) throws IOException {
		
		GMMap oMap = new GMMap();
		GMMap photoMap = new GMMap();
		GMMap tMap = new GMMap();
		
		tMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		BigDecimal trxNo =  tMap.getBigDecimal("TRX_NO");
		byte[] imageByte;
		
		BASE64Decoder decoder = new BASE64Decoder();
        imageByte = decoder.decodeBuffer((String) iMap.getString("FILE"));

  		photoMap.put("FILE", imageByte);

		photoMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COPY_FILE_TO_SERVER_TEMP", photoMap));

		photoMap.put("TRX_NO", trxNo);
		photoMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		photoMap.put("FOTO_ARRAY", imageByte);
		photoMap.put("SERVER_PATH", photoMap.getString("SERVER_PATH"));
		photoMap.put("ONAYLI_FOTO_GUNCELLE", true);

		try{
		
			GMServiceExecuter.execute("BNSPR_TRN3834_SAVE", photoMap);
		}

		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
			return oMap;
		}
	
		oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARILI );
		return oMap;
	
	}
	
}
