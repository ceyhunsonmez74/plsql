package tr.com.aktifbank.bnspr.tff.document.type;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.tff.document.type.Enums;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

public class MusteriBilgiFormuUptIng  extends CardDocument {

	public MusteriBilgiFormuUptIng() {
		super("musteriBilgiFormuUptIng", "musteriBilgiFormuUptIng", Enums.CardDocTypes.MUSTERI_BILGI_FORMU_UPT_ING.getCode());
	}

	@Override
	public String generateXml(String applicationNo) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<DOCUMENT_INFO>");
		builder.append(GMServiceExecuter.call("BNSPR_KK_UPT_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		builder.append("</DOCUMENT_INFO>");

		return builder.toString();
	}
	
	@Override
	public String generateXml(String applicationNo , String barcode) {
		
		
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);
		iMap.put("BARKOD_NO", barcode);

		StringBuilder builder = new StringBuilder();
		builder.append("<DOCUMENT_INFO>");
		builder.append(GMServiceExecuter.call("BNSPR_KK_UPT_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		String template = builder.toString();
		StringBuilder barcodeBl = new StringBuilder();
		barcodeBl.append("<BARKOD>");
		barcodeBl.append(barcode);
		barcodeBl.append("</BARKOD>");
		
		String barcodeString = barcodeBl.toString();
		
		template = template.replaceFirst("</MUSTERI_BILGISI>", barcodeString+"</MUSTERI_BILGISI>");
		template = template.concat("</DOCUMENT_INFO>");	

		return template;
	}
	
	@Override
	public String generateXml(String applicationNo , String barcode , String qrCode) {
		
		
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);
		iMap.put("BARKOD_NO", barcode);
		iMap.put("QRCODE", qrCode);

		StringBuilder builder = new StringBuilder();
		builder.append("<DOCUMENT_INFO>");
		builder.append(GMServiceExecuter.call("BNSPR_KK_UPT_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		String template = builder.toString();
	
		StringBuilder barcodeQr = new StringBuilder();
		barcodeQr.append("<BARKOD>");
		barcodeQr.append(barcode);
		barcodeQr.append("</BARKOD>");
		barcodeQr.append("<QRCODE>");
		barcodeQr.append(qrCode);
		barcodeQr.append("</QRCODE>");
		
		String barcodeQrString = barcodeQr.toString();
		
		template = template.replaceFirst("</MUSTERI_BILGISI>", barcodeQrString+"</MUSTERI_BILGISI>");
		template = template.concat("</DOCUMENT_INFO>");

		return template;
	}
	
  @Override	
  public void generatePdf(String applicationNo , String barkodNo) {
		
		try {
			GMMap iMap = new GMMap();
			iMap.put("XML", generateXml(applicationNo,barkodNo));
			iMap.put("FOLDER_NAME", getFolderName());
			iMap.put("TEMPLATE_NAME", getTemplateName());
			setPdfByteArray((byte[])GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_PDF_BYTE", iMap).get("PDF_BYTE_DATA"));
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
  @Override	
  public void generatePdf(String applicationNo , String barkodNo , String qrCode) {
		
		try {
			GMMap iMap = new GMMap();
			iMap.put("XML", generateXml(applicationNo,barkodNo , qrCode));
			iMap.put("FOLDER_NAME", getFolderName());
			iMap.put("TEMPLATE_NAME", getTemplateName());
			setPdfByteArray((byte[])GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_PDF_BYTE", iMap).get("PDF_BYTE_DATA"));
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
