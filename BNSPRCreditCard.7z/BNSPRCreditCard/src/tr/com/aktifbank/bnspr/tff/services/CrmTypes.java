package tr.com.aktifbank.bnspr.tff.services;

public class CrmTypes {
	public static final int MAIN = 0;
	public static final int PAYMENT = 1;
	public static final int STATUS_UPDATE = 2;
	public static final int ADDRESS = 3;
}
