package tr.com.aktifbank.bnspr.tff.services;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * 
 * Bu class MTT01 ve MBL01 icin is kurallarinin isletildigi yerdir
 *  
 * Bu class icerisinde yer alan servisler dis sistemlerce cagrilan ve 
 * icerisinde is kurallarinin kontrol edildigi servisler olacakt�r 
 *
 * Gercek isleri yapan temel seviyede servisler TffCommonServices icerisinde yer almalidir
 *  
 * 
 */
public class TffWebMobilServices extends TffServicesHelper {
	
	private static final Logger logger = Logger.getLogger(TffWebMobilServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties ("configuration/aktifbank-int-tff.properties");
	/*EVAM event type*/
	private static final String EVENT_TYPE_NO = "17";
	
	
	@GraymoundService("BNSPR_TFF_KPS_SORGU_YAP")
	public static GMMap tffKpsSorgula(GMMap iMap) {
		GMMap oMap = new GMMap(), tMap = new GMMap(), iMap2 = new GMMap();
		try {
			iMap2 = new GMMap();
			iMap2.put("TCKN", iMap.getString("TCKN"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", iMap2));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				return oMap;
			}

			tMap = new GMMap();
			tMap.put("RESPONSE", "2");
			tMap.put("RESPONSE_DATA", "BASARILI");

			tMap.put("TFF_BASVURU_NO", oMap.getString("BASVURU_NO"));
			tMap.put("MUSTERI_BILGILERI", 0, "ADI", oMap.getString("AD1"));
			tMap.put("MUSTERI_BILGILERI", 0, "IKINCI_ADI", oMap.getString("AD2"));
			tMap.put("MUSTERI_BILGILERI", 0, "SOYADI", oMap.getString("SOYAD"));
			tMap.put("MUSTERI_BILGILERI", 0, "DOGUM_TARIHI", new SimpleDateFormat("yyyyMMdd").format(oMap.getDate("DOGUM_TARIHI")));
			tMap.put("MUSTERI_BILGILERI", 0, "BABA_ADI", oMap.getString("BABA_AD"));
			tMap.put("MUSTERI_BILGILERI", 0, "ANNE_ADI", oMap.getString("ANNE_AD"));
			tMap.put("MUSTERI_BILGILERI", 0, "CINSIYET", oMap.getString("CINSIYET"));
			tMap.put("MUSTERI_BILGILERI", 0, "MEDENI_DURUMU", oMap.getString("MEDENI_HALI"));
			tMap.put("MUSTERI_BILGILERI", 0, "NUFUS_VERILIS_TARIHI", new SimpleDateFormat("yyyyMMdd").format(oMap.getDate("VERILIS_TARIHI")));
			tMap.put("MUSTERI_BILGILERI", 0, "ES_TCKN", oMap.getString("ES_TCKN"));
			tMap.put("MUSTERI_BILGILERI", 0, "DOGUM_YERI", oMap.getString("DOGUM_YERI"));
		}
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-1");
			//throw ExceptionHandler.convertException(e);
			//CreditCardTffServices.raiseTffGMError("3007",!(String.valueOf(iMap.getString("TCKN")).isEmpty())?iMap.getString("TCKN"):iMap.getString("PASAPORT"));
		}
		return tMap;
	}
	
	@GraymoundService("BNSPR_WEB_CREATE_APPLICATION")
	public static GMMap createApplicationFromWeb(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_CREATE_APPLICATION_VALIDATION",iMap));
		if("2".equals(oMap.getString("RESPONSE"))){
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_CREATE_APPLICATION",iMap));
		}else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_WEB_ADD_OR_UPDATE_APPLICATION_PHONE")
	public static GMMap addOrUpdateApplicationPhone(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			if(StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO"))){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_TELEFON_EKLE_BASVURU_NO_BULUNAMADI);
			}
			GMMap trxMap = new GMMap();
			if(StringUtils.isBlank(iMap.getString("TRX_NO"))){
				
				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			}
			int size = iMap.getSize("TELEFON_LISTE");
			
			for (int i=0 ; i < size; i++){
				GMMap tmpMap = new GMMap();
				tmpMap.put("TELEFON_TIP", iMap.getString("TELEFON_LISTE",i,"TELEFON_TIP"));
				tmpMap.put("ULKE_KODU", iMap.getString("TELEFON_LISTE",i,"ULKE_KODU"));
				tmpMap.put("ALAN_KODU", iMap.getString("TELEFON_LISTE",i,"ALAN_KODU"));
				tmpMap.put("NUMARA", iMap.getString("TELEFON_LISTE",i,"NUMARA"));
				tmpMap.put("DAHILI", iMap.getString("TELEFON_LISTE",i,"DAHILI"));
				tmpMap.put("ILETISIM_MI", iMap.getString("TELEFON_LISTE",i,"ILETISIM_MI"));
				tmpMap.put("TRX_NO", iMap.getString("TRX_NO"));
				tmpMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_PHONE",iMap));
			}
			iMap.put("TRX_NAME", "3801");
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}
			
		catch (Exception e) {
			logger.error(e);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-4");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}
}
