package tr.com.aktifbank.bnspr.tff.document.type;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.tff.document.type.Enums;

public class KKSozlesmeOncesiBilgiFormu  extends CardDocument {

	public KKSozlesmeOncesiBilgiFormu() {
		super("kkSozlesmeOncesiBilgiFormu", "kkSozlesmeOncesiBilgiFormu", Enums.CardDocTypes.KK_SOZLESME_ONCESI_BILGI_FORMU.getCode());
	}

	@Override
	public String generateXml(String applicationNo) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<DOCUMENT_INFO>");
		builder.append(GMServiceExecuter.call("BNSPR_TFF_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		
		builder.append("</DOCUMENT_INFO>");

		return builder.toString();
	}

}
