package tr.com.aktifbank.bnspr.tff.xml;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import oracle.jdbc.OracleTypes;

import org.apache.axis.utils.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.tff.document.type.CardDocument;
import tr.com.aktifbank.bnspr.tff.document.type.DocumentCreator;
import tr.com.aktifbank.bnspr.tff.document.type.Enums.CardDocMailTypes;
import tr.com.aktifbank.bnspr.tff.document.type.Enums.CardDocTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.calikbank.integration.ftp.FtpClient;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CardDocumentPdfServices {
	
private static Configurator cardParams=Configurator.createConfiguratorFromProperties("aktifbank-int-tff.properties");
	
	@GraymoundService("BNSPR_CREATE_CARD_DOCUMENTS_BYTE")
	public static GMMap createCardDocumentsByte(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			int j=0;
			String applicationNo = iMap.getString("APPLICATION_NO");
			for(int index=0;index<iMap.getSize("DOC_LIST");index++) {
				int documentCode=iMap.getInt("DOC_LIST", index, "CODE");
				CardDocument cardDocument=DocumentCreator.createCardDocument(documentCode);
				if(cardDocument == null){
					continue;
				}
				cardDocument.setDocName(getDocumentName(documentCode));
				cardDocument.generatePdf(applicationNo);
				oMap.put("DOC_LIST", j, "CODE", documentCode);
				oMap.put("DOC_LIST", j, "BYTE_ARRAY", cardDocument.getPdfByteArray());
				j++;
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CREATE_KK_CARD_DOCUMENTS")
	public static GMMap createKKCardDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String applicationNo = iMap.getString("APPLICATION_NO");
			String barkod = iMap.getString("BARKOD");
			String qrCode = iMap.getString("QRCODE");
			
			boolean mailTransfer = iMap.getBoolean("MAIL_TRANSFER");
			boolean dysTransfer = iMap.getBoolean("DYS_TRANSFER");
			
			
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			BigDecimal musteriNo = kkBasvuru!= null && kkBasvuru.getMusteriNo() != null ? kkBasvuru.getMusteriNo() : null;
			
			if(musteriNo == null){
				return oMap;
			}
			if(iMap.getSize("DOC_LIST")>0 && (dysTransfer || mailTransfer)) {
				
				ArrayList<CardDocument> cardDocuments=new ArrayList<CardDocument>();
				for(int index=0;index<iMap.getSize("DOC_LIST");index++) {
					int documentCode=iMap.getInt("DOC_LIST",index,"CODE");
					CardDocument  cardDocument = DocumentCreator.createCardDocument(documentCode);
					if(cardDocument == null){
						continue;
					}
					cardDocument.setDocName(getDocumentName(documentCode));
					if(!StringUtils.isEmpty(barkod)){
						if(StringUtils.isEmpty(qrCode)){
							cardDocument.generatePdf(applicationNo,barkod);
						}
						else{
							cardDocument.generatePdf(applicationNo,barkod ,qrCode);
						}
						
					}
					else{
						cardDocument.generatePdf(applicationNo);
					}
					
					
					
					cardDocuments.add(cardDocument);
					GMMap sorguMap = new GMMap();
					sorguMap.put("MUSTERI_NO",musteriNo);
					sorguMap.put("DOKUMAN_KOD", documentCode);
					
					//GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI", sorguMap);
				}
				
				if(dysTransfer) {
					putDocumentToFTP(musteriNo.toString(), cardDocuments);
				}
				
				if(mailTransfer) {
					sendEMailPdfDocument(iMap, cardDocuments);
				}
				
				oMap.put("RESPONSE", 2);
			} else {
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", "Gecersiz Request");
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	

	@GraymoundService("BNSPR_CREATE_CARD_DOCUMENTS")
	public static GMMap createCardDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		String query = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String applicationNo = iMap.getString("APPLICATION_NO");
			
			boolean mailTransfer = iMap.getBoolean("MAIL_TRANSFER");
			boolean dysTransfer = iMap.getBoolean("DYS_TRANSFER");
			
			boolean isDocumentPublic = iMap.getBoolean("IS_PUBLIC_VERSION", false);
			
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			BigDecimal musteriNo = tffBasvuru!= null && tffBasvuru.getMusteriNo() != null ? tffBasvuru.getMusteriNo() : null;
			
			if(musteriNo == null){
				return oMap;
			}
			if(iMap.getSize("DOC_LIST")>0 && (dysTransfer || mailTransfer)) {
				         
				ArrayList<CardDocument> cardDocuments=new ArrayList<CardDocument>();
				for(int index=0;index<iMap.getSize("DOC_LIST");index++) {
					int documentCode=iMap.getInt("DOC_LIST",index,"CODE");
					
					/*Cc p2d i�lemi gelirse m��teri bilgilerini i�ermeyen dokuman versiyonlar�n�n templateini ��k�yoruz, yerine ge�ecek kodlar CC_P2D_DOC_CODES parametresinde tan�ml�*/
					if (isDocumentPublic) {
						 documentCode = Integer.parseInt(BnsprOceanCommonFunctions.getGlobalParamText("CC_P2D_DOC_CODES", String.valueOf(documentCode), null, null));
					}
					CardDocument  cardDocument = DocumentCreator.createCardDocument(documentCode);
					if(cardDocument == null){
						continue;
					}
					cardDocument.setDocName(getDocumentName(documentCode));
					cardDocument.generatePdf(applicationNo);
					/*template olu�tuktan sonra m��teri �zerine eski kodu yazmak i�in dokuman kodunu eski haline �ekiyoruz*/
					documentCode = iMap.getInt("DOC_LIST",index,"CODE");
					cardDocuments.add(cardDocument);
					GMMap sorguMap = new GMMap();
					sorguMap.put("MUSTERI_NO",musteriNo);
					sorguMap.put("DOKUMAN_KOD", documentCode);
					
					GMServiceExecuter.execute("BNSPR_TFF_DOKUMAN_ALINDI", sorguMap);

				}

				if (dysTransfer) {
					putDocumentToFTP(musteriNo.toString(), cardDocuments);
				}

				if (mailTransfer) {
					for (CardDocTypes sozlesmeKodu : CardDocTypes.values()) {
						if (sozlesmeKodu.getCode() == iMap.getInt("DOC_LIST", 0, "CODE")) {

							iMap.put("EMAIL_TYPE", sozlesmeKodu.name());
							break;
						}
					}
						sendEMailPdfDocument(iMap, cardDocuments);
				}

				
				oMap.put("RESPONSE", 2);
				}
				else {
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", "Gecersiz Request");
				}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	private static void putDocumentToFTP(String musteriNo, ArrayList<CardDocument> cardDocuments){
		Connection conn = null;
        CallableStatement stmt = null;
	    ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?)}");
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, cardParams.getProperty("ftp.gnl.sifre.code"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			rSet.next();

			String serverUri = rSet.getString("ip");
			String username = rSet.getString("user_name");
			String password = rSet.getString("passwd");
			String path = rSet.getString("path");
			BigDecimal port = rSet.getBigDecimal("port");
			String ftpType = rSet.getString("FTP_TURU");

			FtpClient ftpClient=new FtpClient(serverUri, port, ftpType, username, password);
			if(!ftpClient.isFileExist(path, musteriNo)) {
				ftpClient.createDirectory(path, musteriNo);
			}
			StringBuilder sb=new StringBuilder(path);
			sb.append(File.separator).append(musteriNo);
			for(CardDocument cardDocument:cardDocuments){
				ftpClient.put(sb.toString(), cardDocument.getDysPdfFileName(), cardDocument.getPdfByteArray());
			}
			
		}catch (Exception exp) {
			throw ExceptionHandler.convertException(exp);
			
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static void sendEMailPdfDocument(GMMap iMap, ArrayList<CardDocument> cardDocuments){
		GMMap inputMap=new GMMap();
		inputMap.put("FROM", cardParams.getProperty("mail.from"));
		inputMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EMAIL_TO")));
		inputMap.put("SUBJECT", iMap.getString("EMAIL_SUBJECT")==null?cardParams.getProperty("mail.subject"):iMap.getString("EMAIL_SUBJECT"));		
		
		inputMap.put("IS_BODY_HTML", true);
		inputMap.put("MESSAGE_BODY", generateMailHtml(iMap));
		inputMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
		int index=0;
		for(CardDocument cardDocument:cardDocuments) {
			inputMap.put("ATTACMENT_FILE_LIST",index,"FILE_NAME",cardDocument.getMailPdfFileName());
			inputMap.put("ATTACMENT_FILE_LIST",index,"FILE_BYTE_ARRAY",cardDocument.getPdfByteArray());
			index++;
		}
		GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", inputMap);
	}
	
	private static String generateMailHtml(GMMap iMap){
		GMMap inputMap=new GMMap();
		inputMap.put("FOLDER_NAME","tff");
		inputMap.put("TEMPLATE_NAME",CardDocMailTypes.valueOf(iMap.getString("EMAIL_TYPE")).getVmName());
		inputMap.put("ENCODING", "ISO-8859-9");
		
		HashMap<String,Object> inputs=new HashMap<String, Object>();
		inputs.put("AD", iMap.getString("EMAIL_NAME"));
		inputs.put("SOYAD", iMap.getString("EMAIL_SURNAME"));
		inputs.put("BASVURU_NO", iMap.getString("APPLICATION_NO"));
		inputs.put("KART_NO", iMap.getString("EMAIL_CARD_NO"));
		inputMap.put("INPUTS", inputs);
		
		return GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", inputMap).getString("HTML_DATA");
	}
	
	private static String getDocumentName(int documentCode) {
		Connection 			conn = null;
		PreparedStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareStatement("SELECT ACIKLAMA FROM v_ml_gnl_dokuman_kod_pr WHERE KOD = ?");
			stmt.setString(1, String.valueOf(documentCode));
			rSet = stmt.executeQuery();
			
			if(rSet.next()) {
				return rSet.getString(1);
			}
			throw new GMRuntimeException(0, "Gecersiz Dokuman Kodu!");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
