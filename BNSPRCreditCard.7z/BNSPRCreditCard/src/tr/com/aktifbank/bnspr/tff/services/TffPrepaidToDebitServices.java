package tr.com.aktifbank.bnspr.tff.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.util.KkProductsUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkSsProductMap;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TffPrepaidToDebitServices extends TffServicesHelper implements TffServicesMessages {
	
	private static final Logger logger = Logger.getLogger(TffPrepaidToDebitServices.class);
	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	private static final String LOGO_CODE= "001";
	private static final String CHANNEL_PASCOMMBL = "PASCOMMBL";
	private static final String IS_MUSTERI_GERCEK = "E";
	
	

	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_PROCESS_REQUEST")
	public static GMMap processRequest(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			//Talep gecerlilik kontrolu yap
			try {
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				GMServiceExecuter.execute("BNSPR_TFF_PREPAID_TO_DEBIT_VALIDATE_REQUEST", sorguMap);
			} catch (Exception e) {
				//Talebi guncelle
				String durumAciklama = e.getMessage();
				if (durumAciklama.length() > 200) {
					durumAciklama = durumAciklama.substring(0, 200);
				}
				
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", 8);//Talep data hatasi
				sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
				GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_VALIDASYON_HATASI);
			}
			
			//Talebin kart(SS) tarafina iletilip iletilmeyecegine karar ver dys_no 999 degilse SS e barkod almak icin ilet
			try {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_PREPAID_TO_DEBIT_AGREEMENT", sorguMap));
				//Kontrol
				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
					StringBuilder hata = new StringBuilder();
					hata.append("ORESULT");
					hata.append("\n");
					hata.append(oMap.getString("ORESULT"));
					hata.append("\n");
					hata.append("RETURN_DESCRIPTION");
					hata.append("\n");
					hata.append(oMap.getString("RETURN_DESCRIPTION"));

					//Talebi guncelle
					String durumAciklama = hata.toString();
					if (durumAciklama.length() > 200) {
						durumAciklama = durumAciklama.substring(0, 200);
					}
					
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", 9);//Kart olusturma hatasi
					sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
					return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
				} 
			} catch (Exception e) {
				//Talebi guncelle
				String durumAciklama = e.getMessage();
				if (durumAciklama.length() > 200) {
					durumAciklama = durumAciklama.substring(0, 200);
				}
				
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", 9);//Kart olusturma hatasi
				sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
				GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;

		
	}
	
	/** Verilen bilgiye sahip prepaid kart icin talepte girilen bilgilerle 
	 * tx kaydi olusturulur ve olusturulan bu tx kaydi ile talep validasyonu yapilir.<br>
	 * @author murat.el
	 * @since TY-4842
	 * @param iMap - Talep bilgileri<br>
	 * 			<li>TFF_BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>TRX_NO - Tx kaydi slem numarasi
	 */
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_VALIDATE_REQUEST")
	public static GMMap validateRequest(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			oMap.putAll(createTffTxFromRequest(sorguMap));
			//Kontrol
			if (oMap.get("TRX_NO") == null) {
				CreditCardServicesUtil.raiseGMError("330", "Islem No");
			}
			
			sorguMap.clear();
			sorguMap.put("TRX_NO", oMap.get("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_AFTER_CONTROL", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid kart icin talepte girilen bilgilerle tx kaydi olusturur.<br>
	 * @author murat.el
	 * @since TY-4842
	 * @param iMap - Talep bilgileri<br>
	 * 			<li>TFF_BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>TRX_NO - Tx kaydi slem numarasi
	 */
	private static GMMap createTffTxFromRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.create_tff_tx_with_talep(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.execute();

			trxNo = stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("TRX_NO", trxNo);
		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid kart icin kart paketine 
	 * kartin debite cevrilmek istendigini bildirir.<br>
	 * @author murat.el
	 * @since TY-4795
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>ID - Kaydedilen talebe ait id
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>RETURN_CODE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_AGREEMENT")
	public static GMMap prepaidToDebitAgreement(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.putAll(getAgreementInfoForP2D(sorguMap));
			String dagitimKodu = sorguMap.getString("DYS_NO");
			oMap.put("DYS_NO" ,dagitimKodu);
			
			// dagitim kodu = 999 degil ise kurye ile bhs gonderilmesi icin ss cagir 
			String bhsBekleniyorMu = "E";
			if(!StringUtils.isEmpty(dagitimKodu) && !BASVURU_DAGITIM_KOD_BOS.equals(dagitimKodu)){
				bhsBekleniyorMu = "E";
				logger.debug(" INPUT : " + sorguMap.toString());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_SEND_PREPAID_TO_DEBIT_AGREEMENT", sorguMap));
				
				logger.debug("BNSPR_INTRACARD_SEND_PREPAID_TO_DEBIT_AGREEMENT OUTPUT : " + oMap.toString());
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", 1);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
					
				}
				
				else{
					
					StringBuilder mailHata = new StringBuilder();
					mailHata.append("ORESULT");
					mailHata.append("\n");
					mailHata.append(oMap.getString("ORESULT"));
					mailHata.append("\n");
					mailHata.append("RETURN_DESCRIPTION");
					mailHata.append("\n");
					mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
					
					GMMap mailMap = new GMMap();
					mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
					mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
					mailMap.put("MAIL_SUBJECT", "TFF P2D Agreement Hata - " + sorguMap.getString("CARD_NO"));
					mailMap.put("MAIL_BODY", mailHata.toString());
					GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				}
				oMap.put("BHS_BEKLENIYOR_MU", bhsBekleniyorMu);

			}
			
			else {
				bhsBekleniyorMu = "H";
				GMMap outMap = new GMMap();
				outMap.put("BHS_BEKLENIYOR_MU", bhsBekleniyorMu);
				
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				//Basvuru kontrolu
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				session.flush();
				if(tffBasvuru != null){
					
					GMMap bhsNotifyMap = new GMMap();
					bhsNotifyMap.put("ApplicationNo", tffBasvuru.getBasvuruNo());
					bhsNotifyMap.put("CustomerNo", tffBasvuru.getMusteriNo());
					bhsNotifyMap.put("CardNo", tffBasvuru.getKartNo());
					bhsNotifyMap.put("CourierDelivery", "H");
					bhsNotifyMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					bhsNotifyMap.put("BASVURU_TALEP_ID", iMap.get("ID"));
					GMMap bhsNotifyResultMap = new GMMap();
					
					try{
					bhsNotifyResultMap.putAll(GMServiceExecuter.executeNT("BNSPR_INTRACARD_BHS_NOTIFY",bhsNotifyMap));
					if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(bhsNotifyResultMap.getString("RESPONSE_CODE"))){
							outMap.putAll(CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI));
							return outMap;
					}
					}
					
					catch(Exception e){
						outMap.putAll(CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI));
						return outMap;
					}
					
					if(bhsNotifyResultMap.get("TX_NO") == null){
						oMap.put("BHS_BEKLENIYOR_MU", bhsBekleniyorMu);
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
						return oMap;

					}
					
					GMMap bhsNotifyManagerMap = new GMMap();
					bhsNotifyManagerMap.put("TX_NO", bhsNotifyResultMap.getBigDecimal("TX_NO"));
					bhsNotifyManagerMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					bhsNotifyManagerMap.put("BASVURU_TALEP_ID", iMap.get("ID"));
					GMMap bhsManagerResultMap = new GMMap();
					
					try{
					bhsManagerResultMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_BHS_NOTIFY_PROCESS_SINGLE",bhsNotifyManagerMap));
					if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(bhsManagerResultMap.getString("RESPONSE_CODE"))){

							outMap.putAll(CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI));
							return outMap;
					}
					}
					catch(Exception e){
						outMap.putAll(CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI));
						return outMap;
					}
						
					
					 
				}
				
				
			}
			
			
			
			
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid karti debit karta cevirmek icin
	 * gerekli ekstra bilgiyi bulur.<br>
	 * @author murat.el
	 * @since TY-4795
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>ID - Kaydedilen talebe ait id
	 * @return oMap - Karta ait tum bilgiler<br>
	 */
	private static GMMap getAgreementInfoForP2D(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call PKG_KART_BASVURU_TALEP.getAgreementInfoForP2D(?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("ID"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.registerOutParameter(4, -10);
			stmt.registerOutParameter(5, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(2);//Ev
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet = (ResultSet) stmt.getObject(3);//Is
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet = (ResultSet) stmt.getObject(4);//Diger
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet = (ResultSet) stmt.getObject(5);//Talep
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid basvuruyu debit basvuruya cevrilebilir mi?<br>
	 * @author murat.el
	 * @since TY-4768
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>TFF_BASVURU_NO - Tff karta ait basvuru no
	 * @return oMap - Islem sonuc bilgisi<br>
	 * 			<li>DONUSUM_YAPILABILIR_MI - P2D Donusumu yapilabilir mi (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_PREPAID_TO_DEBIT_VALIDATE_APPLICATION")
	public static GMMap validateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DONUSUM_YAPILABILIR_MI", CreditCardServicesUtil.HAYIR);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Basvuru kontrolu
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru != null) {
				// blokeli bakiye kontrolu
				GMMap inMap = new GMMap();
				inMap.put("CARD_NO", tffBasvuru.getKartNo());
				inMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
				GMMap rMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_PREPAID_CARD_BLOCKED_BALANCE", inMap);
				if(rMap.getBigDecimal("BLOCKED_AMOUNT").compareTo(BigDecimal.ZERO) > 0){
					oMap.put("DONUSUM_YAPILABILIR_MI", CreditCardServicesUtil.HAYIR);
					logger.info("Bloke bakiyesi olan kartin PP2DB donusumu yapilamaz. KartNo: " + tffBasvuru.getKartNo().toString() + " MusteriNo: " + tffBasvuru.getMusteriNo().toString() + " Bloke Bakiye: " + rMap.getBigDecimal("BLOCKED_AMOUNT").toString());
					return oMap;
				}
				
				//Durum kontrolu
				if ("BASIM".equals(tffBasvuru.getDurumKod()) || "ACIK".equals(tffBasvuru.getDurumKod())) {
					//Tip kontrolu
					if ("P".equals(tffBasvuru.getKartTipi())) {
						oMap.put("DONUSUM_YAPILABILIR_MI", CreditCardServicesUtil.EVET);
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid basvuruyu debit basvuruya cevirir.<br>
	 * @author murat.el
	 * @since TY-4768
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>TFF_BASVURU_NO - Tff karta ait basvuru no
	 * @return oMap - Islem sonuc bilgisi<br>
	 */
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_UPDATE_APPLICATION")
	public static GMMap updateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call PKG_KART_BASVURU_TALEP.convertTffApplicationP2D(?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** P2D donusumu icin verilen tff basvurusunun talep idsini bulur.<br>
	 * @author murat.el
	 * @since TY-4768
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>kart_basvuru_Talep tablosundaki kolon adlari ile datalarin mape koyulmasi gerek
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_GET_CARD_REQUEST_ID_FOR_P2D")
	public static GMMap getCardRequestIdForP2D(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal id = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.getCardRequestIdByAppNo(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.execute();

			id = stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("ID", id);
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_GET_CONVERT_PARAMETERS")
	public static GMMap getConvertParameters(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Tff basvuru al

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			session.refresh(tffBasvuru);
			if (tffBasvuru == null) {
				return oMap;
			}
			oMap.put("URUN_ID", tffBasvuru.getUrunId());
			
			//urun bilgisi al
			TffSsProductMap tffSsProductMap = (TffSsProductMap) session.createCriteria(TffSsProductMap.class)
					.add(Restrictions.eq("urunId", tffBasvuru.getUrunId().toString()))
					.uniqueResult();
			if (tffSsProductMap == null) {
				return oMap;
			}
			oMap.put("LOGO_KOD", tffSsProductMap.getLogoKod());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_IS_PRODUCT_EXISTS")
	public static GMMap isProductExists(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("IS_EXISTS", CreditCardServicesUtil.HAYIR);

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.isProductExistsForP2D(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TFF_BASVURU_NO"));
			stmt.execute();

			oMap.put("IS_EXISTS", stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Musterinin prepaid kartini debit karta cevirir.
	 * 
	 * @since TYWMC-694
	 * @author murat.el
	 * @param iMap - Basvuru/Donusum bilgileri<br>
	 * 			<li>TFF_BASVURU_NO<li>KART_NO<li>MUSTERI_NO<li>TCKN<li>SOURCE
	 *			<li>AD<li>IKINCI_AD<li>SOYAD<li>ANNE_KIZLIK_SOYAD<li>EMAIL
	 *			<li>KIMLIK_SERI_NO<li>KIMLIK_SIRA_NO<li>CALISMA_SEKLI_KOD<li>ISYERI_ADI
	 *			<li>OGRENIM_DURUM_KOD<li>UNVAN_KOD<li>MESLEK_KOD<li>ISYERI_VERGI_DAIRESI_IL
	 *			<li>ISYERI_VERGI_DAIRESI_AD<li>CEP_ULKE_KOD<li>CEP_TEL_KOD<li>CEP_TEL_NO
	 *			<li>IS_ULKE_KOD<li>IS_TEL_KOD<li>IS_TEL_NO<li>IS_TEL_DAHILI
	 *			<li>EV_ULKE_KOD<li>EV_TEL_KOD<li>EV_TEL_NO<li>EV_IL<li>EV_ILCE
	 *			<li>EV_ADRES<li>EV_POSTA_KOD<li>IS_IL<li>IS_ILCE<li>IS_ADRES<li>IS_POSTA_KOD
	 *			<li>DIGER_IL<li>DIGER_ILCE<li>DIGER_ADRES<li>DIGER_POSTA_KOD
	 *			<li>TESLIMAT_ADRES_KOD<li>ILETISIM_ADRES_KOD
	 * @return oMap - Islem sonucu<br>
	 *          <li>RESPONSE - Islem Sonuc Kodu
	 *          <li>RESPONSE_DATA - Islem Sonuc Aciklama
	 */
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_MAKE_REQUEST_FROM_CHANNEL")
	public static GMMap makeRequestFromChannel(GMMap iMap) {
		GMMap sorguMap = new GMMap();
		GMMap oMap = new GMMap();
		

		try {
			//Basvuru No
			if (StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO"))) {
				return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			}
			
			//Kart no
			if (StringUtils.isBlank(iMap.getString("KART_NO"))) {
				return CreditCardServicesUtil.getErrorResponse(KART_NO_BOS);
			}
			
			//Basvuru gercekten cevrilebilir mi?
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_TO_DEBIT_VALIDATE_APPLICATION", sorguMap));
			
			if (HAYIR.equals(oMap.getString("DONUSUM_YAPILABILIR_MI"))) {
				return CreditCardServicesUtil.getErrorResponse(KART_TALEP_BASVURU_P2D_CEVRIME_UYGUN_DEGIL);
			}
			
			//Alanlari kontrol et
			sorguMap.clear();
			oMap.clear();
			sorguMap.putAll(iMap);
			sorguMap.put("ISLEM_TIPI", "P2D");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_VALIDATE_CARD_REQUEST_FROM_CHANNEL", sorguMap));
			if (!RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(oMap.getString("RESPONSE_DATA"));
			}

			//Kaydet
			sorguMap.clear();
			oMap.clear();
			sorguMap.putAll(iMap);			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap));
			oMap.put("RESPONSE" , RESPONSE_BASARILI);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/* Test DATA
			iMap.put("TFF_BASVURU_NO", "212703");
			iMap.put("KART_NO", "5282460249630264");
			iMap.put("MUSTERI_NO", "1242475");
			iMap.put("TCKN", "25369855474");
			iMap.put("SOURCE", "MTT01");
			iMap.put("AD", "S�LEYMAN");
			iMap.put("IKINCI_AD", "BESTAM�");
			iMap.put("SOYAD", "TEKEL�");
			iMap.put("ANNE_KIZLIK_SOYAD", "ANNE_KIZLIK_SOYAD");
			iMap.put("EMAIL", "sulobestek@basvuru.com");
			iMap.put("KIMLIK_SERI_NO", "V11");
			iMap.put("KIMLIK_SIRA_NO", "191115");
			iMap.put("CALISMA_SEKLI_KOD", "O");
			iMap.put("ISYERI_ADI", "AKTIFBANK");
			iMap.put("OGRENIM_DURUM_KOD", "Y");
			iMap.put("MESLEK_KOD", "14");
			iMap.put("ISYERI_VERGI_DAIRESI_IL", "008");
			iMap.put("ISYERI_VERGI_DAIRESI_AD", "08260");
			iMap.put("CEP_ULKE_KOD", "90");
			iMap.put("CEP_TEL_KOD", "551");
			iMap.put("CEP_TEL_NO", "4546554");
			iMap.put("IS_ULKE_KOD", "90");
			iMap.put("IS_TEL_KOD", "212");
			iMap.put("IS_TEL_NO", "3232323");
			iMap.put("IS_TEL_DAHILI", "");
			iMap.put("EV_ULKE_KOD", "90");
			iMap.put("EV_TEL_KOD", "212");
			iMap.put("EV_TEL_NO", "4323234");
			iMap.put("EV_IL", "034");
			iMap.put("EV_ILCE", "1183");
			iMap.put("EV_ADRES", "dfasdf adsf a");
			iMap.put("EV_POSTA_KOD", "1234");
			iMap.put("IS_IL", "034");
			iMap.put("IS_ILCE", "1183");
			iMap.put("IS_ADRES", "asdfas dasd fa");
			iMap.put("IS_POSTA_KOD", "9868");
			iMap.put("DIGER_IL", "034");
			iMap.put("DIGER_ILCE", "1183");
			iMap.put("DIGER_ADRES", "dasfassda asa");
			iMap.put("DIGER_POSTA_KOD", "5674");
			iMap.put("TESLIMAT_ADRES_KOD", "D");
			iMap.put("ILETISIM_ADRES_KOD", "E");
	 */
	
	
	
	
	
	@GraymoundService("BNSPR_TFF_PREPAID_TO_DEBIT_FROM_CHANNEL")
	public static GMMap prepaidToDebitFromChannel(GMMap iMap) {
		try{
			GMMap oMap  = new GMMap();
			GMMap requestMap = new GMMap();
			iMap.put("ISLEM_TIPI", "P2D");
			iMap.put("KANAL", nvl(iMap.get("KANAL"), iMap.get("SOURCE")));
			iMap.put("REFERANS_NO", nvl(iMap.get("REFERANS_NO"), iMap.get("TCKN")));
			iMap.put("SOURCE", nvl(iMap.get("SOURCE"), iMap.get("KANAL")));
			iMap.put("DURUM_KOD", nvl(iMap.get("DURUM_KOD"), KART_BASVURU_TALEP_ILK_DURUM_KOD));

			if (IS_MUSTERI_GERCEK.equals(iMap.getString("GERCEK_MUSTERI"))) {
				iMap.put("FILLED", true);
				iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3850_GET_APP_INFO_FROM_CUSTOMER", iMap));
				iMap.put("TESLIMAT_ADRES_KOD", iMap.getString("ILETISIM_ADRES_KOD"));
				iMap.put("REFERANS_NO", iMap.getString("TFF_BASVURU_NO"));

			}

			requestMap.putAll(GMServiceExecuter.executeNT("BNSPR_TFF_PREPAID_TO_DEBIT_MAKE_REQUEST_FROM_CHANNEL", iMap));
			if(!RESPONSE_BASARILI.equals(requestMap.getString("RESPONSE"))){
				return CreditCardServicesUtil.getErrorResponse(requestMap.getString("RESPONSE_DATA"));
			}
			
		
			// kart ilk basvuru talebi atildi , talebin islenmesini sagla
				
			GMMap talepMap = new GMMap();
			talepMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_GET_KART_BASVURU_TALEP_BY_ID", requestMap));
			GMMap talepResultMap =talepMap.getMap("RESULT_TABLE" ,0);
				
			if (talepResultMap == null || talepResultMap.isEmpty()) {
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_GENEL_HATA);
			}

			if (!(talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_BEKLEMEDE_DURUM_KOD || talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_ILK_DURUM_KOD)) {
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_GENEL_HATA);
			}

				if (talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_ILK_DURUM_KOD) {
					GMMap processMap = new GMMap();
					processMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_PROCESS_CARD_REQUEST", talepMap.getMap("RESULT_TABLE", 0)));

					if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(processMap.getString("RESPONSE"))) {
						return CreditCardServicesUtil.getErrorResponse(processMap.getString("RESPONSE_DATA"));
					}
				}
				
				if (talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_BEKLEMEDE_DURUM_KOD) {
					return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
				}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
	}
	@GraymoundService("BNSPR_OCEAN_PREPAID_TO_DEBIT_VALIDATE_APPLICATION")
	public static GMMap oceanValidateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DONUSUM_YAPILABILIR_MI", CreditCardServicesUtil.HAYIR);

		try {
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Basvuru kontrolu
			KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("KK_BASVURU_NO"));
			if (kkBasvuru != null) {
				// Bloke yeterli mi kontrolu
				GMMap inMap = new GMMap();
				inMap.put("CARD_NO", kkBasvuru.getKartNo());
				inMap.put("CUSTOMER_NO", kkBasvuru.getMusteriNo());
				GMMap rMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_PREPAID_CARD_BLOCKED_BALANCE", inMap);
				if(rMap.getBigDecimal("BLOCKED_AMOUNT").compareTo(BigDecimal.ZERO) > 0){
					oMap.put("DONUSUM_YAPILABILIR_MI", CreditCardServicesUtil.HAYIR);
					logger.info("Bloke bakiyesi olan kartin PP2DB donusumu yapilamaz. KartNo: " + kkBasvuru.getKartNo().toString() + " MusteriNo: " + kkBasvuru.getMusteriNo().toString() + " Bloke Bakiye: " + rMap.getBigDecimal("BLOCKED_AMOUNT").toString());
					return oMap;
				}
				
				//Durum kontrolu
				if ("BASIM".equals(kkBasvuru.getDurumKod()) || "ACIK".equals(kkBasvuru.getDurumKod())) {
					//Tip kontrolu
					if ("P".equals(kkBasvuru.getKartTipi())) {
						oMap.put("DONUSUM_YAPILABILIR_MI", CreditCardServicesUtil.EVET);
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_DEBIT_COMMON_GET_CARD_REQUEST_ID_FOR_OCEAN_P2D")
	public static GMMap getCardRequestIdForOceanP2D(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal id = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.getOceanCardRequestIdByAppNo(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KK_BASVURU_NO"));
			stmt.execute();

			id = stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("ID", id);
		return oMap;
	}
	
	@GraymoundService("BNSPR_OCEAN_PREPAID_TO_DEBIT_UPDATE_APPLICATION")
	public static GMMap updateOceanApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call PKG_KART_BASVURU_TALEP.convertKkApplicationP2D(?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("KK_BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	@GraymoundService("BNSPR_OCEAN_PREPAID_TO_DEBIT_GET_CONVERT_PARAMETERS")
	public static GMMap getOceanConvertParameters(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			
				//Session ac
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				//Basvuru kontrolu
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuru != null) {
					
					String urunId = KkProductsUtil.p2dProductCodeToConvert(kkBasvuru.getUrunTipi());
					oMap.put("URUN_ID", urunId);
					KkSsProductMap kkSsProductMap  = KkProductsUtil.getProductInfoById(urunId);
					
					if (kkSsProductMap != null)
					oMap.put("LOGO_KOD", kkSsProductMap.getLogoKod());
					else
						oMap.put("LOGO_KOD", LOGO_CODE);

			  }
			

			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static boolean isMusteriGercek(String musteriNo) {

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		@SuppressWarnings("unchecked")
		List<GnlMusteri> musteriList = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", new BigDecimal(musteriNo))).add(Restrictions.eq("musteriKontakt", "M")).list();

		if (musteriList == null)
			return false;
		else
			return true;

	}

}
