package tr.com.aktifbank.bnspr.tff.document.type;




public class DocumentCreator {

	public static CardDocument createCardDocument(int documentCode){
		
		
	   if (documentCode == Enums.CardDocTypes.DEBIT_SOZLESME_ONCESI_BILGI_FORMU.getCode()){
			return new DebitSozlesmeOncesiBilgiFormu();
		}
		
		else if (documentCode == Enums.CardDocTypes.DEBIT_URUN_BILGI_FORMU.getCode()){
			return new DebitUrunBilgiFormu();
		}
		
		else if (documentCode==Enums.CardDocTypes.KK_SOZLESME_ONCESI_BILGI_FORMU.getCode()){
			return new KKSozlesmeOncesiBilgiFormu();
		}
		
		else if(documentCode==Enums.CardDocTypes.KK_URUN_BILGI_FORMU.getCode()){
			return new KKUrunBilgiFormu();
		}
	   
		else if(documentCode==Enums.CardDocTypes.DIJITAL_CERCEVE_SOZLESME.getCode()){
			return new DijitalCerceveSozlesme();
		}
	   
		else if(documentCode==Enums.CardDocTypes.MUSTERI_BILGI_FORMU_YIM.getCode()){
			return new MusteriBilgiFormuYim();
		}
	   
		else if(documentCode==Enums.CardDocTypes.MUSTERI_BILGI_FORMU_UPT.getCode()){
			return new MusteriBilgiFormuUpt();
		}
	   
		else if(documentCode==Enums.CardDocTypes.MUSTERI_BILGI_FORMU_UPT_ING.getCode()){
			return new MusteriBilgiFormuUptIng();
		}
	   
		else if(documentCode==Enums.CardDocTypes.DIJITAL_CERCEVE_SOZLESME_EGOMOBIL.getCode()){
			return new DijitalCerceveSozlesmeEgoMobil();
		}
	   
		else if(documentCode==Enums.CardDocTypes.VERI_GIZLILIGI_SOZLESME_EGOMOBIL.getCode()){
			return new VeriGizliligiSozlesmesiEgoMobil();
		}
	   
		else if(documentCode==Enums.CardDocTypes.DIJITAL_CERCEVE_SOZLESME_ING_EGOMOBIL.getCode()){
			return new DijitalCerceveSozlesmeIngEgoMobil();
		}
	   
		else if(documentCode==Enums.CardDocTypes.VERI_GIZLILIGI_SOZLESME_ING_EGOMOBIL.getCode()){
			return new VeriGizliligiSozlesmesiIngEgoMobil();
		}
	   
		else if(documentCode==Enums.CardDocTypes.ELEKTRONIK_PASSOLIG_HIZMET_KOSULLARI_SOZLESME.getCode()){
			return new ElektronikPassoligHizmetKosullariSozlesme();
		}
	   
		else if(documentCode==Enums.CardDocTypes.KVKK_AYDINLATMA_METNI.getCode()){
			return new KisiselVerilerinKorunmasiKanunuAydinlatmaMetni();
		}
	   
		else if(documentCode==Enums.CardDocTypes.PASSOLIG_HIZMET_KOSULLARI_SOZLESMESI.getCode()){
			return new PassoligHizmetKosullariSozlesmesi();
		}
	   
		else if(documentCode==Enums.CardDocTypes.PASSOLIG_SOZLESME_ONCESI_BILGI_FORMU.getCode()){
			return new PassoligSozlesmeOncesiBilgiFormu();
		}
	   
		else if(documentCode==Enums.CardDocTypes.PASSOLIG_URUN_BILGI_FORMU.getCode()){
			return new PassoligUrunBilgiFormu();
		}
	   
		else{
			return null;
		}
			
	}
	
}
