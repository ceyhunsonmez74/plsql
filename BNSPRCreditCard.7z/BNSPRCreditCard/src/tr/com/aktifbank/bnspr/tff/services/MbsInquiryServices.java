package tr.com.aktifbank.bnspr.tff.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;



import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MbsInquiryServices implements OceanMapKeys {
    
    
    
	@GraymoundService("BNSPR_TFF_GET_MBS_INFO")
	public static GMMap getTffMbsInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		String RESULT_TABLE = "RESULT_TABLE";
		String BASVURU_BILGI = "BASVURU_BILGI";
		String KART_BILGI= "KART_BILGI";
		String CARD_DETAIL_INFO ="CARD_DETAIL_INFO" ;
		String basimAcikIptalMi =  "H";
		String cardBankStatus = OceanConstants.Card_Bank_Status_All;
        String cardGroup = OceanConstants.Card_Group_ALL;
        BigDecimal musteriNo;
		

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String query = null;
		try {
			if(StringUtils.isEmpty(iMap.getString("COUNTRY_CODE")) && !StringUtils.isEmpty(iMap.getString("PASSPORT_NO"))) {
				musteriNo = CardServicesHelper.searchCustomer(iMap.getString("PASSPORT_NO"));
			}
			else{
			musteriNo = CardServicesHelper.searchCustomer(iMap.getString("COUNTRY_CODE"), iMap.getString("TCKN"), iMap.getString("PASSPORT_NO"));
			}
			
			if(musteriNo == null || musteriNo.intValue() == 0){
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "M��teri bulunamad�");
				return oMap;
			}
			 
			conn = DALUtil.getGMConnection();
			query = "{call PKG_TFF_BASVURU.listMbsBasvuruOzetBilgi(?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);

			
			stmt.setBigDecimal(1, musteriNo);
			
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, Types.CHAR);
			stmt.registerOutParameter(4, Types.CHAR);
			stmt.registerOutParameter(5, Types.CHAR);
			stmt.registerOutParameter(6, Types.CHAR);
			stmt.registerOutParameter(7, Types.CHAR);
			stmt.registerOutParameter(8, Types.CHAR);
			stmt.registerOutParameter(9, Types.CHAR);
			stmt.registerOutParameter(10, Types.CHAR);
			

			stmt.execute();
			String ad = stmt.getString(6);
								
			if(StringUtils.isEmpty(ad)){
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "M��teri bulunamad�");
				return oMap;
			}
			rSet = (ResultSet) stmt.getObject(2);
			GMMap resultMap = DALUtil.rSetResults(rSet, RESULT_TABLE);

			if (resultMap == null || resultMap.isEmpty() || resultMap.getSize(RESULT_TABLE) == 0) {
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "Ba�vuru bulunamad�");
				return oMap;
			}
			
			
			
			oMap.put("MUSTERI_NO", musteriNo);
			oMap.put("TCKN", stmt.getString(3));
			oMap.put("PASAPORT_NO" , stmt.getString(4));
			oMap.put("UYRUK" , stmt.getString(5));
			oMap.put("AD", stmt.getString(6));
			oMap.put("IKINCI_AD", stmt.getString(7));
			oMap.put("SOYAD", stmt.getString(8));
			oMap.put("TFF_KARA_LISTEDE_MI", stmt.getString(9));
			oMap.put("TFF_OTP_KARA_LISTEDE_MI", stmt.getString(10));
			
			GMMap kanalBlokeMap = new GMMap();
			kanalBlokeMap.put("MUSTERI_NO", musteriNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN4131_GET_KANAL_BLOKE", kanalBlokeMap));
			oMap.put("INTERNET_BLOKE" , oMap.getBoolean("INTERNET") ? "E" : "H");
			oMap.put("IVR_BLOKE" , oMap.getBoolean("IVR") ? "E" : "H");
			oMap.put("CAGRI_MERKEZI_BLOKE", oMap.getBoolean("CAGRI_MERKEZI") ? "E" : "H");
			oMap.put("MOBIL_BLOKE", oMap.getBoolean("MOBIL") ? "E" : "H");
			oMap.put("PTT_BLOKE", oMap.getBoolean("PTT") ? "E" : "H");
			oMap.put("WEB_BLOKE", oMap.getBoolean("WEB") ? "E" : "H");
		
			
			// todo simcard bloke sorgula 
			
			GMMap sorguMap = new GMMap();	
			sorguMap.put("CUSTOMER_NO", oMap.getString("MUSTERI_NO"));
			sorguMap.put("FORMAT", "UAT");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", sorguMap));
			String cepNo = sorguMap.getString("PHONE_NUMBER");  
			
			GMMap simBlokeSorguMap = new GMMap();
			simBlokeSorguMap.put("USER_NAME" , "IVRUser");
			simBlokeSorguMap.put("MSISDN" ,cepNo);
			simBlokeSorguMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SIMCARD_GET_BLOCK_STATUS", simBlokeSorguMap));
			oMap.put("SIM_KART_BLOKELI_MI" , simBlokeSorguMap.getBoolean("BLOCKED") ? "E" : "H");

			
			
			Map oceanCardSet = new HashMap<String ,Map>();
			Map intraCardSet = new HashMap<String ,Map>();
			GMMap kartMap = new GMMap();
			
			
			int j= 0;
			int k= 0;
			for (int i = 0; i < resultMap.getSize(RESULT_TABLE); i++) {
				    String kartNo = resultMap.getString(RESULT_TABLE, i, "KART_NO");
				    String kuryeTipi = resultMap.getString(RESULT_TABLE, i, "KURYE_TIPI");
					String durumKod = resultMap.getString(RESULT_TABLE, i, "DURUM_KOD");
					String source = resultMap.getString(RESULT_TABLE, i, "SOURCE");
					String kkBasvuruNo  = resultMap.getString(RESULT_TABLE, i, "KK_BASVURU_NO");
					
					if(StringUtils.isEmpty(kartNo)){
					
					oMap.put(BASVURU_BILGI, k, "BASVURU_NO", resultMap.getBigDecimal(RESULT_TABLE, i, "BASVURU_NO"));
					oMap.put(BASVURU_BILGI, k, "DURUM", durumKod);
					oMap.put(BASVURU_BILGI, k, "DURUM_ACIKLAMA", resultMap.getString(RESULT_TABLE, i, "DURUM_KOD_ACIKLAMA"));
					oMap.put(BASVURU_BILGI, k, "KART_URUN_ID", resultMap.getString(RESULT_TABLE, i, "KART_URUN_ID"));
					oMap.put(BASVURU_BILGI, k, "KART_URUN_ADI", resultMap.getString(RESULT_TABLE, i, "URUN_ADI"));
					oMap.put(BASVURU_BILGI, k, "KART_URUN_KODU", resultMap.getString(RESULT_TABLE, i, "URUN_KODU"));
					oMap.put(BASVURU_BILGI, k, "LOGO_KODU", resultMap.getString(RESULT_TABLE, i, "LOGO_KODU"));
					oMap.put(BASVURU_BILGI, k, "CARD_DCI", getCardDciByKartTipi(resultMap.getString(RESULT_TABLE, i, "KART_TIPI")));
					oMap.put(BASVURU_BILGI, k, "BASVURU_TARIH", resultMap.getString(RESULT_TABLE, i, "BASVURU_TARIH"));
					oMap.put(BASVURU_BILGI, k, "SOURCE", source);
					
					boolean isReversible = basvuruIptalEdilebilirMi(durumKod, kuryeTipi, kartNo, source, basimAcikIptalMi);
					oMap.put(BASVURU_BILGI, k, "IPTAL_EDILEBILIR", isReversible ? "E" : "H");
					k++;
				
				}
				else{
					
					kartMap.put(KART_BILGI, j, "BASVURU_NO", resultMap.getBigDecimal(RESULT_TABLE, i, "BASVURU_NO"));
					kartMap.put(KART_BILGI, j, "KK_BASVURU_NO", kkBasvuruNo);
					kartMap.put(KART_BILGI, j, "DURUM", durumKod);
					kartMap.put(KART_BILGI, j, "DURUM_ACIKLAMA", resultMap.getString(RESULT_TABLE, i, "DURUM_KOD_ACIKLAMA"));
					kartMap.put(KART_BILGI, j, "KART_URUN_ID", resultMap.getString(RESULT_TABLE, i, "KART_URUN_ID"));
					kartMap.put(KART_BILGI, j, "KART_URUN_ADI", resultMap.getString(RESULT_TABLE, i, "URUN_ADI"));
					kartMap.put(KART_BILGI, j, "KART_URUN_KODU", resultMap.getString(RESULT_TABLE, i, "URUN_KODU"));
					kartMap.put(KART_BILGI, j, "LOGO_KODU", resultMap.getString(RESULT_TABLE, i, "LOGO_KODU"));
					kartMap.put(KART_BILGI, j, "CARD_DCI", getCardDciByKartTipi(resultMap.getString(RESULT_TABLE, i, "KART_TIPI")));
					kartMap.put(KART_BILGI, j, "BASVURU_TARIH", resultMap.getString(RESULT_TABLE, i, "BASVURU_TARIH"));
					kartMap.put(KART_BILGI, j, "SOURCE", source);
					kartMap.put(KART_BILGI, j, "KART_NO", kartNo);
					kartMap.put(KART_BILGI, j, "MASKED_KART_NO", CardServicesHelper.maskCardNumber(kartNo));
				    if(!StringUtils.isEmpty(kkBasvuruNo)){
				    	oceanCardSet.put(kartNo, j);
				    }
				    else{
				    	intraCardSet.put(kartNo, j);
				    }
				    j++;
				}
			}
			
			// ocean kart bilgilerini al
					
				if(oceanCardSet.size() > 0){
					GMMap oceanResponseInpMap = new GMMap();
					GMMap oceanResponseOutMap = new GMMap();
					oceanResponseInpMap.put("CUSTOMER_NO", musteriNo);
					oceanResponseOutMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", oceanResponseInpMap));
					if("2".equals(oceanResponseOutMap.getString("RETURN_CODE"))){
						for(int i= 0 ; i<oceanResponseOutMap.getSize(CARD_DETAIL_INFO) ; i++){
							String responseCard = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "CARD_NO");
							int s = 0;
							if(oceanCardSet.containsKey(responseCard)){
								s = ((Integer)oceanCardSet.get(responseCard)).intValue();
							}
							else{
								continue;
							}
							
							String cardStatCode =  oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "CARD_STAT_CODE");
							String cardSubStatCode =  oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "CARD_SUB_STAT_CODE"); 
							String cardStatDesc =  oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "CARD_STAT_DESC");
							String courierStatus = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "COURIER_STATUS");
							String visaStat = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "VISA_STAT");
							String visaStartDate = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "VISA_START_DATE");
							String visaEndDate = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "VISA_END_DATE");
							String cardGroupDesc = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "CARD_GROUP_DESC");
							String cardStatChangeDate = oceanResponseOutMap.getString(CARD_DETAIL_INFO, i, "CARD_STAT_CHANGE_DATE");
							
							
							kartMap.put(KART_BILGI , s , "KART_ANA_STATU" ,cardStatCode);
							kartMap.put(KART_BILGI , s , "KART_ALT_STATU" , cardSubStatCode);
							kartMap.put(KART_BILGI , s , "KART_STATU_ACIKLAMA" , cardStatDesc);
							kartMap.put(KART_BILGI , s , "KURYE_STATU" ,courierStatus);
							kartMap.put(KART_BILGI ,s , "KART_GRUP_ACIKLAMA" ,cardGroupDesc);
							kartMap.put(KART_BILGI ,s , "VISA_STATU" ,visaStat);
							
							
							 
							 GMMap pinCheckMap = new GMMap();
							 pinCheckMap.put("CARD_NO", responseCard);
							 pinCheckMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CHECK_PIN_SET", pinCheckMap));
							 String pincheckFlag = !StringUtils.isEmpty(pinCheckMap.getString(IS_PIN_SET)) && "1".equals(pinCheckMap.getString(IS_PIN_SET)) ? "E" : "H";
							 kartMap.put(KART_BILGI , s , "SIFRE_ALINDI_MI" , pincheckFlag);
							 
							 if(!("N".equals(cardStatCode) ||  "G".equals(cardStatCode))){
								 if(!StringUtils.isEmpty(cardStatChangeDate)){
									 SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
									 Date today = new Date();
									 long diff = diffDay(formatter.parse(cardStatChangeDate) ,today);
									 GMMap parametreMap = new GMMap();
									 parametreMap.put("PARAMETRE", "TFF_KART_IPTAL_BEKLENECEK_SURE");
									 int basvuruYenilemeUyariGun = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", iMap).getInt("DEGER");
									 if (diff > basvuruYenilemeUyariGun){
										 kartMap.put(KART_BILGI ,s , "KART_IPTAL_YENI_BASVURU_UYARI" ,"E");
								     }
									 else{
										 kartMap.put(KART_BILGI ,s , "KART_IPTAL_YENI_BASVURU_UYARI" ,"H");
									 }
									
								 }
							 }
							 
							 if(!StringUtils.isEmpty(visaEndDate)){
								 SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
								 Date today = new Date();
								 long diff = diffDay(today ,formatter.parse(visaEndDate) );
								 GMMap parametreMap = new GMMap();
								 parametreMap.put("PARAMETRE", "TFF_VISA_YENILEME_UYARI_GUN");
								 int vizaYenilemeUyariGun = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", iMap).getInt("DEGER");
								 if (vizaYenilemeUyariGun >= diff){
									 kartMap.put(KART_BILGI ,s , "KART_VISA_YENILEME_UYARI" ,"E");
							     }
								 else{
									 kartMap.put(KART_BILGI ,s , "KART_VISA_YENILEME_UYARI" ,"H");
								 }
							 }
							 
						}
					}
					
				
				}
				
				
				// intra kart bilgilerini al
				
				if(intraCardSet.size() > 0){
					GMMap intraResponseMap = new GMMap();
					intraResponseMap.put("CUSTOMER_NO", musteriNo);
					intraResponseMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_GET_CARD_INFO", intraResponseMap));
					if("2".equals(intraResponseMap.getString("RETURN_CODE"))){
						for(int i= 0 ; i<intraResponseMap.getSize(CARD_DETAIL_INFO) ; i++){
							String responseCard = intraResponseMap.getString(CARD_DETAIL_INFO, i, "CARD_NO");
							int s = 0;
							if(intraCardSet.containsKey(responseCard)){
								s = ((Integer)intraCardSet.get(responseCard)).intValue();
							}
							else{
								continue;
							}
						
							String cardStatCode =  intraResponseMap.getString(CARD_DETAIL_INFO, i, "CARD_STAT_CODE");
							String cardSubStatCode =  intraResponseMap.getString(CARD_DETAIL_INFO, i, "CARD_SUB_STAT_CODE"); 
							String cardStatDesc =  intraResponseMap.getString(CARD_DETAIL_INFO, i, "CARD_STAT_DESC");
							String courierStatus = intraResponseMap.getString(CARD_DETAIL_INFO, i, "COURIER_STATUS");
							String visaStat = intraResponseMap.getString(CARD_DETAIL_INFO, i, "VISA_STAT");
							String visaStartDate = intraResponseMap.getString(CARD_DETAIL_INFO, i, "VISA_START_DATE");
							String visaEndDate = intraResponseMap.getString(CARD_DETAIL_INFO, i, "VISA_END_DATE");
							String cardGroupDesc = intraResponseMap.getString(CARD_DETAIL_INFO, i, "CARD_GROUP_DESC");
							String cardStatChangeDate = intraResponseMap.getString(CARD_DETAIL_INFO, i, "CARD_STAT_CHANGE_DATE");
							
							
							kartMap.put(KART_BILGI , s , "KART_ANA_STATU" ,cardStatCode);
							kartMap.put(KART_BILGI , s , "KART_ALT_STATU" , cardSubStatCode);
							kartMap.put(KART_BILGI , s , "KART_STATU_ACIKLAMA" , cardStatDesc);
							kartMap.put(KART_BILGI , s , "KURYE_STATU" ,courierStatus);
							kartMap.put(KART_BILGI ,s , "KART_GRUP_ACIKLAMA" ,cardGroupDesc);
							kartMap.put(KART_BILGI ,s , "VISA_STATU" ,visaStat);
							
							
							 
							 GMMap pinCheckMap = new GMMap();
							 pinCheckMap.put("CARD_NO", responseCard);
							 pinCheckMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_CHECK_PIN_SET", pinCheckMap));
							 String pincheckFlag = !StringUtils.isEmpty(pinCheckMap.getString(IS_PIN_SET)) && "1".equals(pinCheckMap.getString(IS_PIN_SET)) ? "E" : "H";
							 kartMap.put(KART_BILGI , s , "SIFRE_ALINDI_MI" , pincheckFlag);
							 
							 if(!("N".equals(cardStatCode) ||  "G".equals(cardStatCode))){
								 if(!StringUtils.isEmpty(cardStatChangeDate)){
									 SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
									 Date today = new Date();
									 long diff = diffDay(formatter.parse(cardStatChangeDate) ,today);
									 GMMap parametreMap = new GMMap();
									 parametreMap.put("PARAMETRE", "TFF_KART_IPTAL_BEKLENECEK_SURE");
									 int basvuruYenilemeUyariGun = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", iMap).getInt("DEGER");
									 if (diff > basvuruYenilemeUyariGun){
										 kartMap.put(KART_BILGI ,s , "KART_IPTAL_YENI_BASVURU_UYARI" ,"E");
								     }
									 else{
										 kartMap.put(KART_BILGI ,s , "KART_IPTAL_YENI_BASVURU_UYARI" ,"H");
									 }
									
								 }
							 }
							 
							 if(!StringUtils.isEmpty(visaEndDate)){
								 SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
								 Date today = new Date();
								 long diff = diffDay(today ,formatter.parse(visaEndDate) );
								 GMMap parametreMap = new GMMap();
								 parametreMap.put("PARAMETRE", "TFF_VISA_YENILEME_UYARI_GUN");
								 int vizaYenilemeUyariGun = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", iMap).getInt("DEGER");
								 if (vizaYenilemeUyariGun >= diff){
									 kartMap.put(KART_BILGI ,s , "KART_VISA_YENILEME_UYARI" ,"E");
							     }
								 else{
									 kartMap.put(KART_BILGI ,s , "KART_VISA_YENILEME_UYARI" ,"H");
								 }
							 }
					
								 
						}
					}
					
				
				}
				
				
				if(kartMap.size() > 0){
				   oMap.putAll(kartMap);
				}
				
				
				
				
				oMap.put("RESPONSE", "2");
				
			}

			

		
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

		return oMap;
	}
    
	private static boolean basvuruIptalEdilebilirMi(String durumKod , String kuryeTipi , String kartNo , String source , String basimAcikIptalMi){
		  boolean iptalEdilebilir = true;
			if (!"BASVURU".equals(durumKod) && !"FOTO".equals(durumKod) && !"ODEME".equals(durumKod) && !"ODEME_BEKLE".equals(durumKod) && !"ODEME_BASARISIZ".equals(durumKod)) {
				if ("BASIM".equals(durumKod)) {
					if ("H".equals(basimAcikIptalMi)) {
						if (!("NTS01".equals(source) && StringUtils.isEmpty(kartNo) && "A".equals(kuryeTipi))) {
							iptalEdilebilir = false;
						}

					}
				}
				else if ("ACIK".equals(durumKod)) {
					if ("H".equals(basimAcikIptalMi)){
						iptalEdilebilir = false;
					}

				}
				else {
					iptalEdilebilir = false;
				}

			}
		  
		  return iptalEdilebilir ;
		}
	
	
	
    
   
    
  
    
    
    
 
    
    
  
  
    
    
  
    
    
  
   
  
    
    
  
 
    
   
   
   
    
    
    private static GMMap getCustomerInfoFromEUPT(GMMap iMap) {
        GMMap eMap = new GMMap();
        eMap.put("USERID" , iMap.getString(EUPT_ACCOUNT_NO));
        return GMServiceExecuter.call("BNSPR_EUPT_GET_CUSTOMER_INFO_WITH_EUPT_ACCOUNTS" , iMap);
        /*
         * GET_USER_COREINFO_BY_ID Input: USERID (Hesap No) Output: CORE_CUSNUM(Aktifbank numaras�), GOVID(TCKN),
         * FOREIGNID(Yabanci kimlik numaras�), PASSPORTID(pasaport numaras�)
         */
    }
    
    private static String getCardDciByKartTipi(String kartTipi) {

		if ("D".equals(kartTipi)) {
			return OceanConstants.Akustik_DebitCard;
		}

		else if ("P".equals(kartTipi)) {
			return OceanConstants.Akustik_PrepaidCard;
		}

		else if ("KK".equals(kartTipi)) {
			return OceanConstants.Akustik_CreditCard;
		}
		else {
			return kartTipi;
		}
	}
    
    private static long diffDay(Date beginDate , Date endDate){
    	 // Creates two calendars instances
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        
        // Set the date for both of the calendar instance
        cal1.setTime(beginDate);
        cal2.setTime(endDate);

        // Get the represented date in milliseconds
        long milis1 = cal1.getTimeInMillis();
        long milis2 = cal2.getTimeInMillis();
        
        // Calculate difference in milliseconds
        long diff = milis2 - milis1;
        
       
        
        // Calculate difference in days
        long diffDays = diff / (24 * 60 * 60 * 1000);
        
        return diffDays;

    	
    }
   
  
   
    
    
    
    
    

   
}
