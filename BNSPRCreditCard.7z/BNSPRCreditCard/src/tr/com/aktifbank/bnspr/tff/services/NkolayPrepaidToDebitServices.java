package tr.com.aktifbank.bnspr.tff.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class NkolayPrepaidToDebitServices extends TffServicesHelper implements TffServicesMessages {
	
	private static final Logger logger = Logger.getLogger(NkolayPrepaidToDebitServices.class);
	private static final String BASVURU_DAGITIM_KOD_BOS = "999";
	
	@GraymoundService("BNSPR_NKOLAY_PREPAID_TO_DEBIT_PROCESS_REQUEST")
	public static GMMap processRequest(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			//Talep gecerlilik kontrolu yap
			try {
				sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
				GMServiceExecuter.execute("BNSPR_NKOLAY_PREPAID_TO_DEBIT_VALIDATE_REQUEST", sorguMap);
			} catch (Exception e) {
				//Talebi guncelle
				String durumAciklama = e.getMessage();
				if (durumAciklama.length() > 200) {
					durumAciklama = durumAciklama.substring(0, 200);
				}
				
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", 8);//Talep data hatasi
				sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
				
				GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_VALIDASYON_HATASI);
			}
			
			//Talebin kart(SS) tarafina iletilip iletilmeyecegine karar ver dys_no 999 degilse SS e barkod almak icin ilet
			try {
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_NKOLAY_PREPAID_TO_DEBIT_AGREEMENT", sorguMap));
				//Kontrol
				if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
					StringBuilder hata = new StringBuilder();
					hata.append("ORESULT");
					hata.append("\n");
					hata.append(oMap.getString("ORESULT"));
					hata.append("\n");
					hata.append("RETURN_DESCRIPTION");
					hata.append("\n");
					hata.append(oMap.getString("RETURN_DESCRIPTION"));

					//Talebi guncelle 
					
					String durumAciklama = hata.toString();
					if (durumAciklama.length() > 200) {
						durumAciklama = durumAciklama.substring(0, 200);
					}
					
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", 9);//Kart olusturma hatasi
					sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
					return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
				} 
				
			} catch (Exception e) {
				//Talebi guncelle
				String durumAciklama = e.getMessage();
				if (durumAciklama.length() > 200) {
					durumAciklama = durumAciklama.substring(0, 200);
				}
				
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("DURUM_KOD", 9);//Kart olusturma hatasi
				sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
				GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;

		
	}
	
	/** Verilen bilgiye sahip prepaid kart icin talepte girilen bilgilerle 
	 * tx kaydi olusturulur ve olusturulan bu tx kaydi ile talep validasyonu yapilir.<br>
	 * @author murat.el
	 * @since TY-4842
	 * @param iMap - Talep bilgileri<br>
	 * 			<li>TFF_BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>TRX_NO - Tx kaydi slem numarasi
	 */
	@GraymoundService("BNSPR_NKOLAY_PREPAID_TO_DEBIT_VALIDATE_REQUEST")
	public static GMMap validateRequest(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
			oMap.putAll(createTffTxFromRequest(sorguMap));
			//Kontrol
			if (oMap.get("TRX_NO") == null) {
				CreditCardServicesUtil.raiseGMError("330", "Islem No");
			}
			
			sorguMap.clear();
			sorguMap.put("TRX_NO", oMap.get("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_AFTER_CONTROL", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid kart icin talepte girilen bilgilerle tx kaydi olusturur.<br>
	 * @author murat.el
	 * @since TY-4842
	 * @param iMap - Talep bilgileri<br>
	 * 			<li>TFF_BASVURU_NO - Tff basvuru numarasi
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>TRX_NO - Tx kaydi slem numarasi
	 */
	private static GMMap createTffTxFromRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal trxNo = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.create_nkolay_tx_with_talep(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KK_BASVURU_NO"));
			stmt.execute();

			trxNo = stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("TRX_NO", trxNo);
		return oMap;
	}
	
	/** Verilen bilgiye sahip prepaid kart icin kart paketine 
	 * kartin debite cevrilmek istendigini bildirir.<br>
	 * @author murat.el
	 * @since TY-4795
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>ID - Kaydedilen talebe ait id
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>RETURN_CODE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_NKOLAY_PREPAID_TO_DEBIT_AGREEMENT")
	public static GMMap prepaidToDebitAgreement(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			
			GMMap sorguMap = new GMMap();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.putAll(getAgreementInfoForP2D(sorguMap));
			String dagitimKodu = sorguMap.getString("DYS_NO");
			
			if(!StringUtils.isEmpty(dagitimKodu) && !BASVURU_DAGITIM_KOD_BOS.equals(dagitimKodu)){
				logger.debug("BNSPR_OCEAN_SEND_PREPAID_TO_DEBIT_AGREEMENT INPUT : " + sorguMap.toString());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_SEND_PREPAID_TO_DEBIT_AGREEMENT", sorguMap));
				
				logger.debug("BNSPR_OCEAN_SEND_PREPAID_TO_DEBIT_AGREEMENT OUTPUT : " + oMap.toString());
				if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RETURN_CODE"))) {
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", 1);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
					
				}
				
				else{
					
					StringBuilder mailHata = new StringBuilder();
					mailHata.append("ORESULT");
					mailHata.append("\n");
					mailHata.append(oMap.getString("ORESULT"));
					mailHata.append("\n");
					mailHata.append("RETURN_DESCRIPTION");
					mailHata.append("\n");
					mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
					
					GMMap mailMap = new GMMap();
					mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
					mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
					mailMap.put("MAIL_SUBJECT", "Ocean P2D Agreement Hata - " + sorguMap.getString("CARD_NO"));
					mailMap.put("MAIL_BODY", mailHata.toString());
					GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);
				}
			}
			
			
			else{
				
			
				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				//Basvuru kontrolu
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, iMap.getBigDecimal("KK_BASVURU_NO"));
				session.flush();
				if(kkBasvuru != null){
					
					GMMap bhsNotifyMap = new GMMap();
					bhsNotifyMap.put("ApplicationNo", kkBasvuru.getBasvuruNo());
					bhsNotifyMap.put("CustomerNo", kkBasvuru.getMusteriNo());
					bhsNotifyMap.put("CardNo", kkBasvuru.getKartNo());
					bhsNotifyMap.put("CourierDelivery", "H");
					bhsNotifyMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
					bhsNotifyMap.put("BASVURU_TALEP_ID", iMap.get("ID"));
					GMMap bhsNotifyResultMap = new GMMap();
					
					try{
					bhsNotifyResultMap.putAll(GMServiceExecuter.executeNT("BNSPR_INTRACARD_BHS_NOTIFY",bhsNotifyMap));
					if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(bhsNotifyResultMap.getString("RESPONSE_CODE"))){
						return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
					}
					}
					
					catch(Exception e){
						return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
					}
					
					if(bhsNotifyResultMap.get("TX_NO") == null){
						oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
						return oMap;
					}
					
					
					
					GMMap bhsNotifyManagerMap = new GMMap();
					bhsNotifyManagerMap.put("TX_NO", bhsNotifyResultMap.getBigDecimal("TX_NO"));
					bhsNotifyManagerMap.put("KK_BASVURU_NO", kkBasvuru.getBasvuruNo());
					bhsNotifyManagerMap.put("BASVURU_TALEP_ID", iMap.get("ID"));

					GMMap bhsManagerResultMap = new GMMap();
					
					try{
					bhsManagerResultMap.putAll(GMServiceExecuter.execute("BNSPR_INTRACARD_BHS_NOTIFY_PROCESS_SINGLE",bhsNotifyManagerMap));
					if(!CreditCardServicesUtil.RESPONSE_BASARILI.equals(bhsManagerResultMap.getString("RESPONSE_CODE"))){
						return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
					}
					}
					catch(Exception e){
						return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_TALEP_ALINDI);
					}
						
					oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
					 
				}
			}
			
		
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static GMMap getAgreementInfoForP2D(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{call PKG_KART_BASVURU_TALEP.getAgreementInfoForP2DOcean(?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("ID"));
			stmt.setString(2, "910");
			stmt.registerOutParameter(3, -10);
			stmt.registerOutParameter(4, -10);
			stmt.registerOutParameter(5, -10);
			stmt.registerOutParameter(6, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(3);//Ev
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet = (ResultSet) stmt.getObject(4);//Is
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet = (ResultSet) stmt.getObject(5);//Diger
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			rSet = (ResultSet) stmt.getObject(6);//Talep
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_OCEAN_PREPAID_TO_DEBIT_FROM_CHANNEL")
	public static GMMap oceanPrepaidToDebitFromChannel(GMMap iMap) {
		try{
			GMMap oMap  = new GMMap();
			GMMap requestMap = new GMMap();
			iMap.put("ISLEM_TIPI", "P2D");
			iMap.put("KANAL", nvl(iMap.get("KANAL") , iMap.get("SOURCE")));			
			iMap.put("REFERANS_NO", nvl(iMap.get("REFERANS_NO"),  iMap.get("TCKN")));
			iMap.put("SOURCE", nvl(iMap.get("SOURCE") , iMap.get("KANAL")));
			iMap.put("DURUM_KOD", nvl(iMap.get("DURUM_KOD"), KART_BASVURU_TALEP_ILK_DURUM_KOD));
			
			requestMap.putAll(GMServiceExecuter.executeNT("BNSPR_OCEAN_PREPAID_TO_DEBIT_MAKE_REQUEST_FROM_CHANNEL", iMap));
			if(!RESPONSE_BASARILI.equals(requestMap.getString("RESPONSE"))){
				return CreditCardServicesUtil.getErrorResponse(requestMap.getString("RESPONSE_DATA"));
			}
		
			// kart ilk basvuru talebi atildi , talebin islenmesini sagla
				
			GMMap talepMap = new GMMap();
			talepMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_GET_KART_BASVURU_TALEP_BY_ID", requestMap));
			GMMap talepResultMap =talepMap.getMap("RESULT_TABLE" ,0);
				
			if (talepResultMap == null || talepResultMap.isEmpty()) {
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_GENEL_HATA);
			}
			
			if(!(talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_BEKLEMEDE_DURUM_KOD ||
 talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_ILK_DURUM_KOD)) {
				return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_GENEL_HATA);
			}

			if (talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_ILK_DURUM_KOD) {
				GMMap processMap = new GMMap();
				processMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_PROCESS_CARD_REQUEST", talepMap.getMap("RESULT_TABLE", 0)));

				if (CreditCardServicesUtil.RESPONSE_BASARISIZ.equals(processMap.getString("RESPONSE"))) {
					return CreditCardServicesUtil.getErrorResponse(processMap.getString("RESPONSE_DATA"));
				}
			}
			
			if (talepResultMap.getInt("DURUM_KOD") == KART_BASVURU_TALEP_BEKLEMEDE_DURUM_KOD) {
				return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
	}
	
	@GraymoundService("BNSPR_OCEAN_PREPAID_TO_DEBIT_MAKE_REQUEST_FROM_CHANNEL")
	public static GMMap makeOceanRequestFromChannel(GMMap iMap) {
		GMMap sorguMap = new GMMap();
		GMMap oMap = new GMMap();
		

		try {
			//Basvuru No
			if (StringUtils.isBlank(iMap.getString("KK_BASVURU_NO"))) {
				return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			}
			
			//Kart no
			if (StringUtils.isBlank(iMap.getString("KART_NO"))) {
				return CreditCardServicesUtil.getErrorResponse(KART_NO_BOS);
			}
			
			//Basvuru gercekten cevrilebilir mi?
			sorguMap.clear();
			sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_PREPAID_TO_DEBIT_VALIDATE_APPLICATION", sorguMap));
			
			if (HAYIR.equals(oMap.getString("DONUSUM_YAPILABILIR_MI"))) {
				return CreditCardServicesUtil.getErrorResponse(KART_TALEP_BASVURU_P2D_CEVRIME_UYGUN_DEGIL);
			}
			
			//Alanlari kontrol et
			sorguMap.clear();
			oMap.clear();
			sorguMap.putAll(iMap);
			sorguMap.put("ISLEM_TIPI", "P2D");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_VALIDATE_CARD_REQUEST_FROM_CHANNEL", sorguMap));
			if (!RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(oMap.getString("RESPONSE_DATA"));
			}

			//Kaydet
			sorguMap.clear();
			oMap.clear();
			sorguMap.putAll(iMap);			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap));
			oMap.put("RESPONSE" , RESPONSE_BASARILI);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	
}
