package tr.com.aktifbank.bnspr.tff.services;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.URLConnection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;
import org.joda.time.DateTime;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.context.support.StaticApplicationContext;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardTRN3802Services;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardTffServices;
import tr.com.aktifbank.bnspr.dao.CrdCcFundAccount;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTxId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlik;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlikTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgi;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgiTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonTxId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.aktifbank.bnspr.dao.Tffislem;
import tr.com.aktifbank.bnspr.dao.TffislemDetay;
import tr.com.aktifbank.bnspr.dao.UrunSahip;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriTelefon;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPrId;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * 
 * Bu class icerisindeki servisleri bolunup is kurallarini icerek halleri kanal bazindaki classlara
 * temel islemleri yapan kisimlari TffCommonServices altina alinacaktir
 * 
 * 
 */
public class TffServices extends TffServicesHelper {

	private static final Logger logger = Logger.getLogger(TffServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-tff.properties");
	/*EVAM event type*/
	private static final String EVENT_TYPE_NO = "17";
	private static final String BASIM_TIPI_VADE_YENILEME = "VD";
	private static final String BASIM_TIPI_SANAL_YENILENMIS = "SY";

	@GraymoundService("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE")
	public static GMMap tffBasvuruBilgisiIleMusteriGuncelle(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap customerContactMap = new GMMap();
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "Basvuru bulunamadi");
				return oMap;
			}
			BigDecimal uyeNo = tffBasvuru.getTffUyeNo();
			TffBasvuruKimlik tffBasvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			List<TffBasvuruAdres> adreslerList = session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).list();
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, uyeNo);

			GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, tffBasvuru.getMusteriNo());

			customerContactMap.put("KAYNAK", "TFF");
			customerContactMap.put("TUR", "TFFKART");
			customerContactMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
			customerContactMap.put("ADK_MUSTERISIMI", "H");
			customerContactMap.put("SOURCE", "TFF");
			customerContactMap.put("UYRUK_KOD", tffBasvuruKimlik.getUyrukKod());
			customerContactMap.put("EMAIL_KISISEL", tffBasvuru.getEPosta());
			customerContactMap.put("PROFIL_KOD", gnlMusteri.getMusteriStat1());
			customerContactMap.put("MUSTERI_GRUP_KOD", gnlMusteri.getMusteriGrupKod());
			customerContactMap.put("DK_GRUP_KOD", new BigDecimal("1042"));
			customerContactMap.put("BAGLI_KANAL_GRUBU", "40");
			customerContactMap.put("KAZANIM_KANALI", "40");
			customerContactMap.put("KANAL_KODU", StringUtils.EMPTY);
			customerContactMap.put("KAZANIM_URUNU", "TFFKART");

			customerContactMap.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"))).getString("PORTFOY_KOD"));
			customerContactMap.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3871_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", customerContactMap.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));

			if (tffBasvuruKimlik != null && "TR".equals(tffBasvuruKimlik.getUyrukKod())) {

				if (!StringUtils.isBlank(tffBasvuruKimlik.getTcKimlikNo())) {
					customerContactMap.put("TC_KIMLIK_NO", tffBasvuruKimlik.getTcKimlikNo());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getAd())) {
					customerContactMap.put("ISIM", tffBasvuruKimlik.getAd());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getSoyad())) {
					customerContactMap.put("SOYADI", tffBasvuruKimlik.getSoyad());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getOncekiSoyad())) {
					customerContactMap.put("KIZLIK_SOYADI", tffBasvuruKimlik.getOncekiSoyad());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getAnneAdi())) {
					customerContactMap.put("ANNE_ADI", tffBasvuruKimlik.getAnneAdi());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getBabaAd())) {
					customerContactMap.put("BABA_ADI", tffBasvuruKimlik.getBabaAd());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getIkinciAd())) {
					customerContactMap.put("IKINCI_ISIM", tffBasvuruKimlik.getIkinciAd());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getCinsiyet())) {
					customerContactMap.put("CINSIYET_KOD", tffBasvuruKimlik.getCinsiyet());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getMedeniHal())) {
					customerContactMap.put("MEDENI_HAL_KOD", tffBasvuruKimlik.getMedeniHal());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getDogumYeri())) {
					customerContactMap.put("DOGUM_YERI", tffBasvuruKimlik.getDogumYeri());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getNufusIlKod())) {
					customerContactMap.put("IL_KOD", tffBasvuruKimlik.getNufusIlKod());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getNufusIlceKod())) {
					customerContactMap.put("ILCE_KOD", tffBasvuruKimlik.getNufusIlceKod());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getKimlikSeriNo())) {
					customerContactMap.put("NUFUS_CUZDANI_SERI_NO", tffBasvuruKimlik.getKimlikSeriNo());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getKimlikSiraNo())) {
					customerContactMap.put("KIMLIK_SIRA_NO", tffBasvuruKimlik.getKimlikSiraNo());
				}

				if (tffBasvuruKimlik.getNufusVerTarKps() != null) {
					customerContactMap.put("VERILDIGI_TARIH", tffBasvuruKimlik.getNufusVerTarKps());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getNufusVerNedeni())) {
					customerContactMap.put("NUF_VERILIS_NEDENI", tffBasvuruKimlik.getNufusVerNedeni());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getNufusVerYer())) {
					customerContactMap.put("VERILDIGI_YER", tffBasvuruKimlik.getNufusVerYer());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getCiltNo())) {
					customerContactMap.put("CILT_NO", tffBasvuruKimlik.getCiltNo());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getAileSiraNo())) {
					customerContactMap.put("AILE_SIRA_NO", tffBasvuruKimlik.getAileSiraNo());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getBireySiraNo())) {
					customerContactMap.put("SIRA_NO", tffBasvuruKimlik.getBireySiraNo());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getMahalleKoy())) {
					customerContactMap.put("MAHALLE_KOY", tffBasvuruKimlik.getMahalleKoy());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getAnneKizlik()) || !StringUtils.isBlank(tffUyeler.getAnneKizlikSoyadi())) {
					customerContactMap.put("ANNE_KIZLIK_SOYADI", nvl(tffBasvuruKimlik.getAnneKizlik(), tffUyeler.getAnneKizlikSoyadi()));
				}

				if (tffUyeler != null && tffUyeler.getCepAlanKod() != null && "".equals(tffUyeler.getCepAlanKod()) && tffUyeler.getCepAlanKod() != null && "".equals(tffUyeler.getCepNumara())) {
					customerContactMap.put("CEP_TEL_KOD", tffUyeler.getCepAlanKod());
					customerContactMap.put("CEP_TEL_NO", tffUyeler.getCepNumara());
				}

				if (tffBasvuruKimlik.getDogumTar() != null) {
					customerContactMap.put("DOGUM_TARIHI", tffBasvuruKimlik.getDogumTar());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getTcKimlikNo())) {
					customerContactMap.put("TCKN", tffBasvuruKimlik.getTcKimlikNo());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getTcKimlikNo())) {
					customerContactMap.put("TCKNO_IN", tffBasvuruKimlik.getTcKimlikNo());
				}

				if (!StringUtils.isBlank(tffBasvuruKimlik.getTcKimlikNo())) {
					customerContactMap.put("TCKNO_OUT", tffBasvuruKimlik.getTcKimlikNo());
				}

				if (tffBasvuruKimlik.getKpsSorguTarihi() != null) {
					customerContactMap.put("KPS_TARIH", tffBasvuruKimlik.getKpsSorguTarihi());
				}

				customerContactMap.put("KANAL_ALT_KOD", "");
				customerContactMap.put("F_KPS", "E");
				customerContactMap.put("YERLESIM_KOD", "I");
				customerContactMap.put("F_NUF", "E");
			}
			else {

				if (!StringUtils.isBlank(tffBasvuruKimlik.getIkinciAd())) {
					customerContactMap.put("IKINCI_ADI", tffBasvuruKimlik.getIkinciAd());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getPasaportNo())) {
					customerContactMap.put("PASAPORT_NO", tffBasvuruKimlik.getPasaportNo());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getAd())) {
					customerContactMap.put("ADI", tffBasvuruKimlik.getAd());
				}
				if (!StringUtils.isBlank(tffBasvuruKimlik.getSoyad())) {
					customerContactMap.put("SOYADI", tffBasvuruKimlik.getSoyad());
				}
				if (tffBasvuruKimlik.getDogumTar() != null) {
					customerContactMap.put("DOGUM_TARIHI", tffBasvuruKimlik.getDogumTar());
				}

				customerContactMap.put("YERLESIM_KOD", "I");

				customerContactMap.put("F_PASAPORT", "E");
			}

			TffBasvuruMeslekiBilgi tffBasvuruMeslekiBilgi = (TffBasvuruMeslekiBilgi) session.get(TffBasvuruMeslekiBilgi.class, iMap.getBigDecimal("TFF_BASVURU_NO"));

			if (tffBasvuruMeslekiBilgi != null) {
				if (!StringUtils.isBlank(tffBasvuruMeslekiBilgi.getCalismaSekli())) {
					customerContactMap.put("CALISMA_SEKLI", tffBasvuruMeslekiBilgi.getCalismaSekli());
				}
				if (!StringUtils.isBlank(tffBasvuruMeslekiBilgi.getMeslek())) {
					customerContactMap.put("MESLEK_KOD", tffBasvuruMeslekiBilgi.getMeslek());
				}
				if (!StringUtils.isBlank(tffBasvuruMeslekiBilgi.getIsyeriAdi())) {
					customerContactMap.put("ISYERI_UNVANI", tffBasvuruMeslekiBilgi.getIsyeriAdi());
				}
				if (!StringUtils.isBlank(tffBasvuruMeslekiBilgi.getIsyeriAdi())) {
					customerContactMap.put("ISYERI_ADI", tffBasvuruMeslekiBilgi.getIsyeriAdi());
				}
				if (!StringUtils.isBlank(tffBasvuruMeslekiBilgi.getEgitimKod())) {
					customerContactMap.put("EGITIM_KOD", tffBasvuruMeslekiBilgi.getEgitimKod());
				}
			}

			int adresIndex = 0;
			boolean adresEkle = false;
			boolean ekstreAdresiSecildi = false;
			for (TffBasvuruAdres tffBasvuruAdres : adreslerList) {
				if ("D".equals(tffBasvuruAdres.getId().getAdresKod())) {
					adresEkle = false;
					if ("E".equals(tffBasvuruAdres.getTeslimatAdresiMi())) {
						if (tffBasvuruAdres.getUyeAdresNo() != null) {
							adresEkle = true;
						}
					}
				}
				else if ("TN".equals(tffBasvuruAdres.getId().getAdresKod()) || "GN".equals(tffBasvuruAdres.getId().getAdresKod())) {
					adresEkle = false;
				}
				else {
					adresEkle = true;
				}

				if (adresEkle) {
					session.refresh(tffBasvuruAdres);
					if ("I".equals(tffBasvuruAdres.getId().getAdresKod())) {
						customerContactMap.put("ADRES_LIST", adresIndex, "ISYERI_UNVANI", customerContactMap.getString("ISYERI_UNVANI"));
					}
					customerContactMap.put("ADRES_LIST", adresIndex, "ADRES_KOD", tffBasvuruAdres.getId().getAdresKod().equals("D") ? "W" : tffBasvuruAdres.getId().getAdresKod());
					customerContactMap.put("ADRES_LIST", adresIndex, "ADRES", tffBasvuruAdres.getAcikAdres());
					customerContactMap.put("ADRES_LIST", adresIndex, "ADRES_IL_KOD", tffBasvuruAdres.getIlKod());
					customerContactMap.put("ADRES_LIST", adresIndex, "ADRES_ILCE_KOD", tffBasvuruAdres.getIlceKod());
					customerContactMap.put("ADRES_LIST", adresIndex, "ULKE_KOD", "TR");
					if ("E".equals(tffBasvuruAdres.getIletisimMi()) && !ekstreAdresiSecildi) {
						customerContactMap.put("ADRES_LIST", adresIndex, "EXTRE_ADRES_KOD_F", "E");
						ekstreAdresiSecildi = true;
					}
					else {
						customerContactMap.put("ADRES_LIST", adresIndex, "EXTRE_ADRES_KOD_F", "H");
					}
					if (!ekstreAdresiSecildi && adreslerList.size() - 1 == adresIndex) {
						customerContactMap.put("ADRES_LIST", adresIndex, "EXTRE_ADRES_KOD_F", "E");
					}
					adresIndex++;
				}
			}

			List<TffBasvuruTelefon> tffBasvuruTelefonListe = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).list();
			int index = 0;
			// cepepepepepep
			for (TffBasvuruTelefon tffBasvuruTelefon : tffBasvuruTelefonListe) {
				customerContactMap.put("TELEFON_LIST", index, "ALAN_KOD", tffBasvuruTelefon.getAlanKod());
				customerContactMap.put("TELEFON_LIST", index, "TEL_NO", tffBasvuruTelefon.getNumara());
				customerContactMap.put("TELEFON_LIST", index, "TEL_TIP", tffBasvuruTelefon.getId().getTip());
				customerContactMap.put("TELEFON_LIST", index, "ULKE_KODU", tffBasvuruTelefon.getUlkeKod());
				customerContactMap.put("TELEFON_LIST", index, "F_ILETISIM", "E".equals(tffBasvuruTelefon.getIletisim()) ? "1" : "0");
				customerContactMap.put("TELEFON_LIST", index, "OTPMI", tffBasvuruTelefon.getId().getTip().equals("3") ? true : false);
				if (tffBasvuruTelefon.getId().getTip().equals("3")) {
					customerContactMap.put("CEP_NUMARA", tffBasvuruTelefon.getNumara());
					customerContactMap.put("CEP_ALAN_KOD", tffBasvuruTelefon.getAlanKod());
					customerContactMap.put("CEP_ULKE_KOD", tffBasvuruTelefon.getUlkeKod());
				}
				index++;
			}
			customerContactMap.put("TRX_ONAYSIZ_ISLEM", CreditCardServicesUtil.EVET);
			customerContactMap.putAll(GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerContactMap));
			return customerContactMap;
		}
		catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF BASVURUDAN MUSTERI GUNCELLEME HATA";
			String mailBody = "hata alan BASVURU bilgileri:";
			mailBody += "BASVURU NO:" + iMap.getString("TFF_BASVURU_NO");
			mailBody += ":  " + e.getMessage();
			mailBody += ":  " + getTraceAsString(e);
			mailBody += "customerContactMap :  " + customerContactMap.toString();
			mailBody += "iMap :  " + iMap.toString();
			sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
			e.printStackTrace();
		}
		oMap.put("RESPONSE", "2");
		oMap.put("RESPONSE_DATA", "Basvuru musteri bilgileri guncellendi");
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_MESLEKI_BILGI_EKLE")
	public static GMMap tffBasvuruMeslekiBilgiEkle(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruMeslekiBilgiTx tffBasvuruMeslekiBilgiTx = (TffBasvuruMeslekiBilgiTx) session.get(TffBasvuruMeslekiBilgiTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruMeslekiBilgiTx == null) {
				tffBasvuruMeslekiBilgiTx = new TffBasvuruMeslekiBilgiTx();
				tffBasvuruMeslekiBilgiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			tffBasvuruMeslekiBilgiTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			tffBasvuruMeslekiBilgiTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruMeslekiBilgiTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriFaaliyetAlani(iMap.getString("ISYER_FAALIYET_ALANI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiAdi(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			tffBasvuruMeslekiBilgiTx.setMeslek(iMap.getString("MESLEK"));
			tffBasvuruMeslekiBilgiTx.setUnvani(iMap.getString("UNVANI"));
			tffBasvuruMeslekiBilgiTx.setEgitimKod(iMap.getString("EGITIM"));
			session.saveOrUpdate(tffBasvuruMeslekiBilgiTx);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-4");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_ISLEM_DETAY_KAYIT")
	public static GMMap basvuruIslemDetayKayit(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			String islemDetayId = UUID.randomUUID().toString().replaceAll("-", "");
			TffislemDetay tffislemDetay = null;

			String islemId = iMap.getString("ISLEM_OID");

			GMMap tMap = new GMMap();
			if (iMap.containsKey("IMAP_REQUEST_DATA")) {
				tMap = (GMMap) iMap.get("IMAP_REQUEST_DATA");
				tMap.remove("FOTO_BYTE_ARRAY");
				tMap.remove("BELGE");
			}
			tffislemDetay = new TffislemDetay();
			tffislemDetay.setOid(islemDetayId);
			tffislemDetay.setIslemId(islemId);
			tffislemDetay.setRequest(new ClobImpl(tMap.toString()));
			tffislemDetay.setRequestIp(iMap.getString("CLIENT_IP"));
			tffislemDetay.setRequestClient(iMap.getString("REQUEST_SESSION"));
			tffislemDetay.setServisAdi(iMap.getString("SERVIS_ADI"));

			tMap.clear();
			if (iMap.containsKey("IMAP_RESPONSE_DATA")) {
				tMap = (GMMap) iMap.get("IMAP_RESPONSE_DATA");
				tMap.remove("FOTO_BYTE_ARRAY");
				tMap.remove("VALID_FOTO_BYTE_ARRAY");
			}
			tffislemDetay.setResponse(new ClobImpl(tMap.toString()));
			tffislemDetay.setEndDate(new Timestamp(System.currentTimeMillis()));

			session.save(tffislemDetay);
			session.flush();

			oMap.put("ISLEM_OID", islemId);
			oMap.put("ISLEM_DETAY_OID", tffislemDetay.getOid());
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_ISLEM_DETAY_KAYIT_GENEL_HATA);

		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_PARAMETRE_LISTESI")
	public static GMMap tffParametreListesi(GMMap iMap) {
		GMMap oMap = new GMMap();

		oMap.put("PARAMETRELER", 0, "TARIH", new SimpleDateFormat("yyyyMMdd").format(new Date()));
		String otpZamanAsimiSuresi = "";
		try {
			String func = "{? = call pkg_trn3801.get_otp_zaman_asimi}";
			otpZamanAsimiSuresi = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.NUMBER));

		}
		catch (Exception e) {
			otpZamanAsimiSuresi = "300";
		}
		oMap.put("PARAMETRELER", 0, "OTP_ZAMAN_ASIMI_SURESI", otpZamanAsimiSuresi);

		String otpDenemeSayisi = "";
		try {
			String func = "{? = call pkg_trn3801.get_otp_dogrulama_uyari_sayisi}";
			otpDenemeSayisi = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.NUMBER));

		}
		catch (Exception e) {
			otpDenemeSayisi = "4";
		}
		oMap.put("PARAMETRELER", 0, "OTP_DENEME_SAYISI", otpDenemeSayisi);

		String kimlikBilgiDenemeSayisi = "";
		try {
			String func = "{? = call pkg_trn3801.get_kara_liste_uyari_sayisi(?)}";
			kimlikBilgiDenemeSayisi = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.NUMBER, BnsprType.NUMBER, new BigDecimal("2")));

		}
		catch (Exception e) {
			kimlikBilgiDenemeSayisi = "4";
		}
		oMap.put("PARAMETRELER", 0, "KIMLIK_BILGI_DENEME_SAYISI", kimlikBilgiDenemeSayisi);
		oMap.put("PARAMETRELER", 0, "KARGO_BEDELI", TffServicesHelper.getKuryeBedeli("S"));
		oMap.put("PARAMETRELER", 0, "KOMISYON_BEDELI", "0.00");
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_ISLEM_KAYIT")
	public static GMMap basvuruIslemKayit(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			if (StringUtils.isEmpty(iMap.getString("ISLEM_OID"))) {
				Tffislem tffIslem = new Tffislem();
				tffIslem.setCepTelNo(iMap.getString("CEP_TEL_NO"));
				tffIslem.setClientIp(iMap.getString("CLIENT_IP"));
				tffIslem.setClientSessionId(iMap.getString("CLIENT_SESSION_ID"));
				tffIslem.setCoreSessionId(iMap.getString("CORE_SESSION_ID"));
				tffIslem.setPasaportNo(iMap.getString("PASAPORT_NO"));
				tffIslem.setSource(iMap.getString("SOURCE"));
				tffIslem.setTckn(iMap.getString("TCKN"));
				tffIslem.setUyruk(iMap.getString("UYRUK"));
				tffIslem.setBasvuruNo(iMap.getString("TFF_BASVURU_NO"));
				tffIslem.setUyeNo(iMap.getString("UYE_NO"));
				tffIslem.setBoundSessionId(iMap.getString("BOUND_SESSION_ID"));
				session.save(tffIslem);
				session.flush();
				iMap.put("ISLEM_OID", tffIslem.getOid());
			}

			oMap.put("ISLEM_OID", iMap.getString("ISLEM_OID"));

			GMMap tMap = GMServiceExecuter.call("BNSPR_TFF_BASVURU_ISLEM_DETAY_KAYIT", iMap);
			oMap.put("ISLEM_DETAY_OID", tMap.getString("ISLEM_DETAY_OID"));

		}
		catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_ISLEM_KAYIT_GENEL_HATA);
		}
		return oMap;
	}

	/**
	 * 3801 kara liste kontrolu
	 * 
	 * 
	 * @param iMap
	 * 
	 *            TCKN
	 *            PASAPORT_NO
	 *            CEP_ULKE_KOD
	 *            CEP_ALAN_KOD
	 *            CEP_NUMARA
	 *            SOURCE
	 * 
	 * @return oMap
	 *         RESPONSE
	 *         RESPONSE_DATA
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_KARA_LISTE_KONTROL")
	public static GMMap tffKaraListeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String pasaportNo = iMap.getString("PASAPORT_NO", "");

			if (StringUtils.isNotEmpty(pasaportNo)) {
				pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			}
			String procStr = "{call BNSPR.PKG_TRN3801.tff_tckn_karaliste_kontrol (?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[8];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = pasaportNo;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.KARA_LISTE_KONTROL_KARA_LISTEDE_HATASI);
			}
		}
		catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.KARA_LISTE_KONTROL_GENEL_HATA);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_PASAPORT_GUNCELLEME")
	public static GMMap pasaportGuncelleme(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		BigDecimal bankaMusteriNo = iMap.getBigDecimal("BANKA_MUSTERI_NO");
		String cepUlkeKod = iMap.getString("CEP_ULKE_KDO");
		String cepAlanKod = iMap.getString("CEP_ALAN_KOD");
		String cepTelKod = iMap.getString("CEP_TEL_NO");

		BigDecimal tckn = iMap.getBigDecimal("TCKN");
		String uyruk = iMap.getString("UYRUK");
		String newPasaportNo = iMap.getString("YENI_PASAPORT_NO");
		String oldPasaportNo = iMap.getString("ESKI_PASAPORT_NO");

		TffUyeler tffUyelerUyruk = new TffUyeler();
		if (!StringUtils.isEmpty(oldPasaportNo)) {
			oldPasaportNo = iMap.getString("ESKI_PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			tffUyelerUyruk = findUye(uyruk, tckn, oldPasaportNo);
		}
		else if (bankaMusteriNo.compareTo(BigDecimal.ZERO) > 0) {

			List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("bankaMusteriNo", bankaMusteriNo)).list();
			tffUyelerUyruk = list.get(0);
		}
		else if (!StringUtils.isEmpty(cepUlkeKod) && !StringUtils.isEmpty(cepAlanKod) && !StringUtils.isEmpty(cepTelKod)) {
			GMMap otpMap = new GMMap();
			otpMap.put("COUNTRY_CODE", cepUlkeKod);
			otpMap.put("AREA_CODE", cepAlanKod);
			otpMap.put("PHONE_NO", cepTelKod);
			otpMap.putAll(GMServiceExecuter.call("BNSPR_CUSTOMER_GET_CUSTOMER_NO_BY_PHONE", otpMap));

			if ("E".equals(otpMap.getString("IS_OTP"))) {
				bankaMusteriNo = otpMap.getBigDecimal("CUSTOMER_NO");
				List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("bankaMusteriNo", bankaMusteriNo)).list();
				tffUyelerUyruk = list.get(0);
			}
		}

		try {

			if (tffUyelerUyruk != null) {
				
				TffUyeler tffUyelerYeni = findUye(uyruk, tckn, newPasaportNo);

				if (tffUyelerYeni !=null){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DESC", TffServicesMessages.UYE_EKLE_UYE_KAYDI_VAR_HATASI);
				}
				else {
			
					
					try{
				      GMMap customerMap = new GMMap();
				      GMMap newCustomerMap = new GMMap();
				      
			          newCustomerMap.put("MUSTERI_NO",tffUyelerUyruk.getBankaMusteriNo());
			          customerMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", newCustomerMap));
			          
			          customerMap.put("PASAPORT_NO", newPasaportNo);
			          customerMap.putAll(GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerMap));
						}
					catch(Exception e){
						e.printStackTrace();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DESC", TffServicesMessages.UYE_EKLE_GENEL_HATA);
						return oMap;
					}
					
					tffUyelerUyruk.setPasaportNo(iMap.getString("YENI_PASAPORT_NO"));
					session.saveOrUpdate(tffUyelerUyruk);
					session.flush();
					logger.error("---------- tffUyeler : pasaport g�ncellendi");
					
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				}

			}

			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DESC", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
			}
		}

		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DESC", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
		}
		return oMap;

	}




	/**
	 * Project : TFF
	 * 
	 * DESC : YENI UYE KAYDI, uye no varsa alanlari gÃ¼ncelleme
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            UYE_NO
	 *            UYRUK
	 *            TCKN
	 *            KIMLIK_TIPI
	 *            KIMLIK_SERI_NO
	 *            PASAPORT_NO
	 *            DOGUM_TARIHI
	 *            KIMLIK_VERILIS_TARIHI
	 *            WEB_DOGUM_TARIHI
	 *            TAKIM
	 *            ANNE_KIZLIK_SOYADI
	 *            CALISMA_SEKLI
	 *            CEP_ULKE_KOD
	 *            CEP_ALAN_KOD
	 *            CEP_NUMARA
	 *            ADI
	 *            SOYADI
	 *            IKINCI_ADI
	 *            DOGUM_TARIHI
	 *            EPOSTA
	 *            CLIENT_IP
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         UYE_NO
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TFF_UYE_EKLE")
	public static GMMap tffUyeEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean goldenGate = false;
		String pasaportNo = iMap.getString("PASAPORT_NO", "");

		if (!StringUtils.isEmpty(pasaportNo)) {
			pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
		}

		try {
			if (StringUtils.isEmpty(iMap.getString("UYE_NO"))) {
				oMap = tffUyeEkleAlanKontrol(iMap);

				if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
					return oMap;
				}

			}
			String verTarihCheck = "H";
			try {
				String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
				verTarihCheck = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, iMap.getString("SOURCE"), BnsprType.STRING, "VER_TAR_CHECK"));

			}
			catch (Exception e) {
				verTarihCheck = "H";
			}
			if ("E".equals(verTarihCheck)) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KARA_LISTE_KONTROL", iMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
					return oMap;
				}
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			if (iMap.getString("UYRUK").equals("TR")) {
				List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn", iMap.getBigDecimal("TCKN"))).list();

				if (list != null && list.size() > 0) {
					iMap.put("UYE_NO", list.get(0).getUyeNo());
				}
			}
			else {
				List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaportNo", pasaportNo)).add(Restrictions.eq("uyruk", iMap.getString("UYRUK"))).list();
				if (list != null && list.size() > 0) {
					iMap.put("UYE_NO", list.get(0).getUyeNo());
				}
			}
			if (StringUtils.isNotEmpty(iMap.getString("UYE_NO"))) {
				tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
				if (tffUyeler == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_UYE_KAYDI_YOK_HATASI);
					return oMap;
				}
				else {

					GMMap customerContactMap = new GMMap();
					customerContactMap.put("SOURCE", iMap.getString("SOURCE"));
					customerContactMap.put("TUR", "TFFKART");
					customerContactMap.put("KAYNAK", "TFF");
					customerContactMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
					customerContactMap.put("ADK_MUSTERISIMI", "H");
					customerContactMap.put("UYRUK_KOD", tffUyeler.getUyruk());
					customerContactMap.put("EMAIL_KISISEL", tffUyeler.getEposta());

					tffUyeler.setCepUlkeKod(iMap.getString("CEP_ULKE_KOD"));
					tffUyeler.setCepAlanKod(iMap.getString("CEP_ALAN_KOD"));
					tffUyeler.setCepNumara(iMap.getString("CEP_NUMARA"));
					tffUyeler.setCepTel(iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));

					if (StringUtils.isEmpty(tffUyeler.getEuptNo())) {
						customerContactMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
						try {
							GMMap euptRegInput = GMServiceExecuter.call("BNSPR_TFF_EUPT_HESABI_OLUSTUR", customerContactMap);
							tffUyeler.setEuptNo(euptRegInput.getString("USERID"));
							// GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", customerContactMap);
							session.saveOrUpdate(tffUyeler);
							session.flush();
						}
						catch (Exception e) {
							String mailFrom = "system@aktifbank.com.tr";
							String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
							String mailSubject = "TFF EUPT YARATMA HATA";
							String mailBody = "hata alan kimlik bilgileri:";
							mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
							if ("TR".equals(tffUyeler.getUyruk())) {
								mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
							}
							else {
								mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
							}
							mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
							mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
							mailBody += ":  " + getTraceAsString(e);
							sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
							e.printStackTrace();
						}

					}
					session.save(tffUyeler);
					session.flush();
					oMap.put("UYE_NO", tffUyeler.getUyeNo());
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
					return oMap;
				}
			}

			GMMap customerContactMap = new GMMap();
			boolean fraudMu = false;
			GMMap kpsMap = new GMMap();

			int minBasvuruYasi = 7;
			try {
				String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
				minBasvuruYasi = Integer.parseInt(String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "MIN_YAS", BnsprType.STRING, "BASVURU_KRITER")));

			}
			catch (Exception e) {
				minBasvuruYasi = 7;
			}
			if (tffUyeler == null) {
				tffUyeler = new TffUyeler();
				GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYELER);
				BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
				tffUyeler.setUyeNo(id);

				if (iMap.getString("UYRUK").equals("TR")) {

					kpsMap.put("TCKN", iMap.getString("TCKN"));
					kpsMap.put("TCK_NO", iMap.getString("TCKN"));
					kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
					if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
						return kpsMap;
					}

					if (StringUtils.isNotEmpty(kpsMap.getString("KPS_YASI")) && kpsMap.getInt("KPS_YASI") < minBasvuruYasi) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
						return oMap;

					}

					// if (StringUtils.isNotEmpty(iMap.getString("NUFUS_VER_TAR")))
					// iMap.put("NUFUS_VER_TAR_2", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					if (StringUtils.isNotEmpty(iMap.getString("WEB_DOGUM_TARIHI"))) {
						iMap.put("WEB_DOGUM_TARIHI2", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("WEB_DOGUM_TARIHI")));
					}
					if ("E".equals(verTarihCheck) && iMap.getString("WEB_DOGUM_TARIHI2") != null && kpsMap.getString("DOGUM_TARIHI") != null && !(iMap.getDate("WEB_DOGUM_TARIHI2").equals(kpsMap.getDate("DOGUM_TARIHI")))) {
						GMMap karaListeMap = new GMMap();
						karaListeMap.put("TCKN", iMap.getString("TCKN"));
						karaListeMap.put("CEP_TEL", iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
						karaListeMap.put("ISLEM_ID", iMap.getString("ISLEM_ID"));
						karaListeMap.put("KILIT_SEBEP", TffServicesMessages.TFF_KARA_LISTE_TCKN_VER_TARIH_HATASI);
						karaListeMap.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
						karaListeMap = GMServiceExecuter.call("WEBEXT_TFF_KARA_LISTEYE_EKLE", karaListeMap);
						if (TffServicesMessages.RESPONSE_BASARISIZ.equals(karaListeMap.getString("RESPONSE"))) {
							karaListeMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							karaListeMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_VERILIS_TARIHI_KARA_LISTE_UYARI);
							return karaListeMap;
						}
						fraudMu = true;
					}
					customerContactMap.putAll(kpsMap);
					customerContactMap.put("TCKN", iMap.getString("TCKN"));
					customerContactMap.put("F_KPS", "E");
					customerContactMap.put("KPS_TARIH", customerContactMap.getDate("SORGU_TARIHI"));
					tffUyeler.setSonKpsTarih(kpsMap.getDate("SORGU_TARIHI"));
					tffUyeler.setTckn(iMap.getBigDecimal("TCKN"));
					tffUyeler.setCinsiyet(kpsMap.getString("CINSIYET"));
					// tffUyeler.setNufusVerilisTarihi(new SimpleDateFormat("yyyyMMdd").parse(StringUtils.isEmpty(iMap.getString("NUFUS_VER_TAR"))?kpsMap.getString("VERILIS_TARIHI"):iMap.getString("NUFUS_VER_TAR")));
					if (StringUtils.isNotEmpty(iMap.getString("NUFUS_VER_TAR")))
						tffUyeler.setNufusVerilisTarihi(new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					else if (StringUtils.isNotEmpty(kpsMap.getString("VERILIS_TARIHI")))
						tffUyeler.setNufusVerilisTarihi(new SimpleDateFormat("yyyyMMdd").parse(kpsMap.getString("VERILIS_TARIHI")));
					else
						tffUyeler.setNufusVerilisTarihi(null);

				}
				else {
					DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyyMMdd");
					DateTime dogumTarihi = new DateTime(formatter.parseDateTime(iMap.getString("WEB_DOGUM_TARIHI")));
					DateTime simdi = new DateTime(Calendar.getInstance().getTime());

					oMap.put("YASI", Years.yearsBetween(dogumTarihi, simdi).getYears());

					if (StringUtils.isNotEmpty(oMap.getString("YASI")) && oMap.getInt("YASI") < minBasvuruYasi) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
						return oMap;

					}

					customerContactMap.put("PASAPORT_NO", StringUtils.deleteWhitespace(pasaportNo));
					customerContactMap.put("AD1", iMap.getString("WEB_ADI"));
					customerContactMap.put("AD2", iMap.getString("WEB_IKINCI_ADI"));
					customerContactMap.put("SOYAD", iMap.getString("WEB_SOYADI"));
					customerContactMap.put("DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));

					tffUyeler.setPasaportNo(StringUtils.deleteWhitespace(pasaportNo));
				}
			}
			customerContactMap.put("UYRUK", iMap.getString("UYRUK"));
			tffUyeler.setAdi(customerContactMap.getString("AD1"));
			tffUyeler.setIkinciAdi(customerContactMap.getString("AD2"));
			tffUyeler.setSoyadi(customerContactMap.getString("SOYAD"));
			if (iMap.getString("CEP_ULKE_KOD") != null && iMap.getString("CEP_ALAN_KOD") != null && iMap.getString("CEP_NUMARA") != null) {
				tffUyeler.setCepTel(iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
				tffUyeler.setCepAlanKod(iMap.getString("CEP_ALAN_KOD"));
				tffUyeler.setCepNumara(iMap.getString("CEP_NUMARA"));
				tffUyeler.setCepUlkeKod(iMap.getString("CEP_ULKE_KOD"));
			}
			tffUyeler.setUyruk(iMap.getString("UYRUK"));

			tffUyeler.setEposta(iMap.getString("EMAIL"));
			tffUyeler.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			tffUyeler.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
			tffUyeler.setKimlikTipi(iMap.getString("KIMLIK_TIPI"));
			tffUyeler.setTakim(iMap.getString("TAKIM"));

			tffUyeler.setDogumTarihi(customerContactMap.getDate("DOGUM_TARIHI"));
			tffUyeler.setSource(iMap.getString("SOURCE"));

			if (!fraudMu) {
				tffUyeler.setAnneKizlikSoyadi(iMap.getString("ANNE_KIZLIK_SOYADI"));
				if (iMap.getString("CEP_ULKE_KOD") != null && iMap.getString("CEP_ALAN_KOD") != null && iMap.getString("CEP_NUMARA") != null) {
					customerContactMap.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
					customerContactMap.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
					customerContactMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
				}
				customerContactMap.put("UYRUK", iMap.getString("UYRUK"));
				customerContactMap.put("EPOSTA", iMap.getString("EMAIL"));
				customerContactMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
				customerContactMap.put("SOURCE", iMap.getString("SOURCE"));
				customerContactMap.put("ILETISIM_TEL_TIP", iMap.getString("ILETISIM_TEL_TIP"));
				GMMap tffUyeMap = new GMMap();
				tffUyeMap.put("TFF_UYELER", tffUyeler);
				try {
					tffUyeMap.putAll(GMServiceExecuter.executeNT("BNSPR_TFF_UYE_KAYDET", tffUyeMap));
				}
				catch (Exception e) {
					e.printStackTrace();
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_OLUSTURMA_HATA);
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					return oMap;
				}
				if (tffUyeler.getBankaMusteriNo() == null) {
					try {
						session.saveOrUpdate(tffUyeler);
						GMMap tMap = GMServiceExecuter.call("BNSPR_TFF_CREATE_CUSTOMER", customerContactMap);
						if (tMap.getBigDecimal("MUSTERI_NO").compareTo(BigDecimal.ZERO) > 0)
							tffUyeler.setBankaMusteriNo(tMap.getBigDecimal("MUSTERI_NO"));
						else {
							String mailFrom = "system@aktifbank.com.tr";
							String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
							String mailSubject = "TFF MUSTERI YARATMA HATA";
							String mailBody = "hata alan kimlik bilgileri:";
							mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
							if ("TR".equals(tffUyeler.getUyruk())) {
								mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
							}
							else {
								mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
							}
							mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
							mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();

							sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_GENEL_HATA);
							return oMap;
						}
					}
					catch (Exception e) {
						String mailFrom = "system@aktifbank.com.tr";
						String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
						String mailSubject = "TFF MUSTERI YARATMA HATA";
						String mailBody = "hata alan kimlik bilgileri:";
						mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
						if ("TR".equals(tffUyeler.getUyruk())) {
							mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
						}
						else {
							mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
						}
						mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
						mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
						mailBody += ":  " + getTraceAsString(e);
						sendMail(mailFrom, mailToParametre, mailSubject, mailBody);

						e.printStackTrace();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_GENEL_HATA);
						return oMap;
					}

				}
				else {
					// mevcut m��teri
					goldenGate = true;

				}

				tffUyeler.setOnaylandiMi(verTarihCheck);

				if (StringUtils.isEmpty(tffUyeler.getEuptNo())) {
					customerContactMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());

					customerContactMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
					try {
						GMMap euptRegInput = GMServiceExecuter.call("BNSPR_TFF_EUPT_HESABI_OLUSTUR", customerContactMap);
						tffUyeler.setEuptNo(euptRegInput.getString("USERID"));
					}
					catch (Exception e) {
						String mailFrom = "system@aktifbank.com.tr";
						String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
						String mailSubject = "TFF EUPT YARATMA HATA";
						String mailBody = "hata alan kimlik bilgileri:";
						mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
						if ("TR".equals(tffUyeler.getUyruk())) {
							mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
						}
						else {
							mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
						}
						mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
						mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
						mailBody += ":  " + getTraceAsString(e);
						sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
						e.printStackTrace();
					}

				}

				oMap.put("UYE_NO", tffUyeler.getUyeNo());
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				oMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());

			}
			else {
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_VERILIS_TARIHI_KARA_LISTE_HATASI);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				tffUyeler.setOnaylandiMi("H");
			}

			session.saveOrUpdate(tffUyeler);
			session.flush();

			if (goldenGate) {
				// GoldenGate Crm Data Feed i�in m��teri tablolar�na sembolik g�ncelleme ge�iliyor (m��teri tablolar�na update ge�ilmezse GoldenGate e yans�m�yor)
				if (tffUyeler.getBankaMusteriNo() != null || tffUyeler.getBankaMusteriNo().compareTo(BigDecimal.ZERO) > 0) {
					GMMap crmMap = new GMMap();
					crmMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
					crmMap = GMServiceExecuter.call("BNSPR_TFF_UPDATE_CUSTOMER_RECORDS_FOR_CRM", crmMap);
				}
			}

			try {
				GMMap kkKontrol = new GMMap();
				kkKontrol.put("UYE_NO", tffUyeler.getUyeNo());
				if(BnsprOceanCommonFunctions.isNewCard(tffUyeler.getBankaMusteriNo().toString(), null, null)){
					kkKontrol =GMServiceExecuter.call("BNSPR_YENI_TFF_UYE_KART_UYGUNLUK_DURUMU", kkKontrol);
				}else{
					kkKontrol = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", kkKontrol);
				}
				for (int i = 0; i < kkKontrol.getSize("KART_UYGUNLUK"); i++) {
					if ("KK".equals(kkKontrol.getString("KART_UYGUNLUK", i, "KART_TIPI"))) {
						oMap.put("KK_ALABILIR_MI", kkKontrol.getString("KART_UYGUNLUK", i, "UYGUNLUK"));
					}
					if ("D".equals(kkKontrol.getString("KART_UYGUNLUK", i, "KART_TIPI"))) {
						oMap.put("D_ALABILIR_MI", kkKontrol.getString("KART_UYGUNLUK", i, "UYGUNLUK"));
					}
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				oMap.put("KK_ALABILIR_MI", "E");
				oMap.put("D_ALABILIR_MI", "E");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_GENEL_HATA);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_UYE_KAYDET")
	public static GMMap tffUyeKaydet(GMMap iMap) {

		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);

			TffUyeler tffUyeler = (TffUyeler) iMap.get("TFF_UYELER");
			session.save(tffUyeler);
			session.flush();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

		return new GMMap();
	}

	@GraymoundService("BNSPR_TFF_EUPT_HESABI_OLUSTUR")
	public static GMMap createEuptRegisterInput(GMMap iMap2) {
		// call eupt service

		GMMap euptMap = new GMMap();
		// euptMap.putAll(GMServiceExecuter.executeNT("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", euptRegInput));
		try {
			GMMap tMap = new GMMap();
			tMap.put("CUSTOMER_NO", iMap2.getString("MUSTERI_NO"));
			tMap.put("NATIONALITY", iMap2.getString("UYRUK"));
			tMap.put("LANGUAGE", iMap2.getString("UYRUK"));
			tMap.put("SIGNUPIP", iMap2.getString("CLIENT_IP"));
			tMap.put("MOBILECOUNTRY", iMap2.getString("CEP_ULKE_KOD", ""));
			tMap.put("MOBILECODE", iMap2.getString("CEP_ALAN_KOD", ""));
			tMap.put("MOBILENUMBER", iMap2.getString("CEP_NUMARA", ""));
			tMap.put("REGCHANNEL", "TFF");
			tMap.put("NICK", tMap.getString("MOBILECOUNTRY") + tMap.getString("MOBILECODE") + tMap.getString("MOBILENUMBER"));
			tMap.put("EMAIL", StringUtils.isBlank(iMap2.getString("EPOSTA")) ? iMap2.getString("UYRUK") + "" + iMap2.getString("TCKN") + iMap2.getString("PASAPORT_NO") + "@passolig.com.tr" : iMap2.getString("EPOSTA"));

			GMMap tMapKps = new GMMap();

			if (iMap2.getString("UYRUK").equals("TR")) {
				tMap.put("GOVID", iMap2.getString("TCKN"));
				tMap.put("MIDNAME", iMap2.getString("AD2"));
				tMap.put("NAME", iMap2.getString("AD1"));
				tMap.put("SURNAME", iMap2.getString("SOYAD"));
				tMap.put("PHONECOUNTRY", "");
				tMap.put("PHONECODE", "");
				tMap.put("PHONENUMBER", "");
				tMap.put("BIRTHDATE", iMap2.getString("DOGUM_TARIHI"));
				tMap.put("COUNTRY", "TR");

				tMapKps.put("NAME", iMap2.getString("AD1"));
				tMapKps.put("SURNAME", iMap2.getString("SOYAD"));
				tMapKps.put("GENDER_CODE", iMap2.getString("CINSIYET"));
				tMapKps.put("MOTHERNAME", iMap2.getString("ANNE_AD"));
				tMapKps.put("FATHERNAME", iMap2.getString("BABA_AD"));
				tMapKps.put("BIRTHPLACE", iMap2.getString("DOGUM_YERI"));
				tMapKps.put("MARITALSTATUS", iMap2.getString("MEDENI_HALI"));
				tMapKps.put("BIRTHDATE", iMap2.getString("DOGUM_TARIHI"));
				tMapKps.put("DISTRICT_CODE", iMap2.getString("ILCE_KODU"));
				tMapKps.put("TOWN_CODE", iMap2.getString("IL_KOD"));
				tMapKps.put("FAMILY_ORDER_NO", iMap2.getString("AILE_SIRA_NO"));
				tMapKps.put("BINDING_NO", iMap2.getString("CILT_KODU"));
				tMapKps.put("REGISTER_NO", "");
				tMapKps.put("ID_ORDER_NO", iMap2.getString("KIMLIK_SIRA_NO", ""));
				tMapKps.put("QUARTER", iMap2.getString("MAHALLE_KOY"));
				tMapKps.put("ID_SERIAL_NO", iMap2.getString("KIMLIK_SERI_NO", ""));
				tMapKps.put("ORDER_NO", iMap2.getString("BIREY_SIRA_NO", ""));
				tMapKps.put("GIVEN_DISTRICT_CODE", "");
				tMapKps.put("GIVEN_PLACE", iMap2.getString("VERILDIGI_ILCE_KODU", ""));
				tMapKps.put("GIVEN_REASON", iMap2.getString("VERILIS_NEDENI", ""));
				tMapKps.put("GIVEN_DATE", iMap2.getString("VERILIS_TARIHI", ""));
				tMapKps.put("DEATH_DATE", "");

			}
			else {
				tMap.put("GOVID", iMap2.getString("PASAPORT_NO"));
				tMap.put("MIDNAME", iMap2.getString("AD2"));
				tMap.put("NAME", iMap2.getString("AD1"));
				tMap.put("SURNAME", iMap2.getString("SOYAD"));
				tMap.put("BIRTHDATE", iMap2.getString("DOGUM_TARIHI"));
				tMap.put("COUNTRY", iMap2.getString("UYRUK"));

				tMapKps.put("NAME", iMap2.getString("AD1"));
				tMapKps.put("MIDNAME", iMap2.getString("AD2"));
				tMapKps.put("SURNAME", iMap2.getString("SOYAD"));
				tMapKps.put("BIRTHDATE", iMap2.getString("DOGUM_TARIHI"));
			}

			tMapKps.put("TC_KIMLIK_NO", tMap.getString("GOVID"));
			tMapKps.put("GOVID", tMap.getString("GOVID"));

			tMap.put("KPSRESULT", tMapKps);
			tMap.put("SESSION_ID", ADCSession.getSessionID());
			euptMap.putAll(GMServiceExecuter.executeNT("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", tMap));
			// euptMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_EUPT_TFF_REGISTRATION_EXECUTE", tMap));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return euptMap;
	}

	/**
	 * Project : TFF
	 * 
	 * DESC : YENI UYE KAYDI, uye no varsa alanlari gÃ¼ncelleme
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            TFF_BASVURU_NO
	 * 
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         TRX_NO
	 * 
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TFF_BULK_BASVURU_YAP")
	public static GMMap tffBulkBasvuruYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		if (tffBasvuru == null) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
			return oMap;
		}
		BigDecimal txNo = null;
		if (StringUtils.isEmpty(iMap.getString("TRX_NO"))) {

			GMMap trxMap = new GMMap();
			trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
			txNo = trxMap.getBigDecimal("TRX_NO");

		}
		else
			txNo = iMap.getBigDecimal("TRX_NO");
		TffBasvuruTx tffBasvuruTx = new TffBasvuruTx();
		tffBasvuruTx.setBasvuruNo(tffBasvuru.getBasvuruNo());
		tffBasvuruTx.setCalismaSekli(tffBasvuru.getCalismaSekli());
		tffBasvuruTx.setDurumKod(tffBasvuru.getDurumKod());
		tffBasvuruTx.setEPosta(tffBasvuru.getEPosta());
		tffBasvuruTx.setEuptUserId(tffBasvuru.getEuptUserId());
		tffBasvuruTx.setKanalKod(tffBasvuru.getKanalKod());
		tffBasvuruTx.setKartTipi(tffBasvuru.getKartTipi());
		tffBasvuruTx.setMusteriNo(tffBasvuru.getMusteriNo());
		tffBasvuruTx.setSessionIp(tffBasvuru.getSessionIp());
		tffBasvuruTx.setTakim(tffBasvuru.getTakim());
		tffBasvuruTx.setTcKimlikNo(tffBasvuru.getTcKimlikNo());
		tffBasvuruTx.setKartNo(tffBasvuru.getKartNo());
		tffBasvuruTx.setKkBasvuruNo(tffBasvuru.getKkBasvuruNo());
		tffBasvuruTx.setKuryeTipi(tffBasvuru.getKuryeTipi());
		tffBasvuruTx.setMusteriNo(tffBasvuru.getMusteriNo());
		tffBasvuruTx.setSource(tffBasvuru.getSource());
		tffBasvuruTx.setTffUyeNo(tffBasvuru.getTffUyeNo());
		tffBasvuruTx.setUrun(tffBasvuru.getUrun());
		tffBasvuruTx.setUrunSahipKodu(tffBasvuru.getUrunSahipKodu());
		tffBasvuruTx.setUrunId(tffBasvuru.getUrunId());
		tffBasvuruTx.setTxNo(txNo);
		session.saveOrUpdate(tffBasvuruTx);
		session.flush();

		TffBasvuruKimlik basvuruKimlik = (TffBasvuruKimlik) session.get(TffBasvuruKimlik.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		TffBasvuruKimlikTx basvuruKimlikTx = new TffBasvuruKimlikTx();
		basvuruKimlikTx.setBasvuruNo(basvuruKimlik.getBasvuruNo());
		basvuruKimlikTx.setUyrukKod(basvuruKimlik.getUyrukKod());
		basvuruKimlikTx.setTcKimlikNo(basvuruKimlik.getTcKimlikNo());
		basvuruKimlikTx.setPasaportNo(basvuruKimlik.getPasaportNo());
		basvuruKimlikTx.setAd(basvuruKimlik.getAd());
		basvuruKimlikTx.setIkinciAd(basvuruKimlik.getIkinciAd());
		basvuruKimlikTx.setSoyad(basvuruKimlik.getSoyad());
		basvuruKimlikTx.setOncekiSoyad(basvuruKimlik.getOncekiSoyad());
		basvuruKimlikTx.setBabaAd(basvuruKimlik.getBabaAd());
		basvuruKimlikTx.setDogumYeri(basvuruKimlik.getDogumYeri());
		basvuruKimlikTx.setDogumTar(basvuruKimlik.getDogumTar());
		basvuruKimlikTx.setAnneKizlik(basvuruKimlik.getAnneKizlik());
		basvuruKimlikTx.setCinsiyet(basvuruKimlik.getCinsiyet());
		basvuruKimlikTx.setMedeniHal(basvuruKimlik.getMedeniHal());
		basvuruKimlikTx.setEsTcKimlikNo(basvuruKimlik.getEsTcKimlikNo());
		basvuruKimlikTx.setKimlikSeriNo(basvuruKimlik.getKimlikSeriNo());
		basvuruKimlikTx.setKimlikSiraNo(basvuruKimlik.getKimlikSiraNo());
		basvuruKimlikTx.setAnneAdi(basvuruKimlik.getAnneAdi());
		basvuruKimlikTx.setNufusIlKod(basvuruKimlik.getNufusIlKod());
		basvuruKimlikTx.setNufusIlceKod(basvuruKimlik.getNufusIlceKod());
		basvuruKimlikTx.setCiltNo(basvuruKimlik.getCiltNo());
		basvuruKimlikTx.setMahalleKoy(basvuruKimlik.getMahalleKoy());
		basvuruKimlikTx.setAileSiraNo(basvuruKimlik.getAileSiraNo());
		basvuruKimlikTx.setBireySiraNo(basvuruKimlik.getBireySiraNo());
		basvuruKimlikTx.setNufusVerTarKps(basvuruKimlik.getNufusVerTarKps());
		basvuruKimlikTx.setNufusVerTar(basvuruKimlik.getNufusVerTar());
		basvuruKimlikTx.setNufusVerYer(basvuruKimlik.getNufusVerYer());
		basvuruKimlikTx.setNufusVerNedeni(basvuruKimlik.getNufusVerNedeni());
		basvuruKimlikTx.setKayipKimlikSeriNo(basvuruKimlik.getKayipKimlikSeriNo());
		basvuruKimlikTx.setKayipKimlikSiraNo(basvuruKimlik.getKayipKimlikSiraNo());
		basvuruKimlikTx.setTxNo(txNo);
		session.saveOrUpdate(basvuruKimlikTx);
		session.flush();
		List<TffBasvuruAdres> adreslerList = session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).list();

		for (TffBasvuruAdres tffBasvuruAdres : adreslerList) {
			TffBasvuruAdresTx basvuruAdresTx = new TffBasvuruAdresTx();
			TffBasvuruAdresTxId id = new TffBasvuruAdresTxId();
			id.setAdresKod(tffBasvuruAdres.getId().getAdresKod());
			id.setTxNo(txNo);
			basvuruAdresTx.setId(id);
			basvuruAdresTx.setAcikAdres(tffBasvuruAdres.getAcikAdres());
			basvuruAdresTx.setBasvuruNo(tffBasvuruAdres.getId().getBasvuruNo());
			basvuruAdresTx.setIletisimMi(tffBasvuruAdres.getIletisimMi());

			if ("H".equals(iMap.getString("TESLIMAT_ADRESI_OLSUN"))) {
				basvuruAdresTx.setTeslimatAdresiMi("H");
			}
			else
				basvuruAdresTx.setTeslimatAdresiMi(tffBasvuruAdres.getTeslimatAdresiMi());
			basvuruAdresTx.setUyeAdresNo(tffBasvuruAdres.getUyeAdresNo());
			basvuruAdresTx.setIlAd(tffBasvuruAdres.getIlAd());
			basvuruAdresTx.setIlceAd(tffBasvuruAdres.getIlceAd());
			basvuruAdresTx.setIlKod(tffBasvuruAdres.getIlKod());
			basvuruAdresTx.setIlceKod(tffBasvuruAdres.getIlceKod());
			session.saveOrUpdate(basvuruAdresTx);
			session.flush();
		}

		TffBasvuruMeslekiBilgi tffBasvuruMeslekiBilgi = (TffBasvuruMeslekiBilgi) session.get(TffBasvuruMeslekiBilgi.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		if (tffBasvuruMeslekiBilgi != null) {
			TffBasvuruMeslekiBilgiTx tffBasvuruMeslekiBilgiTx = new TffBasvuruMeslekiBilgiTx();
			tffBasvuruMeslekiBilgiTx.setTxNo(txNo);
			tffBasvuruMeslekiBilgiTx.setAylikGelir(tffBasvuruMeslekiBilgi.getAylikGelir());
			tffBasvuruMeslekiBilgiTx.setBasvuruNo(tffBasvuruMeslekiBilgi.getBasvuruNo());
			tffBasvuruMeslekiBilgiTx.setCalismaSekli(tffBasvuruMeslekiBilgi.getCalismaSekli());
			tffBasvuruMeslekiBilgiTx.setIsyeriAdi(tffBasvuruMeslekiBilgi.getIsyeriAdi());
			tffBasvuruMeslekiBilgiTx.setIsyeriFaaliyetAlani(tffBasvuruMeslekiBilgi.getIsyeriFaaliyetAlani());
			tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiAdi(tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiAdi());
			tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiIl(tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiIl());
			tffBasvuruMeslekiBilgiTx.setMeslek(tffBasvuruMeslekiBilgi.getMeslek());
			tffBasvuruMeslekiBilgiTx.setUnvani(tffBasvuruMeslekiBilgi.getUnvani());
			tffBasvuruMeslekiBilgiTx.setEgitimKod(tffBasvuruMeslekiBilgi.getEgitimKod());
			session.saveOrUpdate(tffBasvuruMeslekiBilgiTx);
			session.flush();
		}

		List<TffBasvuruTelefon> telefonList = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).list();

		for (TffBasvuruTelefon tffBasVuruTelefon : telefonList) {
			TffBasvuruTelefonTx basvuruTelefonTx = new TffBasvuruTelefonTx();
			TffBasvuruTelefonTxId id = new TffBasvuruTelefonTxId();
			id.setTip(tffBasVuruTelefon.getId().getTip());
			id.setTxNo(txNo);
			basvuruTelefonTx.setAlanKod(tffBasVuruTelefon.getAlanKod());
			basvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			basvuruTelefonTx.setDahili(tffBasVuruTelefon.getDahili());
			basvuruTelefonTx.setId(id);
			basvuruTelefonTx.setIletisim(tffBasVuruTelefon.getIletisim());
			basvuruTelefonTx.setNumara(tffBasVuruTelefon.getNumara());
			basvuruTelefonTx.setUlkeKod(tffBasVuruTelefon.getUlkeKod());
			session.saveOrUpdate(basvuruTelefonTx);
			session.flush();
		}

		oMap.put("TRX_NO", txNo);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_CREATE_CUSTOMER")
	public static GMMap tffCreateCustomer(GMMap iMap) {
		GMMap customerContactMap = new GMMap();

		if ("TR".equals(iMap.getString("UYRUK"))) {
			/*START CREATE CUSTOMER CONTACT*/

			customerContactMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
			customerContactMap.put("ADI", iMap.getString("AD1"));
			customerContactMap.put("SOYADI", iMap.getString("SOYAD"));
			customerContactMap.put("ONCEKI_SOYADI", iMap.getString("KIZLIK_SOYAD"));
			customerContactMap.put("ANNE_ADI", iMap.getString("ANNE_AD"));
			customerContactMap.put("BABA_ADI", iMap.getString("BABA_AD"));
			customerContactMap.put("IKINCI_ADI", iMap.getString("AD2"));
			customerContactMap.put("CINSIYET", iMap.getString("CINSIYET"));
			customerContactMap.put("MEDENI_HAL", iMap.getString("MEDENI_HALI"));
			customerContactMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			customerContactMap.put("NUFUS_IL_KOD", iMap.getString("IL_KODU"));
			customerContactMap.put("NUFUS_ILCE_KOD", iMap.getString("ILCE_KODU"));
			customerContactMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			customerContactMap.put("KIMLIK_SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			customerContactMap.put("NUFUS_VERILIS_TARIHI", iMap.getString("VERILIS_TARIHI"));
			customerContactMap.put("NUF_VERILIS_NEDENI", iMap.getString("VERILIS_NEDENI"));
			customerContactMap.put("NUF_VERILDIGI_YER", iMap.getString("VERILDIGI_ILCE_ADI"));
			customerContactMap.put("NUFUS_CILT_NO", iMap.getString("CILT_KODU"));
			customerContactMap.put("NUFUS_AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
			customerContactMap.put("NUFUS_SIRA_NO", iMap.getString("BIREY_SIRA_NO"));
			customerContactMap.put("NUFUS_MAHALLE", iMap.getString("MAHALLE_KOY"));
			customerContactMap.put("KANAL_ALT_KOD", "");
			customerContactMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));

			customerContactMap.put("CEP_TEL_KOD", iMap.getString("CEP_ALAN_KOD"));
			customerContactMap.put("CEP_TEL_NO", iMap.getString("CEP_NUMARA"));

			customerContactMap.put("DOGUM_IL_KOD", iMap.getString("DOGUM_IL_KODU"));
			customerContactMap.put("DOGUM_TARIHI", iMap.getString("DOGUM_TARIHI"));
			customerContactMap.put("TCKN", iMap.getString("TCKN"));
			customerContactMap.put("TCKNO_IN", iMap.getString("TCKN"));
			customerContactMap.put("TCKNO_OUT", iMap.getString("TCKN"));
			customerContactMap.put("F_KPS", iMap.getString("F_KPS"));
			customerContactMap.put("KPS_TARIH", iMap.getString("KPS_TARIH"));
			customerContactMap.put("EXTRE_ADRES_KOD_F", "E");

		}
		else {
			customerContactMap.put("PASAPORT_NO", iMap.getString("PASAPORT_NO"));
			customerContactMap.put("ADI", iMap.getString("AD1"));
			customerContactMap.put("SOYADI", iMap.getString("SOYAD"));
			customerContactMap.put("DOGUM_TARIHI", iMap.getString("DOGUM_TARIHI"));
		}
		customerContactMap.put("ILETISIM_TEL_TIP", iMap.getString("ILETISIM_TEL_TIP"));
		customerContactMap.put("SOURCE", iMap.getString("SOURCE"));
		customerContactMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
		customerContactMap.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
		customerContactMap.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
		customerContactMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
		customerContactMap.put("UYRUK", iMap.getString("UYRUK"));
		customerContactMap.put("EPOSTA", iMap.getString("EMAIL_KISISEL"));
		customerContactMap.put("KISA_AD", iMap.getString("KISA_AD"));

		customerContactMap.putAll(GMServiceExecuter.call("BNSPR_TRN3801_SAVE_KONTAK_MUSTERI_GERCEK", customerContactMap));
		return customerContactMap;

	}

	/**
	 * 
	 * DESC : DESCRIPTION
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            UYE_NO
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 * 
	 *         ADI
	 *         SOYADI
	 *         IKINCI_ADI
	 *         TCKN
	 *         PASAPORT_NO
	 *         UYRUK
	 *         VERILIS_TARIHI
	 *         EMAIL
	 *         MUSTERI_NO
	 *         EUPT_NO
	 *         KPS_TARIH
	 *         CALISMA_SEKLI
	 *         CEP_TEL
	 *         KIMLIK_TIPI
	 *         KIMLIK_SERI_NO
	 *         ONAYLANDI_MI
	 *         TAKIM
	 *         UYE_NO
	 * 
	 * 
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TFF_UYE_BILGILERI_VER")
	public static GMMap tffUyeBilgileriVer(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean fromCustomerRecord = false;
		GnlMusteri gnlMusteri = null;
		boolean isNewCard = false;
		GMMap infoMap = new GMMap();
		GMMap virtualInfo = new GMMap();
		String pasaportNo = iMap.getString("PASAPORT_NO", "");
		if (!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))) {
			pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
		}

		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			if ("NTS01".equals(iMap.getString("SOURCE")) && StringUtils.isBlank(iMap.getString("UYE_NO"))) {
				tffUyeler = findUye(iMap.getString("UYRUK"), iMap.getBigDecimal("TCKN"), pasaportNo);
			}
			else {
				tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
			}

			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_BILGILERI_VER_UYE_KAYDI_BULUNAMADI_HATASI);
				return oMap;
			}
			
			GMMap musteriBilgiMap = new GMMap();

			if (tffUyeler.getBankaMusteriNo() != null && tffUyeler.getBankaMusteriNo().compareTo(new BigDecimal(0)) > 0) {
				if(BnsprOceanCommonFunctions.isNewCard(tffUyeler.getBankaMusteriNo().toString(), null, null)){
					isNewCard = true;
				}
				gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", tffUyeler.getBankaMusteriNo())).uniqueResult();
				if (gnlMusteri != null) {
					fromCustomerRecord = true;
				}

			}

			if (fromCustomerRecord) {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "ADI", gnlMusteri.getAdi());
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "SOYADI", gnlMusteri.getSoyadi());
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "IKINCI_ADI", gnlMusteri.getIkinciAdi());
				String email = !StringUtils.isEmpty(gnlMusteri.getEmailKisisel()) ? gnlMusteri.getEmailKisisel() : tffUyeler.getEposta();
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "EMAIL", email);

			}
			else {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "ADI", tffUyeler.getAdi());
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "SOYADI", tffUyeler.getSoyadi());
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "IKINCI_ADI", tffUyeler.getIkinciAdi());
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "EMAIL", tffUyeler.getEposta());
			}

			try {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "DOGUM_TARIHI", new SimpleDateFormat("yyyyMMdd").format(tffUyeler.getDogumTarihi()));
			}
			catch (Exception e) {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "DOGUM_TARIHI", "");
			}
			
			 musteriBilgiMap.put("MUSTERI_BILGI", 0, "ANNE_KIZLIK_SOYADI", tffUyeler.getAnneKizlikSoyadi());
			 musteriBilgiMap.put("MUSTERI_BILGI", 0, "OGRENIM_DURUMU", tffUyeler.getOgrenimDurumu());
			 
			try {
				GnlMusteriTelefon gnlMusteriTelefon  = (GnlMusteriTelefon) session.createCriteria(GnlMusteriTelefon.class)
	                    .add(Restrictions.eq("id.musteriNo", tffUyeler.getBankaMusteriNo())).add(Restrictions.eq("otpMi", "E")).uniqueResult();
	         
	         if   (gnlMusteriTelefon != null){
	                 String cepTel =   gnlMusteriTelefon.getUlkeKod()+gnlMusteriTelefon.getAlanKod()+gnlMusteriTelefon.getTelNo();

	     			musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_TEL_NO", cepTel);
	     			musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_ULKE_KOD", gnlMusteriTelefon.getUlkeKod());
	     			musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_ALAN_NO", gnlMusteriTelefon.getAlanKod());
	     			musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_TEL_NUMARA", gnlMusteriTelefon.getTelNo());
	     			
			} 
	         else{
	        	    musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_TEL_NO", tffUyeler.getCepTel());
	                musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_ULKE_KOD", tffUyeler.getCepUlkeKod());
	                musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_ALAN_NO", tffUyeler.getCepAlanKod());
	                musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_TEL_NUMARA", tffUyeler.getCepNumara());
	        	 
	         }
			}
			catch (Exception e) {
				
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_TEL_NO", tffUyeler.getCepTel());
                musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_ULKE_KOD", tffUyeler.getCepUlkeKod());
                musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_ALAN_NO", tffUyeler.getCepAlanKod());
                musteriBilgiMap.put("MUSTERI_BILGI", 0, "CEP_TEL_NUMARA", tffUyeler.getCepNumara());

			}

			

			musteriBilgiMap.put("MUSTERI_BILGI", 0, "EUPT_REF_ID", tffUyeler.getEuptNo());
			try {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "NUFUS_VER_TARIH", new SimpleDateFormat("yyyyMMdd").format(tffUyeler.getNufusVerilisTarihi()));
			}
			catch (Exception e) {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "NUFUS_VER_TARIH", "");
			}

			musteriBilgiMap.put("MUSTERI_BILGI", 0, "CALISMA_SEKLI", tffUyeler.getCalismaSekli());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "TAKIM", tffUyeler.getTakim());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "TCKN", tffUyeler.getTckn());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "PASAPORT_NO", tffUyeler.getPasaportNo());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "UYRUK", tffUyeler.getUyruk());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "UYE_NO", tffUyeler.getUyeNo());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "MUSTERI_NO", tffUyeler.getBankaMusteriNo());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "CINSIYET", tffUyeler.getCinsiyet());
			musteriBilgiMap.put("MUSTERI_BILGI", 0, "KAMPANYA_KATILIM", tffUyeler.getKampanyaKatilim());
			try {
				GMMap kdhMap = new GMMap();
				kdhMap.put("TC_KIMLIK_NO", tffUyeler.getTckn());
				kdhMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
				GMMap kdhKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_GET_KDH_AVAILABILITY", kdhMap);
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "DESTEK_HESAP_ALABILME", kdhKontrol.getString("KDH_AVAILABILITY"));

			}
			catch (Exception e) {
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "DESTEK_HESAP_ALABILME", "H");
			}
			try {
				
				iMap.put("UYE_NO", tffUyeler.getUyeNo());
				iMap.put("DIRECT_CALL", false);
				GMMap kkKontrol = new GMMap();
				kkKontrol.put("UYE_NO", tffUyeler.getUyeNo());
				
				if(isNewCard){
					kkKontrol =GMServiceExecuter.call("BNSPR_YENI_TFF_UYE_KART_UYGUNLUK_DURUMU", kkKontrol);
				}else{
					kkKontrol = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", kkKontrol);
				}
				for (int i = 0; i < kkKontrol.getSize("KART_UYGUNLUK"); i++) {
					if ("KK".equals(kkKontrol.getString("KART_UYGUNLUK", i, "KART_TIPI"))) {
						musteriBilgiMap.put("MUSTERI_BILGI", 0, "KK_ALABILIR_MI", kkKontrol.getString("KART_UYGUNLUK", i, "UYGUNLUK"));
					}
					if ("D".equals(kkKontrol.getString("KART_UYGUNLUK", i, "KART_TIPI"))) {
						musteriBilgiMap.put("MUSTERI_BILGI", 0, "D_ALABILIR_MI", kkKontrol.getString("KART_UYGUNLUK", i, "UYGUNLUK"));
					}
					if ("P".equals(kkKontrol.getString("KART_UYGUNLUK", i, "KART_TIPI"))) {
						musteriBilgiMap.put("MUSTERI_BILGI", 0, "P_ALABILIR_MI", kkKontrol.getString("KART_UYGUNLUK", i, "UYGUNLUK"));
					}
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "KK_ALABILIR_MI", "E");
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "D_ALABILIR_MI", "E");
				musteriBilgiMap.put("MUSTERI_BILGI", 0, "P_ALABILIR_MI", "E");
			}

			List<TffBasvuru> tffBasvuruList = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("tffUyeNo", iMap.getBigDecimal("UYE_NO"))).addOrder(Order.desc("basvuruNo")).list();

			int index = 0;
			BigDecimal maxBasvuru = null;
			for (TffBasvuru tffBasvuru : tffBasvuruList) {
				if (index == 0) {
					maxBasvuru = tffBasvuru.getBasvuruNo();
				}
				TffBasvuruAdres tffBasvuruAdres = (TffBasvuruAdres) session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", tffBasvuru.getBasvuruNo())).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();
				musteriBilgiMap.put("BASVURU_DETAY", index, "TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
				musteriBilgiMap.put("BASVURU_DETAY", index, "TAKIM_KODU", tffBasvuru.getUrunSahipKodu());
				musteriBilgiMap.put("BASVURU_DETAY", index, "URUN_KODU", tffBasvuru.getUrun());

				UrunSahip urunSahip = (UrunSahip) session.createCriteria(UrunSahip.class).add(Restrictions.eq("kod", tffBasvuru.getUrunSahipKodu())).uniqueResult();
				if (urunSahip != null) {

					musteriBilgiMap.put("BASVURU_DETAY", index, "TAKIM_ADI", urunSahip.getAdi());
				}

				musteriBilgiMap.put("BASVURU_DETAY", index, "URUN_ADI", PassoligCardName.getByCode(tffBasvuru.getKartTipi()).getName());

				musteriBilgiMap.put("BASVURU_DETAY", index, "KURYE_TIPI", tffBasvuru.getKuryeTipi());
				musteriBilgiMap.put("BASVURU_DETAY", index, "KART_TIPI", tffBasvuru.getKartTipi());
				if (tffBasvuruAdres != null) {
					musteriBilgiMap.put("BASVURU_DETAY", index, "TESLIMAT_ADRESI_NO", tffBasvuruAdres.getUyeAdresNo());
				}
				else {
					musteriBilgiMap.put("BASVURU_DETAY", index, "TESLIMAT_ADRESI_NO", "");
				}
				musteriBilgiMap.put("BASVURU_DETAY", index, "SOURCE", tffBasvuru.getSource());
				if ("SMS".equals(tffBasvuru.getSource())) {
					GMMap sMap = new GMMap();
					sMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
					sMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
					GMMap odemeMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ODEME_YAPILDI_MI", sMap);
					GMMap fotoMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_FOTO_YUKLENDI_MI", sMap);
					if ("E".equals(odemeMap.getString("ODEME_YAPILDIMI")) && "H".equals(fotoMap.getString("FOTO_YUKLENDIMI"))) {
						musteriBilgiMap.put("BASVURU_DETAY", index, "DURUM", "FOTO_EKSIK");
					}
					else if ("H".equals(odemeMap.getString("ODEME_YAPILDIMI")) && "H".equals(fotoMap.getString("FOTO_YUKLENDIMI"))) {
						musteriBilgiMap.put("BASVURU_DETAY", index, "DURUM", "FOTO");
					}
					else if ("H".equals(odemeMap.getString("ODEME_YAPILDIMI")) && "E".equals(fotoMap.getString("FOTO_YUKLENDIMI"))) {
						musteriBilgiMap.put("BASVURU_DETAY", index, "DURUM", "ODEME_BEKLE");
					}
					else {
						musteriBilgiMap.put("BASVURU_DETAY", index, "DURUM", tffBasvuru.getDurumKod());
					}
				}
				else {
					musteriBilgiMap.put("BASVURU_DETAY", index, "DURUM", tffBasvuru.getDurumKod());
				}
				// skt i�in eklenen yeni alanlar
				// bas�m yipi yenileme ise bu bilgiler d�n�lecek expiredate, cvv2
				// getcardinfo
				if ("ACIK".equals(tffBasvuru.getDurumKod())|| "BASIM".equals(tffBasvuru.getDurumKod()) ){
					infoMap.clear();
					infoMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
					infoMap.put("APPLICATION_NO", tffBasvuru.getBasvuruNo());
					infoMap.put("CARD_BANK_STATUS", OceanConstants.Card_Bank_Status_Open);
				
					if(!isNewCard){
						// �nceki ba�vuru �zerindeki son kart numaras�n� alal�m
						infoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", infoMap);
		
						if (StringUtils.isNotEmpty(infoMap.getString("CARD_DETAIL_INFO", 0, "EN_SON_BASIM")) && (BASIM_TIPI_SANAL_YENILENMIS.equals(infoMap.getString("CARD_DETAIL_INFO", 0, "EN_SON_BASIM")) || BASIM_TIPI_VADE_YENILEME.equals(infoMap.getString("CARD_DETAIL_INFO", 0, "EN_SON_BASIM")))) {
							virtualInfo.clear();
							virtualInfo.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
							virtualInfo.put("CARD_NO", infoMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO"));
							virtualInfo = GMServiceExecuter.call("BNSPR_INTRACARD_GET_VIRTUAL_CARD_INFO", virtualInfo);
							musteriBilgiMap.put("BASVURU_DETAY", index, "SKT", virtualInfo.getString("VIRTUAL_CARD_INFO_LIST", 0, "EXPIRY_DATE"));
							musteriBilgiMap.put("BASVURU_DETAY", index, "CVV", virtualInfo.getString("VIRTUAL_CARD_INFO_LIST", 0, "CVV"));
							musteriBilgiMap.put("BASVURU_DETAY", index, "CARD_NO", virtualInfo.getString("VIRTUAL_CARD_INFO_LIST", 0, "CARD_NO"));
						}
					}else{
						infoMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", infoMap);
						
						if (StringUtils.isNotEmpty(infoMap.getString("CARD_DETAIL_INFO", 0, "EMBOSS_CODE")) && (BASIM_TIPI_SANAL_YENILENMIS.equals(infoMap.getString("CARD_DETAIL_INFO", 0, "EMBOSS_CODE")) || BASIM_TIPI_VADE_YENILEME.equals(infoMap.getString("CARD_DETAIL_INFO", 0, "EMBOSS_CODE")))) {
							virtualInfo.clear();
							virtualInfo.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
							virtualInfo.put("CARD_NO", infoMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO"));
							virtualInfo = GMServiceExecuter.call("BNSPR_GENERAL_GET_VIRTUAL_CARD_INFO", virtualInfo);
							musteriBilgiMap.put("BASVURU_DETAY", index, "SKT", virtualInfo.getString("VIRTUAL_PP_CARD_INFO", 0, "EXPIRY_DATE"));
							musteriBilgiMap.put("BASVURU_DETAY", index, "CVV", virtualInfo.getString("VIRTUAL_PP_CARD_INFO", 0, "CVV2"));
							musteriBilgiMap.put("BASVURU_DETAY", index, "CARD_NO", virtualInfo.getString("VIRTUAL_PP_CARD_INFO", 0, "CARD_NO"));
							musteriBilgiMap.put("BASVURU_DETAY", index, "IBAN", virtualInfo.getString("VIRTUAL_PP_CARD_INFO", 0, "IBAN"));
						}
					}
					}
				index++;
			}
			musteriBilgiMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

			List<TffBasvuruAdres> tffBasvuruAdreslerList = session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", maxBasvuru)).list();
			index = 0;
			for (TffBasvuruAdres uyeAdres : tffBasvuruAdreslerList) {
				musteriBilgiMap.put("ADRES_LISTE", index, "ADRES_TIPI", uyeAdres.getId().getAdresKod());
				musteriBilgiMap.put("ADRES_LISTE", index, "ADRES_RUMUZ", new String());
				musteriBilgiMap.put("ADRES_LISTE", index, "IL_KODU", uyeAdres.getIlKod());
				musteriBilgiMap.put("ADRES_LISTE", index, "IL_ADI", uyeAdres.getIlAd());
				musteriBilgiMap.put("ADRES_LISTE", index, "ILCE_KODU", uyeAdres.getIlceKod());
				musteriBilgiMap.put("ADRES_LISTE", index, "ILCE_ADI", uyeAdres.getIlceAd());
				musteriBilgiMap.put("ADRES_LISTE", index, "ACIK_ADRES", uyeAdres.getAcikAdres());
				musteriBilgiMap.put("ADRES_LISTE", index, "ADRES_NO", uyeAdres.getUyeAdresNo());
				musteriBilgiMap.put("ADRES_LISTE", index, "ILETISIM_ADRESI_MI", uyeAdres.getIletisimMi());
				musteriBilgiMap.put("ADRES_LISTE", index, "IS_MATCHED", uyeAdres.getIsMatched());

				index++;
			}

			List<TffBasvuruMeslekiBilgi> tffBasvuruMeslekiBilgiList = session.createCriteria(TffBasvuruMeslekiBilgi.class).add(Restrictions.eq("basvuruNo", maxBasvuru)).list();
			index = 0;
			for (TffBasvuruMeslekiBilgi tffBasvuruMeslekiBilgi : tffBasvuruMeslekiBilgiList) {
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "AYLIK_GELIR", tffBasvuruMeslekiBilgi.getAylikGelir());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "CALISMA_SEKLI", tffBasvuruMeslekiBilgi.getCalismaSekli());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "ISYERI_ADI", tffBasvuruMeslekiBilgi.getIsyeriAdi());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "ISYERI_FAALIYET_ALANI", tffBasvuruMeslekiBilgi.getIsyeriFaaliyetAlani());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "ISYERI_VERGI_DAIRESI_ADI", tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiAdi());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "ISYERI_VERGI_DAIRESI_ILI", tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiIl());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "MESLEK", tffBasvuruMeslekiBilgi.getMeslek());
				musteriBilgiMap.put("UYE_MESLEKI_BILGI", index, "UNVANI", tffBasvuruMeslekiBilgi.getUnvani());
				index++;
			}

			List<TffBasvuruTelefon> tffUyeTelefonListe = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("id.basvuruNo", maxBasvuru)).list();
			index = 0;
			for (TffBasvuruTelefon tffUyeTelefon : tffUyeTelefonListe) {
				musteriBilgiMap.put("TELEFON_LISTE", index, "ALAN_KOD", tffUyeTelefon.getAlanKod());
				musteriBilgiMap.put("TELEFON_LISTE", index, "TELEFON_NUMARA", tffUyeTelefon.getNumara());
				musteriBilgiMap.put("TELEFON_LISTE", index, "TELEFON_ID", tffUyeTelefon.getId().getBasvuruNo());
				musteriBilgiMap.put("TELEFON_LISTE", index, "TELEFON_TIPI", tffUyeTelefon.getId().getTip());
				musteriBilgiMap.put("TELEFON_LISTE", index, "ULKE_KODU", tffUyeTelefon.getUlkeKod());
				index++;
			}
			musteriBilgiMap.put("TELEFON_LISTE", index, "TEL_TIP", "C");
			musteriBilgiMap.put("TELEFON_LISTE", index, "ALAN_KOD", tffUyeler.getCepAlanKod());
			musteriBilgiMap.put("TELEFON_LISTE", index, "TELEFON_NUMARA", tffUyeler.getCepNumara());
			musteriBilgiMap.put("TELEFON_LISTE", index, "ULKE_KODU", tffUyeler.getCepUlkeKod());
			musteriBilgiMap.put("TELEFON_LISTE", index, "UYE_NO", tffUyeler.getUyeNo());
			musteriBilgiMap.put("TELEFON_LISTE", index, "TELEFON_ID", "");
			musteriBilgiMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

			return musteriBilgiMap;

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_BILGILERI_VER_GENEL_HATA);
			return oMap;
		}

	}

	/*in
	 * KURYE_KOD
	 * TFF_BASVURU_NO
	 * 
	 * out
	 * KURYE_BILGI
	 * 		-TARIH
	 * 		-SAAT
	 * 		-KOD
	 * 		-ACIKLAMA
	 * */
	@GraymoundService("BNSPR_TFF_KURYE_BILGILERI_VER_SS")
	public static GMMap basvuruKuryeBilgileriSS(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).uniqueResult();
			// basim durumundakilerin kuryedeki durumu icin once barkod bilgisini al

			if ("BASIM".equals(tffBasvuru.getDurumKod()) || ("ACIK".equals(tffBasvuru.getDurumKod()) && tffBasvuru.getBasvuruNo().equals(tffBasvuru.getVdBasvuruNo()))) { // ayn� kartla vade yenileme ise durumu ACIK kal�yor, sorgulanabilsin
				logger.info("Kurye bilgilerine bak basvuru no :" + tffBasvuru.getBasvuruNo());
				// SS tarafindan barkod bilgilerini al

				GMMap infoMap = new GMMap();
				infoMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
				infoMap.put("APPLICATION_NO", tffBasvuru.getBasvuruNo());
				infoMap.put("CARD_BANK_STATUS", OceanConstants.Card_Bank_Status_Open);

				// �nceki ba�vuru �zerindeki son kart numaras�n� alal�m
				infoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", infoMap);
				String kartNo = StringUtils.isNotEmpty(infoMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO")) ? infoMap.getString("CARD_DETAIL_INFO", 0, "CARD_NO") : tffBasvuru.getKartNo();

				GMMap kuryeMap = new GMMap();
				kuryeMap.put("KART_NO", kartNo);
				kuryeMap.putAll(GMServiceExecuter.call("BNSPR_SS_KURYE_BILGISI_VER", kuryeMap));
				// Kurye sorgu bilgilerini al
				kuryeMap.put("CARD_NO", kartNo);
				String barcode = kuryeMap.getString("BARKOD_NO");
				if (barcode == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", "Kurye bilgileri alinamadi, barkod bo� ");
					return oMap;
				}
				kuryeMap.put("BAR_CODE", barcode);
				GMMap rMap = new GMMap();
				if ("KK".equals(tffBasvuru.getKartTipi())) {
					rMap.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_COURIER_HISTORY", kuryeMap));
				}
				else {
					rMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_COURIER_HISTORY", kuryeMap));
				}

				int rSize = rMap.getSize("LIST");
				logger.info(" Kurye kayit sayisi: " + rSize);
				for (int i = 0; i < rSize; i++) {
					oMap.put("KURYE_BILGILERI", i, "TARIH", rMap.getString("LIST", i, "TXN_DATE"));
					oMap.put("KURYE_BILGILERI", i, "SAAT", rMap.getString("LIST", i, "TXN_TIME"));
					oMap.put("KURYE_BILGILERI", i, "FIRMA", rMap.getString("LIST", i, "COURIER_CODE"));// kurye fimasinin kodu
					oMap.put("KURYE_BILGILERI", i, "KOD", rMap.getString("LIST", i, "COURIER_SUB_CODE"));// kuryede gonderinin durum kodu
					oMap.put("KURYE_BILGILERI", i, "ACIKLAMA", rMap.getString("LIST", i, "DESCRIPTION"));
				}
			}
		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "Kurye bilgileri alinamadi " + e.getMessage());
			e.printStackTrace();
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KURYE_BILGILERI_VER_EXT")
	public static GMMap basvuruKuryeBilgileriExt(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("TFF_BASVURU_NO"))).uniqueResult();
			// basim durumundakilerin kuryedeki durumu icin once barkod bilgisini al
			if ("BASIM".equals(tffBasvuru.getDurumKod())) {
				logger.info("Kurye bilgilerine bak basvuru no :" + tffBasvuru.getBasvuruNo());
				// SS tarafindan barkod bilgilerini al
				GMMap kuryeMap = new GMMap();
				kuryeMap.put("KART_NO", tffBasvuru.getKartNo());
				kuryeMap.putAll(GMServiceExecuter.call("BNSPR_SS_KURYE_BILGISI_VER", kuryeMap));
				// Kurye sorgu bilgilerini al
				kuryeMap.put("CARD_NO", tffBasvuru.getKartNo());
				String barcode = kuryeMap.getString("BARKOD_NO");
				logger.info(" Kurye takip no: " + barcode);
				String kurye = kuryeMap.getString("KURYE_KOD", "KURYENET");
				logger.info(" Kurye firmasi: " + kurye);
				// gelen barkod ile kurye sorgula
				kuryeMap.put("KURYE_KOD", kurye);
				if (StringUtils.isNotBlank(barcode) && barcode.length() > 12) {
					kuryeMap.put("TAKIP_NO", barcode.substring(0, 12));
				}
				else {
					kuryeMap.put("TAKIP_NO", barcode);
				}
				GMMap rMap = new GMMap();
				rMap.putAll(GMServiceExecuter.call("BNSPR_EXT_GET_KURYE_ISLEM_BILGILERI", kuryeMap));
				int rSize = rMap.getSize("ISLEM_DETAY");
				logger.info(" Kurye kayit sayisi: " + rSize);
				for (int i = 0; i < rSize; i++) {
					oMap.put("KURYE_BILGILERI", i, "TARIH", rMap.getString("ISLEM_DETAY", i, "TARIH"));
					oMap.put("KURYE_BILGILERI", i, "SAAT", rMap.getString("ISLEM_DETAY", i, "SAAT"));
					oMap.put("KURYE_BILGILERI", i, "KOD", rMap.getString("ISLEM_DETAY", i, "KOD"));
					oMap.put("KURYE_BILGILERI", i, "ACIKLAMA", rMap.getString("ISLEM_DETAY", i, "ACIKLAMA"));
				}
			}
		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "Kurye bilgileri alinamadi " + e.getMessage());
			e.printStackTrace();
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KURYE_BILGILERI_VER")
	public static GMMap basvuruKuryeBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kuryeRoute = "SS";
		try {
			try {
				String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
				kuryeRoute = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "KURYE_ROUTE"));
			}
			catch (Exception e) {
				kuryeRoute = "SS";
			}
			if ("EXT".equals(kuryeRoute)) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_TFF_KURYE_BILGILERI_VER_EXT", iMap));
			}
			else {
				oMap.putAll(GMServiceExecuter.call("BNSPR_TFF_KURYE_BILGILERI_VER_SS", iMap));
			}
		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "Kurye bilgileri alinamadi " + e.getMessage());
			e.printStackTrace();
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * 
	 * @author murat.el
	 * @since 17.01.2014
	 * @param iMap
	 *            - Tff basvuru iptal islemi bilgileri<br>
	 *            <li>KART_NO - Kart numarasi
	 * @return Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu <li>RESPONSE_DATA - Islem sonuc mesaji <li>BARKOD_NO - Smartsoft barkod numarasi <li>QR_KOD - Qr Kodu <li>KURYE_KOD - Kurye firmasi kodu
	 */
	@GraymoundService("BNSPR_SS_KURYE_BILGISI_VER")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Kart numarasindan kart sistem bilgisini al
			sorguMap.put("CARD_NO", iMap.get("KART_NO"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CARD_PROPERTIES", sorguMap));
			if ("2".equals(sorguMap.getString("RETURN_CODE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Kart Bilgileri Alinamadi:" + iMap.getString("KART_NO"));
				return oMap;
			}

			// kart tipine gore barkod bilgilerini al
			String kartKanali = sorguMap.getString("DESTINATION");
			String servisAdi = null;
			sorguMap.clear();
			sorguMap.put("CARD_NO", iMap.get("KART_NO"));
			if (iMap.getBoolean("YENI_PAKET_MI") && BnsprOceanCommonFunctions.isCreationOnNewIntegration()) {
				// if (iMap.getBoolean("YENI_PAKET_MI") && BnsprOceanCommonFunctions.isNewCard(null, sorguMap.getString("CARD_NO"), null) || BnsprOceanCommonFunctions.isNoNameFromNewIntegration(sorguMap.getString("CARD_NO")) ) {

				servisAdi = "BNSPR_GENERAL_GET_CARD_BARCODE_QRCODE";
			}
			else {

				if ("O".equals(kartKanali)) {
					servisAdi = "BNSPR_OCEAN_GET_CARD_BARCODE_QRCODE";
				}
				else if ("I".equals(kartKanali)) {
					servisAdi = "BNSPR_INTRACARD_GET_CARD_BARCODE_QRCODE";
				}
				else {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", "Kart Tipi Alinamadi:" + kartKanali);
					return oMap;
				}
			}
			// Sorgula ve sonucu al
			sorguMap.putAll(GMServiceExecuter.call(servisAdi, sorguMap));
			oMap.put("BARKOD_NO", sorguMap.get("BAR_CODE"));
			oMap.put("QR_KOD", sorguMap.get("QR_CODE"));
			logger.info("SS Kurye Kodu: " + sorguMap.get("COURIER_CODE"));
			if (StringUtils.isNotBlank(sorguMap.getString("COURIER_CODE")) && !"0".equals(sorguMap.getString("COURIER_CODE"))) {
				oMap.put("KURYE_KOD", sorguMap.get("COURIER_CODE"));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "Teknik Hata Nedeni ile Kart Bilgileri Alinamadi:" + iMap.getString("KART_NO"));
			return oMap;
		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * 
	 * DESC : DESCRIPTION
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            TRX_NO
	 *            TFF_BASVURU_NO
	 *            UYE_NO
	 *            EUPT_REF_ID
	 *            MUSTERI_NO
	 *            TCKN
	 *            DURUM_KODU
	 *            KULUP_URUN
	 *            KULUP_URUN_SAHIP
	 *            KART_TIPI
	 *            TAKIM
	 *            CALISMA_SEKLI
	 *            EMAIL
	 *            KURYE_TIPI
	 *            CLIENT_IP
	 *            SOURCE
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         TFF_BASVURU_NO
	 *         EUPT_REF_ID
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TFF_SAVE_BASVURU")
	public static GMMap saveBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		// TffBasvuruTx tffBasvuruTx = new TffBasvuruTx();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruTx tffBasvuruTx = (TffBasvuruTx) session.get(TffBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruTx == null)
				tffBasvuruTx = new TffBasvuruTx();
			tffBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tffBasvuruTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruTx.setTffUyeNo(iMap.getBigDecimal("UYE_NO"));
			tffBasvuruTx.setEuptUserId(iMap.getString("EUPT_REF_ID"));
			tffBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			tffBasvuruTx.setTcKimlikNo(iMap.getString("TCKN"));
			tffBasvuruTx.setDurumKod(iMap.getString("DURUM_KODU"));
			tffBasvuruTx.setUrun(iMap.getString("URUN_KODU"));
			tffBasvuruTx.setUrunSahipKodu(iMap.getString("URUN_SAHIP_KODU"));
			tffBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
			tffBasvuruTx.setTakim(iMap.getString("TAKIM"));
			tffBasvuruTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			tffBasvuruTx.setEPosta(iMap.getString("EMAIL"));
			tffBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
			tffBasvuruTx.setSessionIp(iMap.getString("CLIENT_IP"));
			tffBasvuruTx.setSource(iMap.getString("SOURCE"));
			tffBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
			tffBasvuruTx.setKanalKod(iMap.getString("KANAL_KODU"));
			tffBasvuruTx.setClientRefId(iMap.getString("CLIENT_REF_ID"));
			tffBasvuruTx.setKdhIstiyorMu(iMap.getString("DESTEK_HESAP_VAR_MI", "H"));
			tffBasvuruTx.setGiseId(iMap.getString("GISE_ID"));
			tffBasvuruTx.setGiseUser(iMap.getString("GISE_USER"));
			tffBasvuruTx.setUrunId(iMap.getBigDecimal("URUN_ID"));

			// vade yenileme ile y�nlendirilmi� yeni ba�vuru ise ba�vuruya iz kayd� at�yoruz
			if (StringUtils.isNotBlank(iMap.getString("VD_KAYNAK_BASVURU_NO"))) {
				tffBasvuruTx.setVdKaynakBasvuruNo(iMap.getBigDecimal("VD_KAYNAK_BASVURU_NO"));
				tffBasvuruTx.setVdBasvuruMu(iMap.getString("VD_BASVURU_MU", ""));
			}
			if (StringUtils.isNotBlank(iMap.getString("VD_BASVURU_NO"))) {
				tffBasvuruTx.setVdBasvuruNo(iMap.getBigDecimal("VD_BASVURU_NO"));
			}
			session.saveOrUpdate(tffBasvuruTx);

			session.flush();
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-2");
		}

		return oMap;
	}

	/**
	 * 
	 * DESC : UYENIN BASVURUSUNA TESLIMAT ADRESI OLARAK EKLENIR
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            TFF_BASVURU_NO
	 *            ADRES_TIPI
	 *            ADRES_RUMUZ
	 *            IL_KOD
	 *            IL_AD
	 *            ILCE_KOD
	 *            ILCE_AD
	 *            ACIK_ADRES
	 *            SOURCE
	 *            UYE_ADRES_NO
	 *            TESLIMAT_NOKTASI_KODU
	 *            TESLIMAT_ADRESI_MI
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 * 
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TFF_BASVURU_ADRES_EKLE")
	public static GMMap tffBasvuruAdresEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			if (iMap.getString("ACIK_ADRES").length() < 10 || !iMap.getString("ACIK_ADRES").trim().contains(" ")) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
				return oMap;
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_ADRESLER);
			BigDecimal aid = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");

			oMap.put("ADRES_NO", aid);
			GMMap trxMap = new GMMap();
			if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {
				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			}
			TffBasvuruAdresTxId id = new TffBasvuruAdresTxId();
			id.setAdresKod(iMap.getString("ADRES_TIPI"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			TffBasvuruAdresTx tffBasvuruAdresTx = (TffBasvuruAdresTx) session.get(TffBasvuruAdresTx.class, id);
			if (tffBasvuruAdresTx == null) {
				tffBasvuruAdresTx = new TffBasvuruAdresTx();
				tffBasvuruAdresTx.setId(id);
			}
			GnlilceKodPrId iid = new GnlilceKodPrId();

			GnlilKodPr il = (GnlilKodPr) session.createCriteria(GnlilKodPr.class).add(Restrictions.eq("kod", iMap.getString("IL_KOD"))).uniqueResult();
			GnlilceKodPr ilce = (GnlilceKodPr) session.createCriteria(GnlilceKodPr.class).add(Restrictions.and(Restrictions.eq("id.ilceKod", iMap.getString("ILCE_KOD")), Restrictions.eq("id.gnlilKodPr.kod", iMap.getString("IL_KOD")))).uniqueResult();
			if ("E".equals(iMap.getString("ADRES_TIPI"))) {
				if (StringUtils.isBlank(iMap.getString("IL_KOD")) || il == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.EV_IL_BOS_OLAMAZ);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ACIK_ADRES_BOS_OLAMAZ);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ILCE_KOD")) || ilce == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ILCE_BOS_OLAMAZ);
					return oMap;
				}
			}

			if ("I".equals(iMap.getString("ADRES_TIPI"))) {
				if (StringUtils.isBlank(iMap.getString("IL_KOD")) || il == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.IS_IL_BOS_OLAMAZ);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ACIK_ADRES_BOS_OLAMAZ);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ILCE_KOD")) || ilce == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ILCE_BOS_OLAMAZ);
					return oMap;
				}
			}

			if ("D".equals(iMap.getString("ADRES_TIPI"))) {
				if (StringUtils.isBlank(iMap.getString("IL_KOD")) || il == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.DIGER_ADRES_IL_BOS_OLAMAZ);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.DIGER_ADRES_ACIK_ADRES_BOS_OLAMAZ);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ILCE_KOD")) || ilce == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.DIGER_ADRES_ILCE_BOS_OLAMAZ);
					return oMap;
				}
			}

			tffBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruAdresTx.setIlKod(iMap.getString("IL_KOD"));
			tffBasvuruAdresTx.setIlAd(iMap.getString("IL_AD"));
			tffBasvuruAdresTx.setIlceKod(iMap.getString("ILCE_KOD"));
			tffBasvuruAdresTx.setIlceAd(iMap.getString("ILCE_AD"));
			tffBasvuruAdresTx.setAcikAdres(iMap.getString("ACIK_ADRES"));
			tffBasvuruAdresTx.setUyeAdresNo(aid);
			tffBasvuruAdresTx.setTeslimatAdresiMi(iMap.getString("TESLIMAT_ADRESI_MI"));
			tffBasvuruAdresTx.setTeslimatNoktasiKodu(iMap.getString("TESLIMAT_NOKTASI_KODU"));
			tffBasvuruAdresTx.setIletisimMi("E".equals(iMap.getString("ILETISIM_MI")) ? "E" : "H");
			tffBasvuruAdresTx.setIsMatched(iMap.getBigDecimal("IS_MATCHED", BigDecimal.ZERO));
			tffBasvuruAdresTx.setTeslimatAdresiDegistiMi(CreditCardServicesUtil.HAYIR);// Bu servisten hep hayir olarak gelecek.
			session.saveOrUpdate(tffBasvuruAdresTx);
			session.flush();
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-3");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * 
	 * DESC : DESCRIPTION
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            UYE_NO
	 *            TFF_BASVURU_NO
	 *            KART_TIPI
	 *            URUN_KODU
	 *            URUN_SAHIP_KODU
	 *            KIMLIK_SERI_NO
	 *            KIMLIK_SIRA_NO
	 *            ANNE_KIZLIK_SOYADI
	 *            EMAIL
	 *            KREDI_KARTI_EKSTRE_SECIMI
	 *            KREDI_KARTI_EKSTRE_TIPI_EMAIL
	 *            KREDI_KARTI_EKSTRE_TIPI_POSTA
	 *            KREDI_KARTI_EKSTRE_TIPI_SMS
	 *            CALISMA_SEKLI
	 *            AYLIK_GELIR
	 *            ISYERI_ADI
	 *            HESAP_KESIM_TARIHI
	 *            KART_OTOMATIK_ODEME
	 *            YURT_DISI_EKSTRE_TIP
	 *            OGRENIM_DURUMU
	 *            MEVCUT_ADRESTE_OTURMA_SURESI_YIL
	 *            MEVCUT_ADRESTE_OTURMA_SURESI_AY
	 *            ISYERINDE_CALISMA_SURESI_YIL
	 *            ISYERINDE_CALISMA_SURESI_AY
	 *            ISYERI_FAALIYET_ALANI
	 *            UNVANI
	 *            MESLEK
	 *            ISYERI_VERGI_DAIRESI_ADI
	 *            ISYERI_VERGI_DAIRESI_IL
	 *            CEP_ULKE_KOD
	 *            CEP_TEL_KOD
	 *            CEP_TEL_NO
	 *            IS_ULKE_KOD
	 *            IS_TEL_KOD
	 *            IS_TEL_NO
	 *            IS_TEL_DAHILI
	 *            EV_ULKE_KOD
	 *            EV_TEL_KOD
	 *            EV_TEL_NO
	 *            TESLIMAT_ADRES_NO
	 *            EUPT_YARAT
	 *            SOURCE
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         TFF_BASVURU_NO
	 *         EUPT_REF_ID
	 * 
	 *         Company : Aktifbank
	 * 
	 */

	@GraymoundService("BNSPR_TFF_BASVURU_OLUSTUR")
	public static GMMap tffBasvuruOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (!isSourceValid(iMap)) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
			return oMap;
		}

		if (StringUtils.isEmpty(iMap.getString("URUN_KODU"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_URUN_TIPI_TANIMSIZ_HATASI);
			return oMap;
		}
		if (StringUtils.isEmpty(iMap.getString("KART_TIPI"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_URUN_TIPI_TANIMSIZ_HATASI);
			return oMap;
		}
		if (StringUtils.isEmpty(iMap.getString("URUN_SAHIP_KODU"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_URUN_SAHIP_KODU_TANIMSIZ_HATASI);
			return oMap;
		}

		if (StringUtils.isEmpty(iMap.getString("UYE_NO"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_UYE_NO_BOS_HATASI);
			return oMap;
		}

		oMap = tffBasvuruYapAlanKontrol(iMap);
		if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}

		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));

		if (tffUyeler == null) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_UYE_NO_BULUNAMADI_HATASI);
			return oMap;
		}
		/*if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))){
			String kimlikNo = iMap.getString("KIMLIK_SERI_NO") + "-" + iMap.getString("KIMLIK_SIRA_NO");
			if ( !kimlikNo.matches("[A-Z0-9]{3}-[0-9]{6}") ){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_KIMLIK_SERI_NO_YANLIS_HATASI);
				return oMap;
			}
				
			

		}*/// sonra format de�i�ebilir bu nedenle seri s�rano kontrolleri kald�r�ld�

		if (tffUyeler.getBankaMusteriNo() == null) {
			BigDecimal bankaMusteriNo = searchCustomer(tffUyeler.getUyruk(), String.valueOf(tffUyeler.getTckn()), tffUyeler.getPasaportNo());
			if (bankaMusteriNo != null)
				tffUyeler.setBankaMusteriNo(bankaMusteriNo);
			else {
				// musteri yarat
			}
		}
		iMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
		iMap.put("TCKN", tffUyeler.getTckn());
		oMap = GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap);
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		iMap.put("DIRECT_CALL", true);
		GMMap tmpMap = new GMMap();
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", iMap);
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		else {
			int su = tmpMap.getSize("KART_UYGUNLUK");
			for (int i = 0; i < su; i++) {
				String tip = tmpMap.getString("KART_UYGUNLUK", i, "KART_TIPI");
				String uygunluk = tmpMap.getString("KART_UYGUNLUK", i, "UYGUNLUK");
				if (iMap.getString("KART_TIPI").equals(tip) && "H".equals(uygunluk)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					if ("KK".equals(iMap.getString("KART_TIPI"))) {
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
					}
					else if ("D".equals(iMap.getString("KART_TIPI"))) {
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
					}
					else if ("P".equals(iMap.getString("KART_TIPI"))) {
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
					}

					return oMap;
				}
			}

		}

		List<String> adresTipList = new ArrayList<String>();
		adresTipList.add("E");
		adresTipList.add("I");
		/*		List<TffUyeAdresler> adreslerList = session.createCriteria(TffUyeAdresler.class).add(Restrictions.eq("uyeNo", tffUyeler.getUyeNo())).add(Restrictions.in("adresTipi",adresTipList )).list();
				if ( !"NTS01".equals(iMap.getString("SOURCE")) ){
					String evIlKod= "";
					String isIlKod = "";
					
					for (Iterator iterator = adreslerList.iterator(); iterator.hasNext();) {
						TffUyeAdresler tffUyeAdresler = (TffUyeAdresler) iterator.next();
						if (  tffUyeAdresler.getAdresTipi().equals("E")){
							evIlKod = tffUyeAdresler.getIlKodu();
						}
						if (  tffUyeAdresler.getAdresTipi().equals("I")){
							isIlKod = tffUyeAdresler.getIlKodu();
						}
					}
				
					if (  StringUtils.isNotEmpty(iMap.getString("EV_TEL_KOD")) ){
						GMMap kontrol = new GMMap();
						kontrol.put("TEL_ALAN", iMap.getString("EV_TEL_KOD") );
						kontrol.put("IL_KODU",evIlKod);
						if ( !telAlanKodDogrumu(kontrol) ){
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_EV_ALAN_EV_ADRES_UYUMSUZ);
							return oMap;
						}
						
						if(!isPhoneNumberValid(iMap.getString("EV_TEL_NO"))){
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", "Ev telefonu gecersiz");
							return oMap;
						}
						
					}
					if (StringUtils.isNotEmpty(iMap.getString("IS_TEL_KOD")) ){
						GMMap kontrol = new GMMap();
						kontrol.put("TEL_ALAN",iMap.getString("IS_TEL_KOD") );
						kontrol.put("IL_KODU",isIlKod );
						if ( !telAlanKodDogrumu(kontrol) ){
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_IS_ALAN_IS_ADRES_UYUMSUZ);
							return oMap;
						}
						if(!isPhoneNumberValid(iMap.getString("IS_TEL_NO"))){
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", "Is telefonu gecersiz");
							return oMap;
						}
						
					}
				}*/
		GMMap basvuruMap = new GMMap();
		if (StringUtils.isNotEmpty(iMap.getString("TFF_BASVURU_NO"))) {
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
				return oMap;
			}
			if (tffBasvuru.getTffUyeNo() != tffUyeler.getUyeNo()) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_UYESI_FARKLI_HATASI);
				return oMap;
			}
			basvuruMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
		}
		else {
			GMMap tMap = new GMMap();
			tMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_BASVURU_NO", new GMMap()));
			basvuruMap.put("TFF_BASVURU_NO", tMap.getString("ID"));

		}

		if (!TffServicesMessages.KART_TIPI_PREPAID.equals(iMap.getString("KART_TIPI")) && !TffServicesMessages.KART_TIPI_DEBIT.equals(iMap.getString("KART_TIPI")) && !TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_KART_TIPI_TANIMSIZ_HATASI);
			return oMap;
		}

		if (!iMap.containsKey("URUN_ID")) {
			String isUnder18S = "H";
			try {
				boolean isUnder18 = isUnder18(tffUyeler.getDogumTarihi());

				if (isUnder18) {
					isUnder18S = "E";
				}
			}
			catch (Exception e) {

			}
			List<TffSsProductMap> tffSsProductMapList = (List<TffSsProductMap>) session.createCriteria(TffSsProductMap.class).add(Restrictions.eq("kartTipi", iMap.getString("KART_TIPI"))).add(Restrictions.eq("urunSahipKod", iMap.getString("URUN_SAHIP_KODU"))).add(Restrictions.eq("gecerli", "E")).add(Restrictions.eq("under18", isUnder18S)).list();

			TffSsProductMap tffSsProductMap = null;

			if (tffSsProductMapList == null || tffSsProductMapList.size() <= 0) {
				CreditCardServicesUtil.raiseGMError("Urun tak�m e�le�tirilmesi yap�lamad�");
			}
			else {
				tffSsProductMap = (TffSsProductMap) tffSsProductMapList.get(0);
				iMap.put("URUN_ID", tffSsProductMap != null ? tffSsProductMap.getUrunId() : null);

			}
		}

		basvuruMap.put("UYE_NO", tffUyeler.getUyeNo());
		basvuruMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());
		basvuruMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
		basvuruMap.put("TCKN", tffUyeler.getTckn());
		basvuruMap.put("DURUM_KODU", "FOTO");
		basvuruMap.put("TAKIM", tffUyeler.getTakim());
		basvuruMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
		basvuruMap.put("KURYE_TIPI", iMap.getString("KURYE_TIPI"));
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
		basvuruMap.put("KART_TIPI", iMap.getString("KART_TIPI"));
		basvuruMap.put("URUN_KODU", iMap.getString("URUN_KODU"));
		basvuruMap.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
		basvuruMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
		basvuruMap.put("EMAIL", tffUyeler.getEposta());
		basvuruMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
		basvuruMap.put("KIMLIK_SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
		basvuruMap.put("KIMLIK_TIPI", iMap.getString("KIMLIK_TIPI"));
		basvuruMap.put("SOURCE", iMap.getString("SOURCE"));
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
		basvuruMap.put("URUN_ID", iMap.getBigDecimal("URUN_ID"));
		if (StringUtils.isNotEmpty(iMap.getString("KANAL_KODU"))) {
			basvuruMap.put("KANAL_KODU", iMap.getString("KANAL_KODU"));
		}
		else {
			String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
			basvuruMap.put("KANAL_KODU", kanalKodu);
		}

		tffUyeler.setOgrenimDurumu(nvl(iMap.getString("OGRENIM_DURUMU"), tffUyeler.getOgrenimDurumu()));

		GMMap trxMap = new GMMap();
		trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		basvuruMap.put("TRX_NO", trxMap.getString("TRX_NO"));
		iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
		if (StringUtils.isEmpty(iMap.getString("MESLEK"))) {

		}

		GMServiceExecuter.call("BNSPR_TFF_SAVE_BASVURU", basvuruMap);

		/*
		TffUyeMeslekiBilgi tffUyeMeslekiBilgi = (TffUyeMeslekiBilgi)session.get(TffUyeMeslekiBilgi.class, iMap.getBigDecimal("UYE_NO"));
		if (tffUyeMeslekiBilgi == null){
			tffUyeMeslekiBilgi = new TffUyeMeslekiBilgi();
			if ( StringUtils.isEmpty(iMap.getString("MESLEK")) ){
				iMap.put("MESLEK","14");
			}
		}
		else{
			if ( StringUtils.isEmpty(tffUyeMeslekiBilgi.getMeslek()) ){
				iMap.put("MESLEK",nvl(iMap.getString("MESLEK"),"14"));
			}
			else{
				iMap.put("MESLEK",nvl(iMap.getString("MESLEK"),tffUyeMeslekiBilgi.getMeslek()));
			}
		}
		tffUyeMeslekiBilgi.setAylikGelir(nvl(iMap.getBigDecimal("AYLIK_GELIR"),tffUyeMeslekiBilgi.getAylikGelir()));
		tffUyeMeslekiBilgi.setCalismaSekli(nvl(iMap.getString("CALISMA_SEKLI"),tffUyeMeslekiBilgi.getCalismaSekli()));
		tffUyeMeslekiBilgi.setIsyeriAdi(nvl(iMap.getString("ISYERI_ADI"),tffUyeMeslekiBilgi.getIsyeriAdi()));
		tffUyeMeslekiBilgi.setIsyeriFaaliyetAlani(nvl(iMap.getString("ISYERI_FAALIYET_ALANI"),tffUyeMeslekiBilgi.getIsyeriFaaliyetAlani()));
		tffUyeMeslekiBilgi.setIsyeriVergiDairesiAdi(nvl(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"),tffUyeMeslekiBilgi.getIsyeriVergiDairesiAdi()));
		tffUyeMeslekiBilgi.setIsyeriVergiDairesiIl(nvl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"),tffUyeMeslekiBilgi.getIsyeriVergiDairesiIl()));
		tffUyeMeslekiBilgi.setMeslek(nvl(iMap.getString("MESLEK"),tffUyeMeslekiBilgi.getMeslek()));
		tffUyeMeslekiBilgi.setUnvani(nvl(iMap.getString("UNVANI"),tffUyeMeslekiBilgi.getUnvani()));
		tffUyeMeslekiBilgi.setUyeNo(nvl(iMap.getBigDecimal("UYE_NO"),tffUyeMeslekiBilgi.getUyeNo()));
		session.saveOrUpdate(tffUyeMeslekiBilgi);
		session.flush();
		*/
		tffUyeler.setCalismaSekli(nvl(iMap.getString("CALISMA_SEKLI"), tffUyeler.getCalismaSekli()));

		session.saveOrUpdate(tffUyeler);
		session.flush();
		/*		try {
					List<TffUyeTelefon> tffUyeTelefonList =session.createCriteria(TffUyeTelefon.class).add(Restrictions.eq("uyeNo", tffUyeler.getUyeNo())).list();
					TffUyeTelefon uyeEvTelefon = null;
					TffUyeTelefon uyeIsTelefon = null;
					TffUyeTelefon uyeCepTelefon = null;
					
					for (TffUyeTelefon tffUyeTelefon : tffUyeTelefonList) {
						if ( tffUyeTelefon.getTip().equals("E") ){
							uyeEvTelefon = tffUyeTelefon;
						}
						else if ( tffUyeTelefon.getTip().equals("I") ){
							uyeIsTelefon = tffUyeTelefon;
						}
					}
					if ( StringUtils.isNotEmpty(iMap.getString("EV_TEL_NO")) ){
						if (uyeEvTelefon == null){
							uyeEvTelefon = new TffUyeTelefon();
							GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_TELEFON);
							BigDecimal  id= GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
							uyeEvTelefon.setTelefonNo(id);
							uyeEvTelefon.setTip("E");
							uyeEvTelefon.setUyeNo(iMap.getBigDecimal("UYE_NO"));
						}
						uyeEvTelefon.setAlanKod(nvl(iMap.getString("EV_TEL_KOD"),uyeEvTelefon.getAlanKod()));
						uyeEvTelefon.setNumara(nvl(iMap.getString("EV_TEL_NO"),uyeEvTelefon.getNumara()));
						uyeEvTelefon.setUlkeKod(nvl("90",uyeEvTelefon.getUlkeKod()));
						session.saveOrUpdate(uyeEvTelefon);
						session.flush();
					}
					if ( StringUtils.isNotEmpty(iMap.getString("IS_TEL_NO")) ){
						if (uyeIsTelefon == null){
							uyeIsTelefon = new TffUyeTelefon();
							GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_TELEFON);
							BigDecimal  id= GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
							uyeIsTelefon.setTelefonNo(id);
							uyeIsTelefon.setTip("I");
							uyeIsTelefon.setUyeNo(iMap.getBigDecimal("UYE_NO"));
						}
						
						uyeIsTelefon.setAlanKod(nvl(iMap.getString("IS_TEL_KOD"),uyeIsTelefon.getAlanKod()));
						uyeIsTelefon.setNumara(nvl(iMap.getString("IS_TEL_NO"),uyeIsTelefon.getNumara()));
						uyeIsTelefon.setUlkeKod(nvl("90",uyeIsTelefon.getUlkeKod()));
						session.saveOrUpdate(uyeIsTelefon);
						session.flush();
					}
					if ( StringUtils.isNotEmpty(iMap.getString("CEP_TEL_NO")) ){
						if (uyeCepTelefon == null){
							uyeCepTelefon = new TffUyeTelefon();
							GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_TELEFON);
							BigDecimal  id= GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
							uyeCepTelefon.setTelefonNo(id);
							uyeCepTelefon.setTip("C");
							uyeCepTelefon.setUyeNo(iMap.getBigDecimal("UYE_NO"));
						}
						
						uyeCepTelefon.setAlanKod(nvl(iMap.getString("CEP_TEL_KOD"),uyeCepTelefon.getAlanKod()));
						uyeCepTelefon.setNumara(nvl(iMap.getString("CEP_TEL_NO"),uyeCepTelefon.getNumara()));
						uyeCepTelefon.setUlkeKod(nvl(tffUyeler.getCepUlkeKod(),"90"));
						session.saveOrUpdate(uyeCepTelefon);
						session.flush();
					}
					
				}
				catch (Exception e) {
					logger.error(e);
				}*/

		/*		
				
				for (TffUyeAdresler tffUyeAdresler : adreslerList) {
					basvuruMap.put("ADRES_TIPI", tffUyeAdresler.getAdresTipi());
					basvuruMap.put("ADRES_RUMUZ", tffUyeAdresler.getAdresRumuz());
					basvuruMap.put("IL_KOD", tffUyeAdresler.getIlKodu());
					basvuruMap.put("IL_AD", tffUyeAdresler.getIlAdi());
					basvuruMap.put("ILCE_KOD", tffUyeAdresler.getIlceKodu());
					basvuruMap.put("ILCE_AD", tffUyeAdresler.getIlceAdi());
					basvuruMap.put("ACIK_ADRES", tffUyeAdresler.getAcikAdres());
					basvuruMap.put("ILETISIM_MI", tffUyeAdresler.getIletisim());
					
					if ( StringUtils.isNotEmpty(iMap.getString("TESLIMAT_ADRES_NO")) &&  iMap.getBigDecimal("TESLIMAT_ADRES_NO").compareTo(tffUyeAdresler.getAdresNo())==0){
						basvuruMap.put("TESLIMAT_ADRESI_MI","E");
					}
					else{
						basvuruMap.put("TESLIMAT_ADRESI_MI","H");
					}
					basvuruMap.put("UYE_ADRES_NO",tffUyeAdresler.getAdresNo());
					GMServiceExecuter.call("BNSPR_TFF_BASVURU_ADRES_EKLE",basvuruMap);
				}
				
				
				try {
					List<TffUyeTelefon> tffUyeTelefonListe= session.createCriteria(TffUyeTelefon.class).add(Restrictions.eq("uyeNo", iMap.getBigDecimal("UYE_NO"))).list();
					for (TffUyeTelefon tffUyeTelefon:tffUyeTelefonListe) {
						GMMap telefonMap = new GMMap();
						telefonMap.put("TELEFON_TIPI",tffUyeTelefon.getTip());
						if (telefonMap.getString("TELEFON_TIPI").equals(iMap.getString("ILETISIM_TEL_TIP"))){
							telefonMap.put("ILETISIM_MI","E");
							
						}
						else{
							telefonMap.put("ILETISIM_MI","H");
						}
						telefonMap.put("TRX_NO", basvuruMap.getString("TRX_NO"));
						telefonMap.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
						telefonMap.put("NUMARA", tffUyeTelefon.getNumara());
						telefonMap.put("ULKE_KOD", tffUyeTelefon.getUlkeKod());
						telefonMap.put("ALAN_KOD", tffUyeTelefon.getAlanKod());
						GMServiceExecuter.call("BNSPR_TFF_BASVURU_TELEFON_EKLE",telefonMap);
					}
					if(tffUyeler.getCepAlanKod() != null && tffUyeler.getCepNumara() != null){
						GMMap telefonMap = new GMMap();
						telefonMap.put("TELEFON_TIPI","C");
						telefonMap.put("ILETISIM_MI","E");
						telefonMap.put("TRX_NO", basvuruMap.getString("TRX_NO"));
						telefonMap.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
						telefonMap.put("NUMARA", tffUyeler.getCepNumara());
						telefonMap.put("ULKE_KOD", tffUyeler.getCepUlkeKod());
						telefonMap.put("ALAN_KOD", tffUyeler.getCepAlanKod());
						GMServiceExecuter.call("BNSPR_TFF_BASVURU_TELEFON_EKLE",telefonMap);
					}
				}
				catch (Exception e) {
					logger.error(e);
				}
			
				*/

		basvuruMap.put("UYRUK_KOD", tffUyeler.getUyruk());

		if ("TR".equals(tffUyeler.getUyruk())) {
			GMMap kpsMap = new GMMap();
			kpsMap.put("TCKN", tffUyeler.getTckn());
			kpsMap.put("TCK_NO", tffUyeler.getTckn());
			basvuruMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
			if (!"2".equals(basvuruMap.getString("RESPONSE"))) {
				logger.error("KPS HATASI" + basvuruMap.getString("RESPONSE_DATA"));
			}
			iMap.put("F_KPS", "E");
			iMap.put("KPS_TARIH", basvuruMap.getString("SORGU_TARIHI"));
			basvuruMap.put("YABANCI_AD", tffUyeler.getAdi());
			basvuruMap.put("YABANCI_SOYAD", tffUyeler.getSoyadi());
			basvuruMap.put("PASAPORT_NO", tffUyeler.getPasaportNo());
			basvuruMap.put("YABANCI_IKINCI_AD", tffUyeler.getIkinciAdi());
			basvuruMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
		}
		else {

			basvuruMap.put("YABANCI_AD", tffUyeler.getAdi());
			basvuruMap.put("YABANCI_SOYAD", tffUyeler.getSoyadi());
			basvuruMap.put("PASAPORT_NO", tffUyeler.getPasaportNo());
			basvuruMap.put("YABANCI_IKINCI_AD", tffUyeler.getIkinciAdi());
			basvuruMap.put("DOGUM_TARIHI", tffUyeler.getDogumTarihi());

		}

		GMServiceExecuter.call("BNSPR_TFF_BASVURU_KIMLIK_EKLE", basvuruMap);
		/*{
			GMMap basvuruMeslekiMap = new GMMap();
			basvuruMeslekiMap.put("AYLIK_GELIR",tffUyeMeslekiBilgi.getAylikGelir());
			basvuruMeslekiMap.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
			basvuruMeslekiMap.put("TRX_NO", basvuruMap.getString("TRX_NO"));
			basvuruMeslekiMap.put("CALISMA_SEKLI", tffUyeMeslekiBilgi.getCalismaSekli());
			basvuruMeslekiMap.put("ISYERI_ADI", tffUyeMeslekiBilgi.getIsyeriAdi());
			basvuruMeslekiMap.put("ISYER_FAALIYET_ALANI", tffUyeMeslekiBilgi.getIsyeriFaaliyetAlani());
			basvuruMeslekiMap.put("ISYERI_VERGI_DAIRESI_ADI", tffUyeMeslekiBilgi.getIsyeriVergiDairesiAdi());
			basvuruMeslekiMap.put("ISYERI_VERGI_DAIRESI_IL", tffUyeMeslekiBilgi.getIsyeriVergiDairesiIl());
			basvuruMeslekiMap.put("MESLEK", tffUyeMeslekiBilgi.getMeslek());
			basvuruMeslekiMap.put("UNVANI", tffUyeMeslekiBilgi.getUnvani());
			basvuruMeslekiMap.put("EGITIM", tffUyeler.getOgrenimDurumu());
			GMServiceExecuter.call("BNSPR_TFF_BASVURU_MESLEKI_BILGI_EKLE",basvuruMeslekiMap);
		}*/
		if (TffServicesMessages.KART_TIPI_DEBIT.equals(iMap.getString("KART_TIPI"))) {
			// Debit Kontrolleri Eklenecektir
		}
		if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {

			TffKrediKartiBasvuru krediKartiBasvuru = (TffKrediKartiBasvuru) session.get(TffKrediKartiBasvuru.class, basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
			if (krediKartiBasvuru == null)
				krediKartiBasvuru = new TffKrediKartiBasvuru();

			krediKartiBasvuru.setBasvuruNo(basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
			krediKartiBasvuru.setAnneKizlikSoyad(iMap.getString("ANNE_KIZLIK_SOYADI"));
			krediKartiBasvuru.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			krediKartiBasvuru.setBasvuruNo(basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
			krediKartiBasvuru.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			krediKartiBasvuru.setCepTelKod(iMap.getString("CEP_TEL_KOD"));
			krediKartiBasvuru.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			krediKartiBasvuru.setEkstreSecim(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
			krediKartiBasvuru.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
			if ("E".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")) && StringUtils.isBlank(iMap.getString("EMAIL"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.EKSTRE_TIPI_EMAIL_SECILEMEZ);
				return oMap;
			}
			krediKartiBasvuru.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));
			krediKartiBasvuru.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
			krediKartiBasvuru.setEmail(iMap.getString("EMAIL"));
			krediKartiBasvuru.setOtomatikLimitArtimi(iMap.getString("OTOMATIK_LIMIT_ARTIMI", "H"));

			krediKartiBasvuru.setEvTelKod(iMap.getString("EV_TEL_KOD"));
			krediKartiBasvuru.setEvTelNo(iMap.getString("EV_TEL_NO"));
			krediKartiBasvuru.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));

			krediKartiBasvuru.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
			krediKartiBasvuru.setIsTelKod(iMap.getString("IS_TEL_KOD"));
			krediKartiBasvuru.setIsTelNo(iMap.getString("IS_TEL_NO"));
			krediKartiBasvuru.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
			krediKartiBasvuru.setIsyeriVergiDairesiAdi(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			krediKartiBasvuru.setIsyeriVergiDairesiIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			krediKartiBasvuru.setKartOtomatikOdeme(iMap.getString("KART_OTOMATIK_ODEME"));
			krediKartiBasvuru.setKartUzerindekiIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
			krediKartiBasvuru.setMeslekKod(iMap.getString("MESLEK"));
			krediKartiBasvuru.setOgrenimDurumu(iMap.getString("OGRENIM_DURUMU"));
			krediKartiBasvuru.setSource(iMap.getString("SOURCE"));
			krediKartiBasvuru.setTckn(iMap.getBigDecimal("TCKN"));
			// krediKartiBasvuru.setUnvanKod(iMap.getString("UNVANI"));
			krediKartiBasvuru.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
			krediKartiBasvuru.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
			krediKartiBasvuru.setTckn(tffUyeler.getTckn());
			krediKartiBasvuru.setYurtdisiEkstreTipi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
			krediKartiBasvuru.setKartTipi(basvuruMap.getString("KART_TIPI"));

			/*
			List<TffUyeAdresler> tffUyeAdreslerList= session.createCriteria(TffUyeAdresler.class).add(Restrictions.eq("uyeNo", iMap.getBigDecimal("UYE_NO"))).list();
			
			for (TffUyeAdresler tffUyeAdresler : tffUyeAdreslerList) {
				if ( "E".equals(tffUyeAdresler.getAdresTipi()) ){
					
					krediKartiBasvuru.setEvAdresi(tffUyeAdresler.getAcikAdres());
					krediKartiBasvuru.setEvIl(tffUyeAdresler.getIlKodu());
					krediKartiBasvuru.setEvIlce(tffUyeAdresler.getIlceKodu());
					krediKartiBasvuru.setEvPostaKodu(tffUyeAdresler.getPostaKodu());
				}
				else if ("I".equals(tffUyeAdresler.getAdresTipi()) ){
					krediKartiBasvuru.setIsAdresi(tffUyeAdresler.getAcikAdres());
					krediKartiBasvuru.setIsIl(tffUyeAdresler.getIlKodu());
					krediKartiBasvuru.setIsIlce(tffUyeAdresler.getIlceKodu());
					krediKartiBasvuru.setIsPostaKodu(tffUyeAdresler.getPostaKodu());
				}
			}
			*/
			session.save(krediKartiBasvuru);
			session.flush();
		}
		iMap.put("TRX_NAME", "3801");
		oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		// GMServiceExecuter.call("BNSPR_TFF_UPDATE_CUSTOMER", iMap);
		iMap.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
		if ("NTS01".equals(iMap.getString("SOURCE"))) {
			GMServiceExecuter.call("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", iMap);
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
		oMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_URUN_LISTE_SORGULA")
	public static GMMap tffUrunListeSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_basvuru_urun_bilgileri (?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "URUN_SAHIBI";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "URUN_SAHIBI_TIPI";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			oMap.put("PARAMETRELER", 0, "TARIH", new SimpleDateFormat("yyyyMMdd").format(new Date()));
		}
		catch (Exception e) {
			oMap = new GMMap();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_LISTE_SORGULA_GENEL_HATA);
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;

	}

	@GraymoundService("BNSPR_TFF_AKTIF_BASVURU_VAR_MI")
	public static GMMap tffAktifBasvuruVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.tffUyeAktifBasvuruVarmi (?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[12];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("UYE_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TFF_BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("URUN_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("URUN_SAHIP_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KART_TIPI");
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			if (TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
				if (TffServicesMessages.KART_TIPI_DEBIT.equals(iMap.getString("KART_TIPI"))) {
					GMMap dKontrol = new GMMap();
					dKontrol.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
					dKontrol.put("KART_TIPI", TffServicesMessages.KART_TIPI_DEBIT);
					dKontrol = GMServiceExecuter.call("BNSPR_TFF_D_ALABILME_KONTROL", dKontrol);
					if (TffServicesMessages.EVET.equals(dKontrol.getString("D_VERILEBILIR_MI"))) {
						oMap = new GMMap();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
					}
					else {
						oMap = new GMMap();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_KART_MEVCUT_HATASI);
					}

				}
				else if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
					GMMap kkKontrol = new GMMap();
					kkKontrol.put("KK_ALABILIR_MI", true);
					kkKontrol.put("MUST_NO", iMap.getBigDecimal("MUSTERI_NO"));
					kkKontrol.put("TCKN", iMap.getBigDecimal("TCKN"));
					kkKontrol = GMServiceExecuter.call("BNSPR_TFF_KK_ALABILME_KONTROL", kkKontrol);
					if (TffServicesMessages.EVET.equals(kkKontrol.getString("KK_VERILEBILIR_MI"))) {
						oMap = new GMMap();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
					}
					else {
						oMap = new GMMap();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_KART_MEVCUT_HATASI);
					}

				}

				else if (TffServicesMessages.KART_TIPI_PREPAID.equals(iMap.getString("KART_TIPI"))) {
					GMMap dKontrol = new GMMap();
					dKontrol.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
					dKontrol.put("KART_TIPI", TffServicesMessages.KART_TIPI_PREPAID);
					dKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
					dKontrol.put("URUN_KODU", iMap.getString("URUN_KODU"));

					dKontrol = GMServiceExecuter.call("BNSPR_TFF_D_ALABILME_KONTROL", dKontrol);
					if (TffServicesMessages.EVET.equals(dKontrol.getString("D_VERILEBILIR_MI"))) {
						oMap = new GMMap();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
					}
					else {
						oMap = new GMMap();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_KART_MEVCUT_HATASI);
					}
				}
			}

		}
		catch (Exception ex) {
			ex.printStackTrace();
			oMap = new GMMap();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}

		return oMap;
	}/*
		@GraymoundService("BNSPR_TFF_GREEN4_SYNC_OPERATION")
		public static GMMap tffGreen4SyncOperation(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			GMMap keyValueMap = new GMMap();
			
			String func = "{? = call pkg_trn3801.Green4IcinBasvuruBilgi (?)}";
			keyValueMap = DALUtil.callOracleRefCursorFunction(func, "BASVURU_DETAY_LISTE", BnsprType.NUMBER, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if ( keyValueMap.getSize("BASVURU_DETAY_LISTE") > 0 ){
				for (int i = 0; i <keyValueMap.getSize("BASVURU_DETAY_LISTE"); i++) {
					GMMap tkeyValueMap = keyValueMap.getMap("BASVURU_DETAY_LISTE",i);
					Vector<ArrayOfKeyValueOfstringstringKeyValueOfstringstring>  keyValueVector = new Vector<ArrayOfKeyValueOfstringstringKeyValueOfstringstring>();
					for (Iterator iterator = tkeyValueMap.keySet().iterator(); iterator.hasNext();) {
						String key = (String) iterator.next();
						String value = tkeyValueMap.getString(key);
						if ( StringUtils.isNotEmpty(value) )
							keyValueVector.add(new ArrayOfKeyValueOfstringstringKeyValueOfstringstring(key.toLowerCase(Locale.ENGLISH),value));
						
					}
					Green4Service green4 = Green4Service.getGreen4ServiceInstance();
					
					Green[] parameterList=new ArrayOfKeyValueOfstringstringKeyValueOfstringstring[keyValueVector.size()];
					keyValueVector.toArray(parameterList);
					
					if (green4.updateGreen4Contacts(parameterList).isSuccess()){
						logger.info("Success");
					}
					else{
						logger.error("Update contact error:" + iMap.getString("TFF_BASVURU_NO"));
					}
				}
				
			}
		}
		catch (Exception e) {
			logger.error(e);
		}
		return oMap;
		}
		*/

	@GraymoundService("BNSPR_TFF_BASVURU_TELEFON_EKLE")
	public static GMMap tffTelefonEkle(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruTelefonTxId id = new TffBasvuruTelefonTxId();
			// id.setTip(iMap.getString("TELEFON_TIPI"));
			if ("E".equals(iMap.getString("TELEFON_TIPI"))) {
				id.setTip("1");
			}
			else if ("C".equals(iMap.getString("TELEFON_TIPI"))) {
				id.setTip("3");
			}
			else if ("I".equals(iMap.getString("TELEFON_TIPI"))) {
				id.setTip("2");
			}
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			TffBasvuruTelefonTx tffBasvuruTelefonTx = (TffBasvuruTelefonTx) session.get(TffBasvuruTelefonTx.class, id);
			if (tffBasvuruTelefonTx == null) {
				tffBasvuruTelefonTx = new TffBasvuruTelefonTx();
				tffBasvuruTelefonTx.setId(id);
			}

			tffBasvuruTelefonTx.setAlanKod(iMap.getString("ALAN_KOD"));
			tffBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruTelefonTx.setDahili(null);
			tffBasvuruTelefonTx.setIletisim(iMap.getString("ILETISIM_MI", "H"));
			tffBasvuruTelefonTx.setNumara(iMap.getString("NUMARA"));
			tffBasvuruTelefonTx.setUlkeKod(iMap.getString("ULKE_KOD"));

			session.saveOrUpdate(tffBasvuruTelefonTx);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-4");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_KIMLIK_EKLE")
	public static GMMap tffKimlikEkle(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruKimlikTx tffBasvuruKimlikTx = (TffBasvuruKimlikTx) session.get(TffBasvuruKimlikTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruKimlikTx == null) {
				tffBasvuruKimlikTx = new TffBasvuruKimlikTx();
			}

			tffBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tffBasvuruKimlikTx.setUyrukKod(iMap.getString("UYRUK_KOD"));

			if ("TR".equals(tffBasvuruKimlikTx.getUyrukKod())) {
				tffBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
				tffBasvuruKimlikTx.setAd(iMap.getString("AD1"));
				tffBasvuruKimlikTx.setAileSiraNo(iMap.getString("AILE_SIRA_NO"));
				tffBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_AD"));
				tffBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_AD"));
				tffBasvuruKimlikTx.setBireySiraNo(iMap.getString("BIREY_SIRA_NO"));
				tffBasvuruKimlikTx.setCiltNo(iMap.getString("CILT_KODU"));
				tffBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
				tffBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
				tffBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
				tffBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
				tffBasvuruKimlikTx.setIkinciAd(iMap.getString("AD2"));
				tffBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI_NO"));
				tffBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_SIRA_NO"));
				tffBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
				tffBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
				tffBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
				tffBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HALI"));
				tffBasvuruKimlikTx.setNufusIlceKod(iMap.getString("ILCE_KODU"));
				tffBasvuruKimlikTx.setNufusIlKod(iMap.getString("IL_KODU"));
				tffBasvuruKimlikTx.setMahalleKoy(iMap.getString("MAHALLE_KOY"));
				tffBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("VERILIS_NEDENI"));
				tffBasvuruKimlikTx.setNufusVerTar(iMap.getDate("VERILIS_TARIHI"));
				tffBasvuruKimlikTx.setNufusVerTarKps(iMap.getDate("VERILIS_TARIHI"));
				tffBasvuruKimlikTx.setNufusVerYer(iMap.getString("VERILDIGI_ILCE_ADI"));
				tffBasvuruKimlikTx.setOncekiSoyad(iMap.getString("KIZLIK_SOYAD"));
				tffBasvuruKimlikTx.setSoyad(iMap.getString("SOYAD"));
				tffBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TCKNO_OUT"));

				/*
				 * 
				 * 	oMap.put("IL_KODU", ilKodu);
				oMap.put("IL", String.valueOf(kpsDataLog.getKayitIl()));
				
				oMap.put("ILCE_KODU", String.valueOf(kpsDataLog.getKayitIlceKod()));
				oMap.put("ILCE", String.valueOf(kpsDataLog.getKayitIlce()));
				
				//oMap.put("DOGUM_ILCE_KODU", kisiBilgisi.getDogumYerKod());
				
				oMap.put("MAHALLE_KOY", 	kpsDataLog.getKayitCilt());
				oMap.put("CILT_KODU", 		kpsDataLog.getKayitCiltKod());
				oMap.put("CILT", 			kpsDataLog.getKayitCilt());
				oMap.put("AILE_SIRA_NO", 	kpsDataLog.getAileSiraNo());
				 * */
			}
			else {
				String pasaportNo = iMap.getString("PASAPORT_NO", "");
				if (!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))) {
					pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
				}
				tffBasvuruKimlikTx.setAd(iMap.getString("YABANCI_AD"));
				tffBasvuruKimlikTx.setIkinciAd(iMap.getString("YABANCI_IKINCI_AD"));
				tffBasvuruKimlikTx.setPasaportNo(pasaportNo);
				tffBasvuruKimlikTx.setSoyad(iMap.getString("YABANCI_SOYAD"));
				tffBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			}

			session.saveOrUpdate(tffBasvuruKimlikTx);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-5");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KARA_LISTEYE_EKLE")
	public static GMMap tffKaraListeEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String pasaportNo = iMap.getString("PASAPORT_NO", "");
			if (!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))) {
				pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			}
			String procStr = "{call BNSPR.PKG_TRN3801.tff_karaliste_ekle (?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[14];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = pasaportNo;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_TEL_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_ID");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("KILIT_SEBEP");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_IP");

			i = 0;
			Object[] outputValues = new Object[6];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "KARA_LISTE_ID";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			return oMap;
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.KARA_LISTE_EKLE_GENEL_HATA);
			return oMap;

		}

	}

	@GraymoundService("BNSPR_TFF_KK_BASVURU")
	public static GMMap tffKKBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		GMMap kkBasvuruMap = new GMMap();
		kkBasvuruMap.put("TCKN", tffUyeler.getTckn());
		kkBasvuruMap.put("CEP_TEL_NO", tffUyeler.getCepNumara());
		kkBasvuruMap.put("CEP_TEL_KOD", tffUyeler.getCepAlanKod());
		kkBasvuruMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3801_KK_KISA_BASVURU", kkBasvuruMap));
		if (TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			if ("EPOS".equals(tffBasvuru.getSource()) || "NTS02".equals(tffBasvuru.getSource())) {
				KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, oMap.getBigDecimal("BASVURU_NO"));
				if (kkBasvuru != null) {
					// basvurunun durumunu VERI_KONTROL olarak guncellemeliyiz. CC'dan basvuru ilerletilmesin diye
					GMMap tarihceMap = new GMMap();
					tarihceMap.put("BASVURU_NO", kkBasvuru.getBasvuruNo());
					tarihceMap.put("ISLEM_NO", oMap.get("TRX_NO"));
					tarihceMap.put("DURUM_KOD", "VERI_KONTROL");
					tarihceMap.put("ISLEM_ACIKLAMA", "Odeme sonrasi kk basvuru veri kontrol");
					tarihceMap.put("TARIHCE_AKSIYON", "E");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", tarihceMap);

					// Kredi karti basari ile olustu, eventi olustur
					iMap.put("EVENT_TYPE_NO", CreditCardTRN3802Services.EPOS_EVENT_TYPE_NO);
					iMap.put("EVENT_REF_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
					GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
				}
			}
			else {
				kkBasvuruMap.put("TRX_NO", oMap.getString("TRX_NO"));
				kkBasvuruMap.put("BASVURU_NO", oMap.getString("BASVURU_NO"));
				oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3801_KK_TAM_BASVURU", kkBasvuruMap));
			}
		}

		// Islem bittikten sonra onceki kullaniciyi set et.
		GMMap sorguMap = new GMMap();
		sorguMap.put("KULLANICI_KOD", iMap.getString("KULLANICI_KOD"));
		sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
		GMServiceExecuter.call("BNSPR_KK_SET_USER_GLOBALS", sorguMap);

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KK_ALABILME_KONTROL")
	public static GMMap tffKrediKartiAlabilmeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		String krediKartiKontrol = TffServicesMessages.HAYIR;
		logger.info("----------  tffKKAlabilmeKontrol -  MUSTERI_NO : " + iMap.getString("MUST_NO"));
		logger.info("----------  tffKKAlabilmeKontrol -  KART_TIPI : " + "KK");
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			krediKartiKontrol = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "VERILEBILIR_MI", BnsprType.STRING, "KK_KONRTOL"));
		}
		catch (Exception e) {
			krediKartiKontrol = TffServicesMessages.HAYIR;
		}
		if (krediKartiKontrol.equals(TffServicesMessages.HAYIR)) {
			oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
			logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
			return oMap;
		}
		try {
			oMap = GMServiceExecuter.call("BNSPR_TRN3871_KART_VAR_MI", iMap);

			if (oMap.getBoolean("KART_VAR_MI")) {
				if (oMap.getBoolean("KAPAMA_TALEBI_VAR_MI")) {
					oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.UYARI);
				}
				else {
					oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
				}
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
				return oMap;
			}

			GMMap redKontrol = new GMMap();
			redKontrol.put("TCK_NO", iMap.getString("TCKN"));
			redKontrol.put("BASVURU_SONLANDIR", "H");
			oMap = GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL", redKontrol);

			if (TffServicesMessages.HAYIR.equals(oMap.getString("DEVAM"))) {
				oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
				return oMap;
			}

			oMap = GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", redKontrol);
			if (TffServicesMessages.HAYIR.equals(oMap.getString("DEVAM"))) {
				oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
				return oMap;
			}
			//kk m��terisinin telefonuyla yeni bir kk ba�vurusu gelmi� mi?
			GMMap checkKK = new GMMap();
			checkKK.put("TCKN", iMap.getString("TCKN"));
			checkKK.put("MUSTERI_NO",  iMap.getString("MUSTERI_NO"));
			checkKK.put("TEL_NO", iMap.getString("CEP_TEL_NUMARA"));
			checkKK.put("ALAN_KOD", iMap.getString("CEP_ALAN_NO"));
			checkKK.put("ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
			oMap =GMServiceExecuter.call("BNSPR_CHECK_PHONE_FOR_PASSOLIG_APPLICATION", checkKK);
			if(BASKA_KK_MUSTERISI_VAR_HATASI.equals(oMap.getString("RESPONSE"))){
				oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
				return oMap;

			}
			
			
		}
		catch (Exception e) {
			oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
			logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
			return oMap;
		}

		oMap.put("KK_VERILEBILIR_MI", CreditCardServicesUtil.EVET);
		logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_FOTO_YUKLE")
	public static GMMap tffFotoYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			long start = System.currentTimeMillis();
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			String durumKodu = "";
			if (tffBasvuru != null) {
				if (tffBasvuru.getDurumKod().equals("FOTO")) {
					durumKodu = CreditCardTRN3802Services.ODEME;
					iMap.put("DURUM_KODU", CreditCardTRN3802Services.ODEME);
				}
				else if (tffBasvuru.getDurumKod().equals("FOTO_EKSIK")) {
					durumKodu = CreditCardTRN3802Services.VERI_KONTROL;
					iMap.put("DURUM_KODU", CreditCardTRN3802Services.VERI_KONTROL);
				}
				else if (tffBasvuru.getDurumKod().equals("ODEME_BEKLE") && tffBasvuru.getSource().equals("SMS")) {
					GMMap odemeMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ODEME_YAPILDI_MI", iMap);
					if ("E".equals(odemeMap.getString("ODEME_YAPILDIMI"))) {
						durumKodu = CreditCardTRN3802Services.VERI_KONTROL;
						iMap.put("DURUM_KODU", CreditCardTRN3802Services.VERI_KONTROL);
					}
					else if ("H".equals(odemeMap.getString("ODEME_YAPILDIMI"))) {
						durumKodu = CreditCardTRN3802Services.ODEME_BEKLE;
						iMap.put("DURUM_KODU", CreditCardTRN3802Services.ODEME_BEKLE);
					}
				}
				else {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_DURUM_HATASI);
					return oMap;
				}

			}
			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			start = System.currentTimeMillis();
			byte[] bytes = decode64ByteArray(iMap.getString("FOTO_BYTE_ARRAY"));

			start = System.currentTimeMillis();
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, tffBasvuru.getTffUyeNo());
			String kimlikNo = null;
			if (tffUyeler.getTckn() != null && tffUyeler.getTckn().compareTo(BigDecimal.ZERO) > 0) {
				kimlikNo = tffUyeler.getTckn().toString();
			}
			else {
				kimlikNo = tffUyeler.getPasaportNo();
			}

			String basvuruNo = iMap.getString("TFF_BASVURU_NO");
			double fileSize = bytes.length;

			if (fileSize > Integer.valueOf(conf.getProperty("tff-foto-max-size")) * 1024 * 1024) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_BOYUT_HATASI);
				return oMap;
			}
			else {
				start = System.currentTimeMillis();
				GMMap tMap = getFotoValidity(bytes, iMap.getString("SOURCE"));
				if (tMap.getBoolean("VALID_MI", true)) {
					bytes = (byte[]) tMap.get("VALID_FOTO_BYTE_ARRAY");

					oMap.put("VALID_FOTO_BYTE_ARRAY", encode64ByteArray(bytes));
				}
				else {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_YUZ_TANIMA_HATASI);
					return oMap;
				}
				logger.info(" FOTO VALIDITY :" + (System.currentTimeMillis() - start));
			}
			start = System.currentTimeMillis();
			ImageInputStream iis = ImageIO.createImageInputStream(new ByteArrayInputStream(bytes));
			Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);

			ByteArrayInputStream bis = new ByteArrayInputStream(bytes);

			String sourceMimeType = URLConnection.guessContentTypeFromStream(bis);
			GMMap t = new GMMap();
			t.put("image/png", "png");
			t.put("image/jpeg", "jpg");
			String type = "jpg";
			if (t.getString(sourceMimeType).isEmpty()) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_TIPI_TANIMLAMASI_HATASI);
				return oMap;
			}
			else {
				type = t.getString(sourceMimeType);
			}

			String kimlikNoLpad = StringUtil.lPad(kimlikNo, 12);
			// Iterator<?> readers = ImageIO.getImageReadersByFormatName("jpg");

			// ImageIO is a class containing static methods for locating ImageReaders
			// and ImageWriters, and performing simple encoding and decoding.

			ImageReader reader = readers.next();
			// Object source = bis;
			// ImageInputStream iis = ImageIO.createImageInputStream(source);
			reader.setInput(iis, true);
			ImageReadParam param = reader.getDefaultReadParam();

			Image image = reader.read(0, param);
			// got an image file

			String folderPath = ROOT + File.separator + "files";
			String isWindows = "H";

			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				start = System.currentTimeMillis();
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			/*
			try {
				isWindows =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "WINDOWS", BnsprType.STRING, "SISTEM"));
			}
			catch (Exception e) {
				// TODO: handle exception
			}*/

			// isWindows="E";
			if (SystemUtils.IS_OS_WINDOWS) {
				isWindows = "E";
			}
			else {
				isWindows = "H";
			}
			String[] sp = kimlikNoLpad.split("(?<=\\G.{3})");
			File klasor = null;
			boolean isFirst = false;
			String approved = "";
			Runtime runtime = Runtime.getRuntime();
			// folderPath = String.format("/%s/%s/%s/%s/%s/", folderPath,sp[0],sp[1],sp[2],kimlikNo);
			start = System.currentTimeMillis();
			for (int i = 0; i < sp.length - 1 && i < 3; i++) {
				if (TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath, "XXX");
				else
					folderPath = String.format("%s/%s", folderPath, sp[i]);

				klasor = new File(folderPath);
				if (!klasor.exists()) {
					if (isWindows.equals("E"))
						klasor.mkdir();
					else {
						String[] cmdLine = { "mkdir", folderPath };
						Process p = runtime.exec(cmdLine);
						p.waitFor();
					}
				}
			}
			folderPath = String.format("%s/%s", folderPath, kimlikNo);
			klasor = new File(folderPath);
			if (!klasor.exists()) {
				if (isWindows.equals("E"))
					klasor.mkdir();
				else {
					String[] cmdLine = { "mkdir", folderPath };
					Process p = runtime.exec(cmdLine);
					p.waitFor();
				}
				// ilk basvurusu
				isFirst = true;
				approved = String.format("%s/%s", folderPath, conf.getProperty("gise_foto_folder"));
				File app = new File(approved);
				if (isWindows.equals("E"))
					app.mkdirs();
				else {
					String[] cmdLine = { "mkdir", approved };
					Process p = runtime.exec(cmdLine);
					p.waitFor();
				}
			}
			BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
			// bufferedImage is the RenderedImage to be written

			Graphics2D g2 = bufferedImage.createGraphics();
			g2.drawImage(image, null, null);
			start = System.currentTimeMillis();
			File imageFile = new File(folderPath + File.separator + kimlikNo + "_" + basvuruNo + "." + type);
			ImageIO.write(bufferedImage, type, imageFile);
			// ilk basvuru ise yuklenen resim approved klasorune aktarilir
			if (isFirst) {
				start = System.currentTimeMillis();
				File appImage = new File(approved + File.separator + kimlikNo + "." + type);
				ImageIO.write(bufferedImage, type, appImage);
			}

			start = System.currentTimeMillis();
			tffBasvuru.setFotoDurum("T");
			session.save(tffBasvuru);
			session.flush();

			if (tffBasvuru.getSource().equals("SMS")) {
				iMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
				GMMap odemeMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ODEME_YAPILDI_MI", iMap);
				GMMap fotoMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_FOTO_YUKLENDI_MI", iMap);
				if ("SMS".equals(tffBasvuru.getSource()) && "E".equals(odemeMap.getString("ODEME_YAPILDIMI"))) {
					if ("KK".equals(tffBasvuru.getKartTipi()) && tffBasvuru.getKkBasvuruNo() == null) {
						GMMap kkBasvuru = new GMMap();
						kkBasvuru.put("KULLANICI_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", null).getString("KULLANICI_KOD"));
						kkBasvuru.put("UYE_NO", tffBasvuru.getTffUyeNo());
						kkBasvuru.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
						// GMServiceExecuter.execute("BNSPR_TFF_KK_BASVURU", kkBasvuru);
						GMServiceExecuter.executeAsync("BNSPR_TFF_KK_BASVURU", kkBasvuru);
					}
					else if ("KK".equals(tffBasvuru.getKartTipi()) && tffBasvuru.getKkBasvuruNo() != null) {
						GMMap kkMap = new GMMap();
						kkMap.put("BASVURU_NO", tffBasvuru.getKkBasvuruNo());
						// kkMap.put("ISLEM_NO", oMap.get("TRX_NO"));
						kkMap.put("DURUM_KOD", durumKodu);
						kkMap.put("ISLEM_ACIKLAMA", "Eksik/Hatali foto yuklendi");
						kkMap.put("TARIHCE_AKSIYON", "E");
						GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", kkMap);
					}
				}

			}
			else {
				if ("KK".equals(tffBasvuru.getKartTipi()) && tffBasvuru.getKkBasvuruNo() != null && durumKodu == CreditCardTRN3802Services.VERI_KONTROL) {
					GMMap kkMap = new GMMap();
					kkMap.put("BASVURU_NO", tffBasvuru.getKkBasvuruNo());
					// kkMap.put("ISLEM_NO", oMap.get("TRX_NO"));
					kkMap.put("DURUM_KOD", durumKodu);
					kkMap.put("ISLEM_ACIKLAMA", "Eksik/Hatali foto yuklendi");
					kkMap.put("TARIHCE_AKSIYON", "E");
					GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", kkMap);
				}
			}
			logger.info(" FOTO KK DURUM GUNCELLE  :" + (System.currentTimeMillis() - start));
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "BASARILI");

			start = System.currentTimeMillis();
			GMMap durumMap = new GMMap();
			durumMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
			durumMap.put("DURUM_KOD", durumKodu);
			durumMap.put("ISLEM_ACIKLAMA", "Foto eklendi");
			durumMap.put("TARIHCE_AKSIYON", "E");
			GMServiceExecuter.execute("BNSPR_TFF_DURUM_GUNCELLE", durumMap);
			start = System.currentTimeMillis();
			// Veri kontrol havuzuna ekle
			if (CreditCardTRN3802Services.VERI_KONTROL.equals(durumKodu)) {
				GMMap sorguMap = new GMMap();
				sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
				sorguMap.put("KK_BASVURU_NO", tffBasvuru.getKkBasvuruNo());
				sorguMap.put("KART_TIPI", tffBasvuru.getKartTipi());
				sorguMap.put("MUSTERI_NO", tffBasvuru.getMusteriNo());
				sorguMap.put("SOURCE", tffBasvuru.getSource());
				GMServiceExecuter.execute("BNSPR_TRN3805_SAVE_OR_UPDATE_HAVUZ", sorguMap);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
			return oMap;
		}
		try {
			oMap.put("TFF_BASVURU_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
			oMap.put("CRM_TYPE", CrmTypes.MAIN);
			GMServiceExecuter.call("BNSPR_TFF_SEND_APPLICATION_TO_CRM", oMap);
		}
		catch (Exception e) {
			oMap.clear();
			oMap.put("RESPONSE_DATA", TffServicesMessages.CRM_GONDERIM_HATASI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
		}
		return oMap;
	}

	/* @consumer GREEN4
	 * 
	 * Verilen basvuru numarasina ait foto gise fotosu olarak
	 * ilgili klasore kopyalanir
	 * 
	 * @param TFF_BASVURU_NO
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_GISE_FOTO_GUNCELLE")
	public static GMMap onayliFotoGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		String filePath = "";
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, tffBasvuru.getTffUyeNo());
			String kimlikNo = tffBasvuru.getTcKimlikNo();
			if (kimlikNo == null) {
				if (tffUyeler.getTckn() != null && tffUyeler.getTckn().compareTo(BigDecimal.ZERO) > 0) {
					kimlikNo = tffUyeler.getTckn().toString();
				}
				else {
					kimlikNo = tffUyeler.getPasaportNo();
				}
			}
			// Foto pathi al.
			try {
				GMMap fMap = new GMMap();
				fMap.put("KIMLIK_NO", kimlikNo);
				fMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());

				if (logger.isInfoEnabled()) {
					logger.info("Gise icin foto path al  KimlikNo:" + kimlikNo + " BASVURU :" + tffBasvuru.getBasvuruNo());
				}

				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_FOTO_PATH_VER", fMap));
			}
			catch (Exception e) {
				String mailFrom = "system@aktifbank.com.tr";
				String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
				String mailSubject = "TFF FOTO GUNCELLE HATA ";
				String mailBody = "hata alan kimlik bilgileri:";
				mailBody += "<br>" + "BNSPR_TRN3801_FOTO_PATH_VER: patladi";
				mailBody += "<br>" + "BASVURU_NO:" + iMap.getBigDecimal("TFF_BASVURU_NO");
				mailBody += "<br>" + "HATA :" + e.getMessage();
				StringWriter sw = new StringWriter();
				e.printStackTrace(new PrintWriter(sw));
				mailBody += "<br>" + "TRACE :" + sw.toString();

				sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
				filePath = null;
				logger.error("Gise foto guncellme icin path alinamadi. KimlikNo:" + kimlikNo + " BASVURU :" + tffBasvuru.getBasvuruNo());
				logger.error(e.getMessage());
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GISE_FOTO_GUNCELLENEMEDI);
				return oMap;
			}

			// Foto pathi hatali isec default deger ata, yoksa pathi al.
			if (oMap.getInt("RESPONSE") == 1 || oMap.get("PATH") == null) {
				filePath = null;
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GISE_FOTO_GUNCELLENEMEDI);
				return oMap;

			}
			else {
				// filePath = "C:" + oMap.getString("PATH");
				filePath = oMap.getString("PATH");
				logger.info("----onayliFotoGuncelle - filePath :" + filePath);
				File img = new File(filePath);
				logger.info("----onayliFotoGuncelle - img  :" + img.canRead());
				logger.info("----onayliFotoGuncelle - img canRead :" + img.canRead());
				String parentFolder = img.getParent();
				String ext = TffServicesHelper.getFotoExtension(img.getAbsolutePath());
				logger.info("----onayliFotoGuncelle - ext :" + ext);
				String fName = conf.getProperty("gise_foto_folder", "APPROVED");
				logger.info("----onayliFotoGuncelle - fName :" + fName);
				String approvedFolderPath = String.format("%s/%s/", parentFolder, fName);
				File appF = new File(approvedFolderPath);
				if (!appF.exists()) {
					boolean res = createApprovedFolder(appF);
					logger.info("----onayliFotoGuncelle - createApprovedFolder  :" + res);
				}
				String giseFotoPath = String.format("%s/%s/%s.%s", parentFolder, fName, kimlikNo, ext);
				logger.info("----onayliFotoGuncelle - giseFotoPath :" + giseFotoPath);
				File finalFoto = new File(giseFotoPath);
				try {
					logger.info("----onayliFotoGuncelle - finalFoto canRead :" + finalFoto.canRead());
					logger.info("----onayliFotoGuncelle - finalFoto canWrite :" + finalFoto.canWrite());
				}
				catch (Exception e) {
					// kesme log bas
					logger.info("----onayliFotoGuncelle - finalFoto canWrite ya da canWrite hata var. security manager hatasi");
				}
				boolean delResult = TffServicesHelper.deleteFile(finalFoto);
				if (!delResult) {
					logger.info("----onayliFotoGuncelle - finalFoto silinemedi");
				}
				boolean result = TffServicesHelper.copyFile(img, finalFoto);
				logger.info("----onayliFotoGuncelle - result :" + result);
				if (result) {
					byte[] imageInByte;

					if (!finalFoto.exists() || !finalFoto.isFile()) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
						return oMap;
					}

					BufferedImage originalImage = ImageIO.read(finalFoto);

					// convert BufferedImage to byte array
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ImageIO.write(originalImage, "jpg", baos);
					baos.flush();
					imageInByte = baos.toByteArray();
					baos.close();

					oMap.put("PATH", finalFoto.getAbsolutePath());
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				}
				else {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.GISE_FOTO_GUNCELLENEMEDI);
					return oMap;
				}
			}

		}
		catch (Exception e) {
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF FOTO GUNCELLE HATA";
			String mailBody = "hata alan basvuru bilgileri:";
			mailBody += "<br>" + "BASVURU_NO:" + iMap.getBigDecimal("TFF_BASVURU_NO");
			mailBody += "<br>" + "HATA :" + e.getMessage();
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			mailBody += "<br>" + "TRACE :" + sw.toString();
			sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GISE_FOTO_GUNCELLENEMEDI);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_YENI_TFF_UYE_KART_UYGUNLUK_DURUMU")
	public static GMMap uyeKartUygunlukDurumu(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			String pasaportNo = iMap.getString("PASAPORT_NO", "");
			if (!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))) {
				pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			if (("NTS02".equals(iMap.getString("SOURCE")) || "NTS01".equals(iMap.getString("SOURCE"))) && StringUtils.isBlank(iMap.getString("UYE_NO"))) {
				tffUyeler = findUye(iMap.getString("UYRUK"), iMap.getBigDecimal("TCKN"), pasaportNo);

			}
			else {
				tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
			}

			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_BILGILERI_VER_UYE_KAYDI_BULUNAMADI_HATASI);
				return oMap;
			}

			int index = 0;
			boolean onSekizYasKontrolu = false;
			if ("EPOS".equals(iMap.getString("SOURCE")) && iMap.containsKey("DIRECT_CALL")) {
				GMServiceExecuter.execute("BNSPR_TFF_BUS_CANCEL_PREVIOUS_APPLICATIONS", iMap);
			}
			if (!isUnder18(tffUyeler.getDogumTarihi())) {
				onSekizYasKontrolu = true;
			}
			GMMap tMap = new GMMap();

			tMap.put("UYE_NO", iMap.getBigDecimal("UYE_NO", tffUyeler.getUyeNo()));
			logger.info("----------  uyeKartAlabilirlikDurumu -  uyeNo : " + iMap.getBigDecimal("UYE_NO"));

			tMap = tffAktifKartBasvurulari(tMap);
			// P Kontrolu
			// oMap.put("KART_UYGUNLUK",index,"KART_TIPI","P");
			// oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.EVET);
			// index++;
			String pVerebilme = "E";
			String dVerebilme = "E";
			String kkVerebilme = "E";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				pVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "P", BnsprType.STRING, "UYGUNLUK"));
				dVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "D", BnsprType.STRING, "UYGUNLUK"));
				kkVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "KK", BnsprType.STRING, "UYGUNLUK"));

			}
			catch (Exception e) {
				e.printStackTrace();

			}

			GMMap pKontrol = new GMMap();
			pKontrol.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
			// pKontrol.put("KART_TIPI", TffServicesMessages.KART_TIPI_PREPAID);

			if (iMap.containsKey("URUN_SAHIP_KODU")) {
				pKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
				pKontrol.put("URUN_KODU", iMap.getString("URUN_KODU", "TFFSTD"));
			}
			else {

				logger.error("----------  uyeKartAlabilirlikDurumu -  URUN_SAHIP_KODU YOK ");

			}
			pKontrol.put("TCKN", tffUyeler.getTckn().compareTo(BigDecimal.ZERO) > 0 ? tffUyeler.getTckn() : "");
			pKontrol = GMServiceExecuter.call("BNSPR_TFF_CARD_ALABILME_KONTROL", pKontrol);

			if (iMap.containsKey("DIRECT_CALL") && iMap.getBoolean("DIRECT_CALL")) {
				boolean pUygun = true;
				if (tMap.getBigDecimal("P_BASVURU_SAYISI", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {
					List<TffBasvuru> masters = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("tffUyeNo", tffUyeler.getUyeNo())).add(Restrictions.eq("kartTipi", "P")).add(Restrictions.not(Restrictions.in("durumKod", new String[] { "IPTAL", "RED", "ACIK" }))).add(Restrictions.eq("urun", iMap.getString("URUN_KODU"))).list();
					for (TffBasvuru b : masters) {
						if (iMap.getString("URUN_SAHIP_KODU").equals(b.getUrunSahipKodu()) && (StringUtils.isNotBlank(iMap.getString("URUN_KODU")) && iMap.getString("URUN_KODU").equals(b.getUrun()))) {
							oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
							if (!"BASVURU".equals(b.getDurumKod()) && !"FOTO".equals(b.getDurumKod()) && !"ODEME".equals(b.getDurumKod()) && !"ODEME_BEKLE".equals(b.getDurumKod())) {
								oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", "");
							}
							else {
								oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("P_BASVURU_NO"));
							}
							oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
							oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "152");
							pUygun = false;
							break;
						}
					}

				}
				if (pUygun) {
					pKontrol = GMServiceExecuter.call("BNSPR_TFF_CARD_ALABILME_KONTROL", pKontrol);
					oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("P_VERILEBILIR_MI"));

					if ("U".equals(pKontrol.getString("P_VERILEBILIR_MI"))) {
						oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("P_VERILEBILIR_MI"));
						oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", TffServicesMessages.P_KART_KAPAMA_TALEBI_VAR);
					}
					else if ("H".equals(pKontrol.getString("P_VERILEBILIR_MI"))) {
						oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "152");
					}
				}
				if ("H".equals(pVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				}
				index++;
			}
			else {
				if ("H".equals(pVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "152");
				}
			}
			/*            // P URUN KANAL KONTROLU
						pKontrol.put("UYE_NO", tffUyeler.getUyeNo());
						pKontrol.put("KART_TIPI", "P");
						pKontrol.put("SOURCE", iMap.getString("SOURCE"));
						pKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
						pKontrol.put("URUN_KODU", iMap.getString("URUN_KODU","TFFSTD"));
						pKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", pKontrol);
						if(!"2".equals(pKontrol.getString("RESPONSE")) && TffServicesMessages.URUN_GECERLI_DEGIL_HATASI.equals(pKontrol.getString("RESPONSE_DATA"))){
							oMap.put("KART_UYGUNLUK",index,"KART_TIPI","P");
							oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.HAYIR);
							logger.info("----------  uyeKartAlabilirlikDurumu -  KART_TIPI : P  urun kanala kapali" );
						}*/
			// D Kontrolu

			if (isUnder18(tffUyeler.getDogumTarihi())) {
				logger.info("----------  tffkartUygunluk -  18 yas altina D KK yok");
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", "");
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "0217");
				index++;
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", "");
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "0217");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				return oMap;

			}

			if ("TR".equals(tffUyeler.getUyruk()) && tMap.getBigDecimal("D_BASVURU_SAYISI", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 0) {
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("D_VERILEBILIR_MI"));
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", StringUtils.EMPTY);
				if ("U".equals(pKontrol.getString("D_VERILEBILIR_MI"))) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("D_VERILEBILIR_MI"));
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", TffServicesMessages.D_KART_KAPAMA_TALEBI_VAR);
				}
				else {
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", StringUtils.EMPTY);
				}
				if ("H".equals(dVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "153");
				}
				index++;

			}
			else {
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("D_BASVURU_NO"));
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "153");
				index++;
				logger.info("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
				logger.info("----------  tffDAlabilmeKontrol -  D_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI") + ".  (basvurusu var)");
			}
			/*		// D URUN KANAL KONTROLU
					dKontrol.put("UYE_NO", tffUyeler.getUyeNo());
					dKontrol.put("KART_TIPI", "D");
					dKontrol.put("SOURCE", iMap.getString("SOURCE"));
					dKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU",tffUyeler.getTakim()));
					dKontrol.put("URUN_KODU", iMap.getString("URUN_KODU","TFFSTD"));
					dKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", dKontrol);
					if(!"2".equals(dKontrol.getString("RESPONSE")) && TffServicesMessages.URUN_GECERLI_DEGIL_HATASI.equals(dKontrol.getString("RESPONSE_DATA"))){
						oMap.put("KART_UYGUNLUK",index,"KART_TIPI","D");
						oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.HAYIR);
						logger.info("----------  uyeKartAlabilirlikDurumu -  KART_TIPI : D  urun kanala kapali" );
					}
				*/

			// KK Kontrolu

			if ("TR".equals(tffUyeler.getUyruk()) && tMap.getBigDecimal("KK_BASVURU_SAYISI", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 0) {

				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("KK_BASVURU_NO"));
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("KK_VERILEBILIR_MI"));
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", StringUtils.EMPTY);
				if (TffServicesMessages.UYARI.equals(pKontrol.getString("KK_VERILEBILIR_MI"))) {
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", TffServicesMessages.KK_KART_KAPAMA_TALEBI_VAR);
				}

				if ("H".equals(kkVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "154");
				}
			}
			else {
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("KK_BASVURU_NO"));
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "154");
				logger.info("----------  tffKKAlabilmeKontrol -  KART_TIPI : " + "KK");
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + CreditCardServicesUtil.HAYIR + ".  (basvurusu var)");

			}
			/*		kkKontrol.put("UYE_NO", tffUyeler.getUyeNo());
					kkKontrol.put("KART_TIPI", "KK");
					kkKontrol.put("SOURCE", iMap.getString("SOURCE"));
					kkKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU",tffUyeler.getTakim()));
					kkKontrol.put("URUN_KODU", iMap.getString("URUN_KODU","TFFSTD"));
					kkKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", kkKontrol);
					if(!"2".equals(kkKontrol.getString("RESPONSE")) && TffServicesMessages.URUN_GECERLI_DEGIL_HATASI.equals(kkKontrol.getString("RESPONSE_DATA"))){
						oMap.put("KART_UYGUNLUK",index,"KART_TIPI","KK");
						oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.HAYIR);
						logger.info("----------  uyeKartAlabilirlikDurumu -  KART_TIPI : KK  urun kanala kapali" );
					}*/

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;

	}

	@GraymoundService("BNSPR_TFF_CARD_ALABILME_KONTROL")
	public static GMMap tffCardAlabilmeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			boolean fbKombineVar = false;
			boolean isKartKuryede = false;
			boolean isKartNormal = false;
			boolean isKartGeciciKapali = false;
			boolean isKartDigerDurum = false;
			boolean isKartYasalTakip = false;
			boolean isExistCard = false;
			boolean isKapamaTalepAlindi = false;

			String durum = "CARD_STAT_CODE";
			String altDurum = "CARD_SUB_STAT_CODE";
			GMMap dKontrol = new GMMap();
			GMMap sMap = new GMMap();
			dKontrol.put("CARD_DCI", "A");
			dKontrol.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
			// dKontrol.put("CARD_BANK_STATUS","N");
			// dKontrol.put("NO_NEED_OCEAN_CARDS", true);/*YKP i�in ocean kartlar� listelemesin*/
			dKontrol.put("SEGMENT", "TFF"); // sadece TFF kartlar
			dKontrol = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", dKontrol);
			oMap.put("D_VERILEBILIR_MI", TffServicesMessages.EVET);
			oMap.put("P_VERILEBILIR_MI", TffServicesMessages.EVET);
			oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.EVET);
			if (dKontrol.getSize("CARD_DETAIL_INFO") > 0) {
				for (int i = 0; i < dKontrol.getSize("CARD_DETAIL_INFO"); i++) {
					if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_DEBIT) && isCardOpen(dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE"), dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE"), dKontrol.getString("CARD_DETAIL_INFO", i, "OLD_CARD_NO"))) {
						sMap.clear();
						sMap.put("KART_NO", dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
						sMap.put("KART_TIPI", "D");
						sMap = GMServiceExecuter.call("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", sMap);
						if ("E".equals(sMap.getString("KAPAMA_TALEBI_VAR_MI"))) {
							oMap.put("D_VERILEBILIR_MI", TffServicesMessages.UYARI);
						}
						else {
							oMap.put("D_VERILEBILIR_MI", TffServicesMessages.HAYIR);
						}
					}
					else if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_PREPAID) && isCardOpen(dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_STAT_CODE"), dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE"), dKontrol.getString("CARD_DETAIL_INFO", i, "OLD_CARD_NO"))) {

						String urunId = dKontrol.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");
						String logoKod = dKontrol.getString("CARD_DETAIL_INFO", i, "LOGO_CODE");
						String func = "{? = call pkg_trn3801.get_takim_kodu(?,?,?)}";
						String urunSahipKodu = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, urunId, BnsprType.STRING, logoKod, BnsprType.STRING, "P"));

						String funcUrun = "{? = call pkg_trn3801.get_urun_kodu(?,?,?)}";
						String urunKodu = String.valueOf(DALUtil.callOracleFunction(funcUrun, BnsprType.STRING, BnsprType.STRING, urunId, BnsprType.STRING, logoKod, BnsprType.STRING, "P"));
						if ("TFF11".equals(urunSahipKodu) && "TFFKOM".equals(urunKodu)) {
							fbKombineVar = true;
						}
						if (urunSahipKodu.equals(iMap.getString("URUN_SAHIP_KODU")) && urunKodu.equals(iMap.getString("URUN_KODU"))) {
							sMap.clear();
							sMap.put("KART_NO", dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
							sMap.put("KART_TIPI", "P");
							sMap = GMServiceExecuter.call("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", sMap);
							if ("E".equals(sMap.getString("KAPAMA_TALEBI_VAR_MI"))) {
								oMap.put("P_VERILEBILIR_MI", TffServicesMessages.UYARI);
							}
							else {
								oMap.put("P_VERILEBILIR_MI", TffServicesMessages.HAYIR);
							}
						}
						logger.info("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
						logger.info("----------  tffDAlabilmeKontrol -  P_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI"));
					}
					else if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_KK) && !isExistCard) {

						sMap.clear();
						sMap.put("KART_NO", dKontrol.get("CARD_DETAIL_INFO", i, "CARD_NO"));
						sMap.put("KART_TIPI", CreditCardTffServices.TFF_KREDI_KARTI);
						sMap.putAll(GMServiceExecuter.execute("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", sMap));
						if (CreditCardServicesUtil.EVET.equals(sMap.getString("KAPAMA_TALEBI_VAR_MI"))) {
							isExistCard = true;
							isKapamaTalepAlindi = true;
							// break;
						}
						else {

							isKartKuryede = "G".equals(dKontrol.get("CARD_DETAIL_INFO", i, durum)) && "J".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)); // KURYEDE OLAN KART
							isKartNormal = "N".equals(dKontrol.get("CARD_DETAIL_INFO", i, durum)) && "N".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)); // Normal
							isKartGeciciKapali = "G".equals(dKontrol.get("CARD_DETAIL_INFO", i, durum)) && ("N".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // GECICI KAPALI
									|| "V".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // GECICI KAPALI - VEFAT BILDIRIMI
									|| "X".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // GECICI KAPALI - UCUNCU SAHIS BILDIRIMI
									|| "M".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // MUSTERI KAYIP (GECICI)
									|| "K".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // KURYE KAYIP (GECICI)
									|| "G".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // KAYIP CALINTI KONTROL
									|| "C".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // CALINTI(GECICI)
									|| "Y".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // VADE YENILEME
									|| "Q".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // GECICI KAPALI - VEFAT BILDIRIMI
							|| "B".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // BASIM BEKLENIYOR
							);

							isKartDigerDurum = "I".equals(dKontrol.get("CARD_DETAIL_INFO", i, durum)) && ("V".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // VEFAT
							|| "Y".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)) // MUKERRER KART
							);

							isKartYasalTakip = "P".equals(dKontrol.get("CARD_DETAIL_INFO", i, durum)) && "P".equals(dKontrol.get("CARD_DETAIL_INFO", i, altDurum)); // YASAL TAKIP

							if (isKartKuryede || isKartNormal || isKartGeciciKapali || isKartDigerDurum || isKartYasalTakip) {
								isExistCard = true;

							}
						}

					}

				}
				if ("TFF11".equals(iMap.getString("URUN_SAHIP_KODU")) && "TFFSTD".equals(iMap.getString("URUN_KODU")) && fbKombineVar) {
					oMap.put("P_VERILEBILIR_MI", TffServicesMessages.HAYIR);
					logger.error("----------  tffDAlabilmeKontrol -  FB Kombine var Prepaid alamaz");
				}

				if (isExistCard) {
					if (isKapamaTalepAlindi) {
						oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.UYARI);
					}
					else {
						oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
					}
					logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
					return oMap;
				}

				GMMap redKontrol = new GMMap();
				redKontrol.put("TCK_NO", iMap.getString("TCKN"));
				redKontrol.put("BASVURU_SONLANDIR", "H");
				oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL", redKontrol));

				if (TffServicesMessages.HAYIR.equals(oMap.getString("DEVAM"))) {
					oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
					logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
					return oMap;
				}

				oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", redKontrol));
				if (TffServicesMessages.HAYIR.equals(oMap.getString("DEVAM"))) {
					oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
					logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
					return oMap;
				}

			}
			//kk m��terisinin telefonuyla yeni bir kk ba�vurusu gelmi� mi?
			GMMap checkKK = new GMMap();
			checkKK.put("TCKN", iMap.getString("TCKN"));
			checkKK.put("MUSTERI_NO",  iMap.getString("MUSTERI_NO"));
			checkKK.put("TEL_NO", iMap.getString("CEP_TEL_NUMARA"));
			checkKK.put("ALAN_KOD", iMap.getString("CEP_ALAN_NO"));
			checkKK.put("ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
			oMap = GMServiceExecuter.call("BNSPR_CHECK_PHONE_FOR_PASSOLIG_APPLICATION", checkKK);
			if(BASKA_KK_MUSTERISI_VAR_HATASI.equals(oMap.getString("RESPONSE"))){
				oMap.put("KK_VERILEBILIR_MI", TffServicesMessages.HAYIR);
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
				return oMap;

			}

			logger.info("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
			logger.info("----------  tffDAlabilmeKontrol -  D_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI"));
			return oMap;
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("D_VERILEBILIR_MI", "E");

			logger.info("----------  tffDAlabilmeKontrol -  P_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI"));
			e.printStackTrace();
		}
		return oMap;
	}

	private static boolean isCardOpen(String statCode, String subStatcode, String oldCardNo) {
		boolean isOpen = false;
		if (("N".equals(statCode) || "N".equals(subStatcode)) || (!StringUtil.isEmpty(oldCardNo) && "G".equals(statCode) && ("B".equals(subStatcode) || "J".equals(subStatcode)))) {
			isOpen = true;
		}
		return isOpen;
	}

	@Deprecated
	/**
	 * 
	 * @See BNSPR_TFF_COMMON_GET_CARD_AVAILABILITY_FOR_MEMBER
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU")
	public static GMMap uyeKartAlabilirlikDurumu(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String pasaportNo = iMap.getString("PASAPORT_NO", "");
			if (!StringUtils.isEmpty(iMap.getString("PASAPORT_NO"))) {
				pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			if (("NTS02".equals(iMap.getString("SOURCE")) || "NTS01".equals(iMap.getString("SOURCE"))) && StringUtils.isBlank(iMap.getString("UYE_NO"))) {
				tffUyeler = findUye(iMap.getString("UYRUK"), iMap.getBigDecimal("TCKN"), pasaportNo);

			}
			else {
				tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
			}

			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_BILGILERI_VER_UYE_KAYDI_BULUNAMADI_HATASI);
				return oMap;
			}

			int index = 0;
			boolean onSekizYasKontrolu = false;
			if ("EPOS".equals(iMap.getString("SOURCE")) && iMap.containsKey("DIRECT_CALL")) {
				GMServiceExecuter.execute("BNSPR_TFF_BUS_CANCEL_PREVIOUS_APPLICATIONS", iMap);
			}
			if (!isUnder18(tffUyeler.getDogumTarihi())) {
				onSekizYasKontrolu = true;
			}
			GMMap tMap = new GMMap();

			tMap.put("UYE_NO", iMap.getBigDecimal("UYE_NO", tffUyeler.getUyeNo()));
			logger.info("----------  uyeKartAlabilirlikDurumu -  uyeNo : " + iMap.getBigDecimal("UYE_NO"));

			tMap = tffAktifKartBasvurulari(tMap);
			// P Kontrolu
			// oMap.put("KART_UYGUNLUK",index,"KART_TIPI","P");
			// oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.EVET);
			// index++;
			String pVerebilme = "E";
			String dVerebilme = "E";
			String kkVerebilme = "E";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				pVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "P", BnsprType.STRING, "UYGUNLUK"));
				dVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "D", BnsprType.STRING, "UYGUNLUK"));
				kkVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "KK", BnsprType.STRING, "UYGUNLUK"));

			}
			catch (Exception e) {
				e.printStackTrace();

			}

			GMMap pKontrol = new GMMap();
			if (iMap.containsKey("DIRECT_CALL") && iMap.getBoolean("DIRECT_CALL")) {

				pKontrol.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
				pKontrol.put("KART_TIPI", TffServicesMessages.KART_TIPI_PREPAID);

				if (iMap.containsKey("URUN_SAHIP_KODU")) {
					pKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
					pKontrol.put("URUN_KODU", iMap.getString("URUN_KODU", "TFFSTD"));
				}
				else {

					logger.error("----------  uyeKartAlabilirlikDurumu -  URUN_SAHIP_KODU YOK ");

				}

				boolean pUygun = true;
				if (tMap.getBigDecimal("P_BASVURU_SAYISI", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0) {
					List<TffBasvuru> masters = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("tffUyeNo", tffUyeler.getUyeNo())).add(Restrictions.eq("kartTipi", "P")).add(Restrictions.not(Restrictions.in("durumKod", new String[] { "IPTAL", "RED", "ACIK" }))).add(Restrictions.eq("urun", iMap.getString("URUN_KODU"))).list();
					for (TffBasvuru b : masters) {
						if (iMap.getString("URUN_SAHIP_KODU").equals(b.getUrunSahipKodu()) && (StringUtils.isNotBlank(iMap.getString("URUN_KODU")) && iMap.getString("URUN_KODU").equals(b.getUrun()))) {
							oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
							if (!"BASVURU".equals(b.getDurumKod()) && !"FOTO".equals(b.getDurumKod()) && !"ODEME".equals(b.getDurumKod()) && !"ODEME_BEKLE".equals(b.getDurumKod())) {
								oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", "");
							}
							else {
								oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("P_BASVURU_NO"));
							}
							oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
							oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "152");
							pUygun = false;
							break;
						}
					}

				}
				if (pUygun) {
					pKontrol = GMServiceExecuter.call("BNSPR_TFF_D_ALABILME_KONTROL", pKontrol);
					oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("D_VERILEBILIR_MI"));

					if ("U".equals(pKontrol.getString("D_VERILEBILIR_MI"))) {
						oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", pKontrol.getString("D_VERILEBILIR_MI"));
						oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", TffServicesMessages.P_KART_KAPAMA_TALEBI_VAR);
					}
					else if ("H".equals(pKontrol.getString("D_VERILEBILIR_MI"))) {
						oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "152");
					}
				}
				if ("H".equals(pVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				}
				index++;
			}
			else {
				if ("H".equals(pVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "152");
				}
			}
			/*            // P URUN KANAL KONTROLU
						pKontrol.put("UYE_NO", tffUyeler.getUyeNo());
						pKontrol.put("KART_TIPI", "P");
						pKontrol.put("SOURCE", iMap.getString("SOURCE"));
						pKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
						pKontrol.put("URUN_KODU", iMap.getString("URUN_KODU","TFFSTD"));
						pKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", pKontrol);
						if(!"2".equals(pKontrol.getString("RESPONSE")) && TffServicesMessages.URUN_GECERLI_DEGIL_HATASI.equals(pKontrol.getString("RESPONSE_DATA"))){
							oMap.put("KART_UYGUNLUK",index,"KART_TIPI","P");
							oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.HAYIR);
							logger.info("----------  uyeKartAlabilirlikDurumu -  KART_TIPI : P  urun kanala kapali" );
						}*/
			// D Kontrolu

			if (isUnder18(tffUyeler.getDogumTarihi())) {
				logger.info("----------  tffkartUygunluk -  18 yas altina D KK yok");
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", "");
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "0217");
				index++;
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", "");
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "0217");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				return oMap;

			}
			GMMap dKontrol = new GMMap();
			if ("TR".equals(tffUyeler.getUyruk()) && tMap.getBigDecimal("D_BASVURU_SAYISI", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 0) {

				dKontrol.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
				dKontrol.put("KART_TIPI", TffServicesMessages.KART_TIPI_DEBIT);
				dKontrol = GMServiceExecuter.call("BNSPR_TFF_D_ALABILME_KONTROL", dKontrol);

				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", dKontrol.getString("D_VERILEBILIR_MI"));
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", StringUtils.EMPTY);
				if ("U".equals(dKontrol.getString("D_VERILEBILIR_MI"))) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", dKontrol.getString("D_VERILEBILIR_MI"));
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", TffServicesMessages.D_KART_KAPAMA_TALEBI_VAR);
				}
				else {
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", StringUtils.EMPTY);
				}
				if ("H".equals(dVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "153");
				}
				index++;

			}
			else {
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("D_BASVURU_NO"));
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "153");
				index++;
				logger.info("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
				logger.info("----------  tffDAlabilmeKontrol -  D_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI") + ".  (basvurusu var)");
			}
			/*		// D URUN KANAL KONTROLU
					dKontrol.put("UYE_NO", tffUyeler.getUyeNo());
					dKontrol.put("KART_TIPI", "D");
					dKontrol.put("SOURCE", iMap.getString("SOURCE"));
					dKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU",tffUyeler.getTakim()));
					dKontrol.put("URUN_KODU", iMap.getString("URUN_KODU","TFFSTD"));
					dKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", dKontrol);
					if(!"2".equals(dKontrol.getString("RESPONSE")) && TffServicesMessages.URUN_GECERLI_DEGIL_HATASI.equals(dKontrol.getString("RESPONSE_DATA"))){
						oMap.put("KART_UYGUNLUK",index,"KART_TIPI","D");
						oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.HAYIR);
						logger.info("----------  uyeKartAlabilirlikDurumu -  KART_TIPI : D  urun kanala kapali" );
					}
				*/

			// KK Kontrolu
			GMMap kkKontrol = new GMMap();
			if ("TR".equals(tffUyeler.getUyruk()) && tMap.getBigDecimal("KK_BASVURU_SAYISI", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 0) {

				kkKontrol.put("KK_ALABILIR_MI", onSekizYasKontrolu);
				kkKontrol.put("MUST_NO", tffUyeler.getBankaMusteriNo());
				kkKontrol.put("TCKN", tffUyeler.getTckn());
				kkKontrol = GMServiceExecuter.call("BNSPR_TFF_KK_ALABILME_KONTROL", kkKontrol);
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("KK_BASVURU_NO"));
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", kkKontrol.getString("KK_VERILEBILIR_MI"));
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", StringUtils.EMPTY);
				if (TffServicesMessages.UYARI.equals(kkKontrol.getString("KK_VERILEBILIR_MI"))) {
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", TffServicesMessages.KK_KART_KAPAMA_TALEBI_VAR);
				}

				if ("H".equals(kkVerebilme)) {
					oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
					oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "154");
				}
			}
			else {
				oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
				oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tMap.getBigDecimal("KK_BASVURU_NO"));
				oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", CreditCardServicesUtil.HAYIR);
				oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", "154");
				logger.info("----------  tffKKAlabilmeKontrol -  KART_TIPI : " + "KK");
				logger.info("----------  tffKKAlabilmeKontrol -  KK_VERILEBILIR_MI : " + CreditCardServicesUtil.HAYIR + ".  (basvurusu var)");

			}
			/*		kkKontrol.put("UYE_NO", tffUyeler.getUyeNo());
					kkKontrol.put("KART_TIPI", "KK");
					kkKontrol.put("SOURCE", iMap.getString("SOURCE"));
					kkKontrol.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU",tffUyeler.getTakim()));
					kkKontrol.put("URUN_KODU", iMap.getString("URUN_KODU","TFFSTD"));
					kkKontrol = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", kkKontrol);
					if(!"2".equals(kkKontrol.getString("RESPONSE")) && TffServicesMessages.URUN_GECERLI_DEGIL_HATASI.equals(kkKontrol.getString("RESPONSE_DATA"))){
						oMap.put("KART_UYGUNLUK",index,"KART_TIPI","KK");
						oMap.put("KART_UYGUNLUK",index,"UYGUNLUK",CreditCardServicesUtil.HAYIR);
						logger.info("----------  uyeKartAlabilirlikDurumu -  KART_TIPI : KK  urun kanala kapali" );
					}*/

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_D_ALABILME_KONTROL")
	public static GMMap tffDAlabilmeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("----------  tffDAlabilmeKontrol -  MUSTERI_NO : " + iMap.getString("MUSTERI_NO"));

		boolean fbKombineVar = false;
		try {
			GMMap dKontrol = new GMMap();
			dKontrol.put("CARD_DCI", "A");
			dKontrol.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
			dKontrol.put("CARD_BANK_STATUS", "N");
			dKontrol.put("NO_NEED_OCEAN_CARDS", true);/*YKP i�in ocean kartlar� listelemesin*/
			dKontrol = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", dKontrol);
			if (TffServicesMessages.KART_TIPI_DEBIT.equals(iMap.getString("KART_TIPI"))) {
				oMap.put("D_VERILEBILIR_MI", TffServicesMessages.EVET);
				if (dKontrol.getSize("CARD_DETAIL_INFO") > 0) {
					for (int i = 0; i < dKontrol.getSize("CARD_DETAIL_INFO"); i++) {
						if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_DEBIT)) {
							dKontrol.put("KART_NO", dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
							dKontrol.put("KART_TIPI", "D");
							dKontrol = GMServiceExecuter.call("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", dKontrol);
							if ("E".equals(dKontrol.getString("KAPAMA_TALEBI_VAR_MI"))) {
								oMap.put("D_VERILEBILIR_MI", TffServicesMessages.UYARI);
							}
							else {
								oMap.put("D_VERILEBILIR_MI", TffServicesMessages.HAYIR);
							}
						}
					}
				}

				logger.info("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
				logger.info("----------  tffDAlabilmeKontrol -  D_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI"));
			}
			else if (TffServicesMessages.KART_TIPI_PREPAID.equals(iMap.getString("KART_TIPI"))) {
				oMap.put("D_VERILEBILIR_MI", TffServicesMessages.EVET);
				if (dKontrol.getSize("CARD_DETAIL_INFO") > 0) {
					for (int i = 0; i < dKontrol.getSize("CARD_DETAIL_INFO"); i++) {
						if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_PREPAID)) {
							String urunId = dKontrol.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");
							String logoKod = dKontrol.getString("CARD_DETAIL_INFO", i, "LOGO_CODE");
							String func = "{? = call pkg_trn3801.get_takim_kodu(?,?,?)}";
							String urunSahipKodu = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, urunId, BnsprType.STRING, logoKod, BnsprType.STRING, "P"));

							String funcUrun = "{? = call pkg_trn3801.get_urun_kodu(?,?,?)}";
							String urunKodu = String.valueOf(DALUtil.callOracleFunction(funcUrun, BnsprType.STRING, BnsprType.STRING, urunId, BnsprType.STRING, logoKod, BnsprType.STRING, "P"));
							if ("TFF11".equals(urunSahipKodu) && "TFFKOM".equals(urunKodu)) {
								fbKombineVar = true;
							}
							if (iMap.getString("URUN_SAHIP_KODU").equals(urunSahipKodu) && iMap.getString("URUN_KODU").equals(urunKodu)) {
								dKontrol.put("KART_NO", dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
								dKontrol.put("KART_TIPI", "P");
								dKontrol = GMServiceExecuter.call("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", dKontrol);
								if ("E".equals(dKontrol.getString("KAPAMA_TALEBI_VAR_MI"))) {
									oMap.put("D_VERILEBILIR_MI", TffServicesMessages.UYARI);
								}
								else {
									oMap.put("D_VERILEBILIR_MI", TffServicesMessages.HAYIR);
								}
							}
							logger.info("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
							logger.info("----------  tffDAlabilmeKontrol -  P_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI"));
						}
					}
					if ("TFF11".equals(iMap.getString("URUN_SAHIP_KODU")) && "TFFSTD".equals(iMap.getString("URUN_KODU")) && fbKombineVar) {
						oMap.put("D_VERILEBILIR_MI", TffServicesMessages.HAYIR);
						logger.error("----------  tffDAlabilmeKontrol -  FB Komine var Prepaid alamaz");
					}
				}
			}
			else {
				logger.error("----------  tffDAlabilmeKontrol -  KART_TIPI : " + iMap.getString("KART_TIPI"));
				logger.error("----------  tffDAlabilmeKontrol -  KART_TIPI :  D ya da P olmal�");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("D_VERILEBILIR_MI", "E");

			logger.info("----------  tffDAlabilmeKontrol -  P_VERILEBILIR_MI : " + oMap.getString("D_VERILEBILIR_MI"));
			e.printStackTrace();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_UYE_KART_BILGISI_VER")
	public static GMMap tffUyeKartBilgisiVer(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (StringUtils.isEmpty(iMap.getString("TFF_BASVURU_NO"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_KART_BILGI_VER_BASVURU_BULUNAMADI_HATASI);
			return oMap;
		}
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);

		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
		session.refresh(tffBasvuru);
		if (tffBasvuru == null) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_KART_BILGI_VER_BASVURU_BULUNAMADI_HATASI);
			return oMap;
		}
		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, tffBasvuru.getTffUyeNo());
		if (StringUtils.isNotEmpty(tffBasvuru.getKartNo())) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_KART_BILGI_VER_KART_BILGISI_DOLU_HATASI);
			return oMap;
		}
		if (!tffBasvuru.getDurumKod().equals("BASIM")) {
			logger.info("----------  tffUyeKartBilgisiVer -  getDurumKod : " + tffBasvuru.getDurumKod());
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_KART_BILGI_DURUM_KART_BILGI_VER_DEGIL_HATASI);
			return oMap;
		}
		if ("A".equals(tffBasvuru.getKuryeTipi())) {
			GMMap tmpMap = new GMMap();
			tmpMap.put("CARD_NO", iMap.getString("KART_BILGI"));
			tmpMap.put("PRODUCT_OWNER", tffBasvuru.getUrunSahipKodu());
			tmpMap.put("PRODUCT_ID", tffBasvuru.getUrunId());

			/** validasyon ekle ***/
			GMMap checkMap = GMServiceExecuter.call("BNSPR_TFF_G4_KART_URUN_KONTROLU", tmpMap);
			if (!"2".equals(checkMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.G4_KART_ILE_BASVURU_UYUMSUZ);
				return oMap;
			}

			tmpMap.clear();
			GMMap kartBilgileriMap = new GMMap();
			kartBilgileriMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			kartBilgileriMap = GMServiceExecuter.call("BNSPR_CREATE_INTRACARD_CUSTOMER", kartBilgileriMap);

			if (TffServicesMessages.RESPONSE_BASARILI.equals(kartBilgileriMap.getString("RETURN_CODE"))) {

				/*tffBasvuru.setKartNo(iMap.getString("KART_BILGI"));
				session.saveOrUpdate(tffBasvuru);
				session.flush();*/
				if (tffBasvuru.getMusteriNo() != null && tffBasvuru.getMusteriNo().compareTo(new BigDecimal(0)) > 0) {
					tmpMap.put("CARD_NO", iMap.getString("KART_BILGI"));
					tmpMap.put("APPLICATION_NO", iMap.get("TFF_BASVURU_NO"));
					try {
						tmpMap = GMServiceExecuter.call("BNSPR_CARD_ACTIVATION", tmpMap);
						// gise basvurular�nda aktivasyondan sonra kvkk i�in m��teriye sms gitsin
						kvkkSmsGonder(tffBasvuru.getBasvuruNo(), tffBasvuru.getMusteriNo());
					}
					catch (Exception e) {
						CreditCardServicesUtil.raiseGMError("4255", "Kart aktivasyonu yap�lamad�");
					}
					GMMap sorguMap = new GMMap();
					// PY-9205
					sorguMap.put("TFF_UYE_NO", tffBasvuru.getTffUyeNo());
					sorguMap.put("TARGET", "SS");
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GET_APPROVED_PHOTO_PATH", sorguMap));
					if (CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
						tmpMap.put("PHOTO_PATH", sorguMap.getString("TFF_APPROVED_IMAGE_PATH"));
					}

					List<TffSsProductMap> tffSsProductMapList = (List<TffSsProductMap>) session.createCriteria(TffSsProductMap.class).add(Restrictions.eq("urunSahipKod", tffBasvuru.getUrunSahipKodu())).list();

					TffSsProductMap tffSsProductMap = null;

					if (tffSsProductMapList == null || tffSsProductMapList.size() <= 0) {
						CreditCardServicesUtil.raiseGMError("Urun tak�m e�le�tirilmesi yap�lamad�");
					}
					else {
						tffSsProductMap = (TffSsProductMap) tffSsProductMapList.get(0);
					}
					tmpMap.put("CUSTOMER_NO", tffBasvuru.getMusteriNo());
					tmpMap.put("CARD_NO", iMap.getString("KART_BILGI"));
					tmpMap.put("NAME", kartBilgileriMap.getString("EMBOSS_NAME"));
					tmpMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
					tmpMap.put("PRODUCT_OWNER", tffBasvuru.getUrunSahipKodu());
					tmpMap.put("TXN_TYPE", "N");
					tmpMap.put("GISE_ID", iMap.getString("GISE_ID"));
					tmpMap.put("PRODUCT_ID", tffBasvuru.getUrunId());
					tmpMap.put("TEAM_CODE", tffSsProductMap != null ? tffSsProductMap.getKlupId() : null);

					GMMap matchMap = null;
					try {
						matchMap = GMServiceExecuter.call("BNSPR_INTRACARD_MATCH_CARD_AND_CUSTOMER", tmpMap);
					}
					catch (Exception e) {
						tmpMap.put("TXN_TYPE", "C");
						GMServiceExecuter.call("BNSPR_INTRACARD_MATCH_CARD_AND_CUSTOMER", tmpMap);
						basvuruIptal(tffBasvuru);

						CreditCardServicesUtil.raiseGMError("3285", "Kart eslestirilemedi");
					}

					if ("2".equals(matchMap.getString("RETURN_CODE"))) {
						try {

							String cardNo = StringUtils.isEmpty(matchMap.getString("CARD_NO")) ?  iMap.getString("KART_BILGI") : matchMap.getString("CARD_NO");
							iMap.put("CARD_NO", cardNo);
							GMMap infoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", iMap);
							BigDecimal productId = infoMap.getBigDecimal("CARD_DETAIL_INFO", 0, "PRODUCT_ID");

							session.refresh(tffBasvuru);
							tffBasvuru.setKartNo(cardNo);
							tffBasvuru.setUrunId(productId);
							session.saveOrUpdate(tffBasvuru);
							session.flush();

							iMap.put("BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
							iMap.put("UYRUK_KOD", tffUyeler.getUyruk());
							iMap.put("TCKN", tffUyeler.getTckn());
							iMap.put("PASAPORT_NO", tffUyeler.getPasaportNo());
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
							GMServiceExecuter.execute("BNSPR_TFF_UPDATE_APPROVED_PHOTO", iMap);

							// Belgeleri kaydet.

							GMMap belgeMap = new GMMap();
							belgeMap.put("BASVURU_NO", tffBasvuru.getBasvuruNo());
							oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BELGE_KAYIT", belgeMap));
						}
						catch (HibernateException e1) {
							e1.printStackTrace();
							tmpMap.put("TXN_TYPE", "C");
							GMServiceExecuter.call("BNSPR_INTRACARD_MATCH_CARD_AND_CUSTOMER", tmpMap);
							basvuruIptal(tffBasvuru);
							throw ExceptionHandler.convertException(e1);
						}
						catch (Exception e) {
							logger.error("Belge kaydetmede hata");
						}

						GMMap eMap = new GMMap();
						eMap.put("EVENT_TYPE_NO", EVENT_TYPE_NO);
						eMap.put("EVENT_REF_NO", iMap.get("TFF_BASVURU_NO"));
						GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", eMap);
					}
					else {
						tmpMap.put("TXN_TYPE", "C");
						GMServiceExecuter.call("BNSPR_INTRACARD_MATCH_CARD_AND_CUSTOMER", tmpMap);
						basvuruIptal(tffBasvuru);
						CreditCardServicesUtil.raiseGMError("3285", "Kart eslestirilemedi");
					}
				}
				else {
					// throw ExceptionHandler.convertException(new Exception("Musteri bulunamadi"));
					CreditCardServicesUtil.raiseGMError("4256", "Musteri bulunamadi");
				}

			}
			else {
				// throw ExceptionHandler.convertException(new Exception(kartBilgileriMap.getString("RETURN_DESCRIPTION")));
				CreditCardServicesUtil.raiseGMError("4257", "Intra musteri yaratilamadi");
			}

		}
		else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_KART_BILGI_VER_KURYE_TIPI_HATASI);
			return oMap;
		}
		try {
			oMap.put("CRM_TYPE", CrmTypes.MAIN);
			oMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			GMServiceExecuter.call("BNSPR_TFF_SEND_APPLICATION_TO_CRM", oMap);
		}
		catch (Exception e) {
			oMap.clear();
			oMap.put("RESPONSE_DATA", TffServicesMessages.CRM_GONDERIM_HATASI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_UYE_KART_LISTESI")
	public static GMMap tffUyeKartListesi(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (StringUtils.isEmpty(iMap.getString("UYE_NO"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_UYE_NO_BOS_HATASI);
			return oMap;
		}

		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
		if (tffUyeler == null) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_UYE_NO_BULUNAMADI_HATASI);
			return oMap;
		}
		iMap.put("INPUT_PARAMETER_TYPE", "CST");
		iMap.put("MASK_CC_NO", "Y");
		iMap.put("CUSTOMER_NO", tffUyeler.getBankaMusteriNo());
		GMMap kartBilgileriMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
		String tableName = "CARD_DETAIL_INFO";
		oMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());

		for (int i = 0; i < oMap.getSize(tableName); i++) {
			oMap.put("KART_BILGILERI", i, "KART_NO", kartBilgileriMap.getString(tableName, i, "CARD_NO"));
			oMap.put("KART_BILGILERI", i, "KART_ADI", kartBilgileriMap.getString(tableName, i, "CARD_PRODUCT_NAME"));
			oMap.put("KART_BILGILERI", i, "LOGO_KODU", kartBilgileriMap.getString(tableName, i, "LOGO_CODE"));
			oMap.put("KART_BILGILERI", i, "URUN_ID", kartBilgileriMap.getString(tableName, i, "PRODUCT_ID"));
			oMap.put("KART_BILGILERI", i, "SISTEM", kartBilgileriMap.getString(tableName, i, "SYSTEM"));
		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/*
	 * Kart numarasi ile TFF_BASVURU_ODEME tablosundaki bilgileri doner
	 * @param iMap KART_NO inputunu bekler
	 * @return ODEME_BILGILERI icerisinde kolonlari doner
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_KART_ODEME_BILGILERI")
	public static GMMap tffKartOdemeBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		try {
			BigDecimal basvuruNo;

			String kartNo = iMap.getString("KART_NO");
			if (kartNo == null || "".equals(kartNo.trim())) {
				throw ExceptionHandler.convertException(new GMRuntimeException(831, CreditCardTffServices.errorMessageOlustur("831", "E")));
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Basvuru_No_Bul(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC); // ref cursor
			stmt.setString(i++, kartNo);
			stmt.execute();

			basvuruNo = stmt.getBigDecimal(1);
			oMap.put("BASVURU_NO", basvuruNo);

			stmt2 = conn.prepareCall("{? = call PKG_TFF_BASVURU.Kart_Ucreti(?,?)}");
			i = 1;
			stmt2.registerOutParameter(i++, -10);
			stmt2.setBigDecimal(i++, basvuruNo);
			stmt2.setString(i++, kartNo);
			stmt2.execute();

			rSet = (ResultSet) stmt2.getObject(1);

			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru master = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruNo)).uniqueResult();
			if (rSet.next()) {
				GMMap kartBilgileriMap = new GMMap();
				iMap.put("CARD_NO", kartNo);
				iMap.put("CUSTOMER_NO", master.getMusteriNo());
				if ("KK".equals(master.getKartTipi())) {
					iMap.put("CARD_DCI", "C");
					kartBilgileriMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap);
				}
				else {
					iMap.put("CARD_DCI", master.getKartTipi());
					kartBilgileriMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", iMap);
				}

				int index = 0;
				oMap.put("ODEME_BILGILERI", index, "BASVURU_NO", basvuruNo);
				oMap.put("ODEME_BILGILERI", index, "ODEME_SEKLI", rSet.getString("ODEME_SEKLI"));
				oMap.put("ODEME_BILGILERI", index, "KART_BEDELI", rSet.getBigDecimal("KART_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "VIZE_BEDELI", rSet.getBigDecimal("VIZE_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "LOYALITY_BEDELI", rSet.getBigDecimal("LOYALTY_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "KURYE_BEDELI", rSet.getBigDecimal("KURYE_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_KODU", rSet.getString("PROMOSYON_KODU"));
				oMap.put("ODEME_BILGILERI", index, "ODEME_REF_ID", rSet.getString("ODEME_REF_ID"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_BEDELI", rSet.getBigDecimal("PROMOSYON_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_ORANI", rSet.getBigDecimal("PROMOSYON_ORANI"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_KART", rSet.getBigDecimal("PROMOSYON_KART"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_KURYE", rSet.getBigDecimal("PROMOSYON_KURYE"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_VIZE", rSet.getBigDecimal("PROMOSYON_VIZE"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_LOYALTY", rSet.getBigDecimal("PROMOSYON_LOYALTY"));
				oMap.put("ODEME_BILGILERI", index, "VIZE_TARIHI", kartBilgileriMap.getLong("CARD_DETAIL_INFO", 0, "EMBOSS_DATE"));
			}
			else {
				String errorMessage = CreditCardTffServices.errorMessageOlustur("1599", "E");
				throw ExceptionHandler.convertException(new GMRuntimeException(1599, errorMessage));
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/*
	 * Basvuru veya kart numarasi ile TFF_BASVURU_ODEME_TX tablosundaki bilgileri doner.
	 * @param iMap KART_NO veya BASVURU_NO inputunu bekler
	 * @return ODEME_BILGILERI icerisinde kolonlari doner
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_BEKLEYEN_ODEME_BILGILERI")
	public static GMMap tffBekleyenOdemeBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		try {
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO", BigDecimal.ZERO);
			String kartNo = iMap.getString("KART_NO", "");
			conn = DALUtil.getGMConnection();

			if (basvuruNo == BigDecimal.ZERO) {
				stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Basvuru_No_Bul(?)}");
				int i = 1;
				stmt.registerOutParameter(i++, Types.NUMERIC); // ref cursor
				stmt.setString(i++, kartNo);
				stmt.execute();

				basvuruNo = stmt.getBigDecimal(1);
			}

			oMap.put("BASVURU_NO", basvuruNo);

			if ((kartNo == null || "".equals(kartNo.trim())) && (basvuruNo == null || basvuruNo == BigDecimal.ZERO)) {
				throw ExceptionHandler.convertException(new GMRuntimeException(831, CreditCardTffServices.errorMessageOlustur("831", "E")));
			}

			stmt2 = conn.prepareCall("{? = call PKG_TFF_BASVURU.Bekleyen_Odeme_Bilgileri(?,?)}");
			int i = 1;
			stmt2.registerOutParameter(i++, -10);
			stmt2.setBigDecimal(i++, basvuruNo);
			stmt2.setString(i++, kartNo);
			stmt2.execute();

			rSet = (ResultSet) stmt2.getObject(1);

			if (rSet.next()) {
				int index = 0;
				oMap.put("ODEME_BILGILERI", index, "BASVURU_NO", basvuruNo);
				oMap.put("ODEME_BILGILERI", index, "ODEME_SEKLI", rSet.getString("ODEME_SEKLI"));
				oMap.put("ODEME_BILGILERI", index, "KART_BEDELI", rSet.getBigDecimal("KART_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "VIZE_BEDELI", rSet.getBigDecimal("VIZE_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "LOYALITY_BEDELI", rSet.getBigDecimal("LOYALTY_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "KURYE_BEDELI", rSet.getBigDecimal("KURYE_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_KODU", rSet.getString("PROMOSYON_KODU"));
				oMap.put("ODEME_BILGILERI", index, "ODEME_REF_ID", rSet.getString("ODEME_REF_ID"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_BEDELI", rSet.getBigDecimal("PROMOSYON_BEDELI"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_ORANI", rSet.getBigDecimal("PROMOSYON_ORANI"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_KART", rSet.getBigDecimal("PROMOSYON_KART"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_KURYE", rSet.getBigDecimal("PROMOSYON_KURYE"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_VIZE", rSet.getBigDecimal("PROMOSYON_VIZE"));
				oMap.put("ODEME_BILGILERI", index, "PROMOSYON_LOYALTY", rSet.getBigDecimal("PROMOSYON_LOYALTY"));
				oMap.put("ODEME_BILGILERI", index, "KURYE_TIPI", rSet.getString("KURYE_TIPI"));
				oMap.put("ODEME_BILGILERI", index, "UYE_ADRES_NO", rSet.getBigDecimal("UYE_ADRES_NO"));
			}
			else {
				String errorMessage = CreditCardTffServices.errorMessageOlustur("1599", "E");
				throw ExceptionHandler.convertException(new GMRuntimeException(1599, errorMessage));
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KART_ODEME_BILGILERI_WITH_FOTO")
	public static GMMap tffKartOdemeBilgileriWithPhoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String kartNo = iMap.getString("KART_NO");
			if (kartNo == null || "".equals(kartNo.trim())) {
				throw ExceptionHandler.convertException(new GMRuntimeException(831, CreditCardTffServices.errorMessageOlustur("831", "E")));
			}
			oMap = GMServiceExecuter.call("BNSPR_TFF_KART_ODEME_BILGILERI", iMap);

			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffBasvuru master = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", oMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (master != null) {
				GMMap fMap = new GMMap();
				if (master.getTcKimlikNo().isEmpty()) {
					TffBasvuruKimlik kimlik = (TffBasvuruKimlik) session.createCriteria(TffBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", oMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					fMap.put("KIMLIK_NO", kimlik.getPasaportNo());
				}
				else
					fMap.put("KIMLIK_NO", master.getTcKimlikNo());
				fMap.put("BASVURU_NO", master.getBasvuruNo());

				fMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_FOTO_PATH_VER", fMap));
				oMap.put("FOTO_PATH", fMap.get("PATH"));

				iMap.put("FILE_PATH", fMap.get("PATH"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3805_GET_FOTO", iMap));
				// FOTO_DEGER

			}

		}
		catch (Exception e) {
			String errorMessage = CreditCardTffServices.errorMessageOlustur("1599", "E");
			throw ExceptionHandler.convertException(new GMRuntimeException(1599, errorMessage));
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_MINI_INTERNET_PREAUTH")
	public static GMMap tffMiniInternetPreAuth(GMMap iMap) {
		GMMap oMap = new GMMap();

		String cardLastSix = iMap.getString("CARD_NO_LASTSIX");
		if (cardLastSix == null || "".equals(cardLastSix.trim())) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.MINI_INTERNET_KARTNO_HATASI);
			return oMap;
		}

		String mCountryCode = iMap.getString("MOBILE_COUNTRY_CODE");
		String mAreaCode = iMap.getString("MOBILE_AREA_CODE");
		String mNumber = iMap.getString("MOBILE_NUMBER");

		if (mNumber == null || "".equals(mNumber.trim()) || mAreaCode == null || "".equals(mAreaCode.trim())) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
			return oMap;
		}

		String tckn = iMap.getString("TCKN");

		String passportNo = iMap.getString("PASSPORT_NO");
		String counrtyCode = iMap.getString("COUNTRY_CODE");

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TFF_BASVURU.Get_mini_internet_preauth(?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setString(i++, cardLastSix);
			stmt.setString(i++, tckn);
			stmt.setString(i++, mCountryCode);
			stmt.setString(i++, mAreaCode);
			stmt.setString(i++, mNumber);
			stmt.setString(i++, passportNo);
			stmt.setString(i++, counrtyCode);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			ResultSetMetaData metadata = rSet.getMetaData();
			int numberOfColumns = metadata.getColumnCount();
			GMMap tmpMap = DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");

			if (tmpMap.getSize("BASVURU_BILGILERI") == 0) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Kay�t yok");
				return oMap;
			}
			else if (tmpMap.getSize("BASVURU_BILGILERI") > 1) {
				oMap.put("RESPONSE", "1");
				oMap.put("RESPONSE_DATA", TffServicesMessages.MINI_INTERNET_TEKIL_KAYIT_YOK_HATASI);
				return oMap;
			}
			else if (tmpMap.getSize("BASVURU_BILGILERI") == 1) {
				oMap.put("CUSTOMER_NO", tmpMap.getString("BASVURU_BILGILERI", 0, "MUSTERI_NO"));
				oMap.put("CARD_NO", tmpMap.getString("BASVURU_BILGILERI", 0, "KART_NO"));
				String kTipi = tmpMap.getString("BASVURU_BILGILERI", 0, "KART_TIPI");
				oMap.put("CARD_DCI", "KK".equals(kTipi) ? "C" : kTipi);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				return oMap;
			}
			System.out.println(tmpMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		/*
			oMap.put("CUSTOMER_NO", b.getMusteriNo());
			oMap.put("CARD_NO", b.getKartNo());
			oMap.put("CARD_DCI","KK".equals(b.getKartTipi()) ? "C" : b.getKartTipi());
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			*/
		return oMap;

	}

	//
	/*
	 * input
	 * CUSTOMER_NO
	 * 
	 * output
	 * 
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_GET_CARD_LIST")
	public static GMMap tffGetCardList(GMMap iMap) {
		GMMap outMap = new GMMap();

		Session sessionadc = DAOSession.getSession("ADCCore");
		Session session = DAOSession.getSession(BNSPR_SESSION_NAME);
		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
		if (tffUyeler == null) {
			outMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			outMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_UYE_KAYDI_YOK_HATASI);
			return outMap;
		}
		BigDecimal customerNo = tffUyeler.getBankaMusteriNo();
		if (customerNo == null) {
			outMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			outMap.put("RESPONSE_DATA", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
			return outMap;
		}
		User user = (User) sessionadc.createCriteria(User.class).add(Restrictions.eq("customerId", customerNo)).uniqueResult();
		if (user != null) {
			outMap.put("USER_OID", user.getOid());
			if (iMap.getString("OID_ONLY") != null && "1".equals(iMap.getString("OID_ONLY"))) {
				outMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				return outMap;
			}
		}
		else {
			outMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			outMap.put("RESPONSE_DATA", TffServicesMessages.ADC_USER_BULUNAMADI);
			return outMap;
		}
		logger.info("tffGetCardList ---> customerNo: " + customerNo);
		GMMap serviceInMap = new GMMap();
		serviceInMap.put("CUSTOMER_NO", customerNo);
		serviceInMap.put("CARD_DCI", "C");
		serviceInMap.put("TCKN", "");

		GMMap creditCardMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", serviceInMap);
		int tableSize = creditCardMap.getSize("CARD_DETAIL_INFO");
		logger.info("tffGetCardList ---> Ocean count: " + tableSize);
		int index = 0;
		for (int i = 0; i < tableSize; index++, i++) {
			String cardNo = creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO");
			// String cardEmboseName = new StringBuilder().append(creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1")).append(" ").append(creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2")).toString();
			String name1 = creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1");
			String name2 = creditCardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2");
			StringBuilder cardEmboseName = new StringBuilder().append(name1);
			if (name2 != null && !"".equals(name2)) {
				cardEmboseName.append(" ").append(name2);
			}
			outMap.put("CARD_DETAIL_INFO", index, "CARD_DCI", creditCardMap.get("CARD_DETAIL_INFO", i, "CARD_DCI"));
			outMap.put("CARD_DETAIL_INFO", index, "MASKED_CARD_NO", maskCardNumber(cardNo));
			outMap.put("CARD_DETAIL_INFO", index, "CARD_EMBOSS_NAME", cardEmboseName.toString());
			outMap.put("CARD_DETAIL_INFO", index, "CARD_PRODUCT_NAME", creditCardMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME"));
			outMap.put("CARD_DETAIL_INFO", index, "SYSTEM", "O");
		}

		serviceInMap = new GMMap();
		serviceInMap.put("CUSTOMER_NO", customerNo);
		serviceInMap.put("CARD_DCI", "A");
		serviceInMap.put("TCKN", "");

		GMMap cardMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", serviceInMap);
		tableSize = cardMap.getSize("CARD_DETAIL_INFO");
		logger.info("tffGetCardList ---> Intra count: " + tableSize);
		for (int i = 0; i < tableSize; index++, i++) {
			String cardNo = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_NO");
			GMMap iMap2 = new GMMap();
			iMap2.put("CARD_NO", cardNo);
			GMMap cardProperty = new GMMap();
			cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap2);
			String dci = cardProperty.getString("DCI");
			String name1 = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_1");
			String name2 = cardMap.getString("CARD_DETAIL_INFO", i, "CARD_EMBOSS_NAME_2");
			StringBuilder cardEmboseName = new StringBuilder();

			if (name1 != null && !"".equals(name1)) {
				cardEmboseName.append(name1);
			}
			if (name2 != null && !"".equals(name2)) {
				cardEmboseName.append(" ").append(name2);
			}

			outMap.put("CARD_DETAIL_INFO", index, "CARD_DCI", dci);
			outMap.put("CARD_DETAIL_INFO", index, "MASKED_CARD_NO", maskCardNumber(cardNo));
			outMap.put("CARD_DETAIL_INFO", index, "CARD_EMBOSS_NAME", cardEmboseName.toString());
			outMap.put("CARD_DETAIL_INFO", index, "CARD_PRODUCT_NAME", cardMap.get("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME"));
			outMap.put("CARD_DETAIL_INFO", index, "SYSTEM", "I");
		}
		outMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return outMap;
	}

	// -------------------------------------------------------------------
	// --------------------------------------------------------MURAT
	// -------------------------------------------------------------------
	/**
	 * Kuryeden iade olan kartlar icin alinan yeni teslimat adresini gunceller.
	 * 
	 * @since TYWMC-631
	 * @author murat.el
	 * @param iMap
	 *            - Basvuru/Adres bilgileri<br>
	 *            <li>TFF_BASVURU_NO - Tff Basvuru Numarasi <li>UYE_NO - Uye numarasi <li>ADRES_NO - Adres numarasi <li>ADRES_TIPI - Adres tipi <li>ADRES_RUMUZ - Adres rumuzu <li>IL_KOD - Il kod <li>IL_AD - Il ad <li>ILCE_KOD - Ilce kod <li>ILCE_AD - Ilce ad <li>ACIK_ADRES - Acik adres <li>ILETISIM_MI - Iletisim adresi mi <li>IS_MATCHED - Pigeoan eslesmesi var mi(0, 1) <li>TESLIMAT_NOKTASI_KODU -
	 *            Teslimat noktasi kodu
	 * @return oMap - Islem sonucu<br>
	 *         <li>RESPONSE - Islem Sonuc Kodu <li>RESPONSE_DATA - Islem Sonuc Aciklama
	 */
	@GraymoundService("BNSPR_TFF_TESLIMAT_ADRES_DEGISTIR")
	public static GMMap tffKuryeAdresiDegistir(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			// Adres tipi E,I olmali
			String adresTipi = iMap.getString("ADRES_TIPI");
			if (!("E".equals(adresTipi) || "I".equals(adresTipi))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ADRES_GUNCELLE_ADRES_TIPI_E_I_OLMALI_HATASI);
				return oMap;
			}

			// Basvuru var mi?
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_BASVURU_NO_BULUNAMADI_HATASI);
				return oMap;
			}

			// Basvuru uzerinde girilen adres var mi?
			boolean adresVarMi = true;
			TffBasvuruAdresId id = new TffBasvuruAdresId();
			id.setAdresKod(adresTipi);
			id.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			TffBasvuruAdres tffBasvuruAdres = (TffBasvuruAdres) session.get(TffBasvuruAdres.class, id);
			if (tffBasvuruAdres == null) {
				adresVarMi = false;
			}

			// Basvuru uzerinde adres guncellemesini yap.
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.put("UYE_NO", tffBasvuru.getTffUyeNo());
			sorguMap.put("ADRES_NO", adresVarMi == true ? tffBasvuruAdres.getUyeAdresNo() : StringUtils.EMPTY);
			sorguMap.put("ADRES_TIPI", adresTipi);
			sorguMap.put("IL_KOD", iMap.get("IL_KOD"));
			sorguMap.put("IL_AD", iMap.get("IL_AD"));
			sorguMap.put("ILCE_KOD", iMap.get("ILCE_KOD"));
			sorguMap.put("ILCE_AD", iMap.get("ILCE_AD"));
			sorguMap.put("ACIK_ADRES", iMap.get("ACIK_ADRES"));
			sorguMap.put("ADRES_RUMUZ", adresVarMi == true ? null : iMap.getString("ADRES_RUMUZ"));
			sorguMap.put("ILETISIM_MI", adresVarMi == true ? tffBasvuruAdres.getIletisimMi() : iMap.getString("ILETISIM_MI"));
			sorguMap.put("IS_MATCHED", adresVarMi == true ? null : iMap.getString("IS_MATCHED"));
			sorguMap.put("TESLIMAT_ADRESI_MI", CreditCardServicesUtil.EVET);
			sorguMap.put("TESLIMAT_NOKTASI_KODU", iMap.get("TESLIMAT_NOKTASI_KODU"));
			sorguMap.put("TESLIMAT_ADRESI_DEGISTI_MI", CreditCardServicesUtil.EVET);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS", sorguMap));
			if (AkustikConstants.RESPONSE_FAIL.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			}
			oMap.put("ADRES_NO", sorguMap.get("ADRES_NO"));

			// Basvuru bilgileri ile musteriyi guncelle
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap));
			if (AkustikConstants.RESPONSE_FAIL.equals(sorguMap.getString("RESPONSE"))) {
				oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
				oMap.put("RESPONSE_DATA", sorguMap.get("RESPONSE_DATA"));
				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", AkustikConstants.RESPONSE_SUCCESS);
		return oMap;
	}

	// ty-7832 ilerletme amacli prod sonrasi acilacak
	private static void basvuruIptal(TffBasvuru b) {
		if (b == null) {
			return;
		}
		GMMap tmpMap = new GMMap();
		tmpMap.put("TFF_BASVURU_NO", b.getBasvuruNo());
		tmpMap.put("SOURCE", b.getSource());
		tmpMap.put("GEREKCE_KOD", 2);
		tmpMap.put("ACIKLAMA", "Yarim basvuru");
		tmpMap.put("KK_BASVURU_IPTAL_MI", b.getKartTipi().equals("KK") ? "E" : "H");
		GMServiceExecuter.executeAsync("BNSPR_TFF_BASVURU_IPTAL", tmpMap);
	}

	@GraymoundService("BNSPR_TFF_UPDATE_TEAM_CODE")
	public static GMMap tffUyeTakimDegistir(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", TffServicesMessages.ISLEM_BASARILI);
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = null;
			List<?> list = null;
			list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("bankaMusteriNo", iMap.getBigDecimal("MUSTERI_NO"))).list();

			if (list != null && list.size() == 1) {
				tffUyeler = ((TffUyeler) list.get(0));
			}

			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_BILGILERI_VER_UYE_KAYDI_BULUNAMADI_HATASI);
				return oMap;
			}

			tffUyeler.setTakim(iMap.getString("NEW_TEAM_CODE"));

			List<TffBasvuru> tffbasvuruList = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("tffUyeNo", tffUyeler.getUyeNo())).list();
			for (TffBasvuru b : tffbasvuruList) {
				b.setTakim(iMap.getString("NEW_TEAM_CODE"));
				session.save(b);
				session.flush();
			}

			session.saveOrUpdate(tffUyeler);
			session.flush();

			GMMap output = DALUtil.getResults("select klup_id from bnspr.tff_takim_hesap_pr where urun_sahip_kod= '" + iMap.getString("NEW_TEAM_CODE") + "'", "TEAM_CODE");

			short teamCode = Short.parseShort(output.getString("TEAM_CODE", 0, "KLUP_ID"));

			GMMap infoMap = new GMMap();
			GMMap gMap = new GMMap();

			infoMap.put("CUSTOMER_NO", iMap.getBigDecimal("MUSTERI_NO"));
			infoMap.put("TEAM_CODE", teamCode);

			gMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_UPDATE_CUSTOMER_TEAM", infoMap));
			oMap.put("INTRA_RESPONSE", gMap.getString("RETURN_CODE"));

			gMap.clear();
			gMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_UPDATE_CUSTOMER_TEAM", infoMap));
			oMap.put("OCEAN_RESPONSE", gMap.getString("RETURN_CODE"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TFF_KIMLIK_YUKLE")
	public static GMMap tffKimlikYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			long start = System.currentTimeMillis();
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			String durumKodu = "";
			if (tffBasvuru == null) {

				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_BASVURU_NO_BULUNAMADI);
				return oMap;
			}
			start = System.currentTimeMillis();
			byte[] bytes = decode64ByteArray(iMap.getString("KIMLIK_BYTE_ARRAY"));

			start = System.currentTimeMillis();
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, tffBasvuru.getTffUyeNo());
			String kimlikNo = null;
			if (tffUyeler.getTckn() != null && tffUyeler.getTckn().compareTo(BigDecimal.ZERO) > 0) {
				kimlikNo = tffUyeler.getTckn().toString();
			}
			else {
				kimlikNo = tffUyeler.getPasaportNo();
			}

			String basvuruNo = iMap.getString("TFF_BASVURU_NO");
			double fileSize = bytes.length;

			/*
			if (fileSize > Integer.valueOf(conf.getProperty("tff-foto-max-size")) * 1024 * 1024) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_BOYUT_HATASI);
				return oMap;
			}else{
				start = System.currentTimeMillis() ;
				GMMap tMap = getFotoValidity(bytes,iMap.getString("SOURCE"));
				if ( tMap.getBoolean("VALID_MI",true) ){
					bytes = (byte[]) tMap.get("VALID_FOTO_BYTE_ARRAY");
					
					oMap.put("VALID_FOTO_BYTE_ARRAY",	encode64ByteArray(bytes));
				}
				else{
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_YUZ_TANIMA_HATASI);
					return oMap;
				}
				logger.info(" FOTO VALIDITY :"+ (System.currentTimeMillis() -start) );
			}
			*/

			start = System.currentTimeMillis();
			ImageInputStream iis = ImageIO.createImageInputStream(new ByteArrayInputStream(bytes));
			Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);

			ByteArrayInputStream bis = new ByteArrayInputStream(bytes);

			String sourceMimeType = URLConnection.guessContentTypeFromStream(bis);
			GMMap t = new GMMap();
			t.put("image/png", "png");
			t.put("image/jpeg", "jpg");
			String type = "jpg";
			if (t.getString(sourceMimeType).isEmpty()) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_RESIM_TIPI_TANIMLAMASI_HATASI);
				return oMap;
			}
			else {
				type = t.getString(sourceMimeType);
			}

			String kimlikNoLpad = StringUtil.lPad(kimlikNo, 12);
			// Iterator<?> readers = ImageIO.getImageReadersByFormatName("jpg");

			// ImageIO is a class containing static methods for locating ImageReaders
			// and ImageWriters, and performing simple encoding and decoding.

			ImageReader reader = readers.next();
			// Object source = bis;
			// ImageInputStream iis = ImageIO.createImageInputStream(source);
			reader.setInput(iis, true);
			ImageReadParam param = reader.getDefaultReadParam();

			Image image = reader.read(0, param);
			// got an image file

			String folderPath = ROOT + File.separator + "files";
			String isWindows = "H";

			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				start = System.currentTimeMillis();
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			/*
			try {
				isWindows =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "WINDOWS", BnsprType.STRING, "SISTEM"));
			}
			catch (Exception e) {
				// TODO: handle exception
			}*/

			// isWindows="E";
			if (SystemUtils.IS_OS_WINDOWS) {
				isWindows = "E";
			}
			else {
				isWindows = "H";
			}
			String[] sp = kimlikNoLpad.split("(?<=\\G.{3})");
			File klasor = null;
			boolean isFirst = false;
			String approved = "";
			Runtime runtime = Runtime.getRuntime();
			// folderPath = String.format("/%s/%s/%s/%s/%s/", folderPath,sp[0],sp[1],sp[2],kimlikNo);
			start = System.currentTimeMillis();
			for (int i = 0; i < sp.length - 1 && i < 3; i++) {
				if (TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath, "XXX");
				else
					folderPath = String.format("%s/%s", folderPath, sp[i]);

				klasor = new File(folderPath);
				if (!klasor.exists()) {
					if (isWindows.equals("E"))
						klasor.mkdir();
					else {
						String[] cmdLine = { "mkdir", folderPath };
						Process p = runtime.exec(cmdLine);
						p.waitFor();
					}
				}
			}
			folderPath = String.format("%s/%s/%s", folderPath, kimlikNo, "KIMLIK");
			klasor = new File(folderPath);
			if (!klasor.exists()) {
				if (isWindows.equals("E"))
					klasor.mkdir();
				else {
					String[] cmdLine = { "mkdir", folderPath };
					Process p = runtime.exec(cmdLine);
					p.waitFor();
				}

			}
			BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
			// bufferedImage is the RenderedImage to be written

			Graphics2D g2 = bufferedImage.createGraphics();
			g2.drawImage(image, null, null);
			start = System.currentTimeMillis();
			File imageFile = new File(folderPath + File.separator + kimlikNo + "_" + basvuruNo + "." + type);
			ImageIO.write(bufferedImage, type, imageFile);
			// ilk basvuru ise yuklenen resim approved klasorune aktarilir

			start = System.currentTimeMillis();
			// tffBasvuru.setFotoDurum("T");
			// session.save(tffBasvuru);
			// session.flush();

			logger.info(" FOTO KIMLIK EKLE  :" + (System.currentTimeMillis() - start));
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			oMap.put("RESPONSE_DATA", "BASARILI");

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FOTO_YUKLE_GENEL_HATA);
			return oMap;
		}
		/*
		
		try {
			oMap.put("TFF_BASVURU_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
			oMap.put("CRM_TYPE", CrmTypes.MAIN);
			GMServiceExecuter.call("BNSPR_TFF_SEND_APPLICATION_TO_CRM", oMap);	
		}
		catch (Exception e) {
			oMap.clear();
			oMap.put("RESPONSE_DATA", TffServicesMessages.CRM_GONDERIM_HATASI);
			oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
		}
		*/
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KART_URUN_FIYAT_VER")
	public static GMMap tffKartUrunFiyatVer(GMMap iMap) {
		GMMap oMap = new GMMap();
		String RESULT_TABLE = "RESULT_TABLE";
		String KART_URUN_FIYAT = "KART_URUN_FIYAT";
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String query = null;
		try {

			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}

			conn = DALUtil.getGMConnection();
			query = "{call PKG_TRN3801.tff_kart_urun_fiyat(?,?,?,?)}";
			stmt = conn.prepareCall(query);

			stmt.setString(1, iMap.getString("SOURCE"));
			stmt.setString(2, iMap.getString("KART_TIPI"));
			stmt.setString(3, iMap.getString("URUN_SAHIP_KOD"));

			stmt.registerOutParameter(4, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(4);
			GMMap resultMap = DALUtil.rSetResults(rSet, RESULT_TABLE);

			if (resultMap == null || resultMap.isEmpty() || resultMap.getSize(RESULT_TABLE) == 0) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_LISTE_SORGULA_KAYIT_BULUNAMADI);
				return oMap;
			}

			for (int i = 0; i < resultMap.getSize(RESULT_TABLE); i++) {

				oMap.put(KART_URUN_FIYAT, i, "URUN_SAHIP_KOD", resultMap.getString(RESULT_TABLE, i, "URUN_SAHIP_KOD"));
				oMap.put(KART_URUN_FIYAT, i, "KART_TIPI", resultMap.getString(RESULT_TABLE, i, "KART_TIPI"));
				oMap.put(KART_URUN_FIYAT, i, "KART_URUN_ID", resultMap.getString(RESULT_TABLE, i, "KART_URUN_ID"));
				oMap.put(KART_URUN_FIYAT, i, "KART_URUN_ADI", resultMap.getString(RESULT_TABLE, i, "KART_URUN_ADI"));
				oMap.put(KART_URUN_FIYAT, i, "KART_BEDELI", resultMap.getString(RESULT_TABLE, i, "KART_BEDELI"));
				oMap.put(KART_URUN_FIYAT, i, "LOYALTY_BEDELI", resultMap.getString(RESULT_TABLE, i, "LOYALTY_BEDELI"));

			}

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		}
		catch (Exception e) {
			oMap = new GMMap();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_LISTE_SORGULA_GENEL_HATA);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

		return oMap;

	}

	@GraymoundService("BNSPR_TFF_APS_SORGU_YAP")
	public static GMMap tffAPSSorguYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap adresSorguMap = new GMMap();

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		adresSorguMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
		boolean apsYapildi = true;

		if (iMap.get("TRX_NO") == null) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
		}
		adresSorguMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

		BigDecimal musteriNo = CardServicesHelper.searchCustomer("TR", iMap.getString("TCKN"), "");

		if (musteriNo.compareTo(BigDecimal.ZERO) > 0)
			adresSorguMap.put("MUSTERI_NO", musteriNo);

		adresSorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_APS_SORGULAMA", adresSorguMap));

		if (!"E".equals(adresSorguMap.getString("APS_YAPILDIMI"))) {
			apsYapildi = false;
		}

		adresSorguMap.putAll(CreditCardServicesUtil.getApsAcikAdres(adresSorguMap));

		oMap.put("IL_KOD", adresSorguMap.getString("IL_KODU"));
		oMap.put("ILCE_KOD", adresSorguMap.getString("ILCE_KODU"));
		oMap.put("IL_AD", adresSorguMap.getString("IL"));
		oMap.put("ILCE_AD", adresSorguMap.getString("ILCE"));
		oMap.put("ADRES_NO", adresSorguMap.getString("ADRES_NO"));
		oMap.put("APS_YAPILDI_MI", adresSorguMap.getString("APS_YAPILDIMI"));
		oMap.put("ACIK_ADRES", adresSorguMap.getString("ACIK_ADRES"));
		oMap.put("TRX_NO", adresSorguMap.getString("TRX_NO"));

		if (StringUtils.isEmpty(adresSorguMap.getString("ACIK_ADRES")) || StringUtils.isEmpty(adresSorguMap.getString("IL_KODU")) || StringUtils.isEmpty(adresSorguMap.getString("ILCE_KODU"))) {
			apsYapildi = false;
		}

		if (!apsYapildi) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.APS_YAPILAMADI);
			return oMap;
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_GET_GISE_KIMLIK")
	public static GMMap tffGetApprovedPhoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			TffUyeler tffUyeler = findUye(iMap.getString("UYRUK"), iMap.getBigDecimal("TCKN"), iMap.getString("PASAPORT_NO"));
			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_UYE_MEVCUT_DEGIL);
				return oMap;
			}
			String folderPath = ROOT + File.separator + "files";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}

			catch (Exception e) {
				e.printStackTrace();
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
				return oMap;
			}
			File klasor = null;
			String[] sp;
			String kimlikNo = "";
			if ("TR".equals(tffUyeler.getUyruk())) {
				kimlikNo = tffUyeler.getTckn().toString();
			}
			else {
				kimlikNo = tffUyeler.getPasaportNo();
			}
			String kimlikNoLpad = StringUtil.lPad(kimlikNo, 12);
			sp = kimlikNoLpad.split("(?<=\\G.{3})");

			for (int i = 0; i < sp.length - 1 && i < 3; i++) {
				if (TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath, "XXX");
				else
					folderPath = String.format("%s/%s", folderPath, sp[i]);
				klasor = new File(folderPath);
				if (!klasor.exists()) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
					return oMap;
				}
			}
			folderPath = String.format("%s/%s", folderPath, kimlikNo);
			folderPath += "/" + "KIMLIK" + "/" + kimlikNo + "_" + iMap.getBigDecimal("BASVURU_NO") + ".jpg";
			byte[] imageInByte;
			File file = new File(folderPath);
			if (!file.exists() || !file.isFile()) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
				return oMap;
			}
			BufferedImage originalImage = ImageIO.read(file);

			// convert BufferedImage to byte array
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(originalImage, "jpg", baos);
			baos.flush();
			imageInByte = baos.toByteArray();
			baos.close();

			oMap.put("KIMLIK_LIST", 0, "DATA", encode64ByteArray(imageInByte));
			oMap.put("KIMLIK_LIST", 0, "SAYFA", kimlikNo + "_" + iMap.getBigDecimal("BASVURU_NO") + ".jpg");
			oMap.put("SAYFA_SAYISI", 1);
			oMap.put("KIMLIK_TIPI", "N");
			oMap.put("UYRUK", tffUyeler.getUyruk());
			oMap.put("TCKN", tffUyeler.getTckn());
			oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
		}
		return oMap;

	}

	private static void kvkkSmsGonder(BigDecimal applicationNo, BigDecimal customerNo) {
		try {
			GMMap smsMap = new GMMap();
			GMMap otpMap = new GMMap();

			smsMap.put("BASVURU_NO", applicationNo);
			smsMap.put("MUSTERI_NO", customerNo);
			smsMap.put("KAYNAK", "TFF");
			smsMap.put("MESAJ_NO", "5905");
			smsMap.put("BASLIK", conf.getProperty("passolig-info-sms-header"));
			otpMap.put("CUSTOMER_NO", customerNo);

			otpMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", otpMap));

			smsMap.put("TEL_NO", otpMap.getString("PHONE_NUMBER"));
			smsMap.putAll(GMServiceExecuter.execute("BNSPR_KK_PP_BASVURU_SMS_BILDIRIM", smsMap));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@GraymoundService("BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF")
	   public static GMMap updateTokenizedCardsForTff(GMMap iMap){
		   GMMap oMap= new GMMap();
		   Session session = DAOSession.getSession("BNSPRDal");
		   try {
			List<TffBasvuru> tffBasvuruList = new ArrayList<TffBasvuru>();
			
			do {
				tffBasvuruList = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("isTokenized", false)).add(Restrictions.isNotNull("kartNo")).setMaxResults(500).list();
				if(tffBasvuruList.size()>0){
					
					updateTokenizedCardsForTff(tffBasvuruList);
				}
			}
			while (tffBasvuruList.size()>0);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		   
		   return oMap;
	   
	}

	public static GMMap updateTokenizedCardsForTff(List<TffBasvuru> tffBasvuruList){
		
		GMMap inputMap= new GMMap();
		GMMap iMap1= new GMMap();
		GMMap iMap2= new GMMap();
		GMMap iMap3= new GMMap();
		GMMap iMap4= new GMMap();
		GMMap iMap5= new GMMap();
		ArrayList<GMMap> taskList=new ArrayList<GMMap>();
		
		 boolean devam=true;

			int s=0;
			for (int i = 0; i < 100; i++) {
				if(tffBasvuruList.size()<=i){
					devam=false;
					break;
				}
					
				iMap1.put("BASVURU_LIST", s,"BASVURU_NO", tffBasvuruList.get(i).getBasvuruNo());
				
			}
			iMap1.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF_BASVURU");
			iMap1.put("SERVICE_ID", "1");
			taskList.add(iMap1);
			s=0;
			if(devam){
				for (int i =100; i < 200; i++){
					if(tffBasvuruList.size()<=i){
						devam=false;
						break;
					}
					iMap2.put("BASVURU_LIST", s,"BASVURU_NO", tffBasvuruList.get(i).getBasvuruNo());
				}
				iMap2.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF_BASVURU");
				iMap2.put("SERVICE_ID", "2");
				taskList.add(iMap2);
			}
			s=0;
			if(devam){
				for(int i=200; i<300; i++){
					if(tffBasvuruList.size()<=i){
						devam=false;
						break;
					}
					iMap3.put("BASVURU_LIST", s,"BASVURU_NO", tffBasvuruList.get(i).getBasvuruNo());
					}
				iMap3.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF_BASVURU");
				iMap3.put("SERVICE_ID", "3");
				taskList.add(iMap3);
			}
			s=0;	
			if(devam){
				for (int i =300; i < 400; i++) {
					if(tffBasvuruList.size()<=i){
						devam=false;
						break;
					}
					iMap4.put("BASVURU_LIST", s,"BASVURU_NO",tffBasvuruList.get(i).getBasvuruNo());
				}
				iMap4.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF_BASVURU");
				iMap4.put("SERVICE_ID", "4");
				taskList.add(iMap4);
			}
			 s=0;
			 if(devam){
				for (int i =400; i < 500; i++) {
					if(tffBasvuruList.size()<=i){
						break;
					}
					iMap5.put("BASVURU_LIST", s,"BASVURU_NO", tffBasvuruList.get(i).getBasvuruNo());
				}
				iMap5.put("T_SERVICE_NAME", "BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF_BASVURU");
				iMap5.put("SERVICE_ID", "5");
				taskList.add(iMap5);
			}
			 inputMap.put("T_TASKS", taskList);
			 GMMap outputMap = GMServiceExecuter.callParallel(inputMap);
		
		return outputMap;
	}
	@GraymoundService("BNSPR_UPDATE_TOKENIZED_CARDS_FOR_TFF_BASVURU")
	public static GMMap updateTokenizedCardForTffBasvuru(GMMap iMap){
		GMMap oMap= new GMMap();
		String tokenizedCardNo ="";
		// Boolean isTokenized=true;
		Session session = DAOSession.getSession("BNSPRDal");
		int j = 0;
		for (int i = 0; i < iMap.getSize("BASVURU_LIST"); i++){
			try {
				tokenizedCardNo = "";
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_LIST",i,"BASVURU_NO"));
				
				if(!StringUtils.isNumeric(tffBasvuru.getKartNo())){//tokenlanm�� ise
					//isTokenized=false;
					tffBasvuru.setIsTokenized(true);
				}else{
					tokenizedCardNo = BnsprOceanCommonFunctions.getTokenizedCardNo(tffBasvuru.getKartNo().toString());
					tffBasvuru.setKartNo(tokenizedCardNo);
					tffBasvuru.setIsTokenized(false);
				}
				session.saveOrUpdate(tffBasvuru);
				j=j+1;
				if(j==10){
					session.flush();
					j=0;
				}
				
			}
			catch (Exception e) {
				e.printStackTrace();
				continue;
				}
		}
		session.flush();
		System.out.println("SERVICE_ID"+iMap.getString("SERVICE_ID"));
        oMap.put("PARALLEL_CALL_RESULT", "X");
		
		return oMap;
	}
}
