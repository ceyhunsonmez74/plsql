package tr.com.aktifbank.bnspr.tff.document.type;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class indiBindiUyelikveOdemeSozlesmesi extends CardDocument {

	public indiBindiUyelikveOdemeSozlesmesi() {
		super("indiBindiUyelikveOdemeSozlesmesi", "indiBindiUyelikveOdemeSozlesmesi", Enums.CardDocTypes.INDIBINDI_UYELIK_ODEME_SOZLESMES�.getCode());
	}

	@Override
	public String generateXml(String applicationNo) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<MUSTERI_BILGILERI>");
		builder.append(GMServiceExecuter.call("BNSPR_KK_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		
		builder.append("</MUSTERI_BILGILERI>");

		return builder.toString();
	}
}
