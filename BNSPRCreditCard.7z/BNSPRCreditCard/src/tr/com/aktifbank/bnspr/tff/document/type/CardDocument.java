package tr.com.aktifbank.bnspr.tff.document.type;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public abstract class CardDocument {

	private int code;
	private String folderName;
	private String templateName;
	private String docName;
	
	private byte[] pdfByteArray;
	
	public CardDocument(String folderName, String templateName, int code) {
		setFolderName(folderName);
		setTemplateName(templateName);
		setCode(code);
	}
	
	public abstract String generateXml(String applicationNo);
    
	public String generateXml(String applicationNo , String barcode){
    	return null;
    }
	public String generateXml(String applicationNo , String barcode , String qrCode){
    	return null;
    }
	public void generatePdf(String applicationNo , String barkodNo) {
	}
	
	public void generatePdf(String applicationNo , String barkodNo , String qrCode) {
	}
	
	public void generatePdf(String applicationNo) {
		
		try {
			GMMap iMap = new GMMap();
			iMap.put("XML", generateXml(applicationNo));
			iMap.put("FOLDER_NAME", getFolderName());
			iMap.put("TEMPLATE_NAME", getTemplateName());
			setPdfByteArray((byte[])GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_PDF_BYTE", iMap).get("PDF_BYTE_DATA"));
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public String getDysPdfFileName(){
		StringBuilder sb=new StringBuilder();
		sb.append(getCode());
		sb.append(".pdf");
		return sb.toString();
	}
	
	public String getMailPdfFileName(){
		StringBuilder sb=new StringBuilder();
		sb.append(getDocName());
		sb.append(".pdf");
		return sb.toString();
	}
	
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public byte[] getPdfByteArray() {
		return pdfByteArray;
	}
	public void setPdfByteArray(byte[] pdfByteArray) {
		this.pdfByteArray = pdfByteArray;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	
}
