package tr.com.aktifbank.bnspr.tff.services;

public interface TffServicesMessages {

	public static final String GM_DATASOURCE = "java:/GraymoundDS";
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";

	public static final String TESLIMAT_NOKTASI ="TESLIMAT_NOKTASI";
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String EVET = "E";
	public static final String HAYIR = "H";
	public static final String UYARI = "U";
	public static final String IPTAL = "I";
	
	public static final String FACE_VALIDATION_SUCCESS = "00";  
	public static final String FACE_VALIDATION_NO_FACE = "01";
	public static final String FACE_VALIDATION_MORE_THAN_ONE_FACE ="02"; 
	public static final String FACE_VALIDATION_SMALL_FACE = "03";

	public static final String SOURCE_G4 	= "NTS01";
	public static final String SOURCE_WEB 	= "MTT01";
	public static final String SOURCE_MOBIL	= "MBL01";
	public static final String SOURCE_EPOS 	= "NTS01";
	
	public static final String KART_TIPI_KREDI_KARTI = "KK";
	public static final String KART_TIPI_PREPAID = "P";
	public static final String KART_TIPI_DEBIT = "D";
	
	
	
	
	
	public static final String OCEAN_KART_TIPI_PREPAID="Prepaid";
	public static final String OCEAN_KART_TIPI_DEBIT="Debit";
	public static final String OCEAN_KART_TIPI_KK="Credit";

	public static final String RESPONSE_BASARISIZ = "0";
	public static final String RESPONSE_BASARILI = "2";
	public static final String ISLEM_BASARILI = "Islem Basarili";
	
	public static final String TABLO_TFF_UYELER = "TFF_UYELER";
	public static final String TABLO_TFF_BASVURU_GIDEN_OTP = "TFF_BASVURU_GIDEN_OTP";
	public static final String TABLO_TFF_UYE_ADRESLER = "TFF_UYE_ADRESLER";
	public static final String TABLO_TFF_ISLEM = "TFF_ISLEM";
	public static final String TABLO_TFF_UYE_TELEFON = "TFF_UYE_TELEFON";
	
	public static final String UYE_EKLE_UYE_KAYDI_VAR_HATASI = "0001";
	public static final String UYE_EKLE_UYE_KAYDI_YOK_HATASI = "0002";
	public static final String UYE_EKLE_GENEL_HATA = "0003";
	public static final String TCKN_KONTROL_KARAKTER_SAYISI_HATASI = "0004";
	public static final String TCKN_KONTROL_CHECK_DIGIT_HATASI = "0005";
	public static final String TCKN_KPS_GENEL_HATA = "0006";
	public static final String TCKN_KPS_OLUM_HATASI = "0007";
	public static final String TCKN_KPS_DURUM_UYGUN_DEGIL_HATASI = "0008";
	public static final String TCKN_KPS_SORGU_BASARISIZ_HATASI = "0009";
	public static final String UYE_BILGILERI_VER_UYE_KAYDI_BULUNAMADI_HATASI = "0010";
	public static final String UYE_BILGILERI_VER_GENEL_HATA = "0011";
	public static final String OTP_GONDER_OTP_GONDERILEMEDI_HATASI = "0012";
	public static final String OTP_GONDER_GENEL_HATA = "0013";
	public static final String OTP_KONTROL_GENEL_HATA = "0014";
	public static final String OTP_GONDER_KONTROL_GENEL_HATA = "0015";
	public static final String TFF_BASVURU_ISLEM_KAYIT_GENEL_HATA = "0016";
	public static final String TFF_BASVURU_ISLEM_KAYIT_SESSION_ID_FARKLI_HATASI = "0017";
	public static final String TFF_BASVURU_ISLEM_DETAY_KAYIT_GENEL_HATA = "0018";
	public static final String UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI = "0019";
	public static final String UYE_EKLE_TCKN_YAS_100_KONTROLU_HATASI = "644";
	public static final String UYE_EKLE_VERILIS_TARIHI_KARA_LISTE_UYARI = "0020";
	public static final String UYE_EKLE_VERILIS_TARIHI_KARA_LISTE_HATASI = "0021";
	public static final String KARA_LISTE_KONTROL_KARA_LISTEDE_HATASI = "0022";
	public static final String KARA_LISTE_KONTROL_GENEL_HATA = "0023";
	public static final String TFF_KARA_LISTE_TCKN_VER_TARIH_HATASI = "0024";
	public static final String KPS_SORGU_YAP_VERILIS_TARIH_YANLIS_HATASI = "0025";
	public static final String UYE_ADRES_EKLE_UYE_NO_BULUNAMADI_HATASI = "0026";
	public static final String UYE_ADRES_EKLE_BASVURU_NO_BULUNAMADI_HATASI = "0027";
	public static final String UYE_ADRES_EKLE_UYE_NO_BOS_HATASI = "0028";
	public static final String UYE_ADRES_EKLE_BASVURU_NO_UYESI_FARKLI_HATASI = "0029";
	public static final String BASVURU_OLUSTUR_UYE_NO_BULUNAMADI_HATASI = "0030";
	public static final String BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI = "0031";
	public static final String BASVURU_OLUSTUR_BASVURU_NO_UYESI_FARKLI_HATASI = "0057";
	public static final String BASVURU_OLUSTUR_URUN_TIPI_TANIMSIZ_HATASI = "0032";
	public static final String BASVURU_OLUSTUR_URUN_SAHIP_KODU_TANIMSIZ_HATASI = "0033";
	public static final String BASVURU_OLUSTUR_EMAIL_BOS_HATASI = "0034";
	public static final String BASVURU_OLUSTUR_KART_TIPI_TANIMSIZ_HATASI = "0035";
	
	public static final String OTP_DOGRULAMA_OTP_ID_BULUNAMADI_HATASI = "0036";
	public static final String OTP_DOGRULAMA_OTP_DENEME_SAYISI_FAZLA_HATASI = "0037";
	public static final String OTP_DOGRULAMA_OTP_DAHA_ONCE_DOGRULANDI_HATASI = "0038";
	public static final String OTP_DOGRULAMA_OTP_HATALI_GIRIS_HATASI = "0040";
	public static final String OTP_DOGRULAMA_OTP_ZAMAN_ASIMI_HATASI = "0041";
	public static final String OTP_DOGRULAMA_OTP_KIMLIK_UYUMSUZ_HATASI = "0042";
	public static final String OTP_DOGRULAMA_OTP_CEPTEL_UYUMSUZ_HATASI = "0043";
	public static final String OTP_DOGRULAMA_KARA_LISTE_EKLENDI_HATASI = "0044";
	public static final String OTP_DOGRULAMA_KARA_LISTE_EKLENDI_UYARISI = "0045";
	public static final String OTP_GONDER_AKTIF_BASVURU_YOK_HATASI = "0046";
	public static final String OTP_GONDER_KIMLIK_CEPTEL_UYUMSUZ_HATASI = "0047";
	public static final String KARA_LISTE_KONTROL_KIMLIK_KARALISTEDE_HATASI = "0048";
	public static final String KARA_LISTE_KONTROL_KIMLIK_KARALISTEDE_OTP_UYARISI = "0049";
	public static final String KARA_LISTE_KONTROL_KIMLIK_KARALISTEDE_OTP_HATASI = "0050";
	public static final String KARA_LISTE_KONTROL_CEPTEL_KARALISTEDE_OTP_UYARISI = "0051";
	public static final String KARA_LISTE_KONTROL_CEPTEL_KARALISTEDE_OTP_HATASI = "0052";
	public static final String AKTIF_BASVURU_VAR_HATASI = "0053";
	public static final String UYE_ADRES_EKLE_GENEL_HATA = "0054";
	public static final String UYE_ADRES_EKLE_ADRES_BULUNAMADI_HATASI = "0055";
	public static final String UYE_ADRES_EKLE_E_I_VAR_HATASI = "0056";
	public static final String BASVURU_OLUSTUR_TESLIMAT_ADRESI_BOS_HATASI = "0058";
	public static final String BASVURU_OLUSTUR_TESLIMAT_ADRESI_BULUNAMADI_HATASI = "0059";
	public static final String FOTO_YUKLE_YUZ_TANIMA_HATASI = "0060";
	public static final String FOTO_YUKLE_BASVURU_DURUM_HATASI = "0061";
	public static final String FOTO_YUKLE_BASVURU_NO_BULUNAMADI = "0062";
	public static final String FOTO_YUKLE_RESIM_BOYUT_HATASI = "0063";
	public static final String FOTO_YUKLE_RESIM_TIPI_TANIMLAMASI_HATASI = "0064";
	public static final String FOTO_YUKLE_GENEL_HATA = "0065";
	public static final String ODEME_YAP_GENEL_HATA = "0066";
	public static final String ODEME_YAP_EUPT_ODEME_YAPILAMADI_HATASI = "0067";
	public static final String ODEME_YAP_BASVURU_BULUNAMADI_HATASI = "0068";
	public static final String ODEME_YAP_BASVURU_DURUM_UYGUN_DEGIL_HATASI = "0069";
	public static final String ODEME_GUNCELLE_BASVURU_BULUNAMADIL_HATASI = "0070";
	public static final String SANAL_POS_SONRASI_ODEME_GUNCELLE_HATA = "0071";
	public static final String ODEME_ALINDI_YENILEMEDE_HATA = "0072";

	public static final String ODEME_GUNCELLE_BASVURU_DURUM_UYGUN_DEGIL_HATASI ="0080";
	public static final String ODEME_GUNCELLE_ISLEM_NO_EKSIK_HATASI = "0081";
	public static final String KARA_LISTE_EKLE_GENEL_HATA = "0082";
	public static final String UYE_KART_ALABILIRLIK_GENEL_HATA = "0083";
	public static final String KARA_LISTE_EKLE_VT_YANLIS_1_UYARISI = "0084";
	public static final String KARA_LISTE_EKLE_VT_YANLIS_2_UYARISI = "0085";
	public static final String KARA_LISTE_EKLE_VT_YANLIS_3_UYARISI = "0086";
	public static final String KARA_LISTE_KONTROL_VERITAMAMLAMA_FRAUD_HATASI = "0087";
	public static final String KARA_LISTE_KONTROL_VERITAMAMLAMA_BLOKE_HATASI = "0088";
	public static final String BASVURU_KART_GUNCELLE_BASVURU_NO_YOK_HATASI = "0089";
	public static final String BASVURU_KART_GUNCELLE_BASVURU_NO_BULUNAMADI = "0090";
	public static final String BASVURU_OLUSTUR_KIMLIK_SERI_NO_YANLIS_HATASI = "0100";
	public static final String BASVURU_KART_BILGI_VER_BASVURU_BULUNAMADI_HATASI = "0101";
	public static final String BASVURU_KART_BILGI_VER_KART_BILGISI_DOLU_HATASI = "0102";
	public static final String BASVURU_KART_BILGI_VER_KURYE_TIPI_HATASI = "0103";
	public static final String BASVURU_KART_BILGI_DURUM_KART_BILGI_VER_DEGIL_HATASI = "0104";
	public static final String BASVURU_OLUSTUR_EV_ALAN_EV_ADRES_UYUMSUZ = "0105";
	public static final String BASVURU_OLUSTUR_IS_ALAN_IS_ADRES_UYUMSUZ = "0106";
	public static final String UYE_EKLE_UYE_KAYDI_BASARISIZ = "0107";
	public static final String UYE_EKLE_OLUSTURMA_HATA = "0108";
	public static final String ODEME_YAP_PROMOSYON_KODU_BULUNAMADI_HATASI = "0109";
	public static final String ODEME_YAP_PROMOSYON_KODU_KULLANILAMAZ_HATASI = "0110";
	
	public static final String KARA_LISTE_EKLE_TCKN_KONTROL_UYARISI = "0111";
	public static final String KARA_LISTE_EKLE_TCKN_KONTROL_HATASI = "0112";
	public static final String IL_ILCE_KODLARI_UYUMLU_DEGIL_HATASI = "0113";
	public static final String EMAIL_HATALI_HATASI = "0114";
	public static final String TEL_NO_HATALI_HATASI = "0115";
	public static final String CALISMA_SEKLI_HATASI = "0116";
	public static final String EGITIM_KOD_HATASI = "0117";
	public static final String UYRUK_KOD_HATASI = "0118";
	public static final String KARA_TIPI_HATASI = "0119";
	public static final String URUN_SAHIP_KOD_HATASI = "0120";
	public static final String URUN_GECERLI_DEGIL_HATASI = "0121";
	public static final String FIZIKI_BASVURU_ALAN_KONTROL_GENEL_HATA = "0122";
	public static final String MESLEK_KOD_HATASI = "0123";
	public static final String BASVURU_KART_BILGI_VER_INTRACARD_HATASI = "0124";
	public static final String BASVURU_OLUSTUR_CEP_NO_BOS_HATASI = "0125";
	public static final String ADRES_TIPI_HATASI = "0126";
	public static final String DEBIT_BASVURU_YAPILAMAZ_HATASI = "0127";
	public static final String MUSTERI_KART_ESLESTIRILEMEDI = "3285";
	
	public static final String URUN_LISTE_SORGULA_GENEL_HATA = "0128";
	public static final String GISE_FOTO_GUNCELLENEMEDI = "3308";
	public static final String AKTIF_D_KART_MEVCUT_HATASI = "0129";
	public static final String AKTIF_P_KART_MEVCUT_HATASI = "0130";
	public static final String AKTIF_KK_KART_MEVCUT_HATASI = "0131";
	public static final String MINI_INTERNET_KARTNO_HATASI = "0132";
	public static final String MINI_INTERNET_TEKIL_KAYIT_YOK_HATASI = "0134";
	public static final String MUSTERI_NO_BULUNAMADI = "0135";
	public static final String MUSTERI_KART_ESLESTIRILEMEDI_DAHA_ONCE_ESLESTIRILMIS_KART = "0136";
	public static final String ADC_USER_BULUNAMADI ="0137";
	public static final String FIZIKI_BASVURU_V2_GENEL_HATA = "0137";
	public static final String UYE_MESLEKI_BILGI_EKLE_GENEL_HATA = "0138";
	public static final String GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL = "0139";
	public static final String GET_APPROVED_PHOTO_GENEL_HATA = "0140";
	public static final String GET_APPROVED_PHOTO_UYE_MEVCUT_DEGIL = "0141";

	public static final String TFF_BASVURU_IPTAL_BASVURU_NO_BULUNAMADI = "0147";
	public static final String TFF_BASVURU_IPTAL_GENEL_HATA = "0142";
	public static final String TFF_BASVURU_IPTAL_BASVURU_DURUM_IPTAL_EDILEMEZ = "0143";
	
	public static final String BASVURU_OLUSTUR_MUSTERI_BULUNAMADI = "0144";
	public static final String WEB_SERVIS_GECERSIZ_SOURCE = "0145";
	public static final String BASVURULAN_KART_UYGUN_DEGIL = "0146";
	public static final String EKSTRE_TIPI_EMAIL_SECILEMEZ = "147";
	public static final String UYE_TELEFON_EKLE_GENEL_HATA = "0148";
	public static final String BASVURU_OLUSTUR_GENEL_HATA = "0149";
	public static final String UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI = "0150";
	public static final String BASVURU_KIMLIK_BILGISI_HATASI = "0151";
	public static final String AKTIF_P_BASVURU_VAR_HATASI = "0152";
	public static final String AKTIF_D_BASVURU_VAR_HATASI = "0153";
	public static final String AKTIF_KK_BASVURU_VAR_HATASI = "0154";
	public static final String GECERSIZ_KURYE_TIPI = "0155";
	public static final String ANNEKIZLIK_SOYADI_BOS_OLAMAZ = "0156";
	public static final String GECERSIZ_TARIH = "0157";
	public static final String BASVURU_TELEFON_EKLE_BASVURU_NO_BULUNAMADI = "0158";
	public static final String GECERSIZ_ODEME_TIPI = "0159";
	public static final String KART_NO_BOS = "0160";
	public static final String ADRES_ESLESTIRME_HATASI = "0161";
	
	public static final String PROMOSYON_GRUP_ID_BOS = "0162";//4315
	public static final String PROMOSYON_GRUP_ADI_BOS = "0163";//4316
	public static final String PROMOSYON_URUN_BOS = "0164";//4317
	public static final String PROMOSYON_BASLANGIC_TARIHI_UYGUN_DEGIL = "0165";//4318
	public static final String PROMOSYON_BITIS_TARIHI_UYGUN_DEGIL = "0166";//4319
	public static final String HESAP_NO_BULUNAMADI = "0167";
	public static final String KK_TESLIMAT_ADRESI_D_OLAMAZ = "0168";
	
	public static final String BATCH_BASVURU_HATA = "0169";
	public static final String HESAP_BAKIYE_YETERSIZ_HATA = "1861";//1861
	public static final String DESTEK_HESAP_EKSTRE_EPOSTA_ICIN_EMAIL_BOS_OLAMAZ = "0170";
	public static final String DESTEK_HESAP_EKSTRE_POSTA_ICIN_SECIM_BOS_OLAMAZ = "0171";//posta ile gidecek adres secilmemis
	public static final String DESTEK_HESAP_EKSTRE_TIPI_BOS_OLAMAZ = "0172";
	public static final String DESTEK_HESAP_AYLIK_GELIR_BOS_OLAMAZ = "0173";
	public static final String DESTEK_HESAP_KART_TIPI_UYGUN_DEGIL = "0174";
	public static final String ODEME_YAP_PROMOSYON_KODU_KULLANIM_SURESI_HATALI ="0175";
	public static final String ODEME_YAP_PROMOSYON_KODU_KULLANILMISTIR ="0176";
	public static final String GECERSIZ_CEP_ALAN_KODU ="0177";
	public static final String KIMLIK_SERI_NO_BOS_OLAMAZ = "0178";
	public static final String KIMLIK_SIRA_NO_BOS_OLAMAZ = "0179";
	public static final String ANNE_KIZLIK_SOYADI_BOS_OLAMAZ = "0180";
	public static final String CALISMA_SEKLI_BOS_OLAMAZ = "0181";
	public static final String OGRENIM_DURUMU_BOS_OLAMAZ = "0182";
	public static final String MESLEK_BOS_OLAMAZ = "0183";
	public static final String ISYERI_ADI_BOS_OLAMAZ = "0184";
	public static final String ISYERI_VERGI_DAIRESI_IL_BOS_OLAMAZ = "0185";
	public static final String ISYERI_VERGI_DAIRESI_ADI_BOS_OLAMAZ = "0186";
	public static final String AYLIK_GELIR_BOS_OLAMAZ = "0187";
	public static final String EV_IL_BOS_OLAMAZ = "0188";
	public static final String EV_TEL_BOS_OLAMAZ = "0189";
	public static final String IS_IL_BOS_OLAMAZ = "0190";
	public static final String IS_TEL_BOS_OLAMAZ = "0191";
	public static final String EKSTRE_ADRESI_SECIMI_BOS_OLAMAZ = "0192";
	public static final String BASVURU_KART_TIPI_ICIN_OTP_GEREKLI = "0193";
	public static final String ODEME_BULUNAMADI = "0194";
	public static final String G4_ODEME_TUTARI_HATALI = "0195";
	public static final String MOBIL_UYUMSUZ_VERSION = "0196";
	public static final String EKSTRE_ADRESI_TIPI_BOS_OLAMAZ = "0197";
	public static final String URUN_KANAL_KONTROLU_YAPILAMADI = "0198";
	public static final String KK_KART_KAPAMA_TALEBI_VAR = "0200";
	public static final String D_KART_KAPAMA_TALEBI_VAR = "0201";
	public static final String P_KART_KAPAMA_TALEBI_VAR = "0202";
	public static final String ODEME_YAP_PROMOSYON_KODU_IPTAL = "0203";
	public static final String KPS_TARIH_HESAPLANAMADI  = "0199";
	public static final String KPS_CUZDAN_BILGISI_EKSIK = "0204";
	public static final String KPS_KISI_BILGISI_EKSIK = "0205";
	public static final String KPS_VATANDASLIKTAN_CIKMA = "0206";
	public static final String KPS_VERILIS_NEDENI_BOS = "0207";
	public static final String ADRES_HATALI = "0208";
	public static final String AKTIF_KART_BASVURUSU_KONTROL_HATASI = "0209";
	public static final String G4_KART_ILE_BASVURU_UYUMSUZ = "0210";
	public static final String SMS_FOTO_YUKLE_KOD_BULUNAMADI = "0211";
	public static final String SMS_BASVURU_GUNCELLENEMEZ = "0212";
	public static final String G4_KART_INFO_INTRA_HATASI = "0213";
	public static final String ODEME_YAP_SANAL_POS_HATA = "0214";
	public static final String APS_YAPILAMADI = "0215";
	public static final String VERGI_DAIRESI_IL_BILGISI_ALINAMADI = "0216";
	public static final String ONSEKIZ_YAS_KK_D_KONTROLU = "0217";
	public static final String GISE_USER_BOS_OLAMAZ = "0218";
	public static final String GISE_ID_BOS_OLAMAZ = "0219";
	public static final String PROMOSYON_KODU_KART_TIPI_UYGUN_DEGIL = "0220";
	public static final String KK_HESAP_KESIM_TARIHI_BOS_OLAMAZ = "0221";
	public static final String KK_OTOMATIK_ODEME_TALIMATI_BOS_OLAMAZ = "0222";
	public static final String CEP_ULKE_KOD_HATALI = "0223";
	public static final String CEP_ALAN_KOD_HATALI = "0224";
	public static final String CEP_TEL_NO_HATALI = "0225";
	public static final String IS_ULKE_KOD_HATALI = "0226";
	public static final String IS_ALAN_KOD_HATALI = "0227";
	public static final String IS_TEL_NO_HATALI = "0228";
	public static final String EV_ULKE_KOD_HATALI = "0229";
	public static final String EV_ALAN_KOD_HATALI = "0230";
	public static final String EV_TEL_NO_HATALI = "0231";
	public static final String EV_ILCE_BOS_OLAMAZ = "0232";
	public static final String EV_ACIK_ADRES_BOS_OLAMAZ = "0233";
	public static final String IS_ILCE_BOS_OLAMAZ = "0234";
	public static final String IS_ACIK_ADRES_BOS_OLAMAZ = "0235";
	public static final String DIGER_ADRES_IL_BOS_OLAMAZ = "0236";
	public static final String DIGER_ADRES_ILCE_BOS_OLAMAZ = "0237";
	public static final String DIGER_ADRES_ACIK_ADRES_BOS_OLAMAZ = "0238";
	public static final String AYLIK_GELIR_100_DEN_BUYUK_OLMALI = "0239";
	public static final String TUTULAN_TAKIM_BOS_OLAMAZ = "0240";
	public static final String PROMOSYON_KODU_GECERSIZ_KART_TIPI = "0241";
	public static final String PROMOSYON_KODU_GECERSIZ_KANAL = "0242";
	public static final String PROMOSYON_KODU_GECERSIZ_URUN = "0243";
	public static final String KK_KART_ALABILME_RED = "0244";
	public static final String UYE_NO_ILE_TCKN_FARKLI = "0245";//gonderilen uye no ile iliskili tckn ile inputtan gelen tckn farkli ise
	public static final String YASAKLI_KIMLIK_BILGISI = "0246";
	public static final String VIZE_ODEME_HATASI = "0247";
	public static final String CRM_GONDERIM_HATASI = "0248";
	public static final String KART_TALEP_BASVURU_P2D_CEVRIME_UYGUN_DEGIL = "0249";
	public static final String BASVURU_OZET_BILGI_KAYIT_BULUNAMADI = "0250";
	
	public static final String OTP_GONDERILEMEDI_HATASI_SIM_OPERATOR_DEGISIKLIK= "0251"; // -991
	public static final String OTP_GONDERILEMEDI_HATASI_OPERATOR_DEGISIKLIK= "0252"; // -701
	public static final String OTP_GONDERILEMEDI_HATASI_SIM_DEGISIKLIK= "0253"; // -700
	public static final String OTP_GONDERILEMEDI_HATASI_SIM_KART_DEGISIKLIK= "0254"; // 509
	public static final String OTP_GONDERILEMEDI_HATASI_SIM_KART_DEGISIKLIK_ZAMAN= "0255"; // 603
	public static final String OTP_GONDERILEMEDI_HATASI_SIM_KART_DEGISIKLIK_NOTIFIED= "0256"; // 613
	public static final String OTP_GONDERILEMEDI_HATASI_NUMARA_TASIMA= "0257"; // 5015
	public static final String OTP_GONDERILEMEDI_HATASI_SIM_KART_DEGISIM_TARIHI_CHECK_DATE= "0258"; // 5019
	
	public static final String TFF_BASVURU_IPTAL_GEREKCE_KOD_BOS = "0259";
	public static final String TFF_BASVURU_IPTAL_INVALID_GEREKCE_KOD = "0260";
	
	public static final String KART_BASVURU_TALEP_P2D_GENEL_HATA = "0261";
	public static final String KART_BASVURU_TALEP_DEBIT_TALEP_ALINDI = "0262";
	public static final String KART_BASVURU_TALEP_P2D_TALEP_ALINDI = "0263";
	
	public static final String KART_BASVURU_TALEP_P2D_VALIDASYON_HATASI = "0264";
	
	public static final String DOGUM_TARIHI_HATALI = "0265";
	public static final String BASVURU_YAS_KONTROLU = "0266";
	public static final String URUN_LISTE_SORGULA_KAYIT_BULUNAMADI = "0267";
	public static final String GERCEK_MUSTERI_UZERINDEKI_TEL_BASVURUDAN_FARKLI = "0268";
	public static final String KONTAKT_MUSTERI_UZERINDEKI_TEL_BASVURUDAN_FARKLI = "0269";
	public static final String GERCEK_MUSTERI_UZERINDE_KAYITLI_TEL_YOK = "0270";
	public static final String KONTAKT_MUSTERI_UZERINDE_KAYITLI_TEL_YOK = "0271";
	public static final String GIRILEN_TEL_BASKA_MUSTERI_UZERINDE_KAYITLI = "0272";
	public static final String YABANCI_UYRUKLU_TCKN_GIRILEMEZ = "0273";
	public static final String ADRES_NO_UYUMSUZ_HATASI = "0274";
	public static final String GIRILEN_TELEFON_NUMARASIYLA_EN_FAZLA_10_KAYIT_YAPILABILIR ="0275";
	public static final String GIRILEN_TELEFON_NUMARASIYLA_EN_FAZLA_1_KREDI_KARTI_BA�VURUSU_YAPILABILIR="0276";
	public static final String BASKA_KK_MUSTERISI_VAR_HATASI="0277";



	public static final String ADRES_GUNCELLE_ADRES_BULUNAMADI_HATASI = "5240";
	public static final String ADRES_GUNCELLE_ADRES_TIPI_E_I_OLMALI_HATASI = "5241";
	public static final String KART_TALEP_TCKN_MUSTERISI_BULUNAMADI = "5228";
	public static final String KART_TALEP_TCKN_MUSTERISI_MUSTERI_NO_ILE_UYUMSUZ = "5229";
	public static final String KART_TALEP_AKTIF_TALEP_VAR = "5221";	
	public static final String DOKUMAN_SORGULA_SORGU_TIPI_HATALI = "5268";
	public static final String DOKUMAN_SORGULA_DOKUMAN_KODU_HATALI = "5269";
	public static final String DOKUMAN_KAYDET_ISLEM_TIPI_HATALI = "5270";
	public static final String DOKUMAN_KAYDET_DOSYA_ICERIK_HATALI = "5271";
	public static final String TFF_BASVURU_IPTAL_BASVURU_DURUM_IPTAL_EDILEMEZ_DEF = "Basvuru durumu iptale uygun degildir";
	public static final int KART_BASVURU_TALEP_ILK_DURUM_KOD = 0;
	public static final int KART_BASVURU_TALEP_BEKLEMEDE_DURUM_KOD = -1;
	
	public static enum PassoligCardName{
		
		DEBIT("D" , "Banka Kart�"),
		KREDI_KARTI("KK" , "Kredi Kart�"),
		PREPAID("P" , "�n �demeli Kart");
		
		
		
		
        private String code;
        private String name ;
        private PassoligCardName(String code , String name) {
                this.code = code;
                this.name = name;
        }
        
		public String getCode() {
			return code;
		}
		
		public String getName(){
			return name;
		}
		
		public static PassoligCardName getByCode(String code){
			for(PassoligCardName v : PassoligCardName.values()){
		        if( v.code.equals(code)){
		            return v;
		        }
		      
		    }
			return null;

		}
	};
	
}
