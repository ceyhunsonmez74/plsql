package tr.com.aktifbank.bnspr.tff.services;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import tr.com.aktifbank.bnspr.dao.GnlParamText;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;

import javax.imageio.ImageIO;
import javax.print.DocFlavor.STRING;

import net.dflora.pigeon.fix.AddressOut;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.joda.time.DateTime;
import org.joda.time.Years;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KartKuryeUcretPr;
import tr.com.aktifbank.bnspr.dao.KartKuryeUcretPrTx;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.MrcQrMerchantDefinitions;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdres;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruAdresTxId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruGidenOtp;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKdhTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruKimlikTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgi;
import tr.com.aktifbank.bnspr.dao.TffBasvuruMeslekiBilgiTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruOdeme;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefon;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTelefonTxId;
import tr.com.aktifbank.bnspr.dao.TffBasvuruTx;
import tr.com.aktifbank.bnspr.dao.TffBasvuruVizeTx;
import tr.com.aktifbank.bnspr.dao.TffKrediKartiBasvuru;
import tr.com.aktifbank.bnspr.dao.TffServiceLog;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.dao.GnlMusteriTelefon;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.calikbank.integration.webservices.kps.KPSUtil;
import tr.com.obss.adc.core.otp.util.OtpGenerator;
import tr.com.obss.adc.core.util.ADCSession;
import tr.gov.nvi.kpsv2.model.CuzdanModel;
import tr.gov.nvi.kpsv2.model.KisiModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.BilesikKutukModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCCuzdanBilgisiModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKKModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKisiBilgisiModel;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.sun.mail.handlers.image_gif;

/**
 * 
 * Bu class tum kanallar icin is kurallari disinda temel kaydetme,
 * sorgulama,gonderme gibi ortak yapilarin oldugu ve is kurali icermeyen servislerin bulundugu yerdir
 * 
 * 
 */
public class TffCommonServices extends TffServicesHelper {

	private static final Logger logger = Logger.getLogger(TffCommonServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/aktifbank-int-tff.properties");
	/*EVAM event type*/
	private static boolean isLocal = false;
	static {
		try {
			isLocal = ("1".equals(conf.getProperty("isLocal"))) ? true : false;
		}
		catch (Exception e) {
			isLocal = false;
		}
	}

	/**
	 * 
	 * INPUT :
	 * CLIENT_SESSION_ID*
	 * CLIENT_IP*
	 * TCKN*
	 * PASAPORT : yabanc� ise zorunlu
	 * CEP_TEL_NO*
	 * LOGIN_MI
	 * SOURCE*
	 * GIDEN_MESAJ_KOD*
	 * DIL
	 * EMAIL
	 * TAKIM
	 * WEB_DOGUM_TARIHI: yabanc� ise zorunlu
	 * WEB_ADI: yabanc� ise zorunlu
	 * WEB_SOYADI: yabanc� ise zorunlu
	 * WEB_IKINCI_ADI: yabanc� ise zorunlu
	 * UYRUK : yabanc� ise zorunlu
	 * 
	 * 
	 * OUTPUT:
	 * OTP_ID
	 * RESPONSE
	 * RESPONSE_DATA
	 * */
	@GraymoundService("BNSPR_TFF_BUS_OTP_GONDER")
	public static GMMap tffWebOtpGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			// musteri varsa gelen telefon yerine otp telefonuna otp gonder

			GMMap otpMap = GMServiceExecuter.call("BNSPR_TFF_OTP_GONDER_KONTROL", iMap);
			if (TffServicesMessages.RESPONSE_BASARILI.equals(otpMap.getString("RESPONSE"))) {
				otpMap.putAll(iMap);
				otpMap.putAll(GMServiceExecuter.call("BNSPR_TFF_OTP_GONDER", otpMap));

				if (TffServicesMessages.RESPONSE_BASARILI.equals(otpMap.getString("RESPONSE"))) {

					oMap.put("OTP_ID", otpMap.getString("OTP_ID"));
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

				}
				else {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", otpMap.getString("RESPONSE_DATA"));
					return oMap;
				}
			}
			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", otpMap.getString("RESPONSE_DATA"));
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.OTP_GONDER_GENEL_HATA);
		}
		return oMap;
	}

	/*
	 * 
	 * 
	 * */

	@GraymoundService("BNSPR_TFF_OTP_GONDER")
	public static GMMap tffOtpGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_GENERATE_OTP_VALUE_AND_ID_AND_RETURN", iMap));

		if (isLocal) {
			GMServiceExecuter.execute("BNSPR_TFF_ASYNCH_OTP_CALL", oMap);
		}
		else {
			GMServiceExecuter.executeAsync("BNSPR_TFF_ASYNCH_OTP_CALL", oMap);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_GENERATE_OTP_VALUE_AND_ID_AND_RETURN")
	public static GMMap generateOtpValueAndIdAndReturn(GMMap iMap) {
		GMMap otpMap = new GMMap();
		String otpCharacterSet = "0123456789";
		int otpLength = 6;
		try {
			otpCharacterSet = conf.getProperty("tff_otp_character_set");
			otpLength = Integer.parseInt(conf.getProperty("tff_otp_length"));
		}
		catch (Exception e) {
			e.printStackTrace();
			otpCharacterSet = "0123456789";
			otpLength = 6;
		}
		String otpValue = OtpGenerator.generate(otpCharacterSet, otpLength);
		GMMap otpMessageMap = new GMMap();
		otpMessageMap.put("MESSAGE_NO", iMap.getString("GIDEN_MESAJ_KOD"));
		otpMessageMap.put("P1", BnsprOceanCommonFunctions.otpValueforCodec(otpValue));
		otpMessageMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", otpMessageMap));
		otpMap.put("GIDEN_MESAJ", otpMessageMap.getString("ERROR_MESSAGE"));
		otpMap.put("HEADER", StringUtils.isNotBlank(iMap.getString("HEADER")) ? iMap.getString("HEADER") : conf.getProperty("passolig-otp-sms-header"));
		otpMap.put("CEP_NO", iMap.getString("CEP_TEL_NO"));
		otpMap.put("KIMLIK_NO", StringUtils.isNotBlank(iMap.getString("TCKN")) ? iMap.getString("TCKN") : iMap.getString("PASAPORT"));

		GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_BASVURU_GIDEN_OTP);
		BigDecimal otpId = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");

		otpMap.put("OTP_ID", otpId);
		otpMap.put("OTP_CEVAP", otpValue);
		otpMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return otpMap;
	}

	@GraymoundService("BNSPR_TFF_ASYNCH_OTP_CALL")
	public static GMMap asynchTffOtpCall(GMMap otpMap) {
		GMMap oMap = new GMMap();

		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_SMS_GONDER", otpMap));

		if (TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruGidenOtp basvuruGidenOtp = new TffBasvuruGidenOtp();
			basvuruGidenOtp.setCepTelNo(otpMap.getString("CEP_NO"));
			basvuruGidenOtp.setDenemeSayisi(BigDecimal.ZERO);
			basvuruGidenOtp.setDurum("B");
			basvuruGidenOtp.setKimlikNo(otpMap.getString("KIMLIK_NO"));
			basvuruGidenOtp.setOtpValue(otpMap.getString("OTP_CEVAP"));
			basvuruGidenOtp.setSmsRefId(oMap.getString("BNSPR_LOG_ID"));
			basvuruGidenOtp.setId(otpMap.getBigDecimal("OTP_ID"));
			session.saveOrUpdate(basvuruGidenOtp);
			session.flush();

		}
		else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			String response_data = TffServicesMessages.OTP_GONDER_OTP_GONDERILEMEDI_HATASI;
			oMap.put("RESPONSE_DATA", response_data);
			// CreditCardTffServicesMessages.errorMessageOlustur("3012", "E",iMap.getString("CEP_NO")));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_OTP_KONTROL")
	public static GMMap tffOtpKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String procStr = "{call BNSPR.PKG_TRN3801.TFF_BASVURU_OTP_DOGRULAMA (?,?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			String pasaportNo = iMap.getString("PASAPORT_NO", "");
			if (!StringUtils.isEmpty(pasaportNo)) {
				pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			}
			Object[] inputValues = new Object[16];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = pasaportNo; // iMap.getString("PASAPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CEP_TEL_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("OTP_CEVAP");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("OTP_ID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CLIENT_IP");

			i = 0;
			Object[] outputValues = new Object[6];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "UYE_NO";
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.OTP_KONTROL_GENEL_HATA);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TFF_BASVURU_IPTAL")
	public static GMMap tffBasvuruIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru == null) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_BASVURU_NO_BULUNAMADI);
				return oMap;
			}

			if (!basvuruIptalEdilebilirMi(tffBasvuru, iMap.getString("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR))) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_BASVURU_DURUM_IPTAL_EDILEMEZ);
				return oMap;
			}

			if (StringUtils.isEmpty(iMap.getString("GEREKCE_KOD"))) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_GEREKCE_KOD_BOS);
				return oMap;
			}
			session.flush();

			Criteria criteria = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "KK_BASVURU_AKSIYON_KARAR_KOD")).add(Restrictions.eq("key1", "C")).add(Restrictions.eq("key2", iMap.getString("GEREKCE_KOD")));
			GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
			session.flush();

			if (gnlParamText == null) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_INVALID_GEREKCE_KOD);
				return oMap;
			}

			GMMap iptalMap = new GMMap();
			iptalMap.put("BASVURU_NO", iMap.getBigDecimal("TFF_BASVURU_NO"));
			iptalMap.put("ONCEKI_DURUM_KOD", tffBasvuru.getDurumKod());
			iptalMap.put("ISLEM_KOD", iMap.getString("SOURCE"));
			iptalMap.put("GEREKCE_KOD", iMap.getString("GEREKCE_KOD"));
			iptalMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
			iptalMap.put("KK_BASVURU_IPTAL_MI", StringUtils.isEmpty(iMap.getString("KK_BASVURU_IPTAL_MI")) ? "H" : iMap.getString("KK_BASVURU_IPTAL_MI"));
			/*
			 * <li>BASVURU_NO - Basvuru numarasi
			*        <li>ONCEKI_DURUM_KOD - Basvuru durum kodu
			*        <li>ISLEM_KOD - Iptalin hangi ekran ya da islemden yapildigi.
			*        <li>GEREKCE_KOD - Iptal gerekcesi
			*        <li>ACIKLAMA - Iptal aciklamasi
			*        <li>>KK_BASVURU_IPTAL_MI - Basvuruya ait kredi karti var ise iptal edilsin mi(E:Evet | H:Hayir)
			 */
			iptalMap = GMServiceExecuter.call("BNSPR_TRN3809_SAVE", iptalMap);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_IPTAL_GENEL_HATA);

		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_GET_APPROVED_PHOTO")
	public static GMMap tffGetApprovedPhoto(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("TFF_UYE_NO"));
			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_UYE_MEVCUT_DEGIL);
				return oMap;
			}
			String folderPath = ROOT + File.separator + "files";
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			try {
				folderPath = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "K", BnsprType.STRING, "RESIM_PATH"));
			}

			catch (Exception e) {
				e.printStackTrace();
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
				return oMap;
			}
			File klasor = null;
			String[] sp;
			String kimlikNo = "";
			if ("TR".equals(tffUyeler.getUyruk())) {
				kimlikNo = tffUyeler.getTckn().toString();
			}
			else {
				kimlikNo = tffUyeler.getPasaportNo();
			}
			String kimlikNoLpad = StringUtil.lPad(kimlikNo, 12);
			sp = kimlikNoLpad.split("(?<=\\G.{3})");

			for (int i = 0; i < sp.length - 1 && i < 3; i++) {
				if (TffServicesHelper.isWindowsReservedFilename(sp[i]))
					folderPath = String.format("%s/%s", folderPath, "XXX");
				else
					folderPath = String.format("%s/%s", folderPath, sp[i]);
				klasor = new File(folderPath);
				if (!klasor.exists()) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
					return oMap;
				}
			}
			folderPath = String.format("%s/%s", folderPath, kimlikNo);
			folderPath += "/" + conf.getProperty("gise_foto_folder") + "/" + kimlikNo + ".jpg";
			byte[] imageInByte;
			File file = new File(folderPath);
			if (!file.exists() || !file.isFile()) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_PATH_MEVCUT_DEGIL);
				return oMap;
			}
			BufferedImage originalImage = ImageIO.read(file);

			// convert BufferedImage to byte array
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(originalImage, "jpg", baos);
			baos.flush();
			imageInByte = baos.toByteArray();
			baos.close();
			oMap.put("TFF_APPROVED_IMAGE", encode64ByteArray(imageInByte));
			oMap.put("TFF_APPROVED_IMAGE_PATH", folderPath);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GET_APPROVED_PHOTO_GENEL_HATA);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TFF_OTP_GONDER_KONTROL")
	public static GMMap otpGonderKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kpsMap = new GMMap();

		try {
			if ("MBL01".equals(iMap.getString("SOURCE")) && StringUtils.isNotBlank("VERSION")) {
				GMMap xMap = new GMMap();
				xMap.put("PARAMETRE", "TFF_MOBIL_APP_VERSION");
				String v = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER").toString();
				BigDecimal version = new BigDecimal(v);
				if (iMap.getBigDecimal("VERSION").compareTo(version) < 0) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.MOBIL_UYUMSUZ_VERSION);
					return oMap;
				}
			}
			else if ("MBL01".equals(iMap.getString("SOURCE")) && StringUtils.isBlank("VERSION")) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MOBIL_UYUMSUZ_VERSION);
				return oMap;
			}
			if (StringUtils.isNotBlank(iMap.getString("WEB_DOGUM_TARIHI")) && iMap.getDate("WEB_DOGUM_TARIHI") != null && "H".equals(iMap.getString("LOGIN_MI"))) {
				String dt = iMap.getString("WEB_DOGUM_TARIHI");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				sdf.setLenient(false);
				Date webDt = sdf.parse(dt);
				if ("TR".equals(iMap.getString("UYRUK"))) {
					kpsMap.put("TCKN", iMap.getString("TCKN"));
					kpsMap.put("TCK_NO", iMap.getString("TCKN"));
					kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
					if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
						return kpsMap;
					}
					Date kpsDt = kpsMap.getDate("DOGUM_TARIHI");

					if (kpsDt.compareTo(webDt) != 0) {
						GMMap karalisteMap = new GMMap();
						karalisteMap.put("KILIT_SEBEP", "2");
						karalisteMap.putAll(iMap);
						karalisteMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KARA_LISTEYE_EKLE", karalisteMap));
						oMap.put("RESPONSE", karalisteMap.getString("RESPONSE"));
						oMap.put("RESPONSE_DATA", karalisteMap.getString("RESPONSE_DATA"));
						return oMap;

					}
				}

			}
			else if (StringUtils.isNotBlank(iMap.getString("WEB_DOGUM_TARIHI")) && iMap.getDate("WEB_DOGUM_TARIHI") == null && "H".equals(iMap.getString("LOGIN_MI"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GECERSIZ_TARIH);
				return oMap;
			}

			iMap.put("DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
			iMap.put("AD", iMap.getString("WEB_ADI"));
			iMap.put("SOYAD", iMap.getString("WEB_SOYADI"));
			boolean qrMi = false;
			qrMi = "E".equals(iMap.getString("IS_QR")) ? true : false;
			boolean yeniGiris = "E".equals(iMap.getString("QR_CREATE")) ? true : false;
			if (!qrMi) {
				oMap = GMServiceExecuter.call("BNSPR_TFF_KARALISTE_KONTROL", iMap);
				if (!"2".equals(oMap.getString("RESPONSE"))) {
					return oMap;
				}
			}

			String pasaportNo = iMap.getString("PASAPORT", "");
			if (!StringUtils.isEmpty(pasaportNo)) {
				pasaportNo = iMap.getString("PASAPORT").toUpperCase(Locale.ENGLISH);
			}
			BigDecimal customerNo = searchCustomer(iMap.getString("UYRUK"), iMap.getString("TCKN"), pasaportNo);

			if (customerNo != null) {

				GMMap gm = new GMMap();
				gm.put("MUSTERI_NO", customerNo);
				gm.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_MUSTERIMI_KONTAKMI", gm));
				String res = gm.getString("KONTAK_MUSTERI");
				if (!qrMi) {
					if ("M".equals(res)) {
						GMMap uMap = findUye(iMap);
						String phone=getOtpCepTelNo(customerNo);
						// gercek musteri uye ise otp telefonu zorunlu
						if (uMap.getBigDecimal("UYE_NO") != null && !"BITIST".equals(iMap.getString("SOURCE"))) { // bitmatrix kanal�ndan geliyorsa otp kontrol� yap�lmas�n
						
							if (!StringUtils.isBlank(phone) && !phone.equals(iMap.getString("CEP_TEL_NO"))) {
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.OTP_DOGRULAMA_OTP_CEPTEL_UYUMSUZ_HATASI);
								return oMap;

							}
						}
						else {
							logger.info("--------- otpGonderKontrol MUSTERI_NO:" + customerNo + " gercek musteri uye degil");
							
							Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
							Criteria criteria = session.createCriteria(GnlParamText.class)
									.add(Restrictions.eq("kod", "SOURCE_CODES_FOR_PASSOLIG_APPLICATION"))
									.add(Restrictions.eq("key1", iMap.getString("SOURCE")));

							GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
							if(gnlParamText!=null){
								  if(!StringUtils.isBlank(phone) && !phone.equals(iMap.getString("CEP_TEL_NO"))){
									  oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
										oMap.put("RESPONSE_DATA", TffServicesMessages.OTP_DOGRULAMA_OTP_CEPTEL_UYUMSUZ_HATASI);
										return oMap;
								  }
							
							}
							  
							
								
							

							
						}
					}

					String procStr = "{call BNSPR.PKG_TRN3801.TFF_BASVURU_OTP_GONDER_KONTROL (?,?,?,?,?,?,?,?,?)}";
					int i = 0;
					Object[] inputValues = new Object[14];
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("TCKN");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = pasaportNo; // iMap.getString("PASAPORT");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("CEP_TEL_NO");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("LOGIN_MI");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("UYRUK");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("SOURCE");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("CLIENT_IP");

					i = 0;
					Object[] outputValues = new Object[4];
					outputValues[i++] = BnsprType.NUMBER;
					outputValues[i++] = "RESPONSE";
					outputValues[i++] = BnsprType.STRING;
					outputValues[i++] = "RESPONSE_DATA";

					oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

				}
				else {
					String procStr = "{call BNSPR.PKG_TRN3801.QR_BASVURU_OTP_GONDER_KONTROL (?,?,?,?,?)}";
					int i = 0;
					Object[] inputValues = new Object[6];
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("TCKN");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("CEP_TEL_NO");
					inputValues[i++] = BnsprType.STRING;
					inputValues[i++] = iMap.getString("CLIENT_IP");

					i = 0;
					Object[] outputValues = new Object[4];
					outputValues[i++] = BnsprType.NUMBER;
					outputValues[i++] = "RESPONSE";
					outputValues[i++] = BnsprType.STRING;
					outputValues[i++] = "RESPONSE_DATA";
					oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
					if (oMap.getString("RESPONSE").equals("1") && oMap.getString("RESPONSE_DATA").equals("0047") && yeniGiris) {
						
						Date date = new Date();
						GMMap telMap = new GMMap();
						telMap.put("MUSTERI_NO", customerNo);
						telMap = GMServiceExecuter.call("BNSPR_TRN1048_CREATE_TRX_NO", telMap);
						
						telMap.putAll(GMServiceExecuter.call("BNSPR_TRN1048_GET_INFO", telMap));
						int a = telMap.getSize("TELEFON_LIST");
						telMap.put("TELEFON_LIST", a, "TEL_TIP", "6");
						telMap.put("TELEFON_LIST", a, "ALAN_KOD", iMap.getString("CEP_TEL_NO").substring(2, 5));
						telMap.put("TELEFON_LIST", a, "TEL_NO", iMap.getString("CEP_TEL_NO").substring(5, 12));
						telMap.put("TELEFON_LIST", a, "ULKE_KODU", iMap.getString("CEP_TEL_NO").substring(0, 2));
						telMap.put("TELEFON_LIST", a, "TEL_UPD_DATE", date);
						telMap.put("TELEFON_LIST", a, "OTPMI", "H");
						telMap.put("MUSTERI_NO", customerNo);
						telMap.put("TRX_ONAYSIZ_ISLEM", "E");
						try {
							GMServiceExecuter.execute("BNSPR_TRN1048_SAVE", telMap);
							oMap.put("RESPONSE", "2");
						}
						catch (Exception e) {
							e.printStackTrace();
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", "QR Tel Ekleme hatas�");
						}

					}
				}
			}
		}
		catch (ParseException e1) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GECERSIZ_TARIH);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.OTP_GONDER_KONTROL_GENEL_HATA);
		}
		return oMap;
	}

	/**
	 * TFF basvurusunda teslimat adresi olarak kullanilabilecek PTT Subeleri/Stad Giselerini listeler<br>
	 * 
	 * @author murat.el
	 * @since 12.03.2014
	 * @param iMap
	 *            - Input yok<br>
	 * @return Teslimat noktasi tipine gore listeler<br>
	 *         <li>PTT_TESLIMAT_NOKTASI - PTT Subeleri <li>STAD_TESLIMAT_NOKTASI - Stad Giseleri <li>TESLIMAT_NOKTASI - Hem PTT Subeleri hem Stad Giseleri
	 */
	@GraymoundService("BNSPR_TFF_COMMON_GET_PTT_STADIUM_LIST")
	public static GMMap getPTTAndStadiumList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		String pttListName = "PTT_TESLIMAT_NOKTASI";
		String stadListName = "STAD_TESLIMAT_NOKTASI";
		String hepsiListName = "TESLIMAT_NOKTASI";
		String mapName = "PTT_STDM_LIST";

		try {
			// Intra sisteminde ptt ve stad gise bilgilerini al
			sorguMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_PTT_AND_STADIUM_LIST", sorguMap);
			if (sorguMap == null || sorguMap.isEmpty() || sorguMap.getSize(mapName) < 1) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "Teslimat Noktas� Olarak Se�ilebilecek Stad ya da PTT Gi�esi Yoktur");
				return oMap;
			}

			// Il kodundan adini bulmak icin session ac
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			GnlilKodPr city = null;

			for (int i = 0, j = 0, k = 0, l = 0; j < sorguMap.getSize(mapName); j++) {
				// Il adi bilgisini al
				city = (GnlilKodPr) session.createCriteria(GnlilKodPr.class).add(Restrictions.eq("kod", sorguMap.getString(mapName, j, "CITY_CODE"))).uniqueResult();
				String ilAd = StringUtils.EMPTY;
				if (city != null) {
					ilAd = city.getIlAdi();
				}

				// eger basvuru girilen dis kanallar icin liste verilecekse valid olmayanlari gonderme
				if (iMap.containsKey("SOURCE") && ("MTT01".equals(iMap.getString("SOURCE")) || "TABLET".equals(iMap.getString("SOURCE")) || "NTS01".equals(iMap.getString("SOURCE")) || "NTS02".equals(iMap.getString("SOURCE")) || "MBL01".equals(iMap.getString("SOURCE")) || "CC001".equals(iMap.getString("SOURCE")) || "EPOS".equals(iMap.getString("SOURCE"))) && !"Y".equals(sorguMap.getString(mapName, j, "IS_VALID"))) {
					continue;	
				}

				// Teslimat noktasi tipine gore listele
				if ("T".equals(sorguMap.getString(mapName, j, "CARD_DELIVERY_TYPE"))) {
					oMap.put(hepsiListName, l, "TYPE", "TN");
					oMap.put(pttListName, i, "TYPE", "TN");
					oMap.put(pttListName, i, "VALUE", sorguMap.getString(mapName, j, "BRANCH_ID"));
					oMap.put(pttListName, i, "CITY_ID", sorguMap.getString(mapName, j, "CITY_CODE"));
					oMap.put(pttListName, i, "TOWN_ID", sorguMap.getString(mapName, j, "TOWN"));
					oMap.put(pttListName, i, "NAME", sorguMap.getString(mapName, j, "NAME"));
					oMap.put(pttListName, i, "IS_VALID", sorguMap.getString(mapName, j, "IS_VALID"));
					oMap.put(pttListName, i, "ADDRESS", sorguMap.getString(mapName, j, "NAME") + " / " + sorguMap.getString(mapName, j, "ADRS1") + " " + sorguMap.getString(mapName, j, "ADRS2") + " " + sorguMap.getString(mapName, j, "TOWN") + " " + ilAd);
					i++;
				}
				else if ("A".equals(sorguMap.getString(mapName, j, "CARD_DELIVERY_TYPE"))) {
					oMap.put(hepsiListName, l, "TYPE", "GN");
					oMap.put(stadListName, k, "TYPE", "GN");
					oMap.put(stadListName, k, "VALUE", sorguMap.getString(mapName, j, "BRANCH_ID"));
					oMap.put(stadListName, k, "CITY_ID", sorguMap.getString(mapName, j, "CITY_CODE"));
					oMap.put(stadListName, k, "TOWN_ID", sorguMap.getString(mapName, j, "TOWN"));
					oMap.put(stadListName, k, "NAME", sorguMap.getString(mapName, j, "NAME"));
					oMap.put(stadListName, k, "IS_VALID", sorguMap.getString(mapName, j, "IS_VALID"));
					oMap.put(stadListName, k, "ADDRESS", sorguMap.getString(mapName, j, "NAME") + " / " + sorguMap.getString(mapName, j, "ADRS1") + " " + sorguMap.getString(mapName, j, "ADRS2") + " " + sorguMap.getString(mapName, j, "TOWN") + " " + ilAd);
					k++;
				}
				// Teslimat noktasi tipten bagimsiz listele
				oMap.put(hepsiListName, l, "VALUE", sorguMap.getString(mapName, j, "BRANCH_ID"));
				oMap.put(hepsiListName, l, "ID", sorguMap.getString(mapName, j, "BRANCH_ID"));
				oMap.put(hepsiListName, l, "CITY_ID", sorguMap.getString(mapName, j, "CITY_CODE"));
				oMap.put(hepsiListName, l, "TOWN_ID", sorguMap.getString(mapName, j, "TOWN"));
				oMap.put(hepsiListName, l, "NAME", sorguMap.getString(mapName, j, "NAME"));
				oMap.put(hepsiListName, l, "IS_VALID", sorguMap.getString(mapName, j, "IS_VALID"));
				oMap.put(hepsiListName, l, "ADDRESS", sorguMap.getString(mapName, j, "NAME") + " / " + sorguMap.getString(mapName, j, "ADRS1") + " " + sorguMap.getString(mapName, j, "ADRS2") + " " + sorguMap.getString(mapName, j, "TOWN") + " " + ilAd);
				l++;
			}

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			// throw ExceptionHandler.convertException(e);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_TCKN_KONTROL")
	public static GMMap tcknKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// TCKN Kontrolu
			String tcKimlikNo = iMap.getString("TCKN");
			if (StringUtils.isNotBlank(tcKimlikNo) && "9".equals(tcKimlikNo.substring(0, 1))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.TCKN_KONTROL_KARAKTER_SAYISI_HATASI);
				return oMap;
			}

			// Validasyon
			iMap.put("TC_KIMLIK_NO", tcKimlikNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", iMap));
			if ("0".equals(oMap.getString("SONUC"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.TCKN_KONTROL_CHECK_DIGIT_HATASI);
				return oMap;
			}

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.TCKN_KONTROL_CHECK_DIGIT_HATASI);
			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KPS_BILGISI_SORGULA")
	public static GMMap kpsBilgisiSorgulama(GMMap iMap) throws IOException {
		GMMap kpsMap = new GMMap();
		GMMap oMap = new GMMap();
		// TCKN Kontrolu
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_TCKN_KONTROL", iMap));
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}

		if (isLocal) {
			kpsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_KPS_GET_KISI_BILGILERI", iMap));
		}
		else {
			try {
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_KPS_GET_KISI_BILGILERI", iMap));
			}
			catch (Exception e) {
				e.printStackTrace();
				oMap.put("RESPONSE_DATA", TffServicesMessages.KPS_KISI_BILGISI_EKSIK);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				return oMap;
			}

		}

		BilesikKutukModel kisiBilgisi = (BilesikKutukModel) kpsMap.get("KISI_BILGISI");

		if (kisiBilgisi == null || (kpsMap.containsKey("HATA") && kpsMap.getString("HATA").matches("exhausted"))) {
			oMap.put("RESPONSE_DATA", TffServicesMessages.KPS_KISI_BILGISI_EKSIK);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}

		TCKisiBilgisiModel tcKisiBilgisiModel = kisiBilgisi.getTcKisiBilgisiModel();

		if (tcKisiBilgisiModel.getDurum().getKod() == 5) {// VATANDASLIKTAN CIKMA
			oMap.put("RESPONSE_DATA", TffServicesMessages.KPS_VATANDASLIKTAN_CIKMA);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}

		if (!StringUtil.isEmpty(tcKisiBilgisiModel.getDogumTarih().toString())) {
			Calendar dogumTarihi = Calendar.getInstance();
			dogumTarihi.set(tcKisiBilgisiModel.getDogumTarih().getYil(), tcKisiBilgisiModel.getDogumTarih().getAy() - 1, tcKisiBilgisiModel.getDogumTarih().getGun());
			oMap.put("DOGUM_TARIHI", dogumTarihi.getTime());
		}

		oMap.put("TCKNO_OUT", tcKisiBilgisiModel.getTcKimlikNo());
		oMap.put("AD", tcKisiBilgisiModel.getAd());
		oMap.put("SOYAD", tcKisiBilgisiModel.getSoyad());
		oMap.put("CINSIYET", KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getCinsiyet()));
		oMap.put("CINSIYET_KOD", KPSUtil.getParametreKod(tcKisiBilgisiModel.getCinsiyet()));
		oMap.put("BABA_AD", tcKisiBilgisiModel.getBabaAd());
		oMap.put("ANNE_AD", tcKisiBilgisiModel.getAnneAd());
		oMap.put("KIZLIK_SOYAD", "");
		oMap.put("DOGUM_YERI", tcKisiBilgisiModel.getDogumYer());
		oMap.put("DURUMU", KPSUtil.getParametreKod(tcKisiBilgisiModel.getDurum())); // DURUMU_KOD
		oMap.put("DURUMU_ACIKLAMA", KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getDurum()));
		oMap.put("MEDENI_HALI", KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getMedeniHal()));
		oMap.put("MEDENI_HALI_KOD", KPSUtil.getParametreKod(tcKisiBilgisiModel.getMedeniHal()));
		oMap.put("ES_TCKN", tcKisiBilgisiModel.getEsTCKimlikNo());
		oMap.put("DIN", tcKisiBilgisiModel.getDin());

		String ad = tcKisiBilgisiModel.getAd();
		String ad1;
		String ad2;
		if (ad.indexOf(" ") >= 0) {
			ad1 = ad.substring(0, ad.indexOf(" "));
			ad2 = ad.substring(ad.indexOf(" ")).trim();
		}
		else {
			ad1 = ad;
			ad2 = null;
		}
		oMap.put("AD1", ad1);
		oMap.put("AD2", ad2);

		String ilKodu = String.valueOf(tcKisiBilgisiModel.getIl().getKod());
		if (ilKodu.length() == 2)
			ilKodu = "0" + ilKodu;
		if (ilKodu.length() == 1)
			ilKodu = "00" + ilKodu;
		oMap.put("IL_KODU", ilKodu);
		oMap.put("IL", String.valueOf(tcKisiBilgisiModel.getIl().getAciklama()));

		oMap.put("ILCE_KODU", String.valueOf(tcKisiBilgisiModel.getIlce().getKod()));
		oMap.put("ILCE", String.valueOf(tcKisiBilgisiModel.getIlce().getAciklama()));

		// oMap.put("DOGUM_ILCE_KODU", kisiBilgisi.getDogumYerKod());

		oMap.put("MAHALLE_KOY", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getAciklama() : "");
		oMap.put("CILT_KODU", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getKod() : "");
		oMap.put("CILT", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getAciklama() : "");
		oMap.put("AILE_SIRA_NO", tcKisiBilgisiModel.getAileSiraNo());
		oMap.put("BIREY_SIRA_NO", tcKisiBilgisiModel.getBireySiraNo());

		if (!StringUtil.isEmpty(tcKisiBilgisiModel.getOlumTarih().toString())) {
			Calendar olumTarihi = Calendar.getInstance();
			olumTarihi.set(tcKisiBilgisiModel.getOlumTarih().getYil(), tcKisiBilgisiModel.getOlumTarih().getAy() - 1, tcKisiBilgisiModel.getOlumTarih().getGun());

			oMap.put("OLUM_TARIHI", convertTarihModel(tcKisiBilgisiModel.getOlumTarih()));
		}
		else {
			TCCuzdanBilgisiModel cuzdan = kisiBilgisi.getTcCuzdanBilgisiModel();
			TCKKModel tckk = kisiBilgisi.getTckkModel();
			if (cuzdan != null && cuzdan.getSeri() != null && !cuzdan.getSeri().isEmpty()) {
				String seriNo = cuzdan.getSeriNo();
				oMap.put("TCKK", false);
				oMap.put("TC_KIMLIK_NO", cuzdan.getTcKimlikNo());
				if (seriNo != null) {
					oMap.put("NUFUS_CUZDANI_SERI_NO", seriNo);
					oMap.put("KIMLIK_SERI_NO", seriNo.substring(0, 3));
					oMap.put("KIMLIK_SIRA_NO", seriNo.substring(3, seriNo.length()));

				}

				oMap.put("VERILIS_TARIHI", convertTarihModel(cuzdan.getVerilmeTarih()));
				oMap.put("OLUM_TARIHI", convertTarihModel(null));
				oMap.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(cuzdan.getCuzdanVerilmeNeden()));
				oMap.put("VERILIS_NEDENI", KPSUtil.getParametreAciklama(cuzdan.getCuzdanVerilmeNeden()));
				oMap.put("VERILIS_NEDENI_KOD", KPSUtil.getParametreKod(cuzdan.getCuzdanVerilmeNeden()));
				oMap.put("KIMLIK_KAYIT_NO", cuzdan.getCuzdanKayitNo());
				oMap.put("VERILDIGI_ILCE_KODU", KPSUtil.getParametreKod(cuzdan.getVerildigiIlce()));
				oMap.put("VERILDIGI_YER", KPSUtil.getParametreAciklama(cuzdan.getVerildigiIlce()));
				oMap.put("VERILDIGI_ILCE_ADI", KPSUtil.getParametreAciklama(cuzdan.getVerildigiIlce()));

			}
			else if (tckk != null && tckk.getSeriNo() != null && !tckk.getSeriNo().isEmpty()) {

				String seriNo = tckk.getSeriNo();
				oMap.put("TCKK", true);
				oMap.put("TC_KIMLIK_NO", tckk.getTcKimlikNo());
				if (seriNo != null) {
					oMap.put("NUFUS_CUZDANI_SERI_NO", seriNo);
					oMap.put("KIMLIK_SERI_NO", seriNo.substring(0, 3));
					oMap.put("KIMLIK_SIRA_NO", seriNo.substring(3, seriNo.length()));

				}
				oMap.put("VERILIS_TARIHI", convertTarihModel(tckk.getTeslimTarih()));
				oMap.put("OLUM_TARIHI", convertTarihModel(null));
				oMap.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(tckk.getBasvuruNeden()));
				oMap.put("KIMLIK_KAYIT_NO", tckk.getKayitNo());
				oMap.put("TCKK_TESLIM_EDEN_BIRIM", KPSUtil.getParametreAciklama(tckk.getTeslimEdenBirim()));
				oMap.put("TCKK_VEREN_MAKAM", tckk.getVerenMakam());
			}
		}

		// Cinsiyet Donusumu
		String cinsiyet = tcKisiBilgisiModel.getCinsiyet().getAciklama();
		if (StringUtils.isNotBlank(cinsiyet)) {
			oMap.remove("CINSIYET");
			if ("Erkek".equals(cinsiyet)) {
				oMap.put("CINSIYET", "E");
			}

			else if ("Kad�n".equals(cinsiyet)) {
				oMap.put("CINSIYET", "K");
			}
			else {
				oMap.put("CINSIYET", "K");
			}
		}

		// Medeni Hal
		String medeniHal = tcKisiBilgisiModel.getMedeniHal().getAciklama();
		if (StringUtils.isNotBlank(medeniHal)) {
			oMap.remove("MEDENI_HALI");
			if ("E".equals(medeniHal.substring(0, 1))) {
				oMap.put("MEDENI_HALI", "1");
			}
			else

				oMap.put("MEDENI_HALI", "2");
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		DateTime dt;
		try {
			dt = new DateTime(sdf.parse(convertTarihModel(tcKisiBilgisiModel.getDogumTarih())).getTime());
			if (dt != null) {
				DateTime simdi = new DateTime(Calendar.getInstance().getTime());

				if (Years.yearsBetween(dt, simdi).getYears() >= 18) {
					oMap.put("18_YASINDA_MI", TffServicesMessages.EVET);
				}
				else {
					oMap.put("18_YASINDA_MI", TffServicesMessages.HAYIR);
				}
				oMap.put("KPS_YASI", Years.yearsBetween(dt, simdi).getYears());
			}
		}
		catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			oMap.put("RESPONSE_DATA", TffServicesMessages.KPS_TARIH_HESAPLANAMADI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}

		String olumTarihi = oMap.getString("OLUM_TARIHI");
		if (StringUtils.isNotBlank(olumTarihi)) {
			String errorMessage = null;
			if (olumTarihi.length() >= 8) {
				errorMessage = olumTarihi.substring(6, 8) + "/" + olumTarihi.substring(4, 6) + "/" + olumTarihi.substring(0, 4);
			}
			oMap.put("RESPONSE_DATA", TffServicesMessages.TCKN_KPS_OLUM_HATASI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}

		// TCKN Durumunu Kontrol Et - Uygun Degilse Hata Ver
		else if (!"1".equals(oMap.getString("DURUMU"))) {
			iMap.put("MESSAGE_NO", new BigDecimal(2087));

			oMap.put("RESPONSE_DATA", TffServicesMessages.TCKN_KPS_DURUM_UYGUN_DEGIL_HATASI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * 
	 * Uye ekeleme ile ayni parametreler alinir, <li>Input kontrolleri yapilir <li>Kara liste kontrolu <li>7 yas kontrolu <li>Kimlik verilis tarihi kontrolu <li>Dogum tarihi kontrolu yapilir
	 * 
	 * <br>
	 * KPS ile tutarsiz veri var ise kara listeye eklenir
	 * 
	 * @param iMap
	 * @return
	 *         <li>FRAUD_MU</li> <li>RESPONSE</li> <li>RESPONSE_DATA</li>
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_COMMON_CREATE_MEMBER_VALIDATION")
	public static GMMap createMemberValidation(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kpsMap = new GMMap();
		try {

			/*
			 * input kontrolleri
			 * 
			 * */
			if (StringUtils.isEmpty(iMap.getString("UYE_NO"))) {
				if (!isUyrukValid(iMap)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYRUK_KOD_HATASI);
					return oMap;
				}
			}
			if ((StringUtils.isBlank(iMap.getString("EMAIL")) || !isEmailValid(iMap.getString("EMAIL"))) && ("SMS".equals(iMap.getString("SOURCE")) || "MTT01".equals(iMap.getString("SOURCE")) || "TABLET".equals(iMap.getString("SOURCE")) || "MBL01".equals(iMap.getString("SOURCE")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.EMAIL_HATALI_HATASI);
				return oMap;

			}
			if ("BATCH".equals(iMap.getString("SOURCE")) && StringUtils.isNotBlank(iMap.getString("EMAIL")) && !isEmailValid(iMap.getString("EMAIL"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.EMAIL_HATALI_HATASI);
				return oMap;
			}
			if ((StringUtils.isBlank(iMap.getString("CEP_ULKE_KOD")) || !StringUtils.isNumeric(iMap.getString("CEP_ULKE_KOD"))) && ("SMS".equals(iMap.getString("SOURCE")) || "MTT01".equals(iMap.getString("SOURCE")) || "TABLET".equals(iMap.getString("SOURCE")) || "MBL01".equals(iMap.getString("SOURCE")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_ULKE_KOD_HATALI);
				return oMap;

			}
			if ((StringUtils.isBlank(iMap.getString("CEP_ALAN_KOD")) || !StringUtils.isNumeric(iMap.getString("CEP_ALAN_KOD"))) && ("SMS".equals(iMap.getString("SOURCE")) || "MTT01".equals(iMap.getString("SOURCE")) || "TABLET".equals(iMap.getString("SOURCE")) || "MBL01".equals(iMap.getString("SOURCE")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_ALAN_KOD_HATALI);
				return oMap;

			}

			if ((StringUtils.isBlank(iMap.getString("CEP_NUMARA")) || !StringUtils.isNumeric(iMap.getString("CEP_NUMARA"))) && ("SMS".equals(iMap.getString("SOURCE")) || "MTT01".equals(iMap.getString("SOURCE")) || "TABLET".equals(iMap.getString("SOURCE")) || "MBL01".equals(iMap.getString("SOURCE")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_TEL_NO_HATALI);
				return oMap;

			}

			String validPhone = validatePhoneNumber("C", iMap.getString("CEP_ULKE_KOD"), iMap.getString("CEP_ALAN_KOD"), iMap.getString("CEP_NUMARA"));
			if (!"2".equals(validPhone)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", validPhone);
				return oMap;
			}
			int minBasvuruYasi = 7;
			try {
				String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
				minBasvuruYasi = Integer.parseInt(String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "MIN_YAS", BnsprType.STRING, "BASVURU_KRITER")));
			}
			catch (Exception e) {
				minBasvuruYasi = 7;
			}

			int maxBasvuruYasi = 99;
			try {
				String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
				maxBasvuruYasi = Integer.parseInt(String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "MAX_YAS", BnsprType.STRING, "BASVURU_KRITER")));
			}
			catch (Exception e) {
				maxBasvuruYasi = 99;
			}

			iMap.put("DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
			iMap.put("AD", iMap.getString("WEB_ADI"));
			iMap.put("SOYAD", iMap.getString("WEB_SOYADI"));
			oMap = GMServiceExecuter.call("BNSPR_TFF_KARALISTE_KONTROL", iMap);
			if (!"2".equals(oMap.getString("RESPONSE"))) {
				return oMap;
			}
			try {

				String dt = iMap.getString("WEB_DOGUM_TARIHI");
				logger.info("------------------ createMemberValidation WEB_DOGUM_TARIHI" + dt);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				sdf.setLenient(false);
				Date wdt = sdf.parse(dt);
				Calendar dob = Calendar.getInstance();
				dob.setTime(wdt);
				Calendar today = Calendar.getInstance();
				int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
				if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
					age--;
				}
				else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
					age--;
				}

				oMap.put("YASI", age);
			}
			catch (Exception e) {
				e.printStackTrace();
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.GECERSIZ_TARIH);
				return oMap;
			}

			/**
			 * yabancilar icin 7 yas kontrolu
			 * 
			 */
			if (StringUtils.isNotEmpty(oMap.getString("YASI")) && !"TR".equals(iMap.getString("UYRUK"))) {
				if (oMap.getInt("YASI") < minBasvuruYasi) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
					return oMap;
				}

				if (oMap.getInt("YASI") > maxBasvuruYasi) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_100_KONTROLU_HATASI);
					return oMap;
				}

			}
			if (StringUtils.isNotEmpty(iMap.getString("WEB_DOGUM_TARIHI"))) {
				iMap.put("WEB_DOGUM_TARIHI2", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("WEB_DOGUM_TARIHI")));
			}

			if (iMap.getString("UYRUK").equals("TR")) {

				/**
				 * Dogrulamalari yapabilmek icin kps yap
				 * 
				 * */
				kpsMap.put("TCKN", iMap.getString("TCKN"));
				kpsMap.put("TCK_NO", iMap.getString("TCKN"));
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
					return kpsMap;
				}

				/**
				 * Turkler icin kpsden 7 yas kontrolu
				 * 
				 */
				if (StringUtils.isNotEmpty(kpsMap.getString("KPS_YASI")) && kpsMap.getInt("KPS_YASI") < minBasvuruYasi) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
					return oMap;

				}

				/**
				 * Kimlik verilis tarihi kontorl edilecek mi
				 * */
				String verTarihCheck = "H";
				try {
					String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
					verTarihCheck = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, iMap.getString("SOURCE"), BnsprType.STRING, "VER_TAR_CHECK"));
				}
				catch (Exception e) {
					verTarihCheck = "H";
				}

				if ("E".equals(verTarihCheck)) {

					/**
					 * Kimlik verilis tarihi kontrollerini yap
					 * */
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KARA_LISTE_KONTROL", iMap));
					if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
						return oMap;
					}

				}

				if ("E".equals(verTarihCheck) && iMap.getString("WEB_DOGUM_TARIHI2") != null && kpsMap.getString("DOGUM_TARIHI") != null && !(iMap.getDate("WEB_DOGUM_TARIHI2").equals(kpsMap.getDate("DOGUM_TARIHI")))) {
					/**
					 * Tutarsiz bilgi varsa kara listeye ekle
					 */

					GMMap karaListeMap = new GMMap();
					karaListeMap.put("TCKN", iMap.getString("TCKN"));
					karaListeMap.put("CEP_TEL", iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
					karaListeMap.put("ISLEM_ID", iMap.getString("ISLEM_ID"));
					karaListeMap.put("KILIT_SEBEP", TffServicesMessages.TFF_KARA_LISTE_TCKN_VER_TARIH_HATASI);
					karaListeMap.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
					karaListeMap = GMServiceExecuter.call("WEBEXT_TFF_KARA_LISTEYE_EKLE", karaListeMap);
					if (TffServicesMessages.RESPONSE_BASARISIZ.equals(karaListeMap.getString("RESPONSE"))) {
						karaListeMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						karaListeMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_VERILIS_TARIHI_KARA_LISTE_UYARI);
						return karaListeMap;
					}
					oMap.put("FRAUD_MU", true);
				}

			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			return oMap;
		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * <li>UYRUK <li>TCKN <li>PASAPORT_NO <li>UYE_NO <li>EPOSTA <li>TAKIM <li>ANNE_KIZLIK_SOYADI <li>OGRENIM_DURUMU
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_COMMON_CREATE_MEMBER")
	public static GMMap createMember(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		GMMap kpsMap = new GMMap();
		GMMap customerContactMap = new GMMap();
		boolean goldenGate = false;
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		String kanalkod = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", iMap).getString("KANAL_KOD");
		if (!"12".equals(kanalkod)) {// SMS
			tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_MEMBER_VALIDATION", iMap);
		}
		else {

			tmpMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		String pasaportNo = iMap.getString("PASAPORT_NO", "");
		if (!StringUtils.isEmpty(pasaportNo)) {
			pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
		}

		TffUyeler tffUyeler = findUye(iMap.getString("UYRUK"), iMap.getBigDecimal("TCKN"), pasaportNo);

		if (TffServicesMessages.RESPONSE_BASARILI.equals(tmpMap.getString("RESPONSE"))) {
			try {

				if (tffUyeler == null) {
					tffUyeler = new TffUyeler();
				}
				else {
					if (getYas(tffUyeler.getDogumTarihi()) < 7) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
						return oMap;
					}
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
					oMap.put("UYE_NO", tffUyeler.getUyeNo());
					oMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
					oMap.put("YAS", getYas(tffUyeler.getDogumTarihi()));
					return oMap;
				}
				GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYELER);
				BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
				tffUyeler.setUyeNo(id);
				oMap.put("UYE_NO", id);
				if (iMap.getString("UYRUK").equals("TR")) {

					kpsMap.put("TCKN", iMap.getString("TCKN"));
					kpsMap.put("TCK_NO", iMap.getString("TCKN"));
					kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
					if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
						return kpsMap;
					}
					oMap.put("YAS", kpsMap.getString("KPS_YASI"));
					tffUyeler.setAdi(kpsMap.getString("AD1"));
					tffUyeler.setIkinciAdi(kpsMap.getString("AD2"));
					tffUyeler.setSoyadi(kpsMap.getString("SOYAD"));
					tffUyeler.setTckn(iMap.getBigDecimal("TCKN"));
					tffUyeler.setCinsiyet(kpsMap.getString("CINSIYET"));
					// tffUyeler.setNufusVerilisTarihi(new SimpleDateFormat("yyyyMMdd").parse(StringUtils.isEmpty(iMap.getString("NUFUS_VER_TAR"))?kpsMap.getString("VERILIS_TARIHI"):iMap.getString("NUFUS_VER_TAR")));
					if (StringUtils.isNotEmpty(iMap.getString("NUFUS_VER_TAR")))
						tffUyeler.setNufusVerilisTarihi(new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("NUFUS_VER_TAR")));
					else if (StringUtils.isNotEmpty(kpsMap.getString("VERILIS_TARIHI")))
						tffUyeler.setNufusVerilisTarihi(new SimpleDateFormat("yyyyMMdd").parse(kpsMap.getString("VERILIS_TARIHI")));
					else
						tffUyeler.setNufusVerilisTarihi(null);

					tffUyeler.setAnneKizlikSoyadi(iMap.getString("ANNE_KIZLIK_SOYADI"));
					tffUyeler.setKimlikSeriNo(kpsMap.getString("KIMLIK_SERI_NO"));
					tffUyeler.setKimlikTipi(iMap.getString("KIMLIK_TIPI"));

					tffUyeler.setDogumTarihi(kpsMap.getDate("DOGUM_TARIHI"));
					tffUyeler.setSource(iMap.getString("SOURCE"));

				}
				else {
					tffUyeler.setAdi(iMap.getString("WEB_ADI"));
					tffUyeler.setIkinciAdi(iMap.getString("WEB_IKINCI_ADI"));
					tffUyeler.setSoyadi(iMap.getString("WEB_SOYADI"));
					tffUyeler.setDogumTarihi(iMap.getDate("WEB_DOGUM_TARIHI"));
					tffUyeler.setPasaportNo(StringUtils.deleteWhitespace(pasaportNo));
					tffUyeler.setAdi(iMap.getString("WEB_ADI"));
					tffUyeler.setKimlikSeriNo(kpsMap.getString("KIMLIK_SERI_NO") + kpsMap.getString("KIMLIK_SIRA_NO"));
					tffUyeler.setKimlikTipi(iMap.getString("KIMLIK_TIPI"));

				}
				if (!StringUtils.isBlank(iMap.getString("CEP_ULKE_KOD")) && !StringUtils.isBlank(iMap.getString("CEP_ALAN_KOD")) && !StringUtils.isBlank(iMap.getString("CEP_NUMARA"))) {
					tffUyeler.setCepTel(iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
					tffUyeler.setCepAlanKod(iMap.getString("CEP_ALAN_KOD"));
					tffUyeler.setCepNumara(iMap.getString("CEP_NUMARA"));
					tffUyeler.setCepUlkeKod(iMap.getString("CEP_ULKE_KOD"));

				}
				tffUyeler.setKampanyaKatilim(StringUtils.isBlank(iMap.getString("KAMPANYA_KATILIM")) ? BigDecimal.ONE : iMap.getBigDecimal("KAMPANYA_KATILIM"));
				tffUyeler.setSource(iMap.getString("SOURCE"));
				tffUyeler.setUyruk(iMap.getString("UYRUK"));
				tffUyeler.setEposta(iMap.getString("EMAIL"));
				tffUyeler.setTakim(iMap.getString("TAKIM"));
				if ("EPOS".equals(iMap.getString("SOURCE")) || "NTS02".equals(iMap.getString("SOURCE"))) {
					tffUyeler.setOnaylandiMi("H");
				}
				if (getYas(tffUyeler.getDogumTarihi()) < 7) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
					return oMap;
				}
				BigDecimal musteriNo = searchCustomer(tffUyeler.getUyruk(), String.valueOf(tffUyeler.getTckn()), tffUyeler.getPasaportNo());
				tffUyeler.setBankaMusteriNo(musteriNo);
				if (tffUyeler.getBankaMusteriNo() == null || tffUyeler.getBankaMusteriNo().compareTo(BigDecimal.ZERO) == 0) {
					try {
						session.saveOrUpdate(tffUyeler);

						customerContactMap.put("SOURCE", iMap.getString("SOURCE"));
						customerContactMap.put("TUR", "TFFKART");
						customerContactMap.put("KAYNAK", "TFF");
						customerContactMap.put("ADK_MUS  TERISIMI", "H");
						customerContactMap.put("UYRUK_KOD", tffUyeler.getUyruk());
						customerContactMap.put("UYRUK", iMap.getString("UYRUK"));
						customerContactMap.put("EMAIL_KISISEL", tffUyeler.getEposta());
						customerContactMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
						customerContactMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));

						if (iMap.getString("CEP_ULKE_KOD") != null && iMap.getString("CEP_ALAN_KOD") != null && iMap.getString("CEP_NUMARA") != null) {
							customerContactMap.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
							customerContactMap.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
							customerContactMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
						}
						if ("TR".equals(tffUyeler.getUyruk())) {
							customerContactMap.putAll(kpsMap);
							customerContactMap.put("F_KPS", "E");
							customerContactMap.put("KPS_TARIH", iMap.getDate("SORGU_TARIHI"));
						}
						else {
							customerContactMap.put("PASAPORT_NO", StringUtils.deleteWhitespace(pasaportNo));
							customerContactMap.put("AD1", iMap.getString("WEB_ADI"));
							customerContactMap.put("AD2", iMap.getString("WEB_IKINCI_ADI"));
							customerContactMap.put("SOYAD", iMap.getString("WEB_SOYADI"));
							customerContactMap.put("DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
						}

						GMMap tMap = GMServiceExecuter.call("BNSPR_TFF_CREATE_CUSTOMER", customerContactMap);
						if (tMap.getBigDecimal("MUSTERI_NO").compareTo(BigDecimal.ZERO) > 0) {
							tffUyeler.setBankaMusteriNo(tMap.getBigDecimal("MUSTERI_NO"));

						}
						else {
							String mailFrom = "system@aktifbank.com.tr";
							String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
							String mailSubject = "TFF MUSTERI YARATMA HATA";
							String mailBody = "hata alan kimlik bilgileri:";
							mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
							if ("TR".equals(tffUyeler.getUyruk())) {
								mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
							}
							else {
								mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
							}
							mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
							mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
							mailBody += "<br>" + "MAP:" + customerContactMap.toString();
							sendMail(mailFrom, mailToParametre, mailSubject, mailBody);

							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
							logger.error("---------- createMember : uye tablosuna yazarken hata olustu");
							return oMap;

						}
					}
					catch (Exception e) {
						String mailFrom = "system@aktifbank.com.tr";
						String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
						String mailSubject = "TFF MUSTERI YARATMA HATA";
						String mailBody = "hata alan kimlik bilgileri:";
						mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
						if ("TR".equals(tffUyeler.getUyruk())) {
							mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
						}
						else {
							mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
						}
						mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
						mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();

						sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
						e.printStackTrace();
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
						return oMap;
					}

				}

				else {
					GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", tffUyeler.getBankaMusteriNo())).uniqueResult();

					goldenGate = true;

					if ("K".equals(musteri.getMusteriKontakt()) && "TR".equals(tffUyeler.getUyruk())) {

						try {
							customerContactMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
							customerContactMap.put("SOURCE", iMap.getString("SOURCE"));
							customerContactMap.putAll(kpsMap);
							customerContactMap.put("F_KPS", "E");
							customerContactMap.put("KPS_TARIH", iMap.getDate("SORGU_TARIHI"));
							customerContactMap.put("UYRUK_KOD", tffUyeler.getUyruk());
							customerContactMap.put("UYRUK", iMap.getString("UYRUK"));
							String kisaAd = tffUyeler.getAdi();
							kisaAd = !StringUtils.isEmpty(tffUyeler.getIkinciAdi()) ? kisaAd + " " + tffUyeler.getIkinciAdi() : kisaAd;
							kisaAd = !StringUtils.isEmpty(tffUyeler.getSoyadi()) ? kisaAd + " " + tffUyeler.getSoyadi() : kisaAd;
							if (!StringUtils.isEmpty(kisaAd)) {
								if (kisaAd.length() > 50) {
									kisaAd = kisaAd.substring(0, 50);
								}

							}

							customerContactMap.put("KISA_AD", kisaAd);

							GMMap tMap = GMServiceExecuter.call("BNSPR_TFF_CREATE_CUSTOMER", customerContactMap);
							if (tMap.getBigDecimal("MUSTERI_NO").compareTo(BigDecimal.ZERO) > 0) {
								tffUyeler.setBankaMusteriNo(tMap.getBigDecimal("MUSTERI_NO"));

							}
							else {
								String mailFrom = "system@aktifbank.com.tr";
								String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
								String mailSubject = "TFF MUSTERI YARATMA HATA";
								String mailBody = "hata alan kimlik bilgileri:";
								mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
								if ("TR".equals(tffUyeler.getUyruk())) {
									mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
								}
								else {
									mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
								}
								mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
								mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
								mailBody += "<br>" + "MAP:" + customerContactMap.toString();
								sendMail(mailFrom, mailToParametre, mailSubject, mailBody);

								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
								logger.error("---------- createMember : uye tablosuna yazarken hata olustu");
								return oMap;

							}
						}
						catch (Exception e) {
							String mailFrom = "system@aktifbank.com.tr";
							String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
							String mailSubject = "TFF MUSTERI YARATMA HATA";
							String mailBody = "hata alan kimlik bilgileri:";
							mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
							if ("TR".equals(tffUyeler.getUyruk())) {
								mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
							}
							else {
								mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
							}
							mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
							mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();

							sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
							e.printStackTrace();
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
							return oMap;
						}

					}

				}

				if (StringUtils.isBlank(tffUyeler.getEuptNo()) && tffUyeler.getBankaMusteriNo() != null || tffUyeler.getBankaMusteriNo().compareTo(BigDecimal.ZERO) > 0) {
					kpsMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
					oMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
					kpsMap.put("UYRUK", iMap.getString("UYRUK"));
					kpsMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
					try {
						kpsMap.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
						kpsMap.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
						kpsMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
						customerContactMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
						GMMap euptRegInput = GMServiceExecuter.call("BNSPR_TFF_EUPT_HESABI_OLUSTUR", customerContactMap);
						tffUyeler.setEuptNo(euptRegInput.getString("USERID"));
						oMap.put("EUPT_REF_ID", euptRegInput.getString("USERID"));
					}
					catch (Exception e) {
						String mailFrom = "system@aktifbank.com.tr";
						String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
						String mailSubject = "TFF EUPT YARATMA HATA";
						String mailBody = "hata alan kimlik bilgileri:";
						mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
						if ("TR".equals(tffUyeler.getUyruk())) {
							mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
						}
						else {
							mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
						}
						mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
						mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();

						sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
						e.printStackTrace();
					}

				}
				session.saveOrUpdate(tffUyeler);
				session.flush();

				if (goldenGate) {
					// GoldenGate Crm Data Feed i�in m��teri tablolar�na sembolik g�ncelleme ge�iliyor (m��teri tablolar�na update ge�ilmezse GoldenGate e yans�m�yor)
					if (tffUyeler.getBankaMusteriNo() != null || tffUyeler.getBankaMusteriNo().compareTo(BigDecimal.ZERO) > 0) {
						GMMap crmMap = new GMMap();
						crmMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
						crmMap = GMServiceExecuter.call("BNSPR_TFF_UPDATE_CUSTOMER_RECORDS_FOR_CRM", crmMap);
					}

				}

			}
			catch (Exception e) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_OLUSTURMA_HATA);
				return oMap;
			}
		}
		else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", tmpMap.getString("RESPONSE_DATA"));
			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	/**
	 * Iz�n verilen uye bilgilerini gunceller
	 * 
	 * @param iMap
	 *            <li>UYRUK <li>TCKN <li>PASAPORT_NO <li>UYE_NO <li>EPOSTA <li>TAKIM <li>ANNE_KIZLIK_SOYADI <li>OGRENIM_DURUMU
	 * 
	 * @return oMap <li>UYE_NO <li>RESPONSE <li>RESPONSE_DATA
	 */
	@GraymoundService("BNSPR_TFF_COMMON_UPDATE_MEMBER")
	public static GMMap updateMember(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();

		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_MEMBER_VALIDATION", iMap);
		logger.info("---------- updateMember : UYE_NO " + iMap.getString("UYE_NO"));
		if (TffServicesMessages.RESPONSE_BASARILI.equals(tmpMap.getString("RESPONSE"))) {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			String pasaportNo = iMap.getString("PASAPORT_NO", "");
			if (!StringUtils.isEmpty(pasaportNo)) {
				pasaportNo = iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
			}

			TffUyeler tffUyeler = findUye(iMap.getString("UYRUK"), iMap.getBigDecimal("TCKN"), pasaportNo);
			logger.info("---------- updateMember : UYRUK " + iMap.getString("UYRUK"));
			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_UYE_KAYDI_YOK_HATASI);
				return oMap;
			}
			/**
			 * Uyenin alanlari guncellenir
			 * */

			if (iMap.containsKey("EMAIL") && !StringUtils.isBlank(iMap.getString("EMAIL"))) {
				tffUyeler.setEposta(iMap.getString("EMAIL"));
				logger.info("---------- updateMember : EMAIL " + iMap.getString("EMAIL"));
			}

			if (iMap.containsKey("TAKIM") && !StringUtils.isBlank(iMap.getString("TAKIM"))) {
				tffUyeler.setTakim(iMap.getString("TAKIM"));
				logger.info("---------- updateMember : TAKIM " + iMap.getString("TAKIM"));
			}

			if (iMap.containsKey("ONAYLANDI_MI") && !StringUtils.isBlank(iMap.getString("ONAYLANDI_MI"))) {
				tffUyeler.setOnaylandiMi(iMap.getString("ONAYLANDI_MI"));
				logger.info("---------- updateMember : ONAYLANDI_MI " + iMap.getString("ONAYLANDI_MI"));
			}

			if (iMap.containsKey("KAMPANYA_KATILIM") && !StringUtils.isBlank(iMap.getString("KAMPANYA_KATILIM"))) {
				tffUyeler.setKampanyaKatilim(iMap.getBigDecimal("KAMPANYA_KATILIM"));
				logger.info("---------- updateMember : KAMPANYA_KATILIM " + iMap.getString("KAMPANYA_KATILIM"));
			}
			if (!StringUtils.isBlank(iMap.getString("CEP_ULKE_KOD")) && !StringUtils.isBlank(iMap.getString("CEP_ALAN_KOD")) && !StringUtils.isBlank(iMap.getString("CEP_NUMARA"))) {
				tffUyeler.setCepTel(iMap.getString("CEP_ULKE_KOD") + iMap.getString("CEP_ALAN_KOD") + iMap.getString("CEP_NUMARA"));
				tffUyeler.setCepAlanKod(iMap.getString("CEP_ALAN_KOD"));
				tffUyeler.setCepNumara(iMap.getString("CEP_NUMARA"));
				tffUyeler.setCepUlkeKod(iMap.getString("CEP_ULKE_KOD"));

			}
			try {
				session.saveOrUpdate(tffUyeler);
				session.flush();
			}
			catch (Exception e) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_GENEL_HATA);
				logger.error("---------- updateMember : uye tablosuna yazarken hata olustu");
				return oMap;
			}
			oMap.put("UYE_NO", tffUyeler.getUyeNo());
			oMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());
			oMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			return oMap;

		}
		else {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", tmpMap.getString("RESPONSE_DATA"));
			return oMap;
		}

	}

	/**
	 * Uye ekle varsa guncelle
	 * 
	 * @param iMap
	 *            <li>UYE_NO <li>UYRUK <li>TCKN <li>KIMLIK_TIPI <li>KIMLIK_SERI_NO <li>PASAPORT_NO <li>DOGUM_TARIHI <li>KIMLIK_VERILIS_TARIHI <li>WEB_DOGUM_TARIHI <li>TAKIM <li>ANNE_KIZLIK_SOYADI <li>CALISMA_SEKLI <li>CEP_ULKE_KOD <li>CEP_ALAN_KOD <li>CEP_NUMARA <li>ADI <li>SOYADI <li>IKINCI_ADI <li>DOGUM_TARIHI <li>EPOSTA <li>CLIENT_IP
	 * @return oMap <li>UYE_NO <li>RESPONSE <li>RESPONSE_DATA
	 */
	@GraymoundService("BNSPR_TFF_COMMON_CREATE_OR_UPDATE_MEMBER")
	public static GMMap createOrUpdateMember(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_MEMBER_VALIDATION", iMap);
		logger.info("---------- createOrUpdateMember : UYRUK " + iMap.getString("UYRUK"));

		if (!TffServicesMessages.RESPONSE_BASARILI.equals(tmpMap.getString("RESPONSE"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", tmpMap.getString("RESPONSE_DATA"));
			return oMap;

		}
		else {

			if (iMap.getString("UYRUK").equals("TR")) {

				List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("tckn", iMap.getBigDecimal("TCKN"))).list();
				logger.info("---------- createOrUpdateMember : TCKN " + iMap.getString("TCKN"));
				if (list != null && list.size() > 0) {
					iMap.put("UYE_NO", list.get(0).getUyeNo());
					logger.info("---------- createOrUpdateMember : UYE_NO " + iMap.getString("UYE_NO"));
				}
			}
			else {
				List<TffUyeler> list = session.createCriteria(TffUyeler.class).add(Restrictions.eq("pasaportNo", StringUtils.isEmpty(iMap.getString("PASAPORT_NO")) ? iMap.getString("PASAPORT_NO") : iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH))).add(Restrictions.eq("uyruk", iMap.getString("UYRUK"))).list();
				logger.info("---------- createOrUpdateMember : PASAPORT_NO " + iMap.getString("PASAPORT_NO"));
				if (list != null && list.size() > 0) {
					iMap.put("UYE_NO", list.get(0).getUyeNo());

					logger.info("---------- createOrUpdateMember : UYE_NO " + iMap.getString("UYE_NO"));
				}
			}
			tmpMap.clear();
			if (iMap.containsKey("UYE_NO") && !StringUtils.isBlank(iMap.getString("UYE_NO"))) {

				tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_UPDATE_MEMBER", iMap);
			}
			else {
				tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_MEMBER", iMap);
			}
			oMap.putAll(tmpMap);
			if (TffServicesMessages.RESPONSE_BASARILI.equals(tmpMap.getString("RESPONSE"))) {
				oMap.put("UYE_NO", tmpMap.getString("UYE_NO"));
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				return oMap;
			}

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", tmpMap.getString("RESPONSE_DATA"));
			return oMap;
		}

	}

	/**
	 * DESC : DESCRIPTION
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            UYE_NO*
	 *            TFF_BASVURU_NO*
	 *            KART_TIPI*
	 *            URUN_KODU*
	 *            URUN_SAHIP_KODU*
	 *            KIMLIK_SERI_NO
	 *            KIMLIK_SIRA_NO
	 *            ANNE_KIZLIK_SOYADI
	 *            EMAIL
	 *            KREDI_KARTI_EKSTRE_SECIMI
	 *            KREDI_KARTI_EKSTRE_TIPI_EMAIL
	 *            KREDI_KARTI_EKSTRE_TIPI_POSTA
	 *            KREDI_KARTI_EKSTRE_TIPI_SMS
	 *            CALISMA_SEKLI
	 *            AYLIK_GELIR
	 *            ISYERI_ADI
	 *            HESAP_KESIM_TARIHI
	 *            KART_OTOMATIK_ODEME
	 *            YURT_DISI_EKSTRE_TIP
	 *            OGRENIM_DURUMU
	 *            MEVCUT_ADRESTE_OTURMA_SURESI_YIL
	 *            MEVCUT_ADRESTE_OTURMA_SURESI_AY
	 *            ISYERINDE_CALISMA_SURESI_YIL
	 *            ISYERINDE_CALISMA_SURESI_AY
	 *            ISYERI_FAALIYET_ALANI
	 *            UNVANI
	 *            MESLEK
	 *            ISYERI_VERGI_DAIRESI_ADI
	 *            ISYERI_VERGI_DAIRESI_IL
	 *            CEP_TEL_KOD
	 *            CEP_TEL_NO
	 *            IS_TEL_KOD
	 *            IS_TEL_NO
	 *            IS_TEL_DAHILI
	 *            EV_TEL_KOD
	 *            EV_TEL_NO
	 *            TESLIMAT_ADRES_NO
	 *            EUPT_YARAT
	 *            SOURCE
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         TFF_BASVURU_NO
	 *         EUPT_REF_ID
	 * 
	 *         Company : Aktifbank
	 * 
	 */

	@GraymoundService("BNSPR_TFF_COMMON_CREATE_APPLICATION_VALIDATION")
	public static GMMap createApplicationValidation(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (!isSourceValid(iMap)) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
			return oMap;
		}
		if (StringUtils.isEmpty(iMap.getString("URUN_KODU"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_URUN_TIPI_TANIMSIZ_HATASI);
			return oMap;
		}
		if (StringUtils.isEmpty(iMap.getString("KART_TIPI"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_URUN_TIPI_TANIMSIZ_HATASI);
			return oMap;
		}
		if (StringUtils.isEmpty(iMap.getString("URUN_SAHIP_KODU"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_URUN_SAHIP_KODU_TANIMSIZ_HATASI);
			return oMap;
		}
		if (("KK".equals(iMap.getString("KART_TIPI")) || "D".equals(iMap.getString("KART_TIPI"))) && StringUtils.isEmpty(iMap.getString("ANNE_KIZLIK_SOYADI")) && !"NTS02".equals(iMap.getString("SOURCE"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ANNEKIZLIK_SOYADI_BOS_OLAMAZ);
			return oMap;
		}
		if (StringUtils.isEmpty(iMap.getString("UYE_NO"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_UYE_NO_BOS_HATASI);
			return oMap;
		}

		if (!"P".equals(iMap.getString("KART_TIPI")) && ("MBL01".equals(iMap.getString("SOURCE")) || "TABLET".equals(iMap.getString("SOURCE")) || "MTT01".equals(iMap.getString("SOURCE")) || "SMS".equals(iMap.getString("SOURCE")) || "BATCH".equals(iMap.getString("SOURCE")))) {
			oMap = GMServiceExecuter.call("BNSPR_TFF_KK_D_INPUT_KONTROLLERI", iMap);
			if (!"2".equals(oMap.getString("RESPONSE"))) {
				return oMap;
			}
		}

		if ("NTS02".equals(iMap.getString("SOURCE"))) {
			String giseID = iMap.getString("GISE_ID");
			String giseUser = iMap.getString("GISE_USER");

			if (StringUtils.isBlank(giseID)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "0219");
				return oMap;
			}
			if (StringUtils.isBlank(giseUser)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", "0218");
				return oMap;
			}
		}
		// kanal urun kontrolu
		oMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", iMap);
		if (!"2".equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
		iMap.put("UYRUK", tffUyeler.getUyruk());
		iMap.put("TCKN", tffUyeler.getTckn());
		iMap.put("PASAPORT_NO", tffUyeler.getPasaportNo());
		iMap.put("DOGUM_TARIHI", tffUyeler.getDogumTarihi());
		iMap.put("AD", tffUyeler.getAdi());
		iMap.put("SOYAD", tffUyeler.getSoyadi());
		oMap = GMServiceExecuter.call("BNSPR_TFF_KARALISTE_KONTROL", iMap);
		if (!"2".equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		try {
			if (!"P".equals(iMap.getString("KART_TIPI")) && isUnder18(tffUyeler.getDogumTarihi())) {
				logger.error("18 yas alti");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
				return oMap;
			}

			if (getYas(tffUyeler.getDogumTarihi()) < 7) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
				return oMap;
			}
		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.GECERSIZ_TARIH);
			oMap.put("RESPONSE_DETAIL", "KK D 18 yas kontrolu yapilamadi");
			return oMap;
		}

		if ("E".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")) && StringUtils.isBlank(iMap.getString("EMAIL")) && !"NTS02".equals(iMap.getString("SOURCE"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.EKSTRE_TIPI_EMAIL_SECILEMEZ);
			return oMap;
		}
		if (StringUtils.isNotBlank(iMap.getString("DESTEK_HESAP_VAR_MI")) && "E".equals(iMap.getString("DESTEK_HESAP_VAR_MI")) && !"NTS02".equals(iMap.getString("SOURCE"))) {
			String aylikGelir = iMap.getString("AYLIK_GELIR");
			String ekstreSecim = iMap.getString("DESTEK_HESAP_EKSTRE_SECIMI");
			String emailEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_EMAIL");
			String postaEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_POSTA");
			String otoLimit = iMap.getString("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI");

			if ("P".equals(iMap.getString("KART_TIPI"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_KART_TIPI_UYGUN_DEGIL);
				return oMap;
			}
			if (StringUtils.isBlank(aylikGelir)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_AYLIK_GELIR_BOS_OLAMAZ);
				return oMap;
			}

			if ((StringUtils.isBlank(emailEktre) && StringUtils.isBlank(postaEktre)) || (("H".equals(emailEktre) && "H".equals(postaEktre)))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_TIPI_BOS_OLAMAZ);
				return oMap;
			}
			if (StringUtils.isNotBlank(emailEktre) && "E".equals(emailEktre)) {
				if (!isEmailValid(iMap.getString("EMAIL"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_EPOSTA_ICIN_EMAIL_BOS_OLAMAZ);
					return oMap;
				}
			}

			if (StringUtils.isNotBlank(postaEktre) && "E".equals(postaEktre) && (StringUtils.isBlank(ekstreSecim) || (!"E".equals(ekstreSecim) && !"I".equals(ekstreSecim)))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_POSTA_ICIN_SECIM_BOS_OLAMAZ);
				return oMap;
			}
		}

		if (tffUyeler == null) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_UYE_NO_BULUNAMADI_HATASI);
			return oMap;
		}
		if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI")) && !"NTS02".equals(iMap.getString("SOURCE"))) {
			String kimlikNo = iMap.getString("KIMLIK_SERI_NO") + "-" + iMap.getString("KIMLIK_SIRA_NO");
			if (!kimlikNo.matches("[A-Z0-9]{3}-[A-Z0-9]{6}")) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_KIMLIK_SERI_NO_YANLIS_HATASI);
				return oMap;
			}

		}

		if (tffUyeler.getBankaMusteriNo() == null) {
			BigDecimal bankaMusteriNo = searchCustomer(tffUyeler.getUyruk(), String.valueOf(tffUyeler.getTckn()), tffUyeler.getPasaportNo());
			if (bankaMusteriNo != null && bankaMusteriNo.compareTo(new BigDecimal(0)) == 0)
				tffUyeler.setBankaMusteriNo(bankaMusteriNo);
			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
				return oMap;
			}
		}

		// G4 ve EPOStan gelmiyorsa ev is telefonu kontrollerini yap
		if (!TffServicesMessages.SOURCE_G4.equals(iMap.getString("SOURCE")) && !TffServicesMessages.SOURCE_EPOS.equals(iMap.getString("SOURCE")) && !"NTS02".equals(iMap.getString("SOURCE"))) {

			if (StringUtils.isNotEmpty(iMap.getString("EV_TEL_KOD"))) {
				String evTelUlke = iMap.getString("EV_ULKE_KOD", "90");
				String evTelAlan = iMap.getString("EV_TEL_KOD");
				String evTelNumara = iMap.getString("EV_TEL_NO");

				if (!isPhoneNumberValidInternational(evTelUlke, evTelAlan, evTelNumara)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
					return oMap;
				}
				GMMap kontrol = new GMMap();
				kontrol.put("TEL_ALAN", iMap.getString("EV_TEL_KOD"));
				kontrol.put("IL_KODU", iMap.getString("EV_IL_KOD"));
				if (!telAlanKodDogrumu(kontrol)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_EV_ALAN_EV_ADRES_UYUMSUZ);
					return oMap;
				}

			}

			if (StringUtils.isNotEmpty(iMap.getString("IS_TEL_KOD"))) {
				String isTelUlke = iMap.getString("IS_ULKE_KOD", "90");
				String isTelAlan = iMap.getString("IS_TEL_KOD");
				String isTelNumara = iMap.getString("IS_TEL_NO");

				if (!isPhoneNumberValidInternational(isTelUlke, isTelAlan, isTelNumara)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
					return oMap;
				}

				GMMap kontrol = new GMMap();
				kontrol.put("TEL_ALAN", iMap.getString("IS_TEL_KOD"));
				kontrol.put("IL_KODU", iMap.getString("IS_IL_KOD"));
				if (!telAlanKodDogrumu(kontrol)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_IS_ALAN_IS_ADRES_UYUMSUZ);
					return oMap;
				}
			}
		}
		if (StringUtils.isNotBlank(iMap.getString("TFF_BASVURU_NO"))) {
			TffBasvuru tffbasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffbasvuru != null && "FOTO".equals(tffbasvuru.getDurumKod())) {

				// guncelleme ile geliyor adrste hata aldi
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				return oMap;
			}
		}
		iMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
		iMap.put("TCKN", tffUyeler.getTckn());
		oMap = GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap);
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		iMap.put("DIRECT_CALL", true);
		GMMap tmpMap = new GMMap();
		tmpMap.put("URUN_KODU", iMap.getString("URUN_KODU"));
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", iMap);
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			return oMap;
		}
		else {
			int su = tmpMap.getSize("KART_UYGUNLUK");
			for (int i = 0; i < su; i++) {
				String tip = tmpMap.getString("KART_UYGUNLUK", i, "KART_TIPI");
				String uygunluk = tmpMap.getString("KART_UYGUNLUK", i, "UYGUNLUK");
				if (iMap.getString("KART_TIPI").equals(tip) && "H".equals(uygunluk)) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					if ("KK".equals(iMap.getString("KART_TIPI"))) {
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
					}
					else if ("D".equals(iMap.getString("KART_TIPI"))) {
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
					}
					else if ("P".equals(iMap.getString("KART_TIPI"))) {
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
					}

					return oMap;
				}
			}

		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_COUNT_PHONE_NUMBER")
	public static GMMap countPhoneNumber(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);

		try {
			int countKK = 0;
			int countPP = 0;
			int countDB = 0;
			String tffBsvuruTCKN = "";
			// String countryCode= iMap.getString("CEP_ULKE_KOD");
			String phoneCode = iMap.getString("CEP_TEL_KOD");
			String phoneNumber = iMap.getString("CEP_TEL_NO");

			// List<TffBasvuruTelefon> tffUyeTelefonListe = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("alanKod", phoneCode)).add(Restrictions.eq("numara", phoneNumber)).list();
			//
			// if(tffUyeTelefonListe.size()>=10){
			// oMap.put("RESPONSE", GIRILEN_TELEFON_NUMARASIYLA_EN_FAZLA_10_KAYIT_YAPILABILIR);
			// oMap.put("RESPONSE_DATA", "Girilen telefon numaras�yla en fazla 10 ba�vuru yap�labilir.");
			// }else{
			// oMap.put("RESPONSE", "2");
			// oMap.put("RESPONSE_DATA", "Ba�ar�l�");
			//
			// }

			List<TffBasvuruTelefon> tffUyeTelefonListe = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("alanKod", phoneCode)).add(Restrictions.eq("numara", phoneNumber)).list();
			logger.info("tffUyeTelefonListe.size() --->" + tffUyeTelefonListe.size());
			if (tffUyeTelefonListe.size() > 0) {
				for (int i = 0; i < tffUyeTelefonListe.size(); i++) {
					TffBasvuruTelefon tffTelefon = (TffBasvuruTelefon) tffUyeTelefonListe.get(i);

					TffBasvuru tffBasvuru = (TffBasvuru) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("basvuruNo", tffTelefon.getId().getBasvuruNo())).add(Restrictions.ne("durumKod", "IPTAL")).uniqueResult();
					if (tffBasvuru == null)
						continue;
					// logger.info("tffBasvuru.getKartTipi() --->" + tffBasvuru.getKartTipi());
					if ("KK".equals(tffBasvuru.getKartTipi())) {
						countKK = countKK + 1;
					}
					if ("P".equals(tffBasvuru.getKartTipi())) {
						countPP = countPP + 1;
					}
					if ("D".equals(tffBasvuru.getKartTipi())) {
						countDB = countDB + 1;
					}
					tffBsvuruTCKN = tffBasvuru.getTcKimlikNo();
				}
				logger.info("countKK --->" + countKK);
				logger.info("countPP --->" + countPP);
				logger.info("countDB --->" + countDB);

				// var olan m��teri ile yeni gelen telefon numaras�na ait m��erinin tckn'si ayn� m�?
				List<GnlMusteriTelefon> telefonList = session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("telNo", phoneNumber)).add(Restrictions.eq("alanKod", phoneCode)).list();
				for (int j = 0; j < telefonList.size(); j++) {

					GnlMusteriTelefon musteriTelefon = (GnlMusteriTelefon) telefonList.get(j);

					BigDecimal musteriNo = musteriTelefon.getId().getMusteriNo();
					logger.info("musteriTelefon.getId().getMusteriNo() --->" + musteriNo);

					GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();
					logger.info("musteri.getTcKimlikNo()--->" + musteri.getTcKimlikNo());
					logger.info("tffBasvuru.getTcKimlikNo()--->" + tffBsvuruTCKN);
					// tcknler e�it de�ilse
					if (!StringUtils.equals(musteri.getTcKimlikNo(), tffBsvuruTCKN)) {
						
						if (countKK >= Integer.valueOf(getGlobalParam("COUNT_KK_BASVURU")) || countPP >= Integer.valueOf(getGlobalParam("COUNT_PP_D_BASVURU")) 
								|| countDB >= Integer.valueOf(getGlobalParam("COUNT_PP_D_BASVURU"))) {

							if (countKK >= Integer.valueOf(getGlobalParam("COUNT_KK_BASVURU"))) {
								oMap.put("RESPONSE", GIRILEN_TELEFON_NUMARASIYLA_EN_FAZLA_1_KREDI_KARTI_BA�VURUSU_YAPILABILIR);
								oMap.put("RESPONSE_DATA", "Girilen telefon numaras�yla en fazla 1 kredi kart� ba�vurusu yap�labilir.");
								return oMap;
							}
							if (countPP >= Integer.valueOf(getGlobalParam("COUNT_PP_D_BASVURU")) || countDB >= Integer.valueOf(getGlobalParam("COUNT_PP_D_BASVURU"))) {
								oMap.put("RESPONSE", GIRILEN_TELEFON_NUMARASIYLA_EN_FAZLA_10_KAYIT_YAPILABILIR);
								oMap.put("RESPONSE_DATA", "Bu telefon numaras� ile ba�vurulabilecek Passolig Kart say�s� limiti dolmu�tur, l�tfen ba�ka bir telefon numaras� ile tekrar deneyiniz");
								return oMap;
							}

						}
						else {
							oMap.put("RESPONSE", "2");
							oMap.put("RESPONSE_DATA", "Ba�ar�l�");
							return oMap;
						}

					}
					else { // m��terilerin tckn'leri e�itse kontrol� ge�ti.
						oMap.put("RESPONSE", "2");
						oMap.put("RESPONSE_DATA", "Ba�ar�l�");
						return oMap;
					}

				}

			}
			// girilen telefona ait hi� ba�vuru yoksa kontrol� ge�ti.
			else {
				oMap.put("RESPONSE", "2");
				oMap.put("RESPONSE_DATA", "Ba�ar�l�");
				return oMap;
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_CREATE_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap basvuruMap = new GMMap();
		GMMap tMap = new GMMap();
		try {
			oMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU", iMap);
			if (!"2".equals(oMap.getString("RESPONSE"))) {
				return oMap;
			}
			oMap=GMServiceExecuter.call("BNSPR_COMMON_COUNT_PHONE_NUMBER", iMap);
			if (!"2".equals(oMap.getString("RESPONSE"))) {
				return oMap;
			}

			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));

			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_UYE_NO_BULUNAMADI_HATASI);
				return oMap;
			}
			if (!StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO"))) {
				TffBasvuru tffbasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffbasvuru != null) {
					basvuruMap.put("TFF_BASVURU_NO", tffbasvuru.getBasvuruNo());

				}
				else if (tffbasvuru == null && "SMS".equals(iMap.getString("SOURCE"))) {
					basvuruMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
				}
				else {

					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_BASVURU_NO_BULUNAMADI_HATASI);
				}
			}
			else {
				tMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_GET_BASVURU_NO", new GMMap()));
				basvuruMap.put("TFF_BASVURU_NO", tMap.getString("ID"));
			}

			if (!TffServicesMessages.KART_TIPI_PREPAID.equals(iMap.getString("KART_TIPI")) && !TffServicesMessages.KART_TIPI_DEBIT.equals(iMap.getString("KART_TIPI")) && !TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_KART_TIPI_TANIMSIZ_HATASI);
				return oMap;
			}

			if (!iMap.containsKey("URUN_ID")) {
				String isUnder18S = "H";
				try {
					boolean isUnder18 = isUnder18(tffUyeler.getDogumTarihi());

					if (isUnder18) {
						isUnder18S = "E";
					}
				}
				catch (Exception e) {

				}
				List<TffSsProductMap> tffSsProductMapList = (List<TffSsProductMap>) session.createCriteria(TffSsProductMap.class).add(Restrictions.eq("kartTipi", iMap.getString("KART_TIPI"))).add(Restrictions.eq("urunSahipKod", iMap.getString("URUN_SAHIP_KODU"))).add(Restrictions.eq("gecerli", "E")).add(Restrictions.eq("under18", isUnder18S)).list();

				TffSsProductMap tffSsProductMap = null;

				if (tffSsProductMapList == null || tffSsProductMapList.size() <= 0) {
					CreditCardServicesUtil.raiseGMError("Urun tak�m e�le�tirilmesi yap�lamad�");
				}
				else {
					tffSsProductMap = (TffSsProductMap) tffSsProductMapList.get(0);
					iMap.put("URUN_ID", tffSsProductMap != null ? tffSsProductMap.getUrunId() : null);

				}
			}

			basvuruMap.put("UYE_NO", tffUyeler.getUyeNo());

			basvuruMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());
			basvuruMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
			basvuruMap.put("TCKN", tffUyeler.getTckn());
			basvuruMap.put("DURUM_KODU", "FOTO");
			basvuruMap.put("TAKIM", tffUyeler.getTakim());
			basvuruMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			basvuruMap.put("KURYE_TIPI", iMap.getString("KURYE_TIPI"));
			basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			basvuruMap.put("KART_TIPI", iMap.getString("KART_TIPI"));
			basvuruMap.put("URUN_KODU", iMap.getString("URUN_KODU"));
			basvuruMap.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
			basvuruMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			basvuruMap.put("EMAIL", iMap.getString("EMAIL"));
			basvuruMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			basvuruMap.put("KIMLIK_SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			basvuruMap.put("KIMLIK_TIPI", iMap.getString("KIMLIK_TIPI"));
			basvuruMap.put("SOURCE", iMap.getString("SOURCE"));
			basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			basvuruMap.put("CLIENT_REF_ID", iMap.getString("CLIENT_REF_ID", ""));

			basvuruMap.put("GISE_ID", iMap.getString("GISE_ID", ""));
			basvuruMap.put("GISE_USER", iMap.getString("GISE_USER", ""));
			basvuruMap.put("URUN_ID", iMap.getBigDecimal("URUN_ID"));

			if (StringUtils.isNotEmpty(iMap.getString("KANAL_KODU"))) {
				basvuruMap.put("KANAL_KODU", iMap.getString("KANAL_KODU"));
			}
			else {
				String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
				basvuruMap.put("KANAL_KODU", kanalKodu);
			}

			// vade yenileme ile y�nlendirilmi� yeni ba�vuru ise ba�vuruya iz kayd� at�yoruz
			if (StringUtils.isNotBlank(iMap.getString("VD_KAYNAK_BASVURU_NO"))) {
				basvuruMap.put("VD_KAYNAK_BASVURU_NO", iMap.getBigDecimal("VD_KAYNAK_BASVURU_NO"));
				basvuruMap.put("VD_BASVURU_MU", "E");
			}

			if (StringUtils.isNotBlank(iMap.getString("DESTEK_HESAP_VAR_MI")) && "E".equals(iMap.getString("DESTEK_HESAP_VAR_MI")))
				basvuruMap.put("DESTEK_HESAP_VAR_MI", iMap.getString("DESTEK_HESAP_VAR_MI", "H"));

			GMMap trxMap = new GMMap();
			if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {

				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				basvuruMap.put("TRX_NO", trxMap.getString("TRX_NO"));
				iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			}
			else {
				basvuruMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			}

			GMServiceExecuter.call("BNSPR_TFF_SAVE_BASVURU", basvuruMap);

			GMMap kimlik = new GMMap();
			if ("TR".equals(tffUyeler.getUyruk())) {
				kimlik.put("TCKN", tffUyeler.getTckn());
				kimlik = GMServiceExecuter.call("BNSPR_TFF_KPS_BILGISI_SORGULA", kimlik);
				if (!"2".equals(kimlik.getString("RESPONSE"))) {
					logger.error("KPS HATASI" + kimlik.getString("RESPONSE_DATA"));
					return kimlik;
				}
				kimlik.put("ISLEM_FLAG", "E");
				kimlik.put("TRX_NO", iMap.getString("TRX_NO"));
				kimlik.put("UYRUK_KOD", tffUyeler.getUyruk());
				kimlik.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				kimlik.put("TCKN", tffUyeler.getTckn());
				kimlik.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));

			}
			else {
				kimlik.put("ISLEM_FLAG", "E");
				kimlik.put("TRX_NO", iMap.getString("TRX_NO"));
				kimlik.put("UYRUK_KOD", tffUyeler.getUyruk());
				kimlik.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				kimlik.put("AD1", tffUyeler.getAdi());
				kimlik.put("AD2", tffUyeler.getIkinciAdi());
				kimlik.put("PASAPORT_NO", tffUyeler.getPasaportNo());
				kimlik.put("SOYAD", tffUyeler.getSoyadi());
				kimlik.put("DOGUM_TARIHI", tffUyeler.getDogumTarihi());
			}
			GMMap tmpMap = GMServiceExecuter.call("BNSPR_TRN3801_SAVE_OR_UPDATE_KIMLIK", kimlik);

			if (!StringUtils.isBlank(CreditCardServicesUtil.nvl(iMap.getString("CEP_TEL_NO"), tffUyeler.getCepUlkeKod()))) {
				GMMap telefon = new GMMap();
				telefon.put("TRX_NO", iMap.getString("TRX_NO"));
				telefon.put("TELEFON_TIPI", "C");
				telefon.put("ULKE_KOD", CreditCardServicesUtil.nvl(iMap.getString("CEP_ULKE_KOD"), tffUyeler.getCepUlkeKod()));
				telefon.put("ALAN_KOD", CreditCardServicesUtil.nvl(iMap.getString("CEP_TEL_KOD"), tffUyeler.getCepAlanKod()));
				telefon.put("NUMARA", CreditCardServicesUtil.nvl(iMap.getString("CEP_TEL_NO"), tffUyeler.getCepNumara()));
				telefon.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				telefon.put("ILETISIM_MI", "E");
				iMap.put("CEP_ULKE_KOD", tffUyeler.getCepUlkeKod());
				tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_PHONE", telefon);
				if (!"2".equals(tmpMap.getString("RESPONSE"))) {
					return tmpMap;
				}
			}

			if (!StringUtils.isBlank(iMap.getString("EV_TEL_NO"))) {
				GMMap evTelefon = new GMMap();
				evTelefon.put("TRX_NO", iMap.getString("TRX_NO"));
				evTelefon.put("TELEFON_TIPI", "E");
				evTelefon.put("ULKE_KOD", iMap.getString("EV_ULKE_KOD", "90"));
				evTelefon.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
				evTelefon.put("NUMARA", iMap.getString("EV_TEL_NO"));
				evTelefon.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				evTelefon.put("ILETISIM_MI", "H");
				tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_PHONE", evTelefon);
				if (!"2".equals(tmpMap.getString("RESPONSE"))) {
					return tmpMap;
				}
			}
			if (!StringUtils.isBlank(iMap.getString("IS_TEL_NO"))) {
				GMMap isTelefon = new GMMap();
				isTelefon.put("TRX_NO", iMap.getString("TRX_NO"));
				isTelefon.put("TELEFON_TIPI", "I");
				isTelefon.put("ULKE_KOD", iMap.getString("IS_ULKE_KOD", "90"));
				isTelefon.put("ALAN_KOD", iMap.getString("IS_TEL_KOD"));
				isTelefon.put("NUMARA", iMap.getString("IS_TEL_NO"));
				isTelefon.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				isTelefon.put("ILETISIM_MI", "H");
				tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_PHONE", isTelefon);
				if (!"2".equals(tmpMap.getString("RESPONSE"))) {
					return tmpMap;
				}
			}

			if (StringUtils.isNotBlank(iMap.getString("EV_IL_KOD"))) {
				GMMap uyeAdres = new GMMap();
				uyeAdres.put("TRX_NO", iMap.getString("TRX_NO"));
				uyeAdres.put("UYE_NO", iMap.getString("UYE_NO"));
				uyeAdres.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				uyeAdres.put("ADRES_TIPI", "E");
				uyeAdres.put("ACIK_ADRES", iMap.getString("EV_ACIK_ADRES"));
				uyeAdres.put("IL_AD", iMap.getString("EV_IL_AD"));
				uyeAdres.put("IL_KOD", iMap.getString("EV_IL_KOD"));
				uyeAdres.put("ILCE_KOD", iMap.getString("EV_ILCE_KOD"));
				uyeAdres.put("ILCE_AD", iMap.getString("EV_ILCE_AD"));
				if (StringUtils.isNotBlank(iMap.getString("EV_IS_MATCHED")) && NumberUtils.isNumber(iMap.getString("EV_IS_MATCHED"))) {
					uyeAdres.put("IS_MATCHED", iMap.getBigDecimal("EV_IS_MATCHED"));
				}
				else {
					uyeAdres.put("IS_MATCHED", BigDecimal.ZERO);
				}
				uyeAdres.put("ADRES_RUMUZ", "EV");
				uyeAdres.put("SOURCE", iMap.getString("SOURCE"));
				uyeAdres.put("TESLIMAT_ADRESI_MI", "E".equals(iMap.getString("TESLIMAT_ADRES_TIPI")) ? "E" : "H");
				uyeAdres.put("ILETISIM_MI", "E".equals(iMap.getString("ILETISIM_ADRES_TIPI")) ? "E" : "H");
				uyeAdres.put("TESLIMAT_NOKTASI_KODU", "");
				uyeAdres.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ADRES_EKLE", uyeAdres));

				if (!"2".equals(uyeAdres.getString("RESPONSE"))) {
					throw new GMRuntimeException(0, TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
				}
				else {
					oMap.put("EV_ADRES_NO", uyeAdres.getString("ADRES_NO"));
				}
			}
			if (StringUtils.isNotBlank(iMap.getString("IS_IL_KOD"))) {
				GMMap uyeAdres = new GMMap();
				uyeAdres.put("TRX_NO", iMap.getString("TRX_NO"));
				uyeAdres.put("UYE_NO", iMap.getString("UYE_NO"));
				uyeAdres.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				uyeAdres.put("ADRES_TIPI", "I");
				uyeAdres.put("ACIK_ADRES", iMap.getString("IS_ACIK_ADRES"));
				uyeAdres.put("IL_AD", iMap.getString("IS_IL_AD"));
				uyeAdres.put("IL_KOD", iMap.getString("IS_IL_KOD"));
				uyeAdres.put("ILCE_KOD", iMap.getString("IS_ILCE_KOD"));
				uyeAdres.put("ILCE_AD", iMap.getString("IS_ILCE_AD"));
				if (StringUtils.isNotBlank(iMap.getString("IS_IS_MATCHED")) && NumberUtils.isNumber(iMap.getString("IS_IS_MATCHED"))) {
					uyeAdres.put("IS_MATCHED", iMap.getBigDecimal("IS_IS_MATCHED"));
				}
				else {
					uyeAdres.put("IS_MATCHED", BigDecimal.ZERO);
				}

				uyeAdres.put("ADRES_RUMUZ", "IS");
				uyeAdres.put("SOURCE", iMap.getString("SOURCE"));
				uyeAdres.put("TESLIMAT_ADRESI_MI", "I".equals(iMap.getString("TESLIMAT_ADRES_TIPI")) ? "E" : "H");
				uyeAdres.put("ILETISIM_MI", "I".equals(iMap.getString("ILETISIM_ADRES_TIPI")) ? "E" : "H");
				uyeAdres.put("TESLIMAT_NOKTASI_KODU", "");
				uyeAdres.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ADRES_EKLE", uyeAdres));
				if (!"2".equals(uyeAdres.getString("RESPONSE"))) {
					throw new GMRuntimeException(0, TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
				}
				else {
					oMap.put("IS_ADRES_NO", uyeAdres.getString("ADRES_NO"));
				}
			}
			if (!"EPOS".equals(iMap.getString("SOURCE")) && !"NTS02".equals(iMap.getString("SOURCE"))) {
				GMMap meslekiBilgi = new GMMap();
				meslekiBilgi.put("TRX_NO", iMap.getString("TRX_NO"));
				meslekiBilgi.put("AYLIK_GELIR", iMap.getBigDecimal("AYLIK_GELIR"));
				meslekiBilgi.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
				meslekiBilgi.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
				meslekiBilgi.put("ISYERI_FAALIYET_ALANI", iMap.getString("ISYERI_FAALIYET_ALANI"));
				meslekiBilgi.put("ISYERI_VERGI_DAIRESI_ADI", iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				meslekiBilgi.put("ISYERI_VERGI_DAIRESI_IL", iMap.getString("ISYERI_VERGI_DAIRESI_IL"));

				meslekiBilgi.put("MESLEK", StringUtils.isBlank(iMap.getString("MESLEK")) ? "14" : iMap.getString("MESLEK"));
				meslekiBilgi.put("UNVANI", iMap.getString("UNVANI"));
				meslekiBilgi.put("EGITIM", iMap.getString("OGRENIM_DURUMU"));

				meslekiBilgi.put("TFF_BASVURU_NO", basvuruMap.getString("TFF_BASVURU_NO"));
				tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ADD_APPLICATION_OCCUPATION", meslekiBilgi);
			}

			if (StringUtils.isNotBlank(iMap.getString("DESTEK_HESAP_VAR_MI")) && "E".equals(iMap.getString("DESTEK_HESAP_VAR_MI"))) {
				String ekstreSecim = iMap.getString("DESTEK_HESAP_EKSTRE_SECIMI");
				String emailEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_EMAIL");
				String postaEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_POSTA");
				String otoLimit = iMap.getString("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI");

				TffBasvuruKdhTx kdhtx = new TffBasvuruKdhTx();
				kdhtx.setTxNo(trxMap.getBigDecimal("TRX_NO"));
				kdhtx.setBasvuruNo(basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
				kdhtx.setEkstreTipiEmail(emailEktre);
				kdhtx.setEkstreTipiPosta(postaEktre);
				kdhtx.setEkstreSecimi(ekstreSecim);
				kdhtx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				if (StringUtils.isBlank(otoLimit)) {
					otoLimit = "H";
				}
				kdhtx.setOtomatikLimitArtisi(otoLimit);

				session.save(kdhtx);
				session.flush();
			}

			// iMap.put("KULLANICI_KOD",ADCSession.get("USER_ID"));
			// GMServiceExecuter.call("BNSPR_KK_SET_USER_GLOBALS", iMap);
			iMap.put("TRX_NAME", "3801");
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));
			oMap.put("TFF_BASVURU_NO", basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
			oMap.put("EUPT_REF_ID", tffUyeler.getEuptNo());
			oMap.put("TRX_NO", iMap.getString("TRX_NO"));

			if (TffServicesMessages.KART_TIPI_KREDI_KARTI.equals(iMap.getString("KART_TIPI"))) {

				TffKrediKartiBasvuru krediKartiBasvuru = (TffKrediKartiBasvuru) session.get(TffKrediKartiBasvuru.class, basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
				if (krediKartiBasvuru == null)
					krediKartiBasvuru = new TffKrediKartiBasvuru();
				iMap.putAll(kimlik);
				krediKartiBasvuru.setBasvuruNo(basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
				krediKartiBasvuru.setAnneKizlikSoyad(iMap.getString("ANNE_KIZLIK_SOYADI"));
				krediKartiBasvuru.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				krediKartiBasvuru.setBasvuruNo(basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
				krediKartiBasvuru.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
				krediKartiBasvuru.setCepUlkeKod(iMap.getString("CEP_ULKE_KOD"));
				krediKartiBasvuru.setCepTelKod(iMap.getString("CEP_TEL_KOD"));
				krediKartiBasvuru.setCepTelNo(iMap.getString("CEP_TEL_NO"));
				
				krediKartiBasvuru.setEkstreSecim(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"));
				krediKartiBasvuru.setEkstreTipiEmail(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL"));
				krediKartiBasvuru.setEkstreTipiSms(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS"));
				
				if (StringUtils.isNotBlank(iMap.getString("EMAIL")) && ("H".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")) && "H".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA")))) {
					krediKartiBasvuru.setEkstreTipiEmail("E");
					krediKartiBasvuru.setEkstreTipiSms("E");
				}
				/*TYATLAS-1108*/
				if (StringUtils.isNotBlank(iMap.getString("EMAIL")) && ("E".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")))) {
					krediKartiBasvuru.setEkstreTipiSms("E");
				}
				else if ("H".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")) && "E".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"))) {
					krediKartiBasvuru.setEkstreTipiSms("H");
				}
				/*TYATLAS-1108*/
				
				krediKartiBasvuru.setEkstreTipiPosta(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"));

				krediKartiBasvuru.setEmail(iMap.getString("EMAIL"));
				krediKartiBasvuru.setOtomatikLimitArtimi(iMap.getString("OTOMATIK_LIMIT_ARTIMI", "H"));

				krediKartiBasvuru.setEvUlkeKod(iMap.getString("EV_ULKE_KOD"));
				krediKartiBasvuru.setEvTelKod(iMap.getString("EV_TEL_KOD"));
				krediKartiBasvuru.setEvTelNo(iMap.getString("EV_TEL_NO"));
				krediKartiBasvuru.setHesapKesimTarihi(iMap.getString("HESAP_KESIM_TARIHI"));

				krediKartiBasvuru.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
				krediKartiBasvuru.setIsUlkeKod(iMap.getString("IS_ULKE_KOD"));
				krediKartiBasvuru.setIsTelKod(iMap.getString("IS_TEL_KOD"));
				krediKartiBasvuru.setIsTelNo(iMap.getString("IS_TEL_NO"));
				krediKartiBasvuru.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
				krediKartiBasvuru.setIsyeriVergiDairesiAdi(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				krediKartiBasvuru.setIsyeriVergiDairesiIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
				krediKartiBasvuru.setKartOtomatikOdeme(iMap.getString("KART_OTOMATIK_ODEME"));
				krediKartiBasvuru.setKartUzerindekiIsim(iMap.getString("KART_UZERINDEKI_ISIM"));
				krediKartiBasvuru.setMeslekKod(StringUtils.isBlank(iMap.getString("MESLEK")) ? "14" : iMap.getString("MESLEK"));
				krediKartiBasvuru.setOgrenimDurumu(iMap.getString("OGRENIM_DURUMU"));
				krediKartiBasvuru.setSource(iMap.getString("SOURCE"));
				krediKartiBasvuru.setTckn(iMap.getBigDecimal("TCKN"));
				// krediKartiBasvuru.setUnvanKod(iMap.getString("UNVANI"));
				krediKartiBasvuru.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
				krediKartiBasvuru.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
				krediKartiBasvuru.setTckn(tffUyeler.getTckn());
				krediKartiBasvuru.setYurtdisiEkstreTipi(iMap.getString("YURT_DISI_EKSTRE_TIP"));
				krediKartiBasvuru.setKartTipi(basvuruMap.getString("KART_TIPI"));
				if(iMap.containsKey("KART_LIMITI") && !StringUtils.isEmpty(iMap.getString("KART_LIMITI"))){
				krediKartiBasvuru.setKartLimiti(iMap.getBigDecimal("KART_LIMITI"));
				}
				krediKartiBasvuru.setEvIl(iMap.getString("EV_IL_KOD"));
				krediKartiBasvuru.setEvIlce(iMap.getString("EV_ILCE_KOD"));
				krediKartiBasvuru.setEvAdresi(iMap.getString("EV_ACIK_ADRES"));

				krediKartiBasvuru.setIsIl(iMap.getString("IS_IL_KOD"));
				krediKartiBasvuru.setIsIlce(iMap.getString("IS_ILCE_KOD"));
				krediKartiBasvuru.setIsAdresi(iMap.getString("IS_ACIK_ADRES"));
				krediKartiBasvuru.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRES_TIPI"));

				session.save(krediKartiBasvuru);
				session.flush();

			}
			/*
			 * Kontakt musteride cep telefonu yoksa basurusu sonras� musteri guncelleme cagirilmasi lazim
			 * baska eksik parametrelerde kontrol edilip eklenebilir ihtiyac halinde
			 * */

			boolean musteriGuncelle = false;
			String func = "{? = call pkg_trn3801.kontakt_musteri_guncelle(?)}";
			try {
				String res = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, tffUyeler.getBankaMusteriNo()));
				if ("E".equals(res)) {
					musteriGuncelle = true;
				}
			}
			catch (SQLException e) {
				musteriGuncelle = false;
			}
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			if ("NTS01".equals(iMap.getString("SOURCE")) || musteriGuncelle || "NTS02".equals(iMap.getString("SOURCE"))) {
				iMap.put("TFF_BASVURU_NO", basvuruMap.getBigDecimal("TFF_BASVURU_NO"));
				GMServiceExecuter.call("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", iMap);
			}

			try {
				GMMap crmMap = new GMMap();

				crmMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());
				GMServiceExecuter.execute("BNSPR_TFF_CRM_EXISTING_CUSTOMER_INFO_FULL_UPDATE", crmMap);
			}
			catch (Exception e)

			{
				e.printStackTrace();
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.clear();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			if (TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA.equals(e.getMessage())) {
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
			}
			else {
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_GENEL_HATA);
			}

			return oMap;
		}
		try {
			oMap.put("CRM_TYPE", CrmTypes.MAIN);
			GMServiceExecuter.call("BNSPR_TFF_SEND_APPLICATION_TO_CRM", oMap);
		}
		catch (Exception e) {
			oMap.clear();
			oMap.put("RESPONSE_DATA", TffServicesMessages.CRM_GONDERIM_HATASI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
		}

		return oMap;
	}

	/**
	 * 
	 * 
	 * @param iMap
	 * 
	 *            TELEFON_TIPI
	 *            ILETISIM_MI
	 *            TRX_NO
	 *            TFF_BASVURU_NO
	 *            NUMARA
	 *            ULKE_KOD
	 *            ALAN_KOD
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_PHONE")
	public static GMMap addOrUpdateApplicationPhone(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruTelefonTxId id = new TffBasvuruTelefonTxId();
			// id.setTip(iMap.getString("TELEFON_TIPI"));
			if ("E".equals(iMap.getString("TELEFON_TIPI"))) {
				id.setTip("1");
			}
			else if ("C".equals(iMap.getString("TELEFON_TIPI"))) {
				id.setTip("3");
			}
			else if ("I".equals(iMap.getString("TELEFON_TIPI"))) {
				id.setTip("2");
			}
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));

			TffBasvuruTelefonTx tffBasvuruTelefonTx = (TffBasvuruTelefonTx) session.get(TffBasvuruTelefonTx.class, id);
			if (tffBasvuruTelefonTx == null) {
				tffBasvuruTelefonTx = new TffBasvuruTelefonTx();
				tffBasvuruTelefonTx.setId(id);
			}

			if ("E".equals(iMap.getString("TELEFON_TIPI"))) {
				if (StringUtils.isBlank(iMap.getString("ULKE_KOD"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ULKE_KOD_HATALI);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ALAN_KOD"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ALAN_KOD_HATALI);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("NUMARA"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.EV_TEL_NO_HATALI);
					return oMap;
				}
				if (iMap.getString("ULKE_KOD").startsWith("90")) {
					if (iMap.getString("ALAN_KOD").length() != 3) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ALAN_KOD_HATALI);
						return oMap;
					}
					if (iMap.getString("NUMARA").length() != 7) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.EV_TEL_NO_HATALI);
						return oMap;
					}
				}
			}

			if ("I".equals(iMap.getString("TELEFON_TIPI"))) {
				if (StringUtils.isBlank(iMap.getString("ULKE_KOD"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ULKE_KOD_HATALI);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ALAN_KOD"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ALAN_KOD_HATALI);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("NUMARA"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.IS_TEL_NO_HATALI);
					return oMap;
				}

				if (iMap.getString("ULKE_KOD").startsWith("90")) {
					if (iMap.getString("ALAN_KOD").length() != 3) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ALAN_KOD_HATALI);
						return oMap;
					}
					if (iMap.getString("NUMARA").length() != 7) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.IS_TEL_NO_HATALI);
						return oMap;
					}
				}
			}
			if ("C".equals(iMap.getString("TELEFON_TIPI"))) {
				if (StringUtils.isBlank(iMap.getString("ULKE_KOD"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_ULKE_KOD_HATALI);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("ALAN_KOD"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_ALAN_KOD_HATALI);
					return oMap;
				}
				if (StringUtils.isBlank(iMap.getString("NUMARA"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_TEL_NO_HATALI);
					return oMap;
				}
				if (iMap.getString("ULKE_KOD").startsWith("90")) {
					if (iMap.getString("ALAN_KOD").length() != 3) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_ALAN_KOD_HATALI);
						return oMap;
					}
					if (iMap.getString("NUMARA").length() != 7) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.CEP_TEL_NO_HATALI);
						return oMap;
					}
				}
			}

			tffBasvuruTelefonTx.setAlanKod(iMap.getString("ALAN_KOD"));
			tffBasvuruTelefonTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruTelefonTx.setDahili(null);
			tffBasvuruTelefonTx.setIletisim(iMap.getString("ILETISIM_MI", "H"));
			tffBasvuruTelefonTx.setNumara(iMap.getString("NUMARA"));
			tffBasvuruTelefonTx.setUlkeKod(iMap.getString("ULKE_KOD"));

			session.saveOrUpdate(tffBasvuruTelefonTx);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-4");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS")
	public static GMMap addOrUpdateApplicationAddress(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
			if (tffUyeler == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_UYE_NO_BULUNAMADI_HATASI);
				return oMap;
			}
			if (StringUtils.isNotEmpty(iMap.getString("TFF_BASVURU_NO"))) {
				TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
				if (tffBasvuru == null) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_BASVURU_NO_BULUNAMADI_HATASI);
					return oMap;
				}

				if (tffBasvuru.getTffUyeNo().compareTo(tffUyeler.getUyeNo()) != 0) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_BASVURU_NO_UYESI_FARKLI_HATASI);
					return oMap;
				}

				if ("TN".equals(iMap.getString("ADRES_TIPI")) || "GN".equals(iMap.getString("ADRES_TIPI"))) {
					if (StringUtils.isBlank(iMap.getString("TESLIMAT_NOKTASI_KODU"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
						return oMap;
					}
				}
				/*if (StringUtils.isNotBlank(iMap.getString("ADRES_NO")) && !"0".equals(iMap.getString("ADRES_NO"))) {
					TffBasvuruAdresId adresId = new TffBasvuruAdresId();
					adresId.setAdresKod(iMap.getString("ADRES_TIPI"));
					adresId.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
					TffBasvuruAdres adres = (TffBasvuruAdres) session.get(TffBasvuruAdres.class, adresId);
					if (adres != null) {
						if (adres.getUyeAdresNo().compareTo(iMap.getBigDecimal("ADRES_NO")) != 0) {
							List<?> basvuruList = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("musteriNo", tffBasvuru.getMusteriNo())).list();
							boolean adresVar = false;
							for (int i = 0; i < basvuruList.size(); i++) {
								TffBasvuru basvuruDiger = (TffBasvuru) basvuruList.get(i);
								TffBasvuruAdresId adresIdDiger = new TffBasvuruAdresId();
								adresIdDiger.setAdresKod(iMap.getString("ADRES_TIPI"));
								adresIdDiger.setBasvuruNo(basvuruDiger.getBasvuruNo());
								TffBasvuruAdres adresDiger = (TffBasvuruAdres) session.get(TffBasvuruAdres.class, adresIdDiger);
								if (adresDiger != null) {
									if (adresDiger.getUyeAdresNo().compareTo(iMap.getBigDecimal("ADRES_NO")) == 0) {
										adresVar = true;
										break;
									}
								}
							}
							if (!adresVar) {
								oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
								oMap.put("RESPONSE_DATA", TffServicesMessages.ADRES_NO_UYUMSUZ_HATASI);
								return oMap;
							}
						}
					}
					else {
						List<?> basvuruList = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("musteriNo", tffBasvuru.getMusteriNo())).list();
						boolean adresVar = false;
						for (int i = 0; i < basvuruList.size(); i++) {
							TffBasvuru basvuruDiger = (TffBasvuru) basvuruList.get(i);
							TffBasvuruAdresId adresIdDiger = new TffBasvuruAdresId();
							adresIdDiger.setAdresKod(iMap.getString("ADRES_TIPI"));
							adresIdDiger.setBasvuruNo(basvuruDiger.getBasvuruNo());
							TffBasvuruAdres adresDiger = (TffBasvuruAdres) session.get(TffBasvuruAdres.class, adresIdDiger);
							if (adresDiger != null) {
								if (adresDiger.getUyeAdresNo().compareTo(iMap.getBigDecimal("ADRES_NO")) == 0) {
									adresVar = true;
									break;
								}
							}
						}
						if (!adresVar) {
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.ADRES_NO_UYUMSUZ_HATASI);
							return oMap;
						}
					}
				}
*/
				GMMap trxMap = new GMMap();
				if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {

					trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
					iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
				}

				TffBasvuruAdresTxId id = new TffBasvuruAdresTxId();
				id.setAdresKod(iMap.getString("ADRES_TIPI"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));

				TffBasvuruAdresTx tffBasvuruAdresTx = (TffBasvuruAdresTx) session.get(TffBasvuruAdresTx.class, id);
				if (tffBasvuruAdresTx == null) {
					tffBasvuruAdresTx = new TffBasvuruAdresTx();
					tffBasvuruAdresTx.setId(id);
				}
				if (StringUtils.isNotBlank(iMap.getString("ADRES_NO")) && !"0".equals(iMap.getString("ADRES_NO")) && "E".equals(iMap.getString("TESLIMAT_ADRESI_MI", "H"))) {
					tffBasvuruAdresTx.setUyeAdresNo(iMap.getBigDecimal("ADRES_NO"));
					oMap.put("ADRES_NO", iMap.getBigDecimal("ADRES_NO"));

				}
				else {
					GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_ADRESLER);
					BigDecimal aid = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
					tffBasvuruAdresTx.setUyeAdresNo(aid);
					oMap.put("ADRES_NO", aid);
				}
				if ("E".equals(iMap.getString("ADRES_TIPI"))) {
					if (StringUtils.isBlank(iMap.getString("IL_KOD"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.EV_IL_BOS_OLAMAZ);
						return oMap;
					}
					if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ACIK_ADRES_BOS_OLAMAZ);
						return oMap;
					}
					if (StringUtils.isBlank(iMap.getString("ILCE_KOD"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ILCE_BOS_OLAMAZ);
						return oMap;
					}
				}

				if ("I".equals(iMap.getString("ADRES_TIPI"))) {
					if (StringUtils.isBlank(iMap.getString("IL_KOD"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.IS_IL_BOS_OLAMAZ);
						return oMap;
					}
					if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ACIK_ADRES_BOS_OLAMAZ);
						return oMap;
					}
					if (StringUtils.isBlank(iMap.getString("ILCE_KOD"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ILCE_BOS_OLAMAZ);
						return oMap;
					}
				}

				if ("D".equals(iMap.getString("ADRES_TIPI"))) {
					if (StringUtils.isBlank(iMap.getString("IL_KOD"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.DIGER_ADRES_IL_BOS_OLAMAZ);
						return oMap;
					}
					if (StringUtils.isBlank(iMap.getString("ACIK_ADRES"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.DIGER_ADRES_ACIK_ADRES_BOS_OLAMAZ);
						return oMap;
					}
					if (StringUtils.isBlank(iMap.getString("ILCE_KOD"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.DIGER_ADRES_ILCE_BOS_OLAMAZ);
						return oMap;
					}
				}

				if ("E".equals(iMap.getString("ADRES_TIPI")) || "I".equals(iMap.getString("ADRES_TIPI")) || "D".equals(iMap.getString("ADRES_TIPI"))) {
					if (iMap.getString("ACIK_ADRES").length() < 10 || !iMap.getString("ACIK_ADRES").trim().contains(" ")) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
						return oMap;
					}
				}

				if ("E".equals(iMap.getString("TESLIMAT_ADRESI_DEGISTI_MI"))) {
					if (!"E".equals(iMap.getString("TESLIMAT_ADRESI_MI"))) {
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_TESLIMAT_ADRESI_BOS_HATASI);
						return oMap;
					}
				}

				tffBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
				tffBasvuruAdresTx.setIlKod(iMap.getString("IL_KOD"));
				tffBasvuruAdresTx.setIlAd(iMap.getString("IL_AD"));
				tffBasvuruAdresTx.setIlceKod(iMap.getString("ILCE_KOD"));
				tffBasvuruAdresTx.setIlceAd(iMap.getString("ILCE_AD"));
				tffBasvuruAdresTx.setIsMatched(nvl(iMap.getBigDecimal("IS_MATCHED"), BigDecimal.ZERO));
				tffBasvuruAdresTx.setTeslimatAdresiDegistiMi(iMap.getString("TESLIMAT_ADRESI_DEGISTI_MI", "H"));
				tffBasvuruAdresTx.setAcikAdres(iMap.getString("ACIK_ADRES").trim());
				if (!StringUtils.isBlank(iMap.getString("ADRES_RUMUZ")) && "TESLIMAT_NOKTASI".equals(iMap.getString("ADRES_RUMUZ"))) {
					tffBasvuruAdresTx.setTeslimatAdresiMi("E");
				}
				else {
					tffBasvuruAdresTx.setTeslimatAdresiMi(iMap.getString("TESLIMAT_ADRESI_MI", "H"));
				}
				tffBasvuruAdresTx.setTeslimatAdresiMi(iMap.getString("TESLIMAT_ADRESI_MI", "H"));
				tffBasvuruAdresTx.setTeslimatNoktasiKodu(iMap.getString("TESLIMAT_NOKTASI_KODU"));
				tffBasvuruAdresTx.setIletisimMi("E".equals(iMap.getString("ILETISIM_MI")) ? "E" : "H");

				if ("E".equals(tffBasvuruAdresTx.getTeslimatAdresiMi())) {
					tffBasvuruAdresTx.setVeriKontrolEdilecekMi("E"); // set default
					if (!StringUtils.isEmpty(tffBasvuruAdresTx.getAcikAdres())) {

						session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
						Criteria criteria = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "VERI_KONTROL_ADRES_UYGUNLUK_ORANI")).add(Restrictions.eq("key1", "A"));

						GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
						if (gnlParamText != null && gnlParamText.getSayi() != null && gnlParamText.getSayi().intValue() >= 0) {
							BigDecimal compRate = gnlParamText.getSayi();
							GMMap pigeonMap = new GMMap();
							String acikAdres = tffBasvuruAdresTx.getAcikAdres();
							if (!StringUtils.isEmpty(tffBasvuruAdresTx.getIlceAd())) {
								acikAdres = acikAdres + " " + tffBasvuruAdresTx.getIlceAd();
							}
							if (!StringUtils.isEmpty(tffBasvuruAdresTx.getIlAd())) {
								acikAdres = acikAdres + " " + tffBasvuruAdresTx.getIlAd();
							}
							pigeonMap.put("ADDRESS", acikAdres);
							pigeonMap.put("FORMAT_RESPONSE", false);
							AddressOut checkedAdress = (AddressOut) GMServiceExecuter.call("BNSPR_COMMON_DETECT_BEST_ADDRESS", pigeonMap).get("RESULT_ADDRESS");

						}

					}
				}

				session.saveOrUpdate(tffBasvuruAdresTx);
				session.flush();
				iMap.put("TRX_NAME", "3801");
				iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

				if ("E".equals(iMap.getString("TESLIMAT_ADRESI_MI", "H"))) {
					GMMap crmMap = new GMMap();
					crmMap.put("APPLICATIONNO", tffBasvuruAdresTx.getBasvuruNo());
					crmMap.put("ADDRESSCODE", tffBasvuruAdresTx.getId().getAdresKod());
					crmMap.put("ADDRESS", tffBasvuruAdresTx.getAcikAdres());
					crmMap.put("TOWNCODE", tffBasvuruAdresTx.getIlceKod());
					crmMap.put("TOWNNAME", tffBasvuruAdresTx.getIlceAd());
					crmMap.put("CITYCODE", tffBasvuruAdresTx.getIlKod());
					crmMap.put("CITYNAME", tffBasvuruAdresTx.getIlAd());
					crmMap.put("PROCESSDATE", new Date());
					GMServiceExecuter.call("BNSPR_TFF_CRM_SEND_APPLICATION_DELIVERY_ADDRESS", crmMap);
				}

				if ("KK".equals(tffBasvuru.getKartTipi())) {
					TffKrediKartiBasvuru kkb = (TffKrediKartiBasvuru) session.get(TffKrediKartiBasvuru.class, tffBasvuru.getBasvuruNo());
					if (kkb != null) {
						if ("E".equals(iMap.getString("ADRES_TIPI"))) {
							kkb.setEvIl(iMap.getString("IL_KOD"));
							kkb.setEvIlce(iMap.getString("ILCE_KOD"));
							kkb.setEvAdresi(iMap.getString("ACIK_ADRES"));
						}
						else if ("I".equals(iMap.getString("ADRES_TIPI"))) {
							kkb.setIsIl(iMap.getString("IL_KOD"));
							kkb.setIsIlce(iMap.getString("ILCE_KOD"));
							kkb.setIsAdresi(iMap.getString("ACIK_ADRES"));
						}
						if ("E".equals(tffBasvuruAdresTx.getTeslimatAdresiMi())) {
							kkb.setTeslimatAdresi(tffBasvuruAdresTx.getId().getAdresKod());
						}

						session.saveOrUpdate(kkb);
						session.flush();

					}
				}

			}
			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_BASVURU_NO_BULUNAMADI_HATASI);
				return oMap;
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-3");
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
			String mailSubject = "TFF ADRES EKLEME HATA";
			String mailBody = "Odeme adiminda adres eklemede hata :";
			mailBody += "<br> HATA" + TffServicesHelper.getTraceAsString(e);
			mailBody += "<br> MAP" + iMap.toString();
			TffServicesHelper.sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS_LIST")
	public static GMMap addOrUpdateApplicationAddressList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			GMMap trxMap = new GMMap();
			if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {

				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			}
			else {
				iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			}

			if (iMap.getSize("ADRES_LISTE") > 0) {
				for (int i = 0; i < iMap.getSize("ADRES_LISTE"); i++) {

					TffBasvuruAdresTxId id = new TffBasvuruAdresTxId();
					id.setAdresKod(iMap.getString("ADRES_LISTE", i, "ADRES_TIPI"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					TffBasvuruAdresTx tffBasvuruAdresTx = (TffBasvuruAdresTx) session.get(TffBasvuruAdresTx.class, id);
					if (tffBasvuruAdresTx == null) {
						tffBasvuruAdresTx = new TffBasvuruAdresTx();
						tffBasvuruAdresTx.setId(id);
					}

					tffBasvuruAdresTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
					tffBasvuruAdresTx.setIlKod(iMap.getString("ADRES_LISTE", i, "IL_KODU"));
					tffBasvuruAdresTx.setIlAd(iMap.getString("ADRES_LISTE", i, "IL_ADI"));
					tffBasvuruAdresTx.setIlceKod(iMap.getString("ADRES_LISTE", i, "ILCE_KODU"));
					tffBasvuruAdresTx.setIlceAd(iMap.getString("ADRES_LISTE", i, "ILCE_ADI"));

					if ("E".equals(iMap.getString("ADRES_TIPI")) || "I".equals(iMap.getString("ADRES_TIPI"))) {
						if (iMap.getString("ADRES_LISTE", i, "ACIK_ADRES").length() < 10 || !iMap.getString("ADRES_LISTE", i, "ACIK_ADRES").trim().contains(" ")) {
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_ADRES_EKLE_GENEL_HATA);
							return oMap;
						}
					}
					tffBasvuruAdresTx.setAcikAdres(iMap.getString("ADRES_LISTE", i, "ACIK_ADRES"));
					GMMap xMap = new GMMap().put("TABLE_NAME", TffServicesMessages.TABLO_TFF_UYE_ADRESLER);
					BigDecimal aid = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
					tffBasvuruAdresTx.setUyeAdresNo(aid);
					if ("E".equals(iMap.getString("ADRES_LISTE", i, "TESLIMAT_ADRESI_MI"))) {
						tffBasvuruAdresTx.setTeslimatAdresiMi("E");
					}
					if ("E".equals(tffBasvuruAdresTx.getTeslimatAdresiMi())) {
						tffBasvuruAdresTx.setVeriKontrolEdilecekMi("E"); // set default
						if (!StringUtils.isEmpty(tffBasvuruAdresTx.getAcikAdres())) {

							session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
							Criteria criteria = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "VERI_KONTROL_ADRES_UYGUNLUK_ORANI")).add(Restrictions.eq("key1", "A"));

							GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
							if (gnlParamText != null && gnlParamText.getSayi() != null && gnlParamText.getSayi().intValue() >= 0) {
								BigDecimal compRate = gnlParamText.getSayi();
								GMMap pigeonMap = new GMMap();
								String acikAdres = tffBasvuruAdresTx.getAcikAdres();
								if (!StringUtils.isEmpty(tffBasvuruAdresTx.getIlceAd())) {
									acikAdres = acikAdres + " " + tffBasvuruAdresTx.getIlceAd();
								}
								if (!StringUtils.isEmpty(tffBasvuruAdresTx.getIlAd())) {
									acikAdres = acikAdres + " " + tffBasvuruAdresTx.getIlAd();
								}

								pigeonMap.put("ADDRESS", acikAdres);
								pigeonMap.put("FORMAT_RESPONSE", false);
								AddressOut checkedAdress = (AddressOut) GMServiceExecuter.call("BNSPR_COMMON_DETECT_BEST_ADDRESS", pigeonMap).get("RESULT_ADDRESS");

							}

						}
					}

					tffBasvuruAdresTx.setTeslimatNoktasiKodu(iMap.getString("ADRES_LISTE", i, "TESLIMAT_NOKTASI_KODU"));
					tffBasvuruAdresTx.setIletisimMi("E".equals(iMap.getString("ADRES_LISTE", i, "ILETISIM_MI")) ? "E" : "H");

					session.saveOrUpdate(tffBasvuruAdresTx);
					session.flush();
					iMap.put("TRX_NAME", "3801");
					iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
					GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

				}
			}
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-3");
		}

		return oMap;
	}

	/**
	 * basvuru kimlik bilgilerini ekle
	 * 
	 * @param iMap
	 *            Yerli
	 * 
	 *            TFF_BASVURU_NO
	 *            TRX_NO
	 *            UYRUK_KOD
	 *            ANNE_KIZLIK_SOYADI
	 *            AD1
	 *            AILE_SIRA_NO
	 *            ANNE_AD
	 *            BABA_AD
	 *            BIREY_SIRA_NO
	 *            CILT_KODU
	 *            CINSIYET
	 *            DOGUM_TARIHI
	 *            DOGUM_YERI
	 *            ES_TCKN
	 *            AD2
	 *            KAYIP_CUZDAN_SERI_NO
	 *            KAYIP_CUZDAN_SIRA_NO
	 *            KIMLIK_SERI_NO
	 *            KIMLIK_SIRA_NO
	 *            NUFUS_MAHALLE
	 *            MEDENI_HALI
	 *            ILCE_KODU
	 *            IL_KODU
	 *            MAHALLE_KOY
	 *            VERILIS_NEDENI
	 *            VERILDIGI_ILCE_ADI
	 *            KIZLIK_SOYAD
	 *            SOYAD
	 *            TCKNO_OUT
	 * 
	 *            Yabanci:
	 *            YABANCI_AD
	 *            YABANCI_IKINCI_AD
	 *            PASAPORT_NO
	 *            YABANCI_SOYAD
	 *            DOGUM_TARIHI
	 * 
	 * @return
	 */
	@GraymoundService("BNSPR_TFF_COMMON_ADD_ID_TO_APPLICATION")
	public static GMMap addIdToApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffBasvuruKimlikTx tffBasvuruKimlikTx = (TffBasvuruKimlikTx) session.get(TffBasvuruKimlikTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruKimlikTx == null) {
				tffBasvuruKimlikTx = new TffBasvuruKimlikTx();
			}

			tffBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tffBasvuruKimlikTx.setUyrukKod(iMap.getString("UYRUK_KOD"));

			if ("TR".equals(tffBasvuruKimlikTx.getUyrukKod())) {
				tffBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
				tffBasvuruKimlikTx.setAd(iMap.getString("AD1"));
				tffBasvuruKimlikTx.setAileSiraNo(iMap.getString("AILE_SIRA_NO"));
				tffBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_AD"));
				tffBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_AD"));
				tffBasvuruKimlikTx.setBireySiraNo(iMap.getString("BIREY_SIRA_NO"));
				tffBasvuruKimlikTx.setCiltNo(iMap.getString("CILT_KODU"));
				tffBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
				tffBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
				tffBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
				tffBasvuruKimlikTx.setEsTcKimlikNo(iMap.getString("ES_TCKN"));
				tffBasvuruKimlikTx.setIkinciAd(iMap.getString("AD2"));
				tffBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI_NO"));
				tffBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_SIRA_NO"));
				tffBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
				tffBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
				tffBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
				tffBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HALI"));
				tffBasvuruKimlikTx.setNufusIlceKod(iMap.getString("ILCE_KODU"));
				tffBasvuruKimlikTx.setNufusIlKod(iMap.getString("IL_KODU"));
				tffBasvuruKimlikTx.setMahalleKoy(iMap.getString("MAHALLE_KOY"));
				tffBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("VERILIS_NEDENI"));
				tffBasvuruKimlikTx.setNufusVerTar(iMap.getDate("VERILIS_TARIHI"));
				tffBasvuruKimlikTx.setNufusVerTarKps(iMap.getDate("VERILIS_TARIHI"));
				tffBasvuruKimlikTx.setNufusVerYer(iMap.getString("VERILDIGI_ILCE_ADI"));
				tffBasvuruKimlikTx.setOncekiSoyad(iMap.getString("KIZLIK_SOYAD"));
				tffBasvuruKimlikTx.setSoyad(iMap.getString("SOYAD"));
				tffBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TCKNO_OUT"));

			}
			else {
				tffBasvuruKimlikTx.setAd(iMap.getString("YABANCI_AD"));
				tffBasvuruKimlikTx.setIkinciAd(iMap.getString("YABANCI_IKINCI_AD"));
				tffBasvuruKimlikTx.setPasaportNo(StringUtils.isEmpty(iMap.getString("PASAPORT_NO")) ? iMap.getString("PASAPORT_NO") : iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH));
				tffBasvuruKimlikTx.setSoyad(iMap.getString("YABANCI_SOYAD"));
				tffBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			}

			session.saveOrUpdate(tffBasvuruKimlikTx);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-5");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_ADD_APPLICATION_OCCUPATION")
	public static GMMap addApplicationOccupation(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruMeslekiBilgiTx tffBasvuruMeslekiBilgiTx = (TffBasvuruMeslekiBilgiTx) session.get(TffBasvuruMeslekiBilgiTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruMeslekiBilgiTx == null) {
				tffBasvuruMeslekiBilgiTx = new TffBasvuruMeslekiBilgiTx();
				tffBasvuruMeslekiBilgiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			tffBasvuruMeslekiBilgiTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			tffBasvuruMeslekiBilgiTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruMeslekiBilgiTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriFaaliyetAlani(iMap.getString("ISYER_FAALIYET_ALANI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiAdi(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			tffBasvuruMeslekiBilgiTx.setIsyeriVergiDairesiIl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			tffBasvuruMeslekiBilgiTx.setMeslek(iMap.getString("MESLEK"));
			tffBasvuruMeslekiBilgiTx.setUnvani(iMap.getString("UNVANI"));
			tffBasvuruMeslekiBilgiTx.setEgitimKod(iMap.getString("EGITIM"));
			session.saveOrUpdate(tffBasvuruMeslekiBilgiTx);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-4");
		}

		return oMap;
	}

	/**
	 * 
	 * DESC : DESCRIPTION
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            TRX_NO
	 *            TFF_BASVURU_NO
	 *            UYE_NO
	 *            EUPT_REF_ID
	 *            MUSTERI_NO
	 *            TCKN
	 *            DURUM_KODU
	 *            KULUP_URUN
	 *            KULUP_URUN_SAHIP
	 *            KART_TIPI
	 *            TAKIM
	 *            CALISMA_SEKLI
	 *            EMAIL
	 *            KURYE_TIPI
	 *            CLIENT_IP
	 *            SOURCE
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 *         TFF_BASVURU_NO
	 *         EUPT_REF_ID
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TFF_COMMON_SAVE_APPLICATION")
	public static GMMap saveApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		// TffBasvuruTx tffBasvuruTx = new TffBasvuruTx();

		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuruTx tffBasvuruTx = (TffBasvuruTx) session.get(TffBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tffBasvuruTx == null)
				tffBasvuruTx = new TffBasvuruTx();
			tffBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tffBasvuruTx.setBasvuruNo(iMap.getBigDecimal("TFF_BASVURU_NO"));
			tffBasvuruTx.setTffUyeNo(iMap.getBigDecimal("UYE_NO"));
			tffBasvuruTx.setEuptUserId(iMap.getString("EUPT_REF_ID"));
			tffBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			tffBasvuruTx.setTcKimlikNo(iMap.getString("TCKN"));
			tffBasvuruTx.setDurumKod(iMap.getString("DURUM_KODU"));
			tffBasvuruTx.setUrun(iMap.getString("URUN_KODU"));
			tffBasvuruTx.setUrunSahipKodu(iMap.getString("URUN_SAHIP_KODU"));
			tffBasvuruTx.setKartTipi(iMap.getString("KART_TIPI"));
			tffBasvuruTx.setTakim(iMap.getString("TAKIM"));
			tffBasvuruTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			tffBasvuruTx.setEPosta(iMap.getString("EMAIL"));
			tffBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
			tffBasvuruTx.setSessionIp(iMap.getString("CLIENT_IP"));
			tffBasvuruTx.setSource(iMap.getString("SOURCE"));
			tffBasvuruTx.setKuryeTipi(iMap.getString("KURYE_TIPI"));
			tffBasvuruTx.setKanalKod(iMap.getString("KANAL_KODU"));
			tffBasvuruTx.setUrunId(iMap.getBigDecimal("URUN_ID"));

			session.saveOrUpdate(tffBasvuruTx);

			session.flush();
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "-2");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_GET_PRODUCT_TEXT")
	public static GMMap getProductText(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			String procStr = "{call BNSPR.PKG_TRN3801.listUrunMetinleri(?)}";
			int i = 0;
			Object[] inputValues = new Object[0];

			i = 0;
			Object[] outputValues = new Object[2];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "TEXT";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			oMap = new GMMap();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_LISTE_SORGULA_GENEL_HATA);
		}

		return oMap;

	}

	public static GMMap createCustomerFromMember(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kpsMap = new GMMap();
		TffUyeler tffUyeler = findUye(iMap.getBigDecimal("UYE_NO"));
		if (tffUyeler.getBankaMusteriNo() == null || tffUyeler.getBankaMusteriNo().compareTo(new BigDecimal(0)) == 0) {
			try {
				kpsMap.put("TCKN", iMap.getString("TCKN"));
				kpsMap.put("TCK_NO", iMap.getString("TCKN"));
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_KPS_BILGISI_SORGULA", kpsMap));
				if (!TffServicesMessages.RESPONSE_BASARILI.equals(kpsMap.getString("RESPONSE"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", kpsMap.getString("RESPONSE_DATA"));
					return kpsMap;
				}
				iMap.putAll(kpsMap);
				iMap.put("F_KPS", "E");
				iMap.put("KPS_TARIH", iMap.getDate("SORGU_TARIHI"));
				GMMap tMap = GMServiceExecuter.call("BNSPR_TFF_CREATE_CUSTOMER", iMap);
				if (tMap.getBigDecimal("MUSTERI_NO").compareTo(BigDecimal.ZERO) > 0) {
					tffUyeler.setBankaMusteriNo(tMap.getBigDecimal("MUSTERI_NO"));
					if (StringUtils.isEmpty(tffUyeler.getEuptNo())) {
						kpsMap.put("MUSTERI_NO", tffUyeler.getBankaMusteriNo());

						kpsMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
						try {
							GMMap euptRegInput = GMServiceExecuter.call("BNSPR_TFF_EUPT_HESABI_OLUSTUR", kpsMap);
							tffUyeler.setEuptNo(euptRegInput.getString("USERID"));
							oMap.put("EUPT_REF_ID", euptRegInput.getString("USERID"));
						}
						catch (Exception e) {
							String mailFrom = "system@aktifbank.com.tr";
							String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
							String mailSubject = "TFF EUPT YARATMA HATA";
							String mailBody = "hata alan kimlik bilgileri:";
							mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
							if ("TR".equals(tffUyeler.getUyruk())) {
								mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
							}
							else {
								mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
							}
							mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
							mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
							mailBody += "<br>" + "MAP:" + iMap.toString();
							sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
							e.printStackTrace();
						}

					}

				}
				else {
					String mailFrom = "system@aktifbank.com.tr";
					String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
					String mailSubject = "TFF MUSTERI YARATMA HATA";
					String mailBody = "hata alan kimlik bilgileri:";
					mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
					if ("TR".equals(tffUyeler.getUyruk())) {
						mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
					}
					else {
						mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
					}
					mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
					mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
					mailBody += "<br>" + "MAP:" + iMap;
					sendMail(mailFrom, mailToParametre, mailSubject, mailBody);

					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_KONTAK_MUSTERI_YARATILAMADI);
					logger.error("---------- createMember : uye tablosuna yazarken hata olustu");
					return oMap;

				}
			}
			catch (Exception e) {
				String mailFrom = "system@aktifbank.com.tr";
				String mailToParametre = "TFF_MUSTERI_YAP_HATA_MAIL_TO";
				String mailSubject = "TFF MUSTERI YARATMA HATA";
				String mailBody = "hata alan kimlik bilgileri:";
				mailBody += "<br>" + "Uyruk:" + tffUyeler.getUyruk();
				if ("TR".equals(tffUyeler.getUyruk())) {
					mailBody += "<br>" + "Tckn:" + tffUyeler.getTckn();
				}
				else {
					mailBody += "<br>" + "Pasaport No:" + tffUyeler.getPasaportNo();
				}
				mailBody += "<br>" + "Ad:" + tffUyeler.getAdi();
				mailBody += "<br>" + "Soyad:" + tffUyeler.getSoyadi();
				mailBody += "<br>" + "MAP:" + iMap;

				sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
				e.printStackTrace();
			}

		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_MATCH_ADDRESS_INFO")
	public static GMMap matchAddressInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			iMap.put("FORMAT_RESPONSE", true);
			GMMap tMap = GMServiceExecuter.call("BNSPR_COMMON_DETECT_BEST_ADDRESSES", iMap);
			int size = tMap.getSize("ADDRESS_LIST");

			for (int i = 0; i < size; i++) {
				AddressOut res = (AddressOut) tMap.get("ADDRESS_LIST", i, "RESULT_ADDRESS");
				oMap.put("ADDRESS_LIST", i, "ACIKLAMA", nvl(res.getAciklama(), ""));
				oMap.put("ADDRESS_LIST", i, "ADRES", nvl(res.toString(), ""));
				oMap.put("ADDRESS_LIST", i, "ULKE", nvl(res.getUlke() == null ? null : res.getUlke().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "IL", nvl(res.getIl() == null ? null : res.getIl().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "ILCE", nvl(res.getIlce() == null ? null : res.getIlce().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "SEMT", nvl(res.getSemt() == null ? null : res.getSemt().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "MAHALLE", nvl(res.getMahalle() == null ? null : res.getMahalle().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "KOY", nvl(res.getKoy() == null ? null : res.getKoy().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "BELDE", nvl(res.getBelde() == null ? null : res.getBelde().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "MEZRA", nvl(res.getMezra() == null ? null : res.getMezra().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "MEVKII", nvl(res.getMevkii() == null ? null : res.getMevkii().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "CADDE", nvl(res.getCadde() == null ? null : res.getCadde().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "SOKAK", nvl(res.getSokak() == null ? null : res.getSokak().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "BULVAR", nvl(res.getBulvar() == null ? null : res.getBulvar().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "MEYDAN", nvl(res.getMeydan() == null ? null : res.getMeydan().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "KUME_EVLER", nvl(res.getKumeEvler() == null ? null : res.getKumeEvler().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "BINA_NO", nvl(res.getBinaNo() == null ? null : res.getBinaNo().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "BINA_AD", nvl(res.getBinaAd() == null ? null : res.getBinaAd().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "BLOK", nvl(res.getBlok() == null ? null : res.getBlok().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "KAPI_NO", nvl(res.getKapiNo() == null ? null : res.getKapiNo().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "KAT", nvl(res.getKat() == null ? null : res.getKat().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "POSTA_KUTUSU", nvl(res.getPostaKutusu() == null ? null : res.getPostaKutusu().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "YOL", nvl(res.getYol() == null ? null : res.getYol().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "POSTA_KODU", nvl(res.getPostaKodu() == null ? null : res.getPostaKodu().getOutText(), ""));
				oMap.put("ADDRESS_LIST", i, "BOLGE_KODU", nvl(res.getBolgeKodu() == null ? null : res.getBolgeKodu(), ""));
				oMap.put("ADDRESS_LIST", i, "COORDINATE_BASED_ON", nvl(res.getCoordinateBasedOn() == null ? null : res.getCoordinateBasedOn(), ""));
				oMap.put("ADDRESS_LIST", i, "LONGTITUDE", nvl(res.getLongitude(), ""));
				oMap.put("ADDRESS_LIST", i, "LATITUDE", nvl(res.getLatitude(), ""));
				oMap.put("ADDRESS_LIST", i, "SCORE", nvl(res.getScore(), ""));
				oMap.put("ADDRESS_LIST", i, "COMPLETENESS_RATE", nvl(res.getCompletenessRate(), ""));
			}
		}
		catch (Exception e) {
			logger.error(getTraceAsString(e));
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ADRES_ESLESTIRME_HATASI);
			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_KK_D_INPUT_KONTROLLERI")
	public static GMMap kkInputKontrolleri(GMMap iMap) {
		GMMap oMap = new GMMap();
		if ("KK".equals(iMap.getString("KART_TIPI"))) {

			// kimlik seri no
			if (StringUtils.isBlank(iMap.getString("KIMLIK_SERI_NO"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.KIMLIK_SERI_NO_BOS_OLAMAZ);
				return oMap;
			}
			// kimlik sira no
			if (StringUtils.isBlank(iMap.getString("KIMLIK_SIRA_NO"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.KIMLIK_SIRA_NO_BOS_OLAMAZ);
				return oMap;
			}
			// anne kizlik soyadi
			if (StringUtils.isBlank(iMap.getString("ANNE_KIZLIK_SOYADI"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ANNE_KIZLIK_SOYADI_BOS_OLAMAZ);
				return oMap;
			}
			// ogrenim durumu
			if (StringUtils.isBlank(iMap.getString("OGRENIM_DURUMU"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.OGRENIM_DURUMU_BOS_OLAMAZ);
				return oMap;
			}

			// meslek //('K', 'O', 'E2', 'E3', 'B', 'D', 'S')
			if (StringUtils.isBlank(iMap.getString("MESLEK")) && ("K".equals(iMap.getString("CALISMA_SEKLI")) || "O".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")) || "B".equals(iMap.getString("CALISMA_SEKLI")) || "D".equals(iMap.getString("CALISMA_SEKLI")) || "E3".equals(iMap.getString("CALISMA_SEKLI")) || "S".equals(iMap.getString("CALISMA_SEKLI")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MESLEK_BOS_OLAMAZ);
				return oMap;
			}
			// vergi dairesi il
			if (StringUtils.isBlank(iMap.getString("ISYERI_VERGI_DAIRESI_IL")) && "KK".equals(iMap.getString("KART_TIPI")) && ("S".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ISYERI_VERGI_DAIRESI_IL_BOS_OLAMAZ);
				return oMap;
			}
			// vergi dairesi adi
			if (StringUtils.isBlank(iMap.getString("ISYERI_VERGI_DAIRESI_ADI")) && ("S".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ISYERI_VERGI_DAIRESI_ADI_BOS_OLAMAZ);
				return oMap;
			}

			// aylik gelir
			// Uyeden tckn bilgisini al
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			TffUyeler tffUyeler = (TffUyeler) session.get(TffUyeler.class, iMap.getBigDecimal("UYE_NO"));
			// Personel ise gelir kontrolu yapilmaz
			GMMap sorguMap = new GMMap();
			sorguMap.put("TC_KIMLIK_NO", tffUyeler.getTckn());// KKda tckn zorunlu
			sorguMap.put("REFERANS_TIPI", "TFF");
			sorguMap.put("HATA_VERILSIN_MI", TffServicesMessages.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_PERSONEL_MI", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("PERSONEL_MI"))) {
				if (StringUtils.isBlank(iMap.getString("AYLIK_GELIR")) || !NumberUtils.isNumber(iMap.getString("AYLIK_GELIR"))) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.AYLIK_GELIR_BOS_OLAMAZ);
					return oMap;
				}
				if (iMap.getBigDecimal("AYLIK_GELIR").compareTo(new BigDecimal("100.00")) <= 0) {
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.AYLIK_GELIR_100_DEN_BUYUK_OLMALI);
					return oMap;
				}
			}

			if (StringUtils.isBlank(iMap.getString("HESAP_KESIM_TARIHI"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.KK_HESAP_KESIM_TARIHI_BOS_OLAMAZ);
				return oMap;
			}
			if (StringUtils.isBlank(iMap.getString("KART_OTOMATIK_ODEME"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.KK_OTOMATIK_ODEME_TALIMATI_BOS_OLAMAZ);
				return oMap;
			}

			String kimlikSeriNo = iMap.getString("KIMLIK_SERI_NO");
			String kimlikSiraNo = iMap.getString("KIMLIK_SIRA_NO");
			if (StringUtils.isNumeric(kimlikSeriNo.substring(0, 1)) || !StringUtils.isNumeric(kimlikSeriNo.substring(1, 2)) || !StringUtils.isNumeric(kimlikSeriNo.substring(2, 3))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_KIMLIK_SERI_NO_YANLIS_HATASI);
				return oMap;
			}

		} // kk kontrolleri

		// calisma sekli
		if (StringUtils.isBlank(iMap.getString("CALISMA_SEKLI"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.CALISMA_SEKLI_BOS_OLAMAZ);
			return oMap;
		}

		// isyeri adi
		if (StringUtils.isBlank(iMap.getString("ISYERI_ADI")) && ("D".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")) || "E3".equals(iMap.getString("CALISMA_SEKLI")) || "K".equals(iMap.getString("CALISMA_SEKLI")) || "O".equals(iMap.getString("CALISMA_SEKLI")) || "S".equals(iMap.getString("CALISMA_SEKLI")) || "TR".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ISYERI_ADI_BOS_OLAMAZ);
			return oMap;
		}

		// ('A', 'C', 'E', 'T');
		// ev adresi
		if (StringUtils.isBlank(iMap.getString("EV_IL_KOD")) && ("A".equals(iMap.getString("CALISMA_SEKLI")) || "C".equals(iMap.getString("CALISMA_SEKLI")) || "E".equals(iMap.getString("CALISMA_SEKLI")) || "T".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.EV_IL_BOS_OLAMAZ);
			return oMap;
		}

		if (StringUtils.isBlank(iMap.getString("EV_ILCE_KOD")) && ("A".equals(iMap.getString("CALISMA_SEKLI")) || "C".equals(iMap.getString("CALISMA_SEKLI")) || "E".equals(iMap.getString("CALISMA_SEKLI")) || "T".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ILCE_BOS_OLAMAZ);
			return oMap;
		}
		if (StringUtils.isBlank(iMap.getString("EV_ACIK_ADRES")) && ("A".equals(iMap.getString("CALISMA_SEKLI")) || "C".equals(iMap.getString("CALISMA_SEKLI")) || "E".equals(iMap.getString("CALISMA_SEKLI")) || "T".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.EV_ACIK_ADRES_BOS_OLAMAZ);
			return oMap;
		}

		// ev telefon
		/*	if(StringUtils.isBlank(iMap.getString("EV_TEL_KOD")) || StringUtils.isBlank(iMap.getString("EV_TEL_NO") )){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.EV_TEL_BOS_OLAMAZ);
				return oMap;
			}else if(StringUtils.isNotBlank(iMap.getString("EV_TEL_KOD")) || StringUtils.isNotBlank(iMap.getString("EV_TEL_NO") )){
				GMMap kontrol = new GMMap();
				kontrol.put("TEL_ALAN", iMap.getString("EV_TEL_KOD") );
				kontrol.put("IL_KODU",iMap.getString("EV_IL_KOD") );
				if ( !telAlanKodDogrumu(kontrol) ){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_EV_ALAN_EV_ADRES_UYUMSUZ);
					return oMap;
				}
				
			}*/
		// ('D', 'E2', 'E3', 'K', 'O', 'S', 'TR')
		// is adresi
		if (StringUtils.isBlank(iMap.getString("IS_IL_KOD")) && ("D".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")) || "E3".equals(iMap.getString("CALISMA_SEKLI")) || "K".equals(iMap.getString("CALISMA_SEKLI")) || "O".equals(iMap.getString("CALISMA_SEKLI")) || "S".equals(iMap.getString("CALISMA_SEKLI")) || "TR".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.IS_IL_BOS_OLAMAZ);
			return oMap;
		}
		if (StringUtils.isBlank(iMap.getString("IS_ILCE_KOD")) && ("D".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")) || "E3".equals(iMap.getString("CALISMA_SEKLI")) || "K".equals(iMap.getString("CALISMA_SEKLI")) || "O".equals(iMap.getString("CALISMA_SEKLI")) || "S".equals(iMap.getString("CALISMA_SEKLI")) || "TR".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ILCE_BOS_OLAMAZ);
			return oMap;
		}

		if (StringUtils.isBlank(iMap.getString("IS_ACIK_ADRES")) && ("D".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")) || "E3".equals(iMap.getString("CALISMA_SEKLI")) || "K".equals(iMap.getString("CALISMA_SEKLI")) || "O".equals(iMap.getString("CALISMA_SEKLI")) || "S".equals(iMap.getString("CALISMA_SEKLI")) || "TR".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.IS_ACIK_ADRES_BOS_OLAMAZ);
			return oMap;
		}

		// is telefon
		if ((StringUtils.isBlank(iMap.getString("IS_TEL_KOD")) || StringUtils.isBlank(iMap.getString("IS_TEL_NO"))) && ("D".equals(iMap.getString("CALISMA_SEKLI")) || "E2".equals(iMap.getString("CALISMA_SEKLI")) || "E3".equals(iMap.getString("CALISMA_SEKLI")) || "K".equals(iMap.getString("CALISMA_SEKLI")) || "O".equals(iMap.getString("CALISMA_SEKLI")) || "S".equals(iMap.getString("CALISMA_SEKLI")) || "TR".equals(iMap.getString("CALISMA_SEKLI")))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.IS_TEL_BOS_OLAMAZ);
			return oMap;
		}
		else if (StringUtils.isNotBlank(iMap.getString("IS_TEL_KOD")) && StringUtils.isNotBlank(iMap.getString("IS_TEL_NO"))) {
			GMMap kontrol = new GMMap();
			kontrol.put("TEL_ALAN", iMap.getString("IS_TEL_KOD"));
			kontrol.put("IL_KODU", iMap.getString("IS_IL_KOD"));
			if (!telAlanKodDogrumu(kontrol)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_IS_ALAN_IS_ADRES_UYUMSUZ);
				return oMap;
			}
		}

		// ekstre tipi
		if ("KK".equals(iMap.getString("KART_TIPI")) && "H".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL", "H")) && "H".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA", "H")) && "H".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_SMS", "H"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.EKSTRE_ADRESI_TIPI_BOS_OLAMAZ);
			return oMap;
		}

		if (StringUtils.isNotBlank(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")) && "E".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_EMAIL")) && StringUtils.isBlank(iMap.getString("EMAIL"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.EMAIL_HATALI_HATASI);
			return oMap;
		}
		if (StringUtils.isNotBlank(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA")) && "E".equals(iMap.getString("KREDI_KARTI_EKSTRE_TIPI_POSTA"))) {
			if (StringUtils.isBlank(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.EKSTRE_ADRESI_SECIMI_BOS_OLAMAZ);
				return oMap;
			}
			else if ("E".equals(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI")) && StringUtils.isBlank(iMap.getString("EV_IL_KOD"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.EV_IL_BOS_OLAMAZ);
				return oMap;
			}
			else if ("I".equals(iMap.getString("KREDI_KARTI_EKSTRE_SECIMI")) && StringUtils.isBlank(iMap.getString("IS_IL_KOD"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.IS_IL_BOS_OLAMAZ);
				return oMap;
			}

		}

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_GET_ODEME_TARIHI")
	public static GMMap getOdemeTarihi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		try {
			if (StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO")) || !StringUtils.isNumeric(iMap.getString("TFF_BASVURU_NO")) || BigDecimal.ZERO.equals(iMap.getBigDecimal("TFF_BASVURU_NO"))) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_GUNCELLE_BASVURU_BULUNAMADIL_HATASI);
				return oMap;
			}
			String func = "{? = call PKG_TFF_BASVURU.Get_Basvuru_Odeme_Tarihi(?)}";
			Date d = (Date) DALUtil.callOracleFunction(func, BnsprType.DATE, BnsprType.NUMBER, iMap.getBigDecimal("TFF_BASVURU_NO"));

			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			oMap.put("ODEME_TARIHI", sdf.format(d));
		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.ODEME_BULUNAMADI);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_URUN_KANAL_KONTROLU")
	public static GMMap kanalUrunKontrolu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			TffUyeler uye = findUye(iMap.getBigDecimal("UYE_NO"));
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

			String func = "{? = call PKG_TFF_BASVURU.Basvuru_Kanal_Urun_Kontrolu(?,?,?,?,?)}";
			String yas18mi = "H";
			if (isUnder18(sdf.format(uye.getDogumTarihi()))) {
				yas18mi = "E";
			}
			else {
				yas18mi = "H";
			}
			String d = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, iMap.getString("SOURCE"), BnsprType.STRING, iMap.getString("KART_TIPI"), BnsprType.STRING, iMap.getString("URUN_KODU"), BnsprType.STRING, iMap.getString("URUN_SAHIP_KODU"), BnsprType.STRING, yas18mi);
			if ("E".equals(d)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			}
			else {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_KANAL_KONTROLU_YAPILAMADI);
		}
		return oMap;
	}

	/**
	 *
	 * Company : Aktifbank
	 *
	 */
	@GraymoundService("BNSPR_TFF_COMMON_GET_BASVURU_BILGILERI")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		int index = 0;
		try {
			if (!isSourceValid(iMap)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			oMap.put("TFF_BASVURU_NO", tffBasvuru.getBasvuruNo());
			oMap.put("TAKIM_KODU", tffBasvuru.getUrunSahipKodu());
			oMap.put("URUN_KODU", tffBasvuru.getUrun());
			oMap.put("KURYE_TIPI", tffBasvuru.getKuryeTipi());
			oMap.put("KART_TIPI", tffBasvuru.getKartTipi());
			oMap.put("DURUM", tffBasvuru.getDurumKod());

			List<TffBasvuruMeslekiBilgi> tffBasvuruMeslekiBilgiList = session.createCriteria(TffBasvuruMeslekiBilgi.class).add(Restrictions.eq("basvuruNo", basvuruNo)).list();
			if (tffBasvuruMeslekiBilgiList.size() == 1) {
				TffBasvuruMeslekiBilgi tffBasvuruMeslekiBilgi = tffBasvuruMeslekiBilgiList.get(0);
				oMap.put("AYLIK_GELIR", tffBasvuruMeslekiBilgi.getAylikGelir());
				oMap.put("CALISMA_SEKLI", tffBasvuruMeslekiBilgi.getCalismaSekli());
				oMap.put("ISYERI_ADI", tffBasvuruMeslekiBilgi.getIsyeriAdi());
				oMap.put("ISYERI_FAALIYET_ALANI", tffBasvuruMeslekiBilgi.getIsyeriFaaliyetAlani());
				oMap.put("ISYERI_VERGI_DAIRESI_ADI", tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiAdi());
				oMap.put("ISYERI_VERGI_DAIRESI_ILI", tffBasvuruMeslekiBilgi.getIsyeriVergiDairesiIl());
				oMap.put("MESLEK", tffBasvuruMeslekiBilgi.getMeslek());
				oMap.put("UNVANI", tffBasvuruMeslekiBilgi.getUnvani());
			}

			List<TffBasvuruAdres> tffBasvuruAdreslerList = session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).list();

			for (TffBasvuruAdres uyeAdres : tffBasvuruAdreslerList) {
				oMap.put("ADRES_LISTE", index, "ADRES_NO", uyeAdres.getUyeAdresNo());
				oMap.put("ADRES_LISTE", index, "ADRES_TIPI", uyeAdres.getId().getAdresKod());
				oMap.put("ADRES_LISTE", index, "ADRES_RUMUZ", new String());
				oMap.put("ADRES_LISTE", index, "IL_KODU", uyeAdres.getIlKod());
				oMap.put("ADRES_LISTE", index, "IL_ADI", uyeAdres.getIlAd());
				oMap.put("ADRES_LISTE", index, "ILCE_KODU", uyeAdres.getIlceKod());
				oMap.put("ADRES_LISTE", index, "ILCE_ADI", uyeAdres.getIlceAd());
				oMap.put("ADRES_LISTE", index, "ACIK_ADRES", uyeAdres.getAcikAdres());
				oMap.put("ADRES_LISTE", index, "ADRES_NO", uyeAdres.getUyeAdresNo());
				oMap.put("ADRES_LISTE", index, "ILETISIM_ADRESI_MI", uyeAdres.getIletisimMi());
				oMap.put("ADRES_LISTE", index, "TESLIMAT_ADRESI_MI", uyeAdres.getTeslimatAdresiMi());
				oMap.put("ADRES_LISTE", index, "TESLIMAT_NOKTASI_KODU", uyeAdres.getTeslimatNoktasiKodu());
				oMap.put("ADRES_LISTE", index, "IS_MATCHED", uyeAdres.getIsMatched());

				index++;
			}

			List<TffBasvuruTelefon> tffUyeTelefonListe = session.createCriteria(TffBasvuruTelefon.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).list();
			index = 0;
			for (TffBasvuruTelefon tffUyeTelefon : tffUyeTelefonListe) {
				oMap.put("TELEFON_LISTE", index, "ALAN_KOD", tffUyeTelefon.getAlanKod());
				oMap.put("TELEFON_LISTE", index, "TELEFON_NUMARA", tffUyeTelefon.getNumara());
				oMap.put("TELEFON_LISTE", index, "TELEFON_ID", tffUyeTelefon.getId().getBasvuruNo());
				oMap.put("TELEFON_LISTE", index, "TELEFON_TIPI", tffUyeTelefon.getId().getTip());
				oMap.put("TELEFON_LISTE", index, "ULKE_KODU", tffUyeTelefon.getUlkeKod());
				index++;
			}

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_SCREEN_WRAPPER_NT")
	public static GMMap screenWrapperNt(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String serviceName = iMap.getString("SERVICE_NAME");
			if (StringUtils.isNotBlank(serviceName)) {
				oMap.putAll(GMServiceExecuter.executeNT(serviceName, iMap));
			}
		}
		catch (Exception e) {
			GMMap tmpMap = new GMMap();
			tmpMap.put("WEB_HATA_KOD", e.getMessage());
			tmpMap.put("HATA_VERILSIN_MI", "H");
			oMap = GMServiceExecuter.call("BNSPR_TFF_HATA_MESAJI_AL", tmpMap);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", oMap.getString("HATA_MESAJI"));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_ODEME_YAPILDI_MI")
	public static GMMap tffOdemeYapildimi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			oMap.put("ODEME_YAPILDIMI", "H");
			if (tffBasvuru != null) {
				TffBasvuruOdeme tffBasvuruOdeme = (TffBasvuruOdeme) session.get(TffBasvuruOdeme.class, basvuruNo);
				if (tffBasvuruOdeme != null) {
					oMap.put("ODEME_YAPILDIMI", "E");
				}
			}
		}
		catch (Exception e) {
			oMap.put("ODEME_YAPILDIMI", "H");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_FOTO_YUKLENDI_MI")
	public static GMMap tffFotoYuklendimi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			oMap.put("FOTO_YUKLENDIMI", "H");
			if (tffBasvuru != null) {
				if ("T".equals(tffBasvuru.getFotoDurum())) {
					oMap.put("FOTO_YUKLENDIMI", "E");
				}
			}
		}
		catch (Exception e) {
			oMap.put("FOTO_YUKLENDIMI", "H");
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		return oMap;
	}

	public static boolean isLocal() {
		return isLocal;
	}

	public static void setLocal(boolean isLocal) {
		TffCommonServices.isLocal = isLocal;
	}

	/**
	 * <p>
	 * Checks if the customer is able to get prepaid card. Checks active uncomplete applications and asks intra system for active cards.
	 * </p>
	 * 
	 * @param iMap
	 *            <li><b>CUSTOMER_NO</b> <li><b>PRODUCT_OWNER (URUN_SAHIP_KODU)</b> : TFF13 <li><b>PRODUCT (URUN_KODU)</b> : TFFSTD
	 * 
	 * @return oMap <li><b>AVAILABILITY</b> : 0 - NO, 1 - No/Warning, 2-YES <li><b>DESCRIPTION</b> : Description for why customer can not get this type of card, error codes <L�> <B>APPLICATION_NO</b> : Previous application no which prevents new application <li><b>RESPONSE</b> : 0 - Error, 2 - Success <li><b>RESPONSE_DATA</b>: Error description
	 *
	 * */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TFF_COMMON_PREPAID_CARD_AVAILABILITY")
	public static GMMap getPrepaidCardAvailability(GMMap iMap) {
		GMMap oMap = new GMMap();
		String pVerebilme = "E";
		String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
		try {
			oMap.put("AVAILABILITY", "2");
			oMap.put("DESCRIPTION", "");
			oMap.put("APPLICATION_NO", "");
			oMap.put("RESPONSE_DATA", "");
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			// Genel olarak prpaid kartlar acikmi kontrol et
			pVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "P", BnsprType.STRING, "UYGUNLUK"));
			if ("H".equals(pVerebilme)) {
				logger.error("-------------getPrepaidCardAvailability : Prepaid kart basvurusu kapatilmisitr.");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
				return oMap;
			}

			if (StringUtils.isBlank(iMap.getString("PRODUCT_OWNER"))) {
				logger.error("-------------getPrepaidCardAvailability : Prepaid kart basvurusu takim bilgisi bos.");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.URUN_SAHIP_KOD_HATASI);
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_SAHIP_KOD_HATASI);
				return oMap;
			}
			if (StringUtils.isBlank(iMap.getString("PRODUCT"))) {
				logger.error("-------------getPrepaidCardAvailability : Prepaid kart basvurusu urun tipi bos.");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
				return oMap;
			}
			if (iMap.getBigDecimal("CUSTOMER_NO") == null || !NumberUtils.isNumber(iMap.getString("CUSTOMER_NO"))) {
				logger.error("-------------getPrepaidCardAvailability : Prepaid kart basvurusu musteri no.");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				return oMap;
			}
			logger.info("-------------getPrepaidCardAvailability : Customer No : " + iMap.getString("CUSTOMER_NO") + " Product : " + iMap.getString("PRODUCT") + " Product Owner : " + iMap.getString("PRODUCT_OWNER"));
			oMap.put("AVAILABILITY", 2);
			oMap.put("DESCRIPTION", "");
			oMap.put("APPLICATION_NO", "");

			// musterinini aktif basvurusu var mi kontrole et
			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			List<TffBasvuru> tffBasvurular = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kartTipi", "P")).add(Restrictions.not(Restrictions.in("durumKod", new String[] { "IPTAL", "RED", "ACIK" }))).list();

			GnlMusteriKimlik musteri = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, iMap.getBigDecimal("CUSTOMER_NO"));
			if (musteri != null) {
				if (getYas(musteri.getDogumTarihi()) <= 7) {
					oMap.put("AVAILABILITY", 0);
					oMap.put("DESCRIPTION", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
					logger.error("-------------getCreditCardAvailability : 7 yas alti");
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_EKLE_TCKN_YAS_7_KONTROLU_HATASI);
					return oMap;
				}
			}
			else {
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				logger.error("-------------getCreditCardAvailability : musteri yok");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				return oMap;
			}
			if (tffBasvurular.size() > 0) {
				for (TffBasvuru b : tffBasvurular) {
					if (b.getUrun().equals(iMap.getString("PRODUCT")) && b.getUrunSahipKodu().equals(iMap.getString("PRODUCT_OWNER"))) {
						oMap.put("AVAILABILITY", 0);
						oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
						// sadece asagidaki durumlarda iptal edilebilir
						if ("BASVURU".equals(b.getDurumKod()) || "FOTO".equals(b.getDurumKod()) || "ODEME".equals(b.getDurumKod()) || "ODEME_BEKLE".equals(b.getDurumKod())) {
							oMap.put("APPLICATION_NO", b.getBasvuruNo());
						}
						oMap.put("RESPONSE", 0);
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
						return oMap;

					}
				}
			}
			GMMap dKontrol = new GMMap();
			dKontrol.put("CARD_DCI", "P");
			dKontrol.put("CUSTOMER_NO", iMap.getString("CUSTOMER_NO"));
			dKontrol.put("CARD_BANK_STATUS", "N");
			dKontrol = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", dKontrol);
			boolean fbKombineVar = false;

			// kart sisteminden musterinin kartlarina bak
			for (int i = 0; i < dKontrol.getSize("CARD_DETAIL_INFO"); i++) {
				if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_PREPAID)) {
					String urunId = dKontrol.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");
					String logoKod = dKontrol.getString("CARD_DETAIL_INFO", i, "LOGO_CODE");
					String func1 = "{? = call pkg_trn3801.get_takim_kodu(?,?,?)}";
					String urunSahipKodu = String.valueOf(DALUtil.callOracleFunction(func1, BnsprType.STRING, BnsprType.STRING, urunId, BnsprType.STRING, logoKod, BnsprType.STRING, "P"));

					String funcUrun = "{? = call pkg_trn3801.get_urun_kodu(?,?,?)}";
					String urunKodu = String.valueOf(DALUtil.callOracleFunction(funcUrun, BnsprType.STRING, BnsprType.STRING, urunId, BnsprType.STRING, logoKod, BnsprType.STRING, "P"));

					if ("TFF11".equals(urunSahipKodu) && "TFFKOM".equals(urunKodu)) {
						fbKombineVar = true;
					}
					// daha once ayni takimin prepaid karti varsa engelle
					if (iMap.getString("PRODUCT_OWNER").equals(urunSahipKodu) && iMap.getString("PRODUCT").equals(urunKodu)) {
						dKontrol.put("KART_NO", dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
						dKontrol.put("KART_TIPI", "P");
						dKontrol = GMServiceExecuter.call("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", dKontrol);
						if ("E".equals(dKontrol.getString("KAPAMA_TALEBI_VAR_MI"))) {
							oMap.put("AVAILABILITY", 1);
							oMap.put("DESCRIPTION", TffServicesMessages.P_KART_KAPAMA_TALEBI_VAR);
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.P_KART_KAPAMA_TALEBI_VAR);
							return oMap;
						}
						else {
							oMap.put("AVAILABILITY", 0);
							oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_P_KART_MEVCUT_HATASI);
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
							oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_KART_MEVCUT_HATASI);
							return oMap;
						}
					}

					// FB kombinesi olan FB prepid alamasin
					if ("TFF11".equals(iMap.getString("PRODUCT_OWNER")) && "TFFKOM".equals(iMap.getString("PRODUCT")) && fbKombineVar) {
						oMap.put("AVAILABILITY", 0);
						oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_P_KART_MEVCUT_HATASI);
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_KART_MEVCUT_HATASI);
						return oMap;
					}
				}
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);

			return oMap;
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "");

		return oMap;
	}

	/**
	 * <p>
	 * Checks if the customer is able to get debit card. Checks active uncomplete applications and asks intra system for active cards.
	 * </p>
	 * 
	 * @param iMap
	 *            <li><b>CUSTOMER_NO</b>
	 * 
	 * 
	 * @return oMap <li><b>AVAILABILITY</b> : 0 - NO, 1 - No/Warning, 2-YES <li><b>DESCRIPTION</b> : Description for why customer can not get this type of card, error codes <L�> <B>APPLICATION_NO</b> : Previous application no which prevents new application <li><b>RESPONSE</b> : 0 - Error, 2 - Success <li><b>RESPONSE_DATA</b>: Error description
	 */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TFF_COMMON_DEBIT_CARD_AVAILABILITY")
	public static GMMap getDebitCardAvailability(GMMap iMap) {
		GMMap oMap = new GMMap();
		String dVerebilme = "E";
		String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
		oMap.put("AVAILABILITY", "2");
		oMap.put("DESCRIPTION", "");
		oMap.put("APPLICATION_NO", "");
		oMap.put("RESPONSE_DATA", "");
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		try {
			dVerebilme = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "D", BnsprType.STRING, "UYGUNLUK"));
			if ("H".equals(dVerebilme)) {
				logger.error("-------------getDebitCardAvailability : Debit kart basvurusu kapatilmisitr.");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
				return oMap;
			}

			if (iMap.getBigDecimal("CUSTOMER_NO") == null || !NumberUtils.isNumber(iMap.getString("CUSTOMER_NO"))) {
				logger.error("-------------getDebitCardAvailability : Debit kart basvurusu musteri no.");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				return oMap;
			}

			Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
			List<TffBasvuru> tffBasvurular = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kartTipi", "D")).add(Restrictions.not(Restrictions.in("durumKod", new String[] { "IPTAL", "RED", "ACIK" }))).list();
			GnlMusteriKimlik musteri = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, iMap.getBigDecimal("CUSTOMER_NO"));
			if (musteri != null) {
				if (isUnder18(musteri.getDogumTarihi())) {
					oMap.put("AVAILABILITY", 0);
					oMap.put("DESCRIPTION", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
					logger.error("-------------getCreditCardAvailability : 18 yas alti");
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
					return oMap;
				}
			}
			else {
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				logger.error("-------------getCreditCardAvailability : musteri yok");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				return oMap;
			}
			if (tffBasvurular.size() > 0) {
				logger.error("-------------getDebitCardAvailability : Debit kart basvurusu var. D alamaz");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
				oMap.put("RESPONSE", 0);
				TffBasvuru b = tffBasvurular.get(0);
				if (!"BASVURU".equals(b.getDurumKod()) && !"FOTO".equals(b.getDurumKod()) && !"ODEME".equals(b.getDurumKod()) && !"ODEME_BEKLE".equals(b.getDurumKod())) {
					oMap.put("APPLICATION_NO", b.getBasvuruNo());
				}
				else {
					oMap.put("APPLICATION_NO", "");
				}
				oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
				return oMap;
			}

			GMMap dKontrol = new GMMap();
			dKontrol.put("CARD_DCI", "D");
			dKontrol.put("CUSTOMER_NO", iMap.getString("CUSTOMER_NO"));
			dKontrol.put("CARD_BANK_STATUS", "N");
			dKontrol = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", dKontrol);

			if (dKontrol.getSize("CARD_DETAIL_INFO") > 0) {
				for (int i = 0; i < dKontrol.getSize("CARD_DETAIL_INFO"); i++) {
					if (dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_DCI").equals(TffServicesMessages.OCEAN_KART_TIPI_DEBIT)) {
						dKontrol.put("KART_NO", dKontrol.getString("CARD_DETAIL_INFO", i, "CARD_NO"));
						dKontrol.put("KART_TIPI", "D");
						dKontrol = GMServiceExecuter.call("BNSPR_KK_KART_KAPAMA_TALEBI_VAR_MI", dKontrol);
						if ("E".equals(dKontrol.getString("KAPAMA_TALEBI_VAR_MI"))) {
							oMap.put("AVAILABILITY", "1");
							oMap.put("DESCRIPTION", TffServicesMessages.D_KART_KAPAMA_TALEBI_VAR);
							oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						}
						else {
							oMap.put("AVAILABILITY", "0");
							oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_D_KART_MEVCUT_HATASI);
							oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
							oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						}
						return oMap;
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("AVAILABILITY", 0);
			oMap.put("DESCRIPTION", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			oMap.put("RESPONSE", 0);
			oMap.put("APPLICATION_NO", "");
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}
		oMap.put("RESPONSE_DATA", "");
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		return oMap;
	}

	/**
	 * <p>
	 * Checks if the customer is able to get credit card. Checks active uncomplete applications and asks ocean system for active cards.
	 * </p>
	 * 
	 * @param iMap
	 *            <li><b>CUSTOMER_NO</b>
	 * 
	 * 
	 * @return oMap <li><b>AVAILABILITY</b> : 0 - NO, 1 - No/Warning, 2-YES <li><b>DESCRIPTION</b> : Description for why customer can not get this type of card, error codes <L�> <B>APPLICATION_NO</b> : Previous application no which prevents new application <li><b>RESPONSE</b> : 0 - Error, 2 - Success <li><b>RESPONSE_DATA</b>: Error description
	 */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TFF_COMMON_CREDIT_CARD_AVAILABILITY")
	public static GMMap getCreditCardAvailability(GMMap iMap) {
		GMMap oMap = new GMMap();
		String krediKartiKontrol = TffServicesMessages.HAYIR;
		oMap.put("AVAILABILITY", "2");
		oMap.put("DESCRIPTION", "");
		oMap.put("APPLICATION_NO", "");
		oMap.put("RESPONSE_DATA", "");
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		logger.info("----------  getCreditCardAvailability -  CUSTOMER_NO : " + iMap.getString("CUSTOMER_NO"));
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?,?)}";
			krediKartiKontrol = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_WEBSERVIS_PARAM", BnsprType.STRING, "VERILEBILIR_MI", BnsprType.STRING, "KK_KONRTOL"));
		}
		catch (Exception e) {
			krediKartiKontrol = TffServicesMessages.HAYIR;
		}
		if (krediKartiKontrol.equals(TffServicesMessages.HAYIR)) {
			oMap.put("AVAILABILITY", 0);
			oMap.put("DESCRIPTION", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
			logger.error("----------  getCreditCardAvailability -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
			return oMap;
		}

		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		List<TffBasvuru> tffBasvurular = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("kartTipi", "KK")).add(Restrictions.not(Restrictions.in("durumKod", new String[] { "IPTAL", "RED", "ACIK" }))).list();

		try {
			TffUyeler uye = (TffUyeler) session.createCriteria(TffUyeler.class).add(Restrictions.eq("bankaMusteriNo", iMap.getBigDecimal("CUSTOMER_NO"))).uniqueResult();

			if (uye != null) {
				iMap.put("TCKN", uye.getTckn());
				if (isUnder18(uye.getDogumTarihi())) {
					oMap.put("AVAILABILITY", 0);
					oMap.put("DESCRIPTION", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
					logger.error("-------------getCreditCardAvailability : 18 yas alti");
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURULAN_KART_UYGUN_DEGIL);
					return oMap;
				}
			}
			else {
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				logger.error("-------------getCreditCardAvailability : musteri yok");
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.MUSTERI_NO_BULUNAMADI);
				return oMap;
			}
			if (tffBasvurular.size() > 0) {
				logger.error("-------------getCreditCardAvailability : KK kart basvurusu var. KK alamaz");
				oMap.put("AVAILABILITY", 0);
				oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
				oMap.put("RESPONSE", 0);

				oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
				TffBasvuru b = tffBasvurular.get(0);
				if (!"BASVURU".equals(b.getDurumKod()) && !"FOTO".equals(b.getDurumKod()) && !"ODEME".equals(b.getDurumKod()) && !"ODEME_BEKLE".equals(b.getDurumKod())) {
					oMap.put("APPLICATION_NO", b.getBasvuruNo());
				}
				else {
					oMap.put("APPLICATION_NO", "");
				}
				return oMap;
			}
		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			oMap.put("AVAILABILITY", "0");
			oMap.put("DESCRIPTION", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			logger.error("----------  getCreditCardAvailability -  Exception :  KK alamaz");
			return oMap;
		}

		try {
			iMap.put("MUST_NO", iMap.getString("CUSTOMER_NO"));
			oMap = GMServiceExecuter.call("BNSPR_TRN3871_KART_VAR_MI", iMap);

			if (oMap.getBoolean("KART_VAR_MI")) {
				if (oMap.getBoolean("KAPAMA_TALEBI_VAR_MI")) {
					logger.error("----------  getCreditCardAvailability - Kart kapama talebi var 	");
					oMap.put("AVAILABILITY", "1");
					oMap.put("DESCRIPTION", TffServicesMessages.KK_KART_KAPAMA_TALEBI_VAR);
					oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				}
				else {
					logger.error("----------  getCreditCardAvailability - Kart var KK alamaz");
					oMap.put("AVAILABILITY", "0");
					oMap.put("DESCRIPTION", TffServicesMessages.AKTIF_KK_KART_MEVCUT_HATASI);
					oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_KART_MEVCUT_HATASI);
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				}
				return oMap;
			}

			GMMap redKontrol = new GMMap();
			redKontrol.put("TCK_NO", iMap.getString("TCKN"));
			redKontrol.put("BASVURU_SONLANDIR", "H");
			oMap = GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_RED_KONTROL", redKontrol);

			if (TffServicesMessages.HAYIR.equals(oMap.getString("DEVAM"))) {
				oMap.put("AVAILABILITY", "0");
				oMap.put("DESCRIPTION", TffServicesMessages.KK_KART_ALABILME_RED);
				oMap.put("RESPONSE_DATA", TffServicesMessages.KK_KART_ALABILME_RED);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				logger.error("----------  getCreditCardAvailability -  KK Red kontrol : KK alamaz");
				return oMap;
			}

			oMap = GMServiceExecuter.call("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", redKontrol);
			if (TffServicesMessages.HAYIR.equals(oMap.getString("DEVAM"))) {
				oMap.put("AVAILABILITY", "0");
				oMap.put("DESCRIPTION", TffServicesMessages.KK_KART_ALABILME_RED);
				oMap.put("RESPONSE_DATA", TffServicesMessages.KK_KART_ALABILME_RED);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);

				logger.error("----------  getCreditCardAvailability -  KK capraz kontrol : KK alamaz");
				return oMap;
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("AVAILABILITY", "0");
			oMap.put("DESCRIPTION", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_KART_ALABILIRLIK_GENEL_HATA);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			logger.error("----------  getCreditCardAvailability -  Exception :  KK alamaz");
			return oMap;
		}

		logger.info("----------  getCreditCardAvailability -  KK_VERILEBILIR_MI : " + oMap.getString("KK_VERILEBILIR_MI"));
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TFF_COMMON_GET_CARD_AVAILABILITY_FOR_MEMBER")
	public static GMMap getCardAvailabilityForMember(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal uyeNo = iMap.getBigDecimal("UYE_NO");
		BigDecimal tckn = iMap.getBigDecimal("TCKN");
		String pasaportNo = StringUtils.isEmpty(iMap.getString("PASAPORT_NO")) ? iMap.getString("PASAPORT_NO") : iMap.getString("PASAPORT_NO").toUpperCase(Locale.ENGLISH);
		String uyruk = iMap.getString("UYRUK");
		String urunSahip = iMap.getString("URUN_SAHIP_KODU");
		String urun = iMap.getString("URUN", "TFFSTD");

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffUyeler uye = (TffUyeler) session.createCriteria(TffUyeler.class).add(Restrictions.eq("uyeNo", uyeNo)).uniqueResult();

		if (uye == null) {
			uye = findUye(uyruk, tckn, pasaportNo);
			if (uye != null) {
				tckn = uye.getTckn();
				pasaportNo = uye.getPasaportNo();
				uyruk = uye.getUyruk();

			}
			else {
				oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_BILGILERI_VER_UYE_KAYDI_BULUNAMADI_HATASI);
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				return oMap;
			}
		}
		if (tckn != null && !tckn.equals(uye.getTckn())) {
			oMap.put("RESPONSE_DATA", TffServicesMessages.UYE_NO_ILE_TCKN_FARKLI);
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			return oMap;
		}

		GMMap sorguMap = new GMMap();
		GMMap tmpMap = new GMMap();
		sorguMap.put("CUSTOMER_NO", uye.getBankaMusteriNo());
		sorguMap.put("TCKN", tckn);
		sorguMap.put("PRODUCT", urun);
		sorguMap.put("PRODUCT_OWNER", urunSahip);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_PREPAID_CARD_AVAILABILITY", sorguMap);
		int index = 0;
		oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "P");
		oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", convertUygunluk(tmpMap.getString("AVAILABILITY")));
		oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", tmpMap.getString("DESCRIPTION"));
		oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tmpMap.getString("APPLICATION_NO"));

		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_DEBIT_CARD_AVAILABILITY", sorguMap);
		index++;
		oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "D");
		oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", convertUygunluk(tmpMap.getString("AVAILABILITY")));
		oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", tmpMap.getString("DESCRIPTION"));
		oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tmpMap.getString("APPLICATION_NO"));

		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREDIT_CARD_AVAILABILITY", sorguMap);
		index++;
		oMap.put("KART_UYGUNLUK", index, "KART_TIPI", "KK");
		oMap.put("KART_UYGUNLUK", index, "UYGUNLUK", convertUygunluk(tmpMap.getString("AVAILABILITY")));
		oMap.put("KART_UYGUNLUK", index, "ACIKLAMA", tmpMap.getString("DESCRIPTION"));
		oMap.put("KART_UYGUNLUK", index, "BASVURU_NO", tmpMap.getString("APPLICATION_NO"));

		oMap.put("RESPONSE_DATA", "");
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TFF_COMMON_GET_KDH_AVAILABILITY")
	public static GMMap getKdhAvailabilityForMember(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (StringUtils.isBlank(iMap.getString("TC_KIMLIK_NO"))) {
			oMap.put("KDH_AVAILABILITY", "H");
			oMap.put("RESPONSE_DATA", "");
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			return oMap;
		}
		oMap = GMServiceExecuter.call("BNSPR_MUSTERI_AKTIF_KDH_BASVURU_VARMI", iMap);
		if ("E".equals(oMap.getString("AKTIF_KDH_BASVURU_VARMI"))) {
			oMap.put("KDH_AVAILABILITY", "H");
			oMap.put("RESPONSE_DATA", "");
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			return oMap;
		}
		oMap = GMServiceExecuter.call("BNSPR_MUSTERI_AKTIF_KDH_VARMI", iMap);
		if ("E".equals(oMap.getString("AKTIF_KDH_VARMI"))) {
			oMap.put("KDH_AVAILABILITY", "H");
			oMap.put("RESPONSE_DATA", "");
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
			return oMap;
		}
		oMap.put("KDH_AVAILABILITY", "E");
		oMap.put("RESPONSE_DATA", "");
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_SERVICE_LOG")
	public static GMMap logService(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			TffServiceLog serviceLog = new TffServiceLog();
			serviceLog.setOid(iMap.getString("OID"));
			serviceLog.setUyruk(iMap.getString("UYRUK"));
			serviceLog.setTckn(iMap.getString("TCKN"));
			serviceLog.setPasaportNo(iMap.getString("PASAPORT"));
			serviceLog.setUyeNo(iMap.getString("UYE_NO"));
			serviceLog.setBasvuruNo(iMap.getString("BASVURU_NO"));
			serviceLog.setSource(iMap.getString("SOURCE"));
			serviceLog.setBeginDate(new Timestamp(iMap.getLong("BEGIN_DATE")));
			serviceLog.setEndDate(new Timestamp(iMap.getLong("END_DATE")));
			serviceLog.setRequest(Hibernate.createClob(iMap.getString("REQUEST")));
			serviceLog.setResponse(Hibernate.createClob(iMap.getString("RESPONSE")));
			serviceLog.setCoreSessionId(iMap.getString("CORE_SESSION_ID"));
			serviceLog.setCoreTrxId(iMap.getString("CORE_TRX_ID_RESERVED"));
			serviceLog.setClientIp(iMap.getString("CLIENT_IP"));
			serviceLog.setClientSessionId(iMap.getString("CLIENT_SESSION_ID"));
			serviceLog.setDuration(new BigDecimal(iMap.getLong("END_DATE") - iMap.getLong("BEGIN_DATE")));
			serviceLog.setIsError(iMap.getBigDecimal("IS_ERROR"));
			serviceLog.setServiceName(iMap.getString("SERVIS_ADI"));
			session.save(serviceLog);
			session.flush();

		}
		catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", TffServicesMessages.TFF_BASVURU_ISLEM_KAYIT_GENEL_HATA);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_ADD_KDH_VALIDATION")
	public static GMMap addKdhValidation(GMMap iMap) {
		GMMap oMap = new GMMap();

		String aylikGelir = iMap.getString("AYLIK_GELIR");
		String ekstreSecim = iMap.getString("DESTEK_HESAP_EKSTRE_SECIMI");
		String emailEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_EMAIL");
		String postaEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_POSTA");
		String otoLimit = iMap.getString("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI");
		String kkOtomatikOdeme = iMap.getString("DESTEK_HESAP_KK_OTOMATIK_ODEME", "H");
		String bkOtomatikOdeme = iMap.getString("DESTEK_HESAP_BK_OTOMATIK_ODEME", "H");
		String sigOtomatikOdeme = iMap.getString("DESTEK_HESAP_SIG_OTOMATIK_ODEME", "H");
		String ootOtomatikOdeme = iMap.getString("DESTEK_HESAP_OOT_OTOMATIK_ODEME", "H");
		String dotOtomatikOdeme = iMap.getString("DESTEK_HESAP_DOT_OTOMATIK_ODEME", "H");
		BigDecimal basvuruNo = iMap.getBigDecimal("TFF_BASVURU_NO");

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);

		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		if ("P".equals(iMap.getString("KART_TIPI"))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_KART_TIPI_UYGUN_DEGIL);
			return oMap;
		}
		if (StringUtils.isBlank(aylikGelir)) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_AYLIK_GELIR_BOS_OLAMAZ);
			return oMap;
		}
		BigDecimal gelir = new BigDecimal(aylikGelir);
		if (gelir.compareTo(new BigDecimal("100")) < 0) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.AYLIK_GELIR_100_DEN_BUYUK_OLMALI);
			return oMap;
		}
		if ((StringUtils.isBlank(emailEktre) && StringUtils.isBlank(postaEktre)) || (("H".equals(emailEktre) && "H".equals(postaEktre)))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_TIPI_BOS_OLAMAZ);
			return oMap;
		}
		if (StringUtils.isNotBlank(emailEktre) && "E".equals(emailEktre)) {
			if (!isEmailValid(tffBasvuru.getEPosta())) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_EPOSTA_ICIN_EMAIL_BOS_OLAMAZ);
				return oMap;
			}
		}

		if (StringUtils.isNotBlank(postaEktre) && "E".equals(postaEktre) && (StringUtils.isBlank(ekstreSecim) || (!"E".equals(ekstreSecim) && !"I".equals(ekstreSecim)))) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_POSTA_ICIN_SECIM_BOS_OLAMAZ);
			return oMap;
		}
		if ("E".equals(postaEktre)) {

			TffBasvuruAdres tffBasvuruAdres = (TffBasvuruAdres) session.createCriteria(TffBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).add(Restrictions.eq("id.adresKod", ekstreSecim)).uniqueResult();
			if (tffBasvuruAdres == null) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.DESTEK_HESAP_EKSTRE_POSTA_ICIN_SECIM_BOS_OLAMAZ);
				return oMap;
			}
		}

		return oMap;

	}

	/**
	 * TFF_BASVURU_NO
	 * AYLIK_GELIR
	 * DESTEK_HESAP_EKSTRE_SECIMI
	 * DESTEK_HESAP_EKSTRE_TIPI_EMAIL
	 * DESTEK_HESAP_EKSTRE_TIPI_POSTA
	 * DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI
	 * DESTEK_HESAP_KK_OTOMATIK_ODEME
	 * DESTEK_HESAP_BK_OTOMATIK_ODEME
	 * DESTEK_HESAP_SIG_OTOMATIK_ODEME
	 * DESTEK_HESAP_OOT_OTOMATIK_ODEME
	 * DESTEK_HESAP_DOT_OTOMATIK_ODEME
	 * 
	 * */
	@GraymoundService("BNSPR_TFF_COMMON_ADD_KDH")
	public static GMMap addKdh(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			oMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_ADD_KDH_VALIDATION", iMap);
			if (!"2".equals(oMap.getString("RESPONSE"))) {
				return oMap;
			}

			GMMap trxMap = new GMMap();
			if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {

				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			}

			BigDecimal basvuruNo = iMap.getBigDecimal("TFF_BASVURU_NO");

			String ekstreSecim = iMap.getString("DESTEK_HESAP_EKSTRE_SECIMI");
			String emailEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_EMAIL");
			String postaEktre = iMap.getString("DESTEK_HESAP_EKSTRE_TIPI_POSTA");
			String otoLimit = iMap.getString("DESTEK_HESAP_OTOMATIK_LIMIT_ARTISI", "H");
			String kkOtomatikOdeme = iMap.getString("DESTEK_HESAP_KK_OTOMATIK_ODEME", "H");
			String bkOtomatikOdeme = iMap.getString("DESTEK_HESAP_BK_OTOMATIK_ODEME", "H");
			String sigOtomatikOdeme = iMap.getString("DESTEK_HESAP_SIG_OTOMATIK_ODEME", "H");
			String ootOtomatikOdeme = iMap.getString("DESTEK_HESAP_OOT_OTOMATIK_ODEME", "H");
			String dotOtomatikOdeme = iMap.getString("DESTEK_HESAP_DOT_OTOMATIK_ODEME", "H");
			TffBasvuruKdhTx kdhtx = new TffBasvuruKdhTx();
			kdhtx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kdhtx.setBasvuruNo(basvuruNo);
			kdhtx.setEkstreTipiEmail(emailEktre);
			kdhtx.setEkstreTipiPosta(postaEktre);
			kdhtx.setEkstreSecimi(ekstreSecim);
			kdhtx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));

			kdhtx.setOtomatikLimitArtisi(otoLimit);
			kdhtx.setKkOtomatikOdeme(kkOtomatikOdeme);
			kdhtx.setBkOtomatikOdeme(bkOtomatikOdeme);
			kdhtx.setSigOtomatikOdeme(sigOtomatikOdeme);
			kdhtx.setOotOtomatikOdeme(ootOtomatikOdeme);
			kdhtx.setDotOtomatikOdeme(dotOtomatikOdeme);

			session.save(kdhtx);
			session.flush();

			iMap.put("TRX_NAME", "3801");
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));

			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, basvuruNo);
			session.refresh(tffBasvuru);
			tffBasvuru.setKdhIstiyorMu("E");
			if ("KK".equals(tffBasvuru.getKartTipi())) {
				TffKrediKartiBasvuru tffKKBasvuru = (TffKrediKartiBasvuru) session.createCriteria(TffKrediKartiBasvuru.class).add(Restrictions.eq("basvuruNo", tffBasvuru.getBasvuruNo())).uniqueResult();
				if (tffKKBasvuru != null) {
					KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", tffKKBasvuru.getKkBasvuruNo())).uniqueResult();
					if (kkBasvuru != null) {
						kkBasvuru.setKdhIstiyorMu("E");
						session.save(kkBasvuru);
						session.flush();
					}
				}
			}
			session.save(tffBasvuru);
			session.flush();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OLUSTUR_GENEL_HATA);
			return oMap;
		}

		return oMap;
	}

	/**
	 * Tff karaliste kontrol servisi kimlik bilgileri ile GNL_KARA_LISTE_GERCEK uzerinden kontrol eder.
	 * 
	 * @param TCKN
	 * @param PASAPORT_NO
	 * 
	 * */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TFF_KARALISTE_KONTROL")
	public static GMMap karaListeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		try {
			String func = "{? = call pkg_trn3801.GNL_KARALISTE_KONTROL(?,?,?,?,?,?)}";

			BigDecimal res = new BigDecimal(String.valueOf(DALUtil.callOracleFunction(func, BnsprType.NUMBER, BnsprType.STRING, iMap.getString("UYRUK"), BnsprType.STRING, iMap.getString("PASAPORT_NO"), BnsprType.NUMBER, iMap.getBigDecimal("TCKN"), BnsprType.STRING, iMap.getString("AD"), BnsprType.STRING, iMap.getString("SOYAD"), BnsprType.STRING, iMap.getString("DOGUM_TARIHI"))));

			if (res.compareTo(BigDecimal.ZERO) > 0) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.YASAKLI_KIMLIK_BILGISI);

			}

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.YASAKLI_KIMLIK_BILGISI);

		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_VIZE_ISLEM")
	public static GMMap vizeIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		try {
			GMMap trxMap = new GMMap();
			if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {

				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				iMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			}
			TffBasvuruVizeTx vize = new TffBasvuruVizeTx();
			vize.setTxNo(iMap.getBigDecimal("TRX_NO"));
			vize.setServiceName(iMap.getString("SERVICE_NAME"));
			vize.setCardNo(iMap.getBigDecimal("CARD_NO"));
			vize.setChannelTxNo(iMap.getBigDecimal("CHANNEL_TX_NO"));
			vize.setCustomerNo(iMap.getBigDecimal("CUSTOMER_NO"));
			vize.setPaymentAccountNo(iMap.getString("PAYMENT_ACCOUNT_NO"));
			vize.setPaymentAmount(iMap.getBigDecimal("PAYMENT_AMOUNT"));
			vize.setPaymentCardNo(iMap.getBigDecimal("PAYMENT_CARD_NO"));
			vize.setVisaFeePaymentType(iMap.getString("VISA_FEE_PAYMENT_TYPE"));
			vize.setPaymentUserName(iMap.getString("PAYMENT_USER_NAME"));
			vize.setPaymentUserTcNo(iMap.getBigDecimal("PAYMENT_USER_TC_NO"));
			vize.setTxnTrm(iMap.getString("TXN_TRM"));
			vize.setVisaFeeTxnType(iMap.getString("VISA_FEE_TXN_TYPE"));
			vize.setVisaEndDate(iMap.getDate("VISA_END_DATE"));
			vize.setVisaOrderId(iMap.getString("VISA_ORDER_ID"));
			vize.setVisaStartDate(iMap.getDate("VISA_START_DATE"));
			vize.setVisaTxnGuid(iMap.getString("VISA_TXN_GUID"));
			vize.setVisaRrn(iMap.getString("VISA_RRN"));
			session.saveOrUpdate(vize);
			session.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.VIZE_ODEME_HATASI);

		}

		return oMap;
	}

	/**
	 * DESC : Ehaciz servisleri tarafindan cagrilir
	 *
	 * @param iMap
	 *            (GMMap)
	 *            MUSTERI_NO
	 *
	 * @return oMap (GMMap)
	 *         VALUE(true/false)
	 *
	 */
	@GraymoundService("BNSPR_TFF_EHCZ_KART_BASVURU_VARMI")
	public static GMMap kartBasvuruVarmiEhaciz(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			boolean olumluKartBasvuruVarmi = false;

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			List<?> tffBasvurular = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.in("durumKod", new String[] { "ACIK", "BASIM" })).add(Restrictions.in("kartTipi", new String[] { "P", "KK" })).list();

			if (tffBasvurular.size() > 0)
				olumluKartBasvuruVarmi = true;

			oMap.put("VALUE", olumluKartBasvuruVarmi);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Verilen bilgilere ait bir urun varsa, id bilgisini doner.<br>
	 * 
	 * @author murat.el
	 * @since TY-4768
	 * @param iMap
	 *            - Basvuru bilgileri<br>
	 *            <li>KART_TIPI - Tff basvuru kart tipi <li>URUN_KOD - Tff basvuru urun tipi <li>URUN_SAHIP_KOD - Tff basvuru takim kodu <li>DOGUM_TARIHI - Tff basvuran dogum tarihi
	 * @return oMap - Urun bilgisi<br>
	 *         <li>URUN_ID - Urune ait ID bilgisi
	 */
	@GraymoundService("BNSPR_TFF_GET_URUN_ID")
	public static GMMap getUrunId(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal urunId = null;

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.getUrunId(?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("KART_TIPI"));
			stmt.setString(3, iMap.getString("URUN_KOD"));
			stmt.setString(4, iMap.getString("URUN_SAHIP_KOD"));

			if (iMap.get("DOGUM_TARIHI") != null) {
				stmt.setDate(4, new java.sql.Date(iMap.getDate("DOGUM_TARIHI").getTime()));
			}
			else {
				stmt.setDate(4, null);
			}

			stmt.execute();
			urunId = stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("URUN_ID", urunId);
		return oMap;
	}

	@GraymoundService("BNSPR_TFF_BASVURU_IPTAL_BY_KANAL")
	public static GMMap tffBasvuruIptalByKanal(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (!"EPOS".equals(iMap.getString("SOURCE")) && !"NTS01".equals(iMap.getString("SOURCE")) && !"NTS02".equals(iMap.getString("SOURCE"))) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", "Gecersiz kanal tipi");
			return oMap;
		}

		oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_IPTAL", iMap));

		if (TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("TFF_BASVURU_NO"));
			if (tffBasvuru != null) {
				String iptalYeriBilgi = "";
				if (!StringUtils.isEmpty(iMap.getString("STAD"))) {
					iptalYeriBilgi += iMap.getString("STAD") + "-";
				}
				if (!StringUtils.isEmpty(iMap.getString("GISE_ID"))) {
					iptalYeriBilgi += iMap.getString("GISE_ID") + "-";
				}
				if (!StringUtils.isEmpty(iMap.getString("GISE_USER"))) {
					iptalYeriBilgi += iMap.getString("GISE_USER");
				}

				if (!StringUtils.isEmpty(iptalYeriBilgi)) {
					iptalYeriBilgi = iptalYeriBilgi.replaceAll("-$", "");
					tffBasvuru.setIptalYeriBilgi(iptalYeriBilgi);
					session.saveOrUpdate(tffBasvuru);
				}

				session.flush();
			}
		}

		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			GMMap responseDataInpMap = new GMMap();
			responseDataInpMap.put("SOURCE", iMap.getString("SOURCE"));
			responseDataInpMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
			GMMap responseDataMap = new GMMap();
			responseDataMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_CONVERT_RESPONSE_DATA_BY_SOURCE", responseDataInpMap));
			if (!StringUtils.isEmpty(responseDataMap.getString("RESPONSE_DATA"))) {
				oMap.put("RESPONSE_DATA", responseDataMap.getString("RESPONSE_DATA"));
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TFF_COMMON_GET_APPLICATION_SUMMARY_INFO_BY_KANAL")
	public static GMMap getApplicationSummaryInfoByKanal(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (!isSourceValid(iMap)) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "Gecersiz kanal tipi");
			return oMap;
		}
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_GET_APPLICATION_SUMMARY_INFO", iMap));
		if (TffServicesMessages.RESPONSE_BASARISIZ.equals(oMap.getString("RESPONSE"))) {
			GMMap responseDataInpMap = new GMMap();
			responseDataInpMap.put("SOURCE", iMap.getString("SOURCE"));
			responseDataInpMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
			GMMap responseDataMap = new GMMap();
			responseDataMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_CONVERT_RESPONSE_DATA_BY_SOURCE", responseDataInpMap));
			if (!StringUtils.isEmpty(responseDataMap.getString("RESPONSE_DATA"))) {
				oMap.put("RESPONSE_DATA", responseDataMap.getString("RESPONSE_DATA"));
			}
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_CHECK_PHONE_FOR_PASSOLIG_APPLICATION")
	public static GMMap checkPhoneForPassolig(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			String ulkeKodu = iMap.getString("ULKE_KOD");
			String alanKodu = iMap.getString("ALAN_KOD");
			String telNo = iMap.getString("TEL_NO");
			String tckn = iMap.getString("TCKN");

			List<GnlMusteriTelefon> telefonList = null;
			List<?> list3 = null;
			List<?> list4 = null;
			if (!StringUtils.isEmpty(telNo) && !StringUtils.isEmpty(ulkeKodu) && !StringUtils.isEmpty(alanKodu)) {

				telefonList = session.createCriteria(GnlMusteriTelefon.class)
						.add(Restrictions.eq("ulkeKod", ulkeKodu)).add(Restrictions.eq("telNo", telNo))
						.add(Restrictions.eq("alanKod", alanKodu))
						.add(Restrictions.eq("otpMi", "E")).list();
			}
			else {
				if (musteriNo == null) {
					if (StringUtils.isEmpty(tckn)) {
						oMap.put("RESPONSE", "01");
						oMap.put("RESPONSE_DATA", "TCKN bilgisi bulunamad�.");
						return oMap;
					}

					musteriNo = new BigDecimal(BnsprOceanCommonFunctions.getCustomerNo(tckn, null, null));
					logger.info("musteriNo --> " + musteriNo);

				}
				GnlMusteriTelefon girisYapanMusteri =(GnlMusteriTelefon) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("id.musteriNo", musteriNo))
						.add(Restrictions.eq("otpMi", "E")).uniqueResult();

				telefonList = session.createCriteria(GnlMusteriTelefon.class)
						.add(Restrictions.eq("ulkeKod", girisYapanMusteri.getUlkeKod())).add(Restrictions.eq("telNo", girisYapanMusteri.getTelNo()))
						.add(Restrictions.eq("alanKod", girisYapanMusteri.getAlanKod()))
						.add(Restrictions.eq("otpMi", "E")).list(); 

				
			}
			if (telefonList.size() > 0) {
				for (int t = 0; t < telefonList.size(); t++) {
					GnlMusteriTelefon gnlMusteriTelefon =  telefonList.get(t);

//					ulkeKodu = gnlMusteriTelefon.getUlkeKod();
//					alanKodu = gnlMusteriTelefon.getAlanKod();
//					telNo = gnlMusteriTelefon.getTelNo();
				
                    BigDecimal musteriNo2= gnlMusteriTelefon.getId().getMusteriNo();
					logger.info("musteriNo2 --> " + musteriNo2);

						// girilen telefon ile kk var ise, kart�n durumuna bak
						list3 = session.createCriteria(TffBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo2))

						.add((Restrictions.in("durumKod", YARIM_KALAN_BASVURU_DURUM_KOD))).add(Restrictions.eq("kartTipi", "KK")).list();

						logger.info("list3.size() --> " + list3.size());
						if (list3.size() > 0) {
							oMap.put("RESPONSE", BASKA_KK_MUSTERISI_VAR_HATASI);
							oMap.put("RESPONSE_DATA", "Bu telefon numaras�yla ba�ka kredi kart� m��terisi var.");
							return oMap;
						}
						//a��k ya da bas�mda kart� varsa
						list4 =session.createCriteria(TffBasvuru.class).add(Restrictions.eq("musteriNo", musteriNo2))
								.add(Restrictions.in("durumKod", ACIK_BASIM_DURUM_KOD)).add(Restrictions.eq("kartTipi", "KK")).list();

						if (list3.size() == 0 || list4.size()>0) {
							logger.info("list4.size() --> " + list4.size());

							// for(int k=0; k<list3.size(); k++){
							// TffBasvuru tffBasvuru = (TffBasvuru)list3.get(k);
							// logger.info("tffBasvuru musteriNo --> " +tffBasvuru.getMusteriNo());
							GMMap inputMap = new GMMap();
							inputMap.put("CUSTOMER_NO", musteriNo2);
							inputMap.put("SEGMENT", "TFF");
							inputMap.put("DCI", "C");
							GMMap cardMap = new GMMap();
							cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", inputMap);
							if(cardMap.getSize("CARD_DETAIL_INFO") >0){
							for (int i = 0; i < cardMap.getSize("CARD_DETAIL_INFO"); i++) {
								
								logger.info("CARD_STAT_CODE --> " + cardMap.get("CARD_DETAIL_INFO", i, "CARD_STAT_CODE"));
								logger.info("CARD_SUB_STAT_CODE --> " + cardMap.get("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE"));

								// var olan m��terinin KK's� a��ksa, kuryedeyse ya da bas�mdaysa
								if ("G".equals(cardMap.get("CARD_DETAIL_INFO", i, "CARD_STAT_CODE")) && "J".equals(cardMap.get("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE")) || "N".equals(cardMap.get("CARD_DETAIL_INFO", i, "CARD_STAT_CODE")) && "N".equals(cardMap.get("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE")) || "B".equals(cardMap.get("CARD_DETAIL_INFO", i, "CARD_SUB_STAT_CODE"))) {

									oMap.put("RESPONSE", BASKA_KK_MUSTERISI_VAR_HATASI);
									oMap.put("RESPONSE_DATA", "Bu telefon numaras�yla ba�ka kredi kart� m��terisi var.");
									return oMap;

								}
								else {
									oMap.put("RESPONSE", "2");
									oMap.put("RESPONSE_DATA", "Bu telefon numaras�yla ba�ka kredi kart� m��terisi bulunmamaktad�r.");
									
								}
							}
							}else{
								oMap.put("RESPONSE", "2");
								oMap.put("RESPONSE_DATA", "Bu telefon numaras�yla ba�ka kredi kart� m��terisi bulunmamaktad�r.");
								
							}
						}

				
				
				}

			}
			else {
				oMap.put("RESPONSE", "2");
				oMap.put("RESPONSE_DATA", "Bu telefon numaras�yla ba�ka kredi kart� m��terisi bulunmamaktad�r.");
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

		return oMap;

	}
	private static final List<String> YARIM_KALAN_BASVURU_DURUM_KOD;
	static {
		YARIM_KALAN_BASVURU_DURUM_KOD = new ArrayList<String>();
		YARIM_KALAN_BASVURU_DURUM_KOD.add("FOTO");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("FOTO_EKSIK");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("FOTO_EKSIK_ONAY");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("ODEME");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("ODEME_BEKLE");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("ON_BASVURU");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("KREDI_KARTI");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("VERI_KONTROL");
		YARIM_KALAN_BASVURU_DURUM_KOD.add("VERI_TAMAMLAMA");

	}
	private static final List<String> ACIK_BASIM_DURUM_KOD;
	static {
		ACIK_BASIM_DURUM_KOD = new ArrayList<String>();
		ACIK_BASIM_DURUM_KOD.add("ACIK");
		ACIK_BASIM_DURUM_KOD.add("BASIM");
		

	}

	@GraymoundService("BNSPR_TFF_COMMON_GET_APPLICATION_SUMMARY_INFO")
	public static GMMap getApplicationSummaryInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		String RESULT_TABLE = "RESULT_TABLE";
		String APPLICATION_SUMMARY_INFO = "APPLICATION_SUMMARY_INFO";
		String basimAcikIptalMi = iMap.getString("BASIM_ACIK_IPTAL_MI", CreditCardServicesUtil.HAYIR);

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String query = null;
		try {

			conn = DALUtil.getGMConnection();
			query = "{call PKG_TFF_BASVURU.listBasvuruOzetBilgi(?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);

			stmt.setString(1, iMap.getString("TCKN"));
			stmt.setString(2, iMap.getString("PASSPORT_NO"));
			stmt.setString(3, iMap.getString("APPLICATION_NO"));
			stmt.setString(4, iMap.getString("APPLICATION_START_DATE"));
			stmt.setString(5, iMap.getString("APPLICATION_END_DATE"));
			stmt.registerOutParameter(6, -10);
			stmt.registerOutParameter(7, Types.CHAR);
			stmt.registerOutParameter(8, Types.CHAR);
			stmt.registerOutParameter(9, Types.CHAR);
			stmt.registerOutParameter(10, Types.CHAR);
			stmt.registerOutParameter(11, Types.CHAR);

			stmt.execute();
			String ad = stmt.getString(9);

			if (StringUtils.isEmpty(ad)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OZET_BILGI_KAYIT_BULUNAMADI);
				return oMap;
			}
			rSet = (ResultSet) stmt.getObject(6);
			GMMap resultMap = DALUtil.rSetResults(rSet, RESULT_TABLE);

			if (resultMap == null || resultMap.isEmpty() || resultMap.getSize(RESULT_TABLE) == 0) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.BASVURU_OZET_BILGI_KAYIT_BULUNAMADI);
				return oMap;
			}

			oMap.put("TCKN", stmt.getString(7));
			oMap.put("PASSPORT_NO", stmt.getString(8));
			oMap.put("AD", ad);
			oMap.put("IKINCI_AD", stmt.getString(10));
			oMap.put("SOYAD", stmt.getString(11));

			for (int i = 0; i < resultMap.getSize(RESULT_TABLE); i++) {
				String kartNo = resultMap.getString(RESULT_TABLE, i, "KART_NO");
				String kuryeTipi = resultMap.getString(RESULT_TABLE, i, "KURYE_TIPI");
				String durumKod = resultMap.getString(RESULT_TABLE, i, "DURUM_KOD");
				String source = resultMap.getString(RESULT_TABLE, i, "SOURCE");

				oMap.put(APPLICATION_SUMMARY_INFO, i, "APPLICATION_NO", resultMap.getBigDecimal(RESULT_TABLE, i, "BASVURU_NO"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "APPLICATION_STATUS", durumKod);
				oMap.put(APPLICATION_SUMMARY_INFO, i, "PRODUCT_ID", resultMap.getString(RESULT_TABLE, i, "KART_URUN_ID"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "LOGO_CODE", resultMap.getString(RESULT_TABLE, i, "LOGO_KODU"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "CARD_DCI", getCardDciByKartTipi(resultMap.getString(RESULT_TABLE, i, "KART_TIPI")));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "APPLICATION_DATE", resultMap.getString(RESULT_TABLE, i, "BASVURU_TARIH"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "USER_CODE", resultMap.getString(RESULT_TABLE, i, "GISE_USER"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "TERMINAL_ID", resultMap.getString(RESULT_TABLE, i, "GISE_ID"));
				oMap.put(APPLICATION_SUMMARY_INFO, i, "SOURCE", source);

				boolean isReversible = basvuruIptalEdilebilirMi(durumKod, kuryeTipi, kartNo, source, basimAcikIptalMi);
				oMap.put(APPLICATION_SUMMARY_INFO, i, "IS_REVERSIBLE", isReversible);
				if (!isReversible) {
					GMMap messageMap = new GMMap();
					messageMap.put("MESSAGE_NO", 50008);
					messageMap.put("P1", resultMap.getString(RESULT_TABLE, i, "DURUM_KOD_TEXT"));
					String reasonDef = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE");
					oMap.put(APPLICATION_SUMMARY_INFO, i, "IRREVERSIBLE_REASON", reasonDef);
				}
			}

			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

		return oMap;
	}

	private static String getCardDciByKartTipi(String kartTipi) {

		if ("D".equals(kartTipi)) {
			return OceanConstants.Akustik_DebitCard;
		}

		else if ("P".equals(kartTipi)) {
			return OceanConstants.Akustik_PrepaidCard;
		}

		else if ("KK".equals(kartTipi)) {
			return OceanConstants.Akustik_CreditCard;
		}
		else {
			return kartTipi;
		}
	}

	private static boolean basvuruIptalEdilebilirMi(TffBasvuru basvuru, String basimAcikIptalMi) {
		return basvuruIptalEdilebilirMi(basvuru.getDurumKod(), basvuru.getKuryeTipi(), basvuru.getKartNo(), basvuru.getSource(), basimAcikIptalMi);
	}

	private static boolean basvuruIptalEdilebilirMi(String durumKod, String kuryeTipi, String kartNo, String source, String basimAcikIptalMi) {
		boolean iptalEdilebilir = true;
		if (!"BASVURU".equals(durumKod) && !"FOTO".equals(durumKod) && !"ODEME".equals(durumKod) && !"ODEME_BEKLE".equals(durumKod) && !"ODEME_BASARISIZ".equals(durumKod)) {
			if ("BASIM".equals(durumKod)) {
				if (CreditCardServicesUtil.HAYIR.equals(basimAcikIptalMi)) {
					if (!("NTS01".equals(source) && "A".equals(kuryeTipi))) {
						iptalEdilebilir = false;
					}

				}
			}
			else if ("ACIK".equals(durumKod)) {
				if (CreditCardServicesUtil.HAYIR.equals(basimAcikIptalMi)) {
					iptalEdilebilir = false;
				}

			}
			else {
				iptalEdilebilir = false;
			}

		}

		return iptalEdilebilir;
	}

	@GraymoundService("BNSPR_TFF_COMMON_CONVERT_RESPONSE_DATA_BY_SOURCE")
	public static GMMap convertResponseDataBySource(GMMap iMap) {

		String messageCode = null;
		String source = iMap.getString("SOURCE");

		GMMap oMap = new GMMap();
		if (!StringUtils.isEmpty(source) && !StringUtils.isEmpty(iMap.getString("RESPONSE_DATA"))) {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			Criteria criteria = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "TFF_SERVIS_SONUC_MESAJ")).add(Restrictions.eq("key1", source)).add(Restrictions.eq("key2", iMap.getString("RESPONSE_DATA")));
			GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
			if (gnlParamText != null && !StringUtils.isEmpty(gnlParamText.getKey3())) {
				messageCode = gnlParamText.getKey3();
			}
			session.flush();

		}

		if (!StringUtils.isEmpty(messageCode)) {
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", messageCode);
			String messageText = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE");
			if (!StringUtils.isEmpty(messageText)) {
				oMap.put("RESPONSE_DATA", messageText);
			}

		}

		return oMap;

	}

	@GraymoundService("BNSPR_TFF_UPDATE_CUSTOMER_RECORDS_FOR_CRM")
	public static GMMap crmUpdateCustomerRecords(GMMap cMap) {

		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		try {

			String func = "{? = call PKG_TFF_CRM_UPDATE.updateCustomerRecords(?)}";

			BigDecimal res = new BigDecimal(String.valueOf(DALUtil.callOracleFunction(func, BnsprType.NUMBER, BnsprType.NUMBER, cMap.getBigDecimal("MUSTERI_NO"))));

			if (res.compareTo(BigDecimal.ZERO) > 0) {
				oMap.put("RESPONSE_DATA", "Update Edilen Kay�t Say�s�:" + res);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());

		}
		return oMap;

	}

	@GraymoundService("BNSPR_TFF_COMMON_UPDATE_APPLICATION")
	public static GMMap updateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);

			BigDecimal trxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO").toString());

			iMap.put("ISLEM_FLAG", "G");
			iMap.put("ILETISIM_TIPI", iMap.getString("ILETISIM_ADRES_TIPI"));
			iMap.put("CEP_NUMARA", iMap.getString("CEP_TEL_NO"));
			iMap.put("CEP_ALAN_KOD", iMap.getString("CEP_TEL_KOD"));
			iMap.put("EV_NUMARA", iMap.getString("EV_TEL_NO"));
			iMap.put("EV_ALAN_KOD", iMap.getString("EV_TEL_KOD"));
			iMap.put("IS_NUMARA", iMap.getString("IS_TEL_NO"));
			iMap.put("IS_ALAN_KOD", iMap.getString("IS_TEL_KOD"));
			iMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3801_SAVE_OR_UPDATE", iMap));

			GMMap sorguMap = new GMMap();
			sorguMap.put("TRX_NAME", "3801");
			sorguMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", sorguMap));

			// Musteri Bilgilerini Guncelle
			sorguMap.clear();
			sorguMap.put("TFF_BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
			sorguMap.put("SOURCE", "TFF");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", sorguMap));

		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());

		}
		return oMap;

	}
	
	@GraymoundService("BNSPR_GET_FAIZ_ORANLARI")
	public static GMMap getKartFaizOranlari(GMMap iMap){
		   GMMap oMap= new GMMap();
		   Session session = DAOSession.getSession("BNSPRDal");
		   try {
			   
			   List<GnlParamText> faizOranList = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "KART_FAIZ_ORANLARI")).addOrder(Order.asc("siraNo")).list();
			   for (int row = 0; row < faizOranList.size(); row++) {
				   GnlParamText gnlParamText = (GnlParamText) faizOranList.get(row);
				   oMap.put("KART_FAIZ_LIST", row, "FAIZ_TIPI", gnlParamText.getKey1());
				   oMap.put("KART_FAIZ_LIST", row, "FAIZ_ORANI", gnlParamText.getText());
			   }
				oMap.put("RESPONSE", "2");

		} catch (Exception e) {
			oMap.put("RETURN_CODE", "0");
			oMap.put("RETURN_DESC", e.getMessage());		
			}
		   
		   return oMap;
	}
	
	@GraymoundService("BNSPR_GET_KURYE_UCRETLERI")
	public static GMMap getKuryeUcretleri(GMMap iMap){
		GMMap oMap= new GMMap();
		try {  
			String kanalKod =iMap.getString("KANAL_KOD");
			List<?> list = null;

			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			list =  session.createCriteria(KartKuryeUcretPr.class).add(Restrictions.eq("kanalKod", kanalKod)).list();
			for (int i = 0; i < list.size(); i++){
				
				KartKuryeUcretPr ucret= (KartKuryeUcretPr) list.get(i);
				oMap.put("KART_KURYE_LIST", i, "KART_TIPI", ucret.getKartTipi());
				oMap.put("KART_KURYE_LIST", i, "UCRET", ucret.getUcret());
				//oMap.put("KART_KURYE_LIST", i, "FIRMA_ADI", ucret.getFirmaAdi());
				if("0".equals(ucret.getYerliYabanci())){
					oMap.put("KART_KURYE_LIST", i, "YERLI_YABANCI", "YERLI");
				} else if ("1".equals(ucret.getYerliYabanci())) {
					oMap.put("KART_KURYE_LIST", i, "YERLI_YABANCI", "YABANCI");
				} else {
					oMap.put("KART_KURYE_LIST", i, "YERLI_YABANCI", ucret.getYerliYabanci());
				}
				
			}
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
				
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", e.getMessage());
			}
		
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_GET_KURYE_UCRETLERI_FAIZ_ORANLARI")
	public static GMMap getKuryeUcretleriFaizOranlari(GMMap iMap){
		   GMMap oMap= new GMMap();
		   try {
			   oMap.putAll(GMServiceExecuter.call("BNSPR_GET_KURYE_UCRETLERI", iMap));
			   oMap.putAll(GMServiceExecuter.call("BNSPR_GET_FAIZ_ORANLARI", iMap));
				oMap.put("RESPONSE", "2");
		}
		catch (Exception e) {
			oMap.put("RETURN_CODE", "0");
			oMap.put("RETURN_DESC", e.getMessage());		
			}
		   
		   return oMap;
	}
	
	public static String getOtpCepTelNo(BigDecimal customerNo) {
		GMMap telMap = new GMMap();

		telMap.put("CUSTOMER_NO", customerNo);
		telMap.put("FORMAT", "UAT");
		telMap = GMServiceExecuter.call("BNSPR_GET_CUSTOMER_OTP", telMap);
		String phone = telMap.getString("PHONE_NUMBER");
		return phone;
	}
	public static String getGlobalParam(String kod) {
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", kod);
		iMapG.put("TRIM_QUOTES", true);
		String deger = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
		return deger;
	}

}
