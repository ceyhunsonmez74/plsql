package tr.com.aktifbank.bnspr.tff.services;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
/**
 * 
 * Bu class AktifNokta icin is kurallarinin isletildigi yerdir
 *  
 * Bu class icerisinde yer alan servisler dis sistemlerce cagrilan ve 
 * icerisinde is kurallarinin kontrol edildigi servisler olacakt�r 
 *
 * Gercek isleri yapan temel seviyede servisler TffCommonServices icerisinde yer almalidir
 *  
 * 
 */
public class TffAktifNoktaServices extends TffServicesHelper {
	private static final Logger logger = Logger.getLogger(TffServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties ("configuration/aktifbank-int-tff.properties");
	/*EVAM event type*/
	private static final String EVENT_TYPE_NO = "17";
	
	@GraymoundService("BNSPR_TFF_BUS_EPOS_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap basvuruMap =  new GMMap();
		//GMServiceExecuter.executeNT("BNSPR_TFF_BUS_CANCEL_PREVIOUS_APPLICATIONS", iMap);
		GMMap trxMap = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap());
		basvuruMap.put("TRX_NO",trxMap.getString("TRX_NO"));
		iMap.put("TRX_NO",trxMap.getString("TRX_NO"));
		GMMap basvuru = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", iMap);
		oMap.put("TFF_BASVURU_NO",basvuru.getString("TFF_BASVURU_NO"));
		oMap.put("EUPT_REF_ID",basvuru.getString("EUPT_REF_ID"));
		oMap.put("RESPONSE",basvuru.getString("RESPONSE"));
		oMap.put("RESPONSE_DATA",basvuru.getString("RESPONSE_DATA"));
		
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_TFF_BUS_CANCEL_PREVIOUS_APPLICATIONS")
	public static GMMap cancelPreviousApplications(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap basvuruMap =  new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		List <TffBasvuru> tffbasvuruList = (List<TffBasvuru>) session.createCriteria(TffBasvuru.class).add(Restrictions.eq("tffUyeNo",iMap.getBigDecimal("UYE_NO"))).add(Restrictions.eq("source","EPOS")).list();
		for(TffBasvuru b: tffbasvuruList)
		{
			String func = "{? = call Pkg_parametre.ParamTextDegerVarMi (?,?,?)}";
			String iptalEdilebilir ="H";
			try {
				 iptalEdilebilir = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "TFF_BASVURU_DURUM_KOD", BnsprType.STRING, b.getDurumKod(), BnsprType.STRING, "E"));
				 if("E".equals(iptalEdilebilir)){
					 GMMap tmpMap = new GMMap();
					 tmpMap.put("TFF_BASVURU_NO", b.getBasvuruNo());
					 tmpMap.put("SOURCE", b.getSource());
					 tmpMap.put("GEREKCE_KOD",2);
					 tmpMap.put("ACIKLAMA", "Yarim basvuru");
					 tmpMap.put("KK_BASVURU_IPTAL_MI", b.getKartTipi().equals("KK") ? "E":"H");
					 GMMap basvuru = GMServiceExecuter.call("BNSPR_TFF_BASVURU_IPTAL", tmpMap);
				 }
				
			}
			catch (Exception e) {
				logger.error("Iptal edilecek basvuru durumu sorgulanamadi");
				logger.error(e);
			}
		}
		oMap.put("RESPONSE","2");
		oMap.put("RESPONSE_DATA","");
		
		return oMap;
		
	}
}
