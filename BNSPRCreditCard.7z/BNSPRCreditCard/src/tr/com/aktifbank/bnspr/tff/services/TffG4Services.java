package tr.com.aktifbank.bnspr.tff.services;

import java.math.BigDecimal;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.aktifbank.bnspr.dao.TffSsProductMap;
import tr.com.aktifbank.bnspr.dao.TffUyeler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
/**
 * 
 * Bu class G4 icin is kurallarinin isletildigi yerdir
 *  
 * Bu class icerisinde yer alan servisler dis sistemlerce cagrilan ve 
 * icerisinde is kurallarinin kontrol edildigi servisler olacakt�r 
 *
 * Gercek isleri yapan temel seviyede servisler TffCommonServices icerisinde yer almalidir
 *  
 * 
 */
public class TffG4Services extends TffServicesHelper {
	private static final Logger logger = Logger.getLogger(TffServices.class);
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";
	protected static Configurator conf = Configurator.createConfiguratorFromProperties ("configuration/aktifbank-int-tff.properties");
	/*EVAM event type*/
	private static final String EVENT_TYPE_NO = "17";
	
	
	@GraymoundService("BNSPR_TFF_FIZIKI_BASVURU_YAP_V2")
	public static GMMap tffFizikiBasvuruYapV2(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			if(!isSourceValid(iMap)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.WEB_SERVIS_GECERSIZ_SOURCE);
				return oMap;
			}
			if(!iMap.containsKey("TELEFON_LISTE") || iMap.getSize("TELEFON_LISTE") == 0 ){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
				return oMap;
			}	
			for(int i = 0 ; i<iMap.getSize("TELEFON_LISTE");i++){
			
				if ( "C".equals(iMap.getString("TELEFON_LISTE",i,"TELEFON_TIP")) ){
					
					iMap.put("CEP_ULKE_KOD", iMap.getString("TELEFON_LISTE",i,"ULKE_KODU"));
					iMap.put("CEP_ALAN_KOD", iMap.getString("TELEFON_LISTE",i,"ALAN_KODU"));
					iMap.put("CEP_NUMARA", iMap.getString("TELEFON_LISTE",i,"NUMARA"));
					iMap.put("CEP_TEL_NO", iMap.getString("TELEFON_LISTE",i,"ULKE_KODU")+iMap.getString("TELEFON_LISTE",i,"ALAN_KODU")+iMap.getString("TELEFON_LISTE",i,"NUMARA"));
					if ("E".equals(iMap.getString("TELEFON_LISTE",i,"ILETISIM_MI"))){
						iMap.put("ILETISIM_TEL_TIP", "C");
					}
					
				
					
					String cepTelUlke = iMap.getString("CEP_ULKE_KOD");
					String cepTelAlan = iMap.getString("CEP_ALAN_KOD");
					String cepTelNumara = iMap.getString("CEP_NUMARA");
					
					if(!isPhoneNumberValidInternational(cepTelUlke, cepTelAlan, cepTelNumara)){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
						return oMap;
					}
				}
				else if( "I".equals(iMap.getString("TELEFON_LISTE",i,"TELEFON_TIP")) ){
					iMap.put("IS_ULKE_KOD", iMap.getString("TELEFON_LISTE",i,"ULKE_KODU"));
					iMap.put("IS_TEL_KOD", iMap.getString("TELEFON_LISTE",i,"ALAN_KODU"));
					iMap.put("IS_TEL_NO", iMap.getString("TELEFON_LISTE",i,"NUMARA"));
					iMap.put("IS_TEL_DAHILI", iMap.getString("TELEFON_LISTE",i,"DAHILI"));
					if ("E".equals(iMap.getString("TELEFON_LISTE",i,"ILETISIM_MI"))){
						iMap.put("ILETISIM_TEL_TIP", "I");
					}
					

					String isTelUlke = iMap.getString("IS_ULKE_KOD");
					String isTelAlan = iMap.getString("IS_TEL_KOD");
					String isTelNumara = iMap.getString("IS_TEL_NO");
					
					if(!isPhoneNumberValidInternational(isTelUlke, isTelAlan, isTelNumara)){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
						return oMap;
					}
				}
				else if( "E".equals(iMap.getString("TELEFON_LISTE",i,"TELEFON_TIP")) ){
					iMap.put("EV_ULKE_KOD", iMap.getString("TELEFON_LISTE",i,"ULKE_KODU"));
		    		iMap.put("EV_TEL_KOD", iMap.getString("TELEFON_LISTE",i,"ALAN_KODU"));
					iMap.put("EV_TEL_NO", iMap.getString("TELEFON_LISTE",i,"NUMARA"));
					if ("E".equals(iMap.getString("TELEFON_LISTE",i,"ILETISIM_MI"))){
						iMap.put("ILETISIM_TEL_TIP", "E");
					}
					
					String evTelUlke = iMap.getString("EV_ULKE_KOD");
					String evTelAlan = iMap.getString("EV_TEL_KOD");
					String evTelNumara = iMap.getString("EV_TEL_NO");
					
					if(!isPhoneNumberValidInternational(evTelUlke, evTelAlan, evTelNumara)){
						oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
						oMap.put("RESPONSE_DATA", TffServicesMessages.TEL_NO_HATALI_HATASI);
						return oMap;
					}
					
				}
			}
			
			
			oMap = GMServiceExecuter.call("BNSPR_TFF_FIZIKI_BASVURU_YAP", iMap);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", TffServicesMessages.FIZIKI_BASVURU_V2_GENEL_HATA);
			e.printStackTrace();
			return oMap;
			
		}
	
		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_FIZIKI_BASVURU_YAP")
	public static GMMap tffFizikiBasvuruYap(GMMap iMap){
		GMMap oMap = new GMMap();
		
		//TODO:SQL package yazilacak
		/*
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3801_UYE_AKTIF_BASVURULARI_IPTAL_ET", iMap));
		if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) )
			return oMap;
		*/
		
		StringTokenizer stringTokenizer = new StringTokenizer(iMap.getString("KULUP_URUN"),"-");
		iMap.put("URUN_SAHIP_KODU",stringTokenizer.nextToken());
		if ( stringTokenizer.hasMoreTokens())
			iMap.put("URUN_KODU",stringTokenizer.nextToken());
		 
		iMap.put("UYRUK", iMap.getString("UYRUK", iMap.getString("DIL")));
		oMap = tffFizikiBasvuruAlanKontrol(iMap);
		if ( !TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) ){
			return oMap;
		}
		GMMap uyeMap=new GMMap();
		uyeMap.put("TCKN", iMap.getString("TCKN"));
		uyeMap.put("PASAPORT_NO", iMap.getString("PASAPORT_NO"));
		uyeMap.put("UYRUK", iMap.getString("UYRUK",iMap.getString("DIL")));
		
		uyeMap.putAll(findUye(uyeMap));
		
		if(!uyeMap.containsKey("UYE_NO")) {
			uyeMap.put("UYRUK", iMap.getString("UYRUK"));
			uyeMap.put("TCKN", iMap.getString("TCKN"));
			uyeMap.put("KIMLIK_TIPI", iMap.getString("KIMLIK_TIPI"));
			uyeMap.put("KIMLIK_SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			uyeMap.put("KIMLIK_VERILIS_TARIHI", iMap.getString("NUFUS_VER_TAR"));
			uyeMap.put("TAKIM", iMap.getString("KULUP"));
			uyeMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			uyeMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			uyeMap.put("ILETISIM_TEL_TIP", iMap.getString("ILETISIM_TEL_TIP"));
			if ( iMap.get("CEP_NUMARA")!=null && StringUtils.isNotBlank(iMap.getString("CEP_NUMARA"))){
			
				uyeMap.put("CEP_ULKE_KOD", iMap.getString("CEP_ULKE_KOD"));
				uyeMap.put("CEP_ALAN_KOD", iMap.getString("CEP_ALAN_KOD"));
				uyeMap.put("CEP_NUMARA", iMap.getString("CEP_NUMARA"));
			}
			uyeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			uyeMap.put("WEB_ADI", iMap.getString("WEB_ADI"));
			uyeMap.put("WEB_SOYADI", iMap.getString("WEB_SOYADI"));
			uyeMap.put("WEB_IKINCI_ADI", iMap.getString("WEB_IKINCI_ADI"));
			uyeMap.put("WEB_DOGUM_TARIHI", iMap.getString("WEB_DOGUM_TARIHI"));
			uyeMap.put("EMAIL", iMap.getString("EMAIL"));
			uyeMap.put("SOURCE", iMap.getString("SOURCE"));
		 
			
			uyeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_MEMBER", uyeMap));
			if (!TffServicesMessages.RESPONSE_BASARILI.equals(uyeMap.getString("RESPONSE")))
				return uyeMap;
			
		}
		
		GMMap basvuruMap=new GMMap();
		String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
		basvuruMap.put("KANAL_KOD", kanalKodu);
		basvuruMap.put("GISE_ID", iMap.getString("GISE_ID",""));
		basvuruMap.put("GISE_USER", iMap.getString("GISE_USER",""));
		basvuruMap.put("ISYERI_ADI",iMap.getString("ISYERI_ADI"));
		basvuruMap.put("UYE_NO",uyeMap.getString("UYE_NO"));
		basvuruMap.put("KART_TIPI", iMap.getString("KART_TIPI"));
		basvuruMap.put("URUN_KODU", iMap.getString("URUN_KODU"));
		basvuruMap.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
		basvuruMap.put("EUPT_YARAT", "E");
		basvuruMap.put("EMAIL", iMap.getString("EMAIL"));
		basvuruMap.put("SOURCE", iMap.getString("SOURCE"));
		basvuruMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
		if(!isKuryeTipiValid(iMap)){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA",TffServicesMessages.GECERSIZ_KURYE_TIPI);
			return oMap;
		}
		basvuruMap.put("KURYE_TIPI", iMap.getString("KURYE_TIPI"));
		basvuruMap.put("ILETISIM_TEL_TIP", iMap.getString("ILETISIM_TEL_TIP"));
		basvuruMap.put("IS_ULKE_KOD", iMap.getString("IS_ULKE_KOD"));
		basvuruMap.put("IS_TEL_KOD", iMap.getString("IS_TEL_KOD"));
		basvuruMap.put("IS_TEL_NO", iMap.getString("IS_TEL_NO"));
		basvuruMap.put("IS_TEL_DAHILI", iMap.getString("IS_TEL_DAHILI"));
		basvuruMap.put("EV_ULKE_KOD", iMap.getString("EV_ULKE_KOD"));
		basvuruMap.put("EV_TEL_KOD", iMap.getString("EV_TEL_KOD"));
		basvuruMap.put("EV_TEL_NO", iMap.getString("EV_TEL_NO"));
		basvuruMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
		
		// vade yenileme ile y�nlendirilmi� yeni ba�vuru ise ba�vuruya iz kayd� at�yoruz
		if (StringUtils.isNotBlank(iMap.getString("VD_KAYNAK_BASVURU_NO"))){
			basvuruMap.put("VD_KAYNAK_BASVURU_NO", iMap.getString("VD_KAYNAK_BASVURU_NO"));
			basvuruMap.put("VD_BASVURU_MU", "E");
		}
		if (StringUtils.isNotBlank(iMap.getString("VD_BASVURU_NO"))){
			basvuruMap.put("VD_BASVURU_NO", iMap.getString("VD_BASVURU_NO"));
		}
		
		if( ("TN".equals(iMap.getString("KURYE_TIPI")) || "GN".equals(iMap.getString("KURYE_TIPI")))&& ("D".equals(iMap.getString("KART_TIPI")) || "KK".equals(iMap.getString("KART_TIPI")) )){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", "Sadece PrePaid kartlar teslimat noktas�dan teslim edilebilir. Kurye tipini kontrol ediniz.");
			return oMap;
		}
		
		GMMap tmpMap = new GMMap();
		tmpMap.clear();
		TffUyeler uye = findUye(iMap.getString("UYRUK"), StringUtils.isBlank(iMap.getString("TCKN")) ? null : iMap.getBigDecimal("TCKN"), iMap.getString("PASAPORT_NO"));
		iMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
		iMap.put("TCKN", uye.getTckn());
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap);
		if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE")) ){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", tmpMap.getString("RESPONSE_DATA"));
			return oMap;
		}
		tmpMap.clear();
		tmpMap.put("DIRECT_CALL", true);
		tmpMap.put("URUN_SAHIP_KODU", iMap.getString("URUN_SAHIP_KODU"));
		tmpMap.put("URUN_KODU", iMap.getString("URUN_KODU"));
		tmpMap.put("UYE_NO", uye.getUyeNo());
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", tmpMap);
		if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE")) ){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", tmpMap.getString("RESPONSE_DATA"));
			return oMap;
		}else{
			int su = tmpMap.getSize("KART_UYGUNLUK");
			for (int i =0 ; i < su; i++){
				String ktip = tmpMap.getString("KART_UYGUNLUK", i,"KART_TIPI");
				String uygunluk = tmpMap.getString("KART_UYGUNLUK", i,"UYGUNLUK");
				if(iMap.getString("KART_TIPI").equals(ktip) && "H".equals(uygunluk)){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					if("KK".equals(iMap.getString("KART_TIPI"))){
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
					}else if("D".equals(iMap.getString("KART_TIPI"))){
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
					}else if("P".equals(iMap.getString("KART_TIPI"))){
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
					}
					
					
					return oMap;
				}
			}
			
		}
		
		oMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", basvuruMap);
		if (!TffServicesMessages.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE")) ){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA"));
			return oMap;
		}
		
		BigDecimal teslimatAdresiNo = null;
		if (iMap.getSize("ADRES_LISTE") > 0 ){
			for (int i = 0; i < iMap.getSize("ADRES_LISTE"); i++) {
				GMMap uyeAdres=new GMMap();
				uyeAdres.put("UYE_NO", uyeMap.getString("UYE_NO"));
				uyeAdres.put("TFF_BASVURU_NO", oMap.getString("TFF_BASVURU_NO"));
				uyeAdres.put("ADRES_TIPI", iMap.getString("ADRES_LISTE",i,"ADRES_TIPI"));
				uyeAdres.put("ACIK_ADRES",  iMap.getString("ADRES_LISTE",i,"ACIK_ADRES"));
				uyeAdres.put("IL_AD",  iMap.getString("ADRES_LISTE",i,"IL_ADI"));
				uyeAdres.put("IL_KOD", iMap.getString("ADRES_LISTE",i,"IL_KODU"));
				uyeAdres.put("ILCE_KOD",  iMap.getString("ADRES_LISTE",i,"ILCE_KODU"));
				uyeAdres.put("ILCE_AD",  iMap.getString("ADRES_LISTE",i,"ILCE_ADI"));
				uyeAdres.put("ADRES_RUMUZ",  nvl(iMap.getString("ADRES_LISTE",i,"ADRES_RUMUZ"),"GISE"));
				uyeAdres.put("SOURCE", iMap.getString("SOURCE"));
				uyeAdres.put("TESLIMAT_ADRESI_MI",iMap.getString("ADRES_LISTE",i,"TESLIMAT_ADRESI_MI"));
				uyeAdres.put("ILETISIM_MI",iMap.getString("ADRES_LISTE",i,"ILETISIM_MI"));
				uyeAdres.put("TESLIMAT_NOKTASI_KODU",iMap.getString("ADRES_LISTE",i,"TESLIMAT_NOKTASI_KODU"));
				uyeAdres.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_ADD_OR_UPDATE_APPLICATION_ADDRESS",uyeAdres));
			}
		}
		
		//PREPAID icin teslimat noktasi secilirse 
/*		if(("TN".equals(iMap.getString("KURYE_TIPI")) || "GN".equals(iMap.getString("KURYE_TIPI")) ) && "P".equals(iMap.getString("KART_TIPI"))){
			if (iMap.getSize("ADRES_LISTE") > 0 ){
				for (int i = 0; i < iMap.getSize("ADRES_LISTE"); i++) {
					GMMap adresMap=new GMMap();
					String tnCode = iMap.getString("ADRES_LISTE",i,"TESLIMAT_NOKTASI_KODU");
					if (tnCode != null && !"".equals(tnCode.trim())){
						adresMap.put("TESLIMAT_NOKTASI_KODU", tnCode);
						adresMap.put("UYE_NO", uyeMap.getString("UYE_NO"));
						adresMap.put("TFF_BASVURU_NO", oMap.getString("TFF_BASVURU_NO"));
						adresMap.put("ADRES_TIPI", iMap.getString("KURYE_TIPI"));
						adresMap.put("ACIK_ADRES",  iMap.getString("ADRES_LISTE",i,"ACIK_ADRES"));
						adresMap.put("IL_AD",  iMap.getString("ADRES_LISTE",i,"IL_ADI"));
						adresMap.put("IL_KOD", iMap.getString("ADRES_LISTE",i,"IL_KODU"));
						adresMap.put("ILCE_KOD",  iMap.getString("ADRES_LISTE",i,"ILCE_KODU"));
						adresMap.put("ILCE_AD",  iMap.getString("ADRES_LISTE",i,"ILCE_ADI"));
						adresMap.put("ADRES_RUMUZ",  nvl(iMap.getString("ADRES_LISTE",i,"ADRES_RUMUZ"),"TESLIMAT_NOKTASI"));
						adresMap.put("SOURCE", iMap.getString("SOURCE"));
						if ("E".equals(iMap.getString("ADRES_LISTE",i,"TESLIMAT_ADRESI_MI"))){
							teslimatAdresiNo = adresMap.getBigDecimal("ADRES_NO");
						}
						adresMap = GMServiceExecuter.call("BNSPR_TFF_UYE_ADRES_EKLE",adresMap);
						
					}else{
						continue;
					}
					
					
					
				}
			}
		}*/
		
		return oMap;
	}
	
	
	/**
	 * 
	 * @param iMap
	 * @return RESPONSE, RESPONSE_DATA, BASVURU_NO
	 */
	@GraymoundService("BNSPR_TFF_INSTANT_APPLICATION_VALIDATION")
	public static GMMap createInstantApplicationValidation(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(TffServicesMessages.BNSPR_SESSION_NAME);
		BigDecimal basvuruNo =  iMap.getBigDecimal("BASVURU_NO");
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		/* 1 CREATE MEMBER */
		String uyruk 		= iMap.getString("NATIONALITY");
		String pasaportNo 	= iMap.getString("PASSPORT_NO"); 
		String tckn			= iMap.getString("TCKN");
		String kartTipi		= iMap.getString("CARD_TYPE");
		String urun			= iMap.getString("PRODUCT");
		String urunSahip	= iMap.getString("PRODUCT_OWNER");
		String adi			= iMap.getString("NAME");
		String soyadi		= iMap.getString("SOYADI");
		String ikinciAdi	= iMap.getString("MIDDLE_NAME");
		String annekizlikSoyadi	= iMap.getString("MOTHER_MAIDEN_SURNAME");
		String birthDate	= iMap.getString("BIRTHDATE");
		String email		= iMap.getString("EMAIL");
		String foto			= iMap.getString("PHOTO_BYTE_ARRAY");
		String kuryeTipi 	= iMap.getString("COURIER_TYPE");
		String kartBedeli	= iMap.getString("CARD_FEE");
		String kuryeBedeli	= iMap.getString("COURIER_FEE");
		String sadakatBedeli= iMap.getString("LOYALTY_FEE");
		String vizeBedeli 	= iMap.getString("SUBSCRIPTION_FEE");
		String paymentType 	= iMap.getString("PAYMENT_TYPE");
		String kartNo	 	= iMap.getString("CARD_NO");
		String source	 	= iMap.getString("SOURCE");
		
		String tip 		= iMap.getString("PHONE_TYPE");
		String ulkeKod 	= iMap.getString("PHONE_COUNTRY_CODE");
		String alanKod	= iMap.getString("PHONE_AREA_CODE");
		String numara	= iMap.getString("PHONE_NUMBER");
		
		String giseID	= iMap.getString("GISE_ID");
		String giseUser	= iMap.getString("GISE_USER");
		
		if(StringUtils.isBlank(giseID)){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","0219");
			return oMap;
		}
		if(StringUtils.isBlank(giseUser)){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","0218");
			return oMap;
		}
		
			try {
			String procStr = "{call BNSPR.PKG_TRN3801.validation_instant_application(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[36];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("NATIONALITY");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PASSPORT_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CARD_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PRODUCT");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PRODUCT_OWNER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("NAME");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SURNAME");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BIRTHDATE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("EMAIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("COURIER_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PAYMENT_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CARD_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_COUNTRY_CODE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_AREA_CODE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PHONE_NUMBER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOURCE");
			
			
			i = 0;
			Object[] outputValues = new Object[4];
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "RESPONSE_DATA";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			GMMap kontrolMap = new GMMap();
			
			kontrolMap.put("CARD_NO", iMap.getString("CARD_NO"));
			kontrolMap.put("PRODUCT_OWNER", iMap.getString("PRODUCT_OWNER"));
			GMMap tmpMap = GMServiceExecuter.call("BNSPR_TFF_G4_KART_URUN_KONTROLU", kontrolMap);
			if(!"2".equals(tmpMap.getString("RESPONSE"))){
				return tmpMap;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA",TffServicesMessages.FIZIKI_BASVURU_ALAN_KONTROL_GENEL_HATA);
			
		}
			
			
		return oMap;
		
		
		/* 2 CREATE APPLICATION  */
		/* 3 PAYMENT   */
		
		
		/* 4 ACTIVATION  */
	
	}
	/**
	 * 
	 * @param iMap
	 * @return RESPONSE, RESPONSE_DATA, BASVURU_NO
	 */
	@GraymoundService("BNSPR_TFF_INSTANT_APPLICATION")
	public static GMMap createInstantApplication(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap tmpMap = new GMMap();
		String uyruk 		= iMap.getString("NATIONALITY");
		String pasaportNo 	= iMap.getString("PASSPORT_NO"); 
		String tckn			= iMap.getString("TCKN");
		String kartTipi		= iMap.getString("CARD_TYPE");
		String urun			= iMap.getString("PRODUCT");
		String urunSahip	= iMap.getString("PRODUCT_OWNER");
		String adi			= iMap.getString("NAME");
		String soyadi		= iMap.getString("SURNAME");
		String ikinciAdi	= iMap.getString("MIDDLE_NAME");
		String annekizlikSoyadi	= iMap.getString("MOTHER_MAIDEN_SURNAME");
		String dogumTarihi	= iMap.getString("BIRTHDATE");
		String email		= iMap.getString("EMAIL");
		String calismaSekli	= iMap.getString("WORK_TYPE","C");//Calismiyor atiliyor bir bilgi gelmezse
		String foto			= iMap.getString("PHOTO_BYTE_ARRAY");
		String kuryeTipi 	= iMap.getString("COURIER_TYPE");
		String kartBedeli	= iMap.getString("CARD_FEE");
		String kuryeBedeli	= iMap.getString("COURIER_FEE");
		String sadakatBedeli= iMap.getString("LOYALTY_FEE");
		String vizeBedeli 	= iMap.getString("SUBSCRIPTION_FEE");
		String odemeTipi 	= iMap.getString("PAYMENT_TYPE");
		String odemeRefId 	= iMap.getString("PAYMENT_REF_ID");
		String kartNo	 	= iMap.getString("CARD_NO");
		String source	 	= iMap.getString("SOURCE");
		
		String tip 		= iMap.getString("PHONE_TYPE");
		String ulkeKod 	= iMap.getString("PHONE_COUNTRY_CODE");
		String alanKod	= iMap.getString("PHONE_AREA_CODE");
		String numara	= iMap.getString("PHONE_NUMBER");
		BigDecimal basvuruNo = null;
		BigDecimal uyeNo = null;
		
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_INSTANT_APPLICATION_VALIDATION", iMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			return tmpMap;
		}
		
		
		/* 1 CREATE MEMBER  */
		GMMap uyeMap=new GMMap();
		uyeMap.put("TCKN", tckn);
		uyeMap.put("PASAPORT_NO", pasaportNo);
		uyeMap.put("UYRUK", uyruk);
		
		uyeMap.putAll(findUye(uyeMap));
		uyeNo = uyeMap.getBigDecimal("UYE_NO");
		if(!uyeMap.containsKey("UYE_NO")) {
			uyeMap.put("UYRUK", uyruk);
			uyeMap.put("TCKN", tckn);
			uyeMap.put("TAKIM", urunSahip);
			uyeMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
			uyeMap.put("CALISMA_SEKLI", calismaSekli);
			uyeMap.put("ILETISIM_TEL_TIP",tip);
			if ("C".equals(tip)){
			
				uyeMap.put("CEP_ULKE_KOD", ulkeKod);
				uyeMap.put("CEP_ALAN_KOD", alanKod);
				uyeMap.put("CEP_NUMARA", numara);
			}
			uyeMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
			uyeMap.put("WEB_ADI", adi);
			uyeMap.put("WEB_SOYADI", soyadi);
			uyeMap.put("WEB_IKINCI_ADI", ikinciAdi);
			uyeMap.put("WEB_DOGUM_TARIHI",dogumTarihi );
			uyeMap.put("EMAIL", email);
			uyeMap.put("SOURCE", source);
		 
			uyeMap.putAll(GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_OR_UPDATE_MEMBER", uyeMap));
			if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(uyeMap.getString("RESPONSE") )){
				throw new GMRuntimeException(0,uyeMap.getString("RESPONSE_DATA"));
			}else{
				uyeNo = uyeMap.getBigDecimal("UYE_NO");
			}
		}
		/* 1 CREATE MEMBER  */
		
		
		/* 2 CREATE APPLICATION  */
		GMMap basvuruMap=new GMMap();
		String kanalKodu = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD").toString();
		basvuruMap.put("KANAL_KOD", kanalKodu);
		
//		basvuruMap.put("ISYERI_ADI",iMap.getString("ISYERI_ADI"));
		basvuruMap.put("UYE_NO",uyeMap.getString("UYE_NO"));
		basvuruMap.put("KART_TIPI", kartTipi);
		basvuruMap.put("URUN_KODU", urun);
		basvuruMap.put("URUN_SAHIP_KODU", urunSahip);
		basvuruMap.put("EUPT_YARAT", "E");
		basvuruMap.put("EMAIL", email);
		basvuruMap.put("SOURCE", source);
		basvuruMap.put("CALISMA_SEKLI", calismaSekli);
		basvuruMap.put("CLIENT_IP", iMap.getString("CLIENT_IP"));
		basvuruMap.put("GISE_USER", iMap.getString("GISE_USER"));
		basvuruMap.put("GISE_ID", iMap.getString("GISE_ID"));
		iMap.put("KURYE_TIPI", kuryeTipi);
		if(!isKuryeTipiValid(iMap)){
			throw new GMRuntimeException(0,"0155");
		}
		basvuruMap.put("KURYE_TIPI", kuryeTipi);
		basvuruMap.put("ILETISIM_TEL_TIP", tip);
		
		if("E".equals(tip)){
			basvuruMap.put("EV_ULKE_KOD", ulkeKod);
			basvuruMap.put("EV_TEL_KOD",alanKod);
			basvuruMap.put("EV_TEL_NO", numara);
		}else if("I".equals(tip)){
			basvuruMap.put("IS_ULKE_KOD", ulkeKod);
			basvuruMap.put("IS_TEL_KOD", alanKod);
			basvuruMap.put("IS_TEL_NO", numara);
		}else if("C".equals(tip)){
			basvuruMap.put("CEP_ULKE_KOD", ulkeKod);
			basvuruMap.put("CEP_TEL_KOD", alanKod);
			basvuruMap.put("CEP_TEL_NO", numara);
		}
		
		basvuruMap.put("ANNE_KIZLIK_SOYADI", annekizlikSoyadi);
		if( ("TN".equals(kuryeTipi) || "GN".equals(kuryeTipi))&& ("D".equals(kartTipi) || "KK".equals(kartTipi) )){
			throw new GMRuntimeException(0,"0155");
		}
		
		
		tmpMap.clear();
		TffUyeler uye = findUye(uyruk, StringUtils.isBlank(tckn) ? null : new BigDecimal(tckn), pasaportNo);
		iMap.put("MUSTERI_NO", uye.getBankaMusteriNo());
		iMap.put("TCKN", tckn);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_AKTIF_BASVURU_VAR_MI", iMap);
		if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE")) ){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}
		tmpMap.clear();
		tmpMap.put("DIRECT_CALL", true);
		tmpMap.put("URUN_SAHIP_KODU", urunSahip);
		tmpMap.put("URUN_KODU", urun);
		tmpMap.put("UYE_NO", uyeNo);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_UYGUNLUK_DURUMU", tmpMap);
		if ( TffServicesMessages.RESPONSE_BASARISIZ.equals(tmpMap.getString("RESPONSE")) ){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}else{
			int su = tmpMap.getSize("KART_UYGUNLUK");
			for (int i =0 ; i < su; i++){
				String ktip = tmpMap.getString("KART_UYGUNLUK", i,"KART_TIPI");
				String uygunluk = tmpMap.getString("KART_UYGUNLUK", i,"UYGUNLUK");
				if(kartTipi.equals(ktip) && "H".equals(uygunluk)){
					oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
					if("KK".equals(kartTipi)){
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_KK_BASVURU_VAR_HATASI);
					}else if("D".equals(kartTipi)){
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_D_BASVURU_VAR_HATASI);
					}else if("P".equals(kartTipi)){
						oMap.put("RESPONSE_DATA", TffServicesMessages.AKTIF_P_BASVURU_VAR_HATASI);
					}
					throw new GMRuntimeException(0, oMap.getString("RESPONSE_DATA"));
				}
			}
			
		}
		
		
		
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", basvuruMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}
		basvuruNo = tmpMap.getBigDecimal("TFF_BASVURU_NO");
		iMap.put("TFF_BASVURU_NO",basvuruNo);
		GMServiceExecuter.execute("BNSPR_TFF_BASVURU_ILE_MUSTERI_GUNCELLE", iMap);
		/* 2 CREATE APPLICATION  */
		/* 3 PHOTO  */
		
		tmpMap.clear();
		GMMap photoMap = new GMMap();
		photoMap.put("TFF_BASVURU_NO", basvuruNo);
		photoMap.put("SOURCE", source);
		photoMap.put("FOTO_BYTE_ARRAY", foto);
		tmpMap = GMServiceExecuter.call("BNSPR_TFF_FOTO_YUKLE", photoMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}
		
		/* 4 PAYMENT   */
		GMMap odemeMap = new GMMap();
		odemeMap.put("BASVURU_NO", basvuruNo);
		odemeMap.put("KURYE_TIPI", kuryeTipi);
		odemeMap.put("ODEME_TIPI", odemeTipi);
		
		odemeMap.put("ODEME_REF_ID", odemeRefId);
		odemeMap.put("KART_BEDELI", kartBedeli);
		odemeMap.put("KURYE_BEDELI", kuryeBedeli);
		odemeMap.put("LOYALTY_BEDELI", sadakatBedeli);
		odemeMap.put("VIZE_BEDELI", vizeBedeli);
		odemeMap.put("PROMOSYON_BEDELI", 0);
		odemeMap.put("GISE_USER", iMap.getString("GISE_USER"));
		odemeMap.put("GISE_ID", iMap.getString("GISE_ID"));
		tmpMap.clear();
		tmpMap = GMServiceExecuter.call("BNSPR_TRN3802_ODEME_YAP", odemeMap);
		if(!"2".equals(tmpMap.getString("RESPONSE"))){
			throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
		}
		oMap.put("ODEME_ISLEM_NO", tmpMap.getString("ISLEM_NO"));
		tmpMap.clear();
		/* 5 ACTIVATION  */
		GMMap aktivasyonMap = new GMMap();
		aktivasyonMap.put("TFF_BASVURU_NO", basvuruNo);
		aktivasyonMap.put("KART_BILGI", kartNo);
		try {
			tmpMap = GMServiceExecuter.call("BNSPR_TFF_UYE_KART_BILGISI_VER", aktivasyonMap);
			if(!"2".equals(tmpMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0,tmpMap.getString("RESPONSE_DATA"));
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0,e.getMessage());
		}
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		oMap.put("RESPONSE_DATA", "");
		oMap.put("APPLICATION_NO", basvuruNo);
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TFF_BUS_NETAS_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap basvuruMap =  new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_CREATE_APPLICATION_VALIDATION",iMap));
		if(!"2".equals(oMap.getString("RESPONSE"))){
			return oMap;
		}
		//GMServiceExecuter.executeNT("BNSPR_TFF_BUS_CANCEL_PREVIOUS_APPLICATIONS", iMap);
		GMMap trxMap = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap());
		basvuruMap.put("TRX_NO",trxMap.getString("TRX_NO"));
		iMap.put("TRX_NO",trxMap.getString("TRX_NO"));
		GMMap basvuru = GMServiceExecuter.call("BNSPR_TFF_COMMON_CREATE_APPLICATION", iMap);
		oMap.put("TFF_BASVURU_NO",basvuru.getString("TFF_BASVURU_NO"));
		oMap.put("EUPT_REF_ID",basvuru.getString("EUPT_REF_ID"));
		oMap.put("RESPONSE",basvuru.getString("RESPONSE"));
		oMap.put("RESPONSE_DATA",basvuru.getString("RESPONSE_DATA"));
		
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_TFF_G4_ODEME_YAP")
	public static GMMap g4OdemeYap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap odemeMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
		
		
		if(tffBasvuru != null){
			TffSsProductMap ssmap = (TffSsProductMap)session.createCriteria(TffSsProductMap.class)
					.add(
							Restrictions.and(Restrictions.eq("kartTipi", tffBasvuru.getKartTipi()), 
									         Restrictions.eq("urunSahipKod", tffBasvuru.getUrunSahipKodu()))
			             )
			        .add(Restrictions.eq("gecerli", "E"))
			        .add(Restrictions.eq("under18", "H"))
			        .list().get(0);
			
			
			BigDecimal kartBedeli = iMap.getBigDecimal("KART_BEDELI");
			BigDecimal loyaltyBedeli = iMap.getBigDecimal("LOYALTY_BEDELI");
			BigDecimal vizeBedeli = iMap.getBigDecimal("VIZE_BEDELI");
			
			
			if(ssmap != null){
				if(kartBedeli.add(loyaltyBedeli).compareTo(ssmap.getKartBedeli().add(ssmap.getLoyaltyBedeli())) == 0){
					odemeMap.put("LOYALTY_BEDELI", ssmap.getLoyaltyBedeli());
					odemeMap.put("KART_BEDELI", ssmap.getKartBedeli());
				}else{
					oMap.put("RESPONSE",TffServicesMessages.RESPONSE_BASARISIZ);
					oMap.put("RESPONSE_DATA",TffServicesMessages.G4_ODEME_TUTARI_HATALI);
					
					return oMap;
				}
				
			}else{
				logger.error("SS Mapte urunu bulamadim. Basvuru No :"+ tffBasvuru.getBasvuruNo());
				odemeMap.put("LOYALTY_BEDELI",  iMap.get("LOYALTY_BEDELI"));
				odemeMap.put("KART_BEDELI",  iMap.get("KART_BEDELI"));
			}
			
			
			
			
			
			odemeMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			odemeMap.put("KURYE_TIPI", iMap.get("KURYE_TIPI"));
			odemeMap.put("ODEME_TIPI", iMap.get("ODEME_TIPI"));
			odemeMap.put("TESLIMAT_ADRES_NO", iMap.get("TESLIMAT_ADRES_NO"));
			odemeMap.put("SOURCE", iMap.get("SOURCE"));
			odemeMap.put("ISLEM_BASARISIZ", iMap.get("ISLEM_BASARISIZ"));
			odemeMap.put("PROMOSYON_DEGERI", iMap.get("PROMOSYON_DEGERI"));
			odemeMap.put("PROMOSYON_BEDELI", iMap.get("PROMOSYON_BEDELI"));
			odemeMap.put("PROMOSYON_KODU", iMap.get("PROMOSYON_KODU"));
			
			odemeMap.put("KURYE_BEDELI", iMap.get("KURYE_BEDELI"));
			
			odemeMap.put("PROMOSYON_ORANI", iMap.get("PROMOSYON_ORANI"));
			odemeMap.put("VIZE_BEDELI", iMap.get("VIZE_BEDELI"));
			odemeMap.put("HESAP_NO", iMap.get("HESAP_NO"));
			odemeMap.put("ODEME_REF_ID", iMap.get("ODEME_REF_ID"));
			odemeMap.put("DIL", iMap.get("DIL"));
			odemeMap.put("GISE_USER", iMap.getString("GISE_USER"));
			odemeMap.put("GISE_ID", iMap.getString("GISE_ID"));
		}
		
		
		
		GMMap trxMap = GMServiceExecuter.call("BNSPR_TRN3802_ODEME_YAP", odemeMap);
		
		oMap.put("RESPONSE",trxMap.getString("RESPONSE"));
		oMap.put("RESPONSE_DATA",trxMap.getString("RESPONSE_DATA"));
		oMap.put("ISLEM_NO", trxMap.getString("ISLEM_NO"));
		
		return oMap;
		
	}
	/**
	 * CARD_NO
	 * PRODUCT_OWNER
	 * */
	@GraymoundService("BNSPR_TFF_G4_KART_URUN_KONTROLU")
	public static GMMap kartUrunKontrolu(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tmpMap= new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARILI);
		
		tmpMap = GMServiceExecuter.call("BNSPR_INTRACARD_PREPERSO_GET_CARD_INFO", iMap);
		if(!"2".equals(tmpMap.getString("RETURN_CODE"))){
			oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
			oMap.put("RESPONSE_DATA","0213");
			return oMap;
		}else{
			String productId = tmpMap.getString("PRODUCT_ID");
			if (StringUtils.isEmpty(productId)) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
				return oMap;
			}
			try {
				GMMap sorguMap = new GMMap();
				sorguMap.put("KOD", "KART_LOGOSUZ_URUN_ID");
				sorguMap.put("KEY", productId);

				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
				if (TffServicesMessages.EVET.equals(sorguMap.getString("IS_EXIST"))) {					
						return oMap;
				}
			}
			catch (Exception e) {
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA", TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
				return oMap;
			}




			TffSsProductMap tffSsProductMap = (TffSsProductMap) session.createCriteria(TffSsProductMap.class).add(Restrictions.eq("urunId",productId)).uniqueResult();
			if(tffSsProductMap == null){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.URUN_GECERLI_DEGIL_HATASI);
				return oMap;	
			}
			String teamCode = tmpMap.getString("TEAM_CODE");
			if(StringUtils.isBlank(teamCode)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.URUN_SAHIP_KOD_HATASI);
				return oMap;
			}
			if(!tffSsProductMap.getKlupId().equals(teamCode)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA","0210");
				return oMap;
			}
			
			String productOwner = iMap.getString("PRODUCT_OWNER");
			
			if(StringUtils.isBlank(productOwner)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA",TffServicesMessages.URUN_SAHIP_KOD_HATASI);
				return oMap;
			}
			if(!tffSsProductMap.getUrunSahipKod().equals(productOwner)){
				oMap.put("RESPONSE", TffServicesMessages.RESPONSE_BASARISIZ);
				oMap.put("RESPONSE_DATA","0210");
				return oMap;
			}
		}
		
		return oMap;
	}
}
