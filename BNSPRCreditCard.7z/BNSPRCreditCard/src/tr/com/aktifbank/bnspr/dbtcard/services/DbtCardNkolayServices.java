package tr.com.aktifbank.bnspr.dbtcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KartBasvuruTalep;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class DbtCardNkolayServices {
	private static final String IssuingExceptionApplicationNoUsedBefore = "Issuing.Exception.ApplicationNoUsedBefore";

	/** NKolay debit kart icin girilen talebi alarak basvuru ve kart 
	 * sureclerini tamamlar. Islem sonucuna gore talebi gunceller.<br>
	 * @author murat.el
	 * @since TY-4783
	 * @param iMap - Sorgu kriterleri<br>
	 * 			<li>ID - Talep ID
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>BASVURU_NO - Debit basvuru no
	 *          <li>KART_NO - Debit kart no
	 *          <li>DURUM_KOD - Islem durum kodu
	 */
	@GraymoundService("BNSPR_DEBIT_NKOLAY_PROCESS_REQUEST")
	public static GMMap processRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		BigDecimal dbtBasvuruNo = iMap.getBigDecimal("DBT_BASVURU_NO");
		int durumKod = iMap.getInt("DURUM_KOD");
		String durumAciklama = StringUtils.EMPTY;
		String teslimatOnay = iMap.getString("KREDI_TESLIMAT_ONAY");

		try {
			//Basvuru yoksa ya da olusturulurken hata almissa olustur.
			if (dbtBasvuruNo == null && (durumKod == 0 || durumKod == 12)) {
				//Basvuru olustur
				iMap.remove("DURUM_KOD");//Talep tablosunun durum kodu geliyor, basvuru ile ayni parametre oldugu icin
				iMap.remove("KART_NO");//Talep tablosundan geliyordu. Gelmemesi lazim ama gelirse dikkate alinmamasi icin
				iMap.remove("BASVURU_NO");//Talep tablosundan geliyordu. Log icin talep Id olarak kullaniliyor
				
				try {
					oMap.putAll(GMServiceExecuter.executeNT("BNSPR_DEBIT_NKOLAY_CREATE_APPLICATION", iMap));//BASVURU_NO
					dbtBasvuruNo = oMap.getBigDecimal("BASVURU_NO");
					durumKod = 11;//Basvuru olustu
					
					//Talebi guncelle
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", durumKod);
					sorguMap.put("DBT_BASVURU_NO", dbtBasvuruNo);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
				}
				catch (Exception e) {
					durumKod = 12;//Basvuru olusturulamadi
					durumAciklama = e.getMessage();
					if (durumAciklama.length() > 200) {
						durumAciklama = durumAciklama.substring(0, 200);
					}
					
					//Talebi guncelle
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", durumKod);
					sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
					return oMap;
				}
			}
			
			//Basvuru olusturuldu, Kart olusturulmadiysa, karti olustur
			String kartNo = null;
			if (dbtBasvuruNo != null && (durumKod == 11 || durumKod == 14)) {
				try {
					//Kart olustur
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", dbtBasvuruNo);
					sorguMap.put("TESLIMAT_ONAY", teslimatOnay);
					
					oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CREATE_OCEAN_DEBIT_CUSTOMER_AND_CARD", sorguMap));
					kartNo = oMap.getString("KART_NO");
					
					//Kontrol
					if (StringUtils.isBlank(kartNo) || 
							!CreditCardServicesUtil.RESPONSE_BASARILI.equals(oMap.getString("RESPONSE"))) {
						durumKod = 14;//Basvuru olusturuldu, kart olusturulamadi
						//Talebi guncelle
						sorguMap.clear();
						sorguMap.put("ID", iMap.get("ID"));
						sorguMap.put("DURUM_KOD", durumKod);
						sorguMap.put("DURUM_ACIKLAMA", oMap.get("RESPONSE_DATA"));
						GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
						return oMap;
					} else {
						durumKod = 13;
						//Talebi guncelle
						sorguMap.clear();
						sorguMap.put("ID", iMap.get("ID"));
						sorguMap.put("DURUM_KOD", durumKod);
						sorguMap.put("KART_NO", kartNo);
						GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
						GMServiceExecuter.execute("BNSPR_SMS_FOR_NKOLAY", sorguMap);
					}
				}
				catch (Exception e) {
					durumKod = 14;//Basvuru olusturuldu, kart olusturulamadi
					durumAciklama = e.getMessage();
					if (durumAciklama.length() > 200) {
						durumAciklama = durumAciklama.substring(0, 200);
					}
					
					//Talebi guncelle
					sorguMap.clear();
					sorguMap.put("ID", iMap.get("ID"));
					sorguMap.put("DURUM_KOD", durumKod);
					sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
					GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
				}
			}
		}
		catch (Exception e) {
			durumKod = 99;//Genel Hata
			durumAciklama = e.getMessage();
			if (durumAciklama.length() > 200) {
				durumAciklama = durumAciklama.substring(0, 200);
			}
			
			//Talebi guncelle
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", "99");
			sorguMap.put("DURUM_ACIKLAMA", e.getMessage());
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
		}

		oMap.put("DURUM_KOD", durumKod);
		return oMap;
	}
	
	/** NKolay debit kart icin girilen talebi alarak basvuru surecini tamamlar<br>
	 * @author murat.el
	 * @since TY-4783
	 * @param iMap - Basvuru bilgileri<br>
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_DEBIT_NKOLAY_CREATE_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Ayni TCKNye ait debit basvuru veya kart var mi?
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("KAYNAK", "NKOLAY");
			//sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_NKOLAY_VALIDATE_APPLICATION", sorguMap));
			
			//KPS datasini al
			sorguMap.put("TCK_NO", iMap.get("TCKN"));
			sorguMap.put("KPS_JOB_AKTIF_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_KPS_SORGULA", sorguMap));
			sorguMap.remove("TCK_NO");
			sorguMap.remove("KPS_JOB_AKTIF_MI");
			
			//Basvurunun talepten gelmeyen alanlarini al
			sorguMap.putAll(getNkolayApplicationParameters(iMap));
			
			//Talepten gelen datalari al
			sorguMap.putAll(iMap);
			
			//Basvuru datasini kaydet
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_SAVE_OR_UPDATE_APPLICATION", sorguMap));//BASVURU_NO, TRX_NO
			oMap.put("BASVURU_NO", sorguMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", sorguMap.get("TRX_NO"));
			
			//Basvuruyu datasini kontrol et
			GMServiceExecuter.execute("BNSPR_TRN3870_AFTER_CONTROL", sorguMap);
			GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", sorguMap);
			
			//Basvuruyu tamamla
			GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap);
			GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", sorguMap);
			
			//Tarihceye kayit at
			//Tarihceye NBSMe gonderildi kaydi at
			sorguMap.clear();
			sorguMap.put("ISLEM_KODU", "TALEP");
			sorguMap.put("BASVURU_NO", oMap.get("BASVURU_NO"));
			sorguMap.put("DURUM_KODU", "TALEP");
			sorguMap.put("ISLEM_SONRASI_DURUM_KODU", "BASVURU");
			sorguMap.put("TRX_NO", oMap.get("TRX_NO"));
			sorguMap.put("BAS_TARIHI",Calendar.getInstance().getTime());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	@GraymoundService("BNSPR_DEBIT_NKOLAY_VALIDATE_APPLICATION")
	public static GMMap validateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Akista basvurusu var mi?
			sorguMap.clear();
			sorguMap.put("TCK_NO", iMap.get("TCKN"));
			sorguMap.put("KART_TIPI", "D");
			sorguMap.put("BASVURU_SONLANDIR", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_BASVURU_GIRIS_CAPRAZ_KONTROL", sorguMap));
			if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DEVAM", CreditCardServicesUtil.HAYIR))) {
				CreditCardServicesUtil.raiseGMError("2055");
			}

			//Akista karti var mi?
			if ("NKOLAY".equals(iMap.getString("KAYNAK"))) {
				sorguMap.clear();
				sorguMap.put("TCKN", iMap.get("TCKN"));
				sorguMap.put("KART_TIPI", "D");
				sorguMap.put("HATA_VERILECEK_MI", CreditCardServicesUtil.EVET);
				GMServiceExecuter.execute("BNSPR_TRN3871_KART_VAR_MI", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** NKolay debit kart icin girilen talebte yer almayan 
	 * nkolay debit basvurusuna ozel degerleri alir.<br>
	 * @author murat.el
	 * @since TY-4783
	 * @param iMap - Basvuru bilgileri<br>
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>BASVURU_TARIHI<li>KANAL_KOD<li>KREDI_KARTI_SEVIYESI
	 *          <li>KART_TIPI<li>SESSION_IP<li>FINANSAL_TIP
	 *          <li>LOGO_KODU<li>KART_URUN_TIP<li>KART_UZERINDEKI_ISIM
	 *          <li>MUSTERI_TIPI<li>MUSTERI_GROUP<li>SUBE_KOD
	 */
	private static GMMap getNkolayApplicationParameters(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Default degerleri ata
			oMap.put("BASVURU_TARIHI", Calendar.getInstance().getTime());
			oMap.put("KANAL_KOD", "8");//webkredi kontrolu
			oMap.put("KREDI_KARTI_SEVIYESI", "K");//Kart basvurusu
			oMap.put("KART_TIPI", "D");//TODO bununla ilgili buyuk degisiklik yapilacak
			oMap.put("SESSION_IP", ADCSession.getString("CLIENT_IP"));
			
			//Banka personeli mi
	    	GMMap sorguMap = new GMMap();
	    	sorguMap.put("TC_KIMLIK_NO", iMap.get("TCKN"));
	    	sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
	    	String personelMi = GMServiceExecuter.call("BNSPR_CREDITCARD_PERSONEL_MI", sorguMap).getString("PERSONEL_MI");
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
					
			//Webkredi ucunda art�k TROY debit verilecek ama de�i�me ihtimaline kar�� parametrik yap�ld�. Parametrede tan�ml� de�ilse bo� kayd� al�r 
			String markaNKD = getChannelNKDBrand(iMap.getString("SOURCE"));

			String musteriTipi = "";
			if (CreditCardServicesUtil.EVET.equals(personelMi)) {
				musteriTipi = "P";
			}
			GMMap productMap = new GMMap();
			productMap.put(OceanConstants.URUN_TABLO_MARKA, markaNKD);
			productMap.put(OceanConstants.URUN_TABLO_MUSTERI_TIPI, musteriTipi);
			productMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_DebitCard);
			productMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, "NKD");
			
			productMap.putAll(GMServiceExecuter.execute("BNSPR_GET_KK_PRODUCT_INFO_BY_DETAILS", productMap));
			
			if (productMap.getSize(OceanConstants.KK_PRODUCT_LIST) > 0 ){
				oMap.put("FINANSAL_TIP", productMap.get(OceanConstants.KK_PRODUCT_LIST, 0, OceanConstants.URUN_TABLO_FINANSAL_KOD));
				oMap.put("LOGO_KODU", productMap.get(OceanConstants.KK_PRODUCT_LIST, 0, OceanConstants.URUN_TABLO_LOGO_KOD));
				oMap.put("KART_URUN_TIP", productMap.get(OceanConstants.KK_PRODUCT_LIST, 0, OceanConstants.URUN_TABLO_URUN_ID));
			}
			
			//Musteri bilgilerini al
			oMap.put("KART_UZERINDEKI_ISIM", CreditCardApplicationServices.getKartUzerindekiIsim
					(iMap.getString("AD"), iMap.getString("IKINCI_AD"), iMap.getString("SOYAD")));
	    	
	    	//Personel olup olmadigina gore musteri tipi ve grubu belirlenir.
	    	//Default olarak belirlenen musteri tipi
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI");
	    	}
	    	oMap.put("MUSTERI_TIPI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));

	    	//Default olarak belirlenen musteri grubu
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP");
	    	}
	    	oMap.put("MUSTERI_GROUP", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));
	    	
	    	//Sube kodu bilgisini musteri uzerinden al
	    	GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("MUSTERI_NO"));
	    	if (gnlMusteri != null) {
	    		oMap.put("SUBE_KOD", gnlMusteri.getSubeKodu());
	    	}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	
	/** NKolay debit kart icin girilen talebi alarak ocean kart ve musteri olusturma 
	 * sureclerini tamamlar. Basvuruyu kart bilgisi ile gunceller.<br>
	 * @author murat.el
	 * @since TY-4783
	 * @param iMap - Sorgu kriterleri<br>
	 * 			<li>BASVURU_NO - Debit basvuru no
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>RESPONSE - Islem sonuc kodu
	 *          <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 *          <li>KART_NO - Debit kart no
	 */
	@GraymoundService("BNSPR_CREATE_OCEAN_DEBIT_CUSTOMER_AND_CARD")
	public static GMMap createOceanDebit(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Musteri olustur
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("DURUM_KOD", "BASIM");		
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_CREDIT_CARD_CUSTOMER", sorguMap));
			String custResult = sorguMap.getString("ORESULT");
			String custResultDesc = sorguMap.getString("RETURN_DESCRIPTION");
			//Kontrol
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RETURN_CODE"))) {
				oMap.put("RESPONSE_DATA", custResult + "-" + custResultDesc);
				return oMap;
			}

			//Kart olusturulmadan once musterinin hesabi yoksa yeni bir rezerv hesap acilir.
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("HESAP_KAYDEDILSIN_MI", CreditCardServicesUtil.EVET);
			GMServiceExecuter.execute("BNSPR_KK_REZERV_HESAP_AL", sorguMap);
			
			//Kart olustur
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("DURUM_KOD", "BASIM");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_DEBIT_CARD", iMap));
			String kartNo =  sorguMap.getString("CARD_NO");
			//Kontrol
			String cardResult = sorguMap.getString("ORESULT");
			String cardResultDesc = sorguMap.getString("RETURN_DESCRIPTION");
			if (!CreditCardServicesUtil.RESPONSE_BASARILI.equals(sorguMap.getString("RETURN_CODE"))) {
				//Tekrar kullan�ld� hatasi aldi ise basvuru no ile kart no bilgisini all ve devam et
				//1.Hata mesaji:ORESULT=SystemError, ERROR_DETAIL=System.Exception: Girilen ApplicationNo 
				//ve Customer bilgileriyle basvuru daha once yapilmistir.CardNo:  6711210163228796
				//2.Hata mesaji:ORESULT=Error, ERROR_DETAIL=This application no is used before :3082517
				/*String cardResultError = sorguMap.getString("ERROR_DETAIL");;
				if ( (cardResultError.indexOf("ApplicationNo") > 0 && cardResultError.indexOf("CardNo") > 0) || 
						cardResultDesc.indexOf("This application no is used before") > 0) {*/
						
				if (BnsprOceanCommonFunctions.convertNewReturnCodeToOld(IssuingExceptionApplicationNoUsedBefore).equals(sorguMap.getString("RETURN_CODE"))){
					sorguMap.clear();
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_KART_NO_BY_BASVURU_NO", sorguMap));
					//Kontrol
					if (StringUtils.isNotBlank(sorguMap.getString("KART_NO"))) {
						kartNo = sorguMap.getString("KART_NO");
					}
				}
			}
			
			//Kart no olusmamissa cik.
			if (StringUtils.isBlank(kartNo)) {
				oMap.put("RESPONSE_DATA", cardResult + "-" + cardResultDesc + "-" + "KartNo:" + kartNo);
				return oMap;
			}  else {
				oMap.put("KART_NO", kartNo);
			}
			
			//Kart no guncelle
			conn = DALUtil.getGMConnection();
			query = "{ call PKG_TRN3874.update_kart_no(?,?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, kartNo);
			stmt.execute();
			GMServerDatasource.close(stmt);
			
			//Kart basim datalarini guncelle.
			query = "{ call PKG_KK_BASVURU.Update_Ocean_Service_Info(?,?,?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, custResult);
			stmt.setString(3, custResultDesc);
			stmt.setString(4, cardResult);
			stmt.setString(5, cardResultDesc);
			stmt.execute();
			GMServerDatasource.close(stmt);
			
			//Basvuru durumunu guncelle
			sorguMap.clear();
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("ISLEM_NO", 0);
			sorguMap.put("DURUM_KOD", "BASIM");
			sorguMap.put("TARIHCE_AKSIYON", "E");
			sorguMap.put("ISLEM_ACIKLAMA", custResult + "-" + cardResult);
			GMServiceExecuter.execute("BNSPR_KK_DURUM_GUNCELLE", sorguMap);
			
			//Sonuc
			oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	  @GraymoundService("BNSPR_SMS_FOR_NKOLAY")
	    public static GMMap sendSmsForNkolay(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        GMMap smsMap = new GMMap();
	        GMMap mesajMap = new GMMap();
	        String iletisimTel = "";	   
	        BigDecimal id ;
	        
	        
	        id= iMap.getBigDecimal("ID");
	        
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			
			Criteria criteria = session.createCriteria(KartBasvuruTalep.class);
			criteria.add(Restrictions.eq("id",id) );
			
		
			KartBasvuruTalep kTalep = (KartBasvuruTalep) criteria.list().get(0);
			iletisimTel = kTalep.getCepTelKod() + kTalep.getCepTelNo();
			
	  	       
	        if(StringUtils.isBlank(iletisimTel))
	        {
	            throw new GMRuntimeException(53133 , "mesaj atacak numara bulunamadi. �slemi durdurmayacak log at�l�yor");
	        }
	        
	        String mesajKod ="";
	        GMMap paramMap = CreditCardServicesUtil.getParameterListByKey("SMS_LIST", "NKOLAY_SMS_KOD", kTalep.getKanal(), null, null, null);
	        if (paramMap.getSize("SMS_LIST") == 0)
	        	 paramMap = CreditCardServicesUtil.getParameterListByKey("SMS_LIST", "NKOLAY_SMS_KOD", "DEFAULT", null, null, null);
			// kanal koduna g�re at�lacak sms i�eri�ini belirler, kanal kodu tan�ml� de�ilse default tipli kayd� al�r
			mesajKod = 	paramMap.get("SMS_LIST", 0, "NAME").toString();
			
		    mesajMap.put("MESSAGE_NO", mesajKod);
	        String mesaj = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", mesajMap).get("ERROR_MESSAGE");	        
	       
	        smsMap.put("MSISDN",iletisimTel);
	        smsMap.put("CONTENT", mesaj);
	       
	        GMServiceExecuter.executeAsync("BNSPR_SMS_SEND_SMS", smsMap);
	        
	        
	      
	        return oMap;
    }
	  
	  
	  private static String getChannelNKDBrand (String channel) {
	  
		try{
			
		GMMap paramMap = new GMMap();
		paramMap.put("KOD", "NKD_KANAL_MARKA");
		paramMap.put("KEY", channel);
		paramMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
		return paramMap.getString("TEXT"); 
		
		}
	  catch(Exception ex){
		  try{
			  
			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "NKD_KANAL_MARKA");
			paramMap.put("KEY", " ");
			paramMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
			
			return paramMap.getString("TEXT"); 
		  	}
		  catch(Exception e){
			  return OceanConstants.MASTERCARD;
		  }
	  	}
		
	  }
	
}
