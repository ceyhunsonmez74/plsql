package tr.com.aktifbank.bnspr.dbtcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CardServicesHelper;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices;
import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KartBasvuruTalep;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KkBasvuruAdres;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class DbtCardNoNameServices {
	
	private static final int CARD_HOLDER_NAME_LENGTH = 26;
	private static final Logger logger = Logger.getLogger(CardServicesHelper.class);
	private static final String NONAME_KAZANIM_URUNU = "NNDEBIT";

	/** NKolay debit kart icin girilen talebi alarak basvuru olusturur.
	 *  Islem sonucuna gore talebi gunceller.<br>
	 * @author murat.el
	 * @since 
	 * @param iMap - Sorgu kriterleri<br>
	 * 			<li>Talepten alinan basvuru olusturmak icin gerekli bilgiler
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>BASVURU_NO - Debit basvuru no
	 *          <li>KART_NO - Debit kart no
	 *          <li>DURUM_KOD - Islem durum kodu
	 */
	@GraymoundService("BNSPR_DEBIT_NONAME_PROCESS_REQUEST")
	public static GMMap processRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		String durumAciklama = StringUtils.EMPTY;

		try {
			//yeni noname card kanallar�ndan biri ise ba�vuru basvuru stat�s�nde yarat�l�p teslim a�amas�nda a���a d�ner
			if (isNewNonameCardSource(iMap.getString("SOURCE")))
				iMap.put("DURUM_KOD", "BASVURU");
			else
				iMap.put("DURUM_KOD", "ACIK");
			
			//Basvuru olustur
			iMap.put("BASVURU_NO", iMap.get("DBT_BASVURU_NO"));//Talep tablosundan geliyordu. Log icin talep Id olarak kullaniliyor
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_NONAME_CREATE_APPLICATION", iMap));//BASVURU_NO
			
			//Talebi guncelle
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", 21);
			sorguMap.put("DBT_BASVURU_NO", oMap.getString("BASVURU_NO"));
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
		}
		catch (Exception e) {
			durumAciklama = e.getMessage();
			if (durumAciklama.length() > 200) {
				durumAciklama = durumAciklama.substring(0, 200);
			}
			
			//Talebi guncelle
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", 99);
			sorguMap.put("DURUM_ACIKLAMA", e.getMessage());
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
		}

		return oMap;
	}
	
	/** No Name debit kart icin girilen talebi alarak basvuru surecini tamamlar<br>
	 * @author murat.el
	 * @since 
	 * @param iMap - Basvuru bilgileri<br>
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>RESPONSE - Islem sonuc kodu
	 */
	@GraymoundService("BNSPR_DEBIT_NONAME_CREATE_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARISIZ);

		try {
			//Ayni TCKNye ait debit basvuru veya kart var mi?
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("KAYNAK", "NONAME");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_NKOLAY_VALIDATE_APPLICATION", sorguMap));
			
			//KPS datasini al
			sorguMap.put("TCK_NO", iMap.get("TCKN"));
			sorguMap.put("KPS_JOB_AKTIF_MI", CreditCardServicesUtil.HAYIR);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3870_KPS_SORGULA", sorguMap));
			sorguMap.remove("TCK_NO");
			sorguMap.remove("KPS_JOB_AKTIF_MI");
			
			//Basvurunun talepten gelmeyen alanlarini al
			sorguMap.putAll(getNoNameApplicationParameters(iMap));
			
			//Talepten gelen datalari al
			sorguMap.putAll(iMap);
			
			//Basvuru datasini kaydet
			sorguMap.put("ISLEM_FLAG", "E");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_SAVE_OR_UPDATE_APPLICATION", sorguMap));//BASVURU_NO, TRX_NO
			oMap.put("BASVURU_NO", sorguMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", sorguMap.get("TRX_NO"));
			
			//Basvuruyu datasini kontrol et
			GMServiceExecuter.execute("BNSPR_TRN3870_AFTER_CONTROL", sorguMap);
			GMServiceExecuter.execute("BNSPR_TRN3871_CHECK_FIELDS", sorguMap);
			
			//Basvuruyu tamamla
			GMServiceExecuter.execute("BNSPR_TRN3871_START_TRANSACTION", sorguMap);
			GMServiceExecuter.execute("BNSPR_KK_BELGE_KAYIT", sorguMap);
			
			//Tarihceye kayit at
			//Tarihceye NBSMe gonderildi kaydi at
			sorguMap.clear();
			sorguMap.put("ISLEM_KODU", "TALEP");
			sorguMap.put("BASVURU_NO", oMap.get("BASVURU_NO"));
			sorguMap.put("DURUM_KODU", "TALEP");
			sorguMap.put("ISLEM_SONRASI_DURUM_KODU", iMap.getString ("DURUM_KOD","ACIK"));
			sorguMap.put("TRX_NO", oMap.get("TRX_NO"));
			sorguMap.put("BAS_TARIHI", Calendar.getInstance().getTime());
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("RESPONSE", CreditCardServicesUtil.RESPONSE_BASARILI);
		return oMap;
	}
	
	/** NKolay debit kart icin girilen talebte yer almayan 
	 * nkolay debit basvurusuna ozel degerleri alir.<br>
	 * @author murat.el
	 * @since TY-4783
	 * @param iMap - Basvuru bilgileri<br>
	 * @return oMap - Islem sonuc degerleri<br>
	 *          <li>BASVURU_TARIHI<li>KANAL_KOD<li>KREDI_KARTI_SEVIYESI
	 *          <li>KART_TIPI<li>SESSION_IP<li>FINANSAL_TIP
	 *          <li>LOGO_KODU<li>KART_URUN_TIP<li>KART_UZERINDEKI_ISIM
	 *          <li>MUSTERI_TIPI<li>MUSTERI_GROUP<li>SUBE_KOD
	 */
	private static GMMap getNoNameApplicationParameters(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Default degerleri ata
			oMap.put("BASVURU_TARIHI", Calendar.getInstance().getTime());
			
			oMap.put("KANAL_KOD", getNonameApplicationChannel(iMap.getString("KANAL")));//yim-bayi
			oMap.put("KREDI_KARTI_SEVIYESI", "K");//Kart basvurusu
			oMap.put("KART_TIPI", "D");
			oMap.put("SESSION_IP", ADCSession.getString("CLIENT_IP"));
			
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

			GMMap productMap = new GMMap();
			productMap.put(OceanConstants.URUN_TABLO_KART_TIPI, OceanConstants.Akustik_DebitCard);
			productMap.put(OceanConstants.URUN_TABLO_KAYNAK_GRUP_KOD, "NND");
			productMap.put(OceanConstants.URUN_TABLO_KAYNAK_ALT_GRUP_KOD, "V2"); // art�k yeni Noname kart verilecek, eski Noname UPT d�n���m� i�in kalmaya devam edecek
			
			productMap.putAll(GMServiceExecuter.execute("BNSPR_GET_KK_PRODUCT_INFO_BY_DETAILS", productMap));
			
			if (productMap.getSize(OceanConstants.KK_PRODUCT_LIST) > 0 ){
				oMap.put("FINANSAL_TIP", productMap.get(OceanConstants.KK_PRODUCT_LIST, 0, OceanConstants.URUN_TABLO_FINANSAL_KOD));
				oMap.put("LOGO_KODU", productMap.get(OceanConstants.KK_PRODUCT_LIST, 0, OceanConstants.URUN_TABLO_LOGO_KOD));
				oMap.put("KART_URUN_TIP", productMap.get(OceanConstants.KK_PRODUCT_LIST, 0, OceanConstants.URUN_TABLO_URUN_ID));
			}

			//Musteri bilgilerini al
			oMap.put("KART_UZERINDEKI_ISIM", CreditCardApplicationServices.getKartUzerindekiIsim
					(iMap.getString("AD"), iMap.getString("IKINCI_AD"), iMap.getString("SOYAD")));
			
			//Banka personeli mi
	    	GMMap sorguMap = new GMMap();
	    	sorguMap.put("TC_KIMLIK_NO", iMap.get("TCKN"));
	    	sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.HAYIR);
	    	String personelMi = GMServiceExecuter.call("BNSPR_CREDITCARD_PERSONEL_MI", sorguMap).getString("PERSONEL_MI");
	    	
	    	//Personel olup olmadigina gore musteri tipi ve grubu belirlenir.
	    	//Default olarak belirlenen musteri tipi
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_TIPI");
	    	}
	    	oMap.put("MUSTERI_TIPI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));

	    	//Default olarak belirlenen musteri grubu
	    	sorguMap.clear();
	    	if (CreditCardServicesUtil.EVET.equals(personelMi)) {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP_PERSONEL");
	    	} else {
	    		sorguMap.put("PARAMETRE", "KK_MUSTERI_GRUP");
	    	}
	    	oMap.put("MUSTERI_GROUP", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).get("DEGER"));
	    	
	    	//Sube kodu bilgisini musteri uzerinden al
	    	GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("MUSTERI_NO"));
	    	if (gnlMusteri != null) {
	    		oMap.put("SUBE_KOD", gnlMusteri.getSubeKodu());
	    	}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	
	
	/**NoNameDebitCard icin musteri atamasi yapar.<br>
	 * @author dilek.dogan
	 * @since 
	 * @param iMap <br>
	 *        <li>BASVURU_NO -  basvuru numarasi
	 *        <li>BARKOD_NO - Kart barkod numarasi
	 * @return oMap - Sonuc bilgisi<br>
	 * 		  <li>RETURN_CODE - Islem sonuc kodu (0:Basarisiz|1:Basarili)
	 * 		  <li>RETURN_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_DEBIT_NONAME_CARD_MATCH")
	public static GMMap noNameMatchCardAndCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = null;
		BigDecimal customerNo = BigDecimal.ZERO;
		BigDecimal appNo = BigDecimal.ZERO;
		BigDecimal bankAccountNo = BigDecimal.ZERO;
		String cardNo = StringUtils.EMPTY;
		String customerName = StringUtils.EMPTY;
		String barcodeNo = StringUtils.EMPTY;
		String teslimatAdresKod = StringUtils.EMPTY;
		boolean isCardOpenStat = iMap.getBoolean("IS_CARD_OPEN_STAT", false);
		boolean isMatchCustomer = false;
		
		try {
			session = DAOSession.getSession("BNSPRDal");
			appNo = iMap.getBigDecimal("BASVURU_NO");
			barcodeNo = iMap.getString("BARKOD_NO");
			KkBasvuru application = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", appNo)).uniqueResult();
			if(application == null){
				oMap.put(OceanMapKeys.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(OceanMapKeys.RESPONSE_DATA, "Basvuru kaydi bulunamadi");
				return oMap;
			}
			

			teslimatAdresKod = teslimatAdresKoduBul(session, appNo);
			
			if (StringUtils.isEmpty(teslimatAdresKod)) {
				oMap.put(OceanMapKeys.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(OceanMapKeys.RESPONSE_DATA, "Basvuru adres kaydi bulunamadi");
				return oMap;
			}
			
			customerNo = application.getMusteriNo();
			GnlMusteri customer = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", customerNo)).uniqueResult();
			
			if(customer == null){
				oMap.put(OceanMapKeys.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(OceanMapKeys.RESPONSE_DATA, "Musteri kaydi bulunamadi.");
				return oMap;
			}
			
			customerName = checkCardHolderName(customer.getAdi(), customer.getIkinciAdi(), customer.getSoyadi());

			cardNo = getCardNoFromBarcode(barcodeNo);
			
			if (cardNo == null || StringUtils.isEmpty(cardNo)) {
				oMap.put(OceanMapKeys.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(OceanMapKeys.RESPONSE_DATA, "Bu barkod numaras�na ait kart bulunamadi.");
				return oMap;
			}
			
			GMMap queryMap = new GMMap();
			queryMap.put("BASVURU_NO", appNo);
			queryMap.put("CARD_NO", cardNo);
			queryMap.putAll(GMServiceExecuter.execute("BNSPR_CREATE_CREDIT_CARD_CUSTOMER", queryMap));
			
            String custResult = queryMap.getString("ORESULT");
            String custResultDesc = queryMap.getString("RETURN_DESCRIPTION");
            
            if (!AkustikConstants.RESPONSE_SUCCESS.equals(queryMap.getString("RETURN_CODE"))) {
            	oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
            	oMap.put("RESPONSE_DATA", custResult + "-" + custResultDesc);
                return oMap;
            }
            
    		//Kart olusturulmadan once musterinin hesabi yoksa yeni bir rezerv hesap acilir.
            bankAccountNo = rezervHesapAc(appNo);
			
            //matchCardAndCustomer
            logger.info("match account no" + bankAccountNo);
            queryMap.clear();
			queryMap.put("CUSTOMER_NO", customerNo);
			queryMap.put("BANK_ACCOUNT_NO", bankAccountNo);
			queryMap.put("CARD_NO", cardNo);
			queryMap.put("NAME", customerName);
			queryMap.put("APPLICATION_NO", appNo);
            logger.info("match customerNo" + customerNo +"-"+ cardNo.toString()+ "-"+appNo);

            if(!StringUtils.isEmpty(iMap.getString("BOX_OFFICE_ID")))
			queryMap.put("BOX_OFFICE_ID", iMap.getString("BOX_OFFICE_ID"));
			else
				queryMap.put("BOX_OFFICE_ID",getNonameBoxOfficeId(iMap.getBigDecimal("KURYE_KOD")));
			
            logger.info("match BOX_OFFICE_ID" + queryMap.getString("BOX_OFFICE_ID"));

			queryMap.put("TXN_TYPE", "N");
            logger.info("match teslimatAdresKod" + teslimatAdresKod);

			queryMap.put("CARD_POST_IDX", getCardPostId(teslimatAdresKod));
            logger.info("match BOX_OFFICE_ID" + queryMap.getString("CARD_POST_IDX"));

			queryMap.put("IS_CARD_OPEN_STAT", isCardOpenStat);
			 logger.info("match IS_CARD_OPEN_STAT" + isCardOpenStat);
			 logger.info("match" +queryMap.toString());
			queryMap.putAll(GMServiceExecuter.call("BNSPR_GENERAL_MATCH_CARD_AND_CUSTOMER", queryMap));
			if (!AkustikConstants.RESPONSE_SUCCESS.equals(queryMap.getString("RETURN_CODE"))){
				oMap.put(OceanMapKeys.RESPONSE, queryMap.getString("RETURN_CODE"));
				oMap.put(OceanMapKeys.RESPONSE_DATA, queryMap.getString("RETURN_DESCRIPTION"));
				return oMap;
			}
				
			isMatchCustomer = true;
			
			queryMap.clear();
			queryMap.put("BASVURU_NO", appNo);
			queryMap.put("KART_NO", cardNo);
			queryMap.put("ONCEKI_DURUM_KOD", application.getDurumKod());
			queryMap.put("SONRAKI_DURUM_KOD", isCardOpenStat? "ACIK":"BASIM");

			queryMap.putAll(GMServiceExecuter.execute("BNSPR_NONAME_UPDATE_APPLICATION_STATUS_AND_CARD", queryMap));

			//kart aktivasyon
			queryMap.clear();
			queryMap.put("CARD_NO", cardNo);
			queryMap.put("APPLICATION_NO", appNo);
			queryMap.put("DURUM_KODU", isCardOpenStat? "ACIK":"BASIM");
			oMap.put("CARD_NO", cardNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_NONAME_CARD_ACTIVATION", queryMap));

			oMap.put(OceanMapKeys.RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
			oMap.put(OceanMapKeys.RESPONSE_DATA, "Musteri ve kart eslestirme islemi basariyla gerceklesmistir.");
		}
		catch (Exception e) {
			if(isMatchCustomer){
				GMMap queryMap = new GMMap();
				queryMap.put("CUSTOMER_NO", customerNo);
				queryMap.put("BANK_ACCOUNT_NO", bankAccountNo);
				queryMap.put("CARD_NO", cardNo);
				queryMap.put("NAME", customerName);
				queryMap.put("BOX_OFFICE_ID", iMap.getString("BOX_OFFICE_ID", getNonameBoxOfficeId(iMap.getBigDecimal("KURYE_KOD"))));
				queryMap.put("APPLICATION_NO",  appNo);
				queryMap.put("TXN_TYPE", "C");
				queryMap.put("CARD_POST_IDX", getCardPostId(teslimatAdresKod));
				GMServiceExecuter.call("BNSPR_GENERAL_MATCH_CARD_AND_CUSTOMER", queryMap);
			}
			
			String message = e.getMessage();

			oMap.put(OceanMapKeys.RESPONSE, AkustikConstants.RESPONSE_FAIL);
			oMap.put(OceanMapKeys.RESPONSE_DATA, message);
		}
		
		return oMap;
	}
	
	
	public static String checkCardHolderName(String name, String secondName, String lastName){
		String cardHolderName = name + (StringUtils.isEmpty(secondName) ? " " : (" " + secondName + " ")) + lastName;
		
		if(cardHolderName.length() > CARD_HOLDER_NAME_LENGTH){
			if((name + " " + lastName).length() <= CARD_HOLDER_NAME_LENGTH){
				cardHolderName = name + " " + lastName;
			}else if((name.substring(0, 1) + ". " + lastName).length() <= CARD_HOLDER_NAME_LENGTH) {
				cardHolderName = (name.substring(0, 1) + ". " + lastName);
			}else{
				cardHolderName = (name + " " + lastName).substring(0, CARD_HOLDER_NAME_LENGTH);
			}
		}
		
		return cardHolderName;
	}
	
	public static boolean isNewNonameCardSource(String source) {
		GMMap paramMap = new GMMap();
		paramMap.put("KOD", "NONAME_CARD_SOURCE");
		paramMap.put("KEY", source);
		// yeni noname kart i�in ba�vuru yapabilecek kanallar parametreye tan�mland�, parametrede varsa noname ba�vurusu ba�vuru ad�m�nda yarat�l�r, teslim a�amas�nda a���a d�nd�r�l�r
		paramMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", paramMap));
		if (TffServicesMessages.EVET.equals(paramMap.getString("IS_EXIST")))
			return true;

		else
			return false;
	}
	
	public static String getNonameApplicationChannel(String source) {
		String kanal = StringUtils.EMPTY;
		try {
			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "NONAME_CARD_SOURCE");
			paramMap.put("KEY1", source);
			kanal = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", paramMap).getString("TEXT");
		}
		catch (Exception e) {
			kanal = BnsprOceanCommonFunctions.getChannelCode();
		}

		return kanal;
	}
	
	public static String getNonameBoxOfficeId(BigDecimal courierCode) {

		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
		List<GnlParamText> kurye = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "NONAME_CARD_KURYE_FIRMA")).add(Restrictions.eq("siraNo", courierCode)).list();
		return kurye.get(0).getText();

	}
	
	
	public static String getCardNoFromBarcode(String barcode) {

		GMMap infoMap = new GMMap();
		GMMap oMap = new GMMap();
		String cardNo = StringUtils.EMPTY;
		infoMap.put("COURIER_BARCODE", barcode);
		oMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CARD_APPLICANT_INFO", infoMap);
		cardNo = oMap.getString("CARD_NO");

		return cardNo;
	}
	
	@GraymoundService("BNSPR_NONAME_UPDATE_APPLICATION_STATUS_AND_CARD")
	public static GMMap updateApplicationStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);

		// Ba�vuru bilgilerini al
		KkBasvuru kkBasvuru = (KkBasvuru) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

		if (kkBasvuru != null) {
			kkBasvuru.setDurumKod(iMap.getString("SONRAKI_DURUM_KOD"));
			kkBasvuru.setKartNo(iMap.getString("KART_NO"));
			session.saveOrUpdate(kkBasvuru);
		}

		GMMap sorguMap = new GMMap();

		sorguMap.put("ISLEM_KODU", iMap.getString("ONCEKI_DURUM_KOD"));
		sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
		sorguMap.put("DURUM_KODU", iMap.getString("ONCEKI_DURUM_KOD"));
		sorguMap.put("ISLEM_SONRASI_DURUM_KODU", iMap.get("SONRAKI_DURUM_KOD"));
		sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
		sorguMap.put("BAS_TARIHI", Calendar.getInstance().getTime());
		sorguMap.putAll(GMServiceExecuter.execute("BNSPR_KK_TARIHCE_KAYDET", sorguMap));
		
		kartBasvuruTalepGuncelle(iMap.getBigDecimal("BASVURU_NO"), iMap.getString("KART_NO"));

			

		return oMap;
	}

	

	@GraymoundService("BNSPR_CHECK_DELIVERY_FOR_CARD_MATCH")
	public static GMMap checkDeliveryForMatchCardAndCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("BASVURU_NO", iMap.getString("REFERANS_NO"));
			oMap = GMServiceExecuter.call("BNSPR_DEBIT_NONAME_CARD_MATCH", iMap);
			if (!AkustikConstants.RESPONSE_SUCCESS.equals(oMap.getString(OceanMapKeys.RESPONSE)))
				throw new GMRuntimeException(0, oMap.getString(OceanMapKeys.RESPONSE_DATA));
		}

		catch (GMRuntimeException e) {
			throw new GMRuntimeException(0, oMap.getString(OceanMapKeys.RESPONSE_DATA));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	

	public static String getCardPostId(String adresKod) {

		if (OceanConstants.ADRES_TIPI_EV.equals(adresKod))
			return OceanConstants.CARD_POST_IDX_HOME;
		
		else if (OceanConstants.ADRES_TIPI_IS.equals(adresKod))
			return OceanConstants.CARD_POST_IDX_WORK;

		else if (OceanConstants.ADRES_TIPI_DIGER.equals(adresKod))
			return OceanConstants.CARD_POST_IDX_OTHER;
		
		else
			return OceanConstants.CARD_POST_IDX_OTHER;

	}
	
	
	
	public static void kartBasvuruTalepGuncelle(BigDecimal applicationNo, String cardNo) {
		try {
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			GMMap sorguMap = new GMMap();

			BigDecimal kartBasvuruTalepId = BigDecimal.ZERO;
			List<KartBasvuruTalep> list = session.createCriteria(KartBasvuruTalep.class).add(Restrictions.eq("dbtBasvuruNo", applicationNo)).add(Restrictions.eq("islemTip", "NND")).add(Restrictions.eq("durumKod", new BigDecimal(21))).list();
			if (list.size() > 0) {
				kartBasvuruTalepId = list.get(0).getId();
			}

			// Talebi guncelle
			sorguMap.put("KOD", "KART_BASVURU_TALEP_DURUM_KOD");
			sorguMap.put("KEY1", 22);
			sorguMap.put("ID", kartBasvuruTalepId);
			sorguMap.put("DURUM_KOD", 22);
			sorguMap.put("KART_NO", cardNo);
			sorguMap.put("DURUM_ACIKLAMA", CreditCardServicesUtil.getParamText(sorguMap).getString("TEXT"));
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	
	public static String teslimatAdresKoduBul(Session session, BigDecimal basvuruNo) {

		KkBasvuruAdres applicationAddress = (KkBasvuruAdres) session.createCriteria(KkBasvuruAdres.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).add(Restrictions.eq("teslimatAdresiMi", "E")).uniqueResult();

		if (applicationAddress != null) {
			return applicationAddress.getId().getAdresKod();
		}
		
		return null;

	}
	
	
	public static BigDecimal rezervHesapAc(BigDecimal appNo) {

		GMMap queryMap = new GMMap();
		queryMap.put("BASVURU_NO", appNo);
		queryMap.put("HESAP_KAYDEDILSIN_MI", CreditCardServicesUtil.EVET);
		queryMap.putAll(GMServiceExecuter.execute("BNSPR_KK_REZERV_HESAP_AL", queryMap));
		return queryMap.getBigDecimal("HESAP_NO");

	}
	
	@GraymoundService("BNSPR_NONAME_CARD_ACTIVATION")
	public static GMMap noNameCardActivation(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Belgeler tamamlandiysa musteri,hesap ve kart islemlerini tamamla.
			// 1.Basvuru musteri bilgisini al.
			String kartNo = iMap.getString("CARD_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			if (!StringUtils.isEmpty(iMap.getString("APPLICATION_NO"))) {
				basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
			}
			GMMap musteriBilgiMap = new GMMap();
			musteriBilgiMap.putAll(getBasvuruMusteriInfo(kartNo, basvuruNo));// KART_NO
			/* Hep parametre olarak gelen kart numarasi islemlerde esas olacak, basvuru no gelemeyebileceginden
			fonk.dan donen deger ile tazelenir.*/

			iMap.putAll(musteriBilgiMap);
			// basvuru durumu basim degilse cik.
			if (!"BASIM".equals(iMap.getString("DURUM_KODU"))) {
				CreditCardServicesUtil.raiseGMError("2701", basvuruNo, iMap.getString("DURUM_KODU"), "BASIM");
			}

			// 2.musteri kontak ise gercege cevrilmelidir.
			// BNSPR_TRN3182_GERCEK_MUSTERI_DONUSTUR
			if ("K".equals(iMap.getString("MUSTERI_KONTAKT"))) {
				try {
					iMap.put("SISTEM", "OCEAN");
					iMap.put("KART_TIPI", musteriBilgiMap.getString("KART_TIPI"));
					iMap.put("KAZANIM_URUNU", NONAME_KAZANIM_URUNU);
					oMap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_GERCEK_MUSTERI_DONUSTUR", iMap));
				}
				catch (Exception e) {

					throw ExceptionHandler.convertException(e);

				}
				// 3.musteri gercek ise basvuru bilgileri ile guncellenir.
			} // PY-6705 ile kaldirildi, ancak PY-11417 ile eklendi.
			else if ("M".equals(iMap.getString("MUSTERI_KONTAKT"))) {
				if ("D".equals(musteriBilgiMap.getString("KART_TIPI"))) {
					GMMap sorguMap = new GMMap();
					sorguMap.put("MUSTERI_NO", musteriBilgiMap.get("MUSTERI_NO"));
					GMServiceExecuter.execute("BNSPR_CREDITCARD_GERCEK_MUSTERI_GUNCELLE", sorguMap);
				}
			}

			// 4.rezerv hesap yoksa vadesiz hesap acilmalidir.
			// sube kodu null ise calisilan sune kodunu al
			if (iMap.getString("SUBE_KODU") == null) {
				iMap.put("SUBE_KODU", "444");
			}

			iMap.put("BASVURU_NO", basvuruNo);

			// Vadesiz hesap al
			GMMap hesap = new GMMap();
			hesap.put("BASVURU_NO", basvuruNo);
			hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_VADESIZ_HESAP_AC", iMap));
			iMap.put("HESAP_NO", hesap.getString("HESAP_NO"));
			oMap.put("VADESIZ_HESAP_BILGI", hesap);

			// Otomatik �at� hesab� a��lmas�n diye kapat�ld�
			// Vadesiz hesabi cati Hesabina Cevir
			/*hesap = new GMMap();
			hesap.put("BASVURU_NO", basvuruNo);
			hesap.putAll(GMServiceExecuter.call("BNSPR_CREDITCARD_CATI_HESAP_AC", iMap));
			oMap.put("CATI_HESAP_BILGI", hesap);*/

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	   /** Basim asamasindaki basvurularin belge kontrolu yapildiktan sonra
		 * musteri, hesap ve kart tamamlama islemleri gerceklestirilir
		 * 
		 * @author murat.el
		 * @param basvuruNo - Kredi karti basvuru numarasi
		 * @param kartNo - Kredi karti numarasi
		 * @return Basvuru yapan musteri bilgileri
		 */
		private static GMMap getBasvuruMusteriInfo(String kartNo, BigDecimal basvuruNo) {
			GMMap oMap = new GMMap();
			
			//initial database variables
			String query = null;
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			
			try {
				conn = DALUtil.getGMConnection();
				
				query = "{? = call PKG_KK_BASVURU.Musteri_Bilgisi(?,?) }";
				stmt = conn.prepareCall(query);
				stmt.registerOutParameter(1, -10);
				stmt.setString(2, kartNo);
				stmt.setBigDecimal(3, basvuruNo);
				stmt.execute();

				rSet = (ResultSet) stmt.getObject(1);
				oMap = DALUtil.rSetMap(rSet);
			} catch(Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			
			return oMap;
		}
	
}
