package tr.com.aktifbank.bnspr.dbtcard.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.creditcard.services.CreditCardServicesUtil;
import tr.com.aktifbank.bnspr.dao.GnlKaraListeGercek;
import tr.com.aktifbank.bnspr.dao.KartBasvuruTalep;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.tff.services.TffServicesHelper;
import tr.com.aktifbank.bnspr.tff.services.TffServicesMessages;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class DbtCardCommonServices extends TffServicesHelper implements TffServicesMessages {
	
	//Logger
	private static final Logger logger = Logger.getLogger(DbtCardCommonServices.class);
	private static final String BASVURU_BEKLEMEDE = "-1";
	private static final String ANINDA_DONUSUM = "E";
	private static final Object BHS_ALINMIS = "E";
	private static final String SANAL_YENILEME_YAPILMIS_AMA_BASILMAMIS = "N";
	private static final String KARA_LISTE_YASA_DISI_KUMAR_BAHIS_KATEGORISI = "18";
	private static final List<String> NONAME_DEBIT_BASVURU_DURUM_KOD;
	private static final List<BigDecimal> NONAME_DEBIT_TALEP_DURUM_KOD;

	static {
		NONAME_DEBIT_BASVURU_DURUM_KOD = new ArrayList<String>();
		NONAME_DEBIT_BASVURU_DURUM_KOD.add("BASVURU");
	}
	
	static {
		NONAME_DEBIT_TALEP_DURUM_KOD = new ArrayList<BigDecimal>();
		NONAME_DEBIT_TALEP_DURUM_KOD.add(BigDecimal.ZERO);
		NONAME_DEBIT_TALEP_DURUM_KOD.add(BigDecimal.ONE.negate());

	}

	/** Kisinin sahip oldugu kart donusumune uygun; 
	 *  herhangi bir sistemdeki debit kartlari, 
	 *  intra sistemindeki prepaid kartlari listelenir.<br>
	 * @author murat.el
	 * @since PY-11118
	 * @param iMap - Sorgu kriterleri<br>
	 * 			<li>TCKN - Kisi tc kimlik numarasi
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *          <li>KART_LIST - Kriterlere uygun kart listesi
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_LIST_CARDS_FOR_EXCHANGE")
	public static GMMap listCardsForExchange(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap kartMap = new GMMap();
			GMMap sorguMap = new GMMap();
			GMMap urunMap = new GMMap();

			Boolean subeEkranindanMi =  iMap.getBoolean("SUBE_EKRANI_MI", false);
			
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("KART_TIPI", iMap.getString("KART_TIPI", OceanConstants.Akustik_AllCardDci));// Hepsi
			sorguMap.put("DURUM", OceanConstants.Card_Bank_Status_All);// Hepsi

			String musteriNo = StringUtils.EMPTY;
			if (StringUtils.isEmpty(iMap.getString("MUSTERI_NO")))
				musteriNo = BnsprOceanCommonFunctions.getCustomerNo(iMap.getString("TCKN"), null, null);
			else
				musteriNo = iMap.getString("MUSTERI_NO");
			
			sorguMap.put("CUSTOMER_NO", musteriNo);

			urunMap.putAll(GMServiceExecuter.execute("BNSPR_GET_NONAME_PRODUCT_ID", urunMap));
			String noNameUrunKodu = urunMap.getString("PRODUCT_ID");
			
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_GENERAL_KART_LISTELE", sorguMap));
			int gecerliKartSayisi = 0;
			for (int i = 0; i < kartMap.getSize("KART_LIST"); i++) {
				
				if(mevcutKartKurallaraUygunMu(noNameUrunKodu, kartMap.getString("KART_LIST", i, "KART_TIPI"), kartMap.getString("KART_LIST", i, "URUN_KODU"), kartMap.getString("KART_LIST", i, "EXT_ISSUE"), subeEkranindanMi))
				{	// Gecerli bir kart mi
						sorguMap.clear();
						sorguMap.put("KOD", "DEBIT_KART_DONUSUM_DURUM_KOD");// NN,GJ
						sorguMap.put("KEY", kartMap.getString("KART_LIST", i, "DURUM_KODU"));
						sorguMap.put("KEY2", kartMap.getString("KART_LIST", i, "ALT_DURUM_KODU"));
						sorguMap.put("KEY3", "OD");
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
						// Gecerli ise al
						if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
							oMap.put("KART_LIST", gecerliKartSayisi++, kartMap.getMap("KART_LIST", i));
						}
					}
			}	
			
			/*Kart� yoksa bekleyen Noname ba�vurusu var m� diye bak�l�r*/
			if (oMap.getSize("KART_LIST") == 0) {

				Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
				List<KkBasvuru> kkBasvuruList = (List<KkBasvuru>) session.createCriteria(KkBasvuru.class).add(Restrictions.eq("musteriNo", new BigDecimal(musteriNo))).add(Restrictions.in("durumKod", NONAME_DEBIT_BASVURU_DURUM_KOD)).add(Restrictions.eq("urunTipi", noNameUrunKodu)).list();

				if (kkBasvuruList.size() > 0) {
					int j = 0;
					for (KkBasvuru kkBasvuru : kkBasvuruList) {

						oMap.put("KART_LIST", j, "KART_NO", kkBasvuru.getKartNo());
						oMap.put("KART_LIST", j, "KART_TIPI", OceanConstants.Akustik_DebitCard);
						oMap.put("KART_LIST", j, "URUN_KODU", kkBasvuru.getUrunTipi());
						oMap.put("KART_LIST", j, "LOGO_KODU", kkBasvuru.getLogoKod());
						oMap.put("KART_LIST", j, "DURUM_KODU", kkBasvuru.getDurumKod());
						oMap.put("KART_LIST", j, "BASVURU_NO", kkBasvuru.getBasvuruNo());
						oMap.put("KART_LIST", j, "KAYIT_TARIHI", kkBasvuru.getBasvuruTarihi());
						j++;
					}
				}

				else {// hen�z ba�vurusu olu�mam�� talep var m� diye bak�l�r

					List<KartBasvuruTalep> kartBasvuruTalepList = (List<KartBasvuruTalep>) session.createCriteria(KartBasvuruTalep.class).add(Restrictions.eq("musteriNo", new BigDecimal(musteriNo))).add(Restrictions.eq("islemTip", "NND")).add(Restrictions.in("durumKod", NONAME_DEBIT_TALEP_DURUM_KOD)).list();
					if (kartBasvuruTalepList.size() > 0) {
						int j = 0;
						for (KartBasvuruTalep kartBasvuruTalep : kartBasvuruTalepList) {

							oMap.put("KART_LIST", j, "KART_NO", StringUtils.EMPTY);
							oMap.put("KART_LIST", j, "KART_TIPI", OceanConstants.Akustik_DebitCard);
							oMap.put("KART_LIST", j, "URUN_KODU", sorguMap.getString("PRODUCT_ID"));
							oMap.put("KART_LIST", j, "LOGO_KODU", StringUtils.EMPTY);
							oMap.put("KART_LIST", j, "DURUM_KODU", "BASVURU");
							oMap.put("KART_LIST", j, "BASVURU_NO", (kartBasvuruTalep.getDbtBasvuruNo() == null) ? kartBasvuruTalep.getId() : kartBasvuruTalep.getDbtBasvuruNo());
							oMap.put("KART_LIST", j, "KAYIT_TARIHI", kartBasvuruTalep.getLastUpdDate());
							j++;
						}
					}
				}
			}
				
		}
					
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Yeni bir kart talebi alir.<br>
	 * @author murat.el
	 * @since PY-11118
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>kart_basvuru_Talep tablosundaki kolon adlari ile datalarin mape koyulmasi gerek
	 * @return oMap - Islem sonuc bilgisi<br>
	 *          <li>ID - Kaydedilen talebe ait id
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST")
	public static GMMap saveOrUpdateCardRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal id = null;

		try {
			//Tan�ml� kanallardan NKD girilse bile i�erde yeni NND bas�lacak
			if (!StringUtils.isEmpty(iMap.getString("ISLEM_TIPI")) && OceanConstants.KART_BASVURU_TALEP_ISLEM_TIP_NKD.equals(iMap.getString("ISLEM_TIPI")) && DbtCardNoNameServices.isNewNonameCardSource(iMap.getString("KANAL")))
				iMap.put("ISLEM_TIPI", OceanConstants.KART_BASVURU_TALEP_ISLEM_TIP_NND);
			
			//Parametre Tamamla.
			id = iMap.getBigDecimal("ID");
			String durumKod = iMap.getString("DURUM_KOD");
			if (id == null) {
				sorguMap.clear();
				sorguMap.put("TABLE_NAME", "KART_BASVURU_TALEP");
				id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID");
				if (StringUtils.isBlank(durumKod)) {
					iMap.put("DURUM_KOD", BigDecimal.ZERO);
					durumKod = "0";
				}
			}
			
			//Durum aciklama al
			if (StringUtils.isNotBlank(durumKod) && 
					StringUtils.isBlank(iMap.getString("DURUM_ACIKLAMA"))) {
				sorguMap.clear();
				sorguMap.put("KOD", "KART_BASVURU_TALEP_DURUM_KOD");
				sorguMap.put("KEY1", durumKod);
				iMap.put("DURUM_ACIKLAMA", CreditCardServicesUtil.getParamText(sorguMap).getString("TEXT"));
			}
			
			//Durum aciklama uzunluk kontrolu yap
			String durumAciklama = iMap.getString("DURUM_ACIKLAMA");
			if (StringUtils.isNotBlank(durumAciklama)) {
				if (durumAciklama.length() > 200) {
					iMap.put("DURUM_ACIKLAMA", durumAciklama.substring(0, 200));
				}
			}
			
			//Kart basvuru talebini olustur.
			//Session ac
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			//Talep al
			KartBasvuruTalep kartBasvuruTalep = (KartBasvuruTalep) session.get(KartBasvuruTalep.class, id);
			if (kartBasvuruTalep == null) {
				kartBasvuruTalep = new KartBasvuruTalep();
				kartBasvuruTalep.setId(id);
			}

			kartBasvuruTalep.setAd(CreditCardServicesUtil.nvl(iMap.getString("AD"), kartBasvuruTalep.getAd()));
			kartBasvuruTalep.setAktarimNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("AKTARIM_NO"), kartBasvuruTalep.getAktarimNo()));
			kartBasvuruTalep.setAnneKizlikSoyad(CreditCardServicesUtil.nvl(iMap.getString("ANNE_KIZLIK_SOYAD"), kartBasvuruTalep.getAnneKizlikSoyad()));
			kartBasvuruTalep.setCalismaSekliKod(CreditCardServicesUtil.nvl(iMap.getString("CALISMA_SEKLI_KOD"), kartBasvuruTalep.getCalismaSekliKod()));
			kartBasvuruTalep.setCepTelKod(CreditCardServicesUtil.nvl(iMap.getString("CEP_TEL_KOD"), kartBasvuruTalep.getCepTelKod()));
			kartBasvuruTalep.setCepTelNo(CreditCardServicesUtil.nvl(iMap.getString("CEP_TEL_NO"), kartBasvuruTalep.getCepTelNo()));
			kartBasvuruTalep.setCepUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("CEP_ULKE_KOD"), CreditCardServicesUtil.nvl(kartBasvuruTalep.getCepUlkeKod(), "90")));
			kartBasvuruTalep.setDbtBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("DBT_BASVURU_NO"), kartBasvuruTalep.getDbtBasvuruNo()));
			kartBasvuruTalep.setDigerAdres(CreditCardServicesUtil.nvl(iMap.getString("DIGER_ADRES"), kartBasvuruTalep.getDigerAdres()));
			kartBasvuruTalep.setDigerIl(CreditCardServicesUtil.nvl(iMap.getString("DIGER_IL"), kartBasvuruTalep.getDigerIl()));
			kartBasvuruTalep.setDigerIlce(CreditCardServicesUtil.nvl(iMap.getString("DIGER_ILCE"), kartBasvuruTalep.getDigerIlce()));
			kartBasvuruTalep.setDigerPostaKod(CreditCardServicesUtil.nvl(iMap.getString("DIGER_POSTA_KOD"), kartBasvuruTalep.getDigerPostaKod()));
			kartBasvuruTalep.setDurumAciklama(CreditCardServicesUtil.nvl(iMap.getString("DURUM_ACIKLAMA"), kartBasvuruTalep.getDurumAciklama()));
			kartBasvuruTalep.setDurumKod(CreditCardServicesUtil.nvl(iMap.getBigDecimal("DURUM_KOD"), kartBasvuruTalep.getDurumKod()));
			kartBasvuruTalep.setEmail(CreditCardServicesUtil.nvl(iMap.getString("EMAIL"), kartBasvuruTalep.getEmail()));
			kartBasvuruTalep.setEvAdres(CreditCardServicesUtil.nvl(iMap.getString("EV_ADRES"), kartBasvuruTalep.getEvAdres()));
			kartBasvuruTalep.setEvIl(CreditCardServicesUtil.nvl(iMap.getString("EV_IL"), kartBasvuruTalep.getEvIl()));
			kartBasvuruTalep.setEvIlce(CreditCardServicesUtil.nvl(iMap.getString("EV_ILCE"), kartBasvuruTalep.getEvIlce()));
			kartBasvuruTalep.setEvPostaKod(CreditCardServicesUtil.nvl(iMap.getString("EV_POSTA_KOD"), kartBasvuruTalep.getEvPostaKod()));
			kartBasvuruTalep.setEvTelKod(CreditCardServicesUtil.nvl(iMap.getString("EV_TEL_KOD"), kartBasvuruTalep.getEvTelKod()));
			kartBasvuruTalep.setEvTelNo(CreditCardServicesUtil.nvl(iMap.getString("EV_TEL_NO"), kartBasvuruTalep.getEvTelNo()));
			kartBasvuruTalep.setEvUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("EV_ULKE_KOD"), kartBasvuruTalep.getEvUlkeKod()));
			kartBasvuruTalep.setIkinciAd(CreditCardServicesUtil.nvl(iMap.getString("IKINCI_AD"), kartBasvuruTalep.getIkinciAd()));
			kartBasvuruTalep.setIletisimAdresKod(CreditCardServicesUtil.nvl(iMap.getString("ILETISIM_ADRES_KOD"), kartBasvuruTalep.getIletisimAdresKod()));
			kartBasvuruTalep.setIsAdres(CreditCardServicesUtil.nvl(iMap.getString("IS_ADRES"), kartBasvuruTalep.getIsAdres()));
			kartBasvuruTalep.setIsIl(CreditCardServicesUtil.nvl(iMap.getString("IS_IL"), kartBasvuruTalep.getIsIl()));
			kartBasvuruTalep.setIsIlce(CreditCardServicesUtil.nvl(iMap.getString("IS_ILCE"), kartBasvuruTalep.getIsIlce()));
			kartBasvuruTalep.setIslemTip(CreditCardServicesUtil.nvl(iMap.getString("ISLEM_TIPI"), kartBasvuruTalep.getIslemTip()));
			kartBasvuruTalep.setIsPostaKod(CreditCardServicesUtil.nvl(iMap.getString("IS_POSTA_KOD"), kartBasvuruTalep.getIsPostaKod()));
			kartBasvuruTalep.setIsTelDahili(CreditCardServicesUtil.nvl(iMap.getString("IS_TEL_DAHILI"), kartBasvuruTalep.getIsTelDahili()));
			kartBasvuruTalep.setIsTelKod(CreditCardServicesUtil.nvl(iMap.getString("IS_TEL_KOD"), kartBasvuruTalep.getIsTelKod()));
			kartBasvuruTalep.setIsTelNo(CreditCardServicesUtil.nvl(iMap.getString("IS_TEL_NO"), kartBasvuruTalep.getIsTelNo()));
			kartBasvuruTalep.setIsUlkeKod(CreditCardServicesUtil.nvl(iMap.getString("IS_ULKE_KOD"),kartBasvuruTalep.getIsUlkeKod()));
			kartBasvuruTalep.setIsyeriAdi(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_ADI"), kartBasvuruTalep.getIsyeriAdi()));
			kartBasvuruTalep.setIsyeriVergiDairesiAd(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_AD"), kartBasvuruTalep.getIsyeriVergiDairesiAd()));
			kartBasvuruTalep.setIsyeriVergiDairesiIl(CreditCardServicesUtil.nvl(iMap.getString("ISYERI_VERGI_DAIRESI_IL"), kartBasvuruTalep.getIsyeriVergiDairesiIl()));
			kartBasvuruTalep.setKanal(CreditCardServicesUtil.nvl(iMap.getString("KANAL"), kartBasvuruTalep.getKanal()));
			kartBasvuruTalep.setKartNo(CreditCardServicesUtil.nvl(iMap.getString("KART_NO"), kartBasvuruTalep.getKartNo()));
			kartBasvuruTalep.setKimlikSeriNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SERI_NO"), kartBasvuruTalep.getKimlikSeriNo()));
			kartBasvuruTalep.setKimlikSiraNo(CreditCardServicesUtil.nvl(iMap.getString("KIMLIK_SIRA_NO"), kartBasvuruTalep.getKimlikSiraNo()));
			kartBasvuruTalep.setLastUpdDate(Calendar.getInstance().getTime());
			kartBasvuruTalep.setLastUpdOwner(ADCSession.getString("USER_NAME"));
			kartBasvuruTalep.setMeslekKod(CreditCardServicesUtil.nvl(iMap.getString("MESLEK_KOD"), kartBasvuruTalep.getMeslekKod()));
			kartBasvuruTalep.setMusteriNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("MUSTERI_NO"), kartBasvuruTalep.getMusteriNo()));
			kartBasvuruTalep.setOgrenimDurumKod(CreditCardServicesUtil.nvl(iMap.getString("OGRENIM_DURUM_KOD"), kartBasvuruTalep.getOgrenimDurumKod()));
			kartBasvuruTalep.setReferansNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("REFERANS_NO"), kartBasvuruTalep.getReferansNo()));
			kartBasvuruTalep.setSoyad(CreditCardServicesUtil.nvl(iMap.getString("SOYAD"), kartBasvuruTalep.getSoyad()));
			kartBasvuruTalep.setTckn(CreditCardServicesUtil.nvl(iMap.getString("TCKN"), kartBasvuruTalep.getTckn()));
			kartBasvuruTalep.setTeslimatAdresKod(CreditCardServicesUtil.nvl(iMap.getString("TESLIMAT_ADRES_KOD"), kartBasvuruTalep.getTeslimatAdresKod()));
			kartBasvuruTalep.setTffBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("TFF_BASVURU_NO"), kartBasvuruTalep.getTffBasvuruNo()));
			kartBasvuruTalep.setUnvanKod(CreditCardServicesUtil.nvl(iMap.getString("UNVAN_KOD"), kartBasvuruTalep.getUnvanKod()));
			kartBasvuruTalep.setGelir(CreditCardServicesUtil.nvl(iMap.getBigDecimal("GELIR"), kartBasvuruTalep.getGelir()));
			kartBasvuruTalep.setKrediTeslimatOnay(CreditCardServicesUtil.nvl(iMap.getString("KREDI_TESLIMAT_ONAY"), kartBasvuruTalep.getKrediTeslimatOnay()));
			// p2d nkolay
			kartBasvuruTalep.setKkBasvuruNo(CreditCardServicesUtil.nvl(iMap.getBigDecimal("KK_BASVURU_NO"), kartBasvuruTalep.getKkBasvuruNo()));
			

			session.save(kartBasvuruTalep);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("ID", id);
		return oMap;
	}
	
	/** Yeni bir kart talebi validasyonu yapar.<br>
	 * @author murat.el
	 * @since PY-11118
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>kart_basvuru_Talep tablosundaki kolon adlari ile datalarin mape koyulmasi gerek
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_VALIDATE_CARD_REQUEST")
	public static GMMap validateCardRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Durum Kod
			String durumKod = iMap.getString("DURUM_KOD");
			if (StringUtils.isNotBlank(durumKod)) {
				sorguMap.clear();
				sorguMap.put("KOD", "KART_BASVURU_TALEP_DURUM_KOD");
				sorguMap.put("KEY", durumKod);
				sorguMap.putAll(CreditCardServicesUtil.isExistParamText(sorguMap));
				if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("IS_EXIST"))) {
					CreditCardServicesUtil.raiseGMError("3", "Durum Kod", durumKod);
				}
			}
			
			//Yeni kayi ise kontrol et
			if ("0".equals(durumKod)) {
				//Kanal 
				if (StringUtils.isBlank(iMap.getString("KANAL"))) {
					CreditCardServicesUtil.raiseGMError("330", "Islem Kanali");
				}
				//Referans No
				if (StringUtils.isBlank(iMap.getString("REFERANS_NO"))) {
					CreditCardServicesUtil.raiseGMError("330", "Referans No");
				}
				//TCKN
				sorguMap.clear();
				sorguMap.put("TCKN", iMap.get("TCKN"));
				sorguMap.put("HATA_VERILSIN_MI", CreditCardServicesUtil.EVET);
				GMServiceExecuter.execute("BNSPR_TRN3870_TCKN_KONTROL", sorguMap);
				
				//Musteri No
				if (StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
					CreditCardServicesUtil.raiseGMError("330", "Musteri No");
				} else {
					//Girilen tcknye ait musteri var mi
					sorguMap.clear();
					sorguMap.put("TCKN", iMap.getString("TCKN"));
					sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
					sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
					BigDecimal musteriNo = sorguMap.getBigDecimal("CUSTOMER_NO");
		            if (musteriNo == null || musteriNo.equals(BigDecimal.ZERO)) {
		            	CreditCardServicesUtil.raiseGMError("5228", iMap.getString("TCKN"));
		            }
		            //Var olan musteri ile gelen musteri ayni mi
		            if (musteriNo.compareTo(iMap.getBigDecimal("MUSTERI_NO")) != 0) {
		            	CreditCardServicesUtil.raiseGMError("5229", iMap.getString("TCKN"), iMap.getBigDecimal("MUSTERI_NO"));
		            }
				}
					
				//Islem Tipi
				String islemTipi = iMap.getString("ISLEM_TIP");
				if (StringUtils.isBlank(islemTipi)) {
					CreditCardServicesUtil.raiseGMError("330", "Islem Tipi");
				} else {
					sorguMap.clear();
					sorguMap.put("KOD", "KART_BASVURU_TALEP_ISLEM_TIPI");
					sorguMap.put("KEY", islemTipi);
					sorguMap.putAll(CreditCardServicesUtil.isExistParamText(sorguMap));
					if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("IS_EXIST"))) {
						CreditCardServicesUtil.raiseGMError("3", "Islem Tipi", islemTipi);
					}
				}
				//Aktif talep var mi?
				sorguMap.clear();
				sorguMap.put("ID", iMap.get("ID"));
				sorguMap.put("ISLEM_TIPI", islemTipi);
				if ("P2D".equals(islemTipi)) {
					if(iMap.get("TFF_BASVURU_NO")!=null)
						sorguMap.put("REFERANS_NO", iMap.get("TFF_BASVURU_NO"));
					else
						sorguMap.put("REFERANS_NO", iMap.get("KK_BASVURU_NO"));
				} else if ("NKD".equals(islemTipi)) {
					sorguMap.put("REFERANS_NO", iMap.get("TCKN"));
				}
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_IS_EXIST_ACTIVE_REQUEST", sorguMap));
				//Kontrol
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("TALEP_VAR_MI"))) {
					CreditCardServicesUtil.raiseGMError("5221");
				}
				//Islem tipi bazli kontroller
				//P2D
				if ("P2D".equals(islemTipi)) {
					//TFF Basvuru No
					if (StringUtils.isBlank(iMap.getString("TFF_BASVURU_NO")) && StringUtils.isBlank(iMap.getString("KK_BASVURU_NO"))) {
						CreditCardServicesUtil.raiseGMError("330", "Prepaid Basvuru No");
					}
					//Kart No
					if (StringUtils.isBlank(iMap.getString("KART_NO"))) {
						CreditCardServicesUtil.raiseGMError("330", "Prepaid Kart No");
					}
					//Dbt Basvuru No
					if (StringUtils.isNotBlank(iMap.getString("DBT_BASVURU_NO"))) {
						CreditCardServicesUtil.raiseGMError("745", "Debit Basvuru No");
					}
					//Donusum yapilabilecek bir prepaid basvuru mu?
					sorguMap.clear();
					if(iMap.get("TFF_BASVURU_NO")!=null){
						sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_PREPAID_TO_DEBIT_VALIDATE_APPLICATION", sorguMap));
					}
					else
					{
						sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
						sorguMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_PREPAID_TO_DEBIT_VALIDATE_APPLICATION", sorguMap));
						
					}
					if (CreditCardServicesUtil.HAYIR.equals(sorguMap.getString("DONUSUM_YAPILABILIR_MI"))) {
						CreditCardServicesUtil.raiseGMError("3", "Prepaid Basvuru No", iMap.getString("TFF_BASVURU_NO"));
					}
				} else if ("NKD".equals(islemTipi)) {
					//TFF Basvuru No
					if (StringUtils.isNotBlank(iMap.getString("TFF_BASVURU_NO"))) {
						CreditCardServicesUtil.raiseGMError("745", "Prepaid Basvuru No");
					}
					//Kart No
					if (StringUtils.isNotBlank(iMap.getString("KART_NO"))) {
						CreditCardServicesUtil.raiseGMError("745", "Prepaid Kart No");
					}
					//Dbt Basvuru No
					if (StringUtils.isNotBlank(iMap.getString("DBT_BASVURU_NO"))) {
						CreditCardServicesUtil.raiseGMError("745", "Debit Basvuru No");
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Yeni bir kart talebi validasyonu yapar.<br>
	 * @author murat.el
	 * @since PY-11118
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>kart_basvuru_Talep tablosundaki kolon adlari ile datalarin mape koyulmasi gerek
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_IS_EXIST_ACTIVE_REQUEST")
	public static GMMap isExistsActiveRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		String isExistsActiveRequest = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.oncedenTalepVarMi(?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
			stmt.setString(3, iMap.getString("ISLEM_TIPI"));
			stmt.setString(4, iMap.getString("REFERANS_NO"));
			stmt.execute();

			isExistsActiveRequest = stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("TALEP_VAR_MI", CreditCardServicesUtil.nvl(isExistsActiveRequest, CreditCardServicesUtil.HAYIR));
		return oMap;
	}
	
	
	/** Yeni bir kart talebi validasyonu yapar.<br>
	 * @author murat.el
	 * @since PY-11118
	 * @param iMap - Basvuru bilgileri<br>
	 * 			<li>kart_basvuru_Talep tablosundaki kolon adlari ile datalarin mape koyulmasi gerek
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_GET_KART_BASVURU_TALEP_BY_ID")
	public static GMMap getKartBasvuruTalepById(GMMap iMap) {
		GMMap oMap = new GMMap();
		

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KART_BASVURU_TALEP.getKartBasvuruTalep(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
		
			stmt.execute();

			rs = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rs, "RESULT_TABLE");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_DEBIT_COMMON_PROCESS_CARD_REQUEST")
	public static GMMap processCardRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		
		//Talebi kontrol et
		try {
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_VALIDATE_CARD_REQUEST", iMap);
		} 
		
		
		
		catch (Exception e) {
			String durumAciklama = e.getMessage();
			if (durumAciklama.length() > 200) {
				durumAciklama = durumAciklama.substring(0, 200);
			}
			
			//Talebi guncelle
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", 99);
			sorguMap.put("DURUM_ACIKLAMA", durumAciklama);
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", sorguMap);
			return CreditCardServicesUtil.getErrorResponse(KART_BASVURU_TALEP_P2D_VALIDASYON_HATASI);
			
		}
		
		//Talebi isle
		String islemTipi = iMap.getString("ISLEM_TIP");
		iMap.put("SOURCE", iMap.get("KANAL"));
		
		if (OceanConstants.KART_BASVURU_TALEP_ISLEM_TIP_NKD.equals(islemTipi)) {//NKolay Debit
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_NKOLAY_PROCESS_REQUEST", iMap));
		} else if (OceanConstants.KART_BASVURU_TALEP_ISLEM_TIP_P2D.equals(islemTipi)) {//Prepaid To Debit
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			if(iMap.get("TFF_BASVURU_NO")!=null)
			{
			sorguMap.put("TFF_BASVURU_NO", iMap.get("TFF_BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_PREPAID_TO_DEBIT_PROCESS_REQUEST", sorguMap));
			}
			else 
			{
				sorguMap.put("KK_BASVURU_NO", iMap.get("KK_BASVURU_NO"));
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_NKOLAY_PREPAID_TO_DEBIT_PROCESS_REQUEST", sorguMap));
			}
			
		} else if (OceanConstants.KART_BASVURU_TALEP_ISLEM_TIP_NND.equals(islemTipi)) {//No Name Debit
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_NONAME_PROCESS_REQUEST", iMap));
		}
		
		return oMap;
	}
	
	/**
	 * Alinan bilgilerle debit basvuru bilgisini olusturur/gunceller.<br>
	 * 
	 * @author murat.el
	 * @since 
	 * @param iMap - Basvuru bilgileri<br>
	 * @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices#saveBasvuru(GMMap)} - Basvuru bilgisi
	 * @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices#saveKimlik(GMMap)} - Kimlik bilgisi
	 * @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices#saveMeslek(GMMap)} - Meslek bilgisi
	 * @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices#saveAdres(GMMap)} - Adres bilgisi
	 * @see {@link tr.com.aktifbank.bnspr.creditcard.services.CreditCardApplicationServices#saveTelefon(GMMap)} - Telefon bilgisi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_DEBIT_SAVE_OR_UPDATE_APPLICATION")
	public static GMMap saveOrUpdateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			//Islem no
			if (iMap.get("TRX_NO") == null) {
				sorguMap.clear();
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sorguMap));
			}
			oMap.put("TRX_NO", iMap.get("TRX_NO"));
			
			//Basvuru No
			if (iMap.get("BASVURU_NO") == null) {
				sorguMap.clear();
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3871_GET_BASVURU_NO", sorguMap));
				iMap.put("BASVURU_NO", sorguMap.getString("ID"));
			}
			oMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			
			//Durum Kod
			if (iMap.get("DURUM_KOD") == null || "BASVURU".equals(iMap.getString("DURUM_KOD"))) {
				iMap.put("DURUM_KOD", "BASVURU");
				iMap.put("ISLEM_FLAG", CreditCardServicesUtil.nvl(iMap.getString("ISLEM_FLAG"), "E"));//Yeni bir basvuru olusturulacak
			} else {
				iMap.put("ISLEM_FLAG", CreditCardServicesUtil.nvl(iMap.getString("ISLEM_FLAG"), "G"));//Mevcut bir basvuru guncellenecek
			}

			//Basvuru
			GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_BASVURU", iMap);
			//Kimlik
			GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_KIMLIK", iMap);
			//Meslek
			GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_MESLEK", iMap);
			//Ev Adres
			if (StringUtils.isNotBlank(iMap.getString("EV_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "E");
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", "E");
				sorguMap.put("IL_KOD", iMap.get("EV_IL"));
				sorguMap.put("ILCE_KOD", iMap.get("EV_ILCE"));
				sorguMap.put("ACIK_ADRES", iMap.get("EV_ADRES"));
				sorguMap.put("POSTA_KOD", iMap.get("EV_POSTA_KOD"));
				sorguMap.put("ILETISIM_MI", "E".equals(iMap.getString("ILETISIM_ADRES_KOD")) == true ? "E":"H");
				sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.EVET);
				sorguMap.put("TESLIMAT_ADRESI_MI", "E".equals(iMap.getString("TESLIMAT_ADRES_KOD")) == true ? "E":"H");
				GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_ADRES", sorguMap);
			}
			
			//Is Adres
			if (StringUtils.isNotBlank(iMap.getString("IS_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "E");
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", "I");
				sorguMap.put("IL_KOD", iMap.get("IS_IL"));
				sorguMap.put("ILCE_KOD", iMap.get("IS_ILCE"));
				sorguMap.put("ACIK_ADRES", iMap.get("IS_ADRES"));
				sorguMap.put("POSTA_KOD", iMap.get("IS_POSTA_KOD"));
				sorguMap.put("ILETISIM_MI", "I".equals(iMap.getString("ILETISIM_ADRES_KOD")) == true ? "E":"H");
				sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.put("TESLIMAT_ADRESI_MI", "I".equals(iMap.getString("TESLIMAT_ADRES_KOD")) == true ? "E":"H");
				GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_ADRES", sorguMap);
			}
			
			//Teslimat Adres
			if (StringUtils.isNotBlank(iMap.getString("DIGER_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "E");
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("ADRES_TIPI", "D");
				sorguMap.put("IL_KOD", iMap.get("DIGER_IL"));
				sorguMap.put("ILCE_KOD", iMap.get("DIGER_ILCE"));
				sorguMap.put("ACIK_ADRES", iMap.get("DIGER_ADRES"));
				sorguMap.put("POSTA_KOD", iMap.get("DIGER_POSTA_KOD"));
				sorguMap.put("ILETISIM_MI", "D".equals(iMap.getString("ILETISIM_ADRES_KOD")) == true ? "E":"H");
				sorguMap.put("EKSTRE_ADRESI_MI", CreditCardServicesUtil.HAYIR);
				sorguMap.put("TESLIMAT_ADRESI_MI", "D".equals(iMap.getString("TESLIMAT_ADRES_KOD")) == true ? "E":"H");
				GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_ADRES", sorguMap);
			}
			
			//Ev Tel
			if (StringUtils.isNotBlank(iMap.getString("EV_TEL_KOD")) && 
					StringUtils.isNotBlank(iMap.getString("EV_TEL_NO"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "E");
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TELEFON_TIPI", "E");
				sorguMap.put("ULKE_KOD", iMap.get("EV_ULKE_KOD"));
				sorguMap.put("ALAN_KOD", iMap.get("EV_TEL_KOD"));
				sorguMap.put("NUMARA", iMap.get("EV_TEL_NO"));
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.HAYIR);
				GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_TELEFON", sorguMap);
			}
			
			//Is Tel
			if (StringUtils.isNotBlank(iMap.getString("IS_TEL_KOD")) && 
					StringUtils.isNotBlank(iMap.getString("IS_TEL_NO"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "E");
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TELEFON_TIPI", "I");
				sorguMap.put("ULKE_KOD", iMap.get("IS_ULKE_KOD"));
				sorguMap.put("ALAN_KOD", iMap.get("IS_TEL_KOD"));
				sorguMap.put("NUMARA", iMap.get("IS_TEL_NO"));
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.HAYIR);
				GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_TELEFON", sorguMap);
			}
			
			//Cep Tel
			if (StringUtils.isNotBlank(iMap.getString("CEP_TEL_KOD")) && 
					StringUtils.isNotBlank(iMap.getString("CEP_TEL_NO"))) {
				sorguMap.clear();
				sorguMap.put("ISLEM_FLAG", "E");
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TELEFON_TIPI", "C");//Cep tel
				sorguMap.put("ULKE_KOD", iMap.get("CEP_ULKE_KOD"));
				sorguMap.put("ALAN_KOD", iMap.get("CEP_TEL_KOD"));
				sorguMap.put("NUMARA", iMap.get("CEP_TEL_NO"));
				sorguMap.put("ILETISIM_MI", CreditCardServicesUtil.EVET);
				GMServiceExecuter.execute("BNSPR_KK_SAVE_OR_UPDATE_TELEFON", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_CREATE_DEBIT_CARD")
	public static GMMap createDebitCard(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_KK_BASVURU.Get_Debit_Card_Info_For_Ocean(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			//Karti olustur
			logger.info("BNSPR_OCEAN_CREATE_DEBIT_CARD INPUT : " + iMap.toString());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_DEBIT_CARD", iMap));
			logger.info("BNSPR_OCEAN_CREATE_DEBIT_CARD OUTPUT : " + oMap.toString());
			
			//Hata varsa mail at
			if ("BASIM".equals(iMap.getString("DURUM_KOD")) && !"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "Debit Ocean Card Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
		
		return oMap;
	}
	
	/** Musterinin prepaid kartini debit karta cevirir.
	 * 
	 * @since TYWMC-694
	 * @author murat.el
	 * @param iMap - Basvuru/Donusum bilgileri<br>
	 * 			<li>ISLEM_TIPI<li>TFF_BASVURU_NO<li>MUSTERI_NO<li>TC_KIMLIK_NO<li>SOURCE
	 *			<li>AD<li>IKINCI_AD<li>SOYAD<li>ANNE_KIZLIK_SOYAD<li>EMAIL
	 *			<li>KIMLIK_SERI_NO<li>KIMLIK_SIRA_NO<li>CALISMA_SEKLI_KOD<li>ISYERI_ADI
	 *			<li>OGRENIM_DURUM_KOD<li>UNVAN_KOD<li>MESLEK_KOD<li>ISYERI_VERGI_DAIRESI_IL
	 *			<li>ISYERI_VERGI_DAIRESI_AD<li>CEP_ULKE_KOD<li>CEP_TEL_KOD<li>CEP_TEL_NO
	 *			<li>IS_ULKE_KOD<li>IS_TEL_KOD<li>IS_TEL_NO<li>IS_TEL_DAHILI
	 *			<li>EV_ULKE_KOD<li>EV_TEL_KOD<li>EV_TEL_NO<li>EV_IL<li>EV_ILCE
	 *			<li>EV_ADRES<li>EV_POSTA_KOD<li>IS_IL<li>IS_ILCE<li>IS_ADRES<li>IS_POSTA_KOD
	 *			<li>DIGER_IL<li>DIGER_ILCE<li>DIGER_ADRES<li>DIGER_POSTA_KOD
	 *			<li>TESLIMAT_ADRES_KOD<li>ILETISIM_ADRES_KOD
	 * @return oMap - Islem sonucu<br>
	 *          <li>RESPONSE - Islem Sonuc Kodu
	 *          <li>RESPONSE_DATA - Islem Sonuc Aciklama
	 */
	@GraymoundService("BNSPR_DEBIT_COMMON_VALIDATE_CARD_REQUEST_FROM_CHANNEL")
	public static GMMap makeRequestFromChannel(GMMap iMap) {
		GMMap sorguMap = new GMMap();

		try {
			//Source
			sorguMap.clear();
			sorguMap.put("SOURCE", iMap.get("SOURCE"));
			if (!isSourceValid(sorguMap)) {
				return CreditCardServicesUtil.getErrorResponse(WEB_SERVIS_GECERSIZ_SOURCE);
			}
			
			//Musteri No
			if (StringUtils.isBlank("MUSTERI_NO")) {
				return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_MUSTERI_BULUNAMADI);
			}
			
			//Tckn
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_COMMON_TCKN_KONTROL", sorguMap));
			if (RESPONSE_BASARISIZ.equals(sorguMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}
			
			//AKS
			if (StringUtils.isBlank(iMap.getString("ANNE_KIZLIK_SOYAD"))) {
				return CreditCardServicesUtil.getErrorResponse(ANNEKIZLIK_SOYADI_BOS_OLAMAZ);
			}
			
			//Email
			if (StringUtils.isNotBlank(iMap.getString("EMAIL")) && !isEmailValid(iMap.getString("EMAIL"))) {
				return CreditCardServicesUtil.getErrorResponse(EMAIL_HATALI_HATASI);
			}
			
			//kimlik seri no
			String kimlikSeriNo = iMap.getString("KIMLIK_SERI_NO");
			if (StringUtils.isBlank(kimlikSeriNo)) {
				return CreditCardServicesUtil.getErrorResponse(KIMLIK_SERI_NO_BOS_OLAMAZ);
			} else {
				if (StringUtils.isNumeric(kimlikSeriNo.substring(0,1)) || 
						!StringUtils.isNumeric(kimlikSeriNo.substring(1,2))  || 
						!StringUtils.isNumeric(kimlikSeriNo.substring(2,3))) {
					return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_KIMLIK_SERI_NO_YANLIS_HATASI);
				}
				
				String lastCharStr = kimlikSeriNo.substring(kimlikSeriNo.length() - 1) ;
				if (!StringUtils.isNumeric(lastCharStr)) {
					return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_KIMLIK_SERI_NO_YANLIS_HATASI);
				}

				
				
			}
			
			//kimlik sira no
			String kimlikSiraNo = iMap.getString("KIMLIK_SIRA_NO");
			if (StringUtils.isBlank(kimlikSiraNo)) {
				return CreditCardServicesUtil.getErrorResponse(KIMLIK_SIRA_NO_BOS_OLAMAZ);
			} 
			
			//calisma sekli
			boolean evAdresiVarMi = false;
			boolean isAdresiVarMi = false;
			boolean digerAdresVarMi = false;
			String calismaSekli = iMap.getString("CALISMA_SEKLI_KOD");
			if (StringUtils.isBlank(calismaSekli)) {
				return CreditCardServicesUtil.getErrorResponse(CALISMA_SEKLI_BOS_OLAMAZ);
			} else {
				if ("D".equals(calismaSekli) || "O".equals(calismaSekli) ||
						"K".equals(calismaSekli) || "S".equals(calismaSekli) ||
						"E2".equals(calismaSekli) || "E3".equals(calismaSekli) ) {
					//Meslek
					if (StringUtils.isBlank(iMap.getString("MESLEK_KOD"))) {
						return CreditCardServicesUtil.getErrorResponse(MESLEK_BOS_OLAMAZ);
					}
					//Isyeri adi
					if (StringUtils.isBlank(iMap.getString("ISYERI_ADI"))) {
						return CreditCardServicesUtil.getErrorResponse(ISYERI_ADI_BOS_OLAMAZ);
					}
					//Is adres
					sorguMap.clear();
					sorguMap.put("ADRES_TIPI", "I");
					sorguMap.put("IL_KOD", iMap.get("IS_IL"));
					sorguMap.put("ILCE_KOD", iMap.get("IS_ILCE"));
					sorguMap.put("ACIK_ADRES", iMap.get("IS_ADRES"));
					sorguMap.putAll(adresKontrol(sorguMap));
					if (!RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
						return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
					}
					isAdresiVarMi = true;
					//Is tel
					sorguMap.clear();
					sorguMap.put("TELEFON_TIPI", "I");
					sorguMap.put("ULKE_KOD", iMap.get("IS_ULKE_KOD"));
					sorguMap.put("ALAN_KOD", iMap.get("IS_TEL_KOD"));
					sorguMap.put("NUMARA", iMap.get("IS_TEL_NO"));
					sorguMap.put("IL_KOD", iMap.get("IS_IL"));
					sorguMap.putAll(telefonKontrol(sorguMap));
					if (!RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
						return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
					}
				}
				
				if ("S".equals(calismaSekli) || "E2".equals(calismaSekli)) {
					//vergi dairesi il
					if (StringUtils.isBlank(iMap.getString("ISYERI_VERGI_DAIRESI_IL"))) {
						return CreditCardServicesUtil.getErrorResponse(ISYERI_VERGI_DAIRESI_IL_BOS_OLAMAZ);
					}
					//vergi dairesi adi
					if (StringUtils.isBlank(iMap.getString("ISYERI_VERGI_DAIRESI_AD"))) {
						return CreditCardServicesUtil.getErrorResponse(ISYERI_VERGI_DAIRESI_ADI_BOS_OLAMAZ);
					}
				}
			}
			
			//ogrenim durumu
			if (StringUtils.isBlank(iMap.getString("OGRENIM_DURUM_KOD"))) {
				return CreditCardServicesUtil.getErrorResponse(OGRENIM_DURUMU_BOS_OLAMAZ);
			}
			
			//Cep tel
			sorguMap.clear();
			sorguMap.put("TELEFON_TIPI", "C");
			sorguMap.put("ULKE_KOD", iMap.get("CEP_ULKE_KOD"));
			sorguMap.put("ALAN_KOD", iMap.get("CEP_TEL_KOD"));
			sorguMap.put("NUMARA", iMap.get("CEP_TEL_NO"));
			sorguMap.putAll(telefonKontrol(sorguMap));
			if (!RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}
		
			//Ev Adres
			sorguMap.clear();
			sorguMap.put("ADRES_TIPI", "E");
			sorguMap.put("IL_KOD", iMap.get("EV_IL"));
			sorguMap.put("ILCE_KOD", iMap.get("EV_ILCE"));
			sorguMap.put("ACIK_ADRES", iMap.get("EV_ADRES"));
			sorguMap.putAll(adresKontrol(sorguMap));
			if (!RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
				return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
			}
			evAdresiVarMi = true;

			//Ev tel
			sorguMap.clear();
			sorguMap.put("TELEFON_TIPI", "E");
			sorguMap.put("ULKE_KOD", iMap.get("EV_ULKE_KOD"));
			sorguMap.put("ALAN_KOD", iMap.get("EV_TEL_KOD"));
			sorguMap.put("NUMARA", iMap.get("EV_TEL_NO"));
			if (StringUtils.isNotBlank(sorguMap.getString("ULKE_KOD")) || StringUtils.isNotBlank(sorguMap.getString("ALAN_KOD")) || StringUtils.isNotBlank(sorguMap.getString("NUMARA")) ){
				//ev telefonu girilmemi�se kontrole girmesin, zorunlu tutulmas�n
				sorguMap.putAll(telefonKontrol(sorguMap));
				if (!RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
				}
			}
			//Diger Adres
			if (StringUtils.isNotBlank(iMap.getString("DIGER_ADRES"))) {
				sorguMap.clear();
				sorguMap.put("ADRES_TIPI", "D");
				sorguMap.put("IL_KOD", iMap.get("DIGER_IL"));
				sorguMap.put("ILCE_KOD", iMap.get("DIGER_ILCE"));
				sorguMap.put("ACIK_ADRES", iMap.get("DIGER_ADRES"));
				sorguMap.putAll(adresKontrol(sorguMap));
				if (!RESPONSE_BASARILI.equals(sorguMap.getString("RESPONSE"))) {
					return CreditCardServicesUtil.getErrorResponse(sorguMap.getString("RESPONSE_DATA"));
				}
				digerAdresVarMi = true;
			}
			
			
			//Teslimat Adres
			String teslimatAdresi = iMap.getString("TESLIMAT_ADRES_KOD");
			if (StringUtils.isBlank(teslimatAdresi)) {
				return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_TESLIMAT_ADRESI_BOS_HATASI);
			} else {
				if (("E".equals(teslimatAdresi) && !evAdresiVarMi) || 
						("I".equals(teslimatAdresi) && !isAdresiVarMi) ||
						("D".equals(teslimatAdresi) && !digerAdresVarMi)) {
					return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_TESLIMAT_ADRESI_BULUNAMADI_HATASI);
				}
			}
			
			//Iletisim Adres
			String iletisimAdresi = iMap.getString("ILETISIM_ADRES_KOD");
			if (StringUtils.isBlank(iletisimAdresi)) {
				return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_TESLIMAT_ADRESI_BOS_HATASI);
			} else {
				if (("E".equals(iletisimAdresi) && !evAdresiVarMi) || 
						("I".equals(iletisimAdresi) && !isAdresiVarMi) ||
						("D".equals(iletisimAdresi) && !digerAdresVarMi)) {
					return CreditCardServicesUtil.getErrorResponse(BASVURU_OLUSTUR_TESLIMAT_ADRESI_BULUNAMADI_HATASI);
				}
			}
			
			//Girilen tcknye ait musteri var mi
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.getString("TCKN"));
			sorguMap.put("MUSTERI_TURUNE_GORE_MI", true);
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sorguMap));
			BigDecimal musteriNo = sorguMap.getBigDecimal("CUSTOMER_NO");
            if (musteriNo == null || musteriNo.equals(BigDecimal.ZERO)) {
            	return CreditCardServicesUtil.getErrorResponse(KART_TALEP_TCKN_MUSTERISI_BULUNAMADI);
            }
            //Var olan musteri ile gelen musteri ayni mi
            if (musteriNo.compareTo(iMap.getBigDecimal("MUSTERI_NO")) != 0) {
            	return CreditCardServicesUtil.getErrorResponse(KART_TALEP_TCKN_MUSTERISI_MUSTERI_NO_ILE_UYUMSUZ);
            }
			
            //Aktif talep var mi?
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("ISLEM_TIPI", iMap.get("ISLEM_TIPI"));
			if ("P2D".equals(iMap.getString("ISLEM_TIPI"))) {
				if(iMap.get("TFF_BASVURU_NO")!=null){
					sorguMap.put("REFERANS_NO", iMap.get("TFF_BASVURU_NO"));
				}
				else{
					sorguMap.put("REFERANS_NO", iMap.get("KK_BASVURU_NO"));
				}
			} else if ("NKD".equals(iMap.getString("ISLEM_TIPI"))) {
				sorguMap.put("REFERANS_NO", iMap.get("TCKN"));
			}
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_IS_EXIST_ACTIVE_REQUEST", sorguMap));
			//Kontrol
			if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("TALEP_VAR_MI"))) {
				return CreditCardServicesUtil.getErrorResponse(KART_TALEP_AKTIF_TALEP_VAR);
			}
			
			//Yasa D��� Kumar Bahis Kara Liste kayd� var m�? TYATLAS-52
			Session session = DAOSession.getSession(CreditCardServicesUtil.BNSPR_SESSION_NAME);
			List<GnlKaraListeGercek> karaliste = (List<GnlKaraListeGercek>) session.createCriteria(GnlKaraListeGercek.class).add(Restrictions.eq("tcknNo", iMap.getBigDecimal("TCKN"))).add(Restrictions.eq("kayitKategorisi", KARA_LISTE_YASA_DISI_KUMAR_BAHIS_KATEGORISI)).add(Restrictions.eq("kayitDurum", "A")).addOrder(Order.desc("kayitNo")).list();
			if (karaliste.size() > 0) {
				return CreditCardServicesUtil.getErrorResponse(KARA_LISTE_KONTROL_KIMLIK_KARALISTEDE_HATASI);
			}
		
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return CreditCardServicesUtil.getSuccessResponse(ISLEM_BASARILI);
	}
	
	@GraymoundService("BNSPR_DEBIT_COMMON_LIST_CARDS_FOR_EXCHANGE_BONO")
	public static GMMap listCardsForExchangeBono(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Intra kart sisteminde var mi?
			GMMap kartMap = new GMMap();
			GMMap sorguMap = new GMMap();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("KART_TIPI", "A");//Hepsi
			sorguMap.put("DURUM", "A");//Hepsi
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_INTRA_KART_LISTELE", sorguMap));//KART_LIST
			//Liste icerisinde kriterlere uygun kart var mi?
			int gecerliKartSayisi = 0;
			for (int i = 0 ; i < kartMap.getSize("KART_LIST"); i++) {
				//Gecerli bir kart mi
				sorguMap.clear();
				sorguMap.put("KOD", "DEBIT_KART_DONUSUM_DURUM_KOD");//NN,GJ
				sorguMap.put("KEY","N");
				sorguMap.put("KEY2", "N");
				sorguMap.put("KEY3", "I" + kartMap.getString("KART_LIST", i, "KART_TIPI")) ;
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
				//Gecerli ise al
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
					oMap.put("KART_LIST", gecerliKartSayisi++, kartMap.getMap("KART_LIST", i));
				}
			}
			
			//Ocean sisteminde var mi?
			kartMap.clear();
			sorguMap.clear();
			sorguMap.put("TCKN", iMap.get("TCKN"));
			sorguMap.put("KART_TIPI", "D");//Hepsi
			sorguMap.put("DURUM", "A");//Hepsi
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_KART_LISTELE", sorguMap));//KART_LIST
			sorguMap.put("KART_TIPI", "P");//Hepsi
			kartMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_KART_LISTELE", sorguMap));//KART_LIST
			//Liste icerisinde kriterlere uygun kart var mi?
			for (int i = 0 ; i < kartMap.getSize("KART_LIST"); i++) {
				//Gecerli bir kart mi
				sorguMap.clear();
				sorguMap.put("KOD", "DEBIT_KART_DONUSUM_DURUM_KOD");//NN,GJ
				sorguMap.put("KEY", "N");
				sorguMap.put("KEY2", "N");
				sorguMap.put("KEY3", "OD") ;//Ocean Debit
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", sorguMap));
				//Gecerli ise al
				if (CreditCardServicesUtil.EVET.equals(sorguMap.getString("IS_EXIST"))) {
					oMap.put("KART_LIST", gecerliKartSayisi++, kartMap.getMap("KART_LIST", i));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	@GraymoundService("BNSPR_GET_DEBIT_CARD_INFO")
	public static GMMap getDebitCardInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap queryMap = new GMMap();
		//Outputs
		String cardType = null;
		BigDecimal applicationNo = null;
		BigDecimal kkApplicationNo = null;
		String cardNo = null;
		GMMap pMap = new GMMap();

		try {
			//Parametre kontrol
			String tckn = iMap.getString("TCKN");
			if (StringUtils.isBlank(tckn)) {
				CreditCardServicesUtil.raiseGMError("330", "Tc Kimlik No");
			} else {
				//TCKN kontrolu
				queryMap.clear();
				queryMap.put("TC_KIMLIK_NO", tckn);
				queryMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", queryMap));
				if ("0".equals(queryMap.getString("SONUC"))) {
					CreditCardServicesUtil.raiseGMError("456", tckn);
				}
			}
			
			//Alinabilecek kartlari listele
			queryMap.clear();
			queryMap.put("TCKN", tckn);
			queryMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_LIST_CARDS_FOR_EXCHANGE_BONO", queryMap));
			//Kontrol
			String tableName = "KART_LIST";
			Date maxKayitTar = null;
			if (queryMap.get(tableName) != null && queryMap.getSize(tableName) > 0) {
				//Listedeki kayitlari kontrol et
				for (int i = 0; i < queryMap.getSize(tableName); i++) {
					//Debiti var mi, varsa hicbir kart verilmez
					if ("D".equals(queryMap.getString(tableName, i , "KART_TIPI"))) {
						if(maxKayitTar == null || maxKayitTar.before(queryMap.getDate(tableName, i, "KAYIT_TARIHI"))){
							cardType = null;
							applicationNo = queryMap.getBigDecimal(tableName, i , "BASVURU_NO");
							cardNo = queryMap.getString(tableName, i , "KART_NO");
							maxKayitTar = queryMap.getDate(tableName, i, "KAYIT_TARIHI");
						}
					} 
				}
				
				if(cardNo == null){
					maxKayitTar = null;
					for (int i = 0; i < queryMap.getSize(tableName); i++) {
						if ("P".equals(queryMap.getString(tableName, i , "KART_TIPI"))) {
							pMap.clear();
							// pp kartlar i�in urun id bilgisine bak�l�p, intra ocaen ayr�m� yap�ld�.910 Yim PP �ncelikli							
							GMMap nKolayMap = new GMMap();
							nKolayMap.put("PRODUCT_ID", queryMap.getString(tableName, i , "PRODUCT_ID"));
							nKolayMap.putAll(GMServiceExecuter.execute("BNSPR_IS_NKOLAY_PP_PRODUCT", nKolayMap));
							
							if("Y".equals(nKolayMap.getString("IS_NKOLAY")))
							{
							 pMap.put("KK_BASVURU_NO", queryMap.getBigDecimal(tableName, i , "BASVURU_NO"));
								cardType = "P";
								kkApplicationNo = queryMap.getBigDecimal(tableName, i , "BASVURU_NO");
								cardNo = queryMap.getString(tableName, i , "KART_NO");
								maxKayitTar = queryMap.getDate(tableName, i, "KAYIT_TARIHI");
								applicationNo= null;
								break;
								
							}
							else	
							{
							  pMap.put("TFF_BASVURU_NO", queryMap.getBigDecimal(tableName, i , "BASVURU_NO"));
							
							
							  pMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_PREPAID_TO_DEBIT_IS_PRODUCT_EXISTS", pMap));
							  if("E".equals(pMap.getString("IS_EXISTS"))){
								if(maxKayitTar == null || maxKayitTar.before(queryMap.getDate(tableName, i, "KAYIT_TARIHI"))){
									cardType = "P";
									applicationNo = queryMap.getBigDecimal(tableName, i , "BASVURU_NO");
									cardNo = queryMap.getString(tableName, i , "KART_NO");
									maxKayitTar = queryMap.getDate(tableName, i, "KAYIT_TARIHI");
								}
							  }
							}
						}
					}
				}
			} else {
				//Hicbir karti yok ise NKolay Debit Kart verilir
				cardType = "N";
			}
			
	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("CARD_TYPE", cardType);
		oMap.put("APPLICATION_NO", applicationNo);
		oMap.put("KK_APPLICATION_NO", kkApplicationNo);
		oMap.put("CARD_NO", cardNo);
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_PREPAID_TO_DEBIT_FROM_CHANNEL")
	public static GMMap prepaidToDebitFromChannels(GMMap iMap) {
		
		GMMap oMap  = new GMMap();
		try{
			iMap.put("SOURCE", iMap.getString("KANAL"));
			iMap.put("SORGU_TIPI", iMap.getString("ISLEM_TIPI"));

			if(iMap.get("TFF_BASVURU_NO")!=null){
				iMap.put("BASVURU_NO", iMap.getString("TFF_BASVURU_NO"));
				/*An�nda donusum yapilacaksa donusum senkron yap�l�p tamamlan�yor*/
				if ((ANINDA_DONUSUM.equals(GMServiceExecuter.call("BNSPR_TFF_DOKUMAN_ALINDI_MI_BY_KANAL", iMap).getString("ANINDA_DONUSUM")) || BHS_ALINMIS.equals(GMServiceExecuter.call("BNSPR_MUSTERI_BHS_KONTROL", iMap).getString("F_BHS"))) && !BASVURU_BEKLEMEDE.equals(iMap.getString("DURUM_KOD")))
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_PREPAID_TO_DEBIT_FOR_UNNEEDED_BHS", iMap));
				/*Aninda donusum yapilamayacaksa, asenkron olarak cagri yapiliyor*/
				else
					GMServiceExecuter.executeAsync("BNSPR_TFF_PREPAID_TO_DEBIT_FROM_CHANNEL", iMap);
			}
			/*Performans d�zenlemesi sadece Tff i�in yap�lm��t�r, passomobil ve mobil kdh*/
			else if(iMap.get("KK_BASVURU_NO")!=null){
				GMServiceExecuter.execute("BNSPR_OCEAN_PREPAID_TO_DEBIT_FROM_CHANNEL", iMap);
			}
			
			else{
				throw new Exception("Basvuru no bos olamaz");
			}
			
			
		}
		catch (Exception e) {
			throw new GMRuntimeException(99, e.getMessage());
		}

		return oMap;
	}

	public static boolean mevcutKartKurallaraUygunMu(String noNameUrunId, String kartTipi, String urunTipi, String extIssue, Boolean subeEkaniMi) {

		Boolean isNonameChannelsOpened = DbtCardNoNameServices.isNewNonameCardSource("WEBKREDI");

		if (isNonameChannelsOpened|| subeEkaniMi) {// kanallardan noname ak��� ba�lad� m�? webkredi-bono-kdh e�zamanl� ge�ece�i i�in sadece webkredi kontrol edildi
			if (noNameUrunId.equals(urunTipi) && OceanConstants.Akustik_Basvuru_DebitCard.equals(kartTipi))
				return true;	/*Noname harici Debiti varsa yine de Noname debit bas�lacak bu nedenle ba�ka Debit varsa da g�sterilmesin*/
			if ((!SANAL_YENILEME_YAPILMIS_AMA_BASILMAMIS.equals(extIssue)) && OceanConstants.Akustik_PrepaidCard.equals(kartTipi) )
				return true;
		}
		else {
			if (!SANAL_YENILEME_YAPILMIS_AMA_BASILMAMIS.equals(extIssue) && OceanConstants.Akustik_PrepaidCard.equals(kartTipi) || OceanConstants.Akustik_Basvuru_DebitCard.equals(kartTipi))
				return true;
		}
	

		return false;

	}
		
		
		
}
