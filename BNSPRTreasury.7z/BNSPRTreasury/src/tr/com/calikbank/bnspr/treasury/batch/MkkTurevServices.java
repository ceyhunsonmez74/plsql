package tr.com.calikbank.bnspr.treasury.batch;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkTurevServices {

	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	//private static Logger logger = Logger.getLogger(VostroMasrafTahsilatBatch.class);
	
	@GraymoundService("BNSPR_BATCH_MKK_TUREV_MAIL")
	public static GMMap mkkTurevMail(GMMap iMap) {
		GMMap xMap = new GMMap();
		try {
		//	logger.info("BNSPR_BATCH_MKK_TUREV_MAIL ba�lad�");
			String mkkTurevDosyaAdi = "MkkTurev";
			
			GMMap oMap = new GMMap();
			GMMap mkkMap = new GMMap();
			GMMap mkkInMap = new GMMap();
			GMMap mkkOutMap = new GMMap();
			
			byte[] mkkBytes = null;

			Date banka_tarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH");
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			mkkTurevDosyaAdi = mkkTurevDosyaAdi + "_" + df.format(banka_tarih) + "_";
			System.out.println(banka_tarih);
			Object[] inputs = new Object[] { BnsprType.DATE, banka_tarih };
			mkkMap = DALUtil.callOracleRefCursorFunction("{?=call bnspr.pkg_mkk_turev.mkk_turev_liste(?)}", "TABLE_DATA", inputs);
			
			if (mkkMap.size() > 0) {
			
				LinkedHashMap<String, String[]> mkkHeaders = new LinkedHashMap<String, String[]>();					
				mkkHeaders=listHeaders(mkkHeaders);
				
				mkkInMap.put("TABLE_DATA", mkkMap.get("TABLE_DATA"));
				mkkInMap.put("HEADERS", mkkHeaders);
				mkkInMap.put("FILE_NAME", mkkTurevDosyaAdi);
				mkkInMap.put("CHANGE_PAGE_DIRECTION", false);

				mkkOutMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", mkkInMap));
				mkkTurevDosyaAdi = mkkTurevDosyaAdi + "1.xls";
				mkkBytes = FileUtil.readFileToByteArray(ROOT + File.separator + "files" + File.separator + mkkTurevDosyaAdi);
			}

			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", "akustik@aktifbank.com.tr");
		
			xMap.put("PARAMETRE", "MKK_TUREV_MAIL");
			servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
			//servisMap.put("MAIL_TO", "mustafa.yilmaz@aktifbank.com.tr");
			servisMap.put("IS_BODY_HTML", "H");

			String mailSubject = df.format(banka_tarih) + " Tarihli MKK t�rev dosyas�";

			if (mkkMap.size() > 0) {
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", mkkTurevDosyaAdi);
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", mkkBytes);
			}
			servisMap.put("MAIL_SUBJECT", mailSubject);
			servisMap.put("MAIL_BODY", mailSubject + "n� bilgilerinize sunar�z.");

			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			xMap.put("RESPONSE", 0);
			xMap.put("RESPONSE_DATA", "SUCCESS");

			return oMap;
		}
		catch (Exception e) {	
			xMap.put("RESPONSE", 0);
			xMap.put("RESPONSE_DATA", e.getLocalizedMessage());
			throw ExceptionHandler.convertException(e);
		}
	}
	private static LinkedHashMap<String, String[]> listHeaders (LinkedHashMap<String, String[]> mkkHeaders){
		mkkHeaders.put("REPORTINGCOUNTERPARTYID",new String[] {"REPORTINGCOUNTERPARTYID*"});
		mkkHeaders.put("SENDERREFERENCE",new String[] {"SENDERREFERENCE*"});
		mkkHeaders.put("CHANNEL",new String[] {"CHANNEL*"});
		mkkHeaders.put("BOTHSIDEFLAG",new String[] {"BOTHSIDEFLAG*"});
		mkkHeaders.put("ACTIONTYPE",new String[] {"ACTIONTYPE*"});
		mkkHeaders.put("LEVL",new String[] {"LEVL*"});
		mkkHeaders.put("SENDERMESSAGEREF",new String[] {"SENDERMESSAGEREF*"});
		mkkHeaders.put("COUNTERPARTYIDTYPE",new String[] {"COUNTERPARTYIDTYPE*"});
		mkkHeaders.put("COUNTERPARTYID",new String[] {"COUNTERPARTYID*"});
		mkkHeaders.put("NAMEOFTHECOUNTERPARTY",new String[] {"NAMEOFTHECOUNTERPARTY*"});
		mkkHeaders.put("COUNTRYTHECOUNTERPARTY",new String[] {"COUNTRYTHECOUNTERPARTY*"});
		mkkHeaders.put("NATUREOFREPORTINGCOUNTERPARTY",new String[] {"NATUREOFREPORTINGCOUNTERPARTY*"});
		mkkHeaders.put("CORPORATESECTOR",new String[] {"CORPORATESECTOR*"});
		mkkHeaders.put("BENEFICIARYIDTYPE",new String[] {"BENEFICIARYIDTYPE*"});
		mkkHeaders.put("BENEFICIARYNAME",new String[] {"BENEFICIARYNAME*"});			
		mkkHeaders.put("BENEFICIARYID",new String[] {"BENEFICIARYID"});
		mkkHeaders.put("BRANCHOFFICE",new String[] {"BRANCHOFFICE*"});
		mkkHeaders.put("TRADINGCAPACITY",new String[] {"TRADINGCAPACITY*"});
		mkkHeaders.put("CLIENTLIMIT",new String[] {"CLIENTLIMIT*"});
		mkkHeaders.put("OTHERCLIENTLIMIT",new String[] {"OTHERCLIENTLIMIT*"});
		mkkHeaders.put("COUNTERPARTYSIDE",new String[] {"COUNTERPARTYSIDE*"});
		mkkHeaders.put("DIRECTLYLINKEDTOCOMACT",new String[] {"DIRECTLYLINKEDTOCOMACT*"});
		mkkHeaders.put("HEDGEDETAIL",new String[] {"HEDGEDETAIL"});
		mkkHeaders.put("HEDGEINFO",new String[] {"HEDGEINFO"});
		mkkHeaders.put("COLLATERALISATION",new String[] {"COLLATERALISATION*"});
		mkkHeaders.put("COLLATERALPORTFOLIO",new String[] {"COLLATERALPORTFOLIO"});
		mkkHeaders.put("COLLATERALPORTFOLIOCODE",new String[] {"COLLATERALPORTFOLIOCODE"});
		mkkHeaders.put("OTHERCOUNTERPARTYIDTYPE",new String[] {"OTHERCOUNTERPARTYIDTYPE"});
		mkkHeaders.put("OTHERCOUNTERPARTYID",new String[] {"OTHERCOUNTERPARTYID"});
		mkkHeaders.put("NAMEOFTHEOTHERCOUNTERPARTY",new String[] {"NAMEOFTHEOTHERCOUNTERPARTY*"});
		mkkHeaders.put("COUNTRYOFTHEOTHERCOUNTERPARTY",new String[] {"COUNTRYOFTHEOTHERCOUNTERPARTY"});
		mkkHeaders.put("NATUREOFREPORTINGOTHERCOUNTER",new String[] {"NATUREOFREPORTINGOTHERCOUNTER"});
		mkkHeaders.put("OTHERCORPORATESECTOR",new String[] {"OTHERCORPORATESECTOR*"});
		mkkHeaders.put("OTHERBENEFICIARYIDTYPE",new String[] {"OTHERBENEFICIARYIDTYPE*"});
		mkkHeaders.put("OTHERBENEFICIARYNAME",new String[] {"OTHERBENEFICIARYNAME*"});
		mkkHeaders.put("OTHERBENEFICIARYID",new String[] {"OTHERBENEFICIARYID"});
		mkkHeaders.put("OTHERBRANCHOFFICE",new String[] {"OTHERBRANCHOFFICE*"});
		mkkHeaders.put("OTHERTRADINGCAPACITY",new String[] {"OTHERTRADINGCAPACITY*"});
		mkkHeaders.put("CONTRACTWITHNONEEACOUNTERPARTY",new String[] {"CONTRACTWITHNONEEACOUNTERPARTY*"});
		mkkHeaders.put("OFFSHORESTATUS",new String[] {"OFFSHORESTATUS"});
		mkkHeaders.put("SECTORANDOFFSHORECODE",new String[] {"SECTORANDOFFSHORECODE"});
		mkkHeaders.put("OTHERHEDGEDETAIL",new String[] {"OTHERHEDGEDETAIL"});
		mkkHeaders.put("OTHERHEDGEINFO",new String[] {"OTHERHEDGEINFO"});
		mkkHeaders.put("OTHERLINKEDTOCOMACT",new String[] {"OTHERLINKEDTOCOMACT*"});
		mkkHeaders.put("OTHERCOLLATERALISATION",new String[] {"OTHERCOLLATERALISATION"});
		mkkHeaders.put("OTHERCOLLATERALPORTFOLIO",new String[] {"OTHERCOLLATERALPORTFOLIO"});
		mkkHeaders.put("OTHERCOLLATERALCODE",new String[] {"OTHERCOLLATERALCODE"});
		mkkHeaders.put("BROKERID",new String[] {"BROKERID"});
		mkkHeaders.put("BROKERIDTYPE",new String[] {"BROKERIDTYPE"});
		mkkHeaders.put("BROKERNAME",new String[] {"BROKERNAME"});
		mkkHeaders.put("CLEARINGMEMBERID",new String[] {"CLEARINGMEMBERID"});
		mkkHeaders.put("CLEARINGMEMBERIDTYPE",new String[] {"CLEARINGMEMBERIDTYPE"});
		mkkHeaders.put("CLEARINGMEMBERNAME",new String[] {"CLEARINGMEMBERNAME"});
		mkkHeaders.put("CLEARINGTHRESHOLD",new String[] {"CLEARINGTHRESHOLD*"});
		mkkHeaders.put("CONTRACTTYPE",new String[] {"CONTRACTTYPE*"});
		mkkHeaders.put("ASSETCLASS",new String[] {"ASSETCLASS*"});
		mkkHeaders.put("PRODUCTCLASSIFICATIONTYPE",new String[] {"PRODUCTCLASSIFICATIONTYPE"});
		mkkHeaders.put("PRODUCTCLASSIFICATION",new String[] {"PRODUCTCLASSIFICATION"});
		mkkHeaders.put("PRODUCTIDENTIFICATIONTYPE",new String[] {"PRODUCTIDENTIFICATIONTYPE"});
		mkkHeaders.put("PRODUCTIDENTIFICATION",new String[] {"PRODUCTIDENTIFICATION"});
		mkkHeaders.put("UNDERLYINGIDENTIFICATIONTYPE",new String[] {"UNDERLYINGIDENTIFICATIONTYPE"});
		mkkHeaders.put("UNDERLYINGIDENTIFICATION",new String[] {"UNDERLYINGIDENTIFICATION"});
		mkkHeaders.put("NOTIONALCURRENCY1",new String[] {"NOTIONALCURRENCY1*"});
		mkkHeaders.put("NOTIONALCURRENCY2",new String[] {"NOTIONALCURRENCY2"});
		mkkHeaders.put("DELIVERABLECURRENCY",new String[] {"DELIVERABLECURRENCY"});
		mkkHeaders.put("TRADEID",new String[] {"TRADEID"});
		mkkHeaders.put("REPORTTRACKINGNUMBER",new String[] {"REPORTTRACKINGNUMBER*"});
		mkkHeaders.put("COMPLEXTRADECOMPONENTID",new String[] {"COMPLEXTRADECOMPONENTID"});
		mkkHeaders.put("VENUEOFEXECUTION",new String[] {"VENUEOFEXECUTION*"});
		mkkHeaders.put("REDISCOUNTAMOUNT",new String[] {"REDISCOUNTAMOUNT"});
		mkkHeaders.put("OPTIONCONDITION",new String[] {"OPTIONCONDITION*"});
		mkkHeaders.put("COMPRESSION",new String[] {"COMPRESSION*"});
		mkkHeaders.put("PRICERATE",new String[] {"PRICERATE*"});
		mkkHeaders.put("PRICENOTATION",new String[] {"PRICENOTATION*"});
		mkkHeaders.put("CURRENCYOFPRICE",new String[] {"CURRENCYOFPRICE"});
		mkkHeaders.put("NOMINALCHANGEPOSSIBILITY",new String[] {"NOMINALCHANGEPOSSIBILITY*"});
		mkkHeaders.put("NOTIONAL",new String[] {"NOTIONAL*"});
		mkkHeaders.put("PRICEMULTIPLIER",new String[] {"PRICEMULTIPLIER*"});
		mkkHeaders.put("QUANTITY",new String[] {"QUANTITY*"});
		mkkHeaders.put("UPFRONTPAYMENT",new String[] {"UPFRONTPAYMENT"});
		mkkHeaders.put("DELIVERYTYPE",new String[] {"DELIVERYTYPE*"});
		mkkHeaders.put("EXECUTIONDATE",new String[] {"EXECUTIONDATE"});
		mkkHeaders.put("EXECUTIONTIME",new String[] {"EXECUTIONTIME*"});
		mkkHeaders.put("EFFECTIVEDATE",new String[] {"EFFECTIVEDATE*"});
		mkkHeaders.put("MATURITYDATE",new String[] {"MATURITYDATE"});
		mkkHeaders.put("TERMINATIONDATE",new String[] {"TERMINATIONDATE"});
		mkkHeaders.put("SETTLEMENTDATE",new String[] {"SETTLEMENTDATE"});
		mkkHeaders.put("MASTERAGREEMENTTYPE",new String[] {"MASTERAGREEMENTTYPE"});
		mkkHeaders.put("MASTERAGRREMENTVERSION",new String[] {"MASTERAGRREMENTVERSION"});
		mkkHeaders.put("CONFIRMATIONDATE",new String[] {"CONFIRMATIONDATE"});
		mkkHeaders.put("CONFIRMATIONTIME",new String[] {"CONFIRMATIONTIME"});
		mkkHeaders.put("CONFIRMATIONMEANS",new String[] {"CONFIRMATIONMEANS*"});
		mkkHeaders.put("CLEARINGOBLIGATION",new String[] {"CLEARINGOBLIGATION*"});
		mkkHeaders.put("CLEARED",new String[] {"CLEARED*"});
		mkkHeaders.put("CLEARINGDATE",new String[] {"CLEARINGDATE"});
		mkkHeaders.put("CLEARINGTIME",new String[] {"CLEARINGTIME"});
		mkkHeaders.put("CCPID",new String[] {"CCPID"});
		mkkHeaders.put("CCPTITLE",new String[] {"CCPTITLE"});
		mkkHeaders.put("FIXEDRATEOFLEG1",new String[] {"FIXEDRATEOFLEG1"});
		mkkHeaders.put("FIXEDRATEOFLEG2",new String[] {"FIXEDRATEOFLEG2"});
		mkkHeaders.put("FXRATEDAYCOUNTLEG1",new String[] {"FXRATEDAYCOUNTLEG1"});
		mkkHeaders.put("FXRATEDAYCOUNTLEG2",new String[] {"FXRATEDAYCOUNTLEG2"});
		mkkHeaders.put("FXRATEPAYMENTFREQLEG1TP",new String[] {"FXRATEPAYMENTFREQLEG1TP"});
		mkkHeaders.put("FXRATEPAYMENTFREQLEG1M",new String[] {"FXRATEPAYMENTFREQLEG1M"});
		mkkHeaders.put("FXRATEPAYMENTFREQLEG2TP",new String[] {"FXRATEPAYMENTFREQLEG2TP"});
		mkkHeaders.put("FXRATEPAYMENTFREQLEG2M",new String[] {"FXRATEPAYMENTFREQLEG2M"});
		mkkHeaders.put("FRATEPAYMENTFREQLEG1TP",new String[] {"FRATEPAYMENTFREQLEG1TP"});
		mkkHeaders.put("FRATEPAYMENTFREQLEG1M",new String[] {"FRATEPAYMENTFREQLEG1M"});
		mkkHeaders.put("FRATEPAYMENTFREQLEG2TP",new String[] {"FRATEPAYMENTFREQLEG2TP"});
		mkkHeaders.put("FRATEPAYMENTFREQLEG2M",new String[] {"FRATEPAYMENTFREQLEG2M"});
		mkkHeaders.put("FRATERESETFREQLEG1TP",new String[] {"FRATERESETFREQLEG1TP"});
		mkkHeaders.put("FRATERESETFREQLEG1M",new String[] {"FRATERESETFREQLEG1M"});
		mkkHeaders.put("FRATERESETFREQLEG2TP",new String[] {"FRATERESETFREQLEG2TP"});
		mkkHeaders.put("FRATERESETFREQLEG2M",new String[] {"FRATERESETFREQLEG2M"});
		mkkHeaders.put("FLOATINGRATEOFLEG1",new String[] {"FLOATINGRATEOFLEG1"});
		mkkHeaders.put("FRATEREFPERIODLEG1TP",new String[] {"FRATEREFPERIODLEG1TP"});
		mkkHeaders.put("FRATEREFPERIODLEG1M",new String[] {"FRATEREFPERIODLEG1M"});
		mkkHeaders.put("FLOATINGRATEOFLEG2",new String[] {"FLOATINGRATEOFLEG2"});
		mkkHeaders.put("FRATEREFPERIODLEG2TP",new String[] {"FRATEREFPERIODLEG2TP"});
		mkkHeaders.put("FRATEREFPERIODLEG2M",new String[] {"FRATEREFPERIODLEG2M"});
		mkkHeaders.put("ADDBONUSRATEREFLEG1",new String[] {"ADDBONUSRATEREFLEG1"});
		mkkHeaders.put("ADDBONUSRATEREFLEG2",new String[] {"ADDBONUSRATEREFLEG2"});
		mkkHeaders.put("CURRENCY2",new String[] {"CURRENCY2"});
		mkkHeaders.put("EXCHANGERATE1",new String[] {"EXCHANGERATE1"});
		mkkHeaders.put("FORWARDEXCHANGERATE",new String[] {"FORWARDEXCHANGERATE"});
		mkkHeaders.put("EXCHANGERATEBASIS1",new String[] {"EXCHANGERATEBASIS1"});
		mkkHeaders.put("EXCHANGERATEBASIS2",new String[] {"EXCHANGERATEBASIS2"});
		mkkHeaders.put("COMMODITYBASE",new String[] {"COMMODITYBASE"});
		mkkHeaders.put("COMMODITYDETAILS",new String[] {"COMMODITYDETAILS"});
		mkkHeaders.put("DELIVERYPOINTORZONE",new String[] {"DELIVERYPOINTORZONE"});
		mkkHeaders.put("INTERCONNECTIONPOINT",new String[] {"INTERCONNECTIONPOINT"});
		mkkHeaders.put("LOADTYPE",new String[] {"LOADTYPE"});
		mkkHeaders.put("LOADDELIVERYRATE",new String[] {"LOADDELIVERYRATE"});
		mkkHeaders.put("DELIVERYSTARTDATE",new String[] {"DELIVERYSTARTDATE"});
		mkkHeaders.put("DELIVERYSTARTTIME",new String[] {"DELIVERYSTARTTIME"});
		mkkHeaders.put("DELIVERYENDDATE",new String[] {"DELIVERYENDDATE"});
		mkkHeaders.put("DELIVERYENDTIME",new String[] {"DELIVERYENDTIME"});
		mkkHeaders.put("DELIVERYPERIOD",new String[] {"DELIVERYPERIOD"});
		mkkHeaders.put("DELIVERYDAYS",new String[] {"DELIVERYDAYS"});
		mkkHeaders.put("CONTRACTCAPACITY",new String[] {"CONTRACTCAPACITY"});
		mkkHeaders.put("QUANTITYUNIT",new String[] {"QUANTITYUNIT"});
		mkkHeaders.put("PRICETIMEINTERVALQUANTITIES",new String[] {"PRICETIMEINTERVALQUANTITIES"});
		mkkHeaders.put("OPTIONTYPE",new String[] {"OPTIONTYPE"});
		mkkHeaders.put("OPTIONEXERCISESTYLE",new String[] {"OPTIONEXERCISESTYLE"});
		mkkHeaders.put("STRIKEPRICE",new String[] {"STRIKEPRICE"});
		mkkHeaders.put("STRIKEPRICENOTATION",new String[] {"STRIKEPRICENOTATION"});
		mkkHeaders.put("MATURITYDATEOFUNDERLYING",new String[] {"MATURITYDATEOFUNDERLYING"});
		mkkHeaders.put("DELTA",new String[] {"DELTA"});
		mkkHeaders.put("GAMA",new String[] {"GAMA"});
		mkkHeaders.put("SENIORITY",new String[] {"SENIORITY"});
		mkkHeaders.put("REFERENCEENTITY",new String[] {"REFERENCEENTITY"});
		mkkHeaders.put("FREQUENCYOFPAYMENT",new String[] {"FREQUENCYOFPAYMENT"});
		mkkHeaders.put("CALCULATIONBASIS",new String[] {"CALCULATIONBASIS"});
		mkkHeaders.put("SERIES",new String[] {"SERIES"});
		mkkHeaders.put("VERSION",new String[] {"VERSION"});
		mkkHeaders.put("INDEXFACTOR",new String[] {"INDEXFACTOR"});
		mkkHeaders.put("TRANCHE",new String[] {"TRANCHE"});
		mkkHeaders.put("ATTACHMENTPOINT",new String[] {"ATTACHMENTPOINT"});
		mkkHeaders.put("DETACHMENTPOINT",new String[] {"DETACHMENTPOINT"});
		mkkHeaders.put("MARKTOMARKETVALUE",new String[] {"MARKTOMARKETVALUE*"});
		mkkHeaders.put("CURRENCYOFMARKTOMARKETVALUE",new String[] {"CURRENCYOFMARKTOMARKETVALUE*"});
		mkkHeaders.put("VALUATIONDATE",new String[] {"VALUATIONDATE*"});
		mkkHeaders.put("VALUATIONTIME",new String[] {"VALUATIONTIME*"});
		mkkHeaders.put("VALUATIONTYPE",new String[] {"VALUATIONTYPE*"});
		mkkHeaders.put("INITIALMARGINPOSTED",new String[] {"INITIALMARGINPOSTED"});
		mkkHeaders.put("INITIALMARGINPOSTEDCUR",new String[] {"INITIALMARGINPOSTEDCUR"});
		mkkHeaders.put("VARIATIONMARGINPOSTED",new String[] {"VARIATIONMARGINPOSTED"});
		mkkHeaders.put("VARIATIONMARGINPOSTEDCUR",new String[] {"VARIATIONMARGINPOSTEDCUR"});
		mkkHeaders.put("INITIALMARGINRECEIVED",new String[] {"INITIALMARGINRECEIVED"});
		mkkHeaders.put("INITIALMARGINRECEIVEDCUR",new String[] {"INITIALMARGINRECEIVEDCUR"});
		mkkHeaders.put("VARIATIONMARGINRECEIVED",new String[] {"VARIATIONMARGINRECEIVED"});
		mkkHeaders.put("VARIATIONMARGINRECEIVEDCUR",new String[] {"VARIATIONMARGINRECEIVEDCUR"});
		mkkHeaders.put("EXCESSCOLLATERALPOSTED",new String[] {"EXCESSCOLLATERALPOSTED"});
		mkkHeaders.put("EXCESSCOLLATERALPOSTEDCUR",new String[] {"EXCESSCOLLATERALPOSTEDCUR"});
		mkkHeaders.put("EXCESSCOLLATERALRECEIVED",new String[] {"EXCESSCOLLATERALRECEIVED"});
		mkkHeaders.put("EXCESSCOLLATERALRECEIVEDCUR",new String[] {"EXCESSCOLLATERALRECEIVEDCUR"});
		mkkHeaders.put("OTHERINVESTMENTPURPOSE",new String[] {"OTHERINVESTMENTPURPOSE"});
		mkkHeaders.put("INVESTMENTPURPOSE",new String[] {"INVESTMENTPURPOSE"});
		mkkHeaders.put("OTHERRISKGROUPCODE",new String[] {"OTHERRISKGROUPCODE"});
		mkkHeaders.put("ELIGIBILITYDATE",new String[] {"ELIGIBILITYDATE"});
		mkkHeaders.put("CURRENCYOFORIGINALNOTIONAL",new String[] {"CURRENCYOFORIGINALNOTIONAL"});
		mkkHeaders.put("ORIGINALNOTIONAL",new String[] {"ORIGINALNOTIONAL"});

		return mkkHeaders;
				
	}
}
