package tr.com.calikbank.bnspr.treasury.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import jxl.Cell;
import jxl.NumberCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznYieldRateTx;
import tr.com.aktifbank.bnspr.dao.HznYieldRateTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1585Services {

	@GraymoundService("BNSPR_TRN1585_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		int size = iMap.getSize("TABLE");
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			for (int row = 0; row < size; row++) {

				HznYieldRateTx hznYieldRateTx = new HznYieldRateTx();
				HznYieldRateTxId hznYieldRateTxId = new HznYieldRateTxId();
				hznYieldRateTxId.setDeger(new BigDecimal(iMap.getString("TABLE", row, "DEGER")));
				hznYieldRateTx.setVkgs(new BigDecimal(iMap.getString("TABLE", row, "VKGS")));
				hznYieldRateTxId.setTenor(iMap.getString("TABLE", row, "TENOR"));
				hznYieldRateTxId.setYieldAdi(iMap.getString("TABLE", row, "YIELD_ADI"));
				hznYieldRateTx.setDovizKodu(iMap.getString("TABLE", row, "DOVIZ_KODU"));
				hznYieldRateTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				hznYieldRateTx.setId(hznYieldRateTxId);

				session.saveOrUpdate(hznYieldRateTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "1585");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1585_LOAD_EXCEL")
	public static GMMap loadExcelFile(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			byte[] inputFile = (byte[]) iMap.get("DOSYA_YOLU");
			if (inputFile == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Dosya secmediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			Workbook workbook;
			WorkbookSettings ws = new WorkbookSettings();

			// ws.setCharacterSet(cs);
			ws.setEncoding("ISO-8859-9");
			ws.setExcelDisplayLanguage("TR");
			ws.setExcelRegionalSettings("TR");
			// ws.setLocale(new Locale("tr", "TR"));
			try {
				workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
			}

			catch (Exception e) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Gecerli Bir Excel Dosyasi Secmediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Sheet sheet = workbook.getSheet(0);

			for (int j = 0; j < sheet.getRows() - 1; j++) {
				oMap.put("TABLE", j, "YIELD_ADI", sheet.getCell(1, j + 1).getContents());
				oMap.put("TABLE", j, "TENOR", sheet.getCell(2, j + 1).getContents());
				oMap.put("TABLE", j, "VKGS", sheet.getCell(3, j + 1).getContents());

				Cell cell = sheet.getCell(4, j + 1);
				NumberCell nc = null;
				nc = (NumberCell) cell;

				oMap.put("TABLE", j, "DEGER", Float.parseFloat(String.valueOf(nc.getValue())));
				oMap.put("TABLE", j, "DOVIZ_KODU", checkDovizKodu(sheet, j));

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}

	private static String checkDovizKodu(Sheet sheet, int j) {

		String dovizKodu = null;

		try {

			if (sheet.getCell(5, j + 1) != null && sheet.getCell(5, j + 1).getContents() != null) {
				dovizKodu = sheet.getCell(5, j + 1).getContents();
			}
		}
		catch (Exception e) {
			return dovizKodu;
		}
		return dovizKodu;
	}

	@GraymoundService("BNSPR_TRN1585_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1585_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<HznYieldRateTx> list = session.createCriteria(HznYieldRateTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int row = 0;
			while (row < list.size()) {

				oMap.put("TABLE", row, "YIELD_ADI", list.get(row).getId().getYieldAdi());
				oMap.put("TABLE", row, "TENOR", list.get(row).getId().getTenor());
				oMap.put("TABLE", row, "VKGS", list.get(row).getVkgs());
				oMap.put("TABLE", row, "DEGER", list.get(row).getId().getDeger());
				oMap.put("TABLE", row, "DOVIZ_KODU", list.get(row).getDovizKodu());

				row++;
			}
			return oMap;
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_Q1583_GET_DATA")
	public static GMMap getdata(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			String func = "{? = call PKG_TRN1585.search1853(?,?,?) }";
			Object[] inputValues = new Object[] { BnsprType.STRING, iMap.getString("REFERANS"), BnsprType.DATE, iMap.getDate("TARIH"), BnsprType.DATE, iMap.getDate("TARIH2") };

			Object resultMap = DALUtil.callOracleRefCursorFunction(func, "SONUC_TABLE", inputValues);

			oMap.putAll((GMMap) resultMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
}