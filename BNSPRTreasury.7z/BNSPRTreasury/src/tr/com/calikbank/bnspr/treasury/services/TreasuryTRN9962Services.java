package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SpkRiskGrubu;
import tr.com.aktifbank.bnspr.dao.SpkRiskGrubuUrun;
import tr.com.aktifbank.bnspr.dao.SpkRiskGrubuUrunTx;
import tr.com.aktifbank.bnspr.dao.SpkRiskGrubuUrunTxId;
import tr.com.aktifbank.bnspr.dao.SpkRiskUrun;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN9962Services {
	
	@GraymoundService("BNSPR_TRN9962_INIT")
	public static GMMap init(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		executeInitialize();
		fillRiskUrunleri(oMap);
		fillRiskGruplari(oMap);
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN9962_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			String oldTableName = "OLD_LIST";
			int row = 0, oldRow = 0;
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				/*
				 * tx-e gore mevcut-liste cekilir
				 */
				List<?> list = session.createCriteria(SpkRiskGrubuUrunTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SpkRiskGrubuUrunTx spkRiskGrubuUrun = (SpkRiskGrubuUrunTx) iterator.next();
					
					oMap.put(tableName, row, "GRUP_NO", spkRiskGrubuUrun.getId().getGrupNo());
					oMap.put(tableName, row, "URUN_KODU", spkRiskGrubuUrun.getId().getUrunKodu());
					
					row++;
				}
				
				/*
				 * Eski tx-no bulunur
				 */
				BigDecimal oldTrxNo = getOncekiTxNo(trxNo);
				
				/*
				 * tx-e gore eski liste cekilir
				 */
				List<?> oldList = session.createCriteria(SpkRiskGrubuUrunTx.class).add(Restrictions.eq("id.txNo", oldTrxNo)).list();
				
				for (Iterator<?> iterator = oldList.iterator(); iterator.hasNext();) {
					SpkRiskGrubuUrunTx spkRiskGrubuUrun = (SpkRiskGrubuUrunTx) iterator.next();
					
					oMap.put(oldTableName, oldRow, "GRUP_NO", spkRiskGrubuUrun.getId().getGrupNo());
					oMap.put(oldTableName, oldRow, "URUN_KODU", spkRiskGrubuUrun.getId().getUrunKodu());
					
					oldRow++;
				}
				
				/*
				 * eski ve yeni listeler karsilatirilir, renklendirme icin
				 */
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("GRUP_NO");
				keyColumns.add("URUN_KODU");
				
				oMap.put("COLOR_LIST", BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(oldTableName), (ArrayList<?>) oMap.get(tableName), keyColumns).get("COLOR_DATA"));
				
			} else {//yoksa ana tablo uzerinden gelsin
				
				List<?> list = session.createCriteria(SpkRiskGrubuUrun.class).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SpkRiskGrubuUrun spkRiskGrubuUrun = (SpkRiskGrubuUrun) iterator.next();
					
					oMap.put(tableName, row, "GRUP_NO", spkRiskGrubuUrun.getId().getGrupNo());
					oMap.put(tableName, row, "URUN_KODU", spkRiskGrubuUrun.getId().getUrunKodu());
					
					row++;
				}
				
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9962_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			
			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete SpkRiskGrubuUrunTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			/*
			 * tablo insert edilir
			 */
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				SpkRiskGrubuUrunTx spkRiskGrubuUrun = new SpkRiskGrubuUrunTx();
				
				//
				SpkRiskGrubuUrunTxId id = new SpkRiskGrubuUrunTxId();
				id.setTxNo(trxNo);
				id.setGrupNo(iMap.getString(tableName, row, "GRUP_NO"));
				id.setUrunKodu(iMap.getString(tableName, row, "URUN_KODU"));
				//
				
				spkRiskGrubuUrun.setId(id);
				
				session.saveOrUpdate(spkRiskGrubuUrun);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9962");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static BigDecimal getOncekiTxNo(BigDecimal trxNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_9962(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, trxNo);
			stmt.execute();
			
			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static void executeInitialize() {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN9962.initialize}");
			stmt.execute();
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static void fillRiskUrunleri(GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		/*
		 * Risk urunleri comboya doldurulur
		 */
		List<?> list = session.createCriteria(SpkRiskUrun.class).list();
		
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			SpkRiskUrun spkRiskUrun = (SpkRiskUrun) iterator.next();
			
			StringBuffer urunAdi = new StringBuffer();
			urunAdi.append(spkRiskUrun.getUrunKodu());
			urunAdi.append(" - ");
			urunAdi.append(spkRiskUrun.getUrunAdi());
			
			GuimlUtil.wrapMyCombo(oMap, "RISK_URUN_LIST", spkRiskUrun.getUrunKodu().toString(), urunAdi.toString());
		}
	}
	
	private static void fillRiskGruplari(GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		/*
		 * Risk gruplari comboya doldurulur
		 */
		List<?> list = session.createCriteria(SpkRiskGrubu.class).list();
		
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			SpkRiskGrubu spkRiskGrubu = (SpkRiskGrubu) iterator.next();
			
			StringBuffer grupAdi = new StringBuffer();
			grupAdi.append(spkRiskGrubu.getGrupAdi());
			grupAdi.append(" ( ");
			grupAdi.append(spkRiskGrubu.getMinPuan());
			grupAdi.append(" / ");
			grupAdi.append(spkRiskGrubu.getMaxPuan());
			grupAdi.append(" ) ");
			
			GuimlUtil.wrapMyCombo(oMap, "RISK_GRUP_LIST", spkRiskGrubu.getGrupNo(), grupAdi.toString());
		}
	}

}
