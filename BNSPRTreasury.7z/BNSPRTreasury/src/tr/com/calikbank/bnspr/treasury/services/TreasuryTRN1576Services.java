package tr.com.calikbank.bnspr.treasury.services;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTxId;
import tr.com.calikbank.bnspr.dao.HznSwapTx;
import tr.com.calikbank.bnspr.dao.HznSwapTxId;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1576Services {

	@GraymoundService("BNSPR_TRN1576_INITIALIZE")
	public static GMMap initialize1575(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			String param = "ALIS_SATIS";
			GuimlUtil.wrapMyCombo(oMap, param, null, null);
			GuimlUtil.wrapMyCombo(oMap, param, "A", "Banka Al��");
			GuimlUtil.wrapMyCombo(oMap, param, "S", "Banka Sat��");

			param = "OPS_SEKLI";
			GuimlUtil.wrapMyCombo(oMap, param, null, null);
			GuimlUtil.wrapMyCombo(oMap, param, "C", "CALL");
			GuimlUtil.wrapMyCombo(oMap, param, "P", "PUT");

			param = "OPS_TIPI";
			GuimlUtil.wrapMyCombo(oMap, param, null, null);
			GuimlUtil.wrapMyCombo(oMap, param, "AVR", "Avrupa");
			GuimlUtil.wrapMyCombo(oMap, param, "AMR", "Amerika");

			param = "KULLANIM";
			GuimlUtil.wrapMyCombo(oMap, param, null, "Seciniz");
			GuimlUtil.wrapMyCombo(oMap, param, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, param, "H", "Hayir");

			DALUtil.fillComboBox(oMap, "BAZ_DOVIZ", true,
					"SELECT ALL kOD, ACIKLAMA,sira_no FROM v_ml_gnl_doviz_kod_pr ORDER BY sira_no");

			oMap.putAll(getList());

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static GMMap getList() {
		try {
			GMMap oMap = new GMMap();
			String tableName = "TABLE";

			/*
			 * Yasayan opsiyon, swap ve spot/fwd listeleri cekilir
			 */
			GMMap opMap = DALUtil.callOracleRefCursorFunction("{? = call PKG_TRN1576.YasayanOpsiyonListesi}", tableName);
			GMMap swMap = DALUtil.callOracleRefCursorFunction("{? = call PKG_TRN1576.YasayanSwapListesi}", tableName);
			GMMap sfMap = DALUtil.callOracleRefCursorFunction("{? = call PKG_TRN1576.YasayanSpotFwdListesi}", tableName);
			
			/*
			 * Opsiyon listesi eklenir 
			 */
			oMap.putAll(opMap);

			/*
			 * Swap listesi eklenir
			 */
			int row = oMap.getSize(tableName);

			for (int i = 0; i < swMap.getSize(tableName); i++) {
				oMap.put(tableName, i + row, swMap.getMap(tableName, i));
			}

			/*
			 * Spot/Fwd listesi eklenir
			 */
			row = oMap.getSize(tableName);

			for (int i = 0; i < sfMap.getSize(tableName); i++) {
				oMap.put(tableName, i + row, sfMap.getMap(tableName, i));
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1576_GET_INFO")
	public static GMMap getInfo1575(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "TABLE";
			
			int row = 0;
			
			GMMap oMap = new GMMap();
			
			GMMap greenColor = new GMMap();
			greenColor.put("setBackground", Color.GREEN);

			/*
			 * Opsiyonlar
			 */
			List<?> opList = session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo",trxNo)).list();
			
			for (Iterator<?> iterator = opList.iterator(); iterator.hasNext();) {
				HznOpsiyonislemTx p = (HznOpsiyonislemTx) iterator.next();
				
				oMap.put(tableName, row, "REFERANS", p.getId().getReferans());
				oMap.put(tableName, row, "SUBE_KOD", LovHelper.diLov(p.getMusteriNo(), "1576/LOV_GENEL_MUSTERI_NO", "SUBE_KODU"));
				oMap.put(tableName, row, "MUSTERI_NO", p.getMusteriNo());
				oMap.put(tableName, row, "UNVAN", LovHelper.diLov(p.getMusteriNo(), "1576/LOV_GENEL_MUSTERI_NO", "UNVAN"));
				oMap.put(tableName, row, "OPS_YONU", p.getOpsYonu());
				oMap.put(tableName, row, "OPS_SEKLI_BAZ", p.getOpsSekliBaz());
				oMap.put(tableName, row, "HEDEF_FIYAT", p.getHedefFiyat());
				oMap.put(tableName, row, "BAZ_DVZ", p.getBazDvz());
				oMap.put(tableName, row, "BAZ_TUTAR", p.getBazTutar());
				oMap.put(tableName, row, "PRIM_MALIYET", p.getPrimMaliyet());
				oMap.put(tableName, row, "PRIM_MUSTERI", p.getPrimMusteri());
				oMap.put(tableName, row, "TARIH_ISLEM", p.getTarihIslem());
				oMap.put(tableName, row, "TARIH_UZLASMA", p.getTarihUzlasma());
				oMap.put(tableName, row, "TARIH_VADE", p.getTarihVade());
				oMap.put(tableName, row, "OPS_TIPI", p.getOpsTipi());
				oMap.put(tableName, row, "KULLANIM", p.getKullanildimi());
				oMap.put(tableName, row, "PARITE", p.getBazDvz() + "/" + p.getKarsiDoviz());
				oMap.put(tableName, row, "KARSI_DOVIZ", p.getKarsiDoviz());
				oMap.put(tableName, row, "MTM_TUTAR", p.getMtmTutar());
				oMap.put(tableName, row, "MTM_TARIH", p.getMtmTarih());
				oMap.put(tableName, row, "ISLEM_TURU", "OP");
				oMap.put(tableName, row, "DELTA", p.getDelta());				
				oMap.put(tableName, row, "GAMA", p.getGama());
				
				if ("E".equals(p.getMtmGuncellendimi())) {
					oMap.put("COLOR", row, "MTM_TUTAR", greenColor);
					oMap.put("COLOR", row, "REFERANS", greenColor);
				}
				
				row++;
			}
			
			/*
			 * Swaplar
			 */
			List<?> swList = session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo",trxNo)).list();
			
			for (Iterator<?> iterator = swList.iterator(); iterator.hasNext();) {
				HznSwapTx p = (HznSwapTx) iterator.next();
				
				oMap.put(tableName, row, "REFERANS", p.getId().getReferans());
				oMap.put(tableName, row, "SUBE_KOD", LovHelper.diLov(p.getBankaMusteriNo(), "1576/LOV_GENEL_MUSTERI_NO", "SUBE_KODU"));
				oMap.put(tableName, row, "MUSTERI_NO", p.getBankaMusteriNo());
				oMap.put(tableName, row, "UNVAN", LovHelper.diLov(p.getBankaMusteriNo(), "1576/LOV_GENEL_MUSTERI_NO", "UNVAN"));
				oMap.put(tableName, row, "OPS_YONU", p.getIslemSekli());
				//oMap.put(tableName, row, "OPS_SEKLI_BAZ", p.getOpsSekliBaz());
				if (p.getForwardParite() != null && !BigDecimal.ZERO.equals(p.getForwardParite()))
					oMap.put(tableName, row, "HEDEF_FIYAT", p.getForwardParite());
				else if (p.getForwardAlisKur() != null && BigDecimal.ONE.compareTo(p.getForwardAlisKur()) == -1)
					oMap.put(tableName, row, "HEDEF_FIYAT", p.getForwardAlisKur());
				else 
					oMap.put(tableName, row, "HEDEF_FIYAT", p.getForwardSatisKur());
				//oMap.put(tableName, row, "BAZ_DVZ", p.getBazDvz());
				oMap.put(tableName, row, "BAZ_TUTAR", (BigDecimal) DALUtil.callOracleFunction("{? = call PKG_TRN1576.BazDovizTutariBul(?, ?, ?, ?)}", BnsprType.NUMBER, 
						new Object[] {BnsprType.STRING, p.getAlisDovizKodu(), BnsprType.NUMBER, p.getForwardSatisTutari(), BnsprType.STRING, p.getSatisDovizKodu(), BnsprType.NUMBER, p.getForwardAlisTutari()}));
				//oMap.put(tableName, row, "PRIM_MALIYET", p.getPrimMaliyet());
				//oMap.put(tableName, row, "PRIM_MUSTERI", p.getPrimMusteri());
				oMap.put(tableName, row, "TARIH_ISLEM", p.getDealTarihi());
				//oMap.put(tableName, row, "TARIH_UZLASMA", p.getTarihUzlasma());
				oMap.put(tableName, row, "TARIH_VADE", p.getVadeTarihi());
				//oMap.put(tableName, row, "OPS_TIPI", p.getOpsTipi());
				//oMap.put(tableName, row, "KULLANIM", p.getKullanildimi());
				oMap.put(tableName, row, "PARITE", p.getAlisDovizKodu() + "/" + p.getSatisDovizKodu());
				//oMap.put(tableName, row, "KARSI_DOVIZ", p.getKarsiDoviz());
				oMap.put(tableName, row, "MTM_TUTAR", p.getMtmTutar());
				oMap.put(tableName, row, "MTM_TARIH", p.getMtmTarih());
				oMap.put(tableName, row, "ISLEM_TURU", "SW");
				
				if ("E".equals(p.getMtmGuncellendimi())) {
					oMap.put("COLOR", row, "MTM_TUTAR", greenColor);
					oMap.put("COLOR", row, "REFERANS", greenColor);
				}
				
				row++;
			}
			
			/*
			 * Spot/fwdlar
			 */
			List<?> sfList = session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo",trxNo)).list();
			
			for (Iterator<?> iterator = sfList.iterator(); iterator.hasNext();) {
				HznSpotfwdTx p = (HznSpotfwdTx) iterator.next();
				
				oMap.put(tableName, row, "REFERANS", p.getId().getReferans());
				oMap.put(tableName, row, "SUBE_KOD", LovHelper.diLov(p.getBankaMusteriNo(), "1576/LOV_GENEL_MUSTERI_NO", "SUBE_KODU"));
				oMap.put(tableName, row, "MUSTERI_NO", p.getBankaMusteriNo());
				oMap.put(tableName, row, "UNVAN", LovHelper.diLov(p.getBankaMusteriNo(), "1576/LOV_GENEL_MUSTERI_NO", "UNVAN"));
				oMap.put(tableName, row, "OPS_YONU", p.getAS());
				//oMap.put(tableName, row, "OPS_SEKLI_BAZ", p.getOpsSekliBaz());
				if (p.getParite() != null && !BigDecimal.ZERO.equals(p.getParite()))
					oMap.put(tableName, row, "HEDEF_FIYAT", p.getParite());
				else if (p.getAlisKur() != null && BigDecimal.ONE.compareTo(p.getAlisKur()) == -1)
					oMap.put(tableName, row, "HEDEF_FIYAT", p.getAlisKur());
				else 
					oMap.put(tableName, row, "HEDEF_FIYAT", p.getSatisKur());
				//oMap.put(tableName, row, "BAZ_DVZ", p.getBazDvz());
				oMap.put(tableName, row, "BAZ_TUTAR", (BigDecimal) DALUtil.callOracleFunction("{? = call PKG_TRN1576.BazDovizTutariBul(?, ?, ?, ?)}", BnsprType.NUMBER, 
						new Object[] {BnsprType.STRING, p.getAlisDovizKodu(), BnsprType.NUMBER, p.getAlisTutari(), BnsprType.STRING, p.getSatisDovizKodu(), BnsprType.NUMBER, p.getSatisTutari()}));
				//oMap.put(tableName, row, "PRIM_MALIYET", p.getPrimMaliyet());
				//oMap.put(tableName, row, "PRIM_MUSTERI", p.getPrimMusteri());
				oMap.put(tableName, row, "TARIH_ISLEM", p.getDealTarihi());
				//oMap.put(tableName, row, "TARIH_UZLASMA", p.getTarihUzlasma());
				oMap.put(tableName, row, "TARIH_VADE", p.getValorTarihi());
				//oMap.put(tableName, row, "OPS_TIPI", p.getOpsTipi());
				//oMap.put(tableName, row, "KULLANIM", p.getKullanildimi());
				oMap.put(tableName, row, "PARITE", p.getAlisDovizKodu() + "/" + p.getSatisDovizKodu());
				//oMap.put(tableName, row, "KARSI_DOVIZ", p.getKarsiDoviz());
				oMap.put(tableName, row, "MTM_TUTAR", p.getMtmTutar());
				oMap.put(tableName, row, "MTM_TARIH", p.getMtmTarih());
				oMap.put(tableName, row, "ISLEM_TURU", "SF");
				
				if ("E".equals(p.getMtmGuncellendimi())) {
					oMap.put("COLOR", row, "MTM_TUTAR", greenColor);
					oMap.put("COLOR", row, "REFERANS", greenColor);
				}
				
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1576_SAVE")
	public static Map<?, ?> saveTRN3160(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "TABLE";
			
			int updateSayisi = 0;
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				String referans = iMap.getString(tableName, row, "REFERANS");
				String islemTuru = iMap.getString(tableName, row, "ISLEM_TURU");
				BigDecimal mtmTutar = iMap.getBigDecimal(tableName, row, "MTM_TUTAR");
				BigDecimal delta = iMap.getBigDecimal(tableName, row, "DELTA");
				BigDecimal gama = iMap.getBigDecimal(tableName, row, "GAMA");
				BigDecimal oncekiMtmTutar = iMap.getBigDecimal(tableName, row, "ONCEKI_MTM_TUTAR");
				BigDecimal oncekiDelta = iMap.getBigDecimal(tableName, row, "ONCEKI_DELTA");
				BigDecimal oncekiGama = iMap.getBigDecimal(tableName, row, "ONCEKI_GAMA");
				
				if (mtmTutar ==  null)
					mtmTutar = BigDecimal.ZERO;
				
				if (oncekiMtmTutar == null)
					oncekiMtmTutar = BigDecimal.ZERO;
				
				if (delta ==  null)
					delta = BigDecimal.ZERO;
				
				if (oncekiDelta == null)
					oncekiDelta = BigDecimal.ZERO;
				
				if (gama ==  null)
					gama = BigDecimal.ZERO;
				
				if (oncekiGama == null)
					oncekiGama = BigDecimal.ZERO;
				
				/*
				 * MTM tutar degismis mi?
				 */
				if (mtmTutar.compareTo(oncekiMtmTutar) != 0  || gama.compareTo(oncekiGama) != 0 
						|| delta.compareTo(oncekiDelta) != 0 ) {
					
					/*
					 * Ana tablodan tx-e yazilir
					 */
					Object inputValues[] = {
							BnsprType.NUMBER, trxNo,
							BnsprType.STRING, referans,
							BnsprType.STRING, islemTuru
					};
					Object outputValues[] = {};
					DALUtil.callOracleProcedure("{call PKG_TRN1576.Ana_Tablodan_Tx(?, ?, ?)}", inputValues, outputValues);

					/*
					 * Opsyionlar
					 */
					if ("OP".equals(islemTuru)) {
						HznOpsiyonislemTxId tid = new HznOpsiyonislemTxId();
						tid.setReferans(referans);
						tid.setTxNo(trxNo);
						
						HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.get(HznOpsiyonislemTx.class, tid);
						
						hznOpsiyonislemTx.setId(tid);
						hznOpsiyonislemTx.setOpsStatus("MT");
						hznOpsiyonislemTx.setMtmTutar(mtmTutar);
						hznOpsiyonislemTx.setMtmTarih(BnsprCommonFunctions.getBankaTarih());
						hznOpsiyonislemTx.setMtmGuncellendimi("E");
						hznOpsiyonislemTx.setDelta(delta);
						hznOpsiyonislemTx.setGama(gama);
						
						session.saveOrUpdate(hznOpsiyonislemTx);
					}
					
					/*
					 * Swaplar
					 */
					if ("SW".equals(islemTuru)) {
						HznSwapTxId tid = new HznSwapTxId();
						tid.setReferans(referans);
						tid.setTxNo(trxNo);
						
						HznSwapTx hznSwapTx = (HznSwapTx) session.get(HznSwapTx.class, tid);
						
						hznSwapTx.setId(tid);
						hznSwapTx.setMtmTutar(mtmTutar);
						hznSwapTx.setMtmTarih(BnsprCommonFunctions.getBankaTarih());
						hznSwapTx.setMtmGuncellendimi("E");
						
						session.saveOrUpdate(hznSwapTx);
					}

					/*
					 * Spot/fwdlar
					 */
					if ("SF".equals(islemTuru)) {
						HznSpotfwdTxId tid = new HznSpotfwdTxId();
						tid.setReferans(referans);
						tid.setTxNo(trxNo);
						
						HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.get(HznSpotfwdTx.class, tid);
						
						hznSpotfwdTx.setId(tid);
						hznSpotfwdTx.setMtmTutar(mtmTutar);
						hznSpotfwdTx.setMtmTarih(BnsprCommonFunctions.getBankaTarih());
						hznSpotfwdTx.setMtmGuncellendimi("E");
						
						session.saveOrUpdate(hznSpotfwdTx);
					}
					
					updateSayisi++;
				}
			}
			
			if (updateSayisi == 0)
				throw new GMRuntimeException(0, "Kay�t i�in en az bir g�ncelleme yap�lmal�d�r");
			
			session.flush();
			
			iMap.put("TRX_NAME", "1576");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1576_YUKLE_EXCEL")
	public static GMMap loadExcelFile(GMMap iMap) {
		try {

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA_YOLU")));
			Sheet sheet = workbook.getSheet(0);

			int ref = 0, mtm = 0,delta=0,gama=0;

			for (int x = 0; x < sheet.getColumns(); x++) {
				if (sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("REFERANS")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("REFERANS NO")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("REFERANS NUMARASI"))
					
					ref = x;
				
				if (sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("MTM")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("MTM TUTARI")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("MTM TUTAR")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("MTM DE�ER�"))
					
					mtm = x;
				
				if (sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("DELTA")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("DELTA TUTARI")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("DELTA TUTAR")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("DELTA DE�ER�"))
					
					delta = x;
				
				if (sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("GAMA")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("GAMA TUTARI")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("GAMA TUTAR")
						|| sheet.getCell(x, 0).getContents().trim().equalsIgnoreCase("GAMA DE�ER�"))
					
					gama = x;
			}

			for (int excelRow = 1; excelRow < sheet.getRows(); excelRow++) {
				for (int row = 0; row < iMap.getSize("TABLE"); row++) {
					if (iMap.getString("TABLE", row, "REFERANS").equals(sheet.getCell(ref, excelRow).getContents().trim())) {
						String mtm_tutar = sheet.getCell(mtm, excelRow).getContents().trim();
						String delta_tutar = sheet.getCell(delta, excelRow).getContents().trim();
						String gama_tutar = sheet.getCell(gama, excelRow).getContents().trim();
						mtm_tutar = mtm_tutar.replace(',', '.');
						delta_tutar = delta_tutar.replace(',', '.');
						gama_tutar = gama_tutar.replace(',', '.');
						iMap.put("TABLE", row, "MTM_TUTAR", mtm_tutar);
						iMap.put("TABLE", row, "DELTA", delta_tutar);
						iMap.put("TABLE", row, "GAMA", gama_tutar);
					}
				}
			}
			workbook.close();
		} catch (IndexOutOfBoundsException e) {
			throw new GMRuntimeException(0, "Excel s�tunu eksik");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return iMap;
	}
}
