package tr.com.calikbank.bnspr.treasury.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;


public class TreasuryQRY1591Services {
	
    @GraymoundService("BNSPR_QRY1591_GET_NETLEMELER")
    public static GMMap getNetlemelerQRY1591(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            String func = "{? = call pkg_rc1591.GetNetlemeList(?,?,?,?,?)}";
            Object [] values  = new Object[] { BnsprType.STRING, iMap.getString("REFERANS"),
            		                           BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
            		                           BnsprType.DATE, iMap.getDate("VALOR_TARIHI"),
            		                           BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
            		                           BnsprType.STRING, iMap.getString("KARSI_MUHABIR_BANKA")
            								 };

            oMap = DALUtil.callOracleRefCursorFunction(func , "TABLE_NETLEME" , values);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
    @GraymoundService("BNSPR_QRY1591_GET_NETLEME_DETAY")
    public static GMMap getNetlemeDetayQRY1591(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            String func = "{? = call pkg_rc1591.GetNetlemeDetayList(?,?)}";
            Object [] values  = new Object[] { BnsprType.STRING, iMap.getString("REFERANS"),
                    						  BnsprType.NUMBER, iMap.getBigDecimal("OZET_ID")
            							     };

            oMap = DALUtil.callOracleRefCursorFunction(func , "TABLE_NETLEME_DETAY" , values);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }	
}
