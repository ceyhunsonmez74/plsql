package tr.com.calikbank.bnspr.treasury.services;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BbtGeriAlisFaizOranTx;
import tr.com.aktifbank.bnspr.dao.BbtKpFaizOranTx;
import tr.com.aktifbank.bnspr.dao.BbtKpFaizOranTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings({ "unchecked" })
public class TreasuryTRN1472Services {
    @GraymoundService("BNSPR_TRN1472_INITIALIZE")
    public static GMMap initiazlize(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call Pkg_TRN1472.Faiz_Oran_Listesi(?)}");

            stmt.registerOutParameter(1 , -10);

            stmt.execute();
            String tn = "BONO_FAIZ_ORAN";

            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, tn);     		       	
        	

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    private static boolean isBlank(Object object, boolean canBeEmptyOrZero) {
        
        if          (object instanceof String) return canBeEmptyOrZero ? false:StringUtils.isEmpty((String) object);
        else if     (object instanceof BigDecimal) return canBeEmptyOrZero ? false:((BigDecimal) object).compareTo(new BigDecimal("0"))==0; 
        
        return true;
    }

    @GraymoundService("BNSPR_TRN1472_SAVE")
    public static GMMap save(GMMap iMap) {
    	try {
            String tn = "BONO_FAIZ_ORAN";
            int size = iMap.getSize(tn);

            Object[][] cols = {
                {"DOVIZ_KODU",  "FAIZ_ORAN",        "MAX_TUTAR",        "MIN_TUTAR",        "MAX_GUN",         "MIN_GUN",        "GMY_MARJI",        "SUBE_MARJI"},
                {"getString",   "getBigDecimal",    "getBigDecimal",    "getBigDecimal",    "getBigDecimal",   "getBigDecimal",  "getBigDecimal",    "getBigDecimal"},
                {false,         false,             false,             false,             false,             false,           true,              true           }
            };

            Method method;

            int j=0;
            for (int i = 0; i < size; i++) {
                for (Object col : cols[0]) {

                    method = GMMap.class.getMethod((String) cols[1][j], String.class, int.class, String.class);
                    if (isBlank(method.invoke(iMap, tn, i, col), (Boolean) cols[2][j])) {
                        GMMap t = new GMMap();
                        t.put("HATA_NO", 330);
                        t.put("P1", (String) col);
                        return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", t);
                    }
                    
                    j++;
                }
                j=0;
            }

            Session session = DAOSession.getSession("BNSPRDal");

            BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
            BbtKpFaizOranTxId bbtId;
            BbtKpFaizOranTx bbt;

            /*
             * Tabloda yer almayacak elamanlar�n kay�t edilmemesi i�in �nceki
             * kay�tar� sil
             */
            {
                List<BbtKpFaizOranTx> bbtTMP = session.createCriteria(BbtGeriAlisFaizOranTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();

                if (bbtTMP != null) {
                    for (BbtKpFaizOranTx bb : bbtTMP) {
                        session.delete(bb);
                    }
                }
                session.flush();
            }

            for (int i = 0; i < size; i++) {

                bbtId = new BbtKpFaizOranTxId();

                bbtId.setTxNo(trxNo);
                bbtId.setDovizKodu(iMap.getString(tn, i, "DOVIZ_KODU"));
                bbtId.setFaizOran(iMap.getBigDecimal(tn, i, "FAIZ_ORAN"));
                bbtId.setMaxVade(iMap.getBigDecimal(tn, i, "MAX_GUN"));
                bbtId.setMinVade(iMap.getBigDecimal(tn, i, "MIN_GUN"));
                bbtId.setMinTutar(iMap.getBigDecimal(tn, i, "MIN_TUTAR"));
                bbtId.setMaxTutar(iMap.getBigDecimal(tn, i, "MAX_TUTAR"));

                bbt = new BbtKpFaizOranTx(bbtId);
                bbt.setSubeMarji(iMap.getBigDecimal(tn, i, "SUBE_MARJI"));
                bbt.setGmyMarji(iMap.getBigDecimal(tn, i, "GMY_MARJI"));
                
                session.saveOrUpdate(bbt);
            }
            session.flush();

            iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
            

        } catch (NonUniqueObjectException e) {
            GMMap t = new GMMap();
            t.put("HATA_NO", 785);
            return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", t);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_TRN1472_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();

        try {
            Session session = DAOSession.getSession("BNSPRDal");

            List<BbtKpFaizOranTx> bbtTMP =
                session.createCriteria(BbtKpFaizOranTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

            int i = 0;
            String tn = "BONO_FAIZ_ORAN";
            for (BbtKpFaizOranTx bb : bbtTMP) {
                
                oMap.put(tn, i, "DOVIZ_KODU", bb.getId().getDovizKodu());
                oMap.put(tn, i, "MIN_GUN", bb.getId().getMinVade());
                oMap.put(tn, i, "MAX_GUN", bb.getId().getMaxVade());
                oMap.put(tn, i, "FAIZ_ORAN", bb.getId().getFaizOran());
                oMap.put(tn, i, "MIN_TUTAR",bb.getId().getMinTutar());
                oMap.put(tn, i, "MAX_TUTAR",bb.getId().getMaxTutar());

                oMap.put(tn, i, "SUBE_MARJI",bb.getSubeMarji());
                oMap.put(tn, i++, "GMY_MARJI",bb.getGmyMarji());
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
}
