package tr.com.calikbank.bnspr.treasury.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import tr.com.aktifbank.bnspr.dao.MkkHesapAcilis;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirme;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferi;
import tr.com.aktifbank.bnspr.dao.MkkMessageQuery;
import tr.com.aktifbank.bnspr.dao.MkkMessageQueryResult;
import tr.com.aktifbank.bnspr.dao.MkkMessageQueryResultId;
import tr.com.aktifbank.bnspr.dao.MkkRehinTeminat;
import tr.com.aktifbank.integration.mkk.MkkClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.mkk.ws.schemas.messagequery.MessageQueryResponseType;
import tr.com.mkk.ws.schemas.messagequery.MessageQueryType;
import tr.com.mkk.ws.schemas.messagequery.QueryResponseType;
import tr.com.mkk.ws.schemas.messagequery.QueryType;
import tr.com.mkk.ws.schemas.messagequery.ResultMessageType;
import tr.com.mkk.ws.schemas.messagequery.ResultType;
import tr.com.mkk.ws.schemas.mkkresponse.ResponseType;
import tr.com.mkk.ws.schemas.types_1_0.RequestHeaderType;
import tr.com.mkk.ws.schemas.types_1_0.ResponseHeaderType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkMQBatchService {
    
    private static final Logger logger = Logger.getLogger(MkkMQBatchService.class);
    
    @GraymoundService("BNSPR_MKK_MESSAGE_QUERY_SERVICE")
    public static GMMap mkkCallMqServices(GMMap iMap) {
        GMMap oMap = new GMMap();
        logger.info("MKK Message Query servisi �al��maya ba�lad�:[BNSPR_MKK_MQ_BATCH_SERVICE]");
        try{

            Session session = DAOSession.getSession("BNSPRDal");
            logger.info("[BNSPR_MKK_MQ_BATCH_SERVICE] g�nderilecek kay�t:" + iMap.getString("SENDER_REFERENCE") + " servis:" + iMap.getString("SERVICE_NAME"));
            if (iMap.getString("SENDER_REFERENCE") == null || iMap.getString("SERVICE_NAME")==null){
                throw new Exception("SENDER_REFERENCE ve SERVICE_NAME bo� olamaz");
            }
                        
            BigDecimal mqId = newId("MKK_MQ_ID");
            
            MkkMessageQuery mq = new MkkMessageQuery();
            mq.setMqId(mqId);
            mq.setDurum("G"); //G�nderilecek
            mq.setSenderMember("AFB");
            mq.setSenderReference("MQ-"+mqId);
            mq.setQuerySenderReference(iMap.getString("SENDER_REFERENCE"));
            mq.setQueryServiceName(iMap.getString("SERVICE_NAME"));
            
            session.save(mq);
            session.flush();
            
            MessageQueryType messageQueryType = new MessageQueryType();
            QueryType queryType = new QueryType();
            queryType.setSenderReference(mq.getQuerySenderReference());
            queryType.setServiceName(mq.getQueryServiceName());
            messageQueryType.setQuery(queryType);
            
            RequestHeaderType reqHeader = new RequestHeaderType();
            reqHeader.setSenderMember(mq.getSenderMember());
            reqHeader.setSenderReference(mq.getSenderReference());
            messageQueryType.setRequestHeader(reqHeader);
            
            
            MessageQueryResponseType response = MkkClient.getMkkMessageQueryService().messageQuery(messageQueryType);
            logger.info("[BNSPR_MKK_MQ_BATCH_SERVICE] g�nderildi, ID:" + mq.getMqId());
            
            saveMessageQueryResponse(response, mq.getMqId());//Response objesini kaydedelim.
            
            if (response != null){ //�imdi art�k gelen mesaja g�re ilgili i�lem tablosunu g�ncellemek vakti.
                updateMainTransactionStatus(response);
            }

            try{ //Son olarak becerebilirsek request tablosundaki responseCode ve responseDesc alanlar�n� da g�ncelleyelim, yoksa .. sa�olsun.
                QueryResponseType queryResponse = response.getQueryResponse();
                ResponseType resType = queryResponse.getResponse();
                if (resType == null || "0000".equals(resType.getResponseCode())){
                    mq.setDurum("T"); //Tamamland�
                }
                else{
                    mq.setDurum("H"); //Ba�ar�s�z Hatal�
                }
                if (resType != null){
                    mq.setResponseCode(resType.getResponseCode());
                    mq.setResponseDesc(resType.getResponseDesc());
                }
                session.update(mq);
                session.flush();
            }
            catch(Exception ex){
                logger.error(ex);
            }
            
        } catch (Exception e){
            logger.error(e);
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("MKK Message Query servisi tamamland�:[BNSPR_MKK_MQ_BATCH_SERVICE]");
        }
        return oMap;
    }
    
    public static void saveMessageQueryResponse(MessageQueryResponseType response, BigDecimal mqId){
        Session session = DAOSession.getSession("BNSPRDal");
        boolean messageListExist = false;
        
        ResponseHeaderType responseHeader = response.getResponseHeader();
        QueryResponseType queryResponse = response.getQueryResponse();
        QueryType query = queryResponse.getQuery();
        ResponseType resType = queryResponse.getResponse();
        ResultType result = queryResponse.getResult();

        try{
            MkkMessageQueryResult mkkResp = new MkkMessageQueryResult();
            MkkMessageQueryResultId mkkRespId = new MkkMessageQueryResultId();
            mkkRespId.setMqId(mqId);
            mkkResp.setId(mkkRespId);
            
            if (responseHeader != null){
                mkkResp.setSenderReference(responseHeader.getSenderReference());
                mkkResp.setReceiverMember(responseHeader.getReceiverMember());
                mkkResp.setTid(responseHeader.getTid());
                mkkResp.setMessageId(responseHeader.getMessageId());
                mkkResp.setMkkSenderReference(responseHeader.getMkkSenderReference());
            }
            if (query != null ){
                mkkResp.setQuerySenderReference(query.getSenderReference());
                mkkResp.setQueryServiceName(query.getServiceName());
                mkkResp.setQueryTid(query.getTid());
            }
            if (resType != null){
                mkkResp.setResponseCode(resType.getResponseCode());
                mkkResp.setResponseDesc(resType.getResponseDesc());
            }
            if (result != null){
                List<ResultMessageType> messages = result.getMessage();
                if (messages != null && messages.size() > 0){
                    int i = 1;
                    for (ResultMessageType message : messages){
                        messageListExist = true;
                        logger.info("MKK Message Query Response Base64 decoded:" + new String(message.getMessage(), "UTF-8"));
                        mkkResp.getId().setSira(new BigDecimal(i++));
                        mkkResp.setResultServiceName(message.getServiceName());
                        mkkResp.setResultMessageBase64(Hibernate.createBlob((message.getMessage())));
                        session.save(mkkResp);
                    }
                }
            }
            if (!messageListExist){ //response daki message list bo�sa di�er alanlar� kaydedelim tek kay�t olarak
                mkkResp.getId().setSira(BigDecimal.ONE);
                session.save(mkkResp);
            }
            
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Message Query Response received..............");
            if (query != null){
                logger.info("responseHeader.senderReference => "+ query.getSenderReference());
                logger.info("responseHeader.serviceName => "+ query.getServiceName());
            }
            if (resType != null ){
                logger.info("response.responseCode => "+ resType.getResponseCode());
                logger.info("response.responseDesc => "+ resType.getResponseDesc());
            }
            logger.info("..............End Of MKK Message Query Response..............");
        }
    }
    
    private static void updateMainTransactionStatus(MessageQueryResponseType response) throws Exception{
        Session session = DAOSession.getSession("BNSPRDal");
        QueryResponseType queryResponse = response.getQueryResponse();
        ResultType result = queryResponse.getResult();
        
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        
        if (result != null){
            List<ResultMessageType> messages = result.getMessage();
            if (messages != null && messages.size() > 0){
                for (ResultMessageType message : messages){
                    Document doc = builder.parse(new ByteArrayInputStream(message.getMessage()));
                    String responseCode = getFirstElementValueByTagName(doc, "oires:responseCode");
                    String responseDesc = getFirstElementValueByTagName(doc, "oires:responseDesc");
                    String recId = getFirstElementValueByTagName(doc, "oityp:senderReference");
                    if ("OpenAccount".equals(message.getServiceName())){
                        if (recId != null && recId.startsWith("HA-")){
                            recId = recId.substring(3);
                            MkkHesapAcilis haOld = (MkkHesapAcilis)session.get(MkkHesapAcilis.class , new BigDecimal(recId));
                            haOld.setResponseCode(responseCode);
                            haOld.setResponseDesc(responseDesc);
                            if ("0000".equals(responseCode)){
                                haOld.setDurum("A"); //Ba�ar�l� Tamamland�
                            }
                            else{
                                haOld.setDurum("H"); //Ba�ar�s�z Hatal�
                            }
                            session.update(haOld);
                        }
                    }
                    else if ("MatchIdentities".equals(message.getServiceName())){
                        if (recId != null && recId.startsWith("KE-")){
                            recId = recId.substring(3);
                            Criteria criteria = session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("id.keId" , new BigDecimal(recId)));
                            List<?> list = criteria.list();
                            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                                MkkKimlikEslestirme keOld = (MkkKimlikEslestirme)iterator.next();
                                keOld.setResponseCode(responseCode);
                                keOld.setResponseDesc(responseDesc);
                                //TODO G�nderildi(A) ile Tamamland�(T) fark�n� yapabiliyor muyuz?
                                if ("0000".equals(responseCode)){
                                    keOld.setDurum("A"); //Ba�ar�l� Tamamland�
                                }
                                else{
                                    keOld.setDurum("H"); //Ba�ar�s�z Hatal�
                                }
                                session.update(keOld);
                            }
                        }
                    }
                    else if ("SecTransTrade".equals(message.getServiceName())){
                        if (recId != null && recId.startsWith("KT-")){
                            recId = recId.substring(3);
                            MkkKiymetTransferi ktOld = (MkkKiymetTransferi)session.get(MkkKiymetTransferi.class , new BigDecimal(recId));
                            ktOld.setResponseCode(responseCode);
                            ktOld.setResponseDesc(responseDesc);
                            //TODO G�nderildi(A) ile Tamamland�(T) fark�n� yapabiliyor muyuz?
                            if ("0000".equals(responseCode)){
                                ktOld.setDurum("A"); //Ba�ar�l� Tamamland�
                            }
                            else{
                                ktOld.setDurum("H"); //Ba�ar�s�z Hatal�
                            }
                            session.update(ktOld);
                        }
                    }
                    else if ("EnterExitPl".equals(message.getServiceName())){
                        if (recId != null && recId.startsWith("RT-")){
                            recId = recId.substring(3);
                            MkkRehinTeminat rtOld = (MkkRehinTeminat)session.get(MkkRehinTeminat.class , new BigDecimal(recId));
                            rtOld.setResponseCode(responseCode);
                            rtOld.setResponseDesc(responseDesc);
                            //TODO G�nderildi(A) ile Tamamland�(T) fark�n� yapabiliyor muyuz?
                            if ("0000".equals(responseCode)){
                                rtOld.setDurum("A"); //Ba�ar�l� Tamamland�
                            }
                            else{
                                rtOld.setDurum("H"); //Ba�ar�s�z Hatal�
                            }
                            session.update(rtOld);
                        }
                    }
                    else{
                        throw new Exception("[BNSPR_MKK_MQ_BATCH_SERVICE] Ge�ersiz ��lem Tipi");
                    }
                }
            }
            session.flush();
        }
        
    }
    
    private static BigDecimal newId(String key){
        GMMap map = new GMMap();
        map.put("TABLE_NAME" , key);
        return (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", map).get("ID");        
    }
    
    private static String getFirstElementValueByTagName(Document doc, String tagName){
        NodeList nList = doc.getElementsByTagName(tagName);
        if (nList != null){
            Node node = nList.item(0);
            if (node != null){
                return node.getTextContent();
            }
        }
        return null;
    }
}
