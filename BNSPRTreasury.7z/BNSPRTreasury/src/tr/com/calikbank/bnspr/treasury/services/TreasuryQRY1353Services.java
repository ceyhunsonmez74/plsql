package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1353Services {
	
	@GraymoundService("BNSPR_QRY1353_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();

		iMap.put("KOD", "HZN_DEPO_ISLEM_TURU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_DEPO_ISLEM_TURU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("TABLE_HZN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY1353_HZN_DEPO")
	public static GMMap getHznDepo(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_RC_HAZINE.RC_QRY1353_HZN_DEPO(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			if(!iMap.getString("REFERANS").isEmpty())
				stmt.setString(i++, iMap.getString("REFERANS"));
			else
				stmt.setString(i++, null);
			stmt.setString(i++, iMap.getString("ISLEM_TURU"));
			stmt.setString(i++, iMap.getString("ALINAN_VERILEN"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			
			if(!iMap.getBigDecimal("FAIZ_ORANI").toString().equals("0.00000"))
				stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			else
				stmt.setBigDecimal(i++, null);
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));
			if(!iMap.getString("DOVIZ_KODU").isEmpty())
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			else
				stmt.setString(i++, null);
			if(iMap.getDate("DEAL_TARIHI_MIN")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI_MIN").getTime()));
			if(iMap.getDate("DEAL_TARIHI_MAX")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI_MAX").getTime()));
			if(iMap.getDate("VADE_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			if(iMap.getDate("VADE_TARIHI_2")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI_2").getTime()));
			if(iMap.getDate("VALOR_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			if(iMap.getDate("VALOR_TARIHI_2")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI_2").getTime()));
			if(!iMap.getString("MUSTERI_NO").isEmpty())
				stmt.setString(i++, iMap.getString("MUSTERI_NO"));
			else
				stmt.setString(i++, null);
			if(iMap.getDate("ACIK_OLDUGU_TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("ACIK_OLDUGU_TARIH").getTime()));
			if(iMap.getDate("TAKSIT_VADE_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TAKSIT_VADE_TARIHI").getTime()));
			if(iMap.getDate("TAKSIT_VADE_TARIHI_2")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TAKSIT_VADE_TARIHI_2").getTime()));
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "DEPO_BILGILERI";
			int j = 0;
			while (rSet.next()) {
				oMap.put(tableName, j, "ALINAN_TARIH", rSet.getDate("ALINAN_TARIH"));
				oMap.put(tableName, j, "BANKA_HESAP_NO", rSet.getString("BANKA_HESAP_NO"));
				oMap.put(tableName, j, "BANKA_MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put(tableName, j, "BIRIKMIS_FAIZ_POZ", rSet.getBigDecimal("BIRIKMIS_FAIZ_POZ"));
				oMap.put(tableName, j, "SUBE_KODU", rSet.getString("SUBE_KODU"));
				oMap.put(tableName, j, "CIKIS_HESAP_NO", rSet.getString("CIKIS_HESAP_NO"));
				oMap.put(tableName, j, "CIKIS_HESAP_TURU", rSet.getString("CIKIS_HESAP_TURU"));
				oMap.put(tableName, j, "DEALER_NO", rSet.getString("DEALER_NO"));
				oMap.put(tableName, j, "DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName, j, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, j, "ESAS_GUN_SAYISI", rSet.getBigDecimal("ESAS_GUN_SAYISI"));
				oMap.put(tableName, j, "FAIZ_ORANI", rSet.getBigDecimal("FAIZ_ORANI"));
				oMap.put(tableName, j, "FAIZ_TUTARI", rSet.getBigDecimal("FAIZ_TUTARI"));
				oMap.put(tableName, j, "GECEN_YIL_FAIZ_TOPLAMI", rSet.getBigDecimal("GECEN_YIL_FAIZ_TOPLAMI"));
				oMap.put(tableName, j, "GIRIS_HESAP_NO", rSet.getString("GIRIS_HESAP_NO"));
				oMap.put(tableName, j, "GIRIS_HESAP_TURU", rSet.getString("GIRIS_HESAP_TURU"));
				oMap.put(tableName, j, "MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, j, "TENOR", rSet.getBigDecimal("TENOR"));
				oMap.put(tableName, j, "TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, j, "URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
				oMap.put(tableName, j, "URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put(tableName, j, "VADE_ISLEM_BILGISI", rSet.getString("VADE_ISLEM_BILGISI"));
				oMap.put(tableName, j, "VADE_TARIHI", rSet.getDate("VADE_TARIHI"));
				oMap.put(tableName, j, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, j, "YENILENEN_TUTAR", rSet.getBigDecimal("YENILENEN_TUTAR"));
				oMap.put(tableName, j, "BIRIKMIS_FAIZ", rSet.getBigDecimal("BIRIKMIS_FAIZ"));
				oMap.put(tableName, j, "GECEN_YIL_FAIZI", rSet.getBigDecimal("GECEN_YIL_FAIZI"));
				oMap.put(tableName, j, "ISLEM_TURU", rSet.getString("ISLEM_TURU"));
				oMap.put(tableName, j, "DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));
				oMap.put(tableName, j, "ANAPARA_ODEME_SEKLI", rSet.getString("ANAPARA_ODEME_SEKLI"));
				oMap.put(tableName, j, "ANAPARA_TAKSIT_ADEDI", rSet.getBigDecimal("ANAPARA_TAKSIT_ADEDI"));
				oMap.put(tableName, j, "ANAPARA_ODEME_SIKLIK_TIPI", rSet.getString("ANAPARA_ODEME_SIKLIK_TIPI"));
				oMap.put(tableName, j, "ANAPARA_ODEME_SIKLIK", rSet.getString("ANAPARA_ODEME_SIKLIK"));
				oMap.put(tableName, j, "ANAPARA_TAKSITLI_ODEME_SEKLI", rSet.getString("ANAPARA_TAKSITLI_ODEME_SEKLI"));
				oMap.put(tableName, j, "FAIZ_ENDEKS_KODU", rSet.getString("FAIZ_ENDEKS_KODU"));
				oMap.put(tableName, j, "FAIZ_DEGISIM_TARIHI", rSet.getString("FAIZ_DEGISIM_TARIHI"));
				oMap.put(tableName, j, "FAIZ_ENDEKS_PERIOD", rSet.getString("FAIZ_ENDEKS_PERIOD"));
				oMap.put(tableName, j, "SPREAD", rSet.getString("SPREAD"));
				oMap.put(tableName, j, "SPREAD_ORANI", rSet.getString("SPREAD_ORANI"));
				oMap.put(tableName, j, "FAIZ_SIKLIK_TIPI", rSet.getString("FAIZ_SIKLIK_TIPI"));
				oMap.put(tableName, j, "FAIZ_SIKLIK", rSet.getString("FAIZ_SIKLIK"));
				oMap.put(tableName, j, "FAIZ_HESAPLANACAK_TUTAR", rSet.getString("FAIZ_HESAPLANACAK_TUTAR"));
				oMap.put(tableName, j, "KALAN_ANAPARA", rSet.getBigDecimal("KALAN_ANAPARA"));
				oMap.put(tableName, j, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, j, "DEALER_ACIKLAMA", rSet.getString("DEALER_ACIKLAMA"));
				oMap.put(tableName, j, "MUSTERI_ADI", rSet.getString("MUSTERI_ADI"));
				oMap.put(tableName, j, "GIRIS_ACIKLAMA", rSet.getString("GIRIS_ACIKLAMA"));
				oMap.put(tableName, j, "CIKIS_ACIKLAMA", rSet.getString("CIKIS_ACIKLAMA"));
				
				oMap.put(tableName, j, "CIKIS_MUHABIR_MUSTERI_NO", rSet.getString("CIKIS_MUHABIR_MUSTERI_NO"));
				
				oMap.put(tableName, j, "GIRIS_MUHABIR_MUSTERI_NO", rSet.getString("GIRIS_MUHABIR_MUSTERI_NO"));
				oMap.put(tableName, j, "MURABAHA_ID", rSet.getString("murabaha_id"));
				oMap.put(tableName, j, "KREDI_NO", rSet.getString("krediNo"));

				
				
				j++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_QRY1353_HZN_ISLEM_HAREKETLERI")
	public static GMMap getHznIslemHareketleri(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_HAZINE.RC_QRY1353_HZN_DEPO_HAREKET(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "ISLEM_BILGILERI");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY1353_HZN_ADEPO_AP")
	public static GMMap getHznAdepoAP(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_HAZINE.RC_QRY1353_HZN_ADEPO_AP(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "HZN_ADEPO_AP");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1353_HZN_ADEPO_FAIZ")
	public static GMMap getHznAdepoFaiz(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_HAZINE.RC_QRY1353_HZN_ADEPO_FAIZ(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "HZN_ADEPO_FAIZ");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY1353_HZN_DEPO_IZLEME")
	public static GMMap getHznDepoIzleme(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_HAZINE.RC_QRY1353_DEPO_ODMPLN_IZLE(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap = DALUtil.rSetResults(rSet, "HZN_DEPO_IZLEME");
			while(rSet.next())
			{
				oMap.put("ANAPARA_TAKSIT_PERIODU", rSet.getString("ANAPARA_TAKSIT_PERIODU"));
				oMap.put("FAIZ_ORANI_ENDEKS_DONEMI", rSet.getString("FAIZ_ORANI_ENDEKS_DONEMI"));
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
