package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BbSatisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class TreasuryTRN1470Services {

	@GraymoundService("BNSPR_1470_KANAL_KOD")
	public static GMMap getChanelCode(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("KANAL_KOD" , GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , iMap).getString("KANAL_KOD"));
		oMap.put("SUBE_KOD" , GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , iMap).getString("SUBE_KOD"));
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1470_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;
		oMap.put("PC_TURU", i, "NAME", "Sabit");
		oMap.put("PC_TURU", i++, "VALUE", "S");
		oMap.put("PC_TURU", i, "NAME", "De�i�ken");
		oMap.put("PC_TURU", i++, "VALUE", "D");
		oMap.put("PC_TURU", i, "NAME", "Hepsi");
		oMap.put("PC_TURU", i++, "VALUE", "H");
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_CHECK_CUT_OFF")
	public static GMMap cutOff(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BB.BB_saat_kontrol(?)}");
			stmt.setString(1 , iMap.getString("KANAL_KOD"));
			stmt.execute();
		} catch (Exception e){
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
    
//	
//	@GraymoundService("BNSPR_TRN1470_INIT")
//	public static GMMap init(GMMap iMap) {
//
//		GMMap oMap = new GMMap();
//		
//	    if (!NumberUtils.isNumber(iMap.getString("MUSTERI_NO"))){
//            iMap.put("HATA_NO", new BigDecimal(660));
//            iMap.put("P1", "M��teri No se�mediniz!");
//            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
//	    }
//	    
//       // oMap = musteriBelgeKontrol(iMap);
//
//		try {
//
//			String func = "{? = call PKG_TRN1472.bbt_kp_faiz_list}";
//			Object[] inputValues = new Object[0];
//			Object[] outputValues = new Object[]{ BnsprType.REFCURSOR, "P_FAIZ_ORANLARI"};
////			String tableName = "tblFaiz_List";			
////			
////			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
////			oMap.putAll(resultMap);
//			
//			oMap =  (GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues);	
////			oMap = DALUtil.callOracleRefCursorFunction(func, "tblFaiz_List", new Object[0]);
//		}
//		catch (Exception e) {
//			throw ExceptionHandler.convertException(e);
//		}
//		oMap.put("ERROR" , false);
//		return oMap;
//	}
	

	
	@GraymoundService("BNSPR_TRN1470_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {

		GMMap oMap = new GMMap();
		
	    if (!NumberUtils.isNumber(iMap.getString("MUSTERI_NO"))){
            iMap.put("HATA_NO", new BigDecimal(660));
            iMap.put("P1", "M��teri No se�mediniz!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	    }
	    
       // oMap = musteriBelgeKontrol(iMap);

		try {

			String func = "{? = call PKG_TRN1472.bbt_kp_faiz_list}";
			Object[] inputValues = new Object[0];
			Object[] outputValues = new Object[]{ BnsprType.REFCURSOR, "RC_FAIZ_LIST"};
//			String tableName = "tblFaiz_List";			
//			
//			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
//			oMap.putAll(resultMap);
			
			oMap =  (GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues);			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	
	@GraymoundService("BNSPR_TRN1470_KUPONLU_BONO_LIST")
	public static GMMap bonoList(GMMap iMap) {

		GMMap oMap = new GMMap();   
	  

		try {

			String func = "{? = call PKG_BB_WRAPPER.Kuponlu_bono_list(?)}";
			Object[] inputValues = new Object[]{BnsprType.STRING, iMap.getString("PC_TURU")};
			
			oMap =  DALUtil.callOracleRefCursorFunction(func, "R_LIST", inputValues);	
			
//			oMap.put("R_LIST", DALUtil.callOracleRefCursorFunction(func, "MENKUL_TABLE", new Object[] {BnsprType.STRING, iMap.getString("PC_TURU") }).get("TABLE"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1470_KUPON_LIST")
	public static GMMap bonoKuponList(GMMap iMap) {

		GMMap oMap = new GMMap();  	  

		try {

			String func = "{? = call PKG_BB_WRAPPER.Kupon_list(?)}";
			Object[] inputValues = new Object[]{ BnsprType.STRING, iMap.getString("P_ISIN")};
			
			
			oMap =  DALUtil.callOracleRefCursorFunction(func, "R_LIST", inputValues);	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	 // private static String masrafAlisSekli="HESAPTAN";

//		private static GMMap musteriBelgeKontrol(GMMap iMap){
//		    GMMap oMap= new GMMap();
//	        Connection conn = null;
//	        CallableStatement stmt = null;
//	        try{
//	            conn = GMServerDatasource.getConnection("java:/GraymoundDS");
//	            stmt = conn.prepareCall("{call Pkg_trn1099.Bono_Musteri_Belge_Kontrol(?)}");
//	            int i = 1;
//	            stmt.setString(i++ , iMap.getString("MUSTERI_NO"));
//	            stmt.execute();
//	            return oMap;
//	        } catch (Exception e){
//	            throw ExceptionHandler.convertException(e);
//	        } finally{
//	            GMServerDatasource.close(stmt);
//	            GMServerDatasource.close(conn);
//	        }
//		}
	
	
	@GraymoundService("BNSPR_TRN1470_SUBE_EKLE")
    public static GMMap getAddedSube(GMMap iMap) throws ParseException {
        GMMap oMap = new GMMap();
		oMap.put("SUBE_KOD" , GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , iMap).getString("SUBE_KOD"));
        return oMap;
    }
		
	

		@GraymoundService("BNSPR_TRN1470_SAVE")
		public static GMMap save(GMMap iMap) {
			Session session = DAOSession.getSession("BNSPRDal");
			try{
				/**
				 * TX_NO NUMBER not null,MUSTERI_NO NUMBER, HESAP_NO NUMBER,TALEP_TUTAR NUMBER, VADE_GUN_SAYISI NUMBER,
				 * VADE_TARIHI DATE, SATIS_BIRIM_FIYAT NUMBER, SATIS_NOMINAL NUMBER, SATIS_TUTAR NUMBER, MASRAF_HESAP_NO
				 * NUMBER, MASRAF_TUTARI NUMBER, NET_TUTAR NUMBER, GERIALIS_BIRIM_FIYAT NUMBER, GERIALIS_BURUT_FIYAT NUMBER,
				 * GERIALIS_STOPAJ NUMBER, GERIALIS_NET_TUTAR NUMBER, SATIS_FAIZ_ORAN NUMBER, FAIZ_ORAN_ID NUMBER, ISIN
				 * VARCHAR2(20)
				 */
				BbSatisTx bbSatistx = new BbSatisTx();
				bbSatistx.setFaizOranId(null);
				bbSatistx.setGerialisBirimFiyat(iMap.getBigDecimal("GA_BIRIM_FIYAT"));
				bbSatistx.setGerialisBurutFiyat(iMap.getBigDecimal("GA_BRUT_FIYAT"));
				bbSatistx.setGerialisNetTutar(iMap.getBigDecimal("GA_NET_TUTAR"));
				bbSatistx.setGerialisStopaj(iMap.getBigDecimal("GA_STOPAJ"));
				bbSatistx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
				bbSatistx.setIsin(iMap.getString("ISIN"));
				bbSatistx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
				bbSatistx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTAR"));
				bbSatistx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO"));
				bbSatistx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				bbSatistx.setNetTutar(iMap.getBigDecimal("NET_TUTAR"));
				bbSatistx.setSatisBirimFiyat(iMap.getBigDecimal("S_BIRIM_FIYAT"));
				bbSatistx.setSatisFaizOran(iMap.getBigDecimal("S_FAIZ_ORAN"));
				bbSatistx.setSatisNominal(iMap.getBigDecimal("S_NOMINAL"));
				bbSatistx.setSatisTutar(iMap.getBigDecimal("S_TUTAR"));
				bbSatistx.setMevcutFaizOran(iMap.getBigDecimal("MEVCUT_FAIZ_ORAN"));
				bbSatistx.setTalepTutar(iMap.getBigDecimal("TALEP_TUTAR"));
				bbSatistx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				bbSatistx.setVadeGunSayisi(iMap.getBigDecimal("VADE_GUN_SAYISI"));
				bbSatistx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
				bbSatistx.setReferans(iMap.getString("TRX_NO"));
				bbSatistx.setKanalKodu(GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , iMap).getString("KANAL_KOD"));
				bbSatistx.setSubeKodu(getSubeKodFromGlobal());
//				bbSatistx.setMasrafAlisSekli(masrafAlisSekli);
	            bbSatistx.setItfaTarihi(iMap.getDate("ITFA_TARIHI"));
	            bbSatistx.setEmanetEh(iMap.getBoolean("EMANET_MI")?"E":"H");
	            bbSatistx.setBbHesapAc(iMap.getBoolean("BONO_HESABI_ACILSIN")?"E":"H");
				
				session.saveOrUpdate(bbSatistx);
				session.flush();
				
				iMap.put("TRX_NAME" , iMap.getString("EKRAN_NO"));
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			} catch (Exception e){
				throw ExceptionHandler.convertException(e);
			}
		}

	    @GraymoundService("BNSPR_TRN1470_GET_FAIZ_ORAN")
	    public static GMMap faizOran(GMMap iMap) {
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;

	        GMMap oMap = new GMMap();
	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{call PKG_TRN1470.INT_Faiz_Hesapla (?, ?, ?, ?, ?)}");

	            int i = 1;
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("TALEP_TUTAR"));
	            stmt.setDate(i++, new java.sql.Date(new Date().getTime()));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE_GUN_SAYISI"));
	            stmt.setString(i++, StringUtils.isBlank(iMap.getString("DOVIZ_KODU")) ? "TRY" : iMap.getString("DOVIZ_KODU"));

	            stmt.registerOutParameter(i, Types.NUMERIC);
	            stmt.execute();

	            oMap.put("FAIZ_ORANI", stmt.getBigDecimal(i));
	            oMap.put("DOVIZ_KODU", StringUtils.isBlank(iMap.getString("DOVIZ_KODU"))?iMap.getString("DOVIZ_KOD"):iMap.getString("DOVIZ_KODU"));

	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
		
		@GraymoundService("BNSPR_TRN1470_GET_INFO")
		public static GMMap getInfo(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			try{
				BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
				GMMap oMap = new GMMap();
				Session session = DAOSession.getSession("BNSPRDal");
				BbSatisTx bbSatistx = (BbSatisTx) session.createCriteria(BbSatisTx.class).add(Restrictions.eq("txNo" , txNo)).uniqueResult();
				session.flush();
				oMap.put("GA_BIRIM_FIYAT" , bbSatistx.getGerialisBirimFiyat());
				oMap.put("GA_BRUT_FIYAT" , bbSatistx.getGerialisBurutFiyat());
				oMap.put("GA_NET_TUTAR" , bbSatistx.getGerialisNetTutar());
				oMap.put("GA_STOPAJ" , bbSatistx.getGerialisStopaj());
				oMap.put("HESAP_NO" , bbSatistx.getHesapNo());
				oMap.put("ISIN" , bbSatistx.getIsin());
				oMap.put("DOVIZ_KOD" , bbSatistx.getDovizKodu());
				oMap.put("MASRAF_TUTAR" , bbSatistx.getMasrafTutari());
				oMap.put("MASRAF_HESAP_NO" , bbSatistx.getMasrafHesapNo());
				oMap.put("MUSTERI_NO" , bbSatistx.getMusteriNo());
				oMap.put("UNVAN" , LovHelper.diLov(bbSatistx.getMusteriNo() , "1402/LOV_MUSTERI_NO" , "Unvan"));
				oMap.put("BAKIYE" , LovHelper.diLov(bbSatistx.getHesapNo() , bbSatistx.getMusteriNo() , "1402/LOV_HESAP_NO" , "BAKIYE"));
				oMap.put("BLOKE_TUTARI" , LovHelper.diLov(bbSatistx.getHesapNo() , bbSatistx.getMusteriNo() , "1402/LOV_HESAP_NO" , "BLOKE_TUTARI"));
				oMap.put("KULLANILABILIR_BAKIYE" , LovHelper.diLov(bbSatistx.getHesapNo() , bbSatistx.getMusteriNo() , "1402/LOV_HESAP_NO" , "KULLANILABILIR_BAKIYE"));
				oMap.put("NET_TUTAR" , bbSatistx.getNetTutar());
				oMap.put("S_BIRIM_FIYAT" , bbSatistx.getSatisBirimFiyat());
				oMap.put("S_FAIZ_ORAN" , bbSatistx.getSatisFaizOran());
				oMap.put("S_NOMINAL" , bbSatistx.getSatisNominal());
				oMap.put("S_TUTAR" , bbSatistx.getSatisTutar());
				oMap.put("MEVCUT_FAIZ_ORAN" , bbSatistx.getMevcutFaizOran());
				oMap.put("TALEP_TUTAR" , bbSatistx.getTalepTutar());
				oMap.put("VADE_GUN_SAYISI" , bbSatistx.getVadeGunSayisi());
	            oMap.put("VADE_TARIHI" , bbSatistx.getVadeTarihi());
	            oMap.put("ITFA_TARIHI" , bbSatistx.getItfaTarihi());
	            oMap.put("ISIN" , bbSatistx.getIsin());
	            oMap.put("EMANET_MI" , bbSatistx.getEmanetEh()==null?false:bbSatistx.getEmanetEh().equals("E")?true:false);
	            oMap.put("BONO_HESABI_ACILSIN" , bbSatistx.getBbHesapAc()==null?false:bbSatistx.getBbHesapAc().equals("E")?true:false);
				
				conn = DALUtil.getGMConnection();
				
	            stmt = conn.prepareCall("{? = call PKG_TRN1470.bbt_faiz_list()}");
	            int i = 1;
	            stmt.registerOutParameter(i , -10);

	            stmt.execute();
	            rSet = (ResultSet) stmt.getObject(i);
	            i = 0;

	            while (rSet.next()){
	                oMap.put("LIST" , i , "VADE_ARALIK" , rSet.getString("VADE_ARALIK"));
	                oMap.put("LIST" , i , "TUTAR_ARALIK" , rSet.getString("TUTAR_ARALIK"));
	                oMap.put("LIST" , i , "FAIZ_ORANI" , rSet.getBigDecimal("FAIZ_ORAN"));
	                oMap.put("LIST" , i , "DOVIZ_KODU" , rSet.getString("DOVIZ_KODU"));
	                oMap.put("LIST" , i , "SUBE_MARJI" , rSet.getBigDecimal("SUBE_MARJI"));
	                oMap.put("LIST" , i , "GMY_MARJI" , rSet.getBigDecimal("GMY_MARJI"));
	                i++;
	            }
				return oMap;
			} catch (Exception e){
				throw ExceptionHandler.convertException(e);
			} finally{
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}

		private static String getSubeKodFromGlobal() {
	        Connection conn = null;
	        CallableStatement stmt = null;
	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_GLOBAL.GET_SUBEKOD()}");
	            stmt.registerOutParameter(1, Types.DECIMAL);
	            stmt.execute();
	            String subeKod = stmt.getString(1);
	            return subeKod;
	        } catch (SQLException e) {
	            throw new GMRuntimeException(0, e);
	        } finally {
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
	

   
	
}