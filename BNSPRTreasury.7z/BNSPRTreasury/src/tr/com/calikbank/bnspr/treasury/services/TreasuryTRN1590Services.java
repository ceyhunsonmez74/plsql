package tr.com.calikbank.bnspr.treasury.services;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDovizKodPr;
import tr.com.calikbank.bnspr.dao.NettingAnlasmaPr;
import tr.com.calikbank.bnspr.dao.NettingAnlasmaPrTx;
import tr.com.calikbank.bnspr.dao.NettingAnlasmaPrTxId;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class TreasuryTRN1590Services {

	@GraymoundService("BNSPR_TRN1590_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "NETTING_ISLEM_TIPLERI");
		iMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("NETTING_ISLEM_TIPLERI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1590_DOSYA_YUKLE")
	public static GMMap dosyaYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		String musteri_no =iMap.getString("MUSTERI_NO");
		String dosya_adi =  musteri_no+"_SOZLESME.pdf";
		String mntPath = null;
		try{
			GMMap sorguMap = new GMMap();
			sorguMap.put("PARAMETRE", "NETTING_DOCS_PATH");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
			mntPath = sorguMap.getString("DEGER");
			
		    fos = new FileOutputStream(new File(mntPath + File.separator + dosya_adi));	
		    bos = new BufferedOutputStream(fos);	
			byte[] pdfContent = (byte[]) iMap.get("CONTENT");	
			bos.write(pdfContent);

			oMap.put("YUKLEME","OK");			
			bos.close();
			fos.close();
		}
		catch(Exception e)
		{
			oMap.put("YUKLEME","ERROR");
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
		}
		finally{
        }
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1590_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		String mntPath = null;
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<NettingAnlasmaPrTx> anlasmaList = session.createCriteria(NettingAnlasmaPrTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
				
			GMMap sorguMap = new GMMap();
			sorguMap.put("PARAMETRE", "NETTING_DOCS_PATH");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
			mntPath = sorguMap.getString("DEGER");
			
			for(int i=0; i<anlasmaList.size(); i++){
				if(anlasmaList.get(i).getDurum()==null || anlasmaList.get(i).getDurum().isEmpty()){ //IPTAL EDILMEDI ISE
					if(anlasmaList.get(i).getDosya().equals("E")){
					String musteri_no = anlasmaList.get(i).getId().getBankaMusteriNo().toString();
					byte[] pdfContent = IOUtils.toByteArray(new FileInputStream(new File(mntPath + File.separator + musteri_no+"_SOZLESME.pdf")));
				    GMMap dysMap=new GMMap();
				    BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
			        dysMap.put("TRX_NO", trxNo);
			        dysMap.put("REFERANS_TIPI", 6);
			        dysMap.put("REFERANS_NO", trxNo);
			        dysMap.put("MUSTERI_NO", musteri_no);
			        dysMap.put("DOKUMAN_TIPI", 567);
			        dysMap.put("DOKUMAN_ADI", musteri_no+"_SOZLESME.pdf");
			        dysMap.put("DOSYA_SAYFA", 0, "CONTENT",pdfContent);
			        dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", musteri_no+"_SOZLESME.pdf");
			        dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER",1);
			        dysMap.put("TRX_ONAYSIZ_ISLEM","E");
			        GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
			        if(isExistMap.getBoolean("RESULT")){
			               GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			        }else{
			               GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			        }
				}
			}
		}
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
	
	
	@GraymoundService("BNSPR_TRN1590_SAVE")
	public static Map<?, ?> save1590(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");

	/*	NettingAnlasmaPrTx nettingAnlasmaPrTx = (NettingAnlasmaPrTx) session.createCriteria(NettingAnlasmaPrTx.class)
				.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add("id.", )
		NettingAnlasmaPrTxId nettingAnlasmaPrTxId;


		if (nettingAnlasmaPrTx == null) {
			nettingAnlasmaPrTx = new NettingAnlasmaPrTx();
			nettingAnlasmaPrTxId = new NettingAnlasmaPrTxId();
		}
		else {
			nettingAnlasmaPrTxId = nettingAnlasmaPrTx.getId();
		}*/
		saveOrNot(iMap);

		for (int row = 0; row < iMap.getSize("TABLE_ANLASMA"); row++) {

			if ( StringUtil.isEmpty(iMap.getString("TABLE_ANLASMA", row, "MUSTERI_NO"))){
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Eksik bilgi giri�i yapt�n�z. Banka M��teri No bo� olamaz.");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
						
			String islemTipi1 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI1");
			String islemTipi2 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI2");
			String islemTipi3 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI3");
			String islemTipi4 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI4");
			String islemTipi5 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI5");
			String islemTipi6 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI6");
			String islemTipi7 = iMap.getString("TABLE_ANLASMA", row, "ISLEM_TIPI7");

			if (StringUtil.isEmpty(islemTipi1) &&StringUtil.isEmpty(islemTipi2) && StringUtil.isEmpty(islemTipi3) && StringUtil.isEmpty(islemTipi4)&& StringUtil.isEmpty(islemTipi5)
					&&StringUtil.isEmpty(islemTipi6) && StringUtil.isEmpty(islemTipi7)){
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Eksik bilgi giri�i yapt�n�z. Her banka i�in en az bir i�lem tipi girilmelidir: " + iMap.getString("TABLE_ANLASMA", row, "MUSTERI_NO") );
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		    ArrayList<String> list = new ArrayList<String>();
		    HashSet<String> unique = new LinkedHashSet<String>();
		    HashSet<String> dup = new LinkedHashSet<String>();
		    if(!StringUtil.isEmpty(islemTipi1)) list.add(islemTipi1);
		    if(!StringUtil.isEmpty(islemTipi2)) list.add(islemTipi2);
		    if(!StringUtil.isEmpty(islemTipi3)) list.add(islemTipi3);
		    if(!StringUtil.isEmpty(islemTipi4)) list.add(islemTipi4);
		    if(!StringUtil.isEmpty(islemTipi5)) list.add(islemTipi5);
		    if(!StringUtil.isEmpty(islemTipi6)) list.add(islemTipi6);
		    if(!StringUtil.isEmpty(islemTipi7)) list.add(islemTipi7);

		    for(Iterator iterator= list.iterator();iterator.hasNext();)
		    {
		        String value = (String)iterator.next();
		        if(unique.add(value)==false) dup.add(value);
		        else unique.add(value);
		    }
		    
			if (dup.size()>0)
			{
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", iMap.getString("TABLE_ANLASMA", row, "MUSTERI_NO") + " no'lu m��teri i�in ayn� i�lem tipini birden fazla girdiniz." );
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			NettingAnlasmaPrTx nettingAnlasmaPrTx = (NettingAnlasmaPrTx) session.createCriteria(NettingAnlasmaPrTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.bankaMusteriNo",  iMap.getBigDecimal("TABLE_ANLASMA", row, "MUSTERI_NO"))).uniqueResult();
			NettingAnlasmaPrTxId nettingAnlasmaPrTxId;
			
			if (nettingAnlasmaPrTx == null) {
				nettingAnlasmaPrTx = new NettingAnlasmaPrTx();
				nettingAnlasmaPrTxId = new NettingAnlasmaPrTxId();
				nettingAnlasmaPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				BigDecimal bankaMusteriNo = new BigDecimal(iMap.getString("TABLE_ANLASMA", row, "MUSTERI_NO"));
				nettingAnlasmaPrTxId.setBankaMusteriNo(bankaMusteriNo);
				nettingAnlasmaPrTx.setId(nettingAnlasmaPrTxId);
			}
			else {
				nettingAnlasmaPrTxId = nettingAnlasmaPrTx.getId();
			}
						
			nettingAnlasmaPrTx.setIslemTipi1(islemTipi1);
			nettingAnlasmaPrTx.setIslemTipi2(islemTipi2);
			nettingAnlasmaPrTx.setIslemTipi3(islemTipi3);
			nettingAnlasmaPrTx.setIslemTipi4(islemTipi4);
			nettingAnlasmaPrTx.setIslemTipi5(islemTipi5);
			nettingAnlasmaPrTx.setIslemTipi6(islemTipi6);
			nettingAnlasmaPrTx.setIslemTipi7(islemTipi7);
			
			if(iMap.getBoolean("TABLE_ANLASMA" , row , "DOSYA"))
				nettingAnlasmaPrTx.setDosya("E");
			else nettingAnlasmaPrTx.setDosya("H");
			
			String hariciDovizKodlari = iMap.getString("TABLE_ANLASMA", row, "HARICI_DOVIZ_KODLARI");
			String hariciDovizKodlariOut = ""; int j=0;
			if(!StringUtil.isEmpty(hariciDovizKodlari)){
				hariciDovizKodlari = hariciDovizKodlari.toUpperCase().replace(" ", "");
			    String[] dovizKodlari = hariciDovizKodlari.split(",");			    
			    for(; j<dovizKodlari.length; j++)
			    {
			    	checkDovizKod(session, dovizKodlari[j]);
				    hariciDovizKodlariOut += dovizKodlari[j] + ",";			    }
			}
			String email = iMap.getString("TABLE_ANLASMA", row, "EMAIL");
			nettingAnlasmaPrTx.setEmail(email);
			if (j>0){
				nettingAnlasmaPrTx.setHariciDovizKodlari(hariciDovizKodlariOut.substring(0,hariciDovizKodlariOut.length()-1));
			}
			session.saveOrUpdate(nettingAnlasmaPrTx);
		}

		session.flush();

		iMap.put("TRX_NAME","1590");
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	}
	
	private static GnlDovizKodPr checkDovizKod(Session session, String dovizkod) {
		GnlDovizKodPr dovizKodPr = (GnlDovizKodPr)session.get(GnlDovizKodPr.class, dovizkod);

		//sistemde doviz tan�ml� de�il 
		if(dovizKodPr == null){ 
			GMMap servIMap = new GMMap();
			servIMap.put("MESSAGE_NO", new BigDecimal(956));
			servIMap.put("P1", dovizkod);
			Map<?, ?> servOMap = GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", servIMap);
			throw new GMRuntimeException(0, (String)servOMap.get("ERROR_MESSAGE"));
		}
		return dovizKodPr;
	}
	@SuppressWarnings("unchecked")
	private static GMMap saveOrNot(GMMap iMap) {

		List anlasmaList = new ArrayList<String>();

		for (int row = 0; row < iMap.getSize("TABLE_ANLASMA"); row++) {

			String musteriNo = iMap.getString("TABLE_ANLASMA", row, "MUSTERI_NO");

			if (anlasmaList.contains(musteriNo)){
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", musteriNo + " numaral� banka i�in sistemde netting tan�m� bulunmaktad�r.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if(!StringUtil.isEmpty(musteriNo))
				anlasmaList.add(musteriNo);
		}			
		return iMap;

	}

	@GraymoundService("BNSPR_TRN1590_GET_INFO")
	public static GMMap getInfo1590(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			@SuppressWarnings("unchecked")
			List<NettingAnlasmaPrTx> anlasmaList = session.createCriteria(NettingAnlasmaPrTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			String tn = "TABLE_ANLASMA";
			for (NettingAnlasmaPrTx kayit : anlasmaList) {

				oMap.put(tn, i,   "MUSTERI_NO",kayit.getId().getBankaMusteriNo());
				oMap.put(tn, i,   "UNVAN",LovHelper.diLov(kayit.getId().getBankaMusteriNo(), "1590/LOV_BANKA_MUSTERI", "UNVAN"));
				oMap.put(tn, i,   "ISLEM_TIPI1",kayit.getIslemTipi1());
				oMap.put(tn, i,   "ISLEM_TIPI2",kayit.getIslemTipi2());
				oMap.put(tn, i,   "ISLEM_TIPI3",kayit.getIslemTipi3());
				oMap.put(tn, i,   "ISLEM_TIPI4",kayit.getIslemTipi4());    
				oMap.put(tn, i, "ISLEM_TIPI5",kayit.getIslemTipi5());
				oMap.put(tn, i, "ISLEM_TIPI6",kayit.getIslemTipi6());
				oMap.put(tn, i, "ISLEM_TIPI7",kayit.getIslemTipi7());
				oMap.put(tn, i, "EMAIL",kayit.getEmail());               
				if(kayit.getDosya().equals("E"))  oMap.put(tn,  i,    "DOSYA", true);
				else 						      oMap.put(tn,  i,    "DOSYA", false);
				oMap.put(tn, i++, "HARICI_DOVIZ_KODLARI",kayit.getHariciDovizKodlari());    
			}
			
			  List<?> bbtTMPOld2 = session.createCriteria(NettingAnlasmaPr.class).list();			  
			String tnOld = "TABLE_ANLASMA_OLD";
			
            for (int j = 0; j < bbtTMPOld2.size(); j++){
            	NettingAnlasmaPr bb = (NettingAnlasmaPr)bbtTMPOld2.get(j);
            	oMap.put(tnOld , j , "MUSTERI_NO" , bb.getBankaMusteriNo());
            	oMap.put(tnOld , j , "UNVAN" , LovHelper.diLov(bb.getBankaMusteriNo(), "1590/LOV_BANKA_MUSTERI", "UNVAN"));
            	oMap.put(tnOld , j , "ISLEM_TIPI1" , bb.getIslemTipi1());
            	oMap.put(tnOld , j , "ISLEM_TIPI2" , bb.getIslemTipi2());
            	oMap.put(tnOld , j , "ISLEM_TIPI3" , bb.getIslemTipi3());
            	oMap.put(tnOld , j , "ISLEM_TIPI4" , bb.getIslemTipi4());
            	oMap.put(tnOld , j , "ISLEM_TIPI5" , bb.getIslemTipi5());
            	oMap.put(tnOld , j , "ISLEM_TIPI6" , bb.getIslemTipi6());
            	oMap.put(tnOld , j , "ISLEM_TIPI7" , bb.getIslemTipi7());
            	oMap.put(tnOld , j , "EMAIL" , bb.getEmail());
				oMap.put(tnOld,  j,  "DOSYA", false);
            	oMap.put(tnOld , j , "HARICI_DOVIZ_KODLARI" , bb.getHariciDovizKodlari());

            }
            ArrayList<String> str2 = new ArrayList<String>();
            
            str2.add("MUSTERI_NO");
            str2.add("UNVAN");
            str2.add("ISLEM_TIPI1");
            str2.add("ISLEM_TIPI2");
            str2.add("ISLEM_TIPI3");
            str2.add("ISLEM_TIPI4");
            str2.add("ISLEM_TIPI5");
            str2.add("EMAIL");
            str2.add("HARICI_DOVIZ_KODLARI");
            
            oMap.put("COLOR",BeanSetProperties.tableDifferenceWithPropertiesColumn( (ArrayList<?>) oMap.get(tnOld),(ArrayList<?>) oMap.get(tn)  , str2).get("COLOR_DATA") );

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1590_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {

			String func = "{? = call PKG_TRN1590.RC_TRN1590_GET_LIST}";
			Object[] inputValues = new Object[0];
			Object[] outputValues = new Object[]{ BnsprType.REFCURSOR, "RC_TUM_LIST"};
			oMap =  (GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues);
			
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}