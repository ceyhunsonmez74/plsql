package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY1386Services {

	@GraymoundService("BNSPR_QRY1386_GET_BONO_TALEP_IZLEME")
	public static GMMap getBonoTalepIzleme(GMMap iMap) {
		
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet           rSet = null;
		
		try {
			conn 				= DALUtil.getGMConnection();
			stmt 				= conn.prepareCall("{? = call PKG_RC1386.get_bono_talep_izleme(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			int i	= 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("MUSTERI_TUR"));
			stmt.setString(i++, iMap.getString("TCKN"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TALEP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAS_TALEP_TUTARI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BIT_TALEP_TUTARI"));
			
			if(iMap.getDate("BAS_TALEP_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TALEP_TARIHI").getTime()));
			if(iMap.getDate("BIT_TALEP_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TALEP_TARIHI").getTime()));
			
			if(iMap.getDate("BAS_PARA_GONDERIM_TARIH1")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_PARA_GONDERIM_TARIH1").getTime()));
			if(iMap.getDate("BIT_PARA_GONDERIM_TARIH1")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_PARA_GONDERIM_TARIH1").getTime()));
			
			if(iMap.getDate("BAS_PARA_GONDERIM_TARIH2")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_PARA_GONDERIM_TARIH2").getTime()));
			if(iMap.getDate("BIT_PARA_GONDERIM_TARIH2")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_PARA_GONDERIM_TARIH2").getTime()));
			
			if(iMap.getDate("BAS_RANDEVU_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_RANDEVU_TARIHI").getTime()));
			if(iMap.getDate("BIT_RANDEVU_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_RANDEVU_TARIHI").getTime()));
			
			if(iMap.getDate("BAS_EFT_GONDERIM_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_EFT_GONDERIM_TARIHI").getTime()));
			if(iMap.getDate("BIT_EFT_GONDERIM_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_EFT_GONDERIM_TARIHI").getTime()));
			
			stmt.setString(i++, iMap.getString("EKSIK_EVRAK_F"));
			stmt.setString(i++, iMap.getString("BONO_ALIS_TEYIT_STATU"));
			stmt.setString(i++, iMap.getString("GORUS_MESONUCU_F"));
			stmt.setString(i++, iMap.getString("BONO_ALIMI_GERCEKLESTI_F"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"));
			
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "TALEP_LISTE");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		    GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1386_GET_BONO_TARIHCE")
	public static GMMap getBonoTarihce(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet           rSet = null;
		try {
			conn 				= DALUtil.getGMConnection();
			stmt 				= conn.prepareCall("{? = call PKG_RC1386.get_bono_talep_tarihce(?)}");
			
			int i	= 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TALEP_NO"));
			
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "TALEP_LISTE");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		    GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
