package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;

import java.util.Date;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BbDogrulamaYetkiTx;
import tr.com.aktifbank.bnspr.dao.HznSwapXccy;
import tr.com.aktifbank.bnspr.dao.HznSwapXccyCfTx;
import tr.com.aktifbank.bnspr.dao.HznSwapXccyCfTxId;
import tr.com.aktifbank.bnspr.dao.HznSwapXccyTx;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.wm.broker.encoding.GregorianCalendarCoder;

public class TreasuryTRN1325Services {

	@GraymoundService("BNSPR_TRN1325_SAVE")
	public static GMMap Save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			/* E�er i�lem geri �evirildiyse �ncelikle eski kay�tlar� u�ural�m */
			Criteria criteria = session.createCriteria(HznSwapXccyTx.class)
					.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")));
			List<?> delList = criteria.list();
			if (delList != null && delList.size() > 0) {
				for (Iterator<?> iterator = delList.iterator(); iterator
						.hasNext();) {
					HznSwapXccyTx hznSwapXccyTx = (HznSwapXccyTx) iterator
							.next();
					session.delete(hznSwapXccyTx);
				}
				session.flush();
			}

			criteria = session.createCriteria(HznSwapXccyCfTx.class).add(
					Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));
			delList = criteria.list();
			if (delList != null && delList.size() > 0) {
				for (Iterator<?> iterator = delList.iterator(); iterator
						.hasNext();) {
					HznSwapXccyCfTx hznSwapXccyCfTx = (HznSwapXccyCfTx) iterator
							.next();
					session.delete(hznSwapXccyCfTx);
				}
				session.flush();
			}

			HznSwapXccyTx hznSwapTx = new HznSwapXccyTx();

			hznSwapTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznSwapTx.setModulTurKod("HAZINE");
			hznSwapTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSwapTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSwapTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznSwapTx.setDealerNo((String) iMap.get("DEALER_NO"));
			hznSwapTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSwapTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznSwapTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSwapTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSwapTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSwapTx.setSpotAlisKur(iMap.getBigDecimal("SPOT_ALIS_KUR"));
			hznSwapTx.setSpotSatisKur(iMap.getBigDecimal("SPOT_SATIS_KUR"));
			hznSwapTx.setSpotParite(iMap.getBigDecimal("SPOT_PARITE"));
			hznSwapTx.setSpotAlisTutari(iMap.getBigDecimal("SPOT_ALIS_TUTARI"));
			hznSwapTx.setSpotSatisTutari(iMap
					.getBigDecimal("SPOT_SATIS_TUTARI"));
			hznSwapTx.setSpotAlisHesapTuru(iMap
					.getString("SPOT_ALIS_HESAP_TURU"));
			hznSwapTx.setSpotAlisHesapNo(iMap
					.getBigDecimal("SPOT_ALIS_HESAP_NO"));
			hznSwapTx.setSpotSatisHesapTuru(iMap
					.getString("SPOT_SATIS_HESAP_TURU"));
			hznSwapTx.setSpotSatisHesapNo(iMap
					.getBigDecimal("SPOT_SATIS_HESAP_NO"));
			hznSwapTx.setForwardAlisKur(iMap.getBigDecimal("SPOT_SATIS_KUR"));
			hznSwapTx.setForwardSatisKur(iMap.getBigDecimal("SPOT_ALIS_KUR"));
			hznSwapTx.setForwardParite(iMap.getBigDecimal("SPOT_PARITE"));
			hznSwapTx.setForwardAlisTutari(iMap
					.getBigDecimal("SPOT_SATIS_TUTARI"));
			hznSwapTx.setForwardSatisTutari(iMap
					.getBigDecimal("SPOT_ALIS_TUTARI"));
			hznSwapTx.setForwardAlisHesapTuru(iMap
					.getString("SPOT_SATIS_HESAP_TURU"));
			hznSwapTx.setForwardAlisHesapNo(iMap
					.getBigDecimal("SPOT_SATIS_HESAP_NO"));
			hznSwapTx.setForwardSatisHesapTuru(iMap
					.getString("SPOT_ALIS_HESAP_TURU"));
			hznSwapTx.setForwardSatisHesapNo(iMap
					.getBigDecimal("SPOT_ALIS_HESAP_NO"));
			hznSwapTx.setAciklama(iMap.getString("ACIKLAMA"));

			if (iMap.getBoolean("RDB_GUNCEL"))
				hznSwapTx.setDurumKodu("G");
			else
				hznSwapTx.setDurumKodu("K");

			hznSwapTx.setIslemSekli(iMap.getString("ISLEM_SEKLI"));

			hznSwapTx.setSpotAlisMuhMusteriNo(iMap.getString("SPOT_ALIS"));
			hznSwapTx.setSpotSatisMuhMusteriNo(iMap.getString("SPOT_SATIS"));
			hznSwapTx.setForwardAlisMuhMusteriNo(iMap.getString("SPOT_SATIS"));
			hznSwapTx.setForwardSatisMuhMusteriNo(iMap.getString("SPOT_ALIS"));
			hznSwapTx.setDigerReferans(iMap.getString("DIGER_REFERANS"));
			hznSwapTx.setReferans(iMap.getString("REFERANS"));

			hznSwapTx.setBorcEsasGunSayisi(iMap
					.getBigDecimal("BORC_ESAS_GUN_SAYISI"));
			hznSwapTx.setBorcFaizFullname(iMap
					.getString("BORC_FAIZ_ENDEKS_KODU_ADI"));

			if (iMap.getString("BORC_FAIZ_ENDEKS_KODU_ADI").equals("Sabit")) {
				hznSwapTx.setBorcFaizTenor(null);
				hznSwapTx.setBorcFaizDoviz(null);
				hznSwapTx.setBorcFaizEndeksKodu("Sabit");
			} else {
				String[] str = iMap.getString("BORC_FAIZ_ENDEKS_KODU_ADI")
						.split("\\.");

				hznSwapTx.setBorcFaizTenor(str[2]);
				hznSwapTx.setBorcFaizDoviz(str[1].trim());
				hznSwapTx.setBorcFaizEndeksKodu(str[0]);
			}

			hznSwapTx.setBorcEsasGunSayisi(iMap
					.getBigDecimal("BORC_ESAS_GUN_SAYISI"));
			hznSwapTx.setBorcFaizFullname(iMap
					.getString("BORC_FAIZ_ENDEKS_KODU_ADI"));

			hznSwapTx.setBorcFrekans(iMap.getString("BORC_FREKANS"));
			hznSwapTx.setBorcIlkFaiz(iMap
					.getBigDecimal("BORC_FAIZ_ENDEKS_KODU"));
			hznSwapTx.setBorcSpread(iMap.getBigDecimal("BORC_SPREAD_KUR"));
			hznSwapTx.setBorcSpreadYonu(iMap.getString("BORC_SPREAD_YONU"));

			// Alacak kismi
			if (iMap.getString("ALACAK_FAIZ_ENDEKS_KODU_ADI").equals("Sabit")) {
				hznSwapTx.setAlacakFaizTenor(null);
				hznSwapTx.setAlacakFaizDoviz(null);
				hznSwapTx.setAlacakFaizEndeksKodu("Sabit");
			} else {
				String[] str = iMap.getString("ALACAK_FAIZ_ENDEKS_KODU_ADI")
						.split("\\.");

				hznSwapTx.setAlacakFaizTenor(str[2]);
				hznSwapTx.setAlacakFaizDoviz(str[1]);
				hznSwapTx.setAlacakFaizEndeksKodu(str[0]);
			}

			hznSwapTx.setAlacakEsasGunSayisi(iMap
					.getBigDecimal("ALACAK_ESAS_GUN_SAYISI"));
			hznSwapTx.setAlacakFaizFullname(iMap
					.getString("ALACAK_FAIZ_ENDEKS_KODU_ADI"));
			hznSwapTx.setAlacakFrekans(iMap.getString("ALACAK_FREKANS"));
			hznSwapTx.setAlacakIlkFaiz(iMap
					.getBigDecimal("ALACAK_FAIZ_ENDEKS_KODU"));
			hznSwapTx.setAlacakSpread(iMap.getBigDecimal("ALACAK_SPREAD_KUR"));
			hznSwapTx.setAlacakSpreadYonu(iMap.getString("ALACAK_SPREAD_YONU"));
			hznSwapTx.setBorcFaizFrekans(iMap.getString("BORC_FAIZ_FREKANS"));
			hznSwapTx.setAlacakFaizFrekans(iMap
					.getString("ALACAK_FAIZ_FREKANS"));

			session.saveOrUpdate(hznSwapTx);

			session.flush();
			int faizCount = 0;
			Date faizGuncelleme = null;

			for (int i = 0; i < iMap.getSize("BORC_TABLE"); i++) {

				HznSwapXccyCfTx hznSwapXccyCFTx = new HznSwapXccyCfTx();

				HznSwapXccyCfTxId id = new HznSwapXccyCfTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setVadeTarihi(iMap.getDate("BORC_TABLE", i, "VADE"));

				if (iMap.getString("BORC_TABLE", i, "ANAPARAMI").equals("E"))
					id.setDurum("X");
				else
					id.setDurum("O");

				id.setYon("B");

				hznSwapXccyCFTx.setId(id);

				hznSwapXccyCFTx.setDovizKodu(iMap.getString("BORC_TABLE", i,
						"DOVIZ_KODU"));

				if (iMap.getString("BORC_FAIZ_ENDEKS_KODU_ADI").equals("Sabit")) {
					hznSwapXccyCFTx.setFaizCinsi("S");
				} else {
					if (faizCount == 0) {
						faizCount++;
						faizGuncelleme = iMap.getDate("BORC_TABLE", i,
								"FAIZ_TARIH");
					} else if (iMap.getDate("BORC_TABLE", i, "FAIZ_TARIH") == null)
						faizCount++;
					else if (faizGuncelleme.before(iMap.getDate("BORC_TABLE",
							i, "FAIZ_TARIH")))
						faizCount++;

					if (faizCount > 1)
						hznSwapXccyCFTx.setFaizCinsi("G");
					else
						hznSwapXccyCFTx.setFaizCinsi("D");
				}

				hznSwapXccyCFTx.setIlkHesaplananTutar(iMap.getBigDecimal(
						"BORC_TABLE", i, "TUTAR"));
				hznSwapXccyCFTx.setOdemeGunuGostergeFaizi(null);
				hznSwapXccyCFTx.setOdemeGunuNetFaiz(null);
				hznSwapXccyCFTx.setOdemeGunuTutar(null);
				hznSwapXccyCFTx.setReferans(iMap.getString("REFERANS"));
				/*
				 * hznSwapTx.setSpotAlisHesapTuru(iMap.getString(
				 * "SPOT_ALIS_HESAP_TURU"));
				 * hznSwapTx.setSpotAlisHesapNo(iMap.getBigDecimal
				 * ("SPOT_ALIS_HESAP_NO"));
				 */
				/*
				 * hznSwapTx.setSpotAlisMuhMusteriNo(iMap.getString("SPOT_ALIS"))
				 * ;
				 * hznSwapTx.setSpotSatisMuhMusteriNo(iMap.getString("SPOT_SATIS"
				 * ));
				 */
				hznSwapXccyCFTx.setIlkFaiz(iMap.getBigDecimal("BORC_TABLE", i,
						"FAIZ"));
				hznSwapXccyCFTx.setFaizGuncellemeTarih(iMap.getDate(
						"BORC_TABLE", i, "FAIZ_TARIH"));
				hznSwapXccyCFTx.setHesapNo(iMap
						.getBigDecimal("SPOT_ALIS_HESAP_NO"));
				hznSwapXccyCFTx.setMuhMusteriNo(iMap.getString("SPOT_ALIS"));
				hznSwapXccyCFTx.setHesapTuru(iMap
						.getString("SPOT_ALIS_HESAP_TURU"));

				session.saveOrUpdate(hznSwapXccyCFTx);

			}

			faizCount = 0;

			for (int i = 0; i < iMap.getSize("ALACAK_TABLE"); i++) {
				HznSwapXccyCfTx hznSwapXccyCFTx2 = new HznSwapXccyCfTx();

				HznSwapXccyCfTxId id = new HznSwapXccyCfTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setVadeTarihi(iMap.getDate("ALACAK_TABLE", i, "VADE"));

				if (iMap.getString("ALACAK_TABLE", i, "ANAPARAMI").equals("E"))
					id.setDurum("X");
				else
					id.setDurum("O");
				id.setYon("A");

				hznSwapXccyCFTx2.setDovizKodu(iMap.getString("ALACAK_TABLE", i,
						"DOVIZ_KODU"));

				hznSwapXccyCFTx2.setId(id);

				if (iMap.getString("ALACAK_FAIZ_ENDEKS_KODU_ADI").equals(
						"Sabit")) {
					hznSwapXccyCFTx2.setFaizCinsi("S");
				} else {
					if (faizCount == 0) {
						faizCount++;
						faizGuncelleme = iMap.getDate("ALACAK_TABLE", i,
								"FAIZ_TARIH");
					} else if (iMap.getDate("ALACAK_TABLE", i, "FAIZ_TARIH") == null)
						faizCount++;
					else if (faizGuncelleme.before(iMap.getDate("ALACAK_TABLE",
							i, "FAIZ_TARIH")))
						faizCount++;

					if (faizCount > 1)
						hznSwapXccyCFTx2.setFaizCinsi("G");
					else
						hznSwapXccyCFTx2.setFaizCinsi("D");
				}

				hznSwapXccyCFTx2.setIlkHesaplananTutar(iMap.getBigDecimal(
						"ALACAK_TABLE", i, "TUTAR"));
				hznSwapXccyCFTx2.setOdemeGunuGostergeFaizi(null);
				hznSwapXccyCFTx2.setOdemeGunuNetFaiz(null);
				hznSwapXccyCFTx2.setOdemeGunuTutar(null);
				hznSwapXccyCFTx2.setReferans(iMap.getString("REFERANS"));

				hznSwapXccyCFTx2.setIlkFaiz(iMap.getBigDecimal("ALACAK_TABLE",
						i, "FAIZ"));
				hznSwapXccyCFTx2.setFaizGuncellemeTarih(iMap.getDate(
						"ALACAK_TABLE", i, "FAIZ_TARIH"));
				hznSwapXccyCFTx2.setHesapNo(iMap
						.getBigDecimal("SPOT_SATIS_HESAP_NO"));
				hznSwapXccyCFTx2.setMuhMusteriNo(iMap.getString("SPOT_SATIS"));
				hznSwapXccyCFTx2.setHesapTuru(iMap
						.getString("SPOT_SATIS_HESAP_TURU"));

				session.save(hznSwapXccyCFTx2);

			}
			session.flush();

			GMMap oMap = new GMMap();
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1325_TRANSACTION_START")
	public static Map<?, ?> Transactionstart(GMMap iMap) {

		try {
			iMap.put("TRX_NAME", "1325");
			return GMServiceExecuter
					.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1325_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();

		return oMap;// Swift mesajini duzelt Fikretcim.
		/*
		 * try { conn = DALUtil.getGMConnection(); stmt =
		 * conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?)}");
		 * 
		 * stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
		 * stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO")); stmt.execute();
		 * 
		 * } catch (Exception e) { throw ExceptionHandler.convertException(e); }
		 * finally { GMServerDatasource.close(stmt);
		 * GMServerDatasource.close(conn); } return oMap;
		 */
	}

	@GraymoundService("BNSPR_TRN1325_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();

			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapXccyTx hznSwapTx = (HznSwapXccyTx) session.get(
					HznSwapXccyTx.class, txNo);

			oMap.put("TX_NO", hznSwapTx.getTxNo());
			oMap.put("REF_NO", hznSwapTx.getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSwapTx.getUrunTurKod(),
					"1324/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSwapTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSwapTx.getDealTarihi());
			oMap.put("DEALER_NO", hznSwapTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSwapTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSwapTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznSwapTx.getVadeTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSwapTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSwapTx.getSatisDovizKodu());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSwapTx.getDealerNo(),
					"1324/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(
					hznSwapTx.getBankaMusteriNo(), "1324/LOV_BANKA_MUSTERI",
					"UNVAN"));
			oMap.put("SPOT_ALIS_TUTARI", hznSwapTx.getSpotAlisTutari());
			oMap.put("SPOT_ALIS_HESAP_TURU", hznSwapTx.getSpotAlisHesapTuru());
			oMap.put("SPOT_ALIS_HESAP_NO", hznSwapTx.getSpotAlisHesapNo());
			oMap.put("SPOT_SATIS_TUTARI", hznSwapTx.getSpotSatisTutari());
			oMap.put("SPOT_SATIS_HESAP_TURU", hznSwapTx.getSpotSatisHesapTuru());
			oMap.put("SPOT_SATIS_HESAP_NO", hznSwapTx.getSpotSatisHesapNo());
			oMap.put("SPOT_ALIS_KUR", hznSwapTx.getSpotAlisKur());
			oMap.put("SPOT_SATIS_KUR", hznSwapTx.getSpotSatisKur());
			oMap.put("SPOT_PARITE", hznSwapTx.getSpotParite());
			oMap.put("SPOT_ALIS_HESAP_KISAISIM", LovHelper.diLov(
					hznSwapTx.getSpotAlisHesapNo(),
					hznSwapTx.getAlisDovizKodu(),
					hznSwapTx.getSpotAlisHesapTuru(),
					hznSwapTx.getAlisDovizKodu(),
					hznSwapTx.getSpotAlisHesapTuru(),
					hznSwapTx.getBankaMusteriNo(), "1324/LOV_SPOT_ALIS_HESAP",
					"KISA_ISIM"));
			oMap.put("SPOT_SATIS_HESAP_KISAISIM", LovHelper.diLov(
					hznSwapTx.getSpotSatisHesapNo(),
					hznSwapTx.getSatisDovizKodu(),
					hznSwapTx.getSpotSatisHesapTuru(),
					hznSwapTx.getSatisDovizKodu(),
					hznSwapTx.getSpotSatisHesapTuru(),
					hznSwapTx.getBankaMusteriNo(), "1324/LOV_SPOT_SATIS_HESAP",
					"KISA_ISIM"));
			oMap.put("ISLEM_SEKLI", hznSwapTx.getIslemSekli());
			oMap.put("ACIKLAMA", hznSwapTx.getAciklama());

			oMap.put("SPOT_ALIS", hznSwapTx.getSpotAlisMuhMusteriNo());
			oMap.put("SPOT_SATIS", hznSwapTx.getSpotSatisMuhMusteriNo());
			oMap.put("SPOT_SATIS", hznSwapTx.getForwardAlisMuhMusteriNo());
			oMap.put("SPOT_ALIS", hznSwapTx.getForwardSatisMuhMusteriNo());
			/*
			 * oMap.put("FORWARD_ALIS", hznSwapTx.getForwardAlisMuhMusteriNo());
			 * oMap.put("FORWARD_SATIS",
			 * hznSwapTx.getForwardSatisMuhMusteriNo());
			 */
			oMap.put("BORC_SPREAD_YONU", hznSwapTx.getBorcSpreadYonu());
			oMap.put("ALACAK_SPREAD_YONU", hznSwapTx.getAlacakSpreadYonu());
			oMap.put("ALACAK_SPREAD_YONU", hznSwapTx.getAlacakSpreadYonu());

			oMap.put("BORC_FAIZ_KODU", hznSwapTx.getBorcFaizFullname());
			oMap.put("ALACAK_FAIZ_KODU", hznSwapTx.getAlacakFaizFullname());

			oMap.put("BORC_ESAS_GUN_SAYISI", hznSwapTx.getBorcEsasGunSayisi());
			oMap.put("ALACAK_ESAS_GUN_SAYISI",
					hznSwapTx.getAlacakEsasGunSayisi());

			oMap.put("BORC_SPREAD_CUR", hznSwapTx.getBorcSpread());
			oMap.put("ALACAK_SPREAD_CUR", hznSwapTx.getAlacakSpread());

			oMap.put("BORC_FREKANS", hznSwapTx.getBorcFrekans());
			oMap.put("ALACAK_FREKANS", hznSwapTx.getAlacakFrekans());

			oMap.put("BORC_FAIZ_FREKANS", hznSwapTx.getBorcFaizFrekans());
			oMap.put("ALACAK_FAIZ_FREKANS", hznSwapTx.getAlacakFaizFrekans());

			oMap.put("BORC_FAIZ", hznSwapTx.getBorcIlkFaiz());
			oMap.put("ALACAK_FAIZ", hznSwapTx.getAlacakIlkFaiz());

			if (hznSwapTx.getDurumKodu().equals("G")) {
				oMap.put("RDB_GUNCEL", true);
				oMap.put("RDB_KAPAMA", false);
			} else {
				oMap.put("RDB_KAPAMA", true);
				oMap.put("RDB_GUNCEL", false);
			}
			Criteria criteria = session
					.createCriteria(HznSwapXccyCfTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO")));
			criteria.add(Restrictions.eq("id.yon", "A"));
			criteria.addOrder(Order.asc("id.vadeTarihi"));
			List<?> list = criteria.list();
			int i = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				HznSwapXccyCfTx menRezervTx = (HznSwapXccyCfTx) iterator.next();

				String tn = "ALACAK_TABLE";

				oMap.put(tn, i, "ANAPARAMI", menRezervTx.getId().getDurum()
						.equals("X") ? "E" : "H");
				oMap.put(tn, i, "DOVIZ_KODU", menRezervTx.getDovizKodu());
				oMap.put(tn, i, "DURUM", menRezervTx.getId().getDurum());
				oMap.put(tn, i, "MAX_TUTAR", menRezervTx.getFaizCinsi());
				oMap.put(tn, i, "TUTAR", menRezervTx.getIlkHesaplananTutar());
				oMap.put(tn, i, "VADE", menRezervTx.getId().getVadeTarihi());
				oMap.put(tn, i, "FAIZ", menRezervTx.getIlkFaiz());
				oMap.put(tn, i, "FAIZ_TARIH",
						menRezervTx.getFaizGuncellemeTarih());
				i++;

			}

			criteria = session.createCriteria(HznSwapXccyCfTx.class).add(
					Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO")));
			criteria.add(Restrictions.eq("id.yon", "B"));
			criteria.addOrder(Order.asc("id.vadeTarihi"));
			list = criteria.list();

			i = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				HznSwapXccyCfTx hznSwapXccyCfTx = (HznSwapXccyCfTx) iterator
						.next();

				String tn = "BORC_TABLE";

				oMap.put(tn, i, "ANAPARAMI", hznSwapXccyCfTx.getId().getDurum()
						.equals("X") ? "E" : "H");
				oMap.put(tn, i, "DOVIZ_KODU", hznSwapXccyCfTx.getDovizKodu());
				oMap.put(tn, i, "DURUM", hznSwapXccyCfTx.getId().getDurum());
				oMap.put(tn, i, "MAX_TUTAR", hznSwapXccyCfTx.getFaizCinsi());
				oMap.put(tn, i, "TUTAR",
						hznSwapXccyCfTx.getIlkHesaplananTutar());
				oMap.put(tn, i, "VADE", hznSwapXccyCfTx.getId().getVadeTarihi());
				oMap.put(tn, i, "FAIZ", hznSwapXccyCfTx.getIlkFaiz());
				oMap.put(tn, i, "FAIZ_TARIH",
						hznSwapXccyCfTx.getFaizGuncellemeTarih());
				i++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1325_GET_BY_REFNO")
	public static GMMap getRecord(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();

			String txNo = iMap.getString("REF_NO");
			Session session = DAOSession.getSession("BNSPRDal");

			List<HznSwapXccyTx> hznSwapTx = (List<HznSwapXccyTx>) session
					.createCriteria(HznSwapXccyTx.class)
					.add(Restrictions.eq("referans", txNo))
					.addOrder(Order.desc("txNo")).list();

			oMap.put("TX_NO", hznSwapTx.get(0).getTxNo());

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_1325_NAKIT_AKIS_SIMPLE_BORC")
	public static GMMap nakitAkisSimple(GMMap iMap) {

		return simpleNakitAkis(iMap.getString("ALIS_DOVIZ_KOD"),
				iMap.getBigDecimal("ALIS_TUTARI"), iMap.getBigDecimal("FAIZ"),
				iMap.getString("SPREAD"), iMap.getBigDecimal("SPREAD_CUR"),
				iMap.getBigDecimal("ESAS_GUN_SAYISI"), iMap.getInt("FREKANS"),
				iMap.getInt("FAIZ_FREKANS"), iMap.getString("VALOR_TARIHI"),
				iMap.getString("VADE_TARIHI"), null);

	}

	@GraymoundService("BNSPR_1325_NAKIT_AKIS_WITH_TABLE_BORC")
	public static GMMap nakitAkiswithTable(GMMap iMap) {

		return simpleNakitAkis(iMap.getString("ALIS_DOVIZ_KOD"),
				iMap.getBigDecimal("ALIS_TUTARI"), iMap.getBigDecimal("FAIZ"),
				iMap.getString("SPREAD"), iMap.getBigDecimal("SPREAD_CUR"),
				iMap.getBigDecimal("ESAS_GUN_SAYISI"), iMap.getInt("FREKANS"),
				iMap.getInt("FAIZ_FREKANS"), iMap.getString("VALOR_TARIHI"),
				iMap.getString("VADE_TARIHI"), iMap);

	}

	@GraymoundService("BNSPR_1325_NAKIT_AKIS_SIMPLE_ALACAK")
	public static GMMap nakitAkisSimpleAlacak(GMMap iMap) {

		return simpleNakitAkis(iMap.getString("SATIS_DOVIZ_KOD"),
				iMap.getBigDecimal("SATIS_TUTARI"), iMap.getBigDecimal("FAIZ"),
				iMap.getString("SPREAD"), iMap.getBigDecimal("SPREAD_CUR"),
				iMap.getBigDecimal("ESAS_GUN_SAYISI"), iMap.getInt("FREKANS"),
				iMap.getInt("FAIZ_FREKANS"), iMap.getString("VALOR_TARIHI"),
				iMap.getString("VADE_TARIHI"), null);

	}

	@GraymoundService("BNSPR_1325_NAKIT_AKIS_WITH_TABLE_ALACAK")
	public static GMMap nakitAkiswithTableAlacak(GMMap iMap) {

		return simpleNakitAkis(iMap.getString("SATIS_DOVIZ_KOD"),
				iMap.getBigDecimal("SATIS_TUTARI"), iMap.getBigDecimal("FAIZ"),
				iMap.getString("SPREAD"), iMap.getBigDecimal("SPREAD_CUR"),
				iMap.getBigDecimal("ESAS_GUN_SAYISI"), iMap.getInt("FREKANS"),
				iMap.getInt("FAIZ_FREKANS"), iMap.getString("VALOR_TARIHI"),
				iMap.getString("VADE_TARIHI"), iMap);

	}

	public static GregorianCalendar GetCalendar(String s) {

		int days = Integer.parseInt(s.substring(6, 8));
		int month = Integer.parseInt(s.substring(4, 6));
		int year = Integer.parseInt(s.substring(0, 4));
		return new GregorianCalendar(year, month - 1, days);
	}

	public static String GetDateStr(GregorianCalendar s) {

		return s.get(Calendar.YEAR) + ""
				+ ((s.get(Calendar.MONTH) + 1) < 10 ? "0" : "")
				+ (s.get(Calendar.MONTH) + 1) + ""
				+ (s.get(Calendar.DATE) < 10 ? "0" : "") + s.get(Calendar.DATE);
	}

	public static GMMap simpleNakitAkis(String doviz_kod, BigDecimal tutar,
			BigDecimal faiz, String spreadYonu, BigDecimal spread,
			BigDecimal esasGunSayisi, int frequency, int interest_frequency,
			String valor, String vade, GMMap iMap) {

		GMMap oMap = new GMMap();
		try {

			if (valor == null || vade == null || doviz_kod == null
					|| tutar.intValue() == 0 || esasGunSayisi == null
					|| frequency == 0) {
				return oMap;
			}

			GregorianCalendar vl = GetCalendar(valor);// new
														// GregorianCalendar(valor.getYear(),valor.getMonth(),valor.getDate());
			GregorianCalendar vt = GetCalendar(valor);// new
														// GregorianCalendar(valor.getYear(),valor.getMonth(),valor.getDate());
			GregorianCalendar vd = GetCalendar(vade);// new
														// GregorianCalendar(vade.getYear(),vade.getMonth(),vade.getDate());
			GregorianCalendar vf = GetCalendar(valor);// new
														// GregorianCalendar(valor.getYear(),valor.getMonth(),valor.getDate());
			int faizFrekansOrani = interest_frequency / frequency;
			int frekansIncrement = 0;

			boolean condition = true;
			if (faiz == null)
				faiz = new BigDecimal(0);

			if ("+".equals(spreadYonu))
				faiz = faiz.add(spread);
			else
				faiz = faiz.subtract(spread);
			faiz = faiz.divide(new BigDecimal(100), 8, RoundingMode.HALF_UP);
			int row = 0;

			if (iMap != null && iMap.getSize("TBL") < 2)
				iMap = null;

			// iMap bos ise ekrandan BNSPR_1324_NAKIT_AKIS_SIMPLE_BORC servisi
			// cagrilmistir
			if (iMap == null) {
				while (condition) {
					vl.add(Calendar.DATE, frequency);
					if (vl.after(vd))
						vl = vd;
					if (vl.equals(vd))
						condition = false;
					BigDecimal gunSayisi = new BigDecimal(gunFarkiniHesapla(vl,
							vt));

					BigDecimal faiztutar = tutar.multiply(faiz);
					faiztutar = faiztutar.multiply(gunSayisi);
					faiztutar = faiztutar.divide(esasGunSayisi, 2,
							RoundingMode.HALF_UP);

					 if(frekansIncrement ==faizFrekansOrani && oMap.size()>0 ){
	                        frekansIncrement = 0;
	                        vf=GetCalendar(oMap.getString("TBL" , row-1 , "VADE" ));
	                     }
	                  
		                
		                
		                oMap.put("TBL" , row , "VADE" ,GetDateStr(  vl));
		                
		                if(frekansIncrement<faizFrekansOrani  )	               
		                	oMap.put("TBL" , row , "FAIZ_TARIH" ,GetDateStr(  vf));
		                else
		                    oMap.put("TBL" , row , "FAIZ_TARIH" ,oMap.get("TBL" , row , "VADE" ));
		                	
		                frekansIncrement++;
		                
		                oMap.put("TBL" , row , "TUTAR" , faiztutar);
		                oMap.put("TBL" , row , "DOVIZ_KODU" , doviz_kod);
		                oMap.put("TBL" , row , "TATIL" , "Tatil");
		                oMap.put("TBL" , row , "ANAPARAMI" , "H");
		                oMap.put("TBL" , row , "FAIZ" ,  faiz);
		                
					row++;
					if (!condition) {
						oMap.put("TBL", row, "VADE", GetDateStr(vl));
						oMap.put("TBL", row, "TUTAR", tutar);
						oMap.put("TBL", row, "DOVIZ_KODU", doviz_kod);
						oMap.put("TBL", row, "TATIL", "Tatil");
						oMap.put("TBL", row, "ANAPARAMI", "E");
					}

					vt.set(vl.get(Calendar.YEAR), vl.get(Calendar.MONTH),
							vl.get(Calendar.DATE));

				}
			} else {

				// BNSPR_1324_NAKIT_AKIS_WITH_TABLE_BORC servisi icin calisiyor
				int length = iMap.getSize("TBL");
				vf = new GregorianCalendar();
				for (int i = 0; i < length; i++) {

					if ("E".equals(iMap.getString("TBL", i, "ANAPARAMI")))
						break;

					vl = GetCalendar(iMap.getString("TBL", i, "VADE"));

					if (vl.before(vt))
						throw new Exception("Uyumsuz odeme tarihi: " + vl);

					if (vl.after(vd))
						throw new Exception("Uyumsuz odeme tarihi: " + vl);

					BigDecimal gunSayisi = new BigDecimal(gunFarkiniHesapla(vl,
							vt));

					BigDecimal faiztutar = tutar.multiply(faiz);
					faiztutar = faiztutar.multiply(gunSayisi);
					faiztutar = faiztutar.divide(esasGunSayisi, 2,
							RoundingMode.HALF_UP);

					oMap.put("TBL", row, "VADE", GetDateStr(vl));
					oMap.put("TBL", row, "TUTAR", faiztutar);
					oMap.put("TBL", row, "DOVIZ_KODU", doviz_kod);
					oMap.put("TBL", row, "TATIL", "Tatil");
					oMap.put("TBL", row, "ANAPARAMI", "H");
					oMap.put("TBL", row, "FAIZ", faiz);

					  if(frekansIncrement ==faizFrekansOrani  ){
	                         frekansIncrement = 0;
	                         //vf.set(vl.get(Calendar.YEAR) , vl.get(Calendar.MONTH),vl.get(Calendar.DATE));
	                     }
	                     frekansIncrement++;
	                     
	                     if (row==0)
	                    	 oMap.put("TBL" , row , "FAIZ_TARIH" ,GetDateStr(vf));
	                     else
	                     oMap.put("TBL" , row , "FAIZ_TARIH" ,oMap.get("TBL" , row-1 , "VADE" ));
	 
	                     row++;
	                      
	                     vt.set(vl.get(Calendar.YEAR) , vl.get(Calendar.MONTH),vl.get(Calendar.DATE));
	            
	                   }
				
				oMap.put("TBL", row, "VADE", GetDateStr(vd));
				oMap.put("TBL", row, "TUTAR", tutar);
				oMap.put("TBL", row, "DOVIZ_KODU", doviz_kod);
				oMap.put("TBL", row, "TATIL", "Tatil");
				oMap.put("TBL", row, "ANAPARAMI", "E");
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

		}
		return oMap;

	}

	public String[] getBasicMap(String[] nodes, String[][] parentNodes,
			String latterTargetNode) {

		return null;
	}

	public static int findIndex(String[] array, String node) {
		return Arrays.asList(array).indexOf(node);
	}

	public static void ClearDate(Calendar a) {
		a.set(Calendar.HOUR, 0);
		a.set(Calendar.MINUTE, 0);
		a.set(Calendar.SECOND, 0);
		a.set(Calendar.MILLISECOND, 0);
	}

	public static int gunFarkiniHesapla(Calendar a, Calendar b) {
		{
			ClearDate(a);
			ClearDate(b);
			Calendar c1 = new GregorianCalendar(a.get(Calendar.YEAR),
					a.get(Calendar.MONTH), a.get(Calendar.DAY_OF_MONTH));
			Calendar c2 = new GregorianCalendar(b.get(Calendar.YEAR),
					b.get(Calendar.MONTH), b.get(Calendar.DAY_OF_MONTH));
			int aradakiGunSayisi = 0;
			if (c2.before(c1)) {
				while (c2.before(c1)) {
					c2.add(Calendar.DATE, 1);
					aradakiGunSayisi++;
				}
			} else {
				while (c1.before(c2)) {
					c1.add(Calendar.DATE, 1);
					aradakiGunSayisi++;
				}
			}
			return aradakiGunSayisi;
		}
	}

}
