package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY2111Services {

	@GraymoundService("BNSPR_QRY2111_GET_EVE_TESLIM_KOMISYON")
	public static GMMap getEveTeslim(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2110.IAR_KOMISYON_SIPARIS_MUTABAKAT(?,?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("TARIHBAS").getTime()));
			stmt.setDate(++index, new Date(iMap.getDate("TARIHSON").getTime()));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "EVE_TESLIM");

			int size = oMap.getSize("EVE_TESLIM");
			int row = 0;
			BigDecimal gram = BigDecimal.ZERO;
			BigDecimal tutar = BigDecimal.ZERO;

			while (row < size) {
				gram = gram.add(oMap.getBigDecimal("EVE_TESLIM", row, "XAU_TESLIM_GR"));
				tutar = gram.add(oMap.getBigDecimal("EVE_TESLIM", row, "TL_IAR_MASRAF"));
				row++;
			}

			oMap.put("ADET", size);
			oMap.put("KOMISYON", tutar);
			oMap.put("GRAM", gram);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_QRY2111_GET_PTT_FIZIKI_KOMISYON")
	public static GMMap getPTTTeslim(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC2110.PTTFizikiKomisyon(?,?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("TARIHBAS").getTime()));
			stmt.setDate(++index, new Date(iMap.getDate("TARIHSON").getTime()));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "PTT_FIZIKI");

			int size = oMap.getSize("EVE_TESLIM");
			int row = 0;
			BigDecimal gram = BigDecimal.ZERO;
			BigDecimal tutar = BigDecimal.ZERO;

			while (row < size) {
				gram = gram.add(oMap.getBigDecimal("EVE_TESLIM", row, "ISLEM_GRAMI"));
				tutar = gram.add(oMap.getBigDecimal("EVE_TESLIM", row, "IAR_KOMISYON"));
				row++;
			}

			oMap.put("ADET", size);
			oMap.put("KOMISYON", tutar);
			oMap.put("GRAM", gram);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_QRY2111_GET_IAR_KOMISYON")
	public static GMMap getKomisyonlar(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC2110.IAR_KOMISYON_MUTABAKAT(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.setDate(++index, new Date(iMap.getDate("TARIHBAS").getTime()));
			stmt.setDate(++index, new Date(iMap.getDate("TARIHSON").getTime()));
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.registerOutParameter(++index, Types.NUMERIC);
			stmt.execute();
			BigDecimal toplamKomisyon = (BigDecimal) stmt.getObject(index);
			BigDecimal toplamGram = (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamAdet = (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamIntKomisyon = (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamIntGram= (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamIntAdet = (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamPttKomisyon = (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamPttGram= (BigDecimal) stmt.getObject(--index);
			BigDecimal toplamPttAdet = (BigDecimal) stmt.getObject(--index);
			
			oMap.put("toplamKomisyon", toplamKomisyon);
			oMap.put("toplamGram", toplamGram);
			oMap.put("toplamAdet", toplamAdet);
			oMap.put("toplamIntKomisyon", toplamIntKomisyon);
			oMap.put("toplamIntGram", toplamIntGram);
			oMap.put("toplamIntAdet", toplamIntAdet);
			oMap.put("toplamPttKomisyon", toplamPttKomisyon);
			oMap.put("toplamPttGram", toplamPttGram);
			oMap.put("toplamPttAdet", toplamPttAdet);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		

	}

}