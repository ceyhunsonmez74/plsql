package tr.com.calikbank.bnspr.treasury.services;


import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznAltinFonTanimlamaTx;
import tr.com.aktifbank.bnspr.dao.HznAltinFonTanimlamaTxId;
import tr.com.aktifbank.bnspr.dao.HznAltinParametreTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3600Services {
    
    
    @GraymoundService("BNSPR_TRN3600_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName    = "ALTIN_FON_TABLE";
            
            List<?> recordList = (List<?>)iMap.get(tableName);
            
            HznAltinParametreTx hznAltinParametreTx =
                    (HznAltinParametreTx) session.createCriteria(HznAltinParametreTx.class).add(
                            Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
           
            if(hznAltinParametreTx == null){
                hznAltinParametreTx = new HznAltinParametreTx();}
      
            hznAltinParametreTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            hznAltinParametreTx.setAltinSaflikDerecesi(iMap.getBigDecimal("ALTIN_SAFLIK_DERECESI"));
            
            
            session.saveOrUpdate(hznAltinParametreTx);
            session.flush();
            
            for (int row = 0;row<recordList.size();row++) {
               
                if (!(("S").equals(iMap.getString(tableName , row , "G_S"))&&
                        ((iMap.getString(tableName,row, "ISLEM_TURU")==null)||
                                (iMap.getString(tableName,row, "ISLEM_TIPI")==null))))
                    
                {
                HznAltinFonTanimlamaTxId id = new HznAltinFonTanimlamaTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setId(iMap.getBigDecimal(tableName,row,"ID"));
                id.setIslemTipi(iMap.getString(tableName,row,"ISLEM_TIPI"));
                id.setIslemTuru(iMap.getString(tableName,row,"ISLEM_TURU"));
                HznAltinFonTanimlamaTx hznAltinFonTanimlamaTx = (HznAltinFonTanimlamaTx)session.get(HznAltinFonTanimlamaTx.class, id);
               
                if(hznAltinFonTanimlamaTx == null) {
                    hznAltinFonTanimlamaTx = new HznAltinFonTanimlamaTx();
                }
                hznAltinFonTanimlamaTx.setId(id);
              

                hznAltinFonTanimlamaTx.setAltinMiktarMax(iMap.getBigDecimal(tableName,row,"ALTIN_MIKTAR_MAX"));
                hznAltinFonTanimlamaTx.setAltinMiktarMin(iMap.getBigDecimal(tableName,row,"ALTIN_MIKTAR_MIN"));
                hznAltinFonTanimlamaTx.setBorsaKomisyonOrani(iMap.getBigDecimal(tableName,row,"BORSA_KOMISYON_ORANI"));
                hznAltinFonTanimlamaTx.setOtcKomisyonOrani(iMap.getBigDecimal(tableName,row,"OTC_KOMISYON_ORANI"));
                hznAltinFonTanimlamaTx.setGunlukSatisLimiti(iMap.getBigDecimal(tableName,row,"GUNLUK_SATIS_LIMITI"));
                hznAltinFonTanimlamaTx.setIslemSaatBas(iMap.getString(tableName,row,"ISLEM_SAAT_BAS"));
                hznAltinFonTanimlamaTx.setIslemSaatBit(iMap.getString(tableName,row,"ISLEM_SAAT_BIT"));
               

              
                if (("S").equals(iMap.getString(tableName , row , "G_S")))
                    hznAltinFonTanimlamaTx.setGS("S");
                else if (("G").equals(iMap.getString(tableName, row, "G_S")))
                    hznAltinFonTanimlamaTx.setGS("G");
                else hznAltinFonTanimlamaTx.setGS("");
                    
                    session.saveOrUpdate(hznAltinFonTanimlamaTx);
                }
            }
            session.flush();
                
               iMap.put("TRX_NAME","3600");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } 
     }

@GraymoundService("BNSPR_TRN3600_GET_FON_LIST")
public static Map<?, ?> getFonList(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{? = call PKG_TRN3600.GET_FON_LIST}");
        
        int i    = 1;
        stmt.registerOutParameter(i++, -10);
   
        stmt.execute();
   
        rSet = (ResultSet)stmt.getObject(1);
        oMap = DALUtil.rSetResults(rSet, "ALTIN_FON_TABLE");
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }
@GraymoundService("BNSPR_TRN3600_GET_ALTIN_SAF_DER")
public static Map<?, ?> getAltinSaflikDer(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{? = call PKG_TRN3600.GET_ALTIN_SAFLIK_DER}");
        
        int i    = 1;
        stmt.registerOutParameter(i++, Types.NUMERIC);
   
        stmt.execute();
   
        oMap.put("ALTIN_SAFLIK_DERECESI",stmt.getObject(1));
       
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }

@GraymoundService("BNSPR_TRN3600_MUKERRER_TANIM_KONTROLU")
public static GMMap isRecordsUnique(GMMap iMap) throws SQLException {
    
        GMMap oMap = new GMMap();
        
        String tableName = "ALTIN_FON_TABLE";
     
        int rowCount = iMap.getSize(tableName);
        
        for (int i = 0; i < rowCount; i++){
            
            if (!(("S").equals(iMap.getString(tableName , i , "G_S"))&&
                    ((iMap.getString(tableName,i, "ISLEM_TURU")==null)||
                            (iMap.getString(tableName,i, "ISLEM_TIPI")==null))))
            {   
            if (iMap.getString(tableName,i,"ISLEM_TURU") == (null)||iMap.getString(tableName,i,"ISLEM_TURU").equals("")){
                iMap.put("P1","ISLEM TURU");
                iMap.put("HATA_NO",new BigDecimal(330));
                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
            }
            
            if (iMap.getString(tableName,i,"ISLEM_TIPI") == (null)||iMap.getString(tableName,i,"ISLEM_TIPI").equals("")){
                iMap.put("P1","ISLEM TIPI");
                iMap.put("HATA_NO",new BigDecimal(330));
                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
            }
            
            }
            
            for (int j = 0; j < rowCount; j++){
               if (i != j){
                        if (!(iMap.getString(tableName, i, "G_S").equals("S")||iMap.getString(tableName, j, "G_S").equals("S"))) {
                        if (iMap.getString(tableName , i , "ISLEM_TURU").equals(iMap.getString(tableName , j , "ISLEM_TURU")) 
                                &&iMap.getString(tableName , i , "ISLEM_TIPI").equals(iMap.getString(tableName , j , "ISLEM_TIPI"))){
                            iMap.put("HATA_NO" , new BigDecimal(2546));
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                    }
                        if(iMap.getString(tableName,i,"IS_NEW")!=null&&iMap.getString(tableName,i,"IS_NEW").equals("E")){
                            if(UniqueRecordCheck(iMap.getString(tableName,i,"ISLEM_TIPI"),iMap.getString(tableName,i,"ISLEM_TURU"))){
                                iMap.put("HATA_NO" , new BigDecimal(2546));
                                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                            }
                        }
                        }
                 }
                        
            
            }
            }
        
        return oMap;
    }

public static boolean UniqueRecordCheck(String islemTipi,String islemTuru) throws SQLException{
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    try {
    conn = DALUtil.getGMConnection();
    stmt = conn .prepareCall("{? = call PKG_TRN3600.checkUniqRecord(?,?)}");
    stmt.registerOutParameter(1, Types.NUMERIC);
    stmt.setString(2 , islemTipi);
    stmt.setString(3 , islemTuru);
    stmt.execute();
    BigDecimal retVal = stmt.getBigDecimal(1);
     if(retVal.compareTo(BigDecimal.ZERO)==1)
      return true;
     else 
         return false;
    }
     catch (Exception e) {
         
         throw ExceptionHandler.convertException(e);
     
     } finally {
         
         GMServerDatasource.close(rSet);
         GMServerDatasource.close(stmt);
         GMServerDatasource.close(conn);
     
     }
    
}
    
    
    
 

@GraymoundService("BNSPR_TRN3600_GET_INFO")
public static GMMap getTransactionNo(GMMap iMap) {
    
    Connection conn = null;
    
    try{
        
    GMMap oMap = new GMMap();
    conn = DALUtil.getGMConnection();
    Session session = DAOSession.getSession("BNSPRDal");
    String tableName    = "ALTIN_FON_TABLE";
  //  String colorTableName = "TBL_COLOR";
    
    HznAltinParametreTx hznAltinParametreTx =
            (HznAltinParametreTx) session.createCriteria(HznAltinParametreTx.class).add(
                    Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
   

    oMap.put("ALTIN_SAFLIK_DERECESI", hznAltinParametreTx.getAltinSaflikDerecesi());
    
    List<?> list = session.createCriteria(HznAltinFonTanimlamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
        .list();
    
     for (int row = 0; row < list.size(); row++){
         HznAltinFonTanimlamaTx hznAltinFonTanimlamaTx = (HznAltinFonTanimlamaTx) list.get(row);
         
        oMap.put("TRX_NO", hznAltinFonTanimlamaTx.getId().getTxNo());
        oMap.put(tableName, row, "ID", hznAltinFonTanimlamaTx.getId().getId());
        oMap.put(tableName, row, "ISLEM_TURU", hznAltinFonTanimlamaTx.getId().getIslemTuru());
        oMap.put(tableName, row, "ISLEM_TIPI", hznAltinFonTanimlamaTx.getId().getIslemTipi());
        oMap.put(tableName, row, "ALTIN_MIKTAR_MAX", hznAltinFonTanimlamaTx.getAltinMiktarMax());
        oMap.put(tableName, row, "ALTIN_MIKTAR_MIN", hznAltinFonTanimlamaTx.getAltinMiktarMin());
        oMap.put(tableName, row, "BORSA_KOMISYON_ORANI", hznAltinFonTanimlamaTx.getBorsaKomisyonOrani());
        oMap.put(tableName, row, "OTC_KOMISYON_ORANI", hznAltinFonTanimlamaTx.getOtcKomisyonOrani());
        oMap.put(tableName, row, "GUNLUK_SATIS_LIMITI", hznAltinFonTanimlamaTx.getGunlukSatisLimiti());
        oMap.put(tableName, row, "ISLEM_SAAT_BAS", hznAltinFonTanimlamaTx.getIslemSaatBas());
        oMap.put(tableName, row, "ISLEM_SAAT_BIT", hznAltinFonTanimlamaTx.getIslemSaatBit());
        oMap.put(tableName, row, "SIL", ("S").equals(hznAltinFonTanimlamaTx.getGS()) ? true : false);
        oMap.put(tableName, row, "G_S", hznAltinFonTanimlamaTx.getGS());
   /*    
      if ("G".equals(hznAltinFonTanimlamaTx.getGS()) ) {
         
          oMap.put(colorTableName, row, "ISLEM_TURU",getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ISLEM_TIPI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ALTIN_MIKTAR_MAX", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ALTIN_MIKTAR_MIN", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ALTIN_SAFLIK_DERECESI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BORSA_KOMISYON_ORANI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "GUNLUK_SATIS_LIMITI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ISLEM_SAAT_BAS", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ISLEM_SAAT_BIT", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.GREEN));
          
      }
      else if ("S".equals(hznAltinFonTanimlamaTx.getGS())) {
          
          
          oMap.put(colorTableName, row, "ISLEM_TURU",getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ISLEM_TIPI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ALTIN_MIKTAR_MAX", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ALTIN_MIKTAR_MIN", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ALTIN_SAFLIK_DERECESI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BORSA_KOMISYON_ORANI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "GUNLUK_SATIS_LIMITI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ISLEM_SAAT_BAS", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ISLEM_SAAT_BIT", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
          
      }
      else
      {
          
          oMap.put(colorTableName, row, "ISLEM_TURU",getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ISLEM_TIPI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ALTIN_MIKTAR_MAX", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ALTIN_MIKTAR_MIN", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ALTIN_SAFLIK_DERECESI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BORSA_KOMISYON_ORANI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "GUNLUK_SATIS_LIMITI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ISLEM_SAAT_BAS", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ISLEM_SAAT_BIT", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
          }
    */
    }
        
    return oMap;
        
    }catch (Exception e){
        throw ExceptionHandler.convertException(e);
    }finally{
        
        GMServerDatasource.close(conn);
    }
    
}
/* private static GMMap getTableCellColorData(Color backgroundColor){
        GMMap oMap = new GMMap();
        oMap.put("setBackground", backgroundColor);
        return oMap;
    }*/
}
