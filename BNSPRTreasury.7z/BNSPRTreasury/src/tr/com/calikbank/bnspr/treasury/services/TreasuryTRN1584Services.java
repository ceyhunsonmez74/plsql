package tr.com.calikbank.bnspr.treasury.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.MkkGunlukTurevTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1584Services {
	private static final Logger logger = Logger.getLogger(TreasuryTRN1584Services.class);

	@GraymoundService("BNSPR_TRN1584_SAVE")
	public static GMMap save(GMMap iMap) {

		int size = iMap.getSize("GET_LIST");
		if (size > 0) {
			Session session = DAOSession.getSession("BNSPRDal");
			try {

				for (int row = 0; row < size; row++) {

					MkkGunlukTurevTx mkkGunlukTurevTx = new MkkGunlukTurevTx();
					mkkGunlukTurevTx = mkkDoldur(mkkGunlukTurevTx, iMap, row);
					mkkGunlukTurevTx.setQuantity(new BigDecimal(1));

					session.saveOrUpdate(mkkGunlukTurevTx);
				}
				session.flush();

				iMap.put("MESSAGE", size + " sat�r kaydedildi.");
				return iMap;

			}

			catch (Exception e) {
				iMap.put("MESSAGE", e.getMessage());
				throw ExceptionHandler.convertException(e);
			}
			finally {
				session.flush();
			}
		}
		else {
			iMap.put("MESSAGE", "L�tfen kayd� olan bir dosya y�kleyiniz.");
			return iMap;
		}

	}

	@GraymoundService("BNSPR_TRN1584_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1584_YUKLE_EXCEL")
	public static GMMap loadExcelFile(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			byte[] inputFile = (byte[]) iMap.get("DOSYA_YOLU");
			if (inputFile == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Dosya seçmediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Workbook workbook;
			WorkbookSettings ws = new WorkbookSettings();

			// ws.setCharacterSet(cs);
			ws.setEncoding("ISO-8859-9");
			ws.setExcelDisplayLanguage("TR");
			ws.setExcelRegionalSettings("TR");
			// ws.setLocale(new Locale("tr", "TR"));
			try {
				workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
			}
			catch (Exception e) {
				oMap.put("HATA_NO", new BigDecimal(660));
				oMap.put("P1", "Geçerli Bir Excel Dosyası Seçmediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Sheet sheet = workbook.getSheet(0);
			oMap = iMapDoldur(sheet, iMap);
			oMap.put("MESSAGE", "Excel y�klendi,��kmadan �nce kaydediniz.");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}

	private static GMMap iMapDoldur(Sheet sheet, GMMap iMap) {

		int kolon = 0;
		int satir = 0;
		try {
			for (int j = 1; j < sheet.getRows(); j++) {
				satir = j - 1;

				iMap.put("TABLE", satir, "REPORTINGCOUNTERPARTYID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "SENDERREFERENCE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CHANNEL", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BOTHSIDEFLAG", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ACTIONTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "LEVL", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "SENDERMESSAGEREF", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COUNTERPARTYIDTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COUNTERPARTYID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NAMEOFTHECOUNTERPARTY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COUNTRYTHECOUNTERPARTY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NATUREOFREPORTINGCOUNTERPARTY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CORPORATESECTOR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BENEFICIARYIDTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BENEFICIARYNAME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BENEFICIARYID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BRANCHOFFICE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "TRADINGCAPACITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLIENTLIMIT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCLIENTLIMIT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COUNTERPARTYSIDE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DIRECTLYLINKEDTOCOMACT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "HEDGEDETAIL", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "HEDGEINFO", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COLLATERALISATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COLLATERALPORTFOLIO", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COLLATERALPORTFOLIOCODE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCOUNTERPARTYIDTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCOUNTERPARTYID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NAMEOFTHEOTHERCOUNTERPARTY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COUNTRYOFTHEOTHERCOUNTERPARTY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NATUREOFREPORTINGOTHERCOUNTER", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCORPORATESECTOR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERBENEFICIARYIDTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERBENEFICIARYNAME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERBENEFICIARYID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERBRANCHOFFICE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERTRADINGCAPACITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CONTRACTWITHNONEEACOUNTERPARTY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OFFSHORESTATUS", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "SECTORANDOFFSHORECODE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERHEDGEDETAIL", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERHEDGEINFO", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERLINKEDTOCOMACT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCOLLATERALISATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCOLLATERALPORTFOLIO", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERCOLLATERALCODE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BROKERID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BROKERIDTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "BROKERNAME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGMEMBERID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGMEMBERIDTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGMEMBERNAME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGTHRESHOLD", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CONTRACTTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ASSETCLASS", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRODUCTCLASSIFICATIONTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRODUCTCLASSIFICATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRODUCTIDENTIFICATIONTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRODUCTIDENTIFICATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "UNDERLYINGIDENTIFICATIONTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "UNDERLYINGIDENTIFICATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NOTIONALCURRENCY1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NOTIONALCURRENCY2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERABLECURRENCY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "TRADEID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "REPORTTRACKINGNUMBER", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COMPLEXTRADECOMPONENTID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VENUEOFEXECUTION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "REDISCOUNTAMOUNT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OPTIONCONDITION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COMPRESSION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRICERATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRICENOTATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CURRENCYOFPRICE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NOMINALCHANGEPOSSIBILITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "NOTIONAL", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRICEMULTIPLIER", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "QUANTITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "UPFRONTPAYMENT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXECUTIONDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXECUTIONTIME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EFFECTIVEDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "MATURITYDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "TERMINATIONDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "SETTLEMENTDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "MASTERAGREEMENTTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "MASTERAGRREMENTVERSION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CONFIRMATIONDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CONFIRMATIONTIME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CONFIRMATIONMEANS", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGOBLIGATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CLEARINGTIME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CCPID", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CCPTITLE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FIXEDRATEOFLEG1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FIXEDRATEOFLEG2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FXRATEDAYCOUNTLEG1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FXRATEDAYCOUNTLEG2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FXRATEPAYMENTFREQLEG1TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FXRATEPAYMENTFREQLEG1M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FXRATEPAYMENTFREQLEG2TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FXRATEPAYMENTFREQLEG2M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEPAYMENTFREQLEG1TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEPAYMENTFREQLEG1M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEPAYMENTFREQLEG2TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEPAYMENTFREQLEG2M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATERESETFREQLEG1TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATERESETFREQLEG1M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATERESETFREQLEG2TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATERESETFREQLEG2M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FLOATINGRATEOFLEG1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEREFPERIODLEG1TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEREFPERIODLEG1M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FLOATINGRATEOFLEG2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEREFPERIODLEG2TP", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FRATEREFPERIODLEG2M", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ADDBONUSRATEREFLEG1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ADDBONUSRATEREFLEG2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CURRENCY2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCHANGERATE1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FORWARDEXCHANGERATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCHANGERATEBASIS1", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCHANGERATEBASIS2", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COMMODITYBASE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "COMMODITYDETAILS", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYPOINTORZONE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INTERCONNECTIONPOINT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "LOADTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "LOADDELIVERYRATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYSTARTDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYSTARTTIME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYENDDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYENDTIME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYPERIOD", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELIVERYDAYS", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CONTRACTCAPACITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "QUANTITYUNIT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "PRICETIMEINTERVALQUANTITIES", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OPTIONTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OPTIONEXERCISESTYLE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "STRIKEPRICE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "STRIKEPRICENOTATION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "MATURITYDATEOFUNDERLYING", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DELTA", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "GAMA", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "SENIORITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "REFERENCEENTITY", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "FREQUENCYOFPAYMENT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CALCULATIONBASIS", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "SERIES", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VERSION", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INDEXFACTOR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "TRANCHE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ATTACHMENTPOINT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "DETACHMENTPOINT", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "MARKTOMARKETVALUE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CURRENCYOFMARKTOMARKETVALUE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VALUATIONDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VALUATIONTIME", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VALUATIONTYPE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INITIALMARGINPOSTED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INITIALMARGINPOSTEDCUR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VARIATIONMARGINPOSTED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VARIATIONMARGINPOSTEDCUR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INITIALMARGINRECEIVED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INITIALMARGINRECEIVEDCUR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VARIATIONMARGINRECEIVED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "VARIATIONMARGINRECEIVEDCUR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCESSCOLLATERALPOSTED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCESSCOLLATERALPOSTEDCUR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCESSCOLLATERALRECEIVED", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "EXCESSCOLLATERALRECEIVEDCUR", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERINVESMENTPURPOSE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "INVESMENTPURPOSE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "OTHERRISKGROUPCODE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ELIGIBILITYDATE", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "CURRENCYOFORIGINALNOTIONAL", sheet.getCell(kolon++, j).getContents());
				iMap.put("TABLE", satir, "ORIGINALNOTIONAL", sheet.getCell(kolon++, j).getContents());
				kolon = 0;
			}
		}
		catch (Exception e) {

			iMap.put("RESPONSE_DATA", satir + "-" + kolon + ". sat�r hatal�:" + e.getLocalizedMessage());
			logger.debug("MKK HATA:" + satir + "-" + kolon + ". sat�r hatal�:" + e.getLocalizedMessage());

			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}

	private static MkkGunlukTurevTx mkkDoldur(MkkGunlukTurevTx mkk, GMMap iMap, int row) {

		try {
			Connection conn = null;
			CallableStatement stmt = null;

			int size = iMap.getSize("GET_LIST");

			mkk.setReportingcounterpartyid(iMap.getString("GET_LIST", row, "REPORTINGCOUNTERPARTYID"));
			mkk.setChannel(iMap.getString("GET_LIST", row, "CHANNEL"));
			mkk.setBothsideflag(iMap.getString("GET_LIST", row, "BOTHSIDEFLAG"));
			mkk.setActiontype(iMap.getString("GET_LIST", row, "ACTIONTYPE"));
			mkk.setLevl(iMap.getString("GET_LIST", row, "LEVL"));
			mkk.setCounterpartyidtype(iMap.getString("GET_LIST", row, "COUNTERPARTYIDTYPE"));
			mkk.setCounterpartyid(iMap.getString("GET_LIST", row, "COUNTERPARTYID"));
			mkk.setNameofthecounterparty(iMap.getString("GET_LIST", row, "NAMEOFTHECOUNTERPARTY"));
			mkk.setCountrythecounterparty(iMap.getString("GET_LIST", row, "COUNTRYTHECOUNTERPARTY"));
			mkk.setNatureofreportingcounterparty(iMap.getString("GET_LIST", row, "NATUREOFREPORTINGCOUNTERPARTY"));
			mkk.setCorporatesector(iMap.getString("GET_LIST", row, "CORPORATESECTOR"));
			mkk.setBeneficiaryidtype(iMap.getString("GET_LIST", row, "BENEFICIARYIDTYPE"));
			mkk.setBeneficiaryname(iMap.getString("GET_LIST", row, "BENEFICIARYNAME"));
			mkk.setBeneficiaryid(iMap.getString("GET_LIST", row, "BENEFICIARYID"));
			mkk.setBranchoffice(iMap.getString("GET_LIST", row, "BRANCHOFFICE"));
			mkk.setTradingcapacity(iMap.getString("GET_LIST", row, "TRADINGCAPACITY"));
			mkk.setClientlimit(iMap.getBigDecimal("GET_LIST", row, "CLIENTLIMIT"));
			mkk.setOtherclientlimit(iMap.getBigDecimal("GET_LIST", row, "OTHERCLIENTLIMIT"));
			mkk.setCounterpartyside(iMap.getString("GET_LIST", row, "COUNTERPARTYSIDE"));
			mkk.setDirectlylinkedtocomact(iMap.getString("GET_LIST", row, "DIRECTLYLINKEDTOCOMACT"));
			mkk.setHedgedetail(iMap.getString("GET_LIST", row, "HEDGEDETAIL"));
			mkk.setHedgeinfo(iMap.getString("GET_LIST", row, "HEDGEINFO"));
			mkk.setCollateralisation(iMap.getString("GET_LIST", row, "COLLATERALISATION"));
			mkk.setCollateralportfolio(iMap.getString("GET_LIST", row, "COLLATERALPORTFOLIO"));
			mkk.setCollateralportfoliocode(iMap.getString("GET_LIST", row, "COLLATERALPORTFOLIOCODE"));
			mkk.setOthercounterpartyidtype(iMap.getString("GET_LIST", row, "OTHERCOUNTERPARTYIDTYPE"));
			mkk.setOthercounterpartyid(iMap.getString("GET_LIST", row, "OTHERCOUNTERPARTYID"));
			mkk.setNameoftheothercounterparty(iMap.getString("GET_LIST", row, "NAMEOFTHEOTHERCOUNTERPARTY"));
			mkk.setCountryoftheothercounterparty(iMap.getString("GET_LIST", row, "COUNTRYOFTHEOTHERCOUNTERPARTY"));
			mkk.setNatureofreportingothercounter(iMap.getString("GET_LIST", row, "NATUREOFREPORTINGOTHERCOUNTER"));
			mkk.setOthercorporatesector(iMap.getString("GET_LIST", row, "OTHERCORPORATESECTOR"));
			mkk.setOtherbeneficiaryidtype(iMap.getString("GET_LIST", row, "OTHERBENEFICIARYIDTYPE"));
			mkk.setOtherbeneficiaryname(iMap.getString("GET_LIST", row, "OTHERBENEFICIARYNAME"));
			mkk.setOtherbeneficiaryid(iMap.getString("GET_LIST", row, "OTHERBENEFICIARYID"));
			mkk.setOtherbranchoffice(iMap.getString("GET_LIST", row, "OTHERBRANCHOFFICE"));
			mkk.setOthertradingcapacity(iMap.getString("GET_LIST", row, "OTHERTRADINGCAPACITY"));
			mkk.setContractwithnoneeacounterparty(iMap.getString("GET_LIST", row, "CONTRACTWITHNONEEACOUNTERPARTY"));
			mkk.setOffshorestatus(iMap.getString("GET_LIST", row, "OFFSHORESTATUS"));
			mkk.setSectorandoffshorecode(iMap.getString("GET_LIST", row, "SECTORANDOFFSHORECODE"));
			mkk.setOtherhedgedetail(iMap.getString("GET_LIST", row, "OTHERHEDGEDETAIL"));
			mkk.setOtherhedgeinfo(iMap.getString("GET_LIST", row, "OTHERHEDGEINFO"));
			mkk.setOtherlinkedtocomact(iMap.getString("GET_LIST", row, "OTHERLINKEDTOCOMACT"));
			mkk.setOthercollateralisation(iMap.getString("GET_LIST", row, "OTHERCOLLATERALISATION"));
			mkk.setOthercollateralportfolio(iMap.getString("GET_LIST", row, "OTHERCOLLATERALPORTFOLIO"));
			mkk.setOthercollateralcode(iMap.getString("GET_LIST", row, "OTHERCOLLATERALCODE"));
			mkk.setBrokerid(iMap.getString("GET_LIST", row, "BROKERID"));
			mkk.setBrokeridtype(iMap.getString("GET_LIST", row, "BROKERIDTYPE"));
			mkk.setBrokername(iMap.getString("GET_LIST", row, "BROKERNAME"));
			mkk.setClearingmemberid(iMap.getString("GET_LIST", row, "CLEARINGMEMBERID"));
			mkk.setClearingmemberidtype(iMap.getString("GET_LIST", row, "CLEARINGMEMBERIDTYPE"));
			mkk.setClearingmembername(iMap.getString("GET_LIST", row, "CLEARINGMEMBERNAME"));
			mkk.setClearingthreshold(iMap.getString("GET_LIST", row, "CLEARINGTHRESHOLD"));
			mkk.setContracttype(iMap.getString("GET_LIST", row, "CONTRACTTYPE"));
			mkk.setAssetclass(iMap.getString("GET_LIST", row, "ASSETCLASS"));
			mkk.setProductclassificationtype(iMap.getString("GET_LIST", row, "PRODUCTCLASSIFICATIONTYPE"));
			mkk.setProductclassification(iMap.getString("GET_LIST", row, "PRODUCTCLASSIFICATION"));
			mkk.setProductidentificationtype(iMap.getString("GET_LIST", row, "PRODUCTIDENTIFICATIONTYPE"));
			mkk.setProductidentification(iMap.getString("GET_LIST", row, "PRODUCTIDENTIFICATION"));
			mkk.setUnderlyingidentificationtype(iMap.getString("GET_LIST", row, "UNDERLYINGIDENTIFICATIONTYPE"));
			mkk.setUnderlyingidentification(iMap.getString("GET_LIST", row, "UNDERLYINGIDENTIFICATION"));
			mkk.setNotionalcurrency1(iMap.getString("GET_LIST", row, "NOTIONALCURRENCY1"));
			mkk.setNotionalcurrency2(iMap.getString("GET_LIST", row, "NOTIONALCURRENCY2"));
			mkk.setDeliverablecurrency(iMap.getString("GET_LIST", row, "DELIVERABLECURRENCY"));
			mkk.setTradeid(iMap.getString("GET_LIST", row, "TRADEID"));
			mkk.setReporttrackingnumber(iMap.getString("GET_LIST", row, "REPORTTRACKINGNUMBER"));
			mkk.setComplextradecomponentid(iMap.getString("GET_LIST", row, "COMPLEXTRADECOMPONENTID"));
			mkk.setVenueofexecution(iMap.getString("GET_LIST", row, "VENUEOFEXECUTION"));
			mkk.setRediscountamount(iMap.getBigDecimal("GET_LIST", row, "REDISCOUNTAMOUNT"));
			mkk.setOptioncondition(iMap.getString("GET_LIST", row, "OPTIONCONDITION"));
			mkk.setCompression(iMap.getString("GET_LIST", row, "COMPRESSION"));
			mkk.setPricerate(iMap.getBigDecimal("GET_LIST", row, "PRICERATE"));
			mkk.setPricenotation(iMap.getString("GET_LIST", row, "PRICENOTATION"));
			mkk.setCurrencyofprice(iMap.getString("GET_LIST", row, "CURRENCYOFPRICE"));
			mkk.setNominalchangepossibility(iMap.getString("GET_LIST", row, "NOMINALCHANGEPOSSIBILITY"));
			mkk.setNotional(iMap.getBigDecimal("GET_LIST", row, "NOTIONAL"));
			mkk.setPricemultiplier(iMap.getBigDecimal("GET_LIST", row, "PRICEMULTIPLIER"));
			// mkk.setQuantity(iMap.getBigDecimal("GET_LIST", row, "QUANTITY"));
			mkk.setUpfrontpayment(iMap.getBigDecimal("GET_LIST", row, "UPFRONTPAYMENT"));
			mkk.setDeliverytype(iMap.getString("GET_LIST", row, "DELIVERYTYPE"));
			mkk.setExecutiondate(iMap.getString("GET_LIST", row, "EXECUTIONDATE"));
			mkk.setExecutiontime(iMap.getString("GET_LIST", row, "EXECUTIONTIME"));
			mkk.setEffectivedate(iMap.getString("GET_LIST", row, "EFFECTIVEDATE"));
			mkk.setMaturitydate(iMap.getString("GET_LIST", row, "MATURITYDATE"));
			mkk.setTerminationdate(iMap.getString("GET_LIST", row, "TERMINATIONDATE"));
			mkk.setSettlementdate(iMap.getString("GET_LIST", row, "SETTLEMENTDATE"));
			mkk.setMasteragreementtype(iMap.getString("GET_LIST", row, "MASTERAGREEMENTTYPE"));
			mkk.setMasteragrrementversion(iMap.getBigDecimal("GET_LIST", row, "MASTERAGRREMENTVERSION"));
			mkk.setConfirmationdate(iMap.getString("GET_LIST", row, "CONFIRMATIONDATE"));
			mkk.setConfirmationtime(iMap.getString("GET_LIST", row, "CONFIRMATIONTIME"));
			mkk.setConfirmationmeans(iMap.getString("GET_LIST", row, "CONFIRMATIONMEANS"));
			mkk.setClearingobligation(iMap.getString("GET_LIST", row, "CLEARINGOBLIGATION"));
			mkk.setCleared(iMap.getString("GET_LIST", row, "CLEARED"));
			mkk.setClearingdate(iMap.getString("GET_LIST", row, "CLEARINGDATE"));
			mkk.setClearingtime(iMap.getString("GET_LIST", row, "CLEARINGTIME"));
			mkk.setCcpid(iMap.getString("GET_LIST", row, "CCPID"));
			mkk.setCcptitle(iMap.getString("GET_LIST", row, "CCPTITLE"));
			mkk.setFixedrateofleg1(iMap.getBigDecimal("GET_LIST", row, "FIXEDRATEOFLEG1"));
			mkk.setFixedrateofleg2(iMap.getBigDecimal("GET_LIST", row, "FIXEDRATEOFLEG2"));
			mkk.setFxratedaycountleg1(iMap.getBigDecimal("GET_LIST", row, "FXRATEDAYCOUNTLEG1"));
			mkk.setFxratedaycountleg2(iMap.getBigDecimal("GET_LIST", row, "FXRATEDAYCOUNTLEG2"));
			mkk.setFxratepaymentfreqleg1tp(iMap.getString("GET_LIST", row, "FXRATEPAYMENTFREQLEG1TP"));
			mkk.setFxratepaymentfreqleg1m(iMap.getBigDecimal("GET_LIST", row, "FXRATEPAYMENTFREQLEG1M"));
			mkk.setFxratepaymentfreqleg2tp(iMap.getString("GET_LIST", row, "FXRATEPAYMENTFREQLEG2TP"));
			mkk.setFxratepaymentfreqleg2m(iMap.getBigDecimal("GET_LIST", row, "FXRATEPAYMENTFREQLEG2M"));
			mkk.setFratepaymentfreqleg1tp(iMap.getString("GET_LIST", row, "FRATEPAYMENTFREQLEG1TP"));
			mkk.setFratepaymentfreqleg1m(iMap.getBigDecimal("GET_LIST", row, "FRATEPAYMENTFREQLEG1M"));
			mkk.setFratepaymentfreqleg2tp(iMap.getString("GET_LIST", row, "FRATEPAYMENTFREQLEG2TP"));
			mkk.setFratepaymentfreqleg2m(iMap.getBigDecimal("GET_LIST", row, "FRATEPAYMENTFREQLEG2M"));
			mkk.setFrateresetfreqleg1tp(iMap.getString("GET_LIST", row, "FRATERESETFREQLEG1TP"));
			mkk.setFrateresetfreqleg1m(iMap.getBigDecimal("GET_LIST", row, "FRATERESETFREQLEG1M"));
			mkk.setFrateresetfreqleg2tp(iMap.getString("GET_LIST", row, "FRATERESETFREQLEG2TP"));
			mkk.setFrateresetfreqleg2m(iMap.getString("GET_LIST", row, "FRATERESETFREQLEG2M"));
			mkk.setFloatingrateofleg1(iMap.getString("GET_LIST", row, "FLOATINGRATEOFLEG1"));
			mkk.setFraterefperiodleg1tp(iMap.getString("GET_LIST", row, "FRATEREFPERIODLEG1TP"));
			mkk.setFraterefperiodleg1m(iMap.getBigDecimal("GET_LIST", row, "FRATEREFPERIODLEG1M"));
			mkk.setFloatingrateofleg2(iMap.getString("GET_LIST", row, "FLOATINGRATEOFLEG2"));
			mkk.setFraterefperiodleg2tp(iMap.getString("GET_LIST", row, "FRATEREFPERIODLEG2TP"));
			mkk.setFraterefperiodleg2m(iMap.getBigDecimal("GET_LIST", row, "FRATEREFPERIODLEG2M"));
			mkk.setAddbonusraterefleg1(iMap.getBigDecimal("GET_LIST", row, "ADDBONUSRATEREFLEG1"));
			mkk.setAddbonusraterefleg2(iMap.getBigDecimal("GET_LIST", row, "ADDBONUSRATEREFLEG2"));
			mkk.setCurrency2(iMap.getString("GET_LIST", row, "CURRENCY2"));
			mkk.setExchangerate1(iMap.getBigDecimal("GET_LIST", row, "EXCHANGERATE1"));
			mkk.setForwardexchangerate(iMap.getString("GET_LIST", row, "FORWARDEXCHANGERATE"));
			mkk.setExchangeratebasis1(iMap.getString("GET_LIST", row, "EXCHANGERATEBASIS1"));
			mkk.setExchangeratebasis2(iMap.getString("GET_LIST", row, "EXCHANGERATEBASIS2"));
			mkk.setCommoditybase(iMap.getString("GET_LIST", row, "COMMODITYBASE"));
			mkk.setCommoditydetails(iMap.getString("GET_LIST", row, "COMMODITYDETAILS"));
			mkk.setDeliverypointorzone(iMap.getString("GET_LIST", row, "DELIVERYPOINTORZONE"));
			mkk.setInterconnectionpoint(iMap.getString("GET_LIST", row, "INTERCONNECTIONPOINT"));
			mkk.setLoadtype(iMap.getString("GET_LIST", row, "LOADTYPE"));
			mkk.setLoaddeliveryrate(iMap.getString("GET_LIST", row, "LOADDELIVERYRATE"));
			mkk.setDeliverystartdate(iMap.getString("GET_LIST", row, "DELIVERYSTARTDATE"));
			mkk.setDeliverystarttime(iMap.getString("GET_LIST", row, "DELIVERYSTARTTIME"));
			mkk.setDeliveryenddate(iMap.getString("GET_LIST", row, "DELIVERYENDDATE"));
			mkk.setDeliveryendtime(iMap.getString("GET_LIST", row, "DELIVERYENDTIME"));
			mkk.setDeliveryperiod(iMap.getString("GET_LIST", row, "DELIVERYPERIOD"));
			mkk.setDeliverydays(iMap.getString("GET_LIST", row, "DELIVERYDAYS"));
			mkk.setContractcapacity(iMap.getBigDecimal("GET_LIST", row, "CONTRACTCAPACITY"));
			mkk.setQuantityunit(iMap.getString("GET_LIST", row, "QUANTITYUNIT"));
			mkk.setPricetimeintervalquantities(iMap.getBigDecimal("GET_LIST", row, "PRICETIMEINTERVALQUANTITIES"));
			mkk.setOptiontype(iMap.getString("GET_LIST", row, "OPTIONTYPE"));
			mkk.setOptionexercisestyle(iMap.getString("GET_LIST", row, "OPTIONEXERCISESTYLE"));
			mkk.setStrikeprice(iMap.getBigDecimal("GET_LIST", row, "STRIKEPRICE"));
			mkk.setStrikepricenotation(iMap.getString("GET_LIST", row, "STRIKEPRICENOTATION"));
			mkk.setMaturitydateofunderlying(iMap.getString("GET_LIST", row, "MATURITYDATEOFUNDERLYING"));
			mkk.setDelta(iMap.getString("GET_LIST", row, "DELTA"));
			mkk.setGama(iMap.getString("GET_LIST", row, "GAMA"));
			mkk.setSeniority(iMap.getString("GET_LIST", row, "SENIORITY"));
			mkk.setReferenceentity(iMap.getString("GET_LIST", row, "REFERENCEENTITY"));
			mkk.setFrequencyofpayment(iMap.getString("GET_LIST", row, "FREQUENCYOFPAYMENT"));
			mkk.setCalculationbasis(iMap.getString("GET_LIST", row, "CALCULATIONBASIS"));
			mkk.setSeries(iMap.getBigDecimal("GET_LIST", row, "SERIES"));
			mkk.setVersion(iMap.getBigDecimal("GET_LIST", row, "VERSION"));
			mkk.setIndexfactor(iMap.getBigDecimal("GET_LIST", row, "INDEXFACTOR"));
			mkk.setTranche(iMap.getString("GET_LIST", row, "TRANCHE"));
			mkk.setAttachmentpoint(iMap.getBigDecimal("GET_LIST", row, "ATTACHMENTPOINT"));
			mkk.setDetachmentpoint(iMap.getBigDecimal("GET_LIST", row, "DETACHMENTPOINT"));
			mkk.setMarktomarketvalue(iMap.getString("GET_LIST", row, "MARKTOMARKETVALUE"));
			mkk.setCurrencyofmarktomarketvalue(iMap.getString("GET_LIST", row, "CURRENCYOFMARKTOMARKETVALUE"));
			mkk.setValuationdate(iMap.getString("GET_LIST", row, "VALUATIONDATE"));
			mkk.setValuationtime(iMap.getString("GET_LIST", row, "VALUATIONTIME"));
			mkk.setValuationtype(iMap.getString("GET_LIST", row, "VALUATIONTYPE"));
			mkk.setInitialmarginposted(iMap.getBigDecimal("GET_LIST", row, "INITIALMARGINPOSTED"));
			mkk.setInitialmarginpostedcur(iMap.getString("GET_LIST", row, "INITIALMARGINPOSTEDCUR"));
			mkk.setVariationmarginposted(iMap.getBigDecimal("GET_LIST", row, "VARIATIONMARGINPOSTED"));
			mkk.setVariationmarginpostedcur(iMap.getString("GET_LIST", row, "VARIATIONMARGINPOSTEDCUR"));
			mkk.setInitialmarginreceived(iMap.getBigDecimal("GET_LIST", row, "INITIALMARGINRECEIVED"));
			mkk.setInitialmarginreceivedcur(iMap.getString("GET_LIST", row, "INITIALMARGINRECEIVEDCUR"));
			mkk.setVariationmarginreceived(iMap.getBigDecimal("GET_LIST", row, "VARIATIONMARGINRECEIVED"));
			mkk.setVariationmarginreceivedcur(iMap.getString("GET_LIST", row, "VARIATIONMARGINRECEIVEDCUR"));
			mkk.setExcesscollateralposted(iMap.getBigDecimal("GET_LIST", row, "EXCESSCOLLATERALPOSTED"));
			mkk.setExcesscollateralpostedcur(iMap.getString("GET_LIST", row, "EXCESSCOLLATERALPOSTEDCUR"));
			mkk.setExcesscollateralreceived(iMap.getBigDecimal("GET_LIST", row, "EXCESSCOLLATERALRECEIVED"));
			mkk.setExcesscollateralreceivedcur(iMap.getString("GET_LIST", row, "EXCESSCOLLATERALRECEIVEDCUR"));
			mkk.setOtherinvesmentpurpose(iMap.getString("GET_LIST", row, "OTHERINVESMENTPURPOSE"));
			mkk.setInvestmentpurpose(iMap.getString("GET_LIST", row, "INVESMENTPURPOSE"));
			mkk.setOtherriskgroupcode(iMap.getString("GET_LIST", row, "OTHERRISKGROUPCODE"));
			mkk.setEligibilitydate(iMap.getString("GET_LIST", row, "ELIGIBILITYDATE"));
			mkk.setCurrencyoforiginalnotional(iMap.getString("GET_LIST", row, "CURRENCYOFORIGINALNOTIONAL"));
			mkk.setOriginalnotional(iMap.getString("GET_LIST", row, "ORIGINALNOTIONAL"));
			mkk.setSenderreference(iMap.getString("TRX_NO"));
			mkk.setSendermessageref(iMap.getString("TRX_NO"));
			mkk.setTxNo(new BigDecimal(iMap.getString("TRX_NO")));			
		//	mkk.setRecDate(Calendar.getInstance().getTime());
		//	mkk.setRecOwner(GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", iMap).getString("KULLANICI_KOD"));

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call bnspr.PKG_GENEL_PR.genel_kod_al('MKK_GUNLUK_TUREV')}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();

			mkk.setId(stmt.getBigDecimal(1));
			conn.close();

		}
		catch (Exception e) {
			System.out.println("hatal� satir:" + iMap.getString("GET_LIST", row, "REPORTTRACKINGNUMBER"));
			logger.debug("MKK DOLDUR HATA:" + row + ". sat�r hatal�:" + e.getLocalizedMessage());
			throw ExceptionHandler.convertException(e);
		}
		return mkk;
	}
}
