package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.Map;

import org.hibernate.Session;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1575Services {

	@GraymoundService("BNSPR_TRN1575_SAVE")
	public static Map<?, ?> saveTRN3160(GMMap iMap) {
		int size = iMap.getSize("TABLE");
		int updateSayisi = 0;
		StringBuffer message = new StringBuffer();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			for (int row = 0; row < size; row++) {
				
				// Opsiyon kullanimi 'Evet' veya 'Hayir' mi?
				if ("E".equals(iMap.getString("TABLE", row, "KULLANIM")) || 
						"H".equals(iMap.getString("TABLE", row, "KULLANIM"))) {
					
					String referans = iMap.getString("TABLE", row, "REFERANS");
					
					// yeni trx_no alinir
					GMMap trxMap = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap());
					BigDecimal trxNo = trxMap.getBigDecimal("TRX_NO");
					
					/*
					 * Opsiyon islemi kayit ediliyor
					 */
					HznOpsiyonislemTx hznOpsiyonislemTx = new HznOpsiyonislemTx();
					HznOpsiyonislemTxId id = new HznOpsiyonislemTxId();
					
			        id.setReferans(referans);
			        id.setTxNo(trxNo);
			        
			        hznOpsiyonislemTx.setId(id);
					hznOpsiyonislemTx.setSubePyKod(iMap.getString("TABLE", row, "SUBE_PY_KOD"));
					hznOpsiyonislemTx.setMusteriNo(iMap.getBigDecimal("TABLE", row, "MUSTERI_NO"));
					hznOpsiyonislemTx.setOpsAmac(iMap.getString("TABLE", row, "OPS_AMAC"));
					hznOpsiyonislemTx.setOpsSekliBaz(iMap.getString("TABLE", row, "OPS_SEKLI_BAZ"));
					hznOpsiyonislemTx.setHedefFiyat(iMap.getBigDecimal("TABLE", row, "HEDEF_FIYAT"));
					hznOpsiyonislemTx.setBazDvz(iMap.getString("TABLE", row, "BAZ_DVZ"));
					hznOpsiyonislemTx.setBazTutar(iMap.getBigDecimal("TABLE", row, "BAZ_TUTAR"));
					hznOpsiyonislemTx.setPrimMaliyet(iMap.getBigDecimal("TABLE", row, "PRIM_MALIYET"));
					hznOpsiyonislemTx.setPrimMusteri(iMap.getBigDecimal("TABLE", row, "PRIM_MUSTERI"));
					hznOpsiyonislemTx.setTarihIslem(iMap.getDate("TABLE", row, "TARIH_ISLEM"));
					hznOpsiyonislemTx.setTarihUzlasma(iMap.getDate("TABLE", row, "TARIH_UZLASMA"));
					hznOpsiyonislemTx.setTarihVade(iMap.getDate("TABLE", row, "TARIH_VADE"));
					hznOpsiyonislemTx.setOpsTipi(iMap.getString("TABLE", row, "OPS_TIPI"));
					hznOpsiyonislemTx.setKullanildimi(iMap.getString("TABLE", row, "KULLANIM"));
					hznOpsiyonislemTx.setKarsiDoviz(iMap.getString("TABLE", row, "KARSI_DOVIZ"));
					hznOpsiyonislemTx.setOpsStatus("KP");

                    hznOpsiyonislemTx.setKullanimFiyati(iMap.getBigDecimal("TABLE", row, "KULLANIM_FIYATI"));
                    hznOpsiyonislemTx.setNakitUzlasi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("TABLE", row, "NAKIT_UZLASI")));
					
					session.saveOrUpdate(hznOpsiyonislemTx);
					session.flush();
					
					/*
					 * Trx start edilir
					 */
					trxMap.put("TRX_NAME", "1575");
					trxMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", trxMap);
					
					updateSayisi ++;
					
					message.append(" ( ");
					message.append(updateSayisi);
					message.append(" ) ");
					message.append(trxMap.getString("MESSAGE"));
					message.append("----------");
				}
			}
			
			if (updateSayisi == 0)
				throw new GMRuntimeException(0, "Kay�t i�in en az bir g�ncelleme yap�lmal�d�r");
			
			GMMap oMap = new GMMap();
			oMap.put ("MESSAGE", message.toString());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1575_INITIALIZE")
	public static GMMap initialize1575(GMMap iMap) {

		String func = "{ ? = call PKG_TRN1575.YasayanOpsiyonListesi}";
		GMMap oMap = new GMMap();

		String param = "ALIS_SATIS";
		GuimlUtil.wrapMyCombo(oMap, param, null, null);
		GuimlUtil.wrapMyCombo(oMap, param, "A", "Banka Al��");
		GuimlUtil.wrapMyCombo(oMap, param, "S", "Banka Sat��");

		param = "OPS_SEKLI";
		GuimlUtil.wrapMyCombo(oMap, param, null, null);
		GuimlUtil.wrapMyCombo(oMap, param, "C", "CALL");
		GuimlUtil.wrapMyCombo(oMap, param, "P", "PUT");

		param = "OPS_TIPI";
		GuimlUtil.wrapMyCombo(oMap, param, null, null);
		GuimlUtil.wrapMyCombo(oMap, param, "AVR", "Avrupa");
		GuimlUtil.wrapMyCombo(oMap, param, "AMR", "Amerika");

		param = "KULLANIM";
		GuimlUtil.wrapMyCombo(oMap, param, null, "Seciniz");
		GuimlUtil.wrapMyCombo(oMap, param, "E", "Evet");
		GuimlUtil.wrapMyCombo(oMap, param, "H", "Hayir");
		
		DALUtil.fillComboBox(oMap, "BAZ_DOVIZ", true, "SELECT ALL KOD, KOD FROM v_ml_gnl_doviz_kod_pr ORDER BY sira_no");		
		DALUtil.fillComboBox(oMap, "OPS_CINSI", true, "select KEY1, TEXT from V_ML_GNL_PARAM_TEXT t WHERE T.KOD = 'OPSIYON_CINSI' ORDER BY TEXT");
		
		try {
			oMap.put("TABLE", DALUtil.callOracleRefCursorFunction(func, "TABLE", new Object[0]).get("TABLE"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1575_GET_INFO")
	public static GMMap getInfo1575(GMMap iMap) {
		try {
			/*
			 * inputs
			 */
			BigDecimal musteriNo = iMap.getBigDecimal("TRX_NO");
			
			/*
			 * call func.
			 */
			String func = "{? = call pkg_trn1575.getopsiyontx(?)}";
			String listName = "TABLE";
			
			GMMap results = DALUtil.callOracleRefCursorFunction(func, listName, BnsprType.NUMBER, musteriNo);
			
			for (int i = 0; i < results.getSize(listName); i++) {
				results.put(listName, i, "KULLANIM", results.get(listName, i, "KULLANILDIMI"));
			}
			/*
			 * return
			 */
			return results;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
