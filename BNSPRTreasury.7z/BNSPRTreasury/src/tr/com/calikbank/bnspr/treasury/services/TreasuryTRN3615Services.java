package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinVerilendepoTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3615Services {
    
    @GraymoundService("BNSPR_TRN3615_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        CallableStatement stmt2 = null;

        GMMap oMap = new GMMap();
        iMap.put("KOD", "HZN_VADE_ISLEM_BILGISI");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_VADE_ISLEM_BILGISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        iMap.put("KOD", "HZN_ALTIN_DEPO_ISLEM_TURU");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_ALTIN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_ALTIN_FON.saflik_derecesi }");
            int i = 1;
            stmt.registerOutParameter(i, Types.NUMERIC);
            stmt.execute();
            oMap.put("SAFLIK_DERECESI", stmt.getBigDecimal(i));

            
            stmt2 = conn.prepareCall("{ ? = call PKG_ALTIN_FON.DEPO_KOMISYON_ORANI(?) }");
            int j = 1;
            stmt2.registerOutParameter(j++, Types.NUMERIC);
            stmt2.setString(j++ , "SATIS");
            stmt2.execute();
            oMap.put("KOMISYON_ORANI", stmt2.getBigDecimal(1));
            
            return oMap;
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(stmt2);
            GMServerDatasource.close(conn);
        }

    }

 

	@GraymoundService("BNSPR_TRN3615_SAVE")
    public static Map<?, ?> save(GMMap iMap){
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilenDepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAltinVerilenDepoTx == null) {
			    hznAltinVerilenDepoTx = new HznAltinVerilendepoTx();
			}
			
			hznAltinVerilenDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAltinVerilenDepoTx.setModulTurKod("HAZINE");
			hznAltinVerilenDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAltinVerilenDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAltinVerilenDepoTx.setReferans(iMap.getString("REFERANS"));
			hznAltinVerilenDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznAltinVerilenDepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznAltinVerilenDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAltinVerilenDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAltinVerilenDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAltinVerilenDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAltinVerilenDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAltinVerilenDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAltinVerilenDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAltinVerilenDepoTx.setNetTutar(iMap.getBigDecimal("NET_TUTAR"));
			hznAltinVerilenDepoTx.setBrutTutar(iMap.getBigDecimal("BRUT_TUTAR"));
			hznAltinVerilenDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAltinVerilenDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAltinVerilenDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAltinVerilenDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAltinVerilenDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAltinVerilenDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAltinVerilenDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAltinVerilenDepoTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			hznAltinVerilenDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			hznAltinVerilenDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznAltinVerilenDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			hznAltinVerilenDepoTx.setStokNo(iMap.getString("STOK_NO"));
			hznAltinVerilenDepoTx.setSaflikDerecesi(iMap.getBigDecimal("SAFLIK_DERECESI"));
			hznAltinVerilenDepoTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
			hznAltinVerilenDepoTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
            hznAltinVerilenDepoTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
            hznAltinVerilenDepoTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));

			
			session.saveOrUpdate(hznAltinVerilenDepoTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3615");            
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	@GraymoundService("BNSPR_TRN3615_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilendepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAltinVerilendepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinVerilendepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinVerilendepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinVerilendepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinVerilendepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinVerilendepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinVerilendepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinVerilendepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinVerilendepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinVerilendepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinVerilendepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinVerilendepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinVerilendepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinVerilendepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinVerilendepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinVerilendepoTx.getVadeTarihi());
			oMap.put("DEAL_TARIHI", hznAltinVerilendepoTx.getDealTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinVerilendepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinVerilendepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinVerilendepoTx.getFaizTutari());
			oMap.put("FAIZ_ORANI", hznAltinVerilendepoTx.getFaizOrani());
			oMap.put("ISTATISTIK_KODU", hznAltinVerilendepoTx.getIstatistikKodu());
			oMap.put("VADE_ISLEM_BILGISI", hznAltinVerilendepoTx.getVadeIslemBilgisi());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilendepoTx.getGirisHesapNo(),hznAltinVerilendepoTx.getDovizKodu(),
			        hznAltinVerilendepoTx.getGirisHesapTuru(), hznAltinVerilendepoTx.getDovizKodu(), hznAltinVerilendepoTx.getGirisHesapTuru(), 
			        hznAltinVerilendepoTx.getBankaMusteriNo(), "1313/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilendepoTx.getCikisHesapNo(),hznAltinVerilendepoTx.getDovizKodu(),
			        hznAltinVerilendepoTx.getCikisHesapTuru(), hznAltinVerilendepoTx.getDovizKodu(), hznAltinVerilendepoTx.getCikisHesapTuru(), 
			        hznAltinVerilendepoTx.getBankaMusteriNo(), "1313/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinVerilendepoTx.getBankaMusteriNo(), "1313/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinVerilendepoTx.getDealerNo(), "1313/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinVerilendepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinVerilendepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinVerilendepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("STOK_NO", hznAltinVerilendepoTx.getStokNo());
			oMap.put("SAFLIK_DERECESI", hznAltinVerilendepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI", hznAltinVerilendepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI", hznAltinVerilendepoTx.getKomisyonTutari());
			oMap.put("ISLEM_TURU", hznAltinVerilendepoTx.getIslemTuru());
			oMap.put("ISTATISTIK_KODU", hznAltinVerilendepoTx.getIstatistikKodu());
			oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznAltinVerilendepoTx.getIstatistikKodu(), "1330/LOV_ISTATISTIK", "ACIKLAMA"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	

	 @GraymoundService("BNSPR_TRN3615_FAIZ_HESAPLA")
	    public static GMMap getFaizHesabi(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;

	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{ ?=call PKG_TRN3615.Faiz_Tutari_Hesapla(?,?,?)}");
	            int i = 1;
	            stmt.registerOutParameter(i++, Types.NUMERIC);
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("GUN_SAYISI"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("BRUT_TUTAR"));
	            stmt.execute();

	            oMap.put("FAIZ_TUTARI", stmt.getString(1));

	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }

	    }
}
