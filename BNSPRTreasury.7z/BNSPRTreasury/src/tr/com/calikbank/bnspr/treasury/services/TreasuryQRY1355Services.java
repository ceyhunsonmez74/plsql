package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY1355Services {
	
	@GraymoundService("BNSPR_QRY1355_HZN_CASH_FLOW_HAREKET")
	public static GMMap getHznGunlukPozisyonHareketleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_RC1355.QRY1355_Cash_Flow_Hareket(?,?,?,?,?,?,?,?,?,?,?)}");
			/** PKG_RC1355.QRY1355_Cash_Flow_Hareket
			 *inputs----
             *      pd_basTarih date , pd_bitTarih date , pn_basTutar number , pn_bitTutar number , pn_muhabirHesap number,
             *      pc_doviz varchar2, pc_tur varchar2,
             *outputs---
             *      prc_cash_flow_hareket_izleme out RC_1355 , pn_devirTutar out number,
             *      pn_bakiye out number, pc_nostro_vostro out char
             */
			int i = 1;
			if (iMap.getDate("BAS_TARIH") == null)
                  stmt.setDate(i++ , null);
            else  stmt.setDate(i++ , new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
            
			if (iMap.getDate("BIT_TARIH") == null)
                  stmt.setDate(i++ , null);
            else  stmt.setDate(i++ , new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
            
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("BAS_TUTAR")        );
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("BIT_TUTAR")        );
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("MUHABIR_HESAP_NO") );
            stmt.setString(i++ , iMap.getString("DOVIZ_KODU"));
            
            if (iMap.getString("TUR") != null && iMap.getString("TUR").equals("HEPSI"))
                stmt.setString(i++ , null);
            else stmt.setString(i++ , iMap.getString("TUR"));
                        
            stmt.registerOutParameter(i++ , -10);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.VARCHAR );
            stmt.execute();
            
            oMap.put("NOSTRO_VOSTRO", stmt.getString(--i));
            oMap.put("BAKIYE"      , stmt.getBigDecimal(--i)    );
            oMap.put("DEVIR_TUTAR" , stmt.getBigDecimal(--i) );
            rSet = (ResultSet) stmt.getObject(--i);
            
            String tableName = "NAKIT_AKISI"; 
            int j = 0;
            java.math.BigDecimal girisTotal = new java.math.BigDecimal("0");
            java.math.BigDecimal cikisTotal = new java.math.BigDecimal("0");
			
			while (rSet.next()){
				oMap.put(tableName , j , "DOVIZ" 			, rSet.getString("DOVIZ")             );
				oMap.put(tableName , j , "ISLEM_ADI" 		, rSet.getString("ISLEM_ACIKLAMA")    );
				oMap.put(tableName , j , "ISLEM_KODU" 		, rSet.getString("ISLEM_KODU")        );
				oMap.put(tableName , j , "MUHABIR_HESAP" 	, rSet.getBigDecimal("MUHABIR_HESAP") );
				oMap.put(tableName , j , "MUHABIR_ADI" 		, rSet.getString("MUHABIR_ADI")       );
				oMap.put(tableName , j , "MUSTERI_ADI" 		, rSet.getString("MUSTERI_ADI")       );
				oMap.put(tableName , j , "REFERANS" 		, rSet.getString("REFERANS")          );
				oMap.put(tableName , j , "SANAL_TUTAR"		, rSet.getBigDecimal("TUTAR")         );
				oMap.put(tableName , j , "TUR"				, rSet.getString("TUR")               );
				oMap.put(tableName , j , "VALOR"			, rSet.getDate("VALOR")               );
				oMap.put(tableName , j , "CASHID"			, rSet.getString("CASHID")            );
				oMap.put(tableName , j , "MUSTERI_NO"		, rSet.getString("MUSTERI_NO")        );
				oMap.put(tableName , j , "ACIKLAMA"			, rSet.getString("ACIKLAMA")          );
				oMap.put(tableName , j , "BIC_KODU"			, rSet.getString("BIC_KODU")          );
				oMap.put(tableName , j , "REC_DATE"			, rSet.getDate("REC_DATE")            );
				oMap.put(tableName , j , "REC_OWNER"		, rSet.getString("REC_OWNER")         );
				oMap.put(tableName , j , "ISLEM_NO"			, rSet.getBigDecimal("TX_NO")         );
				oMap.put(tableName , j , "DURUM_KODU"		, rSet.getString("DURUM_KODU")        );
				oMap.put(tableName , j , "ONAY"		, rSet.getString("ONAY")        );
								
				if ("B".equals(oMap.getString(tableName , j , "DURUM_KODU"))){					
					if (rSet.getString("TUR") != null && rSet.getString("TUR").equals("GIRIS"))
						girisTotal = girisTotal.add(rSet.getBigDecimal("TUTAR"));
					else cikisTotal = cikisTotal.add(rSet.getBigDecimal("TUTAR"));
				}
				j++;
			}
			oMap.put("GIRIS_TUTAR" , girisTotal);
			oMap.put("CIKIS_TUTAR" , cikisTotal);
			java.math.BigDecimal netTutar = oMap.getBigDecimal("BAKIYE");
           if ("N".equals(oMap.getString("NOSTRO_VOSTRO"))){
			   netTutar = netTutar.add(cikisTotal);
			   netTutar = netTutar.subtract(girisTotal);
           }
           else
           {netTutar = netTutar.add(girisTotal);
 		    netTutar = netTutar.subtract(cikisTotal);
           }
			oMap.put("NETTUTAR" , netTutar);
			return oMap;
		} catch (Exception e){
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
