package tr.com.calikbank.bnspr.treasury.services;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznAtsTransfer;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.services.TreasuryTRN1370Services.IslemTipi;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TreasuryQRY1370Services {

	@GraymoundService("BNSPR_QRY1370_INITIALIZE")
	public static GMMap init(GMMap iMap) {
		GMMap oMap = new GMMap();

		String listName2 = "GELEN_GIDEN";
		GuimlUtil.wrapMyCombo(oMap, listName2, IslemTipi.GELEN.getValue(), IslemTipi.GELEN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName2, IslemTipi.GIDEN.getValue(), IslemTipi.GIDEN.getValue());

		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY1370_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {			
			String tableName = "TBL_TALIMAT";
			Session session = DAOSession.getSession("BNSPRDal");
		    Criteria criteria = session.createCriteria(HznAtsTransfer.class)
		    										.add(Restrictions.eq("gelenGiden", iMap.getString("ISLEM_TIPI")));
			@SuppressWarnings("unchecked")
			List<HznAtsTransfer> transferList = (List<HznAtsTransfer>) criteria.list();
			for (int i = 0; i < transferList.size(); i++) {
				HznAtsTransfer hznAtsTransfer = transferList.get(i);
				oMap.put(tableName, i, "GON_BANKA", String.format("%s - %s", hznAtsTransfer.getGonUyeKod(), hznAtsTransfer.getGonUyeAdi()));
				oMap.put(tableName, i, "GON_MUSTERI_NO", hznAtsTransfer.getGonMusteriNo());
				oMap.put(tableName, i, "GON_MUSTERI_ADI", hznAtsTransfer.getGonMusteriAdi());
				oMap.put(tableName, i, "ALICI_BANKA", String.format("%s - %s", hznAtsTransfer.getAliciUyeKod(), hznAtsTransfer.getAliciUyeAdi()));
				oMap.put(tableName, i, "ALICI_MUSTERI_ADI", hznAtsTransfer.getAliciMusteriAdi());
				oMap.put(tableName, i, "ALICI_MUSTERI_ADI", hznAtsTransfer.getAliciMusteriAdi());
				oMap.put(tableName, i, "MIKTAR", hznAtsTransfer.getMiktar());				
				oMap.put(tableName, i, "VALOR_TARIHI", hznAtsTransfer.getValorTarihi());
				oMap.put(tableName, i, "DURUM", hznAtsTransfer.getDurum());			
				oMap.put(tableName, i, "ACIKLAMA", hznAtsTransfer.getAciklama());
				
				oMap.put(tableName, i, "GON_IBAN_BEYAN", hznAtsTransfer.getGonIbanBeyanEh());
				oMap.put(tableName, i, "GON_IBAN", hznAtsTransfer.getGonIban());
				oMap.put(tableName, i, "GON_SUBE_KODU", hznAtsTransfer.getGonSubeKodu());
				oMap.put(tableName, i, "GON_HESAP_NO", hznAtsTransfer.getGonHesapNo());
				oMap.put(tableName, i, "GON_KIMLIK_TIP", hznAtsTransfer.getGonKimlikTip());
				oMap.put(tableName, i, "GON_KIMLIK_NO", hznAtsTransfer.getGonKimlikNo());			

				oMap.put(tableName, i, "ALICI_MUSTERI_NO", hznAtsTransfer.getAliciMusteriNo());
				oMap.put(tableName, i, "ALICI_IBAN", hznAtsTransfer.getAliciIban());
				oMap.put(tableName, i, "ALICI_IBAN_BEYAN", hznAtsTransfer.getAliciIbanBeyanEh());
				oMap.put(tableName, i, "ALICI_SUBE_KODU", hznAtsTransfer.getAliciSubeKodu());
				oMap.put(tableName, i, "ALICI_HESAP_NO", hznAtsTransfer.getAliciHesapNo());
				oMap.put(tableName, i, "ALICI_KIMLIK_TIP", hznAtsTransfer.getAliciKimlikTip());
				oMap.put(tableName, i, "ALICI_KIMLIK_NO", hznAtsTransfer.getAliciKimlikNo());
				
				oMap.put(tableName, i, "TAKASBANK_TALIMAT_NO", hznAtsTransfer.getTakasbankTalimatNo());
				oMap.put(tableName, i, "TAKASBANK_ACIKLAMA", hznAtsTransfer.getTakasbankAciklama());
				oMap.put(tableName, i, "TAKASBANK_DURUM", hznAtsTransfer.getTakasbankDurum());
			}			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
