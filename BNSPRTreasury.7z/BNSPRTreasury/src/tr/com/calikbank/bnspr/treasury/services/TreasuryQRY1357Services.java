package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY1357Services {
	
	@GraymoundService("BNSPR_QRY1357_HZN_CASH_FLOW_DATE")
	public static GMMap getCashFlowDate(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();   
			stmt = conn.prepareCall("{ call PKG_RC1357.sp_Nakit_Akisi_GunlukRap_Yarat(?,?,?,?,?)}");
			if(iMap.getDate("K_BAS_TARIH")==null)
				stmt.setDate(1, null);
			else
				stmt.setDate(1, new java.sql.Date(iMap.getDate("K_BAS_TARIH").getTime()));
			
			if(iMap.getDate("K_BIT_TARIH")==null)
				stmt.setDate(2, null);
			else
				stmt.setDate(2, new java.sql.Date(iMap.getDate("K_BIT_TARIH").getTime()));
			stmt.setBigDecimal(3, iMap.getBigDecimal("K_MUHABIR_HESAP"));
			stmt.registerOutParameter(4, -10);
			stmt.registerOutParameter(5, -10);
			stmt.execute();
			String tableName1 = "HZN_NAKIT_AKISI_TMP_GUN_IZL";
			String tableName2 = "HZN_NAKIT_AKISI_TMP_GUNDTY_IZL";
			rSet = (ResultSet)stmt.getObject(4);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName1));
			rSet = (ResultSet)stmt.getObject(5);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName2));
	 
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}