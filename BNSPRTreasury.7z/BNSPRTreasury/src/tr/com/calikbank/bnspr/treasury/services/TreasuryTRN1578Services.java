package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznOpsiyonBariyerTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonBariyerTxId;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTeminatTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTeminatTxId;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznOpsiyonluBOpsiyonlarTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1578Services {

	@GraymoundService("BNSPR_TRN1578_TEMINATLARI_HESAPLA")
	public static GMMap teminatlariHesapla(GMMap iMap) {

		GMMap oMap = new GMMap();
		BigDecimal karsilananTutar = BigDecimal.ZERO;
		BigDecimal spotKuru = BigDecimal.ZERO;
		BigDecimal totalKarsilanan = BigDecimal.ZERO;
		iMap.put("IS_INTERNAL" , "TRUE");

		for (int row = 0; row < iMap.getSize("TABLO"); row++) {
         if(iMap.getBigDecimal("TABLO", row, "TEM_TUTAR") != null &&iMap.getString("TABLO", row, "DOVIZ")!=null    ){
			if (iMap.getString("TABLO", row, "DOVIZ").equals(iMap.getString("DOVIZ")) || iMap.getString("TABLO", row, "DOVIZ").equals(iMap.getString("KARSI_DOVIZ"))) {

				karsilananTutar = iMap.getBigDecimal("TABLO", row, "KARSILAMA").multiply(iMap.getBigDecimal("TABLO", row, "TEM_TUTAR"));
				iMap.put("BAZ_DOVIZ_CINSI", iMap.getString("TABLO", row, "DOVIZ"));
				spotKuru = GMServiceExecuter.call("BNSPR_TRN1578_GET_ISLEM_ANI_SPOT_KURU", iMap).getBigDecimal("SPOT_KURU");
				karsilananTutar = spotKuru.multiply(karsilananTutar);
				iMap.put("TABLO", row, "KARSILANAN_TUTAR", karsilananTutar);
			}
			else {
			    
				karsilananTutar = iMap.getBigDecimal("TABLO", row, "FARKLI").multiply(iMap.getBigDecimal("TABLO", row, "TEM_TUTAR"));
				iMap.put("BAZ_DOVIZ_CINSI", iMap.getString("TABLO", row, "DOVIZ"));
				spotKuru = GMServiceExecuter.call("BNSPR_TRN1578_GET_ISLEM_ANI_SPOT_KURU", iMap).getBigDecimal("SPOT_KURU");
				karsilananTutar = spotKuru.multiply(karsilananTutar);
				iMap.put("TABLO", row, "KARSILANAN_TUTAR", karsilananTutar);
			    }
			totalKarsilanan = totalKarsilanan.add(karsilananTutar);
			}

			
		}
		iMap.put("TOTAL", totalKarsilanan);
		return iMap;
	}	
	
	@GraymoundService("BNSPR_TRN1578_WARN_MESSAGE")
	public static GMMap warnMessage(GMMap iMap) {

		GMMap oMap = new GMMap();		
		String warn = iMap.getBigDecimal("TEMINAT_TUTARI").subtract(iMap.getBigDecimal("KARSILANAN_TUTAR")).toString();
		String warnMessage = "Teminat Tutar�, Kar��lan�lan Tutardan "+warn+" lira fazlad�r!";
		oMap.put("WARN_MESSAGE", warnMessage);
		return oMap;
		
	}

	@GraymoundService("BNSPR_TRN1578_TEMINAT_ORANI_HESAPLA")
	public static GMMap teminatOraniHesapla(GMMap iMap) {

		GMMap oMap = new GMMap();
		Object[] inputValues = new Object[6];
		int i = 0;
		inputValues[i++] = BnsprType.NUMBER;
		inputValues[i++] = iMap.getBigDecimal("GUN");
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("DOVIZ");
		inputValues[i++] = BnsprType.STRING;
        inputValues[i++] = iMap.getString("DOVIZ2");

		String func = "{? = call pkg_TRN1578.TeminatOrani(?,?,?)}";
		try {
			Object resultMap = DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			oMap.put("ORAN", resultMap);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1578_TEMINAT_TUTARI_BANKA_SATIS")
	public static GMMap teminatTutariBankaSatis(GMMap iMap) {
	
		GMMap oMap = new GMMap();
		
		try {
			if(!StringUtils.isBlank(iMap.getString("PRIM_DOVIZ_CINSI"))){
				String func = "{? = call pkg_kur.FC_to_LC(?,?,?,?)}";
				Object[] inputValues = new Object[]{BnsprType.STRING,iMap.getString("PRIM_DOVIZ_CINSI"),BnsprType.NUMBER, new BigDecimal(1),BnsprType.NUMBER, new BigDecimal(1), BnsprType.STRING, "A"};
	
				BigDecimal teminat =  (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER , inputValues);
				
				if(iMap.getBigDecimal("PRIM_TUTARI") != null)
					oMap.put("TEMINAT_TUTARI",teminat.multiply(iMap.getBigDecimal("PRIM_TUTARI")));
				else
					oMap.put("TEMINAT_TUTARI", BigDecimal.ZERO);
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;

	}

	@GraymoundService("BNSPR_TRN1578_GET_ISLEM_ANI_SPOT_KURU")
	public static GMMap getIslemAniSpotKuru(GMMap iMap) {

		GMMap oMap = new GMMap();
		Object[] inputValues = new Object[8];
		int i = 0;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("BAZ_DOVIZ_CINSI");
		
		String func = null;
		if (iMap.getString("IS_INTERNAL")!= null){
		inputValues[i++] = BnsprType.NUMBER;
		inputValues[i++] = new BigDecimal(1);
		inputValues[i++] = BnsprType.NUMBER;
		inputValues[i++] = new BigDecimal(1);
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = "S";
		func = "{? = call pkg_kur.FC_to_LC(?,?,?,?)}";
		
		}else{
        inputValues[i++] = BnsprType.STRING;
        inputValues[i++] = iMap.getString("KARSI_DOVIZ_CINSI");
        func = "{? = call pkg_kur.DOVIZ_CEVIR(?,?,null,1,1)}";
		}
                
		i=0;
		
		Object [] inputValuesDoviz = new Object[20];
		inputValuesDoviz[i++] = BnsprType.STRING;
		inputValuesDoviz[i++] = iMap.getString("BAZ_DOVIZ_CINSI");
		inputValuesDoviz[i++] = BnsprType.STRING;
		inputValuesDoviz[i++] = "TRY";
		inputValuesDoviz[i++] = BnsprType.DATE;
	    inputValuesDoviz[i++] = null;
        inputValuesDoviz[i++] = BnsprType.NUMBER;
		inputValuesDoviz[i++] = new BigDecimal(1);
		inputValuesDoviz[i++] = BnsprType.NUMBER;
		inputValuesDoviz[i++] = new BigDecimal(1);;
		inputValuesDoviz[i++] = BnsprType.NUMBER;
		inputValuesDoviz[i++] = null;
		inputValuesDoviz[i++] = BnsprType.NUMBER;
		inputValuesDoviz[i++] = null;
		inputValuesDoviz[i++] = BnsprType.STRING;
		inputValuesDoviz[i++] = "O";
		inputValuesDoviz[i++] = BnsprType.STRING;
		inputValuesDoviz[i++] = "S";
		
		String func2= "{? = call pkg_kur.DOVIZ_CEVIR(?,?,?,?,?,?,?,?,?)}";
		try {
		    if(iMap.getString("IS_INTERNAL")!= null){
		        Object resultMap = DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
	            oMap.put("SPOT_KURU", resultMap);
		    }else{
		   if( iMap.getString("BAZ_DOVIZ_CINSI")==null ||iMap.getString("KARSI_DOVIZ_CINSI")==null) {
		       oMap.put("SPOT_KURU", 0);
		   }else{
			Object resultMap = DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			oMap.put("SPOT_KURU", resultMap);
		   }
		    }
		   if( iMap.getString("BAZ_DOVIZ_CINSI")==null ) {
               oMap.put("DOVIZ_KURU", 0);
           }else{
            oMap.put("DOVIZ_KURU",DALUtil.callOracleFunction(func2, BnsprType.NUMBER, inputValuesDoviz));
           }
		   
		   if (StringUtils.isEmpty(iMap.getString("OPSIYON_DOVIZ_CINSI"))) {
			   oMap.put("OPS_KURU", 0);
		   } else {
			   inputValuesDoviz[1] = iMap.getString("OPSIYON_DOVIZ_CINSI");
			   oMap.put("OPS_KURU", DALUtil.callOracleFunction(func2, BnsprType.NUMBER, inputValuesDoviz));
		   }
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1578_SAVE")
	public static Map<?, ?> save(GMMap iMap) throws ParseException {

		Session session = DAOSession.getSession("BNSPRDal");
		String txNo = "";
		
		HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		HznOpsiyonislemTxId tid = null;
		HznOpsiyonislemTeminatTx hznOpsiyonislemTeminatTx = new HznOpsiyonislemTeminatTx();
		HznOpsiyonislemTeminatTxId hznOpsiyonislemTeminatTxId = new HznOpsiyonislemTeminatTxId();
		HznOpsiyonluBOpsiyonlarTx hznOpsiyonluBOpsiyonlarTx;
		
		if (hznOpsiyonislemTx == null) {
			hznOpsiyonislemTx = new HznOpsiyonislemTx();
			tid = new HznOpsiyonislemTxId();
			tid.setReferans(iMap.getString("TRX_NO"));
			tid.setTxNo(iMap.getBigDecimal("TRX_NO"));
		} else {
			tid= hznOpsiyonislemTx.getId();
		}
		
		hznOpsiyonislemTx.setAlacakHesap(iMap.getBigDecimal("ALACAK_HESAP"));
		hznOpsiyonislemTx.setAlacakHesapDvz(iMap.getString("ALACAK_HESAP_DOVIZ"));
		hznOpsiyonislemTx.setAlinanDoviz(iMap.getString("ALINAN_DOVIZ_TEXT"));
		hznOpsiyonislemTx.setAlinanTutar(iMap.getBigDecimal("ALINAN_DOVIZ"));
		hznOpsiyonislemTx.setBazDvz(iMap.getString("COMBO_BAZ_DOVIZ_CINSI"));
		hznOpsiyonislemTx.setBazTutar(iMap.getBigDecimal("BAZ_OPSIYON_TUTARI"));
		hznOpsiyonislemTx.setBorcluHesap(iMap.getBigDecimal("BORCLU_HESAP"));
		hznOpsiyonislemTx.setBorcluHesapDvz(iMap.getString("BORCLU_HESAP_DOVIZ"));
		hznOpsiyonislemTx.setKarsiDoviz(iMap.getString("COMBO_KARSI_DOVIZ"));
		hznOpsiyonislemTx.setKarsiTutar(iMap.getBigDecimal("KARSI_OPSIYON_TUTARI"));
		hznOpsiyonislemTx.setOpsDoviz(iMap.getString("OPSIYON_DOVIZ_CINSI"));
		
		if(iMap.getBoolean("R_BANKA")==true)
		{
			hznOpsiyonislemTx.setMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI"));
			hznOpsiyonislemTx.setBankami("E");
		}
		
		else if(iMap.getBoolean("R_MUSTERI")==true)
		{
			hznOpsiyonislemTx.setMusteriNo(iMap.getBigDecimal("GENEL_MUSTERI"));
			hznOpsiyonislemTx.setBankami("H");
		}
		
		hznOpsiyonislemTx.setOpsAmac(iMap.getString("COMBO_OPSIYON_AMAC"));
		hznOpsiyonislemTx.setOpsCinsi(iMap.getString("COMBO_OPSIYON_CINS"));
		hznOpsiyonislemTx.setOpsDealer(iMap.getString("dfDealer"));
		hznOpsiyonislemTx.setOpsSekliBaz(iMap.getString("COMBO_OPSIYON_SEKLI"));		
		hznOpsiyonislemTx.setOpsTipi(iMap.getString("COMBO_OPSIYON_TIPI"));
		hznOpsiyonislemTx.setOpsYonu(iMap.getString("COMBO_OPSIYON_YONU"));
		hznOpsiyonislemTx.setPrimDoviz(iMap.getString("COMBO_PRIM_DOVIZ_CINSI"));
		hznOpsiyonislemTx.setPrimHesapNo(iMap.getBigDecimal("PRIM_HESAP_NO"));
		hznOpsiyonislemTx.setPrimMaliyet(iMap.getBigDecimal("MALIYET_PRIM"));
		hznOpsiyonislemTx.setPrimMusteri(iMap.getBigDecimal("MUSTERI_PRIM"));
		hznOpsiyonislemTx.setPrimMusteriYillik(iMap.getBigDecimal("MALIYET_PRIM_YILLIK"));
		hznOpsiyonislemTx.setPrimSubeKariDvz(iMap.getString("SUBE_KARI_DOVIZ_CINSI"));
		hznOpsiyonislemTx.setPrimSubeKariTutar(iMap.getBigDecimal("SUBE_KARI"));
		hznOpsiyonislemTx.setPrimTutar(iMap.getBigDecimal("PRIM_TUTARI"));
		hznOpsiyonislemTx.setRiskIslemTipi(iMap.getString("ISLEM_TURU"));
		hznOpsiyonislemTx.setRiskTeminatOran(iMap.getBigDecimal("TEMINAT_ORANI"));
		hznOpsiyonislemTx.setRiskTeminatTutar(iMap.getBigDecimal("TEMINAT_TUTARI"));
		hznOpsiyonislemTx.setSatilanDvz(iMap.getString("SATILAN_DOVIZ_TEXT"));
		hznOpsiyonislemTx.setSatilanTutar(iMap.getBigDecimal("SATILAN_DOVIZ"));
		hznOpsiyonislemTx.setSpotKur(iMap.getBigDecimal("SPOT_KURU"));
		hznOpsiyonislemTx.setPrimMusteriYillik(iMap.getBigDecimal("MUSTERI_PRIM_YILLIK"));
		hznOpsiyonislemTx.setSubeAna(iMap.getBigDecimal("ANA_SUBE_KODU"));
		hznOpsiyonislemTx.setSubeIslem(iMap.getBigDecimal("SUBE_KODU"));
		hznOpsiyonislemTx.setSubePyKod(iMap.getString("PY_KODU"));
		hznOpsiyonislemTx.setTarihIslem(iMap.getDate("ISLEM_TARIHI")==null ? null: new java.sql.Date( iMap.getDate("ISLEM_TARIHI").getTime()));
		hznOpsiyonislemTx.setTarihPrim(iMap.getDate("PRIM_TARIHI")==null ? null: new java.sql.Date( iMap.getDate("PRIM_TARIHI").getTime()));
		hznOpsiyonislemTx.setTarihUzlasma(iMap.getDate("UZLASMA_TARIHI")==null ? null: new java.sql.Date( iMap.getDate("UZLASMA_TARIHI").getTime()));
		hznOpsiyonislemTx.setTarihVade(iMap.getDate("VADE_TARIHI")==null ? null: new java.sql.Date( iMap.getDate("VADE_TARIHI").getTime()));
		hznOpsiyonislemTx.setKarsilananTeminatTl(iMap.getBigDecimal("KARSILANAN_TUTAR"));
		hznOpsiyonislemTx.setHesaplananTeminatTl(iMap.getBigDecimal("KARSILANAN_TUTAR"));
		hznOpsiyonislemTx.setAlisHesapTuru(iMap.getString("ALIS_HESAP_TURU"));
		hznOpsiyonislemTx.setSatisHesapTuru(iMap.getString("SATIS_HESAP_TURU"));
		hznOpsiyonislemTx.setBankaAlisHesapno(iMap.getBigDecimal("ALIS_HESAP_NO"));
		hznOpsiyonislemTx.setBankaSatisHesapno(iMap.getBigDecimal("SATIS_HESAP_NO"));
		hznOpsiyonislemTx.setAlisMuhabirMusteriNo(iMap.getString("MUSTERIMUHABIRNO"));
		hznOpsiyonislemTx.setSatisMuhabirMusteriNo(iMap.getString("MUSTERIMUHABIRNOSATIS"));
		hznOpsiyonislemTx.setDigerReferans(iMap.getString("DIGER_REFERANS"));
		hznOpsiyonislemTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
		hznOpsiyonislemTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
		hznOpsiyonislemTx.setOrderId(iMap.getString("ORDER_ID"));
		hznOpsiyonislemTx.setMessageId(iMap.getString("MESSAGE_ID"));
		hznOpsiyonislemTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
				
		hznOpsiyonislemTx.setOpsiyonluBonoMu("H");
		
		hznOpsiyonislemTx.setBazDovizIslemTcmb(iMap.getBigDecimal("DOVIZ_KURU"));
		hznOpsiyonislemTx.setKrediTeklifNo(iMap.getBigDecimal("KREDI_TEKLIF_SATIR_NO"));
		hznOpsiyonislemTx.setVadeGunSayisi(iMap.getBigDecimal("GUN_FARKI"));
		
		hznOpsiyonislemTx.setOpsStatus("HO");
		hznOpsiyonislemTx.setDokuman1("Y");
		hznOpsiyonislemTx.setDokuman2("Y");
		txNo = "1578";
		
		hznOpsiyonislemTx.setVadeZaman(iMap.getString("VADE_ZAMAN"));
		
        hznOpsiyonislemTx.setId(tid);
        
		session.saveOrUpdate(hznOpsiyonislemTx);

		int sira = 1;
		for (int row = 0; row < iMap.getSize("TABLE_TEMINAT"); row++) {
					
			hznOpsiyonislemTeminatTxId = new HznOpsiyonislemTeminatTxId();
			hznOpsiyonislemTeminatTx = new HznOpsiyonislemTeminatTx();
			hznOpsiyonislemTeminatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznOpsiyonislemTeminatTxId.setReferans(tid.getReferans());
			hznOpsiyonislemTeminatTxId.setSira(new BigDecimal(sira++));
			hznOpsiyonislemTeminatTx.setId(hznOpsiyonislemTeminatTxId);
			hznOpsiyonislemTeminatTx.setDovizKodu(iMap.getString("TABLE_TEMINAT", row, "DOVIZ"));
			hznOpsiyonislemTeminatTx.setIsinKod(iMap.getString("TABLE_TEMINAT", row, "ISIN_KODU"));
			hznOpsiyonislemTeminatTx.setKarsilananTlTutar(iMap.getBigDecimal("TABLE_TEMINAT", row, "KARSILANAN_TUTAR"));
			hznOpsiyonislemTeminatTx.setRiskKarsilamaYuzdesi(iMap.getBigDecimal("TABLE_TEMINAT", row, "KARSILAMA"));
			hznOpsiyonislemTeminatTx.setTutari(iMap.getBigDecimal("TABLE_TEMINAT", row, "TEM_TUTAR"));
			hznOpsiyonislemTeminatTx.setSpotDovizKuru(iMap.getBigDecimal("SPOT_KURU"));
			hznOpsiyonislemTeminatTx.setTeminatCinsi(iMap.getString("TABLE_TEMINAT", row, "KOD"));
			session.saveOrUpdate(hznOpsiyonislemTeminatTx);

		}
		
		if(iMap.getString("COMBO_OPSIYON_CINS").equals("NT") || iMap.getString("COMBO_OPSIYON_CINS").equals("OT") ||iMap.getString("COMBO_OPSIYON_CINS").equals("D")) {
			HznOpsiyonBariyerTx hznOpsiyonBariyerTx1 = new HznOpsiyonBariyerTx();
			HznOpsiyonBariyerTxId hznOpsiyonBariyerTxId = new HznOpsiyonBariyerTxId();
			hznOpsiyonBariyerTx1.setReferans(tid.getReferans());
			hznOpsiyonBariyerTxId.setSiraNo(new BigDecimal(1));
			hznOpsiyonBariyerTxId.setTxNo(tid.getTxNo());			
			hznOpsiyonBariyerTx1.setId(hznOpsiyonBariyerTxId);
			hznOpsiyonBariyerTx1.setBariyerCinsi(iMap.getString("BARIYER_CINSI1"));
			hznOpsiyonBariyerTx1.setBariyerDeger(iMap.getBigDecimal("BARIYER_DEGER1"));
			hznOpsiyonBariyerTx1.setBariyerTipi(iMap.getString("BARIYER_TIPI1"));
			hznOpsiyonBariyerTx1.setBitisTarih(iMap.getDate("BARIYER_BITTAR1"));
			hznOpsiyonBariyerTx1.setBaslangicTarih(iMap.getDate("BARIYER_BASTAR1"));	
			hznOpsiyonBariyerTx1.setBariyerBaszaman(iMap.getString("BARIYER_BASZAMAN1"));
			hznOpsiyonBariyerTx1.setBariyerBitzaman(iMap.getString("BARIYER_BITZAMAN1"));
			
			session.saveOrUpdate(hznOpsiyonBariyerTx1);
			
		} else if(iMap.getString("COMBO_OPSIYON_CINS").equals("DNT") || iMap.getString("COMBO_OPSIYON_CINS").equals("DOT") || iMap.getString("COMBO_OPSIYON_CINS").equals("A")) {
			HznOpsiyonBariyerTx hznOpsiyonBariyerTx1 = new HznOpsiyonBariyerTx();
			HznOpsiyonBariyerTxId hznOpsiyonBariyerTxId1 = new HznOpsiyonBariyerTxId();
			hznOpsiyonBariyerTx1.setReferans(tid.getReferans());
			hznOpsiyonBariyerTxId1.setSiraNo(new BigDecimal(1));
			hznOpsiyonBariyerTxId1.setTxNo(tid.getTxNo());			
			hznOpsiyonBariyerTx1.setId(hznOpsiyonBariyerTxId1);
			hznOpsiyonBariyerTx1.setBariyerCinsi(iMap.getString("BARIYER_CINSI1"));
			hznOpsiyonBariyerTx1.setBariyerDeger(iMap.getBigDecimal("BARIYER_DEGER1"));
			hznOpsiyonBariyerTx1.setBariyerTipi(iMap.getString("BARIYER_TIPI1"));
			hznOpsiyonBariyerTx1.setBitisTarih(iMap.getDate("BARIYER_BITTAR1"));
			hznOpsiyonBariyerTx1.setBaslangicTarih(iMap.getDate("BARIYER_BASTAR1"));
			hznOpsiyonBariyerTx1.setBariyerBaszaman(iMap.getString("BARIYER_BASZAMAN1"));
			hznOpsiyonBariyerTx1.setBariyerBitzaman(iMap.getString("BARIYER_BITZAMAN1"));
			
			HznOpsiyonBariyerTx hznOpsiyonBariyerTx2 = new HznOpsiyonBariyerTx();
			HznOpsiyonBariyerTxId hznOpsiyonBariyerTxId2 = new HznOpsiyonBariyerTxId();
			hznOpsiyonBariyerTx2.setReferans(tid.getReferans());
			hznOpsiyonBariyerTxId2.setSiraNo(new BigDecimal(2));
			hznOpsiyonBariyerTxId2.setTxNo(tid.getTxNo());			
			hznOpsiyonBariyerTx2.setId(hznOpsiyonBariyerTxId2);
			hznOpsiyonBariyerTx2.setBariyerCinsi(iMap.getString("BARIYER_CINSI2"));
			hznOpsiyonBariyerTx2.setBariyerDeger(iMap.getBigDecimal("BARIYER_DEGER2"));
			hznOpsiyonBariyerTx2.setBariyerTipi(iMap.getString("BARIYER_TIPI2"));
			hznOpsiyonBariyerTx2.setBitisTarih(iMap.getDate("BARIYER_BITTAR2"));
			hznOpsiyonBariyerTx2.setBaslangicTarih(iMap.getDate("BARIYER_BASTAR2"));
			hznOpsiyonBariyerTx2.setBariyerBaszaman(iMap.getString("BARIYER_BASZAMAN2"));
			hznOpsiyonBariyerTx2.setBariyerBitzaman(iMap.getString("BARIYER_BITZAMAN2"));			
			
			session.saveOrUpdate(hznOpsiyonBariyerTx1);
			session.saveOrUpdate(hznOpsiyonBariyerTx2);			
		} 
		
		session.flush();
		
		iMap.put("TRX_NAME",txNo);
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);	
	}

	@GraymoundService("BNSPR_TRN1578_TRANSACTION_START")
	public static Map<?, ?> TRN1578Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1578");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1578_INITIALIZE_COMBO")
	public static GMMap initializeCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		DALUtil.fillComboBox(oMap, "DOVIZ", true, "	select kod,kod as aciklama from v_ml_gnl_doviz_kod_pr order by sira_no");
        String dealerIsim = "";
		
		try {
			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call PKG_TRN1578.TeminatListesi}", "RISK", new Object[0]));
			dealerIsim =         (String) DALUtil.callOracleFunction("{? = call PKG_TRN1578.GetDealerKullanici}",BnsprType.STRING,new Object[0]);
			oMap.put("DEALER",dealerIsim);			
			DALUtil.fillComboBox(oMap, "IPTAL", true,"select  t.tx_no, m.referans from hzn_opsiyon_islem_tx t, hzn_opsiyon_islem m where m.referans = t.referans and m.ops_status = 'IP' and t.ops_status = 'HO' order by t.rec_date desc " );
			
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BARIYER_CINSI");
			oMap.put("BARIYER_CINSI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.clear();
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BARIYER_TIPI");
			oMap.put("BARIYER_TIPI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.clear();
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "EXOTIK_OPSIYON_CINSI");
			oMap.put("OPSIYON_CINSI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.clear();
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "OPSIYON_YONU");
			oMap.put("OPSIYON_YONU", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.clear();
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "OPSIYON_AMACI");
			oMap.put("OPSIYON_AMACI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			/*
			 * opsiyon saatleri alinir
			 * 
			 * default;
			 * 
			 * TP/YP icin USD-TRY
			 * YP/YP icin USD-EUR
			 * 
			 * yaptik.
			 *
			 */
			oMap.put("OPS_SAAT_TRY", (String) DALUtil.callOracleFunction("{? = call PKG_OPSIYON.OpsiyonSaati('USD','TRY')}", BnsprType.STRING));
			oMap.put("OPS_SAAT_DVZ", (String) DALUtil.callOracleFunction("{? = call PKG_OPSIYON.OpsiyonSaati('USD','EUR')}", BnsprType.STRING));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1578_GET_INFO")
	public static GMMap getInfo1578(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			Connection conn = null;
	        PreparedStatement stmt = null;
	        ResultSet rSet = null;
	        

			HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("ALACAK_HESAP", hznOpsiyonislemTx.getAlacakHesap());
			oMap.put("ALACAK_HESAP_DOVIZ", hznOpsiyonislemTx.getAlacakHesapDvz());
			oMap.put("ALINAN_DOVIZ", hznOpsiyonislemTx.getAlinanDoviz());
			oMap.put("ALINAN_TUTAR", hznOpsiyonislemTx.getAlinanTutar());
			oMap.put("BAZ_DOVIZ", hznOpsiyonislemTx.getBazDvz());
			oMap.put("BAZ_TUTAR", hznOpsiyonislemTx.getBazTutar());
			oMap.put("BORCLU_HESAP", hznOpsiyonislemTx.getBorcluHesap());
			oMap.put("BORCLU_HESAP_DOVIZ", hznOpsiyonislemTx.getBorcluHesapDvz());
			oMap.put("HEDEF_FIYAT", hznOpsiyonislemTx.getHedefFiyat());
			oMap.put("KARSI_DOVIZ", hznOpsiyonislemTx.getKarsiDoviz());
			oMap.put("KARSI_TUTAR", hznOpsiyonislemTx.getKarsiTutar());
			oMap.put("MTM_TARIH", hznOpsiyonislemTx.getMtmTarih());
			oMap.put("MTM_TUTAR", hznOpsiyonislemTx.getMtmTutar());
			oMap.put("OPS_AMAC", hznOpsiyonislemTx.getOpsAmac());
			oMap.put("OPS_CINSI", hznOpsiyonislemTx.getOpsCinsi());
			oMap.put("OPS_DEALER", hznOpsiyonislemTx.getOpsDealer());
			oMap.put("OPS_SEKLI_BAZ", hznOpsiyonislemTx.getOpsSekliBaz());
			oMap.put("OPS_STATUS", hznOpsiyonislemTx.getOpsStatus());
			oMap.put("OPS_TIPI", hznOpsiyonislemTx.getOpsTipi());
			oMap.put("PRIM_DOVIZ", hznOpsiyonislemTx.getPrimDoviz());
			oMap.put("PRIM_HESAP_NO", hznOpsiyonislemTx.getPrimHesapNo());
			oMap.put("PRIM_MALIYET", hznOpsiyonislemTx.getPrimMaliyet());
			oMap.put("PRIM_MUSTERI", hznOpsiyonislemTx.getPrimMusteri());
			oMap.put("PRIM_MUSTERI_YILLIK", hznOpsiyonislemTx.getPrimMusteriYillik());
			oMap.put("PRIM_SUBE_KARI_DOVIZ", hznOpsiyonislemTx.getPrimSubeKariDvz());
			oMap.put("PRIM_SUBE_KARI_TUTTAR", hznOpsiyonislemTx.getPrimSubeKariTutar());
			oMap.put("PRIM_TUTAR", hznOpsiyonislemTx.getPrimTutar());
			oMap.put("REFERANS", hznOpsiyonislemTx.getId().getReferans());
			oMap.put("REFERANS_VIEW", hznOpsiyonislemTx.getId().getReferans());
			oMap.put("RISK_FON_CINSI", hznOpsiyonislemTx.getRiskFonCinsi());
			oMap.put("RISK_ISLEM_TIPI", hznOpsiyonislemTx.getRiskIslemTipi());
			oMap.put("RISK_TEMINAT_CINSI", hznOpsiyonislemTx.getRiskTeminatCinsi());
			oMap.put("RISK_TEMINAT_ORAN", hznOpsiyonislemTx.getRiskTeminatOran());
			oMap.put("RISK_TEMINAT_TUTAR", hznOpsiyonislemTx.getRiskTeminatTutar());
			oMap.put("SATILAN_DOVIZ", hznOpsiyonislemTx.getSatilanDvz());
			oMap.put("SATILAN_TUTAR", hznOpsiyonislemTx.getSatilanTutar());
			oMap.put("SPOT_KUR", hznOpsiyonislemTx.getSpotKur());
			oMap.put("SUBE_ANA", hznOpsiyonislemTx.getSubeAna());
			oMap.put("SUBE_ISLEM", hznOpsiyonislemTx.getSubeIslem());
			oMap.put("SUBE_KARI", hznOpsiyonislemTx.getPrimSubeKariTutar());
			oMap.put("SUBE_PY_KOD", hznOpsiyonislemTx.getSubePyKod());
			oMap.put("TARIH_ISLEM", hznOpsiyonislemTx.getTarihIslem());
			oMap.put("TARIH_PRIM", hznOpsiyonislemTx.getTarihPrim());
			oMap.put("TARIH_UZLASMA", hznOpsiyonislemTx.getTarihUzlasma());
			oMap.put("TARIH_VADE", hznOpsiyonislemTx.getTarihVade());
			oMap.put("OPS_YONU", hznOpsiyonislemTx.getOpsYonu());
			oMap.put("KARSILANAN_TUTAR", hznOpsiyonislemTx.getKarsilananTeminatTl());
			oMap.put("PRIM_MUSTERI_YILLIK", hznOpsiyonislemTx.getPrimMusteriYillik());			
			oMap.put("DOKUMAN1", hznOpsiyonislemTx.getDokuman1().equals("Y") ? false : true);
			oMap.put("DOKUMAN2", hznOpsiyonislemTx.getDokuman2().equals("Y") ? false : true);
			oMap.put("KREDI_TEKLIF_SATIR_NO" , hznOpsiyonislemTx.getKrediTeklifNo());
			oMap.put("ALIS_HESAP_TURU" , hznOpsiyonislemTx.getAlisHesapTuru());
			oMap.put("SATIS_HESAP_TURU" , hznOpsiyonislemTx.getSatisHesapTuru());
			oMap.put("ALIS_HESAP_NO" , hznOpsiyonislemTx.getBankaAlisHesapno());
			oMap.put("SATIS_HESAP_NO" , hznOpsiyonislemTx.getBankaSatisHesapno());
			oMap.put("MUSTERIMUHABIRNO" , hznOpsiyonislemTx.getAlisMuhabirMusteriNo());
			oMap.put("MUSTERIMUHABIRNOSATIS" , hznOpsiyonislemTx.getSatisMuhabirMusteriNo());
			oMap.put("DIGER_REFERANS_VIEW", hznOpsiyonislemTx.getDigerReferans());
			oMap.put("OPSIYON_DOVIZ_KODU", hznOpsiyonislemTx.getOpsDoviz());
			oMap.put("VADE_ZAMAN", hznOpsiyonislemTx.getVadeZaman());			
						
			if(hznOpsiyonislemTx.getBankami().equals("E"))
			{
			oMap.put("BANKA_MUSTERI_NO",hznOpsiyonislemTx.getMusteriNo());
			oMap.put("BANKA_MI", true);
			oMap.put("MUSTERI_MI", false);
			}
			else if(hznOpsiyonislemTx.getBankami().equals("H"))
			{
			oMap.put("GENEL_MUSTERI_NO",hznOpsiyonislemTx.getMusteriNo());
			oMap.put("MUSTERI_MI", true);
			oMap.put("BANKA_MI", false);
			}
			
			if(hznOpsiyonislemTx.getOpsiyonluBonoMu()!=null && hznOpsiyonislemTx.getOpsiyonluBonoMu().equals("E"))
			{
				oMap.put("OPSIYONLU_BONO_CHECK",true);
			}
			
			GMMap resultSetBono = new GMMap();
			
			String func2 = "{? = call pkg_rc1560.Get_Opsiyon_Bono_Detay(?)}";
			Object[] inputValues = new Object[]{BnsprType.NUMBER,iMap.getBigDecimal("TRX_NO")};
			
			resultSetBono= DALUtil.callOracleRefCursorFunction(func2, "TABLE",inputValues  );
		 
			
			if (resultSetBono.getSize("TABLE")>0) {
				GMMap resultSet = new GMMap();
				
				func2 = "{? = call pkg_rc1560.T1578_Get_Opsiyon_Bilgileri(?)}";
				Object[] inputValues2 = new Object[]{BnsprType.NUMBER,resultSetBono.getBigDecimal("TABLE",0,"BONO_REFERANS")};
				
				resultSet= DALUtil.callOracleRefCursorFunction(func2, "TABLE",inputValues2);
				
				oMap.put("HESAP_NO", resultSet.getBigDecimal("TABLE",0,"HESAP_NO"));
				oMap.put("TUTAR", resultSet.getBigDecimal("TABLE",0,"TUTAR"));
				oMap.put("VADE_TARIHI", resultSet.getDate("TABLE",0,"VADE"));
				oMap.put("KULLANILMIS_PRIM", resultSet.getBigDecimal("TABLE",0,"OPS_TUTAR"));
				oMap.put("KULLANILABILIR_PRIM", resultSet.getBigDecimal("TABLE",0,"KALAN_TUTAR"));
				oMap.put("DOVIZ_KODU", resultSet.getString("TABLE",0,"DOVIZ"));
				oMap.put("BONO_REFERANS", resultSetBono.getBigDecimal("TABLE",0,"BONO_REFERANS"));
				oMap.put("KUR_REZERVASYON_NO",resultSetBono.getBigDecimal("TABLE",0,"KUR_REZERVASYON_NO").equals(new BigDecimal(0))?null:resultSetBono.getBigDecimal("TABLE",0,"KUR_REZERVASYON_NO"));
			}
			

			String func = "{? = call pkg_TRN1578.ViewTeminatListesi(?)}";
			oMap.put("TEMINAT_TABLE", DALUtil.callOracleRefCursorFunction(func, "TABLE", new Object[] { BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO") }).get("TABLE"));

			
			oMap.put("ISTATISTIK_KODU", hznOpsiyonislemTx.getIstatistikKodu());
			oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznOpsiyonislemTx.getIstatistikKodu(), "3330/LOV_ISTATISTIK", "ACIKLAMA"));
				
			List<HznOpsiyonBariyerTx> hznOpsiyonBariyerTxs = session.createCriteria(HznOpsiyonBariyerTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			int i = 0;
			
			for (HznOpsiyonBariyerTx hznOpsiyonBariyerTx : hznOpsiyonBariyerTxs) {
			
				if (i==0) {
					oMap.put("BARIYER_CINSI1",    hznOpsiyonBariyerTx.getBariyerCinsi());
					oMap.put("BARIYER_TIPI1",     hznOpsiyonBariyerTx.getBariyerTipi());
					oMap.put("BARIYER_DEGER1",    hznOpsiyonBariyerTx.getBariyerDeger());
					oMap.put("BARIYER_BASTAR1",   hznOpsiyonBariyerTx.getBaslangicTarih());
					oMap.put("BARIYER_BITTAR1",   hznOpsiyonBariyerTx.getBitisTarih());
					oMap.put("BARIYER_BASZAMAN1", hznOpsiyonBariyerTx.getBariyerBaszaman());
					oMap.put("BARIYER_BITZAMAN1", hznOpsiyonBariyerTx.getBariyerBitzaman());					
				}
				if (i==1) {
					oMap.put("BARIYER_CINSI2",    hznOpsiyonBariyerTx.getBariyerCinsi());
					oMap.put("BARIYER_TIPI2",     hznOpsiyonBariyerTx.getBariyerTipi());
					oMap.put("BARIYER_DEGER2",    hznOpsiyonBariyerTx.getBariyerDeger());
					oMap.put("BARIYER_BASTAR2",   hznOpsiyonBariyerTx.getBaslangicTarih());
					oMap.put("BARIYER_BITTAR2",   hznOpsiyonBariyerTx.getBitisTarih());		
					oMap.put("BARIYER_BASZAMAN2", hznOpsiyonBariyerTx.getBariyerBaszaman());
					oMap.put("BARIYER_BITZAMAN2", hznOpsiyonBariyerTx.getBariyerBitzaman());
				}
				i++;
			}			
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN1578_GET_RADIO_FLAGS")
    public static GMMap getRadioFlags1573(GMMap iMap) {

        try {
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();
 
            String proc = "{call pkg_trn1573.Belge_Kontrol(?,?,?,?)}";
            Object [] input  = new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO")};
            Object [] output = new Object[] {BnsprType.STRING,"PS_TCS",BnsprType.STRING,"PS_RBS",BnsprType.STRING,"ps_ots"};
             
            try {
                oMap = (GMMap) DALUtil.callOracleProcedure(proc, input, output);
           }
              catch (Exception e) {
                  throw ExceptionHandler.convertException(e);
              }

            if(oMap.get("PS_TCS")!=null && oMap.getString("PS_TCS").equals("E")){
                oMap.put("PS_TCS" , true);                 
            }else{
                oMap.put("PS_TCS" , false);
            }

            if(oMap.get("PS_RBS")!=null && oMap.getString("PS_RBS").equals("E")){
                oMap.put("PS_RBS" , true);                 
            }else{
                oMap.put("PS_RBS" , false);
            }
            
          return oMap;
            
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }
	
	
	
	@GraymoundService("BNSPR_TRN1578_GET_MUSTERI_BILGILERI")
	public static GMMap getMusteriBilgileri(GMMap iMap) {
	
	GMMap oMap = null;
	 String proc = "{call PKG_TRN1578.GETMUSTERIDETAY(?,?,?,?,?,?,?,?,?,?)}";	 
	 Object [] input  = new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO")};
	 Object [] output = new Object[] {BnsprType.NUMBER,"pn_py_no",BnsprType.STRING,"pc_py_isim",BnsprType.NUMBER,"pn_ana_sube",BnsprType.STRING,"pc_ana_sube_isim",
			 BnsprType.STRING,"pn_kullanici_sube_kod",BnsprType.STRING,"pc_kullanici_sube_adi",BnsprType.STRING,"pc_ps_musteri",
			 BnsprType.NUMBER,"pn_limit_tutar",BnsprType.DATE,"pn_limit_vade"};
	 
	 try {
		  oMap = (GMMap) DALUtil.callOracleProcedure(proc, input, output);
	 }
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}


	return oMap;
	
	}
	
	@GraymoundService("BNSPR_TRN_1578_GUN_FARKINI_HESAPLA")
	public static GMMap gunFarkiniHesapla(GMMap iMap) {
		{
			GMMap oMap = new GMMap();
			try {

	            String func = "{? = call PKG_TRN1578.gun_farki_bul(?,?)}";
	            Object[] inputValues = new Object[]{BnsprType.DATE, iMap.getDate("VADE_TARIHI"),
	                                                BnsprType.DATE, iMap.getDate("ISLEM_TARIHI")};

	            BigDecimal gunFarki = (BigDecimal) DALUtil.callOracleFunction(func , BnsprType.NUMBER , inputValues);
	            
	            oMap.put("GUN_FARKI" , gunFarki);
	            }
	        catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }			

			return oMap;
		}
	}
	
	@GraymoundService("BNSPR_TRN1578_GET_BANKA_TARIHI")
    public static GMMap getBankaTarihi(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {

            String func = "{? = call PKG_TARIH.ileri_is_gunu(?)}";
            Object[] inputValues = new Object[]{BnsprType.DATE, iMap.getDate("BANKA_TARIHI")};

            Date bankaTarihi =  (Date) DALUtil.callOracleFunction(func , BnsprType.DATE , inputValues);
            
            oMap.put("BANKA_TARIHI" , bankaTarihi);
            }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_TRN1578_REFERANS_AL")
    public static GMMap referansAl(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {

            }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_TRN1578_PRIM_TARIHI")
    public static GMMap getPrimTarihi(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            oMap.put("PRIM_TARIHI" , DALUtil.callOneParameterFunction("{? = call pkg_tarih.ileri_is_gunu(?)}", Types.DATE, iMap.getDate("ISLEM_TARIHI")));
            }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_TRN1578_PRIM_TUTAR_HESAPLA")
	public static GMMap primTutarHesapla(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			int i=1;
			stmt = conn.prepareCall("{ ? = call PKG_TRN1578.PrimTutarHesapla(?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAZ_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ANLASMA_KURU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_PRIM"));
			stmt.setString(i++, iMap.getString("BAZ_DOVIZ"));
			stmt.setString(i++, iMap.getString("KARSI_DOVIZ"));
			stmt.setString(i++, iMap.getString("PRIM_DOVIZ"));
			stmt.setString(i++, iMap.getString("OPS_YONU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REZERVASYON_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			oMap.put("PRIM_TUTARI", stmt.getBigDecimal(1));
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1578_OPS_BILGILERI")
    public static GMMap opsBilgileri(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
        	BigDecimal Musteri_No = iMap.getBigDecimal("MUSTERI_NO");
        	BigDecimal Bono_referans = iMap.getBigDecimal("BONO_REFERANS");
        	oMap.put("BONO_TUTARI", LovHelper.diLov(Bono_referans,Musteri_No,Musteri_No, "1578/LOV_BONO_REFERANS_NO", "TUTAR"));
        	oMap.put("HESAP_NO", LovHelper.diLov(Bono_referans,Musteri_No,Musteri_No, "1578/LOV_BONO_REFERANS_NO", "HESAP_NO"));
        	oMap.put("VADE", LovHelper.diLov(Bono_referans,Musteri_No,Musteri_No, "1578/LOV_BONO_REFERANS_NO", "VADE"));
        	oMap.put("OPS_TUTAR", LovHelper.diLov(Bono_referans,Musteri_No,Musteri_No,"1578/LOV_BONO_REFERANS_NO", "OPS_TUTAR"));
        	oMap.put("KALAN_TUTAR", LovHelper.diLov(Bono_referans,Musteri_No,Musteri_No, "1578/LOV_BONO_REFERANS_NO", "KALAN_TUTAR"));
        	oMap.put("DOVIZ", LovHelper.diLov(Bono_referans,Musteri_No,Musteri_No, "1578/LOV_BONO_REFERANS_NO", "DOVIZ"));
        	oMap.put("UNVAN", LovHelper.diLov(iMap.getBigDecimal("MUSTERI_NO"), "1578/LOV_GENEL_MUSTERI_NO", "UNVAN"));
            
            }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_TRN1578_SWIFT_GORUNTULE")
	public static GMMap swiftGoruntule(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_SWIFT.Swift_Goruntule(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
		    
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(3, iMap.getString("REFERANS"));
			stmt.execute();
			stmt.getMoreResults();
			Object obj = stmt.getObject(1);
			oMap.put("SWIFT_AREA", obj);
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}

	@GraymoundService("BNSPR_TRN1578_FILL_COMBO_INIT")
	public static GMMap initCombo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "BARIYER_CINSI");
			oMap.put("BARIYER_CINSI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.clear();
			
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "BARIYER_TIPI");
			oMap.put("BARIYER_TIPI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.clear();
			
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "OPSIYON_CINSI");
			oMap.put("OPSIYON_CINSI", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
		} catch(Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}		
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1578_SWIFT_GENERATE")
	public static GMMap swiftGenerate(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_SWIFT.Swift_Generate(?,?,?,?,?,?,?,?)}");
		    
			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(3, hznOpsiyonislemTx.getId().getReferans());
			stmt.setString(4, "H");
			stmt.setString(5, "H");
			stmt.setString(6, "H");
			stmt.setString(7, "H");
			stmt.setString(8, "H");
			stmt.execute();
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	}


