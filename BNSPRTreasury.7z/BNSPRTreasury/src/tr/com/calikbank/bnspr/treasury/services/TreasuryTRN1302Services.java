package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznAnaMuhabirPrTx;
import tr.com.calikbank.bnspr.dao.HznAnaMuhabirPrTxId;
import tr.com.calikbank.bnspr.dao.HznEkMuhabirPrTx;
import tr.com.calikbank.bnspr.dao.HznEkMuhabirPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


/**
 * @author obss2
 *
 */
public class TreasuryTRN1302Services {
	
	@GraymoundService("BNSPR_TRN1302_GET_TRANSACTION_NO")
	public static GMMap getTransactionNo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1302.muhabir_arama(?) }");
			stmt.registerOutParameter(1, Types.FLOAT);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1302_GET_MASTER")
	public static GMMap getMasterRecords(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String tableName = "ANA_MUHABIR";
			Session session = DAOSession.getSession("BNSPRDal"); 
			
			Criteria criteria = session.createCriteria(HznAnaMuhabirPrTx.class)
										.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));
			
			if(iMap.getBigDecimal("MUSTERI_NO") != null) {
				criteria.add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO")));
			}
										
			List<?> recordList = criteria.list();
			

			for (int row = 0; row < recordList.size(); row++){
				HznAnaMuhabirPrTx hznAnaMuhabirPrTx = (HznAnaMuhabirPrTx) recordList.get(row);

				oMap.put(tableName, row, "DURUM_KODU",	hznAnaMuhabirPrTx.getDurumKodu());
				oMap.put(tableName, row, "MUSTERI_NO",	hznAnaMuhabirPrTx.getId().getMusteriNo());
				oMap.put(tableName, row, "ANA_BIC_KODU_BANKA", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_ANA_MUHABIR", "BIC_BANKA"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SEHIR", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_ANA_MUHABIR", "BIC_SEHIR"));
				oMap.put(tableName, row, "ANA_BIC_KODU_ULKE", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_ANA_MUHABIR", "BIC_ULKE"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SUBE", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_ANA_MUHABIR", "BIC_SUBE"));
				oMap.put(tableName, row, "ANA_MUHABIR_ADI",
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_ANA_MUHABIR", "UNVAN"));
				oMap.put(tableName, row, "DETAIL_DATA",	new ArrayList<GMMap>());				
				oMap.put(tableName, row, "FLAG",		false);				
				oMap.put(tableName, row, "F_NEW",		false);
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1302_GET_DETAIL")
	public static GMMap getDetailRecords(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String tableName = "EK_MUHABIR";
			Session session = DAOSession.getSession("BNSPRDal"); 
			
			Criteria criteria = session.createCriteria(HznEkMuhabirPrTx.class)
										.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));

			if(iMap.getBigDecimal("MUSTERI_NO") != null) {
				criteria.add(Restrictions.eq("id.anaMuhabir", iMap.getBigDecimal("MUSTERI_NO")));
			}

			List<?> recordList = criteria.list();
			

			for (int row = 0; row < recordList.size(); row++){
				HznEkMuhabirPrTx hznEkMuhabirPrTx = (HznEkMuhabirPrTx) recordList.get(row);

				oMap.put(tableName, row, "ANA_MUHABIR", hznEkMuhabirPrTx.getId().getAnaMuhabir());
				oMap.put(tableName, row, "DURUM_KODU",	hznEkMuhabirPrTx.getDurumKodu());
				oMap.put(tableName, row, "MUSTERI_NO", 	hznEkMuhabirPrTx.getId().getMusteriNo());
				oMap.put(tableName, row, "EK_BIC_KODU_BANKA", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_EK_MUHABIR", "BIC_BANKA"));
				oMap.put(tableName, row, "EK_BIC_KODU_SEHIR", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_EK_MUHABIR", "BIC_SEHIR"));
				oMap.put(tableName, row, "EK_BIC_KODU_ULKE", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_EK_MUHABIR", "BIC_ULKE"));
				oMap.put(tableName, row, "EK_BIC_KODU_SUBE", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_EK_MUHABIR", "BIC_SUBE"));
				oMap.put(tableName, row, "EK_MUHABIR_ADI",
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_EK_MUHABIR", "UNVAN"));
			}
			
			oMap.put("TBS_SIZE", recordList.size());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1302_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		
		try {
			Session session 	= DAOSession.getSession("BNSPRDal");
			String tableName 	= "HZN_ANA_MUHABIR_BANKA_ISL";

			List<?> hznList 	= session.createCriteria(HznAnaMuhabirPrTx.class)
											.add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO")))
											.list();
			for (int i = 0; i < hznList.size(); i++) {
				HznAnaMuhabirPrTx hznAnaMuhabirPrTx = (HznAnaMuhabirPrTx) hznList.get(i);
				Boolean flag = true;
				for (int row = 0; row < iMap.getSize(tableName); row++) {
					HznAnaMuhabirPrTxId id = new HznAnaMuhabirPrTxId();

					id.setMusteriNo(iMap.getBigDecimal(tableName, row, "MUSTERI_NO"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					if (hznAnaMuhabirPrTx.getId().equals(id))
						flag = false;
				}
				if (flag)
					session.delete(hznAnaMuhabirPrTx);
			}
			session.flush();
			
			
			List<?> recordList = (List<?>)iMap.get(tableName);
			
			for (int row = 0;row<recordList.size();row++) {
				BigDecimal musteriNo_FK = iMap.getBigDecimal(tableName, row, "MUSTERI_NO");
				
				HznAnaMuhabirPrTxId id = new HznAnaMuhabirPrTxId();
				id.setMusteriNo	(musteriNo_FK);
				id.setTxNo		(iMap.getBigDecimal("TRX_NO"));
				
				HznAnaMuhabirPrTx hznAnaMuhabirPrTx = (HznAnaMuhabirPrTx)session.get(HznAnaMuhabirPrTx.class, id);
				if(hznAnaMuhabirPrTx == null) {
					hznAnaMuhabirPrTx = new HznAnaMuhabirPrTx();
				}
				
				hznAnaMuhabirPrTx.setId			(id);
				hznAnaMuhabirPrTx.setDurumKodu	(iMap.getString(tableName, row, "DURUM_KODU"));
				
				session.saveOrUpdate(hznAnaMuhabirPrTx);
				session.flush();
			
				if(iMap.getBoolean(tableName, row, "FLAG")) {
					
					List<?> temAltList 	= session.createCriteria(HznEkMuhabirPrTx.class)
													.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
													.add(Restrictions.eq("id.anaMuhabir", musteriNo_FK))
													.list();
					
					for (int i = 0; i < temAltList.size(); i++) {
						HznEkMuhabirPrTx deleted = (HznEkMuhabirPrTx) temAltList.get(i);
						session.delete(deleted);
					}
					session.flush();
					
					List<?> ekList 	= (List<?>) iMap.get(tableName, row, "DETAIL_DATA");
					if(ekList !=null){
						for(int i=0;i<ekList.size();i++) {
							GMMap xMap = new GMMap((HashMap<?, ?>) ekList.get(i));
							
							HznEkMuhabirPrTxId id_Ek = new HznEkMuhabirPrTxId();
							id_Ek.setMusteriNo(xMap.getBigDecimal("MUSTERI_NO"));
							id_Ek.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id_Ek.setAnaMuhabir(musteriNo_FK);
							
							HznEkMuhabirPrTx hznEkMuhabirPrTx = (HznEkMuhabirPrTx)session.get(HznEkMuhabirPrTx.class, id_Ek);
							
							if(hznEkMuhabirPrTx == null) {
								hznEkMuhabirPrTx = new HznEkMuhabirPrTx();
							}
							hznEkMuhabirPrTx.setId(id_Ek);
							hznEkMuhabirPrTx.setDurumKodu(xMap.getString("DURUM_KODU"));
							
							session.saveOrUpdate(hznEkMuhabirPrTx);
							session.flush();
						}
					}
				}
			}
			
			iMap.put("TRX_NAME", "1302");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1302_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			//  Get Master
			String tableName = "ANA_MUHABIR";
			Session session = DAOSession.getSession("BNSPRDal"); 
			
			Criteria criteria = session.createCriteria(HznAnaMuhabirPrTx.class)
										.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));
			
			if(iMap.getBigDecimal("MUSTERI_NO") != null) {
				criteria.add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO")));
			}
										
			List<?> recordList = criteria.list();
			

			for (int row = 0; row < recordList.size(); row++){
				HznAnaMuhabirPrTx hznAnaMuhabirPrTx = (HznAnaMuhabirPrTx) recordList.get(row);

				oMap.put(tableName, row, "DURUM_KODU",	hznAnaMuhabirPrTx.getDurumKodu());
				oMap.put(tableName, row, "MUSTERI_NO",	hznAnaMuhabirPrTx.getId().getMusteriNo());
				oMap.put(tableName, row, "ANA_BIC_KODU_BANKA", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_BANKA"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SEHIR", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_SEHIR"));
				oMap.put(tableName, row, "ANA_BIC_KODU_ULKE", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_ULKE"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SUBE", 
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_SUBE"));
				oMap.put(tableName, row, "ANA_MUHABIR_ADI",
														LovHelper.diLov(hznAnaMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "UNVAN"));
			}
			
			
			//Get Detail
			tableName = "EK_MUHABIR"; 
			
			Criteria criteriaEk = session.createCriteria(HznEkMuhabirPrTx.class)
										.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));

			if(iMap.getBigDecimal("MUSTERI_NO") != null) {
				criteria.add(Restrictions.eq("id.anaMuhabir", iMap.getBigDecimal("MUSTERI_NO")));
			}
			
			recordList = criteriaEk.list();
			

			for (int row = 0; row < recordList.size(); row++){
				HznEkMuhabirPrTx hznEkMuhabirPrTx = (HznEkMuhabirPrTx) recordList.get(row);

				oMap.put(tableName, row, "ANA_MUHABIR", hznEkMuhabirPrTx.getId().getAnaMuhabir());
				oMap.put(tableName, row, "DURUM_KODU",	hznEkMuhabirPrTx.getDurumKodu());
				oMap.put(tableName, row, "MUSTERI_NO", 	hznEkMuhabirPrTx.getId().getMusteriNo());
				oMap.put(tableName, row, "EK_BIC_KODU_BANKA", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_BANKA"));
				oMap.put(tableName, row, "EK_BIC_KODU_SEHIR", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_SEHIR"));
				oMap.put(tableName, row, "EK_BIC_KODU_ULKE", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_ULKE"));
				oMap.put(tableName, row, "EK_BIC_KODU_SUBE", 
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "BIC_SUBE"));
				oMap.put(tableName, row, "EK_MUHABIR_ADI",
														LovHelper.diLov(hznEkMuhabirPrTx.getId().getMusteriNo(), "1302/LOV_K_MUSTERI", "UNVAN"));
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR_1300_SAVE_KONTROL")
	public static GMMap SaveControl(GMMap iMap){
		try{   
			

			int k=0;
			int l=0;
			int m=0;
			String 	tableName	= "MUHABIR_TABLO";
			//BirSaticiLimitTx birSaticiLimitTx =(BirSaticiLimitTx)session_NEW.get(BirSaticiLimitTx.class, iMap.getBigDecimal("TRX_NO"));
			List<?> list = (List<?>) iMap.get(tableName);
			List<?> list_2 = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){


				//hata mesaj�
				if(iMap.getString(tableName, i, "MUSTERI_NO") == null || iMap.getString(tableName, i, "MUSTERI_NO").isEmpty())
				{
				iMap.put("HATA_NO", new BigDecimal(330));
				      iMap.put("P1", "MUSTERI_NO");
				      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if(iMap.getString(tableName, i, "DOVIZ_KODU") == null || iMap.getString(tableName, i, "DOVIZ_KODU").isEmpty())
				{
				iMap.put("HATA_NO", new BigDecimal(330));
				      iMap.put("P1", "DOVIZ_KODU");
				      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if(iMap.getString(tableName, i, "MUSTERI_MUHABIR_NO") == null || iMap.getString(tableName, i, "MUSTERI_MUHABIR_NO").isEmpty())
				{
				iMap.put("HATA_NO", new BigDecimal(330));
				      iMap.put("P1", "MUSTERI_MUHABIR_NO");
				      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				k=0;
				
				for (int j = i+1; j < list_2.size(); j++) {
					
					
				 if(iMap.getString(tableName, j, "MUSTERI_NO")==null || iMap.getString(tableName, j, "MUSTERI_NO").length() ==0 ){
						
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "MUSTERI_NO");
				    return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				
					
			    k=iMap.getString(tableName, j, "MUSTERI_NO").compareTo(iMap.getString(tableName, i, "MUSTERI_NO") );
					

				
				
				 if(iMap.getString(tableName, j, "DOVIZ_KODU")==null || iMap.getString(tableName, j, "DOVIZ_KODU").length() ==0 ){
						
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "DOVIZ_KODU");
				    return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				
					
			    l=iMap.getString(tableName, j, "DOVIZ_KODU").compareTo(iMap.getString(tableName, i, "DOVIZ_KODU") );
					

				
				 if(iMap.getString(tableName, j, "MUSTERI_MUHABIR_NO")==null || iMap.getString(tableName, j, "MUSTERI_MUHABIR_NO").length() ==0 ){
						
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "MUSTERI_MUHABIR_NO");
				    return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				 		
					
			    m=iMap.getString(tableName, j, "MUSTERI_MUHABIR_NO").compareTo(iMap.getString(tableName, i, "MUSTERI_MUHABIR_NO") );
					

			    
			    
				if (  k==0 && l==0 && m==0 ){	
					iMap.put("HATA_NO", new BigDecimal(1524));
					iMap.put("P1", i+1);
					iMap.put("P2", j+1);
					return	(GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
			}
				
				
				

				}
				
				
		}
					
			return iMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
}
