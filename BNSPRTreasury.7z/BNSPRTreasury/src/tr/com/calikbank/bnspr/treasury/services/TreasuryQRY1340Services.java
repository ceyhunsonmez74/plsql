package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1340Services {
	@GraymoundService("BNSPR_QRY1340_W1_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboboxInitialValue(GMMap iMap) {
		
		try {
			GMMap oMap = new GMMap();
			iMap.put("KOD","MT202_DURUM");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("MT202_DURUM", GMServiceExecuter.execute(
					"BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY1340_W1_GET_LIST")
	public static GMMap getList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_trn1304.GET_mt202_list(?,?,?,?,?,?,?,?) }");
			
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("BIC_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_MIN").compareTo(BigDecimal.ZERO)==0?null:iMap.getBigDecimal("TUTAR_MIN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_MAX").compareTo(BigDecimal.ZERO)==0?null:iMap.getBigDecimal("TUTAR_MAX"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setDate(i++,iMap.get("BASLANGIC_TARIHI")!=null?new Date(iMap.getDate("BASLANGIC_TARIHI").getTime()):null);
			stmt.setDate(i++,iMap.get("BITIS_TARIHI")!=null?new Date(iMap.getDate("BITIS_TARIHI").getTime()):null);
			stmt.setDate(i++,iMap.get("VALOR_TARIHI")!=null?new Date(iMap.getDate("VALOR_TARIHI").getTime()):null);
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "TBL_ISLEM"));
			
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1340_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1304.mt202_Aktar(?,?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("COMPANY_CODE"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRANS_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	

}
