package tr.com.calikbank.bnspr.treasury.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;


public class TreasuryQRY1580Services {
	
    @GraymoundService("BNSPR_QRY1580_GET_BELGELER")
    public static GMMap getBelgelerQRY1580(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            String func = "{? = call pkg_rc1580.GetBelgeList(?,?)}";
            Object [] values  = new Object[] {BnsprType.STRING, iMap.getString("REFERANS"),
                                                BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO") };

            oMap = DALUtil.callOracleRefCursorFunction(func , "BELGE_KONTROL" , values);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	
}
