package tr.com.calikbank.bnspr.treasury.services;
import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1337Services {

	
	@GraymoundService("BNSPR_QRY1337_MUSTERI_INFO_SEARCH")
	public static GMMap musteriInfoSearch(GMMap iMap) {
		GMMap oMap = new GMMap();

		//try {

			GMMap innerOutMap = GMServiceExecuter.call("BNSPR_TRN1337_MUSTERI_INFO_SEARCH", iMap);
			oMap.putAll(innerOutMap);

			//oMap.put("RESPONSE", 2);
			//oMap.put("RESPONSE_DATA", "OK");

//		}
//		catch (Exception e) {
//			oMap.put("RESPONSE", 0);
//			//oMap.put("RESPONSE_DATA", e.getMessage());
//			oMap.put("RESPONSE_DATA", ExceptionHandler.convertException(e).getLocalizedMessage());
//
//		}

		return oMap;
	}
	
	
//	@GraymoundService("BNSPR_QRY1337_MUSTERI_INFO_SEARCH")
//	public static GMMap musteriInfoSearch(GMMap iMap) {
//
//		Connection conn = null;
//		CallableStatement stmt = null;
//		ResultSet rSet = null;
//
//		GMMap oMap = new GMMap();
//		try {
//
//			String tableName = "MUSTERI_INFO_LIST";
//			conn = DALUtil.getGMConnection();
//			stmt = conn.prepareCall("{? = call PKG_TRN1337.GetMusteriInfoList(?)}");
//
//			int i = 1;
//			stmt.registerOutParameter(i++, -10);
//			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
//			stmt.execute();
//			rSet = (ResultSet) stmt.getObject(1);
//			i = 0;
//			while (rSet.next()) {
//				oMap.put(tableName, i, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
//				oMap.put(tableName, i, "MUSTERI_TIPI", rSet.getString("MUSTERI_TIPI"));
//				oMap.put(tableName, i, "DMUSTERI_TIPI", rSet.getString("DMUSTERI_TIPI"));
//				oMap.put(tableName, i, "F_NITELIKLI", rSet.getString("F_NITELIKLI"));
//				oMap.put(tableName, i, "DF_NITELIKLI", rSet.getString("DF_NITELIKLI"));
//				oMap.put(tableName, i, "YATIRIM_EXTRESI_GONDERILSINMI", rSet.getString("YATIRIM_EXTRESI_GONDERILSINMI"));
//				oMap.put(tableName, i, "DYATIRIM_EXTRESI_GONDERILSINMI", rSet.getString("DYATIRIM_EXTRESI_GONDERILSINMI"));
//				oMap.put(tableName, i, "SKOR", rSet.getString("SKOR"));
//				i++;
//			}
//
//			return oMap;
//
//		}
//		catch (Exception e) {
//			throw ExceptionHandler.convertException(e);
//		}
//		finally {
//			GMServerDatasource.close(rSet);
//			GMServerDatasource.close(stmt);
//			GMServerDatasource.close(conn);
//		}
//	}

}
