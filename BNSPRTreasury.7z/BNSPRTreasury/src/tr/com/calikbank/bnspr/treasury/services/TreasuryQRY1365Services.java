package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1365Services {
	
	@GraymoundService("BNSPR_QRY1365_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		String listName = "DURUM_KODU";
		GuimlUtil.wrapMyCombo(oMap, listName, "A", "A��k");
		GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kapal�");
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY1365_HZN_TAHSIL_EDILMEMIS_TAKSIT")
	public static GMMap getCashFlowGunlukOzet(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1365.Tahsil_Edilmemis_Taksit(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			
			java.math.BigDecimal tx_no = stmt.getBigDecimal(1);
			stmt = conn.prepareCall("{ ? = call PKG_TRN1365.Sorgula(?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, tx_no);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "TAHSIL_EDILMEMIS_TAKSIT");
		} catch (java.sql.SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1365_HZN_MANUEL_TAKSIT_TAHSILATI")
	public static GMMap getCashFlowGunlukOzet2(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			String tableName = "TAHSIL_EDILMEMIS_TAKSIT";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){
				
			//	System.out.println(iMap.getBigDecimal(tableName, i,"TX_NO"));
				if(iMap.getString(tableName, i,"SEC") != null && iMap.getString(tableName, i,"SEC").equals("1"))
				{
					stmt = conn.prepareCall("{ call PKG_TRN1365.Manuel_Taksit_Tahsilati(?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal(tableName, i,"TX_NO"));
					stmt.execute();
				}
			}
			
			stmt = conn.prepareCall("{ call PKG_TRN1365.Tahsil_Edilmemis_Taksit(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			java.math.BigDecimal tx_no = stmt.getBigDecimal(1);
			stmt = conn.prepareCall("{ ? = call PKG_TRN1365.Sorgula(?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, tx_no);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "TAHSIL_EDILMEMIS_TAKSIT"));
			iMap.put("MESSAGE_NO", new BigDecimal(2076));
			oMap.put("MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
