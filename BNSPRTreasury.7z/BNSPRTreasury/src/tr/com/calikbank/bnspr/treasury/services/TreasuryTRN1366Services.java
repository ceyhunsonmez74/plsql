package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1366Services {

	@GraymoundService("BNSPR_TRN1366_HZN_IPTAL_SORGULA")
	public static GMMap iptalSorgula(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN1365.Iptal_Sorgula}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "HAZINE_DEPO_TAKSIT_BATCH");
		} catch (java.sql.SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN1366_HZN_IPTAL")
	public static GMMap iptal(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1365.Iptal(?)}");
		//	stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(1, iMap.getBigDecimal("TX_NO"));
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("HAZINE_DEPO_TAKSIT_BATCH",GMServiceExecuter.execute("BNSPR_TRN1366_HZN_IPTAL_SORGULA", iMap).get("RESULTS"));
			return oMap;
		} catch (java.sql.SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
