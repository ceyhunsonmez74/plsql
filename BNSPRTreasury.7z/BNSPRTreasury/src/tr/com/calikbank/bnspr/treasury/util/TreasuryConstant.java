package tr.com.calikbank.bnspr.treasury.util;

public class TreasuryConstant {
	public enum IslemKodu{
		DOVIZ_ALIS("2012"),
		DOVIZ_SATIS("2013"),
		DOVIZ_ARBITRAJ("2011");
		
		private String code;

		private IslemKodu(String code) {
			this.code = code;
		}

		public String getCode() {
			return code;
		}
	}
}
