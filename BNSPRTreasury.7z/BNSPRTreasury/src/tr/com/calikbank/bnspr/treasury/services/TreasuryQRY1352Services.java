package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
public class TreasuryQRY1352Services {
	
	@GraymoundService("BNSPR_ORY1352_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
			try{
				GMMap oMap = new GMMap();
				iMap.put("KOD", "RISK_DURUMU");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("K_RISK_DURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
								
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
	
	@GraymoundService("BNSPR_ORY1352_GET_TASLAK")
	public static GMMap getList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC_TREASURY.RC_QRY1352_GET_TASLAK(?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++,iMap.getBigDecimal("K_BANKA_NO"));
			stmt.setString(i++,iMap.getString("K_RISK_DURUMU"));	
			stmt.setString(i++,iMap.getString("K_DOVIZ"));
			if(iMap.getDate("K_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("K_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			
     		stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "V_HZN_LIMIT_RISK_IZLEME");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	 }
	
	
	@GraymoundService("BNSPR_ORY1352_GET_DETAY")
	public static GMMap getDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_HZN_LIMIT.GnlRisk_Izleme_Data_Hazirla(?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++,iMap.getBigDecimal("MUSTERI_NO"));
     		stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "HZN_TMP_ANA_RISK");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	 }
		
	
	@GraymoundService("BNSPR_ORY1352_GET_DETAY2")
	public static GMMap getDetay2(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_HZN_LIMIT.DtyRisk_Izleme_Data(?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++,iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setDate(i++,new Date(iMap.getDate("TARIH").getTime()));
     		stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "HZN_TMP_DTY_RISK");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	 }
}