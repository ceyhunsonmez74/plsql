package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznTurevBsmvistisnaTx;
import tr.com.calikbank.bnspr.dao.HznTurevBsmvistisnaTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1582Services {
	
	@GraymoundService("BNSPR_TRN1582_GET_MUSTERI_LIST")
	public static GMMap getMusteriList(GMMap iMap){
		Connection conn = null;
		ResultSet rSet = null;
		CallableStatement stmt = null;


		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1582.GetParameterList()}");
	
			stmt.registerOutParameter(1, -10); 
			stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

			String tableName = "MUSTERI_LISTESI";
			int row = 0;
			GMMap oMap = new GMMap();
			while (rSet.next()) {
				BigDecimal musteriNo = rSet.getBigDecimal(1);
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(1));
				oMap.put(tableName, row, "MUSTERI_ADI",DALUtil.callOneParameterFunction("{? = call pkg_musteri.unvan(?)}", Types.VARCHAR, musteriNo));

				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1582_SAVE")
	public static Map<?, ?> trn1582Save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "MUSTERI_LISTESI";
			List<?> listGenel = (List<?>) iMap.get(tableName);
			for (int i = 0; i < listGenel.size(); i++) {
				HznTurevBsmvistisnaTx turevBsmvistisnaTx = new HznTurevBsmvistisnaTx();
				HznTurevBsmvistisnaTxId id = new HznTurevBsmvistisnaTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setMusteriNo(iMap.getBigDecimal(tableName,i,"MUSTERI_NO"));
				turevBsmvistisnaTx.setId(id);

				session.saveOrUpdate(turevBsmvistisnaTx);
				session.flush();
			}
			
			
			iMap.put("TRX_NAME", "1582");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1582_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUSTERI_GRUBU";
			 List<?> list = session.createCriteria(HznTurevBsmvistisnaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
		        .list();
		    
		     for (int row = 0; row < list.size(); row++){
		    	 HznTurevBsmvistisnaTx hznTurevBsmvistisna = (HznTurevBsmvistisnaTx) list.get(row);
		    	 oMap.put(tableName, row, "MUSTERI_NO", hznTurevBsmvistisna.getId().getMusteriNo());
				 oMap.put(tableName, row, "MUSTERI_ADI",DALUtil.callOneParameterFunction("{? = call pkg_musteri.unvan(?)}", Types.VARCHAR, hznTurevBsmvistisna.getId().getMusteriNo()));
		     }
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}