package tr.com.calikbank.bnspr.treasury.services;


import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznGenelParametreTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;

import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1231Services {
    
    
    @GraymoundService("BNSPR_TRN1231_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
            Session session = DAOSession.getSession("BNSPRDal");
      
                HznGenelParametreTx id = new HznGenelParametreTx();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                
                if (iMap.getBoolean("CHECK_BUTTON"))
                		id.setDeger("E");
                else
                	id.setDeger("H");
               id.setKod("INTERNET_DOVIZ");
             
                  
                    session.saveOrUpdate(id);
                    session.flush();
                      
                
               iMap.put("TRX_NAME","1231");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } 
     }
	
@GraymoundService("BNSPR_TRN1231_CHECK_BOX_GET")
	public static GMMap getCheckBox(GMMap iMap){
	   GMMap oMap = new GMMap();
 		Object[] inputValues = new Object[2];

 		int i = 0;
 		inputValues[i++] = BnsprType.STRING;
 		inputValues[i++] = "INTERNET_DOVIZ";

 		 i = 0;
 	 

 		String func = "{?=call pkg_trn1231.GetIslemDurumu(?)}";
 		try {
 			Object deg=DALUtil.callOracleFunction(func,BnsprType.STRING ,inputValues);
 			if (deg.equals("E"))
 			oMap.put("ISLEM",true);
 			else
 				oMap.put("ISLEM",false);
 	                  	          	        			
 		}
 		catch (Exception e) {
 			throw ExceptionHandler.convertException(e);
 		}
 		return oMap;
	}

@GraymoundService("BNSPR_TRN1231_GET_HISTORY")
public static GMMap getHistory(GMMap iMap) {
	   GMMap oMap = new GMMap();
		Object[] inputValues = new Object[2];
		Object[] outputValues = new Object[2];
		int i = 0;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = "INTERNET_DOVIZ";
		 i = 0;
	 

		String func = "{?=call pkg_trn1231.GetIslemListesi}";
		try {
			oMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "DATA",outputValues);
	                  	          	        			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
    
}

@GraymoundService("BNSPR_TRN1231_GET_INFO")
public static GMMap getinfo(GMMap iMap) {
	   GMMap oMap = new GMMap();
		Object[] inputValues = new Object[2];
		Object[] outputValues = new Object[2];
		int i = 0;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = "INTERNET_DOVIZ";
		 i = 0;
	 
		 oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

		String func = "{?=call pkg_trn1231.GetIslemListesi}";
		try {
			
			  Session session = DAOSession.getSession("BNSPRDal");
				 
				
				List<HznGenelParametreTx> bb=null;

		         bb= (List<HznGenelParametreTx>) session.createCriteria(HznGenelParametreTx.class)
		         .add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
		        .list();
				 
				oMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "DATA",outputValues);
				
				if (bb.get(0).getDeger().equals("E"))
				oMap.put("CHECH_BTN",true );
				else
				oMap.put("CHECH_BTN",false );
			 
	                  	          	        			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
    
}

}

