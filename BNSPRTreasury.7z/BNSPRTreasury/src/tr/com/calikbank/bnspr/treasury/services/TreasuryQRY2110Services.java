package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryQRY2110Services {

	@GraymoundService("BNSPR_QRY2110_GET_HURDA")
	public static GMMap getHurda(GMMap iMap) {

		BigDecimal PTT_SUBE_ADEDI_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		Set<String> pttSet = new HashSet<String>();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2110.HurdaAltinAlimListesi(?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "HURDA_ALIS");
			index = 0;
			int size = oMap.getSize("HURDA_ALIS");

			while (index < size) {
				if (oMap.getString("HURDA_ALIS", index, "DURUM").equals("TAMAM"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("HURDA_ALIS", index, "ALTIN_FON_GRAM"));
					TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));				
				}
				else if (oMap.getString("HURDA_ALIS", index, "DURUM").equals("�PTAL"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("HURDA_ALIS", index, "ALTIN_FON_GRAM"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.subtract(new BigDecimal(1));
				}
				pttSet.add(oMap.getString("HURDA_ALIS", index, "MERKEZ_ID") + oMap.getString("HURDA_ALIS", index, "SUBE_ID"));

				index++;
			}
			oMap.put("HURDA_ALTIN_TOPLAM_GRAM", TOPLAM_GRAM_AKT.compareTo(BigDecimal.ZERO )>0 ? TOPLAM_GRAM_AKT : TOPLAM_GRAM_AKT.negate());
			oMap.put("HURDA_ALTIN_TOPLAM_ADET", TOPLAM_ADET_AKT);
			oMap.put("PTT_SUBE_ADEDI_AKT", pttSet.size());

		}
		
		catch (ParseException e) {		
			throw new GMRuntimeException(0, "Ge�ersiz Tarih");
	
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_QRY2110_GET_FIZIKI_TESLIM")
	public static GMMap get(GMMap iMap) {

		BigDecimal PTT_SUBE_ADEDI_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;
		Set<String> pttSet = new HashSet<String>();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2110.AltinSatisListesi(?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "FIZIKI_TESLIM");
			index = 0;
			int size = oMap.getSize("FIZIKI_TESLIM");

			while (index < size) {
				if (oMap.getString("FIZIKI_TESLIM", index, "DURUM").equals("TAMAM"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("FIZIKI_TESLIM", index, "ALTIN_FON_GRAM"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				}
				else if (oMap.getString("FIZIKI_TESLIM", index, "DURUM").equals("�PTAL"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("FIZIKI_TESLIM", index, "ALTIN_FON_GRAM"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.subtract(new BigDecimal(1));
				}

				pttSet.add(oMap.getString("FIZIKI_TESLIM", index, "MERKEZ_ID") + oMap.getString("FIZIKI_TESLIM", index, "SUBE_ID"));

				index++;
			}
			oMap.put("FIZIKI_ALTIN_TOPLAM_GRAM", TOPLAM_GRAM_AKT.compareTo(BigDecimal.ZERO )>0 ? TOPLAM_GRAM_AKT : TOPLAM_GRAM_AKT.negate());
			oMap.put("FIZIKI_ALTIN_TOPLAM_ADET", TOPLAM_ADET_AKT);
			oMap.put("PTT_SUBE_ADEDI_AKT", pttSet.size());
		}
		
		catch (ParseException e) {		
			throw new GMRuntimeException(0, "Ge�ersiz Tarih");
		}
		
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY2110_GET_MUSTERIYE_EVE_TESLIM")
	public static GMMap getMusteriEveTeslim(GMMap iMap) {

		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2110.FizikiTeslim(?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "EVE_TESLIM");
			index = 0;
			int size = oMap.getSize("EVE_TESLIM");

			while (index < size) {

				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("EVE_TESLIM", index, "ALTIN_FON_GRAM"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				index++;
			}
			oMap.put("EVE_FIZIKI_ALTIN_TESLIM_TOPLAM_GRAM", TOPLAM_GRAM_AKT.compareTo(BigDecimal.ZERO )>0 ? TOPLAM_GRAM_AKT : TOPLAM_GRAM_AKT.negate());
			oMap.put("EVE_FIZIKI_ALTIN_TESLIM_TOPLAM_ADET", TOPLAM_ADET_AKT);

		}
		
		catch (ParseException e) {		
			throw new GMRuntimeException(0, "Ge�ersiz Tarih");
	
		}		
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY2110_GET_EVE_TESLIM_GERI_GELENLER")
	public static GMMap getEveTeslimIade(GMMap iMap) {
		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2110.FizikiIade(?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "IADE");
			index = 0;
			int size = oMap.getSize("IADE");

			while (index < size) {

				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("IADE", index, "ALTIN_FON_GRAM"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				index++;
			}
			oMap.put("EVE_TESLIM_IADE_ALTIN_TOPLAM_GRAM", TOPLAM_GRAM_AKT.compareTo(BigDecimal.ZERO )>0 ? TOPLAM_GRAM_AKT : TOPLAM_GRAM_AKT.negate());
			oMap.put("EVE_TESLIM_IADE_ALTIN_TOPLAM_ADET", TOPLAM_ADET_AKT);

		}
		
		catch (ParseException e) {		
			throw new GMRuntimeException(0, "Ge�ersiz Tarih");
	
		}
		
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	
		
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_QRY2110_GET_TUM_MUTABAKATLAR")
	public static GMMap getTumMutabakatlar(GMMap iMap) {

		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		Set<String> pttSet = new HashSet<String>();

		try {
			int index = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2110.AltinAnaEkranSorgu(?)}");
			stmt.registerOutParameter(++index, -10);
			stmt.setDate(++index, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "MUTABAKAT");
			index = 0;
			int size = oMap.getSize("MUTABAKAT");

			while (index < size) {
				if (oMap.getString("MUTABAKAT", index, "ISLEM_TIPI").equals("Hurda Al�m") && oMap.getString("MUTABAKAT", index, "DURUM").equals("TAMAM"))
				{		TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("MUTABAKAT", index, "ALTIN_FON_GRAM"));	
				pttSet.add(oMap.getString("MUTABAKAT", index, "MERKEZ_ID") + oMap.getString("MUTABAKAT", index, "SUBE_ID"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				}
				else if (oMap.getString("MUTABAKAT", index, "ISLEM_TIPI").equals("Hurda Al�m") && oMap.getString("MUTABAKAT", index, "DURUM").equals("�PTAL"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("MUTABAKAT", index, "ALTIN_FON_GRAM"));
				pttSet.add(oMap.getString("MUTABAKAT", index, "MERKEZ_ID") + oMap.getString("MUTABAKAT", index, "SUBE_ID"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.subtract(new BigDecimal(1));
				}
				else if (oMap.getString("MUTABAKAT", index, "ISLEM_TIPI").equals("Alt�n Sat��") && oMap.getString("MUTABAKAT", index, "DURUM").equals("TAMAM"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("MUTABAKAT", index, "ALTIN_FON_GRAM"));
				pttSet.add(oMap.getString("MUTABAKAT", index, "MERKEZ_ID") + oMap.getString("MUTABAKAT", index, "SUBE_ID"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				}
				else if (oMap.getString("MUTABAKAT", index, "ISLEM_TIPI").equals("Alt�n Sat��") && oMap.getString("MUTABAKAT", index, "DURUM").equals("�PTAL"))
				{
					TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("MUTABAKAT", index, "ALTIN_FON_GRAM"));
					pttSet.add(oMap.getString("MUTABAKAT", index, "MERKEZ_ID") + oMap.getString("MUTABAKAT", index, "SUBE_ID"));
					TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.subtract(new BigDecimal(1));
				}
				else if (oMap.getString("MUTABAKAT", index, "ISLEM_TIPI").equals("Fiziki Teslim"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("MUTABAKAT", index, "ALTIN_FON_GRAM"));
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				}
				else if(oMap.getString("MUTABAKAT", index, "ISLEM_TIPI").equals("Fiziki Iade"))
				{	TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("MUTABAKAT", index, "ALTIN_FON_GRAM"));
					TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
				}

				

				index++;
			}
			oMap.put("TOPLAM_GRAM_AKT", TOPLAM_GRAM_AKT);
			oMap.put("TOPLAM_ADET_AKT", TOPLAM_ADET_AKT);
			oMap.put("TOPLAM_GRAM", TOPLAM_GRAM_AKT);
			oMap.put("TOPLAM_ADET", TOPLAM_ADET_AKT);
			oMap.put("PTT_SUBESI_ADEDI", pttSet.size());



		}
		
		
		catch (ParseException e) {		
			throw new GMRuntimeException(0, "Ge�ersiz Tarih");
	
		}	
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_QRY2110_GET_HURDA_QUERY")
	public static GMMap getHurdaQuery(GMMap iMap) {

		if (!StringUtils.isBlank(iMap.getString("BASMUDURLUK_ID")) && StringUtils.isBlank(iMap.getString("MERKEZ_ID"))) {
			throw new GMRuntimeException(0, "Merkez ismini girmelisiniz.");
		}

		GMMap oMap = new GMMap();
		int size = iMap.getSize("TABLE_HURDA");
		int row = 0;
		int oMapRow = 0;
		int columnIndex = 0;
		int columnSize = iMap.getSize("COLUMN_LIST");
		
		String pttMerkezTable = "";
		String pttMerkezSubeTable = "";
		String pttMerkez = iMap.getString("MERKEZ_ID");
		String pttMerkezSube = iMap.getString("MERKEZ_ID") + iMap.getString("SUBE_ID");

		while (row < size) {

			pttMerkezSubeTable = (iMap.getString("TABLE_HURDA", row, "MERKEZ_ID")==null?"":iMap.getString("TABLE_HURDA", row, "MERKEZ_ID")) + (iMap.getString("TABLE_HURDA", row, "SUBE_ID")==null?"":iMap.getString("TABLE_HURDA", row, "SUBE_ID"));
			pttMerkezTable =  iMap.getString("TABLE_HURDA", row, "MERKEZ_ID")==null?"" :iMap.getString("TABLE_HURDA", row, "MERKEZ_ID");
           
			if(StringUtils.isBlank(iMap.getString("DURUM")) || iMap.getString("TABLE_HURDA", row, "DURUM").equals(iMap.getString("DURUM")))
			{
			
				if(  pttMerkezTable.equals(pttMerkez) && StringUtils.isBlank(iMap.getString("SUBE_ID"))  || pttMerkezSubeTable.equals(pttMerkezSube) || StringUtils.isBlank(pttMerkezSube))
 {
				while (columnIndex < columnSize) {
					oMap.put("TABLE", oMapRow, iMap.getString("COLUMN_LIST", columnIndex, "NAME"), iMap.getString("TABLE_HURDA", row, iMap.getString("COLUMN_LIST", columnIndex, "NAME")));
					columnIndex++;
				}
				columnIndex = 0;
				oMapRow++;
			}
			}

			row++;
		}

		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;

		int index = 0;
		size = oMap.getSize("TABLE");
		while (index < size) {
			if (oMap.getString("TABLE", index, "DURUM").equals("TAMAM"))
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			else if (oMap.getString("TABLE", index, "DURUM").equals("�PTAL"))
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));

			index++;
		}
		oMap.put("TOPLAM_GRAM_AKT", TOPLAM_GRAM_AKT);
		oMap.put("TOPLAM_ADET_AKT", TOPLAM_ADET_AKT);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY2110_GET_FIZIKI_TESLIM_QUERY")
	public static GMMap getFizikiTeslimQuery(GMMap iMap) {

		if (!StringUtils.isBlank(iMap.getString("BASMUDURLUK_ID")) && StringUtils.isBlank(iMap.getString("MERKEZ_ID"))) {
			throw new GMRuntimeException(0, "Merkez ismini girmelisiniz.");
		}

		GMMap oMap = new GMMap();
		int size = iMap.getSize("TABLE_FIZIKI");
		int row = 0;
		int oMapRow = 0;
		int columnIndex = 0;
		int columnSize = iMap.getSize("COLUMN_LIST");
		String pttMerkezTable = "";
		String pttMerkezSubeTable = "";
		String pttMerkez = iMap.getString("MERKEZ_ID");
		String pttMerkezSube = iMap.getString("MERKEZ_ID") + iMap.getString("SUBE_ID");

		while (row < size) {
		
			if(StringUtils.isBlank(iMap.getString("DURUM")) || iMap.getString("TABLE_FIZIKI", row, "DURUM").equals(iMap.getString("DURUM")))
			{
			
				pttMerkezSubeTable = (iMap.getString("TABLE_FIZIKI", row, "MERKEZ_ID")==null?"":iMap.getString("TABLE_FIZIKI", row, "MERKEZ_ID")) + (iMap.getString("TABLE_FIZIKI", row, "SUBE_ID")==null?"":iMap.getString("TABLE_FIZIKI", row, "SUBE_ID"));
				pttMerkezTable =  iMap.getString("TABLE_FIZIKI", row, "MERKEZ_ID")==null?"" :iMap.getString("TABLE_FIZIKI", row, "MERKEZ_ID");
				
				if(  pttMerkezTable.equals(pttMerkez) && StringUtils.isBlank(iMap.getString("SUBE_ID"))  || pttMerkezSubeTable.equals(pttMerkezSube) || StringUtils.isBlank(pttMerkezSube))
 {
				while (columnIndex < columnSize) {
					oMap.put("TABLE", oMapRow, iMap.getString("COLUMN_LIST", columnIndex, "NAME"), iMap.getString("TABLE_FIZIKI", row, iMap.getString("COLUMN_LIST", columnIndex, "NAME")));
					columnIndex++;
				}
				columnIndex = 0;
				oMapRow++;

			}
			}
			row++;
		}

		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;

		int index = 0;
		size = oMap.getSize("TABLE");
		while (index < size) {
			if (oMap.getString("TABLE", index, "DURUM").equals("TAMAM"))
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			else if (oMap.getString("TABLE", index, "DURUM").equals("�PTAL"))
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));

			index++;
		}
		oMap.put("TOPLAM_GRAM_AKT", TOPLAM_GRAM_AKT);
		oMap.put("TOPLAM_ADET_AKT", TOPLAM_ADET_AKT);

		return oMap;

	}

	@GraymoundService("BNSPR_QRY2110_GET_MUSTERIYE_EVE_TESLIM_QUERY")
	public static GMMap getEveTeslimQuery(GMMap iMap) {

		return iMap;
	}

	@GraymoundService("BNSPR_QRY2110_GET_EVE_TESLIM_GERI_QUERY")
	public static GMMap getEveTeslimIadeQuery(GMMap iMap) {

		return iMap;
	}

	@GraymoundService("BNSPR_QRY2110_GET_MUTABAKAT_QUERY")
	public static GMMap getTumMutabakatlarQuery(GMMap iMap) {
      

		if (!StringUtils.isBlank(iMap.getString("BASMUDURLUK_ID")) && StringUtils.isBlank(iMap.getString("MERKEZ_ID"))) {
			throw new GMRuntimeException(0, "Merkez ismini girmelisiniz.");
		}
		
		
		
		GMMap oMap = new GMMap();
		int size = iMap.getSize("TABLE_MUTABAKAT");
		int row = 0;
		int oMapRow = 0;
		int columnIndex = 0;
		int columnSize = iMap.getSize("COLUMN_LIST");
		String pttMerkezTable = "";
		String pttMerkezSubeTable = "";
		String pttMerkezSube = iMap.getString("MERKEZ_ID") + iMap.getString("SUBE_ID");
		String pttMerkez = iMap.getString("MERKEZ_ID");
		

		while (row < size) {
          
			if(iMap.getString("TABLE_MUTABAKAT", row, "KANAL_KOD").equals("7") && iMap.getString("KANAL").equals("7") || StringUtils.isBlank(iMap.getString("KANAL")))
			{

			if(StringUtils.isBlank(iMap.getString("DURUM")) || iMap.getString("TABLE_MUTABAKAT", row, "DURUM").equals(iMap.getString("DURUM")))
	
			{		
				pttMerkezSubeTable = (iMap.getString("TABLE_MUTABAKAT",row,"MERKEZ_ID")==null ?"":iMap.getString("TABLE_MUTABAKAT",row,"MERKEZ_ID")) + (iMap.getString("TABLE_MUTABAKAT",row,"SUBE_ID")==null ?"":iMap.getString("TABLE_MUTABAKAT",row,"SUBE_ID"));
				pttMerkezTable = iMap.getString("TABLE_MUTABAKAT",row,"MERKEZ_ID") ==null ? "" : iMap.getString("TABLE_MUTABAKAT",row,"MERKEZ_ID") ;
				
				if(  pttMerkezTable.equals(pttMerkez) && StringUtils.isBlank(iMap.getString("SUBE_ID"))  || pttMerkezSubeTable.equals(pttMerkezSube) || StringUtils.isBlank(pttMerkezSube))
				{
				while (columnIndex < columnSize) {
	oMap.put("TABLE", oMapRow, iMap.getString("COLUMN_LIST", columnIndex, "NAME"), iMap.getString("TABLE_MUTABAKAT", row, iMap.getString("COLUMN_LIST", columnIndex, "NAME")));
					columnIndex++;	
				}
				columnIndex=0;
				oMapRow++;
			}
			}
			
				
				
			}
				
				else if(iMap.getString("TABLE_MUTABAKAT", row, "KANAL_KOD").equals("4") && iMap.getString("KANAL").equals("4"))
				{
					
					while (columnIndex < columnSize) {
	oMap.put("TABLE", oMapRow, iMap.getString("COLUMN_LIST", columnIndex, "NAME"), iMap.getString("TABLE_MUTABAKAT", row, iMap.getString("COLUMN_LIST", columnIndex, "NAME")));
						columnIndex++;	
					}
					columnIndex=0;		

			oMapRow++;
		}
			row++;

		}

		BigDecimal TOPLAM_GRAM_AKT = BigDecimal.ZERO;
		BigDecimal TOPLAM_ADET_AKT = BigDecimal.ZERO;

		int index = 0;
		size = oMap.getSize("TABLE");
		
		while (index < size) {
		
			if(oMap.getString("TABLE", index, "KANAL_KOD").equals("7"))
			{
			if (oMap.getString("TABLE", index, "DURUM").equals("TAMAM") && oMap.getString("TABLE", index, "ISLEM_TIPI").equals("Hurda Al�m")  )
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			else if (oMap.getString("TABLE", index, "DURUM").equals("�PTAL") && oMap.getString("TABLE", index, "ISLEM_TIPI").equals("Hurda Al�m") )
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			if (oMap.getString("TABLE", index, "DURUM").equals("TAMAM") && oMap.getString("TABLE", index, "ISLEM_TIPI").equals("Alt�n Sat��")  )
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			else if (oMap.getString("TABLE", index, "DURUM").equals("�PTAL") && oMap.getString("TABLE", index, "ISLEM_TIPI").equals("Alt�n Sat��")  )
				TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			
			TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));
			}
			
			else if (oMap.getString("TABLE", index, "KANAL_KOD").equals("4"))
			{
				if (oMap.getString("TABLE", index, "ISLEM_TIPI").equals("Fiziki Iade")  )
					TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.add(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
				else if (oMap.getString("TABLE", index, "ISLEM_TIPI").equals("Fiziki Teslim") )
					TOPLAM_GRAM_AKT = TOPLAM_GRAM_AKT.subtract(oMap.getBigDecimal("TABLE", index, "ALTIN_FON_GRAM"));
			
				TOPLAM_ADET_AKT = TOPLAM_ADET_AKT.add(new BigDecimal(1));

			}
			index++;
		}
		oMap.put("TOPLAM_GRAM", TOPLAM_GRAM_AKT);
		oMap.put("TOPLAM_ADET", TOPLAM_ADET_AKT);

		return oMap;
		
	}

	@GraymoundService("BNSPR_QRY2110_GET_COMBO")
	public static GMMap getComboQuery(GMMap iMap) {

		GMMap oMap = new GMMap();

		GuimlUtil.wrapMyCombo(oMap, "DURUM", null, "Se�iniz");
		GuimlUtil.wrapMyCombo(oMap, "DURUM", "TAMAM", "Tamam");
		GuimlUtil.wrapMyCombo(oMap, "DURUM", "�PTAL", "�ptal");

		return oMap;
	}

}
