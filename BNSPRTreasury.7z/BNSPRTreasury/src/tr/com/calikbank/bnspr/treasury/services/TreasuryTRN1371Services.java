package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznAtsTransferTx;
import tr.com.aktifbank.bnspr.dao.HznAtsUyeBankaPr;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.services.TreasuryTRN1370Services.AktifbankDurum;
import tr.com.calikbank.bnspr.treasury.services.TreasuryTRN1370Services.IbanBeyan;
import tr.com.calikbank.bnspr.treasury.services.TreasuryTRN1370Services.IslemTipi;
import tr.com.calikbank.bnspr.treasury.services.TreasuryTRN1370Services.TakasbankIslemDurum;
import tr.com.calikbank.bnspr.treasury.services.TreasuryTRN1370Services.TakasbankTransferYon;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1371Services {
    private static final Logger logger = Logger.getLogger(TreasuryTRN1371Services.class);
    private static final SimpleDateFormat SDF_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	
	@GraymoundService("BNSPR_TRN1371_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		String listName2 = "IADE_KODU";
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.ALICI_BANKA_ISLEM_LIMITI_DISINDA.getCode(), IadeKodu.ALICI_BANKA_ISLEM_LIMITI_DISINDA.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.ALICI_HESAP_HATALI.getCode(), 				IadeKodu.ALICI_HESAP_HATALI.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.ALICI_TCKN_VKN_UYUMSUZ.getCode(), 			IadeKodu.ALICI_TCKN_VKN_UYUMSUZ.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.DIGER.getCode(), 							IadeKodu.DIGER.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.GONDEREN_BILGILERI_EKSIK_HATALI.getCode(), 	IadeKodu.GONDEREN_BILGILERI_EKSIK_HATALI.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.HESAP_KAPALI.getCode(), 					IadeKodu.HESAP_KAPALI.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.HESAP_TRANSFERE_UYGUN_DEGIL.getCode(), 		IadeKodu.HESAP_TRANSFERE_UYGUN_DEGIL.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.HESAP_VE_ALICIAD_UYUMSUZ.getCode(), 		IadeKodu.HESAP_VE_ALICIAD_UYUMSUZ.getDescription());
		GuimlUtil.wrapMyCombo(oMap, listName2, IadeKodu.HESAP_VEYA_IBAN_YANLIS.getCode(), 			IadeKodu.HESAP_VEYA_IBAN_YANLIS.getDescription());
		return oMap;
	}
		
	@GraymoundService("BNSPR_TRN1371_ATS_TRANSFER_TALIMAT_SORGULA_EKLE")
	public static GMMap atsTransferTalimatSorgulaEkle(GMMap iMap) {
		boolean yeniTalimatVar = false;
		int yeniTalimatSayisi = 0;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
		    String today = SDF_YYYYMMDD.format(new Date());
		    String ucAyOnce = SDF_YYYYMMDD.format(DateUtils.addDays(new Date(), -90));
		    
			iMap.put("WS_NO", trxNo);
			logger.info(String.format("%s transaction numarasi ile %s - %s tarih aral���nda gelen talimatlar sorgulaniyor..", trxNo, ucAyOnce, today));
			iMap.put("ISLEM_DURUM", TakasbankIslemDurum.ISLEM_TAMAMLANDI.getValue());
			iMap.put("TARIH_ILK", ucAyOnce);
			iMap.put("TARIH_SON", today);
			iMap.put("YON", TakasbankTransferYon.GIRIS.getValue());
			
			oMap = GMServiceExecuter.call("BNSPR_EXT_ATS_TRANSFER_LISTELE", iMap);
			if(!oMap.containsKey("HATA_KODU")){
				@SuppressWarnings("unchecked")
				List<HashMap<String, Object>> transferList = (List<HashMap<String, Object>>) oMap.get("TRANSFER_LISTELE_CEVAP");
				int transferListSize = transferList.size();
				logger.info(String.format("%s adet gelen transfer talimati var..", transferListSize));
				if(transferListSize>0){
					for (int i = 0; i < transferListSize; i++) {												
						HashMap<String, Object> gelenTransferMap = transferList.get(i);
						BigDecimal talimatNo = new BigDecimal((String)gelenTransferMap.get("TALIMAT_NO"));
						String iadeDurum = (String) gelenTransferMap.get("IADE_DURUM");
						if("E".equals(iadeDurum)){
							logger.info(String.format("%s talimat numarasi daha once iade edilmis. Listeye dahil edilmiyor.", talimatNo));
							continue;
						}
						if(isYeniGelenTalimat(talimatNo, IslemTipi.GELEN.getValue())){
							yeniTalimatVar = true;
							yeniTalimatSayisi++;
							logger.info(String.format("%s talimat numarasi yeni. HznAtsTransferTx tablosunda kayit yaratiliyor..", talimatNo));
							HznAtsTransferTx hznAtsTransferTx = new HznAtsTransferTx();
							//ALICI BILGILERI
							String girisIbanBeyan = (String) gelenTransferMap.get("GIRIS_IBAN_BEYAN");
							hznAtsTransferTx.setAliciIbanBeyanEh(girisIbanBeyan);
							if(IbanBeyan.EVET.getValue().equals(girisIbanBeyan)){
								hznAtsTransferTx.setAliciIban((String) gelenTransferMap.get("GIRIS_MUS_HESAP"));
							}else{
								hznAtsTransferTx.setAliciHesapNo((String) gelenTransferMap.get("GIRIS_MUS_HESAP"));
							}
							hznAtsTransferTx.setAliciSubeKodu((String) gelenTransferMap.get("GIRIS_SUBE_KODU"));
							hznAtsTransferTx.setAliciKimlikNo((String) gelenTransferMap.get("GIRIS_KIMLIK_NO"));
							hznAtsTransferTx.setAliciKimlikTip((String) gelenTransferMap.get("GIRIS_ID_TIP"));
							hznAtsTransferTx.setAliciMusteriAdi((String) gelenTransferMap.get("GIRIS_MUSTERI_ADI"));
							String girisMusteriNo = (String) gelenTransferMap.get("GIRIS_MUSTERI_NO");
							if(StringUtils.isNotBlank(girisMusteriNo)){
								hznAtsTransferTx.setAliciMusteriNo(new BigDecimal(girisMusteriNo));
							}
							hznAtsTransferTx.setAliciUyeKod((String) gelenTransferMap.get("GIRIS_UYE_KOD"));
							HznAtsUyeBankaPr atsUyeBankaPrAlici = (HznAtsUyeBankaPr) GMServiceExecuter.call("BNSPR_HZN_ATS_GET_ATS_UYE_BANKA_PR", new GMMap()
																	.put("UYE_KOD",(String) gelenTransferMap.get("GIRIS_UYE_KOD")))
																	.get("ATS_UYE_BANKA_PR");
							hznAtsTransferTx.setAliciUyeAdi(atsUyeBankaPrAlici.getUnvan());

							hznAtsTransferTx.setAyar((String) gelenTransferMap.get("AYAR"));
							hznAtsTransferTx.setDurum(AktifbankDurum.GELEN_TALIMAT_GIRIS.getValue());
							hznAtsTransferTx.setGelenGiden("GELEN");
							hznAtsTransferTx.setGelenIslemZamani((String) gelenTransferMap.get("GIRIS_TARIH"));
							
							//GONDEREN BILGILERI
							String cikisIbanBeyan = (String) gelenTransferMap.get("CIKIS_IBAN_BEYAN");
							hznAtsTransferTx.setGonIbanBeyanEh(cikisIbanBeyan);
							if(IbanBeyan.EVET.getValue().equals(cikisIbanBeyan)){
								hznAtsTransferTx.setGonIban((String) gelenTransferMap.get("CIKIS_MUS_HESAP"));
							}else{
								hznAtsTransferTx.setGonHesapNo((String) gelenTransferMap.get("CIKIS_MUS_HESAP"));
							}
							hznAtsTransferTx.setGonSubeKodu((String) gelenTransferMap.get("CIKIS_SUBE_KODU"));
							hznAtsTransferTx.setGonKimlikNo((String) gelenTransferMap.get("CIKIS_KIMLIK_NO"));
							hznAtsTransferTx.setGonKimlikTip((String) gelenTransferMap.get("CIKIS_ID_TIP"));
							hznAtsTransferTx.setGonMusteriAdi((String) gelenTransferMap.get("CIKIS_MUSTERI_ADI"));
							String cikisMusteriNo = (String) gelenTransferMap.get("CIKIS_MUSTERI_NO");
							if(StringUtils.isNotBlank(cikisMusteriNo)){
								hznAtsTransferTx.setGonMusteriNo(new BigDecimal(cikisMusteriNo));
							}
							hznAtsTransferTx.setGonUyeKod((String) gelenTransferMap.get("CIKIS_UYE_KOD"));
							HznAtsUyeBankaPr atsUyeBankaPrGon = (HznAtsUyeBankaPr) GMServiceExecuter.call("BNSPR_HZN_ATS_GET_ATS_UYE_BANKA_PR", new GMMap()
																		.put("UYE_KOD",(String) gelenTransferMap.get("CIKIS_UYE_KOD")))
																		.get("ATS_UYE_BANKA_PR");
							hznAtsTransferTx.setGonUyeAdi(atsUyeBankaPrGon.getUnvan());
							
							//DIGER ALANLAR
							hznAtsTransferTx.setAciklama((String) gelenTransferMap.get("ACIKLAMA"));
							hznAtsTransferTx.setMiktar(new BigDecimal((String)gelenTransferMap.get("MIKTAR")));
							hznAtsTransferTx.setTakasbankTalimatNo(new BigDecimal((String)gelenTransferMap.get("TALIMAT_NO")));
							hznAtsTransferTx.setValorTarihi(SDF_YYYYMMDD.parse((String)gelenTransferMap.get("VALOR_TARIHI")));						
							hznAtsTransferTx.setTakasbankDurum((String) gelenTransferMap.get("DURUM_KOD"));
							hznAtsTransferTx.setTakasbankAciklama((String) gelenTransferMap.get("DURUM"));
							hznAtsTransferTx.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
							session.save(hznAtsTransferTx);
							session.flush();
						}else{
							logger.info(String.format("%s talimat numarasi daha once sorgulandigi icin islem yapilmiyor..", talimatNo));
						}
					}
				}
				if(yeniTalimatVar){
					oMap.put("MESSAGE", String.format("%s adet yeni talimat eklendi.", yeniTalimatSayisi));
				}else{
					oMap.put("MESSAGE", "Takasbank'tan gelen yeni bir talimat yok.");				
				}
			}else{
				oMap.put("MESSAGE", "Takasbank hata: "+oMap.getString("HATA_KODU")+" - "+ oMap.getString("ACIKLAMA"));				
			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1371_ATS_GELEN_IADE_SORGULA_EKLE")
	public static GMMap atsGelenIadeSorgulaEkle(GMMap iMap) {
		boolean yeniIadeVar = false;
		int yeniIadeSayisi = 0;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
		    String today = SDF_YYYYMMDD.format(new Date());
		    String birAyOnce = SDF_YYYYMMDD.format(DateUtils.addDays(new Date(), -30));
		    
			iMap.put("WS_NO", trxNo);
			logger.info(String.format("%s transaction numarasi ile %s - %s tarih aral���nda gelen iadeler sorgulaniyor..", trxNo, birAyOnce, today));
			iMap.put("ISLEM_DURUM", TakasbankIslemDurum.ISLEM_TAMAMLANDI.getValue());
			iMap.put("TARIH_ILK", birAyOnce);
			iMap.put("TARIH_SON", today);
			iMap.put("YON", TakasbankTransferYon.CIKIS.getValue());
			
			oMap = GMServiceExecuter.call("BNSPR_EXT_ATS_TRANSFER_LISTELE", iMap);
			if(!oMap.containsKey("HATA_KODU")){
				@SuppressWarnings("unchecked")
				List<HashMap<String, Object>> transferList = (List<HashMap<String, Object>>) oMap.get("TRANSFER_LISTELE_CEVAP");
				int transferListSize = transferList.size();
				logger.info(String.format("%s adet gelen transfer talimati var..", transferListSize));
				if(transferListSize>0){
					for (int i = 0; i < transferListSize; i++) {												
						HashMap<String, Object> gelenTransferMap = transferList.get(i);
						BigDecimal talimatNo = new BigDecimal((String)gelenTransferMap.get("TALIMAT_NO"));
						String iadeDurum = (String) gelenTransferMap.get("IADE_DURUM");
						if(!"E".equals(iadeDurum)){
							logger.info(String.format("%s talimat numarasi gelen iade degil. Listeye dahil edilmiyor.", talimatNo));
							continue;
						}
						if(isYeniGelenTalimat(talimatNo, IslemTipi.GELEN_IADE.getValue())){
							yeniIadeVar = true;
							yeniIadeSayisi++;
							logger.info(String.format("%s talimat numarasi yeni bir iade. HznAtsTransferTx tablosunda kayit yaratiliyor..", talimatNo));
							HznAtsTransferTx hznAtsTransferTx = new HznAtsTransferTx();
							//ALICI BILGILERI
							String girisIbanBeyan = (String) gelenTransferMap.get("GIRIS_IBAN_BEYAN");
							hznAtsTransferTx.setAliciIbanBeyanEh(girisIbanBeyan);
							if(IbanBeyan.EVET.getValue().equals(girisIbanBeyan)){
								hznAtsTransferTx.setAliciIban((String) gelenTransferMap.get("GIRIS_MUS_HESAP"));
							}else{
								hznAtsTransferTx.setAliciHesapNo((String) gelenTransferMap.get("GIRIS_MUS_HESAP"));
							}
							hznAtsTransferTx.setAliciSubeKodu((String) gelenTransferMap.get("GIRIS_SUBE_KODU"));
							hznAtsTransferTx.setAliciKimlikNo((String) gelenTransferMap.get("GIRIS_KIMLIK_NO"));
							hznAtsTransferTx.setAliciKimlikTip((String) gelenTransferMap.get("GIRIS_ID_TIP"));
							hznAtsTransferTx.setAliciMusteriAdi((String) gelenTransferMap.get("GIRIS_MUSTERI_ADI"));
							String girisMusteriNo = (String) gelenTransferMap.get("GIRIS_MUSTERI_NO");
							if(StringUtils.isNotBlank(girisMusteriNo)){
								hznAtsTransferTx.setAliciMusteriNo(new BigDecimal(girisMusteriNo));
							}
							hznAtsTransferTx.setAliciUyeKod((String) gelenTransferMap.get("GIRIS_UYE_KOD"));
							HznAtsUyeBankaPr atsUyeBankaPrAlici = (HznAtsUyeBankaPr) GMServiceExecuter.call("BNSPR_HZN_ATS_GET_ATS_UYE_BANKA_PR", new GMMap()
																	.put("UYE_KOD",(String) gelenTransferMap.get("GIRIS_UYE_KOD")))
																	.get("ATS_UYE_BANKA_PR");
							hznAtsTransferTx.setAliciUyeAdi(atsUyeBankaPrAlici.getUnvan());

							hznAtsTransferTx.setAyar((String) gelenTransferMap.get("AYAR"));
							hznAtsTransferTx.setDurum(AktifbankDurum.GELEN_IADE_GIRIS.getValue());
							hznAtsTransferTx.setGelenGiden(IslemTipi.GELEN_IADE.getValue());
							hznAtsTransferTx.setGelenIslemZamani((String) gelenTransferMap.get("GIRIS_TARIH"));
							
							//GONDEREN BILGILERI
							String cikisIbanBeyan = (String) gelenTransferMap.get("CIKIS_IBAN_BEYAN");
							hznAtsTransferTx.setGonIbanBeyanEh(cikisIbanBeyan);
							if(IbanBeyan.EVET.getValue().equals(cikisIbanBeyan)){
								hznAtsTransferTx.setGonIban((String) gelenTransferMap.get("CIKIS_MUS_HESAP"));
							}else{
								hznAtsTransferTx.setGonHesapNo((String) gelenTransferMap.get("CIKIS_MUS_HESAP"));
							}
							hznAtsTransferTx.setGonSubeKodu((String) gelenTransferMap.get("CIKIS_SUBE_KODU"));
							hznAtsTransferTx.setGonKimlikNo((String) gelenTransferMap.get("CIKIS_KIMLIK_NO"));
							hznAtsTransferTx.setGonKimlikTip((String) gelenTransferMap.get("CIKIS_ID_TIP"));
							hznAtsTransferTx.setGonMusteriAdi((String) gelenTransferMap.get("CIKIS_MUSTERI_ADI"));
							String cikisMusteriNo = (String) gelenTransferMap.get("CIKIS_MUSTERI_NO");
							if(StringUtils.isNotBlank(cikisMusteriNo)){
								hznAtsTransferTx.setGonMusteriNo(new BigDecimal(cikisMusteriNo));
							}
							hznAtsTransferTx.setGonUyeKod((String) gelenTransferMap.get("CIKIS_UYE_KOD"));
							HznAtsUyeBankaPr atsUyeBankaPrGon = (HznAtsUyeBankaPr) GMServiceExecuter.call("BNSPR_HZN_ATS_GET_ATS_UYE_BANKA_PR", new GMMap()
																		.put("UYE_KOD",(String) gelenTransferMap.get("CIKIS_UYE_KOD")))
																		.get("ATS_UYE_BANKA_PR");
							hznAtsTransferTx.setGonUyeAdi(atsUyeBankaPrGon.getUnvan());
							
							//DIGER ALANLAR
							hznAtsTransferTx.setAciklama((String) gelenTransferMap.get("ACIKLAMA"));
							hznAtsTransferTx.setMiktar(new BigDecimal((String)gelenTransferMap.get("MIKTAR")));
							hznAtsTransferTx.setTakasbankTalimatNo(new BigDecimal((String)gelenTransferMap.get("TALIMAT_NO")));
							hznAtsTransferTx.setValorTarihi(SDF_YYYYMMDD.parse((String)gelenTransferMap.get("VALOR_TARIHI")));						
							hznAtsTransferTx.setTakasbankDurum((String) gelenTransferMap.get("DURUM_KOD"));
							hznAtsTransferTx.setTakasbankAciklama((String) gelenTransferMap.get("DURUM"));
							hznAtsTransferTx.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
							hznAtsTransferTx.setGelenIadeIlkTxNo(new BigDecimal((String)gelenTransferMap.get("UYE_WS_REF_NO")));
							hznAtsTransferTx.setIadeKodu((String)gelenTransferMap.get("IADE_NEDEN_KOD"));
							session.save(hznAtsTransferTx);
							session.flush();
						}else{
							logger.info(String.format("%s talimat numarasi daha once sorgulandigi icin islem yapilmiyor..", talimatNo));
						}
					}
				}
				if(yeniIadeVar){
					oMap.put("MESSAGE", String.format("%s adet iade talimati tabloya eklendi.", yeniIadeSayisi));
				}else{
					oMap.put("MESSAGE", "Takasbank'tan gelen yeni bir iade talimati yok.");				
				}
			}else{
				oMap.put("MESSAGE", "Takasbank hata: "+oMap.getString("HATA_KODU")+" - "+ oMap.getString("ACIKLAMA"));				
			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1371_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {			
			String tableName = "TBL_TALIMAT";
			Session session = DAOSession.getSession("BNSPRDal");
			String islemTipi = iMap.getString("ISLEM_TIPI");
			if(StringUtils.isBlank(islemTipi)){
				islemTipi = IslemTipi.GELEN.getValue();
			}
			String durum = null;
			if(islemTipi.equals(IslemTipi.GELEN.getValue())){
				durum = AktifbankDurum.GELEN_TALIMAT_GIRIS.getValue();
			}else if(islemTipi.equals(IslemTipi.GELEN_IADE.getValue())){
				durum = AktifbankDurum.GELEN_IADE_GIRIS.getValue();
			}
			
		    Criteria criteria = session.createCriteria(HznAtsTransferTx.class)
		    										.add(Restrictions.eq("gelenGiden", islemTipi))
		    										.add(Restrictions.eq("durum", durum));
			@SuppressWarnings("unchecked")
			List<HznAtsTransferTx> transferList = (List<HznAtsTransferTx>) criteria.list();
			for (int i = 0; i < transferList.size(); i++) {
				HznAtsTransferTx hznAtsTransferTx = transferList.get(i);
				oMap.put(tableName, i, "TRX_NO", hznAtsTransferTx.getTxNo());
				oMap.put(tableName, i, "ISLEM_TIPI", hznAtsTransferTx.getGelenGiden());
				oMap.put(tableName, i, "GON_BANKA", String.format("%s - %s", hznAtsTransferTx.getGonUyeKod(), hznAtsTransferTx.getGonUyeAdi()));
				oMap.put(tableName, i, "GON_MUSTERI_NO", hznAtsTransferTx.getGonMusteriNo());
				oMap.put(tableName, i, "GON_MUSTERI_ADI", hznAtsTransferTx.getGonMusteriAdi());
				oMap.put(tableName, i, "ALICI_BANKA", String.format("%s - %s", hznAtsTransferTx.getAliciUyeKod(), hznAtsTransferTx.getAliciUyeAdi()));
				oMap.put(tableName, i, "ALICI_MUSTERI_ADI", hznAtsTransferTx.getAliciMusteriAdi());
				oMap.put(tableName, i, "ALICI_MUSTERI_ADI", hznAtsTransferTx.getAliciMusteriAdi());
				oMap.put(tableName, i, "MIKTAR", hznAtsTransferTx.getMiktar());				
				oMap.put(tableName, i, "VALOR_TARIHI", hznAtsTransferTx.getValorTarihi());
				oMap.put(tableName, i, "DURUM", hznAtsTransferTx.getDurum());			
				oMap.put(tableName, i, "ACIKLAMA", hznAtsTransferTx.getAciklama());
				
				oMap.put(tableName, i, "GON_IBAN_BEYAN", hznAtsTransferTx.getGonIbanBeyanEh());
				oMap.put(tableName, i, "GON_IBAN", hznAtsTransferTx.getGonIban());
				oMap.put(tableName, i, "GON_SUBE_KODU", hznAtsTransferTx.getGonSubeKodu());
				oMap.put(tableName, i, "GON_HESAP_NO", hznAtsTransferTx.getGonHesapNo());
				oMap.put(tableName, i, "GON_KIMLIK_TIP", hznAtsTransferTx.getGonKimlikTip());
				oMap.put(tableName, i, "GON_KIMLIK_NO", hznAtsTransferTx.getGonKimlikNo());			

				oMap.put(tableName, i, "ALICI_MUSTERI_NO", hznAtsTransferTx.getAliciMusteriNo());
				oMap.put(tableName, i, "ALICI_IBAN", hznAtsTransferTx.getAliciIban());
				oMap.put(tableName, i, "ALICI_IBAN_BEYAN", hznAtsTransferTx.getAliciIbanBeyanEh());
				oMap.put(tableName, i, "ALICI_SUBE_KODU", hznAtsTransferTx.getAliciSubeKodu());
				oMap.put(tableName, i, "ALICI_HESAP_NO", hznAtsTransferTx.getAliciHesapNo());
				oMap.put(tableName, i, "ALICI_KIMLIK_TIP", hznAtsTransferTx.getAliciKimlikTip());
				oMap.put(tableName, i, "ALICI_KIMLIK_NO", hznAtsTransferTx.getAliciKimlikNo());
				
				oMap.put(tableName, i, "TAKASBANK_TALIMAT_NO", hznAtsTransferTx.getTakasbankTalimatNo());
				oMap.put(tableName, i, "TAKASBANK_ACIKLAMA", hznAtsTransferTx.getTakasbankAciklama());
				oMap.put(tableName, i, "TAKASBANK_DURUM", hznAtsTransferTx.getTakasbankDurum());
			}			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1371_ONAY")
	public static GMMap onay(GMMap iMap) {
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAtsTransferTx atsTransferTx = (HznAtsTransferTx) session.createCriteria(HznAtsTransferTx.class)
													.add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if(atsTransferTx.getGelenGiden().equals(IslemTipi.GELEN.getValue())){
				atsTransferTx.setDurum(AktifbankDurum.GELEN_TALIMAT_ONAYLANDI.getValue());				
			}else if(atsTransferTx.getGelenGiden().equals(IslemTipi.GELEN_IADE.getValue())){
				atsTransferTx.setDurum(AktifbankDurum.GELEN_IADE_ONAYLANDI.getValue());								
			}
			session.saveOrUpdate(atsTransferTx);
			session.flush();
			iMap.put("TRX_NAME", "1370");			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1371_IADE")
	public static GMMap iade(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String iadeKodu = iMap.getString("IADE_KODU");
			String iadeAciklama = iMap.getString("IADE_ACIKLAMA");
			String takasBankTalimatNo = iMap.getString("TAKASBANK_TALIMAT_NO");
			
			GMMap iadeMap = new GMMap();
			iadeMap.put("WS_NO", trxNo);
			iadeMap.put("IADE_KODU", iadeKodu);
			iadeMap.put("ACIKLAMA", iadeAciklama);
			iadeMap.put("ILGILI_TALIMAT_NO", takasBankTalimatNo);
			oMap = GMServiceExecuter.call("BNSPR_EXT_ATS_MUSTERI_IADE_TRANSFER", iadeMap);
			if(!oMap.containsKey("HATA_KODU")){
				Session session = DAOSession.getSession("BNSPRDal");
				HznAtsTransferTx atsTransferTx = (HznAtsTransferTx) session.createCriteria(HznAtsTransferTx.class)
														.add(Restrictions.eq("txNo" , trxNo)).uniqueResult();
				atsTransferTx.setDurum(AktifbankDurum.GELEN_TALIMAT_IADE.getValue());
				atsTransferTx.setIadeKodu(iadeKodu);
				atsTransferTx.setIadeAciklama(iadeAciklama);
				atsTransferTx.setTakasbankAciklama(oMap.getString("ACIKLAMA"));
				atsTransferTx.setTakasbankDurum(oMap.getString("DURUM"));
				session.saveOrUpdate(atsTransferTx);
				session.flush();	
				oMap.put("MESSAGE", String.format("%s nolu talimat i�in Takasbank Alt�n Transfer Sisteminde iade iste�i olu�turuldu.", takasBankTalimatNo));
			}else{
				String hataKodu = oMap.getString("HATA_KODU");
				String aciklama = oMap.getString("ACIKLAMA");
				throw new GMRuntimeException(0, String.format("%s nolu talimat iade islemi sirasinda hata aldi: Hata Kodu: %s | A��klama: %s", takasBankTalimatNo, hataKodu, aciklama));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	private static boolean isYeniGelenTalimat(BigDecimal talimatNo, String gelenGidenIade) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<HznAtsTransferTx> hznAtsTransferTxList = session.createCriteria(HznAtsTransferTx.class)
														.add(Restrictions.eq("takasbankTalimatNo" , talimatNo))
														.add(Restrictions.eq("gelenGiden" , gelenGidenIade))
														.list();
		    
			if(hznAtsTransferTxList.isEmpty()){
				return true;
			}else{
				return false;
			}		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	protected enum IadeKodu {
		ALICI_HESAP_HATALI("01","Al�c� Hesap Numaras� Hatal�"),
		HESAP_VE_ALICIAD_UYUMSUZ("02","Hesap numaras� ile al�c� ismi uyumsuz"),
		HESAP_KAPALI("03","Hesap kapat�lm��"),
		HESAP_VEYA_IBAN_YANLIS("04","Hesap numaras� veya IBAN yanl��"),
		HESAP_TRANSFERE_UYGUN_DEGIL("05","Hesap transfere uygun de�il"),
		ALICI_TCKN_VKN_UYUMSUZ("06","Mesajla gelen Al�c� TCKN/VKN bilgisi uyumsuz"),
		GONDEREN_BILGILERI_EKSIK_HATALI("07","G�nderici bilgileri eksik ya da hatal�"),
		ALICI_BANKA_ISLEM_LIMITI_DISINDA("08","Al�c� banka i�lem limitleri d���nda transfer"),
		DIGER("99","Di�er");
		
        private String code;
        private String description;

        private IadeKodu(String code,String description) {
                this.code = code;
                this.description=description;
        }
		public String getCode() {
			return code;
		}
		public String getDescription() {
			return description;
		}
	};
}
