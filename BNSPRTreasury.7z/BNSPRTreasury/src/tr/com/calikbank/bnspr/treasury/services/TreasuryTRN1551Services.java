package tr.com.calikbank.bnspr.treasury.services;

import java.awt.Color;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ReutersEtAccountHesapTx;
import tr.com.aktifbank.bnspr.dao.ReutersEtAccountHesapTxId;
import tr.com.aktifbank.bnspr.dao.ReutersEtAccountsTx;
import tr.com.aktifbank.bnspr.dao.ReutersEtAccountsTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1551Services {

	@GraymoundService("BNSPR_TRN1551_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "ACCOUNT_LIST";
			String tableName2 = "HESAP_LIST";

			List<?> recordList = (List<?>) iMap.get(tableName);
			List<?> recordList2 = (List<?>) iMap.get(tableName2);
			
			/*
			 * Ana tablodan tx-e yazilir
			 */
			Object inputValues[] = {
					BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO")
			};
			Object outputValues[] = {};
			DALUtil.callOracleProcedure("{call PKG_TRN1551.Ana_Tablodan_Tx(?)}", inputValues, outputValues);

			/*
			 * accounts yazilir
			 */
			for (int row = 0; row < recordList.size(); row++) {
				ReutersEtAccountsTxId id = new ReutersEtAccountsTxId();

				id.setAccountId(iMap.getString(tableName, row, "ACCOUNT_ID"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setMusteriNo(iMap.getBigDecimal(tableName, row, "MUSTERI_NO"));

				ReutersEtAccountsTx reutersEtAccountsTx = (ReutersEtAccountsTx) session.get(ReutersEtAccountsTx.class, id);

				if (reutersEtAccountsTx == null) {
					reutersEtAccountsTx = new ReutersEtAccountsTx();
				}
				reutersEtAccountsTx.setId(id);
				if (iMap.getBoolean(tableName, row, "SIL"))
					reutersEtAccountsTx.setSilinsinMi("E");
				else
					reutersEtAccountsTx.setSilinsinMi("H");

				session.saveOrUpdate(reutersEtAccountsTx);
			}
			
			/*
			 * hesaplar yazilir
			 */
			for (int row = 0; row < recordList2.size(); row++) {
				ReutersEtAccountHesapTxId id = new ReutersEtAccountHesapTxId();

				id.setAccountId(iMap.getString(tableName2, row, "ACCOUNT_ID"));
				id.setHesapNo(iMap.getBigDecimal(tableName2, row, "HESAP_NO"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));

				ReutersEtAccountHesapTx reutersEtAccountHesapTx = (ReutersEtAccountHesapTx) session.get(ReutersEtAccountHesapTx.class, id);

				if (reutersEtAccountHesapTx == null) {
					reutersEtAccountHesapTx = new ReutersEtAccountHesapTx();
				}
				reutersEtAccountHesapTx.setId(id);
				reutersEtAccountHesapTx.setMusteriNo(iMap.getBigDecimal(tableName2, row, "MUSTERI_NO"));
				reutersEtAccountHesapTx.setDovizKodu(iMap.getString(tableName2, row, "DOVIZ_KODU"));
				reutersEtAccountHesapTx.setMuhabir(iMap.getBigDecimal(tableName2, row, "MUHABIR"));

				if (iMap.getBoolean(tableName2, row, "SIL"))
					reutersEtAccountHesapTx.setSilinsinMi("E");
				else
					reutersEtAccountHesapTx.setSilinsinMi("H");

				session.saveOrUpdate(reutersEtAccountHesapTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "1551");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1551_GET_ACCOUNT_LIST")
	public static Map<?, ?> getMusteriList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1551.GET_ACCOUNT_LISTE(?)}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName1 = "ACCOUNT_LIST";
			for (int row = 0; rSet.next(); row++) {
				oMap.put(tableName1, row, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put(tableName1, row, "MUSTERI_ADI", rSet.getString("MUSTERI_ADI"));
				oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
				oMap.put(tableName1, row, "ACCOUNT_ID", rSet.getString("ACCOUNT_ID"));
			}
			return oMap;
		} catch (Exception e) {

			throw ExceptionHandler.convertException(e);

		} finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN1551_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		Connection conn = null;

		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TBL_ACCOUNT_LIST";
			String colorTableName = "TBL_ACCOUNT_COLOR";

			List<?> list = session.createCriteria(ReutersEtAccountsTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();

			for (int row = 0; row < list.size(); row++) {
				ReutersEtAccountsTx reutersEtAccountsTx = (ReutersEtAccountsTx) list.get(row);

				oMap.put("TRX_NO", reutersEtAccountsTx.getId().getTxNo());
				oMap.put(tableName, row, "MUSTERI_NO", reutersEtAccountsTx.getId().getMusteriNo());
				oMap.put(tableName, row, "MUSTERI_ADI",
						LovHelper.diLov(reutersEtAccountsTx.getId().getMusteriNo(), "1551/LOV_MUSTERI_NO", "MUSTERI_ADI"));
				oMap.put(tableName, row, "ACCOUNT_ID", reutersEtAccountsTx.getId().getAccountId());
				
				if (reutersEtAccountsTx.getSilinsinMi().equals("E"))
					oMap.put(tableName, row, "SIL", true);
				else
					oMap.put(tableName, row, "SIL", false);

				if ("E".equals(reutersEtAccountsTx.getSilinsinMi())) {
					oMap.put(colorTableName, row, "MUSTERI_NO", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "MUSTERI_ADI", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "ACCOUNT_ID", getTableCellColorData(Color.RED));
				} else {
					oMap.put(colorTableName, row, "MUSTERI_NO", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "MUSTERI_ADI", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "ACCOUNT_ID", getTableCellColorData(Color.WHITE));
				}

			}
			String tableName2 = "TBL_HESAP_LIST";
			String colorTableName2 = "TBL_HESAP_COLOR";
			List<?> list2 = session.createCriteria(ReutersEtAccountHesapTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (int row = 0; row < list2.size(); row++) {
				ReutersEtAccountHesapTx reutersEtAccountHesapTx = (ReutersEtAccountHesapTx) list2.get(row);

				oMap.put(tableName2, row, "ACCOUNT_ID", reutersEtAccountHesapTx.getId().getAccountId());
				oMap.put(tableName2, row, "HESAP_NO", reutersEtAccountHesapTx.getId().getHesapNo());
				oMap.put(tableName2, row, "MUSTERI_NO", reutersEtAccountHesapTx.getMusteriNo());
				oMap.put(tableName2, row, "MUHABIR", reutersEtAccountHesapTx.getMuhabir());
				if(reutersEtAccountHesapTx.getMuhabir() != null)
					oMap.put(tableName2, row, "BAKIYE",
							LovHelper.diLov(reutersEtAccountHesapTx.getId().getHesapNo(),reutersEtAccountHesapTx.getMuhabir(), "1551/LOV_HESAP_NO", "BAKIYE"));
				else
					oMap.put(tableName2, row, "BAKIYE",
							LovHelper.diLov(reutersEtAccountHesapTx.getId().getHesapNo(),reutersEtAccountHesapTx.getMusteriNo(), "1551/LOV_HESAP_NO", "BAKIYE"));
				oMap.put(tableName2, row, "DOVIZ_KODU", reutersEtAccountHesapTx.getDovizKodu());
				if (reutersEtAccountHesapTx.getSilinsinMi().equals("E"))
					oMap.put(tableName2, row, "SIL", true);
				else
					oMap.put(tableName2, row, "SIL", false);

				if ("E".equals(reutersEtAccountHesapTx.getSilinsinMi())) {
					oMap.put(colorTableName2, row, "MUSTERI_NO", getTableCellColorData(Color.RED));
					oMap.put(colorTableName2, row, "HESAP_NO", getTableCellColorData(Color.RED));
					oMap.put(colorTableName2, row, "SIL", getTableCellColorData(Color.RED));
					oMap.put(colorTableName2, row, "ACCOUNT_ID", getTableCellColorData(Color.RED));
					oMap.put(colorTableName2, row, "DOVIZ_KODU", getTableCellColorData(Color.RED));
					oMap.put(colorTableName2, row, "MUHABIR", getTableCellColorData(Color.RED));
					oMap.put(colorTableName2, row, "BAKIYE", getTableCellColorData(Color.RED));

				} else {
					oMap.put(colorTableName2, row, "MUSTERI_NO", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName2, row, "HESAP_NO", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName2, row, "SIL", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName2, row, "ACCOUNT_ID", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName2, row, "DOVIZ_KODU", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName2, row, "MUHABIR", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName2, row, "BAKIYE", getTableCellColorData(Color.WHITE));

				}
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(conn);
		}

	}

	private static GMMap getTableCellColorData(Color backgroundColor) {
		GMMap oMap = new GMMap();
		oMap.put("setBackground", backgroundColor);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1551_GET_CLICK_DATA")
	public static GMMap getClickData(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			String func = "{? = call PKG_TRN1551.Get_Table_Hesap(?)}";
			Object[] inputValues = new Object[] { BnsprType.STRING, iMap.getString("ACCOUNT_ID") };

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TBL_HESAP_LIST", inputValues));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
