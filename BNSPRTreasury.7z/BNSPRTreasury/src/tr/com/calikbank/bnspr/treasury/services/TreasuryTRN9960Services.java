package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SpkRiskGrubu;
import tr.com.aktifbank.bnspr.dao.SpkRiskGrubuTx;
import tr.com.aktifbank.bnspr.dao.SpkRiskGrubuTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN9960Services {
	
	@GraymoundService("BNSPR_TRN9960_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			String oldTableName = "OLD_LIST";
			int row = 0, oldRow = 0;
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				/*
				 * tx-e gore mevcut-liste cekilir
				 */
				List<?> list = session.createCriteria(SpkRiskGrubuTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SpkRiskGrubuTx spkRiskGrubu = (SpkRiskGrubuTx) iterator.next();
					
					oMap.put(tableName, row, "GRUP_NO", spkRiskGrubu.getId().getGrupNo());
					oMap.put(tableName, row, "GRUP_ADI", spkRiskGrubu.getGrupAdi());
					oMap.put(tableName, row, "MIN_PUAN", spkRiskGrubu.getMinPuan());
					oMap.put(tableName, row, "MAX_PUAN", spkRiskGrubu.getMaxPuan());
					
					row++;
				}
				
				/*
				 * Eski tx-no bulunur
				 */
				BigDecimal oldTrxNo = getOncekiTxNo(trxNo);
				
				/*
				 * tx-e gore eski liste cekilir
				 */
				List<?> oldList = session.createCriteria(SpkRiskGrubuTx.class).add(Restrictions.eq("id.txNo", oldTrxNo)).list();
				
				for (Iterator<?> iterator = oldList.iterator(); iterator.hasNext();) {
					SpkRiskGrubuTx spkRiskGrubu = (SpkRiskGrubuTx) iterator.next();
					
					oMap.put(oldTableName, oldRow, "GRUP_NO", spkRiskGrubu.getId().getGrupNo());
					oMap.put(oldTableName, oldRow, "GRUP_ADI", spkRiskGrubu.getGrupAdi());
					oMap.put(oldTableName, oldRow, "MIN_PUAN", spkRiskGrubu.getMinPuan());
					oMap.put(oldTableName, oldRow, "MAX_PUAN", spkRiskGrubu.getMaxPuan());
					
					oldRow++;
				}
				
				/*
				 * eski ve yeni listeler karsilatirilir, renklendirme icin
				 */
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("GRUP_NO");
				keyColumns.add("GRUP_ADI");
				keyColumns.add("MIN_PUAN");
				keyColumns.add("MAX_PUAN");
				
				oMap.put("COLOR_LIST", BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(oldTableName), (ArrayList<?>) oMap.get(tableName), keyColumns).get("COLOR_DATA"));
				
			} else {//yoksa ana tablo uzerinden gelsin
				
				List<?> list = session.createCriteria(SpkRiskGrubu.class).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SpkRiskGrubu spkRiskGrubu = (SpkRiskGrubu) iterator.next();
					
					oMap.put(tableName, row, "GRUP_NO", spkRiskGrubu.getGrupNo());
					oMap.put(tableName, row, "GRUP_ADI", spkRiskGrubu.getGrupAdi());
					oMap.put(tableName, row, "MIN_PUAN", spkRiskGrubu.getMinPuan());
					oMap.put(tableName, row, "MAX_PUAN", spkRiskGrubu.getMaxPuan());
					
					row++;
				}
				
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9960_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			
			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete SpkRiskGrubuTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			/*
			 * tablo insert edilir
			 */
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				SpkRiskGrubuTx spkRiskGrubu = new SpkRiskGrubuTx();
				
				//
				SpkRiskGrubuTxId id = new SpkRiskGrubuTxId();
				id.setTxNo(trxNo);
				id.setGrupNo(iMap.getString(tableName, row, "GRUP_NO"));
				//
				
				spkRiskGrubu.setId(id);
				spkRiskGrubu.setGrupAdi(iMap.getString(tableName, row, "GRUP_ADI"));
				spkRiskGrubu.setMinPuan(iMap.getBigDecimal(tableName, row, "MIN_PUAN"));
				spkRiskGrubu.setMaxPuan(iMap.getBigDecimal(tableName, row, "MAX_PUAN"));
				
				session.saveOrUpdate(spkRiskGrubu);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9960");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static BigDecimal getOncekiTxNo(BigDecimal trxNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_9960(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, trxNo);
			stmt.execute();
			
			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
