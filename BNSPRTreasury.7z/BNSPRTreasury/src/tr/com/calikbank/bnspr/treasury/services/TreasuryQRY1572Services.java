package tr.com.calikbank.bnspr.treasury.services;

import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class TreasuryQRY1572Services {

	@GraymoundService("BNSPR_QRY1572_SORGULA")
	public static GMMap initializeQry1572(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {

			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			
			String tableName = "PRIM";
			String func = "{? = call  bnspr.pkg_rc1572.GetPrimList(?)}";
			Object[] inputValues = new Object[]{BnsprType.DATE, iMap.getDate("TARIH")};
			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			oMap.putAll(resultMap);
			
			tableName = "RISK";
			func = "{? = call  bnspr.pkg_rc1572.GetRiskList(?)}";
			resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			oMap.putAll(resultMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}