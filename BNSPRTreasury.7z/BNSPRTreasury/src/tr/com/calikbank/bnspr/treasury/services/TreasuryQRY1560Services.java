package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1560Services {
    
    @GraymoundService("BNSPR_QRY1560_INIT_ISLEM_KANAL_LIST")
    public static GMMap initIslemKanal(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try{
            GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS" , new GMMap().put("KOD" , "BELGE_KONTROL_KOD")).get("RESULTS");
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("select k.KOD, k.ACIKLAMA from v_ml_gnl_kanal_grup_kod_pr k where k.KOD in (1,4,5,6,7,10) ");
            stmt.execute();
            rSet = stmt.getResultSet();
            int i = 0;
            String tableName = "ISLEM_KANALI";
            while (rSet.next()){
                oMap.put(tableName , i , "KOD" , rSet.getString("KOD"));
                oMap.put(tableName , i , "NAME" , rSet.getString("ACIKLAMA"));
                i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_QRY1560_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBox(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            iMap.put("ADD_EMPTY_KEY" , "H");
            iMap.put("KOD" , "BB_BONO_BOZUM_DURUM");
            oMap.put("ISLEM_DURUMU" , GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));

            iMap.clear();
            iMap.put("ADD_EMPTY_KEY" , "HEPSI");
            iMap.put("KOD" , "BONO_TIPI");
            oMap.put("BONO_TIPI" , GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            DALUtil.fillComboBox(oMap , "ISLEM_KANALI" , true , "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr k where k.KOD in (1,4,5,6,7,10)");
            
       
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_QRY1560_SORGULA")
    public static GMMap sorgula(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
            GMMap oMap = new GMMap();
            DALUtil.fillComboBox(oMap , "ISLEM_KANALI_COMBO" , true , "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr k where k.KOD in (1,4,5,6,7,10)");
            int paramIndex = 1;
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC1560.Get_Bono_Bilgileri(?,?,?,?,?,?,?,?,?)}");
            stmt.registerOutParameter(paramIndex++ , -10);
            stmt.setBigDecimal(paramIndex++ , iMap.getString("MUSTERI_NO").equals("") ? null : iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(paramIndex++ , iMap.getString("ISLEM_KANALI"));
            stmt.setString(paramIndex++ , iMap.getString("SUBE_KODU"));
            
            stmt.setDate(paramIndex++ , iMap.getDate("ISLEM_TARIH_1") == null ? null : new java.sql.Date(iMap.getDate("ISLEM_TARIH_1").getTime()));
            stmt.setDate(paramIndex++ , iMap.getDate("ISLEM_TARIH_2") == null ? null : new java.sql.Date(iMap.getDate("ISLEM_TARIH_2").getTime()));
            stmt.setDate(paramIndex++ , iMap.getDate("VADE_TARIH_1") == null ? null : new java.sql.Date(iMap.getDate("VADE_TARIH_1").getTime()));
            stmt.setDate(paramIndex++ , iMap.getDate("VADE_TARIH_2") == null ? null : new java.sql.Date(iMap.getDate("VADE_TARIH_2").getTime()));
            
            stmt.setString(paramIndex++ , iMap.getString("ISLEM_DURUM"));
            stmt.setString(paramIndex++ , iMap.getString("DOVIZ_KODU"));
            
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            
            String tableName = "SONUC_TABLE";
            oMap.putAll(DALUtil.rSetResults(rSet , tableName));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @GraymoundService("BNSPR_QRY1560_GET_OPSIYON_DETAY_TABLE")
    public static GMMap getOpsiyonDetay(GMMap iMap) {
    	 Connection conn = null;
         CallableStatement stmt = null;
         ResultSet rSet = null;
         
         try{
             GMMap oMap = new GMMap();
             int paramIndex = 1;
             conn = DALUtil.getGMConnection();
             stmt = conn.prepareCall("{? = call PKG_RC1560.Get_Opsiyon_Bilgileri(?)}");
             stmt.registerOutParameter(paramIndex++ , -10);
             stmt.setBigDecimal(paramIndex++ , iMap.getBigDecimal(("BONO_REFERANS")));
             
             stmt.execute();
             
             rSet = (ResultSet) stmt.getObject(1);
             
             String tableName = "OPSIYON_DETAY_TABLE";
             oMap.putAll(DALUtil.rSetResults(rSet , tableName));
             return oMap;
         } catch (Exception e){
             throw ExceptionHandler.convertException(e);
         } finally{
             GMServerDatasource.close(rSet);
             GMServerDatasource.close(stmt);
             GMServerDatasource.close(conn);
         }
    }
    @GraymoundService("BNSPR_QRY1560_GET_ISLEM_NO")
    public static GMMap getIslemNo(GMMap iMap) {
         
         try{
             GMMap oMap = new GMMap();

             int i=0;
             String func = "{? = call PKG_RC1560.Get_islem_no(?,?)}";
             Object[] inputValues = new Object[4];
             inputValues [i++] = BnsprType.STRING;
             inputValues [i++] = iMap.getString("BONO_REFERANS");
             inputValues [i++] = BnsprType.STRING;
             inputValues [i++] = iMap.getString(("REFERANS"));

             String islem_no =  (String) DALUtil.callOracleFunction(func , BnsprType.STRING ,inputValues);
             
             oMap.put("ISLEM_NO" , islem_no);
             return oMap;
         } catch (Exception e){
             throw ExceptionHandler.convertException(e);
         
         }
    }
}
