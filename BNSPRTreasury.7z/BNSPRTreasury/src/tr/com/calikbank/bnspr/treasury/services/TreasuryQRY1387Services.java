package tr.com.calikbank.bnspr.treasury.services;

//import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1387Services {
	@GraymoundService("BNSPR_ORY1387_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
			try{
				GMMap oMap = new GMMap();
				iMap.put("KOD", "BLOTTER_ISLEM_TIPI");
				iMap.put("ADD_EMPTY_KEY", "E");
				oMap.put("ISLEM_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
								
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
	}
	
	@GraymoundService("BNSPR_QRY1387_LISTELE")
	public static GMMap listele(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC1387.RC_QRY1387_BLOTTER(?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			if(iMap.getDate("MIN_DATE") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("MIN_DATE").getTime()));
			else
				stmt.setDate(i++,null);
			if(iMap.getDate("MAX_DATE") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("MAX_DATE").getTime()));
			else
				stmt.setDate(i++,null);
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1); 
			String tableName = "TBL_BLOTTER";
			oMap = DALUtil.rSetResults(rSet, tableName);	
		/*	
			while (rSet.next()) {
				toplamtutar = (rSet.getBigDecimal("tutar")==null?new BigDecimal(0):rSet.getBigDecimal("tutar")).add(toplamtutar);
				//toplamtutar= toplamtutar.add(rSet.getBigDecimal("tutar"));		
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++){
					switch (rs.getColumnType(c)){
					case (Types.DATE):{
						oMap.put(tableName, row, rs.getColumnName(c), rSet.getDate(c));
						break;
					}
					default :{
						oMap.put(tableName, row, rs.getColumnName(c), rSet.getObject(c));
						break;
					}
					}
				}
				row++;
			}
			  oMap.put("TOPLAM_TUTAR", toplamtutar ) ;
			
		*/
			   return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
			    GMServerDatasource.close(rSet);
			    GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				
			}
		}
}
