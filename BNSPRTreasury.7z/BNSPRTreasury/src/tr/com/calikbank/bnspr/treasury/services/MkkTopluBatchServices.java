package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.MkkResponse;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkTopluBatchServices {
    private static final Logger logger = Logger.getLogger(MkkKtBatchService.class);
    
    @GraymoundService("BNSPR_MKK_TOPLU_BATCH_SERVICE")
    public static GMMap getMkkTopluBatchService(GMMap iMap) {
    	
    	 GMMap oMap = new GMMap();
         GMMap xMap = new GMMap();
         xMap.put("BATCH_NAME" , "MKK_TOPLU_BATCH_RUNNING_FLAG");
         String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
         boolean iAmRunning = false;
    	
         try{
        	 
        	 if("E".equals(runningFlag)){
                 logger.info("[BNSPR_MKK_TOPLU_BATCH_SERVICE] batch is already running, can't run parallel...");
                 oMap.put("HATA_NO", new BigDecimal(660));
                 oMap.put("P1", "Devam eden MKK Toplu batch islemi bulunmaktadır!");
                 return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
             }
             else{
                 xMap = new GMMap();
                 xMap.put("BATCH_NAME" , "MKK_TOPLU_BATCH_RUNNING_FLAG");
                 xMap.put("BATCH_DEGER" , "\"1\"");
                 GMServiceExecuter.execute("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                 logger.info("[BNSPR_MKK_TOPLU_BATCH_SERVICE] MKK_TOPLU_BATCH_RUNNING_FLAG has been set to [1]");
                 iAmRunning = true;
             }
        	 logger.info("MKK Toplu Batch Calismaya basladı:[BNSPR_MKK_TOPLU_BATCH_SERVICE]");
        	 
        	 oMap.put("BNSPR_MKK_HA_BATCH_SERVICE", GMServiceExecuter.execute("BNSPR_MKK_HA_BATCH_SERVICE", iMap));
        	 oMap.put("BNSPR_MKK_KE_BATCH_SERVICE", GMServiceExecuter.execute("BNSPR_MKK_KE_BATCH_SERVICE", iMap));
        	 
        	 //TY-9672 - Nitelikli yat�r�mc� bildirimi sadece ekrandan tetiklenebilecek.
        	 //07.057.218 Erkan �al��kan 
        	 
        	 //oMap.put("BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE", GMServiceExecuter.execute("BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE", iMap));
        	 
        	 oMap.put("BNSPR_MKK_KT_BATCH_SERVICE", GMServiceExecuter.execute("BNSPR_MKK_KT_BATCH_SERVICE", iMap));
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } 
        finally{
             if (iAmRunning){ //Batchi calistiran bensem isim bittiginde sonlandirmaliyim
                 xMap = new GMMap();
                 xMap.put("BATCH_NAME" , "MKK_TOPLU_BATCH_RUNNING_FLAG");
                 xMap.put("BATCH_DEGER" , "\"0\"");
                 GMServiceExecuter.execute("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                 logger.info("[BNSPR_MKK_TOPLU_BATCH_SERVICE] MKK_TOPLU_BATCH_RUNNING_FLAG has been set to [0]");
             }
             logger.info("MKK Toplu Batch islemi tamamlandi, [BNSPR_MKK_TOPLU_BATCH_SERVICE]");
         }
     
        return oMap;        
    }
}
