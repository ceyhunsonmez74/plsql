package tr.com.calikbank.bnspr.treasury.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ServiceUtil {

	public static GMMap checkInput(GMMap oMap, Object input, Integer messageCode, String message) {
		if (!oMap.getString("RESPONSE").equals("0"))
			return oMap;
		if (input == null || input.toString().isEmpty()) {
			oMap.put("RESPONSE", messageCode.toString());
			oMap.put("RESPONSE_DATA", message);
		}
		return oMap;
	}

	public static Date checkDateInput(GMMap oMap, String input, Integer messageCode, String message, boolean hasTime) {
		Date output = null;
		if (!oMap.getString("RESPONSE").equals("0"))
			return output;
		try {
			if (input != null && !input.isEmpty()) {
				if (hasTime)
					output = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").parse(input);
				else
					output = new SimpleDateFormat("dd.MM.yyyy").parse(input);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", messageCode.toString());
			oMap.put("RESPONSE_DATA", message);
		}
		
		return output;
	}
	
	@SuppressWarnings("deprecation")
	public static String checkDateTime(GMMap oMap, String input, Integer messageCode, String message, boolean hasTime) {
		String output = null;
		if (!oMap.getString("RESPONSE").equals("0"))
			return output;
		try {
			if (input != null && !input.isEmpty()) {
		     Date time = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").parse(input);		
		     String minute = padLeftZeros(String.valueOf(time.getMinutes()), 2);
		     String hour   = padLeftZeros(String.valueOf(time.getHours  ()), 2);
		     output = hour + minute;		     
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", messageCode.toString());
			oMap.put("RESPONSE_DATA", message);
		}
		return output;
	}
	
	public static String padLeftZeros(String inputString, int length) {
	    if (inputString.length() >= length) {
	        return inputString;
	    }
	    StringBuilder sb = new StringBuilder();
	    while (sb.length() < length - inputString.length()) {
	        sb.append('0');
	    }
	    sb.append(inputString);

	    return sb.toString();
	}

	private static void logAt(String serviceName, GMMap request, GMMap response, Exception e) {
		GMMap oMap = new GMMap();
		oMap.put("TRX_NO", request.getBigDecimal("TRX_NO"));
		oMap.put("SP_NAME", serviceName);
		oMap.put("ERR_NO", response != null ? response.getString("RESPONSE") : "-1");
		oMap.put("ERR_MSG", response != null ? response.getString("RESPONSE_DATA") : "");
		oMap.put("EXCEPTION", e != null ? e.getLocalizedMessage() : null);
		oMap.put("PARAM_IN", request.toString());
		oMap.put("PARAM_OUT", response != null ? response.toString() : "");
		GMServiceExecuter.executeNT("BNSPR_MENKUL_SERVICE_LOG", oMap);
	}

	public static void logAt(String serviceName, GMMap request, GMMap response) {
		logAt(serviceName, request, response, null);
	}

	public static void logAt(String serviceName, GMMap request, Exception e) {
		logAt(serviceName, request, null, e);
	}
	public static String checkTimeInput(GMMap oMap, String input, Integer messageCode, String message) {
		String output = null;
		try {
			if (!oMap.getString("RESPONSE").equals("0"))
				return output;

			String hhMMssRegex = "^(?:2[0-3]|[01][0-9]):[0-5][0-9]:[0-5][0-9]$";
			if(input.matches(hhMMssRegex)){
				output = input;
			}else {
				oMap.put("RESPONSE", messageCode.toString());
				oMap.put("RESPONSE_DATA", message);
			}
		}catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", messageCode.toString());
			oMap.put("RESPONSE_DATA", message);
		}
		return output;
	}
	
	public static Date checkWeekend(GMMap oMap, Date date, Integer messageCode, String message) {
		Date output = date;
		if (!oMap.getString("RESPONSE").equals("0"))
			return output;
		try {
			if (output.getDay() == 0 && output.getDay() == 6 ) {
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", messageCode.toString());
			oMap.put("RESPONSE_DATA", message);
		}
		return output;
	}
}
