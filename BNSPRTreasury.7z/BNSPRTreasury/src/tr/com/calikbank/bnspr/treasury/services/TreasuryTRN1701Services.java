package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MkkHesapAcilis;
import tr.com.aktifbank.bnspr.dao.MkkHesapAcilisTx;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirme;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferi;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1701Services {
    
    @GraymoundService("BNSPR_TRN1701_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        Session session = DAOSession.getSession("BNSPRDal");
        MkkHesapAcilis ha = new MkkHesapAcilis();
        MkkHesapAcilisTx hax = new MkkHesapAcilisTx();
        String tableName = "TABLE_HA";
        BigDecimal txNo = iMap.getBigDecimal("TX_NO");

        List<?> satirBilgileri = (List<?>) iMap.get(tableName);
        for (int i = 0; i < satirBilgileri.size(); i++){
            if (iMap.getBoolean(tableName , i , "SEC") == true){
                ha = (MkkHesapAcilis) session.get(MkkHesapAcilis.class , iMap.getBigDecimal(tableName , i , "HA_ID"));
                hax = MkkHaKeBatchService.createNewHaxPojo(ha);
                hax.getId().setTxNo(txNo);
                hax.setDurum("A"); // Ba�ar�l� Tamamland�
                session.save(hax);
                
            }
        }
        
        session.flush();
        iMap.clear();
        iMap.put("TRX_NAME" , "1701");
        iMap.put("TRX_NO" , txNo);
        oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
        
        return oMap;
    }

    @GraymoundService("BNSPR_TRN1701_GET_DATA")
    public static GMMap getData(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            String tableName = "TABLE_HA";
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1701.GET_HA_RECORDS_SCR(?,?,?)}");
            stmt.registerOutParameter(1 , -10);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(3 , iMap.getString("DURUM"));
            if (iMap.getDate("TARIH") != null)
                stmt.setDate(4 , new java.sql.Date(iMap.getDate("TARIH").getTime()));
            else stmt.setDate(4 , null);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            
            oMap.putAll(DALUtil.rSetResults(rSet , tableName));
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }

    @GraymoundService("BNSPR_TRN1701_TEKRAR_GONDER")
    public static GMMap tekrarGonder(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            BigDecimal mustNo = iMap.getBigDecimal("MUSTERI_NO");
            Criteria criteria = session.createCriteria(MkkHesapAcilis.class).add(Restrictions.eq("accountNumber" , iMap.getString("MUSTERI_NO"))).add(Restrictions.ne("durum" , "H"));
            List<?> list = criteria.list();
            if (list != null && list.size()>0){
                return throwGMBusssinessException(mustNo + " nolu m��teri i�in bekleyen veya tamamlanm�� MKK Hesap A��l�� kayd� bulunmaktad�r.");
            }
            
            MkkHesapAcilis haOld = (MkkHesapAcilis)session.get(MkkHesapAcilis.class , iMap.getBigDecimal("HA_ID"));
            
            conn = DALUtil.getGMConnection();

            //�nce yeni hesap a��l�� kayd� ekleyelim
            stmt = conn.prepareCall("{call PKG_MKK.HAInsert(?,?,?,?,?)}");
            stmt.setBigDecimal(1, haOld.getMusteriNo());
            stmt.setBigDecimal(2, haOld.getIslemKod());
            stmt.setBigDecimal(3, haOld.getReferans());
            stmt.setBigDecimal(4, haOld.getGeriAlisReferans());
            stmt.registerOutParameter(5 , Types.NUMERIC);
            stmt.execute();
            
            BigDecimal newHaId = stmt.getBigDecimal(5);

            //Yeni kimlik e�le�tirme kayd� ekleyelim
            stmt = conn.prepareCall("{call PKG_MKK.KEInsert(?,?,?,?,?,?)}");
            stmt.setBigDecimal(1, haOld.getMusteriNo());
            stmt.setString(2, "B"); //Bekliyor
            stmt.setBigDecimal(3, haOld.getIslemKod());
            stmt.setBigDecimal(4, haOld.getReferans());
            stmt.setBigDecimal(5, haOld.getGeriAlisReferans());
            stmt.setBigDecimal(6, newHaId);
            stmt.execute();
            
            //Yeni k�ymet transferi kayd� ekleyelim
            stmt = conn.prepareCall("{call PKG_MKK.KTInsert(?,?,?,?,?,?)}");
            stmt.setBigDecimal(1, haOld.getMusteriNo());
            stmt.setString(2, "B"); //Bekliyor
            stmt.setBigDecimal(3, haOld.getIslemKod());
            stmt.setBigDecimal(4, haOld.getReferans());
            stmt.setBigDecimal(5, haOld.getGeriAlisReferans());
            stmt.setBigDecimal(6, newHaId);
            stmt.execute();
            
            
            //Kimlik e�le�tirme tablosunda bu HA_ID ile bekleyen kay�tlar� iptale �ek
            criteria = session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("haId" , iMap.getBigDecimal("HA_ID"))).add(Restrictions.eq("durum" , "B"));
            List<MkkKimlikEslestirme> keList = criteria.list();
            if (keList != null){
                for (MkkKimlikEslestirme keOld : keList){
                    keOld.setDurum("I");
                    keOld.setResponseDesc("Hesap a��l�� farkl� bir kay�tla g�nderilece�i i�in iptal edildi, yeni HA_ID:" + newHaId);
                    session.save(keOld);
                }
                session.flush();
            }

            //K�ymet transferi tablosunda bu HA_ID ile bekleyen kay�tlar� iptale �ek
            criteria = session.createCriteria(MkkKiymetTransferi.class).add(Restrictions.eq("haId" , iMap.getBigDecimal("HA_ID"))).add(Restrictions.eq("durum" , "B"));
            List<MkkKiymetTransferi> ktList = criteria.list();
            if (ktList != null){
                for (MkkKiymetTransferi ktOld : ktList){
                    ktOld.setDurum("I");
                    ktOld.setResponseDesc("Hesap a��l�� farkl� bir kay�tla g�nderilece�i i�in iptal edildi, yeni HA_ID:" + newHaId);
                    session.save(ktOld);
                }
                session.flush();
            }            
            
            oMap.put("MESSAGE" , mustNo + " nolu m��teri i�in MKK Hesap A��l�� i�i tekrar tetiklenecektir, yeni ID:" + newHaId);
        }
        catch (Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_MKK_BATCH_RUNNING")
    public static GMMap batchRunning(GMMap iMap) {
        GMMap xMap = new GMMap();
        xMap.put("PARAMETRE", iMap.getString("BATCH_NAME"));
        String runFlag = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER").toString();
        
        GMMap oMap = new GMMap();
        oMap.put("RUNNING" , "1".equals(runFlag) ? "E" : "H");
        return oMap;
    }

    @GraymoundService("BNSPR_MKK_BATCH_START_STOP_FLAG")
    public static GMMap batchStartStopFlag(GMMap iMap) {
        GMMap oMap = new GMMap();        
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{call PKG_MKK.BatchStartStopFlag(?,?)}");
            stmt.setString(1, iMap.getString("BATCH_NAME"));
            stmt.setString(2, iMap.getString("BATCH_DEGER"));
            stmt.execute();
        }
        catch (Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1701_MKK_SORGULA")
    public static GMMap mkkSorgula(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            if (iMap.getBigDecimal("HA_ID") == null){
                return throwGMBusssinessException("MKK'dan sorgulamak istedi�iniz kayd� se�iniz.");
            }
            
            MkkHesapAcilis haOld = (MkkHesapAcilis)session.get(MkkHesapAcilis.class , iMap.getBigDecimal("HA_ID"));
            GMMap xMap = new GMMap();
            xMap.put("SENDER_REFERENCE" , haOld.getSenderReference());
            xMap.put("SERVICE_NAME" , "OpenAccount");
            
            oMap = GMServiceExecuter.call("BNSPR_MKK_MESSAGE_QUERY_SERVICE", xMap);
            
            oMap.put("MESSAGE" , iMap.getBigDecimal("HA_ID") + " nolu kay�t MKK'dan sorgulan�p durumu g�ncellenmi�tir");
        }
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }

    public static GMMap throwGMBusssinessException(String string) {             
        GMMap exMap = new GMMap();
        exMap.put("P1", string);
        exMap.put("HATA_NO", "660");
        return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
    }
}
