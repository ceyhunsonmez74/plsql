package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznTcmbDevirTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1363Services {
	
	@GraymoundService("BNSPR_TRN1363_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1363.BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1363_GET_INITIAL_DATA")
	public static GMMap getTransferData(GMMap iMap){

		try {
			GMMap oMap = new GMMap();
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznTcmbDevirTx hznTcmbDevirTx = (HznTcmbDevirTx)session.get(HznTcmbDevirTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("TX_NO", hznTcmbDevirTx.getTxNo());
			oMap.put("REF_NO", hznTcmbDevirTx.getRefNo());
			oMap.put("TUTAR", hznTcmbDevirTx.getTutar());
			oMap.put("SUBE_KODU", hznTcmbDevirTx.getSubeKodu());
			oMap.put("TCMB_REF", hznTcmbDevirTx.getTcmbRefNo());
			oMap.put("ACIKLAMA", hznTcmbDevirTx.getAciklama());
			oMap.put("SUBE_ADI", LovHelper.diLov(hznTcmbDevirTx.getSubeKodu(), "1363/LOV_SUBE_KODU", "ACIKLAMA" ));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1363_SAVE")
	public static GMMap Save (GMMap iMap){
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			HznTcmbDevirTx hznTcmbDevirTx = (HznTcmbDevirTx)session.get(HznTcmbDevirTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznTcmbDevirTx == null) {
				hznTcmbDevirTx = new HznTcmbDevirTx();
			}
			hznTcmbDevirTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznTcmbDevirTx.setRefNo(iMap.getString("REFERANS"));
			hznTcmbDevirTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznTcmbDevirTx.setSubeKodu(iMap.getString("SUBE_KODU"));
			hznTcmbDevirTx.setTcmbRefNo(iMap.getString("TCMB_REF"));
			hznTcmbDevirTx.setTutar(iMap.getBigDecimal("TUTAR"));
			
			session.saveOrUpdate(hznTcmbDevirTx);
			session.flush();
			iMap.put("TRX_NAME", "1363");
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1363_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			
			HznTcmbDevirTx hznTcmbDevirTx = (HznTcmbDevirTx)session.get(HznTcmbDevirTx.class, txNo);
			
			oMap.put("TRX_NO", hznTcmbDevirTx.getTxNo());
			oMap.put("REFERANS", hznTcmbDevirTx.getRefNo());
			oMap.put("TUTAR", hznTcmbDevirTx.getTutar());
			oMap.put("SUBE_KODU", hznTcmbDevirTx.getSubeKodu());
			oMap.put("TCMB_REF", hznTcmbDevirTx.getTcmbRefNo());
			oMap.put("ACIKLAMA", hznTcmbDevirTx.getAciklama());
			oMap.put("SUBE_ADI", LovHelper.diLov(hznTcmbDevirTx.getSubeKodu(), "1363/LOV_SUBE_KODU", "ACIKLAMA" ));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
