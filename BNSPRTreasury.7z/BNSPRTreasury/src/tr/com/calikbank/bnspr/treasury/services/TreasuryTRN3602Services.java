package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinSpotfwdTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3602Services {
    
    @GraymoundService("BNSPR_TRN3602_GET_TRANSFER_TXNO")
    public static GMMap getTransfertxNo(GMMap iMap){
        Connection conn         = null;
        CallableStatement stmt  = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_trn3602.SPFW_BilgiAktar(?) }");
            
            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setString(2, iMap.getString("REF_NO"));
            stmt.execute();
            oMap.put("TRX_NO", stmt.getBigDecimal(1));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
	
    @GraymoundService("BNSPR_TRN3602_GET_TRANSFER_DATA")
    public static GMMap getTransferData(GMMap iMap){

        try {
            GMMap oMap = new GMMap();
            
            Session session = DAOSession.getSession("BNSPRDal");
            HznAltinSpotfwdTx hznAltinSpotfwdTx = (HznAltinSpotfwdTx)session.get(HznAltinSpotfwdTx.class, iMap.getBigDecimal("TRX_NO"));
            
            oMap.put("TX_NO", hznAltinSpotfwdTx.getTxNo());
            oMap.put("REF_NO", hznAltinSpotfwdTx.getReferans());
            oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznAltinSpotfwdTx.getUrunTurKod(), "3601/LOV_URUN_TUR", "KOD"));
            oMap.put("URUN_SINIF_KOD", hznAltinSpotfwdTx.getUrunSinifKod());
            oMap.put("DEAL_TARIHI", hznAltinSpotfwdTx.getDealTarihi());
            oMap.put("ALIS_BRUT_TUTAR", hznAltinSpotfwdTx.getAlisBrutTutar());
            oMap.put("ALIS_NET_TUTAR", hznAltinSpotfwdTx.getAlisNetTutar());
            oMap.put("ALIS_HESAP_TURU", hznAltinSpotfwdTx.getAlisHesapTuru());
            oMap.put("ALIS_HESAP_NO", hznAltinSpotfwdTx.getAlisHesapNo());
            oMap.put("SATIS_BRUT_TUTAR", hznAltinSpotfwdTx.getSatisBrutTutar());
            oMap.put("SATIS_NET_TUTAR", hznAltinSpotfwdTx.getSatisNetTutar());
            oMap.put("SATIS_HESAP_NO", hznAltinSpotfwdTx.getSatisHesapNo());
            oMap.put("SATIS_HESAP_TURU", hznAltinSpotfwdTx.getSatisHesapTuru());
            oMap.put("DEALER_NO", hznAltinSpotfwdTx.getDealerNo());
            oMap.put("BANKA_MUSTERI_NO", hznAltinSpotfwdTx.getBankaMusteriNo());
            oMap.put("VALOR_TARIHI", hznAltinSpotfwdTx.getValorTarihi());
            oMap.put("ALIS_DOVIZ_KODU", hznAltinSpotfwdTx.getAlisDovizKodu());
            oMap.put("SATIS_DOVIZ_KODU", hznAltinSpotfwdTx.getSatisDovizKodu());
            oMap.put("ALIS_KUR", hznAltinSpotfwdTx.getAlisKur());
            oMap.put("SATIS_KUR", hznAltinSpotfwdTx.getSatisKur());
            oMap.put("PARITE", hznAltinSpotfwdTx.getParite());
            oMap.put("ACIKLAMA", hznAltinSpotfwdTx.getAciklama());
            oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinSpotfwdTx.getDealerNo(), "1316/LOV_DEALER", "ISIM"));
            oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznAltinSpotfwdTx.getBankaMusteriNo(), "1316/LOV_BANKA_MUSTERI", "UNVAN"));
            oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznAltinSpotfwdTx.getAlisHesapNo(), hznAltinSpotfwdTx.getBankaMusteriNo(), hznAltinSpotfwdTx.getAlisDovizKodu(), "1316/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
            oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznAltinSpotfwdTx.getSatisHesapNo(), hznAltinSpotfwdTx.getBankaMusteriNo(), hznAltinSpotfwdTx.getSatisDovizKodu(), "1316/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
            oMap.put("AS", hznAltinSpotfwdTx.getAS());
            oMap.put("ALIS_MUHABIR_MUSTERI_NO", hznAltinSpotfwdTx.getAlisMuhabirMusteriNo());
            oMap.put("SATIS_MUHABIR_MUSTERI_NO", hznAltinSpotfwdTx.getSatisMuhabirMusteriNo());
            oMap.put("STOK_NO", hznAltinSpotfwdTx.getStokNo());
            oMap.put("KOMISYON_ORANI", hznAltinSpotfwdTx.getKomisyonOrani());
            oMap.put("KOMISYON_TUTARI", hznAltinSpotfwdTx.getKomisyonTutari());
            oMap.put("ISLEM_TIPI", hznAltinSpotfwdTx.getIslemTipi());
            oMap.put("ALTIN_SAFLIK_DERECESI",hznAltinSpotfwdTx.getAltinSaflikDerecesi());

            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
	@GraymoundService("BNSPR_TRN3602_SAVE")
	  public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinSpotfwdTx hznAltinSpotfwdTx = (HznAltinSpotfwdTx)session.get(HznAltinSpotfwdTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznAltinSpotfwdTx == null) {
			    hznAltinSpotfwdTx = new HznAltinSpotfwdTx();
			}
			
			hznAltinSpotfwdTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAltinSpotfwdTx.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			hznAltinSpotfwdTx.setModulTurKod("HAZINE");
			hznAltinSpotfwdTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAltinSpotfwdTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAltinSpotfwdTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznAltinSpotfwdTx.setAlisBrutTutar(iMap.getBigDecimal("ALIS_BRUT_TUTAR"));
			hznAltinSpotfwdTx.setAlisNetTutar(iMap.getBigDecimal("ALIS_NET_TUTAR"));
			hznAltinSpotfwdTx.setSatisBrutTutar(iMap.getBigDecimal("SATIS_BRUT_TUTAR"));
			hznAltinSpotfwdTx.setSatisNetTutar(iMap.getBigDecimal("SATIS_NET_TUTAR"));
			hznAltinSpotfwdTx.setAlisHesapTuru(iMap.getString("ALIS_HESAP_TURU"));
			hznAltinSpotfwdTx.setAlisHesapNo(iMap.getBigDecimal("ALIS_HESAP_NO"));
			hznAltinSpotfwdTx.setSatisHesapTuru(iMap.getString("SATIS_HESAP_TURU"));
			hznAltinSpotfwdTx.setSatisHesapNo(iMap.getBigDecimal("SATIS_HESAP_NO"));
			hznAltinSpotfwdTx.setDealerNo((String)iMap.get("DEALER_NO"));
			hznAltinSpotfwdTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAltinSpotfwdTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAltinSpotfwdTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznAltinSpotfwdTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznAltinSpotfwdTx.setAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			hznAltinSpotfwdTx.setSatisKur(iMap.getBigDecimal("SATIS_KUR"));
			hznAltinSpotfwdTx.setParite(iMap.getBigDecimal("PARITE"));
			hznAltinSpotfwdTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznAltinSpotfwdTx.setDurumKodu("A");
			hznAltinSpotfwdTx.setAS(iMap.getString("AS"));
			hznAltinSpotfwdTx.setAltinSaflikDerecesi(iMap.getBigDecimal("ALTIN_SAFLIK_DERECESI"));			
			hznAltinSpotfwdTx.setStokNo(iMap.getString("STOK_NO"));
			hznAltinSpotfwdTx.setAlisMuhabirMusteriNo((iMap.getString("ALIS_MUHABIR_MUSTERI_NO")));
			hznAltinSpotfwdTx.setSatisMuhabirMusteriNo((iMap.getString("SATIS_MUHABIR_MUSTERI_NO")));
			hznAltinSpotfwdTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
			hznAltinSpotfwdTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
			hznAltinSpotfwdTx.setReferans(iMap.getString("REFERANS"));

			
			session.saveOrUpdate(hznAltinSpotfwdTx);
			session.flush();
		
            iMap.put("TRX_NAME","3602");

           return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                  
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	

	
	
	@GraymoundService("BNSPR_TRN3602_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinSpotfwdTx hznAltinSpotfwdTx = (HznAltinSpotfwdTx)session.get(HznAltinSpotfwdTx.class, txNo);
			
			oMap.put("TX_NO", hznAltinSpotfwdTx.getTxNo());
			oMap.put("REF_NO", hznAltinSpotfwdTx.getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznAltinSpotfwdTx.getUrunTurKod(), "3601/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznAltinSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznAltinSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_BRUT_TUTAR", hznAltinSpotfwdTx.getAlisBrutTutar());
			oMap.put("ALIS_NET_TUTAR", hznAltinSpotfwdTx.getAlisNetTutar());
			oMap.put("SATIS_BRUT_TUTAR", hznAltinSpotfwdTx.getSatisBrutTutar());
			oMap.put("SATIS_NET_TUTAR", hznAltinSpotfwdTx.getSatisNetTutar());
			oMap.put("ALIS_HESAP_TURU", hznAltinSpotfwdTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznAltinSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_HESAP_TURU", hznAltinSpotfwdTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznAltinSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznAltinSpotfwdTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznAltinSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznAltinSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznAltinSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznAltinSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznAltinSpotfwdTx.getSatisKur());
			oMap.put("PARITE", hznAltinSpotfwdTx.getParite());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinSpotfwdTx.getDealerNo(), "1306/LOV_DEALER", "ISIM"));
            oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznAltinSpotfwdTx.getBankaMusteriNo(), "1306/LOV_BANKA_MUSTERI", "UNVAN"));
            oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznAltinSpotfwdTx.getAlisHesapNo(),hznAltinSpotfwdTx.getAlisDovizKodu(), hznAltinSpotfwdTx.getAlisHesapTuru(),
                    hznAltinSpotfwdTx.getAlisDovizKodu(), hznAltinSpotfwdTx.getAlisHesapTuru(), hznAltinSpotfwdTx.getBankaMusteriNo(), 
                    "1306/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
            oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznAltinSpotfwdTx.getSatisHesapNo(),hznAltinSpotfwdTx.getSatisDovizKodu(), hznAltinSpotfwdTx.getSatisHesapTuru(),
                    hznAltinSpotfwdTx.getSatisDovizKodu(),hznAltinSpotfwdTx.getSatisHesapTuru(),hznAltinSpotfwdTx.getBankaMusteriNo(), 
                    "1306/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
            
			oMap.put("AS", hznAltinSpotfwdTx.getAS());
			oMap.put("ACIKLAMA", hznAltinSpotfwdTx.getAciklama());
	        oMap.put("STOK_NO", hznAltinSpotfwdTx.getStokNo());
	        oMap.put("KOMISYON_ORANI", hznAltinSpotfwdTx.getKomisyonOrani());
	        oMap.put("ISLEM_TIPI", hznAltinSpotfwdTx.getIslemTipi());
	        oMap.put("ALTIN_SAFLIK_DERECESI",hznAltinSpotfwdTx.getAltinSaflikDerecesi());



			
			oMap.put("ALIS_MUHABIR_MUSTERI_NO", hznAltinSpotfwdTx.getAlisMuhabirMusteriNo());
			oMap.put("SATIS_MUHABIR_MUSTERI_NO", hznAltinSpotfwdTx.getSatisMuhabirMusteriNo());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	   @GraymoundService("BNSPR_TRN3602_GET_KOMISYON_ORANI")
	    public static Map<?, ?> getKomisyonOrani(GMMap iMap) {
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        GMMap oMap = new GMMap();
	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_ALTIN_FON.KOMISYON_ORANI(?)}");
	            
	            int i    = 1;
	            
	            stmt.registerOutParameter(i++, Types.NUMERIC);
	            stmt.setString(i++, iMap.getString("ISLEM_TIPI"));

	            stmt.execute();
	       
	            oMap.put("KOMISYON_ORANI",stmt.getObject(1));
	           
	                
	            return oMap;
	        }
	            catch (Exception e) {
	                
	                throw ExceptionHandler.convertException(e);
	            
	            } finally {
	                
	                GMServerDatasource.close(rSet);
	                GMServerDatasource.close(stmt);
	                GMServerDatasource.close(conn);
	            
	            }
	        }
}
