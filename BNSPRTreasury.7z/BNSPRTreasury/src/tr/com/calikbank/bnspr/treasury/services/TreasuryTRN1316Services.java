package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTxId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1316Services {
	
	@GraymoundService("BNSPR_TRN1316_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			HznSpotfwdTxId id = null;
			
			if(hznSpotfwdTx == null) {
				hznSpotfwdTx = new HznSpotfwdTx();
				id = new HznSpotfwdTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setReferans(iMap.getString("TRX_NO"));
			} else {
				id = hznSpotfwdTx.getId();
			}

			hznSpotfwdTx.setId(id);
			hznSpotfwdTx.setModulTurKod("HAZINE");
			hznSpotfwdTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSpotfwdTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSpotfwdTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznSpotfwdTx.setAlisTutari(iMap.getBigDecimal("ALIS_TUTARI"));
			hznSpotfwdTx.setKrediTeklifSatirNumara(iMap.getBigDecimal("KREDI_TEKLIF_SATIR_NUMARA"));
			hznSpotfwdTx.setAlisHesapNo(iMap.getBigDecimal("ALIS_HESAP_NO"));
			hznSpotfwdTx.setSatisTutari(iMap.getBigDecimal("SATIS_TUTARI"));
			hznSpotfwdTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
			hznSpotfwdTx.setSatisHesapNo(iMap.getBigDecimal("SATIS_HESAP_NO"));
			hznSpotfwdTx.setDealerNo((String)iMap.get("DEALER_NO"));
			hznSpotfwdTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSpotfwdTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSpotfwdTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSpotfwdTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSpotfwdTx.setAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			hznSpotfwdTx.setSatisKur(iMap.getBigDecimal("SATIS_KUR"));
			hznSpotfwdTx.setParite(iMap.getBigDecimal("PARITE"));
			hznSpotfwdTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznSpotfwdTx.setTryKarsilik(iMap.getBigDecimal("TRY_KARSILIK"));
			hznSpotfwdTx.setDurumKodu("A");
			hznSpotfwdTx.setHazineKur(iMap.getBigDecimal("HAZINE_KUR"));
			hznSpotfwdTx.setBazFaiz(iMap.getBigDecimal("BAZ_FAIZ"));
			hznSpotfwdTx.setKarsiFaiz(iMap.getBigDecimal("KARSI_FAIZ"));
			
			hznSpotfwdTx.setRiskIslemTipi(iMap.getString("ISLEM_TURU"));
			hznSpotfwdTx.setRiskTeminatTutari(iMap.getBigDecimal("TEM_TUTAR"));
			hznSpotfwdTx.setRiskTeminatOran(iMap.getBigDecimal("TEMINAT_ORANI"));
			hznSpotfwdTx.setKarsilananTeminatTl(iMap.getBigDecimal("KARSILANAN_TUTAR"));
			hznSpotfwdTx.setHesaplananTeminatTl(iMap.getBigDecimal("KARSILANAN_TUTAR"));
			
			hznSpotfwdTx.setSmEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("SM_EH")));
			
			hznSpotfwdTx.setAS(iMap.getString("AS"));
			session.saveOrUpdate(hznSpotfwdTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1316");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1316_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();
			
			oMap.put("TX_NO", hznSpotfwdTx.getId().getTxNo());
			oMap.put("REF_NO", hznSpotfwdTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSpotfwdTx.getUrunTurKod(), "1316/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznSpotfwdTx.getAlisTutari());
			oMap.put("KREDI_TEKLIF_SATIR_NUMARA", hznSpotfwdTx.getKrediTeklifSatirNumara());
			oMap.put("ALIS_HESAP_NO", hznSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznSpotfwdTx.getSatisTutari());
			oMap.put("SOZLESME_NO", hznSpotfwdTx.getSozlesmeNo());
			oMap.put("SATIS_HESAP_NO", hznSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznSpotfwdTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznSpotfwdTx.getSatisKur());
			oMap.put("PARITE", hznSpotfwdTx.getParite());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSpotfwdTx.getDealerNo(), "1316/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSpotfwdTx.getBankaMusteriNo(), "1316/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getAlisHesapNo(), hznSpotfwdTx.getBankaMusteriNo(), hznSpotfwdTx.getAlisDovizKodu(), "1316/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getSatisHesapNo(), hznSpotfwdTx.getBankaMusteriNo(), hznSpotfwdTx.getSatisDovizKodu(), "1316/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("AS", hznSpotfwdTx.getAS());
			oMap.put("ACIKLAMA", hznSpotfwdTx.getAciklama());
			oMap.put("TRY_KARSILIK", hznSpotfwdTx.getTryKarsilik());
			oMap.put("HAZINE_KUR", hznSpotfwdTx.getHazineKur());
			oMap.put("BAZ_FAIZ", hznSpotfwdTx.getBazFaiz());
			oMap.put("KARSI_FAIZ", hznSpotfwdTx.getKarsiFaiz());

			oMap.put("KARSILANAN_TUTAR", hznSpotfwdTx.getKarsilananTeminatTl());
			oMap.put("RISK_TEMINAT_TUTAR", hznSpotfwdTx.getRiskTeminatTutari());
			oMap.put("RISK_TEMINAT_ORAN", hznSpotfwdTx.getRiskTeminatOran());
			oMap.put("RISK_ISLEM_TIPI", hznSpotfwdTx.getRiskIslemTipi());
			
			oMap.put("SM_EH", GuimlUtil.convertToCheckBoxSelected(hznSpotfwdTx.getSmEh()));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
   
	@GraymoundService("BNSPR_TRN1316_MULTIPLY")
    public static GMMap mBigDecimal(GMMap iMap) {

		try{
	        BigDecimal item1 =  new BigDecimal( iMap.getString("ITEM1")==null?"0":iMap.getString("ITEM1"));
	        BigDecimal item2 =  new BigDecimal( iMap.getString("ITEM2")==null?"0":iMap.getString("ITEM2"));
	
	        return iMap.put("RESULT", item1.multiply(item2).setScale(2, RoundingMode.HALF_UP).toPlainString());
		}
		catch(Exception e)
		{
			return  iMap.put("RESULT",new BigDecimal(0));
		}
    }
	
	@GraymoundService("BNSPR_TRN1316_GET_ICON")
	public static Map<?, ?> getIcon(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			String urunSinifKod = "";
			BigDecimal hazineKur = new BigDecimal(0);
			BigDecimal alisKur = new BigDecimal(0);
			BigDecimal satisKur = new BigDecimal(0);
			BigDecimal parite = new BigDecimal(0);
			
			if(iMap.getString("URUN_SINIF_KOD") != null)
				urunSinifKod = iMap.getString("URUN_SINIF_KOD");
			if(iMap.getBigDecimal("HAZINE_KUR") != null)
				hazineKur = iMap.getBigDecimal("HAZINE_KUR");
			if(iMap.getBigDecimal("ALIS_KUR") != null)
				alisKur = iMap.getBigDecimal("ALIS_KUR");
			if(iMap.getBigDecimal("SATIS_KUR") != null)
				satisKur = iMap.getBigDecimal("SATIS_KUR");
			if(iMap.getBigDecimal("PARITE") != null)
				parite = iMap.getBigDecimal("PARITE");
			String icon = null;
			
			if(urunSinifKod.equals("") || hazineKur.compareTo(BigDecimal.ZERO) == 0) {
				icon = "icon/16/smiley.gif";
			}
			else if (urunSinifKod.equals("TP-YP-MUS") || urunSinifKod.equals("YP/TP-MUS")  ){
				if(satisKur.compareTo(BigDecimal.ZERO) == 0) {
					icon = "icon/16/smiley.gif";
				}
				else {
					if(hazineKur.compareTo(satisKur)>0){
						icon = "icon/16/cry2.gif";
					}
					else {
						icon = "icon/16/happy2.gif";
					}
				}					
			}
			else if (urunSinifKod.equals("YP-TP-MUS") || urunSinifKod.equals("TP/YP-MUS")  ){
				if(alisKur.compareTo(BigDecimal.ZERO) == 0) {
					icon = "icon/16/smiley.gif";
				}
				else {
					if(hazineKur.compareTo(alisKur)>0){
						icon = "icon/16/happy2.gif";
					}
					else {
						icon = "icon/16/cry2.gif";
					}
				}					
			}
			else if (urunSinifKod.equals("YP-YP-MUS") || urunSinifKod.equals("YP/YP-MUS") ){
			
				BigDecimal karZararTutar = new BigDecimal(0);
				if(iMap.getBigDecimal("KAR_ZARAR_TUTAR") != null)
					karZararTutar = iMap.getBigDecimal("KAR_ZARAR_TUTAR");
				if (karZararTutar.compareTo(BigDecimal.ZERO) == 0) {
					icon = "icon/16/smiley.gif";
				} else if (karZararTutar.compareTo(BigDecimal.ZERO) > 0 && karZararTutar.compareTo(new BigDecimal(2000)) <= 0) {
					icon = "icon/16/happy2.gif";
				} else if (karZararTutar.compareTo(new BigDecimal(2000)) > 0) {
					icon = "icon/16/BigSmile2.gif";
				} else if (karZararTutar.compareTo(BigDecimal.ZERO) < 0 && karZararTutar.compareTo(new BigDecimal(-2000)) > 0) {
					icon = "icon/16/cry2.gif";
				} else if (karZararTutar.compareTo(new BigDecimal(-2000)) < 0)  {
					icon = "icon/16/cryingsmiley.gif";
				}
				/*	if(parite.compareTo(BigDecimal.ZERO) == 0) {
					icon = "icon/16/smiley.gif";
				}
				else {
					if(hazineKur.compareTo(parite)>0){
						icon = "icon/16/cry2.gif";
					}
					else {
						icon = "icon/16/happy2.gif";
					}
				}	*/				
			}
			
			else{
				icon = "icon/16/smiley.gif";
			}
			/*
			if (karZararTutar.compareTo(BigDecimal.ZERO) == 0) {
				icon = "icon/16/smiley.gif";
			} else if (karZararTutar.compareTo(BigDecimal.ZERO) > 0 && karZararTutar.compareTo(new BigDecimal(2000)) <= 0) {
				icon = "icon/16/happy2.gif";
			} else if (karZararTutar.compareTo(new BigDecimal(2000)) > 0) {
				icon = "icon/16/BigSmile2.gif";
			} else if (karZararTutar.compareTo(BigDecimal.ZERO) < 0 && karZararTutar.compareTo(new BigDecimal(-2000)) > 0) {
				icon = "icon/16/cry2.gif";
			} else if (karZararTutar.compareTo(new BigDecimal(-2000)) < 0)  {
				icon = "icon/16/cryingsmiley.gif";
			}*/
			oMap.put("ICON", icon);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
