package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1306Services {

	@GraymoundService("BNSPR_TRN1306_SAVE")
	public static GMMap Save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			HznSpotfwdTxId id = null;

			if (hznSpotfwdTx == null) {
				hznSpotfwdTx = new HznSpotfwdTx();
				id = new HznSpotfwdTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setReferans(iMap.getString("TRX_NO"));
			}
			else {
				id = hznSpotfwdTx.getId();
			}

			hznSpotfwdTx.setId(id);
			hznSpotfwdTx.setModulTurKod("HAZINE");
			hznSpotfwdTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSpotfwdTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSpotfwdTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			
			//Ekrandan ons islem girildi�inde grama �evrilsin 
            if(iMap.getString("ONS_ISLEM") != null && iMap.getString("ONS_ISLEM").equalsIgnoreCase("true")){
            	hznSpotfwdTx.setOnsIslem("E");
            	onsHesaplama(iMap,hznSpotfwdTx);
            //NKolay ya da STP islemi ise           
            }else if(hznSpotfwdTx.getOrderId() != null && hznSpotfwdTx.getPlatformNo() !=null){
            	hznSpotfwdTx.setOnsIslem("H");
        		iMap.put("XAU_ALIS_ONS_MU", false);
				iMap.put("XAU_SATIS_ONS_MU", false);	
            }else{
            //default H
            	hznSpotfwdTx.setOnsIslem("H");
            }
			
			hznSpotfwdTx.setAlisTutari(iMap.getBigDecimal("ALIS_TUTARI"));
			hznSpotfwdTx.setAlisHesapTuru(iMap.getString("ALIS_HESAP_TURU"));
			hznSpotfwdTx.setAlisHesapNo(iMap.getBigDecimal("ALIS_HESAP_NO"));
			hznSpotfwdTx.setSatisTutari(iMap.getBigDecimal("SATIS_TUTARI"));
			hznSpotfwdTx.setSatisHesapTuru(iMap.getString("SATIS_HESAP_TURU"));
			hznSpotfwdTx.setSatisHesapNo(iMap.getBigDecimal("SATIS_HESAP_NO"));
			hznSpotfwdTx.setDealerNo((String) iMap.get("DEALER_NO"));
			hznSpotfwdTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSpotfwdTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSpotfwdTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSpotfwdTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSpotfwdTx.setAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			hznSpotfwdTx.setSatisKur(iMap.getBigDecimal("SATIS_KUR"));
			hznSpotfwdTx.setParite(iMap.getBigDecimal("PARITE"));
			hznSpotfwdTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznSpotfwdTx.setDurumKodu("A");
			hznSpotfwdTx.setAS(iMap.getString("AS"));
			if (iMap.getString("TRADING_PORTFOY").toString().equals("false"))
				hznSpotfwdTx.setTradingPortfoyu("H");
			else
				hznSpotfwdTx.setTradingPortfoyu("E");

			hznSpotfwdTx.setAlisMuhabirMusteriNo(iMap.getString("ALIS_MUHABIR_MUSTERI_NO"));
			hznSpotfwdTx.setSatisMuhabirMusteriNo(iMap.getString("SATIS_MUHABIR_MUSTERI_NO"));
			hznSpotfwdTx.setDigerReferans(iMap.getString("DIGER_REFERANS"));
			hznSpotfwdTx.setBazFaiz(iMap.getBigDecimal("BAZ_FAIZ"));
			hznSpotfwdTx.setKarsiFaiz(iMap.getBigDecimal("KARSI_FAIZ"));
			hznSpotfwdTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
									
			if (iMap.getString("XAU_ALIS_ONS_MU")!=null &&iMap.getString("XAU_ALIS_ONS_MU").equalsIgnoreCase("false")) {
				hznSpotfwdTx.setXauAlisOnsMu("H");
			}else {
				hznSpotfwdTx.setXauAlisOnsMu("E");
				hznSpotfwdTx.setXauAlisOnsMiktar(iMap.getBigDecimal("XAU_ALIS_ONS_MIKTAR"));
			}

			if (iMap.getString("XAU_SATIS_ONS_MU") != null && iMap.getString("XAU_SATIS_ONS_MU").equalsIgnoreCase("false")) {
				hznSpotfwdTx.setXauSatisOnsMu("H");
			}else {
				hznSpotfwdTx.setXauSatisOnsMu("E");
				hznSpotfwdTx.setXauSatisOnsMiktar(iMap.getBigDecimal("XAU_SATIS_ONS_MIKTAR"));
			}
			
			hznSpotfwdTx.setPlatformNo(iMap.getBigDecimal("PLATFORM_NO"));
			hznSpotfwdTx.setProviderAdi(iMap.getString("PROVIDER_ADI"));

			hznSpotfwdTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
			hznSpotfwdTx.setOrderId(iMap.getString("ORDER_ID"));
			hznSpotfwdTx.setMessageId(iMap.getString("MESSAGE_ID"));
			hznSpotfwdTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));

			session.saveOrUpdate(hznSpotfwdTx);
			session.flush();

			GMMap oMap = new GMMap();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}



	private static void onsHesaplama(GMMap iMap, HznSpotfwdTx hznSpotfwdTx) {
						
		if ("XAU;XAG".contains(iMap.getString("ALIS_DOVIZ_KODU")) && iMap.getString("SATIS_DOVIZ_KODU").equalsIgnoreCase("TRY")){			
			
			iMap.put("XAU_ALIS_ONS_MIKTAR", iMap.getBigDecimal("ALIS_TUTARI"));
			hznSpotfwdTx.setOnsAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			
			BigDecimal grFiyat = iMap.getBigDecimal("ALIS_KUR").divide(new BigDecimal("31.1035"), 8, RoundingMode.HALF_UP);
			iMap.put("ALIS_KUR", grFiyat);
			
			iMap.put("ALIS_TUTARI", iMap.getBigDecimal("SATIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));
			iMap.put("XAU_ALIS_ONS_MU", true);
			iMap.put("XAU_SATIS_ONS_MU", false);		
			
		}else if("XAU;XAG".contains(iMap.getString("SATIS_DOVIZ_KODU")) && iMap.getString("ALIS_DOVIZ_KODU").equalsIgnoreCase("TRY")){			
			
			iMap.put("XAU_SATIS_ONS_MIKTAR", iMap.getBigDecimal("SATIS_TUTARI"));
			hznSpotfwdTx.setOnsSatisKur(iMap.getBigDecimal("SATIS_KUR"));
		
			BigDecimal grFiyat = iMap.getBigDecimal("SATIS_KUR").divide(new BigDecimal("31.1035"), 8, RoundingMode.HALF_UP);
			iMap.put("SATIS_KUR", grFiyat);
					
			iMap.put("SATIS_TUTARI", iMap.getBigDecimal("ALIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));					
			iMap.put("XAU_ALIS_ONS_MU", false);
			iMap.put("XAU_SATIS_ONS_MU", true);
			
		}else{		
			
			BigDecimal grFiyat = iMap.getBigDecimal("PARITE").divide(new BigDecimal("31.1035"), 8, RoundingMode.HALF_UP);
			hznSpotfwdTx.setOnsParite(iMap.getBigDecimal("PARITE"));
			iMap.put("PARITE", grFiyat);				

			if ("XAU;XAG".contains(iMap.getString("ALIS_DOVIZ_KODU"))){		
				iMap.put("XAU_ALIS_ONS_MU", true);
				iMap.put("XAU_SATIS_ONS_MU", false);
				iMap.put("XAU_ALIS_ONS_MIKTAR", iMap.getBigDecimal("ALIS_TUTARI"));
				iMap.put("ALIS_TUTARI", iMap.getBigDecimal("SATIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));
				
			}else{				
				iMap.put("XAU_ALIS_ONS_MU", false);
				iMap.put("XAU_SATIS_ONS_MU", true);
				iMap.put("XAU_SATIS_ONS_MIKTAR", iMap.getBigDecimal("SATIS_TUTARI"));
				iMap.put("SATIS_TUTARI", iMap.getBigDecimal("ALIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));
			}
	
		}	
		
	}

	@GraymoundService("BNSPR_TRN1306_TRANSACTION_START")
	public static Map<?, ?> trn1306Transactionstart(GMMap iMap) {

		try {
			iMap.put("TRX_NAME", "1306");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1306_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(3, "S");
			stmt.setString(4, iMap.getString("NETTING_MI"));
			stmt.execute();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1306_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();

			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();

			oMap.put("TX_NO", hznSpotfwdTx.getId().getTxNo());
			oMap.put("REF_NO", hznSpotfwdTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSpotfwdTx.getUrunTurKod(), "1306/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznSpotfwdTx.getAlisTutari());
			oMap.put("ALIS_HESAP_TURU", hznSpotfwdTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznSpotfwdTx.getSatisTutari());
			oMap.put("SATIS_HESAP_TURU", hznSpotfwdTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznSpotfwdTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznSpotfwdTx.getSatisKur());
			oMap.put("PARITE", hznSpotfwdTx.getParite());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSpotfwdTx.getDealerNo(), "1306/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSpotfwdTx.getBankaMusteriNo(), "1306/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getAlisHesapNo(), hznSpotfwdTx.getAlisDovizKodu(), hznSpotfwdTx.getAlisHesapTuru(), hznSpotfwdTx.getAlisDovizKodu(), hznSpotfwdTx.getAlisHesapTuru(), hznSpotfwdTx.getBankaMusteriNo(), "1306/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getSatisHesapNo(), hznSpotfwdTx.getSatisDovizKodu(), hznSpotfwdTx.getSatisHesapTuru(), hznSpotfwdTx.getSatisDovizKodu(), hznSpotfwdTx.getSatisHesapTuru(), hznSpotfwdTx.getBankaMusteriNo(), "1306/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("AS", hznSpotfwdTx.getAS());
			oMap.put("ACIKLAMA", hznSpotfwdTx.getAciklama());
			if (hznSpotfwdTx.getTradingPortfoyu().toString().equals("H"))
				oMap.put("TRADING_PORTFOY", "false");
			else
				oMap.put("TRADING_PORTFOY", "true");

			oMap.put("ALIS_MUHABIR_MUSTERI_NO", hznSpotfwdTx.getAlisMuhabirMusteriNo());
			oMap.put("SATIS_MUHABIR_MUSTERI_NO", hznSpotfwdTx.getSatisMuhabirMusteriNo());
			oMap.put("DIGER_REFERANS", hznSpotfwdTx.getDigerReferans());
			oMap.put("BAZ_FAIZ", hznSpotfwdTx.getBazFaiz());
			oMap.put("KARSI_FAIZ", hznSpotfwdTx.getKarsiFaiz());
			oMap.put("ISTATISTIK_KODU", hznSpotfwdTx.getIstatistikKodu());
			oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznSpotfwdTx.getIstatistikKodu(), "1306/LOV_ISTATISTIK", "ACIKLAMA"));

			if (hznSpotfwdTx.getXauAlisOnsMu() != null && hznSpotfwdTx.getXauAlisOnsMu().equals("H"))
				oMap.put("XAU_ALIS_ONS_MU", "false");
			else
				oMap.put("XAU_ALIS_ONS_MU", "true");
			if (hznSpotfwdTx.getXauSatisOnsMu() != null && hznSpotfwdTx.getXauSatisOnsMu().equals("H"))
				oMap.put("XAU_SATIS_ONS_MU", "false");
			else
				oMap.put("XAU_SATIS_ONS_MU", "true");
			oMap.put("XAU_ALIS_ONS_MIKTAR", hznSpotfwdTx.getXauAlisOnsMiktar());
			oMap.put("XAU_SATIS_ONS_MIKTAR", hznSpotfwdTx.getXauSatisOnsMiktar());

			oMap.put("ONS_ISLEM", hznSpotfwdTx.getOnsIslem());
			
			if (hznSpotfwdTx.getOnsIslem() != null && hznSpotfwdTx.getOnsIslem().equals("E")){			
				if(hznSpotfwdTx.getAlisDovizKodu().equalsIgnoreCase("TRY")){
					oMap.put("SATIS_TUTARI", hznSpotfwdTx.getXauSatisOnsMiktar());
					oMap.put("SATIS_KUR", hznSpotfwdTx.getOnsSatisKur());

				}else if(hznSpotfwdTx.getSatisDovizKodu().equalsIgnoreCase("TRY")){
					oMap.put("ALIS_TUTARI", hznSpotfwdTx.getXauAlisOnsMiktar());
					oMap.put("ALIS_KUR", hznSpotfwdTx.getOnsAlisKur());

				}else{
					oMap.put("PARITE", hznSpotfwdTx.getOnsParite());
					if("XAU;XAG".contains(hznSpotfwdTx.getAlisDovizKodu())){
						oMap.put("ALIS_TUTARI", hznSpotfwdTx.getXauAlisOnsMiktar());
					}else{
						oMap.put("SATIS_TUTARI", hznSpotfwdTx.getXauSatisOnsMiktar());
					}					
				}		
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1306_ALISSATIS_TUTARI_HESAPLA")
	public static GMMap alisSatisTutariHesapla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN1306.alissatis_tutari_hesapla(?,?,?,?,?,?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("ALIS_DOVIZ_KOD"));
			if (iMap.getBigDecimal("ALIS_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_KUR"));
			stmt.setString(i++, iMap.getString("SATIS_DOVIZ_KOD"));
			if (iMap.getBigDecimal("SATIS_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_KUR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("PARITE"));
			stmt.execute();
			oMap.put("TUTAR", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1306_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_HZN_SWIFT.EFT_OLUSTUR(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();

			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1306_MUKERRER_KONTROLU")
	public static GMMap MukerrerKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1306.Mukerrer_Kontrolu(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("ALIS_TUTARI"));
			if (iMap.getString("ALIS_HESAP_TURU") == null)
				stmt.setString(3, null);
			else
				stmt.setString(3, iMap.getString("ALIS_HESAP_TURU"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("ALIS_KUR"));
			stmt.setString(5, iMap.getString("ALIS_DOVIZ_KODU"));
			stmt.setBigDecimal(6, iMap.getBigDecimal("SATIS_TUTARI"));
			if (iMap.getString("SATIS_HESAP_TURU") == null)
				stmt.setString(7, null);
			else
				stmt.setString(7, iMap.getString("SATIS_HESAP_TURU"));
			stmt.setBigDecimal(8, iMap.getBigDecimal("SATIS_KUR"));
			stmt.setString(9, iMap.getString("SATIS_DOVIZ_KODU"));
			if (iMap.getDate("VALOR_TARIHI") == null)
				stmt.setDate(10, null);
			else
				stmt.setDate(10, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			if (iMap.getBigDecimal("PARITE") == null)
				stmt.setBigDecimal(11, null);
			else
				stmt.setBigDecimal(11, iMap.getBigDecimal("PARITE"));
			if (iMap.getString("AS") == null)
				stmt.setString(12, null);
			else
				stmt.setString(12, iMap.getString("AS"));
			stmt.setString(14, iMap.getString("TX_NO"));
			stmt.registerOutParameter(13, Types.VARCHAR);
			stmt.registerOutParameter(14, Types.VARCHAR);

			stmt.execute();
			oMap.put("REFERANS_NO", stmt.getString(13));
			oMap.put("ISLEM_NO", stmt.getString(14));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1306_NETTING_SWIFT_KONTROLU")
	public static GMMap NettingSwiftKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1306.Netting_Swift_Kontrolu(?,?,?,?,?) }");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			stmt.setString(2, iMap.getString("URUN_TUR_KOD"));
			stmt.setString(3, iMap.getString("SATIS_DOVIZ_KODU"));
			stmt.setString(4, iMap.getString("SATIS_HESAP_TURU"));

			stmt.registerOutParameter(5, Types.VARCHAR);

			stmt.execute();
			oMap.put("NETTING_MI", stmt.getString(5));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}
}
