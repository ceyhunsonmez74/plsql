package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import org.hibernate.Session;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznCurEffTalepTx;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1360Services {

	@GraymoundService("BNSPR_TRN1360_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznCurEffTalepTx hznCurEffTalepTx = (HznCurEffTalepTx)session.get(HznCurEffTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznCurEffTalepTx == null) {
				hznCurEffTalepTx = new HznCurEffTalepTx();
			}
			hznCurEffTalepTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznCurEffTalepTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznCurEffTalepTx.setDurumKodu("A");
			hznCurEffTalepTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznCurEffTalepTx.setDovizKodu(iMap.getString("DOVIZKODU"));
			hznCurEffTalepTx.setIslemTipi(iMap.getString("ISLEMTIPI"));
			hznCurEffTalepTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznCurEffTalepTx.setUrunSinifKod(iMap.getString("URUNSINIFKOD"));
			hznCurEffTalepTx.setUrunTurKod(iMap.getString("URUNTURKOD"));
			hznCurEffTalepTx.setModulTurKod("HAZINE");
			hznCurEffTalepTx.setSubeKodu(iMap.getString("SUBE_KODU"));
			hznCurEffTalepTx.setRefNo(iMap.getString("REFERANS"));
			
			session.saveOrUpdate(hznCurEffTalepTx);
			session.flush();
			iMap.put("TRX_NAME", "1360");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_TRN1360_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznCurEffTalepTx hznCurEffTalepTx = (HznCurEffTalepTx)session.get(HznCurEffTalepTx.class, txNo);
			
			oMap.put("TRX_NO", hznCurEffTalepTx.getTxNo());
			oMap.put("DOVIZ_KODU", hznCurEffTalepTx.getDovizKodu());
			oMap.put("ACIKLAMA", hznCurEffTalepTx.getAciklama());
			oMap.put("ISLEMTIPI", hznCurEffTalepTx.getIslemTipi());
			oMap.put("TUTAR", hznCurEffTalepTx.getTutar());
			oMap.put("URUNSINIFKOD", hznCurEffTalepTx.getUrunSinifKod());
			oMap.put("URUNTURKOD", hznCurEffTalepTx.getUrunTurKod());
			oMap.put("VALORTARIHI", hznCurEffTalepTx.getValorTarihi());
			oMap.put("SUBE_KODU", hznCurEffTalepTx.getSubeKodu());
			
			oMap.put("ACIKLAMA", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "ACIKLAMA" ));
			oMap.put("IL_KODU", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "IL_KODU" ));
			oMap.put("IL_ADI", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "IL_ADI" ));
			oMap.put("ILCE_KODU", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "ILCE_KODU" ));
			oMap.put("ILCE_ADI", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "ILCE_ADI" ));
			
			oMap.put("REFERANS", hznCurEffTalepTx.getRefNo());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
