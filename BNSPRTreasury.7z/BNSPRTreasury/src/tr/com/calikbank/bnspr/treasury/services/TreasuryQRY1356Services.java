package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1356Services {
	
	@GraymoundService("BNSPR_QRY1356_HZN_CASH_FLOW_OZET")
	public static GMMap getCashFlowOzet(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_RC1356.RC_QRY1356_Cash_Flow_Ozet(?,?,?,?,?,?,?,?)}");
			int i=1;
			
			
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++ , iMap.getString("NOSTRO_VOSTRO"));
			stmt.setString(i++ , iMap.getString("YURTICI_YURTDISI"));
			
			
			if (iMap.getString("SIFIRLI_BAKIYE").equals("true"))
                stmt.setString(i++ , null);
            else stmt.setString(i++ , iMap.getString("SIFIRLI_BAKIYE"));
		    
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			  
			rSet = (ResultSet)stmt.getObject(--i);
			
	
			String tableName = "NAKIT_BILGILERI_DETAY";
			int j = 0;
			java.math.BigDecimal girisCikisTotal = new java.math.BigDecimal("0");
			
       
			while (rSet.next()){
				oMap.put(tableName , j , "MUHABIR_HESAP_NO" , rSet.getString("MUHABIR_HESAP"));
				oMap.put(tableName , j , "MUHABIR_ADI" 		, rSet.getString("MUHABIR_ADI"));
				oMap.put(tableName , j , "MUSTERI_NO" 		, rSet.getString("MUSTERI_NO"));
				oMap.put(tableName , j , "DOVIZ" 		, rSet.getString("DOVIZ"));
				oMap.put(tableName , j ,  "NETTUTAR"		,rSet.getString("TUTAR"));
				oMap.put(tableName , j ,  "TUTAR1"		,rSet.getString("TUTAR1"));
				oMap.put(tableName , j ,  "TUTAR2"		,rSet.getString("TUTAR2"));
				
			j++; 
		}	
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	 @GraymoundService("BNSPR_QRY1356_DOVIZ_KURU_BAKIYE")
    public static GMMap getTotalCurrencyAmounts(GMMap iMap){
	       Connection conn = null;
	       CallableStatement stmt = null;
	       ResultSet rSet = null;
	       GMMap oMap = new GMMap();
	        try{
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{ call PKG_RC1356.RC_QRY1356_Total_Curr_Amount(?,?,?,?,?,?,?,?)}");
	            int i=1;
	            
	            
	            if(iMap.getDate("TARIH")==null)
	                stmt.setDate(i++, null);
	            else
	                stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
	            
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
	            stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
	            stmt.setString(i++ , iMap.getString("NOSTRO_VOSTRO"));
	            stmt.setString(i++ , iMap.getString("YURTICI_YURTDISI"));
	            	            
	            if (iMap.getString("SIFIRLI_BAKIYE").equals("true"))
	                stmt.setString(i++ , null);
	            else stmt.setString(i++ , iMap.getString("SIFIRLI_BAKIYE"));
	            
	            stmt.registerOutParameter(i++, -10);
	            stmt.execute();
	              
	            rSet = (ResultSet)stmt.getObject(--i);
	            
	    
	            String tableName = "DOVIZ_KURU_BAKIYE";
	            int j = 0;
	            
	            while (rSet.next()){
	                oMap.put(tableName , j , "DOVIZ_KURU" , rSet.getString("DOVIZ"));
	                oMap.put(tableName , j , "T_VALOR"      , rSet.getString("TUTAR"));
	                oMap.put(tableName , j , "T1_VALOR"       , rSet.getString("TUTAR1"));
	                oMap.put(tableName , j , "T2_VALOR"        , rSet.getString("TUTAR2"));
	            j++; 
	        }   
	            
	            return oMap;
	            
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
	    
	
	
	
	@GraymoundService("BNSPR_QRY1356_HZN_CASH_FLOW_G_OZET")
	public static GMMap getCashFlowGunlukOzet(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1356.RC_QRY1356_Cash_Flow_G_Ozet1(?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
		//	stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "GUNLUK_OZET");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1356_HZN_CASH_FLOW_G_OZET_DETAY")
	public static GMMap getCashFlowGunlukOzetDetay(GMMap iMap){
	    
	    Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1356.RC_QRY1356_Cash_Flow_G_Ozet2(?,?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "GUNLUK_OZET_DETAY");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);  	
			}
	}
	
	@GraymoundService("BNSPR_QRY1356_HZN_CASH_FLOW_OZET_DTY")
	public static GMMap getCashFlowOzetDty(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1356.RC_QRY1356_Cash_Flow_Ozet_Dty(?,?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CASH_FLOW_OZET_DTY");
			
			String listName = "TUR";
			GuimlUtil.wrapMyCombo(oMap, listName, "GIRIS", "Giri�");
			GuimlUtil.wrapMyCombo(oMap, listName, "CIKIS", "��k��");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_ORY1356_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
			try{
				GMMap oMap = new GMMap();
				iMap.put("KOD", "NOSTRO_VOSTRO");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("NOSTRO_VOSTRO", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				iMap.put("KOD", "YURTICI_YURTDISI_DURUM");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("YURTICI_YURTDISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
								
								
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
	
}
