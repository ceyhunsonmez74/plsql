package tr.com.calikbank.bnspr.treasury.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryUtil {

	public static Date trimDate(Date date) {
		if(date == null)
			return null;
		GregorianCalendar trimmed = new GregorianCalendar();
		trimmed.setTime(date);
		trimmed.set(Calendar.HOUR_OF_DAY, 0);
		trimmed.set(Calendar.MINUTE, 0);
		trimmed.set(Calendar.SECOND, 0);
		trimmed.set(Calendar.MILLISECOND, 0);
		return trimmed.getTime();
	}
	
	public static BigDecimal differenceTwoDateByDay(Date date1, Date date2){
		long diffInMillies = Math.abs(date1.getTime() - date2.getTime());
		BigDecimal days = new BigDecimal(TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS));
	    return days;
	}
	
	public static BigDecimal differenceTwoDateByMonth(Date date1, Date date2){
		long diffInMillies = Math.abs(date1.getTime() - date2.getTime());
		BigDecimal days = new BigDecimal(TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS));
	    BigDecimal months = days.divide(new BigDecimal(30), 2, RoundingMode.UP);
	    return months;
	}
	
	/**
	 * M��terinin ileti�im numaras�n� d�nd�r�r. 
	 * @param musteriNo
	 * @return
	 */
	public static String iletisimNumarasi(String musteriNo){
		GMMap oMap = new GMMap();
		oMap.put("TELNO", DALUtil.callOneParameterFunction("{? = call pkg_musteri.iletisim_telefon(?)}", Types.VARCHAR, musteriNo));
		return oMap.getString("TELNO");
	}
	/**
	 * Hesab�n d�viz kodunu verir.
	 * @param hesapNo
	 * @return
	 */
	public static String hesapDovizKodu(String hesapNo){
		GMMap oMap = new GMMap();
		oMap.put("DOVIZ_KODU", DALUtil.callOneParameterFunction("{? = call pkg_hesap.doviz_kodu(?)}", Types.VARCHAR, hesapNo));
		return oMap.getString("DOVIZ_KODU");
	}

	/**
	 * Parametrik mesajdan mesaj almak i�in kullan�l�r.
	 * @param messageNo
	 * @param p1
	 * @param p2
	 * @param p3
	 * @param p4
	 * @return
	 */
	public static String getMessage(Integer messageNo, String p1, String p2, String p3) {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			/*
			 * pkg_hata.mesajolustur cagrilir
			 */
			int i = 1;

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_hata.mesajolustur(?,?,?,?)}");

			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, new BigDecimal(messageNo));
			stmt.setString(i++, p1);
			stmt.setString(i++, p2);
			stmt.setString(i++, p3);
			stmt.execute();

			return stmt.getString(1);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap paramAlStr(String keyName) {
		GMMap oMap = new GMMap();
		oMap.put("DEGER", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K('" + keyName + "')}", Types.VARCHAR));
		return oMap;
	}

	public static GMMap paramAlNumber(String keyName) {
		GMMap oMap = new GMMap();
		oMap.put("DEGER", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('" + keyName + "')}", Types.NUMERIC));
		return oMap;
	}

	public static boolean validateEmail(String email) {
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return email.matches(regex);
	}
	
	public static GMMap callErrorMessage(String message){
		GMMap oMap = new GMMap();
		oMap.put("HATA_NO", new BigDecimal(660));
        oMap.put("P1", message);
        return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
	}
	
	public static BigDecimal getGenelKodAl(String kodAdi) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_GENEL_PR.GENEL_KOD_AL(?)}");

			stmt.registerOutParameter(1, Types.INTEGER);
			stmt.setString(2, kodAdi);
			stmt.execute();

			BigDecimal siraNo = stmt.getBigDecimal(1);

			return siraNo;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static String getParamText(String kod, String key, String key2, String key3){
		GMMap iMap = new GMMap();
		iMap.put("KOD", kod);
		iMap.put("KEY", key);
		iMap.put("KEY2", key2);
		iMap.put("KEY3", key3);
		
		
		String param = ParameterCache.getParameter(kod+';'+key+';'+key2+';'+key3);
		
		
		if(param.equalsIgnoreCase("")){
			return null;
		}
		return param;

//		return GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap).getString("TEXT");
		
	}
	
	private static class ParameterCache{
		
		private static LoadingCache<String, String> cache;
		
		static{
			CacheLoader<String, String> loader = new CacheLoader<String, String>() {
				@Override
				public String load(String key) {
					String[] arr = key.split(";");	
					boolean isKey3 = true;
				    GnlParamText parametre;
					if (arr[3].equalsIgnoreCase("null")){
						isKey3= false;
					}
					
		            Session session = DAOSession.getSession("BNSPRDal");

					if(isKey3){
				         parametre = (GnlParamText) session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", arr[0]))		            		
			            		.add(Restrictions.eq("key1", arr[1]))
			            				.add(Restrictions.eq("key2", arr[2]))
			            						.add(Restrictions.eq("key3", arr[3])
			            					            ).uniqueResult();

					}else{
				         parametre = (GnlParamText) session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", arr[0]))		            		
			            		.add(Restrictions.eq("key1", arr[1]))
			            				.add(Restrictions.eq("key2", arr[2])
			            					            ).uniqueResult();


					}
					
					if(parametre == null || parametre.getText() == null){
						return "";
					}else{
				         return   parametre.getText();

					}
													}

			
			};

			cache = CacheBuilder.newBuilder()
								.expireAfterWrite(5, TimeUnit.MINUTES) // 5 dakikada bir cache degeri yenilensin
								.build(loader);
		}
		
		public static String getParameter(String key){
			String paramValue = cache.getUnchecked(key);
			return paramValue;
		}
	}
}
