package tr.com.calikbank.bnspr.treasury.services;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ZkYukumluluk;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TreasuryQRY1341Services {

	public enum Durum {
	    Beklemede("B"),
	    Onay("O"),
	    Kesinle�ti("K");	    
	    
	    private String key;

	    Durum(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}
	
	public enum IslemDurum {
	    Beklemede("B"),
	    Tamamland�("T");	    
	    
	    private String key;

	    IslemDurum(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}
	public enum IslemTipi {
	    Yat�rma("Y"),
	    �ekme("�");      
	    
	    private String key;

	    IslemTipi(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}
	public enum EftDurum {
	    Evet("E"),
	    Hay�r("H");      
	    
	    private String key;

	    EftDurum(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}

	@GraymoundService("BNSPR_QRY1341_GET_BY_VALOR_DATE")
	public static GMMap getByValorDate1340(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			Criteria criteria = session.createCriteria(ZkYukumluluk.class);
			criteria.setProjection(Projections.distinct(Projections.property("id.zkTarihi")));
			List<Timestamp> list = criteria.add(Restrictions.between("id.zkTarihi", iMap.getDate("VALOR_TARIHI_BAS"), iMap.getDate("VALOR_TARIHI_BIT"))).addOrder(Order.asc("id.zkTarihi")).list();
			
			GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_TARIHI", null, " ");
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy");
			for (Timestamp date : list) {
				String zkTarihi = sd.format(new Date(date.getTime()));
				GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_TARIHI", zkTarihi, zkTarihi);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY1341_GET_INFO_BY_TRX_DATE")
	public static GMMap getInfoByTrxDate1341(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String islemTarihi = iMap.getString("ISLEM_TARIHI");
			if (islemTarihi != null) {
				String[] dList = islemTarihi.split("/");
				int day = Integer.parseInt(dList[0]);
				int month = Integer.parseInt(dList[1]);
				int year = Integer.parseInt(dList[2]);
				Calendar cal = Calendar.getInstance();
				cal.set(year, month - 1, day);
				List<ZkYukumluluk> list = session.createCriteria(ZkYukumluluk.class).add(Restrictions.eq("id.zkTarihi", TreasuryUtil.trimDate(cal.getTime()))).addOrder(Order.asc("sira")).list();

				Iterator<ZkYukumluluk> it = list.iterator();
				ZkYukumluluk zkYukumluluk = null;
				int rowYP = 0;
				int rowTL = 0;
				String tableName = null;
				while (it.hasNext()) {
					zkYukumluluk = it.next();
					if (zkYukumluluk.getTipi().equals("TL")) {
						tableName = "TL_LISTE";
						oMap.put(tableName, rowTL, "ISLEM_TARIHI", zkYukumluluk.getId().getZkTarihi());
						oMap.put(tableName, rowTL, "ZK_ADI", zkYukumluluk.getZkAdi());
						oMap.put(tableName, rowTL, "MIZAN_DK", zkYukumluluk.getMizanDk());
						oMap.put(tableName, rowTL, "ESKI_DONEM_A", zkYukumluluk.getEskiDonemA());
						oMap.put(tableName, rowTL, "YENI_DONEM_B", zkYukumluluk.getYeniDonemB());
						oMap.put(tableName, rowTL, "DURUM_B", getDurumText(zkYukumluluk.getDurumB()));
						oMap.put(tableName, rowTL, "YENI_DONEM_C", zkYukumluluk.getYeniDonemC());
						oMap.put(tableName, rowTL, "DURUM_C", getDurumText(zkYukumluluk.getDurumC()));
						oMap.put(tableName, rowTL, "NETLESEN_TUTAR", zkYukumluluk.getNetlesenTutar());
						oMap.put(tableName, rowTL, "ISLEM_TIPI", getIslemTipiValue(zkYukumluluk.getIslemTipi()));
						oMap.put(tableName, rowTL, "VALOR_TARIHI", zkYukumluluk.getValorTarihi());
						oMap.put(tableName, rowTL, "DURUM", getIslemDurum(zkYukumluluk.getDurum()));
						oMap.put(tableName, rowTL, "EFT", getEftDurum(zkYukumluluk.getEftFlag()));
						oMap.put(tableName, rowTL, "DOVIZ_KODU", zkYukumluluk.getDovizKodu());
						oMap.put(tableName, rowTL, "DURUM_D", getDurumText(zkYukumluluk.getDurumD()));
						rowTL++;
					}
					else {
						tableName = "YP_LISTE";
						oMap.put(tableName, rowYP, "ISLEM_TARIHI", zkYukumluluk.getId().getZkTarihi());
						oMap.put(tableName, rowYP, "ZK_ADI", zkYukumluluk.getZkAdi());
						oMap.put(tableName, rowYP, "MIZAN_DK", zkYukumluluk.getMizanDk());
						oMap.put(tableName, rowYP, "ESKI_DONEM_A", zkYukumluluk.getEskiDonemA());
						oMap.put(tableName, rowYP, "YENI_DONEM_B", zkYukumluluk.getYeniDonemB());
						oMap.put(tableName, rowYP, "DURUM_B", getDurumText(zkYukumluluk.getDurumB()));
						oMap.put(tableName, rowYP, "YENI_DONEM_C", zkYukumluluk.getYeniDonemC());
						oMap.put(tableName, rowYP, "DURUM_C", getDurumText(zkYukumluluk.getDurumC()));
						oMap.put(tableName, rowYP, "NETLESEN_TUTAR", zkYukumluluk.getNetlesenTutar());
						oMap.put(tableName, rowYP, "ISLEM_TIPI", getIslemTipiValue(zkYukumluluk.getIslemTipi()));
						oMap.put(tableName, rowYP, "VALOR_TARIHI", zkYukumluluk.getValorTarihi());
						oMap.put(tableName, rowYP, "DURUM", getIslemDurum(zkYukumluluk.getDurum()));
						oMap.put(tableName, rowYP, "EFT", getEftDurum(zkYukumluluk.getEftFlag()));
						oMap.put(tableName, rowYP, "DOVIZ_KODU", zkYukumluluk.getDovizKodu());
						oMap.put(tableName, rowYP, "DURUM_D", getDurumText(zkYukumluluk.getDurumD()));
						rowYP++;
					}
				}
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static String getIslemDurum(String durum) {
		if (durum.equals(IslemDurum.Tamamland�.key))
			return IslemDurum.Tamamland�.toString();
		return IslemDurum.Beklemede.toString();
	}

 

	private static String getDurumText(String durum) {
		if (durum != null)
			if (durum.equals(Durum.Beklemede.key)) {
				return Durum.Beklemede.toString();
			}
			else if (durum.equals(Durum.Onay.key)) {
				return Durum.Onay.toString();
			}
			else if (durum.equals(Durum.Kesinle�ti.key)) {
				return Durum.Kesinle�ti.toString();
			}
		return Durum.Beklemede.toString();
	}
 

	private static String getIslemTipiValue(String islemTipi) {
		if (islemTipi != null && islemTipi.equals(IslemTipi.Yat�rma.key)) {
			return IslemTipi.Yat�rma.toString();
		}
		else {
			return IslemTipi.�ekme.toString();
		}
	}
	
	
	private static String getEftDurum(String eft) {
		if(eft != null && eft.equals(EftDurum.Evet.key))
			return EftDurum.Evet.toString();
		return EftDurum.Hay�r.toString();
	}


}
