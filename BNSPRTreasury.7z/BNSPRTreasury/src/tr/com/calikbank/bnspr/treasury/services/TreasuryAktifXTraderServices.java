package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.content.creator.pdf.model.nkolayfx.BankaBilgileri;
import tr.com.aktifbank.bnspr.dao.CariArbitrajTx;
import tr.com.aktifbank.bnspr.dao.HznBloombergBankaMust;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.CariDthDovizSatisTx;
import tr.com.calikbank.bnspr.dao.CariDthTlOdemeTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwd;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.treasury.util.ServiceUtil;
import tr.com.calikbank.bnspr.treasury.util.TreasuryConstant;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryAktifXTraderServices {

	@GraymoundService("BNSPR_AKTIFX_TRADER_HESAP_BAKIYE")
	public static GMMap getHesapBakiye(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", 0);
    	oMap.put("RESPONSE_DATA", "");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("MUSTERI_NO"),1,"M��teri No giriniz.");
		if(!oMap.getString("RESPONSE").equals("0")){
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_HESAP_BAKIYE", iMap, oMap);
			return oMap;
		}
		try {
			String func = "{? = call PKG_AKTIFX_TRADER.hesap_bakiye_getir(?,?,?,?) }";
			Object[] inputValues = {
                    BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
                    BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
                    BnsprType.NUMBER, iMap.getBigDecimal("HESAP_NO"),
                    BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_KODU"),
                };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "HESAP_LISTESI", inputValues));
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_HESAP_BAKIYE", iMap, oMap);
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_HESAP_BAKIYE", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_AKTIFX_TRADER_BLOKE")
	public static GMMap setBloke(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		oMap.put("RESPONSE", 0);
    	oMap.put("RESPONSE_DATA", "");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("MUSTERI_NO"),1,"M��teri No giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("HESAP_NO"),2,"Hesap No giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("TUTAR"),3,"Tutar giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("ALIS_DOVIZ_KODU"),3,"Al�� D�viz Kodu giriniz.");
    	iMap.put("ALIS_TUTARI",iMap.getBigDecimal("TUTAR"));
		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2011_VERGI_HESAPLA", iMap));
		if(iMap.getBigDecimal("VERGI_TUTARI").compareTo(BigDecimal.ZERO) > 0){
			iMap.put("TUTAR",iMap.getBigDecimal("ALIS_TUTARI").add(iMap.getBigDecimal("VERGI_TUTARI")));
		}
		checkAccountBalance(oMap, iMap);
		if(!oMap.getString("RESPONSE").equals("0")){
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_BLOKE", iMap, oMap);
			return oMap;
		}
		try {			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_AKTIFX_TRADER.bloke_ekle(?,?,?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("BLOKE_NO"));
			stmt.execute();
			oMap.put("BLOKE_NO", stmt.getString(1));
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_BLOKE", iMap, oMap);
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_BLOKE", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	private static void checkAccountBalance(GMMap oMap, GMMap iMap) {
		iMap.put("SATIS_DOVIZ_KODU", TreasuryUtil.hesapDovizKodu(iMap.getString("HESAP_NO")));
		iMap.put("ISLEM_KODU", setIslemKodu(iMap));
		iMap.putAll(GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_HESAP_BAKIYE", iMap));
		if(iMap.getBigDecimal("TUTAR").compareTo(iMap.getBigDecimal("HESAP_LISTESI",0,"BAKIYE")) > 0){
			oMap.put("RESPONSE", "29");
        	oMap.put("RESPONSE_DATA", "Bloke Tutar� bakiyeden fazlad�r.");
		}else if(iMap.getBigDecimal("TUTAR").compareTo(iMap.getBigDecimal("HESAP_LISTESI",0,"BAKIYE_KMH_ISLEM")) > 0){
			oMap.put("RESPONSE", "37");
        	oMap.put("RESPONSE_DATA", TreasuryUtil.getMessage(5954, iMap.getBigDecimal("HESAP_LISTESI",0,"BAKIYE_KMH_ISLEM").toString(), iMap.getString("SATIS_DOVIZ_KODU"), null));
		}
	}

	private static BigDecimal setIslemKodu(GMMap iMap) {
		String satisDovizKodu = iMap.getString("SATIS_DOVIZ_KODU");
		String alisDovizKodu = iMap.getString("ALIS_DOVIZ_KODU");
		String islemKodu = null;
		if(satisDovizKodu.equals("TRY")){
			islemKodu = TreasuryConstant.IslemKodu.DOVIZ_SATIS.getCode();
		}else if(alisDovizKodu.equals("TRY")){
			islemKodu = TreasuryConstant.IslemKodu.DOVIZ_ALIS.getCode();
		}else{
			islemKodu = TreasuryConstant.IslemKodu.DOVIZ_ARBITRAJ.getCode();
		}
		return new BigDecimal(islemKodu);
	}

	@GraymoundService("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE")
	public static GMMap removeBloke(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		oMap.put("RESPONSE", 0);
    	oMap.put("RESPONSE_DATA", "");
    	ServiceUtil.checkInput(oMap, iMap.getString("BLOKE_NO"),4,"Bloke No giriniz.");
		if(!oMap.getString("RESPONSE").equals("0")){
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE", iMap, oMap);
			return oMap;
		}
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_bloke.sp_bloke_kaldir(?) }");
			int i = 1;
			stmt.setString(i++, iMap.getString("BLOKE_NO"));
			stmt.execute();
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE", iMap, oMap);
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_AKTIFX_TRADER_MUSTERI_ISLEM_AKTARIM")
	public static GMMap saveMusteriIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", 0);
    	oMap.put("RESPONSE_DATA", "");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("MUSTERI_NO"),1,"M��teri No giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ALIM_HESAP_NO"),5,"Al�m Hesap No giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("SATIM_HESAP_NO"),6,"Sat�m Hesap No giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_YONU"),7,"��lem Y�n� giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("TUTAR"),3,"Tutar giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("FIYAT"),8,"Fiyat giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("MALIYET_KURU"),35,"Maliyet Kuru giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("PLATFORM_NO"),9,"Platform No giriniz.");
	    if(!iMap.getString("ISLEM_YONU").equals("A") && !iMap.getString("ISLEM_YONU").equals("S")){
	    	oMap.put("RESPONSE", "28");
	        oMap.put("RESPONSE_DATA", "��lem Y�n� A:Al��, S:Sat�� olabilir.");
	    }
		if(!oMap.getString("RESPONSE").equals("0")){ 
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_MUSTERI_ISLEM_AKTARIM", iMap, oMap);
			return oMap;
		}
		
		String alisDoviz = TreasuryUtil.hesapDovizKodu(iMap.getString("ALIM_HESAP_NO"));
		String satisDoviz = TreasuryUtil.hesapDovizKodu(iMap.getString("SATIM_HESAP_NO"));
		iMap.put("ALIS_DOVIZ_KODU", satisDoviz);
		iMap.put("SATIS_DOVIZ_KODU", alisDoviz);
		Session session = DAOSession.getSession("BNSPRDal");
		if(alisDoviz.equals("TRY")){
			List<CariDthTlOdemeTx> alis = (List<CariDthTlOdemeTx>) session.createCriteria(CariDthTlOdemeTx.class).add(Restrictions.eq("platformNo", iMap.getBigDecimal("PLATFORM_NO"))).list();
			if(alis != null && alis.size()>0){
				oMap.put("RESPONSE", "36");
		        oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
			}else{
				if(iMap.getString("BLOKE_NO") != null && !iMap.getString("BLOKE_NO").isEmpty())
					GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE", iMap);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_DOVIZ_ALIS", iMap));
			}			
		}else if(satisDoviz.equals("TRY")){
			List<CariDthDovizSatisTx> satis = (List<CariDthDovizSatisTx>) session.createCriteria(CariDthDovizSatisTx.class).add(Restrictions.eq("platformNo", iMap.getBigDecimal("PLATFORM_NO"))).list();
			if(satis != null && satis.size()>0){
				oMap.put("RESPONSE", "36");
		        oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
			}else{
				if(iMap.getString("BLOKE_NO") != null && !iMap.getString("BLOKE_NO").isEmpty())
					GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE", iMap);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_DOVIZ_SATIS", iMap));
			}
			
		}else{
			List<CariArbitrajTx> arbitraj = (List<CariArbitrajTx>) session.createCriteria(CariArbitrajTx.class).add(Restrictions.eq("platformNo", iMap.getBigDecimal("PLATFORM_NO"))).list();
			if(arbitraj != null && arbitraj.size()>0){
				oMap.put("RESPONSE", "36");
		        oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
			}else{
				if(iMap.getString("BLOKE_NO") != null && !iMap.getString("BLOKE_NO").isEmpty())
					GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_REMOVE_BLOKE", iMap);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_AKTIFX_TRADER_DOVIZ_ARBITRAJ", iMap));
			}
			
		}
		ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_MUSTERI_ISLEM_AKTARIM", iMap, oMap);
		return oMap;
	}

	@GraymoundService("BNSPR_AKTIFX_TRADER_PROVIDER_ISLEM_AKTARIM")
	public static GMMap saveProviderIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		Date islemValoru = null;
		Date islemZamani = null;
		try {
			oMap.put("RESPONSE", 0);
	    	oMap.put("RESPONSE_DATA", "");
	    	ServiceUtil.checkInput(oMap, iMap.getString("PLATFORM_NO"),9,"Platform No giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getString("PROVIDER_ADI"),10,"Provider Ad� giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_VALORU"),11,"��lem Val�r� giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_ZAMANI"),12,"��lem Zaman� giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ALINAN_TUTAR"),13,"Al�nan Tutar giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("SATILAN_TUTAR"),14,"Sat�lan Tutar giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getString("ALINAN_DOVIZ"),15,"Al�nan D�viz giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getString("SATILAN_DOVIZ"),16,"Sat�lan D�viz giriniz.");
	    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ISLEM_FIYATI"),17,"��lem Fiyat� giriniz.");
	    	islemValoru = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_VALORU"), 30, "��lem Val�r� tarih format� hatal�.",false);
	    	islemZamani = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_ZAMANI"), 31, "��lem Zaman� tarih format� hatal�.",true);
	    	iMap.put("URUN_TUR_KOD", "SPOT");
	    	Session session = DAOSession.getSession("BNSPRDal");
	    	List<HznSpotfwd> spot = (List<HznSpotfwd>) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("platformNo", iMap.getBigDecimal("PLATFORM_NO"))).list();
			if(spot != null && spot.size()>0){
				oMap.put("RESPONSE", "36");
		        oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
		        ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_PROVIDER_ISLEM_AKTARIM", iMap, oMap);
		        return oMap;
			}
	    	musteriBilgileriGetir(iMap, oMap);
	    	if(!oMap.getString("RESPONSE").equals("0")){
	    		ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_PROVIDER_ISLEM_AKTARIM", iMap, oMap);
	    		return oMap;
	    	}
    		iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
    		onsFiyatlama(iMap);
			iMap.put("DEALER_NO", 				getParamText("1306", "DEALER_NO")); 
			iMap.put("VALOR_TARIHI", 			islemValoru);
			iMap.put("DEAL_TARIHI", 			islemZamani);
			iMap.put("ALIS_TUTARI", 			iMap.getBigDecimal("ALINAN_TUTAR"));
			iMap.put("SATIS_TUTARI", 			iMap.getBigDecimal("SATILAN_TUTAR"));
			iMap.put("ALIS_DOVIZ_KODU", 		iMap.getString("ALINAN_DOVIZ"));
			iMap.put("SATIS_DOVIZ_KODU", 		iMap.getString("SATILAN_DOVIZ"));
			iMap.put("PARITE", 					iMap.getBigDecimal("ISLEM_FIYATI"));
			iMap.put("ACIKLAMA", 				getParamText("1306", "ACIKLAMA"));
			iMap.put("TRADING_PORTFOY", 		"false");			
			iMap.put("AS", 						getAlisSatis(iMap));
			iMap.put("URUN_SINIF_KOD", 			getUrunSinifKod(iMap));						 
			iMap.put("ALIS_HESAP_TURU", 		getParamText("1306", "ALIS_HESAP_TURU"));
			iMap.put("SATIS_HESAP_TURU", 		getParamText("1306", "SATIS_HESAP_TURU"));
			iMap.put("ISTATISTIK_KODU", 		getIstatistikKodu(iMap));
			GMServiceExecuter.execute("BNSPR_TRN1306_SAVE", iMap);
			iMap.put("TRX_NAME", "1306");
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));	
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_PROVIDER_ISLEM_AKTARIM", iMap, oMap);
			return oMap;
		} catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_PROVIDER_ISLEM_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}  
	}

	private static void onsFiyatlama(GMMap iMap) {				

		BigDecimal islemFiyat�  = iMap.getBigDecimal("ISLEM_FIYATI");		
		BigDecimal alinanTutar  = iMap.getBigDecimal("ALINAN_TUTAR");
		BigDecimal satilanTutar = iMap.getBigDecimal("SATILAN_TUTAR");
		String     satilanDvz    = iMap.getString("SATILAN_DOVIZ");
		String     alinanDvz   = iMap.getString("ALINAN_DOVIZ");
		String     k�ymetliMadenList = getParamText("1306", "KIYMETLI_MADEN");

		if(k�ymetliMadenList.contains(alinanDvz) && satilanDvz.equalsIgnoreCase("USD")){			
			BigDecimal grFiyat = islemFiyat�.divide(new BigDecimal("31.1035"),8,RoundingMode.FLOOR);			
			iMap.put("ISLEM_FIYATI", grFiyat);		
			iMap.put("ALINAN_TUTAR", satilanTutar.divide(grFiyat,2,RoundingMode.FLOOR));
			iMap.put("XAU_ALIS_ONS_MIKTAR", alinanTutar);
			
		}else if(k�ymetliMadenList.contains(satilanDvz) && alinanDvz.equalsIgnoreCase("USD")){						
			BigDecimal grFiyat = islemFiyat�.divide(new BigDecimal("31.1035"),8,RoundingMode.FLOOR);			

			iMap.put("ISLEM_FIYATI", grFiyat);		
			iMap.put("SATILAN_TUTAR", alinanTutar.divide(grFiyat,2,RoundingMode.FLOOR));
			iMap.put("XAU_SATIS_ONS_MIKTAR", satilanTutar);
			
		}						
			// al�nan xau oldu�u zaman  al�skur/31.1035=56,23	bu parite olucak al�� kura yazm�yorum			
			//  sat�s_tutar�/56, =al�s_tutar�			
	}


	
	
	private static String getAlisSatis(GMMap iMap) {				
		if(iMap.getString("ALINAN_DOVIZ").equals("TRY")){
			return "S";
		}else if(iMap.getString("SATILAN_DOVIZ").equals("TRY")){
			return "A";
		}else{
			return "A";
		}
	}

	private static GMMap musteriBilgileriGetir(GMMap iMap, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		BigDecimal musteriNo = null;				
		List<HznBloombergBankaMust> alisHesapNo = (List<HznBloombergBankaMust>) session.createCriteria(HznBloombergBankaMust.class).add(Restrictions.eq("id.bankaKodu" , iMap.getString("PROVIDER_ADI"))).add(Restrictions.eq("id.dovizKodu" , iMap.getString("ALINAN_DOVIZ"))).add(Restrictions.eq("id.urunTurKod", iMap.getString("URUN_TUR_KOD"))).list();
		
		if (alisHesapNo != null && alisHesapNo.size() > 0) {
			if(alisHesapNo.get(0).getMuhabirHesapNo() != null){
				iMap.put("ALIS_HESAP_NO", alisHesapNo.get(0).getMuhabirHesapNo());
			}else{
				oMap.put("RESPONSE", "33");
				oMap.put("RESPONSE_DATA", "Provider' �n "+iMap.getString("ALINAN_DOVIZ")+" hesab� yoktur.");
			}
			if(alisHesapNo.get(0).getMuhabir() != null){
				iMap.put("ALIS_MUHABIR_MUSTERI_NO", alisHesapNo.get(0).getMuhabir());
			}else{
				oMap.put("RESPONSE", "34");
				oMap.put("RESPONSE_DATA", "Provider' �n "+iMap.getString("ALINAN_DOVIZ")+" muhabiri tan�ml� de�ildir.");
			}
			if(alisHesapNo.get(0).getBankaMusteriNo() != null)
				musteriNo = alisHesapNo.get(0).getBankaMusteriNo();
		}
		
		List<HznBloombergBankaMust> satisHesapNo = (List<HznBloombergBankaMust>) session.createCriteria(HznBloombergBankaMust.class).add(Restrictions.eq("id.bankaKodu", iMap.getString("PROVIDER_ADI"))).add(Restrictions.eq("id.dovizKodu", iMap.getString("SATILAN_DOVIZ"))).add(Restrictions.eq("id.urunTurKod", iMap.getString("URUN_TUR_KOD"))).list();
		
		if (satisHesapNo != null && satisHesapNo.size() > 0) {
			if(satisHesapNo.get(0).getMuhabirHesapNo() != null){
				iMap.put("SATIS_HESAP_NO", satisHesapNo.get(0).getMuhabirHesapNo());
			}else{
				oMap.put("RESPONSE", "33");
				oMap.put("RESPONSE_DATA", "Provider' �n "+iMap.getString("SATILAN_DOVIZ")+" hesab� yoktur.");
			}
			if(satisHesapNo.get(0).getMuhabir() != null){
				iMap.put("SATIS_MUHABIR_MUSTERI_NO", satisHesapNo.get(0).getMuhabir());
			}else{
				oMap.put("RESPONSE", "34");
				oMap.put("RESPONSE_DATA", "Provider' �n "+iMap.getString("SATILAN_DOVIZ")+" muhabiri tan�ml� de�ildir.");
			}
			if(satisHesapNo.get(0).getBankaMusteriNo() != null)
				musteriNo = satisHesapNo.get(0).getBankaMusteriNo();
		}
		
		if(musteriNo != null){
			iMap.put("BANKA_MUSTERI_NO", musteriNo);
		}else{
			oMap.put("RESPONSE", "32");
			oMap.put("RESPONSE_DATA", "Provider' �n m��teri numaras� tan�ml� de�ildir.");
		}
		return iMap;
	}

	private static Object getIstatistikKodu(GMMap iMap) {
		return getParamText("1306", "ISTATISTIK_KODU", iMap.getString("URUN_SINIF_KOD"));
	}

	private static String getUrunSinifKod(GMMap iMap) {
		iMap.put("XAU_SATIS_ONS_MU", "false");
		iMap.put("XAU_ALIS_ONS_MU", "false");
		 String k�ymetliMadenList = getParamText("1306", "KIYMETLI_MADEN");

		if(iMap.getString("ALINAN_DOVIZ").equals("TRY")){
			iMap.put("SATIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));
			if((k�ymetliMadenList).contains(iMap.getString("SATILAN_DOVIZ"))){				
				return getParamText("1306", "URUN_SINIF_KODU",iMap.getString("AS") + iMap.getString("SATILAN_DOVIZ"));
			}else{
				return getParamText("1306", "URUN_SINIF_KODU",iMap.getString("AS") + iMap.getString("ALINAN_DOVIZ"));
			}
		}else if(iMap.getString("SATILAN_DOVIZ").equals("TRY")){
			iMap.put("ALIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));
			if(k�ymetliMadenList.contains(iMap.getString("ALINAN_DOVIZ"))){
				return getParamText("1306", "URUN_SINIF_KODU",iMap.getString("AS") + iMap.getString("ALINAN_DOVIZ"));
			}else{
				return getParamText("1306", "URUN_SINIF_KODU",iMap.getString("AS") + iMap.getString("SATILAN_DOVIZ"));
			}
		}else{
			if(k�ymetliMadenList.contains(iMap.getString("ALINAN_DOVIZ"))){
				iMap.put("ALIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));
								
				if(iMap.getString("SATILAN_DOVIZ").equalsIgnoreCase("USD")){
				iMap.put("XAU_ALIS_ONS_MU", "true");
				}

				return getParamText("1306", "URUN_SINIF_KODU",iMap.getString("ALINAN_DOVIZ")+"-ARBITRAJ");
			}else if(k�ymetliMadenList.contains(iMap.getString("SATILAN_DOVIZ"))){
				iMap.put("SATIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));
			
				if(iMap.getString("SATILAN_DOVIZ").equalsIgnoreCase("USD")){
					iMap.put("XAU_SATIS_ONS_MU", "true");
					}

				return getParamText("1306", "URUN_SINIF_KODU",iMap.getString("SATILAN_DOVIZ")+"-ARBITRAJ");
			}else{
				iMap.put("SATIS_KUR", new BigDecimal(1));
				return getParamText("1306", "URUN_SINIF_KODU","ARBITRAJ");
			}
		}
	}

	@GraymoundService("BNSPR_AKTIFX_TRADER_SMS_BILDIRIM")
	public static GMMap sendSMS(GMMap iMap) {
		GMMap oMap = new GMMap();
		Date emirGirisZamani = null;
		Date islemGerceklesmeZamani = null;
		oMap.put("RESPONSE", 0);
    	oMap.put("RESPONSE_DATA", ""); 
    	try{
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ISLEM_FIYATI"),17,"��lem Fiyat� giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ISLEM_TUTARI"),18,"��lem Tutar� giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("EMIR_TIPI"),19,"Emir Tipi giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_DOVIZ_CIFTI"),20,"��lem D�viz �ifti giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getBigDecimal("EMIR_NUMARASI"),21,"Emir Numaras� giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_YONU"),7,"��lem Y�n� giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_HATA_DURUMU"),26,"��lem Hata Durumu giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("EMIR_GIRIS_ZAMANI"),22,"Emir Giri� Zaman� giriniz.");
    	ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_GERCEKLESME_ZAMANI"),24,"��lem Ger�ekle�me Zaman� giriniz.");
    	emirGirisZamani = ServiceUtil.checkDateInput(oMap, iMap.getString("EMIR_GIRIS_ZAMANI"), 23, "Emir Giri� Zaman� tarih format� hatal�.",true);
    	islemGerceklesmeZamani = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_GERCEKLESME_ZAMANI"), 25, "��lem Ger�ekle�me Zaman� tarih format� hatal�.",true);
		if(!oMap.getString("RESPONSE").equals("0")) 
			return oMap;
		GMMap kMap = new GMMap();
		kMap.put("TRX_NO",iMap.getBigDecimal("EMIR_NUMARASI"));
		kMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1213_GET_INFO", kMap));
		ServiceUtil.checkInput(oMap, kMap.getBigDecimal("MUSTERI_NO"), 27, "��lem bulunamad�.");
		oMap.put("MSISDN", TreasuryUtil.iletisimNumarasi(kMap.getBigDecimal("MUSTERI_NO").toString()));
		oMap.put("CONTENT", TreasuryUtil.getMessage(5881, iMap.getBigDecimal("ISLEM_FIYATI").toString(), iMap.getBigDecimal("ISLEM_TUTARI").toString(), iMap.getString("EMIR_TIPI")) + " " + 
								TreasuryUtil.getMessage(5882, iMap.getString("ISLEM_DOVIZ_CIFTI"), iMap.getBigDecimal("EMIR_NUMARASI").toString(), iMap.getString("ISLEM_YONU")) + " " + 
								TreasuryUtil.getMessage(5883, emirGirisZamani.toString(), islemGerceklesmeZamani.toString(), iMap.getString("ISLEM_HATA_DURUMU")));
		
		oMap.put("HEADER", "AKTIFBANK");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", oMap));
		ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_SMS_BILDIRIM", iMap, oMap);
    	}catch (Exception e) {
    		ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_SMS_BILDIRIM", iMap, e);
    		throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/**
	 * Banka D�viz Sat�� servisi
	 * Bankadan m��teriye d�viz sat���
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_AKTIFX_TRADER_DOVIZ_SATIS")
	public static GMMap dovizSatis(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			iMap.put("DTH_MUSTERI_HESAP_NO", 	iMap.getBigDecimal("ALIM_HESAP_NO"));
			iMap.put("MUSTERI_HESAP_NO", 		iMap.getBigDecimal("SATIM_HESAP_NO"));
			iMap.put("DTH_MUSTERI_NO", 			iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("MUSTERI_NO", 			    iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("DOVIZ_KODU", 				iMap.getString("SATIS_DOVIZ_KODU"));
			iMap.put("KUR", 					iMap.getBigDecimal("FIYAT"));
			iMap.put("DEKONT_BASIM_F", 			getParamText("2013", "DEKONT_BASIM_F")); 
			iMap.put("ISTATISTIK_KODU", 		getParamText("2013", "ISTATISTIK_KODU")); 
			iMap.put("SATIS_SEKLI", 			"2");
			iMap.put("KIMLIK_TIPI", 			"1");
			iMap.put("ISLEM_TIPI", 				"S");
			iMap.put("ACIKLAMA", 				getParamText("2013", "ACIKLAMA"));
			iMap.put("LC_TUTAR", 				iMap.getBigDecimal("TUTAR").multiply(iMap.getBigDecimal("KUR")));
			iMap.put("DOVIZ_TUTARI", 			iMap.getBigDecimal("TUTAR"));
			iMap.put("ONAY_EH", 				"E");
			
			createRezervasyonSatis(iMap);			
			
			iMap.put("TAHSIL_ADILEN_TOPLAM_TUTAR", iMap.getBigDecimal("LC_TUTAR"));
			GMServiceExecuter.execute("BNSPR_TRN2013_SAVE", iMap);
			oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_DOVIZ_SATIS", iMap, oMap);
			return oMap;
		} catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_DOVIZ_SATIS", iMap, e);
			throw ExceptionHandler.convertException(e);
		}  
	}
	/**
	 * Banka D�viz Al�� servisi (M��teri Bankaya Sat�� Yapar)
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_AKTIFX_TRADER_DOVIZ_ALIS")
	public static GMMap dovizAlis(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			iMap.put("MUSTERI_NO", 		iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("ALACAK_HESAP_NO", iMap.getBigDecimal("ALIM_HESAP_NO"));
			iMap.put("BORC_HESAP_NO", 	iMap.getBigDecimal("SATIM_HESAP_NO"));
			iMap.put("DOVIZ_KODU", 		iMap.getString("ALIS_DOVIZ_KODU"));
			iMap.put("KUR", 			iMap.getBigDecimal("FIYAT"));
			iMap.put("DEKONT_BASIM_F", 	getParamText("2012", "DEKONT_BASIM_F"));
			iMap.put("DOVIZ_ULKE_KODU", getParamText("2012", "DOVIZ_ULKE_KODU"));
			iMap.put("ISTATISTIK_KODU", getParamText("2012", "ISTATISTIK_KODU"));
			iMap.put("ALIS_SEKLI", 		"2");
			iMap.put("KIMLIK_TIPI", 	"1");
			iMap.put("ISLEM_TIPI", 		"A");
			iMap.put("ACIKLAMA", 		getParamText("2012", "ACIKLAMA"));
			iMap.put("LC_TUTAR", 		iMap.getBigDecimal("TUTAR").multiply(iMap.getBigDecimal("KUR")));
			iMap.put("DOVIZ_TUTAR", 	iMap.getBigDecimal("TUTAR"));
			iMap.put("ONAY_EH",			"E");
			createRezervasyonAlis(iMap);
			GMServiceExecuter.execute("BNSPR_TRN2012_SAVE", iMap);
			oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_DOVIZ_ALIS", iMap, oMap);
			return oMap;
		} catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_DOVIZ_ALIS", iMap, e);
			throw ExceptionHandler.convertException(e);
		}  
	}
	
	@GraymoundService("BNSPR_AKTIFX_TRADER_DOVIZ_ARBITRAJ")
	public static GMMap dovizArbitraj(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			BigDecimal alisHesapNo = iMap.getBigDecimal("ALIM_HESAP_NO");
			BigDecimal satisHesapNo = iMap.getBigDecimal("SATIM_HESAP_NO");
			iMap.put("ALIS_HESAP_NO", satisHesapNo);
			iMap.put("SATIS_HESAP_NO", alisHesapNo);
			iMap.put("PARITE", iMap.getBigDecimal("FIYAT"));
			iMap.put("KUR_PARITE_SECIM", "P");
			iMap.put("P_OR_K", "P");
			
			GMMap currencyMap = new GMMap();
			currencyMap.put("SATIS_DOVIZ_KODU", iMap.getString("SATIS_DOVIZ_KODU"));
			Object o2 = GMServiceExecuter.execute("BNSPR_TRN2011_GET_SATIS_KURU", currencyMap).get("SATIS_KURU");
			iMap.put("SATIS_KURU", o2 == null ? new BigDecimal(0) : o2);

			currencyMap.put("ALIS_DOVIZ_KODU", iMap.getString("ALIS_DOVIZ_KODU"));
			Object o = GMServiceExecuter.execute("BNSPR_TRN2011_GET_ALIS_KURU",currencyMap).get("ALIS_KURU");
			iMap.put("ALIS_KURU", o == null ? new BigDecimal(0) : o);

			
			if (iMap.getString("ISLEM_YONU").equals("S")) {// Musteri satis tutari girmis
				iMap.put("ALIS_TUTARI", iMap.getBigDecimal("TUTAR"));
				iMap.put("ALIM_SATIM", "A");
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2011_ALISTAN_SATIS", iMap));
			} else if (iMap.getString("ISLEM_YONU").equals("A")) {// Musteri alis tutari girmis
				iMap.put("SATIS_TUTARI", iMap.getBigDecimal("TUTAR"));
				iMap.put("ALIM_SATIM", "S");
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2011_SATISTAN_ALIS", iMap));
			}
			iMap.put("ACIKLAMA", 		getParamText("2011", "ACIKLAMA"));
			iMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("SATIS_HESAP_NO"));
			iMap.put("ONAY_EH",			"E");
			setRezervasyonArbitraj(iMap);
			
			iMap.put("ISLEM_SEKLI", "H");
			GMServiceExecuter.execute("BNSPR_TRN2011_SAVE", iMap);
			oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_DOVIZ_ARBITRAJ", iMap, oMap);
			return oMap;
		} catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_TRADER_DOVIZ_ARBITRAJ", iMap, e);
			throw ExceptionHandler.convertException(e);
		}  
	}
	
	@GraymoundService("BNSPR_AKTIFX_KUR_REZERVASYON_KAYDI_OLUSTUR")
	public static GMMap kurRezervasyonKaydiOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_AKTIFX_TRADER.Kur_Rezervasyon_Kaydi_Olustur(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("ISLEM_SEKLI"));
			stmt.setString(i++, iMap.getString("ALIS_DOVIZ"));
			stmt.setString(i++, iMap.getString("SATIS_DOVIZ"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_KUR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_KUR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("PARITE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MALIYET_ALIS_KUR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MALIYET_SATIS_KUR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MALIYET_PARITE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("REZERVASYON_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIFX_SOZLESME_KONTROL")
	public static GMMap sozlesmeKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			String dokumanKod = (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "NKOLAYFX_DOKUMAN_KOD")).get("DEGER");
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_AKTIFX_TRADER.musteri_dokuman_var_mi(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, dokumanKod);
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("ONAY_DURUM", stmt.getString(1));
			oMap.put("RESPONSE", 0);
	    	oMap.put("RESPONSE_DATA", "SUCCESS");	
			ServiceUtil.logAt("BNSPR_AKTIFX_SOZLESME_KONTROL", iMap, oMap);
			return oMap;
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_SOZLESME_KONTROL", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_AKTIFX_SOZLESME_ONAY")
	public static GMMap sozlesmeOnay(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			String docType = (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "NKOLAYFX_DOKUMAN_KOD")).get("DEGER");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN10011.Musteri_dokuman_ekle(?,?)}");
			stmt.setBigDecimal(1, musteriNo);
			stmt.setString(2, docType);
			stmt.execute();

			String trxNo = (String) GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO");
			String now = new SimpleDateFormat("yyyyMMddhhmm").format(new java.util.Date());
			String fileName = musteriNo + "_" + docType + "_" + now + ".pdf";

			/*
			 * Musteri no ve dokuman kodu ile pdf olusturulur
			 * iMap icinde MUSTERI_NO ve DOC_TYPE olacak
			 */
//			iMap.put("DOC_TYPE", docType);
			
			BankaBilgileri bankaBilgileri = new BankaBilgileri();
			bankaBilgileri.setEmail("iletisim@aktifbank.com.tr");
			bankaBilgileri.setFax("0212 340 88 65");
			bankaBilgileri.setTelefon("0212 340 80 00");
			iMap.put("MODEL_OBJ", bankaBilgileri);
			iMap.put("FOLDER_NAME", "nkolayfx");
			iMap.put("TEMPLATE_NAME", "2078-nkolayFxPlatformuSozlesmesi");

			byte[] doc = (byte[]) GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_PDF_BYTE", iMap).get("PDF_BYTE_DATA");
			

			/*
			 * DysMap ile dokuman olup olmadigi kontrol edilir, varsa update, yoksa save musteri dokuman yapilir.
			 */
			GMMap dysMap = new GMMap();

			dysMap.put("TRX_NO", trxNo);
			dysMap.put("DOKUMAN_TIPI", docType);
			dysMap.put("DOKUMAN_ADI", fileName);
			dysMap.put("MUSTERI_NO", musteriNo);
			dysMap.put("REFERANS_TIPI", "");
			dysMap.put("REFERANS_NO", "");
			dysMap.put("DOSYA_SAYFA", 0, "CONTENT", doc);
			dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", fileName);
			dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", BigDecimal.ONE);
			dysMap.put("TRX_ONAYSIZ_ISLEM", "E");

			GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);

			if (isExistMap.getBoolean("RESULT")) {
				GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			}
			else {
				GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			}

			oMap.put("RESPONSE", 0);
	    	oMap.put("RESPONSE_DATA", "SUCCESS");	
			ServiceUtil.logAt("BNSPR_AKTIFX_SOZLESME_ONAY", iMap, oMap);
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_AKTIFX_SOZLESME_ONAY", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	private static void setRezervasyonArbitraj(GMMap iMap) {
		GMMap xMap = new GMMap();
		xMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
		xMap.put("ISLEM_SEKLI", "ARBITRAJ");
		xMap.put("ALIS_DOVIZ", iMap.getString("ALIS_DOVIZ_KODU"));
		xMap.put("SATIS_DOVIZ", iMap.getString("SATIS_DOVIZ_KODU"));
		xMap.put("ALIS_TUTAR", iMap.getBigDecimal("ALIS_TUTARI"));
		xMap.put("SATIS_TUTAR", iMap.getBigDecimal("SATIS_TUTARI"));
		xMap.put("PARITE", iMap.getBigDecimal("PARITE"));
		xMap.put("MALIYET_PARITE", iMap.getBigDecimal("MALIYET_KURU"));
		xMap.put("TX_NO", iMap.getBigDecimal("TRX_NO"));
		xMap.put("HESAP_NO", iMap.getBigDecimal("ALIS_HESAP_NO"));
		iMap.put("REZERVASYON_NO", GMServiceExecuter.execute(
				"BNSPR_AKTIFX_KUR_REZERVASYON_KAYDI_OLUSTUR", xMap).get(
				"REZERVASYON_NO"));
	}
	
	private static void createRezervasyonSatis(GMMap iMap) {
		GMMap xMap = new GMMap();
		xMap.put("MUSTERI_NO", iMap.getBigDecimal("DTH_MUSTERI_NO"));
		xMap.put("ISLEM_SEKLI", "SATIS");
		xMap.put("ALIS_DOVIZ", iMap.getString("ALIS_DOVIZ_KODU"));
		xMap.put("SATIS_DOVIZ", iMap.getString("SATIS_DOVIZ_KODU"));
		xMap.put("ALIS_TUTAR", 0);
		xMap.put("SATIS_TUTAR", iMap.getBigDecimal("DOVIZ_TUTARI"));
		xMap.put("ALIS_KUR", "");
		xMap.put("SATIS_KUR", iMap.getBigDecimal("KUR"));
		xMap.put("MALIYET_ALIS_KUR", "");
		xMap.put("MALIYET_SATIS_KUR", iMap.getBigDecimal("MALIYET_KURU"));
		xMap.put("TX_NO", iMap.getBigDecimal("TRX_NO"));
		xMap.put("HESAP_NO", iMap.getBigDecimal("ALIM_HESAP_NO"));
		iMap.put("REZERVASYON_NO", GMServiceExecuter.execute(
				"BNSPR_AKTIFX_KUR_REZERVASYON_KAYDI_OLUSTUR", xMap).get(
				"REZERVASYON_NO"));
	}
	
	private static void createRezervasyonAlis(GMMap iMap){
		GMMap xMap = new GMMap();
		xMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
		xMap.put("ISLEM_SEKLI", "ALIS");
		xMap.put("ALIS_DOVIZ", iMap.getString("ALIS_DOVIZ_KODU"));
		xMap.put("SATIS_DOVIZ", iMap.getString("SATIS_DOVIZ_KODU"));
		xMap.put("ALIS_TUTAR", iMap.getBigDecimal("DOVIZ_TUTAR"));
		xMap.put("SATIS_TUTAR", 0);
		xMap.put("ALIS_KUR", iMap.getBigDecimal("KUR"));
		xMap.put("SATIS_KUR", "");
		xMap.put("MALIYET_ALIS_KUR", iMap.getBigDecimal("MALIYET_KURU"));
		xMap.put("MALIYET_SATIS_KUR", "");
		xMap.put("TX_NO", iMap.getBigDecimal("TRX_NO"));
		xMap.put("HESAP_NO", iMap.getBigDecimal("SATIM_HESAP_NO"));
		iMap.put("REZARYASYON_NO", GMServiceExecuter.execute(
				"BNSPR_AKTIFX_KUR_REZERVASYON_KAYDI_OLUSTUR", xMap).get(
				"REZERVASYON_NO"));
	}
	
	private static String getParamText(String key, String key2, String key3){
		return TreasuryUtil.getParamText("NKOLAY_FX_PARAMETRELER", key, key2, key3);
	}
	private static String getParamText(String key, String key2){
		return getParamText(key, key2, null);
	}
}
