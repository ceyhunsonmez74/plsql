package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznTopluAlinandepoOran;
import tr.com.aktifbank.bnspr.dao.HznTopluAlinandepoOranTx;
import tr.com.aktifbank.bnspr.dao.HznTopluAlinandepoOranTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1320Services {

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN1320_INIT")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession("BNSPRDal");
			List<HznTopluAlinandepoOran> depoList = (List<HznTopluAlinandepoOran>) session.createCriteria(HznTopluAlinandepoOran.class).addOrder(Order.asc("id.bankaMusteriNo")).list();

			int i = 0;
			String tn = "TBL";
			for (HznTopluAlinandepoOran depo : depoList) {
				oMap.put(tn, i, "FAIZ_ORANI", depo.getFaizOrani());
				oMap.put(tn, i, "HESAP_NO", depo.getId().getBankaHesapNo());
				oMap.put(tn, i, "MUSTERI_NO", depo.getId().getBankaMusteriNo());
				oMap.put(tn, i, "DOVIZ_KODU", depo.getId().getDovizKodu());
				oMap.put(tn, i, "MIN_TUTAR", depo.getId().getMinTutar());
				oMap.put(tn, i, "MAX_TUTAR", depo.getId().getMaxTutar());
				oMap.put(tn, i, "UNVAN",   LovHelper.diLov(depo.getId().getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
				i++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1320_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

			int i = 0;
			String table = "TBL";

			while (i < iMap.getSize(table)) {
				HznTopluAlinandepoOranTxId id = new HznTopluAlinandepoOranTxId();
				id.setTxNo(trxNo);
				id.setBankaHesapNo(iMap.getBigDecimal(table, i, "HESAP_NO"));
				id.setBankaMusteriNo(iMap.getBigDecimal(table, i, "MUSTERI_NO"));
				id.setDovizKodu(iMap.getString(table, i, "DOVIZ_KODU"));
				id.setMinTutar(iMap.getBigDecimal(table, i, "MIN_TUTAR"));
				id.setMaxTutar(iMap.getBigDecimal(table, i, "MAX_TUTAR"));
				
				HznTopluAlinandepoOranTx tx = new HznTopluAlinandepoOranTx(id);
				tx.setId(id);
			
				
				tx.setFaizOrani(iMap.getBigDecimal(table, i, "FAIZ_ORANI"));
 
				session.save(tx);
				i++;
			}
			session.flush();

			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings({ "unchecked" })
	@GraymoundService("BNSPR_TRN1320_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<HznTopluAlinandepoOranTx> depoList = (List<HznTopluAlinandepoOranTx>) session.createCriteria(HznTopluAlinandepoOranTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();

			int i = 0;
			String tn = "TBL";
			for (HznTopluAlinandepoOranTx depo : depoList) {
				oMap.put(tn, i, "FAIZ_ORANI", depo.getFaizOrani());
				oMap.put(tn, i, "HESAP_NO", depo.getId().getBankaHesapNo());
				oMap.put(tn, i, "MUSTERI_NO", depo.getId().getBankaMusteriNo());
				oMap.put(tn, i, "DOVIZ_KODU", depo.getId().getDovizKodu());
				oMap.put(tn, i, "MIN_TUTAR", depo.getId().getMinTutar());
				oMap.put(tn, i, "MAX_TUTAR", depo.getId().getMaxTutar());
				oMap.put(tn, i, "UNVAN",   LovHelper.diLov(depo.getId().getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
				i++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1320_CHECK_DOUBLE_DATA")
	public static GMMap checkDoubleData(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			int i = 0, j = 0;
			String table = "TBL";

			while (i < iMap.getSize(table)) {
				j = i + 1;
				String uyeKodu = iMap.getString(table, i, "HESAP_NO");
				String min = iMap.getString(table, i, "MIN_TUTAR");
				String max = iMap.getString(table, i, "MAX_TUTAR");
				String faiz = iMap.getString(table, i, "FAIZ_ORANI");
				
				while (j < iMap.getSize(table)) {
					String uyeKodu1 = iMap.getString(table, j, "HESAP_NO");
					String min1 = iMap.getString(table, j, "MIN_TUTAR");
					String max1 = iMap.getString(table, j, "MAX_TUTAR");
					String faiz1 = iMap.getString(table, j, "FAIZ_ORANI");
					
					if (uyeKodu.equalsIgnoreCase(uyeKodu1) && min.equalsIgnoreCase(min1) && max.equalsIgnoreCase(max1)  )
						oMap.put("MESSAGE", "Bu Kay�t Zaten Mevcut -> " + iMap.getString(table, j, "HESAP_NO") + " " + iMap.getBigDecimal(table, j, "MUSTERI_NO"));
					j++;
				}
				
				i++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
