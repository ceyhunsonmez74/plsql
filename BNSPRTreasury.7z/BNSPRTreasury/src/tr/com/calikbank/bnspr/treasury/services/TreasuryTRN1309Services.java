package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSwapTx;
import tr.com.calikbank.bnspr.dao.HznSwapTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1309Services {
	
	@GraymoundService("BNSPR_TRN1309_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapTx hznSwapTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			HznSwapTxId id = null;
			
			if(hznSwapTx == null) {
				hznSwapTx = new HznSwapTx();
				id = new HznSwapTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setReferans(iMap.getString("TRX_NO"));
			} else {
				id = hznSwapTx.getId();
			}

			hznSwapTx.setId(id);
			hznSwapTx.setModulTurKod("HAZINE");
			hznSwapTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			hznSwapTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSwapTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSwapTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznSwapTx.setDealerNo((String)iMap.get("DEALER_NO"));
			hznSwapTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSwapTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznSwapTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSwapTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSwapTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSwapTx.setSpotAlisKur(iMap.getBigDecimal("SPOT_ALIS_KUR"));
			hznSwapTx.setSpotSatisKur(iMap.getBigDecimal("SPOT_SATIS_KUR"));
			hznSwapTx.setSpotParite(iMap.getBigDecimal("SPOT_PARITE"));
			hznSwapTx.setSpotCarpBolFlag(iMap.getString("SPOT_CARP_BOL_FLAG"));
			hznSwapTx.setSpotAlisTutari(iMap.getBigDecimal("SPOT_ALIS_TUTARI"));
			hznSwapTx.setSpotSatisTutari(iMap.getBigDecimal("SPOT_SATIS_TUTARI"));
			hznSwapTx.setSpotAlisHesapTuru(iMap.getString("SPOT_ALIS_HESAP_TURU"));
			hznSwapTx.setSpotAlisHesapNo(iMap.getBigDecimal("SPOT_ALIS_HESAP_NO"));
			hznSwapTx.setSpotSatisHesapTuru(iMap.getString("SPOT_SATIS_HESAP_TURU"));
			hznSwapTx.setSpotSatisHesapNo(iMap.getBigDecimal("SPOT_SATIS_HESAP_NO"));
			hznSwapTx.setForwardAlisKur(iMap.getBigDecimal("FORWARD_ALIS_KUR"));
			hznSwapTx.setForwardSatisKur(iMap.getBigDecimal("FORWARD_SATIS_KUR"));
			hznSwapTx.setForwardParite(iMap.getBigDecimal("FORWARD_PARITE"));
			hznSwapTx.setForwardCarpBolFlag(iMap.getString("FORWARD_CARP_BOL_FLAG"));
			hznSwapTx.setForwardAlisTutari(iMap.getBigDecimal("FORWARD_ALIS_TUTARI"));
			hznSwapTx.setForwardSatisTutari(iMap.getBigDecimal("FORWARD_SATIS_TUTARI"));
			hznSwapTx.setForwardAlisHesapTuru(iMap.getString("FORWARD_ALIS_HESAP_TURU"));
			hznSwapTx.setForwardAlisHesapNo(iMap.getBigDecimal("FORWARD_ALIS_HESAP_NO"));
			hznSwapTx.setForwardSatisHesapTuru(iMap.getString("FORWARD_SATIS_HESAP_TURU"));
			hznSwapTx.setForwardSatisHesapNo(iMap.getBigDecimal("FORWARD_SATIS_HESAP_NO"));
			hznSwapTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznSwapTx.setIslemSekli(iMap.getString("ISLEM_SEKLI"));
			
			hznSwapTx.setSpotAlisMuhMusteriNo(iMap.getString("SPOT_ALIS"));
			hznSwapTx.setSpotSatisMuhMusteriNo(iMap.getString("SPOT_SATIS"));
			
			hznSwapTx.setForwardAlisMuhMusteriNo(iMap.getString("FORWARD_ALIS"));
			hznSwapTx.setForwardSatisMuhMusteriNo(iMap.getString("FORWARD_SATIS"));
			
			hznSwapTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
			hznSwapTx.setOrderId(iMap.getString("ORDER_ID"));
			hznSwapTx.setMessageId(iMap.getString("MESSAGE_ID"));
			hznSwapTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
			hznSwapTx.setSwappoint(iMap.getString("SWAPPOINT"));

			session.saveOrUpdate(hznSwapTx);
			session.flush();
			
			GMMap oMap = new GMMap();
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	
	@GraymoundService("BNSPR_TRN1309_TRANSACTION_START")
	public static Map<?, ?> trn1309Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1309");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1309_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmtNetting = null;
        String spotNetting = null;
        String fwdNetting = null;

		GMMap oMap = new GMMap();
		try {
			
			conn = DALUtil.getGMConnection();
			//SPOT
			stmtNetting = conn.prepareCall("{call PKG_TRN1306.Netting_Swift_Kontrolu(?,?,?,?,?) }");
			
			stmtNetting.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			stmtNetting.setString(2, iMap.getString("URUN_TUR_KOD"));
			stmtNetting.setString(3, iMap.getString("SPOT_SATIS_DOVIZ_KODU"));
			stmtNetting.setString(4, iMap.getString("SPOT_SATIS_HESAP_TURU"));

			stmtNetting.registerOutParameter(5, Types.VARCHAR);

			stmtNetting.execute();
			spotNetting = stmtNetting.getString(5);
											
			if(spotNetting.equals("H")){ //nettinge dahil degilse
				stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?,?)}");
			    
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.setString(3, "S");
	
				stmt.execute();
			}
			//FORWARD
			stmtNetting = conn.prepareCall("{call PKG_TRN1306.Netting_Swift_Kontrolu(?,?,?,?,?) }");
			
			stmtNetting.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			stmtNetting.setString(2, iMap.getString("URUN_TUR_KOD"));
			stmtNetting.setString(3, iMap.getString("FWD_SATIS_DOVIZ_KODU"));
			stmtNetting.setString(4, iMap.getString("FWD_SATIS_HESAP_TURU"));

			stmtNetting.registerOutParameter(5, Types.VARCHAR);

			stmtNetting.execute();
			fwdNetting = stmtNetting.getString(5);	
			
			if(fwdNetting.equals("H")){ //nettinge dahil degilse
				stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?,?)}");
			    
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.setString(3, "F");
	
				stmt.execute();
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmtNetting);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1309_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1309.SWAP_BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1309_GET_TRANSFER_DATA")
	public static GMMap getTransferData(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapTx hznSwapTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			oMap.put("TX_NO", hznSwapTx.getId().getTxNo());
			oMap.put("REF_NO", hznSwapTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSwapTx.getUrunTurKod(), "1308/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSwapTx.getUrunSinifKod());
			oMap.put("DURUM_KODU", hznSwapTx.getDurumKodu());
			oMap.put("DEAL_TARIHI", hznSwapTx.getDealTarihi());
			oMap.put("DEALER_NO", hznSwapTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSwapTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSwapTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznSwapTx.getVadeTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSwapTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSwapTx.getSatisDovizKodu());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSwapTx.getDealerNo(), "1308/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSwapTx.getBankaMusteriNo(), "1308/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("SPOT_ALIS_TUTARI", hznSwapTx.getSpotAlisTutari());
			oMap.put("SPOT_ALIS_HESAP_TURU", hznSwapTx.getSpotAlisHesapTuru());
			oMap.put("SPOT_ALIS_HESAP_NO", hznSwapTx.getSpotAlisHesapNo());
			oMap.put("SPOT_SATIS_TUTARI", hznSwapTx.getSpotSatisTutari());
			oMap.put("SPOT_SATIS_HESAP_TURU", hznSwapTx.getSpotSatisHesapTuru());
			oMap.put("SPOT_SATIS_HESAP_NO", hznSwapTx.getSpotSatisHesapNo());
			oMap.put("SPOT_ALIS_KUR", hznSwapTx.getSpotAlisKur());
			oMap.put("SPOT_SATIS_KUR", hznSwapTx.getSpotSatisKur());
			oMap.put("SPOT_PARITE", hznSwapTx.getSpotParite());
			oMap.put("SPOT_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotAlisHesapNo(),hznSwapTx.getAlisDovizKodu(), hznSwapTx.getSpotAlisHesapTuru(), 
					hznSwapTx.getAlisDovizKodu(), hznSwapTx.getSpotAlisHesapTuru(), hznSwapTx.getBankaMusteriNo(),
					"1308/LOV_SPOT_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("SPOT_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotSatisHesapNo(),hznSwapTx.getSatisDovizKodu(), hznSwapTx.getSpotSatisHesapTuru(),
					hznSwapTx.getSatisDovizKodu(),hznSwapTx.getSpotSatisHesapTuru(),hznSwapTx.getBankaMusteriNo(), 
					"1308/LOV_SPOT_SATIS_HESAP", "KISA_ISIM"));
			
			oMap.put("FORWARD_ALIS_TUTARI", hznSwapTx.getForwardAlisTutari());
			oMap.put("FORWARD_ALIS_HESAP_TURU", hznSwapTx.getForwardAlisHesapTuru());
			oMap.put("FORWARD_ALIS_HESAP_NO", hznSwapTx.getForwardAlisHesapNo());
			oMap.put("FORWARD_SATIS_TUTARI", hznSwapTx.getForwardSatisTutari());
			oMap.put("FORWARD_SATIS_HESAP_TURU", hznSwapTx.getForwardSatisHesapTuru());
			oMap.put("FORWARD_SATIS_HESAP_NO", hznSwapTx.getForwardSatisHesapNo());
			oMap.put("FORWARD_ALIS_KUR", hznSwapTx.getForwardAlisKur());
			oMap.put("FORWARD_SATIS_KUR", hznSwapTx.getForwardSatisKur());
			oMap.put("FORWARD_PARITE", hznSwapTx.getForwardParite());
			oMap.put("FORWARD_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardAlisHesapNo(),hznSwapTx.getSatisDovizKodu(), hznSwapTx.getForwardAlisHesapTuru(), 
					hznSwapTx.getSatisDovizKodu(), hznSwapTx.getForwardAlisHesapTuru(), hznSwapTx.getBankaMusteriNo(), 
					"1308/LOV_FORWARD_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("FORWARD_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardSatisHesapNo(),hznSwapTx.getAlisDovizKodu(), hznSwapTx.getForwardSatisHesapTuru(),
					hznSwapTx.getAlisDovizKodu(),hznSwapTx.getForwardSatisHesapTuru(),hznSwapTx.getBankaMusteriNo(), 
					"1308/LOV_FORWARD_SATIS_HESAP", "KISA_ISIM"));
			oMap.put("ISLEM_SEKLI", hznSwapTx.getIslemSekli());
			oMap.put("ACIKLAMA", hznSwapTx.getAciklama());
			
			
			stmt = conn.prepareCall("{? = call PKG_TRN1309.SWAP_Valor_Gecmismi(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, hznSwapTx.getId().getReferans());
			stmt.execute();
			
			if(stmt.getString(1).equals("E"))
				oMap.put("VALOR_GECMISMI", "false");
			else
				oMap.put("VALOR_GECMISMI", "true");
			
			
			oMap.put("SPOT_ALIS", hznSwapTx.getSpotAlisMuhMusteriNo());
			oMap.put("SPOT_SATIS", hznSwapTx.getSpotSatisMuhMusteriNo());
			oMap.put("FORWARD_ALIS", hznSwapTx.getForwardAlisMuhMusteriNo());
			oMap.put("FORWARD_SATIS", hznSwapTx.getForwardSatisMuhMusteriNo());			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1309_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapTx hznSwapTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();
			
			oMap.put("TX_NO", hznSwapTx.getId().getTxNo());
			oMap.put("REF_NO", hznSwapTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSwapTx.getUrunTurKod(), "1308/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSwapTx.getUrunSinifKod());
			oMap.put("DURUM_KODU", hznSwapTx.getDurumKodu());
			oMap.put("DEAL_TARIHI", hznSwapTx.getDealTarihi());
			oMap.put("DEALER_NO", hznSwapTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSwapTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSwapTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznSwapTx.getVadeTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSwapTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSwapTx.getSatisDovizKodu());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSwapTx.getDealerNo(), "1308/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSwapTx.getBankaMusteriNo(), "1308/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("SPOT_ALIS_TUTARI", hznSwapTx.getSpotAlisTutari());
			oMap.put("SPOT_ALIS_HESAP_TURU", hznSwapTx.getSpotAlisHesapTuru());
			oMap.put("SPOT_ALIS_HESAP_NO", hznSwapTx.getSpotAlisHesapNo());
			oMap.put("SPOT_SATIS_TUTARI", hznSwapTx.getSpotSatisTutari());
			oMap.put("SPOT_SATIS_HESAP_TURU", hznSwapTx.getSpotSatisHesapTuru());
			oMap.put("SPOT_SATIS_HESAP_NO", hznSwapTx.getSpotSatisHesapNo());
			oMap.put("SPOT_ALIS_KUR", hznSwapTx.getSpotAlisKur());
			oMap.put("SPOT_SATIS_KUR", hznSwapTx.getSpotSatisKur());
			oMap.put("SPOT_PARITE", hznSwapTx.getSpotParite());
			oMap.put("SPOT_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotAlisHesapNo(),hznSwapTx.getAlisDovizKodu(), hznSwapTx.getSpotAlisHesapTuru(), 
					hznSwapTx.getAlisDovizKodu(), hznSwapTx.getSpotAlisHesapTuru(), hznSwapTx.getBankaMusteriNo(),
					"1308/LOV_SPOT_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("SPOT_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotSatisHesapNo(),hznSwapTx.getSatisDovizKodu(), hznSwapTx.getSpotSatisHesapTuru(),
					hznSwapTx.getSatisDovizKodu(),hznSwapTx.getSpotSatisHesapTuru(),hznSwapTx.getBankaMusteriNo(), 
					"1308/LOV_SPOT_SATIS_HESAP", "KISA_ISIM"));
			
			oMap.put("FORWARD_ALIS_TUTARI", hznSwapTx.getForwardAlisTutari());
			oMap.put("FORWARD_ALIS_HESAP_TURU", hznSwapTx.getForwardAlisHesapTuru());
			oMap.put("FORWARD_ALIS_HESAP_NO", hznSwapTx.getForwardAlisHesapNo());
			oMap.put("FORWARD_SATIS_TUTARI", hznSwapTx.getForwardSatisTutari());
			oMap.put("FORWARD_SATIS_HESAP_TURU", hznSwapTx.getForwardSatisHesapTuru());
			oMap.put("FORWARD_SATIS_HESAP_NO", hznSwapTx.getForwardSatisHesapNo());
			oMap.put("FORWARD_ALIS_KUR", hznSwapTx.getForwardAlisKur());
			oMap.put("FORWARD_SATIS_KUR", hznSwapTx.getForwardSatisKur());
			oMap.put("FORWARD_PARITE", hznSwapTx.getForwardParite());
			oMap.put("FORWARD_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardAlisHesapNo(),hznSwapTx.getSatisDovizKodu(), hznSwapTx.getForwardAlisHesapTuru(), 
					hznSwapTx.getSatisDovizKodu(), hznSwapTx.getForwardAlisHesapTuru(), hznSwapTx.getBankaMusteriNo(), 
					"1308/LOV_FORWARD_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("FORWARD_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardSatisHesapNo(),hznSwapTx.getAlisDovizKodu(), hznSwapTx.getForwardSatisHesapTuru(),
					hznSwapTx.getAlisDovizKodu(),hznSwapTx.getForwardSatisHesapTuru(),hznSwapTx.getBankaMusteriNo(), 
					"1308/LOV_FORWARD_SATIS_HESAP", "KISA_ISIM"));
			oMap.put("ISLEM_SEKLI", hznSwapTx.getIslemSekli());
			oMap.put("ACIKLAMA", hznSwapTx.getAciklama());
			stmt = conn.prepareCall("{? = call PKG_TRN1309.SWAP_Valor_Gecmismi(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, hznSwapTx.getId().getReferans());
			stmt.execute();
			
			if(stmt.getString(1).equals("E"))
				oMap.put("VALOR_GECMISMI", "false");
			else
				oMap.put("VALOR_GECMISMI", "true");
			
			
			oMap.put("SPOT_ALIS", hznSwapTx.getSpotAlisMuhMusteriNo());
			oMap.put("SPOT_SATIS", hznSwapTx.getSpotSatisMuhMusteriNo());
			oMap.put("FORWARD_ALIS", hznSwapTx.getForwardAlisMuhMusteriNo());
			oMap.put("FORWARD_SATIS", hznSwapTx.getForwardSatisMuhMusteriNo());			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
