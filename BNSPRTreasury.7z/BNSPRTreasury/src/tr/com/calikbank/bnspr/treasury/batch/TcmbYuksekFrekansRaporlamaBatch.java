package tr.com.calikbank.bnspr.treasury.batch;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TcmbYuksekFrekansRaporlamaBatch {
	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	/*K�sa ve Uzun vadeli 348 ve 349 depo hesaplar�n�n kullan�m ve geri �demeleri ve arac�l�k etti�imiz krediler  */
	@GraymoundService("BNSPR_TCMB_KREDI_DATA_WITH_EXCEL")
	public static GMMap sendTcmbKrediDataWithExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement geriStmt = null;
		ResultSet rSet = null;
		ResultSet geriRset = null;

		String kullanimDosyaAdi, geriOdemeDosyaAdi = null;

		try {
			conn = DALUtil.getGMConnection();

			/*YuksekFrekansKullanim dosyasi haz�rlan�yor*/
			kullanimDosyaAdi = getKullanimFileName(iMap);

			stmt = conn.prepareCall("{? = call PKG_RC_INV_TCMB.RC_KREDI_KULLANIM_DATA()}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			importKullanimDataToExcel(rSet, kullanimDosyaAdi);

			/*****************************************************************************************************************************************************************************************************/

			/*YuksekFrekansGeriOdeme dosyasi haz�rlan�yor*/
			geriOdemeDosyaAdi = getGeriOdemeFileName(iMap);

			geriStmt = conn.prepareCall("{? = call PKG_RC_INV_TCMB.RC_KREDI_GERI_ODEME_DATA()}");
			int l = 1;
			geriStmt.registerOutParameter(l++, -10); // ref cursor
			geriStmt.execute();
			geriRset = (ResultSet) geriStmt.getObject(1);
			importGeriOdemeDataToExcel(geriRset, geriOdemeDosyaAdi);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(geriRset);
			GMServerDatasource.close(geriStmt);
			GMServerDatasource.close(conn);
		}
	}

	private static void importGeriOdemeDataToExcel(ResultSet rSet, String tempDosyaAdi) {
		XSSFWorkbook wb;
		try {
			wb = new XSSFWorkbook();
			XSSFSheet sheet1 = wb.createSheet("YuksekFrekansGeriOdeme");
			FileOutputStream fileOut = new FileOutputStream(tempDosyaAdi);
			// Baslik satiri.
			int columnCount = 0;
			{
				Row row = sheet1.createRow(0);
				Cell cell = row.createCell(columnCount);
				cell.setCellValue("SiraNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("KayitID");
				cell = row.createCell(++columnCount);
				cell.setCellValue("kayitTuru");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediTipi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("bankaKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("subeKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediTuru");
				cell = row.createCell(++columnCount);
				cell.setCellValue("garantiVerenBankaKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("anlasmaTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("sonOdemeTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("temditTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediTutari");
				cell = row.createCell(++columnCount);
				cell.setCellValue("dovizCinsi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliAdi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliKimlikNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliUlke");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluAdi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluTel");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluKimlikTipi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluKimlikNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluAdres");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluEposta");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluTipi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluSermaye");
				cell = row.createCell(++columnCount);
				cell.setCellValue("nihaiKullanici");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluFaaliyet");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariGOTutari");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariGODoviz");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariGOTutUSD");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariGOIstKod");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariGOTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariFaizTutari");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariFaizDoviz");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariFaizTutUSD");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariFaizIstKod");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariFaizTarihi");
				columnCount = 0;
			}

			for (int rowNum = 1; rSet.next(); rowNum++) {
				Row row = sheet1.createRow(rowNum);
				columnCount = 0;

				Cell cell = row.createCell(columnCount);

				cell.setCellValue((rowNum));
				cell = row.createCell(++columnCount);

				cell.setCellValue(rSet.getString("kayitId"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("kayitTuru"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediTipi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("bankaKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("subeKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediNo"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediTuru"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("garantiVerenBankaKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("anlasmaTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("sonOdemeTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("temditTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediTutari"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("dovizCinsi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliAdi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliKimlikNo"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliUlke"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluAdi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluTel"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluKimlikTipi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluKimlikNo"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluAdres"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluEposta"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluTipi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluSermaye"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("nihaiKullanici"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluFaaliyet"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariGOTutari"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariGODoviz"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariGOTutUSD"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariGOIstKod"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariGOTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariFaizTutari"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariFaizDoviz"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariFaizTutUSD"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariFaizIstKod"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariFaizTarihi"));
				cell = row.createCell(++columnCount);

				columnCount = 0;

			}
			wb.write(fileOut);
			fileOut.close();

			sendMail("YuksekFrekansGeriOdeme", tempDosyaAdi, "TCMB Yuksek Frekans GeriOdeme GONDERIM Bilgilendirme");

		}
		catch (Exception e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}

	}

	private static void importKullanimDataToExcel(ResultSet rSet, String tempDosyaAdi) {
		XSSFWorkbook wb;
		try {
			wb = new XSSFWorkbook();
			XSSFSheet sheetKullanim = wb.createSheet("YuksekFrekansKullanim");
			XSSFSheet sheetTeminatBilgileri = wb.createSheet("teminatBilgileri");
			XSSFSheet sheetTaksitBilgileri = wb.createSheet("taksitBilgileri");

			FileOutputStream fileOut = new FileOutputStream(tempDosyaAdi);
			// Baslik satiri.
			int columnCount = 0;

			{
				Row row = sheetKullanim.createRow(0);
				Cell cell = row.createCell(columnCount);
				cell.setCellValue("SiraNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("KayitID");
				cell = row.createCell(++columnCount);
				cell.setCellValue("kayitTuru");
				cell = row.createCell(++columnCount);
				cell.setCellValue("gonZamani");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediTipi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("bankaKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("subeKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediTuru");
				cell = row.createCell(++columnCount);
				cell.setCellValue("teminatBilgileri");
				cell = row.createCell(++columnCount);
				cell.setCellValue("garantiVerenBankaKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("anlasmaTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("sonOdemeTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("temditTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("krediTutari");
				cell = row.createCell(++columnCount);
				cell.setCellValue("dovizCinsi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliAdi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliKimlikNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliKodu");
				cell = row.createCell(++columnCount);
				cell.setCellValue("alacakliUlke");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluAdi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluTel");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluKimlikTipi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluKimlikNo");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluAdres");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluEposta");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluTipi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluSermaye");
				cell = row.createCell(++columnCount);
				cell.setCellValue("nihaiKullanici");
				cell = row.createCell(++columnCount);
				cell.setCellValue("borcluFaaliyet");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariKulTutari");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariDoviz");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariKulTutUSD");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariIstKod");
				cell = row.createCell(++columnCount);
				cell.setCellValue("cariKulTarihi");
				cell = row.createCell(++columnCount);
				cell.setCellValue("faizTuru");
				cell = row.createCell(++columnCount);
				cell.setCellValue("spread");
				cell = row.createCell(++columnCount);
				cell.setCellValue("faizOrani");

				columnCount = 0;
				Row rowTeminat = sheetTeminatBilgileri.createRow(0);
				Cell cellTeminat = rowTeminat.createCell(columnCount);
				cellTeminat.setCellValue("KayitID");
				cellTeminat = rowTeminat.createCell(++columnCount);
				cellTeminat.setCellValue("teminatTuru");
				cellTeminat = rowTeminat.createCell(++columnCount);
				cellTeminat.setCellValue("teminatTuruPayi");

				columnCount = 0;
				Row rowTaksit = sheetTaksitBilgileri.createRow(0);
				Cell cellTaksit = rowTaksit.createCell(columnCount);
				cellTaksit.setCellValue("KayitID");
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue("taksitAnaparaTutari");
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue("taksitAnaparaTarih");
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue("taksitFaizTutari");
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue("TaksitFaizTarih");

				columnCount = 0;

			}

			for (int rowNum = 1; rSet.next(); rowNum++) {
				Row row = sheetKullanim.createRow(rowNum);
				columnCount = 0;
				Cell cell = row.createCell(columnCount);

				cell.setCellValue((rowNum));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("KayitID"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("kayitTuru"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("gonZamani"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediTipi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("bankaKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("subeKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediNo"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediTuru"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("teminatBilgileri"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("garantiVerenBankaKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("anlasmaTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("sonOdemeTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("temditTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("krediTutari"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("dovizCinsi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliAdi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliKimlikNo"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliKodu"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("alacakliUlke"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluAdi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluTel"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluKimlikTipi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluKimlikNo"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluAdres"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluEposta"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluTipi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluSermaye"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("nihaiKullanici"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("borcluFaaliyet"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariKulTutari"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariDoviz"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariKulTutUSD"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariIstKod"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("cariKulTarihi"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("faizTuru"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("spread"));
				cell = row.createCell(++columnCount);
				cell.setCellValue(rSet.getString("faizOrani").replace(".", ","));
				cell = row.createCell(++columnCount);

				/************************************* Sheet 2 Teminat Bilgileri *******************************************************************************/

				Row rowTeminat = sheetTeminatBilgileri.createRow(rowNum);
				columnCount = 0;

				Cell cellTeminat = rowTeminat.createCell(columnCount);

				cellTeminat.setCellValue(kayitIdGerekliMi(rSet));
				cellTeminat = rowTeminat.createCell(++columnCount);
				cellTeminat.setCellValue(rSet.getString("teminatTuru"));
				cellTeminat = rowTeminat.createCell(++columnCount);
				cellTeminat.setCellValue(rSet.getString("teminatTuruPayi"));
				cellTeminat = rowTeminat.createCell(++columnCount);

				/****************************************************** Sheet 3 Taksit Bilgileri ****************************************************************/

				Row rowTaksit = sheetTaksitBilgileri.createRow(rowNum);
				columnCount = 0;

				Cell cellTaksit = rowTaksit.createCell(columnCount);

				cellTaksit.setCellValue(rSet.getString("KayitID"));
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue(rSet.getString("taksitAnaparaTutari"));
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue(rSet.getString("taksitAnaparaTarih"));
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue(rSet.getString("taksitFaizTutari"));
				cellTaksit = rowTaksit.createCell(++columnCount);
				cellTaksit.setCellValue(rSet.getString("TaksitFaizTarih"));
				cellTaksit = rowTaksit.createCell(++columnCount);
				columnCount = 0;

			}

			wb.write(fileOut);
			fileOut.close();

			sendMail("YuksekFrekansKullanim", tempDosyaAdi, "TCMB Yuksek Frekans Kullan�m GONDERIM Bilgilendirme");

		}
		catch (Exception e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	private static String kayitIdGerekliMi(ResultSet rSet) throws SQLException {
		if (rSet.getString("teminatTuru") != null) {
			return rSet.getString("KayitID");
		}
		else {
			return null;
		}

	}

	private static String getKullanimFileName(GMMap iMap) {
		String tempDosyaAdi;
		iMap.put("PARAMETRE", "TCMB_PATH_FILE");
		String filePath = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
		iMap.put("PARAMETRE", "TCMB_FILE_NAME");
		String fileName = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
		iMap.put("PARAMETRE", "TCMB_FILE_WRITE_OPTIONS_PARAM");
		String options = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

		if (options.equals("0")) {
			tempDosyaAdi = ROOT + File.separator + "files" + File.separator + "YuksekFrekansKullanim" + ".xlsx";
		}
		else {
			tempDosyaAdi = filePath + File.separator + fileName + File.separator + "YuksekFrekansKullanim" + ".xlsx";
		}

		return tempDosyaAdi;
	}

	private static String getGeriOdemeFileName(GMMap iMap) {
		String tempDosyaAdi;
		iMap.put("PARAMETRE", "TCMB_PATH_FILE");
		String filePath = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
		iMap.put("PARAMETRE", "TCMB_FILE_NAME");
		String fileName = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
		iMap.put("PARAMETRE", "TCMB_FILE_WRITE_OPTIONS_PARAM");
		String options = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

		if (options.equals("0")) {
			tempDosyaAdi = ROOT + File.separator + "files" + File.separator + "YuksekFrekansGeriOdeme" + ".xlsx";
		}
		else {
			tempDosyaAdi = filePath + File.separator + fileName + File.separator + "YuksekFrekansGeriOdeme" + ".xlsx";
		}

		return tempDosyaAdi;
	}

	private static void sendMail(String fileName, String tempDosyaAdi, String mailSubject) throws IOException {
		GMMap mailMap = new GMMap();
		GMMap paramMap = new GMMap();

		mailMap.put("MAIL_FROM", "aktifbank@aktifbank.com.tr");
		paramMap.put("PARAMETRE", "TCMB_SPOT_DVZ_MAIL_TO");
		String mailTo = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", paramMap).get("DEGER").toString();
		mailMap.put("MAIL_TO", mailTo);
		mailMap.put("MAIL_SUBJECT", mailSubject);
		mailMap.put("MAIL_BODY", "TCMB i�in hazirlanan dosya ektedir.");
		mailMap.put("IS_BODY_HTML", "H");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", fileName + ".xlsx");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(tempDosyaAdi));
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
	}

}
