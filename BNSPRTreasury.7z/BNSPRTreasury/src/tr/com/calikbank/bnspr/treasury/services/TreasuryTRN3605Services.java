package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinSpotfwdSwiftDetail;
import tr.com.aktifbank.bnspr.dao.HznAltinSpotfwdSwiftTx;
import tr.com.aktifbank.bnspr.dao.HznAltinSpotfwdSwiftTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

    public class TreasuryTRN3605Services {
    @GraymoundService("BNSPR_TRN3605_GET_TRYINFO")
    public static GMMap getTRYInfo(GMMap iMap) {  
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();                
            stmt = conn.prepareCall("{? = call PKG_TRN3605.Sorgula(?,?,?,?,?,?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO")); //EK
            stmt.setString(i++, iMap.getString("DOVIZ_KOD")); //EK 
            stmt.setString(i++,iMap.getString("PAGE_MODE"));
            
            
            if(iMap.getDate("VALOR_ILK") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_ILK").getTime()));
            else
                stmt.setDate(i++,null);
            
//            if(iMap.getDate("VALOR_SON") != null)
//                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_SON").getTime()));
//            else
//                stmt.setDate(i++,null);
            
            if(iMap.getDate("ISLEM_ILK") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_ILK").getTime()));
            else
                stmt.setDate(i++,null);
            
            if(iMap.getDate("ISLEM_SON") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_SON").getTime()));
            else
                stmt.setDate(i++,null);
 
            
            
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);          
            
            return DALUtil.rSetResults(rSet,iMap.getString("LIST_NAME"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3605_GET_USDINFO")
    public static GMMap getUSDInfo(GMMap iMap) {  
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();                
            stmt = conn.prepareCall("{? = call PKG_TRN3605.Sorgula(?,?,?,?,?,?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO")); //EK
            stmt.setString(i++, iMap.getString("DOVIZ_KOD")); //EK
            stmt.setString(i++,iMap.getString("PAGE_MODE"));
            
            if(iMap.getDate("VALOR_ILK") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_ILK").getTime()));
            else
                stmt.setDate(i++,null);
            
//            if(iMap.getDate("VALOR_SON") != null)
//                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_SON").getTime()));
//            else
//                stmt.setDate(i++,null);
            
            if(iMap.getDate("ISLEM_ILK") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_ILK").getTime()));
            else
                stmt.setDate(i++,null);
            
            if(iMap.getDate("ISLEM_SON") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_SON").getTime()));
            else
                stmt.setDate(i++,null);
 
             stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);          
            
            return DALUtil.rSetResults(rSet,iMap.getString("LIST_NAME"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3605_GET_EURINFO")
    public static GMMap getEURInfo(GMMap iMap) {  
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();                
            stmt = conn.prepareCall("{? = call PKG_TRN3605.Sorgula(?,?,?,?,?,?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO")); //EK
            stmt.setString(i++, iMap.getString("DOVIZ_KOD")); //EK   
            stmt.setString(i++,iMap.getString("PAGE_MODE"));

            
            if(iMap.getDate("VALOR_ILK") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_ILK").getTime()));
            else
                stmt.setDate(i++,null);
            
//            if(iMap.getDate("VALOR_SON") != null)
//                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_SON").getTime()));
//            else
//                stmt.setDate(i++,null);
            
            if(iMap.getDate("ISLEM_ILK") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_ILK").getTime()));
            else
                stmt.setDate(i++,null);
            
            if(iMap.getDate("ISLEM_SON") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_SON").getTime()));
            else
                stmt.setDate(i++,null);
 
            
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);          
            
            return DALUtil.rSetResults(rSet,iMap.getString("LIST_NAME"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_TRN3605_VIEW_GET_USDINFO")
    public static GMMap getViewUSDInfo(GMMap iMap) {  
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();               
            stmt = conn.prepareCall("{? = call PKG_TRN3605.getInfo(?,?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO")); //EK
            stmt.setString(i++, iMap.getString("DOVIZ_KOD")); //EK
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);          
            
            return DALUtil.rSetResults(rSet,iMap.getString("LIST_NAME"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3605_VIEW_GET_EURINFO")
    public static GMMap getViewEurInfo(GMMap iMap) {  
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();                
            stmt = conn.prepareCall("{? = call PKG_TRN3605.getInfo(?,?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO")); //EK
            stmt.setString(i++, iMap.getString("DOVIZ_KOD")); //EK
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);          
            
            return DALUtil.rSetResults(rSet,iMap.getString("LIST_NAME"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3605_VIEW_GET_TRYINFO")
    public static GMMap getViewTryInfo(GMMap iMap) {  
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();                
            stmt = conn.prepareCall("{? = call PKG_TRN3605.getInfo(?,?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO")); //EK
            stmt.setString(i++, iMap.getString("DOVIZ_KOD")); //EK
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);          
            
            return DALUtil.rSetResults(rSet,iMap.getString("LIST_NAME"));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    

    @GraymoundService("GET_CUSTOMER_BY_TX_NO")
    public static GMMap getMusteriNo(GMMap iMap) {  
       GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();                
            stmt = conn.prepareCall("{? = call PKG_TRN3605.GetMusteri(?)}");
            int i = 1;  
            stmt.registerOutParameter(i++, -10); //
            stmt.setBigDecimal(i, iMap.getBigDecimal("TX_NO")); //EK
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);  
            while(rSet.next()){
            oMap.put("MUSTERI_NO" ,rSet.getBigDecimal("MUSTERI_NO"));
            oMap.put("MUSTERI_ADI",LovHelper.diLov( oMap.get("MUSTERI_NO"), "3605/LOV_MUSTERI", "UNVAN"));
            oMap.put("ISLEM" ,rSet.getString("ISLEM"));
            }
           
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
   
    @GraymoundService("BNSPR_TRN3605_CREATE_SWIFT_MESSAGE_NETLESTIRME")
    public static GMMap createSwiftMessageNetlestirme(GMMap iMap) {  
        
        GMMap oMap = new GMMap();
        
        try {
          
            if(iMap.getSize("USD_LIST")>0){
                Session session = DAOSession.getSession("BNSPRDal");
                    for(int i=0;i<iMap.getSize("USD_LIST");i++){
                        
                            HznAltinSpotfwdSwiftTx hznSpotFwdUsd = new HznAltinSpotfwdSwiftTx();
                            HznAltinSpotfwdSwiftTxId hznSpotFwdUsdId = new HznAltinSpotfwdSwiftTxId();                     
                            hznSpotFwdUsdId.setTxNo(iMap.getBigDecimal("TX_NO"));
                            hznSpotFwdUsd.setDovizTuru("USD");
                            hznSpotFwdUsd.setGonderimTarihi(new Date());
                            hznSpotFwdUsdId.setGonderimTxNo(iMap.getBigDecimal("USD_LIST",i,"GONDERIM_TX_NO"));
                            hznSpotFwdUsd.setMusteriNo(iMap.getBigDecimal("USD_LIST",i,"MUSTERI_NO"));
                            hznSpotFwdUsd.setTutar(iMap.getBigDecimal("USD_LIST",i,"ALIS_TUTARI").subtract(iMap.getBigDecimal("USD_LIST",i,"SATIS_TUTARI")));
                            if(hznSpotFwdUsd.getTutar().compareTo(BigDecimal.ZERO)<0){
                                hznSpotFwdUsd.setTutar(hznSpotFwdUsd.getTutar().multiply(BigDecimal.valueOf(-1)));
                            }
                            hznSpotFwdUsd.setGonderimTuru("SWIFT");
                            hznSpotFwdUsd.setGonderimDurumu("N");
                            hznSpotFwdUsd.setIslemTipi("NETLESTIRME");
                            hznSpotFwdUsd.setAlisSatis(iMap.getString("USD_LIST",i,"ALIS_SATIS"));
                            hznSpotFwdUsd.setId(hznSpotFwdUsdId);
                            session.saveOrUpdate(hznSpotFwdUsd);
                            session.flush();
 
                    }
            
            }
            
            if(iMap.getSize("TRY_LIST")>0){
                Session session = DAOSession.getSession("BNSPRDal");
                for(int i=0;i<iMap.getSize("TRY_LIST");i++){
                    
                    HznAltinSpotfwdSwiftTx hznSpotFwdTry = new HznAltinSpotfwdSwiftTx();
                    HznAltinSpotfwdSwiftTxId hznSpotFwdTryId = new HznAltinSpotfwdSwiftTxId();
                    
                     hznSpotFwdTryId.setTxNo(iMap.getBigDecimal("TX_NO"));
                     hznSpotFwdTry.setDovizTuru("TRY");
                     hznSpotFwdTry.setGonderimTarihi(new Date());
                     hznSpotFwdTryId.setGonderimTxNo(iMap.getBigDecimal("TRY_LIST",i,"GONDERIM_TX_NO"));   
                     hznSpotFwdTry.setMusteriNo(iMap.getBigDecimal("TRY_LIST",i,"MUSTERI_NO"));
                         hznSpotFwdTry.setTutar(iMap.getBigDecimal("TRY_LIST",i,"ALIS_TUTARI").subtract(iMap.getBigDecimal("TRY_LIST",i,"SATIS_TUTARI")));
                         if(hznSpotFwdTry.getTutar().compareTo(BigDecimal.ZERO)<0){
                             hznSpotFwdTry.setTutar(hznSpotFwdTry.getTutar().multiply(BigDecimal.valueOf(-1)));
                         }
                         hznSpotFwdTry.setGonderimTuru("EFT");
                         hznSpotFwdTry.setGonderimDurumu("N");
                         hznSpotFwdTry.setAlisSatis(iMap.getString("TRY_LIST",i,"ALIS_SATIS"));
                         hznSpotFwdTry.setId(hznSpotFwdTryId);
                         hznSpotFwdTry.setIslemTipi("NETLESTIRME");
                        session.saveOrUpdate(hznSpotFwdTry);
                        session.flush();
          
                    }
                
            }
                
            if(iMap.getSize("EUR_LIST")>0){
                Session session = DAOSession.getSession("BNSPRDal");
               
                for(int i=0;i<iMap.getSize("EUR_LIST");i++){
                       
                    HznAltinSpotfwdSwiftTx hznSpotFwdEur = new HznAltinSpotfwdSwiftTx();
                    HznAltinSpotfwdSwiftTxId hznSpotFwdEurId = new HznAltinSpotfwdSwiftTxId();                                        
                        hznSpotFwdEurId.setGonderimTxNo(iMap.getBigDecimal("EUR_LIST",i,"GONDERIM_TX_NO"));
                        hznSpotFwdEur.setDovizTuru("EUR");
                        hznSpotFwdEur.setGonderimTarihi(new Date());
                        hznSpotFwdEurId.setTxNo(iMap.getBigDecimal("TX_NO"));
                        hznSpotFwdEur.setTutar(iMap.getBigDecimal("EUR_LIST",i,"ALIS_TUTARI").subtract(iMap.getBigDecimal("EUR_LIST",i,"SATIS_TUTARI")));
                        if(hznSpotFwdEur.getTutar().compareTo(BigDecimal.ZERO)<0){
                            hznSpotFwdEur.setTutar(hznSpotFwdEur.getTutar().multiply(BigDecimal.valueOf(-1)));
                        }
                        hznSpotFwdEur.setMusteriNo(iMap.getBigDecimal("EUR_LIST",i,"MUSTERI_NO"));
                        hznSpotFwdEur.setId(hznSpotFwdEurId);
                        hznSpotFwdEur.setGonderimDurumu("N");
                        hznSpotFwdEur.setIslemTipi("NETLESTIRME");
                        hznSpotFwdEur.setAlisSatis(iMap.getString("EUR_LIST",i,"ALIS_SATIS"));
                        hznSpotFwdEur.setGonderimTuru("SWIFT");
                        session.saveOrUpdate(hznSpotFwdEur);
                        session.flush();                 
                }
            }
            
      
            return oMap;
       } catch (Exception e) {
           throw ExceptionHandler.convertException(e);
       } finally {
           
       }
    }
    //Netle�tir se�ene�i i�aretlenip kaydet denildi�inde �al���r.
    //Ekranda bulunan 3 ayr� listedeki al�� sat�� i�lemlerini birbirinden ��kararak tek  bir Al��/Sat�� kayd� elde eder,database e yazar.
    
    @GraymoundService("BNSPR_TRN3605_CREATE_SWIFT_MESSAGE_NETLESTIR")
    public static GMMap createSwiftMessageNetlestir(GMMap iMap) {  
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
     
         try {
           
             if(iMap.getSize("USD_LIST")>0){
                
                 
                 BigDecimal tutar = new BigDecimal(0);
                 BigDecimal xauTutar = new BigDecimal(0);
                 //Netle�tirme i�lemi yap�lan t�m kay�tlar�n netle�tirilmeden �nceki orjinal halleri hzn_altin_swift_detail tablosuna yaz�l�yor.
                     for(int i=0;i<iMap.getSize("USD_LIST");i++){
                         HznAltinSpotfwdSwiftDetail detail = new HznAltinSpotfwdSwiftDetail();                         
                         detail.setAlisTutari(iMap.getBigDecimal("USD_LIST",i,"ALIS_TUTARI"));
                         detail.setAlisXau(iMap.getString("USD_LIST",i,"ALIS_XAU"));
                         detail.setSatisXau(iMap.getString("USD_LIST",i,"SATIS_XAU"));
                         detail.setAsilTxNo(iMap.getBigDecimal("USD_LIST",i,"GONDERIM_TX_NO"));
                         detail.setMainTxNo(iMap.getBigDecimal("TRX_NO"));
                         detail.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                         detail.setReferans(iMap.getString("USD_LIST",i,"REFERANS"));
                         detail.setSatisTutari(iMap.getBigDecimal("USD_LIST",i,"SATIS_TUTARI"));
                         session.saveOrUpdate(detail);
                         session.flush();
                         tutar = tutar.add(iMap.getBigDecimal("USD_LIST",i,"ALIS_TUTARI"));
                         tutar =  tutar.subtract(iMap.getBigDecimal("USD_LIST",i,"SATIS_TUTARI"));
                        
                        }
                     
                   //Elde edilen netle�tirilmi� kay�t hzn_altin_swift_tx tablosuna yaz�l�r.
                         Map map  =GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap);
                         Object bd =  map.get("TRX_NO"); 
                             BigDecimal txNo = BigDecimal.valueOf(Long.valueOf(String.valueOf(bd)));
                             HznAltinSpotfwdSwiftTx hznSpotFwdUsd = new HznAltinSpotfwdSwiftTx();
                             HznAltinSpotfwdSwiftTxId hznSpotFwdUsdId = new HznAltinSpotfwdSwiftTxId();
                             hznSpotFwdUsdId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                             hznSpotFwdUsd.setDovizTuru("USD");
                             hznSpotFwdUsd.setGonderimTarihi(new Date());
                             hznSpotFwdUsd.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                             hznSpotFwdUsdId.setGonderimTxNo(txNo);
                             hznSpotFwdUsd.setIslemTipi("NETLESTIR");
                             tutar  = iMap.getBigDecimal("USD_USD_BAKIYE");
                             xauTutar = iMap.getBigDecimal("USD_XAU_BAKIYE");
                             if(tutar.compareTo(BigDecimal.ZERO)<0){
                                 hznSpotFwdUsd.setAlisSatis("A");
                                 tutar = tutar.multiply(BigDecimal.valueOf(-1));
                                 hznSpotFwdUsd.setSatisNetTutar(tutar);
                                 if(xauTutar.compareTo(BigDecimal.ZERO)<0)
                                     xauTutar = xauTutar.multiply(BigDecimal.valueOf(-1));
                                 hznSpotFwdUsd.setAlisNetTutar(xauTutar);    
                             }
                             else{
                                 hznSpotFwdUsd.setAlisSatis("S");
                                 xauTutar = xauTutar.multiply(BigDecimal.valueOf(-1));
                                 hznSpotFwdUsd.setSatisNetTutar(xauTutar);
                                 if(tutar.compareTo(BigDecimal.ZERO)<0)
                                      tutar =  tutar.multiply(BigDecimal.valueOf(-1));
                                 hznSpotFwdUsd.setAlisNetTutar(tutar);
                                 
                             }
                             hznSpotFwdUsd.setTutar(tutar);
                             hznSpotFwdUsd.setGonderimTuru("SWIFT");
                             hznSpotFwdUsd.setGonderimDurumu("N");
                             hznSpotFwdUsd.setId(hznSpotFwdUsdId);
                             session.saveOrUpdate(hznSpotFwdUsd);
                             session.flush();
                      
             
             }
             if(iMap.getSize("TRY_LIST")>0){
                 BigDecimal tutar = new BigDecimal(0);
                 BigDecimal xauTutar = new BigDecimal(0);
               //Netle�tirme i�lemi yap�lan t�m kay�tlar�n netle�tirilmeden �nceki orjinal halleri hzn_altin_swift_detail tablosuna yaz�l�yor.
                 for(int i=0;i<iMap.getSize("TRY_LIST");i++){
                     HznAltinSpotfwdSwiftDetail detail = new HznAltinSpotfwdSwiftDetail();                         
                     detail.setAlisTutari(iMap.getBigDecimal("TRY_LIST",i,"ALIS_TUTARI"));
                     detail.setAlisXau(iMap.getString("TRY_LIST",i,"ALIS_XAU"));
                     detail.setSatisXau(iMap.getString("TRY_LIST",i,"SATIS_XAU"));
                     detail.setAsilTxNo(iMap.getBigDecimal("TRY_LIST",i,"GONDERIM_TX_NO"));
                     detail.setMainTxNo(iMap.getBigDecimal("TRX_NO"));
                     detail.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                     detail.setReferans(iMap.getString("TRY_LIST",i,"REFERANS"));
                     detail.setSatisTutari(iMap.getBigDecimal("TRY_LIST",i,"SATIS_TUTARI"));
                     session.saveOrUpdate(detail);
                     
                     session.flush();                  
                     tutar= tutar.add(iMap.getBigDecimal("TRY_LIST",i,"ALIS_TUTARI"));
                     tutar= tutar.subtract(iMap.getBigDecimal("TRY_LIST",i,"SATIS_TUTARI"));
                    }
                 
                 //Elde edilen netle�tirilmi� kay�t hzn_altin_swift_tx tablosuna yaz�l�r.
                     Map map  =GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap);
                      Object bd =  map.get("TRX_NO"); 
                       BigDecimal txNo = BigDecimal.valueOf(Long.valueOf(String.valueOf(bd)));                  
                       HznAltinSpotfwdSwiftTx hznSpotFwdTry = new HznAltinSpotfwdSwiftTx();
                       HznAltinSpotfwdSwiftTxId hznSpotFwdTryId = new HznAltinSpotfwdSwiftTxId();
                      hznSpotFwdTryId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                      hznSpotFwdTry.setDovizTuru("TRY");
                      hznSpotFwdTry.setGonderimTarihi(new Date());
                      hznSpotFwdTryId.setGonderimTxNo(txNo);
                      hznSpotFwdTry.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                      hznSpotFwdTry.setIslemTipi("NETLESTIR");
                      tutar  = iMap.getBigDecimal("TRY_TRY_BAKIYE");
                      xauTutar = iMap.getBigDecimal("TRY_XAU_BAKIYE");
                      if(tutar.compareTo(BigDecimal.ZERO)<0){
                          hznSpotFwdTry.setAlisSatis("A");
                          tutar = tutar.multiply(BigDecimal.valueOf(-1));
                          hznSpotFwdTry.setSatisNetTutar(tutar);
                          
                          if(xauTutar.compareTo(BigDecimal.ZERO)<0)
                              xauTutar = xauTutar.multiply(BigDecimal.valueOf(-1));
                       hznSpotFwdTry.setAlisNetTutar(xauTutar);
                          
                      }
                      else{
                          hznSpotFwdTry.setAlisSatis("S");
                          xauTutar = xauTutar.multiply(BigDecimal.valueOf(-1));
                          hznSpotFwdTry.setSatisNetTutar(xauTutar);
                          if(tutar.compareTo(BigDecimal.ZERO)<0)
                              tutar = tutar.multiply(BigDecimal.valueOf(-1));
                          hznSpotFwdTry.setAlisNetTutar(tutar);
                      }
                      hznSpotFwdTry.setTutar(tutar);
                      hznSpotFwdTry.setGonderimTuru("EFT");
                      hznSpotFwdTry.setGonderimDurumu("N");
                      hznSpotFwdTry.setId(hznSpotFwdTryId);
                      session.saveOrUpdate(hznSpotFwdTry);
                      session.flush();
           
                 
             }
             if(iMap.getSize("EUR_LIST")>0){
                 BigDecimal tutar = new BigDecimal(0);
                 BigDecimal xauTutar = new BigDecimal(0);
                 //Netle�tirme i�lemi yap�lan t�m kay�tlar�n netle�tirilmeden �nceki orjinal halleri hzn_altin_swift_detail tablosuna yaz�l�yor.
                 for(int i=0;i<iMap.getSize("EUR_LIST");i++){                     
                     HznAltinSpotfwdSwiftDetail detail = new HznAltinSpotfwdSwiftDetail();                         
                     detail.setAlisTutari(iMap.getBigDecimal("EUR_LIST",i,"ALIS_TUTARI"));
                     detail.setAlisXau(iMap.getString("EUR_LIST",i,"ALIS_XAU"));
                     detail.setSatisXau(iMap.getString("EUR_LIST",i,"SATIS_XAU"));
                     detail.setAsilTxNo(iMap.getBigDecimal("EUR_LIST",i,"GONDERIM_TX_NO"));
                     detail.setMainTxNo(iMap.getBigDecimal("TRX_NO"));
                     detail.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                     detail.setReferans(iMap.getString("EUR_LIST",i,"REFERANS"));
                     detail.setSatisTutari(iMap.getBigDecimal("EUR_LIST",i,"SATIS_TUTARI"));
                     session.saveOrUpdate(detail);
                     session.flush();      
                     tutar= tutar.add(iMap.getBigDecimal("EUR_LIST",i,"ALIS_TUTARI"));
                     tutar=tutar.subtract(iMap.getBigDecimal("EUR_LIST",i,"SATIS_TUTARI"));
                    }
        
                 //Elde edilen netle�tirilmi� kay�t hzn_altin_swift_tx tablosuna yaz�l�r.
                          Map map  =GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap);
                         Object bd =  map.get("TRX_NO"); 
                         BigDecimal txNo = BigDecimal.valueOf(Long.valueOf(String.valueOf(bd)));
                         HznAltinSpotfwdSwiftTx hznSpotFwdEur = new HznAltinSpotfwdSwiftTx();
                         HznAltinSpotfwdSwiftTxId hznSpotFwdEurId = new HznAltinSpotfwdSwiftTxId();
                         hznSpotFwdEurId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                         hznSpotFwdEur.setDovizTuru("EUR");
                         hznSpotFwdEur.setGonderimTarihi(new Date());
                         hznSpotFwdEurId.setGonderimTxNo(txNo);
                         hznSpotFwdEur.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                         tutar  = iMap.getBigDecimal("EUR_EUR_BAKIYE");
                         xauTutar = iMap.getBigDecimal("EUR_XAU_BAKIYE");
                         if(tutar.compareTo(BigDecimal.ZERO)<0){
                             hznSpotFwdEur.setAlisSatis("A");
                             xauTutar = xauTutar.multiply(BigDecimal.valueOf(-1));
                             hznSpotFwdEur.setAlisNetTutar(xauTutar);
                             
                             if(tutar.compareTo(BigDecimal.ZERO)<0)
                                  tutar = tutar.multiply(BigDecimal.valueOf(-1));
                             hznSpotFwdEur.setSatisNetTutar(tutar);
                             
                         }
                         else{
                             hznSpotFwdEur.setAlisSatis("S");   
                             xauTutar = xauTutar.multiply(BigDecimal.valueOf(-1));
                             hznSpotFwdEur.setSatisNetTutar(xauTutar);
                             if(tutar.compareTo(BigDecimal.ZERO)<0)
                                  tutar = tutar.multiply(BigDecimal.valueOf(-1));
                             hznSpotFwdEur.setAlisNetTutar(tutar);
                         }
                         hznSpotFwdEur.setTutar(tutar);
                         hznSpotFwdEur.setGonderimTuru("SWIFT");
                         hznSpotFwdEur.setIslemTipi("NETLESTIR");
                         hznSpotFwdEur.setGonderimDurumu("N");
                         hznSpotFwdEur .setId(hznSpotFwdEurId);
                         session.saveOrUpdate(hznSpotFwdEur);
                         session.flush();
                    
             }
             
       
             return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            
        }
    }
    
    //Ekranda Netle�tir radiobutton u se�ildi�inde netleme i�lemi ekranda g�r�nt�lenmek �zere yap�l�p ekrana netle�en bilgiler g�nderiliyor.
    @GraymoundService("BNSPR_TRN3605_SELECT_NETLESTIR")
    public static GMMap onNetlestirSelectTed(GMMap iMap) {  
        GMMap oMap = new GMMap();
     
         try {
           
             if(iMap.getSize("USD_LIST")>0){
                
                 BigDecimal tutar = new BigDecimal(0);
                 BigDecimal tutarAux = new BigDecimal(0);
                     for(int i=0;i<iMap.getSize("USD_LIST");i++){
                         if(iMap.getString("USD_LIST",i,"ALIS_SATIS").equals("A")){
                             tutar= tutar.subtract(iMap.getBigDecimal("USD_LIST",i,"ALIS_TUTARI"));
                             tutarAux = tutarAux.add(iMap.getBigDecimal("USD_LIST",i,"ALIS_XAU"));
                          }else{                             
                             tutar= tutar.add(iMap.getBigDecimal("USD_LIST",i,"SATIS_TUTARI"));   
                             tutarAux = tutarAux.subtract(iMap.getBigDecimal("USD_LIST",i,"SATIS_XAU"));
                         }     
                          
                         
                        }
                     oMap.put("USD_BAKIYE" , tutar);
                     oMap.put("USD_XAU" , tutarAux);
             
             }
             if(iMap.getSize("TRY_LIST")>0){
                 
                 BigDecimal tutar = new BigDecimal(0);
                 BigDecimal tutarAux = new BigDecimal(0);
                 for(int i=0;i<iMap.getSize("TRY_LIST");i++){
                     if(iMap.getString("TRY_LIST",i,"ALIS_SATIS").equals("A")){
                         tutar= tutar.subtract(iMap.getBigDecimal("TRY_LIST",i,"ALIS_TUTARI"));
                         tutarAux = tutarAux.add(iMap.getBigDecimal("TRY_LIST",i,"ALIS_XAU"));
                         
                     }else{
                         
                         tutar= tutar.add(iMap.getBigDecimal("TRY_LIST",i,"SATIS_TUTARI")); 
                         tutarAux = tutarAux.subtract(iMap.getBigDecimal("TRY_LIST",i,"SATIS_XAU"));
                     }                   
                     
                     
                    }                 
                 oMap.put("TRY_BAKIYE" , tutar);
                 oMap.put("TRY_XAU" , tutarAux);
             }
             if(iMap.getSize("EUR_LIST")>0){
                 BigDecimal tutar = new BigDecimal(0);
                 BigDecimal tutarAux = new BigDecimal(0);
                 for(int i=0;i<iMap.getSize("EUR_LIST");i++){
                     if(iMap.getString("EUR_LIST",i,"ALIS_SATIS").equals("A")){
                         tutar= tutar.subtract(iMap.getBigDecimal("EUR_LIST",i,"ALIS_TUTARI"));
                         tutarAux = tutarAux.add(iMap.getBigDecimal("EUR_LIST",i,"ALIS_XAU"));
                         
                     }else{                         
                         tutar= tutar.add(iMap.getBigDecimal("EUR_LIST",i,"SATIS_TUTARI"));  
                         tutarAux = tutarAux.subtract(iMap.getBigDecimal("EUR_LIST",i,"SATIS_XAU"));
                         
                     }    
                    }
                 oMap.put("EUR_BAKIYE" , tutar);
                 oMap.put("EUR_XAU" , tutarAux);
             }
             
       
             return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            
        }
    }
    
    
    @GraymoundService("BNSPR_TRN3605_SAVE")
    public static GMMap save(GMMap iMap) {  
        try {
            
            //  Swift Mesaj� burda  g�nderilecek...           
           //   @GraymoundService("BNSPR_TRX_GET_TRANSACTION_NO")
            
            iMap.put("TRX_NAME" , "3605");
         return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
         
     } catch (Exception e) {
         throw ExceptionHandler.convertException(e);
     }
    }
    
    
    
    
  //  getInfo(pn_islem_no  number,pv_satis_doviz  varchar2)

}
