package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.MkkHesaplar;
import tr.com.aktifbank.bnspr.dao.MkkNitelikliYatirimci;
import tr.com.aktifbank.integration.mkk.MkkClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.mkk.ws.schemas.investor.DefineOrDeleteQualifiedInvestorInfoType;
import tr.com.mkk.ws.schemas.investor.DefineOrDeleteQualifiedInvestorType;
import tr.com.mkk.ws.schemas.mkkresponse.MkkResponseType;
import tr.com.mkk.ws.schemas.mkkresponse.ResponseType;
import tr.com.mkk.ws.schemas.types_1_0.AddOrRemoveType;
import tr.com.mkk.ws.schemas.types_1_0.RequestHeaderType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkInvestorServices {
    private static final Logger logger = Logger.getLogger(MkkInvestorServices.class);
    
    /**
     * MKK Nitelikli Yat�r�mc� tan�mlama silme servisi
     * @param iMap: iMap i�erisinde �u bilgiler olmal�d�r: 
     * "REGISTERY_NUMBER"(Yat�r�mc� MKK Sicil No), "MUSTERI_NO"(m��teri no), "PROCESS_TYPE"(��lem t�r�:E-Ekleme,S-Silme)
     * @return 
     */
    @GraymoundService("BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE")
    public static GMMap mkkDefineOrDeleteQualifiedInvestor(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            logger.info("MKK Nitelikli Yat�r�mc� Tan�mlama servisi �al��maya ba�lad�:[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]");
            
            if (iMap.getString("REGISTERY_NUMBER") == null || iMap.getString("REGISTERY_NUMBER").length() == 0){
                logger.error("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]: Nitelikli Yat�r�mc� tan�mlamak i�in REGISTERY_NUMBER g�nderilmelidir");
                throw new Exception("Nitelikli Yat�r�mc� tan�mlamak i�in REGISTERY_NUMBER(Yat�r�mc� MKK Sicil no) g�nderilmelidir");
            }
            else if (iMap.getString("MUSTERI_NO") == null || iMap.getString("MUSTERI_NO").length() == 0){
                logger.error("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]: Nitelikli Yat�r�mc� tan�mlamak i�in MUSTERI_NO g�nderilmelidir");
                throw new Exception("Nitelikli Yat�r�mc� tan�mlamak i�in MUSTERI_NO g�nderilmelidir");
            }
            else if (iMap.getString("PROCESS_TYPE") == null || iMap.getString("PROCESS_TYPE").length() == 0){
                logger.error("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]: Nitelikli Yat�r�mc� tan�mlamak i�in PROCESS_TYPE[E:Ekle, S:Sil] g�nderilmelidir");
                throw new Exception("Nitelikli Yat�r�mc� tan�mlamak i�in PROCESS_TYPE[E:Ekle, S:Sil] g�nderilmelidir");
            }
            else if (!"E".equals(iMap.getString("PROCESS_TYPE")) && !"S".equals(iMap.getString("PROCESS_TYPE"))){ //Sadece E:Ekle veya S:Sil olabilir
                logger.error("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]: Nitelikli Yat�r�mc� tan�mlamak i�in PROCESS_TYPE[E:Ekle, S:Sil] se�eneklerinden biri olmal�d�r, g�nderilen:" + iMap.getString("PROCESS_TYPE"));
                throw new Exception("Nitelikli Yat�r�mc� tan�mlamak i�in PROCESS_TYPE[E:Ekle, S:Sil] se�eneklerinden biri olmal�d�r, g�nderilen:" + iMap.getString("PROCESS_TYPE"));
            }
            else{//Parametreler OK, MKK'y� �a��rabiliriz
                Session session = DAOSession.getSession("BNSPRDal");
                
                BigDecimal newID = saveNYRequest(iMap);
                MkkNitelikliYatirimci nyGon = (MkkNitelikliYatirimci)session.get(MkkNitelikliYatirimci.class , newID);
                
                if (nyGon != null){
                    logger.info("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE] g�nderilecek kay�t:" + nyGon.getNyId());
                    
                    DefineOrDeleteQualifiedInvestorType invType = new DefineOrDeleteQualifiedInvestorType();
                    DefineOrDeleteQualifiedInvestorInfoType invInfoType = new DefineOrDeleteQualifiedInvestorInfoType();
                    
                    invInfoType.setMemberCode(nyGon.getMemberCode());
                    invInfoType.setProcessType(AddOrRemoveType.fromValue(nyGon.getProcessType()));
                    invInfoType.setRegistryNumber(nyGon.getRegisteryNumber());
                    
                    invType.setDefineOrDeleteQualifiedInvestorInfo(invInfoType);
                    
                    RequestHeaderType reqHeader = new RequestHeaderType();
                    reqHeader.setSenderMember(nyGon.getSenderMember());
                    reqHeader.setSenderReference(nyGon.getSenderReference());
                    
                    invType.setRequestHeader(reqHeader);
                    
                    MkkResponseType response = MkkClient.getMkkInvestorService().defineOrDeleteQualifiedInvestor(invType);
                    logger.info("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE] g�nderildi, ID:" + nyGon.getNyId());
                    MkkHaKeBatchService.saveMkkResponse(response);
                    
                    if (response != null){
                        ResponseType responseType = response.getResponse();
                        logger.info("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE] ID:[" + nyGon.getNyId() + "], response code:[" + responseType.getResponseCode() + "], response desc:[" + responseType.getResponseDesc() + "]");
                        
                        nyGon.setResponseCode(responseType.getResponseCode());
                        nyGon.setResponseDesc(responseType.getResponseDesc());
                        
                        if ("0000".equals(responseType.getResponseCode())){
                            nyGon.setDurum("A"); // Ba�ar�l� Tamamland�
                        } else{
                            nyGon.setDurum("H"); // Ba�ar�s�z Hatal�
                        }
                        
                        session.update(nyGon);
                        
                        //MKK_HESAPLAR tablosunda m��terinin sicil numaras�n� ve  niteliklilik durumunu g�ncelleyelim.
                        MkkHesaplar mkkHesap = (MkkHesaplar)session.get(MkkHesaplar.class , nyGon.getMusteriNo());
                        if (mkkHesap != null){
                            if (iMap.getString("PROCESS_TYPE").equals("E")){ //Ekle
                                mkkHesap.setNitelikli("E");
                            } 
                            else if (iMap.getString("PROCESS_TYPE").equals("S")){ //Sil
                                mkkHesap.setNitelikli("H");
                            }
                            mkkHesap.setMkkSicilNo(nyGon.getRegisteryNumber());
                            session.update(mkkHesap);
                        }
                        try{
                            //GNL_MUSTERI tablosunda da m��terinin mkk sicil numaras�n� g�ncelleyelim.
                            GnlMusteri gnlMusteri = (GnlMusteri)session.get(GnlMusteri.class , nyGon.getMusteriNo());
                            gnlMusteri.setMkkSicilno(nyGon.getRegisteryNumber());
                            session.update(mkkHesap);
                        }
                        catch(Exception e){
                            logger.info(nyGon.getMusteriNo() + " nolu m��terinin MKK sicilini g�ncelleyemedik, can sa�l���.");
                            logger.error("mkk sicil g�ncellemede hata:", e);
                        }
                        session.flush();
                    }
                }
            }
            logger.info("MKK Nitelikli Yat�r�mc� Tan�mlama servisi tamamland�, [BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]");
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE")
    public static GMMap mkkQualifiedInvestorCollective(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            logger.info("MKK Nitelikli Yat�r�mc� Toplu G�nderim servisi �al��maya ba�lad�:[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE]");
            
            Session session = DAOSession.getSession("BNSPRDal");

            Criteria criteria = session.createCriteria(MkkNitelikliYatirimci.class).add(Restrictions.eq("durum" , "G")).addOrder(Order.asc("nyId"));
            List<?> list = criteria.list();
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                MkkNitelikliYatirimci nyGon = (MkkNitelikliYatirimci)iterator.next();
                logger.info("[BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE] g�nderilecek kay�t:" + nyGon.getNyId());

                if (nyGon != null){
                    
                    DefineOrDeleteQualifiedInvestorType invType = new DefineOrDeleteQualifiedInvestorType();
                    DefineOrDeleteQualifiedInvestorInfoType invInfoType = new DefineOrDeleteQualifiedInvestorInfoType();
                    
                    invInfoType.setMemberCode(nyGon.getMemberCode());
                    invInfoType.setProcessType(AddOrRemoveType.fromValue(nyGon.getProcessType()));
                    invInfoType.setRegistryNumber(nyGon.getRegisteryNumber());
                    
                    invType.setDefineOrDeleteQualifiedInvestorInfo(invInfoType);
                    
                    RequestHeaderType reqHeader = new RequestHeaderType();
                    reqHeader.setSenderMember(nyGon.getSenderMember());
                    reqHeader.setSenderReference(nyGon.getSenderReference());
                    
                    invType.setRequestHeader(reqHeader);
                    
                    MkkResponseType response = MkkClient.getMkkInvestorService().defineOrDeleteQualifiedInvestor(invType);
                    logger.info("[BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE] g�nderildi, ID:" + nyGon.getNyId());
                    MkkHaKeBatchService.saveMkkResponse(response);
                    
                    if (response != null){
                        ResponseType responseType = response.getResponse();
                        logger.info("[BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE] ID:[" + nyGon.getNyId() + "], response code:[" + responseType.getResponseCode() + "], response desc:[" + responseType.getResponseDesc() + "]");
                        
                        nyGon.setResponseCode(responseType.getResponseCode());
                        nyGon.setResponseDesc(responseType.getResponseDesc());
                        
                        if ("0000".equals(responseType.getResponseCode())){
                            nyGon.setDurum("A"); // Ba�ar�l� Tamamland�
                        } else{
                            nyGon.setDurum("H"); // Ba�ar�s�z Hatal�
                        }
                        
                        session.update(nyGon);
                        
                        //MKK_HESAPLAR tablosunda m��terinin sicil numaras�n� ve  niteliklilik durumunu g�ncelleyelim.
                        MkkHesaplar mkkHesap = (MkkHesaplar)session.get(MkkHesaplar.class , nyGon.getMusteriNo());
                        if (mkkHesap != null){
                            if ("E".equals(nyGon.getProcessType())){ //Ekle
                                mkkHesap.setNitelikli("E");
                            } 
                            else if ("S".equals(nyGon.getProcessType())){ //Sil
                                mkkHesap.setNitelikli("H");
                            }
                            mkkHesap.setMkkSicilNo(nyGon.getRegisteryNumber());
                            session.update(mkkHesap);
                        }
                        session.flush();
                    }
                }
            }
            logger.info("MKK Nitelikli Yat�r�mc� Toplu G�nderim servisi tamamland�, [BNSPR_MKK_NITELIKLI_YAT_TOPLU_GON_SERVICE]");
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    private static BigDecimal saveNYRequest(GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        
        MkkNitelikliYatirimci nyNew = new MkkNitelikliYatirimci();
        BigDecimal id = newId("MKK_NY_ID");
        nyNew.setNyId(id);
        if (iMap.getString("KE_ID") !=null && iMap.getString("KE_ID").startsWith("KE-")){
            nyNew.setKeId(new BigDecimal(iMap.getString("KE_ID").substring(3)));
        }
        nyNew.setDurum("G"); //G�nderilebilir
        nyNew.setSenderMember("AFB");
        nyNew.setSenderReference("NY-" + id.toString());
        nyNew.setProcessType(iMap.getString("PROCESS_TYPE")); //��lem T�r� E:Ekleme S:Silme
        nyNew.setMemberCode("AFB");
        nyNew.setRegisteryNumber(iMap.getString("REGISTERY_NUMBER"));
        nyNew.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
        
        session.save(nyNew);
        session.flush();
        
        return id;
    }

    private static BigDecimal newId(String key){
        GMMap map = new GMMap();
        map.put("TABLE_NAME" , key);
        return (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", map).get("ID");        
    }
}
