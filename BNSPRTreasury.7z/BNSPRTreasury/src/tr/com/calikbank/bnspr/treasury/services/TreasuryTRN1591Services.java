package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznAltinAlinandepoTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.VdmkDevirTx;
import tr.com.aktifbank.bnspr.dao.VdmkDevirTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDovizKodPr;
import tr.com.calikbank.bnspr.dao.HznNettingOzetTx;
import tr.com.calikbank.bnspr.dao.HznNettingOzetTxId;
import tr.com.calikbank.bnspr.dao.HznNettingTx;
import tr.com.calikbank.bnspr.dao.HznNettingTxId;
import tr.com.calikbank.bnspr.dao.HznSwapTx;
import tr.com.calikbank.bnspr.dao.HznTurevBsmvistisnaTx;
import tr.com.calikbank.bnspr.dao.HznTurevBsmvistisnaTxId;
import tr.com.calikbank.bnspr.dao.NettingAnlasmaPrTx;
import tr.com.calikbank.bnspr.dao.NettingAnlasmaPrTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import tr.com.calikbank.bnspr.util.DALUtil;


public class TreasuryTRN1591Services {


	@GraymoundService("BNSPR_TRN1591_SAVE")
	public static Map<?, ?> save1591(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "TABLE_ANLASMA";
			List<?> listTable = (List<?>) iMap.get(tableName);
			String bankaMusteriNo= ""; String dovizKodu= ""; BigDecimal txNo=null; String muhabirMusteriNo=""; 
			String odemetahsilat =""; String referans = ""; 
			txNo = iMap.getBigDecimal("TRX_NO");

			for (int i = 0; i < listTable.size(); i++) {
			//	if(iMap.getBoolean(tableName , i , "SEC"))
			//	{
					
					referans = iMap.getString(tableName,i,"ISLEM_REFERANS");
					if(iMap.getString(tableName,i,"ALIS_SATIS").equals("A")) odemetahsilat ="TAHSILAT";
					else odemetahsilat ="ODEME";
					dovizKodu = iMap.getString(tableName,i,"DOVIZ_KODU");
					HznNettingTx hznNettingTx = (HznNettingTx) session.createCriteria(HznNettingTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.islemReferans",referans)).add(Restrictions.eq("id.dovizKodu", dovizKodu)).add(Restrictions.eq("id.odemeTahsilat", odemetahsilat)).uniqueResult();

					HznNettingTxId hznNettingTxId  = null;
					if(hznNettingTx == null) {
						hznNettingTx = new HznNettingTx();
						hznNettingTxId = new HznNettingTxId();
						hznNettingTxId.setTxNo(txNo);
						hznNettingTxId.setIslemReferans(referans);
						hznNettingTxId.setOdemeTahsilat(odemetahsilat);
						hznNettingTxId.setDovizKodu(dovizKodu);
					}
					else{
						hznNettingTxId= hznNettingTx.getId();
					}
					hznNettingTx.setId(hznNettingTxId);
					hznNettingTx.setBankaMusteriNo(iMap.getString(tableName,i,"MUSTERI_NO"));
					hznNettingTx.setIslemKod(iMap.getBigDecimal(tableName,i,"ISLEM_KOD"));
					hznNettingTx.setMuhabirMusteriNo(iMap.getString(tableName,i,"MUHABIR_BANKA"));
					hznNettingTx.setTutar(iMap.getBigDecimal(tableName,i,"TUTAR"));
					hznNettingTx.setValorTarihi(iMap.getDate(tableName,i,"VALOR_TARIHI"));
					if(iMap.getString("N_OR_G").equals("G"))
						hznNettingTx.setGrossMu('E');
					else 
						hznNettingTx.setGrossMu('H');
					if(iMap.getBoolean(tableName , i , "SEC"))
						 hznNettingTx.setSecili("E");
					else hznNettingTx.setSecili("H");
				    
					hznNettingTx.setKarsiDovizKodu(iMap.getString(tableName,i,"KARSI_DOVIZ_KODU"));
					hznNettingTx.setKarsiTutar(iMap.getBigDecimal(tableName,i,"KARSI_TUTAR"));
					hznNettingTx.setHesapNo(iMap.getBigDecimal(tableName,i,"HESAP_NO"));
					hznNettingTx.setHesapTuru("MUHABIR");
					
					session.saveOrUpdate(hznNettingTx);
			//	}
			}
			
	    	HznNettingOzetTx hznNettingOzetTx = (HznNettingOzetTx)session.get(HznNettingOzetTx.class, txNo);

			if(hznNettingOzetTx == null) {
				hznNettingOzetTx = new HznNettingOzetTx();
				hznNettingOzetTx.setTxNo(txNo);
			}

			if(iMap.getString("N_OR_G").equals("N")){ //NETLEME ISE
				
				hznNettingOzetTx.setReferans(txNo + "");
				hznNettingOzetTx.setBankaMusteriNo(iMap.getString("MUSTERI_NO_OZET"));//MUSTERI_NO_OZET
				hznNettingOzetTx.setDovizKodu(iMap.getString("DOVIZ_KODU_OZET")); //DOVIZ_KODU_OZET
				hznNettingOzetTx.setGrossMu('H');
				hznNettingOzetTx.setMuhabirMusteriNo(iMap.getString("KARSI_MUHABIR_OZET")); 
				hznNettingOzetTx.setOdemeTahsilat(iMap.getString("NETLEME_YONU"));
				hznNettingOzetTx.setTutar(iMap.getBigDecimal("NETLENEN_TUTAR"));
				hznNettingOzetTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
				hznNettingOzetTx.setHesapTuru("MUHABIR");
				hznNettingOzetTx.setHesapNo(iMap.getBigDecimal("HESAP_NO_OZET"));
				hznNettingOzetTx.setDurumKodu("A");
				if (iMap.getBoolean("EMAIL_GONDER"))  hznNettingOzetTx.setEmailGonder("E");
				else hznNettingOzetTx.setEmailGonder("H");
				session.saveOrUpdate(hznNettingOzetTx);
			}
			else // gross ise ayn� kay�tlar� ozet tablosuna da at, sebep: swift ortak bir tablodan beslenecek.
			{
				for (int i = 0; i < listTable.size(); i++) { // yaln�zca bir gross kay�t se�ilebilir
			     if(iMap.getBoolean(tableName , i , "SEC"))
				 {					
				    hznNettingOzetTx.setReferans(iMap.getString(tableName,i,"ISLEM_REFERANS"));
					hznNettingOzetTx.setBankaMusteriNo(iMap.getString(tableName,i,"MUSTERI_NO"));//MUSTERI_NO_OZET
					hznNettingOzetTx.setDovizKodu(iMap.getString(tableName,i,"DOVIZ_KODU")); //DOVIZ_KODU_OZET
					hznNettingOzetTx.setGrossMu('E');
					hznNettingOzetTx.setMuhabirMusteriNo(iMap.getString(tableName,i,"MUHABIR_BANKA")); 
					if(iMap.getString(tableName,i,"ALIS_SATIS").equals("A"))
						hznNettingOzetTx.setOdemeTahsilat("TAHSILAT");
					else 
						hznNettingOzetTx.setOdemeTahsilat("ODEME");						
					hznNettingOzetTx.setTutar(iMap.getBigDecimal(tableName,i,"TUTAR"));
					hznNettingOzetTx.setValorTarihi(iMap.getDate(tableName,i,"VALOR_TARIHI"));
					hznNettingOzetTx.setHesapTuru("MUHABIR");
					hznNettingOzetTx.setHesapNo(iMap.getBigDecimal(tableName,i,"HESAP_NO"));
					hznNettingOzetTx.setDurumKodu("A");
					if (iMap.getBoolean("EMAIL_GONDER"))  hznNettingOzetTx.setEmailGonder("E");
					else hznNettingOzetTx.setEmailGonder("H");
					session.saveOrUpdate(hznNettingOzetTx);

				 }
			   }
			}
			session.flush();

			GMMap oMap = new GMMap();
			
			return oMap;
			/*iMap.put("TRX_NAME", "1591");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);*/
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1591_GET_INFO")
	public static GMMap getInfo1591(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			@SuppressWarnings("unchecked")
			List<HznNettingTx> netlemeList = session.createCriteria(HznNettingTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			String tn = "TABLE_NETLEME";
			String bankaMusteriNo =""; String unvan=""; String dovizKodu = ""; Date valorTarihi =null; String musteriMuhabirNo="";
			
			for (HznNettingTx kayit : netlemeList) {

				bankaMusteriNo = kayit.getBankaMusteriNo();
				unvan = LovHelper.diLov(kayit.getBankaMusteriNo(), "1591/LOV_BANKA_MUSTERI", "UNVAN");
				dovizKodu = kayit.getId().getDovizKodu();
				valorTarihi = kayit.getValorTarihi();
				musteriMuhabirNo = kayit.getMuhabirMusteriNo();
				oMap.put(tn, i,     "MUSTERI_NO",bankaMusteriNo);
				oMap.put(tn, i,     "UNVAN",unvan);
				oMap.put(tn, i,     "TUTAR",kayit.getTutar());
				oMap.put(tn, i,     "DOVIZ_KODU",dovizKodu);
				oMap.put(tn, i,     "VALOR_TARIHI",valorTarihi);
				oMap.put(tn, i,     "ISLEM_KOD",kayit.getIslemKod());  
				oMap.put(tn, i,     "KARSI_DOVIZ_KODU",kayit.getKarsiDovizKodu());  
				oMap.put(tn, i,     "KARSI_TUTAR",kayit.getKarsiTutar());  
				if(kayit.getId().getOdemeTahsilat().equals("TAHSILAT"))
					oMap.put(tn,  i,    "ALIS_SATIS", "A");
				else oMap.put(tn,  i,    "ALIS_SATIS", "S");
				oMap.put(tn, i,     "ISLEM_REFERANS",kayit.getId().getIslemReferans()); 
				if(kayit.getSecili().equals("E")) oMap.put(tn,  i,    "SEC", true);
				else 						      oMap.put(tn,  i,    "SEC", false);
				oMap.put(tn, i,   "HESAP_NO",kayit.getHesapNo());
				oMap.put(tn, i++,   "MUHABIR_BANKA",musteriMuhabirNo);

			}

			HznNettingOzetTx ozet = (HznNettingOzetTx)session.get(HznNettingOzetTx.class, iMap.getBigDecimal("TRX_NO"));

		    //if (ozet.getGrossMu() == 'H'){
	            oMap.put("BANKA_MUSTERINO_OZET", ozet.getBankaMusteriNo());
	            oMap.put("BANKA_UNVAN_OZET", LovHelper.diLov(ozet.getBankaMusteriNo(), "1591/LOV_BANKA_MUSTERI", "UNVAN"));
	            oMap.put("NETLENEN_TUTAR", ozet.getTutar());
	            oMap.put("NETLEME_YONU", ozet.getOdemeTahsilat());
	            oMap.put("MUHABIR_HESAP_NO_OZET", ozet.getHesapNo());
	            oMap.put("DOVIZ_KODU_OZET",ozet.getDovizKodu());
	            oMap.put("MUHABIR_NO_OZET", ozet.getMuhabirMusteriNo());
		   // }
		    if (ozet.getEmailGonder().equals("E"))
		    	 oMap.put("EMAIL_GONDER",true);
		    else oMap.put("EMAIL_GONDER",false);
		    
		    oMap.put("REFERANS",ozet.getReferans());
		    
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
    @GraymoundService("BNSPR_TRN1591_GET_TRANSACTIONS")
    public static GMMap getTransactions(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            String func = "{? = call pkg_trn1591.GetTransactions(?,?,?)}";
            Object [] values  = new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
            		                          BnsprType.DATE, iMap.getDate("VALOR_TARIHI"),
            		                          BnsprType.STRING, iMap.getString("MUHABIR_NO")
            								  };

            oMap = DALUtil.callOracleRefCursorFunction(func , "TABLE_NETLEME" , values);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
	@GraymoundService("BNSPR_TRN1591_TARIH_KONTROL") //valor tarihi T,T+1 ve T+2 olabilir, return value 1 ise pass, 0 ise failure
	public static GMMap tarihKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN1591.Tarih_Kontrol(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);	
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.execute();
			
			//oMap.put("TARIH_KONTROL",stmt.getString(1));
			oMap.put("TARIH_KONTROL","1"); //tarih kontrol kald�r�ld�
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	@GraymoundService("BNSPR_TRN1591_NETLE_KONTROL") //netlenecek kay�t se�me kontrolu
	public static GMMap netlemeKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			String tableName = "TABLE_NETLEME";
            List<?> satirBilgileri = (List<?>) iMap.get(tableName);
            int totalcount = 0;
            int chosencount = 0;
            String kontrolMesaj ="";
            Date valorTarihi = iMap.getDate("VALOR_TARIHI");
            Date bankaTarihi = iMap.getDate("BANKA_TARIHI");
            if(iMap.getString("DOVIZ_KODU").equals("TRY") && valorTarihi.compareTo(bankaTarihi) != 0 ){
            	kontrolMesaj ="TRY d�viz kodlu netlemeler i�in val�r tarihi g�n�n tarihi olmal�d�r.";
            }
            else{
	            for (int i = 0; i < satirBilgileri.size(); i++){
	            	totalcount++;
	                if (iMap.getBoolean(tableName , i , "SEC")){
	                	chosencount++;
	                }              
	            }
	            if (totalcount == 0) kontrolMesaj  ="Listede netlenecek kay�t yok.";
	            else if (chosencount == 0) kontrolMesaj ="Listede netlenecek kay�t se�mediniz.";
	            //else if(totalcount !=chosencount) kontrolMesaj="0";
            }

            
			oMap.put("NETLE_KONTROL",kontrolMesaj);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	@GraymoundService("BNSPR_TRN1591_KAYITSEC") //netleme sonuc
	public static GMMap kayitSec(GMMap iMap){

		try{
			String tableName = "TABLE_NETLEME";
			List<?> satirBilgileri = (List<?>) iMap.get(tableName);
			String doviz_kodu =iMap.getString("DOVIZ_KODU");
            for (int i = 0; i < satirBilgileri.size(); i++){
            	if(iMap.getString(tableName , i , "DOVIZ_KODU").equals(doviz_kodu))
            	{
            	      iMap.put(tableName,i,"SEC", true);
            	}
            	else  iMap.put(tableName,i,"SEC", false);

            }
            
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	@GraymoundService("BNSPR_TRN1591_ONAYDA_KAYIT_VARMI") //onayda bekleyen hazine i�lemi var m�
	public static GMMap onaydaKayitVarmi(GMMap iMap)
	{
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{			 
	        conn = DALUtil.getGMConnection();
		  	stmt = conn.prepareCall("{ ? = call PKG_TRN1591.Onay_Kayit_Kontrol(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);	
			stmt.setString(i++, iMap.getString("MUSTERI_NO"));
			stmt.execute();

			 oMap.put("ONAYDA_KAYIT_VARMI",stmt.getString(1));
			 return oMap;
	     }
		 catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		  } 
		 finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
    }
	
	@GraymoundService("BNSPR_TRN1591_NETLE") //netleme sonuc
	public static GMMap netle(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			String tableName = "TABLE_NETLEME";
            List<?> satirBilgileri = (List<?>) iMap.get(tableName);
            BigDecimal alisToplamTutar = new BigDecimal(0);
            BigDecimal satisToplamTutar = new BigDecimal(0);
            BigDecimal netlenenTutar = new BigDecimal(0);
            String hesapNo = ""; //iMap.getString(tableName , 0 , "HESAP_NO");
            String netlemeYonu = "";
            String musteri_no =iMap.getString(tableName , 0 , "MUSTERI_NO");
            String unvan =iMap.getString(tableName , 0 , "UNVAN");
            String doviz_kodu =""; //iMap.getString(tableName , 0 , "DOVIZ_KODU");
            String muhabir_banka="";//iMap.getString(tableName , 0 , "MUHABIR_BANKA");
		    HashSet<String> unique = new LinkedHashSet<String>();	    
		    HashSet<String> unique2 = new LinkedHashSet<String>();
		    HashSet<String> unique3 = new LinkedHashSet<String>();

            for (int i = 0; i < satirBilgileri.size(); i++){

                if (iMap.getBoolean(tableName , i , "SEC")){ // sadece se�ili sat�rdakileri netle
                	
                	String value = iMap.getString(tableName , i , "MUHABIR_BANKA");
     		        if(unique.add(value)==true) unique.add(value);
     		        muhabir_banka = value;
     		        
                	String value2 = iMap.getString(tableName , i , "HESAP_NO");
     		        if(unique2.add(value2)==true) unique2.add(value2);
     		        hesapNo =value2;
     		        
                	String value3 = iMap.getString(tableName , i , "DOVIZ_KODU");
     		        if(unique3.add(value3)==true) unique3.add(value3);
     		        doviz_kodu = value3;
     		        
                	if(iMap.getString(tableName , i , "ALIS_SATIS").equals("A"))
                		alisToplamTutar = alisToplamTutar.add(iMap.getBigDecimal(tableName , i , "TUTAR"));
                	else 
                		satisToplamTutar = satisToplamTutar.add(iMap.getBigDecimal(tableName , i , "TUTAR"));                		
                }                
            }
            
			if (unique3.size()>1)
			{
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Farkl� doviz koduna sahip se�ili kay�tlar var. Devam edemezsiniz." );
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			if (unique.size()>1)
			{
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Farkl� kar�� muhabire sahip se�ili kay�tlar var. Devam edemezsiniz." );
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			if (unique2.size()>1)
			{
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Farkl� arac� banka hesap numaras�na sahip se�ili kay�tlar var. Devam edemezsiniz." );
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
            if (alisToplamTutar.compareTo(satisToplamTutar)==1)
            {
            	netlemeYonu = "TAHSILAT";
            	netlenenTutar = alisToplamTutar.subtract(satisToplamTutar);
            }
            else if  (alisToplamTutar.compareTo(satisToplamTutar)==-1)
            {
            	netlemeYonu = "ODEME";
            	netlenenTutar = satisToplamTutar.subtract(alisToplamTutar);
            }
            else 
            {
            	netlenenTutar = satisToplamTutar.subtract(alisToplamTutar);           	
            }
            
            oMap.put("MUSTERI_NO", musteri_no);
            oMap.put("UNVAN", unvan);
            oMap.put("DOVIZ_KODU", doviz_kodu);
            oMap.put("MUHABIR_BANKA", muhabir_banka);
            oMap.put("NETLEME_YONU", netlemeYonu);
            oMap.put("NETLENEN_TUTAR", netlenenTutar);
            oMap.put("HESAP_NO", hesapNo);


			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
		
	@GraymoundService("BNSPR_TRN1591_GROSS_KONTROL") //netlenecek kay�t se�me kontrolu
	public static GMMap grossKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			String tableName = "TABLE_NETLEME";
            List<?> satirBilgileri = (List<?>) iMap.get(tableName);
            int totalcount = 0;
            int chosencount = 0;
            String kontrolMesaj ="";
            for (int i = 0; i < satirBilgileri.size(); i++){
            	totalcount++;
                if (iMap.getBoolean(tableName , i , "SEC")){
                	chosencount++;
                }              
            }
            if (totalcount == 0) kontrolMesaj  ="Listede Gross g�nderilecek kay�t yok.";
            else if (chosencount == 0) kontrolMesaj ="Listede Gross g�nderilecek kay�t se�mediniz.";
            else if (chosencount>1 ) kontrolMesaj ="Tek seferde yaln�zca 1 adet Gross g�nderilecek kay�t se�melisiniz.";
			oMap.put("GROSS_KONTROL",kontrolMesaj);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_TRN1591_EMAIL_KONTROL") //email kontrolu
	public static GMMap emailKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			String tableName = "TABLE_NETLEME";
            List<?> satirBilgileri = (List<?>) iMap.get(tableName);
            int totalcount = 0;
            int chosencount = 0;
            String kontrolMesaj ="";
            String email = "";
            for (int i = 0; i < satirBilgileri.size(); i++){
            	totalcount++;
                if (iMap.getBoolean(tableName , i , "SEC")){
                	chosencount++;
                	email = iMap.getString(tableName , i , "EMAIL");
                }              
            }
            if (totalcount == 0) kontrolMesaj  ="Listede email g�nderilecek kay�t yok.";
            else if (chosencount == 0) kontrolMesaj ="Listede email g�nderilecek kay�t se�mediniz.";
            else if (email ==null || email.isEmpty()) kontrolMesaj="Se�ilen banka i�in tan�ml� bir email yoktur.";
            oMap.put("EMAIL_KONTROL",kontrolMesaj);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}

	@GraymoundService("BNSPR_TRN1591_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		Connection conn 		= null;
		CallableStatement stmt  = null;
		CallableStatement stmtEmail  = null;

		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_HZN_SWIFT.EFT_OLUSTUR(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			
			stmtEmail = conn.prepareCall("{call PKG_TRN1591.EMAIL_GONDER(?)}"); //GROSS DEGILSE VE EMAIL GONDER SECILDI ISE
			stmtEmail.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			stmtEmail.execute();
			
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmtEmail);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1591_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			if(iMap.getString("NETLEME_YONU").equals("ODEME") && !iMap.getString("DOVIZ_KODU").equals("TRY")){
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.execute();
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1591_TRANSACTION_START")
	public static Map<?, ?> trn1306Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1591");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}