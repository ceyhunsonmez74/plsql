package tr.com.calikbank.bnspr.treasury.services;

import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HaTalepDetayTx;
import tr.com.aktifbank.bnspr.dao.HznPeBloombergFtm;
import tr.com.aktifbank.bnspr.dao.HznPeBloombergTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/* Fikret Tiryaki
 * Halka arz dosya okuma
 */

public class TreasuryTRN3620Services {
	// Test te comment out et. prodda kals�n
	// private static String ROOT = GMServer.getProperty("graymound.home", null)
	// + File.separator + "Server" + File.separator + "Content" + File.separator
	// + "Root";
	private static String ROOT;
	public static final String projeKodu = "GMS200513";

	@GraymoundService("BNSPR_TRN1501_URUNKODUAL")
	public static GMMap GetHalkaArzUrunKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ call PKG_HALKA_ARZ.URUN_KODU_AL( ?, ?) }");

			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.setString(1, iMap.getString("IN_PROJE_KOD"));
			stmt.execute();
			oMap.put("OUT_URUN_KOD", stmt.getString(2));
			iMap.put("KOD", "AKTIFBANK_IMKB_KOD");
			String aktifbankImkbKod = GMServiceExecuter.call(
					"BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getString(
					"DEGER");
			oMap.put("OUT_UYE_KOD", aktifbankImkbKod.replace("\"", ""));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN1501_KAZANCHESAPLA")
	public static GMMap LotKazancHesapla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ call PKG_HALKA_ARZ.LOT_KAZANC_HESAPLA( ?, ?, ?, ?, ?, ?, ?, ? ) }");

			stmt.registerOutParameter(4, Types.NUMERIC);
			stmt.registerOutParameter(5, Types.NUMERIC);
			stmt.registerOutParameter(6, Types.NUMERIC);
			stmt.registerOutParameter(7, Types.NUMERIC);
			stmt.registerOutParameter(8, Types.DATE);
			stmt.setString(1, iMap.getString("IN_S_URUN_KODU"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("IN_N_ISTENEN_ADET"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("IN_N_ISTENEN_TUTAR"));
			stmt.execute();
			oMap.put("OUT_N_VERILEN_LOT", stmt.getBigDecimal(4));
			oMap.put("OUT_N_VERILEN_TUTAR", stmt.getBigDecimal(5));
			oMap.put("OUT_N_VADE_SONU_TUTAR", stmt.getBigDecimal(6));
			oMap.put("OUT_N_VADE_SONU_KAZANC", stmt.getBigDecimal(7));
			oMap.put("OUT_D_VADE_TARIHI", stmt.getDate(8));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	public static class Position {
		public int i = 0;
	};

	public static String ParseData(String data, Position p, int length) {

		String retVal = data.substring(p.i, p.i + length).trim();
		p.i += length;
		return retVal;
	}

	public static BigDecimal ParseBigDecimal(String tempData, int length)
			throws Exception {

		if (tempData.length() != length)
			throw new Exception("Sayisal alanda bosluklar var");

		tempData = tempData.substring(0, tempData.length() - 2) + "."
				+ tempData.substring(tempData.length() - 2);

		return new BigDecimal(tempData);

	}

	public static ArzElement ParseAndAnalyzeRow(String row, String haKod,
			String uyeKod, boolean isAdmin) {

		DateFormat df = new SimpleDateFormat("ddMMyyyyhhmmss");
		Position p = new Position();
		ArzElement ae = new ArzElement();
		String tempStr;
		BigDecimal tempBigDec;
		Date tempDate;
		int tempInt;
		ae.setHamData(row);
		ae.getHt().setHaKod(haKod);
		if (row.length() != 302) {
			ae.MarkError("Talep satiri 302 karakter degil. (" + row.length()
					+ ")");
			return ae;
		}

		try {
			// � Kay�t Tipi Kodu : 1 Hane Alfabetik (Talep Dosyas� i�in Standart
			// �B�, Da��t�m Dosyas� i�in Standart �D�)
			tempStr = ParseData(row, p, 1);
			if (!tempStr.equals("B")) {
				ae.MarkError("Bilinmeyen islem kodu. (" + tempStr + ")");
				return ae;
			}
			if (isAdmin)
				ae.getHt().setTalepTipi(tempStr);
			else
				ae.getHt().setTalepTipi("K");

			// � �MKB �ye Kodu : 3 Hane Alfabetik
			tempStr = ParseData(row, p, 3);
			if (tempStr.length() != 3 || !tempStr.equals(uyeKod)) {
				ae.MarkError("Hatali uye kod. (" + tempStr + ")");
				return ae;
			}
			ae.getHt().setUyeKod(tempStr);

			// � Tahsis Grubu Kodu : 3 Hane Say�sal
			tempStr = ParseData(row, p, 3);
			tempBigDec = new BigDecimal(tempStr);
			ae.getHt().setTahsisGrup(tempBigDec);

			// � Ba�vuru S�ra No : 9 Hane Say�sal
			tempStr = ParseData(row, p, 9);
			tempInt = Integer.parseInt(tempStr);
			ae.getHt().setBasvuruSira(tempInt);

			// � �deme Tipi : 1 Hane Alfabetik (P,B,D)
			tempStr = ParseData(row, p, 1);
			if (!(tempStr.equals("P") || tempStr.equals("B") || tempStr
					.equals("D"))) {
				ae.MarkError("Bilinmeyen odeme turu. (" + tempStr + ")");
				return ae;
			}
			ae.getHt().setOdemeTipi(tempStr);

			// � Bloke Bozdurma Y�ntemi : 1 Hane Alfabetik (S,D)
			tempStr = ParseData(row, p, 1);
			if (!(tempStr.equals("S") || tempStr.equals("D"))) {
				ae.MarkError("Bilinmeyen bloke bozdurma yontemi. (" + tempStr
						+ ")");
				return ae;
			}
			ae.getHt().setBlokeBozdurmaYontemi(tempStr);

			// � Bloke Bozdurma S�ras� : 3 Hane Say�sal

			tempStr = ParseData(row, p, 3);
			tempBigDec = new BigDecimal(tempStr);
			ae.getHt().setBlokeBozdurmaSirasi(tempBigDec);

			// � Talep Art�r�m� : 1 Hane Alfabetik (A,N)
			tempStr = ParseData(row, p, 1);
			if (!(tempStr.equals("A") || tempStr.equals("N"))) {
				ae.MarkError("Bilinmeyen talep artt�r�m� turu. (" + tempStr
						+ ")");
				return ae;
			}
			ae.getHt().setTalepArtirimi(tempStr);

			// � Talep Tipi : 1 Hane Alfabetik(B,A)
			tempStr = ParseData(row, p, 1);
			if (!(tempStr.equals("A") || tempStr.equals("B"))) {
				ae.MarkError("Bilinmeyen talep tipi. (" + tempStr + ")");
				return ae;
			}
			ae.getHt().setTalepTipi(tempStr);

			// � Teklif Numaras� : 2 Hane Say�sal(00,01)
			tempStr = ParseData(row, p, 2);
			tempBigDec = new BigDecimal(tempStr);
			ae.getHt().setTeklifNumarasi(tempBigDec);

			// � Ad� : 15 Hane Alfabetik
			tempStr = ParseData(row, p, 15);
			ae.getHt().setAdi(tempStr);

			// � �kinci Ad� : 15 Hane Alfabetik
			tempStr = ParseData(row, p, 15);
			ae.getHt().setIkinciAdi(tempStr);

			// � Soyad� : 15 Hane Alfabetik
			tempStr = ParseData(row, p, 15);
			ae.getHt().setSoyadi(tempStr);

			// � T.C.Kimlik No : 11 Hane Say�sal
			tempStr = ParseData(row, p, 11);
			long tempLong = Long.parseLong(tempStr);
			ae.getHt().setTcKimlik(tempLong);

			// � Adres : 60 Hane Alfanumerik
			tempStr = ParseData(row, p, 60);
			ae.getHt().setAdres(tempStr);

			// � �l�e : 15 Hane Alfanumerik
			tempStr = ParseData(row, p, 15);
			ae.getHt().setIlce(tempStr);

			// � �l (Trafik Kodu) : 2 Hane Say�sal
			tempStr = ParseData(row, p, 2);
			tempBigDec = new BigDecimal(tempStr);
			ae.getHt().setIl(tempBigDec);

			// � Talep Tarihi : 8 Hane Say�sal (ggaayyyy)
			// � Talep Saati : 6 Hane Say�sal (SSddss)
			tempStr = ParseData(row, p, 14);
			tempDate = df.parse(tempStr);
			ae.getHt().setTalepTarihi(tempDate);

			// � Halka Arz Birim Fiyat� : 11 Hane Say�sal (9 Hane TL ,2 Hane KR)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setBirimFiyat(new BigDecimal(0));

			// � Talep Edilen Miktar (Toplam Lot) : 11 Hane Say�sal
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepLot(Long.parseLong(tempStr));

			// � Talep Edilen Miktar Alt S�n�r� : 11 Hane Say�sal
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepAltSinirLot(Long.parseLong(tempStr));

			// � Talep Edilen Tutar (Likit Fon Blokesiyle) : 11 Hane Say�sal(9
			// Hane TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTLikitFonB(ParseBigDecimal(tempStr, 11));

			// � Talep Edilen Tutar (DIBS Blokesiyle) : 11 Hane Say�sal(9 Hane
			// TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTDibsB(ParseBigDecimal(tempStr, 11));

			// � Talep Edilen Tutar (D�viz Endeksli DIBS Blokesiyle) : 11 Hane
			// Say�sal(9 Hane TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTDovizDibsB(ParseBigDecimal(tempStr, 11));

			// � Talep Edilen Tutar (Euro Blokesiyle) : 11 Hane Say�sal(9 Hane
			// TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTEuroB(ParseBigDecimal(tempStr, 11));

			// � Talep Edilen Tutar (Dolar Blokesiyle) : 11 Hane Say�sal(9 Hane
			// TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTDolarB(ParseBigDecimal(tempStr, 11));

			// � Talep Edilen Tutar (Di�er D�viz Cinsi Blokesiyle) : 11 Hane
			// Say�sal(9 Hane TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTDigerDovB(ParseBigDecimal(tempStr, 11));

			// � Talep Tutar� : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
			tempStr = ParseData(row, p, 11);
			ae.getHt().setTalepTutar(ParseBigDecimal(tempStr, 11));

			// � Da��t�m Adedi : 11 Hane Say�sal(Talep Dosyas�nda �00000000000�)
			tempStr = ParseData(row, p, 11);

			// � Talep Edilen Tutar Aktif Bank Bono Blokesiyle) : 9 Hane
			// Say�sal(7 Hane TL,2 Hane KR.)
			tempStr = ParseData(row, p, 9);
			ae.getHt().setTalepTAktifBB(ParseBigDecimal(tempStr, 9));

		} catch (Exception exc) {
			ae.MarkError("Exc: " + exc.getMessage());
		}

		return ae;
	}

	public static ArzModel GenerateArzModel(GMMap iMap) {
		ArzModel arz = new ArzModel();

		try {

			String h = iMap.getString("HEADER");
			String f = iMap.getString("FOOTER");
			String t = iMap.getString("USERTYPE");
			String u = iMap.getString("USERNAME");

			// Kay�t Tipi Kodu: 1 Hane Alfabetik (Standart �S�)
			// �IMKB �ye Kodu: 3 Hane Alfabetik
			// �Halka Arz Kodu: 5 Hane Alfabetik
			String uyeKod = h.substring(1, 4).trim();
			String arzKod = h.substring(4, 9).trim();
			long teklifSayisi = Long.parseLong(f.substring(7, 18));
			int size = iMap.getSize("TABLE");
			arz.setAdmin(t.equals("A"));
			arz.setGonderen(u);
			arz.setUyeKodu(uyeKod);
			arz.setUrunKodu(arzKod);

			if (arz.getUyeKodu().length() != 3) {
				return arz;
			}

			if (arzKod.length() != 5) {
				return arz;
			}

			if (size != teklifSayisi) {
				return arz;
			}

			arz.setTeklifSayisi(teklifSayisi);
			int j = 0;

			for (int i = 0; i < size; i++) {
				ArzElement ae = ParseAndAnalyzeRow(
						iMap.getString("TABLE", i, "DATA"), arzKod, uyeKod,
						t.equals("A"));
				arz.getTeklifListesi().add(ae);

			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

		}
		return arz;
	}

	@GraymoundService("BNSPR_TRN3620_BLOOMBERG_KAYDET")
	public static GMMap ParseBloomberg(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean ignoreHeader = false;

		Session session = DAOSession.getSession("BNSPRDal");
		BigDecimal txNo = GMServiceExecuter.call(
				"BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
		iMap.put("TRX_NO", txNo);

		HznPeBloombergFtm bb = new HznPeBloombergFtm();

		// debug
		// String data =
		// "DEAL,2,B,0,7432377090T,0,0,7432377090,,11957821,\"MUHARREM INAN\",6173127,\"CS ADMIN\",20150703,105509,20150703,20150703,105509,CSFX,Credit Suisse FX,,,,,,,EUR,TRY,125000.00,EUR,373677.50,TRY,,,,,,,2.98942,,,,,2.98942,20150707,SPOT,0,,EUR,,,0,,0,,,0,,0,,,,,,,,,,,,2.98999,COBA,2.98957,GBIT,2.98950,KBCQ,,,,,,,,,,,2.9899,,,,,,,,,EUR,KREDBEBB,488-5918637-22,KBC BANK,,,,,,,,,,,,0,0,";

		/* FTM den yuklenmis dosyayi okumaya basliyoruz */

		long start = 1;
		long end = 120;
		long interval = 100;

		BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");

		String fileName = iMap.getString("FILE_NAME");
		GMMap fileMap = null;
		try {
			fileMap = getLineFromFTM(start, end, ftmTransferId);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		if (fileMap.get("FILE_LINE") == null) {
			return oMap;
		}

		String line = "";

		ignoreHeader = iMap.getBoolean("IGNORE_HEADER", false);

		while (fileMap.get("FILE_LINE") != null) {

			int lineCount = fileMap.getSize("FILE_LINE");
			for (int i = 1; i < lineCount; i++) {
				line = fileMap.getString("FILE_LINE", i, "LINE");
				
				line.replaceAll("\\,", " ");
				line=changeCommaInDoubleQuotes(line);
				String[] parts = line.split(",");

				try {

					bb.setMsgType(parts[0]);
					bb.setPureDealType(new BigDecimal(parts[1]));
					bb.setSide(parts[2]);
					
					
					if (!parts[3].isEmpty())
						bb.setProduct(new BigDecimal(parts[3]));
					
					
					bb.setSourceReference(parts[4]);
					
					if (!parts[5].isEmpty())
						bb.setTransType(new BigDecimal(parts[5]));
					
					if (!parts[6].isEmpty())
						bb.setReviseVer(new BigDecimal(parts[6]));
					
					if (!parts[7].isEmpty())
						bb.setTradeId(new BigDecimal(parts[7]));

					bb.setBatchId(parts[8]);
					
					if (!parts[9].isEmpty())
						bb.setTraderId(new BigDecimal(parts[9]));
					
					bb.setTraderName(parts[10]);
					
					if (!parts[11].isEmpty())
						bb.setCounterpartyUuid(new BigDecimal(parts[11]));
					
					
					bb.setCounterpartyName(parts[12]);
					
					
					
					bb.setDateOfDeal(parts[13]);
					
					bb.setTimeOfDeal(parts[14]);
					bb.setTradeDate(parts[15]);
					bb.setDateConfirmed(parts[16]);
					bb.setTimeConfirmed(parts[17]);
					bb.setBank1DealingCode(parts[18]);
					bb.setBank1Name(parts[19]);
					bb.setUserIdent1(parts[20]);
					bb.setUserIdent2(parts[21]);
					bb.setUserIdent3(parts[22]);
					bb.setUserIdent4(parts[23]);
					bb.setBrokerDealingCode(parts[24]);
					bb.setBrokerName(parts[25]);
					bb.setCurrency1(parts[26]);
					bb.setCurrency2(parts[27]);
					
					if (!parts[28].isEmpty())
						bb.setNearAmtDealt(new BigDecimal(parts[28]));
					
					bb.setNearCcyDealt(parts[29]);
					
					if (!parts[30].isEmpty())
						bb.setNearCounterAmt(new BigDecimal(parts[30]));
					
					bb.setNearCounterCcy(parts[31]);

					if (!parts[32].isEmpty())
						bb.setFwdPointsNear(new BigDecimal(parts[32]));
					if (!parts[33].isEmpty())
						bb.setFarAmtDealt(new BigDecimal(parts[33]));

					bb.setFarCcyDealt(parts[34]);
					if (!parts[35].isEmpty())
						bb.setFarCounterAmt(new BigDecimal(parts[35]));
					bb.setFarCounterCcy(parts[36]);

					if (!parts[37].isEmpty())
						bb.setFwdPointsFar(new BigDecimal(parts[37]));
					if (!parts[38].isEmpty())
						bb.setSpotBasisRate(new BigDecimal(parts[38]));
					if (!parts[39].isEmpty())
						bb.setDepositRate(new BigDecimal(parts[39]));

					bb.setDayCountType(parts[40]);
					bb.setNewRoll(parts[41]);

					if (!parts[42].isEmpty())
						bb.setVolumeOfInterest(new BigDecimal(parts[42]));

					if (!parts[43].isEmpty())
						bb.setExchangeRatePeriod1(new BigDecimal(parts[43]));

					bb.setValueDatePeriod1Currency1(parts[44]);
					bb.setTenorPeriod1(parts[45]);

					if (!parts[46].equalsIgnoreCase("0"))
						bb.setFixingDatePeriod1(parts[46]);

					bb.setFixingSourcePeriod1(parts[47]);
					bb.setSettleCrncy(parts[48]);

					if (!parts[49].isEmpty())
						bb.setSwapRate(new BigDecimal(parts[49]));
					if (!parts[50].isEmpty())
						bb.setExchangeRatePeriod2(new BigDecimal(parts[50]));

					if (!parts[51].equalsIgnoreCase("0"))
						bb.setValueDatePeriod2Currency1(parts[51]);

				//	if (!parts[52].isEmpty()&&!parts[52].equalsIgnoreCase("SPOT"))
			//			bb.setTenorPeriod2(new BigDecimal(parts[52]));

					if (!parts[53].equalsIgnoreCase("0"))
						bb.setFixingDatePeriod2(parts[53]);

					if (!parts[54].isEmpty())
						bb.setFixingSourcePeriod2(new BigDecimal(parts[54]));

					bb.setSplitTenorCrncy1(parts[55]);
					bb.setSplitValueDateCrncy1(parts[56]);
					bb.setSplitTenorCrncy2(parts[57]);
					bb.setSplitValueDateCrncy2(parts[58]);
					bb.setCmmnt(parts[59]);
					bb.setNoteName1(parts[60]);

					bb.setNoteText1(parts[61]);
					bb.setNoteName2(parts[62]);
					bb.setNoteText2(parts[63]);
					bb.setNoteName3(parts[64]);
					bb.setNoteText3(parts[65]);
					bb.setNoteName4(parts[66]);
					bb.setNoteText4(parts[67]);
					bb.setNoteName5(parts[68]);
					bb.setNoteText5(parts[69]);

					if (!parts[70].isEmpty())
						bb.setCompQuote1(new BigDecimal(parts[70]));
					if (!parts[71].isEmpty())
						bb.setCompDealCode1(parts[71]);
					if (!parts[72].isEmpty())
						bb.setCompQuote2(new BigDecimal(parts[72]));
					
					bb.setCompDealCode2(parts[73]);
					
					if (!parts[74].isEmpty())
						bb.setCompQuote3(new BigDecimal(parts[74]));
					
					bb.setCompDealCode3(parts[75]);
					
					if (!parts[76].isEmpty())
						bb.setCompQuote4(new BigDecimal(parts[76]));
					
					bb.setCompDealCode4(parts[77]);
					
					if (!parts[78].isEmpty())
						bb.setCompQuote5(new BigDecimal(parts[78]));
					
					bb.setCompDealCode5(parts[79]);
					bb.setPortfolio(parts[80]);
					bb.setAlocAccount(parts[81]);
					bb.setAlocDescription(parts[82]);
					bb.setAlocCustodian(parts[83]);
					bb.setPbName(parts[84]);
					bb.setReferenceRateSpot(parts[85]);
					bb.setReferenceRatePeriod1(parts[86]);
					bb.setReferenceRatePeriod2(parts[87]);
					bb.setPayCcy(parts[88]);
					bb.setPaySwift(parts[89]);
					bb.setPayAcctNum(parts[90]);
					bb.setPayBank(parts[91]);
					bb.setPayBranch(parts[92]);
					bb.setPayBeneficiary(parts[93]);
					bb.setPaySpclInstr(parts[94]);
					bb.setRecCcy(parts[95]);
					bb.setRecSwift(parts[96]);
					bb.setRecAcctNum(parts[97]);
					bb.setRecBank(parts[98]);
					bb.setRecBranch(parts[99]);
					bb.setRecBeneficiary(parts[100]);
					bb.setRecSpclInstr(parts[101]);
					bb.setMidratespot(parts[102]);
					bb.setMidratenear(parts[103]);
					bb.setMidfwdpointnear(parts[104]);
					bb.setMidratefar(parts[105]);
					bb.setMidfwdpointfar(parts[106]);
					bb.setUsiNamespace(parts[107]);
					bb.setUsiId(parts[108]);
					bb.setUsiIdNearLeg(parts[109]);

					if (!parts[110].equalsIgnoreCase("0"))
						bb.setDeliveryDate(parts[110]);

					if (!parts[111].isEmpty())
						bb.setBanknoteRateType(new BigDecimal(parts[111]));
					//eger rate varsa komisyon vardir
					if (!parts[111].equalsIgnoreCase("0"))
					 bb.setCommission(new BigDecimal(parts[112]));

					bb.setStatus("N");
					bb.setStatusExplaination("NEW");
					bb.setFilename(fileName);

				} catch (Exception exc) {
					throw ExceptionHandler.convertException(exc);
				}

			}

			fileMap.clear();
			start = interval + start;
			end = interval + end;
			try {
				fileMap = getLineFromFTM(start, end, ftmTransferId);
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		
			session.saveOrUpdate(bb);
		}

		session.flush();
		
		iMap.put("TRX_NAME", "3620");
		
		//servis 3620 den cagrilirsa hatalari yakalayamaz o nedenle batch yada schedule edildi

		//GMServiceExecuter.executeAsync("BNSPR_TRX_SEND_TRANSACTION", iMap);
		
	
		//return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
         
        return oMap;

	}

	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_AL")
	public static GMMap PortalTalepAl(GMMap iMap) {
		// TODO: debug
		// com.graymound.service.GMServiceExecuter.executeAsync("BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_KAYDET",
		// iMap);
		GMMap oMap = new GMMap();

		try {
			ArzModel arz = GenerateArzModel(iMap);

			if (arz.getUyeKodu().length() != 3) {
				oMap.put("HATA", "Uye kodu okunamadi!");
				return oMap;
			}

			if (arz.getUrunKodu().length() != 5) {
				oMap.put("HATA", "Urun kodu okunamadi!");
				return oMap;
			} else if (arz.getTeklifSayisi() < 1) {
				oMap.put("HATA", "Teklif sayisi tutmuyor!");
				return oMap;
			}

			int j = 0;

			for (int i = 0; i < arz.getTeklifSayisi(); i++) {
				ArzElement ae = arz.getTeklifListesi().get(i);
				if (ae.isHatalimi()) {
					oMap.put("TABLE", j++, "DATA", ae.getHt().getBasvuruSira()
							+ ": " + ae.getHata());
				}
			}
		} catch (Exception exc) {
			oMap.put("HATA", exc.getMessage());
		}

		return oMap;
	}

	static class ArzModel {
		public long getTeklifSayisi() {
			return teklifSayisi;
		}

		public void setTeklifSayisi(long teklifSayisi) {
			this.teklifSayisi = teklifSayisi;
		}

		public String getUyeKodu() {
			return uyeKodu;
		}

		public void setUyeKodu(String uyeKodu) {
			this.uyeKodu = uyeKodu;
		}

		public String getUrunKodu() {
			return urunKodu;
		}

		public void setUrunKodu(String urunKodu) {
			this.urunKodu = urunKodu;
		}

		public ArrayList<ArzElement> getTeklifListesi() {
			return teklifListesi;
		}

		public void setTeklifListesi(ArrayList<ArzElement> teklifListesi) {
			this.teklifListesi = teklifListesi;
		}

		long teklifSayisi;
		String uyeKodu;
		String urunKodu;
		ArrayList<ArzElement> teklifListesi;
		String gonderen;
		boolean isAdmin;

		public boolean isAdmin() {
			return isAdmin;
		}

		public void setAdmin(boolean isAdmin) {
			this.isAdmin = isAdmin;
		}

		public String getGonderen() {
			return gonderen;
		}

		public void setGonderen(String gonderen) {
			this.gonderen = gonderen;
		}

	}

	static class ArzElement {
		/**
         * 
         */
		private static final long serialVersionUID = 11111111111111111L;
		String hamData;

		public String getHamData() {
			return hamData;
		}

		public void setHamData(String hamData) {
			this.hamData = hamData;
		}

		private HaTalepDetayTx ht = new HaTalepDetayTx();

		public HaTalepDetayTx getHt() {
			return ht;
		}

		public void setHt(HaTalepDetayTx ht) {
			this.ht = ht;
		}

		boolean Hatalimi = false;

		public boolean isHatalimi() {
			return Hatalimi;
		}

		public void setHatalimi(boolean hatalimi) {

			Hatalimi = hatalimi;
		}

		public String getHata() {
			return Hata;
		}

		public void setHata(String hata) {
			Hata = hata;
		}

		String Hata;

		public void MarkError(String hata) {
			setHata(hata);
			Hatalimi = true;
		}

	}

	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_ANALIZ_MAIL")
	public static GMMap pttKuryeBatch(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		GMMap mailMap = new GMMap();
		try {
			StringBuilder stb = new StringBuilder();
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN1501.GetAnalizUyeler(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, projeKodu);
			stmt.execute();
			int i = 0;
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				stb.append("\n\n");
				stb.append(rSet.getString("ACIKLAMA"));
				stb.append("\n\n");
				stb.append("Kurum Kodu: ");
				stb.append(rSet.getString("HA_UYE"));
				stb.append("\n");
				stb.append("Y�klenme Tarihi: ");
				stb.append(rSet.getString("YUKLENME_TARIHI"));
				stb.append("\n");
				stb.append("Toplam sat�r: ");
				stb.append(rSet.getString("TOPLAM_SATIR"));
				stb.append("\n");
				stb.append("Hatali sat�r: ");
				stb.append(rSet.getString("HATALI_SATIR"));
				stb.append("\n");
				stb.append("Dosya Formati: ");
				stb.append(rSet.getString("HATA_ACIKLAMA"));
				stb.append("\n\n");

				iMap.put("ID", rSet.getString("ID"));
				iMap.putAll(GMServiceExecuter.executeNT(
						"BNSPR_TRN1501_HALKA_ARZ_EXCEL", iMap));
				if (iMap.getInt("DOSYA_SAYISI") > 0) {
					try {
						mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME",
								iMap.getString("FILE_NAME") + ".xls");
						mailMap.put(
								"MAIL_ATTACHMENT_LIST",
								0,
								"FILE_CONTENT",
								FileUtil.readFileToByteArray(new File(ROOT
										+ File.separator + "files"
										+ File.separator
										+ iMap.getString("FILE_NAME_PTT"))));

					} catch (Exception e) {
						e.printStackTrace();
						stb.append("Dosya al�n�rken hata olu�tu");
					}
				} else {
					stb.append("Olu�turulacak Rapor Bulunamad�.");
				}
				mailMap.put("MAIL_SUBJECT", rSet.getString("ACIKLAMA")
						+ " Rapor Dosyas�");
				mailMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
				mailMap.put("MAIL_TO", rSet.getString("EPOSTA"));
				mailMap.put(
						"MAIL_CC",
						DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'ANALIZ', 'CC') from dual"));
				mailMap.put("IS_BODY_HTML", "H");
				mailMap.put("MAIL_BODY", stb);

				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
						mailMap);
				// GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
				// mailMap);
				stb.setLength(0);
				iMap.clear();
			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_EXCEL")
	public static GMMap halkaArzExcel(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();

			headers.put("SATIR", new String[] { "Sat�r" });
			headers.put("ANALIZ_SONUC", new String[] { "Analiz Sonu�" });

			oMap.put("HEADERS", headers);
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN1501.GetAnalizRapor(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("ID"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "TABLE_DATA";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "SATIR", rSet.getObject("SATIR"));
				oMap.put(tableName, row, "ANALIZ_SONUC",
						rSet.getObject("ANALIZ_SONUC"));
				row++;
			}
			oMap.put("FILE_NAME", "halkaArz");

			oMap = GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", oMap);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_NOVA_MAIL")
	public static GMMap HalkaArzNovaDosyasi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Random rnd = new Random();
		String randomFileCode = rnd.nextInt(1000) + "";
		GMMap oMap = new GMMap();

		try {

			StringBuilder stb = new StringBuilder();
			conn = DALUtil.getGMConnection();

			stb.append("Nova dagitim dosyasi ektedir.");

			iMap.put("IN_PROJE_KOD", projeKodu);
			String urunKodu = GMServiceExecuter.call(
					"BNSPR_TRN1501_URUNKODUAL", iMap).getString("OUT_URUN_KOD");

			File file = null;
			FileWriter fileWriter = null;
			String filePath = ROOT + File.separator + "files" + File.separator
					+ "NOVA(" + randomFileCode + ").csv";

			file = new File(filePath);
			file.createNewFile();
			fileWriter = new FileWriter(file);

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_HALKA_ARZ.GetNovaDosyasi(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, urunKodu);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				fileWriter.write(rSet.getString("data"));
				fileWriter.write("\r\n");
			}
			fileWriter.close();

			GMMap mailMap = new GMMap();

			try {
				mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", "Nova.csv");
				mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT",
						FileUtil.readFileToByteArray(filePath));

			} catch (Exception e) {
				e.printStackTrace();
				stb.append("Dosya al�n�rken hata olu�tu");
			}

			mailMap.put("MAIL_SUBJECT", "NOVA Dagitim Dosyasi");
			mailMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
			mailMap.put(
					"MAIL_TO",
					DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'NOVA', 'TO') from dual"));
			mailMap.put(
					"MAIL_CC",
					DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'NOVA', 'CC') from dual"));
			mailMap.put("IS_BODY_HTML", "H");
			mailMap.put("MAIL_BODY", stb);

			// prod
			GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
					mailMap);

			// local test
			// GMConnection.getConnection("SCHEDULER").serviceCall("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
			// mailMap);

			stb.setLength(0);
			iMap.clear();

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_DAGITIM_MAIL")
	public static GMMap HalkaArzDagitimMail(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Random rnd = new Random();
		String randomFileCode = rnd.nextInt(1000) + "";
		GMMap oMap = new GMMap();

		try {
			StringBuilder stb = new StringBuilder();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetUyeler(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, projeKodu);
			stmt.execute();
			int i = 0;
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				stb.append("\n\n");
				stb.append(rSet.getString("ACIKLAMA"));
				stb.append("\n\n");
				stb.append("Kurum Kodu: ");
				stb.append(rSet.getString("HA_UYE"));
				stb.append("\n");

				GMMap mailMap = new GMMap();
				iMap.put("HA_UYE", rSet.getString("HA_UYE"));
				iMap.put("FILE_NAME", rSet.getString("HA_UYE") + "("
						+ randomFileCode + ")");
				iMap.putAll(GMServiceExecuter.executeNT(
						"BNSPR_TRN1501_HALKA_ARZ_DAGITIM_DOSYASI", iMap));
				if (iMap.getInt("DOSYA_SAYISI") > 0) {
					try {
						mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME",
								iMap.getString("FILE_NAME") + ".txt");
						mailMap.put(
								"MAIL_ATTACHMENT_LIST",
								0,
								"FILE_CONTENT",
								FileUtil.readFileToByteArray((ROOT
										+ File.separator + "files"
										+ File.separator
										+ iMap.getString("FILE_NAME") + ".txt")));

					} catch (Exception e) {
						e.printStackTrace();
						stb.append("Dosya al�n�rken hata olu�tu");
					}
				} else {
					stb.append("Olu�turulacak Rapor Bulunamad�.");
				}
				mailMap.put("MAIL_SUBJECT", rSet.getString("ACIKLAMA")
						+ " Dagitim Dosyasi");
				mailMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
				mailMap.put(
						"MAIL_TO",
						DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'DAGITIM', 'TO') from dual"));
				mailMap.put(
						"MAIL_CC",
						DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'DAGITIM', 'CC') from dual"));
				mailMap.put("IS_BODY_HTML", "H");
				mailMap.put("MAIL_BODY", stb);

				// prod
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
						mailMap);

				// local test
				// GMConnection.getConnection("SCHEDULER").serviceCall("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
				// mailMap);

				stb.setLength(0);
				iMap.clear();
			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_DAGITIM_DOSYASI")
	public static GMMap halkaArzDagitimDosyasi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		iMap.put("IN_PROJE_KOD", projeKodu);
		oMap = GMServiceExecuter.call("BNSPR_TRN1501_URUNKODUAL", iMap);
		String urunKodu = oMap.getString("OUT_URUN_KOD");
		oMap.put("HA_UYE", iMap.getString("HA_UYE"));

		String uyeKodu = "";

		File file = null;
		FileWriter fileWriter = null;

		oMap.put("DOSYA_SAYISI", 0);
		try {

			uyeKodu = iMap.getString("HA_UYE");
			file = new File(ROOT + File.separator + "files" + File.separator
					+ iMap.getString("FILE_NAME") + ".txt");
			// file = new File(iMap.getString("FILE_NAME")+".txt");
			file.createNewFile();
			fileWriter = new FileWriter(file);

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_HALKA_ARZ.GetDagitimDosyasi(?,?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, uyeKodu);
			stmt.setString(3, urunKodu);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				fileWriter.write(rSet.getString("SATIR"));
				fileWriter.write("\r\n");
				oMap.put("DOSYA_SAYISI", 1);
			}
			fileWriter.close();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN1501_GET_CUSTOMER_REPORT")
	public static GMMap CustomerReport(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call BNSPR.PKG_Halka_Arz.CustomerReport(?,?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("UYE"));
			stmt.setString(3, iMap.getString("STATU"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "TABLE");
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN_1501_COMBO_PARAMETERS")
	public static GMMap getCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		String listName = "STATU";
		GuimlUtil.wrapMyCombo(oMap, listName, "", "HEPSI");
		GuimlUtil.wrapMyCombo(oMap, listName, "A", "Talep Alindi");
		GuimlUtil.wrapMyCombo(oMap, listName, "I", "Iptal");
		GuimlUtil.wrapMyCombo(oMap, listName, "T", "Tahsilat Bekliyor");
		GuimlUtil.wrapMyCombo(oMap, listName, "Y", "Teminat Yetersiz");
		GuimlUtil.wrapMyCombo(oMap, listName, "M", "Alt Sinira Takilmis");
		GuimlUtil.wrapMyCombo(oMap, listName, "B", "Basarili");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Tahsilat Hatas�");
		return oMap;
	}

	@GraymoundService("BNSPR_TRN_1501_DEBUGGER")
	public static GMMap debuggg(GMMap iMap) {

		iMap.put("HEADER", "SIYMAKFEN");
		iMap.put("FOOTER", "TIYM99900000000003");
		iMap.put("USERTYPE", "A");
		iMap.put("USERNAME", "FIKRET");
		iMap.put(
				"TABLE",
				0,
				"DATA",
				"BIYM025000000003PS000NA01AV�VASA EMEK.  VE Y.AM�.ESNEK             FON00110398430�NKILAP MAH. K���KSU CAD. AK�A KOCA SOK.NO: 8 34768         �MRAN�YE       34070520101700370000000125000000025000000000000010000000000000000000000000000000000000000000000000000000000000000000003125000000000000000000000000");
		iMap.put(
				"TABLE",
				1,
				"DATA",
				"BIYM025000000003PS000NA01AV�VASA EMEK.  VE Y.AM�.ESNEK             FON00110398430�NKILAP MAH. K���KSU CAD. AK�A KOCA SOK.NO: 8 34768         �MRAN�YE       34070520101700370000000125000000025000000000000010000000000000000000000000000000000000000000000000000000000000000000003125000000000000000000000000");
		iMap.put(
				"TABLE",
				2,
				"DATA",
				"BIYM025000000003PS000NA01AV�VASA EMEK.  VE Y.AM�.ESNEK             FON00110398430�NKILAP MAH. K���KSU CAD. AK�A KOCA SOK.NO: 8 34768         �MRAN�YE       34070520101700370000000125000000025000000000000010000000000000000000000000000000000000000000000000000000000000000000003125000000000000000000000000");

		com.graymound.service.GMServiceExecuter.execute(
				"BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_KAYDET", iMap);
		return iMap;
	}

	@GraymoundService("BNSPR_TRN_1501_UYE_PARAMETERS")
	public static GMMap getCombo2(GMMap iMap) {

		GMMap oMap = new GMMap();
		String listName = "UYE";

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetUyeler(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, projeKodu);
			stmt.execute();
			int i = 0;
			GuimlUtil.wrapMyCombo(oMap, listName, "", "HEPSI");
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {

				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("HA_UYE"),
						rSet.getString("ACIKLAMA"));

			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
    public static String changeCommaInDoubleQuotes(String str) {
        StringBuilder sb = new StringBuilder(str);
        boolean flag = false;
        int index = 0;
        for (char s : sb.toString().toCharArray()) {
              if (s == '"') {
                    flag = !flag;
              }
              if (flag && s == ',') {
                    sb.setCharAt(index, ' ');
              }
              index++;
        }
        return sb.toString();
  }
    
    
    @GraymoundService("BNSPR_QRY3620_FILL_COMBOBOX")
	public static GMMap combo3620(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	
	        try{
	        
	        	
	        	int i = 0;
				oMap.put("ISLEM_DURUM", i, "NAME", "HEPSI");
				oMap.put("ISLEM_DURUM", i++, "VALUE", "HEPSI");

				oMap.put("ISLEM_DURUM", i, "NAME", "HATALI");
				oMap.put("ISLEM_DURUM", i++, "VALUE", "HATA");
				
				oMap.put("ISLEM_DURUM", i, "NAME", "YENI");
				oMap.put("ISLEM_DURUM", i++, "VALUE", "YENI");


				i = 0;
				oMap.put("ISLEM_YONU", i, "NAME", "HEPSI");
				oMap.put("ISLEM_YONU", i++, "VALUE", "");

				oMap.put("ISLEM_YONU", i, "NAME", "ALIS");
				oMap.put("ISLEM_YONU", i++, "VALUE", "B");

				oMap.put("ISLEM_YONU", i, "NAME", "SATIS");
				oMap.put("ISLEM_YONU", i++, "VALUE", "S");
				
				
				i = 0;
				oMap.put("ISLEM_TURU", i, "NAME", "HEPSI");
				oMap.put("ISLEM_TURU", i++, "VALUE", "");

				oMap.put("ISLEM_TURU", i, "NAME", "SPOT");
				oMap.put("ISLEM_TURU", i++, "VALUE", 2);

				oMap.put("ISLEM_TURU", i, "NAME", "SWAP");
				oMap.put("ISLEM_TURU", i++, "VALUE", 8);
				
				oMap.put("ISLEM_TURU", i, "NAME", "FORWARD");
				oMap.put("ISLEM_TURU", i++, "VALUE", 4);


				oMap.put("ISLEM_TURU", i, "NAME", "DEPO");
				oMap.put("ISLEM_TURU", i++, "VALUE", 16);
				
	            
	            return oMap;
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } 
    }

    @GraymoundService("BNSPR_QRY3620_SORGULA")
  	public static GMMap getBllombergETData(GMMap iMap) {
  			GMMap oMap = new GMMap();
  	        Connection conn = null;
  	        CallableStatement stmt = null;
  	        ResultSet rSet = null;
  	        try{
  	            conn = DALUtil.getGMConnection();
  	            stmt = conn.prepareCall("{? = call PKG_TRN3620.getETData(?,?, ?, ?,?)}");
  	           
  	            int paramIndex = 2;
  	            
  	        	
  				stmt.setBigDecimal(paramIndex++,iMap.getString("ISLEM_TURU")==null ? null:iMap.getBigDecimal("ISLEM_TURU"));
  				stmt.setString(paramIndex++, iMap.getString("ISLEM_DURUM"));
  				stmt.setString(paramIndex++, iMap.getString("ISLEM_YONU"));
  				stmt.setDate(paramIndex++, iMap.getDate("TARIH") == null ? null : new java.sql.Date(iMap.getDate("TARIH").getTime()));
  				stmt.setDate(paramIndex++, iMap.getDate("TARIH2") == null ? null : new java.sql.Date(iMap.getDate("TARIH2").getTime()));
  				

  				stmt.registerOutParameter(1, -10);
  				stmt.execute();

  				rSet = (ResultSet) stmt.getObject(1);

  				String tableName = "TBL";
  				oMap.putAll(DALUtil.rSetResults(rSet, tableName));
  	          
  	            
  	            return oMap;
  	        } catch (Exception e){
  	            throw ExceptionHandler.convertException(e);
  	        } finally{
  	            GMServerDatasource.close(rSet);
  	            GMServerDatasource.close(stmt);
  	            GMServerDatasource.close(conn);
  	        }
  	    }
    
    
    @GraymoundService("BNSPR_QRY3620_INTEGRATE")
  	public static GMMap doBloombergOperation(GMMap iMap) {
  			GMMap oMap = new GMMap();
  			Session session = DAOSession.getSession("BNSPRDal");
  	        try{
  	           
  	           
  	        for (int i=0;i<iMap.getSize("TRX_LIST");i++)
  	        {
  	        	GMMap innerMap = new GMMap();
  	        	// ekrandan secilen referanslar ile 3620 transaction cagrilir ve islemler aktar�lmaya baslar
  	        	if (iMap.getBoolean("TRX_LIST", i, "SEC"))
  	        	{
  	        		innerMap.put("TRX_NAME", "3620");
  	        		innerMap.put("TRX_NO",iMap.getBigDecimal("TRX_LIST", i, "REFERANS"));
  	        		oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", innerMap));
  	        	}
  	        	innerMap.clear();
  	        }   
  	        
  	        return oMap;
  	        
  	        } catch (Exception e){
  	            throw ExceptionHandler.convertException(e);
  	        } 
  	    }
	
    @GraymoundService("BNSPR_QRY3620_SORGULA_BB_AKTARILAN")
  	public static GMMap getBllombergAll(GMMap iMap) {
  			GMMap oMap = new GMMap();
  	        Connection conn = null;
  	        CallableStatement stmt = null;
  	        ResultSet rSet = null;
  	        try{
  	            conn = DALUtil.getGMConnection();
  	            stmt = conn.prepareCall("{? = call PKG_TRN3620.getETDataDone(?,?, ?, ?)}");
  	           
  	            int paramIndex = 2;
  	            
  	        	
  				stmt.setBigDecimal(paramIndex++,iMap.getString("ISLEM_TURU")==null ? null:iMap.getBigDecimal("ISLEM_TURU"));
  				stmt.setString(paramIndex++, iMap.getString("ISLEM_YONU"));
  				stmt.setDate(paramIndex++, iMap.getDate("TARIH") == null ? null : new java.sql.Date(iMap.getDate("TARIH").getTime()));
  				stmt.setDate(paramIndex++, iMap.getDate("TARIH2") == null ? null : new java.sql.Date(iMap.getDate("TARIH2").getTime()));
  				

  				stmt.registerOutParameter(1, -10);
  				stmt.execute();

  				rSet = (ResultSet) stmt.getObject(1);

  				String tableName = "TBL";
  				oMap.putAll(DALUtil.rSetResults(rSet, tableName));
  	          
  	            
  	            return oMap;
  	        } catch (Exception e){
  	            throw ExceptionHandler.convertException(e);
  	        } finally{
  	            GMServerDatasource.close(rSet);
  	            GMServerDatasource.close(stmt);
  	            GMServerDatasource.close(conn);
  	        }
  	    }
    
    @GraymoundService("BNSPR_QRY3620_SORGULA_RT_AKTARILAN")
  	public static GMMap getReutersAll(GMMap iMap) {
  			GMMap oMap = new GMMap();
  	        Connection conn = null;
  	        CallableStatement stmt = null;
  	        ResultSet rSet = null;
  	        try{
  	            conn = DALUtil.getGMConnection();
  	            stmt = conn.prepareCall("{? = call PKG_TRN3620.getReutersDataDone(?,?)}");
  	           
  	            int paramIndex = 2;
  	            
  				stmt.setDate(paramIndex++, iMap.getDate("TARIH") == null ? null : new java.sql.Date(iMap.getDate("TARIH").getTime()));
  				stmt.setDate(paramIndex++, iMap.getDate("TARIH2") == null ? null : new java.sql.Date(iMap.getDate("TARIH2").getTime()));
  				

  				stmt.registerOutParameter(1, -10);
  				stmt.execute();

  				rSet = (ResultSet) stmt.getObject(1);

  				String tableName = "TBL";
  				oMap.putAll(DALUtil.rSetResults(rSet, tableName));
  	          
  	            
  	            return oMap;
  	        } catch (Exception e){
  	            throw ExceptionHandler.convertException(e);
  	        } finally{
  	            GMServerDatasource.close(rSet);
  	            GMServerDatasource.close(stmt);
  	            GMServerDatasource.close(conn);
  	        }
  	    }
    
    @GraymoundService("BNSPR_QRY3620_DEPO_DETAY")
	public static GMMap depoBloomDetay(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{? = call PKG_TRN3620.getBloombergDepoData(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			while(rSet.next()){
				oMap.put("REFERANS", rSet.getString("REFERANS"));
				oMap.put("URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put("URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
				oMap.put("DEALER_NO", rSet.getString("DEALER_NO"));
				oMap.put("DEAL_TARIHI",rSet.getDate("DEAL_TARIHI") );
				oMap.put("DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put("TUTAR", rSet.getString("TUTAR"));
	 
				oMap.put("VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put("VADE_TARIHI", rSet.getDate("VADE_TARIHI"));
				oMap.put("ALINAN_TARIH", rSet.getDate("ALINAN_TARIH"));
				oMap.put("DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put("BLOOMBERG_ID", rSet.getString("YARATAN_TX_NO"));
				oMap.put("URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put("BANKA_MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put("BANKA_HESAP_NO", rSet.getString("BANKA_HESAP_NO"));
				
				oMap.put("MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put("MUSTERI_ADI", rSet.getString("UNVAN"));
				oMap.put("GIRIS_HESAP_NO", rSet.getString("GIRIS_HESAP_NO"));
				oMap.put("CIKIS_HESAP_NO", rSet.getString("CIKIS_HESAP_NO"));
				oMap.put("GIRIS_MUHABIR", rSet.getString("GIRIS_MUHABIR"));
				oMap.put("CIKIS_MUHABIR", rSet.getString("CIKIS_MUHABIR"));
				oMap.put("TENOR", rSet.getString("TENOR"));
				oMap.put("FAIZ_TUTARI", rSet.getString("FAIZ_TUTARI"));
				oMap.put("FAIZ_ORANI", rSet.getString("FAIZ_ORANI"));
				oMap.put("VADE_ISLEM_BILGISI", rSet.getString("VADE_ISLEM_BILGISI"));
				
				
        	}
			 
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
    
    @GraymoundService("BNSPR_QRY3620_SAVE_TRADE")
  	public static GMMap saveTrade(GMMap iMap) {
  			GMMap oMap = new GMMap();
  	    
  	        	try {
  	  			Session session = DAOSession.getSession("BNSPRDal");
  	  			List<?> tList = (List<?>)iMap.get("LIST");
  	  			String tableName = "LIST";
  	  			for(int i = 0; i < tList.size(); i++){
  	  				
  	  				if (iMap.getBoolean(tableName,i,"TRADE"))
  	  	        	
  	  				{
  	  					HznPeBloombergTx detailTx = (HznPeBloombergTx)
  	  							session.get(HznPeBloombergTx.class,
  	  									 iMap.getBigDecimal(tableName,i,"REFERANS"));
  	  				
  	  					detailTx.setTradingPortfoy("E");
  	  					
  	  					session.update(detailTx);
  	  				}
  	  				else
  	  				{
  	  					HznPeBloombergTx detailTx = (HznPeBloombergTx)
  	  							session.get(HznPeBloombergTx.class,
  	  									 iMap.getBigDecimal(tableName,i,"REFERANS"));
  	  				
  	  					detailTx.setTradingPortfoy("H");
  	  					
  	  					session.update(detailTx);
  	  				}
  	  			}
  	  			session.flush();
  	          
  	            
  	            return oMap;
  	        } catch (Exception e){
  	            throw ExceptionHandler.convertException(e);
  	        }  
  	    }
    
    
	public static GMMap getLineFromFTM(long start, long end, BigDecimal ftmTransferId) throws Exception{
		try {
			String fetchQuery = String.format("SELECT FFC.LINE_NUMBER, FFC.LINE FROM FTM.FTM_FILE_CONTENT FFC " +
											  "WHERE FFC.FTM_PROCESS_OID = %s AND FFC.LINE_NUMBER >= %s AND FFC.LINE_NUMBER <= %s " +
											  "ORDER BY FFC.LINE_NUMBER", ftmTransferId, start, end);
			final String tableName = "FILE_LINE";
			
			return  DALUtil.getResults(fetchQuery, tableName);
		}
		catch (Exception e) {
			throw e;
		}
	}
	
	public static String getFileNameFromFTM(BigDecimal ftmProcessId) throws Exception{
		try {
			String tableName = "FILES";
			String fetchQuery = String.format("SELECT P.FILE_NAME FROM FTM.FTM_PROCESS P " +
											  "WHERE P.OID = %s ", ftmProcessId);
			
			return  DALUtil.getResults(fetchQuery, tableName).getString(tableName, 0, "FILE_NAME");
		}
		catch (Exception e) {
			throw e;
		}
	}

}