package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ChmsCashProcessTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznCurEffOnayTx;
import tr.com.calikbank.bnspr.dao.HznCurEffTalepTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1361Services {

	@GraymoundService("BNSPR_TRN1361_AFTER_APPROVAL")
	public static GMMap onaySmsGonder(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap myMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {

			HznCurEffOnayTx hznCurEffOnayTx = (HznCurEffOnayTx) session.get(HznCurEffOnayTx.class, iMap.getBigDecimal("ISLEM_NO"));

			/*
			 * 17.07.2018.EK
			 * TY-9973
			 * onay ise sms gonder
			 */
			if ("O".equals(hznCurEffOnayTx.getOnayRed())) {

				@SuppressWarnings("deprecation")
				String unvan = LovHelper.diLov(hznCurEffOnayTx.getBankaMusteriNo(), "1361/LOV_BANKA_MUSTERI", "UNVAN");

				myMap.put("REF_NO", hznCurEffOnayTx.getRefNo());
				myMap.put("OTHER_BANK", unvan);
				oMap = GMServiceExecuter.call("CHMS_SEND_MAIL_FOR_CASH_PROCESS", myMap);

				ChmsCashProcessTx chmsCashProcessTx = (ChmsCashProcessTx) session.createCriteria(ChmsCashProcessTx.class).add(Restrictions.eq("status", true))
						.add(Restrictions.eq("refNo", hznCurEffOnayTx.getRefNo())).uniqueResult();
				
				if (chmsCashProcessTx.getCitFirm().equals("2")) {
					
					GMMap desmerDemand = new GMMap();
					desmerDemand.put("DESMER_PROCESS_TYPE", "YENI");							
					desmerDemand.put("CHMS_DEMAND_POINT", chmsCashProcessTx.getDemandPoint());							
					desmerDemand.put("CHMS_PROCESS_TYPE", chmsCashProcessTx.getProcessType());							
					desmerDemand.put("CHMS_BRANCH_CODE", chmsCashProcessTx.getBranchCode());							
					desmerDemand.put("CHMS_DESTINATION_BRANCH_CODE", chmsCashProcessTx.getDestinationBranch());							
					desmerDemand.put("CHMS_CURRENCY_CODE", chmsCashProcessTx.getCurrencyCode());							
					desmerDemand.put("PROCESS_AMOUNT", chmsCashProcessTx.getProcessAmount());
					desmerDemand.put("PROCESS_DATE", chmsCashProcessTx.getProcessDate());		
					desmerDemand.put("DESCRIPTION", chmsCashProcessTx.getDescription());							
					desmerDemand.put("OTHER_BANK_CUSTOMER_NO", hznCurEffOnayTx.getBankaMusteriNo());							
					desmerDemand.put("TX_NO", chmsCashProcessTx.getTxNo());							
					desmerDemand.put("REF_NO", chmsCashProcessTx.getRefNo());							
										
					GMServiceExecuter.call("CHMS_DESMER_DEMAND_BY_POINT_AND_PROCESS_TYPE", desmerDemand);	
					
				} 
			}
			
			return oMap;

		} catch (Exception e) {
			e.printStackTrace();
			return oMap;
		}

	}
	@GraymoundService("BNSPR_TRN1361_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1361.BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1361_PARITEDEN_TUTAR_HESAPLA")
	public static GMMap paritedenTutarHesapla(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1361.pariteden_tutar_hesapla(?,?,?,?,?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("CASH"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("PARITE"));
			stmt.setString(5, iMap.getString("DOVIZ_KODU1"));
			stmt.setString(6, iMap.getString("DOVIZ_KODU2"));
			
			stmt.execute();
			oMap.put("TUTAR", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1361_GET_INITIAL_DATA")
	public static GMMap getTransferData(GMMap iMap){

		try {
			GMMap oMap = new GMMap();
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznCurEffTalepTx hznCurEffTalepTx = (HznCurEffTalepTx)session.get(HznCurEffTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("TX_NO", hznCurEffTalepTx.getTxNo());
			oMap.put("REF_NO", hznCurEffTalepTx.getRefNo());
			oMap.put("URUN_TUR_KOD", hznCurEffTalepTx.getUrunTurKod());//LovHelper.diLov(, "1361/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznCurEffTalepTx.getUrunSinifKod());
			oMap.put("SUBE_KODU", hznCurEffTalepTx.getSubeKodu());
			oMap.put("SUBE_ADI", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "ACIKLAMA" ));
		//	oMap.put("DEALER_NO", hznCurEffTalepTx.getDealerSicilNo());
	//		oMap.put("DEALER_ADI", LovHelper.diLov(hznCurEffTalepTx.getDealerSicilNo(), "1361/LOV_DEALER", "ISIM"));
			if(hznCurEffTalepTx.getIslemTipi()!= null && hznCurEffTalepTx.getIslemTipi().equals("I"))
			{
				oMap.put("CASH", "A");
				oMap.put("ALIS_TUTARI", hznCurEffTalepTx.getTutar());
				oMap.put("ALIS_DOVIZ_KODU", hznCurEffTalepTx.getDovizKodu());
				oMap.put("SATIS_DOVIZ_KODU", hznCurEffTalepTx.getDovizKodu());
				oMap.put("ALIS_VALOR_TARIHI", hznCurEffTalepTx.getValorTarihi());
				oMap.put("SATIS_TUTARI", "0.00");
			}
			else if (hznCurEffTalepTx.getIslemTipi()!= null && hznCurEffTalepTx.getIslemTipi().equals("F"))
			{
				oMap.put("CASH", "S");
				oMap.put("SATIS_TUTARI", hznCurEffTalepTx.getTutar());
				oMap.put("SATIS_DOVIZ_KODU", hznCurEffTalepTx.getDovizKodu());
				oMap.put("ALIS_DOVIZ_KODU", hznCurEffTalepTx.getDovizKodu());
				oMap.put("SATIS_VALOR_TARIHI", hznCurEffTalepTx.getValorTarihi());
				oMap.put("ALIS_TUTARI", "0.00");
			}
			else
			{
				oMap.put("CASH", "");
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1361_SAVE")
	public static GMMap Save (GMMap iMap){
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			HznCurEffOnayTx hznCurEffOnayTx = (HznCurEffOnayTx)session.get(HznCurEffOnayTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznCurEffOnayTx == null) {
				hznCurEffOnayTx = new HznCurEffOnayTx();
			}
			hznCurEffOnayTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznCurEffOnayTx.setRefNo(iMap.getString("REFERANS"));
			hznCurEffOnayTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznCurEffOnayTx.setAlisTutari(iMap.getBigDecimal("ALIS_TUTARI"));
			hznCurEffOnayTx.setAlisHesapTuru(iMap.getString("ALIS_HESAP_TURU"));
			hznCurEffOnayTx.setAlisHesapNo(iMap.getBigDecimal("ALIS_HESAP_NO"));
			hznCurEffOnayTx.setSatisTutari(iMap.getBigDecimal("SATIS_TUTARI"));
			hznCurEffOnayTx.setSatisHesapTuru(iMap.getString("SATIS_HESAP_TURU"));
			hznCurEffOnayTx.setSatisHesapNo(iMap.getBigDecimal("SATIS_HESAP_NO"));
			hznCurEffOnayTx.setDealerSicilNo(iMap.getString("DEALER_NO"));
			hznCurEffOnayTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznCurEffOnayTx.setAlisValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznCurEffOnayTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznCurEffOnayTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznCurEffOnayTx.setParite(iMap.getBigDecimal("PARITE"));
			hznCurEffOnayTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			hznCurEffOnayTx.setSatisValorTarihi(iMap.getDate("SATIS_VALOR_TARIHI"));
			hznCurEffOnayTx.setOnayRed(iMap.getString("ONAY_RED"));
			hznCurEffOnayTx.setCash(iMap.getString("CASH"));
			hznCurEffOnayTx.setSubeKodu(iMap.getString("SUBE_KODU"));
			hznCurEffOnayTx.setAlisMuhabirMusteriNo(iMap.getString("ALIS_MUSTERI_MUHABIR_NO"));
			hznCurEffOnayTx.setSatisMuhabirMusteriNo(iMap.getString("SATIS_MUSTERI_MUHABIR_NO"));
			session.saveOrUpdate(hznCurEffOnayTx);
			session.flush();
			iMap.put("TRX_NAME", "1361");
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1361_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			
			HznCurEffOnayTx hznCurEffOnayTx = (HznCurEffOnayTx)session.get(HznCurEffOnayTx.class, txNo);
			
			oMap.put("TX_NO", hznCurEffOnayTx.getTxNo());
			oMap.put("DEAL_TARIHI", hznCurEffOnayTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznCurEffOnayTx.getAlisTutari());
			oMap.put("ALIS_HESAP_TURU", hznCurEffOnayTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznCurEffOnayTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznCurEffOnayTx.getSatisTutari());
			oMap.put("SATIS_HESAP_TURU", hznCurEffOnayTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznCurEffOnayTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznCurEffOnayTx.getDealerSicilNo());
			oMap.put("BANKA_MUSTERI_NO", hznCurEffOnayTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznCurEffOnayTx.getAlisValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznCurEffOnayTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznCurEffOnayTx.getSatisDovizKodu());
			oMap.put("PARITE", hznCurEffOnayTx.getParite());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznCurEffOnayTx.getDealerSicilNo(), "1361/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznCurEffOnayTx.getBankaMusteriNo(), "1361/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznCurEffOnayTx.getAlisHesapNo(),hznCurEffOnayTx.getAlisDovizKodu(), hznCurEffOnayTx.getAlisHesapTuru(),hznCurEffOnayTx.getAlisHesapTuru(),
					hznCurEffOnayTx.getAlisHesapTuru(),hznCurEffOnayTx.getBankaMusteriNo(), 
					 "1361/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznCurEffOnayTx.getSatisHesapNo(),hznCurEffOnayTx.getSatisDovizKodu(), hznCurEffOnayTx.getSatisHesapTuru(),
					hznCurEffOnayTx.getSatisHesapTuru(),hznCurEffOnayTx.getSatisHesapTuru(),hznCurEffOnayTx.getBankaMusteriNo(),
					 "1361/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_VALOR_TARIHI",hznCurEffOnayTx.getSatisValorTarihi());
			oMap.put("ONAY_RED",hznCurEffOnayTx.getOnayRed());
			oMap.put("CASH",hznCurEffOnayTx.getCash());
			
			HznCurEffTalepTx hznCurEffTalepTx = (HznCurEffTalepTx)session.get(HznCurEffTalepTx.class, iMap.getBigDecimal("TX_NO"));
			oMap.put("REF_NO", hznCurEffTalepTx.getRefNo());
			oMap.put("URUN_TUR_KOD", hznCurEffTalepTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznCurEffTalepTx.getUrunSinifKod());
			oMap.put("SUBE_KODU", hznCurEffTalepTx.getSubeKodu());
			oMap.put("SUBE_ADI", LovHelper.diLov(hznCurEffTalepTx.getSubeKodu(), "1360/LOV_SUBE_KODU", "ACIKLAMA" ));
			oMap.put("ALIS_MUHABIR_MUSTERI_NO",hznCurEffOnayTx.getAlisMuhabirMusteriNo());
			oMap.put("SATIS_MUHABIR_MUSTERI_NO",hznCurEffOnayTx.getSatisMuhabirMusteriNo());

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
