package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinVerilendepoTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3616Services {

	@GraymoundService("BNSPR_TRN3616_SAVE")
    public static Map<?, ?> save(GMMap iMap){
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilendepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAltinVerilendepoTx == null) {
			    hznAltinVerilendepoTx = new HznAltinVerilendepoTx();
			}
			
			hznAltinVerilendepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAltinVerilendepoTx.setModulTurKod("HAZINE");
			hznAltinVerilendepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAltinVerilendepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAltinVerilendepoTx.setReferans(iMap.getString("REFERANS"));
			hznAltinVerilendepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznAltinVerilendepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznAltinVerilendepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAltinVerilendepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAltinVerilendepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAltinVerilendepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAltinVerilendepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAltinVerilendepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAltinVerilendepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAltinVerilendepoTx.setNetTutar(iMap.getBigDecimal("NET_TUTAR"));
			hznAltinVerilendepoTx.setBrutTutar(iMap.getBigDecimal("BRUT_TUTAR"));
			hznAltinVerilendepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAltinVerilendepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAltinVerilendepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAltinVerilendepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAltinVerilendepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAltinVerilendepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAltinVerilendepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAltinVerilendepoTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			hznAltinVerilendepoTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			hznAltinVerilendepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			hznAltinVerilendepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznAltinVerilendepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			
			hznAltinVerilendepoTx.setStokNo(iMap.getString("STOK_NO"));
			hznAltinVerilendepoTx.setSaflikDerecesi(iMap.getBigDecimal("SAFLIK_DERECESI"));
			hznAltinVerilendepoTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
			hznAltinVerilendepoTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
			hznAltinVerilendepoTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
			
			session.saveOrUpdate(hznAltinVerilendepoTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3616");            
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3616_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3616.BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3616_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilendepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznAltinVerilendepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinVerilendepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinVerilendepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinVerilendepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinVerilendepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinVerilendepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinVerilendepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinVerilendepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinVerilendepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinVerilendepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinVerilendepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinVerilendepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinVerilendepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinVerilendepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinVerilendepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinVerilendepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinVerilendepoTx.getEsasGunSayisi());
			oMap.put("VADEISLEMBILGISI", hznAltinVerilendepoTx.getVadeIslemBilgisi());
			oMap.put("ISTATISTIKKODU", hznAltinVerilendepoTx.getIstatistikKodu());
			oMap.put("DEALTARIHI", hznAltinVerilendepoTx.getDealTarihi());
			oMap.put("TENOR", hznAltinVerilendepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinVerilendepoTx.getFaizTutari());
			oMap.put("FAIZ_ORANI", hznAltinVerilendepoTx.getFaizOrani());
			oMap.put("DURUM_KODU", hznAltinVerilendepoTx.getDurumKodu()); 
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilendepoTx.getGirisHesapNo(),hznAltinVerilendepoTx.getDovizKodu(),
			        hznAltinVerilendepoTx.getGirisHesapTuru(), hznAltinVerilendepoTx.getDovizKodu(), hznAltinVerilendepoTx.getGirisHesapTuru(), 
			        hznAltinVerilendepoTx.getBankaMusteriNo(), "1313/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilendepoTx.getCikisHesapNo(),hznAltinVerilendepoTx.getDovizKodu(),
			        hznAltinVerilendepoTx.getCikisHesapTuru(), hznAltinVerilendepoTx.getDovizKodu(), hznAltinVerilendepoTx.getCikisHesapTuru(), 
			        hznAltinVerilendepoTx.getBankaMusteriNo(), "1313/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinVerilendepoTx.getBankaMusteriNo(), "1313/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinVerilendepoTx.getDealerNo(), "1313/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinVerilendepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinVerilendepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinVerilendepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("STOK_NO",hznAltinVerilendepoTx.getStokNo());
			oMap.put("SAFLIK_DERECESI",hznAltinVerilendepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI",hznAltinVerilendepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI",hznAltinVerilendepoTx.getKomisyonTutari());
			oMap.put("ISLEM_TURU",hznAltinVerilendepoTx.getIslemTuru());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN3616_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilenDepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAltinVerilenDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinVerilenDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinVerilenDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinVerilenDepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinVerilenDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinVerilenDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinVerilenDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinVerilenDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinVerilenDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinVerilenDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinVerilenDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinVerilenDepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinVerilenDepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinVerilenDepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinVerilenDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinVerilenDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinVerilenDepoTx.getEsasGunSayisi());
			oMap.put("VADEISLEMBILGISI", hznAltinVerilenDepoTx.getVadeIslemBilgisi());
			oMap.put("ISTATISTIKKODU", hznAltinVerilenDepoTx.getIstatistikKodu());
			oMap.put("DEALTARIHI", hznAltinVerilenDepoTx.getDealTarihi());
			oMap.put("TENOR", hznAltinVerilenDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinVerilenDepoTx.getFaizTutari());
			oMap.put("FAIZ_ORANI", hznAltinVerilenDepoTx.getFaizOrani());
			oMap.put("DURUM_KODU", hznAltinVerilenDepoTx.getDurumKodu()); 
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getGirisHesapNo(),hznAltinVerilenDepoTx.getDovizKodu(),
			        hznAltinVerilenDepoTx.getGirisHesapTuru(), hznAltinVerilenDepoTx.getDovizKodu(), hznAltinVerilenDepoTx.getGirisHesapTuru(), 
			        hznAltinVerilenDepoTx.getBankaMusteriNo(), "1313/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getCikisHesapNo(),hznAltinVerilenDepoTx.getDovizKodu(),
			        hznAltinVerilenDepoTx.getCikisHesapTuru(), hznAltinVerilenDepoTx.getDovizKodu(), hznAltinVerilenDepoTx.getCikisHesapTuru(), 
			        hznAltinVerilenDepoTx.getBankaMusteriNo(), "1313/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getBankaMusteriNo(), "1313/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinVerilenDepoTx.getDealerNo(), "1313/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinVerilenDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinVerilenDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinVerilenDepoTx.getCikisMuhabirMusteriNo());
			oMap.put("STOK_NO",hznAltinVerilenDepoTx.getStokNo());
			oMap.put("SAFLIK_DERECESI",hznAltinVerilenDepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI",hznAltinVerilenDepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI",hznAltinVerilenDepoTx.getKomisyonTutari());
			oMap.put("ISLEM_TURU",hznAltinVerilenDepoTx.getIslemTuru());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
}
