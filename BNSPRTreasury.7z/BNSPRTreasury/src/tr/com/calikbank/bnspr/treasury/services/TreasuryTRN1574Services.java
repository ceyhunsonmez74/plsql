package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTeminatTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTeminatTxId;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1574Services {



	@GraymoundService("BNSPR_TRN1574_ISLEMLERI_GETIR")
	public static GMMap teminatlariHesapla  (GMMap iMap) {
	GMMap oMap = new GMMap(); 
		
	String func = "{ ? = call pkg_trn1574.yasayantxlist}";
	
	try {
		oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE", new Object[0]);
	}
	catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}
	
	return oMap;
}
	
	@GraymoundService("BNSPR_TRN1574_SAVE")
	public static Map<?, ?> save(GMMap iMap) throws ParseException {

		Session session = DAOSession.getSession("BNSPRDal");

		HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
	//	HznOpsiyonislemTeminatTx hznOpsiyonislemTeminatTx = (HznOpsiyonislemTeminatTx) session.createCriteria(HznOpsiyonislemTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		HznOpsiyonislemTeminatTxId hznOpsiyonislemTeminatTxId = null;

		if (hznOpsiyonislemTx == null) {
			hznOpsiyonislemTx = new HznOpsiyonislemTx();
		}

		HznOpsiyonislemTeminatTx	hznOpsiyonislemTeminatTx = new HznOpsiyonislemTeminatTx();

			hznOpsiyonislemTeminatTxId = new HznOpsiyonislemTeminatTxId();
		

		hznOpsiyonislemTx.setAlacakHesap(iMap.getBigDecimal("ALACAK_HESAP"));
		hznOpsiyonislemTx.setAlacakHesapDvz(iMap.getString("ALACAK_HESAP_DOVIZ"));
		hznOpsiyonislemTx.setAlinanDoviz(iMap.getString("ALINAN_DOVIZ_TEXT"));
		hznOpsiyonislemTx.setAlinanTutar(iMap.getBigDecimal("ALINAN_DOVIZ"));
		hznOpsiyonislemTx.setBazDvz(iMap.getString("COMBO_BAZ_DOVIZ_CINSI"));
		hznOpsiyonislemTx.setBazTutar(iMap.getBigDecimal("BAZ_OPSIYON_TUTARI"));
		hznOpsiyonislemTx.setBorcluHesap(iMap.getBigDecimal("BORCLU_HESAP"));
		hznOpsiyonislemTx.setBorcluHesapDvz(iMap.getString("BORCLU_HESAP_DOVIZ"));
		hznOpsiyonislemTx.setKarsiDoviz(iMap.getString("COMBO_KARSI_DOVIZ"));
		hznOpsiyonislemTx.setKarsiTutar(iMap.getBigDecimal("KARSI_OPSIYON_TUTARI"));
		hznOpsiyonislemTx.setOpsAmac(iMap.getString("COMBO_OPSIYON_AMAC"));
		hznOpsiyonislemTx.setOpsCinsi(iMap.getString("COMBO_OPSIYON_CINS"));
		hznOpsiyonislemTx.setOpsDealer(iMap.getString("dfDealer"));
		hznOpsiyonislemTx.setOpsSekliBaz(iMap.getString("COMBO_OPSIYON_SEKLI"));
		hznOpsiyonislemTx.setHedefFiyat(iMap.getBigDecimal("HEDEF_FIYAT"));
		hznOpsiyonislemTx.setOpsTipi(iMap.getString("COMBO_OPSIYON_TIPI"));
		hznOpsiyonislemTx.setOpsYonu(iMap.getString("COMBO_OPSIYON_YONU"));
		hznOpsiyonislemTx.setPrimDoviz(iMap.getString("COMBO_PRIM_DOVIZ_CINSI"));
		hznOpsiyonislemTx.setPrimHesapNo(iMap.getBigDecimal("PRIM_HESAP_NO"));
		hznOpsiyonislemTx.setPrimMaliyet(iMap.getBigDecimal("MALIYET_PRIM"));
		hznOpsiyonislemTx.setPrimMusteri(iMap.getBigDecimal("MUSTERI_PRIM"));
		hznOpsiyonislemTx.setPrimMusteriYillik(iMap.getBigDecimal("MALIYET_PRIM_YILLIK"));
		hznOpsiyonislemTx.setPrimSubeKariDvz(iMap.getString("SUBE_KARI_DOVIZ_CINSI"));
		hznOpsiyonislemTx.setPrimSubeKariTutar(iMap.getBigDecimal("SUBE_KARI"));
		hznOpsiyonislemTx.setPrimTutar(iMap.getBigDecimal("PRIM_TUTARI"));
		hznOpsiyonislemTx.setRiskIslemTipi(iMap.getString("ISLEM_TURU"));
		hznOpsiyonislemTx.setRiskTeminatOran(iMap.getBigDecimal("TEMINAT_ORANI"));
		hznOpsiyonislemTx.setRiskTeminatTutar(iMap.getBigDecimal("TEMINAT_TUTARI"));
		hznOpsiyonislemTx.setSatilanDvz(iMap.getString("SATILAN_DOVIZ_TEXT"));
		hznOpsiyonislemTx.setSatilanTutar(iMap.getBigDecimal("SATILAN_DOVIZ"));
		hznOpsiyonislemTx.setSpotKur(iMap.getBigDecimal("SPOT_KURU"));
		hznOpsiyonislemTx.setPrimMusteriYillik(iMap.getBigDecimal("MUSTERI_PRIM_YILLIK"));
		hznOpsiyonislemTx.setSubeAna(iMap.getBigDecimal("ANA_SUBE_KODU"));
		hznOpsiyonislemTx.setSubeIslem(iMap.getBigDecimal("SUBE_KODU"));
		hznOpsiyonislemTx.setSubePyKod(iMap.getString("PY_KODU"));
		hznOpsiyonislemTx.setTarihIslem(new java.sql.Date(iMap.getDate("ISLEM_TARIHI").getTime()));
		hznOpsiyonislemTx.setTarihPrim(new java.sql.Date(iMap.getDate("UZLASMA_TARIHI").getTime()));
		hznOpsiyonislemTx.setTarihUzlasma(new java.sql.Date(iMap.getDate("UZLASMA_TARIHI").getTime()));
		hznOpsiyonislemTx.setTarihVade(new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
		hznOpsiyonislemTx.setKarsilananTeminatTl(iMap.getBigDecimal("KARSILANAN_TUTAR"));
		hznOpsiyonislemTx.setHesaplananTeminatTl(iMap.getBigDecimal("KARSILANAN_TUTAR"));
		
	      HznOpsiyonislemTxId tid = new HznOpsiyonislemTxId();
	        tid.setReferans(iMap.getString("TRX_NO_REFERANS"));
	        tid.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        hznOpsiyonislemTx.setId(tid);
		
		hznOpsiyonislemTx.setOpsStatus("IP");
		hznOpsiyonislemTx.setDokuman1("Y");
		hznOpsiyonislemTx.setDokuman2("Y");

		if(iMap.getBoolean("R_BANKA")==true)
		{
			hznOpsiyonislemTx.setMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI"));
			hznOpsiyonislemTx.setBankami("E");
		}
		
		else if(iMap.getBoolean("R_MUSTERI")==true)
		{
			hznOpsiyonislemTx.setMusteriNo(iMap.getBigDecimal("GENEL_MUSTERI"));
			hznOpsiyonislemTx.setBankami("H");
		}
		
		
		session.saveOrUpdate(hznOpsiyonislemTx);

		BigDecimal sira = BigDecimal.ZERO;
		for (int row = 0; row < iMap.getSize("TABLE_TEMINAT"); row++) {
			hznOpsiyonislemTeminatTxId = new HznOpsiyonislemTeminatTxId();
			hznOpsiyonislemTeminatTx = new HznOpsiyonislemTeminatTx();
			sira = sira.add(new BigDecimal(1));
			hznOpsiyonislemTeminatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznOpsiyonislemTeminatTxId.setReferans(iMap.getString("TRX_NO_REFERANS"));
			hznOpsiyonislemTeminatTxId.setSira(sira);
			hznOpsiyonislemTeminatTx.setId(hznOpsiyonislemTeminatTxId);
			hznOpsiyonislemTeminatTx.setDovizKodu(iMap.getString("TABLE_TEMINAT", row, "DOVIZ"));
			hznOpsiyonislemTeminatTx.setIsinKod(iMap.getString("TABLE_TEMINAT", row, "ISIN_KODU"));
			hznOpsiyonislemTeminatTx.setKarsilananTlTutar(iMap.getBigDecimal("TABLE_TEMINAT", row, "KARSILANAN_TUTAR"));
			hznOpsiyonislemTeminatTx.setRiskKarsilamaYuzdesi(iMap.getBigDecimal("TABLE_TEMINAT", row, "KARSILAMA"));
			hznOpsiyonislemTeminatTx.setTutari(iMap.getBigDecimal("TABLE_TEMINAT", row, "TEM_TUTAR"));
			hznOpsiyonislemTeminatTx.setSpotDovizKuru(iMap.getBigDecimal("SPOT_KURU"));
			hznOpsiyonislemTeminatTx.setTeminatCinsi(iMap.getString("TABLE_TEMINAT", row, "KOD"));
			session.saveOrUpdate(hznOpsiyonislemTeminatTx);
		}

		session.flush();
		
		iMap.put("TRX_NAME","1574");
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	}
	
	
}
