package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class TreasuryQRY3611Services {
	
 
    
    @GraymoundService("BNSPR_QRY3611_HZN_ADEPO_FAIZ")
    public static GMMap getHznFaiz(GMMap iMap)
    {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_RC3611.GET_DEPO_DETAY(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("REFERANS"));
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);
            return DALUtil.rSetResults(rSet, "HZN_ADEPO_AP");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
    }
    
    
    @GraymoundService("BNSPR_QRY3611_INITIALIZE_COMBO")
    public static GMMap initialize(GMMap iMap){
        GMMap oMap = new GMMap();

       
        
       iMap.put("ADD_EMPTY_KEY", "E");
        iMap.put("KOD", "HZN_ALTIN_DEPO_ISLEM_TURU");
        oMap.put("HZN_ALTIN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
        iMap.put("ADD_EMPTY_KEY", "E");
        iMap.put("KOD", "HZN_ALTIN_DEPO_ISLEM_TURU");
        oMap.put("HZN_ALTIN_DEPO_ISLEM_TURU_TABLO", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
        iMap.put("ADD_EMPTY_KEY", "E");
      iMap.put("KOD", "HZN_ISLEM_DURUM");
       oMap.put("DURUM_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
      iMap.put("ADD_EMPTY_KEY", "E");
      iMap.put("KOD", "HZN_ISLEM_DURUM");
      oMap.put("DURUM_KODU_TABLO", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
    
        
        
        return oMap;
    }
    

	@GraymoundService("BNSPR_QRY3611_HZN_DEPO")
	public static GMMap getHznDeposu(GMMap iMap){
	
	    GMMap oMap = new GMMap();
	    Connection conn  = null;
	    CallableStatement stmt=null;
		ResultSet rSet=null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_RC3611.GET_DEPO_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			 int i = 1;
          stmt.registerOutParameter(i++, -10);
		  stmt.setString(i++,iMap.getString("SUBE_KODU"));
		  stmt.setString(i++,iMap.getString("REFERANS"));
		  stmt.setString(i++,iMap.getString("DEPO_TIPI"));
	      stmt.setString(i++,iMap.getString("URUN_TUR_KOD"));
	      stmt.setString(i++,iMap.getString("URUN_SINIF_KOD"));
          stmt.setString(i++,iMap.getString("DURUM"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("FAIZ_ORANI"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("MUSTERI_NO"));
          stmt.setString(i++ , iMap.getString("ISLEM_TURU")== null ? null : iMap.getString("ISLEM_TURU"));
          stmt.setDate(i++ , iMap.getDate("DEAL1")== null ? null : new Date(iMap.getDate("DEAL1").getTime()));  
          stmt.setDate(i++ , iMap.getDate("DEAL2")== null ? null : new Date(iMap.getDate("DEAL2").getTime()));
          stmt.setDate(i++ , iMap.getDate("VALOR1")== null ? null : new Date(iMap.getDate("VALOR1").getTime()));
          stmt.setDate(i++ , iMap.getDate("VALOR2")== null ? null : new Date(iMap.getDate("VALOR2").getTime()));
          stmt.setDate(i++ , iMap.getDate("VADE1")== null ? null : new Date(iMap.getDate("VADE1").getTime()));
          stmt.setDate(i++ , iMap.getDate("VADE2")== null ? null : new Date(iMap.getDate("VADE2").getTime()));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("BRUT_MAX"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("BRUT_MIN"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("NET_MAX"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("NET_MIN"));
          stmt.setString(i++,iMap.getString("DOVIZ_KODU"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("ISLEM_NO_MIN"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("ISLEM_NO_MAX"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("PC_STOK"));
          stmt.setBigDecimal(i++,iMap.getBigDecimal("ALTIN_SAFLIK"));
          stmt.execute();
          rSet = (ResultSet)stmt.getObject(1);
          String tableName = "DEPO_BILGILERI";
          
          int j = 0;

			while (rSet.next()) {

                oMap.put(tableName, j, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, j, "BANKA_HESAP_NO", rSet.getString("BANKA_HESAP_NO"));
				oMap.put(tableName, j, "BANKA_MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put(tableName, j, "SUBE_KODU", rSet.getString("SUBE_KODU"));
				oMap.put(tableName, j, "CIKIS_HESAP_NO", rSet.getString("CIKIS_HESAP_NO"));
				oMap.put(tableName, j, "CIKIS_HESAP_TURU", rSet.getString("CIKIS_HESAP_TURU"));
				oMap.put(tableName, j, "DEALER_NO", rSet.getString("DEALER_NO"));
				oMap.put(tableName, j, "DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName, j, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, j, "ESAS_GUN_SAYISI", rSet.getBigDecimal("ESAS_GUN_SAYISI"));
				oMap.put(tableName, j, "FAIZ_ORANI", rSet.getBigDecimal("FAIZ_ORANI"));
				oMap.put(tableName, j, "FAIZ_TUTARI", rSet.getBigDecimal("FAIZ_TUTARI"));
				oMap.put(tableName, j, "GIRIS_HESAP_NO", rSet.getString("GIRIS_HESAP_NO"));
				oMap.put(tableName, j, "GIRIS_HESAP_TURU", rSet.getString("GIRIS_HESAP_TURU"));
				oMap.put(tableName, j, "MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, j, "TENOR", rSet.getBigDecimal("TENOR"));
				oMap.put(tableName, j, "BRUT_TUTAR", rSet.getBigDecimal("BRUT_TUTAR"));
				oMap.put(tableName, j, "NET_TUTAR", rSet.getString("NET_TUTAR"));
				oMap.put(tableName, j, "URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put(tableName, j, "URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
                oMap.put(tableName, j, "VADE_ISLEM_BILGISI", rSet.getString("VADE_ISLEM_BILGISI"));
				oMap.put(tableName, j, "VADE_TARIHI", rSet.getDate("VADE_TARIHI"));
				oMap.put(tableName, j, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, j, "YARATAN_TX_NO", rSet.getString("YARATAN_TX_NO"));
				oMap.put(tableName, j, "ISLEM_TURU", rSet.getString("ISLEM_TURU"));
				oMap.put(tableName, j, "DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));
				oMap.put(tableName, j, "SON_TXNO", rSet.getString("SON_TXNO"));			
				oMap.put(tableName, j, "CIKIS_MUHABIR_MUSTERI_NO", rSet.getString("CIKIS_MUHABIR_MUSTERI_NO"));			
				oMap.put(tableName, j, "GIRIS_MUHABIR_MUSTERI_NO", rSet.getString("GIRIS_MUHABIR_MUSTERI_NO"));
				oMap.put(tableName, j, "SAFLIK_DERECESI",rSet.getBigDecimal("SAFLIK_DERECESI"));
				oMap.put(tableName, j, "KOMISYON_ORANI",rSet.getBigDecimal("KOMISYON_ORANI"));
				oMap.put(tableName, j, "KOMISYON_TUTARI",rSet.getBigDecimal("KOMISYON_TUTARI"));
				oMap.put(tableName, j, "STOK_NO",rSet.getString("STOK_NO"));
				oMap.put(tableName ,j, "ALINAN_TARIH",rSet.getDate("ALINAN_TARIH"));
				j++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	@GraymoundService("BNSPR_QRY3611_HZN_ISLEM_HAREKETLERI")
	public static GMMap getHznIslemHareketleri(GMMap iMap){
	
		try{
		    String func2 = "{? = call PKG_RC_HAZINE.Rc_Qry3611_Hzn_XAU_Depo_Harkt(?)}";
			int i = 0;

            Object[] inputValues = new Object[2];
            inputValues[i++] = BnsprType.STRING;
            inputValues[i++] = iMap.getString("REFERANS");

            return DALUtil.callOracleRefCursorFunction(func2, "ISLEM_BILGILERI", inputValues);

			
			//return DALUtil.rSetResults(rSet, "ISLEM_BILGILERI");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
