package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SpkUygunlukTesti;
import tr.com.aktifbank.bnspr.dao.SpkUygunlukTestiDetayTx;
import tr.com.aktifbank.bnspr.dao.SpkUygunlukTestiDetayTxId;
import tr.com.aktifbank.bnspr.dao.SpkUygunlukTestiTx;
import tr.com.aktifbank.bnspr.dao.SpkUygunlukTestiTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN9963Services {
	
	@GraymoundService("BNSPR_TRN9963_GET_DATA")
	public static GMMap getData(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				/*
				 * tx-e gore mevcut-kayit master tablodan cekilir
				 */
				SpkUygunlukTestiTx uygunlukTestiTx = (SpkUygunlukTestiTx) session.createCriteria(SpkUygunlukTestiTx.class).add(Restrictions.eq("id.txNo", trxNo)).uniqueResult();

				oMap.put("MUSTERI_NO", uygunlukTestiTx.getId().getMusteriNo());
				oMap.put("KANAL_KODU", uygunlukTestiTx.getKanal());
				oMap.put("SKOR", uygunlukTestiTx.getSkor());
				oMap.put("MESLEK", uygunlukTestiTx.getMeslek());
				
				oMap.putAll(getUygunlukTestiTrx(trxNo));
				
			} else {//yoksa ana tablo uzerinden gelsin
				
				/*
				 * musteri noya gore mevcut kayit cekilir
				 */
				SpkUygunlukTesti uygunlukTesti = (SpkUygunlukTesti) session.createCriteria(SpkUygunlukTesti.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();
				
				if (uygunlukTesti != null) {//uygunluk testi varsa
					
					oMap.put("MUSTERI_NO", uygunlukTesti.getMusteriNo());
					oMap.put("KANAL_KODU", uygunlukTesti.getKanal());
					oMap.put("SKOR", uygunlukTesti.getSkor());
					oMap.put("MESLEK", uygunlukTesti.getMeslek());
					
					oMap.putAll(getUygunlukTestiMusteri(musteriNo));
					
				} else {//yoksa
					
					oMap.put("MUSTERI_NO", musteriNo);
					
					oMap.putAll(getUygunlukTesti());
					
				}
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9963_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");

			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete SpkUygunlukTestiTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.createQuery("delete SpkUygunlukTestiDetayTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			/*
			 * master tabloya kayit atilir
			 */
			
			SpkUygunlukTestiTxId id = new SpkUygunlukTestiTxId();
			id.setTxNo(trxNo);
			id.setMusteriNo(musteriNo);
			
			SpkUygunlukTestiTx spkUygunlukTestiTx = new SpkUygunlukTestiTx();
			spkUygunlukTestiTx.setId(id);
			spkUygunlukTestiTx.setKanal(iMap.getString("KANAL_KODU"));
			spkUygunlukTestiTx.setSkor(iMap.getBigDecimal("SKOR"));
			spkUygunlukTestiTx.setMeslek(iMap.getString("MESLEK"));
			
			session.saveOrUpdate(spkUygunlukTestiTx);
			
			/*
			 * detail tabloya kayit atilir
			 */
			
			for (Object key : iMap.keySet()) {
				if (((String)key).startsWith("KOD_")) {//eger ki key kod ise 
					Object kod = iMap.get(key);
					Object skor = iMap.get(((String)key).replaceAll("KOD_", "SKOR_"));//skor budur
					
					if (kod != null && kod instanceof String &&
							skor != null && skor instanceof Integer) {//kod str, skor int olur
						
						SpkUygunlukTestiDetayTxId detayId = new SpkUygunlukTestiDetayTxId();
						detayId.setTxNo(trxNo);
						detayId.setMusteriNo(musteriNo);
						detayId.setKod((String)kod);
						
						SpkUygunlukTestiDetayTx uygunlukTestiDetayTx = new SpkUygunlukTestiDetayTx();
						uygunlukTestiDetayTx.setId(detayId);
						uygunlukTestiDetayTx.setSkor(BigDecimal.valueOf(((Integer)skor)));
						
						session.saveOrUpdate(uygunlukTestiDetayTx);
					}
				}
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9963");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_CHECK_UYGUNLUK")
	public static GMMap checkUygunluk(GMMap iMap) {
		try {
			String func = "{call PKG_TRN9963.Check_Uygunluk(?,?)}";
			Object[] inputs = new Object[] {
					BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_KODU"),
					BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO")};
			Object[] outputs = new Object[]{};
			
			DALUtil.callOracleProcedure(func, inputs, outputs);
			
			GMMap oMap = new GMMap();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9963_SKOR_HESAPLA")
	public static GMMap hesaplaSkor(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			int skor = 0;
			
			for (Object key : iMap.keySet()) {
				Object s = iMap.get(key);
				if (s != null && s instanceof Integer)
					skor += (Integer) iMap.get(key);
			}
			
			oMap.put("SKOR", skor);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static void fillUygunlukTesti(GMMap results, GMMap oMap) {
		try {
			String listName = "RESULTS";
			String parent = "";
			List<HashMap<String, Object>> cevaplar = new ArrayList<HashMap<String,Object>>();
			
			for (int i = 0; i < results.getSize(listName); i++) {
				String kod = results.getString(listName, i, "KOD");
				int skor = results.getInt(listName, i, "SKOR");
				String tip = results.getString(listName, i, "TIP");
				String deger = results.getString(listName, i, "DEGER");
				String seciliMi = results.getString(listName, i, "SECILI_MI");
				
				if ("P".equals(tip)) {//tipi P-> parent ise
					
					oMap.put("TITLE_" + kod, deger);//parent in degeri panelin basligidir
					
					if (cevaplar.size() > 0) {//eger cevaplar varsa
						oMap.put("DATA_" + parent, cevaplar);//parent'a cevaplari ekle
					}
					
					parent = kod;//yeni parent geldi
					cevaplar = new ArrayList<HashMap<String,Object>>();//cevap listesini sifirla
					
				} else {//parent degilse cevaplar� ekleriz
					
					cevaplar.add(createCevap(kod, skor, deger, seciliMi));
					
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static GMMap getUygunlukTesti() {
		try {
			GMMap oMap = new GMMap();
			
			String func = "{? = call PKG_TRN9963.Get_Uygunluk_Testi()}";
			String listName = "RESULTS";
			
			GMMap results = DALUtil.callOracleRefCursorFunction(func, listName);
			
			fillUygunlukTesti(results, oMap);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static GMMap getUygunlukTestiTrx(BigDecimal trxNo) {
		try {
			GMMap oMap = new GMMap();
			
			String func = "{? = call PKG_TRN9963.Get_Uygunluk_Testi_Trx(?)}";
			String listName = "RESULTS";
			Object [] values  = new Object[] {BnsprType.NUMBER, trxNo};
			
			GMMap results = DALUtil.callOracleRefCursorFunction(func, listName, values);
			
			fillUygunlukTesti(results, oMap);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static GMMap getUygunlukTestiMusteri(BigDecimal musteriNo) {
		try {
			GMMap oMap = new GMMap();
			
			String func = "{? = call PKG_TRN9963.Get_Uygunluk_Testi_Musteri(?)}";
			String listName = "RESULTS";
			Object [] values  = new Object[] {BnsprType.NUMBER, musteriNo};
			
			GMMap results = DALUtil.callOracleRefCursorFunction(func, listName, values);
			
			fillUygunlukTesti(results, oMap);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static HashMap<String, Object> createCevap(String kod, int skor, String deger, String seciliMi) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("KOD", kod);
		map.put("SKOR", skor);
		map.put("NAME", deger);
		map.put("VALUE", kod);
		map.put("SELECTED", seciliMi);//"1" ise secilidir 
		return map;
	}
	
}
