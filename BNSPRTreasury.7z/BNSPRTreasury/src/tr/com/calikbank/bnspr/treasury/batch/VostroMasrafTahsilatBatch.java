package tr.com.calikbank.bnspr.treasury.batch;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class VostroMasrafTahsilatBatch {

	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	private static Logger logger = Logger.getLogger(VostroMasrafTahsilatBatch.class);

	@GraymoundService("BNSPR_BATCH_VOSTRO_MASRAF_TAHSILAT_MAIL")
	public static GMMap vostroMasrafTahsilatMail(GMMap iMap) {
		try {
			logger.info("BNSPR_BATCH_VOSTRO_MASRAF_TAHSILAT_MAIL ba�lad�");
			String vostroDosyaAdi = "VostroMasrafTahsilat";
			GMMap oMap = new GMMap();
			GMMap vostroMap = new GMMap();
			GMMap vostroInMap = new GMMap();
			GMMap vostroOutMap = new GMMap();
			byte[] vostroBytes = null;

			Date banka_tarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH");
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			vostroDosyaAdi = vostroDosyaAdi + "_" + df.format(banka_tarih) + "_";

			Object[] inputs = new Object[] { BnsprType.DATE, banka_tarih };
			vostroMap = DALUtil.callOracleRefCursorFunction("{?=call PKG_HAZINE.VostroMasrafTahsilatListe(?)}", "TABLE_DATA", inputs);

			if (vostroMap.size() > 0) {

				logger.info("BNSPR_BATCH_VOSTRO_MASRAF_TAHSILAT_MAIL " + vostroMap.size() + " kay�t var");

				LinkedHashMap<String, String[]> vostroHeaders = new LinkedHashMap<String, String[]>();

				vostroHeaders.put("DURUM", new String[] { "DURUM" });
				vostroHeaders.put("TX_NO", new String[] { "TX_NO" });
				vostroHeaders.put("SIRA_NO", new String[] { "SIRA_NO" });
				vostroHeaders.put("ISLEM_TIPI", new String[] { "ISLEM_TIPI" });
				vostroHeaders.put("MUSTERI_NO", new String[] { "MUSTERI_NO" });
				vostroHeaders.put("UNVAN", new String[] { "UNVAN" });
				vostroHeaders.put("HESAP_NO", new String[] { "HESAP_NO" });
				vostroHeaders.put("DK_HESAP_NO", new String[] { "DK_HESAP_NO" });
				vostroHeaders.put("MASRAF_DOVIZ", new String[] { "MASRAF_DOVIZ" });
				vostroHeaders.put("MASRAF_TUTAR", new String[] { "MASRAF_TUTAR", "getBigDecimal;Number" });
				vostroHeaders.put("BSMV", new String[] { "BSMV", "getBigDecimal;Number" });
				vostroHeaders.put("ISLEM_TARIHI", new String[] { "ISLEM_TARIHI", "getDate;Date" });
				vostroHeaders.put("ISLEM_DOVIZ", new String[] { "ISLEM_DOVIZ" });
				vostroHeaders.put("FIS_NO", new String[] { "FIS_NO" });
				vostroHeaders.put("FIS_TARIH", new String[] { "FIS_TARIH", "getDate;Date" });
				vostroHeaders.put("ACIKLAMA", new String[] { "ACIKLAMA" });
				vostroHeaders.put("KISA_ISIM", new String[] { "KISA_ISIM" });
				vostroHeaders.put("UYRUK_KOD", new String[] { "UYRUK_KOD" });
				vostroHeaders.put("PORTFOY_KOD", new String[] { "PORTFOY_KOD" });
				vostroHeaders.put("BIC_KOD", new String[] { "BIC_KOD" });
				

				vostroInMap.put("TABLE_DATA", vostroMap.get("TABLE_DATA"));
				vostroInMap.put("HEADERS", vostroHeaders);
				vostroInMap.put("FILE_NAME", vostroDosyaAdi);
				vostroInMap.put("CHANGE_PAGE_DIRECTION", false);

				vostroOutMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", vostroInMap));
				vostroDosyaAdi = vostroDosyaAdi + "1.xls";
				vostroBytes = FileUtil.readFileToByteArray(ROOT + File.separator + "files" + File.separator + vostroDosyaAdi);
			}

			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", "akustik@aktifbank.com.tr");
			GMMap xMap = new GMMap();
			xMap.put("PARAMETRE", "VOSTRO_MASRAF_TAHSILAT_MAIL");
			servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
			servisMap.put("IS_BODY_HTML", "H");

			String mailSubject = df.format(banka_tarih) + " tarihli vostro masraf tahsilat� dosyas�";

			if (vostroMap.size() > 0) {
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", vostroDosyaAdi);
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", vostroBytes);
			}
			servisMap.put("MAIL_SUBJECT", mailSubject);
			servisMap.put("MAIL_BODY", mailSubject + " ektedir.");

			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);

			logger.info("BNSPR_BATCH_VOSTRO_MASRAF_TAHSILAT_MAIL bitti");
			return oMap;
		}
		catch (Exception e) {
			logger.info("BNSPR_BATCH_VOSTRO_MASRAF_TAHSILAT_MAIL hata ald�");
			logger.info(e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
