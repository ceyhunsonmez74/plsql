package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznSwiftOnayListTx;
import tr.com.aktifbank.bnspr.dao.HznSwiftOnayListTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1323Services {
    
    
    @GraymoundService("BNSPR_TRN1323_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
             String tableName = "TBL_MUSTERI";
             Session session = DAOSession.getSession("BNSPRDal");
            
             List<?> satirBilgileri = (List<?>) iMap.get(tableName);
             for(int i=0;i<satirBilgileri.size()-1;i++){
                 if(iMap.getBigDecimal(tableName,i,"MUSTERI_NO")==null){
                     GMMap myMap = new GMMap ();
                     myMap.put("MESSAGE_NO", new BigDecimal(4262));
                     throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
               
                 }
                 
                 for(int j=i+1;j<satirBilgileri.size();j++){
                    
                     if(iMap.getBigDecimal(tableName,j,"MUSTERI_NO")==null){
                         GMMap myMap = new GMMap ();
                         myMap.put("MESSAGE_NO", new BigDecimal(4262));
                         throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
                   
                     }
                    if((iMap.getBigDecimal(tableName,i,"MUSTERI_NO").equals(iMap.getBigDecimal(tableName,j,"MUSTERI_NO")))){
                         
                        GMMap myMap = new GMMap ();
                        myMap.put("MESSAGE_NO", new BigDecimal(4261));
                        myMap.put("P1" , iMap.getBigDecimal(tableName,i,"MUSTERI_NO"));
                        throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
                     }
                     
                 }
             }
             
             List<?> strBilgileri = (List<?>) iMap.get(tableName);
             for(int i=0;i<strBilgileri.size();i++){
                 HznSwiftOnayListTx swiftOnayTx;
                 HznSwiftOnayListTxId swiftOnayTxId;        
                 swiftOnayTx = new HznSwiftOnayListTx();
                 swiftOnayTxId = new HznSwiftOnayListTxId();
                 swiftOnayTxId .setTxNo(iMap.getBigDecimal("TRX_NO"));                
                 swiftOnayTxId.setMusteriNo(iMap.getBigDecimal(tableName , i , "MUSTERI_NO"));
                 swiftOnayTx.setId(swiftOnayTxId);
                 session.saveOrUpdate(swiftOnayTx);
                 session.flush();
                 
             }
                iMap.put("TRX_NAME","1323");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } 
     }
 
    @GraymoundService("BNSPR_TRN1323_GET_VIEW_INFO")
    public static Map<?, ?> getViewInfo(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet =null;
        
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{? = call PKG_TRN1323.GET_VIEW_INFO(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName="TBL_MUSTERI";
            int row =0;
            while(rSet.next()){
                oMap.put(tableName,row,"MUSTERI_NO", rSet.getBigDecimal("musteri_no"));
                oMap.put(tableName,row,"UNVAN",  LovHelper.diLov( rSet.getBigDecimal("musteri_no") , "1323/LOV_MUSTERI_NO" , "UNVAN"));                
                row++;
               }
            
                 
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return  oMap;
     }
 
    @GraymoundService("BNSPR_TRN1323_GET_INFO")
    public static Map<?, ?> getInfo(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet =null;
        
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{? = call PKG_TRN1323.GET_INFO}");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName="TBL_MUSTERI";
            int row =0;
            while(rSet.next()){
                oMap.put(tableName,row,"MUSTERI_NO", rSet.getBigDecimal("musteri_no"));
                oMap.put(tableName,row,"UNVAN",  LovHelper.diLov( rSet.getBigDecimal("musteri_no") , "1323/LOV_MUSTERI_NO" , "UNVAN"));                
                row++;
               }
            
                 
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return  oMap;
     }
    
    
}
