package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinAlinandepoTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3613Services {

	
	@GraymoundService("BNSPR_TRN3613_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3613.Hzn_bilgiaktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3613_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinAlinandepoTx hznAltinAlinandepoTx = (HznAltinAlinandepoTx)session.get(HznAltinAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznAltinAlinandepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinAlinandepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinAlinandepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinAlinandepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinAlinandepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinAlinandepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinAlinandepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinAlinandepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinAlinandepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinAlinandepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinAlinandepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinAlinandepoTx.getDovizKodu());
			oMap.put("TUTAR", hznAltinAlinandepoTx.getNetTutar());
			oMap.put("TUTAR", hznAltinAlinandepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinAlinandepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinAlinandepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinAlinandepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinAlinandepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinAlinandepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznAltinAlinandepoTx.getVadeSonuFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAltinAlinandepoTx.getVadeIslemBilgisi());
			oMap.put("YENILENENTUTAR", hznAltinAlinandepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznAltinAlinandepoTx.getEkTutar());
			oMap.put("YILFAIZTOPLAMI", hznAltinAlinandepoTx.getGecenYilFaizToplami());
			oMap.put("YENILENENREFERANS", hznAltinAlinandepoTx.getYenilenenReferans());
			if(hznAltinAlinandepoTx.getVadeTarihindeKapama() != null)
				if(hznAltinAlinandepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_POZ", hznAltinAlinandepoTx.getBirikmisFaizPoz());
			
			oMap.put("FAIZ_ORANI", hznAltinAlinandepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getGirisHesapNo(),hznAltinAlinandepoTx.getDovizKodu(),
			        hznAltinAlinandepoTx.getGirisHesapTuru(), hznAltinAlinandepoTx.getBankaMusteriNo(), hznAltinAlinandepoTx.getGirisHesapTuru(), 
					hznAltinAlinandepoTx.getGirisHesapTuru(), "3613/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getCikisHesapNo(),hznAltinAlinandepoTx.getDovizKodu(),
			        hznAltinAlinandepoTx.getCikisHesapTuru(), hznAltinAlinandepoTx.getBankaMusteriNo(), hznAltinAlinandepoTx.getCikisHesapTuru(), 
					hznAltinAlinandepoTx.getCikisHesapTuru(), "3613/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getBankaMusteriNo(), "3613/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinAlinandepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinAlinandepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinAlinandepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinAlinandepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("ANAPARA_ODEME_SEKLI", hznAltinAlinandepoTx.getAnaparaOdemeSekli());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAltinAlinandepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_ENDEKS_KODU", hznAltinAlinandepoTx.getFaizEndeksKodu());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAltinAlinandepoTx.getFaizHesaplanacakTutar());
			oMap.put("SAFLIK_DERECESI",hznAltinAlinandepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI",hznAltinAlinandepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI",hznAltinAlinandepoTx.getKomisyonTutari());
			oMap.put("STOK_NO",hznAltinAlinandepoTx.getStokNo());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN3613_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinAlinandepoTx hznAltinAlinandepoTx = (HznAltinAlinandepoTx)session.get(HznAltinAlinandepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAltinAlinandepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinAlinandepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinAlinandepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinAlinandepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinAlinandepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinAlinandepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinAlinandepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinAlinandepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinAlinandepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinAlinandepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinAlinandepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinAlinandepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinAlinandepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinAlinandepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinAlinandepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinAlinandepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinAlinandepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinAlinandepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinAlinandepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznAltinAlinandepoTx.getVadeSonuFaizTutari());
			oMap.put("ANAPARA_ODEME_SEKLI", hznAltinAlinandepoTx.getAnaparaOdemeSekli());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAltinAlinandepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_ENDEKS_KODU", hznAltinAlinandepoTx.getFaizEndeksKodu());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAltinAlinandepoTx.getFaizHesaplanacakTutar());
			
			oMap.put("VADE_ISLEM_BILGISI", hznAltinAlinandepoTx.getVadeIslemBilgisi());
			oMap.put("YENILENENTUTAR", hznAltinAlinandepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznAltinAlinandepoTx.getEkTutar());
			oMap.put("YILFAIZTOPLAMI", hznAltinAlinandepoTx.getGecenYilFaizToplami());
			oMap.put("REFERANSYENI", hznAltinAlinandepoTx.getReferansYeni());
			oMap.put("STOK_NO", hznAltinAlinandepoTx.getStokNo());
			oMap.put("SAFLIK_DERECESI", hznAltinAlinandepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI", hznAltinAlinandepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI", hznAltinAlinandepoTx.getKomisyonTutari());
			
			if(hznAltinAlinandepoTx.getVadeTarihindeKapama() != null)
				if(hznAltinAlinandepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_POZ", hznAltinAlinandepoTx.getBirikmisFaizPoz());
			
			oMap.put("FAIZ_ORANI", hznAltinAlinandepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getGirisHesapNo(),hznAltinAlinandepoTx.getDovizKodu(),
			        hznAltinAlinandepoTx.getGirisHesapTuru(), hznAltinAlinandepoTx.getBankaMusteriNo(), hznAltinAlinandepoTx.getGirisHesapTuru(),
			        hznAltinAlinandepoTx.getGirisHesapTuru(), "3613/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getCikisHesapNo(),hznAltinAlinandepoTx.getDovizKodu(),
			        hznAltinAlinandepoTx.getCikisHesapTuru(), hznAltinAlinandepoTx.getBankaMusteriNo(), hznAltinAlinandepoTx.getCikisHesapTuru(), 
					hznAltinAlinandepoTx.getCikisHesapTuru(), "3613/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getBankaMusteriNo(), "3613/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinAlinandepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinAlinandepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinAlinandepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinAlinandepoTx.getCikisMuhabirMusteriNo());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3613_SAVE")
    public static Map<?, ?> save(GMMap iMap){
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinAlinandepoTx hznAltinAlinandepoTx = (HznAltinAlinandepoTx)session.get(HznAltinAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAltinAlinandepoTx == null) {
			    hznAltinAlinandepoTx = new HznAltinAlinandepoTx();
			}
			
			hznAltinAlinandepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAltinAlinandepoTx.setModulTurKod("HAZINE");
			hznAltinAlinandepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAltinAlinandepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAltinAlinandepoTx.setReferans(iMap.getString("REFERANS"));
			hznAltinAlinandepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznAltinAlinandepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAltinAlinandepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAltinAlinandepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAltinAlinandepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAltinAlinandepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAltinAlinandepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAltinAlinandepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAltinAlinandepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAltinAlinandepoTx.setNetTutar(iMap.getBigDecimal("TUTAR"));
			hznAltinAlinandepoTx.setBrutTutar(iMap.getBigDecimal("TUTAR"));
			hznAltinAlinandepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAltinAlinandepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAltinAlinandepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAltinAlinandepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAltinAlinandepoTx.setVadeSonuFaizTutari(iMap.getBigDecimal("VADE_SONU_FAIZ_TUTARI"));
			hznAltinAlinandepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAltinAlinandepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAltinAlinandepoTx.setReferansYeni(iMap.getString("REFERANS_YENI"));
			hznAltinAlinandepoTx.setYenilenenTutar(iMap.getBigDecimal("YENILENEN_TUTAR"));
			if(iMap.getString("VADE_TARIHINDE_KAPAMA").toString().equals("false"))
			    hznAltinAlinandepoTx.setVadeTarihindeKapama("H");
			else
			    hznAltinAlinandepoTx.setVadeTarihindeKapama("E");
			hznAltinAlinandepoTx.setGecenYilFaizToplami(iMap.getBigDecimal("GECEN_YIL_FAIZ_TOPLAMI"));
			hznAltinAlinandepoTx.setBirikmisFaizPoz(iMap.getBigDecimal("BIRIKMIS_FAIZ_POZ"));
			hznAltinAlinandepoTx.setEkTutar(iMap.getBigDecimal("EK_TUTAR"));
			hznAltinAlinandepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznAltinAlinandepoTx.setStokNo(iMap.getString("STOK_NO"));
			hznAltinAlinandepoTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
			hznAltinAlinandepoTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
			hznAltinAlinandepoTx.setSaflikDerecesi(iMap.getBigDecimal("SAFLIK_DERECESI"));
			
			
			session.saveOrUpdate(hznAltinAlinandepoTx);
			session.flush();
			 
			iMap.put("TRX_NAME", "3613");           
	        return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
	        
	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}

}
