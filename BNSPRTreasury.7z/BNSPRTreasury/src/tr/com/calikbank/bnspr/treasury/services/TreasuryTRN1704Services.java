package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MkkRehinTeminat;
import tr.com.aktifbank.bnspr.dao.MkkRehinTeminatTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1704Services {
    @GraymoundService("BNSPR_TRN1704_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        Session session = DAOSession.getSession("BNSPRDal");
        MkkRehinTeminat rt = new MkkRehinTeminat();
        MkkRehinTeminatTx rtx = new MkkRehinTeminatTx();
        String tableName = "TABLE_RT";
        BigDecimal txNo = iMap.getBigDecimal("TX_NO");
        
        List<?> satirBilgileri = (List<?>) iMap.get(tableName);
        for (int i = 0; i < satirBilgileri.size(); i++){
            if (iMap.getBoolean(tableName , i , "SEC") == true){
                
                rt = (MkkRehinTeminat) session.get(MkkRehinTeminat.class , iMap.getBigDecimal(tableName , i , "RT_ID"));
                rtx = MkkRehinTeminatBatchService.createNewRTtxPojo(rt);
                rtx.setTxNo(txNo);
                rtx.setDurum("T"); // Ba�ar�l� Tamamland�
                session.save(rtx);
            }
        }
        
        session.flush();
        iMap.clear();
        iMap.put("TRX_NAME" , "1704");
        iMap.put("TRX_NO" , txNo);
        oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));

        return oMap;        
    }
    
    @GraymoundService("BNSPR_TRN1704_GET_DATA")
    public static GMMap getData(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            String tableName = "TABLE_RT";
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1704.GET_RT_RECORDS_SCR(?,?,?)}");
            stmt.registerOutParameter(1 , -10);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(3 , iMap.getString("DURUM"));
            if (iMap.getDate("TARIH") != null)
                stmt.setDate(4 , new java.sql.Date(iMap.getDate("TARIH").getTime()));
            else stmt.setDate(4 , null);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

            oMap.putAll(DALUtil.rSetResults(rSet , tableName));
        }
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;        
    }
    
    @GraymoundService("BNSPR_TRN1704_GET_RT_RESPONSE")
    public static GMMap getRtResponse(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            BigDecimal txNo = saveRtTx(iMap);
            
            iMap.clear();
            iMap.put("TRX_NAME" , "1704");
            iMap.put("TRX_NO" , txNo);
            oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
            
            oMap.put("RESPONSE_CODE" , "0000");
            oMap.put("RESPONSE_DESC" , "");
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
     
        return oMap;        
    }
    
    private static BigDecimal saveRtTx(GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");

        MkkRehinTeminatTx rtTx = new MkkRehinTeminatTx();

        BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , iMap).getBigDecimal("TRX_NO"); 
        rtTx.setTxNo(txNo);
        if ("OK".equals(iMap.getString("InstStat"))){
            rtTx.setDurum("T"); //Tamamland�
        }
        else{
            rtTx.setDurum("H");
        }
        if (iMap.getString("SenderReference") != null && iMap.getString("SenderReference").length()>3){
            rtTx.setRtId(new BigDecimal(iMap.getString("SenderReference").substring(3)));
        }
        rtTx.setSenderMember(iMap.getString("ReceiverMember"));
        rtTx.setSenderReference(iMap.getString("SenderReference"));
        rtTx.setPlSendMemberCode(iMap.getString("SendMemberCode"));
        rtTx.setPlSendAccNo(iMap.getString("SendAccNo"));
        rtTx.setPlSendSubAccNo(iMap.getString("SendSubAccNo"));
        rtTx.setPlRcvMemberCode(iMap.getString("RcvMemberCode"));
        rtTx.setPlRcvAccNo(iMap.getString("RcvAccNo"));
        rtTx.setPlRcvSubAccNo(iMap.getString("RcvSubAccNo"));
        rtTx.setMic(iMap.getString("Mic"));
        rtTx.setIsin(iMap.getString("Isin"));
        rtTx.setSecAddDefCode(iMap.getString("SecAddDefCode"));
        if(iMap.getString("Amount") != null){
            rtTx.setAmount(new BigDecimal(iMap.getString("Amount")));
        }
        
        session.save(rtTx);
        session.flush();    
        
        return txNo;
    }

    @GraymoundService("BNSPR_TRN1704_TEKRAR_GONDER")
    public static GMMap tekrarGonder(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            
            MkkRehinTeminat rtOld = (MkkRehinTeminat)session.get(MkkRehinTeminat.class , iMap.getBigDecimal("RT_ID"));
            
            if(rtOld != null){
                Criteria criteria = session.createCriteria(MkkRehinTeminat.class)
                                            .add(Restrictions.eq("plSendAccNo" , rtOld.getPlSendAccNo())) //M��teri no
                                            .add(Restrictions.eq("processType" , rtOld.getProcessType())) //i�lem tipi, (G)iri�/(C)�k��
                                            .add(Restrictions.eq("teminatNo" , rtOld.getTeminatNo())) //teminat no
                                            .add(Restrictions.eq("teminatDetayNo" , rtOld.getTeminatDetayNo())) //teminat detay no
                                            .add(Restrictions.ne("durum" , "H"))  //durum:Hatal�
                                            .add(Restrictions.ne("durum" , "I")); //durum:Iptal
                List<?> list = criteria.list();
                if (list != null && list.size()>0){
                    return throwGMBusssinessException("Bu i�lem i�in bekleyen veya tamamlanm�� MKK Rehin Teminat kayd� bulunmaktad�r, teminat_no:" + rtOld.getTeminatNo() + " , teminat detay no:"+ rtOld.getTeminatDetayNo());
                }
                
                conn = DALUtil.getGMConnection();
    
                //Yeni rehin teminat kayd� ekleyelim
                stmt = conn.prepareCall("{call PKG_MKK.RehinTeminatInsert(?,?,?,?)}");
                stmt.setBigDecimal(1, rtOld.getRefTxNo());
                stmt.setBigDecimal(2, rtOld.getTeminatNo());
                stmt.setBigDecimal(3, rtOld.getTeminatDetayNo());
                stmt.setString(4, rtOld.getProcessType()); //i�lem tipi, (G)iri�/(C)�k��
                stmt.execute();
                
                oMap.put("MESSAGE" , rtOld.getTeminatNo() + " teminat nolu i�lem i�in MKK Rehin Teminat i�i tekrar tetiklenecektir.");
            }
            else{
                return throwGMBusssinessException("Kay�t bulunamad�");
            }
        }
        catch (Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1704_MKK_SORGULA")
    public static GMMap mkkSorgula(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            if (iMap.getBigDecimal("RT_ID") == null){
                return throwGMBusssinessException("MKK'dan sorgulamak istedi�iniz kayd� se�iniz.");
            }
            
            MkkRehinTeminat rtOld = (MkkRehinTeminat)session.get(MkkRehinTeminat.class , iMap.getBigDecimal("RT_ID"));
            GMMap xMap = new GMMap();
            xMap.put("SENDER_REFERENCE" , rtOld.getSenderReference());
            xMap.put("SERVICE_NAME" , "EnterExitPl");
            
            oMap = GMServiceExecuter.call("BNSPR_MKK_MESSAGE_QUERY_SERVICE", xMap);
            
            oMap.put("MESSAGE" , iMap.getBigDecimal("RT_ID") + " nolu kay�t MKK'dan sorgulan�p durumu g�ncellenmi�tir");
        }
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }

    public static GMMap throwGMBusssinessException(String string) {             
        GMMap exMap = new GMMap();
        exMap.put("P1", string);
        exMap.put("HATA_NO", "660");
        return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
    }
}
