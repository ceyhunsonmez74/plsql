package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznMuhabirLimitTx;
import tr.com.calikbank.bnspr.dao.HznMuhabirLimitTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


/**
 * @author obss2
 *
 */
public class TreasuryTRN1303Services {
	
	@GraymoundService("BNSPR_TRN1303_GET_TRANSACTION_NO")
	public static GMMap getTransactionNo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1303.muhabir_arama(?) }");
			
			stmt.registerOutParameter(1, Types.FLOAT);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1303_GET_HZN_MUHABIR")
	public static GMMap getRecords(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String tableName = "HZN_MUHBNK_LIMIT_DTYISL";
			Session session = DAOSession.getSession("BNSPRDal");
			
			Criteria criteria = session.createCriteria(HznMuhabirLimitTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));

			if(iMap.getBigDecimal("MUSTERI_NO") != null) {
				criteria.add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO")));
			}

			List<?> recordList = criteria.list();
			

			for (int row = 0; row < recordList.size(); row++){
				HznMuhabirLimitTx hznMuhabirLimitTx = (HznMuhabirLimitTx) recordList.get(row);

				oMap.put(tableName, row, "MUSTERI_NO", hznMuhabirLimitTx.getId().getMusteriNo());
				oMap.put(tableName, row, "LIMIT_DOVIZ", hznMuhabirLimitTx.getLimitDoviz());
				oMap.put(tableName, row, "MONEY_MARKET_LIMIT", hznMuhabirLimitTx.getMoneyMarketLimit());
				oMap.put(tableName, row, "OVERALL_LIMIT", hznMuhabirLimitTx.getOverallLimit());
                oMap.put(tableName, row, "SETTLEMENT_LIMIT", hznMuhabirLimitTx.getSettlementLimit());
                oMap.put(tableName, row, "TUREV_LIMIT", hznMuhabirLimitTx.getTurevLimit());
                oMap.put(tableName, row, "REVIZYON_TARIHI", hznMuhabirLimitTx.getRevizyonTarihi());
				/*oMap.put(tableName, row, "VADELI_ISLEM_LIMIT", hznMuhabirLimitTx.getVadeliIslemLimit());*/
				oMap.put(tableName, row, "ANA_BIC_KODU_BANKA", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_BANKA"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SEHIR", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_SEHIR"));
				oMap.put(tableName, row, "ANA_BIC_KODU_ULKE", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_ULKE"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SUBE", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_SUBE"));
				oMap.put(tableName, row, "ANA_MUHABIR_ADI",
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "UNVAN"));
				
				oMap.put(tableName, row, "VADE_GUN", hznMuhabirLimitTx.getVadeGun());
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1303_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		
		try {
			Session session 	= DAOSession.getSession("BNSPRDal");
			String tableName 	= "HZN_MUHBNK_LIMIT_DTYISL";
			
			List<?> recordList = (List<?>)iMap.get(tableName);
			
			for (int row = 0;row<recordList.size();row++) {
				
				HznMuhabirLimitTxId id = new HznMuhabirLimitTxId();
				id.setMusteriNo(iMap.getBigDecimal(tableName, row, "MUSTERI_NO"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				HznMuhabirLimitTx hznMuhabirLimitTx = (HznMuhabirLimitTx)session.get(HznMuhabirLimitTx.class, id);
				if(hznMuhabirLimitTx == null) {
					hznMuhabirLimitTx = new HznMuhabirLimitTx();
				}
				
				hznMuhabirLimitTx.setId(id);
				hznMuhabirLimitTx.setLimitDoviz(iMap.getString(tableName, row, "LIMIT_DOVIZ"));
				hznMuhabirLimitTx.setMoneyMarketLimit(iMap.getBigDecimal(tableName, row, "MONEY_MARKET_LIMIT"));
				hznMuhabirLimitTx.setOverallLimit(iMap.getBigDecimal(tableName, row, "OVERALL_LIMIT"));
                hznMuhabirLimitTx.setSettlementLimit(iMap.getBigDecimal(tableName, row, "SETTLEMENT_LIMIT"));
                hznMuhabirLimitTx.setTurevLimit(iMap.getBigDecimal(tableName, row, "TUREV_LIMIT"));
				/*hznMuhabirLimitTx.setVadeliIslemLimit(iMap.getBigDecimal(tableName, row, "VADELI_ISLEM_LIMIT"));*/
				hznMuhabirLimitTx.setVadeGun(iMap.getBigDecimal(tableName, row, "VADE_GUN"));
				hznMuhabirLimitTx.setRevizyonTarihi(iMap.getDate(tableName, row, "REVIZYON_TARIHI"));
				session.saveOrUpdate(hznMuhabirLimitTx);

			}
			session.flush();
			
			iMap.put("TRX_NAME", "1303");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1303_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Criteria criteria = session.createCriteria(HznMuhabirLimitTx.class)
									.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));

			if(iMap.getBigDecimal("MUSTERI_NO") != null) {
				criteria.add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO")));
			}
			
			List<?> recordList = criteria.list();
		
			String tableName = "HZN_MUHBNK_LIMIT_DTYISL";
			int row = 0;
			
			Iterator<?> iterator = recordList.iterator();
			while ( iterator.hasNext()) {
				HznMuhabirLimitTx hznMuhabirLimitTx= (HznMuhabirLimitTx) iterator.next();
				
				oMap.put(tableName, row, "LIMIT_DOVIZ", hznMuhabirLimitTx.getLimitDoviz());
				oMap.put(tableName, row, "MONEY_MARKET_LIMIT", hznMuhabirLimitTx.getMoneyMarketLimit());
				oMap.put(tableName, row, "OVERALL_LIMIT", hznMuhabirLimitTx.getOverallLimit());
				oMap.put(tableName, row, "SETTLEMENT_LIMIT", hznMuhabirLimitTx.getSettlementLimit());
                oMap.put(tableName, row, "VEDELI_ISLEM_LIMIT", hznMuhabirLimitTx.getVadeliIslemLimit());
                oMap.put(tableName, row, "TUREV_LIMIT", hznMuhabirLimitTx.getTurevLimit());
				oMap.put(tableName, row, "MUSTERI_NO", hznMuhabirLimitTx.getId().getMusteriNo());
				oMap.put(tableName, row, "REVIZYON_TARIHI", hznMuhabirLimitTx.getRevizyonTarihi());
				oMap.put(tableName, row, "ANA_BIC_KODU_BANKA", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_BANKA"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SEHIR", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_SEHIR"));
				oMap.put(tableName, row, "ANA_BIC_KODU_ULKE", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_ULKE"));
				oMap.put(tableName, row, "ANA_BIC_KODU_SUBE", 
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "BIC_SUBE"));
				oMap.put(tableName, row, "ANA_MUHABIR_ADI",
						LovHelper.diLov(hznMuhabirLimitTx.getId().getMusteriNo(), "1303/LOV_ANA_MUHABIR", "UNVAN"));
				oMap.put(tableName, row, "VADE_GUN", hznMuhabirLimitTx.getVadeGun());
				row++;
			}
		} catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
}
