package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MkkHesapAcilis;
import tr.com.aktifbank.bnspr.dao.MkkHesapAcilisTx;
import tr.com.aktifbank.bnspr.dao.MkkHesapAcilisTxId;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirme;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeTx;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeTxId;
import tr.com.aktifbank.bnspr.dao.MkkResponse;
import tr.com.aktifbank.integration.mkk.MkkClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.mkk.ws.schemas.account.AccountAsyncServiceResultResponseType;
import tr.com.mkk.ws.schemas.account.AccountAsyncServiceResultType;
import tr.com.mkk.ws.schemas.account.AccountMaxAsyncServiceOrderIdResponseType;
import tr.com.mkk.ws.schemas.account.AccountMaxAsyncServiceOrderIdResultType;
import tr.com.mkk.ws.schemas.account.AccountNextAsyncServiceResultResponseType;
import tr.com.mkk.ws.schemas.account.AccountNextAsyncServiceResultType;
import tr.com.mkk.ws.schemas.account.AccountPendingAsyncServiceResultCount;
import tr.com.mkk.ws.schemas.account.AccountPendingAsyncServiceResultCountResponseType;
import tr.com.mkk.ws.schemas.account.AsyncServiceResultType;
import tr.com.mkk.ws.schemas.account.MaxAsyncServiceOrderIdResultType;
import tr.com.mkk.ws.schemas.account.NewAccountType;
import tr.com.mkk.ws.schemas.account.NextAsyncServiceResultType;
import tr.com.mkk.ws.schemas.account.OADerivativeType;
import tr.com.mkk.ws.schemas.account.OpenAccountType;
import tr.com.mkk.ws.schemas.account.PendingAsyncServiceResultCountType;
import tr.com.mkk.ws.schemas.investor.NotifyChangeOfQualificationStatType;
import tr.com.mkk.ws.schemas.matchidentities.FailedParticipantType;
import tr.com.mkk.ws.schemas.matchidentities.MatchIdentitiesResultType;
import tr.com.mkk.ws.schemas.matchidentities.MatchIdentitiesType;
import tr.com.mkk.ws.schemas.matchidentities.MatchResultType;
import tr.com.mkk.ws.schemas.matchidentities.MatchType;
import tr.com.mkk.ws.schemas.matchidentities.ParticipantType;
import tr.com.mkk.ws.schemas.matchidentities.ParticipantsType;
import tr.com.mkk.ws.schemas.mkkresponse.MkkResponseType;
import tr.com.mkk.ws.schemas.mkkresponse.ResponseType;
import tr.com.mkk.ws.schemas.types_1_0.AccountAsyncServiceNameType;
import tr.com.mkk.ws.schemas.types_1_0.AccountJointTypeType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantDomesticFundType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantDomesticLegalType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantDomesticRealType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantForeignFundType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantForeignLegalType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantForeignOtherType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantForeignRealType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantIdentityType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantOtherType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantTrustType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantType;
import tr.com.mkk.ws.schemas.types_1_0.AccountParticipantsType;
import tr.com.mkk.ws.schemas.types_1_0.AccountProcessStatusType;
import tr.com.mkk.ws.schemas.types_1_0.AccountReasonCodeType;
import tr.com.mkk.ws.schemas.types_1_0.AddressType;
import tr.com.mkk.ws.schemas.types_1_0.AddressTypeType;
import tr.com.mkk.ws.schemas.types_1_0.DomesticAddressType;
import tr.com.mkk.ws.schemas.types_1_0.ForeignAddressType;
import tr.com.mkk.ws.schemas.types_1_0.GenderType;
import tr.com.mkk.ws.schemas.types_1_0.RequestHeaderType;
import tr.com.mkk.ws.schemas.types_1_0.ResponseHeaderType;
import tr.com.mkk.ws.schemas.types_1_0.TaxpayerType;
import tr.com.mkk.ws.schemas.types_1_0.YesNoType;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class MkkHaKeBatchService {
	
    private static final Logger logger = Logger.getLogger(MkkHaKeBatchService.class);
    
	private enum Services {
		BNSPR_MKK_ACCOUNT_ASYNC_RESULT_SERVICE("AR"), 
		BNSPR_MKK_ACCOUNT_NEXT_ASYNC_RESULT_SERVICE("ANR"), 
		BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE("AC"), 
		BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE("AMO");
		private final String stringValue;

		Services(final String s) {
			stringValue = s;
		}

		public String toString() {
			return stringValue;
		}
		
		public String getKodAdi() {
			return "MKK_" + stringValue + "_ID";
		}
	}

    @GraymoundService("BNSPR_MKK_HA_BATCH_SERVICE")
    public static GMMap mkkCallHaServices(GMMap iMap) {
          GMMap oMap = new GMMap();
          GMMap xMap = new GMMap();
          xMap.put("BATCH_NAME" , "MKK_HA_BATCH_RUNNING_FLAG");
          String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
          boolean iAmRunning = false;
          try {
              if("E".equals(runningFlag)){
                  logger.info("[BNSPR_MKK_HA_BATCH_SERVICE] batch is already running, can't run parallel...");
                  oMap.put("HATA_NO", new BigDecimal(660));
                  oMap.put("P1", "Devam eden MKK Hesap A��l�� batch i�lemi bulunmaktad�r!");
                  return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
              }
              else{
                  xMap = new GMMap();
                  xMap.put("BATCH_NAME" , "MKK_HA_BATCH_RUNNING_FLAG");
                  xMap.put("BATCH_DEGER" , "\"1\"");
                  GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                  logger.info("[BNSPR_MKK_HA_BATCH_SERVICE] MKK_HA_BATCH_RUNNING_FLAG has been set to [1]");
                  iAmRunning = true;
              }
              logger.info("MKK Hesap A��l�� Batch �al��maya ba�lad�:[BNSPR_MKK_HA_BATCH_SERVICE]");
              Session session = DAOSession.getSession("BNSPRDal");
              Criteria criteria = session.createCriteria(MkkHesapAcilis.class).add(Restrictions.eq("durum" , "G")).addOrder(Order.asc("haId"));
              List<?> list = criteria.list();
              for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                  MkkHesapAcilis haGon = (MkkHesapAcilis)iterator.next();
                  logger.info("[BNSPR_MKK_HA_BATCH_SERVICE] g�nderilecek kay�t:" + haGon.getHaId());
                  
                  OpenAccountType openAccount = new OpenAccountType();
                  
                  NewAccountType newAcc = new NewAccountType();
                  newAcc.setMemberCode(haGon.getMemberCode());
                  newAcc.setAccountNumber(haGon.getAccountNumber());
                  if (haGon.getReasonCode() != null){
                      newAcc.setReasonCode(AccountReasonCodeType.fromValue(haGon.getReasonCode()));
                  }
                  if (haGon.getProcessStatus() != null){
                      newAcc.setProcessStatus(AccountProcessStatusType.fromValue(haGon.getProcessStatus()));
                  }
                  newAcc.setClassCode(haGon.getClassCode());
                  if(haGon.getJointType() != null){
                      newAcc.setJointType(AccountJointTypeType.fromValue(haGon.getJointType()));
                  }
                  newAcc.setIban(haGon.getIban());
                  if (haGon.getIsInvestorBlockaged() != null){
                      newAcc.setIsInvestorBlockaged(YesNoType.fromValue(haGon.getIsInvestorBlockaged()));
                  }
                  newAcc.setPortfolioCode(haGon.getPortfolioCode());
                  if(haGon.getVob() != null){
                      newAcc.setDerivative(OADerivativeType.fromValue(haGon.getVob()));
                  }
                  
                  openAccount.setNewAccount(newAcc);
                  
                  RequestHeaderType reqHeader = new RequestHeaderType();
                  reqHeader.setSenderMember(haGon.getSenderMember());
                  reqHeader.setSenderReference(haGon.getSenderReference());

                  openAccount.setRequestHeader(reqHeader);

                  MkkResponseType response = MkkClient.getMkkAccountService().openAccount(openAccount);
                  logger.info("[BNSPR_MKK_HA_BATCH_SERVICE] g�nderildi, ID:" + haGon.getHaId());
                  saveMkkResponse(response);

                  if (response != null){
                      ResponseType responseType = response.getResponse();
                      
                      logger.info("[BNSPR_MKK_HA_BATCH_SERVICE] ID:[" + haGon.getHaId() + "], response code:[" + responseType.getResponseCode() + "], response desc:[" + responseType.getResponseDesc() + "]");
                      
                      MkkHesapAcilisTx hax = createNewHaxPojo(haGon);

                      BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
                      if ("0000".equals(responseType.getResponseCode())){
                          hax.setDurum("A"); //Ba�ar�l� Tamamland�
                      }
                      else{
                          hax.setDurum("H"); //Ba�ar�s�z Hatal�
                      }
                      hax.setResponseCode(responseType.getResponseCode());
                      hax.setResponseDesc(responseType.getResponseDesc());
                      hax.getId().setTxNo(txNo);                        
                      session.save(hax);
                      session.flush();
                      iMap.clear();
                      iMap.put("TRX_NAME" , "1701");
                      iMap.put("TRX_NO" , txNo);
                      oMap =  new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
                  }
              }
          } 
          catch (Exception e) {
              throw ExceptionHandler.convertException(e);
          }
          finally{
              if (iAmRunning){ //Batchi �al��t�ran bensem i�im bitti�inde sonland�rmal�y�m
                  xMap = new GMMap();
                  xMap.put("BATCH_NAME" , "MKK_HA_BATCH_RUNNING_FLAG");
                  xMap.put("BATCH_DEGER" , "\"0\"");
                  GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                  logger.info("[BNSPR_MKK_HA_BATCH_SERVICE] MKK_HA_BATCH_RUNNING_FLAG has been set to [0]");
              }
              logger.info("MKK Hesap A��l�� Batch tamamland�, [BNSPR_MKK_HA_BATCH_SERVICE]");
          }
          return oMap;
    }
 
    @GraymoundService("BNSPR_MKK_KE_BATCH_SERVICE")
    public static GMMap mkkCallKEService(GMMap iMap){
        GMMap oMap = new GMMap();
        GMMap xMap = new GMMap();
        xMap.put("BATCH_NAME" , "MKK_KE_BATCH_RUNNING_FLAG");
        String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
        boolean iAmRunning = false;
        try {
            if("E".equals(runningFlag)){
                logger.info("[BNSPR_MKK_KE_BATCH_SERVICE] batch is already running, can't run parallel...");
                oMap.put("HATA_NO", new BigDecimal(660));
                oMap.put("P1", "Devam eden MKK Kimlik E�le�tirme batch i�lemi bulunmaktad�r!");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
            }
            else{
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_KE_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"1\"");
                GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_KE_BATCH_SERVICE] MKK_KE_BATCH_RUNNING_FLAG has been set to [1]");
                iAmRunning = true;
            }
            logger.info("MKK Kimlik E�le�tirme Batch �al��maya ba�lad�:[BNSPR_MKK_KE_BATCH_SERVICE]");
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("durum" , "G")).addOrder(Order.asc("id.keId")).setProjection(Projections.distinct(Projections.property("id.keId")));
            List<?> idList = criteria.list();
            
            for (int i = 0; i<idList.size(); i++){
                logger.info("[BNSPR_MKK_KE_BATCH_SERVICE] g�nderilecek kay�t:" + idList.get(i));
                criteria = session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("id.keId" , idList.get(i))).addOrder(Order.asc("id.siraNo"));
                List<?> list = criteria.list();
                MatchIdentitiesType matchIdentities = new MatchIdentitiesType();

                MatchType match = new MatchType();
                matchIdentities.setMatch(match);
                
                AccountParticipantsType accPartsType = new AccountParticipantsType();
                match.setParticipants(accPartsType);
                
                RequestHeaderType requestHeader = new RequestHeaderType();
                matchIdentities.setRequestHeader(requestHeader);

                for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                    MkkKimlikEslestirme keGon = (MkkKimlikEslestirme)iterator.next();
    
                    /*****************************************************************************************************/
                    /*  ortak m��teriler i�in alan de�i�medi�inden loop i�inde birden fazla kere set edilmesi sorun olmaz */
                    requestHeader.setSenderMember(keGon.getSenderMember());
                    requestHeader.setSenderReference(keGon.getSenderReference());
                    
                    match.setAccountNumber(keGon.getAccountNumber());
                    match.setMemberCode(keGon.getMemberCode());
                    /*****************************************************************************************************/
                    
                    AccountParticipantType accPartType = new AccountParticipantType();
                    AddressType addressType = new AddressType();
                    if(keGon.getAdressType() != null){
                        addressType.setAddressType(AddressTypeType.fromValue(keGon.getAdressType()));
                    }
                    addressType.setAddress1(keGon.getAddress1());
                    addressType.setAddress2(keGon.getAddress2());
                    addressType.setAddress3(keGon.getAddress3());
                    addressType.setCellTelephoneNumber(keGon.getCellTelNo());
                    addressType.setDistrict(keGon.getDistrict());
                    addressType.setEmailAddress(keGon.getEmail());
                    addressType.setWard(keGon.getWard());
                    if(keGon.getInvestorType().startsWith("YA")){
                        ForeignAddressType forAddr = new ForeignAddressType();
                        forAddr.setCity(keGon.getYabCity());
                        forAddr.setCountryCode(keGon.getYabCountryCode());
                        forAddr.setPostalCode(keGon.getYabPostalCode());
                        forAddr.setRegion(keGon.getYabRegion());
                        addressType.setForeignAddress(forAddr);
                    }
                    else{
                        DomesticAddressType domAddr = new DomesticAddressType();
                        domAddr.setCity(keGon.getYerliCity());
                        domAddr.setPostalCode(keGon.getYerliPostalCode());
                        domAddr.setTownship(keGon.getYerliTownship());
                        addressType.setDomesticAddress(domAddr);
                    }
                    
                    accPartType.setAddress(addressType);
                    accPartType.setCustomerId(keGon.getCustomerId());
                    
                    
                    AccountParticipantIdentityType accPartIdType = new AccountParticipantIdentityType();
                    
                    if(keGon.getInvestorType().equals("YF")){
                        AccountParticipantDomesticFundType dft = new AccountParticipantDomesticFundType();
                        //dft.setSwiftBic(keGon.getYfSwiftBic());
                        dft.setLei(keGon.getYfSwiftBic());
                        dft.setTaxDepartment(keGon.getYfTaxDept());
                        dft.setTaxIdentityNo(keGon.getYfTaxIdNo());
                        dft.setTitle(keGon.getYfTitle());
                        accPartIdType.setDomesticFund(dft);
                    }                
                    else if(keGon.getInvestorType().equals("YT")){
                        AccountParticipantDomesticLegalType dlt = new AccountParticipantDomesticLegalType();
                        //dlt.setSectorCode(keGon.getYtSectorCode());
                        //dlt.setSubSectorCode(keGon.getYtSubsectorCode());
                        dlt.setTaxDepartment(keGon.getYtTaxDept());
                        dlt.setTaxIdentityNo(keGon.getYtTaxIdNo());
                        dlt.setTitle(keGon.getYtTitle());
                        dlt.setTradeRegDate(keGon.getYtTradeRegDate());
                        dlt.setTradeRegDept(keGon.getYtTradeRegDept());
                        dlt.setTradeRegNo(keGon.getYtTradeRegNo());
                        accPartIdType.setDomesticLegal(dlt);
                    }                
                    else if(keGon.getInvestorType().equals("YD")){
                        AccountParticipantOtherType dot = new AccountParticipantOtherType();
                        dot.setTaxDepartment(keGon.getYdTaxDept());
                        dot.setTaxIdentityNo(keGon.getYdTaxIdNo());
                        dot.setTitle(keGon.getYdTitle());
                        dot.setTradeRegDept(keGon.getYdTradeRegDept());
                        dot.setTradeRegNo(keGon.getYdTradeRegNo());
                        accPartIdType.setDomesticOther(dot);
                    }                
                    else if(keGon.getInvestorType().equals("YG")){
                        AccountParticipantDomesticRealType drt = new AccountParticipantDomesticRealType();
                        drt.setBirthDate(keGon.getYgBirthDate());
                        drt.setIdentityNumber(keGon.getYgIdentityNo());
                        drt.setName(keGon.getYgName());
                        drt.setSurname(keGon.getYgSurname());
                        accPartIdType.setDomesticReal(drt);
                    }                
                    else if(keGon.getInvestorType().equals("YAF")){
                        AccountParticipantForeignFundType fft = new AccountParticipantForeignFundType();
                        fft.setCountryCode(keGon.getYafCountryCode());
                        //fft.setSwiftBic(keGon.getYafSwiftBic());
                        fft.setLei(keGon.getYafSwiftBic());
                        fft.setTaxDepartment(keGon.getYafTaxDept());
                        fft.setTaxIdentityNo(keGon.getYafTaxIdNo());
                        fft.setTitle(keGon.getYafTitle());
                        accPartIdType.setForeignFund(fft);
                    }                
                    else if(keGon.getInvestorType().equals("YAT")){
                        AccountParticipantForeignLegalType flt = new AccountParticipantForeignLegalType();
                        flt.setCountryCode(keGon.getYatCountryCode());
                        flt.setSectorCode(keGon.getYatSectorCode());
                        flt.setSubSectorCode(keGon.getYatSubsectorCode());
                        //flt.setSwiftBic(keGon.getYatSwiftBic());
                        flt.setLei(keGon.getYatSwiftBic());
                        flt.setTaxDepartment(keGon.getYatTaxDept());
                        flt.setTaxIdentityNo(keGon.getYatTaxIdNo());
                        flt.setTitle(keGon.getYatTitle());
                        accPartIdType.setForeignLegal(flt);
                    }                
                    else if(keGon.getInvestorType().equals("YAD")){
                        AccountParticipantForeignOtherType fot = new AccountParticipantForeignOtherType();
                        fot.setCountryCode(keGon.getYadCountryCode());
                        fot.setTaxDepartment(keGon.getYadTaxDept());
                        fot.setTaxIdentityNo(keGon.getYadTaxIdNo());
                        fot.setTitle(keGon.getYadTitle());
                        fot.setTradeRegDept(keGon.getYadTradeRegDept());
                        fot.setTradeRegNo(keGon.getYadTradeRegNo());
                        accPartIdType.setForeignOther(fot);
                    }                
                    else if(keGon.getInvestorType().equals("YAG")){
                        AccountParticipantForeignRealType frt = new AccountParticipantForeignRealType();
                        frt.setBirthDate(keGon.getYagBirthDate());
                        frt.setBirthPlace(keGon.getYagBirthPlace());
                        frt.setCountryCode(keGon.getYagCountryCode());
                        frt.setFatherName(keGon.getYagFatherName());
                        frt.setForeignIdentityNo(keGon.getYagForeignIdNo());
                        if(keGon.getYagGender() != null){
                            frt.setGender(GenderType.fromValue(keGon.getYagGender()));
                        }
                        frt.setIdentityNo(keGon.getYagIdentityNo());
                        frt.setMotherName(keGon.getYagMotherName());
                        frt.setName(keGon.getYagName());
                        frt.setSurname(keGon.getYagSurname());
                        frt.setTaxIdentityNo(keGon.getYagTaxIdNo());
                        accPartIdType.setForeignReal(frt);
                    }                
                    else if(keGon.getInvestorType().equals("YO")){
                        AccountParticipantTrustType tt = new AccountParticipantTrustType();
                        //tt.setSectorCode(keGon.getYoSectorCode());
                        //tt.setSubSectorCode(keGon.getYoSubsectorCode());
                        //tt.setSwiftBic(keGon.getYoSwiftBic());
                        tt.setLei(keGon.getYoSwiftBic());
                        tt.setTaxDepartment(keGon.getYoTaxDept());
                        tt.setTaxIdentityNo(keGon.getYoTaxIdNo());
                        tt.setTitle(keGon.getYoTitle());
                        tt.setTradeRegDate(keGon.getYoTradeRegDate());
                        tt.setTradeRegDept(keGon.getYoTradeRegDept());
                        tt.setTradeRegNo(keGon.getYoTradeRegNo());
                        accPartIdType.setTrust(tt);
                    }
                    
                    
                    accPartType.setParticipant(accPartIdType);
                    accPartType.setPartnershipRatio(keGon.getPartnershipRatio());
                    accPartType.setRegistryNumber(keGon.getRegisteryNumber());
                    if(keGon.getTaxPayerType() != null){
                        accPartType.setTaxpayerType(TaxpayerType.fromValue(keGon.getTaxPayerType()));
                    }
                    
                    accPartsType.getAccountParticipant().add(accPartType);
                }
                
                MkkResponseType response = MkkClient.getMkkMatchIdentitiesService().matchIdentities(matchIdentities);
                logger.info("[BNSPR_MKK_KE_BATCH_SERVICE] g�nderildi, ID:" + idList.get(i));
                saveMkkResponse(response);

                if (response != null){
                    ResponseType responseType = response.getResponse();
                    ResponseHeaderType responseHeader = response.getResponseHeader();
                    
                    logger.info("[BNSPR_MKK_KE_BATCH_SERVICE] ID:[" + idList.get(i) + "], response code:[" + responseType.getResponseCode() + "], response desc:[" + responseType.getResponseDesc() + "]");
                    
                    MkkKimlikEslestirme keGonIlk = (MkkKimlikEslestirme)list.get(0);

                    MkkKimlikEslestirmeTx kex = createNewKexPojo(keGonIlk);
                    
                    BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
                    
                    if ("0000".equals(responseType.getResponseCode())){
                        kex.setDurum("A"); //Ba�ar�l� G�nderildi
                    }
                    else{
                        kex.setDurum("H"); //Hatal�
                    }
                    MkkKimlikEslestirmeTxId kexId = new MkkKimlikEslestirmeTxId();
                    kexId.setTxNo(txNo);
                    kexId.setSiraNo(new BigDecimal(1));
                    
                    kex.setId(kexId);
                    kex.setResponseCode(responseType.getResponseCode());
                    kex.setResponseDesc(responseType.getResponseDesc());
                    session.save(kex);
                    session.flush();
                    iMap.clear();
                    iMap.put("TRX_NAME" , "1702");
                    iMap.put("TRX_NO" , txNo);
                    oMap =  new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
                }
            }
            //GMServiceExecuter.executeNT("BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE", iMap);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally{
            if (iAmRunning){ //Batchi �al��t�ran bensem i�im bitti�inde sonland�rmal�y�m
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_KE_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"0\"");
                GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_KE_BATCH_SERVICE] MKK_KE_BATCH_RUNNING_FLAG has been set to [0]");
            }
            logger.info("MKK Kimlik E�le�tirme Batch tamamland�, [BNSPR_MKK_KE_BATCH_SERVICE]");
        }
        return oMap;
        
    }
    
    @GraymoundService("BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE")
	public static GMMap mkkCallResultBatchService(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap xMap = new GMMap();
        xMap.put("BATCH_NAME" , "MKK_KE_RSLT_BATCH_RUNNING_FLAG");
        String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
        boolean iAmRunning = false;
		try {
			if("E".equals(runningFlag)){
                logger.info("[BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE] batch is already running, can't run parallel...");
                oMap.put("HATA_NO", new BigDecimal(660));
                oMap.put("P1", "Devam eden MKK Kimlik E�le�tirme sonu� batch i�lemi bulunmaktad�r!");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
            }
            else{
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_KE_RSLT_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"1\"");
                GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE] MKK_KE_RSLT_BATCH_RUNNING_FLAG has been set to [1]");
                iAmRunning = true;
            }
			logger.info("MKK Account Sonuc Alma Servisi �al��maya ba�lad�:[BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE]");
			for (int i = 0; i < AccountAsyncServiceNameType.values().length; i++) {
				iMap.put("SERVICE_NAME", AccountAsyncServiceNameType.values()[i].value());
				oMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_ACCOUNT_RESULT_SERVICE", iMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			if (iAmRunning){ //Batchi �al��t�ran bensem i�im bitti�inde sonland�rmal�y�m
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_KE_RSLT_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"0\"");
                GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE] MKK_KE_RSLT_BATCH_RUNNING_FLAG has been set to [0]");
            }
			logger.info("MKK Account Sonuc Alma Servisi tamamland�, [BNSPR_MKK_ACCOUNT_RESULT_BATCH_SERVICE]");
		}
		return oMap;
	}
    /***
     * CreateInvestor
     * MatchIdentities
	 * NotifyChangeOfQualificationStat
	 * Servislerinin sonu�lar�n� alan servis
     * @param iMap
     * @return
     */
    @GraymoundService("BNSPR_MKK_ACCOUNT_RESULT_SERVICE")
    public static GMMap mkkCallAccountResultService(GMMap iMap){
        GMMap oMap = new GMMap();
        try { 
        	logger.info(iMap.getString("SERVICE_NAME") + " Sonu�lar� al�nmaya ba�land�.");
        	iMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE", iMap));
        	int result = iMap.getBigDecimal("COUNT").intValue();
        	if(result > 0){
        		logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE] al�nacak kay�t:" + result);
        		iMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE", iMap));
        		logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE] max order id:" + iMap.getBigDecimal("MAX_OID").intValue());
	            for (int i = 1; i <= result; i++){
	            	iMap.put("ORDER_ID", new BigDecimal(iMap.getBigDecimal("MAX_OID").intValue()+i));
	            	oMap.putAll(GMServiceExecuter.executeNT("BNSPR_MKK_ACCOUNT_NEXT_ASYNC_RESULT_SERVICE", iMap));
	            }
	            HesaplarDurumGuncellemesi();
        	}else{
        		oMap.put("MESSAGE", "Sorgulanacak kimlik e�le�tirme yoktur.");
        	}
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } 
        return oMap;
    }

    
	@GraymoundService("BNSPR_MKK_ACCOUNT_NEXT_ASYNC_RESULT_SERVICE")
	public static GMMap mkkAccountNextAsyncResultService(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_ACCOUNT_NEXT_ASYNC_RESULT_SERVICE] �al��maya ba�lad�.");
			AccountNextAsyncServiceResultType request = new AccountNextAsyncServiceResultType();
			NextAsyncServiceResultType type = new NextAsyncServiceResultType();
			type.setMemberId("AFB");
			type.setOrderId(iMap.getString("ORDER_ID"));
			type.setProcessDate(new SimpleDateFormat("yyyyMMdd").format(new Date()));
			AccountAsyncServiceNameType serviceName = AccountAsyncServiceNameType.fromValue(iMap.getString("SERVICE_NAME"));
			type.setServiceName(serviceName);
			request.setNextAsyncServiceResult(type);
			RequestHeaderType requestHeader = new RequestHeaderType();
			requestHeader.setSenderMember("AFB");
			requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_ACCOUNT_NEXT_ASYNC_RESULT_SERVICE));
			request.setRequestHeader(requestHeader);
			AccountNextAsyncServiceResultResponseType response = MkkClient.getMkkAccountService().accountNextAsyncServiceResult(request);
			saveMkkResponse(response);
			if(response != null && response.getResponse() != null){
				GMMap sMap = new GMMap();
				sMap.put("ServiceName", response.getResponse().getServiceName());
				sMap.put("OrderId", response.getResponse().getOrderId());
				sMap.put("ReferenceKey", response.getResponse().getReferenceKey());
				if (response.getResponse().getMatchIdentitiesResult() != null) {
					matchIdentitiesResult(response.getResponse().getMatchIdentitiesResult(), sMap);
				}
				else if (response.getResponse().getNotifyChangeOfQualificationStat() != null) {
					notifyChangeOfQualificationStat(response.getResponse().getNotifyChangeOfQualificationStat(), sMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			logger.info("[BNSPR_MKK_ACCOUNT_NEXT_ASYNC_RESULT_SERVICE] �al��may� tamamlad�.");
		}
		return oMap;
	}
    
	@GraymoundService("BNSPR_MKK_ACCOUNT_ASYNC_RESULT_SERVICE")
	public static GMMap mkkAccountAsyncResultService(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_SERVICE] �al��maya ba�lad�.");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE", iMap));
			if (oMap.getBigDecimal("COUNT").compareTo(new BigDecimal(0)) > 0) {
				AccountAsyncServiceResultType request = new AccountAsyncServiceResultType();
				AsyncServiceResultType type = new AsyncServiceResultType();
				type.setReferenceKey(iMap.getString("REFERENCE_KEY"));
				request.setAsyncServiceResult(type);
				RequestHeaderType requestHeader = new RequestHeaderType();
				requestHeader.setSenderMember("AFB");
				requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_ACCOUNT_ASYNC_RESULT_SERVICE));
				request.setRequestHeader(requestHeader);
				AccountAsyncServiceResultResponseType response = MkkClient.getMkkAccountService().accountAsyncServiceResult(request);
				saveMkkResponse(response);
				if(response != null && response.getResponse() != null){
					GMMap sMap = new GMMap();
					sMap.put("ServiceName", response.getResponse().getServiceName());
					sMap.put("OrderId", response.getResponse().getOrderId());
					sMap.put("ReferenceKey", response.getResponse().getReferenceKey());
					if(response.getResponse().getServiceName() != null){
						if (response.getResponse().getServiceName().equals(AccountAsyncServiceNameType.MATCH_IDENTITIES_RESULT)) {
							matchIdentitiesResult(response.getResponse().getMatchIdentitiesResult(), sMap);
						}
						else if (response.getResponse().getServiceName().equals(AccountAsyncServiceNameType.NOTIFY_CHANGE_OF_QUALIFICATION_STAT)) {
							notifyChangeOfQualificationStat(response.getResponse().getNotifyChangeOfQualificationStat(), sMap);
						}
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_SERVICE] �al��may� tamamlad�.");
		}
		return oMap;

	}
    
	@GraymoundService("BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE")
	public static GMMap mkkPendingResultCount(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE] �al��maya ba�lad�.");
			AccountPendingAsyncServiceResultCount request = new AccountPendingAsyncServiceResultCount();

			PendingAsyncServiceResultCountType type = new PendingAsyncServiceResultCountType();
			type.setMemberId("AFB");
			type.setProcessDate(new SimpleDateFormat("yyyyMMdd").format(new Date()));
			type.setServiceName(AccountAsyncServiceNameType.fromValue(iMap.getString("SERVICE_NAME")));
			request.setPendingAsyncServiceResultCount(type);

			RequestHeaderType requestHeader = new RequestHeaderType();
			requestHeader.setSenderMember("AFB");
			requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE));
			request.setRequestHeader(requestHeader);

			AccountPendingAsyncServiceResultCountResponseType response = MkkClient.getMkkAccountService().accountPendingAsyncServiceResultCount(request);
			saveMkkResponse(response, iMap);
			if (response != null && response.getResponse() != null && response.getResponse().getPendingResultCount() != null) {
				oMap.put("COUNT", new BigDecimal(response.getResponse().getPendingResultCount()));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_CNT_SERVICE] �al��may� tamamlad�.");
		}
		return oMap;
	}
    
    private static String getSenderReference(Services key) {
		return key.toString() + "-" + TreasuryUtil.getGenelKodAl(key.getKodAdi());
	}

	@GraymoundService("BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE")
	public static GMMap mkkPendingResultMaxOrderId(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE] �al��maya ba�lad�.");
			AccountMaxAsyncServiceOrderIdResultType request = new AccountMaxAsyncServiceOrderIdResultType();

			MaxAsyncServiceOrderIdResultType type = new MaxAsyncServiceOrderIdResultType();
			type.setMemberId("AFB");
			type.setProcessDate(new SimpleDateFormat("yyyyMMdd").format(new Date()));
			type.setServiceName(AccountAsyncServiceNameType.fromValue(iMap.getString("SERVICE_NAME")));
			request.setMaxAsyncServiceOrderIdResult(type);

			RequestHeaderType requestHeader = new RequestHeaderType();
			requestHeader.setSenderMember("AFB");
			requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE));
			request.setRequestHeader(requestHeader);

			AccountMaxAsyncServiceOrderIdResponseType response = MkkClient.getMkkAccountService().accountMaxAsyncServiceOrderId(request);
			saveMkkResponse(response, iMap);
			if (response != null && response.getResponse() != null && response.getResponse().getMaxOrderId() != null) {
				oMap.put("MAX_OID", new BigDecimal(response.getResponse().getMaxOrderId()));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logger.info("[BNSPR_MKK_ACCOUNT_ASYNC_RESULT_MAX_OID_SERVICE] �al��may� tamamlad�.");
		}
		return oMap;
	}

	public static MkkHesapAcilisTx createNewHaxPojo(MkkHesapAcilis ha){
       
        MkkHesapAcilisTx hax = new MkkHesapAcilisTx();
        MkkHesapAcilisTxId haxId = new MkkHesapAcilisTxId();
        
        hax.setId(haxId);
        haxId.setHaId(ha.getHaId());
        hax.setSenderMember(ha.getSenderMember());
        hax.setSenderReference(ha.getSenderReference());
        hax.setMemberCode(ha.getMemberCode());
        hax.setAccountNumber(ha.getAccountNumber());
        hax.setIban(ha.getIban());
        hax.setReasonCode(ha.getReasonCode());
        hax.setProcessStatus(ha.getProcessStatus());
        hax.setClassCode(ha.getClassCode());
        hax.setPortfolioCode(ha.getPortfolioCode());
        hax.setJointType(ha.getJointType());
        hax.setIsInvestorBlockaged(ha.getIsInvestorBlockaged());
        hax.setVob(ha.getVob());
        hax.setMusteriNo(ha.getMusteriNo());
        hax.setIslemKod(ha.getIslemKod());
        hax.setReferans(ha.getReferans());
        hax.setGeriAlisReferans(ha.getGeriAlisReferans());
        
        return hax;
    }
    
    public  static MkkKimlikEslestirmeTx createNewKexPojo(MkkKimlikEslestirme ke){
        
        MkkKimlikEslestirmeTx kex = new MkkKimlikEslestirmeTx();
        MkkKimlikEslestirmeTxId kexId = new MkkKimlikEslestirmeTxId();
        
        kex.setId(kexId);
        kex.setKeId(ke.getId().getKeId());
        kex.setHaId(ke.getHaId());
        kex.setInvestorType(ke.getInvestorType());
        kex.setSenderReference(ke.getSenderReference());
        kex.setSenderMember(ke.getSenderMember());
        kex.setMemberCode(ke.getMemberCode());
        kex.setAccountNumber(ke.getAccountNumber());
        kex.setCustomerId(ke.getCustomerId());
        kex.setRegisteryNumber(ke.getRegisteryNumber());
        kex.setTaxPayerType(ke.getTaxPayerType());
        kex.setPartnershipRatio(ke.getPartnershipRatio());
        kex.setYgName(ke.getYgName());
        kex.setYgSurname(ke.getYgSurname());
        kex.setYgIdentityNo(ke.getYgIdentityNo());
        kex.setYgBirthDate(ke.getYgBirthDate());
        kex.setYtTitle(ke.getYtTitle());
        kex.setYtTradeRegDept(ke.getYtTradeRegDept());
        kex.setYtTradeRegDate(ke.getYtTradeRegDate());
        kex.setYtTradeRegNo(ke.getYtTradeRegNo());
        kex.setYtSectorCode(ke.getYtSectorCode());
        kex.setYtSubsectorCode(ke.getYtSubsectorCode());
        kex.setYtTaxIdNo(ke.getYtTaxIdNo());
        kex.setYtTaxDept(ke.getYtTaxDept());
        kex.setYoTitle(ke.getYoTitle());
        kex.setYoTradeRegDept(ke.getYoTradeRegDept());
        kex.setYoTradeRegDate(ke.getYoTradeRegDate());
        kex.setYoTradeRegNo(ke.getYoTradeRegNo());
        kex.setYoSectorCode(ke.getYoSectorCode());
        kex.setYoSubsectorCode(ke.getYoSubsectorCode());
        kex.setYoTaxIdNo(ke.getYoTaxIdNo());
        kex.setYoTaxDept(ke.getYoTaxDept());
        kex.setYoSwiftBic(ke.getYoSwiftBic());
        kex.setYatTitle(ke.getYatTitle());
        kex.setYatSectorCode(ke.getYatSectorCode());
        kex.setYatSubsectorCode(ke.getYatSubsectorCode());
        kex.setYatTaxIdNo(ke.getYatTaxIdNo());
        kex.setYatTaxDept(ke.getYatTaxDept());
        kex.setYatSwiftBic(ke.getYatSwiftBic());
        kex.setYatCountryCode(ke.getYatCountryCode());
        kex.setYagName(ke.getYagName());
        kex.setYagSurname(ke.getYagSurname());
        kex.setYagIdentityNo(ke.getYagIdentityNo());
        kex.setYagFatherName(ke.getYagFatherName());
        kex.setYagMotherName(ke.getYagMotherName());
        kex.setYagCountryCode(ke.getYagCountryCode());
        kex.setYagBirthPlace(ke.getYagBirthPlace());
        kex.setYagBirthDate(ke.getYagBirthDate());
        kex.setYagGender(ke.getYagGender());
        kex.setYagTaxIdNo(ke.getYagTaxIdNo());
        kex.setYagForeignIdNo(ke.getYagForeignIdNo());
        kex.setYfTitle(ke.getYfTitle());
        kex.setYfTaxIdNo(ke.getYfTaxIdNo());
        kex.setYfTaxDept(ke.getYfTaxDept());
        kex.setYfSwiftBic(ke.getYfSwiftBic());
        kex.setYafTitle(ke.getYafTitle());
        kex.setYafTaxIdNo(ke.getYafTaxIdNo());
        kex.setYafTaxDept(ke.getYafTaxDept());
        kex.setYafSwiftBic(ke.getYafSwiftBic());
        kex.setYafCountryCode(ke.getYafCountryCode());
        kex.setYdTitle(ke.getYdTitle());
        kex.setYdTaxIdNo(ke.getYdTaxIdNo());
        kex.setYdTaxDept(ke.getYdTaxDept());
        kex.setYdTradeRegNo(ke.getYdTradeRegNo());
        kex.setYdTradeRegDept(ke.getYdTradeRegDept());
        kex.setYadTitle(ke.getYadTitle());                        
        kex.setYadTaxIdNo(ke.getYadTaxIdNo());
        kex.setYadTaxDept(ke.getYadTaxDept());
        kex.setYadTradeRegNo(ke.getYadTradeRegNo());
        kex.setYadTradeRegDept(ke.getYadTradeRegDept());
        kex.setYadCountryCode(ke.getYadCountryCode());
        kex.setAdressType(ke.getAdressType());
        kex.setTelNo(ke.getTelNo());
        kex.setCellTelNo(ke.getCellTelNo());
        kex.setFaxNo(ke.getFaxNo());
        kex.setEmail(ke.getEmail());
        kex.setWebAddress(ke.getWebAddress());
        kex.setDistrict(ke.getDistrict());
        kex.setWard(ke.getWard());
        kex.setAddress1(ke.getAddress1());
        kex.setAddress2(ke.getAddress2());
        kex.setAddress3(ke.getAddress3());
        kex.setYerliPostalCode(ke.getYerliPostalCode());
        kex.setYerliTownship(ke.getYerliTownship());
        kex.setYerliCity(ke.getYerliCity());
        kex.setYabCountryCode(ke.getYabCountryCode());
        kex.setYabPostalCode(ke.getYabPostalCode());
        kex.setYabTownship(ke.getYabTownship());
        kex.setYabCity(ke.getYabCity());
        kex.setYabRegion(ke.getYabRegion());
        kex.setMusteriNo(ke.getMusteriNo());
        kex.setIslemKod(ke.getIslemKod());
        kex.setReferans(ke.getReferans());
        kex.setGeriAlisReferans(ke.getGeriAlisReferans());
        kex.setServiceName(ke.getServiceName());
        kex.setOrderId(ke.getOrderId());
        kex.setReferenceKey(ke.getReferenceKey());
        
        return kex;
    }

    public static BigDecimal newId(String key){
        GMMap map = new GMMap();
        map.put("TABLE_NAME" , key);
        return (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", map).get("ID");        
    }
    
    public static void saveMkkResponse(MkkResponseType response){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    
    public static void saveMkkResponse(AccountPendingAsyncServiceResultCountResponseType response, GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(iMap.getString("SERVICE_NAME"));
            mkkPojo.setCountOrMaxOid(response.getResponse().getPendingResultCount());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    public static void saveMkkResponse(AccountMaxAsyncServiceOrderIdResponseType response, GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(iMap.getString("SERVICE_NAME"));
            mkkPojo.setCountOrMaxOid(response.getResponse().getMaxOrderId());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    
    public static void saveMkkResponse(AccountNextAsyncServiceResultResponseType response){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(response.getResponse().getServiceName());
            mkkPojo.setOrderId(response.getResponse().getOrderId());
            mkkPojo.setReferenceKey(response.getResponse().getReferenceKey());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    
    public static void saveMkkResponse(AccountAsyncServiceResultResponseType response){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(response.getResponse().getServiceName());
            mkkPojo.setOrderId(response.getResponse().getOrderId());
            mkkPojo.setReferenceKey(response.getResponse().getReferenceKey());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
	public static void HesaplarDurumGuncellemesi() {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1702.Update_Hesaplar_Durum}");
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static void matchIdentitiesResult(MatchIdentitiesResultType matchIdentitiesResult, GMMap iMap) {

		logger.info("..............MKK Match Identities request received..............");
		if (matchIdentitiesResult.getResponseHeader() != null) {
			logger.info("matchIdentitiesResult.responseHeader.senderReference => " + matchIdentitiesResult.getResponseHeader().getSenderReference());
			logger.info("matchIdentitiesResult.responseHeader.receiverMember => " + matchIdentitiesResult.getResponseHeader().getReceiverMember());
			logger.info("matchIdentitiesResult.responseHeader.tid => " + matchIdentitiesResult.getResponseHeader().getTid());
			logger.info("matchIdentitiesResult.responseHeader.messageId => " + matchIdentitiesResult.getResponseHeader().getMessageId());
			logger.info("matchIdentitiesResult.responseHeader.mkkSenderReference => " + matchIdentitiesResult.getResponseHeader().getMkkSenderReference());
		}

		try {

			MatchResultType resType = matchIdentitiesResult.getMatchResult();
			ResponseHeaderType resHeader = matchIdentitiesResult.getResponseHeader();

			if (resHeader != null) {
				logger.info("resHeader okunuyor...");
				logger.info("resHeader.getSenderReference => " + resHeader.getSenderReference());
				logger.info("resHeader.getReceiverMember => " + resHeader.getReceiverMember());
				logger.info("resHeader.getTid => " + resHeader.getTid());
				logger.info("resHeader.getMessageId => " + resHeader.getMessageId());
				logger.info("resHeader.getMkkSenderReference => " + resHeader.getMkkSenderReference());

				iMap.put("SenderReference", resHeader.getSenderReference());
				iMap.put("ReceiverMember", resHeader.getReceiverMember());
				iMap.put("Tid", resHeader.getTid());
				iMap.put("MessageId", resHeader.getMessageId());
				iMap.put("MkkSenderReference", resHeader.getMkkSenderReference());
			}

			if (resType != null) {
				logger.info("resType okunuyor...");
				logger.info("resType.getMemberCode => " + resType.getMemberCode());
				logger.info("resType.getAccountNo => " + resType.getAccountNo());
				logger.info("resType.getAccountState => " + resType.getAccountState());

				iMap.put("MemberCode", resType.getMemberCode());
				iMap.put("AccountNo", resType.getAccountNo());
				iMap.put("AccState", resType.getAccountState());

				FailedParticipantType failedParticipant = resType.getFailedParticipant();
				logger.info("FailedParticipant okunuyor...");
				if (failedParticipant != null) {
					logger.info("FailedParticipant.getCustomerId:" + failedParticipant.getCustomerId());
					logger.info("FailedParticipant.getMernisState:" + failedParticipant.getMernisState());
					logger.info("FailedParticipant.getTaxNoState:" + failedParticipant.getTaxNoState());
					logger.info("FailedParticipant.getReason:" + failedParticipant.getReason());

					iMap.put("FailCustomerId", failedParticipant.getCustomerId());
					iMap.put("FailMernisState", failedParticipant.getMernisState());
					iMap.put("FailTaxNoState", failedParticipant.getTaxNoState());
					iMap.put("FailReason", failedParticipant.getReason());
				}

				ParticipantsType participantsType = resType.getParticipants();
				if (participantsType != null) {
					List<ParticipantType> participants = participantsType.getParticipant();
					if (participants != null) {
						int i = 0;
						logger.info("SuccessParticipants okunuyor...");
						for (ParticipantType participant : participants) {
							if (participant != null) {
								logger.info("SuccessParticipants-" + i + " getCustomerId:" + participant.getCustomerId());
								logger.info("SuccessParticipants-" + i + " getRegistryNo:" + participant.getRegistryNo());
								logger.info("SuccessParticipants-" + i + " getQualificationStat:" + participant.getQualificationStat());

								iMap.put("SuccessParticipants", i, "CustomerId", participant.getCustomerId());
								iMap.put("SuccessParticipants", i, "RegistryNo", participant.getRegistryNo());
								iMap.put("SuccessParticipants", i, "QualifStat", participant.getQualificationStat());
								iMap.put("RegistryNo", participant.getRegistryNo());
								i++;
							}
						}
					}
				}
			}

			logger.info("Calling service: BNSPR_TRN1702_GET_KE_RESPONSE");
			GMMap resultMap = GMServiceExecuter.call("BNSPR_TRN1702_GET_KE_RESPONSE", iMap);
			logger.info("response code:" + resultMap.getString("RESPONSE_CODE"));
			logger.info("response desc:" + resultMap.getString("RESPONSE_DESC"));
			logger.info("End of service: BNSPR_TRN1702_GET_KE_RESPONSE");

			logger.info("MemberServices.matchIdentitiesResult response parametreleri set edildi");
		}
		catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex);
		}
		logger.info("..............End of MKK Match Identities request..............");
	}

	private static void notifyChangeOfQualificationStat(NotifyChangeOfQualificationStatType notifyChangeOfQualificationStat, GMMap iMap) {
		logger.info("..............MKK Notify Change Of Qualification Stat request received..............");

		ResponseHeaderType resHeader = notifyChangeOfQualificationStat.getResponseHeader();

		if (resHeader != null) {
			logger.info("notifyChangeOfQualificationStat.responseHeader.senderReference => " + resHeader.getSenderReference());
			logger.info("notifyChangeOfQualificationStat.responseHeader.receiverMember => " + resHeader.getReceiverMember());
			logger.info("notifyChangeOfQualificationStat.responseHeader.tid => " + resHeader.getTid());
			logger.info("notifyChangeOfQualificationStat.responseHeader.messageId => " + resHeader.getMessageId());
			logger.info("notifyChangeOfQualificationStat.responseHeader.mkkSenderReference => " + resHeader.getMkkSenderReference());
		}

		logger.info("notifyChangeOfQualificationStat.registryNo => " + notifyChangeOfQualificationStat.getRegistryNo());
		logger.info("notifyChangeOfQualificationStat.qualificationStat => " + notifyChangeOfQualificationStat.getQualificationStat());

		try {

			if (resHeader != null) {
				iMap.put("SenderReference", resHeader.getSenderReference());
				iMap.put("ReceiverMember", resHeader.getReceiverMember());
				iMap.put("Tid", resHeader.getTid());
				iMap.put("MessageId", resHeader.getMessageId());
				iMap.put("MkkSenderReference", resHeader.getMkkSenderReference());
			}

			iMap.put("RegistryNo", notifyChangeOfQualificationStat.getRegistryNo());
			iMap.put("QualificationStat", notifyChangeOfQualificationStat.getQualificationStat());

			logger.info("Calling service: BNSPR_CHANGE_QUALIFICATIION_RESULT_RESPONSE");
			GMMap resultMap = GMServiceExecuter.call("BNSPR_CHANGE_QUALIFICATIION_RESULT_RESPONSE", iMap);
			logger.info("response code:" + resultMap.getString("RESPONSE_CODE"));
			logger.info("response desc:" + resultMap.getString("RESPONSE_DESC"));
			logger.info("End of service: BNSPR_CHANGE_QUALIFICATIION_RESULT_RESPONSE");
		}
		catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex);
		}
		logger.info("..............End of MKK Notify Change Of Qualification Stat request..............");
	}
}
