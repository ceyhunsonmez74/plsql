package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznBankaTransTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1305Services {
	
	@GraymoundService("BNSPR_TRN1305_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1305.BTR_BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1305_GET_TRANSFER_DATA")
	public static GMMap getTransferData(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznBankaTransTx hznBankaTransTx = (HznBankaTransTx)session.get(HznBankaTransTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznBankaTransTx.getTxNo());
			oMap.put("REF_NO", hznBankaTransTx.getRefNo());
			oMap.put("GIRIS_MBANKA_MUSTERINO", hznBankaTransTx.getGirisMuhabirMusterino());
			
			oMap.put("GIRIS_MBANKA_ADI", LovHelper.diLov(hznBankaTransTx.getGirisMuhabirMusterino(), "1305/LOV_MBANKA_MUSTERI_NO", "UNVAN"));
			
			oMap.put("GIRIS_MBANKA_HESAPNO", hznBankaTransTx.getGirisMuhabirHesapno());
			oMap.put("CIKIS_MBANKA_MUSTERINO", hznBankaTransTx.getCikisMuhabirMusterino());
			oMap.put("CIKIS_MBANKA_HESAPNO", hznBankaTransTx.getCikisMuhabirHesapno());
			
			oMap.put("CIKIS_MBANKA_ADI", LovHelper.diLov(hznBankaTransTx.getCikisMuhabirMusterino(), "1305/LOV_MBANKA_MUSTERI_NO", "UNVAN"));
			oMap.put("DEALER_NO", hznBankaTransTx.getDealerNo());
			oMap.put("DEALER_ISIM", LovHelper.diLov(hznBankaTransTx.getDealerNo(), "1305/LOV_DEALER", "ISIM"));
			
			oMap.put("DOVIZ_KODU", hznBankaTransTx.getDovizKodu());
			oMap.put("di_DOVIZ_KODU", LovHelper.diLov(hznBankaTransTx.getDovizKodu(), "1305/LOV_DOVIZ_KODU", "ACIKLAMA"));
			
			oMap.put("TUTAR", hznBankaTransTx.getTutar());
			oMap.put("VALOR_TARIHI", hznBankaTransTx.getValorTarihi());
			oMap.put("ACIKLAMA", hznBankaTransTx.getAciklama());
			oMap.put("DURUM_KODU", hznBankaTransTx.getDurumKodu());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1305_SAVE")
	public static GMMap save (GMMap iMap){
		try {
	
			Session session = DAOSession.getSession("BNSPRDal");
			HznBankaTransTx hznBankaTransTx = (HznBankaTransTx)session.get(HznBankaTransTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznBankaTransTx == null) {
				hznBankaTransTx = new HznBankaTransTx();
			}
			
			hznBankaTransTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznBankaTransTx.setRefNo(iMap.getString("REF_NO"));
			hznBankaTransTx.setGirisMuhabirMusterino(iMap.getBigDecimal("GIRIS_MBANKA_MUSTERINO"));
			hznBankaTransTx.setGirisMuhabirHesapno(iMap.getBigDecimal("GIRIS_MBANKA_HESAPNO"));
			hznBankaTransTx.setCikisMuhabirMusterino(iMap.getBigDecimal("CIKIS_MBANKA_MUSTERINO"));
			hznBankaTransTx.setCikisMuhabirHesapno(iMap.getBigDecimal("CIKIS_MBANKA_HESAPNO"));
			hznBankaTransTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznBankaTransTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznBankaTransTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznBankaTransTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznBankaTransTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznBankaTransTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			
			session.saveOrUpdate(hznBankaTransTx);
			session.flush();
			iMap.put("TRX_NAME", "1305");
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1305_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznBankaTransTx hznBankaTransTx = (HznBankaTransTx)session.get(HznBankaTransTx.class, txNo);
	
			oMap.put("TX_NO", hznBankaTransTx.getTxNo());
			oMap.put("REF_NO", hznBankaTransTx.getRefNo());
			oMap.put("GIRIS_MBANKA_MUSTERINO", hznBankaTransTx.getGirisMuhabirMusterino());
			
			
			oMap.put("GIRIS_MBANKA_ADI", LovHelper.diLov(hznBankaTransTx.getGirisMuhabirMusterino(), "1305/LOV_MBANKA_MUSTERI_NO", "UNVAN"));
			
			oMap.put("GIRIS_MBANKA_HESAPNO", hznBankaTransTx.getGirisMuhabirHesapno());
			oMap.put("CIKIS_MBANKA_MUSTERINO", hznBankaTransTx.getCikisMuhabirMusterino());
			oMap.put("CIKIS_MBANKA_HESAPNO", hznBankaTransTx.getCikisMuhabirHesapno());
			
			oMap.put("CIKIS_MBANKA_ADI", LovHelper.diLov(hznBankaTransTx.getCikisMuhabirMusterino(), "1305/LOV_MBANKA_MUSTERI_NO", "UNVAN"));
			oMap.put("DEALER_NO", hznBankaTransTx.getDealerNo());
			oMap.put("DEALER_ISIM", LovHelper.diLov(hznBankaTransTx.getDealerNo(), "1305/LOV_DEALER", "ISIM"));
			
			oMap.put("DOVIZ_KODU", hznBankaTransTx.getDovizKodu());
			oMap.put("di_DOVIZ_KODU", LovHelper.diLov(hznBankaTransTx.getDovizKodu(), "1305/LOV_DOVIZ_KODU", "ACIKLAMA"));
			
			oMap.put("TUTAR", hznBankaTransTx.getTutar());
			oMap.put("VALOR_TARIHI", hznBankaTransTx.getValorTarihi());
			oMap.put("ACIKLAMA", hznBankaTransTx.getAciklama());
			oMap.put("DURUM_KODU", hznBankaTransTx.getDurumKodu());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
}
