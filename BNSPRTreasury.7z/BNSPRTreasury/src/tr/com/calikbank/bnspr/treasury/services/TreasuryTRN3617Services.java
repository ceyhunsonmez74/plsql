package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinVerilendepoTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3617Services {

	@GraymoundService("BNSPR_TRN3617_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3617.BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3617_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilenDepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznAltinVerilenDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinVerilenDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinVerilenDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinVerilenDepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinVerilenDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinVerilenDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinVerilenDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinVerilenDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinVerilenDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinVerilenDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinVerilenDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinVerilenDepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinVerilenDepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinVerilenDepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinVerilenDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinVerilenDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinVerilenDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinVerilenDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinVerilenDepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznAltinVerilenDepoTx.getVadeSonuFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAltinVerilenDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAltinVerilenDepoTx.getDealTarihi());
			oMap.put("YENILENENTUTAR", hznAltinVerilenDepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznAltinVerilenDepoTx.getEkTutar());
			oMap.put("YENILENENREFERANS", hznAltinVerilenDepoTx.getYenilenenReferans());
			if(hznAltinVerilenDepoTx.getVadeTarihindeKapama() != null)
				if(hznAltinVerilenDepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_NEG", hznAltinVerilenDepoTx.getBirikmisFaizNeg());
			
			oMap.put("FAIZ_ORANI", hznAltinVerilenDepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getGirisHesapNo(),hznAltinVerilenDepoTx.getDovizKodu(),
					hznAltinVerilenDepoTx.getGirisHesapTuru(), hznAltinVerilenDepoTx.getBankaMusteriNo(), hznAltinVerilenDepoTx.getGirisHesapTuru(), 
					hznAltinVerilenDepoTx.getGirisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getCikisHesapNo(),hznAltinVerilenDepoTx.getDovizKodu(),
					hznAltinVerilenDepoTx.getCikisHesapTuru(), hznAltinVerilenDepoTx.getBankaMusteriNo(), hznAltinVerilenDepoTx.getCikisHesapTuru(), 
					hznAltinVerilenDepoTx.getCikisHesapTuru(), "1312/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getBankaMusteriNo(), "1312/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinVerilenDepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinVerilenDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinVerilenDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinVerilenDepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("STOK_NO",hznAltinVerilenDepoTx.getStokNo());
			oMap.put("SAFLIK_DERECESI",hznAltinVerilenDepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI",hznAltinVerilenDepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI",hznAltinVerilenDepoTx.getKomisyonTutari());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN3617_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilenDepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAltinVerilenDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinVerilenDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinVerilenDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinVerilenDepoTx.getReferans());
			oMap.put("DEALER_NO", hznAltinVerilenDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinVerilenDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinVerilenDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinVerilenDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinVerilenDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinVerilenDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinVerilenDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinVerilenDepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinVerilenDepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinVerilenDepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinVerilenDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinVerilenDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinVerilenDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinVerilenDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinVerilenDepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznAltinVerilenDepoTx.getVadeSonuFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAltinVerilenDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAltinVerilenDepoTx.getDealTarihi());
			oMap.put("YENILENENTUTAR", hznAltinVerilenDepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznAltinVerilenDepoTx.getEkTutar());
			oMap.put("REFERANSYENI", hznAltinVerilenDepoTx.getReferansYeni());
			if(hznAltinVerilenDepoTx.getVadeTarihindeKapama() != null)
				if(hznAltinVerilenDepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_NEG", hznAltinVerilenDepoTx.getBirikmisFaizNeg());
			
			oMap.put("FAIZ_ORANI", hznAltinVerilenDepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getGirisHesapNo(),hznAltinVerilenDepoTx.getDovizKodu(),
					hznAltinVerilenDepoTx.getGirisHesapTuru(), hznAltinVerilenDepoTx.getBankaMusteriNo(), hznAltinVerilenDepoTx.getGirisHesapTuru(), 
					hznAltinVerilenDepoTx.getGirisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getCikisHesapNo(),hznAltinVerilenDepoTx.getDovizKodu(),
					hznAltinVerilenDepoTx.getCikisHesapTuru(), hznAltinVerilenDepoTx.getBankaMusteriNo(), hznAltinVerilenDepoTx.getCikisHesapTuru(), 
					hznAltinVerilenDepoTx.getCikisHesapTuru(), "1312/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinVerilenDepoTx.getBankaMusteriNo(), "1312/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinVerilenDepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinVerilenDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinVerilenDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinVerilenDepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("STOK_NO",hznAltinVerilenDepoTx.getStokNo());
			oMap.put("SAFLIK_DERECESI",hznAltinVerilenDepoTx.getSaflikDerecesi());
			oMap.put("KOMISYON_ORANI",hznAltinVerilenDepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI",hznAltinVerilenDepoTx.getKomisyonTutari());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_TRN3617_SAVE")
    public static Map<?, ?> save(GMMap iMap){
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinVerilendepoTx hznAltinVerilenDepoTx = (HznAltinVerilendepoTx)session.get(HznAltinVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAltinVerilenDepoTx == null) {
				hznAltinVerilenDepoTx = new HznAltinVerilendepoTx();
			}
			
			hznAltinVerilenDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAltinVerilenDepoTx.setModulTurKod("HAZINE");
			hznAltinVerilenDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAltinVerilenDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAltinVerilenDepoTx.setReferans(iMap.getString("REFERANS"));
			hznAltinVerilenDepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznAltinVerilenDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAltinVerilenDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAltinVerilenDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAltinVerilenDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAltinVerilenDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAltinVerilenDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAltinVerilenDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAltinVerilenDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAltinVerilenDepoTx.setNetTutar(iMap.getBigDecimal("NET_TUTAR"));
			hznAltinVerilenDepoTx.setBrutTutar(iMap.getBigDecimal("BRUT_TUTAR"));
			hznAltinVerilenDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAltinVerilenDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAltinVerilenDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAltinVerilenDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAltinVerilenDepoTx.setVadeSonuFaizTutari(iMap.getBigDecimal("VADE_SONU_FAIZ_TUTARI"));
			hznAltinVerilenDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAltinVerilenDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAltinVerilenDepoTx.setReferansYeni(iMap.getString("REFERANS_YENI"));
			hznAltinVerilenDepoTx.setYenilenenTutar(iMap.getBigDecimal("YENILENEN_TUTAR"));
			hznAltinVerilenDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			if(iMap.getString("VADE_TARIHINDE_KAPAMA").toString().equals("false"))
				hznAltinVerilenDepoTx.setVadeTarihindeKapama("H");
			else
				hznAltinVerilenDepoTx.setVadeTarihindeKapama("E");
			hznAltinVerilenDepoTx.setBirikmisFaizNeg(iMap.getBigDecimal("BIRIKMIS_FAIZ_NEG"));
			hznAltinVerilenDepoTx.setEkTutar(iMap.getBigDecimal("EK_TUTAR"));
			hznAltinVerilenDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			hznAltinVerilenDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznAltinVerilenDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			
			hznAltinVerilenDepoTx.setStokNo(iMap.getString("STOK_NO"));
			hznAltinVerilenDepoTx.setSaflikDerecesi(iMap.getBigDecimal("SAFLIK_DERECESI"));
			hznAltinVerilenDepoTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
			hznAltinVerilenDepoTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
			
			session.saveOrUpdate(hznAltinVerilenDepoTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3617");            
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
}
