package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.HznBloombergBankaMust;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislem;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.HznPlatformBankaKod;
import tr.com.aktifbank.bnspr.dao.MenBistislemDefteri;
import tr.com.aktifbank.bnspr.dao.MenBistislemDefteriTx;
import tr.com.aktifbank.bnspr.dao.MenBistislemDefteriTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznAlinandepo;
import tr.com.calikbank.bnspr.dao.HznAlinandepoTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwd;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.dao.HznSwap;
import tr.com.calikbank.bnspr.dao.HznSwapTx;
import tr.com.calikbank.bnspr.dao.HznVerilendepo;
import tr.com.calikbank.bnspr.dao.HznVerilendepoTx;
import tr.com.calikbank.bnspr.treasury.util.ServiceUtil;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AktifSTPService {

	private static Logger log = Logger.getLogger(AktifSTPService.class);

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM")
	public static GMMap saveSpotFwIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String serviceName = "SPOT";
		Date islemValoru = null;
		Date islemZamani = null;
		Date dealTarihi = null;
	
		try {
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "");

			/*Zorunlu alanlar�n kontrolu*/
			inputKontrol(iMap, oMap, serviceName);

			/*Tarih format� kontrolleri*/
			dealTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("DEAL_TARIHI"), 2, "Deal tarih format� hatal�.", false);
			islemValoru = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_VALORU"), 2, "��lem Val�r� tarih format� hatal�.", false);
			islemZamani = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_ZAMANI"), 2, "��lem Zaman� tarih format� hatal�.", true);

			getDealorNo(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			bankaKoduBul(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
 
			musteriBilgileriGetir(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			/*Yeni islem girisi*/
			if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("F")) {

				/*Daha once bu id'lerle ilgili bir kay�t gelip gelmedi�ini kontrol edelim*/
				List<HznSpotfwdTx> spot = (List<HznSpotfwdTx>) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("messageId", iMap.getString("MESSAGE_ID"))).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();
				List<HznSpotfwd> spotFwd = (List<HznSpotfwd>) session.createCriteria(HznSpotfwd.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();

				if (spot != null && spot.size() > 0 || spotFwd.size() > 0) {
					oMap.put("RESPONSE", "3");
					oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
					ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
				inputHaz�rla(iMap, islemValoru, islemZamani, dealTarihi, serviceName);
				GMServiceExecuter.execute("BNSPR_TRN1306_SAVE", iMap);
				iMap.put("TRX_NAME", "1306");
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
				oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));

				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);

			}
			else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("G")) {

				/*Guncellenmek istenen kayda ait daha �nce bir kay�t girilmi� mi konrol et*/
				/*Guncelleme iste�i sadece onay sonras�nda gelebilir --> Durum Kodu = A ,*/

				HznSpotfwd spot = (HznSpotfwd) session.createCriteria(HznSpotfwd.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();

				if (spot == null) {
					oMap.put("RESPONSE", "8");
					oMap.put("RESPONSE_DATA", "G�ncelleme iste�ine uygun bir kay�t bulunmuyor.");
					ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				inputHaz�rla(iMap, islemValoru, islemZamani, dealTarihi, serviceName);

				GMMap tMap = new GMMap();
				tMap.put("REF_NO", spot.getReferans());
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1307_GET_TRANSFER_TXNO", tMap));
				iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
				GMServiceExecuter.execute("BNSPR_TRN1307_SAVE", iMap);
				iMap.put("TRX_NAME", "1307");
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
				oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));

				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);

			}
			else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("H")) {

				/*Iptal i�lemi sadece ayn� g�n gelebilir*/
				/*Onay sonraas� ve onay �ncesi de gelebiir*/
				Date nowDate = new Date();

				HznSpotfwd spot = (HznSpotfwd) session.createCriteria(HznSpotfwd.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID")))
				// .add(Restrictions.eq("acilisTarihi", nowDate))
				.uniqueResult();

				/*Onay sonras� iptal edilebilecek bir kay�t var*/
				if (spot != null) {

					inputHaz�rla(iMap, islemValoru, islemZamani, dealTarihi, serviceName);

					GMMap tMap = new GMMap();
					tMap.put("REF_NO", spot.getReferans());
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1307_GET_TRANSFER_TXNO", tMap));
					iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
					GMServiceExecuter.execute("BNSPR_TRN1307_SAVE", iMap);
					iMap.put("TRX_NAME", "1307");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));

					ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				/*Onay �ncesi iptal edilecek bir kay�t var m� bakal�m*/

				HznSpotfwdTx spotFwTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID")))
				// .add(Restrictions.eq("acilisTarihi", nowDate))
				.uniqueResult();

				if (spotFwTx != null) {
					spotFwTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
					session.update(spotFwTx);
					session.flush();

					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "OR");
					onayMap.put("ISLEM_NO", spotFwTx.getId().getTxNo());
					onayMap.put("ACIKLAMA", "Stp Gun i�inde iptal iste�i");
					GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap);
					return oMap;
				}
				else {
					oMap.put("RESPONSE", "8");
					oMap.put("RESPONSE_DATA", "Iptal iste�ine uygun bir kay�t bulunmuyor.");
					ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}
			}
			else {
				oMap.put("RESPONSE", "7");
				oMap.put("RESPONSE_DATA", "Mesaj statu bu de�erlerden biri olabilir. {F,G,H}");
				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;

			}

			return oMap;
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/*-------------------------------------------------------------------SWAP-1308-------------------------------------------------------------------------------------------------------------------------*/

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM")
	public static GMMap saveSwapIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String serviceName = "SWAP";
		Date vadeTarihi = null;
		Date valorTarihi = null;
		Date dealTarihi = null;

		try {
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "");

			/*Zorunlu alanlar�n kontrolu*/
			inputKontrol(iMap, oMap, serviceName);

			/*Tarih format� kontrolleri*/
			dealTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("DEAL_TARIHI"), 2, "Deal tarihi format� hatal�.", false);
			vadeTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("VADE_TARIHI"), 2, "Vade tarihi format� hatal�.", false);
			valorTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("VALOR_TARIHI"), 2, "Val�r tarih format� hatal�.", false);

			getDealorNo(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			bankaKoduBul(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			musteriBilgileriGetir(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			/*Mesaj Statu = F , yeni g�nderilen kay�t*/
			if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("F")) {

				List<HznSwapTx> hznSwapTx = (List<HznSwapTx>) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("messageId", iMap.getString("MESSAGE_ID"))).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();
				List<HznSwap> hznSwap = (List<HznSwap>) session.createCriteria(HznSwap.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();

				if (!hznSwapTx.isEmpty() || !hznSwap.isEmpty()) {
					oMap.put("RESPONSE", "3");
					oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
					ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
				inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);

				GMServiceExecuter.execute("BNSPR_TRN1308_SAVE", iMap);

				iMap.put("TRX_NAME", "1308");
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

				oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
				ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);

			}
			else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("G")) {

				/*Guncellenmek istenen kayda ait daha �nce bir kay�t girilmi� mi konrol et*/
				/*Guncelleme iste�i sadece onay sonras�nda gelebilir --> Durum Kodu = A ,*/

				HznSwap spot = (HznSwap) session.createCriteria(HznSwap.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();

				if (spot == null) {
					oMap.put("RESPONSE", "8");
					oMap.put("RESPONSE_DATA", "G�ncelleme iste�ine uygun bir kay�t bulunmuyor.");
					ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);

				GMMap tMap = new GMMap();
				tMap.put("REF_NO", spot.getReferans());
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1309_GET_TRANSFER_TXNO", tMap));
				iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
				GMServiceExecuter.execute("BNSPR_TRN1309_SAVE", iMap);
				iMap.put("TRX_NAME", "1309");
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
				oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));

				ServiceUtil.logAt("BNSPR_STP_SPOT_FW_TRADER_PROVIDER_AKTARIM", iMap, oMap);

			}
			else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("H")) {

				/*Iptal i�lemi sadece ayn� g�n gelebilir*/
				/*Onay sonraas� ve onay �ncesi de gelebiir*/
				Date nowDate = new Date();

				HznSwap spot = (HznSwap) session.createCriteria(HznSwap.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID")))
				// .add(Restrictions.eq("acilisTarihi", nowDate))
				.uniqueResult();

				/*Onay sonras� iptal edilebilecek bir kay�t var*/
				if (spot != null) {

					inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);

					GMMap tMap = new GMMap();
					tMap.put("REF_NO", spot.getReferans());
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1309_GET_TRANSFER_TXNO", tMap));
					iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
					GMServiceExecuter.execute("BNSPR_TRN1309_SAVE", iMap);
					iMap.put("TRX_NAME", "1309");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));

					ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				/*Onay �ncesi iptal edilecek bir kay�t var m� bakal�m*/

				HznSwapTx spotFwTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID")))
				// .add(Restrictions.eq("acilisTarihi", nowDate))
				.uniqueResult();

				if (spotFwTx != null) {

					spotFwTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
					session.update(spotFwTx);
					session.flush();

					GMMap onayMap = new GMMap();
					onayMap.put("ISLEM_TURU", "OR");
					onayMap.put("ISLEM_NO", spotFwTx.getId().getTxNo());
					onayMap.put("ACIKLAMA", "Stp Gun i�inde iptal iste�i");
					GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap);
					return oMap;
				}
				else {
					oMap.put("RESPONSE", "8");
					oMap.put("RESPONSE_DATA", "Iptal iste�ine uygun bir kay�t bulunmuyor.");
					ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}
			}
			else {
				oMap.put("RESPONSE", "7");
				oMap.put("RESPONSE_DATA", "Mesaj statu bu de�erlerden biri olabilir. {F,G,H}");
				ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;

			}

			return oMap;

		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_STP_OPSIYON_TRADER_PROVIDER_AKTARIM")
	public static GMMap saveOpsiyonIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String serviceName = "OPSIYON";
		Date islemTarihi, islemZamani, vadeTarihi, uzlasmaTarihi, primTarih = null;
		BigDecimal emptyValue = null;

		Date bariyerBasTarih, bariyerBitTarih, bariyerBasTarih2, bariyerBitTarih2 = null;
		String basZaman1, bitZaman1, basZaman2, bitZaman2 = null;

		try {
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "");

			/*Zorunlu alanlar�n kontrolu*/
			inputKontrol(iMap, oMap, serviceName);

			/*Tarih format� kontrolleri*/
			islemTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_TARIHI"), 2, "Islem tarihi format� hatal�.", false);
			islemZamani = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_ZAMANI"), 2, "Islem zamani format� hatal�.", true);
			vadeTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("VADE_TARIHI"), 2, "Vade tarih format� hatal�.", false);
			uzlasmaTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("UZLASMA_TARIHI"), 2, "Uzlasma tarihi format� hatal�.", false);
			primTarih = ServiceUtil.checkDateInput(oMap, iMap.getString("PRIM_TARIH"), 2, "Prim tarihi format� hatal�.", false);

			bariyerBasTarih = ServiceUtil.checkDateInput(oMap, iMap.getString("BARIYER_BAS_TARIH"), 2, "BariyerBas tarihi format� hatal�.", false);
			bariyerBitTarih = ServiceUtil.checkDateInput(oMap, iMap.getString("BARIYER_BIT_TARIH"), 2, "BariyerBit tarihi format� hatal�.", false);
			basZaman1 = ServiceUtil.checkDateTime(oMap, iMap.getString("BARIYER_BAS_TARIH"), 2, "Bariyer bas. zaman tarih format� hatal�.", false);
			bitZaman1 = ServiceUtil.checkDateTime(oMap, iMap.getString("BARIYER_BIT_TARIH"), 2, "Bariyer bit. zaman tarih format� hatal�.", false);

			bariyerBasTarih2 = ServiceUtil.checkDateInput(oMap, iMap.getString("BARIYER_BAS_TARIH2"), 2, "BariyerBas2 tarih format� hatal�.", false);
			bariyerBitTarih2 = ServiceUtil.checkDateInput(oMap, iMap.getString("BARIYER_BIT_TARIH2"), 2, "BariyerBit2 tarih format� hatal�.", false);
			basZaman2 = ServiceUtil.checkDateTime(oMap, iMap.getString("BARIYER_BAS_TARIH2"), 2, "Bariyer bas. zaman tarih format� hatal�.", false);
			bitZaman2 = ServiceUtil.checkDateTime(oMap, iMap.getString("BARIYER_BIT_TARIH2"), 2, "Bariyer bit. zaman tarih format� hatal�.", false);

			getDealorNo(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_OPSIYON_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			bankaKoduBul(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_OPSIYON_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			dovizCinsleriBelirle(iMap);

			musteriBilgileriGetir(iMap, oMap);
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_OPSIYON_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			/*Yeni islem girisi*/
			if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("F")) {

				List<HznOpsiyonislemTx> hznOpsiyonTx = (List<HznOpsiyonislemTx>) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("messageId", iMap.getString("MESSAGE_ID"))).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();
				List<HznOpsiyonislem> hznOpsiyon = (List<HznOpsiyonislem>) session.createCriteria(HznOpsiyonislem.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();

				if (!hznOpsiyonTx.isEmpty() || !hznOpsiyon.isEmpty()) {
					oMap.put("RESPONSE", "3");
					oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
					ServiceUtil.logAt("BNSPR_STP_OPSIYON_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));

				iMap.put("ISLEM_TARIHI", islemTarihi);
				iMap.put("dfDealer", iMap.getString("DEALER_ACIKLAMA"));
				iMap.put("UZLASMA_TARIHI", uzlasmaTarihi);
				iMap.put("VADE_TARIHI", vadeTarihi);
				iMap.put("PRIM_TARIHI", primTarih);
				iMap.put("R_BANKA", true);

				iMap.put("COMBO_OPSIYON_CINS", iMap.getString("OPS_CINS"));
				iMap.put("COMBO_OPSIYON_YONU", iMap.getString("OPS_YON"));
				iMap.put("COMBO_OPSIYON_AMAC", "K");
				iMap.put("COMBO_OPSIYON_TIPI", iMap.getString("OPS_TIP"));

				iMap.put("COMBO_BAZ_DOVIZ_CINSI", iMap.getString("BAZ_DOVIZ"));
				iMap.put("COMBO_OPSIYON_SEKLI", iMap.getString("BAZ_OPS_SEKLI"));
				iMap.put("HEDEF_FIYAT", iMap.getBigDecimal("STRIKE"));
				iMap.put("BAZ_OPSIYON_TUTARI", iMap.getBigDecimal("BAZ_TUTAR"));
				iMap.put("COMBO_KARSI_DOVIZ", iMap.getString("KARSI_DOVIZ"));
				iMap.put("KARSI_OPSIYON_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));

				if (iMap.getString("OPS_CINS").equalsIgnoreCase("V")) {
					iMap.put("SATILAN_DOVIZ_TEXT", iMap.getString("SATILAN_DOVIZ"));
					iMap.put("ALINAN_DOVIZ_TEXT", iMap.getString("ALINAN_DOVIZ"));
					iMap.put("ALINAN_DOVIZ", iMap.getBigDecimal("ALINAN_DOVIZ_TUTARI"));
					iMap.put("SATILAN_DOVIZ", iMap.getBigDecimal("SATILAN_DOVIZ_TUTARI"));
				}
				else {
					if (iMap.getString("OPS_YON").equalsIgnoreCase("A")) {
						iMap.put("ALINAN_DOVIZ_TEXT", iMap.getString("OPS_DOVIZ"));
						iMap.put("ALINAN_DOVIZ", iMap.getBigDecimal("KARSI_TUTAR"));

						iMap.put("SATILAN_DOVIZ_TEXT", "");
						iMap.put("SATILAN_DOVIZ", emptyValue);
					}
					else {
						iMap.put("SATILAN_DOVIZ_TEXT", iMap.getString("OPS_DOVIZ"));
						iMap.put("SATILAN_DOVIZ", iMap.getBigDecimal("KARSI_TUTAR"));

						iMap.put("ALINAN_DOVIZ_TEXT", "");
						iMap.put("ALINAN_DOVIZ", emptyValue);
					}

				}

				iMap.put("SPOT_KURU", iMap.getBigDecimal("ISLEM_ANI_SPOT"));
				iMap.put("BAZ_DOVIZ_CINSI", iMap.getString("BAZ_DOVIZ"));
				iMap.put("KARSI_DOVIZ_CINSI", iMap.getString("KARSI_DOVIZ"));
				iMap.put("OPSIYON_DOVIZ_CINSI", iMap.getString("OPS_DOVIZ"));
				
				GMMap kurMap = GMServiceExecuter.call("BNSPR_TRN1578_GET_ISLEM_ANI_SPOT_KURU", iMap);				
				iMap.put("DOVIZ_KURU", kurMap.getBigDecimal("DOVIZ_KURU"));
				iMap.put("OPS_KURU", kurMap.getBigDecimal("OPS_KURU"));

				
				iMap.put("ALIS_HESAP_TURU", "MUHABIR");
				iMap.put("SATIS_HESAP_TURU", "MUHABIR");

				iMap.put("MUSTERIMUHABIRNO", iMap.getString("ALIS_MUHABIR_MUSTERI_NO"));
				iMap.put("MUSTERIMUHABIRNOSATIS", iMap.getString("SATIS_MUHABIR_MUSTERI_NO"));

				iMap.put("GUN_FARKI", gunFark�Hesapla(iMap));
				iMap.put("KARSILANAN_TUTAR", new BigDecimal(0));

				iMap.put("MUSTERI_PRIM", iMap.getBigDecimal("PRIM_YUZDE"));
				if (iMap.getBigDecimal("PRIM_YUZDE") == null) {
					if (iMap.getString("PRIM_DOVIZ").equalsIgnoreCase(iMap.getString("KARSI_DOVIZ")) || !iMap.getString("COMBO_OPSIYON_CINS").equalsIgnoreCase("V")) {
						iMap.put("MUSTERI_PRIM", ((iMap.getBigDecimal("PRIM_TUTAR").divide(iMap.getBigDecimal("KARSI_TUTAR"), 8, RoundingMode.HALF_UP)).multiply(new BigDecimal(100))));
					}
					else {
						iMap.put("MUSTERI_PRIM", ((iMap.getBigDecimal("PRIM_TUTAR").divide(iMap.getBigDecimal("BAZ_TUTAR"), 8, RoundingMode.HALF_UP).multiply(new BigDecimal(100)))));
					}
				}
				iMap.put("COMBO_PRIM_DOVIZ_CINSI", iMap.getString("PRIM_DOVIZ"));
				iMap.put("PRIM_TUTARI", iMap.getBigDecimal("PRIM_TUTAR"));

				iMap.put("MALIYET_PRIM", new BigDecimal(0));
				iMap.put("SUBE_KARI_DOVIZ_CINSI", iMap.getString("PRIM_DOVIZ"));
				// sube kari hesaplama
				iMap.put("SUBE_KARI", subeKariHesapla(iMap));

				// teminatOran�Hesaplama
				iMap.put("TEMINAT_ORANI", new BigDecimal(100));
				iMap.put("ISLEM_TURU", "D");
				iMap.put("TEMINAT_TUTARI", teminatHesapla(iMap));

				iMap.put("ACIKLAMA", "Stp Opsiyon Provider Aktar�m ��lemi");
				iMap.put("ISTATISTIK_KODU", 4370);

				if (iMap.getString("OPS_CINS").equalsIgnoreCase("V")) {
					iMap.put("EKRAN_NO", "1571");
					iMap.put("TRX_NAME", "1571");
					GMServiceExecuter.execute("BNSPR_TRN1571_SAVE", iMap);
				}
				else {
					if (iMap.getString("COMBO_OPSIYON_CINS").equals("NT") || iMap.getString("COMBO_OPSIYON_CINS").equals("OT") || iMap.getString("COMBO_OPSIYON_CINS").equals("D")) {
						iMap.put("BARIYER_CINSI1", iMap.getString("BARIYER_CINS"));
						iMap.put("BARIYER_TIPI1", iMap.getString("OPS_TIP"));
						iMap.put("BARIYER_DEGER1", iMap.getBigDecimal("BARIYER_SEV1"));
						iMap.put("BARIYER_BITTAR1", bariyerBitTarih);
						iMap.put("BARIYER_BASTAR1", bariyerBasTarih);
						iMap.put("BARIYER_BITZAMAN1", bitZaman1);
						iMap.put("BARIYER_BASZAMAN1", basZaman1);

					}
					else if (iMap.getString("COMBO_OPSIYON_CINS").equals("DNT") || iMap.getString("COMBO_OPSIYON_CINS").equals("DOT") || iMap.getString("COMBO_OPSIYON_CINS").equals("A")) {
						iMap.put("BARIYER_CINSI1", iMap.getString("BARIYER_CINS"));
						iMap.put("BARIYER_TIPI1", iMap.getString("OPS_TIP"));
						iMap.put("BARIYER_DEGER1", iMap.getBigDecimal("BARIYER_SEV1"));
						iMap.put("BARIYER_BITTAR1", bariyerBitTarih);
						iMap.put("BARIYER_BASTAR1", bariyerBasTarih);
						iMap.put("BARIYER_BITZAMAN1", bitZaman1);
						iMap.put("BARIYER_BASZAMAN1", basZaman1);

						iMap.put("BARIYER_CINSI2", iMap.getString("BARIYER_CINS"));
						iMap.put("BARIYER_DEGER2", iMap.getBigDecimal("BARIYER_SEV2"));
						iMap.put("BARIYER_TIPI2", iMap.getString("OPS_TIP"));
						iMap.put("BARIYER_BITTAR2", bariyerBitTarih2);
						iMap.put("BARIYER_BASTAR2", bariyerBasTarih2);
						iMap.put("BARIYER_BASZAMAN2", basZaman2);
						iMap.put("BARIYER_BITZAMAN2", bitZaman2);
					}

					iMap.put("VADE_ZAMAN", vadeZaman�(iMap));
					iMap.put("OPSIYON_DOVIZ_CINSI", iMap.getString("OPS_DOVIZ"));

					iMap.put("EKRAN_NO", "1578");
					iMap.put("TRX_NAME", "1578");
					GMServiceExecuter.execute("BNSPR_TRN1578_SAVE", iMap);
				}

				oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
				ServiceUtil.logAt("BNSPR_STP_OPSIYON_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}else{             
                oMap.put("RESPONSE", "7");
                oMap.put("RESPONSE_DATA", "Mesaj statu bu de�erlerden biri olabilir. {F}");
                ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, oMap);
                return oMap;
			}
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_SWAP_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}

	private static String vadeZaman�(GMMap iMap) {
		String vadeZamani = iMap.getString("VADE_ZAMANI");
		if(vadeZamani.contains(":")){			
			 vadeZamani = vadeZamani.replace(":", "");
		}
		
		return vadeZamani;
	}

	private static BigDecimal gunFark�Hesapla(GMMap iMap) throws Exception {
		String func = "{? = call PKG_TRN1571.gun_farki_bul(?,?)}";
		Object[] inputValues = new Object[] { BnsprType.DATE, iMap.getDate("VADE_TARIHI"), BnsprType.DATE, iMap.getDate("ISLEM_TARIHI") };

		BigDecimal gunFarki = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);

		return gunFarki;
	}

	private static BigDecimal teminatHesapla(GMMap iMap) {

		BigDecimal teminatTutar = new BigDecimal(0);

		if (iMap.getString("OPS_CINS").equalsIgnoreCase("V")) {

			if (iMap.getString("KARSI_DOVIZ").equalsIgnoreCase("TRY")) {
				teminatTutar = (((iMap.getBigDecimal("TEMINAT_ORANI").multiply(iMap.getBigDecimal("BAZ_TUTAR"))).multiply(iMap.getBigDecimal("HEDEF_FIYAT")))).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
			}
			else {
				teminatTutar = (((iMap.getBigDecimal("TEMINAT_ORANI").multiply(iMap.getBigDecimal("BAZ_TUTAR"))).multiply(iMap.getBigDecimal("HEDEF_FIYAT")))).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
			}

			if (iMap.getString("KARSI_DOVIZ") != null && !iMap.getString("KARSI_DOVIZ").equalsIgnoreCase("TRY")) {

				GMMap kMap = new GMMap();
				kMap.put("DOVIZ", iMap.getString("KARSI_DOVIZ"));
				kMap.put("TUTAR", teminatTutar);
				kMap.put("KUR_TIPI", new BigDecimal(1));
				kMap.put("ALIS_SATIS", "A");
				GMMap eMap = GMServiceExecuter.call("BNSPR_COMMON_FC_TO_LC", kMap);
				teminatTutar = eMap.getBigDecimal("KUR");
			}

			if (iMap.getString("OPS_YON").equalsIgnoreCase("S")) {

				try {
					if (!StringUtils.isBlank(iMap.getString("PRIM_DOVIZ"))) {
						String func = "{? = call pkg_kur.FC_to_LC(?,?,?,?)}";
						Object[] inputValues = new Object[] { BnsprType.STRING, iMap.getString("PRIM_DOVIZ"), BnsprType.NUMBER, new BigDecimal(1), BnsprType.NUMBER, new BigDecimal(1), BnsprType.STRING, "A" };

						BigDecimal teminat = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);

						teminatTutar = teminat.multiply(iMap.getBigDecimal("PRIM_TUTARI"));
					}

				}
				catch (Exception e) {
					throw ExceptionHandler.convertException(e);
				}
			}

		}
		else {
			if (iMap.getString("OPS_YON").equalsIgnoreCase("A")) {
				teminatTutar = (((iMap.getBigDecimal("TEMINAT_ORANI").multiply(iMap.getBigDecimal("KARSI_TUTAR"))).multiply(iMap.getBigDecimal("OPS_KURU")))).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
		}
			else {
				try {
					if (!StringUtils.isBlank(iMap.getString("PRIM_DOVIZ"))) {
						String func = "{? = call pkg_kur.FC_to_LC(?,?,?,?)}";
						Object[] inputValues = new Object[] { BnsprType.STRING, iMap.getString("PRIM_DOVIZ"), BnsprType.NUMBER, new BigDecimal(1), BnsprType.NUMBER, new BigDecimal(1), BnsprType.STRING, "A" };

						BigDecimal teminat = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);

						teminatTutar = teminat.multiply(iMap.getBigDecimal("PRIM_TUTARI"));
					}

				}
				catch (Exception e) {
					throw ExceptionHandler.convertException(e);
				}
			}

		}

		return teminatTutar;
	}

	private static BigDecimal subeKariHesapla(GMMap iMap) {

		BigDecimal subeKar = new BigDecimal(0);

		if (iMap.getString("OPS_CINS").equalsIgnoreCase("V")) {

			if (iMap.getString("OPS_YON").equalsIgnoreCase("A") && iMap.getString("PRIM_DOVIZ").equalsIgnoreCase(iMap.getString("BAZ_DOVIZ"))) {
				subeKar = (((iMap.getBigDecimal("MALIYET_PRIM").subtract(iMap.getBigDecimal("MUSTERI_PRIM"))).multiply(iMap.getBigDecimal("BAZ_TUTAR")))).divide(new BigDecimal(100));
			}

			if (iMap.getString("OPS_YON").equalsIgnoreCase("A") && !iMap.getString("PRIM_DOVIZ").equalsIgnoreCase(iMap.getString("BAZ_DOVIZ"))) {
				subeKar = (((iMap.getBigDecimal("MALIYET_PRIM").subtract(iMap.getBigDecimal("MUSTERI_PRIM"))).multiply(iMap.getBigDecimal("KARSI_TUTAR")))).divide(new BigDecimal(100));
			}
			if (iMap.getString("OPS_YON").equalsIgnoreCase("S") && iMap.getString("PRIM_DOVIZ").equalsIgnoreCase(iMap.getString("BAZ_DOVIZ"))) {
				subeKar = (((iMap.getBigDecimal("MUSTERI_PRIM").subtract(iMap.getBigDecimal("MALIYET_PRIM"))).multiply(iMap.getBigDecimal("BAZ_TUTAR")))).divide(new BigDecimal(100));
			}
			if (iMap.getString("OPS_YON").equalsIgnoreCase("S") && !iMap.getString("PRIM_DOVIZ").equalsIgnoreCase(iMap.getString("BAZ_DOVIZ"))) {
				subeKar = (((iMap.getBigDecimal("MUSTERI_PRIM").subtract(iMap.getBigDecimal("MALIYET_PRIM"))).multiply(iMap.getBigDecimal("KARSI_TUTAR")))).divide(new BigDecimal(100));
			}

		}
		else {

			if (iMap.getString("OPS_YON").equalsIgnoreCase("A")) {
				subeKar = (((iMap.getBigDecimal("MALIYET_PRIM").subtract(iMap.getBigDecimal("MUSTERI_PRIM"))).multiply(iMap.getBigDecimal("KARSI_TUTAR")))).divide(new BigDecimal(100));
			}
			else {
				subeKar = (((iMap.getBigDecimal("MUSTERI_PRIM").subtract(iMap.getBigDecimal("MALIYET_PRIM"))).multiply(iMap.getBigDecimal("KARSI_TUTAR")))).divide(new BigDecimal(100));
			}

		}

		return subeKar;

	}

	private static void dovizCinsleriBelirle(GMMap iMap) {
		String bazOpsSekli = iMap.getString("BAZ_OPS_SEKLI");
		String opsYonu = iMap.getString("OPS_YON");
		String opsCinsi = iMap.getString("OPS_CINS");
		BigDecimal emptyValue = null;

		if (opsCinsi.equalsIgnoreCase("V")) {
			if ("XAG;XAU".contains(iMap.getString("BAZ_DOVIZ"))) {
				iMap.put("STRIKE", iMap.getBigDecimal("STRIKE").divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR));
				iMap.put("ISLEM_ANI_SPOT", iMap.getBigDecimal("ISLEM_ANI_SPOT").divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR));
				iMap.put("BAZ_TUTAR", iMap.getBigDecimal("KARSI_TUTAR").divide(iMap.getBigDecimal("STRIKE"), 8, RoundingMode.FLOOR));

			}
		}else{
			if ("XAG;XAU".contains(iMap.getString("BAZ_DOVIZ"))) {
				iMap.put("ISLEM_ANI_SPOT", iMap.getBigDecimal("ISLEM_ANI_SPOT").divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR));
			}
			
			if ("XAG;XAU".contains(iMap.getString("OPS_DOVIZ"))) {
				iMap.put("ISLEM_ANI_SPOT", iMap.getBigDecimal("ISLEM_ANI_SPOT").divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR));
				iMap.put("KARSI_TUTAR", iMap.getBigDecimal("KARSI_TUTAR").multiply(new BigDecimal("31.1035")));
			}			
		}
		
		
		
		if (iMap.getString("OPS_CINS").equalsIgnoreCase("V")) {

			if (bazOpsSekli.equalsIgnoreCase("C")) {
				if (opsYonu.equalsIgnoreCase("A")) {
					iMap.put("ALINAN_DOVIZ", iMap.getString("BAZ_DOVIZ"));
					iMap.put("SATILAN_DOVIZ", iMap.getString("KARSI_DOVIZ"));
					iMap.put("ALINAN_DOVIZ_TUTARI", iMap.getBigDecimal("BAZ_TUTAR"));
					iMap.put("SATILAN_DOVIZ_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));
					iMap.put("ALACAK_HESAP_DOVIZ", iMap.getString("KARSI_DOVIZ"));
					iMap.put("BORCLU_HESAP_DOVIZ", iMap.getString("BAZ_DOVIZ"));
				}
				else {
					iMap.put("ALINAN_DOVIZ", iMap.getString("KARSI_DOVIZ"));
					iMap.put("SATILAN_DOVIZ", iMap.getString("BAZ_DOVIZ"));
					iMap.put("ALINAN_DOVIZ_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));
					iMap.put("SATILAN_DOVIZ_TUTARI", iMap.getBigDecimal("BAZ_TUTAR"));
					iMap.put("ALACAK_HESAP_DOVIZ", iMap.getString("BAZ_DOVIZ"));
					iMap.put("BORCLU_HESAP_DOVIZ", iMap.getString("KARSI_DOVIZ"));
				}
			}
			else {
				if (opsYonu.equalsIgnoreCase("A")) {
					iMap.put("ALINAN_DOVIZ", iMap.getString("KARSI_DOVIZ"));
					iMap.put("SATILAN_DOVIZ", iMap.getString("BAZ_DOVIZ"));
					iMap.put("ALINAN_DOVIZ_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));
					iMap.put("SATILAN_DOVIZ_TUTARI", iMap.getBigDecimal("BAZ_TUTAR"));
					iMap.put("ALACAK_HESAP_DOVIZ", iMap.getString("BAZ_DOVIZ"));
					iMap.put("BORCLU_HESAP_DOVIZ", iMap.getString("KARSI_DOVIZ"));
				}else {
					iMap.put("ALINAN_DOVIZ", iMap.getString("BAZ_DOVIZ"));
					iMap.put("SATILAN_DOVIZ", iMap.getString("KARSI_DOVIZ"));
					iMap.put("ALINAN_DOVIZ_TUTARI", iMap.getBigDecimal("BAZ_TUTAR"));
					iMap.put("SATILAN_DOVIZ_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));
					iMap.put("ALACAK_HESAP_DOVIZ", iMap.getString("KARSI_DOVIZ"));
					iMap.put("BORCLU_HESAP_DOVIZ", iMap.getString("BAZ_DOVIZ"));
				}
			}

		}
		else {
			if (iMap.getString("OPS_YON").equalsIgnoreCase("A")) {

				iMap.put("ALINAN_DOVIZ", iMap.getString("OPS_DOVIZ"));
				iMap.put("ALINAN_DOVIZ_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));

				iMap.put("SATILAN_DOVIZ", "");
				iMap.put("SATILAN_DOVIZ_TUTARI", emptyValue);
			}else {

				iMap.put("ALINAN_DOVIZ", "");
				iMap.put("ALINAN_DOVIZ_TUTARI", emptyValue);

				iMap.put("SATILAN_DOVIZ", iMap.getString("OPS_DOVIZ"));
				iMap.put("SATILAN_DOVIZ_TUTARI", iMap.getBigDecimal("KARSI_TUTAR"));

			}
		}
	}

	private static void inputKontrol(GMMap iMap, GMMap oMap, String serviceName) {

		/*ws'lerde ortak olan alanalr�n parametre kontrolleri*/
		ServiceUtil.checkInput(oMap, iMap.getString("MESSAGE_ID"), 1, "Message Id giriniz.");
		ServiceUtil.checkInput(oMap, iMap.getString("SOURCE_PLATFORM"), 1, "Source Platform giriniz.");
		ServiceUtil.checkInput(oMap, iMap.getString("ORDER_ID"), 1, "Order id giriniz.");
		ServiceUtil.checkInput(oMap, iMap.getString("COUNTER_PARTY"), 1, "Karsi taraf bilgisi giriniz.");

		if (serviceName.equalsIgnoreCase("SPOT")) {
			/*Spot ws i�in zorunlu parametre kontrolleri*/
			ServiceUtil.checkInput(oMap, iMap.getString("DEAL_TARIHI"), 1, "Deal Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_VALORU"), 1, "��lem Val�r� giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ALINAN_TUTAR"), 1, "Al�nan Tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("SATILAN_TUTAR"), 1, "Sat�lan Tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ALINAN_DOVIZ"), 1, "Al�nan D�viz giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("SATILAN_DOVIZ"), 1, "Sat�lan D�viz giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("ISLEM_FIYATI"), 1, "��lem Fiyat� giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("TRADER_REF"), 1, "Trader Ref giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("URUN_TUR_KOD"), 1, "Urun Tur Kod giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("MESAJ_STATU"), 1, "Mesaj�n statusunu giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_ZAMANI"), 1, "��lem Zaman� giriniz.");

		}
		else if (serviceName.equalsIgnoreCase("SWAP")) {
			/*Swap ws i�in zorunlu parametre kontrolleri*/
			ServiceUtil.checkInput(oMap, iMap.getString("DEAL_TARIHI"), 1, "Deal Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("VALOR_TARIHI"), 1, "Valor Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("VADE_TARIHI"), 1, "Vade Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("SPOT_ISLEM_FIYATI"), 1, "Spot islem fiyat� giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("SPOT_ALIS_TUTAR"), 1, "Spot al�nan tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("SPOT_SATIS_TUTAR"), 1, "Spot sat�lan tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ALINAN_DOVIZ"), 1, "Al�nan doviz giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("SATILAN_DOVIZ"), 1, "Sat�lan doviz giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("FWD_ALIS_TUTAR"), 1, "Fwd al�nan tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("FWD_SATIS_TUTAR"), 1, "Fwd sat�lan tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("FWD_ISLEM_FIYATI"), 1, "Fwd islem fiyat� tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("TRADER_REF"), 1, "Trader Ref giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("URUN_TUR_KOD"), 1, "Urun Tur Kod giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("MESAJ_STATU"), 1, "Mesaj�n statusunu giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_ZAMANI"), 1, "��lem Zaman� giriniz.");
		}
		else if (serviceName.equalsIgnoreCase("OPSIYON")) {
			/*Opsiyon ws i�in zorunlu parametre kontrolleri*/
			ServiceUtil.checkInput(oMap, iMap.getString("UZLASMA_TARIHI"), 1, "Uzlasma Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_ANI_SPOT"), 1, "Islem An� Spot giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("OPS_CINS"), 1, "Opsiyon Cinsi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("OPS_YON"), 1, "Opsiyon yonu tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("OPS_TIP"), 1, "Opsiyon tipi doviz kodu giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("BAZ_DOVIZ"), 1, "Baz Doviz cinsi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getBigDecimal("KARSI_TUTAR"), 1, "Kar�� Opsiyon Tutar� giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("KARSI_DOVIZ"), 1, "Kar�� Doviz giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("TRADER_REF"), 1, "Trader Ref giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("URUN_TUR_KOD"), 1, "Urun Tur Kod giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("MESAJ_STATU"), 1, "Mesaj�n statusunu giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_ZAMANI"), 1, "��lem Zaman� giriniz.");

			if (!iMap.getString("OPS_CINS").equalsIgnoreCase("V")) {
				ServiceUtil.checkInput(oMap, iMap.getString("OPS_DOVIZ"), 1, "Ops Doviz giriniz.");
				ServiceUtil.checkInput(oMap, vadeZaman�(iMap), 1, "Vade Zaman giriniz.");

			}

			if (!iMap.getString("OPS_CINS").equalsIgnoreCase("V") && iMap.getString("COMBO_OPSIYON_CINS") != null) {

				if (iMap.getString("COMBO_OPSIYON_CINS").equals("NT") || iMap.getString("COMBO_OPSIYON_CINS").equals("OT") || iMap.getString("COMBO_OPSIYON_CINS").equals("D")) {
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_SEV1"), 1, "BARIYER_SEV1 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_BASTAR1"), 1, "BARIYER_BASTAR1 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_BITTAR1"), 1, "BARIYER_BITTAR1 giriniz.");

				}
				else if (iMap.getString("COMBO_OPSIYON_CINS").equals("DNT") || iMap.getString("COMBO_OPSIYON_CINS").equals("DOT") || iMap.getString("COMBO_OPSIYON_CINS").equals("A")) {

					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_SEV1"), 1, "BARIYER_SEV1 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_BAS_TARIH"), 1, "BARIYER_BASTAR1 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_BIT_TARIH"), 1, "BARIYER_BITTAR1 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_SEV2"), 1, "BARIYER_SEV2 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_BAS_TARIH2"), 1, "BARIYER_BASTAR2 giriniz.");
					ServiceUtil.checkInput(oMap, iMap.getString("BARIYER_BIT_TARIH2"), 1, "BARIYER_BITTAR2 giriniz.");

				}

			}
		}else if (serviceName.equalsIgnoreCase("REPO_TERSREPO")) {
			
			ServiceUtil.checkInput(oMap, iMap.getString("A_S"), 1, "A_S giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("PIYASA"), 1, "Piyasa giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_TIPI"), 1, "��lem tipi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_TARIHI"), 1, "��lem tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("PARA_BIRIMI"), 1, "Para Birimi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_ZAMANI"), 1, "��lem Zaman� giriniz.");
			
			if (!iMap.getString("ISLEM_TIPI").equals("1")) {
				
				ServiceUtil.checkInput(oMap, iMap.getString("ONCEKI_MESAJ_ID"), 1, "�nceki Message Id giriniz.");
			}
			
			if (iMap.getString("PIYASA").equalsIgnoreCase("BIST")) {
				
				ServiceUtil.checkInput(oMap, iMap.getString("UYE"), 1, "�ye giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("PM_HESABI"), 1, "PM_HESABI giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("KARSI_UYE"), 1, "KARSI_UYE giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("KARSI_UYE_PM"), 1, "KARSI_UYE_PM giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("VALOR1"), 1, "VALOR1 tarihi giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("VALOR2"), 1, "VALOR2 tarihi giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("FIYAT_ORAN"), 1, "Fiyat Oran giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("TUTAR"), 1, "Tutar giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("ANAPARA_FAIZ_STOPAJ"), 1, "Anapara Faiz Stopaj giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("EMIR_NO"), 1, "Emir No giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("REPO_MK"), 1, "REPO_MK giriniz.");	
				
			}else if (iMap.getString("PIYASA").equalsIgnoreCase("OTC") && iMap.getString("A_S").equalsIgnoreCase("R")) {
				
				ServiceUtil.checkInput(oMap, iMap.getString("UYE"), 1, "�ye giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_NO"), 1, "i�lem No giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("VALOR1"), 1, "VALOR1 tarihi giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("VALOR2"), 1, "VALOR2 tarihi giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("FIYAT_ORAN"), 1, "Fiyat Oran giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("TUTAR"), 1, "Tutar giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("ANAPARA_FAIZ_STOPAJ"), 1, "Anapara Faiz Stopaj giriniz.");
				ServiceUtil.checkInput(oMap, iMap.getString("REPO_MK"), 1, "Repo Mk giriniz.");	
				ServiceUtil.checkInput(oMap, iMap.getString("REPO_MK_NOMINAL"), 1, "Repo Mk Nominal giriniz.");
			}

		}
		else if (serviceName.equalsIgnoreCase("MONEYMARKET")) {
			ServiceUtil.checkInput(oMap, iMap.getString("MESAJ_STATU"), 1, "Mesaj�n stat�s�nu giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("TRADER_REF"), 1, "Trader Ref giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("ISLEM_TIPI"), 1, "Islem Tipi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("DOVIZ_KODU"), 1, "Doviz kodu giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("TUTAR"), 1, "Tutar giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("VALOR_TARIHI"), 1, "Valor Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("VADE_TARIHI"), 1, "Vade Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("DEAL_TARIHI"), 1, "Deal Tarihi giriniz.");
			ServiceUtil.checkInput(oMap, iMap.getString("FAIZ_ORANI"), 1, "Faiz Oran� giriniz.");
			if (!iMap.getString("MESAJ_STATU").equalsIgnoreCase("F")) {
				ServiceUtil.checkInput(oMap, iMap.getString("ONCEKI_MESAJ_ID"), 1, "�nceki Message Id giriniz.");	
			}
			
		}
	}

	private static void spotOnsHesaplama(GMMap iMap) {

		BigDecimal islemFiyat� = iMap.getBigDecimal("ISLEM_FIYATI");
		BigDecimal alinanTutar = iMap.getBigDecimal("ALINAN_TUTAR");
		BigDecimal satilanTutar = iMap.getBigDecimal("SATILAN_TUTAR");
		String satilanDvz = iMap.getString("SATILAN_DOVIZ");
		String alinanDvz = iMap.getString("ALINAN_DOVIZ");
		String k�ymetliMadenList = getParamText("1306", "KIYMETLI_MADEN");

		if (k�ymetliMadenList.contains(alinanDvz)) {
			BigDecimal grFiyat = islemFiyat�.divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR);
			iMap.put("ISLEM_FIYATI", grFiyat);
			iMap.put("ALINAN_TUTAR", satilanTutar.divide(grFiyat, 2, RoundingMode.FLOOR));
			iMap.put("XAU_ALIS_ONS_MIKTAR", alinanTutar);

		}
		else if (k�ymetliMadenList.contains(satilanDvz)) {
			BigDecimal grFiyat = islemFiyat�.divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR);
			iMap.put("ISLEM_FIYATI", grFiyat);
			iMap.put("SATILAN_TUTAR", alinanTutar.divide(grFiyat, 2, RoundingMode.FLOOR));
			iMap.put("XAU_SATIS_ONS_MIKTAR", satilanTutar);

		}

	}

	private static void swapOnsHesaplama(GMMap iMap) {

		BigDecimal spotIslemFiyat� = iMap.getBigDecimal("SPOT_ISLEM_FIYATI");
		BigDecimal fwdIslemFiyat� = iMap.getBigDecimal("FWD_ISLEM_FIYATI");
		BigDecimal spotAlinanTutar = iMap.getBigDecimal("SPOT_ALIS_TUTAR");
		BigDecimal spotSatilanTutar = iMap.getBigDecimal("SPOT_SATIS_TUTAR");
		BigDecimal fwdAlinanTutar = iMap.getBigDecimal("FWD_ALIS_TUTAR");
		BigDecimal fwdSatilanTutar = iMap.getBigDecimal("FWD_SATIS_TUTAR");

		String satilanDvz = iMap.getString("SATILAN_DOVIZ");
		String alinanDvz = iMap.getString("ALINAN_DOVIZ");

		String k�ymetliMadenList = getParamText("1308", "KIYMETLI_MADEN");

		if (k�ymetliMadenList.contains(alinanDvz)) {

			BigDecimal grSfiyat = spotIslemFiyat�.divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR);
			iMap.put("SPOT_ISLEM_FIYATI", grSfiyat);

			BigDecimal grFfiyat = fwdIslemFiyat�.divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR);
			iMap.put("FWD_ISLEM_FIYATI", grFfiyat);

			iMap.put("SPOT_ALIS_TUTAR", spotSatilanTutar.divide(grSfiyat, 2, RoundingMode.FLOOR));
			iMap.put("FWD_SATIS_TUTAR", fwdAlinanTutar.divide(grFfiyat, 2, RoundingMode.FLOOR));

		}
		else if (k�ymetliMadenList.contains(satilanDvz)) {

			BigDecimal grSfiyat = spotIslemFiyat�.divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR);
			iMap.put("SPOT_ISLEM_FIYATI", grSfiyat);

			BigDecimal grFfiyat = fwdIslemFiyat�.divide(new BigDecimal("31.1035"), 8, RoundingMode.FLOOR);
			iMap.put("FWD_ISLEM_FIYATI", grFfiyat);

			iMap.put("SPOT_SATIS_TUTAR", spotAlinanTutar.divide(grSfiyat, 2, RoundingMode.FLOOR));
			iMap.put("FWD_ALIS_TUTAR", fwdSatilanTutar.divide(grFfiyat, 2, RoundingMode.FLOOR));

		}
	}

	private static void inputHaz�rla(GMMap iMap, Date islemValoru, Date islemZamani, Date dealTarihi, String serviceName) {

		if (serviceName.equalsIgnoreCase("SPOT")) {

			spotOnsHesaplama(iMap);

			iMap.put("VALOR_TARIHI", islemValoru);
			iMap.put("DEAL_TARIHI", dealTarihi);
			iMap.put("ISLEM_ZAMANI", islemZamani);
			iMap.put("ALIS_TUTARI", iMap.getBigDecimal("ALINAN_TUTAR"));
			iMap.put("SATIS_TUTARI", iMap.getBigDecimal("SATILAN_TUTAR"));
			iMap.put("ALIS_DOVIZ_KODU", iMap.getString("ALINAN_DOVIZ"));
			iMap.put("SATIS_DOVIZ_KODU", iMap.getString("SATILAN_DOVIZ"));
			getParite(iMap);
			iMap.put("ACIKLAMA", "Stp Spot/Forward Provider Aktar�m ��lemi");
			iMap.put("TRADING_PORTFOY", "false");
			iMap.put("AS", getAlisSatis(iMap));
			iMap.put("URUN_SINIF_KOD", getSpotUrunSinifKod(iMap));
			iMap.put("URUN_TUR_KOD", iMap.getString("URUN_TUR_KOD"));
			iMap.put("ALIS_HESAP_TURU", "MUHABIR");
			iMap.put("SATIS_HESAP_TURU", "MUHABIR");
			iMap.put("ISTATISTIK_KODU", getIstatistikKodu(iMap, "1306"));

		}
		else if (serviceName.equalsIgnoreCase("SWAP")) {

			swapOnsHesaplama(iMap);

			iMap.put("VALOR_TARIHI", islemValoru);
			iMap.put("DEAL_TARIHI", dealTarihi);
			iMap.put("VADE_TARIHI", islemZamani);
			iMap.put("FORWARD_SATIS_HESAP_TURU", "MUHABIR");
			iMap.put("FORWARD_ALIS_HESAP_TURU", "MUHABIR");
			iMap.put("SPOT_ALIS_HESAP_TURU", "MUHABIR");
			iMap.put("SPOT_SATIS_HESAP_TURU", "MUHABIR");
			iMap.put("ACIKLAMA", "Stp Swap Provider Aktar�m ��lemi");
			iMap.put("ALIS_DOVIZ_KODU", iMap.getString("ALINAN_DOVIZ"));
			iMap.put("SATIS_DOVIZ_KODU", iMap.getString("SATILAN_DOVIZ"));
			iMap.put("SPOT_ALIS_TUTARI", iMap.getBigDecimal("SPOT_ALIS_TUTAR"));
			iMap.put("SPOT_SATIS_TUTARI", iMap.getBigDecimal("SPOT_SATIS_TUTAR"));
			iMap.put("FORWARD_ALIS_TUTARI", iMap.getBigDecimal("FWD_ALIS_TUTAR"));
			iMap.put("FORWARD_SATIS_TUTARI", iMap.getBigDecimal("FWD_SATIS_TUTAR"));
			iMap.put("FORWARD_ALIS_HESAP_NO", iMap.getString("SATIS_HESAP_NO"));
			iMap.put("FORWARD_SATIS_HESAP_NO", iMap.getString("ALIS_HESAP_NO"));
			iMap.put("SPOT_ALIS_HESAP_NO", iMap.getString("ALIS_HESAP_NO"));
			iMap.put("SPOT_SATIS_HESAP_NO", iMap.getString("SATIS_HESAP_NO"));
			iMap.put("URUN_TUR_KOD", iMap.getString("URUN_TUR_KOD"));
			getSwapUrunSinifKod(iMap);
			iMap.put("FORWARD_ALIS", iMap.getString("SATIS_MUHABIR_MUSTERI_NO"));
			iMap.put("FORWARD_SATIS", iMap.getString("ALIS_MUHABIR_MUSTERI_NO"));
			iMap.put("SPOT_ALIS", iMap.getString("ALIS_MUHABIR_MUSTERI_NO"));
			iMap.put("SPOT_SATIS", iMap.getString("SATIS_MUHABIR_MUSTERI_NO"));
			iMap.put("BAZ_FAIZ", 0);
			iMap.put("KARSI_FAIZ", 0);
			iMap.put("TRADING_PORTFOY", "false");
			iMap.put("ISTATISTIK_KODU", getIstatistikKodu(iMap, "1308"));
		}
		else if (serviceName.equalsIgnoreCase("MONEYMARKET")) {
			
			iMap.put("VALOR_TARIHI", islemValoru);
			iMap.put("DEAL_TARIHI", dealTarihi);
			iMap.put("VADE_TARIHI", islemZamani);
			//iMap.put("ISLEM_TURU", iMap.getString("ISLEM_TURU"));
			iMap.put("SPREAD_ORANI", 0);
			iMap.put("ANAPARA_ODEME_SEKLI", "VT");
			iMap.put("VADE_ISLEM_BILGISI", 1);
			iMap.put("FAIZ_SIKLIK_TIPI", "VT");
			iMap.put("FAIZ_HESAPLANACAK_TUTAR", "AT");
			iMap.put("SPREAD_ORANI", 0);
			iMap.put("GIRIS_HESAP_TURU", "MUHABIR");
			iMap.put("CIKIS_HESAP_TURU", "MUHABIR");
			iMap.put("DURUM_KODU", "A");
			iMap.put("NEGATIF_FAIZ", false);
			iMap.put("FAIZ_ORANI", iMap.getString("FAIZ_ORANI"));
			iMap.put("FAIZ_TUTARI", iMap.getBigDecimal("FAIZ_TUTARI"));
			iMap.put("GIRIS_HESAP_NO",iMap.getString("HESAP_NO"));
			iMap.put("CIKIS_HESAP_NO",iMap.getString("HESAP_NO"));
			iMap.put("GIRISMUSTERIMUHABIRNO",iMap.getString("MUHABIR_NO"));
			iMap.put("CIKISMUSTERIMUHABIRNO",iMap.getString("MUHABIR_NO"));
			iMap.put("URUN_SINIF_KOD", iMap.getString("URUN_SINIF_KOD"));
			iMap.put("TENOR", iMap.getString("TENOR"));
			iMap.put("URUN_TUR_KOD", iMap.getString("URUN_TUR_KOD"));
			iMap.put("ACIKLAMA", "Stp Money Market Provider Aktar�m ��lemi");
		}
			
	}

	private static void getDealorNo(GMMap iMap, GMMap oMap) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			String dealerNo = (String) iMap.getString("TRADER_REF");
			String platformAdi = (String) iMap.getString("SOURCE_PLATFORM");

			String dealerRegex = "%" + platformAdi + "-" + dealerNo + "%";

			conn = DALUtil.getGMConnection();
			ps = conn.prepareStatement("SELECT * FROM BNSPR.HZN_DEALER_KODLARI where PLATFORM_ID like ?");
			ps.setString(1, dealerRegex);
			rs = ps.executeQuery();

			boolean next = rs.next();

			if (rs == null || rs.getString("KOD") == null) {
				oMap.put("RESPONSE", "4");
				oMap.put("RESPONSE_DATA", "Gonderilen dealer icin (" + dealerNo + ") banka ici tan�mli bir kod bulunamadi.");
			}
			else {
				iMap.put("DEALER_NO", rs.getString("KOD"));
				iMap.put("DEALER_ACIKLAMA", rs.getString("ACIKLAMA"));

			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE", "4");
			oMap.put("RESPONSE_DATA", "Gonderilen dealer icin banka ici tan�mli bir kod bulunamadi.");
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(ps);
			GMServerDatasource.close(conn);

		}

	}

	private static void bankaKoduBul(GMMap iMap, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		String counterPartyId = (String) iMap.getString("COUNTER_PARTY");
		String platformAdi = (String) iMap.getString("SOURCE_PLATFORM");

		HznPlatformBankaKod platfromBankaKod = (HznPlatformBankaKod) session.createCriteria(HznPlatformBankaKod.class).add(Restrictions.eq("id.platformAdi", platformAdi)).add(Restrictions.eq("id.counterPartyId", counterPartyId)).uniqueResult();

		if (platfromBankaKod == null || platfromBankaKod.getId().getBankaKodu() == null) {
			oMap.put("RESPONSE", "5");
			oMap.put("RESPONSE_DATA", "Gonderilen counterPartyId (" + counterPartyId + ") icin tan�ml� banka kodu bulunamadi.");
		}
		else {
			iMap.put("PROVIDER_ADI", platfromBankaKod.getId().getBankaKodu());
		}

	}

	private static String getSpotUrunSinifKod(GMMap iMap) {

		iMap.put("XAU_SATIS_ONS_MU", "false");
		iMap.put("XAU_ALIS_ONS_MU", "false");
		String k�ymetliMadenList = getParamText("1306", "KIYMETLI_MADEN");

		if (iMap.getString("ALINAN_DOVIZ").equals("TRY")) {
			iMap.put("SATIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));
			if ((k�ymetliMadenList).contains(iMap.getString("SATILAN_DOVIZ"))) {
				return getParamText("1306", "URUN_SINIF_KODU", iMap.getString("AS") + iMap.getString("SATILAN_DOVIZ"));
			}
			else {
				return getParamText("1306", "URUN_SINIF_KODU", iMap.getString("AS") + iMap.getString("ALINAN_DOVIZ"));
			}
		}
		else if (iMap.getString("SATILAN_DOVIZ").equals("TRY")) {
			iMap.put("ALIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));
			if (k�ymetliMadenList.contains(iMap.getString("ALINAN_DOVIZ"))) {
				return getParamText("1306", "URUN_SINIF_KODU", iMap.getString("AS") + iMap.getString("ALINAN_DOVIZ"));
			}
			else {
				return getParamText("1306", "URUN_SINIF_KODU", iMap.getString("AS") + iMap.getString("SATILAN_DOVIZ"));
			}
		}
		else {
			if (k�ymetliMadenList.contains(iMap.getString("ALINAN_DOVIZ"))) {
				iMap.put("ALIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));

				if (iMap.getString("SATILAN_DOVIZ").equalsIgnoreCase("USD")) {
					iMap.put("XAU_ALIS_ONS_MU", "true");
				}

				return getParamText("1306", "URUN_SINIF_KODU", iMap.getString("ALINAN_DOVIZ") + "-ARBITRAJ");
			}
			else if (k�ymetliMadenList.contains(iMap.getString("SATILAN_DOVIZ"))) {
				iMap.put("SATIS_KUR", iMap.getBigDecimal("ISLEM_FIYATI"));

				if (iMap.getString("SATILAN_DOVIZ").equalsIgnoreCase("USD")) {
					iMap.put("XAU_SATIS_ONS_MU", "true");
				}

				return getParamText("1306", "URUN_SINIF_KODU", iMap.getString("SATILAN_DOVIZ") + "-ARBITRAJ");
			}
			else {
				iMap.put("SATIS_KUR", new BigDecimal(1));
				return getParamText("1306", "URUN_SINIF_KODU", "ARBITRAJ");
			}
		}

	}

	private static GMMap getSwapUrunSinifKod(GMMap iMap) {

		String k�ymetliMadenList = getParamText("1308", "KIYMETLI_MADEN");

		if (iMap.getString("ALINAN_DOVIZ").equals("TRY")) {

			iMap.put("URUN_SINIF_KOD", "TP/YP");
			iMap.put("ISLEM_SEKLI", "S");
			iMap.put("SPOT_SATIS_KUR", iMap.getBigDecimal("SPOT_ISLEM_FIYATI"));
			iMap.put("FORWARD_ALIS_KUR", iMap.getBigDecimal("FWD_ISLEM_FIYATI"));
			iMap.put("SPOT_ALIS_KUR", new BigDecimal("1.00000"));
			iMap.put("FORWARD_SATIS_KUR", new BigDecimal("1.00000"));

		}
		else if (iMap.getString("SATILAN_DOVIZ").equals("TRY")) {

			iMap.put("URUN_SINIF_KOD", "YP/TP");
			iMap.put("ISLEM_SEKLI", "A");
			iMap.put("SPOT_ALIS_KUR", iMap.getBigDecimal("SPOT_ISLEM_FIYATI"));
			iMap.put("FORWARD_SATIS_KUR", iMap.getBigDecimal("FWD_ISLEM_FIYATI"));
			iMap.put("SPOT_SATIS_KUR", new BigDecimal("1.00000"));
			iMap.put("FORWARD_ALIS_KUR", new BigDecimal("1.00000"));

		}
		else if (k�ymetliMadenList.contains(iMap.getString("ALINAN_DOVIZ"))) {

			iMap.put("URUN_SINIF_KOD", iMap.getString("ALINAN_DOVIZ") + "/YP");
			iMap.put("ISLEM_SEKLI", "A");
			iMap.put("SPOT_PARITE", iMap.getBigDecimal("SPOT_ISLEM_FIYATI"));
			iMap.put("FORWARD_PARITE", iMap.getBigDecimal("FWD_ISLEM_FIYATI"));
			iMap.put("SPOT_SATIS_KUR", new BigDecimal("0"));
			iMap.put("FORWARD_ALIS_KUR", new BigDecimal("0"));
			iMap.put("SPOT_ALIS_KUR", new BigDecimal("0"));
			iMap.put("FORWARD_SATIS_KUR", new BigDecimal("0"));

		}
		else if (k�ymetliMadenList.contains(iMap.getString("SATILAN_DOVIZ"))) {

			iMap.put("URUN_SINIF_KOD", "YP/" + iMap.getString("SATILAN_DOVIZ"));
			iMap.put("ISLEM_SEKLI", "A");
			iMap.put("SPOT_PARITE", iMap.getBigDecimal("SPOT_ISLEM_FIYATI"));
			iMap.put("FORWARD_PARITE", iMap.getBigDecimal("FWD_ISLEM_FIYATI"));
			iMap.put("SPOT_SATIS_KUR", new BigDecimal("0"));
			iMap.put("FORWARD_ALIS_KUR", new BigDecimal("0"));
			iMap.put("SPOT_ALIS_KUR", new BigDecimal("0"));
			iMap.put("FORWARD_SATIS_KUR", new BigDecimal("0"));

		}
		else {

			iMap.put("URUN_SINIF_KOD", "YP/YP");
			iMap.put("ISLEM_SEKLI", "A");
			iMap.put("SPOT_PARITE", iMap.getBigDecimal("SPOT_ISLEM_FIYATI"));
			iMap.put("FORWARD_PARITE", iMap.getBigDecimal("FWD_ISLEM_FIYATI"));
			iMap.put("SPOT_SATIS_KUR", new BigDecimal("0"));
			iMap.put("FORWARD_ALIS_KUR", new BigDecimal("0"));
			iMap.put("SPOT_ALIS_KUR", new BigDecimal("0"));
			iMap.put("FORWARD_SATIS_KUR", new BigDecimal("0"));

		}

		return iMap;

	}

	@SuppressWarnings("unchecked")
	private static GMMap musteriBilgileriGetir(GMMap iMap, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		BigDecimal musteriNo = null;
		List<HznBloombergBankaMust> alisHesapNo = (List<HznBloombergBankaMust>) session.createCriteria(HznBloombergBankaMust.class).add(Restrictions.eq("id.bankaKodu", iMap.getString("PROVIDER_ADI"))).add(Restrictions.eq("id.dovizKodu", iMap.getString("ALINAN_DOVIZ"))).add(Restrictions.eq("id.urunTurKod", iMap.getString("URUN_TUR_KOD"))).list();

		if (alisHesapNo != null && alisHesapNo.size() > 0) {
			if (alisHesapNo.get(0).getMuhabirHesapNo() != null) {
				iMap.put("ALIS_HESAP_NO", alisHesapNo.get(0).getMuhabirHesapNo());
			}
			else {
				oMap.put("RESPONSE", "6");
				oMap.put("RESPONSE_DATA", "Provider' �n " + iMap.getString("ALINAN_DOVIZ") + " hesab� yoktur.");
			}
			if (alisHesapNo.get(0).getMuhabir() != null) {
				iMap.put("ALIS_MUHABIR_MUSTERI_NO", alisHesapNo.get(0).getMuhabir());
			}
			else {
				oMap.put("RESPONSE", "6");
				oMap.put("RESPONSE_DATA", "Provider' �n " + iMap.getString("ALINAN_DOVIZ") + " muhabiri tan�ml� de�ildir.");
			}
			if (alisHesapNo.get(0).getBankaMusteriNo() != null)
				musteriNo = alisHesapNo.get(0).getBankaMusteriNo();
		}

		List<HznBloombergBankaMust> satisHesapNo = (List<HznBloombergBankaMust>) session.createCriteria(HznBloombergBankaMust.class).add(Restrictions.eq("id.bankaKodu", iMap.getString("PROVIDER_ADI"))).add(Restrictions.eq("id.dovizKodu", iMap.getString("SATILAN_DOVIZ"))).add(Restrictions.eq("id.urunTurKod", iMap.getString("URUN_TUR_KOD"))).list();

		if (satisHesapNo != null && satisHesapNo.size() > 0) {
			if (satisHesapNo.get(0).getMuhabirHesapNo() != null) {
				iMap.put("SATIS_HESAP_NO", satisHesapNo.get(0).getMuhabirHesapNo());
			}
			else {
				oMap.put("RESPONSE", "6");
				oMap.put("RESPONSE_DATA", "Provider' �n " + iMap.getString("SATILAN_DOVIZ") + " hesab� yoktur.");
			}
			if (satisHesapNo.get(0).getMuhabir() != null) {
				iMap.put("SATIS_MUHABIR_MUSTERI_NO", satisHesapNo.get(0).getMuhabir());
			}
			else {
				oMap.put("RESPONSE", "6");
				oMap.put("RESPONSE_DATA", "Provider' �n " + iMap.getString("SATILAN_DOVIZ") + " muhabiri tan�ml� de�ildir.");
			}
			if (satisHesapNo.get(0).getBankaMusteriNo() != null)
				musteriNo = satisHesapNo.get(0).getBankaMusteriNo();
		}

		if (musteriNo != null) {
			iMap.put("BANKA_MUSTERI_NO", musteriNo);
			iMap.put("BANKA_MUSTERI", musteriNo);

		}
		else {
			oMap.put("RESPONSE", "6");
			oMap.put("RESPONSE_DATA", "Provider' �n m��teri numaras� tan�ml� de�ildir.");
		}
		return iMap;
	}

	private static void getParite(GMMap iMap) {
		if (!iMap.getString("ALINAN_DOVIZ").equalsIgnoreCase("TRY") && !iMap.getString("SATILAN_DOVIZ").equalsIgnoreCase("TRY")) {
			iMap.put("PARITE", iMap.getBigDecimal("ISLEM_FIYATI"));
		}
	}

	private static Character durumKodu(String mesajStatusu) {
		if (mesajStatusu.equalsIgnoreCase("H")) {
			return 'I';
		}
		return 'A';
	}

	private static String getAlisSatis(GMMap iMap) {
		if (iMap.getString("ALINAN_DOVIZ").equals("TRY")) {
			return "S";
		}
		else if (iMap.getString("SATILAN_DOVIZ").equals("TRY")) {
			return "A";
		}
		else {
			return "A";
		}
	}

	private static Object getIstatistikKodu(GMMap iMap, String serviceCode) {
		return getParamText(serviceCode, "ISTATISTIK_KODU", iMap.getString("URUN_SINIF_KOD"));
	}

	private static String getParamText(String key, String key2, String key3) {
		return TreasuryUtil.getParamText("STP_SERVICE_PARAMETRELER", key, key2, key3);
	}

	private static String getParamText(String key, String key2) {
		return getParamText(key, key2, null);
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_STP_REPO_TERSREPO_TRADER_PROVIDER_AKTARIM")
	public static GMMap saveRepoIslem(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String serviceName = "REPO_TERSREPO";
			Date islemTarihi = null;
			String islemZamani = null;
			Date valor1 = null;
			Date valor2 = null;
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "");
			inputKontrol(iMap, oMap, serviceName);

			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_REPO_TERSREPO_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}

			islemZamani = ServiceUtil.checkTimeInput(oMap, iMap.getString("ISLEM_ZAMANI"), 2, "��lem Zaman� saat format� hatal�.");
			islemTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_TARIHI"), 2, "��lem Tarihi tarih format� hatal�.", false);
			valor1 = ServiceUtil.checkDateInput(oMap, iMap.getString("VALOR1"), 2, "Valor1 tarih format� hatal�.", false);
			valor2 = ServiceUtil.checkDateInput(oMap, iMap.getString("VALOR2"), 2, "Valor2 tarih format� hatal�.", false);
			int islemTarihiGun = getDayNumber(islemTarihi);
			int valor1Gun = getDayNumber(valor1);
			int valor2Gun = getDayNumber(valor2);
			
			System.out.println("Valor1 : "+valor1Gun +" Valor2 : " +valor2Gun +"��lem tarihi : " +islemTarihiGun);
			
			if (islemTarihiGun == 1 || islemTarihiGun == 7) {
				oMap.put("RESPONSE", 2);
				oMap.put("RESPONSE_DATA", "��lem Tarihi tatil g�n� olamaz");				
			}
			
			if (valor1Gun == 1 || valor1Gun == 7) {
				oMap.put("RESPONSE", 2);
				oMap.put("RESPONSE_DATA", "Valor1 tatil g�n� olamaz");				
			}
			
			if (valor2Gun == 1 || valor2Gun == 7) {
				oMap.put("RESPONSE", 2);
				oMap.put("RESPONSE_DATA", "Valor2 tatil g�n� olamaz");				
			}
			
			if (!oMap.getString("RESPONSE").equals("0")) {
				
				ServiceUtil.logAt("BNSPR_STP_REPO_TERSREPO_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
			/*Daha once bu id'lerle ilgili bir kay�t gelip gelmedi�ini kontrol edelim*/
			List<MenBistislemDefteriTx> menBistIslemDefteriTx = (List<MenBistislemDefteriTx>) session.createCriteria(MenBistislemDefteriTx.class)
					.add(Restrictions.eq("messageId", iMap.getString("MESSAGE_ID"))).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();
			List<MenBistislemDefteri> menBistIslemDefteri = (List<MenBistislemDefteri>) session.createCriteria(MenBistislemDefteri.class)
					.add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();

			if (menBistIslemDefteriTx != null && menBistIslemDefteriTx.size() > 0 || menBistIslemDefteri.size() > 0) {
				
				oMap.put("RESPONSE", "3");
				oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
				ServiceUtil.logAt("BNSPR_STP_REPO_TERSREPO_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
			
			MenBistislemDefteriTx menBistislemDefteriTx = new MenBistislemDefteriTx();
			MenBistislemDefteriTxId id = new MenBistislemDefteriTxId();
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setIslemTarihi(islemTarihi);
			
			if ((iMap.getString("ISLEM_NO") != null) && (!iMap.getString("ISLEM_NO").equals(""))) {
				
				id.setIslemNo(iMap.getString("ISLEM_NO"));
			}else {
				
				id.setIslemNo("1");
			}
			
			menBistislemDefteriTx.setId(id);
			menBistislemDefteriTx.setUye(iMap.getString("UYE"));
			menBistislemDefteriTx.setPazar(iMap.getString("PAZAR"));
			menBistislemDefteriTx.setPmHesabi(iMap.getString("PM_HESABI"));
			menBistislemDefteriTx.setTemsilciRef(iMap.getString("TEMSILCI_REF"));
			menBistislemDefteriTx.setAS(iMap.getString("A_S"));
			menBistislemDefteriTx.setKarsiUye(iMap.getString("KARSI_UYE"));
			menBistislemDefteriTx.setKarsiUyePm(iMap.getString("KARSI_UYE_PM"));
			menBistislemDefteriTx.setValor1(valor1);
			menBistislemDefteriTx.setValor2(valor2);
			menBistislemDefteriTx.setMkKod(iMap.getString("MK_KOD"));
			menBistislemDefteriTx.setRepoSuresi(getRepoSuresi(iMap,valor1,valor2));
			menBistislemDefteriTx.setFiyatOran(iMap.getBigDecimal("FIYAT_ORAN"));
			menBistislemDefteriTx.setGetiri(iMap.getBigDecimal("GETIRI"));
			menBistislemDefteriTx.setRepoMkFiyati(iMap.getBigDecimal("REPO_MK_FIYATI"));
			menBistislemDefteriTx.setMiktar(iMap.getBigDecimal("MIKTAR"));
			menBistislemDefteriTx.setTutar(iMap.getBigDecimal("TUTAR"));
			menBistislemDefteriTx.setIslemisFaiz(iMap.getBigDecimal("ISLEMIS_FAIZ"));
			menBistislemDefteriTx.setTemizFiyat(iMap.getBigDecimal("TEMIZ_FIYAT"));
			menBistislemDefteriTx.setIslemisFaizTutari(iMap.getBigDecimal("ISLEMIS_FAIZ_TUTARI"));
			menBistislemDefteriTx.setAnaparaTutari(iMap.getBigDecimal("ANAPARA_TUTARI"));
			menBistislemDefteriTx.setEnflasyonKatkisi(iMap.getBigDecimal("ENFLASYON_KATKISI"));
			menBistislemDefteriTx.setKirliFiyat(iMap.getBigDecimal("KIRLI_FIYAT"));
			menBistislemDefteriTx.setTakasFiyati(iMap.getBigDecimal("TAKAS_FIYATI"));
			menBistislemDefteriTx.setValor2Fiyati(iMap.getBigDecimal("VALOR2_FIYATI"));
			menBistislemDefteriTx.setParaBirimi(iMap.getString("PARA_BIRIMI"));
			menBistislemDefteriTx.setTakasMerkezi(iMap.getString("TAKAS_MERKEZI"));
			menBistislemDefteriTx.setBorsaPayi(iMap.getBigDecimal("BORSA_PAYI"));
			menBistislemDefteriTx.setAnaparaFaizStopaj(iMap.getBigDecimal("ANAPARA_FAIZ_STOPAJ"));
			menBistislemDefteriTx.setStopajTutari(iMap.getBigDecimal("STOPAJ_TUTARI"));
			menBistislemDefteriTx.setEmirNo(iMap.getString("EMIR_NO"));
			menBistislemDefteriTx.setKullanici(iMap.getString("KULLANICI"));
			menBistislemDefteriTx.setFonIslemi(iMap.getString("FON_ISLEMI"));
			menBistislemDefteriTx.setKurumiciSiraNo(iMap.getBigDecimal("KURUMICI_SIRA_NO"));
			menBistislemDefteriTx.setRepoMk(iMap.getString("REPO_MK"));
			menBistislemDefteriTx.setRepoMkNominal(iMap.getBigDecimal("REPO_MK_NOMINAL"));
			menBistislemDefteriTx.setIslemZamani(islemZamani);
			menBistislemDefteriTx.setEnstruman(iMap.getString("ENSTRUMAN"));
			menBistislemDefteriTx.setPazarIsmi(iMap.getString("PAZAR_ISMI"));
			menBistislemDefteriTx.setHesapTipi(iMap.getString("HESAP_TIPI"));
			menBistislemDefteriTx.setHesapNo(iMap.getString("HESAP_NO"));
			menBistislemDefteriTx.setKarsiHesapTipi(iMap.getString("KARSI_HESAP_TIPI"));
			menBistislemDefteriTx.setKkg(iMap.getBigDecimal("KKG"));
			menBistislemDefteriTx.setRepoFaizMiktari(iMap.getBigDecimal("REPO_FAIZ_MIKTARI"));
			menBistislemDefteriTx.setSeans(iMap.getString("SEANS"));
			menBistislemDefteriTx.setIslemTipi(iMap.getBigDecimal("ISLEM_TIPI"));
			menBistislemDefteriTx.setTakasIslemNo(iMap.getBigDecimal("TAKAS_ISLEM_NO"));
			menBistislemDefteriTx.setOncekiTakasIslemNo(iMap.getBigDecimal("ONCEKI_TAKAS_ISLEM_NO"));
			menBistislemDefteriTx.setOzelIslemBildirimi(iMap.getString("OZEL_ISLEM_BILDIRIMI"));
			menBistislemDefteriTx.setPiyasa(iMap.getString("PIYASA"));
			menBistislemDefteriTx.setOrderId(iMap.getString("ORDER_ID"));
			menBistislemDefteriTx.setMessageId(iMap.getString("MESSAGE_ID"));
			menBistislemDefteriTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
			menBistislemDefteriTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
			menBistislemDefteriTx.setCounterparty(iMap.getString("COUNTER_PARTY"));
			menBistislemDefteriTx.setOnaysizIslemMi("E");
			session.saveOrUpdate(menBistislemDefteriTx);
			session.flush();
			iMap.put("TRX_NAME", "1908");
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
			ServiceUtil.logAt("BNSPR_STP_REPO_TERSREPO_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				
			return oMap;
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_REPO_TERSREPO_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM")
	public static GMMap saveMoneyMarketIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String serviceName = "MONEYMARKET";
		Date nowDate = new Date();
		Date dealTarihi = null;
		Date vadeTarihi = null;
		Date valorTarihi = null;
		Date islemZamani = null;

		try {			
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "");
			inputKontrol(iMap, oMap, serviceName);
			
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
			
			dealTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("DEAL_TARIHI"), 2, "Deal tarih format� hatal�.", false);
			vadeTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("VADE_TARIHI"), 2, "Vade tarih format� hatal�.", false);
			valorTarihi = ServiceUtil.checkDateInput(oMap, iMap.getString("VALOR_TARIHI"), 2, "��lem Val�r� tarih format� hatal�.", false);
			islemZamani = ServiceUtil.checkDateInput(oMap, iMap.getString("ISLEM_ZAMANI"), 2, "��lem Zaman� tarih format� hatal�.", true);
			bankaKoduBul(iMap, oMap);
			getDealorNo(iMap, oMap);
			getEsasGunSayisi(iMap, oMap);
			getMusteriBilgileri(iMap, oMap);
			
			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
			
			getUrunSinifKod(iMap, oMap);
			getUrunTurKodAndTenor(iMap, valorTarihi, vadeTarihi);
			getIstatistikKod(iMap,oMap);
			getFaizTutari(iMap, oMap);

			if (!oMap.getString("RESPONSE").equals("0")) {
				ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
			
			if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("A")) {
				/*Yeni islem girisi*/
				if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("F")) {

					List<HznAlinandepoTx> hznAlinanDepoTx = (List<HznAlinandepoTx>) session.createCriteria(HznAlinandepoTx.class)
							.add(Restrictions.eq("messageId", iMap.getString("MESSAGE_ID"))).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();
					List<HznAlinandepo> hznAlinanDepo = (List<HznAlinandepo>) session.createCriteria(HznAlinandepo.class)
							.add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();

					if (hznAlinanDepoTx != null && hznAlinanDepoTx.size() > 0 || hznAlinanDepo.size() > 0) {
						oMap.put("RESPONSE", "3");
						oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}
					
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
					inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);
					GMServiceExecuter.execute("BNSPR_TRN1310_SAVE", iMap);
					iMap.put("TRX_NAME", "1310");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
					ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);

				}
				/*G�ncelleme i�lemi girisi*/
				else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("G")) {
					/*Guncellenmek istenen kayda ait daha �nce bir kay�t girilmi� mi konrol et*e
					/*Guncelleme iste�i sadece onay sonras�nda gelebilir --> Durum Kodu = A ,*/

					HznAlinandepo hznAlinanDepo = (HznAlinandepo) session.createCriteria(HznAlinandepo.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID")))
							.add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();
					
					if (hznAlinanDepo == null) {
						oMap.put("RESPONSE", "8");
						oMap.put("RESPONSE_DATA", "G�ncelleme iste�ine uygun bir kay�t bulunmuyor.");
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}

					inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);
					GMMap tMap = new GMMap();
					tMap.put("REF_NO", hznAlinanDepo.getReferans());
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1311_GET_TRANSFER_TXNO", tMap));
					iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
					iMap.put("REFERANS", hznAlinanDepo.getReferans());
					iMap.put("BANKA_HESAP_NO", hznAlinanDepo.getBankaHesapNo());
					GMServiceExecuter.execute("BNSPR_TRN1311_SAVE", iMap);
					iMap.put("TRX_NAME", "1311");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
					ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);

				}
				else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("H")) {

					HznAlinandepo hznAlinanDepo =(HznAlinandepo) session.createCriteria(HznAlinandepo.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID")))
						.add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();

					/*Onay sonras� iptal edilebilecek bir kay�t var*/
					if (hznAlinanDepo != null) {

						String tarih1 = getDate(hznAlinanDepo.getRecDate());
						String tarih2 = getDate(nowDate);
						inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);
						GMMap tMap = new GMMap();
						tMap.put("REF_NO", hznAlinanDepo.getReferans());
						iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1311_GET_TRANSFER_TXNO", tMap));
						iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
						iMap.put("REFERANS", hznAlinanDepo.getReferans());
						iMap.put("BANKA_HESAP_NO", hznAlinanDepo.getBankaHesapNo());
						if(tarih1.equals(tarih2)) {
							
							GMServiceExecuter.execute("BNSPR_TRN1310_SAVE", iMap);
							iMap.put("TRX_NAME", "1310");
						}
						else {
							GMServiceExecuter.execute("BNSPR_TRN1311_SAVE", iMap);
							iMap.put("TRX_NAME", "1311");
						}

						GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
						oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}

					//Onay �ncesi iptal edilecek bir kay�t var m� bakal�m

					HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx) session.createCriteria(HznAlinandepoTx.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID")))
							.add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();

					if (hznAlinanDepoTx != null) {
						hznAlinanDepoTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
						session.update(hznAlinanDepoTx);
						session.flush();

						GMMap onayMap = new GMMap();
						onayMap.put("ISLEM_TURU", "OR");
						onayMap.put("ISLEM_NO", hznAlinanDepoTx.getTxNo());
						onayMap.put("ACIKLAMA", "Stp Gun i�inde iptal iste�i");
						GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap);
						return oMap;
					}
					else {
						oMap.put("RESPONSE", "8");
						oMap.put("RESPONSE_DATA", "Iptal iste�ine uygun bir kay�t bulunmuyor.");
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}					
				
				}
				else {
					oMap.put("RESPONSE", "7");
					oMap.put("RESPONSE_DATA", "Mesaj statu bu de�erlerden biri olabilir. {F,G,H}");
					ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;
				}

			}
			
			
			else if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("S")) {
				/*Yeni islem girisi*/
				if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("F")) {

					List<HznVerilendepoTx> hznVerilendepoTx = (List<HznVerilendepoTx>) session.createCriteria(HznVerilendepoTx.class)
							.add(Restrictions.eq("messageId", iMap.getString("MESSAGE_ID"))).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();
					List<HznVerilendepo> hznVerilenDepo = (List<HznVerilendepo>) session.createCriteria(HznVerilendepo.class)
							.add(Restrictions.eq("orderId", iMap.getString("ORDER_ID"))).list();

					if (hznVerilendepoTx != null && hznVerilendepoTx.size() > 0 || hznVerilenDepo.size() > 0) {
						oMap.put("RESPONSE", "3");
						oMap.put("RESPONSE_DATA", "Bu i�lem daha �nce aktar�lm��t�r.");
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}
					
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
					inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);
					GMServiceExecuter.execute("BNSPR_TRN1313_SAVE", iMap);
					iMap.put("TRX_NAME", "1313");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
					ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				}
				
				/*G�ncelleme i�lemi girisi*/
				else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("G")) {
					/*Guncellenmek istenen kayda ait daha �nce bir kay�t girilmi� mi konrol et*e
					/*Guncelleme iste�i sadece onay sonras�nda gelebilir --> Durum Kodu = A ,*/

					HznVerilendepo hznVerilenDepo = (HznVerilendepo) session.createCriteria(HznVerilendepo.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID")))
							.add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();
					
					if (hznVerilenDepo == null) {
						oMap.put("RESPONSE", "8");
						oMap.put("RESPONSE_DATA", "G�ncelleme iste�ine uygun bir kay�t bulunmuyor.");
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}

					inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);
					GMMap tMap = new GMMap();
					tMap.put("REF_NO", hznVerilenDepo.getReferans());
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1314_GET_TRANSFER_TXNO", tMap));
					iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
					iMap.put("REFERANS", hznVerilenDepo.getReferans());
					iMap.put("BANKA_HESAP_NO", hznVerilenDepo.getBankaHesapNo());
					GMServiceExecuter.execute("BNSPR_TRN1314_SAVE", iMap);
					iMap.put("TRX_NAME", "1314");
					GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
					ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);

				}					
				
				else if (iMap.getString("MESAJ_STATU").equalsIgnoreCase("H")) {
							
					HznVerilendepo hznVerilenDepo =(HznVerilendepo) session.createCriteria(HznVerilendepo.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID")))
						.add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();
					
					//Onay sonras� iptal
					if (hznVerilenDepo != null) {
						
						String tarih1 = getDate(hznVerilenDepo.getRecDate());
						String tarih2 = getDate(nowDate);
						
						System.out.println("AktifSTPService.saveMoneyMarketIslem()" +"tarih1------------>" +tarih1);
						
						System.out.println("AktifSTPService.saveMoneyMarketIslem()" +"tarih2----------->" +tarih2);
						
						System.out.println("AktifSTPService.saveMoneyMarketIslem()" +"tarih1.hashCode()" +tarih1.hashCode());
					
						System.out.println("AktifSTPService.saveMoneyMarketIslem()" +"tarih2.hashCode()" +tarih2.hashCode());
						
						System.out.println("------------AktifSTPService.saveMoneyMarketIslem()" +"tarih1.contains(tarih2)------------>" +tarih1.contains(tarih2));
						
						System.out.println("-------------AktifSTPService.saveMoneyMarketIslem()"+"tarih1.equals(tarih2)------------->" +tarih1.equals(tarih2));
						
					
						
						inputHaz�rla(iMap, valorTarihi, vadeTarihi, dealTarihi, serviceName);
						GMMap tMap = new GMMap();
						tMap.put("REF_NO", hznVerilenDepo.getReferans());
						iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1314_GET_TRANSFER_TXNO", tMap));
						iMap.put("DURUM_KODU", durumKodu(iMap.getString("MESAJ_STATU")));
						iMap.put("REFERANS", hznVerilenDepo.getReferans());
						iMap.put("BANKA_HESAP_NO", hznVerilenDepo.getBankaHesapNo());
						

						
						if(tarih1.equals(tarih2)) {
							
							GMServiceExecuter.execute("BNSPR_TRN1313_SAVE", iMap);
							iMap.put("TRX_NAME", "1313");
						}
						else {
							GMServiceExecuter.execute("BNSPR_TRN1314_SAVE", iMap);
							iMap.put("TRX_NAME", "1314");
						}

						GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
						oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}

					//Onay �ncesi iptal

					HznVerilendepoTx hznVerilenDepoTx = (HznVerilendepoTx) session.createCriteria(HznVerilendepoTx.class).add(Restrictions.eq("orderId", iMap.getString("ORDER_ID")))
							.add(Restrictions.eq("durumKodu", "A")).add(Restrictions.eq("messageId", iMap.getString("ONCEKI_MESAJ_ID"))).uniqueResult();

					if (hznVerilenDepoTx != null) {
						hznVerilenDepoTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
						session.update(hznVerilenDepoTx);
						session.flush();
						GMMap onayMap = new GMMap();
						onayMap.put("ISLEM_TURU", "OR");
						onayMap.put("ISLEM_NO", hznVerilenDepoTx.getTxNo());
						onayMap.put("ACIKLAMA", "Stp Gun i�inde iptal iste�i");
						GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", onayMap);
						return oMap;
					}
					else {
						oMap.put("RESPONSE", "8");
						oMap.put("RESPONSE_DATA", "Iptal iste�ine uygun bir kay�t bulunmuyor.");
						ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
						return oMap;
					}					
			
				}
				else {
					oMap.put("RESPONSE", "7");
					oMap.put("RESPONSE_DATA", "Mesaj statu bu de�erlerden biri olabilir. {F,G,H}");
					ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
					return oMap;

				}
				
			}
			else {
				oMap.put("RESPONSE", "7");
				oMap.put("RESPONSE_DATA", "��lem tipi bu de�erlerden biri olabilir. {A,S}");
				ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, oMap);
				return oMap;
			}
			
			return oMap;			
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}

	private static void getFaizTutari(GMMap iMap, GMMap oMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal faizTutari = BigDecimal.ZERO;

			if (iMap.getBigDecimal("FAIZ_TUTARI") == null) {

				if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("A")) {

					String func = "{? = call pkg_trn1310.faiz_tutari_hesapla(?,?,?,?,?,?,?,?,?)}";
					Object[] inputValues = new Object[] { BnsprType.STRING, "VT", BnsprType.STRING, "VT", BnsprType.STRING, iMap.getString("DOVIZ_KODU"), 
							BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"), BnsprType.NUMBER, iMap.getBigDecimal("FAIZ_ORANI"), BnsprType.NUMBER, iMap.getBigDecimal("TENOR"), 
							BnsprType.NUMBER, iMap.getBigDecimal("ESAS_GUN_SAYISI"), BnsprType.STRING, "", BnsprType.STRING,"AT" };
					faizTutari = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
					iMap.put("FAIZ_TUTARI", faizTutari);

					if (faizTutari == BigDecimal.ZERO) {

						iMap.put("URUN_SINIF_KOD", "PAS");

						if (!iMap.getString("DOVIZ_KODU").equalsIgnoreCase("TRY")) {

							oMap.put("RESPONSE", "5");
							oMap.put("RESPONSE_DATA", "Faiz Oran� s�f�r olan i�lemler i�in;D�viz Kodu TRY olmal�d�r!");

						}
						else if (iMap.getInt("TENOR") != 0) {

							oMap.put("RESPONSE", "5");
							oMap.put("RESPONSE_DATA", "Faiz Oran� s�f�r olan i�lemler i�in;Valor Tarihi ve Vade Tarihi ayn� olmal�d�r!");
						}
						
						iMap.put("TENOR", "");
					}
				}

				else if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("S")) {

					String func = "{? = call pkg_trn1313.faiz_tutari_hesapla(?,?,?,?,?)}";
					Object[] inputValues = new Object[] { BnsprType.STRING, iMap.getString("DOVIZ_KODU"), BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"), BnsprType.NUMBER, iMap.getBigDecimal("FAIZ_ORANI"), BnsprType.NUMBER, iMap.getBigDecimal("TENOR"), BnsprType.NUMBER, iMap.getBigDecimal("ESAS_GUN_SAYISI") };
					faizTutari = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
					iMap.put("FAIZ_TUTARI", faizTutari);

					if ((faizTutari == BigDecimal.ZERO) && (iMap.getString("DOVIZ_KODU").equalsIgnoreCase("TRY"))) {

						iMap.put("URUN_SINIF_KOD", "PAS");
						iMap.put("TENOR", "");
					}
				}
			}
		}
		
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static void getIstatistikKod(GMMap iMap, GMMap oMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String code = null;
			String key = null;
			BigDecimal musteriNo = (BigDecimal)  iMap.getBigDecimal("BANKA_MUSTERI_NO");
			String urunTurKod = (String) iMap.getString("URUN_TUR_KOD");

			GnlMusteri gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();

			if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("A")) {

				code = "ADV_ISTATISTIK_KODLARI_1310";

				if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("D") && urunTurKod.equalsIgnoreCase("KRD KV")) {

					key = "YURT_DISI_BANKA_KV";
				}
				else if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("D") && urunTurKod.equalsIgnoreCase("KRD OV-UV")) {

					key = "YURT_DISI_BANKA_OUV";
				}
				else if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("I") && (urunTurKod.equalsIgnoreCase("KRD KV")) || urunTurKod.equalsIgnoreCase("KRD OV-UV")) {

					key = "YURT_ICI_PLASMAN";
				}
			}

			if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("S")) {

				code = "ADV_ISTATISTIK_KODLARI_1313";

				if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("I")) {

					key = "YURT_ICI_PLASMAN";
				}
				else if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("D")) {

					key = "YURT_DISI_PLASMAN";
				}
			}

			GnlParamText gnlParamText = (GnlParamText) session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", code)).add(Restrictions.eq("key1", key)).uniqueResult();

			if (gnlParamText == null || gnlParamText.getText() == null) {
				oMap.put("RESPONSE", "5");
				oMap.put("RESPONSE_DATA", "�statistik Kod bulunamad� !");
			}

			String istatistikKod = gnlParamText.getText();
			iMap.put("ISTATISTIK_KODU", istatistikKod);
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static void getMusteriBilgileri(GMMap iMap, GMMap oMap) {
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			String dovizKodu = (String) iMap.get("DOVIZ_KODU");
			String counterPartyId = (String) iMap.getString("PROVIDER_ADI");
			String urunTurKodu = "DEPO";

			HznBloombergBankaMust hznBloombergBankaMust = (HznBloombergBankaMust) session.createCriteria(HznBloombergBankaMust.class)
					.add(Restrictions.eq("id.dovizKodu", dovizKodu)).add(Restrictions.eq("id.bankaKodu", counterPartyId))
					.add(Restrictions.eq("id.urunTurKod", urunTurKodu)).uniqueResult();
			
			if (hznBloombergBankaMust == null || hznBloombergBankaMust.getId().getBankaKodu() == null) {
				
				oMap.put("RESPONSE", "5");
				oMap.put("RESPONSE_DATA", "Gonderilen counterPartyId (" + counterPartyId + ") ve doviz kodu (" + dovizKodu + ") icin tan�ml� Musteri Numaras� bulunamad� !");
			}else {
				iMap.put("BANKA_MUSTERI_NO", hznBloombergBankaMust.getBankaMusteriNo());
				iMap.put("HESAP_NO", (BigDecimal) hznBloombergBankaMust.getHesapNo());
				iMap.put("MUHABIR_NO", hznBloombergBankaMust.getMuhabir());
				iMap.put("ISLEM_TURU",iMap.getString("URUN_TUR_KOD"));
			}	
			
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	private static void getEsasGunSayisi(GMMap iMap, GMMap oMap) {		
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			String code = "DEPO_ESAS_GUN_SAYI";
			String key = (String) iMap.getString("DOVIZ_KODU");
			GnlParamText gnlParamText = (GnlParamText) session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", code))
					.add(Restrictions.eq("key1", key)).uniqueResult();
			
			if (gnlParamText == null || gnlParamText.getKod() == null) {
				
				iMap.put("ESAS_GUN_SAYISI", "360");
			}else {
				iMap.put("ESAS_GUN_SAYISI", (String) gnlParamText.getText());
			}			
		}		
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}	
	}
	
	private static void getUrunSinifKod(GMMap iMap, GMMap oMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("A")) {

				String dovizKodu = (String) iMap.get("DOVIZ_KODU");
				BigDecimal musteriNo = (BigDecimal) iMap.getBigDecimal("BANKA_MUSTERI_NO");
				GnlMusteri gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", musteriNo)).uniqueResult();

				if (gnlMusteri == null) {
					
					oMap.put("RESPONSE", "5");
					oMap.put("RESPONSE_DATA", "Gonderilen doviz kodu (" + dovizKodu + ") icin tan�ml� Urun Tur Kodu bulunamad� !");
				}

				else {							
					
					if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("I") && dovizKodu.equalsIgnoreCase("TRY")) {

						iMap.put("URUN_SINIF_KOD", "YURTICINDEN-TP");
					}
					
					else if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("D") && dovizKodu.equalsIgnoreCase("TRY")) {
						
						iMap.put("URUN_SINIF_KOD", "YURTDISINDAN-TP");
					}
					
					else if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("I") && !(((dovizKodu.equalsIgnoreCase("TRY")) || (dovizKodu.equalsIgnoreCase("XAU")) 
							|| (dovizKodu.equalsIgnoreCase("XAG")) || (dovizKodu.equalsIgnoreCase("XPD")) || (dovizKodu.equalsIgnoreCase("XPT"))))) {

						iMap.put("URUN_SINIF_KOD", "YURTICINDEN-YP");
					}
					
					else if (gnlMusteri.getYurtIciDisi().equalsIgnoreCase("D") && !((dovizKodu.equalsIgnoreCase("TRY") || (dovizKodu.equalsIgnoreCase("XAU")) 
							|| (dovizKodu.equalsIgnoreCase("XAG")) || (dovizKodu.equalsIgnoreCase("XPD")) || (dovizKodu.equalsIgnoreCase("XPT"))))) {

						iMap.put("URUN_SINIF_KOD", "YURTDISINDAN-YP");
					}
				}

			}else if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("S")) {
				
				Integer tenor = iMap.getInt("TENOR");
				
				if (tenor <= 360) {
					
					iMap.put("URUN_SINIF_KOD", "SERBEST KV");
				}else {				
					iMap.put("URUN_SINIF_KOD", "SERBEST OV-UV");
				}				
			}
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static void getUrunTurKodAndTenor(GMMap iMap, Date valorTarihi, Date vadeTarihi) {
		try {
			long fark = (vadeTarihi.getTime() - valorTarihi.getTime()) / (60 * 60 * 24 * 1000);			
			BigDecimal tenor = new BigDecimal(fark);
			
			if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("A")) {
				
				iMap.put("TENOR", tenor);
				
				if (fark <= 365) {
					
					iMap.put("URUN_TUR_KOD", "KRD KV");
				}
				else {				
					iMap.put("URUN_TUR_KOD", "KRD OV-UV");
				}
			}

			else if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("S")) {
				
				iMap.put("TENOR", tenor);

				if (iMap.getString("DOVIZ_KODU").equalsIgnoreCase("TRY")) {
					
					iMap.put("URUN_TUR_KOD", "NOSTRO-TP");
				}
				else {				
					iMap.put("URUN_TUR_KOD", "NOSTRO-YP");
				}
			}			
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static BigDecimal getRepoSuresi(GMMap iMap,Date valor1, Date valor2) {
		try {
		long fark = (valor2.getTime() - valor1.getTime()) / (60 * 60 * 24 * 1000);			
		BigDecimal repoSuresi = new BigDecimal(fark);
		return repoSuresi;
		}
		catch (Exception e) {
			ServiceUtil.logAt("BNSPR_STP_MONEYMARKET_TRADER_PROVIDER_AKTARIM", iMap, e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static int getDayNumber(Date date) {
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			return cal.get(Calendar.DAY_OF_WEEK);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static String getDate(Date date) {
		try {
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
		String tarih = df.format(date);
		return tarih;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
}