package tr.com.calikbank.bnspr.treasury.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ReutersEtMusteriListesiTx;
import tr.com.aktifbank.bnspr.dao.ReutersEtMusteriListesiTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1550Services {

	@GraymoundService("BNSPR_TRN1550_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUSTERI_LIST";

			List<?> recordList = (List<?>) iMap.get(tableName);
			
			/*
			 * - Controls - 
			 * 
			 * Ayni musteri no girilmesin
			 * TY-7398
			 */
			for (int row = 0; row < recordList.size(); row++) {
				Object musteriNo = iMap.get(tableName, row, "MUSTERI_NO");
				if (GuimlUtil.isDublicateKey(recordList, "MUSTERI_NO", musteriNo)) {
					GMMap myMap = new GMMap ();
                    myMap.put("MESSAGE_NO", new BigDecimal(4261));
                    myMap.put("P1", musteriNo);
                    throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
				}
				if(iMap.getString(tableName, row, "EMAIL") == null){
					TreasuryUtil.callErrorMessage("Email adresi bo� olamaz!");
				}
				if (!TreasuryUtil.validateEmail(iMap.getString(tableName, row, "EMAIL"))) {
					GMMap hata = new GMMap();
					hata.put("HATA_NO", 660);
					hata.put("P1", "Ge�erli bir mail adresi giriniz!");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", hata);
				}
			}
			

			/*
			 * - Save -
			 */
			for (int row = 0; row < recordList.size(); row++) {
				ReutersEtMusteriListesiTxId id = new ReutersEtMusteriListesiTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setMusteriNo(iMap.getBigDecimal(tableName, row, "MUSTERI_NO"));

				ReutersEtMusteriListesiTx reutersEtMusteriListesiTx = (ReutersEtMusteriListesiTx) session.get(
						ReutersEtMusteriListesiTx.class, id);

				if (reutersEtMusteriListesiTx == null) {
					reutersEtMusteriListesiTx = new ReutersEtMusteriListesiTx();
				}
				reutersEtMusteriListesiTx.setId(id);

				reutersEtMusteriListesiTx.setPlatformDovizKodu(iMap.getString(tableName, row, "PLATFORM_DOVIZ_KODU"));
				reutersEtMusteriListesiTx.setPlatformLimiti(iMap.getBigDecimal(tableName, row, "PLATFORM_LIMITI"));
				reutersEtMusteriListesiTx.setTeminatOrani(iMap.getBigDecimal(tableName, row, "TEMINAT_ORANI"));
				reutersEtMusteriListesiTx.setReutersBankId(iMap.getString(tableName, row, "REUTERS_BANK_ID"));
				reutersEtMusteriListesiTx.setHesapKontrol(iMap.getString(tableName, row, "HESAP_KONTROL"));
				reutersEtMusteriListesiTx.setEmail(iMap.getString(tableName, row, "EMAIL"));
				if (iMap.getBoolean(tableName, row, "SIL"))
					reutersEtMusteriListesiTx.setSilinsinMi("E");
				else
					reutersEtMusteriListesiTx.setSilinsinMi("H");
				session.saveOrUpdate(reutersEtMusteriListesiTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "1550");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1550_GET_MUSTERI_LIST")
	public static Map<?, ?> getMusteriList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1550.GET_MUSTERI_LISTE(?)}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName1 = "MUSTERI_LIST";
			for (int row = 0; rSet.next(); row++) {
				oMap.put(tableName1, row, "REUTERS_BANK_ID", rSet.getString("REUTERS_BANK_ID"));
				oMap.put(tableName1, row, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put(tableName1, row, "MUSTERI_ADI", rSet.getString("MUSTERI_ADI"));
				oMap.put(tableName1, row, "G_S", rSet.getString("G_S"));
				oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
				oMap.put(tableName1, row, "TEMINAT_ORANI", rSet.getString("TEMINAT_ORANI"));
				oMap.put(tableName1, row, "PLATFORM_LIMITI", rSet.getString("PLATFORM_LIMITI"));
				oMap.put(tableName1, row, "PLATFORM_DOVIZ_KODU", rSet.getString("PLATFORM_DOVIZ_KODU"));
				oMap.put(tableName1, row, "HESAP_KONTROL", rSet.getString("HESAP_KONTROL"));
				oMap.put(tableName1, row, "EMAIL", rSet.getString("EMAIL"));

			}

			return oMap;
		} catch (Exception e) {

			throw ExceptionHandler.convertException(e);

		} finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN1550_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		Connection conn = null;

		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TBL_MUSTERI_LIST";
			String colorTableName = "TBL_COLOR";

			List<?> list = session.createCriteria(ReutersEtMusteriListesiTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (int row = 0; row < list.size(); row++) {
				ReutersEtMusteriListesiTx reutersEtMusteriListesiTx = (ReutersEtMusteriListesiTx) list.get(row);

				oMap.put("TRX_NO", reutersEtMusteriListesiTx.getId().getTxNo());
				oMap.put(tableName, row, "REUTERS_BANK_ID", reutersEtMusteriListesiTx.getReutersBankId());
				oMap.put(tableName, row, "MUSTERI_NO", reutersEtMusteriListesiTx.getId().getMusteriNo());
				oMap.put(tableName, row, "MUSTERI_ADI",
						LovHelper.diLov(reutersEtMusteriListesiTx.getId().getMusteriNo(), "1550/LOV_MUSTERI_NO", "MUSTERI_ADI"));
				if (reutersEtMusteriListesiTx.getSilinsinMi().equals("E"))
					oMap.put(tableName, row, "SIL", true);
				else
					oMap.put(tableName, row, "SIL", false);
				oMap.put(tableName, row, "PLATFORM_LIMITI", reutersEtMusteriListesiTx.getPlatformLimiti());
				oMap.put(tableName, row, "PLATFORM_DOVIZ_KODU", reutersEtMusteriListesiTx.getPlatformDovizKodu());
				oMap.put(tableName, row, "TEMINAT_ORANI", reutersEtMusteriListesiTx.getTeminatOrani());
				oMap.put(tableName, row, "HESAP_KONTROL", reutersEtMusteriListesiTx.getHesapKontrol());
				oMap.put(tableName, row, "EMAIL", reutersEtMusteriListesiTx.getEmail());

				if ("E".equals(reutersEtMusteriListesiTx.getSilinsinMi())) {
					oMap.put(colorTableName, row, "REUTERS_BANK_ID", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "MUSTERI_NO", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "MUSTERI_ADI", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "PLATFORM_LIMITI", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "PLATFORM_DOVIZ_KODU", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "TEMINAT_ORANI", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "HESAP_KONTROL", getTableCellColorData(Color.RED));
					oMap.put(colorTableName, row, "EMAIL", getTableCellColorData(Color.RED));
				} else {
					oMap.put(colorTableName, row, "REUTERS_BANK_ID", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "MUSTERI_NO", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "MUSTERI_ADI", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "PLATFORM_LIMITI", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "PLATFORM_DOVIZ_KODU", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "TEMINAT_ORANI", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "HESAP_KONTROL", getTableCellColorData(Color.WHITE));
					oMap.put(colorTableName, row, "EMAIL", getTableCellColorData(Color.WHITE));
				}

			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(conn);
		}

	}

	private static GMMap getTableCellColorData(Color backgroundColor) {
		GMMap oMap = new GMMap();
		oMap.put("setBackground", backgroundColor);
		return oMap;
	}
}
