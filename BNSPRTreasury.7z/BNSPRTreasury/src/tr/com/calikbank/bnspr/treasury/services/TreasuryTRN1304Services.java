package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.NostroHesapList;
import tr.com.aktifbank.bnspr.dao.YpHavaleGelenSwift;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznBankaTransTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.PaygateConstants;
import tr.com.paygate.ArrayOfInstanceGroup;
import tr.com.paygate.ArrayOfSearchRequest;
import tr.com.paygate.DetailLevel;
import tr.com.paygate.InstanceGroup;
import tr.com.paygate.SearchRequest;
import tr.com.paygate.SearchType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1304Services {

	@GraymoundService("BNSPR_TRN1304_SAVE")
	public static Map<?, ?> Save(GMMap iMap) {
		List<SearchRequest> searchRequestList = new ArrayList<SearchRequest>();
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			HznBankaTransTx hznBankaTransTx = (HznBankaTransTx) session.get(HznBankaTransTx.class, iMap.getBigDecimal("TRX_NO"));

			if (hznBankaTransTx == null) {
				hznBankaTransTx = new HznBankaTransTx();

			}

			hznBankaTransTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznBankaTransTx.setGirisMuhabirMusterino(iMap.getBigDecimal("GIRIS_MBANKA_MUSTERINO"));
			hznBankaTransTx.setGirisMuhabirHesapno(iMap.getBigDecimal("GIRIS_MBANKA_HESAPNO"));
			hznBankaTransTx.setCikisMuhabirMusterino(iMap.getBigDecimal("CIKIS_MBANKA_MUSTERINO"));
			hznBankaTransTx.setCikisMuhabirHesapno(iMap.getBigDecimal("CIKIS_MBANKA_HESAPNO"));
			hznBankaTransTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznBankaTransTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznBankaTransTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznBankaTransTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznBankaTransTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznBankaTransTx.setFNostroVostro(iMap.getString("NOSTRO_VOSTRO"));
			hznBankaTransTx.setGbankaReferans(iMap.getString("BANKA_REFERANS"));
			hznBankaTransTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP"));
			hznBankaTransTx.setMasrafTahsilDoviz(iMap.getString("MASRAF_DOVIZ"));
			hznBankaTransTx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTAR"));
			hznBankaTransTx.setNihaiAliciBic(iMap.getString("NIHAI_ALICI"));
			hznBankaTransTx.setMasrafIcDis(iMap.getString("MASRAF_IC_DIS"));
			hznBankaTransTx.setNihaiAliciHesapno(iMap.getString("NIHAI_ALICI_HESAPNO"));
			hznBankaTransTx.setAraciBankaBic(iMap.getString("ARACI_BANKA_BIC"));
			hznBankaTransTx.setCikisMuhabirBic(iMap.getString("CIKIS_MUHABIR_BIC"));
			hznBankaTransTx.setGirisMuhabirBic(iMap.getString("GIRIS_MUHABIR_BIC"));
			hznBankaTransTx.setGelenSwiftId(iMap.getString("GELEN_SWIFT_ID"));
			hznBankaTransTx.setMt200202(iMap.getString("MT200_202"));
			hznBankaTransTx.setAliciBic(iMap.getString("ALICI_BIC"));
			hznBankaTransTx.setAliciHesapno(iMap.getString("ALICI_HESAPNO"));
			hznBankaTransTx.setNihaiBanka(iMap.getString("NIHAI_BANKA"));
			hznBankaTransTx.setMasrafHesapNo2(iMap.getBigDecimal("MASRAF_HESAP_2"));
			hznBankaTransTx.setMasrafTahsilDoviz2(iMap.getString("MASRAF_DOVIZ_2"));
			hznBankaTransTx.setMasrafTutari2(iMap.getBigDecimal("MASRAF_TUTAR_2"));
			hznBankaTransTx.setMasrafIcDis2(iMap.getString("MASRAF_IC_DIS_2"));

			session.saveOrUpdate(hznBankaTransTx);
			session.flush();

			ArrayOfSearchRequest arrayOfSearchRequest = new ArrayOfSearchRequest();

			if (StringUtils.isNotBlank(iMap.getString("GIRIS_MBANKA_MUSTERI_ADI"))) {
				SearchRequest srField = new SearchRequest();
				srField.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_ALL, SearchType.GENERIC_NAME));
				srField.setValue(iMap.getString("GIRIS_MBANKA_MUSTERI_ADI"));
				searchRequestList.add(srField);
			}
			if (StringUtils.isNotBlank(iMap.getString("CIKIS_MBANKA_MUSTERI_ADI"))) {
				SearchRequest srField = new SearchRequest();
				srField.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_ALL, SearchType.GENERIC_NAME));
				srField.setValue(iMap.getString("CIKIS_MBANKA_MUSTERI_ADI"));
				searchRequestList.add(srField);
			}
			if (StringUtils.isNotBlank(iMap.getString("ARACI_BANKA_BIC"))) {
				SearchRequest srField = new SearchRequest();
				srField.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_ALL, SearchType.GENERIC_NAME));
				srField.setValue(iMap.getString("ARACI_BANKA_BIC"));
				searchRequestList.add(srField);
			}
			if (StringUtils.isNotBlank(iMap.getString("ALICI_BIC"))) {
				SearchRequest srField = new SearchRequest();
				srField.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_ALL, SearchType.GENERIC_NAME));
				srField.setValue(iMap.getString("ALICI_BIC"));
				searchRequestList.add(srField);
			}
			if (StringUtils.isNotBlank(iMap.getString("NIHAI_ALICI"))) {
				SearchRequest srField = new SearchRequest();
				srField.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_ALL, SearchType.GENERIC_NAME));
				srField.setValue(iMap.getString("NIHAI_ALICI"));
				searchRequestList.add(srField);
			}
			if (StringUtils.isNotBlank(iMap.getString("NIHAI_BANKA"))) {
				SearchRequest srField = new SearchRequest();
				srField.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_ALL, SearchType.GENERIC_NAME));
				srField.setValue(iMap.getString("NIHAI_BANKA"));
				searchRequestList.add(srField);
			}

			arrayOfSearchRequest.getSearchRequest().addAll(searchRequestList);

			GMMap amlMap = new GMMap();
			amlMap.put("TRX_NAME", "1304");
			amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			amlMap.put("SEARCH_REQUEST_LIST", arrayOfSearchRequest);

			GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_BULK_DATA", amlMap);

			GMMap oMap = new GMMap();

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_TRANSACTION_START")
	public static Map<?, ?> trn1306Transactionstart(GMMap iMap) {

		try {
			iMap.put("TRX_NAME", "1304");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznBankaTransTx hznBankaTransTx = (HznBankaTransTx) session.get(HznBankaTransTx.class, txNo);
			System.out.println("sxsasa" + txNo);

			oMap.put("TX_NO", hznBankaTransTx.getTxNo());
			oMap.put("REF_NO", hznBankaTransTx.getRefNo());
			oMap.put("GIRIS_MBANKA_MUSTERINO", hznBankaTransTx.getGirisMuhabirMusterino());
			oMap.put("GIRIS_MBANKA_ADI", LovHelper.diLov(hznBankaTransTx.getGirisMuhabirMusterino(), "1304/LOV_MBANKA_MUSTERI_NO", "UNVAN"));

			oMap.put("GIRIS_MBANKA_HESAPNO", hznBankaTransTx.getGirisMuhabirHesapno());
			oMap.put("CIKIS_MBANKA_MUSTERINO", hznBankaTransTx.getCikisMuhabirMusterino());
			oMap.put("CIKIS_MBANKA_HESAPNO", hznBankaTransTx.getCikisMuhabirHesapno());

			oMap.put("CIKIS_MBANKA_ADI", LovHelper.diLov(hznBankaTransTx.getCikisMuhabirMusterino(), "1304/LOV_CIKIS_MBANKA_MUSTERINO", "UNVAN"));
			oMap.put("DEALER_NO", hznBankaTransTx.getDealerNo());
			oMap.put("DEALER_ISIM", LovHelper.diLov(hznBankaTransTx.getDealerNo(), "1304/LOV_DEALER", "ISIM"));

			oMap.put("DOVIZ_KODU", hznBankaTransTx.getDovizKodu());
			oMap.put("di_DOVIZ_KODU", LovHelper.diLov(hznBankaTransTx.getDovizKodu(), "1304/LOV_DOVIZ_KODU", "ACIKLAMA"));

			oMap.put("TUTAR", hznBankaTransTx.getTutar());
			oMap.put("VALOR_TARIHI", hznBankaTransTx.getValorTarihi());
			oMap.put("ACIKLAMA", hznBankaTransTx.getAciklama());
			oMap.put("DURUM_KODU", hznBankaTransTx.getDurumKodu());

			oMap.put("N_V", hznBankaTransTx.getFNostroVostro());
			oMap.put("BANKA_REFERANS", hznBankaTransTx.getGbankaReferans());
			oMap.put("MASRAF_DOVIZ", hznBankaTransTx.getMasrafTahsilDoviz());
			oMap.put("MASRAF_THSL_DVZ_ADI", LovHelper.diLov(hznBankaTransTx.getMasrafTahsilDoviz(), hznBankaTransTx.getMasrafTahsilDoviz(), "1304/LOV_MASRAF_THSL_DVZ", "ACIKLAMA"));
			oMap.put("MASRAF_HESAP", hznBankaTransTx.getMasrafHesapNo());
			oMap.put("MASRAF_TUTAR", hznBankaTransTx.getMasrafTutari());
			oMap.put("NIHAI_ALICI", hznBankaTransTx.getNihaiAliciBic());
			oMap.put("NIHAI_ALICI_ADI", LovHelper.diLov(hznBankaTransTx.getNihaiAliciBic(), "1304/LOV_ALICININ_BANKASI_BIC", "UNVAN"));
			oMap.put("NIHAI_BANKA", hznBankaTransTx.getNihaiBanka());
			oMap.put("MASRAF_IC_DIS", hznBankaTransTx.getMasrafIcDis());

			oMap.put("MASRAF_DOVIZ_2", hznBankaTransTx.getMasrafTahsilDoviz());
			oMap.put("MASRAF_THSL_DVZ_ADI_2", LovHelper.diLov(hznBankaTransTx.getMasrafTahsilDoviz(), hznBankaTransTx.getMasrafTahsilDoviz(), "1304/LOV_MASRAF_THSL_DVZ", "ACIKLAMA"));
			oMap.put("MASRAF_HESAP_2", hznBankaTransTx.getMasrafHesapNo2());
			oMap.put("MASRAF_TUTAR_2", hznBankaTransTx.getMasrafTutari2());
			oMap.put("MASRAF_IC_DIS_2", hznBankaTransTx.getMasrafIcDis2());

			oMap.put("ARACI_BANKA", hznBankaTransTx.getAraciBankaBic());
			oMap.put("NIHAI_ALICI_HESAP", hznBankaTransTx.getNihaiAliciHesapno());
			oMap.put("GIRIS_MUHABIR_BIC", hznBankaTransTx.getGirisMuhabirBic());
			oMap.put("CIKIS_MUHABIR_BIC", hznBankaTransTx.getCikisMuhabirBic());
			oMap.put("MT200_202", hznBankaTransTx.getMt200202());

			oMap.put("ALICI_BIC", hznBankaTransTx.getAliciBic());
			oMap.put("ALICI_ADI", LovHelper.diLov(hznBankaTransTx.getAliciBic(), "1304/LOV_ALICININ_BANKASI_BIC", "UNVAN"));
			oMap.put("ALICI_HESAP", hznBankaTransTx.getAliciHesapno());

			GMMap xMap = new GMMap();
			xMap.put("HESAP_NO", hznBankaTransTx.getGirisMuhabirHesapno());
			oMap.put("GIRIS_HESAP_BAKIYE", GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", xMap).get("KULLANILABILIR_BAKIYE"));
			GMMap zMap = new GMMap();
			zMap.put("HESAP_NO", hznBankaTransTx.getCikisMuhabirHesapno());
			oMap.put("CIKIS_HESAP_BAKIYE", GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", zMap).get("KULLANILABILIR_BAKIYE"));

			String gelenSwiftId = hznBankaTransTx.getGelenSwiftId();

			if (gelenSwiftId != null && !gelenSwiftId.isEmpty()) {
				YpHavaleGelenSwift ypHavaleGelenSwift = (YpHavaleGelenSwift) session.get(YpHavaleGelenSwift.class, gelenSwiftId);
				if (ypHavaleGelenSwift != null) {
					oMap.put("GELENSWIFTID", gelenSwiftId);
					oMap.put("GELENSWIFTTUR", "MT" + ypHavaleGelenSwift.getMessageType());
				}

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_DEALER_KOD_AL")
	public static GMMap getdealKodAl(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_HAZINE.DealerKodAl(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();

			oMap.put("DEALER_NO", stmt.getString(1));
			oMap.put("DEALER_UNVAN", stmt.getString(2));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

	}

	@GraymoundService("BNSPR_TRN1304_SAVE_MASRAF")
	public static HashMap<String, Object> saveMasraf(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			int i = 1;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_MASRAF_YENI.MASRAF_YARAT(?,?,?,?,?,?,?)}");
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			String hesapNo = iMap.getString("HESAP_NO");
			if (hesapNo == null || hesapNo.equals("")) {
				stmt.setBigDecimal(i++, null);
				stmt.setString(i++, null);
			}
			else {
				stmt.setBigDecimal(i++, (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO", iMap).get("MUSTERI_NO"));
				stmt.setString(i++, iMap.getString("HESAP_NO"));
			}
			stmt.setString(i++, iMap.getString("ALICI_HESAP"));
			stmt.execute();
			return new HashMap<String, Object>();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1304_MUKERRER_KONTROLU")
	public static GMMap MukerrerKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1304.Mukerrer_Kontrolu(?,?,?,?,?,?,?,?) }");

			int i = 1;
			stmt.setBigDecimal(1, iMap.getBigDecimal("CIKIS_MUHABIR_NO"));
			stmt.setString(2, iMap.getString("GBANKA_REF"));
			stmt.setString(3, iMap.getString("DOVIZ"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("TUTAR"));
			if (iMap.getDate("VALOR") == null)
				stmt.setDate(5, null);
			else
				stmt.setDate(5, new java.sql.Date(iMap.getDate("VALOR").getTime()));
			stmt.setBigDecimal(6, iMap.getBigDecimal("GIRIS_MUHABIR_NO"));
			stmt.setString(8, iMap.getString("TRX_NO"));
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);

			stmt.execute();

			oMap.put("REFERANS", stmt.getString(7));
			oMap.put("ISLEMNO", stmt.getString(8));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("BNSPR_TRN1304_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();

			if ("EDIT".equals(iMap.getString("ACTION"))) { // ��lem geri �evirildiyse �nceki olu�turulan swiftleri sil
				try {
					stmt = conn.prepareCall("{call PKG_SWIFT.Swift_Sil(?,?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
					stmt.setString(2, null);
					stmt.execute();
				}
				catch (Exception e) {
					System.out.println("TRN1304 swift sil hata, tx no:" + iMap.getBigDecimal("TRX_NO") + "referans:" + iMap.getString("REFERANS"));
					e.printStackTrace();
				}
				finally {
					GMServerDatasource.close(stmt);
				}
			}

			stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_900910_olustur(?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			if (iMap.getBoolean("MT_200") || iMap.getBoolean("MT_202")) {
				GMServerDatasource.close(stmt);
				stmt = conn.prepareCall("{call PKG_SWIFT.Swift_Olustur(?,?,?,?)}");

				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				if (iMap.getBoolean("MT_200")) {
					stmt.setString(3, "200");
				}
				else if (iMap.getBoolean("MT_202")) {
					stmt.setString(3, "202");
				}
				stmt.setString(4, null); // iMap.getString("REFERANS")
				stmt.execute();
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1304_MASRAF_DK_AL")
	public static GMMap getMasrafDK(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			if (iMap.getString("DK_AL_2") == null || iMap.getString("DK_AL_2").equalsIgnoreCase("false")) {

				if ("I".equals(iMap.getString("MASRAF_IC_DIS"))) {
					BigDecimal DKHesap1 = new BigDecimal(DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('1304_MASRAF_DK_TRY')}", Types.NUMERIC).toString());
					BigDecimal DKHesap2 = new BigDecimal(DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('1304_MASRAF_DK_YP')}", Types.NUMERIC).toString());

					if ("TRY".equals(iMap.getString("DOVIZ"))) {
						oMap.put("DK_HESAP", DKHesap1);
					}
					else
						oMap.put("DK_HESAP", DKHesap2);
				}
			}
			else {
				if ("I".equals(iMap.getString("MASRAF_IC_DIS"))) {
					BigDecimal DKHesap1 = new BigDecimal(DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('1304_MASRAF_DK_TRY_2')}", Types.NUMERIC).toString());
					BigDecimal DKHesap2 = new BigDecimal(DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('1304_MASRAF_DK_YP_2')}", Types.NUMERIC).toString());

					if ("TRY".equals(iMap.getString("DOVIZ"))) {
						oMap.put("DK_HESAP", DKHesap1);
					}
					else
						oMap.put("DK_HESAP", DKHesap2);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

	}

	@GraymoundService("BNSPR_TRN1304_GET_MASRAF_YENI")
	public static GMMap saveMasrafYeni(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = GMServiceExecuter.call("BNSPR_TRN1171_MASRAF_KOMISYON_GETIR", iMap);
			setMasrafHesap(iMap, oMap);

			return oMap;
		}
		catch (GMRuntimeException e) {
			if (e.getMessage().contains("Masraf Kayd� Bulunamad�")) { // Masraf kayd� bulunamad�
				setMasrafHesap(iMap, iMap);
				iMap.put("HATA_NO", "264");
				iMap.put("MESSAGE", e.getMessage());
				return iMap;
			}
			else {
				throw e;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_GET_MASRAF_VOSTRO")
	public static GMMap saveMasrafVostro(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = GMServiceExecuter.call("BNSPR_TRN1171_MASRAF_KOMISYON_GETIR", iMap);
			setMasrafHesapVostro(iMap, oMap);

			return oMap;
		}
		catch (GMRuntimeException e) {
			if (e.getMessage().contains("Masraf Kayd� Bulunamad�")) { // Masraf kayd� bulunamad�
				setMasrafHesapVostro(iMap, iMap);
				iMap.put("HATA_NO", "264");
				iMap.put("MESSAGE", e.getMessage());
				return iMap;
			}
			else {
				throw e;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_TRNSFR_MASRAF_TANIMLI")
	public static GMMap trnsfrMasrafTanimliMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap tMap = GMServiceExecuter.call("BNSPR_TRN1171_MASRAF_KOMISYON_GETIR", iMap);
			if (tMap.getBigDecimal("MASRAF_TUTAR") != null) {
				oMap.put("MASRAF_TANIMLI", "E");
			}
			else {
				oMap.put("MASRAF_TANIMLI", "H");
			}
		}
		catch (Exception e) {
			oMap.put("MASRAF_TANIMLI", "H");
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1304_MT900_MASRAF_TANIMLI")
	public static GMMap mt900910MasrafTanimliMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1304.MT900910MasrafTanimliMi(?,?,?,?,?,?) }");

			stmt.setBigDecimal(1, iMap.getBigDecimal("GIRIS_MBANKA_MUSTERINO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("GIRIS_MBANKA_HESAPNO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("CIKIS_MBANKA_MUSTERINO"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("CIKIS_MBANKA_HESAPNO"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("ISLEM_TUTARI"));
			stmt.setString(6, iMap.getString("ISLEM_DOVIZ"));

			stmt.execute();
			oMap.put("MASRAF_TANIMLI", "E"); // Masraf tan�ml� veya MT900-910 g�ndermeye gerek yok.
		}
		catch (Exception e) {
			oMap.put("MASRAF_TANIMLI", "H"); // MT900-910 g�nderilecek ama masraf tan�m� yap�lmam��.
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1304_GELEN_SWIFT_BILGI_AL")
	public static GMMap gelenSwiftBilgiAl(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			String swiftId = iMap.getString("GELEN_SWIFT_ID");
			Session session = DAOSession.getSession("BNSPRDal");
			YpHavaleGelenSwift gelenSwift = (YpHavaleGelenSwift) session.get(YpHavaleGelenSwift.class, swiftId);

			if (gelenSwift != null) {
				oMap.put("DOVIZ_KODU", gelenSwift.getDovizKodu());
				oMap.put("TUTAR", gelenSwift.getTutar());
				oMap.put("VALOR_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
				// oMap.put("VALOR_TARIHI", gelenSwift.getValorTarihi()); val�r tarihine banka tarihini atmam�z istendi (G�zde Yumruta�lar)
				oMap.put("REFERANS", gelenSwift.getGbankaReferans());
				oMap.put("GONDEREN_BANKA_BIC", gelenSwift.getGonderenBicKodu());
				oMap.put("ARACI_BANKA", gelenSwift.getAraciBicKodu());
				oMap.put("NIHAI_ALICI", gelenSwift.getNihaiAliciBic());
				oMap.put("NIHAI_ALICI_HESAP", gelenSwift.getNihaiAliciHesapNo());

				if ("910".equals(gelenSwift.getMessageType())) {
					oMap.put("GONDEREN_BANKA_MUSTNO", gelenSwift.getMbankaMusteriNo());
					oMap.put("GONDEREN_BANKA_HESAPNO", gelenSwift.getMbankaHesapNo());
					oMap.put("GONDEREN_BANKA_BIC", gelenSwift.getGbankaBicKodu());
				}
				else if (gelenSwift.getGonderenBicKodu() != null && gelenSwift.getGonderenBicKodu().length() > 0) {
					BigDecimal mustNo = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_trn1304.get_mustno_from_bic(?)}", Types.NUMERIC, gelenSwift.getGonderenBicKodu());
					if (mustNo != null) {
						oMap.put("GONDEREN_BANKA_MUSTNO", mustNo);
						if (gelenSwift.getDovizKodu() != null && gelenSwift.getDovizKodu().length() > 0) {
							Object[] inputValues = new Object[4];
							inputValues[0] = BnsprType.NUMBER;
							inputValues[1] = mustNo;
							inputValues[2] = BnsprType.STRING;
							inputValues[3] = gelenSwift.getDovizKodu();
							BigDecimal hesapNo = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_trn1304.get_cikis_mbanka_hesap(?,?)}", BnsprType.NUMBER, inputValues);
							if (hesapNo != null) {
								oMap.put("GONDEREN_BANKA_HESAPNO", hesapNo);
							}
						}
					}
				}

				String girisMuhabirBic = gelenSwift.getAliciBicKodu();
				String girisMuhabirHesap = gelenSwift.getAliciIbanNo();
				if (girisMuhabirHesap != null && girisMuhabirHesap.startsWith("TR")) { // IBAN
					Map map = new GMMap();
					map.put("IBAN", girisMuhabirHesap);
					Long accNo = (Long) GMServiceExecuter.execute("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", map).get("ACCOUNT_NO");
					if (accNo.longValue() != 0) {
						girisMuhabirHesap = accNo.toString();
					}
					else {
						girisMuhabirHesap = ""; // IBAN bizde tan�ml� de�il
					}
				}
				oMap.put("GIRIS_MUHABIR_BIC", girisMuhabirBic);
				oMap.put("GIRIS_MUHABIR_HESAP", girisMuhabirHesap);
				if (girisMuhabirBic != null && girisMuhabirBic.length() > 0) {
					BigDecimal girisMuhabirMust = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_trn1304.get_mustno_from_bic(?)}", Types.NUMERIC, girisMuhabirBic);
					oMap.put("GIRIS_MUHABIR_MUST", girisMuhabirMust);
				}
				else {
					girisMuhabirBic = gelenSwift.getNihaiAliciBic();
					girisMuhabirHesap = gelenSwift.getNihaiAliciHesapNo();
					if (girisMuhabirHesap != null && girisMuhabirHesap.startsWith("TR")) { // IBAN
						Map map = new GMMap();
						map.put("IBAN", girisMuhabirHesap);
						Long accNo = (Long) GMServiceExecuter.execute("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", map).get("ACCOUNT_NO");
						if (accNo.longValue() != 0) {
							girisMuhabirHesap = accNo.toString();
						}
						else {
							girisMuhabirHesap = ""; // IBAN bizde tan�ml� de�il
						}
					}
					oMap.put("GIRIS_MUHABIR_BIC", girisMuhabirBic);
					oMap.put("GIRIS_MUHABIR_HESAP", girisMuhabirHesap);
					if (girisMuhabirBic != null && girisMuhabirBic.length() > 0) {
						BigDecimal girisMuhabirMust = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_trn1304.get_mustno_from_bic(?)}", Types.NUMERIC, girisMuhabirBic);
						oMap.put("GIRIS_MUHABIR_MUST", girisMuhabirMust);
					}
				}
				// M��teri ve hesap no bo�sa, ekrana BIC kodu da getirmesin
				String gMuhMust = oMap.getString("GIRIS_MUHABIR_MUST");
				String gMuhHesap = oMap.getString("GIRIS_MUHABIR_HESAP");
				if ((gMuhMust == null || gMuhMust.length() == 0) && (gMuhHesap == null || gMuhHesap.length() == 0)) {
					oMap.put("GIRIS_MUHABIR_BIC", "");
				}

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_GET_BIC_FROM_MUSTNO")
	public static GMMap getBicFromMustNo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			oMap.put("MUSTERI_BIC", DALUtil.callOneParameterFunction("{? = call pkg_musteri.bic_kod(?)}", Types.VARCHAR, iMap.getBigDecimal("MUSTERI_NO")));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1304_NIHAI_ALICI_HESAP_GETIR")
	public static GMMap nihaiAliciHesapBul(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			BigDecimal musteriNo = iMap.getBigDecimal("GIRIS_MUST_NO");
			BigDecimal hesapNo = iMap.getBigDecimal("GIRIS_HESAP_NO");
			String bicKodu = iMap.getString("GIRIS_BIC_KODU");

			Session session = DAOSession.getSession("BNSPRDal");
			List<?> hesapList = session.createCriteria(NostroHesapList.class).add(Restrictions.eq("musteriNo", musteriNo)).add(Restrictions.eq("hesapNo", hesapNo)).add(Restrictions.eq("bicKodu", bicKodu)).list();

			if (hesapList != null && hesapList.size() == 1) {
				NostroHesapList nostroHesap = (NostroHesapList) hesapList.get(0);
				oMap.put("NIHAI_ALICI_HESAP", nostroHesap.getNostroHesapNo());
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static BigDecimal getBsmvOran() {
		GMMap xMap = new GMMap();
		xMap.put("PARAMETRE", "G_BSMV_ORANI");
		BigDecimal bsmv = new BigDecimal((Integer) (GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", xMap).get("DEGER")));
		return bsmv.divide(new BigDecimal(100)).setScale(2, BigDecimal.ROUND_HALF_UP);
	}

	private static void setMasrafHesap(GMMap iMap, GMMap oMap) {
		
		if ("I".equals(iMap.getString("MASRAF_IC_DIS"))) {
			GMMap iMapDK = new GMMap();
			iMapDK.put("MASRAF_IC_DIS", iMap.get("MASRAF_IC_DIS"));
			iMapDK.put("DOVIZ", iMap.get("MASRAF_DOVIZ"));
			GMMap oMapDK = GMServiceExecuter.call("BNSPR_TRN1304_MASRAF_DK_AL", iMapDK);
			oMap.put("MASRAF_HESAP_NO", oMapDK.getBigDecimal("DK_HESAP"));
		}
		else {
			oMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
		}
		
	}
	
	private static void setMasrafHesapVostro(GMMap iMap, GMMap oMap) {
		
		if ("I".equals(iMap.getString("MASRAF_IC_DIS"))) {
			GMMap iMapDK = new GMMap();
			iMapDK.put("MASRAF_IC_DIS", iMap.get("MASRAF_IC_DIS"));
			iMapDK.put("DOVIZ", iMap.get("MASRAF_DOVIZ"));
			iMapDK.put("DK_AL_2","true");
			GMMap oMapDK = GMServiceExecuter.call("BNSPR_TRN1304_MASRAF_DK_AL", iMapDK);
			oMap.put("MASRAF_HESAP_NO", oMapDK.getBigDecimal("DK_HESAP"));
		}
		else {
			oMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
		}

	}


	private static ArrayOfInstanceGroup getArrOfInstanceGroupWithTypeAndName(String instanceName, SearchType searchType) {
		ArrayOfInstanceGroup instanceGroupListArray = new ArrayOfInstanceGroup();
		List<InstanceGroup> instanceGroupList = new ArrayList<InstanceGroup>();
		InstanceGroup ig = new InstanceGroup();
		ig.setDetailLevel(DetailLevel.FULL);
		ig.setInstanceName(instanceName);
		ig.setSearchType(searchType);
		instanceGroupList.add(ig);
		instanceGroupListArray.getInstanceGroup().addAll(instanceGroupList);
		return instanceGroupListArray;
	}

	@GraymoundService("BNSPR_TRN1304_SWIFT_SWDATA")
	public static GMMap getSwiftData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call pkg_trn1304.SWIFT_GET_SWDATA(?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("AKTIFID")); // AKTIF ID
			stmt.setString(3, iMap.getString("MSG_TYPE", "202")); // MSG TYPE
			stmt.setString(4, "72"); // FIELD

			stmt.execute();

			oMap.put("MESAJ", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

	}

}
