package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznAtsTransfer;
import tr.com.aktifbank.bnspr.dao.HznAtsTransferTx;
import tr.com.aktifbank.bnspr.dao.HznAtsUyeBankaPr;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1370Services {
    private static final Logger logger = Logger.getLogger(TreasuryTRN1370Services.class);
    private static final SimpleDateFormat SDF_DD_MM_YYYY = new SimpleDateFormat("dd.MM.yyyy");

	@GraymoundService("BNSPR_TRN1370_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		String listName = "ALICI_UYE_KOD";
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<HznAtsUyeBankaPr> hznAtsUyeBankaPrList = session.createCriteria(HznAtsUyeBankaPr.class).addOrder(Order.asc("unvan")).list();
		for (HznAtsUyeBankaPr hznAtsUyeBankaPr : hznAtsUyeBankaPrList) {
			GuimlUtil.wrapMyCombo(oMap, listName, hznAtsUyeBankaPr.getUyeKod(), hznAtsUyeBankaPr.getUnvan());			
		}
		
		String listName2 = "GON_KIMLIK_TIP";
		GuimlUtil.wrapMyCombo(oMap, listName2, KimlikTipi.TCKN.name(), KimlikTipi.TCKN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName2, KimlikTipi.VKN.name(), KimlikTipi.VKN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName2, KimlikTipi.PASAPORT.name(), KimlikTipi.PASAPORT.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName2, KimlikTipi.YKN.name(), KimlikTipi.YKN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName2, KimlikTipi.KKTCN.name(), KimlikTipi.KKTCN.getValue());

		String listName3 = "ALICI_KIMLIK_TIP";
		GuimlUtil.wrapMyCombo(oMap, listName3, "UNKNOWN", "Bilinmiyor");
		GuimlUtil.wrapMyCombo(oMap, listName3, KimlikTipi.TCKN.name(), KimlikTipi.TCKN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName3, KimlikTipi.VKN.name(), KimlikTipi.VKN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName3, KimlikTipi.PASAPORT.name(), KimlikTipi.PASAPORT.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName3, KimlikTipi.YKN.name(), KimlikTipi.YKN.getValue());
		GuimlUtil.wrapMyCombo(oMap, listName3, KimlikTipi.KKTCN.name(), KimlikTipi.KKTCN.getValue());		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1370_SAVE")
	public static GMMap save(GMMap iMap) {
		try {			
			List<String> requiredFields=new ArrayList<String>();
			requiredFields.add("MIKTAR");
			requiredFields.add("VALOR_TARIHI");
			requiredFields.add("GON_MUSTERI_NO");
			requiredFields.add("GON_HESAP_NO");
			requiredFields.add("GON_KIMLIK_NO");
			requiredFields.add("ALICI_MUSTERI_ADI");
			validateRequiredFields(iMap, requiredFields);
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAtsTransferTx hznAtsTransferTx = (HznAtsTransferTx)session.get(HznAtsTransferTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznAtsTransferTx == null) {
				hznAtsTransferTx = new HznAtsTransferTx();
			}
			hznAtsTransferTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAtsTransferTx.setGelenGiden(iMap.getString("GELEN_GIDEN"));
			hznAtsTransferTx.setMiktar(iMap.getBigDecimal("MIKTAR"));
			Date valorTarihi = iMap.getDate("VALOR_TARIHI");
			if(!DateUtils.isSameDay(valorTarihi, new Date())){
				if(valorTarihi.compareTo(new Date())==-1){
					throw new GMRuntimeException(0, "Val�r Tarihi i�lem g�n�nden �nce olamaz");
				}else if(valorTarihi.compareTo(new Date())==1){	// 90 gunden buyuk mu kontrolu
					Date doksanGunSonra = DateUtils.addDays(new Date(), 90);
					if(valorTarihi.compareTo(doksanGunSonra)==1){
						throw new GMRuntimeException(0, String.format("Val�r Tarihi i�lem g�n�n� takiben en fazla 90 g�n olabilir. Se�ilebilecek en son tarih: %s", SDF_DD_MM_YYYY.format(doksanGunSonra)));
					}
				}
			}
			hznAtsTransferTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAtsTransferTx.setDurum(iMap.getString("DURUM"));
			hznAtsTransferTx.setAciklama(iMap.getString("ACIKLAMA"));			
			//gonderen bilgileri
			hznAtsTransferTx.setGonUyeKod(iMap.getString("GON_UYE_KOD"));
			hznAtsTransferTx.setGonUyeAdi(iMap.getString("GON_UYE_ADI"));
			hznAtsTransferTx.setGonMusteriNo(iMap.getBigDecimal("GON_MUSTERI_NO"));
			hznAtsTransferTx.setGonMusteriAdi(iMap.getString("GON_MUSTERI_ADI"));
			if(iMap.getBoolean("GON_IBAN_BEYAN")){
				hznAtsTransferTx.setGonIbanBeyanEh(IbanBeyan.EVET.getValue());
			}else{
				hznAtsTransferTx.setGonIbanBeyanEh(IbanBeyan.HAYIR.getValue());				
			}
			hznAtsTransferTx.setGonIban(iMap.getString("GON_IBAN"));
			hznAtsTransferTx.setGonHesapNo(iMap.getString("GON_HESAP_NO"));
			String gonSubeKodu = iMap.getString("GON_SUBE_KODU");
			if(StringUtils.isNotBlank(gonSubeKodu)){
				hznAtsTransferTx.setGonSubeKodu(StringUtils.leftPad(gonSubeKodu, 5, "0"));							
			}

			if(kimlikNoValidate(iMap.getString("GON_KIMLIK_TIP"), iMap.getString("GON_KIMLIK_NO"))){
				hznAtsTransferTx.setGonKimlikTip(iMap.getString("GON_KIMLIK_TIP"));					
				hznAtsTransferTx.setGonKimlikNo(iMap.getString("GON_KIMLIK_NO"));			
			}else{
				throw new GMRuntimeException(0, String.format("%s kimlik tipi i�in %s de�eri hatal�. D�zeltip tekrar deneyin.", 
																iMap.getString("GON_KIMLIK_TIP"), 
																iMap.getString("GON_KIMLIK_NO")));
			}
			//alici bilgileri
			hznAtsTransferTx.setAliciUyeKod(iMap.getString("ALICI_UYE_KOD"));
			hznAtsTransferTx.setAliciUyeAdi(iMap.getString("ALICI_UYE_ADI"));
			hznAtsTransferTx.setAliciMusteriNo(iMap.getBigDecimal("ALICI_MUSTERI_NO"));
			hznAtsTransferTx.setAliciMusteriAdi(iMap.getString("ALICI_MUSTERI_ADI"));
			hznAtsTransferTx.setAliciIbanBeyanEh(iMap.getBoolean("ALICI_IBAN_BEYAN")==true?IbanBeyan.EVET.getValue():IbanBeyan.HAYIR.getValue());	
			if(iMap.getBoolean("ALICI_IBAN_BEYAN")){
				if(StringUtils.isBlank(iMap.getString("ALICI_IBAN"))){
					throw new GMRuntimeException(0, "Al�c� IBAN bo� olamaz.");
				}else{
					hznAtsTransferTx.setAliciIbanBeyanEh(IbanBeyan.EVET.getValue());
					hznAtsTransferTx.setAliciIban(iMap.getString("ALICI_IBAN"));
				}
			}else{
				if(StringUtils.isBlank(iMap.getString("ALICI_HESAP_NO"))){
					throw new GMRuntimeException(0, "Al�c� Hesap No bo� olamaz.");
				}
				if(StringUtils.isBlank(iMap.getString("ALICI_SUBE_KODU"))){
					throw new GMRuntimeException(0, "Al�c� �ube Kodu bo� olamaz.");
				}
				hznAtsTransferTx.setAliciIbanBeyanEh(IbanBeyan.HAYIR.getValue());				
				hznAtsTransferTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO"));
				String aliciSubeKodu = iMap.getString("ALICI_SUBE_KODU");
				if(StringUtils.isNotBlank(aliciSubeKodu)){
					hznAtsTransferTx.setAliciSubeKodu(StringUtils.leftPad(aliciSubeKodu, 5, "0"));	
				}
			}
					
			if(kimlikNoValidate(iMap.getString("ALICI_KIMLIK_TIP"), iMap.getString("ALICI_KIMLIK_NO"))){
				hznAtsTransferTx.setAliciKimlikTip(iMap.getString("ALICI_KIMLIK_TIP").equals("UNKNOWN")?null:iMap.getString("ALICI_KIMLIK_TIP"));
				hznAtsTransferTx.setAliciKimlikNo(iMap.getString("ALICI_KIMLIK_NO"));			
			}else{
				throw new GMRuntimeException(0, String.format("%s kimlik tipi i�in %s de�eri hatal�. D�zeltip tekrar deneyin.", 
																iMap.getString("ALICI_KIMLIK_TIP"), 
																iMap.getString("ALICI_KIMLIK_NO")));
			}
			
			session.saveOrUpdate(hznAtsTransferTx);
			session.flush();
			iMap.put("TRX_NAME", "1370");			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1370_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			
			HznAtsTransferTx hznAtsTransferTx = (HznAtsTransferTx)session.get(HznAtsTransferTx.class, txNo);		
			oMap.put("TRX_NO", hznAtsTransferTx.getTxNo());
			oMap.put("MIKTAR", hznAtsTransferTx.getMiktar());
			oMap.put("VALOR_TARIHI", hznAtsTransferTx.getValorTarihi());
			oMap.put("DURUM", hznAtsTransferTx.getDurum());			
			oMap.put("ACIKLAMA", hznAtsTransferTx.getAciklama());
			oMap.put("GON_MUSTERI_NO", hznAtsTransferTx.getGonMusteriNo());
			oMap.put("GON_MUSTERI_ADI", hznAtsTransferTx.getGonMusteriAdi());
			oMap.put("GON_IBAN", hznAtsTransferTx.getGonIban());
			oMap.put("GON_SUBE_KODU", hznAtsTransferTx.getGonSubeKodu());
			oMap.put("GON_HESAP_NO", hznAtsTransferTx.getGonHesapNo());
			oMap.put("GON_KIMLIK_TIP", hznAtsTransferTx.getGonKimlikTip());
			oMap.put("GON_KIMLIK_NO", hznAtsTransferTx.getGonKimlikNo());			
			oMap.put("ALICI_UYE_KOD", hznAtsTransferTx.getAliciUyeKod());
			oMap.put("ALICI_MUSTERI_NO", hznAtsTransferTx.getAliciMusteriNo());
			oMap.put("ALICI_MUSTERI_ADI", hznAtsTransferTx.getAliciMusteriAdi());
			oMap.put("ALICI_IBAN", hznAtsTransferTx.getAliciIban());
			oMap.put("ALICI_SUBE_KODU", hznAtsTransferTx.getAliciSubeKodu());
			oMap.put("ALICI_HESAP_NO", hznAtsTransferTx.getAliciHesapNo());
			oMap.put("ALICI_KIMLIK_TIP", hznAtsTransferTx.getAliciKimlikTip());
			oMap.put("ALICI_KIMLIK_NO", hznAtsTransferTx.getAliciKimlikNo());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1370_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		String atsErrorStatus = null;
		BigDecimal takasbankTalimatNo = null;
		String takasbankDurum = null;
		String takasbankAciklama = null;
		String takasbankHataKodu = null;
		String takasbankHataAciklama = null;
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");
            HznAtsTransferTx hznAtsTransferTx = (HznAtsTransferTx) session.createCriteria(HznAtsTransferTx.class)
            									.add(Restrictions.eq("txNo" , trxNo)).uniqueResult();
            
            //Alici bilgileri
            String aliciIbanBeyanEH=hznAtsTransferTx.getAliciIbanBeyanEh();
            iMap.put("GIRIS_IBAN_BEYAN", aliciIbanBeyanEH);
            if(IbanBeyan.EVET.getValue().equals(aliciIbanBeyanEH)){
                iMap.put("GIRIS_MUSTERI_HESAP_NO", hznAtsTransferTx.getAliciIban());
            }else{
                iMap.put("GIRIS_MUSTERI_HESAP_NO", hznAtsTransferTx.getAliciHesapNo());
                iMap.put("GIRIS_SUBE_KODU", hznAtsTransferTx.getAliciSubeKodu());
            }
            iMap.put("GIRIS_KIMLIK_NO", hznAtsTransferTx.getAliciKimlikNo());
            iMap.put("GIRIS_ID_TIP", hznAtsTransferTx.getAliciKimlikTip());
            iMap.put("GIRIS_MUSTERI_AD", hznAtsTransferTx.getAliciMusteriAdi());
            iMap.put("GIRIS_ALT_MUSTERI_NO", hznAtsTransferTx.getAliciMusteriNo());
            iMap.put("GIRIS_UYE_KOD", hznAtsTransferTx.getAliciUyeKod());
            
            //Gonderen bilgileri
            iMap.put("CIKIS_IBAN_BEYAN", hznAtsTransferTx.getGonIbanBeyanEh());
            //bizden cikan gonderimler icin her zaman hesap_no kullan..
            //iMap.put("CIKIS_MUSTERI_HESAP_NO", hznAtsTransferTx.getGonIban());
            iMap.put("CIKIS_MUSTERI_HESAP_NO", hznAtsTransferTx.getGonHesapNo());
            iMap.put("CIKIS_SUBE_KODU", hznAtsTransferTx.getGonSubeKodu());            	
            iMap.put("CIKIS_KIMLIK_NO", hznAtsTransferTx.getGonKimlikNo());
            iMap.put("CIKIS_ID_TIP", hznAtsTransferTx.getGonKimlikTip());
            iMap.put("CIKIS_MUSTERI_AD", hznAtsTransferTx.getGonMusteriAdi());
            iMap.put("CIKIS_ALT_MUSTERI_NO", hznAtsTransferTx.getGonMusteriNo());

            iMap.put("ACIKLAMA", hznAtsTransferTx.getAciklama());
            iMap.put("MIKTAR", hznAtsTransferTx.getMiktar());
            iMap.put("VALOR_TARIHI", hznAtsTransferTx.getValorTarihi());
            iMap.put("WS_NO", hznAtsTransferTx.getTxNo());
            
            if(IslemTipi.GIDEN.getValue().equals(hznAtsTransferTx.getGelenGiden())){
    			oMap = GMServiceExecuter.call("BNSPR_EXT_ATS_MUSTERI_TRANSFER", iMap);
    			if(oMap.containsKey("HATA_KODU")){
    				atsErrorStatus = "H";
    				takasbankHataKodu = oMap.getString("HATA_KODU");
    				takasbankHataAciklama = oMap.getString("ACIKLAMA");
    				throw new GMRuntimeException(0, String.format("%s nolu giden altin transfer islemi hata aldi. Hata kodu ve aciklamasi: %s - %s" , 
    															  trxNo, takasbankHataKodu, takasbankHataAciklama));
    			}else{
    				takasbankTalimatNo = oMap.getBigDecimal("TALIMAT_NO");
    				takasbankDurum = oMap.getString("DURUM");
    				takasbankAciklama = oMap.getString("ACIKLAMA");
					if(TakasbankIslemDurum.ISLEM_TAMAMLANDI.getValue().equals(takasbankDurum)) {
						HznAtsTransfer hznAtsTransfer = (HznAtsTransfer) session.createCriteria(HznAtsTransfer.class).add(Restrictions.eq("referansNo", trxNo)).uniqueResult();
						hznAtsTransfer.setDurum(AktifbankDurum.TALIMAT_ONAYLANDI.getValue());
						hznAtsTransfer.setTakasbankTalimatNo(takasbankTalimatNo);
						hznAtsTransfer.setTakasbankDurum(takasbankDurum);
						hznAtsTransfer.setTakasbankAciklama(takasbankAciklama);
						session.saveOrUpdate(hznAtsTransfer);
						session.flush();
						logger.info(String.format("%s nolu giden altin transfer islemi %s talimat numarasiyla basarili olarak tamamlandi.", 
													trxNo, oMap.getBigDecimal("TALIMAT_NO")));
					}else{
						atsErrorStatus = "B";
	    				throw new GMRuntimeException(0, String.format("%s nolu giden altin transfer islemi %s talimat numarasiyla takasbanka iletildi ama durumu %s - %s oldugu icin muhasebelestirme yapilmadi.", 
	    											trxNo, takasbankTalimatNo, takasbankDurum, takasbankAciklama));						
					}
    			}            	
            }else if(IslemTipi.GELEN.getValue().equals(hznAtsTransferTx.getGelenGiden())){
				logger.info(String.format("%s nolu gelen altin transfer islemi %s talimat numarasiyla basarili olarak tamamlandi.", trxNo, oMap.getBigDecimal("TALIMAT_NO")));
	            HznAtsTransfer hznAtsTransfer = (HznAtsTransfer) session.createCriteria(HznAtsTransfer.class)
						.add(Restrictions.eq("referansNo" , trxNo)).uniqueResult();

	            hznAtsTransfer.setDurum(AktifbankDurum.GELEN_TALIMAT_TAMAMLANDI.getValue());				
	            session.saveOrUpdate(hznAtsTransfer);
				session.flush();
            }else if(IslemTipi.GELEN_IADE.getValue().equals(hznAtsTransferTx.getGelenGiden())){
				logger.info(String.format("%s nolu gelen iade islemi %s talimat numarasiyla basarili olarak tamamlandi.", trxNo, oMap.getBigDecimal("TALIMAT_NO")));
	            HznAtsTransfer hznAtsTransfer = (HznAtsTransfer) session.createCriteria(HznAtsTransfer.class)
						.add(Restrictions.eq("referansNo" , trxNo)).uniqueResult();

	            hznAtsTransfer.setDurum(AktifbankDurum.GELEN_IADE_TAMAMLANDI.getValue());				
	            session.saveOrUpdate(hznAtsTransfer);
				session.flush();
            }
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			iMap.put("ATS_ERROR_STATUS", atsErrorStatus);
			if("H".equals(atsErrorStatus)){
				iMap.put("TAKASBANK_HATA_KODU", takasbankHataKodu);
				iMap.put("TAKASBANK_HATA_ACIKLAMA", takasbankHataAciklama);
				GMServiceExecuter.executeNT("BNSPR_HZN_ATS_TRANSFER_TX_SAVE_TAKASBANK_RESPONSE", iMap);				
			}
			if("B".equals(atsErrorStatus)){
				iMap.put("TAKASBANK_TALIMAT_NO", takasbankTalimatNo);
				iMap.put("TAKASBANK_DURUM", takasbankDurum);
				iMap.put("TAKASBANK_ACIKLAMA", takasbankAciklama);
				GMServiceExecuter.executeNT("BNSPR_HZN_ATS_TRANSFER_TX_SAVE_TAKASBANK_RESPONSE", iMap);				
			}
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_HZN_ATS_TRANSFER_TX_SAVE_TAKASBANK_RESPONSE")
	public static GMMap hznAtsTransferTxSaveTakasbankResponse(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal trxNo = iMap.getBigDecimal("ISLEM_NO");
            HznAtsTransferTx hznAtsTransferTx = (HznAtsTransferTx) session.createCriteria(HznAtsTransferTx.class)
            									.add(Restrictions.eq("txNo" , trxNo)).uniqueResult();

            String atsErrorStatus = iMap.getString("ATS_ERROR_STATUS");
            if("H".equals(atsErrorStatus)){
                hznAtsTransferTx.setTakasbankHataKodu(iMap.getString("TAKASBANK_HATA_KODU"));
                hznAtsTransferTx.setTakasbankHataAciklama(iMap.getString("TAKASBANK_HATA_ACIKLAMA"));            	
            }
            
            if("B".equals(atsErrorStatus)){
                hznAtsTransferTx.setTakasbankTalimatNo(iMap.getBigDecimal("TAKASBANK_TALIMAT_NO"));
                hznAtsTransferTx.setTakasbankDurum(iMap.getString("TAKASBANK_DURUM"));
                hznAtsTransferTx.setTakasbankAciklama(iMap.getString("TAKASBANK_ACIKLAMA"));            	
            }
            session.saveOrUpdate(hznAtsTransferTx);
            session.flush();
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**************************************
	 *HZN_ATS_UYE_BANKA_PR servisleri 
	 **************************************/
	@GraymoundService("BNSPR_HZN_ATS_GET_ATS_UYE_BANKA_PR")
	public static GMMap getUyeBankaAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String uyeKod = iMap.getString("UYE_KOD");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAtsUyeBankaPr atsUyeBankaPr = (HznAtsUyeBankaPr) session.createCriteria(HznAtsUyeBankaPr.class)
																	   .add(Restrictions.eq("uyeKod" , uyeKod)).uniqueResult();
			oMap.put("ATS_UYE_BANKA_PR", atsUyeBankaPr);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_HZN_ATS_KURUM_LISTESI_GUNCELLEME_JOB")
	public static GMMap kurumListesiGuncellemeJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
		    Criteria criteria = session.createCriteria(HznAtsUyeBankaPr.class);
			List<HznAtsUyeBankaPr> kurumList = (List<HznAtsUyeBankaPr>) criteria.list();
		    for (HznAtsUyeBankaPr hznAtsUyeBankaPr : kurumList) {
		    	session.delete(hznAtsUyeBankaPr);
		    	session.flush();
			}
		    
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			oMap = GMServiceExecuter.call("BNSPR_EXT_ATS_KURUM_LISTELE", iMap.put("WS_NO", trxNo));
			List<HashMap<String, String>> kurumMap = (List<HashMap<String,String>>) oMap.get("KURUM_LISTELE_CEVAP");
			for (HashMap<String, String> kMap : kurumMap) {
				HznAtsUyeBankaPr hznAtsUyeBankaPr = new HznAtsUyeBankaPr();
				hznAtsUyeBankaPr.setWsNo(trxNo.toString());
				hznAtsUyeBankaPr.setUyeKod(kMap.get("UYE_KOD"));
				hznAtsUyeBankaPr.setBankKod(kMap.get("BANK_KOD"));
				hznAtsUyeBankaPr.setUnvan(kMap.get("UNVAN"));
				session.save(hznAtsUyeBankaPr);
				session.flush();
			}			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static boolean kimlikNoValidate(String kimlikTipi, String kimlikNo) {
		if(kimlikTipi.equals(KimlikTipi.TCKN.name())){
			return Pattern.compile("^\\d{11}$").matcher(kimlikNo).matches();
		}else if(kimlikTipi.equals(KimlikTipi.VKN.name())){
			return Pattern.compile("^\\d{10}$").matcher(kimlikNo).matches();
		}else if(kimlikTipi.equals(KimlikTipi.PASAPORT.name())){
			return Pattern.compile("^[a-zA-Z0-9]{1,15}$").matcher(kimlikNo).matches();
		}else if(kimlikTipi.equals(KimlikTipi.YKN.name())){
			return Pattern.compile("^[a-zA-Z0-9]{1,15}$").matcher(kimlikNo).matches();
		}else if(kimlikTipi.equals(KimlikTipi.KKTCN.name())){
			return Pattern.compile("^[a-zA-Z0-9]{1,15}$").matcher(kimlikNo).matches();
		}else if(kimlikTipi.equals("UNKNOWN")){
			return true;
		}
		return false;
	}
	
	protected enum KimlikTipi{
		TCKN("TC Kimlik No"),
		VKN("Vergi Kimlik No"),
		PASAPORT("Pasaport No"),
		YKN("Yabanc� Kimlik No"),
		KKTCN("KKTC Kimlik No");
		
        private String value;

        private KimlikTipi(String value) {
                this.value = value;
        }
		public String getValue() {
			return value;
		}
	};
	
	protected enum AktifbankDurum{
		TALIMAT_GIRIS_YAPILDI("TG"),
		TALIMAT_IPTAL_EDILDI("TI"),
		TALIMAT_ONAYLANDI("TO"),
		TALIMAT_WS_HATA_ALDI("TH"),
		GELEN_TALIMAT_GIRIS("GG"),
		GELEN_TALIMAT_IADE("GI"),
		GELEN_TALIMAT_ONAYLANDI("GO"),
		GELEN_TALIMAT_TAMAMLANDI("GT"),
		GELEN_IADE_GIRIS("IG"),
		GELEN_IADE_ONAYLANDI("IO"),
		GELEN_IADE_TAMAMLANDI("IT");
		
        private String value;

        private AktifbankDurum(String value) {
                this.value = value;
        }
		public String getValue() {
			return value;
		}
	};
	
	protected enum TakasbankTransferYon{
		GIRIS("G"),
		CIKIS("C"),
		HEPSI("H");
		
        private String value;

        private TakasbankTransferYon(String value) {
                this.value = value;
        }
		public String getValue() {
			return value;
		}
	};
	
	protected enum TakasbankIslemDurum{
		GIRIS_YAPILDI("GR"),
		ONAYLANDI_BAKIYE_BEKLIYOR("BB"),
		ISLEM_TAMAMLANDI("ON"),
		IPTAL_EDILDI("IP"),
		VALOR_BEKLIYOR("VB"),
		SISTEM_TARAFINDAN_IPTAL_EDILDI("SP"),
		HEPSI("HE");
		
        private String value;

        private TakasbankIslemDurum(String value) {
                this.value = value;
        }
		public String getValue() {
			return value;
		}
	};
	
	protected enum IbanBeyan{
		EVET("E"),
		HAYIR("H");
		
        private String value;

        private IbanBeyan(String value) {
                this.value = value;
        }
		public String getValue() {
			return value;
		}
	};
	
	protected enum IslemTipi{
		GELEN("GELEN"),
		GIDEN("GIDEN"),
		GELEN_IADE("GELEN_IADE"),
		GIDEN_IADE("GIDEN_IADE");
		
        private String value;

        private IslemTipi(String value) {
                this.value = value;
        }
		public String getValue() {
			return value;
		}
	};
	
	public static void validateRequiredFields(GMMap iMap , List<String> requiredFields) {
		for (String field : requiredFields) {
			if (StringUtils.isBlank(iMap.getString(field)) ) {
				throw new GMRuntimeException(0,String.format("%s alan� bo� olamaz. ",field));
			}
		}
	}
}
