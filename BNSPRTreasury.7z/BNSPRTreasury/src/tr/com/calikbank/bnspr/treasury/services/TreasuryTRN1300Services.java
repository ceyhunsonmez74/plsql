package tr.com.calikbank.bnspr.treasury.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznKarsiMuhabirTx;
import tr.com.aktifbank.bnspr.dao.HznKarsiMuhabirTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1300Services {
    
    
    @GraymoundService("BNSPR_TRN1300_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName    = "KARSI_MUHABIR";
            
            List<?> recordList = (List<?>)iMap.get(tableName);
            
            for (int row = 0;row<recordList.size();row++) {
                HznKarsiMuhabirTxId id = new HznKarsiMuhabirTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setMusteriNo(iMap.getBigDecimal(tableName,row,"MUSTERI_NO"));
                id.setMusteriMuhabirNo(iMap.getString(tableName, row, "MUSTERI_MUHABIR_NO"));
                id.setDovizKodu(iMap.getString(tableName, row, "DOVIZ_KODU"));
               
                
                HznKarsiMuhabirTx hznKarsiMuhabirTx = (HznKarsiMuhabirTx)session.get(HznKarsiMuhabirTx.class, id);
               
                if(hznKarsiMuhabirTx == null) {
                    hznKarsiMuhabirTx = new HznKarsiMuhabirTx();
                }
                hznKarsiMuhabirTx.setId(id);
              
                    hznKarsiMuhabirTx.setBankaAdi(iMap.getString(tableName, row, "BANKA_ADI"));
                    hznKarsiMuhabirTx.setBicKodu(iMap.getString(tableName, row, "BIC_KODU"));
                    hznKarsiMuhabirTx.setDovizAdi(iMap.getString(tableName, row, "DOVIZ_ADI"));
                    hznKarsiMuhabirTx.setBankaKod(iMap.getString(tableName, row, "BANKA_KOD"));
                    hznKarsiMuhabirTx.setBankaSubeKod(iMap.getString(tableName, row, "BANKA_SUBE_KOD"));
                    hznKarsiMuhabirTx.setHesapNo(iMap.getString(tableName, row, "HESAP_NO"));
                    hznKarsiMuhabirTx.setAraciMuhabir(iMap.getString(tableName, row, "ARACI_MUHABIR"));
                    hznKarsiMuhabirTx.setAraciMuhabirHesapNo(iMap.getString(tableName, row, "ARACI_MUHABIR_HESAP_NO"));
                    hznKarsiMuhabirTx.setOncekiMuhabir(iMap.getString(tableName, row, "ONCEKI_MUHABIR"));
                    
                    
                    if(("S").equals(iMap.getString(tableName,row,"G_S")))
                        hznKarsiMuhabirTx.setGS("S");
                    else if (("G").equals(iMap.getString(tableName, row, "G_S")))
                        hznKarsiMuhabirTx.setGS("G");
                    else hznKarsiMuhabirTx.setGS("");
                    
                  
                    session.saveOrUpdate(hznKarsiMuhabirTx);
                }
                session.flush();
                
               iMap.put("TRX_NAME","1300");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } 
     }
	
@GraymoundService("BNSPR_TRN_1300_SAVE_KONTROL")
	public static GMMap SaveControl(GMMap iMap){
		try{   
			

			int k=0;
			int l=0;
			int m=0;
			String 	tableName	= "MUHABIR_TABLO";
			List<?> list = (List<?>) iMap.get(tableName);
			List<?> list_2 = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){


				//hata mesaj�
				if(iMap.getString(tableName, i, "MUSTERI_NO") == null || iMap.getString(tableName, i, "MUSTERI_NO").isEmpty())
				{
				iMap.put("HATA_NO", new BigDecimal(330));
				      iMap.put("P1", "MUSTERI_NO");
				      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if(iMap.getString(tableName, i, "DOVIZ_KODU") == null || iMap.getString(tableName, i, "DOVIZ_KODU").isEmpty())
				{
				iMap.put("HATA_NO", new BigDecimal(330));
				      iMap.put("P1", "DOVIZ_KODU");
				      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if(iMap.getString(tableName, i, "MUSTERI_MUHABIR_NO") == null || iMap.getString(tableName, i, "MUSTERI_MUHABIR_NO").isEmpty())
				{
				iMap.put("HATA_NO", new BigDecimal(330));
				      iMap.put("P1", "MUSTERI_MUHABIR_NO");
				      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				k=0;
				
				for (int j = i+1; j < list_2.size(); j++) {
					
					
				 if(iMap.getString(tableName, j, "MUSTERI_NO")==null || iMap.getString(tableName, j, "MUSTERI_NO").length() ==0 ){
						
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "MUSTERI_NO");
				    return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				
					
			    k=iMap.getString(tableName, j, "MUSTERI_NO").compareTo(iMap.getString(tableName, i, "MUSTERI_NO") );
					

				
				
				 if(iMap.getString(tableName, j, "DOVIZ_KODU")==null || iMap.getString(tableName, j, "DOVIZ_KODU").length() ==0 ){
						
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "DOVIZ_KODU");
				    return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				
					
			    l=iMap.getString(tableName, j, "DOVIZ_KODU").compareTo(iMap.getString(tableName, i, "DOVIZ_KODU") );
					

				
				 if(iMap.getString(tableName, j, "MUSTERI_MUHABIR_NO")==null || iMap.getString(tableName, j, "MUSTERI_MUHABIR_NO").length() ==0 ){
						
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "MUSTERI_MUHABIR_NO");
				    return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				 		
					
			    m=iMap.getString(tableName, j, "MUSTERI_MUHABIR_NO").compareTo(iMap.getString(tableName, i, "MUSTERI_MUHABIR_NO") );
					

			    
			    
				if (  k==0 && l==0 && m==0 ){	
					iMap.put("HATA_NO", new BigDecimal(1524));
					iMap.put("P1", i+1);
					iMap.put("P2", j+1);
					return	(GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
			}
				
		     	}
			}				
			return iMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
@GraymoundService("BNSPR_TRN1300_GET_MUHABIR_LIST")
public static Map<?, ?> getMuhabirList(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{call PKG_TRN1300.GET_MUHABIR_LISTE(?,?)}");
        int i = 1;
        stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
        stmt.registerOutParameter(i++, -10); 
        stmt.execute(); 
        rSet = (ResultSet) stmt.getObject(2);
        String tableName1 = "KARSI_MUHABIR";
        for (int row = 0; rSet.next(); row++) {
            oMap.put(tableName1, row, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
            oMap.put(tableName1, row, "BANKA_ADI", rSet.getString("BANKA_ADI"));
            oMap.put(tableName1, row, "BIC_KODU", rSet.getString("BIC_KODU"));
            oMap.put(tableName1, row, "DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
            oMap.put(tableName1, row, "DOVIZ_ADI", rSet.getString("DOVIZ_ADI"));
            oMap.put(tableName1, row, "MUSTERI_MUHABIR_NO",rSet.getString("MUSTERI_MUHABIR_NO"));
            oMap.put(tableName1, row, "BANKA_KOD",rSet.getString("BANKA_KOD"));
            oMap.put(tableName1, row, "BANKA_SUBE_KOD",rSet.getString("BANKA_SUBE_KOD"));
            oMap.put(tableName1, row, "G_S", rSet.getString("G_S"));
            oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
            oMap.put(tableName1, row, "HESAP_NO", rSet.getString("HESAP_NO"));
            oMap.put(tableName1, row, "ARACI_MUHABIR", rSet.getString("ARACI_MUHABIR"));
            oMap.put(tableName1, row, "ONCEKI_MUHABIR", rSet.getString("ONCEKI_MUHABIR"));
            oMap.put(tableName1, row, "ARACI_MUHABIR_HESAP_NO", rSet.getString("ARACI_MUHABIR_HESAP_NO"));
        }
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }

@GraymoundService("BNSPR_TRN1300_GET_INFO")
public static GMMap getTransactionNo(GMMap iMap) {
    
    Connection conn = null;
    
    try{
        
    GMMap oMap = new GMMap();
    conn = DALUtil.getGMConnection();
    Session session = DAOSession.getSession("BNSPRDal");
    String tableName    = "TBL_KARSI_MUHABIR";
    String colorTableName = "TBL_COLOR";
    

    List<?> list = session.createCriteria(HznKarsiMuhabirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
    														      //.add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).list();
        
    
     for (int row = 0; row < list.size(); row++){
         HznKarsiMuhabirTx hznKarsiMuhabirTx = (HznKarsiMuhabirTx) list.get(row);
         
        oMap.put("TRX_NO", hznKarsiMuhabirTx.getId().getTxNo());
        oMap.put(tableName, row, "MUSTERI_NO", hznKarsiMuhabirTx.getId().getMusteriNo());
        oMap.put(tableName, row, "MUSTERI_MUHABIR_NO", hznKarsiMuhabirTx.getId().getMusteriMuhabirNo());
        oMap.put(tableName, row, "DOVIZ_KODU", hznKarsiMuhabirTx.getId().getDovizKodu());
        oMap.put(tableName, row, "BANKA_ADI", hznKarsiMuhabirTx.getBankaAdi());
        oMap.put(tableName, row, "BANKA_KOD", hznKarsiMuhabirTx.getBankaKod());
        oMap.put(tableName, row, "BANKA_SUBE_KOD", hznKarsiMuhabirTx.getBankaSubeKod());
        oMap.put(tableName, row, "BIC_KODU", hznKarsiMuhabirTx.getBicKodu());
        oMap.put(tableName, row, "DOVIZ_ADI", hznKarsiMuhabirTx.getDovizAdi());
        oMap.put(tableName, row, "SIL", ("S").equals(hznKarsiMuhabirTx.getGS()) ? true : false);
        oMap.put(tableName, row, "HESAP_NO", hznKarsiMuhabirTx.getHesapNo());
        oMap.put(tableName, row, "ARACI_MUHABIR", hznKarsiMuhabirTx.getAraciMuhabir());
        oMap.put(tableName, row, "ARACI_MUHABIR_HESAP_NO", hznKarsiMuhabirTx.getAraciMuhabirHesapNo());
    
      if ("G".equals(hznKarsiMuhabirTx.getGS()) ) {
         
          oMap.put(colorTableName, row, "MUSTERI_NO",getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "MUSTERI_MUHABIR_NO", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "DOVIZ_KODU", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BANKA_ADI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BANKA_KOD", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BANKA_SUBE_KOD", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BIC_KODU", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "DOVIZ_ADI", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "HESAP_NO", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ARACI_MUHABIR", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ARACI_MUHABIR_HESAP_NO", getTableCellColorData(Color.GREEN));
          
      }
      else if ("S".equals(hznKarsiMuhabirTx.getGS())) {
          
          
          oMap.put(colorTableName, row, "MUSTERI_NO",getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "MUSTERI_MUHABIR_NO", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "DOVIZ_KODU", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BANKA_ADI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BANKA_KOD", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BANKA_SUBE_KOD", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BIC_KODU", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "DOVIZ_ADI", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "HESAP_NO", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ARACI_MUHABIR", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ARACI_MUHABIR_HESAP_NO", getTableCellColorData(Color.RED));
      }
      else
      {
          
          oMap.put(colorTableName, row, "MUSTERI_NO",getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "MUSTERI_MUHABIR_NO", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "DOVIZ_KODU", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BANKA_ADI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BANKA_KOD", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BANKA_SUBE_KOD", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BIC_KODU", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "DOVIZ_ADI", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "HESAP_NO", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ARACI_MUHABIR", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ARACI_MUHABIR_HESAP_NO", getTableCellColorData(Color.WHITE));
      }
    
    }
        
    return oMap;
        
    }catch (Exception e){
        throw ExceptionHandler.convertException(e);
    }finally{
        
        GMServerDatasource.close(conn);
    }
    
}
 private static GMMap getTableCellColorData(Color backgroundColor){
        GMMap oMap = new GMMap();
        oMap.put("setBackground", backgroundColor);
        return oMap;
    }
}
