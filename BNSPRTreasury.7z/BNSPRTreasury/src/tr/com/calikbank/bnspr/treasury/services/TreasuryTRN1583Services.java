package tr.com.calikbank.bnspr.treasury.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznOpsBloombergExcelTx;
import tr.com.aktifbank.bnspr.dao.HznOpsBloombergExcelTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1583Services {

	@GraymoundService("BNSPR_TRN1583_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		int size = iMap.getSize("TABLE");

		try {

			Session session = DAOSession.getSession("BNSPRDal");
			
			for (int row = 0; row < size; row++) {
				
				HznOpsBloombergExcelTx hznOpsiyonislemTx = new HznOpsBloombergExcelTx();
				HznOpsBloombergExcelTxId id = new HznOpsBloombergExcelTxId();
				
					id.setReferans(iMap.getString("TABLE", row, "REFERANS"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
	
					hznOpsiyonislemTx.setId(id);
	
					hznOpsiyonislemTx.setYuklenenDoviz("USD");
					hznOpsiyonislemTx.setYuklenenTutar(iMap.getBigDecimal("TABLE",
							row, "TUTAR"));
				
					session.saveOrUpdate(hznOpsiyonislemTx);
			}

			session.flush();
			iMap.put("TRX_NAME", "1583");
			return GMServiceExecuter
					.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1583_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1583_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<HznOpsBloombergExcelTx> list = session
					.createCriteria(HznOpsBloombergExcelTx.class)
					.add(Restrictions.eq("id.txNo",
							iMap.getBigDecimal("TRX_NO"))).list();
			
			
			
			int row = 0;
 
			while (row<list.size()) {
				 
				oMap.put("TABLE", row, "REFERANS", list.get(row).getId().getReferans());
				oMap.put("TABLE", row, "TUTAR", list.get(row).getYuklenenTutar());
				 
				row++;
			}

			return oMap;

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	@GraymoundService("BNSPR_Q1583_GET_DATA")
	public static GMMap getdata(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		 
				try{
					String func = "{? = call PKG_TRN1583.search1853(?,?,?) }";
					Object[] inputValues = new Object[]{BnsprType.STRING,iMap.getString("REFERANS")
							,BnsprType.DATE,iMap.getDate("TARIH"),
							BnsprType.DATE,iMap.getDate("TARIH2")};
		
					Object resultMap = DALUtil.callOracleRefCursorFunction(func, "SONUC_TABLE", inputValues);
		 
					 oMap.putAll((GMMap) resultMap);
		       
					
				} catch (Exception e){
					throw ExceptionHandler.convertException(e);
				} finally{
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
				}
           
		return oMap;
    }


	@GraymoundService("BNSPR_TRN1583_YUKLE_EXCEL")
	public static GMMap loadExcelFile(GMMap iMap) {
	 
	    GMMap oMap = new GMMap();
        try {
            byte[] inputFile = (byte[]) iMap.get("DOSYA_YOLU");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya seçmediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            //ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
            } catch (Exception e) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Geçerli Bir Excel Dosyası Seçmediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            int row=0;
            for (int j = 0; j < sheet.getRows(); j++) {
            	
            	String ref=sheet.getCell(2, j).getContents();
            	String amount=sheet.getCell(10, j).getContents();

            		if (ref!=null&&ref.contains("."))
    				{            			
	                    oMap.put("TABLE", row, "REFERANS" , ref);
	                    oMap.put("TABLE", row, "TUTAR" , amount);
	                    row++;
	    		   }
                
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

 
      
		
	
}
		

