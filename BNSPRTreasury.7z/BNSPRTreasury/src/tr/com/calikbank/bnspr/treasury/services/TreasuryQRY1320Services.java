package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1320Services {
	
	@GraymoundService("BNSPR_ORY1320_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
			try{
				
				GMMap oMap = new GMMap();
				iMap.put("KOD", "NOSTRO_VOSTRO");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("NOSTRO_VOSTRO", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
								
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
	
	@GraymoundService("BNSPR_QRY1320_NOSTRO_VOSTRO_LIST")
	public static GMMap getNostroVostroList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC1320.RC_QRY1320_NOSTRO_VOSTRO_LIST(?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setString(1, iMap.getString("ISLEM_TIPI_GIZLI"));
			stmt.setString(2, iMap.getString("ULKE_KODU"));
			
			if(iMap.getDate("GIRIS_TARIHI_1")==null)
				stmt.setDate(3, null);
			else
				stmt.setDate(3, new java.sql.Date(iMap.getDate("GIRIS_TARIHI_1").getTime()));
			
			if(iMap.getDate("GIRIS_TARIHI_2")==null)
				stmt.setDate(4, null);
			else
				stmt.setDate(4, new java.sql.Date(iMap.getDate("GIRIS_TARIHI_2").getTime()));
			
			
			if(iMap.getDate("VALOR_TARIHI_1")==null)
				stmt.setDate(5, null);
			else
				stmt.setDate(5, new java.sql.Date(iMap.getDate("VALOR_TARIHI_1").getTime()));
			
			
			if(iMap.getDate("VALOR_TARIHI_2")==null)
				stmt.setDate(6, null);
			else
				stmt.setDate(6, new java.sql.Date(iMap.getDate("VALOR_TARIHI_2").getTime()));
			
			stmt.setBigDecimal(7, iMap.getBigDecimal("GIRIS_MUHABIR_BANKA_NO"));
			stmt.setBigDecimal(8, iMap.getBigDecimal("CIKIS_MUHABIR_BANKA_NO"));
			stmt.setString(9, iMap.getString("DOVIZ_KODU"));
			stmt.setString(10, iMap.getString("REF_NO"));
		
			stmt.registerOutParameter(11, -10);
		  
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(11);
		
	
			
	
			String tableName = "NOSTRO_VOSTRO";
			int j = 0;
			       
			while (rSet.next()){
				oMap.put(tableName , j , "ISLEM_TIPI" , rSet.getString("ISLEM_TIPI"));
				oMap.put(tableName , j , "ISLEM_NO" 		, rSet.getBigDecimal("ISLEM_NO"));
				oMap.put(tableName , j , "REFERANS" 		, rSet.getString("REFERANS"));
				
				
				if("VOSTRO".equals(rSet.getString("ISLEM_TIPI"))) {
				        oMap.put(tableName , j ,  "CIKIS_MUHABIR_MUS_NO",rSet.getBigDecimal("GIRIS_MUHABIR_MUS_NO"));  
				        oMap.put(tableName , j , "GIRIS_MUHABIR_MUS_NO" ,rSet.getBigDecimal("CIKIS_MUHABIR_MUS_NO") );
				        oMap.put(tableName , j , "GIRIS_MUHABIR"    , rSet.getString("CIKIS_MUHABIR"));
				        oMap.put(tableName , j ,  "CIKIS_MUHABIR" ,rSet.getString("GIRIS_MUHABIR"));
				        oMap.put(tableName , j ,  "HESAP_NO_CIKIS" ,rSet.getBigDecimal("HESAP_NO_GIRIS"));
				        oMap.put(tableName , j , "HESAP_NO_GIRIS"       , rSet.getBigDecimal("HESAP_NO_CIKIS"));
				}
				else {
				oMap.put(tableName , j ,  "CIKIS_MUHABIR_MUS_NO",rSet.getBigDecimal("CIKIS_MUHABIR_MUS_NO"));
				oMap.put(tableName , j , "GIRIS_MUHABIR_MUS_NO" ,rSet.getBigDecimal("GIRIS_MUHABIR_MUS_NO") );
				oMap.put(tableName , j , "GIRIS_MUHABIR"    , rSet.getString("GIRIS_MUHABIR")); 
				oMap.put(tableName , j ,  "CIKIS_MUHABIR" ,rSet.getString("CIKIS_MUHABIR"));
				oMap.put(tableName , j ,  "HESAP_NO_CIKIS" ,rSet.getBigDecimal("HESAP_NO_CIKIS"));
				oMap.put(tableName , j , "HESAP_NO_GIRIS"       , rSet.getBigDecimal("HESAP_NO_GIRIS"));
			
			}
				oMap.put(tableName , j ,  "ISLEM_TARIHI" ,rSet.getDate("ISLEM_TARIHI"));
				oMap.put(tableName , j ,  "VALOR_TARIHI" ,rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName , j ,  "TUTAR" ,rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName , j ,  "DOVIZ_KODU" ,rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName , j ,  "MASRAF_TUTARI" ,rSet.getBigDecimal("MASRAF_TUTARI"));
				oMap.put(tableName , j ,  "MASRAF_DOVIZ_KODU" ,rSet.getString ("MASRAF_DOVIZ_KODU"));
				oMap.put(tableName , j ,  "MASRAF_EUR_KARSILIK" ,rSet.getBigDecimal ("MASRAF_EUR_KARSILIK"));
				oMap.put(tableName , j ,  "GONDEREN_BANKA_REFERANSI" ,rSet.getString ("GONDEREN_BANKA_REFERANSI"));
				oMap.put(tableName , j ,  "NIHAI_ALICI" ,rSet.getString ("NIHAI_ALICI"));
				oMap.put(tableName , j ,  "ACIKLAMA" ,rSet.getString ("ACIKLAMA"));
				
 	
			j++; 
		}	
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY1320_GET_TOPLAM_TUTAR")
	public static GMMap getToplamTutarList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC1320.RC_QRY1320_GET_TUTAR_LIST(?,?,?,?,?,?,?,?,?,?,?)}");
		//	int i=1;
			
	//		stmt.registerOutParameter(i++, -10);
			stmt.setString(1, iMap.getString("ISLEM_TIPI_GIZLI"));
			stmt.setString(2, iMap.getString("ULKE_KODU"));
			
			if(iMap.getDate("GIRIS_TARIHI_1")==null)
				stmt.setDate(3, null);
			else
				stmt.setDate(3, new java.sql.Date(iMap.getDate("GIRIS_TARIHI_1").getTime()));
			
			if(iMap.getDate("GIRIS_TARIHI_2")==null)
				stmt.setDate(4, null);
			else
				stmt.setDate(4, new java.sql.Date(iMap.getDate("GIRIS_TARIHI_2").getTime()));
			
			
			if(iMap.getDate("VALOR_TARIHI_1")==null)
				stmt.setDate(5, null);
			else
				stmt.setDate(5, new java.sql.Date(iMap.getDate("VALOR_TARIHI_1").getTime()));
			
			
			if(iMap.getDate("VALOR_TARIHI_2")==null)
				stmt.setDate(6, null);
			else
				stmt.setDate(6, new java.sql.Date(iMap.getDate("VALOR_TARIHI_2").getTime()));
			
			stmt.setBigDecimal(7, iMap.getBigDecimal("GIRIS_MUHABIR_BANKA_NO"));
			stmt.setBigDecimal(8, iMap.getBigDecimal("CIKIS_MUHABIR_BANKA_NO"));
			stmt.setString(9, iMap.getString("DOVIZ_KODU"));
			stmt.setString(10, iMap.getString("REF_NO"));
		
			stmt.registerOutParameter(11, -10);
		  
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(11);
		
			String tableName = "TBL_TUTAR";
			int j = 0;
			       
			while (rSet.next()){
				oMap.put(tableName , j , "DOVIZ_TURU" , rSet.getString("DOVIZ_TURU"));
				oMap.put(tableName , j , "TOPLAM_TUTAR" , rSet.getBigDecimal("TOPLAM_TUTAR"));
			j++; 
		}	
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
