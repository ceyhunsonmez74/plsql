package tr.com.calikbank.bnspr.treasury.services;

import java.awt.Color;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class TreasuryQRY1576Services {

	@GraymoundService("BNSPR_QRY1576_QUERY_GETIR")
	public static GMMap excelOlustur (GMMap iMap) {

		GMMap oMap = new GMMap();
		String func = "{ ? = call PKG_RC1576.GetMusteriRiskBilgi(?,?,?) }";

		try {
			oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE", new Object[]{ BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),BnsprType.STRING, iMap.getString("DOVIZ_KODU")	,
					BnsprType.DATE, iMap.getDate("TARIH")});
			
			GMMap redBackground = new GMMap();
			redBackground.put("setBackground", Color.RED);
			
			GMMap yellowBackground = new GMMap();
			yellowBackground.put("setBackground", Color.YELLOW);
			
			GMMap whiteBackground = new GMMap();
			whiteBackground.put("setBackground", Color.WHITE);

			for(int row=0;row<oMap.getSize("TABLE");row++){
				
				if (oMap.getString("TABLE",row,"RENK").equals("R")) {
					oMap.put("COLOR",row,"ORAN",redBackground);
				} else if (oMap.getString("TABLE",row,"RENK").equals("Y")) {
					oMap.put("COLOR",row,"ORAN",yellowBackground);
				} else {
					oMap.put("COLOR",row,"ORAN",whiteBackground);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		   String proc = "{call PKG_RC1576.GetCatiLimitBilgileri(?,?,?)}";    
		     Object [] input  = new Object[] {};
		     Object [] output = new Object[] {BnsprType.NUMBER,"pn_cati1",BnsprType.NUMBER,"pn_cati2",BnsprType.NUMBER,"pn_cati3"};
		     /*
		      * 
		Procedure GetMusteriDetay(pn_must_no number, pn_py_no out number, pc_py_isim out varchar, pn_ana_sube out number, pc_ana_sube_isim out varchar,
		pn_kullanici_sube_kod out varchar2, pc_kullanici_sube_adi out varchar2 ) is
		      */
		     
		     try {
		          
		          GMMap oMap2 = (GMMap) DALUtil.callOracleProcedure(proc, input, output);
		          oMap.put("CATI_LIMIT1" , oMap2.getBigDecimal("pn_cati1"));
		          oMap.put("CATI_LIMIT2" , oMap2.getBigDecimal("pn_cati2"));
		          oMap.put("CATI_LIMIT3" , oMap2.getBigDecimal("pn_cati3"));
		     }
		        catch (Exception e) {
		            throw ExceptionHandler.convertException(e);
		        }
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY1576_QUERY_GETIR_EUR")
	public static GMMap excelOlusturEur (GMMap iMap) {

		GMMap oMap = new GMMap();
		String func = "{ ? = call PKG_RC1576.GetMusteriRiskBilgi(?,?,?) }";

		try {
			oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE_EUR", new Object[]{ BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
					BnsprType.DATE, iMap.getDate("TARIH")});

			GMMap redBackground = new GMMap();
			redBackground.put("setBackground", Color.RED);
			
			GMMap yellowBackground = new GMMap();
			yellowBackground.put("setBackground", Color.YELLOW);
			
			GMMap whiteBackground = new GMMap();
			whiteBackground.put("setBackground", Color.WHITE);

			for(int row=0;row<oMap.getSize("TABLE_EUR");row++){
				
				if (oMap.getString("TABLE_EUR",row,"RENK").equals("R")) {
					oMap.put("COLOR_EUR",row,"ORAN",redBackground);
				} else if (oMap.getString("TABLE_EUR",row,"RENK").equals("Y")) {
					oMap.put("COLOR_EUR",row,"ORAN",yellowBackground);
				} else {
					oMap.put("COLOR_EUR",row,"ORAN",whiteBackground);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_QRY1576_QUERY_GETIR_USD")
	public static GMMap excelOlusturUsd (GMMap iMap) {

		GMMap oMap = new GMMap();
		String func = "{ ? = call PKG_RC1576.GetMusteriRiskBilgi(?,?,?) }";

		try {
			oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE_USD", new Object[]{ BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
					BnsprType.DATE, iMap.getDate("TARIH")});

			GMMap redBackground = new GMMap();
			redBackground.put("setBackground", Color.RED);
			
			GMMap yellowBackground = new GMMap();
			yellowBackground.put("setBackground", Color.YELLOW);
			
			GMMap whiteBackground = new GMMap();
			whiteBackground.put("setBackground", Color.WHITE);

			for(int row=0;row<oMap.getSize("TABLE_USD");row++){
				
				if (oMap.getString("TABLE_USD",row,"RENK").equals("R")) {
					oMap.put("COLOR_USD",row,"ORAN",redBackground);
				} else if (oMap.getString("TABLE_USD",row,"RENK").equals("Y")) {
					oMap.put("COLOR_USD",row,"ORAN",yellowBackground);
				} else {
					oMap.put("COLOR_USD",row,"ORAN",whiteBackground);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY1576_QUERY_TUREV")
	public static GMMap reportQ1577 (GMMap iMap) {

		GMMap oMap = new GMMap();
		String func = "{ ? = call PKG_RC1576.GetTeminatList(?,?,?,?,?,?,?,?,?) }";

		try {
			oMap = DALUtil.callOracleRefCursorFunction(
					func, "TABLE", new Object[]{
							BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
							BnsprType.STRING, iMap.getString("TIP"),
							BnsprType.DATE, iMap.getDate("TEMINAT_TARIH1"),
							BnsprType.DATE, iMap.getDate("TEMINAT_TARIH2"),
							BnsprType.STRING, iMap.getString("TEMINAT_DURUM"),
							BnsprType.NUMBER, iMap.getBigDecimal("TEMINAT_ACIGI"),
							BnsprType.STRING, iMap.getString("TEMINAT_TURU"),
							BnsprType.STRING, iMap.getString("ISLEM_TURU"),
							BnsprType.STRING, iMap.getString("TEMINAT_AGIRLIGI"),
							}
					);
		}
		        catch (Exception e) {
		            throw ExceptionHandler.convertException(e);
		        }
		return oMap;
	}
	
	
    @GraymoundService("BNSPR_QRY1577_INITIALIZE_COMBO")
    public static GMMap initializeCombo(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        
        //P-Pasif A-Acik E-Eksik Y-Yenileme G-Gecikmis K-Kapali
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", "P", "Pasif");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", "A", "Acik");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", "E", "Eksik");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", "Y", "Yenileme");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", "G", "Gecikmis");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_DURUM", "K", "Kapali");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_ACIGI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_ACIGI", "0", "YOK");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_ACIGI", "1", "VAR");
        
        DALUtil.fillComboBox(oMap, "COMBO_TEMINAT_TURU", true, "SELECT TEMINAT_TURU, TEMINAT_TURU A FROM BNSPR.TEM_TEMINAT_KODLARI_PR ORDER BY A");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_TURU", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_TURU", "SWAP", "SWAP");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_TURU", "FORWARD", "FORWARD");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_TURU", "Opsiyon", "Opsiyon");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "O", "KALDIRACLI");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "D", "TAM TEMINATLI");
        
        return oMap;
    }
}
