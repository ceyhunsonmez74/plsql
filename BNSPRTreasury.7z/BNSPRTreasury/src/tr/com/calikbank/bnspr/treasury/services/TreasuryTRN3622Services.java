package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznPeBloombergTx;
import tr.com.aktifbank.bnspr.dao.HznPlatformBankaKodTx;
import tr.com.aktifbank.bnspr.dao.HznPlatformBankaKodTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3622Services {
	
	@GraymoundService("BNSPR_TRN3622_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;
		
	     iMap.put("KOD", "PLATFORM_TANIM");
         oMap.put("TUR",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
 
//		oMap.put("TUR", i, "NAME", "SPOT");
//	    oMap.put("TUR", i++, "VALUE", "SPOT");
//
//	    oMap.put("TUR", i, "NAME", "SWAP");
//	    oMap.put("TUR", i++, "VALUE", "SWAP");
//	    
//	    oMap.put("TUR", i, "NAME", "FORWARD");
//	    oMap.put("TUR", i++, "VALUE", "FORWARD");
//	    
//	    oMap.put("TUR", i, "NAME", "DEPO");
//	    oMap.put("TUR", i++, "VALUE", "DEPO");

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3622_GET_INITIAL_DATA")
	public static GMMap getTransferData(GMMap iMap){
		  GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        try{
	            conn = DALUtil.getGMConnection();
	            
	            stmt = conn.prepareCall("{? = call PKG_TRN3622.getData}");
	            
	            int parameterIndex = 1;
	       
	            stmt.registerOutParameter(parameterIndex++ , -10);
	          
	            stmt.execute();
	            String tn = "TBL";
	            
	            rSet = (ResultSet) stmt.getObject(1);
	            oMap = DALUtil.rSetResults(rSet , tn);
	            
	            return oMap;
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
	
	
	@GraymoundService("BNSPR_TRN3622_SAVE")
	public static GMMap Save (GMMap iMap){
		try {

			Session session = DAOSession.getSession("BNSPRDal");
            
            BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
            
            int i = 0;
            String tn = "TBL";
			
			  while (i < iMap.getSize(tn)){
	                
				  HznPlatformBankaKodTx hznPlatTx = new HznPlatformBankaKodTx();
				  HznPlatformBankaKodTxId hznPlatTxId = new HznPlatformBankaKodTxId();

	                hznPlatTx.setBankaKodu(iMap.getString(tn , i , "BANKA_KODU"));
	                hznPlatTx.setBankaAdi(iMap.getString(tn , i , "BANKA_ADI"));
	                hznPlatTx.setPlatformAdi(iMap.getString(tn , i , "PLATFORM_ADI"));

	    			hznPlatTxId.setTxNo(trxNo);
	    			hznPlatTxId.setCounterPartyId(iMap.getString(tn , i , "COUNTER_PARTY_ID"));	    			
	    			hznPlatTx.setId(hznPlatTxId);
	    			
	                session.saveOrUpdate(hznPlatTx);
	                
	                i++;
	                
	            }
	            session.flush();
			
		 
			iMap.put("TRX_NAME", "3622");
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3622_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			

			Session session = DAOSession.getSession("BNSPRDal");
			
			List<HznPlatformBankaKodTx> hznPlat = null;
			
			hznPlat = (List<HznPlatformBankaKodTx>) session
					.createCriteria(HznPlatformBankaKodTx.class)
					.add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")))
					.list();
			
			if (hznPlat != null) {
				int i = 0;
				for (HznPlatformBankaKodTx bb2 : hznPlat) {

					oMap.put("TBL", i, "COUNTER_PARTY_ID", bb2.getId().getCounterPartyId());
					oMap.put("TBL", i, "PLATFROM_ADI", bb2.getPlatformAdi());
					oMap.put("TBL", i, "BANKA_KODU", bb2.getBankaKodu());
					oMap.put("TBL", i, "BANKA_ADI", bb2.getBankaAdi());

					i++;
				}
			
			}
 
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3622_GET_DEAL_DATA")
	public static GMMap getDealInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			StringBuilder msg = new StringBuilder(); 
            
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<HznPeBloombergTx> hznBloomberg = null;
			
			hznBloomberg = (List<HznPeBloombergTx>) session
					.createCriteria(HznPeBloombergTx.class)
					.add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO")))
					.list();
			
			if (hznBloomberg != null) {
				int i = 0;
				for (HznPeBloombergTx bb2 : hznBloomberg) {
					msg.append("<br>BANK1 NAME = " +bb2.getBank1Name());
					msg.append("<br>CURRENCY_1 ="+ bb2.getCurrency1());
					
					msg.append("<br>CURRENCY_2 ="+ bb2.getCurrency2());
					msg.append("<br>SIDE =");
					
					if (bb2.getSide().equals("B"))
						msg.append("Buy");
					if (bb2.getSide().equals("S"))
						msg.append("Sell");
					if (bb2.getSide().equals("O"))
						msg.append("Borrow");
					if (bb2.getSide().equals("L"))
						msg.append("Lending");
					
					msg.append("<br>DEAL_TYPE = ");
					
					if (bb2.getPureDealType().intValue()==2)
						msg.append("SPOT");
					if (bb2.getPureDealType().intValue()==8)
						msg.append("SWAP");
					if (bb2.getPureDealType().intValue()==4)
						msg.append("FORWARD");
					if (bb2.getPureDealType().intValue()==16)
						msg.append("DEPO");
					
					msg.append("<br>NEAR AMT DEALT = " +bb2.getNearAmtDealt()+" "+bb2.getNearCcyDealt());
					msg.append("<br>NEAR COUNTER DEALT = " +bb2.getNearCounterAmt()+" "+bb2.getNearCounterCcy());
					msg.append("<br>DATE_OF_DEAL ="+ bb2.getDateOfDeal());
					
					msg.append("<br>TRADER_NAME = " +bb2.getTraderName());
					msg.append("<br>SOURCE_REFERENCE = " +bb2.getSourceReference());
					
					msg.append("<br>SETTLE CURRENCY = " +bb2.getSettleCrncy());
					msg.append("<br>VALUE DATE PERIOD 1 CURRENCY 1 = " +bb2.getValueDatePeriod1Currency1());
					msg.append("<br>TENOR PERIOD = " +bb2.getTenorPeriod1());
					msg.append("<br>SPOT BASIS RATE = " +bb2.getSpotBasisRate());
					
					i++;
				}
			oMap.put("SONUC", msg);
			}
 
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
