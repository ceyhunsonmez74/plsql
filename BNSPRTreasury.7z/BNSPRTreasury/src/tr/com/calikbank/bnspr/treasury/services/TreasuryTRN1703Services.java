package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferi;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferiSonuc;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferiTx;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferiTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1703Services {
	@GraymoundService("BNSPR_TRN1703_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		MkkKiymetTransferi kt = new MkkKiymetTransferi();
		MkkKiymetTransferiTx ktx = new MkkKiymetTransferiTx();
		String tableName = "TABLE_KT";
		BigDecimal txNo = iMap.getBigDecimal("TX_NO");

		List<?> satirBilgileri = (List<?>) iMap.get(tableName);
		for (int i = 0; i < satirBilgileri.size(); i++) {
			if (iMap.getBoolean(tableName, i, "SEC") == true) {

				kt = (MkkKiymetTransferi) session.get(MkkKiymetTransferi.class, iMap.getBigDecimal(tableName, i, "KT_ID"));
				ktx = MkkKtBatchService.createNewKtxPojo(kt);
				ktx.getId().setTxNo(txNo);
				ktx.setDurum("T"); // Ba�ar�l� Tamamland�
				session.save(ktx);
			}
		}

		session.flush();
		iMap.clear();
		iMap.put("TRX_NAME", "1703");
		iMap.put("TRX_NO", txNo);
		oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1703_GET_DATA")
	public static GMMap getData(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			String tableName = "TABLE_KT";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1703.GET_KT_RECORDS_SCR(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("DURUM"));
			if (iMap.getDate("TARIH") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(4, null);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1703_GET_KT_RESPONSE")
	public static GMMap getKeResponse(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			saveKTResponse(iMap);
			if (iMap.getString("SenderReference") != null) {
				if (iMap.getString("SenderReference").startsWith("KT-")) { // K�ymet Transferi
					BigDecimal txNo = saveKtTx(iMap);
					
//					iMap.clear();
//                    iMap.put("TRX_NAME" , "1703");
//                    iMap.put("TRX_NO" , txNo);
//                    oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));

					oMap.put("RESPONSE_CODE", "0000");
					oMap.put("RESPONSE_DESC", "");
				}
				else if (iMap.getString("SenderReference").startsWith("RT-")) { // Rehin Teminat
					return GMServiceExecuter.call("BNSPR_TRN1704_GET_RT_RESPONSE", iMap);
				}
				else {
					oMap.put("RESPONSE_CODE", "1234");
					oMap.put("RESPONSE_DESC", iMap.getString("SenderReference") + " referansl� i�lem bulunamad�.");
				}
			}
			else {
				oMap.put("RESPONSE_CODE", "9876");
				oMap.put("RESPONSE_DESC", "SenderReference bo� olamaz");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static void saveKTResponse(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		MkkKiymetTransferiSonuc mkkSonuc = new MkkKiymetTransferiSonuc();
		mkkSonuc.setId(newId("MKK_KIYMET_TRANSFERI_SONUC"));
		mkkSonuc.setReceiverMember(iMap.getString("ReceiverMember"));
		mkkSonuc.setSenderReference(iMap.getString("SenderReference"));
		mkkSonuc.setTid(iMap.getString("Tid"));
		mkkSonuc.setMessageId(iMap.getString("MessageId"));
		mkkSonuc.setMkkSenderReference(iMap.getString("MkkSenderReference"));
		mkkSonuc.setMsgSeqNo(iMap.getString("MsgSeqNo"));
		mkkSonuc.setInstCode(iMap.getString("InstCode"));
		mkkSonuc.setInstId(iMap.getString("InstId"));
		mkkSonuc.setInstDate(iMap.getString("InstDate"));
		mkkSonuc.setInstTime(iMap.getString("InstTime"));
		mkkSonuc.setInstStat(iMap.getString("InstStat"));
		mkkSonuc.setTransferDate(iMap.getString("TransferDate"));
		mkkSonuc.setTransferTime(iMap.getString("TransferTime"));
		mkkSonuc.setAmount(iMap.getBigDecimal("Amount"));
		mkkSonuc.setRemainder(iMap.getBigDecimal("Remainder"));
		mkkSonuc.setSendMemberCode(iMap.getString("SendMemberCode"));
		mkkSonuc.setSendAccNo(iMap.getString("SendAccNo"));
		mkkSonuc.setSendSubAccNo(iMap.getString("SendSubAccNo"));
		mkkSonuc.setRcvMemberCode(iMap.getString("RcvMemberCode"));
		mkkSonuc.setRcvAccNo(iMap.getString("RcvAccNo"));
		mkkSonuc.setRcvSubAccNo(iMap.getString("RcvSubAccNo"));
		mkkSonuc.setMic(iMap.getString("Mic"));
		mkkSonuc.setIsin(iMap.getString("Isin"));
		mkkSonuc.setSecAddDefCode(iMap.getString("SecAddDefCode"));
		mkkSonuc.setSendInvsTaxNo(iMap.getString("SendInvsTaxNo"));
		mkkSonuc.setPurchasingCost(iMap.getBigDecimal("PurchasingCost"));
		mkkSonuc.setPurchasingDate(iMap.getString("PurchasingDate"));
		mkkSonuc.setTaxRate(iMap.getBigDecimal("TaxRate"));
		mkkSonuc.setServiceName(iMap.getString("ServiceName"));
		mkkSonuc.setOrderId(iMap.getString("OrderId"));
		mkkSonuc.setReferenceKey(iMap.getString("ReferenceKey"));

		session.save(mkkSonuc);
		session.flush();
	}

	private static BigDecimal saveKtTx(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		MkkKiymetTransferiTx ktTx = new MkkKiymetTransferiTx();
		ktTx.setId(new MkkKiymetTransferiTxId());

		BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
		ktTx.getId().setTxNo(txNo);
		if ("OK".equals(iMap.getString("InstStat"))) {
			ktTx.setDurum("T"); // Tamamland�
		}
		else {
			ktTx.setDurum("H");
		}
		if (iMap.getString("SenderReference") != null && iMap.getString("SenderReference").length() > 3) {
			ktTx.getId().setKtId(new BigDecimal(iMap.getString("SenderReference").substring(3)));
		}
		ktTx.setSenderMember(iMap.getString("ReceiverMember"));
		ktTx.setSenderReference(iMap.getString("SenderReference"));
		ktTx.setSendMemberCode(iMap.getString("SendMemberCode"));
		ktTx.setSendAccNo(iMap.getString("SendAccNo"));
		ktTx.setSendSubAccNo(iMap.getString("SendSubAccNo"));
		ktTx.setRcvMemberCode(iMap.getString("RcvMemberCode"));
		ktTx.setRcvAccNo(iMap.getString("RcvAccNo"));
		ktTx.setRcvSubAccNo(iMap.getString("RcvSubAccNo"));
		ktTx.setMic(iMap.getString("Mic"));
		ktTx.setIsin(iMap.getString("Isin"));
		ktTx.setSecAddDefCode(iMap.getString("SecAddDefCode"));
		ktTx.setAmount(iMap.getString("Amount"));
		ktTx.setSendInvsTaxNo(iMap.getString("SendInvsTaxNo"));
		ktTx.setPurchasingDate(iMap.getString("PurchasingDate"));
		ktTx.setPurchasingCost(iMap.getString("PurchasingCost"));
		ktTx.setTaxRate(iMap.getString("TaxRate"));
		ktTx.setServiceName(iMap.getString("ServiceName"));
		ktTx.setOrderId(iMap.getString("OrderId"));
		ktTx.setReferenceKey(iMap.getString("ReferenceKey"));
		
		session.save(ktTx);
		session.flush();

		return txNo;
	}

	@GraymoundService("BNSPR_TRN1703_TEKRAR_GONDER")
	public static GMMap tekrarGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			MkkKiymetTransferi ktOld = (MkkKiymetTransferi) session.get(MkkKiymetTransferi.class, iMap.getBigDecimal("KT_ID"));

			if (ktOld != null) {
				Criteria criteria = session.createCriteria(MkkKiymetTransferi.class).add(Restrictions.eq("musteriNo", ktOld.getMusteriNo())).add(Restrictions.eq("islemKod", ktOld.getIslemKod())).add(Restrictions.eq("referans", ktOld.getReferans())).add(Restrictions.eq("geriAlisReferans", ktOld.getGeriAlisReferans())).add(Restrictions.ne("durum", "H"));
				List<?> list = criteria.list();
				if (list != null && list.size() > 0) {
					return throwGMBusssinessException(ktOld.getReferans() + " referans nolu i�lem i�in bekleyen veya tamamlanm�� MKK K�ymet Transferi kayd� bulunmaktad�r.");
				}
				conn = DALUtil.getGMConnection();
				// Yeni k�ymet transferi kayd� ekleyelim
				stmt = conn.prepareCall("{call PKG_MKK.KTInsert(?,?,?,?,?,?)}");
				stmt.setBigDecimal(1, ktOld.getMusteriNo());
				stmt.setString(2, "G"); // G�nderilebilir
				stmt.setBigDecimal(3, ktOld.getIslemKod());
				stmt.setBigDecimal(4, ktOld.getReferans());
				stmt.setBigDecimal(5, ktOld.getGeriAlisReferans());
				stmt.setBigDecimal(6, ktOld.getHaId());
				stmt.execute();
				oMap.put("MESSAGE", ktOld.getReferans() + " referansl� i�lem i�in MKK K�ymet Transferi i�i tekrar tetiklenecektir.");
			}
			else {
				return throwGMBusssinessException("Kay�t bulunamad�");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1703_MKK_SORGULA")
	public static GMMap mkkSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			if (iMap.getBigDecimal("KT_ID") == null) {
				return throwGMBusssinessException("MKK'dan sorgulamak istedi�iniz kayd� se�iniz.");
			}

			MkkKiymetTransferi ktOld = (MkkKiymetTransferi) session.get(MkkKiymetTransferi.class, iMap.getBigDecimal("KT_ID"));
			GMMap xMap = new GMMap();
			xMap.put("SENDER_REFERENCE", ktOld.getSenderReference());
			xMap.put("SERVICE_NAME", "SecTransTrade");

			oMap = GMServiceExecuter.call("BNSPR_MKK_MESSAGE_QUERY_SERVICE", xMap);

			oMap.put("MESSAGE", iMap.getBigDecimal("KT_ID") + " nolu kay�t MKK'dan sorgulan�p durumu g�ncellenmi�tir");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static BigDecimal newId(String key) {
		GMMap map = new GMMap();
		map.put("TABLE_NAME", key);
		return (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", map).get("ID");
	}

	public static GMMap throwGMBusssinessException(String string) {
		GMMap exMap = new GMMap();
		exMap.put("P1", string);
		exMap.put("HATA_NO", "660");
		return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
	}
}
