package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirme;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeId;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeSonuc;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeTx;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeTxId;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferi;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1702Services {

	private static final Logger logger = Logger.getLogger(TreasuryTRN1702Services.class);

	@GraymoundService("BNSPR_TRN1702_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		MkkKimlikEslestirme ke = new MkkKimlikEslestirme();
		MkkKimlikEslestirmeTx kex = new MkkKimlikEslestirmeTx();
		String tableName = "TABLE_KE";
		BigDecimal txNo = iMap.getBigDecimal("TX_NO");

		List<?> satirBilgileri = (List<?>) iMap.get(tableName);
		for (int i = 0; i < satirBilgileri.size(); i++) {
			if (iMap.getBoolean(tableName, i, "SEC") == true) {

				ke = (MkkKimlikEslestirme) session.get(MkkKimlikEslestirme.class, new MkkKimlikEslestirmeId(iMap.getBigDecimal(tableName, i, "KE_ID"), iMap.getBigDecimal(tableName, i, "SIRA_NO")));
				kex = MkkHaKeBatchService.createNewKexPojo(ke);
				MkkKimlikEslestirmeTxId kexId = new MkkKimlikEslestirmeTxId(txNo, new BigDecimal(i + 1));

				kex.setId(kexId);
				kex.setDurum("T"); // Ba�ar�l� Tamamland�
				session.save(kex);
			}
		}

		session.flush();
		iMap.clear();
		iMap.put("TRX_NAME", "1702");
		iMap.put("TRX_NO", txNo);
		oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1702_GET_DATA")
	public static GMMap getData(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			String tableName = "TABLE_KE";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1702.GET_KE_RECORDS_SCR(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("DURUM"));
			if (iMap.getDate("TARIH") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(4, null);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1702_GET_KE_RESPONSE")
	public static GMMap getKeResponse(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			saveKEResponse(iMap);
			BigDecimal txNo = saveKeTx(iMap);

			logger.info("Nitelikli m��teri bildirimi yap�lacak...");
			int size = iMap.getSize("SuccessParticipants");
			for (int i = 0; i < size; i++) {
				try {
					Session session = DAOSession.getSession("BNSPRDal");
					logger.info("Nitelikli m��teri bildirimi yap�lacak m��teri:" + iMap.getString("SuccessParticipants", i, "CustomerId"));
					GMMap tMap = new GMMap();
					tMap.put("REGISTERY_NUMBER", iMap.getString("SuccessParticipants", i, "RegistryNo"));
					tMap.put("MUSTERI_NO", iMap.getString("SuccessParticipants", i, "CustomerId"));
					tMap.put("KE_ID", iMap.getString("SenderReference"));
					
					GnlMusteri musteri = (GnlMusteri) session.load(GnlMusteri.class, new BigDecimal(iMap.getString("SuccessParticipants", i, "CustomerId")));

					if (musteri != null) {
						logger.info("[BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE] servisi �a��r�l�yor, customerId:" + iMap.getString("SuccessParticipants", i, "CustomerId"));
						if (musteri != null && musteri.getFNitelikli() != null) {
							tMap.put("PROCESS_TYPE", getProcessType(musteri.getFNitelikli()));
						}else{
							tMap.put("PROCESS_TYPE", getProcessType("H"));
						}
						musteri.setMkkSicilno(iMap.getString("SuccessParticipants", i, "RegistryNo"));
                        session.update(musteri);
						GMServiceExecuter.call("BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE", tMap);
					}
				}
				catch (Exception ee) {
					ee.printStackTrace();
					logger.error("Nitelikli m��teri bildiriminde hata, customerId:" + iMap.getString("SuccessParticipants", i, "CustomerId"), ee);
				}
				finally {
					logger.info("Nitelikli m��teri bildirimi sevab�yla g�nah�yla tamamland�...");
				}
			}
			logger.info("Nitelikli m��teri bildirimi tamamland�...");

			GMMap transMap = new GMMap();
			transMap.put("TRX_NAME", "1702");
			transMap.put("TRX_NO", txNo);
			oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", transMap));

			oMap.put("RESPONSE_CODE", "0000");
			oMap.put("RESPONSE_DESC", "");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static String getProcessType(String nitelik) {
		return nitelik != null && nitelik.equals("E") ? "E" : "S";
	}

	private static void saveKEResponse(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		int size = iMap.getSize("SuccessParticipants");

		for (int i = 0; i < size; i++) {
			MkkKimlikEslestirmeSonuc mkkSonuc = new MkkKimlikEslestirmeSonuc();
			mkkSonuc.setId(newId("MKK_KIMLIK_ESLESTIRME_SONUC"));
			mkkSonuc.setSenderReference(iMap.getString("SenderReference"));
			mkkSonuc.setReceiverMember(iMap.getString("ReceiverMember"));
			mkkSonuc.setTid(iMap.getString("Tid"));
			mkkSonuc.setMessageId(iMap.getString("MessageId"));
			mkkSonuc.setMkkSenderReference(iMap.getString("MkkSenderReference"));
			mkkSonuc.setMemberCode(iMap.getString("MemberCode"));
			mkkSonuc.setAccountNo(iMap.getString("AccountNo"));
			mkkSonuc.setAccState(iMap.getString("AccState"));
			mkkSonuc.setServiceName(iMap.getString("ServiceName"));
			mkkSonuc.setOrderId(iMap.getString("OrderId"));
			mkkSonuc.setReferenceKey(iMap.getString("ReferenceKey"));

			mkkSonuc.setSuccessCustomerId(iMap.getString("SuccessParticipants", i, "CustomerId"));
			mkkSonuc.setSuccessRegistryNo(iMap.getString("SuccessParticipants", i, "RegistryNo"));
			mkkSonuc.setSuccessQualifStat(iMap.getString("SuccessParticipants", i, "QualifStat"));

			session.save(mkkSonuc);
		}

		if (iMap.getString("FailCustomerId") != null) {
			MkkKimlikEslestirmeSonuc mkkSonuc = new MkkKimlikEslestirmeSonuc();
			mkkSonuc.setId(newId("MKK_KIMLIK_ESLESTIRME_SONUC"));
			mkkSonuc.setSenderReference(iMap.getString("SenderReference"));
			mkkSonuc.setReceiverMember(iMap.getString("ReceiverMember"));
			mkkSonuc.setTid(iMap.getString("Tid"));
			mkkSonuc.setMessageId(iMap.getString("MessageId"));
			mkkSonuc.setMkkSenderReference(iMap.getString("MkkSenderReference"));
			mkkSonuc.setMemberCode(iMap.getString("MemberCode"));
			mkkSonuc.setAccountNo(iMap.getString("AccountNo"));
			mkkSonuc.setAccState(iMap.getString("AccState"));
			mkkSonuc.setServiceName(iMap.getString("ServiceName"));
			mkkSonuc.setOrderId(iMap.getString("OrderId"));
			mkkSonuc.setReferenceKey(iMap.getString("ReferenceKey"));
			
			mkkSonuc.setFailCustomerId(iMap.getString("FailCustomerId"));
			mkkSonuc.setFailMernisState(iMap.getString("FailMernisState"));
			mkkSonuc.setFailTaxNoState(iMap.getString("FailTaxNoState"));
			mkkSonuc.setFailReason(iMap.getString("FailReason"));

			session.save(mkkSonuc);
		}

		session.flush();
	}

	private static BigDecimal saveKeTx(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		MkkKimlikEslestirmeTx keTx = new MkkKimlikEslestirmeTx();

		BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
		keTx.setId(new MkkKimlikEslestirmeTxId(txNo, new BigDecimal(1)));

		if ("OK".equals(iMap.getString("AccState"))) {
			keTx.setDurum("T"); // Tamamland�
		}
		else {
			keTx.setDurum("H"); // D�zeltilecek, MKK'dan DZ olarak geliyor
		}
		if (iMap.getString("SenderReference") != null) {
			if (iMap.getString("SenderReference").length() > 3) {
				keTx.setKeId(new BigDecimal(iMap.getString("SenderReference").substring(3)));
			}
			else {
				keTx.setKeId(new BigDecimal(iMap.getString("SenderReference")));
			}
		}
		keTx.setCustomerId(iMap.getString("AccountNo"));
		keTx.setSenderReference(iMap.getString("SenderReference"));
		keTx.setSenderMember(iMap.getString("ReceiverMember"));
		keTx.setMemberCode(iMap.getString("MemberCode"));
		keTx.setAccountNumber(iMap.getString("AccountNo"));
		keTx.setRegisteryNumber(iMap.getString("RegistryNo"));
		keTx.setServiceName(iMap.getString("ServiceName"));
		keTx.setOrderId(iMap.getString("OrderId"));
		keTx.setReferenceKey(iMap.getString("ReferenceKey"));

		session.save(keTx);
		session.flush();

		return txNo;
	}

	@GraymoundService("BNSPR_TRN1702_TEKRAR_GONDER")
	public static GMMap tekrarGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			BigDecimal mustNo = iMap.getBigDecimal("MUSTERI_NO");
			Criteria criteria = session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("accountNumber", iMap.getString("MUSTERI_NO"))).add(Restrictions.ne("durum", "H")).add(Restrictions.ne("durum", "I"));
			List<?> list = criteria.list();
			if (list != null && list.size() > 0) {
				return throwGMBusssinessException(mustNo + " nolu m��teri i�in bekleyen veya tamamlanm�� MKK Kimlik E�le�tirme kayd� bulunmaktad�r.");
			}

			MkkKimlikEslestirme keOld = (MkkKimlikEslestirme) session.get(MkkKimlikEslestirme.class, new MkkKimlikEslestirmeId(iMap.getBigDecimal("KE_ID"), new BigDecimal(1)));

			conn = DALUtil.getGMConnection();

			// Yeni kimlik e�le�tirme kayd� ekleyelim
			stmt = conn.prepareCall("{call PKG_MKK.KEInsert(?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, keOld.getMusteriNo());
			stmt.setString(2, "G"); // G�nderilebilir
			stmt.setBigDecimal(3, keOld.getIslemKod());
			stmt.setBigDecimal(4, keOld.getReferans());
			stmt.setBigDecimal(5, keOld.getGeriAlisReferans());
			stmt.setBigDecimal(6, keOld.getHaId());
			stmt.execute();

			// K�ymet transferi tablosunda bu HA_ID ile bekleyen kay�tlar� iptale �ek
			criteria = session.createCriteria(MkkKiymetTransferi.class).add(Restrictions.eq("haId", keOld.getHaId())).add(Restrictions.eq("durum", "B"));
			List<MkkKiymetTransferi> ktList = criteria.list();
			if (ktList != null) {
				for (MkkKiymetTransferi ktOld : ktList) {
					ktOld.setDurum("I");
					ktOld.setResponseDesc("Kimlik e�le�tirme farkl� bir kay�tla g�nderilece�i i�in iptal edildi");
					session.save(ktOld);
				}
				session.flush();
			}

			// Yeni k�ymet transferi kayd� ekleyelim
			stmt = conn.prepareCall("{call PKG_MKK.KTInsert(?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, keOld.getMusteriNo());
			stmt.setString(2, "B"); // Bekliyor
			stmt.setBigDecimal(3, keOld.getIslemKod());
			stmt.setBigDecimal(4, keOld.getReferans());
			stmt.setBigDecimal(5, keOld.getGeriAlisReferans());
			stmt.setBigDecimal(6, keOld.getHaId());
			stmt.execute();

			oMap.put("MESSAGE", mustNo + " nolu m��teri i�in MKK Kimlik E�le�tirme i�i tekrar tetiklenecektir");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1702_MKK_SORGULA")
	public static GMMap mkkSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			if (iMap.getBigDecimal("KE_ID") == null) {
				return throwGMBusssinessException("MKK'dan sorgulamak istedi�iniz kayd� se�iniz.");
			}

			// Birden fazla kay�t olabilir hepsinin senderReference ayn� oldu�u i�in ilk kayd� alsak yeter
			MkkKimlikEslestirme keOld = (MkkKimlikEslestirme) session.get(MkkKimlikEslestirme.class, new MkkKimlikEslestirmeId(iMap.getBigDecimal("KE_ID"), BigDecimal.ONE));
			GMMap xMap = new GMMap();
			xMap.put("SENDER_REFERENCE", keOld.getSenderReference());
			xMap.put("SERVICE_NAME", "MatchIdentities");

			oMap = GMServiceExecuter.call("BNSPR_MKK_MESSAGE_QUERY_SERVICE", xMap);

			oMap.put("MESSAGE", iMap.getBigDecimal("KE_ID") + " nolu kay�t MKK'dan sorgulan�p durumu g�ncellenmi�tir");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static BigDecimal newId(String key) {
		GMMap map = new GMMap();
		map.put("TABLE_NAME", key);
		return (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", map).get("ID");
	}

	public static GMMap throwGMBusssinessException(String string) {
		GMMap exMap = new GMMap();
		exMap.put("P1", string);
		exMap.put("HATA_NO", "660");
		return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
	}
}
