package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HaislemTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1505Services {

	@GraymoundService("BNSPR_TRN1505_GET_HALKA_ARZ_PROJELER")
	public static GMMap getDagitimDosyasi(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call BNSPR.PKG_TRN1505.GetHalkaArzProjeler }");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "TABLO");
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN1505_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		try {

		
			String islemTur = "";
			if (iMap.getBoolean("TEMINAT"))
				islemTur = "2";
			else if (iMap.getBoolean("DAGITIM"))
				islemTur = "3";
			else if (iMap.getBoolean("TUTAR"))
                islemTur = "4";
			else if (iMap.getBoolean("BLOKE"))
				islemTur = "5";
			else if (iMap.getBoolean("TAHSILAT"))
				islemTur = "6";
			else
			{
				HashMap<String, Object> myMap = new HashMap<String, Object>();
				myMap.put("HATA_NO", new BigDecimal(442));
				throw new GMRuntimeException(0, "Islem tipini secmelisiniz.");
			}
			
			if(StringUtils.isBlank(iMap.getString("HA_KOD")))
					{
				HashMap<String, Object> myMap = new HashMap<String, Object>();
				myMap.put("HATA_NO", new BigDecimal(442));
				throw new GMRuntimeException(0, "Gecerli bir satir secmelisiniz.");
					}

			Session session = DAOSession.getSession("BNSPRDal");
			
			HaislemTx haislemTx = (HaislemTx) session.get(HaislemTx.class, iMap.getBigDecimal("TRX_NO"));
			if (haislemTx == null) {
			 haislemTx = new HaislemTx();
			}
			haislemTx.setHaKod(iMap.getString("HA_KOD"));
			haislemTx.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO"));
			haislemTx.setIslemTur(islemTur);
			haislemTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			session.saveOrUpdate(haislemTx);
			session.flush();
			iMap.put("TRX_NAME", "1505");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

}
