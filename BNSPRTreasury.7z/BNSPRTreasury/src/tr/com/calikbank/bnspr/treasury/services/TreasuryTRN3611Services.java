package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinAlinandepoTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3611Services {

    @GraymoundService("BNSPR_TRN3611_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        CallableStatement stmt2 = null;

        GMMap oMap = new GMMap();
        iMap.put("KOD", "HZN_VADE_ISLEM_BILGISI");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_VADE_ISLEM_BILGISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        iMap.put("KOD", "HZN_ALTIN_DEPO_ISLEM_TURU");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_ALTIN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        iMap.put("KOD", "HZN_TAKSIT_DURUMU");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_TAKSIT_DURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_ALTIN_FON.saflik_derecesi }");
            int i = 1;
            stmt.registerOutParameter(i, Types.NUMERIC);
            stmt.execute();
            oMap.put("SAFLIK_DERECESI", stmt.getBigDecimal(i));

            
            stmt2 = conn.prepareCall("{ ? = call PKG_ALTIN_FON.DEPO_KOMISYON_ORANI(?) }");
            int j = 1;
            stmt2.registerOutParameter(j++, Types.NUMERIC);
            stmt2.setString(j++ , "ALIS");
            stmt2.execute();
            oMap.put("KOMISYON_ORANI", stmt2.getBigDecimal(1));
            
            return oMap;
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(stmt2);
            GMServerDatasource.close(conn);
        }

    }

 
    @GraymoundService("BNSPR_TRN3611_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            HznAltinAlinandepoTx hznAltinAlinanDepoTx = (HznAltinAlinandepoTx) session.get(HznAltinAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
            if (hznAltinAlinanDepoTx == null) {
                hznAltinAlinanDepoTx = new HznAltinAlinandepoTx();
            }

            hznAltinAlinanDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            hznAltinAlinanDepoTx.setModulTurKod("HAZINE");
            hznAltinAlinanDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
            hznAltinAlinanDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
            hznAltinAlinanDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
            hznAltinAlinanDepoTx.setReferans(iMap.getString("REFERANS"));
            hznAltinAlinanDepoTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
            hznAltinAlinanDepoTx.setDealerNo(iMap.getString("DEALER_NO"));
            hznAltinAlinanDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
            hznAltinAlinanDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
            hznAltinAlinanDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
            hznAltinAlinanDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
            hznAltinAlinanDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
            hznAltinAlinanDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
            hznAltinAlinanDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
            hznAltinAlinanDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));

            hznAltinAlinanDepoTx.setBrutTutar(iMap.getBigDecimal("BRUT_TUTAR"));
            hznAltinAlinanDepoTx.setNetTutar(iMap.getBigDecimal("NET_TUTAR"));
            hznAltinAlinanDepoTx.setSaflikDerecesi(iMap.getBigDecimal("SAFLIK_DERECESI"));
            hznAltinAlinanDepoTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
            hznAltinAlinanDepoTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
          //  hznAltinAlinanDepoTx.setStokNo(iMap.getBigDecimal("STOK_NO"));

            hznAltinAlinanDepoTx.setAnaparaOdemeSekli(iMap.getString("ANAPARA_ODEME_SEKLI"));
            hznAltinAlinanDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
            hznAltinAlinanDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
            hznAltinAlinanDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
            hznAltinAlinanDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
            hznAltinAlinanDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
            hznAltinAlinanDepoTx.setAnaparaTaksitAdedi(iMap.getBigDecimal("ANAPARA_TAKSIT_ADEDI"));
            hznAltinAlinanDepoTx.setAnaparaOdemeSiklikTipi(iMap.getString("ANAPARA_ODEME_SIKLIK_TIPI"));
            hznAltinAlinanDepoTx.setAnaparaOdemeSiklik(iMap.getBigDecimal("ANAPARA_ODEME_SIKLIK"));
            hznAltinAlinanDepoTx.setAnaparaTaksitliOdemeSekli(iMap.getString("ANAPARA_TAKSITLI_ODEME_SEKLI"));
            hznAltinAlinanDepoTx.setFaizEndeksKodu(iMap.getString("FAIZ_ENDEKS_KODU"));
            hznAltinAlinanDepoTx.setSpread(iMap.getString("SPREAD"));
            hznAltinAlinanDepoTx.setSpreadOrani(iMap.getBigDecimal("SPREAD_ORANI"));
            hznAltinAlinanDepoTx.setFaizEndeksPeriod(iMap.getString("FAIZ_ENDEKS_PERIOD"));
            hznAltinAlinanDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
            hznAltinAlinanDepoTx.setFaizSiklikTipi(iMap.getString("FAIZ_SIKLIK_TIPI"));
            hznAltinAlinanDepoTx.setFaizSiklik(iMap.getBigDecimal("FAIZ_SIKLIK"));
            hznAltinAlinanDepoTx.setFaizHesaplanacakTutar(iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
            hznAltinAlinanDepoTx.setAciklama(iMap.getString("ACIKLAMA"));

            hznAltinAlinanDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
            hznAltinAlinanDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));

            hznAltinAlinanDepoTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
            
            session.saveOrUpdate(hznAltinAlinanDepoTx);
            session.flush();

            iMap.put("TRX_NAME","3611");

            return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);  


        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }

    @GraymoundService("BNSPR_TRN3611_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();

        try {

            BigDecimal txNo = iMap.getBigDecimal("TX_NO");
            Session session = DAOSession.getSession("BNSPRDal");
            HznAltinAlinandepoTx hznAltinAlinandepoTx = (HznAltinAlinandepoTx) session.get(HznAltinAlinandepoTx.class, txNo);

            oMap.put("TRX_NO", hznAltinAlinandepoTx.getTxNo());
            oMap.put("URUN_TUR_KOD", hznAltinAlinandepoTx.getUrunTurKod());

            oMap.put("URUN_SINIF_KOD", hznAltinAlinandepoTx.getUrunSinifKod());

            oMap.put("REFERANS", hznAltinAlinandepoTx.getReferans());
            oMap.put("ISLEM_TURU", hznAltinAlinandepoTx.getIslemTuru());
            oMap.put("DEALER_NO", hznAltinAlinandepoTx.getDealerNo());
            oMap.put("BANKA_MUSTERI_NO", hznAltinAlinandepoTx.getBankaMusteriNo());
            oMap.put("BANKA_HESAP_NO", hznAltinAlinandepoTx.getBankaHesapNo());
            oMap.put("GIRIS_HESAP_TURU", hznAltinAlinandepoTx.getGirisHesapTuru());
            oMap.put("GIRIS_HESAP_NO", hznAltinAlinandepoTx.getGirisHesapNo());
            oMap.put("CIKIS_HESAP_TURU", hznAltinAlinandepoTx.getCikisHesapTuru());
            oMap.put("CIKIS_HESAP_NO", hznAltinAlinandepoTx.getCikisHesapNo());
            oMap.put("DOVIZ_KODU", hznAltinAlinandepoTx.getDovizKodu());

            oMap.put("BRUT_TUTAR", hznAltinAlinandepoTx.getBrutTutar());
            oMap.put("NET_TUTAR", hznAltinAlinandepoTx.getNetTutar());
            oMap.put("SAFLIK_DERECESI", hznAltinAlinandepoTx.getSaflikDerecesi());
            oMap.put("KOMISYON_ORANI", hznAltinAlinandepoTx.getKomisyonOrani());
            oMap.put("KOMISYON_TUTARI", hznAltinAlinandepoTx.getKomisyonTutari());
            oMap.put("STOK_NO", hznAltinAlinandepoTx.getStokNo());

            oMap.put("VALOR_TARIHI", hznAltinAlinandepoTx.getValorTarihi());
            oMap.put("ANAPARA_ODEME_SEKLI", hznAltinAlinandepoTx.getAnaparaOdemeSekli());
            oMap.put("VADE_TARIHI", hznAltinAlinandepoTx.getVadeTarihi());
            oMap.put("ESAS_GUN_SAYISI", hznAltinAlinandepoTx.getEsasGunSayisi());
            oMap.put("TENOR", hznAltinAlinandepoTx.getTenor());
            oMap.put("FAIZ_TUTARI", hznAltinAlinandepoTx.getFaizTutari());
            oMap.put("VADE_ISLEM_BILGISI", hznAltinAlinandepoTx.getVadeIslemBilgisi());
            oMap.put("DEAL_TARIHI", hznAltinAlinandepoTx.getDealTarihi());
            oMap.put("ANAPARA_TAKSIT_ADEDI", hznAltinAlinandepoTx.getAnaparaTaksitAdedi());
            oMap.put("ANAPARA_ODEME_SIKLIK_TIPI", hznAltinAlinandepoTx.getAnaparaOdemeSiklikTipi());
            oMap.put("ANAPARA_ODEME_SIKLIK", hznAltinAlinandepoTx.getAnaparaOdemeSiklik());
            oMap.put("ANAPARA_TAKSITLI_ODEME_SEKLI", hznAltinAlinandepoTx.getAnaparaTaksitliOdemeSekli());
            oMap.put("FAIZ_ENDEKS_KODU", hznAltinAlinandepoTx.getFaizEndeksKodu());
            oMap.put("SPREAD", hznAltinAlinandepoTx.getSpread());
            oMap.put("SPREAD_ORANI", hznAltinAlinandepoTx.getSpreadOrani());
            oMap.put("FAIZ_ENDEKS_PERIOD", hznAltinAlinandepoTx.getFaizEndeksPeriod());
            oMap.put("FAIZ_ORANI", hznAltinAlinandepoTx.getFaizOrani());
            oMap.put("FAIZ_SIKLIK_TIPI", hznAltinAlinandepoTx.getFaizSiklikTipi());
            oMap.put("FAIZ_SIKLIK", hznAltinAlinandepoTx.getFaizSiklik());
            oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAltinAlinandepoTx.getFaizHesaplanacakTutar());
            oMap.put("ACIKLAMA", hznAltinAlinandepoTx.getAciklama());

            oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getGirisHesapNo(), hznAltinAlinandepoTx.getDovizKodu(), hznAltinAlinandepoTx.getGirisHesapTuru(),
                hznAltinAlinandepoTx.getDovizKodu(), hznAltinAlinandepoTx.getGirisHesapTuru(), hznAltinAlinandepoTx.getBankaMusteriNo(), "3611/LOV_ALIS_HESAP_NO", "KISA_ISIM"));

            oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getCikisHesapNo(), hznAltinAlinandepoTx.getDovizKodu(), hznAltinAlinandepoTx.getCikisHesapTuru(),
                hznAltinAlinandepoTx.getDovizKodu(), hznAltinAlinandepoTx.getCikisHesapTuru(), hznAltinAlinandepoTx.getBankaMusteriNo(), "3611/LOV_ALIS_HESAP_NO", "KISA_ISIM"));

            oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinAlinandepoTx.getBankaMusteriNo(), "3611/LOV_BANKA_MUSTERI", "UNVAN"));
            oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinAlinandepoTx.getDealerNo(), "3611/LOV_DEALER", "ISIM"));

            oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinAlinandepoTx.getGirisMuhabirMusteriNo());
            oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinAlinandepoTx.getCikisMuhabirMusteriNo());
            
            oMap.put("ISTATISTIK_KODU", hznAltinAlinandepoTx.getIstatistikKodu());
            oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznAltinAlinandepoTx.getIstatistikKodu(), "1330/LOV_ISTATISTIK", "ACIKLAMA"));


            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }

       @GraymoundService("BNSPR_TRN3611_CALCULATE_TENOR")
    public static GMMap getCalculatedTenor(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_TRN3611.Calculate_Tenor(?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
            stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
            stmt.execute();

            oMap.put("TENOR", stmt.getBigDecimal(1));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_TRN3611_FAIZ_HESAPLA")
    public static GMMap getFaizHesabi(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ?=call PKG_TRN3611.Faiz_Tutari_Hesapla(?,?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("GUN_SAYISI"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("BRUT_TUTAR"));
            stmt.execute();

            oMap.put("FAIZ_TUTARI", stmt.getString(1));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }
    
    @GraymoundService("BNSPR_TRN3611_Komisyon")
    public static GMMap getKomisyon(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;

        GMMap oMap = new GMMap();
    

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_ALTIN_FON.ALT_FON_KOMISYON(?,?,?) }");
            int i = 1;
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.setString(i++ , iMap.getString("ISLEM_TUR"));
            stmt.setString(i++ , iMap.getString("ISLEM_TIP"));
            stmt.setString(i++ , iMap.getString("KOMISYON_TIP"));
            stmt.execute();
            oMap.put("KOMISYON", stmt.getBigDecimal(1));

            
            return oMap;
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }


    }
    
    

}
