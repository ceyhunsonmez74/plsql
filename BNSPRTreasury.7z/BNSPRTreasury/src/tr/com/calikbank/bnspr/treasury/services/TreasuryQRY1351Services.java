package tr.com.calikbank.bnspr.treasury.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznSwapXccy;
import tr.com.aktifbank.bnspr.dao.HznSwapXccyCf;
import tr.com.aktifbank.bnspr.dao.MuhFis;
import tr.com.aktifbank.bnspr.dao.TcmbSpotDovizData;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1351Services {

	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	@GraymoundService("BNSPR_QRY1351_LISTELE")
	public static GMMap listele(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_TREASURY.RC_QRY1351_SWM_FWD_SWP_IZLEME(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.setString(i++, iMap.getString("URUN_TUR_KOD"));
			stmt.setString(i++, iMap.getString("URUN_SINIF_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("ALIS_DOVIZ_KODU"));
			if (iMap.getBigDecimal("ALIS_MIN_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_MIN_TUTAR"));
			if (iMap.getBigDecimal("ALIS_MAX_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_MAX_TUTAR"));
			if (iMap.getBigDecimal("SATIS_MIN_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_MIN_TUTAR"));
			if (iMap.getBigDecimal("SATIS_MAX_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_MAX_TUTAR"));
			if (iMap.getBigDecimal("PARITE").toString().equals("0.00000"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("PARITE"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			if (iMap.getDate("DEAL_TARIHI_MIN") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI_MIN").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("DEAL_TARIHI_MAX") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI_MAX").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("VALOR_BASLANGIC_TARIHI") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_BASLANGIC_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("VALOR_BITIS_TARIHI") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_BITIS_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("VADE_BASLANGIC_TARIHI") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_BASLANGIC_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("VADE_BITIS_TARIHI") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_BITIS_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getString("ISLEM_TIPI") != null)
				stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			else
				stmt.setString(i++, "X");
			if (iMap.getDate("ACIK_OLDUGU_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("ACIK_OLDUGU_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getString("ISLEM_KANALI") != null) {
				if (iMap.getString("ISLEM_KANALI").equals("A")) {
					stmt.setString(i++, "E");
					stmt.setString(i++, "H");
				}
				else if (iMap.getString("ISLEM_KANALI").equals("N")) {
					stmt.setString(i++, "H");
					stmt.setString(i++, "E");
				}
				else {
					stmt.setString(i++, "H");
					stmt.setString(i++, "H");
				}
			}
			else {
				stmt.setString(i++, "H");
				stmt.setString(i++, "H");
			}
			stmt.setString(i++, iMap.getString("RISK_ISLEM_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_SUBE"));

			if (iMap.getDate("XCY_TAKSIT_VADE_BASLANGIC") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("XCY_TAKSIT_VADE_BASLANGIC").getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getDate("XCY_TAKSIT_VADE_BITIS") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("XCY_TAKSIT_VADE_BITIS").getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getBoolean("CHECK_TRADE"))
				stmt.setString(i++, "E");
			else
				stmt.setString(i++, "H");

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "CBS_VW_SPT_FWD_SWP_IZLEME";
			int row = 0;

			while (rSet.next()) {
				String islemTur = rSet.getString("ISLEM_TUR");
				if (islemTur != null && islemTur.equals("SPT")) { // Spot(SPT)
					oMap.put(tableName, row, "SPOT_ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
					oMap.put(tableName, row, "SPOT_SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
					oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
				}
				else if (islemTur != null && islemTur.equals("SPM")) { // Spot Musteri(SPM)
					oMap.put(tableName, row, "SPOT_ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
					oMap.put(tableName, row, "SPOT_SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
					oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
				}
				else if (islemTur != null && islemTur.startsWith("FW")) { // Forward(FWD), Forward M��teri(FWM)
					oMap.put(tableName, row, "FORWARD_ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "FORWARD_ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
					oMap.put(tableName, row, "FORWARD_SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "FORWARD_SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
					oMap.put(tableName, row, "FORWARD_PARITE", rSet.getString("PARITE"));
				}
				else if (islemTur != null && islemTur.startsWith("FWM")) { // Forward(FWM), Forward Musteri(FWM)
					oMap.put(tableName, row, "FORWARD_ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "FORWARD_ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
					oMap.put(tableName, row, "FORWARD_SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "FORWARD_SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
					oMap.put(tableName, row, "FORWARD_PARITE", rSet.getString("PARITE"));
				}
				else if (islemTur != null && islemTur.startsWith("XCY")) { // cross currency
					oMap.put(tableName, row, "SPOT_ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
					oMap.put(tableName, row, "SPOT_SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
					oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
				}
				else if (islemTur != null && islemTur.startsWith("SW")) { // Swap Banka(SWP), Swap M��teri(SWM)
					oMap.put(tableName, row, "SPOT_ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
					oMap.put(tableName, row, "SPOT_SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "SPOT_SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
					oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
					oMap.put(tableName, row, "FORWARD_ALIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "FORWARD_ALIS_TUTARI", rSet.getString("FORWARD_ALIS_TUTARI"));
					oMap.put(tableName, row, "FORWARD_SATIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
					oMap.put(tableName, row, "FORWARD_SATIS_TUTARI", rSet.getString("FORWARD_SATIS_TUTARI"));
					oMap.put(tableName, row, "FORWARD_PARITE", rSet.getString("FORWARD_PARITE"));
				}
				oMap.put(tableName, row, "DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));
				oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, row, "SUBE_ANA", rSet.getString("SUBE_ANA"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put(tableName, row, "MUSTERI_ADI", rSet.getString("BANKA_MUSTERI_ADI"));
				oMap.put(tableName, row, "MUSTERI_KISA_ADI", rSet.getString("BANKA_MUSTERI_KISA_ADI"));
				oMap.put(tableName, row, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, row, "VADE_TARIHI", rSet.getDate("VADE_TARIHI"));
				oMap.put(tableName, row, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, row, "ISLEM_TUR", rSet.getString("ISLEM_TUR"));
				oMap.put(tableName, row, "HAZINE_KUR", rSet.getString("HAZINE_KUR"));
				oMap.put(tableName, row, "BAZ_FAIZ", rSet.getString("BAZ_FAIZ"));
				oMap.put(tableName, row, "KARSI_FAIZ", rSet.getString("KARSI_FAIZ"));

				oMap.put(tableName, row, "SATIS_MUHABIR_MUSTERI_NO", rSet.getString("SATIS_MUHABIR_MUSTERI_NO"));
				oMap.put(tableName, row, "ALIS_MUHABIR_MUSTERI_NO", rSet.getString("ALIS_MUHABIR_MUSTERI_NO"));
				oMap.put(tableName, row, "FORWARD_SATIS_MUH_MUSTERI_NO", rSet.getString("FORWARD_SATIS_MUH_MUSTERI_NO"));
				oMap.put(tableName, row, "FORWARD_ALIS_MUH_MUSTERI_NO", rSet.getString("FORWARD_ALIS_MUH_MUSTERI_NO"));
				oMap.put(tableName, row, "SPOT_SATIS_MUH_MUSTERI_NO", rSet.getString("SPOT_SATIS_MUH_MUSTERI_NO"));
				oMap.put(tableName, row, "SPOT_ALIS_MUH_MUSTERI_NO", rSet.getString("SPOT_ALIS_MUH_MUSTERI_NO"));
				oMap.put(tableName, row, "PORTFOY", rSet.getString("PORTFOY"));
				oMap.put(tableName, row, "PORTFOY_TEMSILCISI", rSet.getString("PORTFOY_TEMSILCISI"));

				oMap.put(tableName, row, "TRY_KARSILIK", rSet.getString("TRY_KARSILIK"));
				oMap.put(tableName, row, "KARLILIK", rSet.getString("KARLILIK"));
				oMap.put(tableName, row, "REUTERS_TRADE_ID", rSet.getString("REUTERS_TRADE_ID"));
				oMap.put(tableName, row, "RISK_ISLEM_TIPI", rSet.getString("RISK_ISLEM_TIPI"));

				oMap.put(tableName, row, "SM_EH", GuimlUtil.convertToCheckBoxSelected(rSet.getString("SM_EH")));
				oMap.put(tableName, row, "SM_TEXT", rSet.getString("SM_TEXT"));
				oMap.put(tableName, row, "MTM_TUTAR", rSet.getString("MTM_TUTAR"));
				oMap.put(tableName, row, "MTM_TARIH", rSet.getDate("MTM_TARIH"));
				oMap.put(tableName, row, "BASE_DOVIZ", rSet.getString("BASE_DOVIZ"));
				oMap.put(tableName, row, "BASE_TUTAR", rSet.getBigDecimal("BASE_TUTAR"));
				oMap.put(tableName, row, "TEMINAT_ORANI", rSet.getBigDecimal("TEMINAT_ORANI"));
				oMap.put(tableName, row, "TEMINAT_TUTARI", rSet.getBigDecimal("TEMINAT_TUTARI"));
				

				row++;
			}

			iMap.put("KOD", "HZN_ISLEM_DURUM");
			oMap.put("COMBO_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1351_PREPARE_TCMB_SPOT_DATA")
	public static GMMap prepareDataForTcmb(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();			
			Session session = DAOSession.getSession("BNSPRDal");

			stmt = conn.prepareCall("{? = call PKG_RC_TREASURY.RC_QRY1351_TCMB_SPT_DATA()}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
				List<?> list = session.createCriteria(TcmbSpotDovizData.class).add(Restrictions.eq("referans", rSet.getString("REFERANS"))).list();
				if (list.isEmpty()) {
					TcmbSpotDovizData tcmbData = new TcmbSpotDovizData();
					tcmbData.setKayitId(rSet.getString("KAYIT_ID"));
					tcmbData.setBankaKodu(rSet.getString("BANKA_KODU"));
					tcmbData.setSubeKodu(rSet.getString("SUBE_KODU"));
					tcmbData.setKurumTipi(rSet.getBigDecimal("KURUM_TIPI"));
					tcmbData.setKkTipi(rSet.getBigDecimal("KK_TIPI"));
					tcmbData.setKkid(rSet.getString("KKID"));
					tcmbData.setKkidTuru(rSet.getBigDecimal("KKID_TURU"));
					tcmbData.setKurumAdi(rSet.getString("KURUM_ADI"));
					tcmbData.setIslemTuru(rSet.getBigDecimal("ISLEM_TURU"));
					tcmbData.setCins(rSet.getString("CINS"));
					tcmbData.setTutar(rSet.getBigDecimal("TUTAR"));
					tcmbData.setTlTutar(rSet.getBigDecimal("TL_TUTAR"));
					tcmbData.setKur(rSet.getBigDecimal("KUR"));
					tcmbData.setUsdTutar(rSet.getBigDecimal("USD_TUTAR"));
					tcmbData.setValorTarihi(rSet.getDate("VALOR_TARIHI").toString());
					tcmbData.setIslemZamani(new BigDecimal(rSet.getTimestamp("ISLEM_ZAMANI").getTime()));
					tcmbData.setKanal(rSet.getBigDecimal("KANAL"));
					tcmbData.setEfektif(rSet.getBigDecimal("EFEKTIF"));
					tcmbData.setKayitTuru(rSet.getBigDecimal("KAYIT_TURU"));
					tcmbData.setReferans(rSet.getString("REFERANS"));
					tcmbData.setGonderim(new BigDecimal(0));
					session.save(tcmbData);
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1351_SEND_TCMB_DATA_WITH_EXCEL")
	public static GMMap sendTcmbDataWithExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		XSSFWorkbook wb = null;
		List<?> list;
		String tempDosyaAdi = null;

		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			iMap.put("PARAMETRE", "TCMB_CONTROL_RECORD_TYPE");
			String kayitTuru = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

			if (kayitTuru.equalsIgnoreCase("0")) {
				list = session.createCriteria(TcmbSpotDovizData.class).add(Restrictions.eq("gonderim", new BigDecimal(0))).list();
			}
			else {
				list = session.createCriteria(TcmbSpotDovizData.class).add(Restrictions.eq("gonderim", new BigDecimal(0))).add(Restrictions.eq("kayitTuru", new BigDecimal(0))).list();
			}

			if (!list.isEmpty()) {
				try {
					Date date = new Date();
					SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_HH_mm");
					String strDate = formatter.format(date);

					iMap.put("PARAMETRE", "TCMB_PATH_FILE");
					String filePath = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
					iMap.put("PARAMETRE", "TCMB_FILE_NAME");
					String fileName = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
					iMap.put("PARAMETRE", "TCMB_FILE_WRITE_OPTIONS_PARAM");
					String options = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

					if (options.equalsIgnoreCase("0")) {
						tempDosyaAdi = ROOT + File.separator + "files" + File.separator + "SpotDoviz" + ".xlsx";
					}
					else {
						tempDosyaAdi = filePath + File.separator + fileName + File.separator + "SpotDoviz" + ".xlsx";
					}



					wb = new XSSFWorkbook();
					XSSFSheet sheet1 = wb.createSheet("Spot_Dvz");
					FileOutputStream fileOut = new FileOutputStream(tempDosyaAdi);

					for (int rowNum = 0; rowNum < list.size(); rowNum++) {
						
						int columnCount = 0;
						if (rowNum == 0) {
							Row row = sheet1.createRow(rowNum);
							Cell cell = row.createCell(columnCount);
							cell.setCellValue("SiraNo");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KayitID");
							cell = row.createCell(++columnCount);
							cell.setCellValue("BankaKodu");
							cell = row.createCell(++columnCount);
							cell.setCellValue("SubeKodu");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KurumTipi");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KKIDTuru");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KKID");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KurumAdi");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KKTipi");
							cell = row.createCell(++columnCount);
							cell.setCellValue("IslemTuru");
							cell = row.createCell(++columnCount);
							cell.setCellValue("Cins");
							cell = row.createCell(++columnCount);
							cell.setCellValue("Tutar");
							cell = row.createCell(++columnCount);
							cell.setCellValue("Kur");
							cell = row.createCell(++columnCount);
							cell.setCellValue("TLTutar");
							cell = row.createCell(++columnCount);
							cell.setCellValue("USDTutar");
							cell = row.createCell(++columnCount);
							cell.setCellValue("ValorTarihi");
							cell = row.createCell(++columnCount);
							cell.setCellValue("IslemZamani");
							cell = row.createCell(++columnCount);
							cell.setCellValue("Kanal");
							cell = row.createCell(++columnCount);
							cell.setCellValue("Efektif");
							cell = row.createCell(++columnCount);
							cell.setCellValue("KayitTuru");
							columnCount = 0;
						}
						   Row row = sheet1.createRow(rowNum+1);
							TcmbSpotDovizData sptDvz = (TcmbSpotDovizData) list.get(rowNum);
							Cell cell = row.createCell(columnCount);

							cell.setCellValue((rowNum+1));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKayitId()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getBankaKodu()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getSubeKodu()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKurumTipi().intValue()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKkidTuru().toString()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKkid()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKurumAdi()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKkTipi().intValue()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getIslemTuru().intValue()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getCins()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((new DecimalFormat("##.##").format(sptDvz.getTutar())));
							cell = row.createCell(++columnCount);

							cell.setCellValue((new DecimalFormat("######.######").format(sptDvz.getKur())));
							cell = row.createCell(++columnCount);

							cell.setCellValue((new DecimalFormat("##.##").format(sptDvz.getTlTutar())));
							cell = row.createCell(++columnCount);

							cell.setCellValue((new DecimalFormat("##.##").format(sptDvz.getUsdTutar())));
							cell = row.createCell(++columnCount);

							Date valorTarihi = new SimpleDateFormat("yyyy-MM-dd").parse(sptDvz.getValorTarihi());
							cell.setCellValue((new SimpleDateFormat("dd.MM.yyyy").format(valorTarihi)));
							cell = row.createCell(++columnCount);

							Date islemZamani = new Date(sptDvz.getIslemZamani().longValue());
							SimpleDateFormat df2 = new SimpleDateFormat("dd.MM.yyyy HH:mm");
							String dateText = df2.format(islemZamani);
							cell.setCellValue((dateText));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKanal().intValue()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getEfektif().intValue()));
							cell = row.createCell(++columnCount);

							cell.setCellValue((sptDvz.getKayitTuru().intValue()));
						
				
					}
					
					wb.write(fileOut);
					fileOut.close();

					for (Object object : list) {
						TcmbSpotDovizData sptDvz = (TcmbSpotDovizData) object;
						sptDvz.setGonderim(new BigDecimal(1));
						session.saveOrUpdate(object);
					}									
					sendMail(iMap, strDate, tempDosyaAdi);
				}
				catch (Exception e) {
					System.out.println("An error occurred.");
					e.printStackTrace();
				}

			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static void sendMail(GMMap iMap, String strDate, String tempDosyaAdi) throws IOException {
		GMMap mailMap = new GMMap();
		GMMap paramMap = new GMMap();

		mailMap.put("MAIL_FROM", "aktifbank@aktifbank.com.tr");
		paramMap.put("PARAMETRE", "TCMB_SPOT_DVZ_MAIL_TO");
		String mailTo = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", paramMap).get("DEGER").toString();
		mailMap.put("MAIL_TO", mailTo);
		mailMap.put("MAIL_SUBJECT", "TCMB SPOT DOVIZ EXCEL GONDERIM Bilgilendirme");
		mailMap.put("MAIL_BODY", "TCMB i�in haz�rlanan dosya ektedir.");
		mailMap.put("IS_BODY_HTML", "H");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", "SpotDoviz" + ".xlsx");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(tempDosyaAdi));
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
		// mailServisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
		// GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);
	}

	@GraymoundService("BNSPR_QRY1351_DETAY")
	public static GMMap detay(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_TREASURY.RC_QRY1351_SWM_FWD_SWP_DETAY(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
				oMap.put("REFERANS", rSet.getString("REFERANS"));
				oMap.put("URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put("URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
				oMap.put("DEALER_NO", rSet.getString("DEALER_NO"));
				oMap.put("ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
				oMap.put("ALIS_KUR", rSet.getString("ALIS_KUR"));
				oMap.put("PARITE", rSet.getString("PARITE"));
				oMap.put("ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
				oMap.put("FORWARD_ALIS_TUTARI", rSet.getString("FORWARD_ALIS_TUTARI"));
				oMap.put("ALIS_HESAP_TURU", rSet.getString("ALIS_HESAP_TURU"));
				oMap.put("SATIS_HESAP_TURU", rSet.getString("SATIS_HESAP_TURU"));
				oMap.put("VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put("VADE_TARIHI", rSet.getDate("VADE_TARIHI"));
				oMap.put("DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put("YARATAN_TXNO", rSet.getString("YARATAN_TXNO"));
				oMap.put("URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put("BANKA_MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put("MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));

				iMap.put("MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
				oMap.put("MUSTERI_ADI", GMServiceExecuter.execute("BNSPR_COMMON_GET_UNVAN", iMap).get("UNVAN"));

				oMap.put("SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
				oMap.put("SATIS_KUR", rSet.getString("SATIS_KUR"));
				oMap.put("SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
				oMap.put("FORWARD_SATIS_TUTARI", rSet.getString("FORWARD_SATIS_TUTARI"));
				oMap.put("ALIS_HESAP_NO", rSet.getString("ALIS_HESAP_NO"));
				oMap.put("SATIS_HESAP_NO", rSet.getString("SATIS_HESAP_NO"));

				oMap.put("HAZINE_KUR", rSet.getString("HAZINE_KUR"));
				oMap.put("BAZ_FAIZ", rSet.getString("BAZ_FAIZ"));
				oMap.put("KARSI_FAIZ", rSet.getString("KARSI_FAIZ"));

				stmt = conn.prepareCall("{ ? = call pkg_hesap.kisa_isim(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, rSet.getString("ALIS_HESAP_NO"));
				stmt.execute();
				oMap.put("ALIS_KISA_ISIM", stmt.getString(1));
				stmt = conn.prepareCall("{ ? = call pkg_hesap.kisa_isim(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, rSet.getString("SATIS_HESAP_NO"));
				stmt.execute();
				oMap.put("SATIS_KISA_ISIM", stmt.getString(1));

				oMap.put("SUBE_KODU", rSet.getString("SUBE_KODU"));
				oMap.put("GN_ALIS_HESAP_NO", rSet.getString("GN_ALIS_HESAP_NO"));
				oMap.put("ACILIS_TARIHI", rSet.getDate("ACILIS_TARIHI"));
				oMap.put("DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));

				oMap.put("SM_EH", GuimlUtil.convertToCheckBoxSelected(rSet.getString("SM_EH")));
				oMap.put("SM_TEXT", rSet.getString("SM_TEXT"));
				oMap.put("MTM_TUTAR", rSet.getString("MTM_TUTAR"));
				oMap.put("MTM_TARIH", rSet.getDate("MTM_TARIH"));

			}
			iMap.put("KOD", "HZN_ISLEM_DURUM");
			oMap.put("COMBO_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1351_HZN_ISLEM_HAREKETLERI")
	public static GMMap getHznIslemHareketleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_TREASURY.RC_QRY1351_SPOTFWDSWAP_HAREKET(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "ISLEM_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1351_INITIALIZE_COMBO")
	public static GMMap initializeCombo(GMMap iMap) {

		GMMap oMap = new GMMap();

		GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", null, " ");
		GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "O", "KALDIRACLI");
		GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "D", "TAM TEMINATLI");
		GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "K", "T�rev Kredi Limiti");
 
		GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_KANALI", null, " ");
		GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_KANALI", "A", "AKTIFX");
		GuimlUtil.wrapMyCombo(oMap, "COMBO_ISLEM_KANALI", "N", "NKOLAY FX");
		return oMap;
	}

	@GraymoundService("BNSPR_QRY1351_GET_CROSS_CURRENCY")
	public static GMMap getCrossData(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();

			Session session = DAOSession.getSession("BNSPRDal");

			Criteria swap = session.createCriteria(HznSwapXccy.class).add(Restrictions.eq("referans", iMap.getString("REFERANS")));
			List<?> listxcy = swap.list();

			for (Iterator<?> itrxcy = listxcy.iterator(); itrxcy.hasNext();) {
				HznSwapXccy hznSwapTx = (HznSwapXccy) itrxcy.next();

				oMap.put("BORC_SPREAD_YONU", hznSwapTx.getBorcSpreadYonu());
				oMap.put("ALACAK_SPREAD_YONU", hznSwapTx.getAlacakSpreadYonu());
				oMap.put("ALACAK_SPREAD_YONU", hznSwapTx.getAlacakSpreadYonu());

				oMap.put("BORC_ESAS_GUN_SAYISI", hznSwapTx.getBorcEsasGunSayisi());
				oMap.put("ALACAK_ESAS_GUN_SAYISI", hznSwapTx.getAlacakEsasGunSayisi());

				oMap.put("BORC_SPREAD_CUR", hznSwapTx.getBorcSpread());
				oMap.put("ALACAK_SPREAD_CUR", hznSwapTx.getAlacakSpread());

				oMap.put("BORC_FREKANS", hznSwapTx.getBorcFrekans());
				oMap.put("ALACAK_FREKANS", hznSwapTx.getAlacakFrekans());

				oMap.put("BORC_FAIZ_FREKANS", hznSwapTx.getBorcFaizFrekans());
				oMap.put("ALACAK_FAIZ_FREKANS", hznSwapTx.getAlacakFaizFrekans());
				BigDecimal c;

				oMap.put("BORC_FAIZ", hznSwapTx.getBorcIlkFaiz());
				oMap.put("ALACAK_FAIZ", hznSwapTx.getAlacakIlkFaiz());

				if (hznSwapTx.getDurumKodu().equals("G")) {
					oMap.put("RDB_GUNCEL", true);
					oMap.put("RDB_KAPAMA", false);
				}
				else {
					oMap.put("RDB_GUNCEL", false);
					oMap.put("RDB_KAPAMA", true);
				}
				Criteria criteria = session.createCriteria(HznSwapXccyCf.class).add(Restrictions.eq("id.referans", iMap.getString("REFERANS")));
				criteria.add(Restrictions.eq("id.yon", "A"));
				criteria.addOrder(Order.asc("id.vadeTarihi"));
				List<?> list = criteria.list();
				int i = 0;
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					HznSwapXccyCf hznSwapXccyCf = (HznSwapXccyCf) iterator.next();

					String tn = "ALACAK_TABLE";

					oMap.put(tn, i, "ANAPARAMI", hznSwapXccyCf.getId().getDurum().equals("X") ? "E" : "H");
					oMap.put(tn, i, "DOVIZ_KODU", hznSwapXccyCf.getDovizKodu());

					String durum = hznSwapXccyCf.getId().getDurum();
					String sonDurum = null;
					if (durum.equals("O"))
						sonDurum = "ACIK";
					if (durum.equals("T"))
						sonDurum = "ODENDI";
					if (durum.equals("X"))
						sonDurum = "ANAPARA ODEMESI";
					oMap.put(tn, i, "DURUM", sonDurum);

					oMap.put(tn, i, "DURUM", sonDurum);
					oMap.put(tn, i, "MAX_TUTAR", hznSwapXccyCf.getFaizCinsi());
					oMap.put(tn, i, "TUTAR", hznSwapXccyCf.getIlkHesaplananTutar());
					oMap.put(tn, i, "ODEME_TUTAR", hznSwapXccyCf.getOdemeGunuTutar());
					oMap.put(tn, i, "VADE", hznSwapXccyCf.getId().getVadeTarihi());
					oMap.put(tn, i, "FAIZ", hznSwapXccyCf.getIlkFaiz());
					oMap.put(tn, i, "FAIZ_TARIH", hznSwapXccyCf.getFaizGuncellemeTarih());

					MuhFis listFis = (MuhFis) session.createCriteria(MuhFis.class).add(Restrictions.eq("islemNumara", hznSwapXccyCf.getSonTxno())).add(Restrictions.eq("tur", "G")).uniqueResult();

					if (listFis != null)
						oMap.put(tn, i, "SON_TX_NO", listFis.getNumara());
					i++;

				}

				criteria = session.createCriteria(HznSwapXccyCf.class).add(Restrictions.eq("id.referans", iMap.getString("REFERANS")));
				criteria.add(Restrictions.eq("id.yon", "B"));
				criteria.addOrder(Order.asc("id.vadeTarihi"));
				list = criteria.list();

				i = 0;
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					HznSwapXccyCf hznSwapXccyCfTx = (HznSwapXccyCf) iterator.next();

					String tn = "BORC_TABLE";

					oMap.put(tn, i, "ANAPARAMI", hznSwapXccyCfTx.getId().getDurum().equals("X") ? "E" : "H");
					oMap.put(tn, i, "DOVIZ_KODU", hznSwapXccyCfTx.getDovizKodu());
					String durum = hznSwapXccyCfTx.getId().getDurum();
					String sonDurum = null;
					if (durum.equals("O"))
						sonDurum = "ACIK";
					if (durum.equals("T"))
						sonDurum = "ODENDI";
					if (durum.equals("X"))
						sonDurum = "ANAPARA ODEMESI";
					oMap.put(tn, i, "DURUM", sonDurum);
					oMap.put(tn, i, "MAX_TUTAR", hznSwapXccyCfTx.getFaizCinsi());
					oMap.put(tn, i, "FAIZ", hznSwapXccyCfTx.getIlkFaiz());
					oMap.put(tn, i, "TUTAR", hznSwapXccyCfTx.getIlkHesaplananTutar());
					oMap.put(tn, i, "ODEME_TUTAR", hznSwapXccyCfTx.getOdemeGunuTutar());
					oMap.put(tn, i, "VADE", hznSwapXccyCfTx.getId().getVadeTarihi());
					oMap.put(tn, i, "FAIZ_TARIH", hznSwapXccyCfTx.getFaizGuncellemeTarih());

					MuhFis listFis = (MuhFis) session.createCriteria(MuhFis.class).add(Restrictions.eq("islemNumara", hznSwapXccyCfTx.getSonTxno())).add(Restrictions.eq("tur", "G")).uniqueResult();

					if (listFis != null)
						oMap.put(tn, i, "SON_TX_NO", listFis.getNumara());

					i++;
				}

			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}


	/************************************************************************************************************************************************************************************************************************/

	@GraymoundService("BNSPR_TCMB_TUREV_DATA_WITH_EXCEL")
	public static GMMap sendTcmbTurevDataWithExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		XSSFWorkbook wb = null;
		String tempDosyaAdi = null;

		try {
			conn = DALUtil.getGMConnection();

			iMap.put("PARAMETRE", "TCMB_PATH_FILE");
			String filePath = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
			iMap.put("PARAMETRE", "TCMB_FILE_NAME");//TODO
			String fileName = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
			iMap.put("PARAMETRE", "TCMB_FILE_WRITE_OPTIONS_PARAM");
			String options = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

			if (options.equals("0")) {
				tempDosyaAdi = ROOT + File.separator + "files" + File.separator + "YuksekFrekansTurev" + ".xlsx";
			}
			else {
				tempDosyaAdi = filePath + File.separator + fileName + File.separator + "YuksekFrekansTurev" + ".xlsx";
			}

			stmt = conn.prepareCall("{? = call PKG_RC_INV_TCMB.RC_TUREV_DATA()}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			try {
				wb = new XSSFWorkbook();
				XSSFSheet sheet1 = wb.createSheet("YuksekFrekansTurev");
				FileOutputStream fileOut = new FileOutputStream(tempDosyaAdi);
				// Baslik satiri.
				int columnCount = 0;
				{
					Row row = sheet1.createRow(0);
					Cell cell = row.createCell(columnCount);
					cell.setCellValue("SiraNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("KayitID");
					cell = row.createCell(++columnCount);
					cell.setCellValue("katilimciKod");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kimlikTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kimlikId");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kurumAdi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kurumTipi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("ulkeKodu");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemAltTur");
					cell = row.createCell(++columnCount);
					cell.setCellValue("paraKod");
					cell = row.createCell(++columnCount);
					cell.setCellValue("karsiParaKodu");
					cell = row.createCell(++columnCount);
					cell.setCellValue("spotKur");
					cell = row.createCell(++columnCount);
					cell.setCellValue("forwardKur");
					cell = row.createCell(++columnCount);
					cell.setCellValue("faizOrani");
					cell = row.createCell(++columnCount);
					cell.setCellValue("tlTutar");
					cell = row.createCell(++columnCount);
					cell.setCellValue("tutar");
					cell = row.createCell(++columnCount);
					cell.setCellValue("usdTutar");
					cell = row.createCell(++columnCount);
					cell.setCellValue("valorTarihi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemZamani");
					cell = row.createCell(++columnCount);
					cell.setCellValue("vadeTarihi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemGercekBirim");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemAmaci");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kayitTuru");

					columnCount = 0;
				}

				for (int rowNum = 1; rSet.next(); rowNum++) {
					Row row = sheet1.createRow(rowNum);
					columnCount = 0;

					Cell cell = row.createCell(columnCount);

					cell.setCellValue((rowNum));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("kayitid"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("katilimciKod"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("kimlikTuru"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("kimlikId"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("kurumAdi"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("kurumTipi"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("ulkeKodu"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("islemTuru"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("islemAltTur"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("paraKod"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("karsiParaKodu"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(getSpotkur(rSet));
					cell = row.createCell(++columnCount);

					cell.setCellValue(getForwardkur(rSet));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("faizOran�"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(getTlTutar(rSet));
					cell = row.createCell(++columnCount);

					cell.setCellValue(getTutar(rSet));
					cell = row.createCell(++columnCount);
					
					cell.setCellValue(getUsdTutar(rSet));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("valorTarihi"));
					cell = row.createCell(++columnCount);
					
					SimpleDateFormat df2 = new SimpleDateFormat("dd.MM.yyyy HH:mm");
					String dateText = df2.format(rSet.getTimestamp("islemZamani"));
					cell.setCellValue((dateText));
					cell = row.createCell(++columnCount);
					
					cell.setCellValue(rSet.getString("vadeTarihi"));
					cell = row.createCell(++columnCount); 

					cell.setCellValue(rSet.getString("islemGercekBirim"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("islemAmaci"));
					cell = row.createCell(++columnCount);

					cell.setCellValue(rSet.getString("kayitTuru"));
					cell = row.createCell(++columnCount);

				}
				wb.write(fileOut);
				fileOut.close();

				if (columnCount > 0)
					sendMailTurev("YuksekFrekansTurev", tempDosyaAdi);

			}
			catch (Exception e) {
				System.out.println("An error occurred.");
				e.printStackTrace();
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static String getSpotkur(ResultSet rSet) throws SQLException {
		if(rSet.getBigDecimal("spotKur") == null){
			return null;	
		}		
		return new DecimalFormat("##.##").format(rSet.getBigDecimal("spotKur"));
	}
	
	private static String getForwardkur(ResultSet rSet) throws SQLException {
		if(rSet.getBigDecimal("forwardKur") == null){
			return null;	
		}		
		return new DecimalFormat("##.##").format(rSet.getBigDecimal("forwardKur"));
	}
	
	private static String getUsdTutar(ResultSet rSet) throws SQLException {
		if(rSet.getString("usdTutar") == null){
			return null;	
		}		
		return rSet.getString("usdTutar").replace(".",",");
	}
	
	private static String getTutar(ResultSet rSet) throws SQLException {
		if(rSet.getString("tutar") == null){
			return null;	
		}		
		return rSet.getString("tutar").replace(".",",");
	}
	
	private static String getTlTutar(ResultSet rSet) throws SQLException {
		if(rSet.getString("tlTutar") == null){
			return null;	
		}		
		
		return rSet.getString("tlTutar").replace(".",",");
	}


	private static void sendMailTurev(String fileName, String tempDosyaAdi) throws IOException {
		GMMap mailMap = new GMMap();
		GMMap paramMap = new GMMap();

		mailMap.put("MAIL_FROM", "aktifbank@aktifbank.com.tr");
		paramMap.put("PARAMETRE", "TCMB_SPOT_DVZ_MAIL_TO");
		String mailTo = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", paramMap).get("DEGER").toString();
		mailMap.put("MAIL_TO", mailTo);
		mailMap.put("MAIL_SUBJECT", "TCMB YUKSEK FREKANS TUREV EXCEL GONDERIM Bilgilendirme");
		mailMap.put("MAIL_BODY", "TCMB i�in hazirlanan dosya ektedir.");
		mailMap.put("IS_BODY_HTML", "H");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", fileName + ".xlsx");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(tempDosyaAdi));
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
	}
}
