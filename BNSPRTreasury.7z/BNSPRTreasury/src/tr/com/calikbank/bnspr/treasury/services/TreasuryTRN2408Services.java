package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AltinPuanBozdurmaLog;
import tr.com.calikbank.bnspr.dao.AltinPuanBozdurmaTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class TreasuryTRN2408Services {
	
	public static final String Request_Normal = "N";
	public static final String Request_Refund = "R";
	
	private static final String ERRORMESSAGE_CARD_NO_CAN_NOT_BE_NULL = "Kart No bo� ge�ilemez.";
	private static final String ERRORMESSAGE_EXCHANGE_AMOUNT_CAN_NOT_BE_NULL = "Alt�n Puan bo� ge�ilemez.";
	private static final String ERRORMESSAGE_EXCHANGE_AMOUNT_POSITIVE_INTEGER = "Alt�n Puan s�f�rdan b�y�k olmal�d�r.";
	private static final String ERRORMESSAGE_XAU_CURRENCY_NOT_FOUND = "Alt�n Kur bulunamad�."; 
	private static final String ERRORMESSAGE_XAU_CURRENCY_CHANGED = "Alt�n Kur de�i�mi�tir.";
	private static final String ERRORMESSAGE_MISSING_CARD_NO = "Kart bulunamad�."; 
	private static final String ERRORMESSAGE_POINT_INFO_NOT_FOUND = "Puan bilgileri bulunamad�."; 
	private static final String ERRORMESSAGE_XAU_SUBLIMIT = "mg alt�ndaki puanlar� bozduramazs�n�z.";
	private static final String ERRORMESSAGE_XAU_USABLE_LIMIT = "Puan tutar�ndan b�y�k tutar giri�i yapamazs�n�z.";
	
	@GraymoundService("BNSPR_TRN2408_FILL_COMBOBOX_INITIAL_VALUE")  
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			iMap.put("KOD", "ALTIN_BOZDURMA_KART_TIPI");
			oMap.put("KART_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2408_ALTIN_PUAN_BOZDUR")
	public static GMMap altinPuanBozdur(GMMap iMap){
	       
	  GMMap oMap= new GMMap();
	  GMMap iCardMap = new GMMap();
	  GMMap oCardMap = new GMMap();
	  GMMap iPuanMap = new GMMap();
	  GMMap oPuanMap = new GMMap();
	  GMMap trxInputMap = new GMMap();
	  GMMap trxOutputMap = new GMMap();
	  try{
	       String cardNo = iMap.getString("CARD_NO").trim();
	       BigDecimal exchangeAmount = iMap.getBigDecimal("EXCHANGE_AMOUNT");
	       BigDecimal iexchangeAmountTL = iMap.getBigDecimal("EXCHANGE_AMOUNT_TL").setScale(2);

	       if(cardNo==null  || cardNo.isEmpty()){
	    	   oMap.put("ERROR",ERRORMESSAGE_CARD_NO_CAN_NOT_BE_NULL);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
	       }
	       else if (exchangeAmount==null){
	    	   oMap.put("ERROR",ERRORMESSAGE_EXCHANGE_AMOUNT_CAN_NOT_BE_NULL);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
	       }
	       else if (exchangeAmount.compareTo(BigDecimal.ZERO) != 1)
	       {
	    	   oMap.put("ERROR",ERRORMESSAGE_EXCHANGE_AMOUNT_POSITIVE_INTEGER);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
	       }
	       else{
	    	   iCardMap.put("KART_NO", cardNo);
		       oCardMap = GMServiceExecuter.call("BNSPR_TRN2408_SORGULA", iCardMap); //card bilgileri getirir 
		       String notFoundMsg = oCardMap.getString("NOTFOUND");
	
		       if(notFoundMsg != null && !notFoundMsg.isEmpty() )
		       {
		    	   oMap.put("ERROR",notFoundMsg);
		    	   oMap.put("RETURN_CODE", 0);
		    	   return oMap;
		       }
		       else
		       {
		    	   String kartTipi = getCardType(oCardMap.getString("KART_BILGILERI", 0, "KART_TIPI"),"2");
		    	   String productAdi = oCardMap.getString("KART_BILGILERI", 0, "PRODUCT_ADI");
		    	   String productId = oCardMap.getString("KART_BILGILERI", 0, "PRODUCT_ID");
		    	   String musteriNo = oCardMap.getString("KART_BILGILERI", 0, "MUSTERI_NO");
		    	   String hesapNo = oCardMap.getString("KART_BILGILERI", 0, "HESAP_NO");
		    	   BigDecimal altinKur = GMServiceExecuter.call("BNSPR_TRN2408_ALTINKURGETIR",new GMMap()).getBigDecimal("KUR");
		    	   
				   Session session = DAOSession.getSession("BNSPRDal");
				   AltinPuanBozdurmaTx altinPuanBozdurmaTx = new AltinPuanBozdurmaTx();
				   altinPuanBozdurmaTx.setXauCurrency(altinKur); // tabloda gram cinsinden set et
				   
				   iPuanMap.put("KUR", altinKur);
		    	   altinKur = altinKur.divide(new BigDecimal(1000)); //miligram i�in
		    	   
		    	   if(altinKur==null  || altinKur.compareTo(BigDecimal.ZERO) != 1)	
		    	   {
			    	   oMap.put("ERROR",ERRORMESSAGE_XAU_CURRENCY_NOT_FOUND);
			    	   oMap.put("RETURN_CODE", 0);
			    	   return oMap;
		    	   }

			       BigDecimal oexchangeAmountTL = altinKur.multiply(exchangeAmount).setScale(2, RoundingMode.HALF_UP);
			       if(!oexchangeAmountTL.equals(iexchangeAmountTL)){
				    	oMap.put("ERROR",ERRORMESSAGE_XAU_CURRENCY_CHANGED);
				    	oMap.put("RETURN_CODE", 0);
				    	return oMap;
			       }
		    	   iPuanMap.put("KART_NO", cardNo);
		    	   iPuanMap.put("MUSTERI_NO", musteriNo);

		    	   oPuanMap = GMServiceExecuter.call("BNSPR_TRN2408_GET_PUAN_BILGISI", iPuanMap); //puan bilgileri getirir 
	
		    	   if(!oPuanMap.getString("RETURN_CODE").equals("2")){
			    	   oMap.put("ERROR",ERRORMESSAGE_POINT_INFO_NOT_FOUND);
			    	   oMap.put("RETURN_CODE", 0);
			    	   return oMap;
		    	   }
		    	   BigDecimal usablePoint=oPuanMap.getBigDecimal("USABLE_POINT");
		    	   BigDecimal cycleEarnedPoint = oPuanMap.getBigDecimal("CYCLE_EARNED_POINT");
		    	   BigDecimal cyclePointExchange = oPuanMap.getBigDecimal("CYCLE_POINT_EXCHANGE");
		    	   BigDecimal cycleRepurchasedPoint = oPuanMap.getBigDecimal("CYCLE_REPURCHASED_POINT");
		    	   BigDecimal totalEarnedPoint = oPuanMap.getBigDecimal("TOTAL_EARNED_POINT");
		    	   BigDecimal totalPointExchange = oPuanMap.getBigDecimal("TOTAL_POINT_EXCHANGE");
		    	   BigDecimal revolvingPoint = oPuanMap.getBigDecimal("REVOLVING_POINT");
		    	   BigDecimal pointExchangeSubLimit = oPuanMap.getBigDecimal("POINT_EXCHANGE_SUB_LIMIT");
		    	   
		    	   if(pointExchangeSubLimit.compareTo(exchangeAmount)==1){
			    	   oMap.put("ERROR", pointExchangeSubLimit + ERRORMESSAGE_XAU_SUBLIMIT);
			    	   oMap.put("RETURN_CODE", 0);
			    	   return oMap;
		    	   }
		    	   if(exchangeAmount.compareTo(usablePoint)==1){
			    	   oMap.put("ERROR",  ERRORMESSAGE_XAU_USABLE_LIMIT);
			    	   oMap.put("RETURN_CODE", 0);
			    	   return oMap;
		    	   }
		
				    BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO",new GMMap()).getBigDecimal("TRX_NO");
					altinPuanBozdurmaTx.setTxNo(trxNo);
					altinPuanBozdurmaTx.setCustomerNo(new BigDecimal(musteriNo));
					altinPuanBozdurmaTx.setCardNo(cardNo);
					altinPuanBozdurmaTx.setExchangeAmount(exchangeAmount);
					altinPuanBozdurmaTx.setProductId(productId);
					altinPuanBozdurmaTx.setProductName(productAdi);
					altinPuanBozdurmaTx.setCardType(kartTipi);
					if(hesapNo!=null)
						altinPuanBozdurmaTx.setAccountNo(new BigDecimal(hesapNo));
					altinPuanBozdurmaTx.setUsablePoint(usablePoint);
					altinPuanBozdurmaTx.setCycleEarnedPoint(cycleEarnedPoint);
					altinPuanBozdurmaTx.setCyclePointExchange(cyclePointExchange);
					altinPuanBozdurmaTx.setCycleRepurchasedPoint(cycleRepurchasedPoint);
					altinPuanBozdurmaTx.setTotalEarnedPoint(totalEarnedPoint);
					altinPuanBozdurmaTx.setTotalPointExchange(totalPointExchange);
					altinPuanBozdurmaTx.setRevolvingPoint(revolvingPoint);
					altinPuanBozdurmaTx.setPointExchangeSubLimit(pointExchangeSubLimit);
					altinPuanBozdurmaTx.setChannelCode((String)GMContext.getCurrentContext().getSession().get("CHANNEL_CODE"));
					
					session.saveOrUpdate(altinPuanBozdurmaTx);
					session.flush();
									
					trxInputMap.put("TRX_NO", trxNo);
					trxInputMap.put("TRX_NAME", "2408");  
					trxOutputMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",trxInputMap)); 
					trxOutputMap.put("RETURN_CODE",2);

		            return trxOutputMap;
		       }
	       }
			
	       }
	       catch(Exception e){
	            e.printStackTrace();
	            oMap.put("ERROR",e.getMessage());
	            oMap.put("RETURN_CODE", 0);
	            return oMap;
	       }

	}
	
	@GraymoundService("BNSPR_TRN2408_SORGULA")
	public static GMMap sorgula(GMMap inputMap){
		
        GMMap outputMap= new GMMap();
        GMMap oMap= new GMMap();
        GMMap oMapAcc= new GMMap();
        GMMap iMapAcc= new GMMap();
        GMMap iMap = new GMMap();
        String cardNo = inputMap.getString("KART_NO").trim();
        String tckn = inputMap.getString("TCKN");
        String customerNo = inputMap.getString("MUSTERI_NO");
        String notFoundMessage ="";

        try{
            if(cardNo!=null  && !cardNo.isEmpty()){
                iMap.put("CARD_NO", cardNo);
	        	oMap = GMServiceExecuter.call("BNSPR_CRD_GET_CARD_INFO_WITH_CARD_NO", iMap);
	        	if (oMap !=  null){
                    outputMap.put("KART_BILGILERI", 0, "KART_NO", cardNo);
                    outputMap.put("KART_BILGILERI", 0, "KART_NO_MASKE", maskCardNumber(cardNo));
                    outputMap.put("KART_BILGILERI", 0, "KART_TIPI", getCardType(oMap.getString("CARD_DCI"),"1"));
                    outputMap.put("KART_BILGILERI", 0, "PRODUCT_ADI", oMap.getString("CARD_PRODUCT_NAME"));	
                    outputMap.put("KART_BILGILERI", 0, "PRODUCT_ID", oMap.getString("PRODUCT_ID"));	
                    outputMap.put("KART_BILGILERI", 0, "MUSTERI_NO", oMap.getString("CUSTOMER_NO"));	
                    
                    if( oMap.getString("CARD_DCI").equals("D"))
                    {
                    	iMapAcc.put("CARD_NO", cardNo);
                    	oMapAcc = GMServiceExecuter.call("BNSPR_INTRACARD_TFF_GET_DEBIT_CARD_MAIN_ACCOUNT", iMapAcc);
                    	String hesapNo = oMapAcc.getString("DEBIT_ACCOUNT_NO");
                    	if(hesapNo != null && !hesapNo.isEmpty())
                    		outputMap.put("KART_BILGILERI", 0, "HESAP_NO", hesapNo );  
                    }
	        	}
	        	else 
	        		notFoundMessage = ERRORMESSAGE_MISSING_CARD_NO;
            }	
            else{
            	 if(tckn!=null  && !tckn.isEmpty()){
            		iMap.put("INPUT_PARAMETER_TYPE", "TCKN");
            		iMap.put("TCKN", tckn);
            	 }
            	 else if(customerNo!=null  && !customerNo.isEmpty()){
            		iMap.put("INPUT_PARAMETER_TYPE", "CST");
            		iMap.put("CUSTOMER_NO", customerNo);
            	 }	                
	                iMap.put("NO_NEED_APPLICATIONS", true);
		        	oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap);
	            	if (oMap !=  null && oMap.getSize("CARD_DETAIL_INFO") > 0) {
		                for (int i = 0; i < oMap.getSize("CARD_DETAIL_INFO"); i++) {
		                	
		                    cardNo = oMap.getString("CARD_DETAIL_INFO", i, "CARD_NO");
		                    String cardType = oMap.getString("CARD_DETAIL_INFO", i, "CARD_DCI_AKUSTIK");
		                    String productName = oMap.getString("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME");
		                    String productId = oMap.getString("CARD_DETAIL_INFO", i, "PRODUCT_ID");
		                    customerNo = oMap.getString("CARD_DETAIL_INFO", i, "CUSTOMER_NO");
		                    
		                    outputMap.put("KART_BILGILERI", i, "KART_NO", cardNo);
		                    outputMap.put("KART_BILGILERI", i, "KART_NO_MASKE", maskCardNumber(cardNo));
		                    outputMap.put("KART_BILGILERI", i, "KART_TIPI", getCardType(cardType,"1"));
		                    outputMap.put("KART_BILGILERI", i, "PRODUCT_ADI", productName);
		                    outputMap.put("KART_BILGILERI", i, "PRODUCT_ID", productId);	
		                    outputMap.put("KART_BILGILERI", i, "MUSTERI_NO", customerNo);
		                    
		                    if(cardType.equals("D"))
		                    {
		                    	iMapAcc.put("CARD_NO", cardNo);
		                    	oMapAcc = GMServiceExecuter.call("BNSPR_INTRACARD_TFF_GET_DEBIT_CARD_MAIN_ACCOUNT", iMapAcc);
		                    	String hesapNo = oMapAcc.getString("DEBIT_ACCOUNT_NO");
		                    	if(hesapNo != null && !hesapNo.isEmpty())
		                    		outputMap.put("KART_BILGILERI", i, "HESAP_NO", hesapNo );
		                    }
		                }
	              }
	              else 
	                	notFoundMessage = ERRORMESSAGE_MISSING_CARD_NO;
            }
        }
        catch(Exception e){
            e.printStackTrace();
            notFoundMessage = ERRORMESSAGE_MISSING_CARD_NO;

        }
       
        outputMap.put("NOTFOUND", notFoundMessage);
        return outputMap;
    }		

	@GraymoundService("BNSPR_TRN2408_GET_PUAN_BILGISI")
	public static GMMap puanSorgula(GMMap inputMap){
		
        GMMap outputMap= new GMMap();
        GMMap oMap= new GMMap();
        GMMap iMap = new GMMap();
        
        try{
	        String cardNo = inputMap.getString("KART_NO").trim();
	        String customerNo = inputMap.getString("MUSTERI_NO");
	        BigDecimal kur = new BigDecimal(0);
	        kur = inputMap.getBigDecimal("KUR");
	        kur = kur.divide(new BigDecimal(1000)); //miligram i�in		
            iMap.put("CUSTOMER_NO", customerNo);
            iMap.put("CARD_NO", cardNo);

        	oMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CUSTOMER_POINT_INFO", iMap);
        	
     /*   	
     //---- servis calisinca bunu kaldir   	
        	oMap.put("USABLE_POINT", 5.23);//KULLANILABILIR PUAN
        	oMap.put("CYCLE_EARNED_POINT", 2.32); //DONEM ICI KAZANILAN PUAN
        	oMap.put("CYCLE_POINT_EXCHANGE", 1.11); //DONEM ICI BOZDURULAN PUAN
        	oMap.put("CYCLE_REPURCHASED_POINT", 1.78); //DONEM ICI GERI ALINAN PUAN
        	oMap.put("TOTAL_EARNED_POINT", 9.65); //TOPLAM KAZANILAN PUAN
        	oMap.put("TOTAL_POINT_EXCHANGE", 5.43); //TOPLAM BOZDURULAN PUAN
        	oMap.put("REVOLVING_POINT", 4.36); //DEVREDEN PUAN
        	oMap.put("POINT_EXCHANGE_SUB_LIMIT", 0.50); //PUAN BOZDURMA ALT LIMIT
     //-----------------------------------   	
     */   	
        	if(oMap.getString("RETURN_CODE").equals("2"))
        	{
        		if(oMap.getSize("POINT_TABLE")>0){
		        	BigDecimal usablePoint = oMap.getBigDecimal("POINT_TABLE", 0, "USABLE_POINT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("USABLE_POINT", usablePoint);//KULLANILABILIR PUAN
		        	BigDecimal cycleEarnedPoint = oMap.getBigDecimal("POINT_TABLE", 0, "CYCLE_EARNED_POINT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("CYCLE_EARNED_POINT", cycleEarnedPoint); //DONEM ICI KAZANILAN PUAN
		        	BigDecimal cyclePointExchange = oMap.getBigDecimal("POINT_TABLE", 0, "CYCLE_POINT_EXCHANGE").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("CYCLE_POINT_EXCHANGE",  cyclePointExchange); //DONEM ICI BOZDURULAN PUAN
		        	BigDecimal cycleRepurchasedPoint = oMap.getBigDecimal("POINT_TABLE", 0, "CYCLE_REPURCHASED_POINT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("CYCLE_REPURCHASED_POINT", cycleRepurchasedPoint); //DONEM ICI GERI ALINAN PUAN
		        	BigDecimal totalEarnedPoint = oMap.getBigDecimal("POINT_TABLE", 0, "TOTAL_EARNED_POINT").setScale(2, RoundingMode.HALF_UP);   	
		        	outputMap.put("TOTAL_EARNED_POINT", totalEarnedPoint ); //TOPLAM KAZANILAN PUAN
		        	BigDecimal totalPointExchange = oMap.getBigDecimal("POINT_TABLE", 0, "TOTAL_POINT_EXCHANGE").setScale(2, RoundingMode.HALF_UP);       	
		        	outputMap.put("TOTAL_POINT_EXCHANGE", totalPointExchange); //TOPLAM BOZDURULAN PUAN
		        	BigDecimal revolvingPoint  = oMap.getBigDecimal("POINT_TABLE", 0, "REVOLVING_POINT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("REVOLVING_POINT", revolvingPoint ); //DEVREDEN PUAN
		        	BigDecimal pointExhangeSubLimit  = oMap.getBigDecimal("POINT_TABLE", 0, "POINT_EXCHANGE_SUB_LIMIT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("POINT_EXCHANGE_SUB_LIMIT", pointExhangeSubLimit); //PUAN BOZDURMA ALT LIMIT
		        	BigDecimal dailyEarnedPoint  = oMap.getBigDecimal("POINT_TABLE", 0, "DAILY_EARNED_POINT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("DAILY_EARNED_POINT", dailyEarnedPoint);  //GUNLUK KAZANILAN PUAN
		        	BigDecimal dailyUsedPoint  = oMap.getBigDecimal("POINT_TABLE", 0, "DAILY_USED_POINT").setScale(2, RoundingMode.HALF_UP);
		        	outputMap.put("DAILY_USED_POINT", dailyUsedPoint);  //GUNLUK BOZDURULAN PUAN	        	       	
		        		        	
		        	outputMap.put("USABLE_POINT_TL", usablePoint.multiply(kur).setScale(2, RoundingMode.HALF_UP));//KULLANILABILIR PUAN
		        	outputMap.put("CYCLE_EARNED_POINT_TL", cycleEarnedPoint.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //DONEM ICI KAZANILAN PUAN
		        	outputMap.put("CYCLE_POINT_EXCHANGE_TL",  cyclePointExchange.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //DONEM ICI BOZDURULAN PUAN      	
		        	outputMap.put("CYCLE_REPURCHASED_POINT_TL", cycleRepurchasedPoint.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //DONEM ICI GERI ALINAN PUAN        	
		        	outputMap.put("TOTAL_EARNED_POINT_TL",  totalEarnedPoint.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //TOPLAM KAZANILAN PUAN       	
		        	outputMap.put("TOTAL_POINT_EXCHANGE_TL",  totalPointExchange.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //TOPLAM BOZDURULAN PUAN        	
		        	outputMap.put("REVOLVING_POINT_TL", revolvingPoint.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //DEVREDEN PUAN
		        	outputMap.put("POINT_EXCHANGE_SUB_LIMIT_TL",  pointExhangeSubLimit.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //PUAN BOZDURMA ALT LIMIT
		        	outputMap.put("DAILY_EARNED_POINT_TL",  dailyEarnedPoint.multiply(kur).setScale(2, RoundingMode.HALF_UP));  //GUNLUK KAZANILAN PUAN
		        	outputMap.put("DAILY_USED_POINT_TL",  dailyUsedPoint.multiply(kur).setScale(2, RoundingMode.HALF_UP)); //GUNLUK BOZDURULAN PUAN
	        		}
	        	outputMap.put("ERROR","");
	        	outputMap.put("RETURN_CODE", "2");
        	}
        	else
        	{
        		outputMap.put("ERROR",ERRORMESSAGE_POINT_INFO_NOT_FOUND);
			    outputMap.put("RETURN_CODE", 0);
        	}
        }
        catch(Exception e){
            e.printStackTrace();
    		outputMap.put("ERROR", ERRORMESSAGE_POINT_INFO_NOT_FOUND + "" + e.getMessage() );
		    outputMap.put("RETURN_CODE", 0);
		    return outputMap;
        }

        return outputMap;
	}
	
	@GraymoundService("BNSPR_TRN2408_ALTINKURGETIR")
    public static GMMap altinKurGetir(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            int i = 1; 
            GMMap oMap = new GMMap();

            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_KUR.DAK_TO_LC('XAU',1) }"); 
            stmt.registerOutParameter(i++,Types.DECIMAL );
            stmt.execute(); 
            BigDecimal miktar = stmt.getBigDecimal(1).setScale(2, RoundingMode.HALF_UP);
            oMap.put("KUR" ,miktar);
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(conn);          
        }
	}
	@GraymoundService("BNSPR_TRN2408_BOZUMTUTARTL_HESAPLA")	
    public static GMMap bozumTutarTLHesapla(GMMap iMap) {
        BigDecimal bozumtutar  = null;
        BigDecimal bozumtutartl = null;
        BigDecimal kur = null;
        BigDecimal bin = new BigDecimal(1000);
        try {
        	bozumtutar = iMap.getBigDecimal("BOZUM_TUTAR");
        	kur = iMap.getBigDecimal("KUR");
        	bozumtutartl = bozumtutar.multiply(kur).divide(bin).setScale(2, RoundingMode.HALF_UP);
            GMMap oMap = new GMMap();
            
            oMap.put("BOZUM_TUTAR_TL" ,bozumtutartl);
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
	}
	
	@GraymoundService("BNSPR_TRN2408_SAVE")
    public static GMMap save(GMMap iMap){
		try
		{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			AltinPuanBozdurmaTx altinPuanBozdurmaTx = (AltinPuanBozdurmaTx)session.get(AltinPuanBozdurmaTx.class, iMap.getBigDecimal("TRX_NO"));
			if(altinPuanBozdurmaTx == null) {
				altinPuanBozdurmaTx = new AltinPuanBozdurmaTx();
			}
			altinPuanBozdurmaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			altinPuanBozdurmaTx.setCustomerNo(iMap.getBigDecimal("CUSTOMER_NO"));
			altinPuanBozdurmaTx.setCardNo(iMap.getString("CARD_NO"));
			altinPuanBozdurmaTx.setTckn(iMap.getString("TCKN"));
			altinPuanBozdurmaTx.setProductId(iMap.getString("PRODUCT_ID"));
			altinPuanBozdurmaTx.setProductName(iMap.getString("PRODUCT_NAME"));
			altinPuanBozdurmaTx.setCardType(getCardType(iMap.getString("CARD_TYPE"),"2"));
			altinPuanBozdurmaTx.setAccountNo(iMap.getBigDecimal("ACCOUNT_NO"));
			altinPuanBozdurmaTx.setUsablePoint(iMap.getBigDecimal("USABLE_POINT"));  
			altinPuanBozdurmaTx.setCycleEarnedPoint(iMap.getBigDecimal("CYCLE_EARNED_POINT"));
			altinPuanBozdurmaTx.setCyclePointExchange(iMap.getBigDecimal("CYCLE_POINT_EXCHANGE"));
			altinPuanBozdurmaTx.setCycleRepurchasedPoint(iMap.getBigDecimal("CYCLE_REPURCHASED_POINT"));
			altinPuanBozdurmaTx.setTotalEarnedPoint(iMap.getBigDecimal("TOTAL_EARNED_POINT"));
			altinPuanBozdurmaTx.setTotalPointExchange(iMap.getBigDecimal("TOTAL_POINT_EXCHANGE"));
			altinPuanBozdurmaTx.setRevolvingPoint(iMap.getBigDecimal("REVOLVING_POINT"));
			altinPuanBozdurmaTx.setPointExchangeSubLimit(iMap.getBigDecimal("POINT_EXCHANGE_SUB_LIMIT"));
			altinPuanBozdurmaTx.setExchangeAmount(iMap.getBigDecimal("EXCHANGE_AMOUNT"));
			altinPuanBozdurmaTx.setXauCurrency(iMap.getBigDecimal("XAU_CURRENCY"));
			altinPuanBozdurmaTx.setChannelCode((String)GMContext.getCurrentContext().getSession().get("CHANNEL_CODE"));
			session.saveOrUpdate(altinPuanBozdurmaTx);
			session.flush();
			
			iMap.put("TRX_NAME", "2408");            
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap));
            return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN2408_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
        GMMap inputMap= new GMMap();
        GMMap reverseMap= new GMMap();
        GMMap revOutputMap= new GMMap();       
        GMMap outputMap= new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
        try{
			Session session = DAOSession.getSession("BNSPRDal");
			
            AltinPuanBozdurmaTx altinPuanBozdurmaTx =
                    (AltinPuanBozdurmaTx) session.createCriteria(AltinPuanBozdurmaTx.class).add(
                            Restrictions.eq("txNo" , iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			if(altinPuanBozdurmaTx == null) {
				altinPuanBozdurmaTx = new AltinPuanBozdurmaTx();
			}
			
			BigDecimal puan = altinPuanBozdurmaTx.getExchangeAmount();
			BigDecimal altinKur = altinPuanBozdurmaTx.getXauCurrency();
			String cardNo = altinPuanBozdurmaTx.getCardNo();
			String channelCode = altinPuanBozdurmaTx.getChannelCode();
			BigDecimal txNo= altinPuanBozdurmaTx.getTxNo();
			inputMap.put("REQUEST_TYPE", Request_Normal);
			inputMap.put("CHANNEL_CODE", channelCode);
			inputMap.put("TX_NO", altinPuanBozdurmaTx.getTxNo());
			inputMap.put("CARD_NO", cardNo);
			inputMap.put("CURRENCY_CODE","XAU");
			inputMap.put("EXCHANGE_AMOUNT",puan);
     
			
			outputMap = GMServiceExecuter.call("BNSPR_OCEAN_USE_POINT", inputMap);
						
			String returnCode =outputMap.getString("RETURN_CODE");   
			String errorDetail = outputMap.getString("ERROR_DETAIL");
			String returnDesc = outputMap.getString("RETURN_DESCRIPTION");
			BigDecimal rrn;
			if(returnCode.equals("2")){ //e�er ba�ar�l�ysa, i�lemi logla sonra muhasebe �a��r
				try{		
					rrn =outputMap.getBigDecimal("RRN"); 
					//LOGLA
					AltinPuanBozdurmaLog altinPuanBozdurmaLog = new AltinPuanBozdurmaLog();
					altinPuanBozdurmaLog.setCardNo(cardNo);
					altinPuanBozdurmaLog.setChannelCode(channelCode);
					altinPuanBozdurmaLog.setExchangeAmount(puan);
					altinPuanBozdurmaLog.setRequestType(Request_Normal);
					altinPuanBozdurmaLog.setXauCurrency(altinKur);
					altinPuanBozdurmaLog.setRrn(rrn);
					altinPuanBozdurmaLog.setTxNo(txNo);
					
					session.saveOrUpdate(altinPuanBozdurmaLog);
					
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{ call PKG_TRN2408.Altin_Puan_Muhasebesi(?)}");
					int i = 1;
					stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
					stmt.execute();
					
				}
				catch (Exception e) {
					e.printStackTrace();
					rrn =outputMap.getBigDecimal("RRN"); 
					reverseMap.put("REQUEST_TYPE", Request_Refund);
					reverseMap.put("ORIGINAL_RRN", rrn);
					reverseMap.put("CHANNEL_CODE", channelCode);
					reverseMap.put("TX_NO", altinPuanBozdurmaTx.getTxNo());
					reverseMap.put("CARD_NO", altinPuanBozdurmaTx.getCardNo());
					reverseMap.put("CURRENCY_CODE","XAU");
					reverseMap.put("EXCHANGE_AMOUNT",puan);

					revOutputMap = GMServiceExecuter.call("BNSPR_OCEAN_USE_POINT", reverseMap);
					
					returnCode =revOutputMap.getString("RETURN_CODE");  
				    BigDecimal iptalrrn =revOutputMap.getBigDecimal("RRN");
				    errorDetail  = revOutputMap.getString("ERROR_DETAIL");
				    returnDesc = revOutputMap.getString("RETURN_DESCRIPTION");
				    if(returnCode.equals("2")){ //e�er ba�ar�l�ysa, i�lemi logla
					   //LOGLA	
						AltinPuanBozdurmaLog altinPuanBozdurmaIptalLog = new AltinPuanBozdurmaLog();
						altinPuanBozdurmaIptalLog.setCardNo(cardNo);
						altinPuanBozdurmaIptalLog.setChannelCode(channelCode);
						altinPuanBozdurmaIptalLog.setExchangeAmount(puan);
						altinPuanBozdurmaIptalLog.setRequestType(Request_Refund);
						altinPuanBozdurmaIptalLog.setXauCurrency(altinKur);						
						altinPuanBozdurmaIptalLog.setRrn(iptalrrn);
						altinPuanBozdurmaIptalLog.setRevRrn(rrn);
						altinPuanBozdurmaIptalLog.setTxNo(txNo);
						
						session.saveOrUpdate(altinPuanBozdurmaIptalLog);
				    }
				    else{
						outputMap.put("HATA_NO", new BigDecimal(660)); 
						outputMap.put("P1", returnDesc); 
						System.out.println("BNSPR_OCEAN_USE_POINT iptal servisi ba�ar�s�z. " + returnDesc + " Error Detail:" + errorDetail);
				        return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", outputMap);
					}
				    session.flush();						 
					return revOutputMap;
				}
		        finally {
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
				}
			}else{
				outputMap.put("HATA_NO", new BigDecimal(660)); 
				outputMap.put("P1", returnDesc); 
				System.out.println("BNSPR_OCEAN_USE_POINT normal servisi ba�ar�s�z. " + returnDesc + " Error Detail:" +errorDetail);
		        return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", outputMap);
			}
        	
			session.flush();			
			return outputMap;
		} catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN2408_GET_INFO")
	public static GMMap getInfo2408(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			AltinPuanBozdurmaTx  altinPuanBozdurmaTx= (AltinPuanBozdurmaTx)session.get(AltinPuanBozdurmaTx.class, iMap.getBigDecimal("TRX_NO"));

			String cardNo =  altinPuanBozdurmaTx.getCardNo();
			String cardType =  altinPuanBozdurmaTx.getCardType();
			BigDecimal customerNo = altinPuanBozdurmaTx.getCustomerNo();
			String productID = altinPuanBozdurmaTx.getProductId();
			String productName = altinPuanBozdurmaTx.getProductName();
			BigDecimal hesapNo = altinPuanBozdurmaTx.getAccountNo();
			BigDecimal altinKuru = altinPuanBozdurmaTx.getXauCurrency();
			oMap.put("XAU_CURRENCY", altinKuru);
			altinKuru = altinKuru.divide(new BigDecimal(1000)); //miligram i�in
			BigDecimal exchangeAmount = altinPuanBozdurmaTx.getExchangeAmount();
			BigDecimal usablePoint = altinPuanBozdurmaTx.getUsablePoint();
			BigDecimal cycleEarnedPoint = altinPuanBozdurmaTx.getCycleEarnedPoint();
			BigDecimal cyclePointExchange = altinPuanBozdurmaTx.getCyclePointExchange();
			BigDecimal cycleRepurchasedPoint = altinPuanBozdurmaTx.getCycleRepurchasedPoint();
			BigDecimal totalEarnedPoint = altinPuanBozdurmaTx.getTotalEarnedPoint();
			BigDecimal totalPointExchange = altinPuanBozdurmaTx.getTotalPointExchange();
			BigDecimal revolvingPoint  = altinPuanBozdurmaTx.getRevolvingPoint();
			BigDecimal pointExhangeSubLimit  = altinPuanBozdurmaTx.getPointExchangeSubLimit();

			oMap.put("TCKN", altinPuanBozdurmaTx.getTckn());
			oMap.put("CUSTOMER_NO", customerNo );
			oMap.put("CUSTOMER_NAME", LovHelper.diLov(customerNo, "2408/LOV_MUSTERI_NO", "UNVAN"));
			oMap.put("CARD_NO",cardNo);

			oMap.put("EXCHANGE_AMOUNT", exchangeAmount );
			oMap.put("EXCHANGE_AMOUNT_TL", exchangeAmount.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("USABLE_POINT", usablePoint );
			oMap.put("USABLE_POINT_TL", usablePoint.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("CYCLE_EARNED_POINT", cycleEarnedPoint );
			oMap.put("CYCLE_EARNED_POINT_TL", cycleEarnedPoint.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("CYCLE_POINT_EXCHANGE", cyclePointExchange );
			oMap.put("CYCLE_POINT_EXCHANGE_TL", cyclePointExchange.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("CYCLE_REPURCHASED_POINT", cycleRepurchasedPoint );
			oMap.put("CYCLE_REPURCHASED_POINT_TL", cycleRepurchasedPoint.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("TOTAL_EARNED_POINT", totalEarnedPoint );
			oMap.put("TOTAL_EARNED_POINT_TL", totalEarnedPoint.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("TOTAL_POINT_EXCHANGE", totalPointExchange );
			oMap.put("TOTAL_POINT_EXCHANGE_TL", totalPointExchange.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("REVOLVING_POINT", revolvingPoint );
			oMap.put("REVOLVING_POINT_TL", revolvingPoint.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			oMap.put("POINT_EXCHANGE_SUB_LIMIT", pointExhangeSubLimit );
			oMap.put("POINT_EXCHANGE_SUB_LIMIT_TL", pointExhangeSubLimit.multiply(altinKuru).setScale(2, RoundingMode.HALF_UP));
			
			oMap.put("KART_BILGILERI", 0, "KART_NO", cardNo);
			oMap.put("KART_BILGILERI", 0, "KART_NO_MASKE", maskCardNumber(cardNo));
			oMap.put("KART_BILGILERI", 0, "KART_TIPI", getCardType(cardType,"1"));
			oMap.put("KART_BILGILERI", 0, "PRODUCT_ID", productID);	
			oMap.put("KART_BILGILERI", 0, "PRODUCT_ADI", productName);	
			oMap.put("KART_BILGILERI", 0, "MUSTERI_NO", customerNo);
			oMap.put("KART_BILGILERI", 0, "HESAP_NO", hesapNo);
			
			return oMap;

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	private static String maskCardNumber(String cardNumber) {
		return cardNumber.replaceAll("(\\d{1,4})(\\d{1,8})(\\d{1,4})",
				"$1 **** **** $3");
	}
	
	private static String getCardType(String dci, String type) {
		String cardType = "";
		if(type.equals("1")){			
			if(dci.equals("C")) cardType = "Credit";
			else if(dci.equals("D")) cardType = "Debit";
			else if(dci.equals("P")) cardType = "Prepaid";
		}
		else
		{
			if(dci.equals("Credit")) cardType = "C";
			else if(dci.equals("Debit")) cardType = "D";
			else if(dci.equals("Prepaid")) cardType = "P";
		}
		return cardType;
	}

	@GraymoundService("BNSPR_TRN2408_GET_EXCHANGE_INFO")
    public static GMMap getExchangeInfo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
           GMMap oMap = new GMMap();
     	   GMMap iPuanMap = new GMMap();
    	   GMMap oPuanMap = new GMMap();
 	       String cardNo = iMap.getString("CARD_NO").trim();
 	       String musteriNo = iMap.getString("CUSTOMER_NO");
           BigDecimal exchangeAmt = iMap.getBigDecimal("EXCHANGE_AMOUNT").setScale(2); //miligram
           
 	       if(cardNo==null  || cardNo.isEmpty()){
 	    	   oMap.put("ERROR",ERRORMESSAGE_CARD_NO_CAN_NOT_BE_NULL);
 	    	   oMap.put("RETURN_CODE", 0);
 	    	   return oMap;
 	       }
	       else if (exchangeAmt==null){
	    	   oMap.put("ERROR",ERRORMESSAGE_EXCHANGE_AMOUNT_CAN_NOT_BE_NULL);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
	       }
	       else if (exchangeAmt.compareTo(BigDecimal.ZERO) != 1)
	       {
	    	   oMap.put("ERROR",ERRORMESSAGE_EXCHANGE_AMOUNT_POSITIVE_INTEGER);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
	       }
            
           BigDecimal altinKur = GMServiceExecuter.call("BNSPR_TRN2408_ALTINKURGETIR",new GMMap()).getBigDecimal("KUR");
            
	       if(altinKur==null  || altinKur.compareTo(BigDecimal.ZERO) != 1)	
	       {
		       oMap.put("ERROR",ERRORMESSAGE_XAU_CURRENCY_NOT_FOUND);
		   	   oMap.put("RETURN_CODE", 0);
		   	   return oMap;
	       }
	    	
           oMap.put("XAU_CURRENCY", altinKur);
          
    	   iPuanMap.put("KART_NO", cardNo);
    	   iPuanMap.put("MUSTERI_NO", musteriNo);
    	   iPuanMap.put("KUR", altinKur);
    	   oPuanMap = GMServiceExecuter.call("BNSPR_TRN2408_GET_PUAN_BILGISI", iPuanMap); //puan bilgileri getirir 

    	   if(!oPuanMap.getString("RETURN_CODE").equals("2")){
	    	   oMap.put("ERROR",ERRORMESSAGE_POINT_INFO_NOT_FOUND);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
    	   }
    	   
    	   BigDecimal pointExchangeSubLimit = oPuanMap.getBigDecimal("POINT_EXCHANGE_SUB_LIMIT");
    	   BigDecimal usablePoint=oPuanMap.getBigDecimal("USABLE_POINT");
    	   
    	   if(pointExchangeSubLimit.compareTo(exchangeAmt)==1){
	    	   oMap.put("ERROR", pointExchangeSubLimit + ERRORMESSAGE_XAU_SUBLIMIT);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
    	   }
    	   
    	   if(exchangeAmt.compareTo(usablePoint)==1){
	    	   oMap.put("ERROR", ERRORMESSAGE_XAU_USABLE_LIMIT);
	    	   oMap.put("RETURN_CODE", 0);
	    	   return oMap;
    	   }  	   
           
           altinKur = altinKur.divide(new BigDecimal(1000)); //miligram i�in          
           BigDecimal exchangeAmtTL = altinKur.multiply(exchangeAmt).setScale(2, RoundingMode.HALF_UP);         
           oMap.put("EXCHANGE_AMOUNT_TL", exchangeAmtTL);
           oMap.put("RETURN_CODE",2);
           return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(conn);          
        }
	}

}
