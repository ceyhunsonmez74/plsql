package tr.com.calikbank.bnspr.treasury.services;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznTurevBelgeTx;
import tr.com.aktifbank.bnspr.dao.HznTurevBelgeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1580Services {

    @GraymoundService("BNSPR_TRN1580_INITIALIZE")
    public static GMMap initialize1580(GMMap iMap) {

        try {
            GMMap oMap = new GMMap();

            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1580_GET_BELGELER")
    public static GMMap getBelgeler1580(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            String func = "{? = call pkg_trn1580.GetBelgeList(?,?,?,?,?,?)}";
            Object [] values  = new Object[] {BnsprType.STRING, iMap.getString("INSERT_OR_UPDATE"),
                                                BnsprType.STRING, iMap.getString("ISLEM_KOD"),
                                                BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
                                                BnsprType.STRING, iMap.getString("REFERANS"),
                                                BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_SUBESI"),
                                                BnsprType.STRING, iMap.getString("ISLEM_TURU")};

                oMap = DALUtil.callOracleRefCursorFunction(func , "BELGE_KONTROL" , values);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("BNSPR_TRN1580_SAVE")
    public static Map<?, ?> save1580(GMMap iMap) throws ParseException {

        Session session = DAOSession.getSession("BNSPRDal");

        HznTurevBelgeTx hznTurevBelge = (HznTurevBelgeTx) session.createCriteria(HznTurevBelgeTx.class)
                .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        HznTurevBelgeTxId hznTurevBelgeId = null;

        if (hznTurevBelge == null) {
            hznTurevBelge = new HznTurevBelgeTx();
            hznTurevBelgeId = new HznTurevBelgeTxId();
        }

        String tableName = "BELGE_KONTROL";
        for (int row = 0; row < iMap.getSize("BELGE_KONTROL"); row++) {
                    
            hznTurevBelgeId = new HznTurevBelgeTxId();
            hznTurevBelge = new HznTurevBelgeTx();
            
            hznTurevBelgeId.setBelgeKod(iMap.getString(tableName , row , "KOD"));
            if(iMap.getBoolean("YENIRB") == true){
                hznTurevBelgeId.setReferans(iMap.getString("YENI"));
                hznTurevBelge.setKayitTuru("I");
            }
            if(iMap.getBoolean("GUNCELLERB")== true){
                hznTurevBelgeId.setReferans(iMap.getString("GUNCELLE"));
                hznTurevBelge.setKayitTuru("U");
            }
            hznTurevBelgeId.setTxNo(iMap.getBigDecimal("TRX_NO"));
            hznTurevBelge.setBelgeAdi(iMap.getString(tableName , row , "AD"));
            if(iMap.getString(tableName , row , "DURUM") != null)
                hznTurevBelge.setBelgeDurumu(iMap.getString(tableName , row , "DURUM"));
            hznTurevBelge.setId(hznTurevBelgeId);
            hznTurevBelge.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
            hznTurevBelge.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            hznTurevBelge.setIslemSube(iMap.getBigDecimal(tableName , row , "ISLEM_SUBESI"));
            hznTurevBelge.setIslemTuru(iMap.getString(tableName , row , "ISLEM_TURU"));
            
            
            session.saveOrUpdate(hznTurevBelge);

        }

        session.flush();
        
        iMap.put("TRX_NAME","1580");
        return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
    }

    @GraymoundService("BNSPR_TRN1580_INITIALIZE_COMBO")
    public static GMMap initializeCombo(GMMap iMap) {

        GMMap oMap = new GMMap();

        String param = "ALINDI_EKSIK";
        GuimlUtil.wrapMyCombo(oMap, param, null, " ");
        GuimlUtil.wrapMyCombo(oMap, param, "A", "Al�nd�");
        GuimlUtil.wrapMyCombo(oMap, param, "E", "Eksik");

        return oMap;
    }

    @GraymoundService("BNSPR_TRN1580_GET_INFO")
    public static GMMap getInfo1580(GMMap iMap) {

      
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();
            String tableName = "BELGE_KONTROL";

            List<?> recordList = session.createCriteria(HznTurevBelgeTx.class)
                    .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
                    .list();
            for (int row = 0; row < recordList.size(); row++){
                HznTurevBelgeTx hznTurevBelgeTx = (HznTurevBelgeTx) recordList.get(row);
                oMap.put("ISLEM_NO" , hznTurevBelgeTx.getIslemNo());
                oMap.put("MUSTERI_NO" , hznTurevBelgeTx.getMusteriNo());
                oMap.put("REFERANS" , hznTurevBelgeTx.getId().getReferans());
                oMap.put("TRX_NO" , hznTurevBelgeTx.getId().getTxNo());
                oMap.put("KAYIT_TURU" , hznTurevBelgeTx.getKayitTuru());
                oMap.put("ISLEM_TURU" , hznTurevBelgeTx.getIslemTuru());
                oMap.put("ISLEM_SUBESI" , hznTurevBelgeTx.getIslemSube());

                oMap.put(tableName , row , "AD" , hznTurevBelgeTx.getBelgeAdi());
                oMap.put(tableName , row , "DURUM" , hznTurevBelgeTx.getBelgeDurumu());
                oMap.put(tableName , row , "KOD" , hznTurevBelgeTx.getId().getBelgeKod());
                oMap.put(tableName , row , "ISLEM_TURU" , hznTurevBelgeTx.getIslemTuru());
                oMap.put(tableName , row , "ISLEM_SUBESI" , hznTurevBelgeTx.getIslemSube());

            }

            
            return oMap;

    }
}
