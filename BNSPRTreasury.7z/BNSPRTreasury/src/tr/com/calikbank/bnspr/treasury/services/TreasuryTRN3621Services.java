package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;


import tr.com.aktifbank.bnspr.dao.HznBloombergBankaMustTx;
import tr.com.aktifbank.bnspr.dao.HznBloombergBankaMustTxId;
import tr.com.aktifbank.bnspr.dao.HznPeBloombergTx;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3621Services {
	
	@GraymoundService("BNSPR_TRN3621_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;
 
		oMap.put("TUR", i, "NAME", "SPOT");
	    oMap.put("TUR", i++, "VALUE", "SPOT");

	    oMap.put("TUR", i, "NAME", "SWAP");
	    oMap.put("TUR", i++, "VALUE", "SWAP");
	    
	    oMap.put("TUR", i, "NAME", "FORWARD");
	    oMap.put("TUR", i++, "VALUE", "FORWARD");
	    
	    oMap.put("TUR", i, "NAME", "DEPO");
	    oMap.put("TUR", i++, "VALUE", "DEPO");
	    
	    oMap.put("TUR", i, "NAME", "OPSIYON");
	    oMap.put("TUR", i++, "VALUE", "OPSIYON");
	    
	    oMap.put("TUR", i, "NAME", "REPO");
	    oMap.put("TUR", i++, "VALUE", "REPO");	    

	    oMap.put("TUR", i, "NAME", "TERSREPO");
	    oMap.put("TUR", i++, "VALUE", "TERSREPO");	   
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3621_GET_INITIAL_DATA")
	public static GMMap getTransferData(GMMap iMap){
		  GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        try{
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call Pkg_TRN3621.getData}");
	            
	            int parameterIndex = 1;
	       
	            stmt.registerOutParameter(parameterIndex++ , -10);
	          
	            stmt.execute();
	            String tn = "TBL";
	            
	            rSet = (ResultSet) stmt.getObject(1);
	            oMap = DALUtil.rSetResults(rSet , tn);
	            
	            return oMap;
	        } catch (Exception e){
	            throw ExceptionHandler.convertException(e);
	        } finally{
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
	
	
	@GraymoundService("BNSPR_TRN3621_SAVE")
	public static GMMap Save (GMMap iMap){
		try {

			Session session = DAOSession.getSession("BNSPRDal");
            
            BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
            
            int i = 0;
            String tn = "TBL";
			
			  while (i < iMap.getSize(tn)){
	                
				  HznBloombergBankaMustTx hznBloomTx = new HznBloombergBankaMustTx();
	                
	                HznBloombergBankaMustTxId hznBloomTxId = new HznBloombergBankaMustTxId() ;
	                
	                
	            	hznBloomTxId.setBankaKodu(iMap.getString(tn , i , "BANKA_KODU"));
	    			hznBloomTxId.setDovizKodu(iMap.getString(tn , i , "DOVIZ_KODU"));
	    			hznBloomTxId.setTxNo(trxNo);
	    			hznBloomTxId.setUrunTurKod(iMap.getString(tn , i , "URUN_TUR_KOD"));
	    			
	    			hznBloomTx.setId(hznBloomTxId);
	    			
	    			hznBloomTx.setBankaAdi(iMap.getString(tn , i , "BANKA_ADI"));
	    			hznBloomTx.setBankaMusteriNo(iMap.getBigDecimal(tn , i , "BANKA_MUSTERI_NO"));
	    			hznBloomTx.setHesapNo(iMap.getBigDecimal(tn , i , "HESAP_NO"));
	    			hznBloomTx.setMuhabir(iMap.getString(tn , i , "MUHABIR"));
	    			hznBloomTx.setMuhabirHesapNo(iMap.getBigDecimal(tn , i , "MUHABIR_HESAP_NO"));
	     
	              
	                session.saveOrUpdate(hznBloomTx);
	                
	                i++;
	                
	            }
	            session.flush();
			
		 
			iMap.put("TRX_NAME", "3621");
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3621_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			

			Session session = DAOSession.getSession("BNSPRDal");
			
			List<HznBloombergBankaMustTx> hznBloomberg = null;
			
			hznBloomberg = (List<HznBloombergBankaMustTx>) session
					.createCriteria(HznBloombergBankaMustTx.class)
					.add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")))
					.list();
			
			if (hznBloomberg != null) {
				int i = 0;
				for (HznBloombergBankaMustTx bb2 : hznBloomberg) {

					oMap.put("TBL", i, "BANKA_KODU", bb2.getId().getBankaKodu());
					oMap.put("TBL", i, "DOVIZ_KODU", bb2.getId().getDovizKodu());
					oMap.put("TBL", i, "URUN_TUR_KOD", bb2.getId().getUrunTurKod());
					oMap.put("TBL", i, "BANKA_ADI", bb2.getBankaAdi());
					oMap.put("TBL", i, "BANKA_MUSTERI_NO", bb2.getBankaMusteriNo());
					oMap.put("TBL", i, "HESAP_NO", bb2.getHesapNo());
					oMap.put("TBL", i, "MUHABIR", bb2.getMuhabir());
					i++;
				}
			
			}
 
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3621_GET_DEAL_DATA")
	public static GMMap getDealInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			StringBuilder msg = new StringBuilder(); 
            
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<HznPeBloombergTx> hznBloomberg = null;
			
			hznBloomberg = (List<HznPeBloombergTx>) session
					.createCriteria(HznPeBloombergTx.class)
					.add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO")))
					.list();
			
			if (hznBloomberg != null) {
				int i = 0;
				for (HznPeBloombergTx bb2 : hznBloomberg) {
					msg.append("<br>BANK1 NAME = " +bb2.getBank1Name());
					msg.append("<br>CURRENCY_1 ="+ bb2.getCurrency1());
					
					msg.append("<br>CURRENCY_2 ="+ bb2.getCurrency2());
					msg.append("<br>SIDE =");
					
					if (bb2.getSide().equals("B"))
						msg.append("Buy");
					if (bb2.getSide().equals("S"))
						msg.append("Sell");
					if (bb2.getSide().equals("O"))
						msg.append("Borrow");
					if (bb2.getSide().equals("L"))
						msg.append("Lending");
					
					msg.append("<br>DEAL_TYPE = ");
					
					if (bb2.getPureDealType().intValue()==2)
						msg.append("SPOT");
					if (bb2.getPureDealType().intValue()==8)
						msg.append("SWAP");
					if (bb2.getPureDealType().intValue()==4)
						msg.append("FORWARD");
					if (bb2.getPureDealType().intValue()==16)
						msg.append("DEPO");
					
					msg.append("<br>NEAR AMT DEALT = " +bb2.getNearAmtDealt()+" "+bb2.getNearCcyDealt());
					msg.append("<br>NEAR COUNTER DEALT = " +bb2.getNearCounterAmt()+" "+bb2.getNearCounterCcy());
					msg.append("<br>DATE_OF_DEAL ="+ bb2.getDateOfDeal());
					
					msg.append("<br>TRADER_NAME = " +bb2.getTraderName());
					msg.append("<br>SOURCE_REFERENCE = " +bb2.getSourceReference());
					
					msg.append("<br>SETTLE CURRENCY = " +bb2.getSettleCrncy());
					msg.append("<br>VALUE DATE PERIOD 1 CURRENCY 1 = " +bb2.getValueDatePeriod1Currency1());
					msg.append("<br>TENOR PERIOD = " +bb2.getTenorPeriod1());
					msg.append("<br>SPOT BASIS RATE = " +bb2.getSpotBasisRate());
					
					i++;
				}
			oMap.put("SONUC", msg);
			}
 
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
