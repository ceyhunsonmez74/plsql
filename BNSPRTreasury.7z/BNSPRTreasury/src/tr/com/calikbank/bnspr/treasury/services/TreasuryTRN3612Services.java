package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznAltinAlinandepoTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN3612Services {


    @GraymoundService("BNSPR_TRN3612_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        CallableStatement stmt2 = null;

        GMMap oMap = new GMMap();
        iMap.put("KOD", "HZN_VADE_ISLEM_BILGISI");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_VADE_ISLEM_BILGISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        iMap.put("KOD", "HZN_ALTIN_DEPO_ISLEM_TURU");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_ALTIN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        iMap.put("KOD", "HZN_TAKSIT_DURUMU");
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("HZN_TAKSIT_DURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_ALTIN_FON.saflik_derecesi }");
            int i = 1;
            stmt.registerOutParameter(i, Types.NUMERIC);
            stmt.execute();
            oMap.put("SAFLIK_DERECESI", stmt.getBigDecimal(i));

            
            stmt2 = conn.prepareCall("{ ? = call PKG_ALTIN_FON.DEPO_KOMISYON_ORANI(?) }");
            int j = 1;
            stmt2.registerOutParameter(j++, Types.NUMERIC);
            stmt2.setString(j++ , "ALIS");
            stmt2.execute();
            oMap.put("KOMISYON_ORANI", stmt2.getBigDecimal(1));
            
            return oMap;
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(stmt2);
            GMServerDatasource.close(conn);
        }

    }

 
	@GraymoundService("BNSPR_TRN3612_SAVE")
    public static Map<?, ?> save(GMMap iMap){
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinAlinandepoTx hznAltinAlinanDepoTx = (HznAltinAlinandepoTx)session.get(HznAltinAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAltinAlinanDepoTx == null) {
				hznAltinAlinanDepoTx = new HznAltinAlinandepoTx();
			}
			
			hznAltinAlinanDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAltinAlinanDepoTx.setModulTurKod("HAZINE");
			hznAltinAlinanDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAltinAlinanDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAltinAlinanDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznAltinAlinanDepoTx.setReferans(iMap.getString("REFERANS"));
			hznAltinAlinanDepoTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
			hznAltinAlinanDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznAltinAlinanDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAltinAlinanDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAltinAlinanDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAltinAlinanDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAltinAlinanDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAltinAlinanDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAltinAlinanDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAltinAlinanDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAltinAlinanDepoTx.setNetTutar(iMap.getBigDecimal("NET_TUTAR"));
			hznAltinAlinanDepoTx.setNetTutar(iMap.getBigDecimal("BRUT_TUTAR"));
			hznAltinAlinanDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAltinAlinanDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAltinAlinanDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAltinAlinanDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAltinAlinanDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAltinAlinanDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAltinAlinanDepoTx.setSaflikDerecesi(iMap.getBigDecimal("SAFLIK_DERECESI"));
			//hznAltinAlinanDepoTx.setStokNo(iMap.getBigDecimal("STOK_NO"));
			hznAltinAlinanDepoTx.setKomisyonOrani(iMap.getBigDecimal("KOMISYON_ORANI"));
			hznAltinAlinanDepoTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
			hznAltinAlinanDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznAltinAlinanDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			
			
		       session.saveOrUpdate(hznAltinAlinanDepoTx);
	            session.flush();

	            iMap.put("TRX_NAME","3612");

	            return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap); 
		 
	
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}
	
	@GraymoundService("BNSPR_TRN3612_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3612.Hzn_Altin_bilgiaktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	

	@GraymoundService("BNSPR_TRN3612_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinAlinandepoTx hznAltinAlinanDepoTx = (HznAltinAlinandepoTx)session.get(HznAltinAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznAltinAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinAlinanDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinAlinanDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinAlinanDepoTx.getReferans());
			oMap.put("ISLEM_TURU", hznAltinAlinanDepoTx.getIslemTuru());
			oMap.put("DEALER_NO", hznAltinAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinAlinanDepoTx.getCikisHesapNo());
			oMap.put("ACIKLAMA", hznAltinAlinanDepoTx.getAciklama());
			oMap.put("DOVIZ_KODU", hznAltinAlinanDepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinAlinanDepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinAlinanDepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinAlinanDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAltinAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAltinAlinanDepoTx.getDealTarihi());
		    oMap.put("FAIZ_ORANI", hznAltinAlinanDepoTx.getFaizOrani());
			
			
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinanDepoTx.getGirisHesapNo(),hznAltinAlinanDepoTx.getDovizKodu(),
			        hznAltinAlinanDepoTx.getGirisHesapTuru(), hznAltinAlinanDepoTx.getDovizKodu(), hznAltinAlinanDepoTx.getGirisHesapTuru(), 
			        hznAltinAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinanDepoTx.getCikisHesapNo(),hznAltinAlinanDepoTx.getDovizKodu(),
			        hznAltinAlinanDepoTx.getCikisHesapTuru(), hznAltinAlinanDepoTx.getDovizKodu(), hznAltinAlinanDepoTx.getCikisHesapTuru(), 
					hznAltinAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinAlinanDepoTx.getDealerNo(), "1310/LOV_DEALER", "ISIM"));
			
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinAlinanDepoTx.getCikisMuhabirMusteriNo());
			oMap.put("KOMISYON_ORANI", hznAltinAlinanDepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI", hznAltinAlinanDepoTx.getKomisyonTutari());
			oMap.put("ALTIN_SAFLIK_DERECESI",hznAltinAlinanDepoTx.getSaflikDerecesi());
			oMap.put("STOK_NO",hznAltinAlinanDepoTx.getStokNo());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}
	
	@GraymoundService("BNSPR_TRN3612_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAltinAlinandepoTx hznAltinAlinanDepoTx = (HznAltinAlinandepoTx)session.get(HznAltinAlinandepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAltinAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAltinAlinanDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAltinAlinanDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAltinAlinanDepoTx.getReferans());
			oMap.put("ISLEM_TURU", hznAltinAlinanDepoTx.getIslemTuru());
			oMap.put("DEALER_NO", hznAltinAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAltinAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAltinAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAltinAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAltinAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAltinAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAltinAlinanDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAltinAlinanDepoTx.getDovizKodu());
			oMap.put("NET_TUTAR", hznAltinAlinanDepoTx.getNetTutar());
			oMap.put("BRUT_TUTAR", hznAltinAlinanDepoTx.getBrutTutar());
			oMap.put("VALOR_TARIHI", hznAltinAlinanDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAltinAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAltinAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAltinAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAltinAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAltinAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAltinAlinanDepoTx.getDealTarihi());
			oMap.put("FAIZ_ORANI", hznAltinAlinanDepoTx.getFaizOrani());
		
			
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinanDepoTx.getGirisHesapNo(),hznAltinAlinanDepoTx.getDovizKodu(),
			        hznAltinAlinanDepoTx.getGirisHesapTuru(), hznAltinAlinanDepoTx.getDovizKodu(), hznAltinAlinanDepoTx.getGirisHesapTuru(), 
			        hznAltinAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAltinAlinanDepoTx.getCikisHesapNo(),hznAltinAlinanDepoTx.getDovizKodu(),
			        hznAltinAlinanDepoTx.getCikisHesapTuru(), hznAltinAlinanDepoTx.getDovizKodu(), hznAltinAlinanDepoTx.getCikisHesapTuru(), 
			        hznAltinAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAltinAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAltinAlinanDepoTx.getDealerNo(), "1310/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAltinAlinanDepoTx.getAciklama());
			
			oMap.put("KOMISYON_ORANI",hznAltinAlinanDepoTx.getKomisyonOrani());
			oMap.put("KOMISYON_TUTARI",hznAltinAlinanDepoTx.getKomisyonTutari());
			oMap.put("SAFLIK_DERECESI",hznAltinAlinanDepoTx.getSaflikDerecesi());
			oMap.put("STOK_NO",hznAltinAlinanDepoTx.getStokNo());
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAltinAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAltinAlinanDepoTx.getCikisMuhabirMusteriNo());
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	  @GraymoundService("BNSPR_TRN3612_FAIZ_HESAPLA")
	    public static GMMap getFaizHesabi(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;

	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{ ?=call PKG_TRN3612.Faiz_Tutari_Hesapla(?,?,?)}");
	            int i = 1;
	            stmt.registerOutParameter(i++, Types.NUMERIC);
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("GUN_SAYISI"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("BRUT_TUTAR"));
	            stmt.execute();

	            oMap.put("FAIZ_TUTARI", stmt.getBigDecimal(1));

	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }

	    }
	    @GraymoundService("BNSPR_TRN3612_CALCULATE_TENOR")
	    public static GMMap getCalculatedTenor(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;

	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{ ? = call PKG_TRN3612.Calculate_Tenor(?,?)}");
	            int i = 1;
	            stmt.registerOutParameter(i++, Types.NUMERIC);
	            stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
	            stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
	            stmt.execute();

	            oMap.put("TENOR", stmt.getBigDecimal(1));

	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
}
