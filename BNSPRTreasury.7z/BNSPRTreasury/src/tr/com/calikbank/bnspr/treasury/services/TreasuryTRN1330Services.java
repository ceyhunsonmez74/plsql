package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSerbestTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1330Services {
	@GraymoundService("BNSPR_TRN1330_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznSerbestTx hznSerbestTx = (HznSerbestTx)session.get(HznSerbestTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(hznSerbestTx == null) {
				hznSerbestTx = new HznSerbestTx();
			}
			hznSerbestTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznSerbestTx.setHznSerbestSecenek(iMap.getString("SECENEK"));
			hznSerbestTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznSerbestTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			hznSerbestTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			hznSerbestTx.setDovizTutari(iMap.getBigDecimal("DOVIZ_TUTARI"));
			hznSerbestTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSerbestTx.setKur(iMap.getBigDecimal("KUR"));
			hznSerbestTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznSerbestTx.setDurumKodu("A");
			hznSerbestTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznSerbestTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			session.saveOrUpdate(hznSerbestTx);
			session.flush();
			iMap.put("TRX_NAME", "1330");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1330_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSerbestTx hznSerbestTx = (HznSerbestTx)session.get(HznSerbestTx.class, txNo);
			
			oMap.put("TRX_NO", hznSerbestTx.getTxNo());
			oMap.put("SECENEK", hznSerbestTx.getHznSerbestSecenek());
			oMap.put("DOVIZ_KODU", hznSerbestTx.getDovizKodu());
			oMap.put("MUSTERI_NO", hznSerbestTx.getMusteriNo());
			oMap.put("HESAP_NO", hznSerbestTx.getHesapNo());
			oMap.put("DOVIZ_TUTARI", hznSerbestTx.getDovizTutari());
			oMap.put("VALOR_TARIHI", hznSerbestTx.getValorTarihi());
			oMap.put("KUR", hznSerbestTx.getKur());
			oMap.put("ACIKLAMA", hznSerbestTx.getAciklama());
			oMap.put("DURUM_KODU", hznSerbestTx.getDurumKodu());
			oMap.put("DEAL_TARIHI", hznSerbestTx.getDealTarihi());
			oMap.put("ISTATISTIK_KODU", hznSerbestTx.getIstatistikKodu());
			
			oMap.put("MUSTERI_KISA_ISIM", LovHelper.diLov(hznSerbestTx.getMusteriNo(), "1330/LOV_BANKA_MUSTERI_NO", "UNVAN"));
			oMap.put("DOVIZ_ACIKLAMA", LovHelper.diLov(hznSerbestTx.getDovizKodu(), "1330/LOV_DOVIZ_KODU", "ACIKLAMA"));
			oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznSerbestTx.getIstatistikKodu(), "1330/LOV_ISTATISTIK", "ACIKLAMA"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1330_KUR_AL")
	public static GMMap kurAl(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_TRN1330.Kur_Al(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("SECENEK"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.execute();
			
			oMap.put("DOVIZ_KUR",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
}
