package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ZkYukumluluk;
import tr.com.aktifbank.bnspr.dao.ZkYukumlulukTx;
import tr.com.aktifbank.bnspr.dao.ZkYukumlulukTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1340Services {
	
	public enum Durum {
	    Beklemede("B"),
	    Onay("O"),
	    Kesinle�ti("K");	    
	    
	    private String key;

	    Durum(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}
	
	public enum IslemDurum {
	    Beklemede("B"),
	    Tamamland�("T");	    
	    
	    private String key;

	    IslemDurum(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}
	public enum IslemTipi {
	    Yat�rma("Y"),
	    �ekme("�");      
	    
	    private String key;

	    IslemTipi(String key) {
	        this.key = key;
	    }

	    public String key() {
	        return key;
	    }
	}

	@GraymoundService("BNSPR_TRN1340_SAVE")
	public static Map<?, ?> saveTRN1340(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TL_LISTE_S";
		int size = iMap.getSize(tableName);
		ZkYukumlulukTx zkYukumlulukTx = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			for (int row = 0; row < size; row++) {
				zkYukumlulukTx = (ZkYukumlulukTx) session.createCriteria(ZkYukumlulukTx.class)
				 								         .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
														 .add(Restrictions.eq("id.zkTarihi", TreasuryUtil.trimDate(iMap.getDate("ISLEM_TARIHI"))))
														 .add(Restrictions.eq("id.zkKodu", iMap.getString(tableName, row, "ZK_KODU"))).uniqueResult();
				if (zkYukumlulukTx == null)
					zkYukumlulukTx = new ZkYukumlulukTx();
				zkYukumlulukTx.setMizanDk(iMap.getString(tableName, row, "MIZAN_DK"));
				zkYukumlulukTx.setEskiDonemA(iMap.getBigDecimal(tableName, row, "ESKI_DONEM_A"));
				zkYukumlulukTx.setYeniDonemB(iMap.getBigDecimal(tableName, row, "YENI_DONEM_B"));
				zkYukumlulukTx.setDurumB(iMap.getString(tableName, row, "DURUM_B"));
				zkYukumlulukTx.setYeniDonemC(iMap.getBigDecimal(tableName, row, "YENI_DONEM_C"));
				zkYukumlulukTx.setDurumC(iMap.getString(tableName, row, "DURUM_C"));
				zkYukumlulukTx.setNetlesenTutar(iMap.getBigDecimal(tableName, row, "NETLESEN_TUTAR"));
				zkYukumlulukTx.setIslemTipi(getIslemTipiKey(iMap.getString(tableName, row, "ISLEM_TIPI")));
				zkYukumlulukTx.setDurumD(getDurumDKey(iMap.getString("ROL"), iMap.getString(tableName, row, "DURUM_D"),iMap.getString(tableName, row, "MUHASEBE_FLAG"),"TL"));
				zkYukumlulukTx.setValorTarihi(TreasuryUtil.trimDate(iMap.getDate(tableName, row, "VALOR_TARIHI")));
				zkYukumlulukTx.setSira(iMap.getBigDecimal(tableName, row, "SIRA"));
				zkYukumlulukTx.setDovizKodu(iMap.getString(tableName, row, "DOVIZ_KODU"));
				zkYukumlulukTx.setMuhasebeFlag(iMap.getString(tableName, row, "MUHASEBE_FLAG"));
				zkYukumlulukTx.setSwiftFlag(iMap.getString(tableName, row, "SWIFT_FLAG"));
				zkYukumlulukTx.setEftFlag(iMap.getString(tableName, row, "EFT_FLAG"));
				zkYukumlulukTx.setFisNo(iMap.getBigDecimal(tableName, row, "FIS_NO"));
				zkYukumlulukTx.setTipi("TL");
				zkYukumlulukTx.setIslemYapanBirim(iMap.getString("ROL"));
				zkYukumlulukTx.setZkAdi(iMap.getString(tableName, row, "ZK_ADI"));
				if (iMap.getString(tableName, row, "SWIFT_FLAG").equals("E"))
					zkYukumlulukTx.setReferans(getReferans(iMap.getBigDecimal("TRX_NO"),iMap.getString(tableName, row, "DOVIZ_KODU"),"TL"));
				
				ZkYukumlulukTxId tid = new ZkYukumlulukTxId();
				tid.setZkKodu(iMap.getString(tableName, row, "ZK_KODU"));
				tid.setZkTarihi(iMap.getDate("ISLEM_TARIHI"));
				tid.setTxNo(iMap.getBigDecimal("TRX_NO"));
				zkYukumlulukTx.setId(tid);
				
				if (iMap.getBoolean(tableName, row, "DURUM") == true) {
					zkYukumlulukTx.setDurum(IslemDurum.Tamamland�.key);
					if (iMap.getBigDecimal(tableName, row, "FIS_NO") == null && !iMap.getString(tableName, row, "DOVIZ_KODU").equals("XAU"))
						getSwiftTxNo(zkYukumlulukTx, session);
				}
				else {
					zkYukumlulukTx.setDurum(IslemDurum.Beklemede.key);
				}
					
				session.saveOrUpdate(zkYukumlulukTx);
				session.flush();
			}
			
			tableName = "YP_LISTE_S";
			size = iMap.getSize(tableName);
			
			for (int row = 0; row < size; row++) {
				zkYukumlulukTx = (ZkYukumlulukTx) session.createCriteria(ZkYukumlulukTx.class)
				         .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
						 .add(Restrictions.eq("id.zkTarihi",TreasuryUtil.trimDate(iMap.getDate("ISLEM_TARIHI"))))
						 .add(Restrictions.eq("id.zkKodu", iMap.getString(tableName, row, "ZK_KODU"))).uniqueResult();
				if (zkYukumlulukTx == null)
					zkYukumlulukTx = new ZkYukumlulukTx();
				zkYukumlulukTx.setMizanDk(iMap.getString(tableName, row, "MIZAN_DK"));
				zkYukumlulukTx.setEskiDonemA(iMap.getBigDecimal(tableName, row, "ESKI_DONEM_A"));
				zkYukumlulukTx.setYeniDonemB(iMap.getBigDecimal(tableName, row, "YENI_DONEM_B"));
				zkYukumlulukTx.setDurumB(iMap.getString(tableName, row, "DURUM_B"));
				zkYukumlulukTx.setYeniDonemC(iMap.getBigDecimal(tableName, row, "YENI_DONEM_C"));
				zkYukumlulukTx.setDurumC(iMap.getString(tableName, row, "DURUM_C"));
				zkYukumlulukTx.setNetlesenTutar(iMap.getBigDecimal(tableName, row, "NETLESEN_TUTAR"));
				zkYukumlulukTx.setIslemTipi(getIslemTipiKey(iMap.getString(tableName, row, "ISLEM_TIPI")));
				zkYukumlulukTx.setDurumD(getDurumDKey(iMap.getString("ROL"), iMap.getString(tableName, row, "DURUM_D"), iMap.getString(tableName, row, "MUHASEBE_FLAG"),"YP"));
				zkYukumlulukTx.setValorTarihi(iMap.getDate(tableName, row, "VALOR_TARIHI"));
				zkYukumlulukTx.setSira(iMap.getBigDecimal(tableName, row, "SIRA"));
				zkYukumlulukTx.setDovizKodu(iMap.getString(tableName, row, "DOVIZ_KODU"));
				zkYukumlulukTx.setMuhasebeFlag(iMap.getString(tableName, row, "MUHASEBE_FLAG"));
				zkYukumlulukTx.setSwiftFlag(iMap.getString(tableName, row, "SWIFT_FLAG"));
				zkYukumlulukTx.setEftFlag(iMap.getString(tableName, row, "EFT_FLAG"));
				zkYukumlulukTx.setFisNo(iMap.getBigDecimal(tableName, row, "FIS_NO"));
				zkYukumlulukTx.setTipi("YP");
				zkYukumlulukTx.setIslemYapanBirim(iMap.getString("ROL"));
				zkYukumlulukTx.setZkAdi(iMap.getString(tableName, row, "ZK_ADI"));
				if (iMap.getString(tableName, row, "SWIFT_FLAG").equals("E"))
					zkYukumlulukTx.setReferans(getReferans(iMap.getBigDecimal("TRX_NO"), iMap.getString(tableName, row, "DOVIZ_KODU"), "YP"));
				
				ZkYukumlulukTxId tid = new ZkYukumlulukTxId();
				tid.setZkKodu(iMap.getString(tableName, row, "ZK_KODU"));
				tid.setZkTarihi(iMap.getDate("ISLEM_TARIHI"));
				tid.setTxNo(iMap.getBigDecimal("TRX_NO"));
				zkYukumlulukTx.setId(tid);
				
				if (iMap.getBoolean(tableName, row, "DURUM") == true) {
					zkYukumlulukTx.setDurum(IslemDurum.Tamamland�.key);
					if(iMap.getBigDecimal(tableName, row, "FIS_NO") == null && !iMap.getString(tableName, row, "DOVIZ_KODU").equals("XAU"))
						getSwiftTxNo(zkYukumlulukTx, session);
				}else{
					zkYukumlulukTx.setDurum(IslemDurum.Beklemede.key);
				}

				session.saveOrUpdate(zkYukumlulukTx);
				session.flush();
			}
			
			iMap.put("TRX_NAME", "1340");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		

	}

	private static void getSwiftTxNo(ZkYukumlulukTx tx, Session session) {
		ZkYukumlulukTx zkYukumlulukTx = new ZkYukumlulukTx();
		zkYukumlulukTx.setMizanDk(tx.getMizanDk());
		zkYukumlulukTx.setEskiDonemA(tx.getEskiDonemA());
		zkYukumlulukTx.setYeniDonemB(tx.getYeniDonemB());
		zkYukumlulukTx.setDurumB(tx.getDurumB());
		zkYukumlulukTx.setYeniDonemC(tx.getYeniDonemC());
		zkYukumlulukTx.setDurumC(tx.getDurumC());
		zkYukumlulukTx.setNetlesenTutar(tx.getNetlesenTutar());
		zkYukumlulukTx.setIslemTipi(tx.getIslemTipi());
		zkYukumlulukTx.setDurumD(tx.getDurumD());
		zkYukumlulukTx.setValorTarihi(tx.getValorTarihi());
		zkYukumlulukTx.setSira(tx.getSira());
		zkYukumlulukTx.setDovizKodu(tx.getDovizKodu());
		zkYukumlulukTx.setMuhasebeFlag(tx.getMuhasebeFlag());
		zkYukumlulukTx.setTipi(tx.getTipi());
		zkYukumlulukTx.setIslemYapanBirim(tx.getIslemYapanBirim());
		zkYukumlulukTx.setReferans(tx.getReferans());
		zkYukumlulukTx.setDurum(tx.getDurum());
		zkYukumlulukTx.setZkAdi(tx.getZkAdi());
		ZkYukumlulukTxId tid = new ZkYukumlulukTxId();
		tid.setZkKodu(tx.getId().getZkKodu());
		tid.setZkTarihi(tx.getId().getZkTarihi());
		BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", null).getBigDecimal("TRX_NO");
		tid.setTxNo(trxNo);
		zkYukumlulukTx.setId(tid);
		tx.setSwiftTxNo(trxNo);
		session.saveOrUpdate(zkYukumlulukTx);
		session.flush();
	}

	private static String getReferans(BigDecimal txNo, String dovizKodu, String tipi) throws ParseException {
		
		return  DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.referans_al(?)}", Types.VARCHAR, "ZK").toString();
	}

	
	public static String getSeq() {
		Connection conn = null;
		CallableStatement stmt = null;
		try {			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call zk_zorunluluk_seq.nextval");

			stmt.registerOutParameter(1, Types.INTEGER);
			stmt.execute();

			Object obj = stmt.getObject(1);		

			return obj.toString();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static String getIslemTipiKey(String islemTipi) {
		if(islemTipi != null && islemTipi.equals(IslemTipi.Yat�rma.toString())){
			return IslemTipi.Yat�rma.key;
		}else if(islemTipi != null && islemTipi.equals(IslemTipi.�ekme.toString())){
			return IslemTipi.�ekme.key;
		}
		return null;
	}
	
	private static String getIslemTipiValue(String islemTipi) {
		if(islemTipi != null && islemTipi.equals(IslemTipi.Yat�rma.key)){
			return IslemTipi.Yat�rma.toString();
		}else if(islemTipi != null && islemTipi.equals(IslemTipi.�ekme.key)){
			return IslemTipi.�ekme.toString();
		}
		return null;
	}

	@GraymoundService("BNSPR_TRN1340_INITIALIZE")
	public static GMMap initialize1340(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		oMap.put("TL_YENI_DONEM_C_EDITABLE", "NO");
		oMap.put("YP_YENI_DONEM_C_EDITABLE", "NO");
		oMap.put("TL_ISLEMI_BITIR_EDITABLE", "YES");
		oMap.put("YP_ISLEMI_BITIR_EDITABLE", "YES");
		try {

			String tableName = "TL_LISTE";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1340.TurkParasiYukumlulukListesi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setDate(i++, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			tableName = "YP_LISTE";
			stmt = conn.prepareCall("{? = call PKG_TRN1340.YabanciParaYukumlulukListesi(?)}");
			i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setDate(i++, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName, oMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1340_GET_INFO")
	public static GMMap getInfo1340(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			java.util.Date islemTarihi = iMap.getDate("ISLEM_TARIHI");
			if (islemTarihi == null) {
				List<ZkYukumlulukTx> zkTx = session.createCriteria(ZkYukumlulukTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).addOrder(Order.asc("sira")).list();
				islemTarihi = zkTx.size() > 0 ? zkTx.get(0).getId().getZkTarihi() : null;
				
			}
			
			List<ZkYukumluluk> list = session.createCriteria(ZkYukumluluk.class).add(Restrictions.eq("id.zkTarihi",islemTarihi)).addOrder(Order.asc("sira")).list();

			Iterator<ZkYukumluluk> it = list.iterator();
			ZkYukumluluk zkYukumluluk = null;
			int rowYP = 0;
			int rowTL = 0;
			if(list.size() == 0){
				oMap.put("NO_DATA_OF_TRX_DATE", "1");
			}
			oMap.put("TL_YENI_DONEM_C_EDITABLE", "YES");
			oMap.put("YP_YENI_DONEM_C_EDITABLE", "YES");
			oMap.put("TL_ISLEMI_BITIR_EDITABLE", "YES");
			oMap.put("YP_ISLEMI_BITIR_EDITABLE", "YES");
			oMap.put("ISLEM_TARIHI",islemTarihi);
			String tableName = null;
			while (it.hasNext()) {
				zkYukumluluk = it.next();
				if (zkYukumluluk.getTipi().equals("TL")) {
					tableName = "TL_LISTE";
					oMap.put(tableName, rowTL, "ISLEM_TARIHI", zkYukumluluk.getId().getZkTarihi());
					oMap.put(tableName, rowTL, "ZK_KODU", zkYukumluluk.getId().getZkKodu());
					oMap.put(tableName, rowTL, "ZK_ADI", zkYukumluluk.getZkAdi());
					oMap.put(tableName, rowTL, "MIZAN_DK", zkYukumluluk.getMizanDk());
					oMap.put(tableName, rowTL, "ESKI_DONEM_A", zkYukumluluk.getEskiDonemA());
					oMap.put(tableName, rowTL, "YENI_DONEM_B", zkYukumluluk.getYeniDonemB());

					oMap.put(tableName, rowTL, "DURUM_B", zkYukumluluk.getDurumB());
					oMap.put(tableName, rowTL, "YENI_DONEM_C", zkYukumluluk.getYeniDonemC());
					oMap.put(tableName, rowTL, "DURUM_C", zkYukumluluk.getDurumC());
					oMap.put(tableName, rowTL, "NETLESEN_TUTAR", zkYukumluluk.getNetlesenTutar());
					oMap.put(tableName, rowTL, "ISLEM_TIPI", getIslemTipiValue(zkYukumluluk.getIslemTipi()));
					oMap.put(tableName, rowTL, "VALOR_TARIHI", zkYukumluluk.getValorTarihi());
					oMap.put(tableName, rowTL, "SIRA", zkYukumluluk.getSira());
					oMap.put(tableName, rowTL, "DURUM", getIslemDurum(zkYukumluluk.getDurum()));
					oMap.put(tableName, rowTL, "DURUM_V", zkYukumluluk.getDurum());
					oMap.put(tableName, rowTL, "DOVIZ_KODU", zkYukumluluk.getDovizKodu());
					oMap.put(tableName, rowTL, "MUHASEBE_FLAG", zkYukumluluk.getMuhasebeFlag());
					oMap.put(tableName, rowTL, "SWIFT_FLAG", zkYukumluluk.getSwiftFlag());
					oMap.put(tableName, rowTL, "EFT_FLAG", zkYukumluluk.getEftFlag());
					oMap.put(tableName, rowTL, "FIS_NO", zkYukumluluk.getFisNo());
					if(zkYukumluluk.getDurumD() != null && !zkYukumluluk.getDurumD().isEmpty())
						oMap.put(tableName, rowTL, "DURUM_D", getDurumDValue(zkYukumluluk.getDurumD()));
					else
						oMap.put(tableName, rowTL, "DURUM_D", getDurumD( zkYukumluluk));
					if((zkYukumluluk.getDurumB() == null || !zkYukumluluk.getDurumB().equals("K")) && zkYukumluluk.getMuhasebeFlag().equals("E")){
						oMap.put("TL_YENI_DONEM_C_EDITABLE", "NO");	
					}
					if(zkYukumluluk.getDurumD() != null && !zkYukumluluk.getDurumD().equals("K") && zkYukumluluk.getMuhasebeFlag().equals("E")){
						oMap.put("TL_ISLEMI_BITIR_EDITABLE", "NO");	
					}
					rowTL++;
				}
				else {
					tableName = "YP_LISTE";
					oMap.put(tableName, rowYP, "ISLEM_TARIHI", zkYukumluluk.getId().getZkTarihi());
					oMap.put(tableName, rowYP, "ZK_KODU", zkYukumluluk.getId().getZkKodu());
					oMap.put(tableName, rowYP, "ZK_ADI", zkYukumluluk.getZkAdi());
					oMap.put(tableName, rowYP, "MIZAN_DK", zkYukumluluk.getMizanDk());
					oMap.put(tableName, rowYP, "ESKI_DONEM_A", zkYukumluluk.getEskiDonemA());
					oMap.put(tableName, rowYP, "YENI_DONEM_B", zkYukumluluk.getYeniDonemB());

					oMap.put(tableName, rowYP, "DURUM_B", zkYukumluluk.getDurumB());
					oMap.put(tableName, rowYP, "YENI_DONEM_C", zkYukumluluk.getYeniDonemC());
					oMap.put(tableName, rowYP, "DURUM_C", zkYukumluluk.getDurumC());
					oMap.put(tableName, rowYP, "NETLESEN_TUTAR", zkYukumluluk.getNetlesenTutar());
					oMap.put(tableName, rowYP, "ISLEM_TIPI", getIslemTipiValue(zkYukumluluk.getIslemTipi()));
					oMap.put(tableName, rowYP, "VALOR_TARIHI", zkYukumluluk.getValorTarihi());
					oMap.put(tableName, rowYP, "SIRA", zkYukumluluk.getSira());
					oMap.put(tableName, rowYP, "DURUM", getIslemDurum(zkYukumluluk.getDurum()));
					oMap.put(tableName, rowYP, "DURUM_V", zkYukumluluk.getDurum());
					oMap.put(tableName, rowYP, "DOVIZ_KODU", zkYukumluluk.getDovizKodu());
					oMap.put(tableName, rowYP, "MUHASEBE_FLAG", zkYukumluluk.getMuhasebeFlag());	
					oMap.put(tableName, rowYP, "SWIFT_FLAG", zkYukumluluk.getSwiftFlag());
					oMap.put(tableName, rowYP, "EFT_FLAG", zkYukumluluk.getEftFlag());
					oMap.put(tableName, rowYP, "FIS_NO", zkYukumluluk.getFisNo());
					if(zkYukumluluk.getDurumD() != null && !zkYukumluluk.getDurumD().isEmpty())
						oMap.put(tableName, rowYP, "DURUM_D", getDurumDValue(zkYukumluluk.getDurumD()));
					else
						oMap.put(tableName, rowYP, "DURUM_D", getDurumD( zkYukumluluk));
					if((zkYukumluluk.getDurumB() == null || !zkYukumluluk.getDurumB().equals("K")) && zkYukumluluk.getMuhasebeFlag().equals("E")){
						oMap.put("YP_YENI_DONEM_C_EDITABLE", "NO");	
					}
					if(zkYukumluluk.getDurumD() != null && !zkYukumluluk.getDurumD().equals("K") && zkYukumluluk.getMuhasebeFlag().equals("E")){
						oMap.put("YP_ISLEMI_BITIR_EDITABLE", "NO");	
					}
					rowYP++;
				}
				
			}

			return oMap;

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	private static Boolean getIslemDurum(String durum) {
		if(durum.equals(IslemDurum.Tamamland�.key))
			return true;
		return false;
	}

	@GraymoundService("BNSPR_TRN1340_GET_INFO_VIEW")
	public static GMMap getInfoView1340(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			
			List<ZkYukumlulukTx> list = session.createCriteria(ZkYukumlulukTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).addOrder(Order.asc("sira")).list();

			Iterator<ZkYukumlulukTx> it = list.iterator();
			ZkYukumlulukTx zkYukumluluk = null;
			int rowYP = 0;
			int rowTL = 0;
 			String tableName = null;
			while (it.hasNext()) {
				zkYukumluluk = it.next();
				oMap.put("ISLEM_TARIHI", zkYukumluluk.getId().getZkTarihi());
				if (zkYukumluluk.getTipi().equals("TL")) {
					tableName = "TL_LISTE";
					oMap.put(tableName, rowTL, "ZK_KODU", zkYukumluluk.getId().getZkKodu());
					oMap.put(tableName, rowTL, "ZK_ADI", zkYukumluluk.getZkAdi());
					oMap.put(tableName, rowTL, "MIZAN_DK", zkYukumluluk.getMizanDk());
					oMap.put(tableName, rowTL, "ESKI_DONEM_A", zkYukumluluk.getEskiDonemA());
					oMap.put(tableName, rowTL, "YENI_DONEM_B", zkYukumluluk.getYeniDonemB());

					oMap.put(tableName, rowTL, "DURUM_B", zkYukumluluk.getDurumB());
					oMap.put(tableName, rowTL, "YENI_DONEM_C", zkYukumluluk.getYeniDonemC());
					oMap.put(tableName, rowTL, "DURUM_C", zkYukumluluk.getDurumC());
					oMap.put(tableName, rowTL, "NETLESEN_TUTAR", zkYukumluluk.getNetlesenTutar());
					oMap.put(tableName, rowTL, "ISLEM_TIPI", getIslemTipiValue(zkYukumluluk.getIslemTipi()));
					oMap.put(tableName, rowTL, "VALOR_TARIHI", zkYukumluluk.getValorTarihi());
					oMap.put(tableName, rowTL, "DURUM_D", getDurumDValue(zkYukumluluk.getDurumD()));
					oMap.put(tableName, rowTL, "DURUM", getIslemDurum(zkYukumluluk.getDurum()));
					rowTL++;
				}
				else {
					tableName = "YP_LISTE";
					oMap.put(tableName, rowYP, "ZK_KODU", zkYukumluluk.getId().getZkKodu());
					oMap.put(tableName, rowYP, "ZK_ADI", zkYukumluluk.getZkAdi());
					oMap.put(tableName, rowYP, "MIZAN_DK", zkYukumluluk.getMizanDk());
					oMap.put(tableName, rowYP, "ESKI_DONEM_A", zkYukumluluk.getEskiDonemA());
					oMap.put(tableName, rowYP, "YENI_DONEM_B", zkYukumluluk.getYeniDonemB());

					oMap.put(tableName, rowYP, "DURUM_B", zkYukumluluk.getDurumB());
					oMap.put(tableName, rowYP, "YENI_DONEM_C", zkYukumluluk.getYeniDonemC());
					oMap.put(tableName, rowYP, "DURUM_C", zkYukumluluk.getDurumC());
					oMap.put(tableName, rowYP, "NETLESEN_TUTAR", zkYukumluluk.getNetlesenTutar());
					oMap.put(tableName, rowYP, "ISLEM_TIPI", getIslemTipiValue(zkYukumluluk.getIslemTipi()));
					oMap.put(tableName, rowYP, "VALOR_TARIHI", zkYukumluluk.getValorTarihi());
					oMap.put(tableName, rowYP, "DURUM_D", getDurumDValue(zkYukumluluk.getDurumD()));
					oMap.put(tableName, rowYP, "DURUM", getIslemDurum(zkYukumluluk.getDurum()));
					rowYP++;
				}
				
			}

			return oMap;

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	private static String getDurumD(ZkYukumluluk zk) {
		if (zk != null && zk.getMuhasebeFlag().equals("E") && (zk.getTipi().equals("TL") || zk.getTipi().equals("YP")))
			if (zk.getDurumB() != null && zk.getDurumC() != null)
				if (zk.getDurumB().equals(Durum.Kesinle�ti.key)) {
					if (zk.getDurumC().equals(Durum.Beklemede.key)) {
						return Durum.Beklemede.toString();
					}
					else if (zk.getDurumC().equals(Durum.Onay.key)) {
						return Durum.Onay.toString();
					}
					else if (zk.getDurumC().equals(Durum.Kesinle�ti.key)) {
						return Durum.Kesinle�ti.toString();
					}
				}
		return "";
	}
	
	private static String getDurumDKey(String islemYapanBirim, String durum, String muhasebeFlag, String tipi) {
		if(durum == null && islemYapanBirim.equals("F") && muhasebeFlag.equals("E") && tipi.equals("YP")){
			return Durum.Beklemede.key;
		}
		if (durum != null)
			if (durum.equals(Durum.Beklemede.toString())) {
				return Durum.Beklemede.key;
			}
			else if (durum.equals(Durum.Onay.toString())) {
				return Durum.Onay.key;
			}
			else if (durum.equals(Durum.Kesinle�ti.toString())) {
				return Durum.Kesinle�ti.key;
			}
		return "";
	}
	
	private static String getDurumDValue(String durum) {
		if (durum != null)
			if (durum.equals(Durum.Beklemede.key)) {
				return Durum.Beklemede.toString();
			}
			else if (durum.equals(Durum.Onay.key)) {
				return Durum.Onay.toString();
			}
			else if (durum.equals(Durum.Kesinle�ti.key)) {
				return Durum.Kesinle�ti.toString();
			}
		return "";
	}

	@GraymoundService("BNSPR_TRN1340_GET_INFO_BY_TRX_DATE")
	public static GMMap getInfoByTrxDate1340(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<ZkYukumluluk> list = session.createCriteria(ZkYukumluluk.class).add(Restrictions.eq("id.zkTarihi", iMap.getDate("ISLEM_TARIHI"))).list();
			if(list.size() == 0){
				oMap.put("NO_DATA_FLAG", "1");
			}else{
				oMap.put("NO_DATA_FLAG", "0");
			}
			return oMap;
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN1340_GERI_AL_TL")
	public static GMMap geriAlTL(GMMap iMap) {
		String tableName = "TL_LISTE_S";
		int size = iMap.getSize(tableName);
		try {
			for (int row = 0; row < size; row++) {
				if (iMap.getBoolean(tableName, row, "SEC") == true) {
					iMap.put(tableName, row, "SEC", "false");
					if (iMap.getString(tableName, row, "DURUM_V").equals(IslemDurum.Tamamland�.key)) {
						iMap.put("SEC_KONTROL", "1");
						return iMap;
					}
					if (iMap.getDate(tableName, row, "VALOR_TARIHI").compareTo(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH")) < 0) {
						iMap.put("VALOR_TARIHI_KONTROL", "1");
						return iMap;
					}
					if (iMap.getString("ROL").equals("H")) {// Hazine
						iMap.put(tableName, row, "YENI_DONEM_C", 0);
						iMap.put(tableName, row, "DURUM_C", "");
						iMap.put(tableName, row, "DURUM_B", Durum.Beklemede.key);
					}
					else if (iMap.getString("ROL").equals("O")) {// Hazine Operasyon
						iMap.put(tableName, row, "DURUM_C", Durum.Beklemede.key);
						iMap.put(tableName, row, "DURUM_D", Durum.Beklemede.toString());
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN1340_GERI_AL_YP")
	public static GMMap geriAlYP(GMMap iMap) {
		String tableName = "YP_LISTE_S";
		int size = iMap.getSize(tableName);
		try {
			for (int row = 0; row < size; row++) {
				if (iMap.getBoolean(tableName, row, "SEC") == true) {
					iMap.put(tableName, row, "SEC", "false");
					if (iMap.getString(tableName, row, "DURUM_V").equals(IslemDurum.Tamamland�.key)) {
						iMap.put("SEC_KONTROL", "1");
						return iMap;
					}
					if (iMap.getDate(tableName, row, "VALOR_TARIHI").compareTo(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH")) < 0) {
						iMap.put("VALOR_TARIHI_KONTROL", "1");
						return iMap;
					}
					if (iMap.getString("ROL").equals("H")) {// Hazine
						iMap.put(tableName, row, "YENI_DONEM_C", 0);
						iMap.put(tableName, row, "DURUM_C", "");
						iMap.put(tableName, row, "DURUM_B", "B");
					}
					else if (iMap.getString("ROL").equals("O")) {// Hazine Operasyon
						iMap.put(tableName, row, "DURUM_C", Durum.Beklemede.key);
						iMap.put(tableName, row, "DURUM_D", Durum.Beklemede.toString());
					}
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return iMap;
	}

	@GraymoundService("BNSPR_TRN1340_GET_ROLE")
	public static GMMap getRoleTRN1340(GMMap iMap) {
		GMMap oMap = new GMMap();
		String roleId = (String) GMContext.getCurrentContext().getSession().get("ROLE_ID");
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1340.RolTipi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, roleId);
			stmt.execute();
			oMap.put("ROL",stmt.getString(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1340_NETLESEN_TUTAR_HESAP")
	public static GMMap netlesenTutarHesaplaTRN1340(GMMap iMap) {
		String tableName = "YP_LISTE";
		int size = iMap.getSize(tableName);
		BigDecimal usdToplam = new BigDecimal(0);
		BigDecimal eurToplam = new BigDecimal(0);
		try {
			for (int row = size-1; row >= 0; row--) {
				if(iMap.getString(tableName, row, "ZK_KODU").equals("BLOKE_USD_BAKIYE") || iMap.getString(tableName, row, "ZK_KODU").equals("SERBEST_USD_BAKIYE")){
					usdToplam = usdToplam.add(iMap.getBigDecimal(tableName, row, "NETLESEN_TUTAR") != null ? iMap.getBigDecimal(tableName, row, "NETLESEN_TUTAR") : new BigDecimal(0));
				}
				if(iMap.getString(tableName, row, "ZK_KODU").equals("SERBEST_EUR_BAKIYE") || iMap.getString(tableName, row, "ZK_KODU").equals("BLOKE_EUR_BAKIYE")){
					eurToplam = eurToplam.add(iMap.getBigDecimal(tableName, row, "NETLESEN_TUTAR") != null ? iMap.getBigDecimal(tableName, row, "NETLESEN_TUTAR") : new BigDecimal(0));
				}
				setNetlesenTutar(tableName,iMap,usdToplam,eurToplam,row);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}

	private static void setNetlesenTutar(String tableName, GMMap iMap, BigDecimal usdToplam, BigDecimal eurToplam, int row) {
		if(iMap.getString(tableName, row, "ZK_KODU").equals("TOPLAM_USD_BAKIYE")){
			iMap.put(tableName, row, "NETLESEN_TUTAR", usdToplam);
		}else if(iMap.getString(tableName, row, "ZK_KODU").equals("TOPLAM_EUR_BAKIYE")){
			iMap.put(tableName, row, "NETLESEN_TUTAR", eurToplam);
		}
		String islemTipi = ""; 
		if(usdToplam.compareTo(new BigDecimal(0)) < 0){
			islemTipi = IslemTipi.�ekme.toString();
		}else if(usdToplam.compareTo(new BigDecimal(0)) > 0){
			islemTipi = IslemTipi.Yat�rma.toString();
		}
		
		if(iMap.getString(tableName, row, "ZK_KODU").equals("TOPLAM_USD_BAKIYE")){
			iMap.put(tableName, row, "ISLEM_TIPI", islemTipi);
		}else if(iMap.getString(tableName, row, "ZK_KODU").equals("BLOKE_USD_BAKIYE")){
			iMap.put(tableName, row, "ISLEM_TIPI", islemTipi);
		}
		
		if(eurToplam.compareTo(new BigDecimal(0)) < 0){
			islemTipi = IslemTipi.�ekme.toString();
		}else if(eurToplam.compareTo(new BigDecimal(0)) > 0){
			islemTipi = IslemTipi.Yat�rma.toString();
		}
		
		if(iMap.getString(tableName, row, "ZK_KODU").equals("TOPLAM_EUR_BAKIYE")){
			iMap.put(tableName, row, "ISLEM_TIPI", islemTipi);
		}else if(iMap.getString(tableName, row, "ZK_KODU").equals("BLOKE_EUR_BAKIYE")){
			iMap.put(tableName, row, "ISLEM_TIPI", islemTipi);
		}
		
	}
}
