package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1354Services {

	@GraymoundService("BNSPR_QRY1354_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();

		iMap.put("KOD", "HZN_POZISL_AKTIF_PASIF");
		oMap.put("HZN_POZISL_AKTIF_PASIF", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_POZIZL_ISLEMCINSI");
		oMap.put("HZN_POZIZL_ISLEMCINSI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY1354_HZN_POSIZYON_HAREKET")
	public static GMMap getHznPozisyonHareketleri(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1354.RC_QRY1354_Pozisyon_Hareket(?,?,?,?,?,?,?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			if(iMap.getBoolean("CHECK_SIFIR_TUTARI"))
				stmt.setString(i++, "E");
			else
				stmt.setString(i++, "H");
			stmt.setString(i++, iMap.getString("ISLEM_CINSI"));
			
			if(iMap.getBoolean("REESKONT"))
				stmt.setString(i++, "E");
			else
				stmt.setString(i++, "H");
			stmt.setString(i++, iMap.getString("TUR"));
			if(iMap.getBoolean("TRADE_MI"))
				stmt.setString(i++, "E");
			else
				stmt.setString(i++, "H");
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "POSIZYON_HAREKET";
			int j=0;
			GMMap oMap = new GMMap();
			while (rSet.next())
			{
				oMap.put(tableName, j, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, j, "DOVIZ", rSet.getString("DOVIZ"));
				oMap.put(tableName, j, "FIS_NO", rSet.getString("FIS_NO"));
				oMap.put(tableName, j, "ISLEM_NO", rSet.getString("ISLEM_NO"));
				oMap.put(tableName, j, "KUR", rSet.getBigDecimal("KUR"));
				oMap.put(tableName, j, "NET_POZISYON_TUTARI", rSet.getString("NET_POZISYON_TUTARI"));
				oMap.put(tableName, j, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, j, "YARATILDIGI_SAAT", rSet.getString("YARATILDIGI_SAAT"));
				oMap.put(tableName, j, "ISLEM_KOD", rSet.getString("ISLEM_KOD"));
				j++;
			}
			return oMap; 
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1354_HZN_GUNLUK_POSIZYON_HAREKET")
	public static GMMap getHznGunlukPozisyonHareketleri(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			
			if (iMap.getBoolean("TRADE_MI")) {
				stmt = conn.prepareCall("{call PKG_RC1354.RC_QRY1354_Gunluk_Hareket_T(?,?,?,?,?,?,?,?,?,?)}");
			} else {
				stmt = conn.prepareCall("{call PKG_RC1354.RC_QRY1354_Gunluk_Hareket(?,?,?,?,?,?,?,?,?,?)}");
			}
			
			if(iMap.getDate("TARIH")==null)
				stmt.setDate(1, null);
			else
				stmt.setDate(1, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setString(2, iMap.getString("DOVIZ_KODU"));
			if(iMap.getBoolean("CHECK_SIFIR_TUTARI"))
				stmt.setString(3, "E");
			else
				stmt.setString(3, "H");
			stmt.setString(4, iMap.getString("ISLEM_CINSI"));
			if(iMap.getBoolean("REESKONT"))
				stmt.setString(5, "E");
			else
				stmt.setString(5, "H");
			stmt.setString(6, iMap.getString("TUR"));
			if(iMap.getBoolean("TRADE_MI"))
				stmt.setString(7, "E");
			else
				stmt.setString(7, "H");
			stmt.registerOutParameter(8, -10);
			stmt.registerOutParameter(9, -10);
			stmt.registerOutParameter(10, -10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(8);
			GMMap oMap = DALUtil.rSetResults(rSet, "GUNLUK_POSIZYON_HAREKET");
			GMServerDatasource.close(rSet);
			rSet = (ResultSet)stmt.getObject(9);
			oMap.putAll(DALUtil.rSetResults(rSet, "GUNLUK_POSIZYON_HAREKET_ONCE"));
			GMServerDatasource.close(rSet);
			rSet = (ResultSet)stmt.getObject(10);
		    oMap.putAll(DALUtil.rSetResults(rSet, "GUNLUK_POSIZYON_HAREKET_SONRA"));
		    return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
