package tr.com.calikbank.bnspr.treasury.services;


import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HaTalepDetayTx;
import tr.com.aktifbank.bnspr.dao.HaTalepDetayTxId;
import tr.com.aktifbank.bnspr.dao.HaUyeTalepDetayTx;
import tr.com.aktifbank.bnspr.dao.HaUyeTalepDetayTxId;
import tr.com.aktifbank.bnspr.dao.HaUyeTalepTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/* Fikret Tiryaki
 * Halka arz dosya okuma
 */ 

public class TreasuryTRN1501Services {
    //Test te comment out et. prodda  kals�n
//    private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";
    private static String ROOT ;
    public static final String projeKodu ="GMS200513";
    
    @GraymoundService("BNSPR_TRN1501_URUNKODUAL")
    public static GMMap GetHalkaArzUrunKodu (GMMap iMap){
        Connection conn       = null;
        CallableStatement stmt  = null;
        ResultSet rSet          = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call PKG_HALKA_ARZ.URUN_KODU_AL( ?, ?) }");

            stmt.registerOutParameter(2, Types.VARCHAR);
            stmt.setString(1, iMap.getString("IN_PROJE_KOD"));
            stmt.execute();
            oMap.put("OUT_URUN_KOD", stmt.getString(2));
            iMap.put("KOD", "AKTIFBANK_IMKB_KOD");
            String aktifbankImkbKod =GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getString("DEGER");
            oMap.put("OUT_UYE_KOD",aktifbankImkbKod.replace("\"" , "") );

            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
            
    }
    
	
	@GraymoundService("BNSPR_TRN1501_KAZANCHESAPLA")
	public static GMMap LotKazancHesapla (GMMap iMap){
	    Connection conn       = null;
        CallableStatement stmt  = null;
        ResultSet rSet          = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call PKG_HALKA_ARZ.LOT_KAZANC_HESAPLA( ?, ?, ?, ?, ?, ?, ?, ? ) }");

            stmt.registerOutParameter(4, Types.NUMERIC);
            stmt.registerOutParameter(5, Types.NUMERIC);
            stmt.registerOutParameter(6, Types.NUMERIC);
            stmt.registerOutParameter(7, Types.NUMERIC);
            stmt.registerOutParameter(8, Types.DATE);
            stmt.setString(1, iMap.getString("IN_S_URUN_KODU"));
            stmt.setBigDecimal(2, iMap.getBigDecimal("IN_N_ISTENEN_ADET"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("IN_N_ISTENEN_TUTAR"));
            stmt.execute();
            oMap.put("OUT_N_VERILEN_LOT", stmt.getBigDecimal(4));
            oMap.put("OUT_N_VERILEN_TUTAR", stmt.getBigDecimal(5));
            oMap.put("OUT_N_VADE_SONU_TUTAR", stmt.getBigDecimal(6));
            oMap.put("OUT_N_VADE_SONU_KAZANC", stmt.getBigDecimal(7));
            oMap.put("OUT_D_VADE_TARIHI", stmt.getDate(8));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
			
	}
	
	public static class Position{public int i=0;};
	
	public static String ParseData(String data, Position p, int length ){
	    
	    String retVal = data.substring(p.i,p.i+length).trim();
	    p.i+=length;
        return retVal;
	}
	
	public static BigDecimal ParseBigDecimal(String tempData, int length) throws Exception
	{
	    
	    if(tempData.length() != length)
	        throw new Exception("Sayisal alanda bosluklar var");
	    
	    tempData = tempData.substring(0, tempData.length()-2) +"."+ tempData.substring(tempData.length()-2);
	    
	    return new BigDecimal(tempData);

	}
	
	public static ArzElement  ParseAndAnalyzeRow (String row, String haKod, String uyeKod, boolean isAdmin)
	{ 

	    DateFormat df = new SimpleDateFormat("ddMMyyyyhhmmss");
	    Position p = new Position();
	    ArzElement ae = new ArzElement();
	    String tempStr;
	    BigDecimal tempBigDec;
	    Date tempDate; 
	    int tempInt;
	    ae.setHamData(row);
	    ae.getHt().setHaKod(haKod);
	    if(row.length() != 302){
	         ae.MarkError("Talep satiri 302 karakter degil. ("+row.length()+")");
	         return ae;
	    }
	    
	    try{
//	    � Kay�t Tipi Kodu : 1 Hane Alfabetik (Talep Dosyas� i�in Standart �B�, Da��t�m Dosyas� i�in Standart �D�)	
	        tempStr = ParseData(row , p , 1);
	        if(!tempStr.equals("B")){
	                ae.MarkError("Bilinmeyen islem kodu. ("+tempStr+")");
	                return ae;
	         }
	        if(isAdmin)
	            ae.getHt().setTalepTipi(tempStr);
	        else
	            ae.getHt().setTalepTipi("K");
	        
//	      � �MKB �ye Kodu : 3 Hane Alfabetik
	        tempStr = ParseData(row , p , 3);
            if(tempStr.length()!=3  || !tempStr.equals(uyeKod) ){
                    ae.MarkError("Hatali uye kod. ("+tempStr+")");
                    return ae;
             }  
            ae.getHt().setUyeKod(tempStr);
	     
//	    � Tahsis Grubu Kodu : 3 Hane Say�sal
           tempStr = ParseData(row , p , 3);
           tempBigDec =new  BigDecimal(tempStr);
           ae.getHt().setTahsisGrup(tempBigDec);
         
//	    � Ba�vuru S�ra No : 9 Hane Say�sal
           tempStr = ParseData(row , p , 9);
           tempInt = Integer.parseInt(tempStr); 
           ae.getHt().setBasvuruSira(tempInt);            
            
            
            
            
            
//	    � �deme Tipi : 1 Hane Alfabetik (P,B,D)
           tempStr = ParseData(row , p , 1);
            if(!(tempStr.equals("P")  ||  tempStr.equals("B")  ||tempStr.equals("D")) ){
                    ae.MarkError("Bilinmeyen odeme turu. ("+tempStr+")");
                    return ae;
             } 
            ae.getHt().setOdemeTipi(tempStr);
            


//	    � Bloke Bozdurma Y�ntemi : 1 Hane Alfabetik (S,D)
          tempStr = ParseData(row , p , 1);
            if(!(tempStr.equals("S")  ||  tempStr.equals("D")) ){
                    ae.MarkError("Bilinmeyen bloke bozdurma yontemi. ("+tempStr+")");
                    return ae;
             } 
          ae.getHt().setBlokeBozdurmaYontemi( tempStr);
          
          
          
//	    � Bloke Bozdurma S�ras� : 3 Hane Say�sal
          
          tempStr = ParseData(row , p , 3);
          tempBigDec =new  BigDecimal(tempStr);
          ae.getHt().setBlokeBozdurmaSirasi(tempBigDec);            
           
          
          
//	    � Talep Art�r�m� : 1 Hane Alfabetik (A,N)
          tempStr = ParseData(row , p , 1);
          if(!(tempStr.equals("A")  ||  tempStr.equals("N")) ){
                  ae.MarkError("Bilinmeyen talep artt�r�m� turu. ("+tempStr+")");
                  return ae;
           } 
          ae.getHt().setTalepArtirimi(tempStr); 
          
          
//	    � Talep Tipi : 1 Hane Alfabetik(B,A)
          tempStr = ParseData(row , p , 1);
          if(!(tempStr.equals("A")  ||  tempStr.equals("B")) ){
                  ae.MarkError("Bilinmeyen talep tipi. ("+tempStr+")");
                  return ae;
           } 
          ae.getHt().setTalepTipi(tempStr); 
          
          
          
          
//	    � Teklif Numaras� : 2 Hane Say�sal(00,01)
          tempStr = ParseData(row , p , 2);
          tempBigDec =new  BigDecimal(tempStr);
          ae.getHt().setTeklifNumarasi(tempBigDec);    
          
          
//	    � Ad� : 15 Hane Alfabetik
          tempStr = ParseData(row , p , 15);
          ae.getHt().setAdi( tempStr);
          
          
          
          
//	    � �kinci Ad� : 15 Hane Alfabetik
          tempStr = ParseData(row , p , 15);
          ae.getHt().setIkinciAdi(tempStr);
          
          
//	    � Soyad� : 15 Hane Alfabetik
          tempStr = ParseData(row , p , 15);
          ae.getHt().setSoyadi(tempStr);
          
          
//	    � T.C.Kimlik No : 11 Hane Say�sal
          tempStr = ParseData(row , p , 11);
          long  tempLong =  Long.parseLong(tempStr);
          ae.getHt().setTcKimlik(tempLong);   
          
          
          
//	    � Adres : 60 Hane Alfanumerik
          tempStr = ParseData(row , p ,  60);
          ae.getHt().setAdres(tempStr);
          
          
          
          
//	    � �l�e : 15 Hane Alfanumerik
          tempStr = ParseData(row , p , 15);
          ae.getHt().setIlce(tempStr);
          
          
          
//	    � �l (Trafik Kodu) : 2 Hane Say�sal
          tempStr = ParseData(row , p , 2);
          tempBigDec =new  BigDecimal(tempStr);
          ae.getHt().setIl(tempBigDec);
          
          
          
//	    � Talep Tarihi : 8 Hane Say�sal (ggaayyyy)
//	    � Talep Saati : 6 Hane Say�sal (SSddss)
          tempStr = ParseData(row , p , 14);
          tempDate = df.parse(tempStr);
          ae.getHt().setTalepTarihi(tempDate);
          
          
          
          
          
//	    � Halka Arz Birim Fiyat� : 11 Hane Say�sal (9 Hane TL ,2 Hane KR)
          tempStr = ParseData(row , p , 11);
          ae.getHt().setBirimFiyat(new BigDecimal(0));
          
          
          
//	    � Talep Edilen Miktar (Toplam Lot) : 11 Hane Say�sal
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepLot(Long.parseLong(tempStr));  
	    
	    
	    
	    
//	    � Talep Edilen Miktar Alt S�n�r� : 11 Hane Say�sal
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepAltSinirLot(Long.parseLong(tempStr)); 
        
        
        
//	    � Talep Edilen Tutar (Likit Fon Blokesiyle) : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTLikitFonB(ParseBigDecimal(tempStr , 11)); 
        
        
        
//	    � Talep Edilen Tutar (DIBS Blokesiyle) : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTDibsB(ParseBigDecimal(tempStr , 11)); 
        
        
        
        
//	    � Talep Edilen Tutar (D�viz Endeksli DIBS Blokesiyle) : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTDovizDibsB(ParseBigDecimal(tempStr , 11)); 
        
        
        
//	    � Talep Edilen Tutar (Euro Blokesiyle) : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTEuroB( ParseBigDecimal(tempStr , 11)); 
        
        
        
        
//	    � Talep Edilen Tutar (Dolar Blokesiyle) : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTDolarB(ParseBigDecimal(tempStr , 11)); 
        
        
        
        
//	    � Talep Edilen Tutar (Di�er D�viz Cinsi Blokesiyle) : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTDigerDovB(ParseBigDecimal(tempStr , 11)); 
        
        
        
//	    � Talep Tutar� : 11 Hane Say�sal(9 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 11);
        ae.getHt().setTalepTutar(ParseBigDecimal(tempStr , 11)); 
        
        
        
        
//	    � Da��t�m Adedi : 11 Hane Say�sal(Talep Dosyas�nda �00000000000�)
        tempStr = ParseData(row , p , 11);
        
        
        
//	    � Talep Edilen Tutar Aktif Bank Bono Blokesiyle) : 9 Hane Say�sal(7 Hane TL,2 Hane KR.)
        tempStr = ParseData(row , p , 9);
        ae.getHt().setTalepTAktifBB(ParseBigDecimal(tempStr , 9)); 
	    
	        
	    
	    
	    }catch(Exception exc){
	        ae.MarkError("Exc: "+exc.getMessage());
	    }
	    
	    
	    
	    return ae;
	}
	
	
	public static ArzModel GenerateArzModel(GMMap iMap)  {
	    ArzModel arz = new ArzModel();

        try {

            
            String h =  iMap.getString("HEADER");
            String f =  iMap.getString("FOOTER");
            String t =  iMap.getString("USERTYPE");
            String u =  iMap.getString("USERNAME");
           
            
          //  Kay�t Tipi Kodu: 1 Hane Alfabetik (Standart �S�)
          //  �IMKB �ye Kodu: 3 Hane Alfabetik
          //  �Halka Arz Kodu: 5 Hane Alfabetik
             String uyeKod = h.substring(1,4).trim();
            String arzKod = h.substring(4,9).trim(); 
            long teklifSayisi = Long.parseLong(f.substring(7,18));
            int size = iMap.getSize("TABLE");
            arz.setAdmin(t.equals("A"));
            arz.setGonderen(u);        
            arz.setUyeKodu(uyeKod);
            arz.setUrunKodu(arzKod);
           
            arz.setTeklifListesi( new ArrayList<TreasuryTRN1501Services.ArzElement>());
            
          
            
            if( arz.getUyeKodu() .length()!=3)
            {
                return arz;
            }
            
            if(arzKod.length()!=5)
            {
               return arz;
            }
            
            if(size != teklifSayisi)
            {
                return arz;
            }
               
                    
         arz.setTeklifSayisi(teklifSayisi);
            int j = 0;
          
            
            for(int i = 0 ; i< size ; i++)
            {
                ArzElement ae =  ParseAndAnalyzeRow(iMap.getString("TABLE", i , "DATA") , arzKod , uyeKod , t.equals("A"));
                    arz.getTeklifListesi().add( ae)   ;

            }
           


        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {

        }
        return arz;
	}
	
	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_KAYDET")
    public static GMMap TalepAsenkronKaydet(GMMap iMap){
	    
	    
	    Session session = DAOSession.getSession("BNSPRDal");
	    BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
	    iMap.put("TRX_NO",txNo);
	 
	    
        ArzModel arz = GenerateArzModel(iMap) ;
        HaUyeTalepTx haut = new HaUyeTalepTx();
        haut.setHaKod(arz.getUrunKodu());
        haut.setUyeKod(arz.getUyeKodu());
        haut.setToplamSatir(  new BigDecimal(  Long.toString( arz.getTeklifSayisi() ))  );
        BigDecimal aid =new BigDecimal( GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO",
                iMap).get("SIRA_NO").toString());
                haut.setId(aid);
        
        
        haut.setTxNo(txNo);
        haut.setStatus("Y");
        haut.setSource(arz.isAdmin()?"A":"K");

       
        
        haut.setYukleyen(arz.getGonderen());
        
       
  
            
            if( arz.getUyeKodu() .length()!=3)
            {  
                haut.setHataAciklama("Hatali uye kodu");
                session.saveOrUpdate(haut);
                return iMap;
 
             
            }
            
            if( arz.getUrunKodu().length()!=5)
            {
                haut.setHataAciklama("Hatali uye kodu");
                session.saveOrUpdate(haut);
                return iMap;
            }
            else if(arz.getTeklifSayisi() < 1)
            {
                haut.setHataAciklama("Hatali teklif sayisi");
                session.saveOrUpdate(haut);
                return iMap;
            }
            
            int hataliSatir = 0;
             BigDecimal toplamTutar = new BigDecimal(0);
             BigDecimal toplamLot = new BigDecimal(0);
            
             
             HaTalepDetayTx hbx;

             // Tabloda yer almayacak elamanlar�n kay�t edilmemesi i�in �nceki kay�tar� sil

             List<HaTalepDetayTx> bbPRM = session.createCriteria(HaTalepDetayTx.class).add(Restrictions.eq("id.txNo", txNo)).list();

             if (bbPRM != null) {
                 for (HaTalepDetayTx bb : bbPRM) {
                     session.delete(bb);
                 }
             }
             session.flush();
            
            for(int i = 0; i < arz.getTeklifListesi().size(); i++){
                HaUyeTalepDetayTx hautd = new HaUyeTalepDetayTx();
                ArzElement ae = arz.getTeklifListesi().get(i);
                
                BigDecimal recId = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO");
                
                hautd.setSatir(ae.getHamData());
                hautd.setHaKod(ae.getHt().getHaKod());
                HaUyeTalepDetayTxId tid = new HaUyeTalepDetayTxId();
                tid.setTalepId(aid );
                tid.setTxNo(txNo);
                tid.setId(recId);
                hautd.setId(tid);
                hautd.setUyeKod(ae.getHt().getUyeKod());
                hautd.setStatus( "Y" ); 
                session.saveOrUpdate(hautd);  
                
                
                
                if(arz.isAdmin()){
                    if(!ae.isHatalimi()){
                        HaTalepDetayTx htd = new HaTalepDetayTx();

                                
                        htd =   ae.getHt();
                        HaTalepDetayTxId id = new HaTalepDetayTxId();
                        id.setTxNo(txNo);
                        id.setId(recId);
                        htd.setId(id);
                        
                        htd.setTalepId(aid);
                        htd.setDagitimDurumu("T");
                        htd.setStatus("A");
                        
                        htd.setTalepTKatilHB(new BigDecimal(0));
                        htd.setTalepTVadeliMevB(new BigDecimal(0));
                        htd.setTxType("Y");
                        htd.setDagitimAdet(new Long(0));
                        session.saveOrUpdate(htd);
                        toplamLot.add(new BigDecimal( htd.getTalepLot()));
                        toplamTutar.add(htd.getTalepTutar());
                    }
                }
                if(ae.isHatalimi())
                    hataliSatir++;
            }
            
            


    haut.setHataliSatir( new BigDecimal( hataliSatir));


    haut.setToplamTutar(toplamTutar);
    haut.setToplamLot(toplamLot);

   session.saveOrUpdate(haut);  
 
  
    session.flush();
    iMap.put("TRX_NAME", "1501");

    GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
    return iMap;
    
    
    
    }
	
	
	
	
	
	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_AL")
    public static GMMap PortalTalepAl(GMMap iMap){
	    //TODO: debug
	//   com.graymound.service.GMServiceExecuter.executeAsync("BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_KAYDET", iMap);
        GMMap oMap = new GMMap();
        
        try{
	    ArzModel arz = GenerateArzModel(iMap) ;

             
            
            if( arz.getUyeKodu() .length()!=3)
            {
                oMap.put("HATA" , "Uye kodu okunamadi!");
                return oMap;
            }
            
            if( arz.getUrunKodu().length()!=5)
            {
                oMap.put("HATA" , "Urun kodu okunamadi!");
                return oMap;
            }
            else if(arz.getTeklifSayisi() < 1)
            {
                oMap.put("HATA" , "Teklif sayisi tutmuyor!");
                return oMap;
            }
            

            int j = 0;
          
            
            for(int i = 0 ; i< arz.getTeklifSayisi() ; i++)
            {
                ArzElement ae =     arz.getTeklifListesi().get( i)   ;
                    if(ae.isHatalimi()) {
                        oMap.put("TABLE" ,j++,"DATA", ae.getHt().getBasvuruSira()+": "+ae.getHata());
                    }
            }
        }
            catch(Exception exc){
                oMap.put("HATA" , exc.getMessage());
            }
              
        return oMap;
    }


	
	static class ArzModel{
	    public long getTeklifSayisi() {
            return teklifSayisi;
        }
        public void setTeklifSayisi(long teklifSayisi) {
            this.teklifSayisi = teklifSayisi;
        }
        public String getUyeKodu() {
            return uyeKodu;
        }
        public void setUyeKodu(String uyeKodu) {
            this.uyeKodu = uyeKodu;
        }
        public String getUrunKodu() {
            return urunKodu;
        }
        public void setUrunKodu(String urunKodu) {
            this.urunKodu = urunKodu;
        }
        public ArrayList<ArzElement> getTeklifListesi() {
            return teklifListesi;
        }
        public void setTeklifListesi(ArrayList<ArzElement> teklifListesi) {
            this.teklifListesi = teklifListesi;
        }
        long teklifSayisi;
	    String uyeKodu;
	    String urunKodu;
	    ArrayList<ArzElement>  teklifListesi;
	    String gonderen;
	    boolean isAdmin;
	    
        public boolean isAdmin() {
            return isAdmin;
        }
        public void setAdmin(boolean isAdmin) {
            this.isAdmin = isAdmin;
        }
        public String getGonderen() {
            return gonderen;
        }
        public void setGonderen(String gonderen) {
            this.gonderen = gonderen;
        }
	   
	    
	    
	}
	
	static class ArzElement    {
	    /**
         * 
         */
        private static final long serialVersionUID = 11111111111111111L;
        String hamData;
	    public String getHamData() {
            return hamData;
        }
        public void setHamData(String hamData) {
            this.hamData = hamData;
        }
        
       private HaTalepDetayTx ht = new HaTalepDetayTx();
       
       
        
        public HaTalepDetayTx getHt() {
        return ht;
    }
    public void setHt(HaTalepDetayTx ht) {
        this.ht = ht;
    }

        boolean Hatalimi = false;
	    
	    public boolean isHatalimi() {
            return Hatalimi;
        }
        public void setHatalimi(boolean hatalimi) {
    
            Hatalimi = hatalimi;
        }
        public String getHata() {
            return Hata;
        }
        public void setHata(String hata) {
            Hata = hata;
        }
        String Hata;
        
        public void MarkError(String hata)
        {
            setHata(hata);
            Hatalimi = true;
        }
	    
	}
	

	
	@GraymoundService("BNSPR_TRN1501_HALKA_ARZ_ANALIZ_MAIL")
    public static GMMap pttKuryeBatch(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        GMMap mailMap = new GMMap();
        try {
            StringBuilder stb = new StringBuilder();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1501.GetAnalizUyeler(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, projeKodu); 
            stmt.execute();
            int i = 0;
            rSet = (ResultSet) stmt.getObject(1);
            while(rSet.next()){
                stb.append("\n\n");
                stb.append(rSet.getString("ACIKLAMA"));
                stb.append("\n\n");
                stb.append("Kurum Kodu: "); 
                stb.append(rSet.getString("HA_UYE"));
                stb.append("\n");
                stb.append("Y�klenme Tarihi: ");
                stb.append(rSet.getString("YUKLENME_TARIHI"));
                stb.append("\n");
                stb.append("Toplam sat�r: ");
                stb.append(rSet.getString("TOPLAM_SATIR"));
                stb.append("\n");
                stb.append("Hatali sat�r: ");
                stb.append(rSet.getString("HATALI_SATIR"));
                stb.append("\n");
                stb.append("Dosya Formati: ");
                stb.append(rSet.getString("HATA_ACIKLAMA"));
                stb.append("\n\n");

                iMap.put("ID", rSet.getString("ID"));
                iMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN1501_HALKA_ARZ_EXCEL", iMap));
                if(iMap.getInt("DOSYA_SAYISI")>0){
                    try{
                        mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", iMap.getString("FILE_NAME") +".xls");
                        mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(new File(ROOT + File.separator + "files" + File.separator+ iMap.getString("FILE_NAME_PTT"))));
                        
                    }catch(Exception e){
                        e.printStackTrace();
                        stb.append("Dosya al�n�rken hata olu�tu");
                    }
                }
                else{
                    stb.append("Olu�turulacak Rapor Bulunamad�.");
                }
                mailMap.put("MAIL_SUBJECT", rSet.getString("ACIKLAMA") + " Rapor Dosyas�");
                mailMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
                mailMap.put("MAIL_TO", rSet.getString("EPOSTA"));
                mailMap.put("MAIL_CC", DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'ANALIZ', 'CC') from dual"));
                mailMap.put("IS_BODY_HTML", "H");
                mailMap.put("MAIL_BODY", stb);
                
                
                GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
  //              GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
                stb.setLength(0);
                iMap.clear();
            }
            
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

	
    @GraymoundService("BNSPR_TRN1501_HALKA_ARZ_EXCEL")
    public static GMMap halkaArzExcel(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            Map<String, String[]> headers = new LinkedHashMap<String, String[]>();

            headers.put("SATIR", new String[] { "Sat�r" });
            headers.put("ANALIZ_SONUC", new String[] { "Analiz Sonu�" });

            oMap.put("HEADERS", headers);
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1501.GetAnalizRapor(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, iMap.getString("ID"));
            stmt.execute();

            rSet = (ResultSet) stmt.getObject(1);

            String tableName = "TABLE_DATA";
            int row = 0;
            while (rSet.next()) {
                oMap.put(tableName, row, "SATIR", rSet.getObject("SATIR"));
                oMap.put(tableName, row, "ANALIZ_SONUC", rSet.getObject("ANALIZ_SONUC"));
                row++;
            }
            oMap.put("FILE_NAME", "halkaArz");
            
            oMap = GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", oMap);
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_TRN1501_HALKA_ARZ_NOVA_MAIL")
    public static GMMap HalkaArzNovaDosyasi(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        Random rnd = new Random();
        String randomFileCode = rnd.nextInt(1000) + "";
        GMMap oMap = new GMMap();
       
        try {
            
            
            StringBuilder stb = new StringBuilder();
            conn = DALUtil.getGMConnection();
          
       
                stb.append("Nova dagitim dosyasi ektedir.");
                
                
                
                iMap.put("IN_PROJE_KOD" , projeKodu);
               String urunKodu=   GMServiceExecuter.call("BNSPR_TRN1501_URUNKODUAL", iMap).getString("OUT_URUN_KOD");

            

                
                File file = null;
                FileWriter fileWriter = null;
                String filePath = ROOT + File.separator + "files" + File.separator + "NOVA("+randomFileCode +").csv";
        
                
                    file = new File(filePath);
                    file.createNewFile();
                    fileWriter = new FileWriter(file);
                   

                     conn = DALUtil.getGMConnection();
                     stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetNovaDosyasi(?) }");
                     stmt.registerOutParameter(1, -10);
                     stmt.setString(2,urunKodu);
                     stmt.execute();

                     rSet = (ResultSet) stmt.getObject(1);
                     while(rSet.next())
                     {
                         fileWriter.write(rSet.getString("data"));
                         fileWriter.write("\r\n");
                     }
                      fileWriter.close();


                GMMap mailMap = new GMMap();

      
                    try{
                        mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME",  "Nova.csv");
                        mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(filePath));
                        
                    }catch(Exception e){
                        e.printStackTrace();
                        stb.append("Dosya al�n�rken hata olu�tu");
                    }
             
                mailMap.put("MAIL_SUBJECT", "NOVA Dagitim Dosyasi");
                mailMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
                mailMap.put("MAIL_TO", DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'NOVA', 'TO') from dual"));
                mailMap.put("MAIL_CC", DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'NOVA', 'CC') from dual"));
                mailMap.put("IS_BODY_HTML", "H");
                mailMap.put("MAIL_BODY", stb);
                
                
                
                
                //prod
              GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
                
                //local test
        //        GMConnection.getConnection("SCHEDULER").serviceCall("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
                
                
                
                
                stb.setLength(0);
                iMap.clear();
          
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_TRN1501_HALKA_ARZ_DAGITIM_MAIL")
    public static GMMap HalkaArzDagitimMail(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        Random rnd = new Random();
        String randomFileCode = rnd.nextInt(1000) + "";
        GMMap oMap = new GMMap();
       
        try {
            StringBuilder stb = new StringBuilder();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetUyeler(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, projeKodu); 
            stmt.execute();
            int i = 0;
            rSet = (ResultSet) stmt.getObject(1);
            while(rSet.next()){
                stb.append("\n\n");
                stb.append(rSet.getString("ACIKLAMA"));
                stb.append("\n\n");
                stb.append("Kurum Kodu: "); 
                stb.append(rSet.getString("HA_UYE"));
                stb.append("\n");

                GMMap mailMap = new GMMap();
                iMap.put("HA_UYE", rSet.getString("HA_UYE"));
                iMap.put("FILE_NAME",   rSet.getString("HA_UYE")+"("+randomFileCode+")");
                iMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN1501_HALKA_ARZ_DAGITIM_DOSYASI", iMap));
                if(iMap.getInt("DOSYA_SAYISI")>0){
                    try{
                        mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", iMap.getString("FILE_NAME") +".txt");
                        mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray((ROOT + File.separator + "files" + File.separator + iMap.getString("FILE_NAME")+".txt")));
                        
                    }catch(Exception e){
                        e.printStackTrace();
                        stb.append("Dosya al�n�rken hata olu�tu");
                    }
                }
                else{
                    stb.append("Olu�turulacak Rapor Bulunamad�.");
                }
                mailMap.put("MAIL_SUBJECT", rSet.getString("ACIKLAMA") + " Dagitim Dosyasi");
                mailMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
                mailMap.put("MAIL_TO", DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'DAGITIM', 'TO') from dual"));
                mailMap.put("MAIL_CC", DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('HA_EMAIL', 'DAGITIM', 'CC') from dual"));
                mailMap.put("IS_BODY_HTML", "H");
                mailMap.put("MAIL_BODY", stb);
                
                
                
                
                //prod
               GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
                
                //local test
       //          GMConnection.getConnection("SCHEDULER").serviceCall("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
                
                
                
                
                stb.setLength(0);
                iMap.clear();
            }
            
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    

    @GraymoundService("BNSPR_TRN1501_HALKA_ARZ_DAGITIM_DOSYASI")
    public static GMMap halkaArzDagitimDosyasi(GMMap iMap)  {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        

     
        iMap.put("IN_PROJE_KOD" , projeKodu);
        oMap=   GMServiceExecuter.call("BNSPR_TRN1501_URUNKODUAL", iMap);
        String urunKodu=oMap.getString("OUT_URUN_KOD");
        oMap.put("HA_UYE" , iMap.getString("HA_UYE"));

        
        
        String uyeKodu="";
        
        
        
        File file = null;
		FileWriter fileWriter = null;
	
		oMap.put("DOSYA_SAYISI" ,0);
        try {
        
            
            
            uyeKodu=iMap.getString("HA_UYE");	
            file = new File(ROOT + File.separator + "files" + File.separator + iMap.getString("FILE_NAME")+".txt");
     //   	file = new File(iMap.getString("FILE_NAME")+".txt");
        	file.createNewFile();
        	fileWriter = new FileWriter(file);
           

             conn = DALUtil.getGMConnection();
             stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetDagitimDosyasi(?,?) }");
             stmt.registerOutParameter(1, -10);
             stmt.setString(2,uyeKodu);
             stmt.setString(3,urunKodu);
             stmt.execute();

             rSet = (ResultSet) stmt.getObject(1);
             while(rSet.next())
             {
            	 fileWriter.write(rSet.getString("SATIR"));
            	 fileWriter.write("\r\n");
            	 oMap.put("DOSYA_SAYISI" ,1);
             }
              fileWriter.close();
             

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            
        }
    }
    
    @GraymoundService("BNSPR_TRN1501_GET_CUSTOMER_REPORT")
    public static GMMap CustomerReport(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;

        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call BNSPR.PKG_Halka_Arz.CustomerReport(?,?) }");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2,iMap.getString("UYE"));
            stmt.setString(3,iMap.getString("STATU"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet, "TABLE");
            return oMap;

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }

    @GraymoundService("BNSPR_TRN_1501_COMBO_PARAMETERS")
    public static GMMap getCombo(GMMap iMap) {

        GMMap oMap = new GMMap();
        String listName = "STATU";
        GuimlUtil.wrapMyCombo(oMap, listName, "", "HEPSI");
        GuimlUtil.wrapMyCombo(oMap, listName, "A", "Talep Alindi");
        GuimlUtil.wrapMyCombo(oMap, listName,  "I", "Iptal");
        GuimlUtil.wrapMyCombo(oMap, listName, "T", "Tahsilat Bekliyor");
        GuimlUtil.wrapMyCombo(oMap, listName,  "Y", "Teminat Yetersiz");
        GuimlUtil.wrapMyCombo(oMap, listName,   "M","Alt Sinira Takilmis");
        GuimlUtil.wrapMyCombo(oMap, listName,   "B", "Basarili");
        GuimlUtil.wrapMyCombo(oMap, listName,  "H","Tahsilat Hatas�");
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN_1501_DEBUGGER")
    public static GMMap debuggg(GMMap iMap) {
        
        
        iMap.put("HEADER","SIYMAKFEN" );
        iMap.put("FOOTER","TIYM99900000000003" );
        iMap.put("USERTYPE","A" );
        iMap.put("USERNAME","FIKRET" );
        iMap.put("TABLE",0 ,"DATA","BIYM025000000003PS000NA01AV�VASA EMEK.  VE Y.AM�.ESNEK             FON00110398430�NKILAP MAH. K���KSU CAD. AK�A KOCA SOK.NO: 8 34768         �MRAN�YE       34070520101700370000000125000000025000000000000010000000000000000000000000000000000000000000000000000000000000000000003125000000000000000000000000" ); 
        iMap.put("TABLE",1 ,"DATA","BIYM025000000003PS000NA01AV�VASA EMEK.  VE Y.AM�.ESNEK             FON00110398430�NKILAP MAH. K���KSU CAD. AK�A KOCA SOK.NO: 8 34768         �MRAN�YE       34070520101700370000000125000000025000000000000010000000000000000000000000000000000000000000000000000000000000000000003125000000000000000000000000" ); 
        iMap.put("TABLE",2 ,"DATA","BIYM025000000003PS000NA01AV�VASA EMEK.  VE Y.AM�.ESNEK             FON00110398430�NKILAP MAH. K���KSU CAD. AK�A KOCA SOK.NO: 8 34768         �MRAN�YE       34070520101700370000000125000000025000000000000010000000000000000000000000000000000000000000000000000000000000000000003125000000000000000000000000" ); 
        
        com.graymound.service.GMServiceExecuter.execute("BNSPR_TRN1501_HALKA_ARZ_UYE_TALEP_KAYDET", iMap);
        return iMap;
    }
    
    @GraymoundService("BNSPR_TRN_1501_UYE_PARAMETERS")
    public static GMMap getCombo2(GMMap iMap) {

        GMMap oMap = new GMMap();
        String listName = "UYE";
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;

        try {
         
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetUyeler(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, projeKodu); 
            stmt.execute();
            int i = 0;
            GuimlUtil.wrapMyCombo(oMap, listName, "", "HEPSI");
            rSet = (ResultSet) stmt.getObject(1);
            while(rSet.next()){
                
                
                GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("HA_UYE"),  rSet.getString("ACIKLAMA"));
              
                
       
            }
            
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        

    }
    
   
}