package tr.com.calikbank.bnspr.treasury.services;

import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznTurevCollateralTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1581Services {
    
    
    @GraymoundService("BNSPR_TRN1581_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        
        Session session = DAOSession.getSession("BNSPRDal");
        
        HznTurevCollateralTx hznTurevCollateralTx = (HznTurevCollateralTx) session.createCriteria(HznTurevCollateralTx.class)
                .add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        
        if (hznTurevCollateralTx == null) {
            hznTurevCollateralTx = new HznTurevCollateralTx();
        }
        try{
            hznTurevCollateralTx.setAciklama(   iMap.getString("ACIKLAMA").startsWith("/BNF/")? iMap.getString("ACIKLAMA"): format72( iMap.getString("ACIKLAMA")) );          
            hznTurevCollateralTx.setBankaMustNo(iMap.getBigDecimal("BANKA_MUST_NO"));            
            hznTurevCollateralTx.setDoviz(iMap.getString("DOVIZ"));
            hznTurevCollateralTx.setCollateralHesapNo(iMap.getBigDecimal("COLLATERAL_HESAP_NO"));
            hznTurevCollateralTx.setIslemTarihi(iMap.getDate("ISLEM_TARIHI"));
            if(iMap.getString("ISLEM_TURU_ALINAN").equals("true")){
                hznTurevCollateralTx.setIslemTuru("A");
                hznTurevCollateralTx.setAlisHesapno(iMap.getBigDecimal("ALIS_HESAPNO"));
                hznTurevCollateralTx.setAlisMuhabirMusteriNo(iMap.getString("ALIS_MUHABIR_MUSTERI_NO"));
                hznTurevCollateralTx.setAlisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
            }
            else{
                hznTurevCollateralTx.setIslemTuru("V");  
                hznTurevCollateralTx.setCikisHesapno(iMap.getBigDecimal("CIKIS_HESAPNO"));
                hznTurevCollateralTx.setCikisMuhabirMusteriNo(iMap.getString("CIKIS_MUHABIR_MUSTERI_NO"));
                hznTurevCollateralTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
                hznTurevCollateralTx.setAlisHesapno(iMap.getBigDecimal("MUS_HESAP_NO"));
                hznTurevCollateralTx.setAlisMuhabirMusteriNo(iMap.getString("MUSTERIMUHABIRNO"));
                hznTurevCollateralTx.setAlisHesapTuru(iMap.getString("MUSTERI_HESAP_TURU"));
            }
            hznTurevCollateralTx.setRefNo(iMap.getString("REF_NO"));
            hznTurevCollateralTx.setTutar(iMap.getBigDecimal("TUTAR"));
            hznTurevCollateralTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            hznTurevCollateralTx.setValorTarihi(iMap.getDate("ISLEM_TARIHI"));
            hznTurevCollateralTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
        
        }catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
        
        session.saveOrUpdate(hznTurevCollateralTx);
        
        session.flush();
        
        iMap.put("TRX_NAME","1581");
        return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
    } 
    public static String format72(String aciklama){
        StringBuffer sb = new StringBuffer();
        if(aciklama != null){
            sb.append("/BNF/");
            if(aciklama.length() <= 30 ){
                sb.append(aciklama);
                return sb.toString();
            }
            String tmp = aciklama.substring(0,30);
            if(tmp.lastIndexOf(" ")>0)
                tmp = tmp.substring(0,tmp.lastIndexOf(" "));
            sb.append(tmp+(char)10);
            aciklama = aciklama.substring(tmp.length());
            while ( aciklama.length() > 32){
                boolean bosluk = false;
                   tmp = aciklama.substring(0,32);
                   if(tmp.lastIndexOf(" ")>0){
                       tmp = tmp.substring(0,tmp.lastIndexOf(" "));
                       bosluk = true;}
                   
                   sb.append("//"+tmp+(char)10);
                   aciklama = aciklama.substring( bosluk?tmp.length()+1: tmp.length());
  
            }
            if (aciklama.length() > 0 )
                sb.append("//"+aciklama);
            
        }
        return sb.toString();
    }
    
    
    @GraymoundService("BNSPR_TRN1581_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        HznTurevCollateralTx hznTurevCollateralTx = (HznTurevCollateralTx) session.createCriteria(HznTurevCollateralTx.class).add(
                Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        
        try {
            
            if("A".equals(hznTurevCollateralTx.getIslemTuru())){
                
                oMap.put("CIKIS_HESAP_TURU" , hznTurevCollateralTx.getAlisHesapTuru());
                oMap.put("ALIS_HESAPNO" , hznTurevCollateralTx.getAlisHesapno());                
                oMap.put("ALIS_MUHABIR_MUSTERI_NO" , hznTurevCollateralTx.getAlisMuhabirMusteriNo());
                oMap.put("CIKIS_MUHABIR_UNVAN", LovHelper.diLov(hznTurevCollateralTx.getAlisMuhabirMusteriNo(),hznTurevCollateralTx.getDoviz(),"1581/LOV_MUHABIR_NO","UNVAN"));
            }
            else{
                
                oMap.put("CIKIS_HESAP_TURU" , hznTurevCollateralTx.getCikisHesapTuru());
                oMap.put("CIKIS_HESAPNO" , hznTurevCollateralTx.getCikisHesapno());                
                oMap.put("CIKIS_MUHABIR_MUSTERI_NO" , hznTurevCollateralTx.getCikisMuhabirMusteriNo());
                oMap.put("CIKIS_MUHABIR_UNVAN", LovHelper.diLov(hznTurevCollateralTx.getCikisMuhabirMusteriNo(),hznTurevCollateralTx.getDoviz(),"1581/LOV_MUHABIR_NO","UNVAN"));
                oMap.put("MUS_HESAP_NO" , hznTurevCollateralTx.getAlisHesapno());
                oMap.put("MUSTERI_HESAP_TURU" , hznTurevCollateralTx.getAlisHesapTuru());
                oMap.put("MUSTERIMUHABIRNO" , hznTurevCollateralTx.getAlisMuhabirMusteriNo());
                
            }
            oMap.put("ACIKLAMA" , hznTurevCollateralTx.getAciklama());
            oMap.put("BANKA_MUST_NO" , hznTurevCollateralTx.getBankaMustNo());
            oMap.put("UNVAN" , DALUtil.callOneParameterFunction("{? = call pkg_musteri.unvan(?)}", Types.VARCHAR, oMap.getBigDecimal("BANKA_MUST_NO")));
            oMap.put("DOVIZ" , hznTurevCollateralTx.getDoviz());
            oMap.put("COLLATERAL_HESAP_NO" , hznTurevCollateralTx.getCollateralHesapNo());
            oMap.put("ISLEM_TARIHI" , hznTurevCollateralTx.getIslemTarihi());
            oMap.put("ISLEM_TURU" , hznTurevCollateralTx.getIslemTuru());
            oMap.put("REF_NO" , hznTurevCollateralTx.getRefNo());
            oMap.put("TUTAR" , hznTurevCollateralTx.getTutar());
            oMap.put("TRX_NO" , hznTurevCollateralTx.getTxNo());
            
            oMap.put("ISTATISTIK_KODU" , hznTurevCollateralTx.getIstatistikKodu());
            oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznTurevCollateralTx.getIstatistikKodu(),"3330/LOV_ISTATISTIK","ACIKLAMA"));
            
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1581_INITIALIZE")
    public static GMMap initiazlize(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        try {
              
            String func = "{? = call PKG_TRN1581.ReferansAl()}";
            Object[] inputValues = new Object[]{};

            String referans =  (String) DALUtil.callOracleFunction(func , BnsprType.STRING , inputValues);
            
            oMap.put("REFERANS" , referans);
            
            oMap.put("ISLEM_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIHI", iMap).getDate("BANKA_TARIH"));
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
    
}