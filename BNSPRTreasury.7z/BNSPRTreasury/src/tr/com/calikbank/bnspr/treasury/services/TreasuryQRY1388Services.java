package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryQRY1388Services {
	@GraymoundService("BNSPR_QRY1388_GET_KUR_LIST")
	public static GMMap getKurlar(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call  PKG_RC1388.RC_QRY1388_GET_KUR_LIST(?,?,?,?)}");
			int i = 1;
			if(iMap.getDate("TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			stmt.registerOutParameter(i++, -10); //LIBOR
			stmt.registerOutParameter(i++, -10); //EURIBOR
			stmt.registerOutParameter(i++, -10); //DIGER
			stmt.execute();
            rSet = (ResultSet) stmt.getObject(2);
			String tableName1 = "LIBOR";
			for (int row = 0; rSet.next(); row++) {
				oMap.put(tableName1, row, "DOVIZ", rSet.getString(1));
				oMap.put(tableName1, row, "PERIYOD", rSet.getString(2));
				oMap.put(tableName1, row, "RATE", rSet.getString(3));
			}
			rSet = (ResultSet) stmt.getObject(3);
			String tableName2 = "EURIBOR";
				for (int row = 0; rSet.next(); row++) {
				oMap.put(tableName2, row, "DOVIZ", rSet.getString(1));
				oMap.put(tableName2, row, "PERIYOD", rSet.getString(2));
				oMap.put(tableName2, row, "RATE", rSet.getString(3));
				}
			rSet = (ResultSet) stmt.getObject(4);
			String tableName3 = "DIGER";
				for (int row = 0; rSet.next(); row++) {
				oMap.put(tableName3, row, "DOVIZ", rSet.getString(1));
				oMap.put(tableName3, row, "PERIYOD", rSet.getString(2));
				oMap.put(tableName3, row, "RATE", rSet.getString(3));
				}
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		}catch (ParseException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
