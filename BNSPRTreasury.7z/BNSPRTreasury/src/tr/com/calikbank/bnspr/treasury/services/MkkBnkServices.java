package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.MkkResponse;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkBnkServices {
    private static final Logger logger = Logger.getLogger(MkkKtBatchService.class);
    
    @GraymoundService("BNSPR_CHANGE_QUALIFICATIION_RESULT_RESPONSE")
    public static GMMap getMkkChangeOfQualifStat(GMMap iMap) {
        logger.info("BNSPR_CHANGE_QUALIFICATIION_RESULT_RESPONSE service is starting...");

        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            BigDecimal respId = saveMkkResponse(iMap);
            logger.info("Saved MKK Response to MKK_RESPONSE, ID:" + respId);
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_MKK.ChangeQualifStat(?,?)}");
            
            stmt.setBigDecimal(1 , iMap.getBigDecimal("RegistryNo")); 
            stmt.setString(2 , iMap.getString("QualificationStat")); 
            
            stmt.execute();
            logger.info("Updated customer qualification stat-" + iMap.getBigDecimal("RegistryNo") + ":" + iMap.getString("QualificationStat"));

            oMap.put("RESPONSE_CODE" , "0000");
            oMap.put("RESPONSE_DESC" , "");
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
     
        return oMap;        
    }
    public static BigDecimal saveMkkResponse(GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        BigDecimal newId = newId("MKK_RESPONSE"); 
        try{
            mkkPojo.setId(newId);
            mkkPojo.setReceiverMember(iMap.getString("ReceiverMember"));
            mkkPojo.setSenderReference(iMap.getString("SenderReference"));
            mkkPojo.setTid(iMap.getString("Tid"));
            mkkPojo.setMessageId(iMap.getString("MessageId"));
            mkkPojo.setMkkSenderReference(iMap.getString("MkkSenderReference"));
            mkkPojo.setResponseCode(iMap.getString("ResponseCode"));
            mkkPojo.setResponseDesc(iMap.getString("ResponseDesc"));
            mkkPojo.setRegistryNo(iMap.getString("RegistryNo"));
            mkkPojo.setQualificationStat(iMap.getString("QualificationStat"));
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ iMap.getString("ReceiverMember"));
            logger.info("responseHeader.senderReference => "+ iMap.getString("SenderReference"));
            logger.info("responseHeader.tid => "+ iMap.getString("Tid"));
            logger.info("responseHeader.messageId => "+ iMap.getString("MessageId"));
            logger.info("responseHeader.mkkSenderReference => "+ iMap.getString("MkkSenderReference"));
            logger.info("response.responseCode => "+ iMap.getString("ResponseCode"));
            logger.info("response.responseDesc => "+ iMap.getString("ResponseDesc"));
            logger.info("response.registryNo => "+ iMap.getString("RegistryNo"));
            logger.info("response.qualificationStat => "+ iMap.getString("QualificationStat"));
            logger.info("..............End Of MKK Response..............");
        }
        
        return newId;
    }

    private static BigDecimal newId(String key){
        GMMap map = new GMMap();
        map.put("TABLE_NAME" , key);
        return (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", map).get("ID");        
    }
}
