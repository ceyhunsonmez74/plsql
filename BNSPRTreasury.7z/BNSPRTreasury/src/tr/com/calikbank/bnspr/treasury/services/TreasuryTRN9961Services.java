package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SpkRiskUrun;
import tr.com.aktifbank.bnspr.dao.SpkRiskUrunTx;
import tr.com.aktifbank.bnspr.dao.SpkRiskUrunTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN9961Services {
	
	@GraymoundService("BNSPR_TRN9961_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			String oldTableName = "OLD_LIST";
			int row = 0, oldRow = 0;
			
			if (iMap.getBoolean("IS_VIEW")) {//ekran view amacli acildiysa tx uzerinden gelsin
				
				/*
				 * tx-e gore mevcut-liste cekilir
				 */
				List<?> list = session.createCriteria(SpkRiskUrunTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SpkRiskUrunTx spkRiskUrun = (SpkRiskUrunTx) iterator.next();
					
					oMap.put(tableName, row, "URUN_KODU", spkRiskUrun.getId().getUrunKodu());
					oMap.put(tableName, row, "URUN_ADI", spkRiskUrun.getUrunAdi());
					oMap.put(tableName, row, "ISLEM_KODLARI", spkRiskUrun.getIslemKodlari());
					
					row++;
				}
				
				/*
				 * Eski tx-no bulunur
				 */
				BigDecimal oldTrxNo = getOncekiTxNo(trxNo);
				
				/*
				 * tx-e gore eski liste cekilir
				 */
				List<?> oldList = session.createCriteria(SpkRiskUrunTx.class).add(Restrictions.eq("id.txNo", oldTrxNo)).list();
				
				for (Iterator<?> iterator = oldList.iterator(); iterator.hasNext();) {
					SpkRiskUrunTx spkRiskUrun = (SpkRiskUrunTx) iterator.next();
					
					oMap.put(oldTableName, oldRow, "URUN_KODU", spkRiskUrun.getId().getUrunKodu());
					oMap.put(oldTableName, oldRow, "URUN_ADI", spkRiskUrun.getUrunAdi());
					oMap.put(oldTableName, oldRow, "ISLEM_KODLARI", spkRiskUrun.getIslemKodlari());
					
					oldRow++;
				}
				
				/*
				 * eski ve yeni listeler karsilatirilir, renklendirme icin
				 */
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("URUN_KODU");
				keyColumns.add("URUN_ADI");
				keyColumns.add("ISLEM_KODLARI");
				
				oMap.put("COLOR_LIST", BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(oldTableName), (ArrayList<?>) oMap.get(tableName), keyColumns).get("COLOR_DATA"));
				
			} else {//yoksa ana tablo uzerinden gelsin
				
				List<?> list = session.createCriteria(SpkRiskUrun.class).list();
				
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					SpkRiskUrun spkRiskUrun = (SpkRiskUrun) iterator.next();
					
					oMap.put(tableName, row, "URUN_KODU", spkRiskUrun.getUrunKodu());
					oMap.put(tableName, row, "URUN_ADI", spkRiskUrun.getUrunAdi());
					oMap.put(tableName, row, "ISLEM_KODLARI", spkRiskUrun.getIslemKodlari());
					
					row++;
				}
				
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9961_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			String tableName = "LIST";
			
			/*
			 * mevcutlar tx-e gore silinir
			 */
			session.createQuery("delete SpkRiskUrunTx where id.txNo = :txNo").setBigDecimal("txNo", trxNo).executeUpdate();
			session.flush();
			
			/*
			 * tablo insert edilir
			 */
			
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				SpkRiskUrunTx spkRiskUrun = new SpkRiskUrunTx();
				
				//
				SpkRiskUrunTxId id = new SpkRiskUrunTxId();
				id.setTxNo(trxNo);
				id.setUrunKodu(iMap.getString(tableName, row, "URUN_KODU"));
				//
				
				spkRiskUrun.setId(id);
				spkRiskUrun.setUrunAdi(iMap.getString(tableName, row, "URUN_ADI"));
				spkRiskUrun.setIslemKodlari(iMap.getString(tableName, row, "ISLEM_KODLARI"));
				
				session.saveOrUpdate(spkRiskUrun);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "9961");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static BigDecimal getOncekiTxNo(BigDecimal trxNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_9961(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, trxNo);
			stmt.execute();
			
			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN9961_POPUP_DATA")
	public static GMMap organizePopupData(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			String flag = iMap.getString("FLAG");
			
			if ("S".equals(flag)) {//string -> model data
				
				int row = 0;
				
				if (StringUtils.isNotEmpty(iMap.getString("STR")))
					for (String islemKodu : iMap.getString("STR").split(",")) {
						oMap.put("DATA", row, "ISLEM_KODU", islemKodu);
						oMap.put("DATA", row++, "ISLEM_ACIKLAMA", LovHelper.diLov(islemKodu, "9961/LOV_ISLEM_KODU", "ACIKLAMA"));
					}
				
			} else {//model data -> string
				
				StringBuffer sb = new StringBuffer();
				
				for (int row = 0; row < iMap.getSize("DATA"); row++)
					if (StringUtils.isNotEmpty(iMap.getString("DATA", row, "ISLEM_KODU")))
						sb.append(iMap.getString("DATA", row, "ISLEM_KODU"))
						  .append(",");
				
				if (sb.length() > 0)
					sb.deleteCharAt(sb.length() - 1);//son (",") virgulu sil
				
				oMap.put("STR", sb.toString());
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
