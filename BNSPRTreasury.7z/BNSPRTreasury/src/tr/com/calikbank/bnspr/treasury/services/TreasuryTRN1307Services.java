package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1307Services {

	@GraymoundService("BNSPR_TRN1307_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn1307.SPFW_BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1307_GET_TRANSFER_DATA")
	public static GMMap getTransferData(GMMap iMap){

		try {
			GMMap oMap = new GMMap();
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			oMap.put("TX_NO", hznSpotfwdTx.getId().getTxNo());
			oMap.put("REF_NO", hznSpotfwdTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSpotfwdTx.getUrunTurKod(), "1307/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznSpotfwdTx.getAlisTutari());
			oMap.put("ALIS_HESAP_TURU", hznSpotfwdTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznSpotfwdTx.getSatisTutari());
			oMap.put("SATIS_HESAP_TURU", hznSpotfwdTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznSpotfwdTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznSpotfwdTx.getSatisKur());
			oMap.put("PARITE", hznSpotfwdTx.getParite());
			oMap.put("ACIKLAMA", hznSpotfwdTx.getAciklama());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSpotfwdTx.getDealerNo(), "1307/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSpotfwdTx.getBankaMusteriNo(), "1307/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getAlisHesapNo(),hznSpotfwdTx.getAlisDovizKodu(), hznSpotfwdTx.getAlisHesapTuru(),
					hznSpotfwdTx.getAlisDovizKodu(), hznSpotfwdTx.getAlisHesapTuru(), hznSpotfwdTx.getBankaMusteriNo(), 
					"1307/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getSatisHesapNo(),hznSpotfwdTx.getSatisDovizKodu(), hznSpotfwdTx.getSatisHesapTuru(),
					hznSpotfwdTx.getSatisDovizKodu(),hznSpotfwdTx.getSatisHesapTuru(),hznSpotfwdTx.getBankaMusteriNo(), 
					"1307/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("AS", hznSpotfwdTx.getAS());
			oMap.put("ALIS_MUHABIR_MUSTERI_NO", hznSpotfwdTx.getAlisMuhabirMusteriNo());
			oMap.put("SATIS_MUHABIR_MUSTERI_NO", hznSpotfwdTx.getSatisMuhabirMusteriNo());
			
			oMap.put("ONS_ISLEM", hznSpotfwdTx.getOnsIslem());
			
			if (hznSpotfwdTx.getOnsIslem() != null && hznSpotfwdTx.getOnsIslem().equals("E")){			
				if(hznSpotfwdTx.getAlisDovizKodu().equalsIgnoreCase("TRY")){
					oMap.put("SATIS_TUTARI", hznSpotfwdTx.getXauSatisOnsMiktar());
					oMap.put("SATIS_KUR", hznSpotfwdTx.getOnsSatisKur());

				}else if(hznSpotfwdTx.getSatisDovizKodu().equalsIgnoreCase("TRY")){
					oMap.put("ALIS_TUTARI", hznSpotfwdTx.getXauAlisOnsMiktar());
					oMap.put("ALIS_KUR", hznSpotfwdTx.getOnsAlisKur());

				}else{
					oMap.put("PARITE", hznSpotfwdTx.getOnsParite());
					if("XAU;XAG".contains(hznSpotfwdTx.getAlisDovizKodu())){
						oMap.put("ALIS_TUTARI", hznSpotfwdTx.getXauAlisOnsMiktar());
					}else{
						oMap.put("SATIS_TUTARI", hznSpotfwdTx.getXauSatisOnsMiktar());
					}					
				}		
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1307_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
	
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			HznSpotfwdTxId id = null;
			
			if(hznSpotfwdTx == null) {
				hznSpotfwdTx = new HznSpotfwdTx();
				id = new HznSpotfwdTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setReferans(iMap.getString("TRX_NO"));
			} else {
				id = hznSpotfwdTx.getId();
			}

			hznSpotfwdTx.setId(id);
			hznSpotfwdTx.setModulTurKod("HAZINE");
			hznSpotfwdTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSpotfwdTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSpotfwdTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
						
			//Ekrandan ons islem girildi�inde grama �evrilsin 
            if(iMap.getString("ONS_ISLEM") != null && iMap.getString("ONS_ISLEM").equalsIgnoreCase("true")){
            	hznSpotfwdTx.setOnsIslem("E");
            	onsHesaplama(iMap,hznSpotfwdTx);
            //NKolay ya da STP islemi ise           
            }else if(hznSpotfwdTx.getOrderId() != null && hznSpotfwdTx.getPlatformNo() !=null){
            	hznSpotfwdTx.setOnsIslem("H");
        		iMap.put("XAU_ALIS_ONS_MU", false);
				iMap.put("XAU_SATIS_ONS_MU", false);	
            }else{
            //default H
            	hznSpotfwdTx.setOnsIslem("H");
            }
						
			hznSpotfwdTx.setAlisTutari(iMap.getBigDecimal("ALIS_TUTARI"));
			hznSpotfwdTx.setAlisHesapTuru(iMap.getString("ALIS_HESAP_TURU"));
			hznSpotfwdTx.setAlisHesapNo(iMap.getBigDecimal("ALIS_HESAP_NO"));
			hznSpotfwdTx.setSatisTutari(iMap.getBigDecimal("SATIS_TUTARI"));
			hznSpotfwdTx.setSatisHesapTuru(iMap.getString("SATIS_HESAP_TURU"));
			hznSpotfwdTx.setSatisHesapNo(iMap.getBigDecimal("SATIS_HESAP_NO"));
			hznSpotfwdTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznSpotfwdTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSpotfwdTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSpotfwdTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSpotfwdTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSpotfwdTx.setAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			hznSpotfwdTx.setSatisKur(iMap.getBigDecimal("SATIS_KUR"));
			hznSpotfwdTx.setParite(iMap.getBigDecimal("PARITE"));
			hznSpotfwdTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			hznSpotfwdTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			hznSpotfwdTx.setAS(iMap.getString("AS"));
			
			if (iMap.getString("XAU_ALIS_ONS_MU") != null && iMap.getString("XAU_ALIS_ONS_MU").equalsIgnoreCase("false")) {
				hznSpotfwdTx.setXauAlisOnsMu("H");
			}else {
				hznSpotfwdTx.setXauAlisOnsMu("E");
				hznSpotfwdTx.setXauAlisOnsMiktar(iMap.getBigDecimal("XAU_ALIS_ONS_MIKTAR"));
			}

			if (iMap.getString("XAU_SATIS_ONS_MU") != null && iMap.getString("XAU_SATIS_ONS_MU").equalsIgnoreCase("false")) {
				hznSpotfwdTx.setXauSatisOnsMu("H");
			}else {
				hznSpotfwdTx.setXauSatisOnsMu("E");
				hznSpotfwdTx.setXauSatisOnsMiktar(iMap.getBigDecimal("XAU_SATIS_ONS_MIKTAR"));
			}
			
			hznSpotfwdTx.setAlisMuhabirMusteriNo((iMap.getString("ALIS_MUHABIR_MUSTERI_NO")));
			hznSpotfwdTx.setSatisMuhabirMusteriNo((iMap.getString("SATIS_MUHABIR_MUSTERI_NO")));
			
			hznSpotfwdTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
			hznSpotfwdTx.setOrderId(iMap.getString("ORDER_ID"));
			hznSpotfwdTx.setMessageId(iMap.getString("MESSAGE_ID"));
			hznSpotfwdTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
			
			session.saveOrUpdate(hznSpotfwdTx);
			session.flush();
		
			
			GMMap oMap = new GMMap();
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	private static void onsHesaplama(GMMap iMap, HznSpotfwdTx hznSpotfwdTx) {
		
		if ("XAU;XAG".contains(iMap.getString("ALIS_DOVIZ_KODU")) && iMap.getString("SATIS_DOVIZ_KODU").equalsIgnoreCase("TRY")){			
			
			iMap.put("XAU_ALIS_ONS_MIKTAR", iMap.getBigDecimal("ALIS_TUTARI"));
			hznSpotfwdTx.setOnsAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			
			BigDecimal grFiyat = iMap.getBigDecimal("ALIS_KUR").divide(new BigDecimal("31.1035"), 8, RoundingMode.HALF_UP);
			iMap.put("ALIS_KUR", grFiyat);
			
			iMap.put("ALIS_TUTARI", iMap.getBigDecimal("SATIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));
			iMap.put("XAU_ALIS_ONS_MU", true);
			iMap.put("XAU_SATIS_ONS_MU", false);		
			
		}else if("XAU;XAG".contains(iMap.getString("SATIS_DOVIZ_KODU")) && iMap.getString("ALIS_DOVIZ_KODU").equalsIgnoreCase("TRY")){			
			
			iMap.put("XAU_SATIS_ONS_MIKTAR", iMap.getBigDecimal("SATIS_TUTARI"));
			hznSpotfwdTx.setOnsSatisKur(iMap.getBigDecimal("SATIS_KUR"));
		
			BigDecimal grFiyat = iMap.getBigDecimal("SATIS_KUR").divide(new BigDecimal("31.1035"), 8, RoundingMode.HALF_UP);
			iMap.put("SATIS_KUR", grFiyat);
					
			iMap.put("SATIS_TUTARI", iMap.getBigDecimal("ALIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));					
			iMap.put("XAU_ALIS_ONS_MU", false);
			iMap.put("XAU_SATIS_ONS_MU", true);
			
		}else{		
			
			BigDecimal grFiyat = iMap.getBigDecimal("PARITE").divide(new BigDecimal("31.1035"), 8, RoundingMode.HALF_UP);
			iMap.put("PARITE", grFiyat);				
			hznSpotfwdTx.setOnsParite(iMap.getBigDecimal("ALIS_KUR"));

			if ("XAU;XAG".contains(iMap.getString("ALIS_DOVIZ_KODU"))){		
				iMap.put("XAU_ALIS_ONS_MU", true);
				iMap.put("XAU_SATIS_ONS_MU", false);
				iMap.put("XAU_ALIS_ONS_MIKTAR", iMap.getBigDecimal("ALIS_TUTARI"));
				iMap.put("ALIS_TUTARI", iMap.getBigDecimal("SATIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));
				
			}else{				
				iMap.put("XAU_ALIS_ONS_MU", false);
				iMap.put("XAU_SATIS_ONS_MU", true);
				iMap.put("XAU_SATIS_ONS_MIKTAR", iMap.getBigDecimal("SATIS_TUTARI"));
				iMap.put("SATIS_TUTARI", iMap.getBigDecimal("ALIS_TUTARI").divide(grFiyat, 2, RoundingMode.HALF_UP));
			}
	
		}	
		
	}	
	
	@GraymoundService("BNSPR_TRN1307_TRANSACTION_START")
	public static Map<?, ?> trn1306Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1307");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	
	@GraymoundService("BNSPR_TRN1307_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmtNetting = null;
        String isNetting = "H";
		
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			
			stmtNetting = conn.prepareCall("{call PKG_TRN1306.Netting_Swift_Kontrolu(?,?,?,?,?) }");
			
			stmtNetting.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			stmtNetting.setString(2, iMap.getString("URUN_TUR_KOD"));
			stmtNetting.setString(3, iMap.getString("SATIS_DOVIZ_KODU"));
			stmtNetting.setString(4, iMap.getString("SATIS_HESAP_TURU"));

			stmtNetting.registerOutParameter(5, Types.VARCHAR);

			stmtNetting.execute();
			isNetting = stmtNetting.getString(5);			
			
			if(isNetting.equals("H")){
				stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?)}");
			    
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.execute();
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN1307_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();
			
			oMap.put("TX_NO", hznSpotfwdTx.getId().getTxNo());
			oMap.put("REF_NO", hznSpotfwdTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSpotfwdTx.getUrunTurKod(), "1307/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznSpotfwdTx.getAlisTutari());
			oMap.put("ALIS_HESAP_TURU", hznSpotfwdTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznSpotfwdTx.getSatisTutari());
			oMap.put("SATIS_HESAP_TURU", hznSpotfwdTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznSpotfwdTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznSpotfwdTx.getSatisKur());
			oMap.put("PARITE", hznSpotfwdTx.getParite());
			oMap.put("ACIKLAMA", hznSpotfwdTx.getAciklama());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSpotfwdTx.getDealerNo(), "1307/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSpotfwdTx.getBankaMusteriNo(), "1307/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getAlisHesapNo(),hznSpotfwdTx.getAlisDovizKodu(), hznSpotfwdTx.getAlisHesapTuru(),
					hznSpotfwdTx.getAlisDovizKodu(), hznSpotfwdTx.getAlisHesapTuru(), hznSpotfwdTx.getBankaMusteriNo(), 
					"1307/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getSatisHesapNo(),hznSpotfwdTx.getSatisDovizKodu(), hznSpotfwdTx.getSatisHesapTuru(),
					hznSpotfwdTx.getSatisDovizKodu(),hznSpotfwdTx.getSatisHesapTuru(),hznSpotfwdTx.getBankaMusteriNo(), 
					"1307/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("AS", hznSpotfwdTx.getAS());
			
			
			oMap.put("ALIS_MUHABIR_MUSTERI_NO", hznSpotfwdTx.getAlisMuhabirMusteriNo());
			oMap.put("SATIS_MUHABIR_MUSTERI_NO", hznSpotfwdTx.getSatisMuhabirMusteriNo());
			oMap.put("MT300_AKTIFID", hznSpotfwdTx.getMt300Aktifid());
			
		oMap.put("ONS_ISLEM", hznSpotfwdTx.getOnsIslem());
			
			if (hznSpotfwdTx.getOnsIslem() != null && hznSpotfwdTx.getOnsIslem().equals("E")){			
				if(hznSpotfwdTx.getAlisDovizKodu().equalsIgnoreCase("TRY")){
					oMap.put("SATIS_TUTARI", hznSpotfwdTx.getXauSatisOnsMiktar());
					oMap.put("SATIS_KUR", hznSpotfwdTx.getOnsSatisKur());

				}else if(hznSpotfwdTx.getSatisDovizKodu().equalsIgnoreCase("TRY")){
					oMap.put("ALIS_TUTARI", hznSpotfwdTx.getXauAlisOnsMiktar());
					oMap.put("ALIS_KUR", hznSpotfwdTx.getOnsAlisKur());

				}else{
					oMap.put("PARITE", hznSpotfwdTx.getOnsParite());
					if("XAU;XAG".contains(hznSpotfwdTx.getAlisDovizKodu())){
						oMap.put("ALIS_TUTARI", hznSpotfwdTx.getXauAlisOnsMiktar());
					}else{
						oMap.put("SATIS_TUTARI", hznSpotfwdTx.getXauSatisOnsMiktar());
					}					
				}		
			}
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1307_ALISSATIS_TUTARI_HESAPLA")
	public static GMMap alisSatisTutariHesapla(GMMap iMap) {
		Connection conn 		= null;
		CallableStatement stmt  = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_TRN1306.alissatis_tutari_hesapla(?,?,?,?,?,?,?) }");
			int i =1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("ALIS_DOVIZ_KOD"));
			if(iMap.getBigDecimal("ALIS_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_KUR"));
			stmt.setString(i++, iMap.getString("SATIS_DOVIZ_KOD"));
			if(iMap.getBigDecimal("SATIS_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_KUR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("PARITE"));
			
			stmt.execute();
			oMap.put("TUTAR", stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
