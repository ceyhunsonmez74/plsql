package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY1360Services {
	
	@GraymoundService("BNSPR_QRY1360_RC_QRY_GET_TAHSILAT_DOSYA")
	public static GMMap getTahsilatDosya(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
	        
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_RC1360.Rc_Qry_Get_Tahsilat_Dosya_Adet(?,?,?) }");
			int i = 1;
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i++, null);
			
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.registerOutParameter(i++, Types.DECIMAL);
			
			
			stmt.execute();
			
			oMap.put("AKTIFBANK_TAHSIL_TOPLAM", stmt.getBigDecimal(2));
			oMap.put("AKTIFBANK_TAHSIL_ADET", stmt.getBigDecimal(3));
			oMap.put("PTT_TAHSIL_TOPLAM", stmt.getBigDecimal(2));
			oMap.put("PTT_TAHSIL_ADET", stmt.getBigDecimal(3));

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY1360_RC_QRY_GET_2ST_LEVEL_TAHSILAT_DOSYA", iMap).get("CBS_AKTIFBANK"));
			
		
		return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1360_RC_QRY_GET_2ST_LEVEL_TAHSILAT_DOSYA")
	public static GMMap getSecondLevelTahsilDosya(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc1360.Rc_Qry_Get_Tahsilat_Dosya(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
