package tr.com.calikbank.bnspr.treasury.services;

import java.awt.Color;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznMusteriTx;
import tr.com.aktifbank.bnspr.dao.MkkHesaplar;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirme;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirmeSonuc;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1337Services {
	
	private static Color CHANGED_BACKGROUND_COLOR_WHITE = new Color(255,255,255);
	private static Color CHANGED_BACKGROUND_COLOR_EMPHASISE = new Color(153,255,0);
	private static Color CHANGED_BACKGROUND_COLOR_COMBO = new Color(238,238,238);

	@GraymoundService("BNSPR_TRN1337_RENKLENDIRME")
	public static GMMap Renklendir(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;

		try {
			GMMap innerOutMap = GMServiceExecuter.call("BNSPR_TRN1337_MUSTERI_INFO_SEARCH", iMap);
           
			oMap.put("COLOR_MUSTERI_TIPI", CHANGED_BACKGROUND_COLOR_COMBO);
			oMap.put("COLOR_F_NITELIKLI", CHANGED_BACKGROUND_COLOR_COMBO);
			oMap.put("COLOR_YATIRIM_EXTRESI_GONDERILSINMI", CHANGED_BACKGROUND_COLOR_COMBO);
			oMap.put("COLOR_SKOR", CHANGED_BACKGROUND_COLOR_WHITE);

    		if(!(iMap.getString("MUSTERI_LIST" , i , "MUSTERI_TIPI").equals(innerOutMap.getString("MUSTERI_INFO_LIST" , i , "MUSTERI_TIPI")))){
    			oMap.put("COLOR_MUSTERI_TIPI", CHANGED_BACKGROUND_COLOR_EMPHASISE);
    		}
    		if(!(iMap.getString("MUSTERI_LIST" , i , "F_NITELIKLI").equals(innerOutMap.getString("MUSTERI_INFO_LIST" , i , "F_NITELIKLI")))){
    			oMap.put("COLOR_F_NITELIKLI", CHANGED_BACKGROUND_COLOR_EMPHASISE);
    		}
    		if(!(iMap.getString("MUSTERI_LIST" , i , "YATIRIM_EXTRESI_GONDERILSINMI").equals(innerOutMap.getString("MUSTERI_INFO_LIST" , i , "YATIRIM_EXTRESI_GONDERILSINMI")))){
    			oMap.put("COLOR_YATIRIM_EXTRESI_GONDERILSINMI", CHANGED_BACKGROUND_COLOR_EMPHASISE);
    		}
        	if(!(iMap.getBigDecimal("MUSTERI_LIST" , i , "SKOR").equals(innerOutMap.getBigDecimal("MUSTERI_INFO_LIST" , i , "SKOR")))){
        		oMap.put("COLOR_SKOR", CHANGED_BACKGROUND_COLOR_EMPHASISE);
    		}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1337_SAVE")
	public static GMMap Save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			// HznMusteriTx hznMusteriTx = (HznMusteriTx) session.get(HznMusteriTx.class, iMap.getBigDecimal("TRX_NO"));
			HznMusteriTx hznMusteriTx = new HznMusteriTx();
			for (int i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
				hznMusteriTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				hznMusteriTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_LIST", i, "MUSTERI_NO"));
				hznMusteriTx.setMusteriTipi(iMap.getString("MUSTERI_LIST", i, "MUSTERI_TIPI"));
				hznMusteriTx.setDmusteriTipi(iMap.getString("MUSTERI_LIST", i, "DMUSTERI_TIPI"));
				hznMusteriTx.setFNitelikli(iMap.getString("MUSTERI_LIST", i, "F_NITELIKLI"));
				hznMusteriTx.setYatirimExtresiGonderilsinmi(iMap.getString("MUSTERI_LIST", i, "YATIRIM_EXTRESI_GONDERILSINMI"));
				hznMusteriTx.setDyatirimExtresiGonderilsinmi(iMap.getString("MUSTERI_LIST", i, "DYATIRIM_EXTRESI_GONDERILSINMI"));
				hznMusteriTx.setSkor(iMap.getBigDecimal("MUSTERI_LIST", i, "SKOR"));
				hznMusteriTx.setOnaysizIslemMi("H");
				session.saveOrUpdate(hznMusteriTx);
				MkkKimlikEslestirme kimlikEs = (MkkKimlikEslestirme) session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
				if (kimlikEs != null && kimlikEs.getRegisteryNumber()!=null) {
					GMMap tMap = new GMMap();
					tMap.put("REGISTERY_NUMBER",kimlikEs.getRegisteryNumber());
					tMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_LIST", i, "MUSTERI_NO"));
					tMap.put("KE_ID", kimlikEs.getSenderReference());
					tMap.put("PROCESS_TYPE", getProcessType(iMap.getString("NITELIK_COMBO")));
					GMServiceExecuter.call("BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE", tMap);
				}
			}

			session.flush();

			iMap.put("TRX_NAME", "1337");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static String getProcessType(String nitelik) {
		return nitelik != null && nitelik.equals("E") ? "E" : "S";
	}

	@GraymoundService("BNSPR_TRN1337_SAVE_ONAYSIZ")
	public static GMMap SaveOnays�z(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap innerOutMap = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);

			HznMusteriTx hznMusteriTx = new HznMusteriTx ();
            hznMusteriTx.setTxNo(innerOutMap.getBigDecimal("TRX_NO"));
            hznMusteriTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            hznMusteriTx.setMusteriTipi(iMap.getString("MUSTERI_TIPI"));
			hznMusteriTx.setDmusteriTipi(iMap.getString("DMUSTERI_TIPI"));
			hznMusteriTx.setFNitelikli(iMap.getString("NITELIKLI"));
            hznMusteriTx.setYatirimExtresiGonderilsinmi(iMap.getString("YATIRIM_EXTRESI_GONDERILSINMI"));
            hznMusteriTx.setDyatirimExtresiGonderilsinmi(iMap.getString("DYATIRIM_EXTRESI_GONDERILSINMI"));
            hznMusteriTx.setOnaysizIslemMi("E");
            session.saveOrUpdate(hznMusteriTx);
			
			if (iMap.getString("NITELIKLI") != null) {
				if (iMap.getString("NITELIKLI").equals("E") || iMap.getString("NITELIKLI").equals("H")) {
					MkkKimlikEslestirme kimlikEs = (MkkKimlikEslestirme) session.createCriteria(MkkKimlikEslestirme.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
					if (kimlikEs != null) {
						if (kimlikEs.getRegisteryNumber() != null) {
							GMMap tMap = new GMMap();
							tMap.put("REGISTERY_NUMBER", kimlikEs.getRegisteryNumber());
							tMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
							tMap.put("KE_ID", kimlikEs.getSenderReference());
							tMap.put("PROCESS_TYPE", getProcessType(iMap.getString("NITELIKLI")));
							GMServiceExecuter.call("BNSPR_MKK_NITELIKLI_YAT_TANIM_SERVICE", tMap);
						}
						else {
							oMap.put("HATA", "M��terinin MKK Sicil Numaras� eksiktir.");
						}
					}
					else {
						oMap.put("HATA", "M��terinin MKK Kimlik E�le�tirmesi yoktur.");
					}
				}else {
					oMap.put("HATA", "Nitelik bilgisi E:Evet, H:Hay�r olabilir.");
				}
			}
			
			session.flush();
			iMap.put("TRX_NAME", "1337");
			iMap.put("TRX_NO", innerOutMap.getBigDecimal("TRX_NO"));
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1337_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
        String dfNitelikli = "Hayır";
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			int row = 0;
			HznMusteriTx hznMusteriTx = (HznMusteriTx) session.load(HznMusteriTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.put("MUSTERI_LIST",row,"MUSTERI_NO", hznMusteriTx.getMusteriNo());
			oMap.put("MUSTERI_LIST",row,"MUSTERI_TIPI", hznMusteriTx.getMusteriTipi());
			oMap.put("MUSTERI_LIST",row,"DMUSTERI_TIPI", hznMusteriTx.getDmusteriTipi());
			oMap.put("MUSTERI_LIST",row,"F_NITELIKLI", hznMusteriTx.getFNitelikli());
			if(hznMusteriTx.getFNitelikli().equals("E")){
				dfNitelikli = "Evet";
			}
			oMap.put("MUSTERI_LIST",row,"DF_NITELIKLI", dfNitelikli);
			oMap.put("MUSTERI_LIST",row,"YATIRIM_EXTRESI_GONDERILSINMI", hznMusteriTx.getYatirimExtresiGonderilsinmi());
			oMap.put("MUSTERI_LIST",row,"DYATIRIM_EXTRESI_GONDERILSINMI", hznMusteriTx.getDyatirimExtresiGonderilsinmi());
			oMap.put("MUSTERI_LIST",row,"SKOR", hznMusteriTx.getSkor());
			oMap.put("MUSTERI_NO", hznMusteriTx.getMusteriNo());
			oMap.put("UNVAN", LovHelper.diLov(hznMusteriTx.getMusteriNo(), "1337/LOV_MUSTERI", "UNVAN"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1337_INITIALIZE_COMBO")
	public static GMMap initializeCombo(GMMap iMap) {

		GMMap oMap = new GMMap();

		GuimlUtil.wrapMyCombo(oMap, "F_NITELIKLI", null, " ");
		GuimlUtil.wrapMyCombo(oMap, "F_NITELIKLI", "E", "Evet");
		GuimlUtil.wrapMyCombo(oMap, "F_NITELIKLI", "H", "Hayir");

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1337_MUSTERI_INFO_SEARCH")
	public static GMMap musteriInfoSearch(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {

			String tableName = "MUSTERI_INFO_LIST";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1337.GetMusteriInfoList(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, i, "MUSTERI_TIPI", rSet.getString("MUSTERI_TIPI"));
				oMap.put(tableName, i, "DMUSTERI_TIPI", rSet.getString("DMUSTERI_TIPI"));
				oMap.put(tableName, i, "F_NITELIKLI", rSet.getString("F_NITELIKLI"));
				oMap.put(tableName, i, "DF_NITELIKLI", rSet.getString("DF_NITELIKLI"));
				oMap.put(tableName, i, "YATIRIM_EXTRESI_GONDERILSINMI", rSet.getString("YATIRIM_EXTRESI_GONDERILSINMI"));
				oMap.put(tableName, i, "DYATIRIM_EXTRESI_GONDERILSINMI", rSet.getString("DYATIRIM_EXTRESI_GONDERILSINMI"));
				oMap.put(tableName, i, "SKOR", rSet.getString("SKOR"));
				oMap.put("YATIRIM_EXTRESI_GONDERILSINMI", rSet.getString("YATIRIM_EXTRESI_GONDERILSINMI"));
				i++;
			}


			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("YATIRIMCI_BELGE_KONTROL")
	public static GMMap yatirimciBelgeKontrol(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			
			String funcDokumanKontrol = "{? = call BNSPR.PKG_MUSTERI_EK.musteri_dokuman_kontrol(?,?)}";
			Object[] inputDokumanKontrol = new Object[] { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.STRING, iMap.getString("DOKUMAN_ADI") };
			oMap.put("DOKUMAN_KONTROL_RESULT", DALUtil.callOracleFunction(funcDokumanKontrol, BnsprType.STRING, inputDokumanKontrol));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
