package tr.com.calikbank.bnspr.treasury.services;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSwapSmTx;
import tr.com.calikbank.bnspr.dao.HznSwapSmTxId;
import tr.com.calikbank.bnspr.dao.HznSwapTx;
import tr.com.calikbank.bnspr.dao.HznSwapTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1319Services {
	
	@GraymoundService("BNSPR_TRN1319_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapTx hznSwapTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			HznSwapTxId id = null;
			
			if(hznSwapTx == null) {
				hznSwapTx = new HznSwapTx();
				id = new HznSwapTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setReferans(iMap.getString("TRX_NO"));
			} else {
				id = hznSwapTx.getId();
			}

			hznSwapTx.setId(id);
			hznSwapTx.setModulTurKod("HAZINE");
			hznSwapTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			hznSwapTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
			hznSwapTx.setKrediTeklifSatirNumara(iMap.getBigDecimal("KREDI_TEKLIF_SATIR_NUMARA"));
			hznSwapTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSwapTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSwapTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznSwapTx.setDealerNo((String)iMap.get("DEALER_NO"));
			hznSwapTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSwapTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznSwapTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSwapTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSwapTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSwapTx.setSpotAlisKur(iMap.getBigDecimal("SPOT_ALIS_KUR"));
			hznSwapTx.setSpotSatisKur(iMap.getBigDecimal("SPOT_SATIS_KUR"));
			hznSwapTx.setSpotParite(iMap.getBigDecimal("SPOT_PARITE"));
			hznSwapTx.setSpotCarpBolFlag(iMap.getString("SPOT_CARP_BOL_FLAG"));
			hznSwapTx.setSpotAlisTutari(iMap.getBigDecimal("SPOT_ALIS_TUTARI"));
			hznSwapTx.setSpotSatisTutari(iMap.getBigDecimal("SPOT_SATIS_TUTARI"));
			hznSwapTx.setSpotAlisHesapTuru(iMap.getString("SPOT_ALIS_HESAP_TURU"));
			hznSwapTx.setSpotAlisHesapNo(iMap.getBigDecimal("SPOT_ALIS_HESAP_NO"));
			hznSwapTx.setSpotSatisHesapTuru(iMap.getString("SPOT_SATIS_HESAP_TURU"));
			hznSwapTx.setSpotSatisHesapNo(iMap.getBigDecimal("SPOT_SATIS_HESAP_NO"));
			hznSwapTx.setForwardAlisKur(iMap.getBigDecimal("FORWARD_ALIS_KUR"));
			hznSwapTx.setForwardSatisKur(iMap.getBigDecimal("FORWARD_SATIS_KUR"));
			hznSwapTx.setForwardParite(iMap.getBigDecimal("FORWARD_PARITE"));
			hznSwapTx.setForwardCarpBolFlag(iMap.getString("FORWARD_CARP_BOL_FLAG"));
			hznSwapTx.setForwardAlisTutari(iMap.getBigDecimal("FORWARD_ALIS_TUTARI"));
			hznSwapTx.setForwardSatisTutari(iMap.getBigDecimal("FORWARD_SATIS_TUTARI"));
			hznSwapTx.setForwardAlisHesapTuru(iMap.getString("FORWARD_ALIS_HESAP_TURU"));
			hznSwapTx.setForwardAlisHesapNo(iMap.getBigDecimal("FORWARD_ALIS_HESAP_NO"));
			hznSwapTx.setForwardSatisHesapTuru(iMap.getString("FORWARD_SATIS_HESAP_TURU"));
			hznSwapTx.setForwardSatisHesapNo(iMap.getBigDecimal("FORWARD_SATIS_HESAP_NO"));
			hznSwapTx.setAciklama(iMap.getString("ACIKLAMA"));
//			hznSwapTx.setDurumKodu("A");
			hznSwapTx.setIslemSekli(iMap.getString("ISLEM_SEKLI"));
			
			if (StringUtils.isEmpty(iMap.getString("SM_EH"))) {
				throw new GMRuntimeException(330, "SM secilmesi zorunludur.");	
			}
			
			hznSwapTx.setSmEh(iMap.getString("SM_EH"));
			hznSwapTx.setSmText(iMap.getString("SM_TEXT"));
			
			
			/*
			 * Hzn Swap Sm - Save Begin -->
			 */
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			List<?> smDataList = (List<?>) iMap.get("SM_DATA");
			
			List<?> hznSwapSmTxList = session.createCriteria(HznSwapSmTx.class)
												.add(Restrictions.eq("id.txNo", txNo)).list();
			// eger liste varsa silinir
			if (hznSwapSmTxList != null) {
				for (int i = 0; i < hznSwapSmTxList.size(); i++) {
					HznSwapSmTx hznSwapSmTx = (HznSwapSmTx) hznSwapSmTxList.get(i);
					
					session.delete(hznSwapSmTx);
				}
				session.flush();
			}
			
			// sm secildiyse, yeni liste kaydedilir
			if ("E".equals(iMap.getString("SM_EH")) && smDataList != null) {
				for (int row = 0; row < smDataList.size(); row++) {
					String smReferans = iMap.getString("SM_DATA", row, "SM_REFERANS");
					String smTipi = iMap.getString("SM_DATA", row, "SM_TIPI");
					
					if (StringUtils.isEmpty(smReferans) || StringUtils.isEmpty(smTipi)) {
						throw new GMRuntimeException(330, "SM bilgilerinde referans ve tipi zorunludur.");
					}
					
					HznSwapSmTx hznSwapSmTx = new HznSwapSmTx(new HznSwapSmTxId(txNo, smReferans), smTipi);
					
					session.saveOrUpdate(hznSwapSmTx);
				}
			}
			/*
			 * <-- Hzn Swap Sm - Save End
			 */
			
			session.saveOrUpdate(hznSwapTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1319");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1319_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1309.SWAP_BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1319_GET_TRANSFER_DATA")
	public static GMMap getTransferData(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapTx hznSwapTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			oMap.put("TX_NO", hznSwapTx.getId().getTxNo());
			oMap.put("REF_NO", hznSwapTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSwapTx.getUrunTurKod(), "1318/LOV_URUN_TUR", "KOD"));
			oMap.put("KREDI_TEKLIF_SATIR_NUMARA", hznSwapTx.getKrediTeklifSatirNumara());
			oMap.put("SOZLESME_NO", hznSwapTx.getSozlesmeNo());
			oMap.put("URUN_SINIF_KOD", hznSwapTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSwapTx.getDealTarihi());
			oMap.put("DEALER_NO", hznSwapTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSwapTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSwapTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznSwapTx.getVadeTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSwapTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSwapTx.getSatisDovizKodu());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSwapTx.getDealerNo(), "1318/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSwapTx.getBankaMusteriNo(), "1318/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("SPOT_ALIS_TUTARI", hznSwapTx.getSpotAlisTutari());
			oMap.put("SPOT_ALIS_HESAP_TURU", hznSwapTx.getSpotAlisHesapTuru());
			oMap.put("SPOT_ALIS_HESAP_NO", hznSwapTx.getSpotAlisHesapNo());
			oMap.put("SPOT_SATIS_TUTARI", hznSwapTx.getSpotSatisTutari());
			oMap.put("SPOT_SATIS_HESAP_TURU", hznSwapTx.getSpotSatisHesapTuru());
			oMap.put("SPOT_SATIS_HESAP_NO", hznSwapTx.getSpotSatisHesapNo());
			oMap.put("SPOT_ALIS_KUR", hznSwapTx.getSpotAlisKur());
			oMap.put("SPOT_SATIS_KUR", hznSwapTx.getSpotSatisKur());
			oMap.put("SPOT_PARITE", hznSwapTx.getSpotParite());
			oMap.put("SPOT_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotAlisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getAlisDovizKodu(), "1318/LOV_SPOT_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("SPOT_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotSatisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getSatisDovizKodu(), "1318/LOV_SPOT_SATIS_HESAP", "KISA_ISIM"));
			
			oMap.put("FORWARD_ALIS_TUTARI", hznSwapTx.getForwardAlisTutari());
			oMap.put("FORWARD_ALIS_HESAP_TURU", hznSwapTx.getForwardAlisHesapTuru());
			oMap.put("FORWARD_ALIS_HESAP_NO", hznSwapTx.getForwardAlisHesapNo());
			oMap.put("FORWARD_SATIS_TUTARI", hznSwapTx.getForwardSatisTutari());
			oMap.put("FORWARD_SATIS_HESAP_TURU", hznSwapTx.getForwardSatisHesapTuru());
			oMap.put("FORWARD_SATIS_HESAP_NO", hznSwapTx.getForwardSatisHesapNo());
			oMap.put("FORWARD_ALIS_KUR", hznSwapTx.getForwardAlisKur());
			oMap.put("FORWARD_SATIS_KUR", hznSwapTx.getForwardSatisKur());
			oMap.put("FORWARD_PARITE", hznSwapTx.getForwardParite());
			oMap.put("FORWARD_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardAlisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getSatisDovizKodu(), "1318/LOV_FORWARD_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("FORWARD_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardSatisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getAlisDovizKodu(), "1318/LOV_FORWARD_SATIS_HESAP", "KISA_ISIM"));
			oMap.put("ISLEM_SEKLI", hznSwapTx.getIslemSekli());
			oMap.put("ACIKLAMA", hznSwapTx.getAciklama());
			oMap.put("DURUM_KODU", hznSwapTx.getDurumKodu());
			stmt = conn.prepareCall("{? = call PKG_TRN1309.SWAP_Valor_Gecmismi(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, hznSwapTx.getId().getReferans());
			stmt.execute();
			
			if(stmt.getString(1).equals("E"))
				oMap.put("VALOR_GECMISMI", "false");
			else
				oMap.put("VALOR_GECMISMI", "true");
			
			oMap.put("SM_EH", hznSwapTx.getSmEh());
			oMap.put("SM_TEXT", hznSwapTx.getSmText());
			
			/*
			 * Hzn Swap Sm - Get Begin -->
			 */
			List<?> hznSwapSmTxList = session.createCriteria(HznSwapSmTx.class)
												.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			if (hznSwapSmTxList != null) {
				for (int i = 0; i < hznSwapSmTxList.size(); i++) {
					HznSwapSmTx hznSwapSmTx = (HznSwapSmTx) hznSwapSmTxList.get(i);
					
					oMap.put("SM_DATA", i, "SM_REFERANS", hznSwapSmTx.getId().getSmReferans());
					oMap.put("SM_DATA", i, "SM_TIPI", hznSwapSmTx.getSmTipi());
				}
			}
			/*
			 * <-- Hzn Swap Sm - Get end
			 */
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1319_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSwapTx hznSwapTx = (HznSwapTx) session.createCriteria(HznSwapTx.class).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();
			
			oMap.put("TX_NO", hznSwapTx.getId().getTxNo());
			oMap.put("REF_NO", hznSwapTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSwapTx.getUrunTurKod(), "1318/LOV_URUN_TUR", "KOD"));
			oMap.put("KREDI_TEKLIF_SATIR_NUMARA", hznSwapTx.getKrediTeklifSatirNumara());
			oMap.put("SOZLESME_NO", hznSwapTx.getSozlesmeNo());
			oMap.put("URUN_SINIF_KOD", hznSwapTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSwapTx.getDealTarihi());
			oMap.put("DEALER_NO", hznSwapTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSwapTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSwapTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznSwapTx.getVadeTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSwapTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSwapTx.getSatisDovizKodu());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSwapTx.getDealerNo(), "1318/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSwapTx.getBankaMusteriNo(), "1318/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("SPOT_ALIS_TUTARI", hznSwapTx.getSpotAlisTutari());
			oMap.put("SPOT_ALIS_HESAP_TURU", hznSwapTx.getSpotAlisHesapTuru());
			oMap.put("SPOT_ALIS_HESAP_NO", hznSwapTx.getSpotAlisHesapNo());
			oMap.put("SPOT_SATIS_TUTARI", hznSwapTx.getSpotSatisTutari());
			oMap.put("SPOT_SATIS_HESAP_TURU", hznSwapTx.getSpotSatisHesapTuru());
			oMap.put("SPOT_SATIS_HESAP_NO", hznSwapTx.getSpotSatisHesapNo());
			oMap.put("SPOT_ALIS_KUR", hznSwapTx.getSpotAlisKur());
			oMap.put("SPOT_SATIS_KUR", hznSwapTx.getSpotSatisKur());
			oMap.put("SPOT_PARITE", hznSwapTx.getSpotParite());
			oMap.put("SPOT_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotAlisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getAlisDovizKodu(), "1318/LOV_SPOT_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("SPOT_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getSpotSatisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getSatisDovizKodu(), "1318/LOV_SPOT_SATIS_HESAP", "KISA_ISIM"));
			
			oMap.put("FORWARD_ALIS_TUTARI", hznSwapTx.getForwardAlisTutari());
			oMap.put("FORWARD_ALIS_HESAP_TURU", hznSwapTx.getForwardAlisHesapTuru());
			oMap.put("FORWARD_ALIS_HESAP_NO", hznSwapTx.getForwardAlisHesapNo());
			oMap.put("FORWARD_SATIS_TUTARI", hznSwapTx.getForwardSatisTutari());
			oMap.put("FORWARD_SATIS_HESAP_TURU", hznSwapTx.getForwardSatisHesapTuru());
			oMap.put("FORWARD_SATIS_HESAP_NO", hznSwapTx.getForwardSatisHesapNo());
			oMap.put("FORWARD_ALIS_KUR", hznSwapTx.getForwardAlisKur());
			oMap.put("FORWARD_SATIS_KUR", hznSwapTx.getForwardSatisKur());
			oMap.put("FORWARD_PARITE", hznSwapTx.getForwardParite());
			oMap.put("FORWARD_ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardAlisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getSatisDovizKodu(), "1318/LOV_FORWARD_ALIS_HESAP", "KISA_ISIM"));
			oMap.put("FORWARD_SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSwapTx.getForwardSatisHesapNo(),
					hznSwapTx.getBankaMusteriNo(), hznSwapTx.getAlisDovizKodu(), "1318/LOV_FORWARD_SATIS_HESAP", "KISA_ISIM"));
			oMap.put("ISLEM_SEKLI", hznSwapTx.getIslemSekli());
			oMap.put("ACIKLAMA", hznSwapTx.getAciklama());
			oMap.put("DURUM_KODU", hznSwapTx.getDurumKodu());
			stmt = conn.prepareCall("{? = call PKG_TRN1309.SWAP_Valor_Gecmismi(?) }");
			
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, hznSwapTx.getId().getReferans());
			stmt.execute();
			
			if(stmt.getString(1).equals("E"))
				oMap.put("VALOR_GECMISMI", "false");
			else
				oMap.put("VALOR_GECMISMI", "true");
			
			oMap.put("SM_EH", hznSwapTx.getSmEh());
			oMap.put("SM_TEXT", hznSwapTx.getSmText());
			
			/*
			 * Hzn Swap Sm - Get Begin -->
			 */
			List<?> hznSwapSmTxList = session.createCriteria(HznSwapSmTx.class)
												.add(Restrictions.eq("id.txNo", txNo)).list();
			
			if (hznSwapSmTxList != null) {
				for (int i = 0; i < hznSwapSmTxList.size(); i++) {
					HznSwapSmTx hznSwapSmTx = (HznSwapSmTx) hznSwapSmTxList.get(i);
					
					oMap.put("SM_DATA", i, "SM_REFERANS", hznSwapSmTx.getId().getSmReferans());
					oMap.put("SM_DATA", i, "SM_TIPI", hznSwapSmTx.getSmTipi());
				}
			}
			/*
			 * <-- Hzn Swap Sm - Get end
			 */
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
