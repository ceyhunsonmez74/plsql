package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY1375Services {
	
	@GraymoundService("BNSPR_QRY1375_GET_DATA")
	public static GMMap getFrkData (GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc1375.Rc1375_Get_Data(?,?,?,?,?,?,?,?,?,?,?)}");
			
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.setString(i++, iMap.getString("URUN_TUR_KOD"));
			stmt.setString(i++, iMap.getString("URUN_SINIF_KOD"));
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_MIN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_MAX"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("SUBE_KODU"));			
			
			
			if (!(iMap.getDate("VALOR_MIN") == null)) {
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("VALOR_MIN").getTime()));
			} else {
					stmt.setDate(i++, null);
			}
			if (!(iMap.getDate("VALOR_MAX") == null)) {
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("VALOR_MAX").getTime()));
			} else {
					stmt.setDate(i++, null);
			}
		
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "TBL_REFERANS";

			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row,"REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, row,"MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, row,"URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put(tableName, row,"URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
				oMap.put(tableName, row,"VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, row,"ISLEM_TIPI", rSet.getString("ISLEM_TIPI"));
				oMap.put(tableName, row,"DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName, row,"TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, row,"DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, row,"SUBE_KODU", rSet.getString("SUBE_KODU"));
				row++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_QRY1375_GET_HISTORY")
	public static GMMap getHistoryTxNo(GMMap iMap) {
		GMMap 				oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet           rSet = null;
		List<BigDecimal>	list = new ArrayList<BigDecimal>();
		
		try {
			conn 				= DALUtil.getGMConnection();
			stmt 				= conn.prepareCall("{? = call pkg_rc1375.Rc1375_Get_Data_Detay(?)}");
			
			int i	= 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("REFERANS"));
			
			
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet)stmt.getObject(1);

			while(rSet.next()) {
				list.add(rSet.getBigDecimal("TX_NO"));
			}
			oMap.put("TX_NO_LIST", list);
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		    GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


}


