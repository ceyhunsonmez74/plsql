package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznTmuMusteriTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1322Services {
    
    
    @GraymoundService("BNSPR_TRN1322_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
             String tableName = "TMU_MUSTERI";
             Session session = DAOSession.getSession("BNSPRDal");
            
            
             List<?> satirBilgileri = (List<?>) iMap.get(tableName);
             for(int i=0;i<satirBilgileri.size();i++){
                 HznTmuMusteriTx tmuMus;                 
                 BigDecimal id ; 
                 tmuMus = new HznTmuMusteriTx();
                 Map map  = GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_SIRA_NO" , new GMMap());
                 Object bd =  map.get("SIRA_NO"); 
                 id = BigDecimal.valueOf(Long.valueOf(String.valueOf(bd)));
                 tmuMus.setId(id);
                 tmuMus.setTxNo(iMap.getBigDecimal("TRX_NO"));
                
                 tmuMus.setMusteriNo(iMap.getBigDecimal(tableName , i , "MUSTERI_NO"));
                 tmuMus.setBaslangicTarih(iMap.getDate(tableName,i,"BAS_TARIH"));
                 tmuMus.setBitisTarih(iMap.getDate(tableName,i,"BIT_TARIH"));
                 session.saveOrUpdate(tmuMus);
                 session.flush();
                 
             }
                iMap.put("TRX_NAME","1322");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } 
     }
 
    @GraymoundService("BNSPR_TRN1322_GET_INFO")
    public static Map<?, ?> getInfo(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet =null;
        
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{? = call PKG_TRN1322.GetMusteriListView(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName="TMU_MUSTERI";
            int row =0;
            while(rSet.next()){
                oMap.put(tableName,row,"MUSTERI_NO", rSet.getBigDecimal("musteri_no"));
                oMap.put(tableName,row,"UNVAN",  LovHelper.diLov( rSet.getBigDecimal("musteri_no") , "1322/LOV_MUSTERI_NO" , "UNVAN"));
                oMap.put(tableName,row,"BAS_TARIH", rSet.getDate("baslangic_tarih"));
                oMap.put(tableName,row,"BIT_TARIH", rSet.getDate("bitis_tarih"));
                oMap.put(tableName,row,"ID", rSet.getBigDecimal("id"));
                
                row++;
               }
            
                 
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return  oMap;
     }
 
    
    @GraymoundService("BNSPR_TRN1322_GET_LIST")
    public static Map<?, ?> getList(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet =null;
        
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{call PKG_TRN1322.Musteri_List(?)}");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName="TMU_MUSTERI";
            int row =0;
            while(rSet.next()){
                oMap.put(tableName,row,"MUSTERI_NO", rSet.getBigDecimal("musteri_no"));
                oMap.put(tableName,row,"UNVAN",  LovHelper.diLov( rSet.getBigDecimal("musteri_no") , "1322/LOV_MUSTERI_NO" , "UNVAN"));
                oMap.put(tableName,row,"BAS_TARIH", rSet.getDate("baslangic_tarih"));
                oMap.put(tableName,row,"BIT_TARIH", rSet.getDate("bitis_tarih"));
                oMap.put(tableName,row,"ID", rSet.getBigDecimal("id"));
                row ++;
            
               }
            
                 
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return  oMap;
     }
 
    
}
