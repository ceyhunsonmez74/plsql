package tr.com.calikbank.bnspr.treasury.services;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MatriksRateDataTx;
import tr.com.aktifbank.bnspr.dao.MatriksRateDataTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznNakitAkisManuelGunTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1338Services {
	
	@GraymoundService("BNSPR_TRN1338_SAVE")
	public static GMMap Save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MATRIKSDATA_INFO_LIST";
			List<?> list = (List<?>) iMap.get(tableName);

			for (int i=0;i<list.size();i++){
				
				MatriksRateDataTxId id = new MatriksRateDataTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setRateId((new java.math.BigDecimal(i+1)));
				
				MatriksRateDataTx matriksRateDataTx = (MatriksRateDataTx)session.get(MatriksRateDataTx.class, id);

				if(matriksRateDataTx == null) {
					matriksRateDataTx = new MatriksRateDataTx();
				}
				
            	matriksRateDataTx.setId(id);	
            	matriksRateDataTx.setSembol(iMap.getString(tableName , i , "SEMBOL"));
            	matriksRateDataTx.setAciklama(iMap.getString(tableName , i , "ACIKLAMA"));
            	session.saveOrUpdate(matriksRateDataTx);
            	session.flush();
            }			
			iMap.put("TRX_NAME", "1338");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1338_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> recordList = session.createCriteria(MatriksRateDataTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			String tableName = "MATRIKSDATA_INFO_LIST";
			for (int row = 0; row < recordList.size(); row++) {
				MatriksRateDataTx matriksRateDataTx = (MatriksRateDataTx) recordList.get(row);
				oMap.put(tableName,row,"SEMBOL", matriksRateDataTx.getSembol());
				oMap.put(tableName,row,"ACIKLAMA", matriksRateDataTx.getAciklama());
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1338_MATRIKSDATA_INFO")
	public static GMMap musteriInfoSearch(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {

			String tableName = "MATRIKSDATA_INFO_LIST";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1338.GetMatriksdataInfoList}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "SEMBOL", rSet.getString("SEMBOL"));
				oMap.put(tableName, i, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
