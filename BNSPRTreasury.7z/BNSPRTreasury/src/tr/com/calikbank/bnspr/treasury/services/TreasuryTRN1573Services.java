package tr.com.calikbank.bnspr.treasury.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class TreasuryTRN1573Services {

	
	@GraymoundService("BNSPR_TRN1573_ISLEMLERI_GETIR")
	public static GMMap teminatlariHesapla  (GMMap iMap) {
	GMMap oMap = new GMMap(); 
		
	String func = "{ ? = call PKG_TRN1573.OnayBekleyenTxList}";
	
	try {
		oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE", new Object[0]);
	}
	catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}
	
	return oMap;
}

	
	
}