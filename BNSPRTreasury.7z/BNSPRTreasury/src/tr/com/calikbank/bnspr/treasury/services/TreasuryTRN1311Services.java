package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznAdepoApOdmplanTx;
import tr.com.calikbank.bnspr.dao.HznAdepoApOdmplanTxId;
import tr.com.calikbank.bnspr.dao.HznAdepoFaizOdmplanTx;
import tr.com.calikbank.bnspr.dao.HznAdepoFaizOdmplanTxId;
import tr.com.calikbank.bnspr.dao.HznAlinandepo;
import tr.com.calikbank.bnspr.dao.HznAlinandepoTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1311Services {

	@GraymoundService("BNSPR_TRN1311_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		iMap.put("KOD", "HZN_VADE_ISLEM_BILGISI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_VADE_ISLEM_BILGISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_AP_ODEME_SEKLI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_AP_ODEME_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_AP_TAKSIT_ODM_SEKLI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_AP_TAKSIT_ODM_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_FAIZ_HESAP_TUTAR");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_FAIZ_HESAP_TUTAR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_DEPO_ISLEM_TURU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "KRE_FAIZ_ENDEKS_KOD");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("KRE_FAIZ_ENDEKS_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_TAKSIT_DURUMU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_TAKSIT_DURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		DALUtil.fillComboBox(oMap, "ANA_PARA_ODEME_SIKLIK_TIPI", true, "SELECT KOD,ACIKLAMA FROM v_ml_muh_tahakkuksiklik_kod_pr MT WHERE MT.KOD IN ( 'GN' , 'AY' , 'YIL' )");
		
		DALUtil.fillComboBox(oMap, "FAIZ_SIKLIK_TIPI", true, "SELECT KOD,ACIKLAMA FROM v_ml_muh_tahakkuksiklik_kod_pr MT");
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1311_SAVE")
	public static GMMap save(GMMap iMap) {
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAlinanDepoTx == null) {
				hznAlinanDepoTx = new HznAlinandepoTx();
			}
			
			hznAlinanDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAlinanDepoTx.setModulTurKod("HAZINE");
			hznAlinanDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAlinanDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAlinanDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznAlinanDepoTx.setReferans(iMap.getString("REFERANS"));
			hznAlinanDepoTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
			hznAlinanDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			hznAlinanDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAlinanDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAlinanDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAlinanDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAlinanDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAlinanDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAlinanDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAlinanDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAlinanDepoTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznAlinanDepoTx.setAnaparaOdemeSekli(iMap.getString("ANAPARA_ODEME_SEKLI"));
			hznAlinanDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAlinanDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAlinanDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAlinanDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAlinanDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAlinanDepoTx.setAnaparaTaksitAdedi(iMap.getBigDecimal("ANAPARA_TAKSIT_ADEDI"));
			hznAlinanDepoTx.setAnaparaOdemeSiklikTipi(iMap.getString("ANAPARA_ODEME_SIKLIK_TIPI"));
			hznAlinanDepoTx.setAnaparaOdemeSiklik(iMap.getBigDecimal("ANAPARA_ODEME_SIKLIK"));
			hznAlinanDepoTx.setAnaparaTaksitliOdemeSekli(iMap.getString("ANAPARA_TAKSITLI_ODEME_SEKLI"));
			hznAlinanDepoTx.setFaizEndeksKodu(iMap.getString("FAIZ_ENDEKS_KODU"));
			hznAlinanDepoTx.setSpread(iMap.getString("SPREAD"));
			hznAlinanDepoTx.setSpreadOrani(iMap.getBigDecimal("SPREAD_ORANI"));
			hznAlinanDepoTx.setFaizEndeksPeriod(iMap.getString("FAIZ_ENDEKS_PERIOD"));
			hznAlinanDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAlinanDepoTx.setFaizSiklikTipi(iMap.getString("FAIZ_SIKLIK_TIPI"));
			hznAlinanDepoTx.setFaizSiklik(iMap.getBigDecimal("FAIZ_SIKLIK"));
			hznAlinanDepoTx.setFaizHesaplanacakTutar(iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			hznAlinanDepoTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			
			hznAlinanDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznAlinanDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			hznAlinanDepoTx.setMurabahaId(iMap.getBigDecimal("MURABAHA_ID"));
			
			hznAlinanDepoTx.setNegatifFaiz(iMap.getBoolean("NEGATIF_FAIZ")==true?new BigDecimal(1):new BigDecimal(0));
			
			hznAlinanDepoTx.setOrderId(iMap.getString("ORDER_ID"));
			hznAlinanDepoTx.setCounterParty(iMap.getString("COUNTER_PARTY"));
			hznAlinanDepoTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
			hznAlinanDepoTx.setMessageId(iMap.getString("MESSAGE_ID"));
			hznAlinanDepoTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
			
			session.saveOrUpdate(hznAlinanDepoTx);
			session.flush();
			
		  GMMap oMap = new GMMap();
		 
		 return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}
	
	@GraymoundService("BNSPR_TRN1311_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1311.Hzn_bilgiaktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	@GraymoundService("BNSPR_TRN1311_TRANSACTION_START")
	public static Map<?, ?> trn1311Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1311");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN1311_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmtNetting = null;
        String isNetting = "H";
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			if(iMap.getString("ISLEM_KOD").equals("1311") ){ 
				stmtNetting = conn.prepareCall("{call PKG_TRN1306.Netting_Swift_Kontrolu(?,?,?,?,?) }");
				
				stmtNetting.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
				stmtNetting.setString(2, "DEPO");
				stmtNetting.setString(3, iMap.getString("SATIS_DOVIZ_KODU"));
				stmtNetting.setString(4, iMap.getString("SATIS_HESAP_TURU"));
	
				stmtNetting.registerOutParameter(5, Types.VARCHAR);
	
				stmtNetting.execute();
				isNetting = stmtNetting.getString(5);
			
			}
			if(isNetting.equals("H")){
				stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?)}");
			    
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.execute();
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN1311_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAlinanDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAlinanDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAlinanDepoTx.getReferans());
			oMap.put("ISLEM_TURU", hznAlinanDepoTx.getIslemTuru());
			oMap.put("DEALER_NO", hznAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAlinanDepoTx.getCikisHesapNo());
			oMap.put("ACIKLAMA", hznAlinanDepoTx.getAciklama());
			oMap.put("DOVIZ_KODU", hznAlinanDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznAlinanDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznAlinanDepoTx.getValorTarihi());
			oMap.put("ANAPARA_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaOdemeSekli());
			oMap.put("VADE_TARIHI", hznAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAlinanDepoTx.getDealTarihi());
			oMap.put("ANAPARA_TAKSIT_ADEDI", hznAlinanDepoTx.getAnaparaTaksitAdedi());
			oMap.put("ANAPARA_ODEME_SIKLIK_TIPI", hznAlinanDepoTx.getAnaparaOdemeSiklikTipi());
			oMap.put("ANAPARA_ODEME_SIKLIK", hznAlinanDepoTx.getAnaparaOdemeSiklik());
			oMap.put("ANAPARA_TAKSITLI_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaTaksitliOdemeSekli());
			oMap.put("FAIZ_ENDEKS_KODU", hznAlinanDepoTx.getFaizEndeksKodu());
			oMap.put("SPREAD", hznAlinanDepoTx.getSpread());
			oMap.put("SPREAD_ORANI", hznAlinanDepoTx.getSpreadOrani());
			oMap.put("FAIZ_ENDEKS_PERIOD", hznAlinanDepoTx.getFaizEndeksPeriod());
			oMap.put("FAIZ_ORANI", hznAlinanDepoTx.getFaizOrani());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAlinanDepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_SIKLIK", hznAlinanDepoTx.getFaizSiklik());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAlinanDepoTx.getFaizHesaplanacakTutar());
			oMap.put("DURUM_KODU", hznAlinanDepoTx.getDurumKodu());
			
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getGirisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getGirisHesapTuru(), hznAlinanDepoTx.getDovizKodu(), hznAlinanDepoTx.getGirisHesapTuru(), 
					hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getCikisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getCikisHesapTuru(), hznAlinanDepoTx.getDovizKodu(), hznAlinanDepoTx.getCikisHesapTuru(), 
					hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAlinanDepoTx.getDealerNo(), "1310/LOV_DEALER", "ISIM"));
			
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAlinanDepoTx.getCikisMuhabirMusteriNo());
			oMap.put("MURABAHA_ID", hznAlinanDepoTx.getMurabahaId());
			
			// Negatif faiz uygulanirsa bu alan secilir faiz orani eksi yapilamaz swift cakiliyor
			if (hznAlinanDepoTx.getNegatifFaiz()!=null)
				oMap.put("NEGATIF_FAIZ", hznAlinanDepoTx.getNegatifFaiz().intValue()==1?true:false);
			else
				oMap.put("NEGATIF_FAIZ", false);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}
	
	@GraymoundService("BNSPR_TRN1311_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAlinanDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAlinanDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAlinanDepoTx.getReferans());
			oMap.put("ISLEM_TURU", hznAlinanDepoTx.getIslemTuru());
			oMap.put("DEALER_NO", hznAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAlinanDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAlinanDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznAlinanDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznAlinanDepoTx.getValorTarihi());
			oMap.put("ANAPARA_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaOdemeSekli());
			oMap.put("VADE_TARIHI", hznAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAlinanDepoTx.getDealTarihi());
			oMap.put("ANAPARA_TAKSIT_ADEDI", hznAlinanDepoTx.getAnaparaTaksitAdedi());
			oMap.put("ANAPARA_ODEME_SIKLIK_TIPI", hznAlinanDepoTx.getAnaparaOdemeSiklikTipi());
			oMap.put("ANAPARA_ODEME_SIKLIK", hznAlinanDepoTx.getAnaparaOdemeSiklik());
			oMap.put("ANAPARA_TAKSITLI_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaTaksitliOdemeSekli());
			oMap.put("FAIZ_ENDEKS_KODU", hznAlinanDepoTx.getFaizEndeksKodu());
			oMap.put("SPREAD", hznAlinanDepoTx.getSpread());
			oMap.put("SPREAD_ORANI", hznAlinanDepoTx.getSpreadOrani());
			oMap.put("FAIZ_ENDEKS_PERIOD", hznAlinanDepoTx.getFaizEndeksPeriod());
			oMap.put("FAIZ_ORANI", hznAlinanDepoTx.getFaizOrani());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAlinanDepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_SIKLIK", hznAlinanDepoTx.getFaizSiklik());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAlinanDepoTx.getFaizHesaplanacakTutar());
			oMap.put("DURUM_KODU", hznAlinanDepoTx.getDurumKodu());
			
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getGirisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getGirisHesapTuru(), hznAlinanDepoTx.getDovizKodu(), hznAlinanDepoTx.getGirisHesapTuru(), 
					hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getCikisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getCikisHesapTuru(), hznAlinanDepoTx.getDovizKodu(), hznAlinanDepoTx.getCikisHesapTuru(), 
					hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAlinanDepoTx.getDealerNo(), "1310/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAlinanDepoTx.getAciklama());
			
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAlinanDepoTx.getCikisMuhabirMusteriNo());
			oMap.put("MURABAHA_ID", hznAlinanDepoTx.getMurabahaId());
			
			
			// Negatif faiz uygulanirsa bu alan secilir faiz orani eksi yapilamaz swift cakiliyor
			if (hznAlinanDepoTx.getNegatifFaiz()!=null)
				oMap.put("NEGATIF_FAIZ", hznAlinanDepoTx.getNegatifFaiz().intValue()==1?true:false);
			else
				oMap.put("NEGATIF_FAIZ", false);
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	@GraymoundService("BNSPR_TRN1311_ODEME_PLANI_OLUSTUR")
	public static GMMap odemePlaniOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.AnaPara_Odeme_Plani_Olustur(?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ADEDI"));
			stmt.setString(i++, iMap.getString("ODEME_ARALIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_ARALIK"));
			stmt.setString(i++, iMap.getString("TAKSITLI_ODEME_SEKLI"));
			if(iMap.getDate("VALOR_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CIKIS_HESAP_NO"));
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.execute();
		//	new SimpleDateFormat("dd.MM.yyyy").format(stmt.getDate(--i))
			oMap.put("VADE_TARIHI",stmt.getDate(--i));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1311_ODEME_PLANI_SIL")
	public static GMMap odemePlaniSil(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.AnaPara_Odeme_Plani_Sil(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1311_FAIZ_ODEME_PLANI_OLUSTUR")
	public static GMMap faizOdemePlaniOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.Faiz_Odeme_Plani_Olustur(?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ADEDI"));
			stmt.setString(i++, iMap.getString("AP_ODEME_ARALIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("AP_ODEME_ARALIK"));
			stmt.setString(i++, iMap.getString("FAIZ_ODEME_ARALIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ODEME_ARALIK"));
			if(iMap.getDate("VALOR_TARIHI") ==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CIKIS_HESAP_NO"));
			
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			if(iMap.getDate("VADE_TARIHI") ==null)
				stmt.setDate(i++, null);
			else
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			
			
			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1311_FAIZ_ODEME_PLANI_SIL")
	public static GMMap faizOdemePlaniSil(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.Faiz_Odeme_Plani_Sil(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt); 
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1311_ODEME_PLANI_TUTAR_HESAPLA")
	public static GMMap odemePlaniTutarHesapla(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			
			Session session 	= DAOSession.getSession("BNSPRDal");
			String 	tableName 	= "CBS_HAZINE_ADEPO_AP_ODMPLISL";
			
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){
				HznAdepoApOdmplanTxId id = new HznAdepoApOdmplanTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSirano(iMap.getBigDecimal	(tableName, i, "SIRANO"));
				
				HznAdepoApOdmplanTx hznAdepoApOdmplanTx = (HznAdepoApOdmplanTx)(session.get(HznAdepoApOdmplanTx.class, id));
				
				if(hznAdepoApOdmplanTx == null)
					hznAdepoApOdmplanTx = new HznAdepoApOdmplanTx();
				
				hznAdepoApOdmplanTx.setId(id);
				hznAdepoApOdmplanTx.setVadeTarihi(iMap.getDate(tableName, i, "VADE_TARIHI"));
				hznAdepoApOdmplanTx.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				hznAdepoApOdmplanTx.setTaksitDurumu(iMap.getString(tableName, i, "TAKSIT_DURUMU"));
				session.saveOrUpdate(hznAdepoApOdmplanTx);
			}
			session.flush();
			
			tableName = "CBS_HAZINE_ADEPO_FAIZ_ODMPLISL";
			
			list = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){
				HznAdepoFaizOdmplanTxId id = new HznAdepoFaizOdmplanTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSirano(iMap.getBigDecimal	(tableName, i, "SIRANO"));
				
				HznAdepoFaizOdmplanTx hznAdepoFaizOdmplanTx = (HznAdepoFaizOdmplanTx)(session.get(HznAdepoFaizOdmplanTx.class, id));
				
				if(hznAdepoFaizOdmplanTx == null)
					hznAdepoFaizOdmplanTx = new HznAdepoFaizOdmplanTx();
				
				hznAdepoFaizOdmplanTx.setId(id);
				hznAdepoFaizOdmplanTx.setVadeTarihi(iMap.getDate(tableName, i, "VADE_TARIHI"));
				hznAdepoFaizOdmplanTx.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				hznAdepoFaizOdmplanTx.setTaksitDurumu(iMap.getString(tableName, i, "TAKSIT_DURUMU"));
				session.saveOrUpdate(hznAdepoFaizOdmplanTx);
			}
			session.flush();
			
			//GMServiceExecuter.execute("BNSPR_TRN1311_FAIZ_ODEME_PLANI_TUTAR_HESAPLA", iMap);
			oMap.put("CBS_HAZINE_ADEPO_FAIZ_ODMPLISL", GMServiceExecuter.execute("BNSPR_TRN1311_GET_FAIZ_ODEME_PLANI", iMap).get("RESULTS"));
			oMap.put("CBS_HAZINE_ADEPO_AP_ODMPLISL", GMServiceExecuter.execute("BNSPR_TRN1311_GET_ANAPARA_ODEME_PLANI", iMap).get("RESULTS"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_TRN1311_FAIZ_ODEME_PLANI_TUTAR_HESAPLA")
	public static GMMap faizOdemePlaniTutarHesapla(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.Faiz_OdmPlan_Tutar_Hesapla(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("FAIZ_ODEME_ARALIK_TIPI"));
			if(iMap.getDate("VALOR_TARIHI") ==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("AP_ODEME_SEKLI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLAYACAK_TUTAR"));
			
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt); 
			GMServerDatasource.close(conn);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1311_GET_FAIZ_ODEME_PLANI")
	public static GMMap getFaizOdemePlani(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		List<?> faizOdemePlaniList = session.createCriteria(HznAdepoFaizOdmplanTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		try{
			int row = 0;
			
			String tabName = "CBS_HAZINE_ADEPO_FAIZ_ODMPLISL";
			for (Iterator<?> iterator = faizOdemePlaniList.iterator(); iterator.hasNext();row++) {
				HznAdepoFaizOdmplanTx faizOdeme = (HznAdepoFaizOdmplanTx) iterator.next();
				oMap.put(tabName,row, "SIRANO",faizOdeme.getId().getSirano() );
				oMap.put(tabName, row, "TAKSIT_DURUMU",faizOdeme.getTaksitDurumu() );
				oMap.put(tabName,row,"TUTAR",faizOdeme.getTutar() );
				oMap.put(tabName,row,"VADE_TARIHI",faizOdeme.getVadeTarihi() );
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			
		}
		
	}
	@GraymoundService("BNSPR_TRN1311_GET_ANAPARA_ODEME_PLANI")
	public static GMMap getAnaparaOdemePlani(GMMap iMap){
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");

		List<?> faizOdemePlaniList = session.createCriteria(HznAdepoApOdmplanTx.class).
			add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		try{
			int row = 0;
			String tabName = "CBS_HAZINE_ADEPO_AP_ODMPLISL";
			for (Iterator<?> iterator = faizOdemePlaniList.iterator(); iterator.hasNext();row++) {
				HznAdepoApOdmplanTx apOdeme = (HznAdepoApOdmplanTx) iterator.next();
				oMap.put(tabName, row, "SIRANO",apOdeme.getId().getSirano() );
				oMap.put(tabName, row, "TAKSIT_DURUMU",apOdeme.getTaksitDurumu() );
				oMap.put(tabName,row,"TUTAR",apOdeme.getTutar() );
				oMap.put(tabName,row,"VADE_TARIHI",apOdeme.getVadeTarihi() );
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			
		}
	}
		
	@GraymoundService("BNSPR_TRN1311_FAIZ_HESAPLA")
	public static GMMap getFaizHesabi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_TRN1311.Faiz_Tutari_Hesapla(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TENOR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			stmt.execute();
			
			oMap.put("FAIZ_TUTARI",stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN1311_ENDEKS_FAIZ_ORAN_AL")
	public static GMMap getEndeksFaizOrani(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_HAZINE.Endeks_Faiz_Oran_Al(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_PERIODU"));
			stmt.execute();
			
			oMap.put("FAIZ_ORANI",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN1311_ODEME_PLANI")
	public static GMMap odemePlani(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.Odeme_Plani(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("REF_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ODEME_ARALIK"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ADEDI"));
			stmt.setString(i++, iMap.getString("TAKSITLI_ODEME_SEKLI"));
			if(iMap.getDate("VALOR_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			if(iMap.getDate("VADE_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CIKIS_HESAP_NO"));
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SIKLIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ANAPARA_ODEME_SIKLIK"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_SIKLIK"));
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.execute();
			oMap.put("VADE_TARIHI", stmt.getDate(--i));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN1311_FAIZ_TUTAR_HESAPLA_UPDATE")
	public static GMMap faizTutarHesaplaUpdate(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1311.Faiz_Tutar_Hesapla_Update(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("REF_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ODEME_ARALIK"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ADEDI"));
			stmt.setString(i++, iMap.getString("TAKSITLI_ODEME_SEKLI"));
			if(iMap.getDate("VALOR_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			if(iMap.getDate("VADE_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CIKIS_HESAP_NO"));
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SIKLIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ANAPARA_ODEME_SIKLIK"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_SIKLIK"));
			
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN1311_GET_MURABAHA_ID")
	public static GMMap getMurabahaID(GMMap iMap){
		GMMap oMap = new GMMap();
	
		try{
			
			if (iMap.getString("REFERANS")!=null)
			{
				
				Session session = DAOSession.getSession("BNSPRDal");
				HznAlinandepo hznAlinanDepo = (HznAlinandepo)session.get(HznAlinandepo.class, iMap.getString("REFERANS"));
				if(hznAlinanDepo != null) {
					
					oMap.put("MURABAHA_ID", hznAlinanDepo.getMurabahaId());
				}
				
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 

	}
	
	
}
