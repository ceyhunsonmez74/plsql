package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MkkRehinTeminat;
import tr.com.aktifbank.bnspr.dao.MkkRehinTeminatTx;
import tr.com.aktifbank.integration.mkk.MkkClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.mkk.ws.schemas.mkkresponse.MkkResponseType;
import tr.com.mkk.ws.schemas.mkkresponse.ResponseType;
import tr.com.mkk.ws.schemas.pledgecollateral.EnterExitPlType;
import tr.com.mkk.ws.schemas.pledgecollateral.PlInfoType;
import tr.com.mkk.ws.schemas.pledgecollateral.PlProcessTypeType;
import tr.com.mkk.ws.schemas.types_1_0.RequestHeaderType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkRehinTeminatBatchService {
    
    private static final Logger logger = Logger.getLogger(MkkRehinTeminatBatchService.class);
    
    @GraymoundService("BNSPR_MKK_REHIN_TEM_BATCH_SERVICE")
    public static GMMap mkkCallRehinTeminatServices(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap xMap = new GMMap();
        xMap.put("BATCH_NAME" , "MKK_RT_BATCH_RUNNING_FLAG");
        String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
        boolean iAmRunning = false;
        try{
            if("E".equals(runningFlag)){
                logger.info("[BNSPR_MKK_RT_BATCH_SERVICE] batch is already running, can't run parallel...");
                oMap.put("HATA_NO", new BigDecimal(660));
                oMap.put("P1", "Devam eden MKK Rehin Teminat batch i�lemi bulunmaktad�r!");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
            }
            else{
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_RT_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"1\"");
                GMServiceExecuter.execute("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_RT_BATCH_SERVICE] MKK_RT_BATCH_RUNNING_FLAG has been set to [1]");
                iAmRunning = true;
            }
            logger.info("MKK Rehin Teminat Batch �al��maya ba�lad�:[BNSPR_MKK_REHIN_TEM_BATCH_SERVICE]");
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(MkkRehinTeminat.class).add(Restrictions.eq("durum" , "G")).addOrder(Order.desc("processType")).addOrder(Order.asc("rtId"));
            List<?> list = criteria.list();
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                MkkRehinTeminat rtGon = (MkkRehinTeminat) iterator.next();
                
                logger.info("[BNSPR_MKK_REHIN_TEM_BATCH_SERVICE] g�nderilecek kay�t:" + rtGon.getRtId());
                
                EnterExitPlType plType = new EnterExitPlType();
                PlInfoType plInfoType = new PlInfoType();
                
                
                plInfoType.setAmount(rtGon.getAmount());
                plInfoType.setExplanation(rtGon.getExplanation());
                plInfoType.setIsin(rtGon.getIsin());
                plInfoType.setMic(rtGon.getMic());
                plInfoType.setPlRcvAccNo(rtGon.getPlRcvAccNo());
                plInfoType.setPlRcvMemberCode(rtGon.getPlRcvMemberCode());
                plInfoType.setPlRcvSubAccNo(rtGon.getPlRcvSubAccNo());
                plInfoType.setPlReason(rtGon.getPlReason());
                plInfoType.setPlRef(rtGon.getPlRef());
                plInfoType.setPlSendAccNo(rtGon.getPlSendAccNo());
                plInfoType.setPlSendMemberCode(rtGon.getPlSendMemberCode());
                plInfoType.setPlSendSubAccNo(rtGon.getPlSendSubAccNo());
                plInfoType.setProcessType(PlProcessTypeType.fromValue(rtGon.getProcessType()));
                plInfoType.setSecAddDefCode(rtGon.getSecAddDefCode());
                plInfoType.setValueDate(rtGon.getValueDate());
                
                plType.setPlInfo(plInfoType);
                
                RequestHeaderType reqHeader = new RequestHeaderType();
                reqHeader.setSenderMember(rtGon.getSenderMember());
                reqHeader.setSenderReference(rtGon.getSenderReference());
                
                plType.setRequestHeader(reqHeader);
                
                MkkResponseType response = MkkClient.getMkkRehinTeminatService().enterExitPl(plType);
                logger.info("[BNSPR_MKK_REHIN_TEM_BATCH_SERVICE] g�nderildi, ID:" + rtGon.getRtId());
                MkkHaKeBatchService.saveMkkResponse(response);
                
                if (response != null){
                    ResponseType responseType = response.getResponse();
                    logger.info("[BNSPR_MKK_REHIN_TEM_BATCH_SERVICE] ID:[" + rtGon.getRtId() + "], response code:[" + responseType.getResponseCode() + "], response desc:[" + responseType.getResponseDesc() + "]");
                    
                    MkkRehinTeminatTx rtx = createNewRTtxPojo(rtGon);
                    
                    BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , iMap).getBigDecimal("TRX_NO");
                    if ("0000".equals(responseType.getResponseCode())){
                        rtx.setDurum("A"); // Ba�ar�l� G�nderildi
                    } else{
                        rtx.setDurum("H"); // Ba�ar�s�z Hatal�
                    }
                    
                    rtx.setResponseCode(responseType.getResponseCode());
                    rtx.setResponseDesc(responseType.getResponseDesc());
                    rtx.setTxNo(txNo);
                    session.save(rtx);
                    session.flush();
                    iMap.clear();
                    iMap.put("TRX_NAME" , "1704");
                    iMap.put("TRX_NO" , txNo);
                    oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
                }
            }
        } catch (Exception e){
            logger.error("MKK Rehin Teminat Batch hata" , e);
            throw ExceptionHandler.convertException(e);
        }
        finally{
            if (iAmRunning){ //Batchi �al��t�ran bensem i�im bitti�inde sonland�rmal�y�m
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_RT_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"0\"");
                GMServiceExecuter.execute("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_RT_BATCH_SERVICE] MKK_RT_BATCH_RUNNING_FLAG has been set to [0]");
            }
            logger.info("MKK Rehin Teminat Batch tamamland�, [BNSPR_MKK_REHIN_TEM_BATCH_SERVICE]");
        }
        return oMap;
    }
    
    public static MkkRehinTeminatTx createNewRTtxPojo(MkkRehinTeminat rt) {
        MkkRehinTeminatTx rtx = new MkkRehinTeminatTx();
        
        rtx.setRtId(rt.getRtId());
        rtx.setTeminatNo(rt.getTeminatNo());
        rtx.setTeminatDetayNo(rt.getTeminatDetayNo());
        rtx.setSenderMember(rt.getSenderMember());
        rtx.setSenderReference(rt.getSenderReference());
        rtx.setProcessType(rt.getProcessType());
        rtx.setValueDate(rt.getValueDate());
        rtx.setPlSendMemberCode(rt.getPlSendMemberCode());
        rtx.setPlSendAccNo(rt.getPlSendAccNo());
        rtx.setPlSendSubAccNo(rt.getPlSendSubAccNo());
        rtx.setPlRcvMemberCode(rt.getPlRcvMemberCode());
        rtx.setPlRcvAccNo(rt.getPlRcvAccNo());
        rtx.setPlRcvSubAccNo(rt.getPlRcvSubAccNo());
        rtx.setPlReason(rt.getPlReason());
        rtx.setPlRef(rt.getPlRef());
        rtx.setMic(rt.getMic());
        rtx.setIsin(rt.getIsin());
        rtx.setSecAddDefCode(rt.getSecAddDefCode());
        rtx.setAmount(rt.getAmount());
        rtx.setExplanation(rt.getExplanation());
        rtx.setRefTxNo(rt.getRefTxNo());

        return rtx;
    }
    
}
