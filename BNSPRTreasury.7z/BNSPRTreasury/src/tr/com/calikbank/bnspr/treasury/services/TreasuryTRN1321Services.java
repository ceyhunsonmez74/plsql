package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.HznGrupLimitTanimlamaTx;
import tr.com.aktifbank.bnspr.dao.HznGrupLimitTanimlamaTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1321Services {
    
    
    @GraymoundService("BNSPR_TRN1321_SAVE")
    public static Map<?, ?> save(GMMap iMap){
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName    = "FR_MUSTERI_BILGI";
            
            List<?> recordList = (List<?>)iMap.get(tableName);
            
            for (int row = 0;row<recordList.size();row++) {
                HznGrupLimitTanimlamaTxId id = new HznGrupLimitTanimlamaTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setId(iMap.getBigDecimal(tableName, row, "ID"));
     
              HznGrupLimitTanimlamaTx hznGrupLimitTanimlamaTx = (HznGrupLimitTanimlamaTx)session.get(HznGrupLimitTanimlamaTx.class, id);
               
                if(hznGrupLimitTanimlamaTx == null) {
                    hznGrupLimitTanimlamaTx = new HznGrupLimitTanimlamaTx();
                }
                hznGrupLimitTanimlamaTx.setId(id);
                
                hznGrupLimitTanimlamaTx.setKod(iMap.getString("GRUP_KODU"));
                hznGrupLimitTanimlamaTx.setMusteriNo(iMap.getBigDecimal(tableName, row, "MUSTERI_NO"));
                hznGrupLimitTanimlamaTx.setGrupAdi(iMap.getString("GRUP_ADI"));
                hznGrupLimitTanimlamaTx.setGrupLimiti(iMap.getBigDecimal("GRUP_LIMITI"));
              
                if (("S").equals(iMap.getString(tableName , row , "G_S")))
                    hznGrupLimitTanimlamaTx.setGS("S");
                else if (("G").equals(iMap.getString(tableName, row, "G_S")))
                    hznGrupLimitTanimlamaTx.setGS("G");
                else hznGrupLimitTanimlamaTx.setGS("");
                hznGrupLimitTanimlamaTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
                    
                    session.saveOrUpdate(hznGrupLimitTanimlamaTx);
                }
                session.flush();
                
               iMap.put("TRX_NAME","1321");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } 
     }

@GraymoundService("BNSPR_TRN1321_GET_GRUP_LIMIT_LIST")
public static Map<?, ?> getMuhabirList(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{? = call PKG_TRN1321.GET_GRUP_LIMIT_LIST(?)}");
        
        int i    = 1;
        stmt.registerOutParameter(i++, -10);
        stmt.setString(i++, iMap.getString("KOD"));
      
        stmt.execute();
   
        rSet = (ResultSet)stmt.getObject(1);
        oMap = DALUtil.rSetResults(rSet, "FR_MUSTERI_BILGI");
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }

@GraymoundService("BNSPR_TRN1321_GET_INFO")
public static GMMap getInfo(GMMap iMap){
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_TRN1321.GET_INFO_KRITER(?) }");
            
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);
            
            GMMap oMap = new GMMap();
            if(rSet.next())
            {
                oMap.put("KOD", rSet.getString("KOD"));
                oMap.put("GRUP_ADI", rSet.getString("GRUP_ADI"));
                oMap.put("GRUP_LIMITI", rSet.getString("GRUP_LIMITI"));
                oMap.put("DOVIZ_KODU",rSet.getString("DOVIZ_KODU"));

             }
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            
            stmt = conn.prepareCall("{ ? = call PKG_TRN1321.GET_INFO(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);
           
           oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
           oMap.putAll(DALUtil.rSetResults(rSet, "FR_GET_INFO"));
  
            return oMap;
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }finally {
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
    } 

@GraymoundService("BNSPR_TRN1321_MUKERRER_TANIM_KONTROLU")
public static GMMap isRecordsUnique(GMMap iMap) {
    
        GMMap oMap = new GMMap();
        
        String tableName = "FR_MUSTERI_BILGI";
        
        int rowCount = iMap.getSize(tableName);
        
        if(rowCount==0)
        {
          iMap.put("HATA_NO",new BigDecimal(2521));
          GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
        
        for (int i = 0; i < rowCount; i++){
            for (int j = 0; j < rowCount; j++){
                if (iMap.getString("KOD").equals("") || iMap.getString("KOD") == (null)){
                    iMap.put("P1","GRUP KODU");
                    iMap.put("HATA_NO",new BigDecimal(330));
                    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
                    if (i != j){
                        if (!(iMap.getString(tableName, i, "G_S").equals("S")||iMap.getString(tableName, j, "G_S").equals("S"))) {
                        if (iMap.getString(tableName , i , "MUSTERI_NO").equals(iMap.getString(tableName , j , "MUSTERI_NO"))){
                            iMap.put("HATA_NO" , new BigDecimal(2522));
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                    }
                        }
                 }
                }
            }
        
        return oMap;
    }
}
