package tr.com.calikbank.bnspr.treasury.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1577Services {

	@GraymoundService("BNSPR_TRN1577_SAVE")
	public static Map<?, ?> saveTRN3160(GMMap iMap) {
		GMMap oMap = new GMMap();
		int size = iMap.getSize("TABLE");
		int updateSayisi = 0;

		try {

			Session session = DAOSession.getSession("BNSPRDal");
			HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			if (hznOpsiyonislemTx == null)
				hznOpsiyonislemTx = new HznOpsiyonislemTx();

			for (int row = 0; row < size; row++) {

				if (iMap.getString("TABLE", row, "KULLANIM")!=null)

				{   
					updateSayisi++;
					if(updateSayisi>1)
						throw new GMRuntimeException(0, "Bir i�lemde sadece bir kay�t g�ncellenebilir.");
						
						
					hznOpsiyonislemTx= new HznOpsiyonislemTx();
					hznOpsiyonislemTx.setSubePyKod(iMap.getString("TABLE", row, "SUBE_PY_KOD"));
					hznOpsiyonislemTx.setMusteriNo(iMap.getBigDecimal("TABLE", row, "MUSTERI_NO"));
					hznOpsiyonislemTx.setOpsAmac(iMap.getString("TABLE", row, "OPS_AMAC"));
					hznOpsiyonislemTx.setOpsSekliBaz(iMap.getString("TABLE", row, "OPS_SEKLI_BAZ"));
					hznOpsiyonislemTx.setHedefFiyat(iMap.getBigDecimal("TABLE", row, "HEDEF_FIYAT"));
					hznOpsiyonislemTx.setBazDvz(iMap.getString("TABLE", row, "BAZ_DVZ"));
					hznOpsiyonislemTx.setBazTutar(iMap.getBigDecimal("TABLE", row, "BAZ_TUTAR"));
					hznOpsiyonislemTx.setPrimMaliyet(iMap.getBigDecimal("TABLE", row, "PRIM_MALIYET"));
					hznOpsiyonislemTx.setPrimMusteri(iMap.getBigDecimal("TABLE", row, "PRIM_MUSTERI"));
					hznOpsiyonislemTx.setTarihIslem(iMap.getDate("TABLE", row, "TARIH_ISLEM"));
					hznOpsiyonislemTx.setTarihUzlasma(iMap.getDate("TABLE", row, "TARIH_UZLASMA"));
					hznOpsiyonislemTx.setTarihVade(iMap.getDate("TABLE", row, "TARIH_VADE"));
					hznOpsiyonislemTx.setOpsTipi(iMap.getString("TABLE", row, "OPS_TIPI"));
					hznOpsiyonislemTx.setOpsYonu(iMap.getString("TABLE", row, "OPS_YONU"));
					hznOpsiyonislemTx.setRiskIslemTipi(iMap.getString("TABLE", row, "KULLANIM"));
					hznOpsiyonislemTx.setKarsiDoviz(iMap.getString("TABLE", row, "KARSI_DOVIZ"));
					hznOpsiyonislemTx.setOpsStatus("KL");

					hznOpsiyonislemTx.setRiskTeminatOran(iMap.getBigDecimal("TABLE", row, "KALDIRAC_ORANI"));

				       HznOpsiyonislemTxId tid = new HznOpsiyonislemTxId();
				        tid.setReferans(iMap.getString("TABLE", row, "REFERANS"));
				        tid.setTxNo(iMap.getBigDecimal("TRX_NO"));
				        hznOpsiyonislemTx.setId(tid);
					
					
					session.saveOrUpdate(hznOpsiyonislemTx);
				}
			}
			
			if(updateSayisi==0)
				throw new GMRuntimeException(0, "Kay�t i�in en az bir g�ncelleme yap�lmal�d�r");
			session.flush();
			iMap.put("TRX_NAME", "1577");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1577_INITIALIZE")
	public static GMMap initialize1577(GMMap iMap) {

		String func = "{ ? = call PKG_TRN1577.YasayanOpsiyonListesi}";
		GMMap oMap = new GMMap();

		String param = "ALIS_SATIS";
		GuimlUtil.wrapMyCombo(oMap, param, null, null);
		GuimlUtil.wrapMyCombo(oMap, param, "A", "Banka Al��");
		GuimlUtil.wrapMyCombo(oMap, param, "S", "Banka Sat��");

		param = "OPS_SEKLI";
		GuimlUtil.wrapMyCombo(oMap, param, null, null);
		GuimlUtil.wrapMyCombo(oMap, param, "C", "CALL");
		GuimlUtil.wrapMyCombo(oMap, param, "P", "PUT");

		param = "OPS_TIPI";
		GuimlUtil.wrapMyCombo(oMap, param, null, null);
		GuimlUtil.wrapMyCombo(oMap, param, "AVR", "Avrupa");
		GuimlUtil.wrapMyCombo(oMap, param, "AMR", "Amerika");

		param = "KULLANIM";
		GuimlUtil.wrapMyCombo(oMap, param, null, "Seciniz");
		GuimlUtil.wrapMyCombo(oMap, param, "O", "Evet");
		GuimlUtil.wrapMyCombo(oMap, param, "D", "Hay�r");

		DALUtil.fillComboBox(oMap, "BAZ_DOVIZ", true, "SELECT ALL KOD, KOD FROM v_ml_gnl_doviz_kod_pr ORDER BY sira_no");

		try {
			oMap.put("TABLE", DALUtil.callOracleRefCursorFunction(func, "TABLE", new Object[0]).get("TABLE"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1577_GET_INFO")
	public static GMMap getInfo1577(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<HznOpsiyonislemTx> list = session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Iterator<HznOpsiyonislemTx> it = list.iterator();
			HznOpsiyonislemTx hznOpsiyonislemTx = null;
			int row = 0;
			while (it.hasNext()) {
				hznOpsiyonislemTx = it.next();
				oMap.put("TABLE", row, "REFERANS", hznOpsiyonislemTx.getId().getReferans());
				oMap.put("TABLE", row, "SUBE_PY_KOD", hznOpsiyonislemTx.getSubePyKod());
				oMap.put("TABLE", row, "MUSTERI_NO", hznOpsiyonislemTx.getMusteriNo());
				oMap.put("TABLE", row, "OPS_AMAC", hznOpsiyonislemTx.getOpsAmac());
				oMap.put("TABLE", row, "OPS_SEKLI_BAZ", hznOpsiyonislemTx.getOpsSekliBaz());
				oMap.put("TABLE", row, "HEDEF_FIYAT", hznOpsiyonislemTx.getHedefFiyat());
				oMap.put("TABLE", row, "BAZ_DVZ", hznOpsiyonislemTx.getBazDvz());
				oMap.put("TABLE", row, "BAZ_TUTAR", hznOpsiyonislemTx.getBazTutar());
				oMap.put("TABLE", row, "PRIM_MALIYET", hznOpsiyonislemTx.getPrimMaliyet());
				oMap.put("TABLE", row, "PRIM_MUSTERI", hznOpsiyonislemTx.getPrimMusteri());				
				oMap.put("TABLE", row, "TARIH_ISLEM", hznOpsiyonislemTx.getTarihIslem());
				oMap.put("TABLE", row, "TARIH_UZLASMA", hznOpsiyonislemTx.getTarihUzlasma());
				oMap.put("TABLE", row, "TARIH_VADE", hznOpsiyonislemTx.getTarihVade());
				oMap.put("TABLE", row, "OPS_TIPI", hznOpsiyonislemTx.getOpsTipi());
				oMap.put("TABLE", row, "KULLANIM", hznOpsiyonislemTx.getRiskIslemTipi());
				oMap.put("TABLE", row, "PARITE", hznOpsiyonislemTx.getBazDvz()+"/"+hznOpsiyonislemTx.getKarsiDoviz());
				oMap.put("TABLE", row, "KARSI_DOVIZ",hznOpsiyonislemTx.getKarsiDoviz());
				oMap.put("TABLE", row, "KALDIRAC_ORANI",hznOpsiyonislemTx.getRiskTeminatOran());
				oMap.put("TABLE", row, "OPS_YONU",hznOpsiyonislemTx.getOpsYonu());

			}

			return oMap;

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
}
