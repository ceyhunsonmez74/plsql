package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznAlinandepoTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1312Services {

		@GraymoundService("BNSPR_TRN1312_INITIALIZE")
		public static GMMap initialize(GMMap iMap){
			GMMap oMap = new GMMap();

			iMap.put("KOD", "HZN_DEPO_ISLEM_TURU");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("HZN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
		}
		
	@GraymoundService("BNSPR_TRN1312_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1311.Hzn_bilgiaktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1312_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAlinanDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAlinanDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAlinanDepoTx.getReferans());
			oMap.put("DEALER_NO", hznAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAlinanDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAlinanDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznAlinanDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznAlinanDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznAlinanDepoTx.getVadeSonuFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("YENILENENTUTAR", hznAlinanDepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznAlinanDepoTx.getEkTutar());
			oMap.put("YILFAIZTOPLAMI", hznAlinanDepoTx.getGecenYilFaizToplami());
			oMap.put("YENILENENREFERANS", hznAlinanDepoTx.getYenilenenReferans());
			if(hznAlinanDepoTx.getVadeTarihindeKapama() != null)
				if(hznAlinanDepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_POZ", hznAlinanDepoTx.getBirikmisFaizPoz());
			
			oMap.put("FAIZ_ORANI", hznAlinanDepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getGirisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getGirisHesapTuru(), hznAlinanDepoTx.getBankaMusteriNo(), hznAlinanDepoTx.getGirisHesapTuru(), 
					hznAlinanDepoTx.getGirisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getCikisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getCikisHesapTuru(), hznAlinanDepoTx.getBankaMusteriNo(), hznAlinanDepoTx.getCikisHesapTuru(), 
					hznAlinanDepoTx.getCikisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getBankaMusteriNo(), "1312/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAlinanDepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAlinanDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAlinanDepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("ANAPARA_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaOdemeSekli());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAlinanDepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_ENDEKS_KODU", hznAlinanDepoTx.getFaizEndeksKodu());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAlinanDepoTx.getFaizHesaplanacakTutar());
			oMap.put("ISLEM_TURU",hznAlinanDepoTx.getIslemTuru());
			
			/*
			 * Murabaha Detay Butonu aktif yada pasif olmasi
			 * */
			if (hznAlinanDepoTx.getMurabahaId()!=null)
			{
				oMap.put("MURABAHA_DETAY", true);
				
				//oMap.put("MURABAHA_ID", hznAlinanDepoTx.getMurabahaId());
			}
			else
				oMap.put("MURABAHA_DETAY", false);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1312_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAlinanDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznAlinanDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznAlinanDepoTx.getReferans());
			oMap.put("DEALER_NO", hznAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAlinanDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAlinanDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznAlinanDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznAlinanDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznAlinanDepoTx.getVadeSonuFaizTutari());
			oMap.put("ANAPARA_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaOdemeSekli());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAlinanDepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_ENDEKS_KODU", hznAlinanDepoTx.getFaizEndeksKodu());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAlinanDepoTx.getFaizHesaplanacakTutar());
			
			oMap.put("VADE_ISLEM_BILGISI", hznAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("YENILENENTUTAR", hznAlinanDepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznAlinanDepoTx.getEkTutar());
			oMap.put("YILFAIZTOPLAMI", hznAlinanDepoTx.getGecenYilFaizToplami());
			oMap.put("REFERANSYENI", hznAlinanDepoTx.getReferansYeni());
			if(hznAlinanDepoTx.getVadeTarihindeKapama() != null)
				if(hznAlinanDepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_POZ", hznAlinanDepoTx.getBirikmisFaizPoz());
			
			oMap.put("FAIZ_ORANI", hznAlinanDepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getGirisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getGirisHesapTuru(), hznAlinanDepoTx.getBankaMusteriNo(), hznAlinanDepoTx.getGirisHesapTuru(),
					hznAlinanDepoTx.getGirisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getCikisHesapNo(),hznAlinanDepoTx.getDovizKodu(),
					hznAlinanDepoTx.getCikisHesapTuru(), hznAlinanDepoTx.getBankaMusteriNo(), hznAlinanDepoTx.getCikisHesapTuru(), 
					hznAlinanDepoTx.getCikisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getBankaMusteriNo(), "1312/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAlinanDepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznAlinanDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAlinanDepoTx.getCikisMuhabirMusteriNo());
			oMap.put("ISLEM_TURU",hznAlinanDepoTx.getIslemTuru());
			
			/*
			 * Murabaha Detay Butonu aktif yada pasif olmasi
			 * */
			if (hznAlinanDepoTx.getMurabahaId()!=null)
			{
				oMap.put("MURABAHA_DETAY", true);
				oMap.put("MURABAHA_ID", hznAlinanDepoTx.getMurabahaId());
			}
				else
				oMap.put("MURABAHA_DETAY", false);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1312_SAVE")
	public static GMMap save(GMMap iMap) {
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAlinanDepoTx == null) {
				hznAlinanDepoTx = new HznAlinandepoTx();
			}
			
			hznAlinanDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAlinanDepoTx.setModulTurKod("HAZINE");
			hznAlinanDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAlinanDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAlinanDepoTx.setReferans(iMap.getString("REFERANS"));
			hznAlinanDepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznAlinanDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAlinanDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAlinanDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAlinanDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAlinanDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAlinanDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAlinanDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAlinanDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAlinanDepoTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznAlinanDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAlinanDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAlinanDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAlinanDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAlinanDepoTx.setVadeSonuFaizTutari(iMap.getBigDecimal("VADE_SONU_FAIZ_TUTARI"));
			hznAlinanDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAlinanDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAlinanDepoTx.setReferansYeni(iMap.getString("REFERANS_YENI"));
			hznAlinanDepoTx.setYenilenenTutar(iMap.getBigDecimal("YENILENEN_TUTAR"));
			if(iMap.getString("VADE_TARIHINDE_KAPAMA").toString().equals("false"))
				hznAlinanDepoTx.setVadeTarihindeKapama("H");
			else
				hznAlinanDepoTx.setVadeTarihindeKapama("E");
			hznAlinanDepoTx.setGecenYilFaizToplami(iMap.getBigDecimal("GECEN_YIL_FAIZ_TOPLAMI"));
			hznAlinanDepoTx.setBirikmisFaizPoz(iMap.getBigDecimal("BIRIKMIS_FAIZ_POZ"));
			hznAlinanDepoTx.setEkTutar(iMap.getBigDecimal("EK_TUTAR"));
			hznAlinanDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			if (iMap.getBigDecimal("MURABAHA_ID")!=null)
			hznAlinanDepoTx.setMurabahaId(iMap.getBigDecimal("MURABAHA_ID"));
			
			session.saveOrUpdate(hznAlinanDepoTx);
			session.flush();
			
			GMMap oMap = new GMMap();
			return oMap;
	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
	}
	
	@GraymoundService("BNSPR_TRN1312_TRANSACTION_START")
	public static Map<?, ?> trn1312Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1312");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	

}
