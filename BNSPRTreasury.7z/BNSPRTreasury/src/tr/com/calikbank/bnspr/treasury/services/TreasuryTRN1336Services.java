package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznNakitAkisManuelGunTx;
import tr.com.calikbank.bnspr.dao.HznNakitAkisManuelGunTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1336Services {

		@GraymoundService("BNSPR_TRN1336_SAVE")
		public static GMMap Save (GMMap iMap){
			try {
				Session session = DAOSession.getSession("BNSPRDal");
				String tableName = "CBS_NAKIT_AKISI_MANUEL_DTYISL";
				List<?> list = (List<?>) iMap.get(tableName);
				
				for (int i=0;i<list.size();i++){
					HznNakitAkisManuelGunTxId id = new HznNakitAkisManuelGunTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					if(iMap.getBigDecimal(tableName,i,"CASHID")!=null)
						id.setCashid(iMap.getBigDecimal(tableName,i,"CASHID"));
					else
						id.setCashid((new java.math.BigDecimal(i+1)));
					HznNakitAkisManuelGunTx hznNakitAkisManuelGunTx = (HznNakitAkisManuelGunTx)session.get(HznNakitAkisManuelGunTx.class, id);
					
					if(hznNakitAkisManuelGunTx == null) {
						hznNakitAkisManuelGunTx = new HznNakitAkisManuelGunTx();
					}
					hznNakitAkisManuelGunTx.setAciklama(iMap.getString(tableName,i,"ACIKLAMA"));
					hznNakitAkisManuelGunTx.setDoviz(iMap.getString(tableName,i,"DOVIZ"));
					hznNakitAkisManuelGunTx.setIslemKodu(iMap.getBigDecimal(tableName,i,"ISLEM_KODU"));
					hznNakitAkisManuelGunTx.setId(id);
					hznNakitAkisManuelGunTx.setModulTur("HAZINE");
					hznNakitAkisManuelGunTx.setMuhabirHesap(iMap.getBigDecimal(tableName,i,"MUHABIR_HESAP"));
					hznNakitAkisManuelGunTx.setMusteriNo(iMap.getBigDecimal(tableName,i,"MUSTERI_NO"));
					hznNakitAkisManuelGunTx.setTur(iMap.getString(tableName,i,"TUR"));
					hznNakitAkisManuelGunTx.setTutar(iMap.getBigDecimal(tableName,i,"TUTAR"));
					hznNakitAkisManuelGunTx.setValor(iMap.getDate(tableName,i,"VALOR"));
					if (iMap.getBoolean(tableName,i,"SIL")==true)
						hznNakitAkisManuelGunTx.setDurumKodu("S");
					else
					hznNakitAkisManuelGunTx.setDurumKodu(iMap.getString(tableName,i,"DURUM_KODU"));
					hznNakitAkisManuelGunTx.setUrunSinif("CUA");
					hznNakitAkisManuelGunTx.setUrunTur("CUA");
					session.saveOrUpdate(hznNakitAkisManuelGunTx);
					session.flush();
				}
				iMap.put("TRX_NAME", "1336");
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		@GraymoundService("BNSPR_TRN1336_GETINFO")
		public static GMMap getInfo (GMMap iMap){
			try {
				GMMap oMap = new GMMap();
				Session session = DAOSession.getSession("BNSPRDal");
			
				List<?> recordList = session.createCriteria(HznNakitAkisManuelGunTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();
				oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				String tableName = "CBS_NAKIT_AKISI_MANUEL_DTYISL";
				
				for (int row = 0; row < recordList.size(); row++) {
					HznNakitAkisManuelGunTx hznNakitAkisManuelGunTx = (HznNakitAkisManuelGunTx) recordList.get(row);
					String durum=hznNakitAkisManuelGunTx.getDurumKodu();
					if (durum.equals("S"))
						oMap.put(tableName, row, "SIL", true);
					else
						oMap.put(tableName, row, "SIL", false);
					oMap.put(tableName, row, "ACIKLAMA", hznNakitAkisManuelGunTx.getAciklama());
					oMap.put(tableName, row, "DOVIZ", hznNakitAkisManuelGunTx.getDoviz());
					oMap.put(tableName, row, "MUHABIR_HESAP", hznNakitAkisManuelGunTx.getMuhabirHesap());
					oMap.put(tableName, row, "MUSTERI_NO", hznNakitAkisManuelGunTx.getMusteriNo());
					oMap.put(tableName, row, "TUR", hznNakitAkisManuelGunTx.getTur());
					oMap.put(tableName, row, "TUTAR", hznNakitAkisManuelGunTx.getTutar());
					oMap.put(tableName, row, "VALOR", hznNakitAkisManuelGunTx.getValor());
					oMap.put(tableName, row, "REFERANS", hznNakitAkisManuelGunTx.getReferans());
					oMap.put(tableName, row, "ISLEM_KODU", hznNakitAkisManuelGunTx.getIslemKodu());
					oMap.put(tableName, row, "DURUM_KODU", hznNakitAkisManuelGunTx.getDurumKodu());
					oMap.put(tableName, row, "CASHID", hznNakitAkisManuelGunTx.getId().getCashid());
				}
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}
		
		@GraymoundService("BNSPR_TRN1336_TRANSFER_DATA")
		public static GMMap transferDate (GMMap iMap){
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			Session session = DAOSession.getSession("BNSPRDal");
			
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ ? =call PKG_TRN1336.BilgiAktar(?,?,?,?,?)}");
				int i = 1;
				stmt.registerOutParameter(i++, Types.NUMERIC);
				
				if(iMap.getDate("VALOR_TARIHI")== null)
					stmt.setDate(i++, null);
				else
					stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
				stmt.setString(i++, iMap.getString("DOVIZ"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASLANGIC_TUTAR"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BITIS_TUTAR"));
				stmt.setString(i++, iMap.getString("REFERANS"));
				stmt.execute();
				
				List<?> recordList = session.createCriteria(HznNakitAkisManuelGunTx.class)
				.add(Restrictions.eq("id.txNo", stmt.getBigDecimal(1)))
				.list();
				oMap.put("TRX_NO", stmt.getBigDecimal(1));
				String tableName = "CBS_NAKIT_AKISI_MANUEL_DTYISL";
				
				for (int row = 0; row < recordList.size(); row++) {
					HznNakitAkisManuelGunTx hznNakitAkisManuelGunTx = (HznNakitAkisManuelGunTx) recordList.get(row);
					oMap.put(tableName, row, "ACIKLAMA", hznNakitAkisManuelGunTx.getAciklama());
					oMap.put(tableName, row, "DOVIZ", hznNakitAkisManuelGunTx.getDoviz());
					oMap.put(tableName, row, "MUHABIR_HESAP", hznNakitAkisManuelGunTx.getMuhabirHesap());
					oMap.put(tableName, row, "MUSTERI_NO", hznNakitAkisManuelGunTx.getMusteriNo());
					oMap.put(tableName, row, "TUR", hznNakitAkisManuelGunTx.getTur());
					oMap.put(tableName, row, "TUTAR", hznNakitAkisManuelGunTx.getTutar());
					oMap.put(tableName, row, "VALOR", hznNakitAkisManuelGunTx.getValor());
					oMap.put(tableName, row, "REFERANS", hznNakitAkisManuelGunTx.getReferans());
					oMap.put(tableName, row, "ISLEM_KODU", hznNakitAkisManuelGunTx.getIslemKodu());
					oMap.put(tableName, row, "CASHID", hznNakitAkisManuelGunTx.getId().getCashid());
				}

				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
		
}
