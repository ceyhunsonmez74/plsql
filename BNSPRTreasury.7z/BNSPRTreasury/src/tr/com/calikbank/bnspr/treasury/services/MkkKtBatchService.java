package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferi;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferiTx;
import tr.com.aktifbank.bnspr.dao.MkkKiymetTransferiTxId;
import tr.com.aktifbank.bnspr.dao.MkkResponse;
import tr.com.aktifbank.integration.mkk.MkkClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.treasury.util.TreasuryUtil;
import tr.com.calikbank.bnspr.util.DALUtil; 
import tr.com.mkk.ws.schemas.instructionreturn.AsyncServiceResultType;
import tr.com.mkk.ws.schemas.instructionreturn.InstAsyncServiceResultResponseType;
import tr.com.mkk.ws.schemas.instructionreturn.InstAsyncServiceResultType;
import tr.com.mkk.ws.schemas.instructionreturn.InstMaxAsyncServiceOrderIdResponseType;
import tr.com.mkk.ws.schemas.instructionreturn.InstMaxAsyncServiceOrderIdResultType;
import tr.com.mkk.ws.schemas.instructionreturn.InstNextAsyncServiceResultResponseType;
import tr.com.mkk.ws.schemas.instructionreturn.InstNextAsyncServiceResultType;
import tr.com.mkk.ws.schemas.instructionreturn.InstPendingAsyncServiceResultCnt;
import tr.com.mkk.ws.schemas.instructionreturn.InstPendingAsyncServiceResultCntResponseType;
import tr.com.mkk.ws.schemas.instructionreturn.InstructionResultType;
import tr.com.mkk.ws.schemas.instructionreturn.InstructionReturnType;
import tr.com.mkk.ws.schemas.instructionreturn.MaxAsyncServiceOrderIdResultType;
import tr.com.mkk.ws.schemas.instructionreturn.NextAsyncServiceResultType;
import tr.com.mkk.ws.schemas.instructionreturn.PendingAsyncServiceResultCntType;
import tr.com.mkk.ws.schemas.mkkresponse.MkkResponseType;
import tr.com.mkk.ws.schemas.mkkresponse.ResponseType;
import tr.com.mkk.ws.schemas.securitytransfer.SecInfoType;
import tr.com.mkk.ws.schemas.securitytransfer.SecTransTradeType;
import tr.com.mkk.ws.schemas.types_1_0.InstAsyncServiceNameType;
import tr.com.mkk.ws.schemas.types_1_0.RequestHeaderType;
import tr.com.mkk.ws.schemas.types_1_0.ResponseHeaderType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MkkKtBatchService {

	private static final Logger logger = Logger.getLogger(MkkKtBatchService.class);
	
	private enum Services {
		BNSPR_MKK_INST_ASYNC_RESULT_SERVICE("IR"), 
		BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE("INR"), 
		BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE("IC"), 
		BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE("IMO");
		private final String stringValue;

		Services(final String s) {
			stringValue = s;
		}

		public String toString() {
			return stringValue;
		}
		
		public String getKodAdi() {
			return "MKK_" + stringValue + "_ID";
		}
	}

	@GraymoundService("BNSPR_MKK_KT_BATCH_SERVICE")
	public static GMMap mkkCallKtServices(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap xMap = new GMMap();
		xMap.put("BATCH_NAME", "MKK_KT_BATCH_RUNNING_FLAG");
		String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
		boolean iAmRunning = false;
		try {
			if ("E".equals(runningFlag)) {
				logger.info("[BNSPR_MKK_KT_BATCH_SERVICE] batch is already running, can't run parallel...");
				oMap.put("HATA_NO", new BigDecimal(660));
				oMap.put("P1", "Devam eden MKK K�ymet Transferi batch i�lemi bulunmaktad�r!");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
			}
			else {
				xMap = new GMMap();
				xMap.put("BATCH_NAME", "MKK_KT_BATCH_RUNNING_FLAG");
				xMap.put("BATCH_DEGER", "\"1\"");
				GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
				logger.info("[BNSPR_MKK_KT_BATCH_SERVICE] MKK_KT_BATCH_RUNNING_FLAG has been set to [1]");
				iAmRunning = true;
			}
			logger.info("MKK K�ymet Transferi Batch �al��maya ba�lad�:[BNSPR_MKK_KT_BATCH_SERVICE]");
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(MkkKiymetTransferi.class).add(Restrictions.eq("durum", "G")).addOrder(Order.asc("ktId"));
			List<?> list = criteria.list();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MkkKiymetTransferi ktGon = (MkkKiymetTransferi) iterator.next();

				logger.info("[BNSPR_MKK_KT_BATCH_SERVICE] g�nderilecek kay�t:" + ktGon.getKtId());

				SecTransTradeType secTransTrade = new SecTransTradeType();
				SecInfoType secInfo = new SecInfoType();
				secInfo.setAmount(new BigDecimal(ktGon.getAmount()));
				secInfo.setEarliestExecutionTime(ktGon.getEarliestExecTime());
				secInfo.setExpiryDate(ktGon.getExpiryDate());
				secInfo.setIsin(ktGon.getIsin());
				secInfo.setLastExecutionTime(ktGon.getLastExecTime());
				secInfo.setMic(ktGon.getMic());
				secInfo.setPriority(new Integer(ktGon.getPriority()));
				secInfo.setProcessDate(ktGon.getProcessDate());
				secInfo.setProcessType(ktGon.getProcessType());
				if (ktGon.getPurchasingCost() != null) {
					secInfo.setPurchasingCost(new BigDecimal(ktGon.getPurchasingCost()));
				}
				secInfo.setPurchasingDate(ktGon.getPurchasingDate());
				secInfo.setRcvAccNo(ktGon.getRcvAccNo());
				secInfo.setRcvInvsName(ktGon.getRcvInvsName());
				secInfo.setRcvInvsRegNo(ktGon.getRcvInvsRegNo());
				secInfo.setRcvInvsSurname(ktGon.getRcvInvsSurname());
				secInfo.setRcvInvsTitlle(ktGon.getRcvInvsTitle());
				secInfo.setRcvMemberCode(ktGon.getRcvMemberCode());
				secInfo.setRcvSubAccNo(ktGon.getRcvSubAccNo());
				secInfo.setReasonCode(ktGon.getReasonCode());
				secInfo.setSecAddDefCode(ktGon.getSecAddDefCode());
				secInfo.setSendAccNo(ktGon.getSendAccNo());
				secInfo.setSendInvsDesc(ktGon.getSendInvsDesc());
				secInfo.setSendInvsTaxNo(ktGon.getSendInvsTaxNo());
				secInfo.setSendMemberCode(ktGon.getSendMemberCode());
				secInfo.setSendMemberDesc(ktGon.getSendMemberDesc());
				secInfo.setSendSubAccNo(ktGon.getSendSubAccNo());
				if (ktGon.getTaxRate() != null) {
					secInfo.setTaxRate(new BigDecimal(ktGon.getTaxRate()));
				}
				secInfo.setValueDate(ktGon.getValueDate());

				secTransTrade.setSecInfo(secInfo);

				RequestHeaderType reqHeader = new RequestHeaderType();
				reqHeader.setSenderMember(ktGon.getSenderMember());
				reqHeader.setSenderReference(ktGon.getSenderReference());

				secTransTrade.setRequestHeader(reqHeader);

				MkkResponseType response = MkkClient.getMkkSecurityTransferService().secTransTrade(secTransTrade);

				logger.info("[BNSPR_MKK_KT_BATCH_SERVICE] g�nderildi, ID:" + ktGon.getKtId());
				MkkHaKeBatchService.saveMkkResponse(response);

				if (response != null) {
					ResponseType responseType = response.getResponse();
					logger.info("[BNSPR_MKK_KT_BATCH_SERVICE] ID:[" + ktGon.getKtId() + "], response code:[" + responseType.getResponseCode() + "], response desc:[" + responseType.getResponseDesc() + "]");

					MkkKiymetTransferiTx ktx = createNewKtxPojo(ktGon);

					BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
					if ("0000".equals(responseType.getResponseCode())) {
						ktx.setDurum("A"); // Ba�ar�l� G�nderildi
					}
					else {
						ktx.setDurum("H"); // Ba�ar�s�z Hatal�
					}

					ktx.setResponseCode(responseType.getResponseCode());
					ktx.setResponseDesc(responseType.getResponseDesc());
					ktx.getId().setTxNo(txNo);
					session.save(ktx);
					session.flush();
					iMap.clear();
					iMap.put("TRX_NAME", "1703");
					iMap.put("TRX_NO", txNo);
					oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			if (iAmRunning) { // Batchi �al��t�ran bensem i�im bitti�inde sonland�rmal�y�m
				xMap = new GMMap();
				xMap.put("BATCH_NAME", "MKK_KT_BATCH_RUNNING_FLAG");
				xMap.put("BATCH_DEGER", "\"0\"");
				GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
				logger.info("[BNSPR_MKK_KT_BATCH_SERVICE] MKK_KT_BATCH_RUNNING_FLAG has been set to [0]");
			}
			logger.info("MKK K�ymet Transferi Batch tamamland�, [BNSPR_MKK_KT_BATCH_SERVICE]");
		}
		return oMap;
	}
	
	/***
     * InstructionReturn
	 * Servislerinin sonu�lar�n� alan servis
     * @param iMap
     * @return
     */
    @GraymoundService("BNSPR_MKK_INST_RESULT_SERVICE")
    public static GMMap mkkCallAccountResultService(GMMap iMap){
        GMMap oMap = new GMMap();
		GMMap xMap = new GMMap();
        xMap.put("BATCH_NAME" , "MKK_KT_RSLT_BATCH_RUNNING_FLAG");
        String runningFlag = GMServiceExecuter.execute("BNSPR_MKK_BATCH_RUNNING", xMap).get("RUNNING").toString();
        boolean iAmRunning = false;
        try { 
        	if("E".equals(runningFlag)){ 
                logger.info("[BNSPR_MKK_INST_RESULT_SERVICE] batch is already running, can't run parallel...");
                oMap.put("HATA_NO", new BigDecimal(660));
                oMap.put("P1", "Devam eden MKK K�ymet Transferi Sonu� batch i�lemi bulunmaktad�r!");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
            }
            else{
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_KT_RSLT_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"1\"");
                GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_INST_RESULT_SERVICE] MKK_KT_RSLT_BATCH_RUNNING_FLAG has been set to [1]");
                iAmRunning = true;
            }
        	iMap.put("SERVICE_NAME", InstAsyncServiceNameType.INSTRUCTION_RETURN.value());
        	logger.info(iMap.getString("SERVICE_NAME") + " Sonu�lar� al�nmaya ba�land�.");
        	iMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE", iMap));
        	int result = 0;
        	if(iMap.getBigDecimal("COUNT") != null){
        		result = iMap.getBigDecimal("COUNT").intValue();
        	}
        	logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE] al�nacak kay�t:" + result);
        	if(result > 0){        		
        		iMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE", iMap));
        		logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE] max order id:" + iMap.getBigDecimal("MAX_OID").intValue());
	            for (int i = 1; i <= result; i++){
	            	iMap.put("ORDER_ID", new BigDecimal(iMap.getBigDecimal("MAX_OID").intValue()+i));
	            	oMap.putAll(GMServiceExecuter.executeNT("BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE", iMap));
	            }
	            KiymetTransferleriDurumGuncellemesi();
        	}else{
        		oMap.put("MESSAGE", "Sorgulanacak k�ymet transferi yoktur.");
        	}
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }finally{
        	if (iAmRunning){ //Batchi �al��t�ran bensem i�im bitti�inde sonland�rmal�y�m
                xMap = new GMMap();
                xMap.put("BATCH_NAME" , "MKK_KT_RSLT_BATCH_RUNNING_FLAG");
                xMap.put("BATCH_DEGER" , "\"0\"");
                GMServiceExecuter.executeNT("BNSPR_MKK_BATCH_START_STOP_FLAG", xMap);
                logger.info("[BNSPR_MKK_INST_RESULT_SERVICE] MKK_KT_RSLT_BATCH_RUNNING_FLAG has been set to [0]");
            }
        	logger.info("MKK K�ymet Transferi Sonu� Alma Servisi tamamland�, [BNSPR_MKK_INST_RESULT_SERVICE]");
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE")
    public static GMMap mkkInstNextAsyncResultService(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
			logger.info("[BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE] �al��maya ba�lad�.");
    		InstNextAsyncServiceResultType request =  new InstNextAsyncServiceResultType();
    		NextAsyncServiceResultType type = new NextAsyncServiceResultType();
    		type.setMemberId("AFB");
    		type.setOrderId(iMap.getString("ORDER_ID"));
    		type.setProcessDate(new SimpleDateFormat("yyyyMMdd").format(new Date()));
    		type.setServiceName(InstAsyncServiceNameType.fromValue(iMap.getString("SERVICE_NAME")));
    		request.setNextAsyncServiceResult(type);
    		RequestHeaderType requestHeader = new RequestHeaderType();
    		requestHeader.setSenderMember("AFB");
    		requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE));
    		request.setRequestHeader(requestHeader);
    		InstNextAsyncServiceResultResponseType response = MkkClient.getInstructionReturn().instNextAsyncServiceResult(request);
    		saveMkkResponse(response);
    		if(response != null && response.getResponse() != null){
				GMMap sMap = new GMMap();
				sMap.put("ServiceName", response.getResponse().getServiceName());
				sMap.put("OrderId", response.getResponse().getOrderId());
				sMap.put("ReferenceKey", response.getResponse().getReferenceKey());
				if (response.getResponse().getInstructionReturn() != null) {
					instructionReturn(response.getResponse().getInstructionReturn(), sMap);
				}
			}else{
				oMap.put("MESSAGE", "BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE servisi hata ald�.");   
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			logger.info("[BNSPR_MKK_INST_NEXT_ASYNC_RESULT_SERVICE] �al��may� bitirdi.");
		}
		return oMap;
    }

	@GraymoundService("BNSPR_MKK_INST_ASYNC_RESULT_SERVICE")
    public static GMMap mkkInstAsyncResultService(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_SERVICE] �al��maya ba�lad�.");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE", iMap));
			if (oMap.getBigDecimal("COUNT").compareTo(new BigDecimal(0)) > 0) {
				InstAsyncServiceResultType request = new InstAsyncServiceResultType();
				AsyncServiceResultType type = new AsyncServiceResultType();
				type.setReferenceKey(iMap.getString("REFERENCE_KEY"));
				request.setAsyncServiceResult(type);
				RequestHeaderType requestHeader = new RequestHeaderType();
				requestHeader.setSenderMember("AFB");
				requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_INST_ASYNC_RESULT_SERVICE));
				request.setRequestHeader(requestHeader);
				InstAsyncServiceResultResponseType response = MkkClient.getInstructionReturn().instAsyncServiceResult(request);
				saveMkkResponse(response);
				if (response != null){
					if (response.getResponse() != null){
						GMMap sMap = new GMMap();
						sMap.put("ServiceName", response.getResponse().getServiceName());
						sMap.put("OrderId", response.getResponse().getOrderId());
						sMap.put("ReferenceKey", response.getResponse().getReferenceKey());
						if(!response.getResponse().getResponseCode().equals("0000")){
							oMap.put("MESSAGE", "BNSPR_MKK_INST_ASYNC_RESULT_SERVICE servisi hata ald�: "+response.getResponse().getResponseDesc());
						}else if (response.getResponse().getInstructionReturn() != null) {
							instructionReturn(response.getResponse().getInstructionReturn(), sMap);
						}
					}
				}else{
					oMap.put("MESSAGE", "BNSPR_MKK_INST_ASYNC_RESULT_SERVICE servisi hata ald�.");   
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_SERVICE] �al��may� bitirdi.");
		}
		return oMap;
    }
	
	@GraymoundService("BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE")
	public static GMMap mkkPendingResultCount(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE] �al��maya ba�lad�.");
			InstPendingAsyncServiceResultCnt request = new InstPendingAsyncServiceResultCnt();

			PendingAsyncServiceResultCntType type = new PendingAsyncServiceResultCntType();
			type.setMemberId("AFB");
			type.setProcessDate(new SimpleDateFormat("yyyyMMdd").format(new Date()));
			type.setServiceName(InstAsyncServiceNameType.fromValue(iMap.getString("SERVICE_NAME")));
			request.setPendingAsyncServiceResultCnt(type);

			RequestHeaderType requestHeader = new RequestHeaderType();
			requestHeader.setSenderMember("AFB");
			requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE));
			request.setRequestHeader(requestHeader);
			
			InstPendingAsyncServiceResultCntResponseType response = MkkClient.getInstructionReturn().instPendingAsyncServiceResultCnt(request);
			saveMkkResponse(response, iMap);
			if (response != null){
				if (response.getResponse() != null){
					if(!response.getResponse().getResponseCode().equals("0000")){
						oMap.put("MESSAGE", "BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE servisi hata ald�: "+response.getResponse().getResponseDesc());
					}else if (response.getResponse().getPendingResultCount() != null) {
						oMap.put("COUNT", response.getResponse().getPendingResultCount());
					}
				}
			}else{
				oMap.put("MESSAGE", "BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE servisi hata ald�.");   
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_CNT_SERVICE] �al��may� bitirdi.");
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE")
	public static GMMap mkkPendingResultMaxOrderId(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE] �al��maya ba�lad�.");
			InstMaxAsyncServiceOrderIdResultType request = new InstMaxAsyncServiceOrderIdResultType();

			MaxAsyncServiceOrderIdResultType type = new MaxAsyncServiceOrderIdResultType();
			type.setMemberId("AFB");
			type.setProcessDate(new SimpleDateFormat("yyyyMMdd").format(new Date()));
			type.setServiceName(InstAsyncServiceNameType.fromValue(iMap.getString("SERVICE_NAME")));
			request.setMaxAsyncServiceOrderIdResult(type);

			RequestHeaderType requestHeader = new RequestHeaderType();
			requestHeader.setSenderMember("AFB");
			requestHeader.setSenderReference(getSenderReference(Services.BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE));
			request.setRequestHeader(requestHeader);

			InstMaxAsyncServiceOrderIdResponseType response = MkkClient.getInstructionReturn().instMaxAsyncServiceOrderId(request);
			saveMkkResponse(response, iMap);
			if (response != null){
				if (response.getResponse() != null){
					if(!response.getResponse().getResponseCode().equals("0000")){
						oMap.put("MESSAGE", "BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE servisi hata ald�: "+response.getResponse().getResponseDesc());
					}else if (response.getResponse().getMaxOrderId() != null) {
						oMap.put("MAX_OID", response.getResponse().getMaxOrderId());
					}
				}
			}else{
				oMap.put("MESSAGE", "BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE servisi hata ald�.");   
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			logger.info("[BNSPR_MKK_INST_ASYNC_RESULT_MAX_OID_SERVICE] �al��may� bitirdi.");
		}
		return oMap;
	}
	
	public static MkkKiymetTransferiTx createNewKtxPojo(MkkKiymetTransferi kt) {
		MkkKiymetTransferiTx ktx = new MkkKiymetTransferiTx();
		MkkKiymetTransferiTxId ktxId = new MkkKiymetTransferiTxId();

		ktx.setId(ktxId);
		ktx.getId().setKtId(kt.getKtId());
		ktx.setHaId(kt.getHaId());
		ktx.setSenderMember(kt.getSenderMember());
		ktx.setSenderReference(kt.getSenderReference());
		ktx.setProcessType(kt.getProcessType());
		ktx.setProcessDate(kt.getProcessDate());
		ktx.setValueDate(kt.getValueDate());
		ktx.setSendMemberCode(kt.getSendMemberCode());
		ktx.setSendAccNo(kt.getSendAccNo());
		ktx.setSendSubAccNo(kt.getSendSubAccNo());
		ktx.setSendMemberDesc(kt.getSendMemberDesc());
		ktx.setSendInvsDesc(kt.getSendInvsDesc());
		ktx.setRcvMemberCode(kt.getRcvMemberCode());
		ktx.setRcvAccNo(kt.getRcvAccNo());
		ktx.setRcvSubAccNo(kt.getRcvSubAccNo());
		ktx.setRcvInvsName(kt.getRcvInvsName());
		ktx.setRcvInvsSurname(kt.getRcvInvsSurname());
		ktx.setRcvInvsTitle(kt.getRcvInvsTitle());
		ktx.setRcvInvsRegNo(kt.getRcvInvsRegNo());
		ktx.setMic(kt.getMic());
		ktx.setIsin(kt.getIsin());
		ktx.setSecAddDefCode(kt.getSecAddDefCode());
		ktx.setAmount(kt.getAmount());
		ktx.setReasonCode(kt.getReasonCode());
		ktx.setEarliestExecTime(kt.getEarliestExecTime());
		ktx.setExpiryDate(kt.getExpiryDate());
		ktx.setLastExecTime(kt.getLastExecTime());
		ktx.setPriority(kt.getPriority());
		ktx.setSendInvsTaxNo(kt.getSendInvsTaxNo());
		ktx.setPurchasingDate(kt.getPurchasingDate());
		ktx.setPurchasingCost(kt.getPurchasingCost());
		ktx.setTaxRate(kt.getTaxRate());
		ktx.setMusteriNo(kt.getMusteriNo());
		ktx.setIslemKod(kt.getIslemKod());
		ktx.setReferans(kt.getReferans());
		ktx.setGeriAlisReferans(kt.getGeriAlisReferans());
		ktx.setServiceName(kt.getServiceName());
		ktx.setOrderId(kt.getOrderId());
		ktx.setReferenceKey(kt.getReferenceKey());

		return ktx;
	}

	public static void KiymetTransferleriDurumGuncellemesi() {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1703.Update_Kiymet_Transfer_Durum}");
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static String getSenderReference(Services key) {
		return key.toString() + "-" + TreasuryUtil.getGenelKodAl(key.getKodAdi());
	}
	
	private static MkkResponseType instructionReturn(InstructionReturnType instructionReturn, GMMap iMap) {

		logger.info("..............MKK Instruction Return request received..............");
		if (instructionReturn.getResponseHeader() != null) {
			logger.info("instructionReturn.responseHeader.senderReference => " + instructionReturn.getResponseHeader().getSenderReference());
			logger.info("instructionReturn.responseHeader.receiverMember => " + instructionReturn.getResponseHeader().getReceiverMember());
			logger.info("instructionReturn.responseHeader.tid => " + instructionReturn.getResponseHeader().getTid());
			logger.info("instructionReturn.responseHeader.messageId => " + instructionReturn.getResponseHeader().getMessageId());
			logger.info("instructionReturn.responseHeader.mkkSenderReference => " + instructionReturn.getResponseHeader().getMkkSenderReference());
		}

		MkkResponseType response = new MkkResponseType();

		ResponseHeaderType header = new ResponseHeaderType();
		if (instructionReturn.getResponseHeader() != null) {
			header.setSenderReference(instructionReturn.getResponseHeader().getSenderReference());
			header.setReceiverMember(instructionReturn.getResponseHeader().getReceiverMember());
			header.setTid(instructionReturn.getResponseHeader().getTid());
			header.setMessageId(instructionReturn.getResponseHeader().getMessageId());
			header.setMkkSenderReference(instructionReturn.getResponseHeader().getMkkSenderReference());
		}
		response.setResponseHeader(header);

		ResponseType responseType = new ResponseType();
		response.setResponse(responseType);

		try {
			ResponseHeaderType resHeader = instructionReturn.getResponseHeader();
			InstructionResultType resType = instructionReturn.getInstructionResult();

			if (resHeader != null) {
				logger.info("resHeader.getReceiverMember:" + resHeader.getReceiverMember());
				logger.info("resHeader.getSenderReference:" + resHeader.getSenderReference());
				logger.info("resHeader.getTid:" + resHeader.getTid());
				logger.info("resHeader.getMessageId:" + resHeader.getMessageId());
				logger.info("resHeader.getMkkSenderReference:" + resHeader.getMkkSenderReference());

				iMap.put("ReceiverMember", resHeader.getReceiverMember());
				iMap.put("SenderReference", resHeader.getSenderReference());
				iMap.put("Tid", resHeader.getTid());
				iMap.put("MessageId", resHeader.getMessageId());
				iMap.put("MkkSenderReference", resHeader.getMkkSenderReference());
			}

			if (resType != null) {
				logger.info("resType.getMsgSeqNo:" + resType.getMsgSeqNo());
				logger.info("resType.getInstCode:" + resType.getInstCode());
				logger.info("resType.getInstId:" + resType.getInstId());
				logger.info("resType.getInstDate:" + resType.getInstDate());
				logger.info("resType.getInstTime:" + resType.getInstTime());
				logger.info("resType.getInstStat:" + resType.getInstStat());
				logger.info("resType.getTransferDate:" + resType.getTransferDate());
				logger.info("resType.getTransferTime:" + resType.getTransferTime());
				logger.info("resType.getAmount:" + resType.getAmount());
				logger.info("resType.getRemainder:" + resType.getRemainder());
				logger.info("resType.getSendMemberCode:" + resType.getSendMemberCode());
				logger.info("resType.getSendAccNo:" + resType.getSendAccNo());
				logger.info("resType.getSendSubAccNo:" + resType.getSendSubAccNo());
				logger.info("resType.getRcvMemberCode:" + resType.getRcvMemberCode());
				logger.info("resType.getRcvAccNo:" + resType.getRcvAccNo());
				logger.info("resType.getRcvSubAccNo:" + resType.getRcvSubAccNo());
				logger.info("resType.getMic:" + resType.getMic());
				logger.info("resType.getIsin:" + resType.getIsin());
				logger.info("resType.getSecAddDefCode:" + resType.getSecAddDefCode());
				logger.info("resType.getSendInvsTaxNo:" + resType.getSendInvsTaxNo());
				logger.info("resType.getPurchasingCost:" + resType.getPurchasingCost());
				logger.info("resType.getPurchasingDate:" + resType.getPurchasingDate());
				logger.info("resType.getTaxRate:" + resType.getTaxRate());

				iMap.put("MsgSeqNo", resType.getMsgSeqNo());
				iMap.put("InstCode", resType.getInstCode());
				iMap.put("InstId", resType.getInstId());
				iMap.put("InstDate", resType.getInstDate());
				iMap.put("InstTime", resType.getInstTime());
				iMap.put("InstStat", resType.getInstStat());
				iMap.put("TransferDate", resType.getTransferDate());
				iMap.put("TransferTime", resType.getTransferTime());
				iMap.put("Amount", resType.getAmount());
				iMap.put("Remainder", resType.getRemainder());
				iMap.put("SendMemberCode", resType.getSendMemberCode());
				iMap.put("SendAccNo", resType.getSendAccNo());
				iMap.put("SendSubAccNo", resType.getSendSubAccNo());
				iMap.put("RcvMemberCode", resType.getRcvMemberCode());
				iMap.put("RcvAccNo", resType.getRcvAccNo());
				iMap.put("RcvSubAccNo", resType.getRcvSubAccNo());
				iMap.put("Mic", resType.getMic());
				iMap.put("Isin", resType.getIsin());
				iMap.put("SecAddDefCode", resType.getSecAddDefCode());
				iMap.put("SendInvsTaxNo", resType.getSendInvsTaxNo());
				iMap.put("PurchasingCost", resType.getPurchasingCost());
				iMap.put("PurchasingDate", resType.getPurchasingDate());
				iMap.put("TaxRate", resType.getTaxRate());
			}

			logger.info("Calling service: BNSPR_TRN1703_GET_KT_RESPONSE");
			GMMap resultMap = GMServiceExecuter.call("BNSPR_TRN1703_GET_KT_RESPONSE", iMap);
			logger.info("response code:" + resultMap.getString("RESPONSE_CODE"));
			logger.info("response desc:" + resultMap.getString("RESPONSE_DESC"));
			logger.info("End of service: BNSPR_TRN1703_GET_KT_RESPONSE");

			response.getResponse().setResponseCode(resultMap.getString("RESPONSE_CODE"));
			response.getResponse().setResponseDesc(resultMap.getString("RESPONSE_DESC"));

			logger.info("MemberServices.instructionReturn response parametreleri set edildi");
		}
		catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex);
			response.getResponse().setResponseCode("9999");
			response.getResponse().setResponseDesc("internal error");
		}

		logger.info("..............End of MKK Instruction Return request..............");
		return response;
	}
	
	public static void saveMkkResponse(InstPendingAsyncServiceResultCntResponseType response, GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(MkkHaKeBatchService.newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(iMap.getString("SERVICE_NAME"));
            mkkPojo.setCountOrMaxOid(response.getResponse().getPendingResultCount());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    public static void saveMkkResponse(InstMaxAsyncServiceOrderIdResponseType response, GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(MkkHaKeBatchService.newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(iMap.getString("SERVICE_NAME"));
            mkkPojo.setCountOrMaxOid(response.getResponse().getMaxOrderId());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    
    public static void saveMkkResponse(InstNextAsyncServiceResultResponseType response){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(MkkHaKeBatchService.newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(response.getResponse().getServiceName());
            mkkPojo.setOrderId(response.getResponse().getOrderId());
            mkkPojo.setReferenceKey(response.getResponse().getReferenceKey());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }
    
    public static void saveMkkResponse(InstAsyncServiceResultResponseType response){
        Session session = DAOSession.getSession("BNSPRDal");
        MkkResponse mkkPojo = new MkkResponse();
        try{
            mkkPojo.setId(MkkHaKeBatchService.newId("MKK_RESPONSE"));
            mkkPojo.setReceiverMember(response.getResponseHeader().getReceiverMember());
            mkkPojo.setSenderReference(response.getResponseHeader().getSenderReference());
            mkkPojo.setTid(response.getResponseHeader().getTid());
            mkkPojo.setMessageId(response.getResponseHeader().getMessageId());
            mkkPojo.setMkkSenderReference(response.getResponseHeader().getMkkSenderReference());
            mkkPojo.setResponseCode(response.getResponse().getResponseCode());
            mkkPojo.setResponseDesc(response.getResponse().getResponseDesc());
            mkkPojo.setServiceName(response.getResponse().getServiceName());
            mkkPojo.setOrderId(response.getResponse().getOrderId());
            mkkPojo.setReferenceKey(response.getResponse().getReferenceKey());
            
            session.save(mkkPojo);
            session.flush();
        }
        catch(Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        finally{
            logger.info("..............MKK Response received..............");
            logger.info("responseHeader.receiverMember => "+ response.getResponseHeader().getReceiverMember());
            logger.info("responseHeader.senderReference => "+ response.getResponseHeader().getSenderReference());
            logger.info("responseHeader.tid => "+ response.getResponseHeader().getTid());
            logger.info("responseHeader.messageId => "+ response.getResponseHeader().getMessageId());
            logger.info("responseHeader.mkkSenderReference => "+ response.getResponseHeader().getMkkSenderReference());
            logger.info("response.responseCode => "+ response.getResponse().getResponseCode());
            logger.info("response.responseDesc => "+ response.getResponse().getResponseDesc());
            logger.info("..............End Of MKK Response..............");
        }
    }

}
