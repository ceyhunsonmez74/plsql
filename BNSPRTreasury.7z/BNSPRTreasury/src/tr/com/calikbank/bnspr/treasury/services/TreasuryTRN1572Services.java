package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonPrimPrmTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonPrimPrmTxId;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonRiskPrmTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonRiskPrmTxId;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTeminatTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTeminatTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1572Services {

	@GraymoundService("BNSPR_TRN1572_INITIALIZE")
	public static GMMap initialize1572(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			String tableName = "PRIM";
			int i = 0;
			
			

			String func = "{? = call  bnspr.pkg_trn1572.GetPrimList()}";
			Object[] inputValues = new Object[0];

			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			oMap.putAll(resultMap);
			func = "{? = call  pkg_trn1572.GetRiskList()}";
			tableName = "RISK";
			resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			oMap.putAll(resultMap);
			 
			
			
			func = "{ call  pkg_trn1572.GetCatiLimitBilgileri(?,?,?)}";
 
			
             
              Object [] input  = new Object[] { };
            Object [] output = new Object[] {BnsprType.NUMBER,"pn_cati1",BnsprType.NUMBER,"pn_cati2",BnsprType.NUMBER,"pn_cati3"};
            /*
             * 
       Procedure GetMusteriDetay(pn_must_no number, pn_py_no out number, pc_py_isim out varchar, pn_ana_sube out number, pc_ana_sube_isim out varchar,
       pn_kullanici_sube_kod out varchar2, pc_kullanici_sube_adi out varchar2 ) is
             */
            
            try {
               GMMap  oMap2 = (GMMap) DALUtil.callOracleProcedure(func, input, output);
               oMap.put("CATI_LIMIT" ,oMap2.getBigDecimal("pn_cati1"));
            }
               catch (Exception e) {
                   throw ExceptionHandler.convertException(e);
               }

 

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1572_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		Session session = DAOSession.getSession("BNSPRDal");

		HznOpsiyonPrimPrmTx hznOpsiyonPrimPrmTx = (HznOpsiyonPrimPrmTx) session.createCriteria(HznOpsiyonPrimPrmTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		
		if (hznOpsiyonPrimPrmTx == null) {
			hznOpsiyonPrimPrmTx = new HznOpsiyonPrimPrmTx();
		}

		HznOpsiyonRiskPrmTx hznOpsiyonRiskPrmTx = (HznOpsiyonRiskPrmTx) session.createCriteria(HznOpsiyonRiskPrmTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		;
		if (hznOpsiyonRiskPrmTx == null) {
			hznOpsiyonRiskPrmTx = new HznOpsiyonRiskPrmTx();
		}

		HznOpsiyonRiskPrmTxId hznOpsiyonRiskPrmTxId = new HznOpsiyonRiskPrmTxId();
		HznOpsiyonPrimPrmTxId hznOpsiyonPrimPrmTxId = new HznOpsiyonPrimPrmTxId();
		int row = 0;

		while (row < iMap.getSize("PRIM")) {
			hznOpsiyonPrimPrmTx = new HznOpsiyonPrimPrmTx ();
			hznOpsiyonPrimPrmTxId = new HznOpsiyonPrimPrmTxId();
			hznOpsiyonPrimPrmTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznOpsiyonPrimPrmTxId.setGun1(iMap.getBigDecimal("PRIM", row, "GUN1"));
			hznOpsiyonPrimPrmTxId.setGun2(iMap.getBigDecimal("PRIM", row, "GUN2"));
			hznOpsiyonPrimPrmTx.setDovizDiger(iMap.getBigDecimal("PRIM", row, "DOVIZ_DIGER"));
			hznOpsiyonPrimPrmTx.setDovizGrup1(iMap.getBigDecimal("PRIM", row, "DOVIZ_GRUP1"));
			hznOpsiyonPrimPrmTx.setDovizGrup2(iMap.getBigDecimal("PRIM", row, "DOVIZ_GRUP2"));
			hznOpsiyonPrimPrmTx.setId(hznOpsiyonPrimPrmTxId);
			session.saveOrUpdate(hznOpsiyonPrimPrmTx);

			row++;

		}

		row = 0;
		while (row < iMap.getSize("RISK")) {
			hznOpsiyonRiskPrmTxId = new HznOpsiyonRiskPrmTxId();
			hznOpsiyonRiskPrmTx = new HznOpsiyonRiskPrmTx(); 
			hznOpsiyonRiskPrmTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznOpsiyonRiskPrmTxId.setKod(iMap.getString("RISK", row, "KOD"));
			hznOpsiyonRiskPrmTx.setId(hznOpsiyonRiskPrmTxId);
			hznOpsiyonRiskPrmTx.setFarklidoviz(iMap.getBigDecimal("RISK", row, "FARKLIDOVIZ"));
			hznOpsiyonRiskPrmTx.setEkteminat(iMap.getBigDecimal("RISK", row, "EKTEMINAT"));
			hznOpsiyonRiskPrmTx.setIsim(iMap.getString("RISK", row, "ISIM"));
			session.saveOrUpdate(hznOpsiyonRiskPrmTx);
			row++;
		}
		HznOpsiyonislemTeminatTx gp = (HznOpsiyonislemTeminatTx) session.createCriteria(HznOpsiyonislemTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        if (gp == null) {
            gp = new HznOpsiyonislemTeminatTx();
        }
        HznOpsiyonislemTeminatTxId tid = new HznOpsiyonislemTeminatTxId();
        tid.setTxNo(iMap.getBigDecimal("TRX_NO"));
        tid.setSira(   new BigDecimal(0));
        tid.setReferans("CATI_LIMIT");
		gp.setTutari(iMap.getBigDecimal("CATI_LIMIT"));
		gp.setId(tid);
		session.saveOrUpdate(gp);
		session.flush();
		iMap.put("TRX_NAME", "1572");
        return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    

	}

	@GraymoundService("BNSPR_TRN1572_GET_INFO")
	public static GMMap getInfo1572(GMMap iMap) {

		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			GMMap oMap = new GMMap();
			String tableName = "PRIM";
			String tableName2 = "RISK";
			int row = 0;
			HznOpsiyonPrimPrmTx prim = null;
			HznOpsiyonRiskPrmTx risk = null;
			
		       List<HznOpsiyonPrimPrmTx> listPrim = session.createCriteria(HznOpsiyonPrimPrmTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		       List<HznOpsiyonRiskPrmTx> listRisk= session.createCriteria(HznOpsiyonRiskPrmTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		       
		       HznOpsiyonislemTeminatTx gp = (HznOpsiyonislemTeminatTx) session.createCriteria(HznOpsiyonRiskPrmTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		       oMap.put("CATI_LIMIT" , gp.getTutari());

             Iterator <HznOpsiyonPrimPrmTx> primIterator  =  listPrim.iterator();
             Iterator <HznOpsiyonRiskPrmTx> riskIterator  =  listRisk.iterator();

             
             while(primIterator.hasNext())
             {
            	 prim=primIterator.next();
            	 oMap.put(tableName,row,"GUN1",prim.getId().getGun1());
            	 oMap.put(tableName,row,"GUN2",prim.getId().getGun2());
            	 oMap.put(tableName,row,"DOVIZ_GRUP1",prim.getDovizGrup1());//DOVIZ_GRUP1,DOVIZ_GRUP2,DOVIZ_DIGER
            	 oMap.put(tableName,row,"DOVIZ_GRUP2",prim.getDovizGrup2());
            	 oMap.put(tableName,row,"DOVIZ_DIGER",prim.getDovizDiger());
            	 row++;
             }
             
             row=0;
             
             while(riskIterator.hasNext())
             {
            	 risk=riskIterator.next();
            	 oMap.put(tableName2,row,"KOD",risk.getId().getKod());
            	 oMap.put(tableName2,row,"EKTEMINAT",risk.getEkteminat());
            	 oMap.put(tableName2,row,"FARKLIDOVIZ",risk.getFarklidoviz());
            	 oMap.put(tableName2,row,"ISIM",risk.getIsim());
            	 row++;
             }

			return oMap;
	}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
}
