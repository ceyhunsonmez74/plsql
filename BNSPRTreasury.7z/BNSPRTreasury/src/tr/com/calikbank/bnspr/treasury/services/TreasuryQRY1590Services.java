package tr.com.calikbank.bnspr.treasury.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;


public class TreasuryQRY1590Services {
	
    @GraymoundService("BNSPR_QRY1590_GET_ANLASMALAR")
    public static GMMap getAnlasmalarQRY1590(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            String func = "{? = call pkg_rc1590.GetAnlasmaList(?)}";
            Object [] values  = new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO") };

            oMap = DALUtil.callOracleRefCursorFunction(func , "TABLE_ANLASMA" , values);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	
}
