package tr.com.calikbank.bnspr.treasury.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznNakitAkisManuelTx;
import tr.com.calikbank.bnspr.dao.HznNakitAkisManuelTxId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1335Services {
	
	@GraymoundService("BNSPR_TRN1335_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		
		String listName = "TUR";
		GuimlUtil.wrapMyCombo(oMap, listName, "GIRIS", "Giri�");
		GuimlUtil.wrapMyCombo(oMap, listName, "CIKIS", "��k��");
		
		return oMap;
	}

		@GraymoundService("BNSPR_TRN1335_SAVE")
		public static GMMap Save (GMMap iMap){
			try {
				Session session = DAOSession.getSession("BNSPRDal");
				String tableName = "CBS_NAKIT_AKISI_MANUEL_DTYISL";
				List<?> list = (List<?>) iMap.get(tableName);
				
				for (int i=0;i<list.size();i++){
					HznNakitAkisManuelTxId id = new HznNakitAkisManuelTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setSiraNo((new java.math.BigDecimal(i+1)));
					
					HznNakitAkisManuelTx hznNakitAkisManuelTx = (HznNakitAkisManuelTx)session.get(HznNakitAkisManuelTx.class, id);
					
					if(hznNakitAkisManuelTx == null) {
						hznNakitAkisManuelTx = new HznNakitAkisManuelTx();
					}
					hznNakitAkisManuelTx.setAciklama(iMap.getString(tableName,i,"ACIKLAMA"));
					hznNakitAkisManuelTx.setDoviz(iMap.getString(tableName,i,"DOVIZ"));
			//		hznNakitAkisManuelTx.setDurumKodu(durumKodu)
					hznNakitAkisManuelTx.setId(id);
			//		hznNakitAkisManuelTx.setIslemKodu(islemKodu)
					hznNakitAkisManuelTx.setModulTur("HAZINE");
					hznNakitAkisManuelTx.setMuhabirHesap(iMap.getBigDecimal(tableName,i,"MUHABIR_HESAP"));
					hznNakitAkisManuelTx.setMusteriNo(iMap.getBigDecimal(tableName,i,"MUSTERI_NO"));
					hznNakitAkisManuelTx.setTur(iMap.getString(tableName,i,"TUR"));
					hznNakitAkisManuelTx.setTutar(iMap.getBigDecimal(tableName,i,"TUTAR"));
					hznNakitAkisManuelTx.setValor(iMap.getDate(tableName,i,"VALOR"));
					hznNakitAkisManuelTx.setUrunSinif("CUA");
					hznNakitAkisManuelTx.setUrunTur("CUA");
					session.saveOrUpdate(hznNakitAkisManuelTx);
					session.flush();
				}
				iMap.put("TRX_NAME", "1335");
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		@GraymoundService("BNSPR_TRN1335_GETINFO")
		public static GMMap getInfo (GMMap iMap){
			try {
				GMMap oMap = new GMMap();
				Session session = DAOSession.getSession("BNSPRDal");
			
				List<?> recordList = (List<?>)session.createCriteria(HznNakitAkisManuelTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();
				oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				String tableName = "CBS_NAKIT_AKISI_MANUEL_DTYISL";
				
				for (int row = 0; row < recordList.size(); row++) {
					HznNakitAkisManuelTx hznNakitAkisManuelTx = (HznNakitAkisManuelTx) recordList.get(row);
					oMap.put(tableName, row, "ACIKLAMA", hznNakitAkisManuelTx.getAciklama());
					oMap.put(tableName, row, "DOVIZ", hznNakitAkisManuelTx.getDoviz());
					oMap.put(tableName, row, "MUHABIR_HESAP", hznNakitAkisManuelTx.getMuhabirHesap());
					oMap.put(tableName, row, "MUSTERI_NO", hznNakitAkisManuelTx.getMusteriNo());
					oMap.put(tableName, row, "TUR", hznNakitAkisManuelTx.getTur());
					oMap.put(tableName, row, "TUTAR", hznNakitAkisManuelTx.getTutar());
					oMap.put(tableName, row, "VALOR", hznNakitAkisManuelTx.getValor());
					oMap.put(tableName, row, "HES_MUSTERI_AD", LovHelper.diLov(hznNakitAkisManuelTx.getMuhabirHesap(),hznNakitAkisManuelTx.getDoviz(),"1335/LOV_HESAP_NO","MUSTERI_ADI"));
					oMap.put(tableName, row, "MUSTERI_ADI", LovHelper.diLov(hznNakitAkisManuelTx.getMusteriNo(),"1335/LOV_BANKA_MUSTERI_NO","MUSTERI_ADI"));
					
				}
				
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
}
