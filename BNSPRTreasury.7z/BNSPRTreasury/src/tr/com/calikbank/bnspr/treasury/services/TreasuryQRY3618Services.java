package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryQRY3618Services {
	@GraymoundService("BNSPR_QRY3618_GET_STOK_LIST")
	public static GMMap getStokList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3618.GetStokList(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); 
			 stmt.setString(i++,  iMap.getString("STOK_TURU"));
			stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);   
             
            int j = 0;
            while (rSet.next()){
             if(j==0){
                  oMap.put("STOK_LIST" ,j ,"STOK_TIPI" ,"BORSA");
                  oMap.put("STOK_LIST" ,j ,"T_VALOR" ,rSet.getBigDecimal("BORSA_T"));
                  oMap.put("STOK_LIST" ,j ,"T1_VALOR" ,rSet.getBigDecimal("BORSA_T1"));
                  oMap.put("STOK_LIST" ,j ,"T2_VALOR" ,rSet.getBigDecimal("BORSA_T2"));
                  oMap.put("STOK_LIST" ,j+1 ,"STOK_TIPI" ,"OTC");
                  oMap.put("STOK_LIST" ,j+1 ,"T_VALOR" ,rSet.getBigDecimal("OTC_T"));
                  oMap.put("STOK_LIST" ,j+1 ,"T1_VALOR" ,rSet.getBigDecimal("OTC_T1"));
                  oMap.put("STOK_LIST" ,j+1 ,"T2_VALOR" ,rSet.getBigDecimal("OTC_T2"));
             }
            j++;
            }
		
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	  @GraymoundService("BNSPR_QRY3618_INITIALIZE")
	    public static GMMap init(GMMap iMap){
	        GMMap oMap = new GMMap();
	        try{
	            int row =0;
	            oMap.put("STOK_TURU", row, "NAME", "Hepsi");
	            oMap.put("STOK_TURU", row++, "VALUE","");
	            oMap.put("STOK_TURU", row, "NAME", "Depo");
	            oMap.put("STOK_TURU", row++, "VALUE", "DEPO");
	            oMap.put("STOK_TURU", row, "NAME", "Spot Forward");
	            oMap.put("STOK_TURU", row++, "VALUE", "FX");
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	    }
	
	
}
