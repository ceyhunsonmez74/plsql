package tr.com.calikbank.bnspr.treasury.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class TreasuryQRY1581Services {
    
    
    @GraymoundService("BNSPR_QRY1581_BANKA_OZET")
    public static GMMap bankaOzet(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        try {
            String func = "{? = call pkg_rc1581.BankaOzet(?,?,?,?)}";
            Object [] values  = new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
                                                BnsprType.DATE, iMap.getDate("BAS_TARIHI"), BnsprType.DATE, iMap.getDate("BIT_TARIHI")};

            oMap = DALUtil.callOracleRefCursorFunction(func , "TABLE" , values);
               
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY1581_HAREKET_IZLEME")
    public static GMMap hareketIzleme(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        try {
            String func = "{? = call pkg_rc1581.HareketIzleme(?,?,?,?)}";
            Object [] values  = new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
                                                BnsprType.DATE, iMap.getDate("BAS_TARIHI"), BnsprType.DATE, iMap.getDate("BIT_TARIHI")};

            oMap = DALUtil.callOracleRefCursorFunction(func , "TABLE" , values);
               
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
    
}