package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY1350Services {

	@GraymoundService("BNSPR_QRY1350_SWAP_SORGULA")
	public static GMMap getSwapData(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_TREASURY.RC_QRY1350_MUSTERI_SWAP_FWD(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setString(2,iMap.getString("SWAP_FORWARD"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "CBS_HAZINE_SWFW";
        	
        	int row = 0;
        	while(rSet.next()){
				oMap.put(tableName, row, "ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
				oMap.put(tableName, row, "BANKA_MUSTERI_NO", rSet.getBigDecimal("BANKA_MUSTERI_NO"));
				oMap.put(tableName, row, "BOLUM_KODU", rSet.getString("SUBE_KODU"));
				oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, row, "ISLEM_SEKLI", rSet.getString("ISLEM_SEKLI"));
				oMap.put(tableName, row, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, row, "SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
				oMap.put(tableName, row, "VADE_TARIHI", rSet.getDate("VADE_TARIHI"));
				oMap.put(tableName, row, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, row, "SPOT_ALIS_KUR", rSet.getString("SPOT_ALIS_KUR"));
				oMap.put(tableName, row, "SPOT_SATIS_KUR", rSet.getString("SPOT_SATIS_KUR"));
				oMap.put(tableName, row, "SPOT_PARITE", rSet.getString("SPOT_PARITE"));
				oMap.put(tableName, row, "SPOT_ALIS_TUTARI", rSet.getString("SPOT_ALIS_TUTARI"));
				oMap.put(tableName, row, "SPOT_SATIS_TUTARI", rSet.getString("SPOT_SATIS_TUTARI"));
				oMap.put(tableName, row, "SPOT_ALIS_HESAP_TURU", rSet.getString("SPOT_ALIS_HESAP_TURU"));
				oMap.put(tableName, row, "SPOT_ALIS_HESAP_NO", rSet.getString("SPOT_ALIS_HESAP_NO"));
				oMap.put(tableName, row, "SPOT_SATIS_HESAP_NO", rSet.getString("SPOT_SATIS_HESAP_NO"));
				oMap.put(tableName, row, "SPOT_SATIS_HESAP_TURU", rSet.getString("SPOT_SATIS_HESAP_TURU"));
				oMap.put(tableName, row, "GN_SPOT_HESAP_NO", rSet.getString("GN_SPOT_HESAP_NO"));
				oMap.put(tableName, row, "FORWARD_ALIS_KUR", rSet.getString("FORWARD_ALIS_KUR"));
				oMap.put(tableName, row, "FORWARD_SATIS_KUR", rSet.getString("FORWARD_SATIS_KUR"));
				oMap.put(tableName, row, "FORWARD_PARITE", rSet.getString("FORWARD_PARITE"));
				oMap.put(tableName, row, "FORWARD_ALIS_TUTARI", rSet.getString("FORWARD_ALIS_TUTARI"));
				oMap.put(tableName, row, "FORWARD_SATIS_TUTARI", rSet.getString("FORWARD_SATIS_TUTARI"));
				oMap.put(tableName, row, "FORWARD_ALIS_HESAP_TURU", rSet.getString("FORWARD_ALIS_HESAP_TURU"));
				oMap.put(tableName, row, "FORWARD_ALIS_HESAP_NO", rSet.getString("FORWARD_ALIS_HESAP_NO"));
				oMap.put(tableName, row, "FORWARD_SATIS_HESAP_TURU", rSet.getString("FORWARD_SATIS_HESAP_TURU"));
				oMap.put(tableName, row, "FORWARD_SATIS_HESAP_NO", rSet.getString("FORWARD_SATIS_HESAP_NO"));
				oMap.put(tableName, row, "GN_FORWARD_HESAP_NO", rSet.getString("GN_FORWARD_HESAP_NO"));
				oMap.put(tableName, row, "URUN_SINIF_KODU", rSet.getString("URUN_SINIF_KOD"));
				oMap.put(tableName, row, "URUN_TUR_KODU", rSet.getString("URUN_TUR_KOD"));
				oMap.put(tableName, row, "SON_TXNO", rSet.getString("SON_TXNO"));
				row++;
        	}
        		
        		oMap.put("COMBO_DURUM",0,"VALUE", "A");
        		oMap.put("COMBO_DURUM",0,"NAME", "A��k");
        		oMap.put("COMBO_DURUM",1,"VALUE", "K");
        		oMap.put("COMBO_DURUM",1,"NAME", "Kapal�");
        		
        		oMap.put("COMBO_ISLEM_SEKLI",0,"VALUE", "A");
        		oMap.put("COMBO_ISLEM_SEKLI",0,"NAME", "A-Al��");
        		oMap.put("COMBO_ISLEM_SEKLI",1,"VALUE", "S");
        		oMap.put("COMBO_ISLEM_SEKLI",1,"NAME", "S-Sat��");
        		
        	return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
	@GraymoundService("BNSPR_QRY1350_FORWARD_SORGULA")
	public static GMMap getForwardData(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{? = call PKG_RC_TREASURY.RC_QRY1350_MUSTERI_SWAP_FWD(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
						
			stmt.setString(2,iMap.getString("SWAP_FORWARD"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "CBS_HAZINE_SWFW";
        	
        	int row = 0;
        	while(rSet.next()){
				oMap.put(tableName, row, "ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
				oMap.put(tableName, row, "BANKA_MUSTERI_NO", rSet.getBigDecimal("BANKA_MUSTERI_NO"));
				oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, row, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, row, "SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
				oMap.put(tableName, row, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, row, "MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(tableName, row, "URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
				oMap.put(tableName, row, "URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
				oMap.put(tableName, row, "SUBE_KODU", rSet.getString("BOLUM_KODU"));
				oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
				oMap.put(tableName, row, "ALIS_KUR", rSet.getString("ALIS_KUR"));
				oMap.put(tableName, row, "SATIS_KUR", rSet.getString("SATIS_KUR"));
				oMap.put(tableName, row, "ALIS_TUTARI", rSet.getString("ALIS_TUTARI"));
				oMap.put(tableName, row, "SATIS_TUTARI", rSet.getString("SATIS_TUTARI"));
				oMap.put(tableName, row, "ALIS_HESAP_NO", rSet.getString("ALIS_HESAP_NO"));
				oMap.put(tableName, row, "SATIS_HESAP_NO", rSet.getString("SATIS_HESAP_NO"));
				oMap.put(tableName, row, "SON_TXNO", rSet.getString("SON_TXNO"));
				row++;
        	}
        	oMap.put("COMBO_DURUM",0,"VALUE", "A");
    		oMap.put("COMBO_DURUM",0,"NAME", "A��k");
    		oMap.put("COMBO_DURUM",1,"VALUE", "K");
    		oMap.put("COMBO_DURUM",1,"NAME", "Kapal�");
        	return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
	
	@GraymoundService("BNSPR_QRY1350_SWAP_STARTEOD")
	public static GMMap getSwapStartEOD(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String tableName = "CBS_HAZINE_SWFW";
		List<?> list = (List<?>) iMap.get(tableName);
		try{
			conn = DALUtil.getGMConnection();
			for (int i=0;i<list.size();i++){
				if(iMap.getBoolean	(tableName, i, "SECIM")== true)
				{
					stmt = conn.prepareCall("{ call PKG_HAZINE.Musteri_Swap_EOD(?,?)}");
					stmt.setString(1, iMap.getString	(tableName, i, "SON_TXNO"));
					stmt.setString(2, iMap.getString	(tableName, i, "REFERANS"));
					stmt.execute();
				}
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY1350_FORWARD_STARTEOD")
	public static GMMap getForwardStartEOD(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String tableName = "CBS_HAZINE_SWFW";
		List<?> list = (List<?>) iMap.get(tableName);
		try{
			conn = DALUtil.getGMConnection();
			for (int i=0;i<list.size();i++){
				if(iMap.getBoolean	(tableName, i, "SECIM")== true)
				{
					stmt = conn.prepareCall("{ call PKG_HAZINE.Musteri_Forward_EOD(?,?)}");
					stmt.setString(1, iMap.getString	(tableName, i, "SON_TXNO"));
					stmt.setString(2, iMap.getString	(tableName, i, "REFERANS"));
					stmt.execute();
				}
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
