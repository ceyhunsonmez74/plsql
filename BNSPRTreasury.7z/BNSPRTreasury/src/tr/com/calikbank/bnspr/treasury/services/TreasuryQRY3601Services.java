package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryQRY3601Services {
	
	@GraymoundService("BNSPR_QRY3601_GET_LIST")
	public static GMMap listele(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		 
		try{
			
			conn = DALUtil.getGMConnection();
	        stmt = conn.prepareCall("{? = call PKG_RC3601.GET_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.setString(i++, iMap.getString("URUN_TUR_KOD"));
			stmt.setString(i++, iMap.getString("URUN_SINIF_KOD"));	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("ALIS_DOVIZ_KODU"));
			
			if(iMap.getBigDecimal("ALIS_BRUT_MIN_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_BRUT_MIN_TUTAR"));
			if(iMap.getBigDecimal("ALIS_BRUT_MAX_TUTAR").toString().equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_BRUT_MAX_TUTAR"));
		   if(iMap.getBigDecimal("SATIS_BRUT_MIN_TUTAR").toString().equals("0.00"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_BRUT_MIN_TUTAR"));
            if(iMap.getBigDecimal("SATIS_BRUT_MAX_TUTAR").toString().equals("0.00"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_BRUT_MAX_TUTAR"));
            
            if(iMap.getBigDecimal("PARITE").toString().equals("0.00000"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("PARITE"));
            stmt.setString(i++, iMap.getString("DURUM_KODU"));
            if(iMap.getDate("DEAL_TARIHI_MIN") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI_MIN").getTime()));
            else
                stmt.setDate(i++,null);
            
            if(iMap.getDate("VALOR_BASLANGIC_TARIHI") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_BASLANGIC_TARIHI").getTime()));
            else
                stmt.setDate(i++,null);
            if(iMap.getDate("VALOR_BITIS_TARIHI") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_BITIS_TARIHI").getTime()));
            else
                stmt.setDate(i++,null);
            
            stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
            
            
            if(iMap.getDate("DEAL_TARIHI_MAX") != null)
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI_MAX").getTime()));
            else
                stmt.setDate(i++,null);
            
            
			if(iMap.getBigDecimal("ALIS_NET_MIN_TUTAR").toString().equals("0.00"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_NET_MIN_TUTAR"));
			if(iMap.getBigDecimal("ALIS_NET_MAX_TUTAR").toString().equals("0.00"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("ALIS_NET_MAX_TUTAR"));
		
			if(iMap.getBigDecimal("SATIS_NET_MIN_TUTAR").toString().equals("0.00"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_NET_MIN_TUTAR"));
			if(iMap.getBigDecimal("SATIS_NET_MAX_TUTAR").toString().equals("0.00"))
                stmt.setBigDecimal(i++, null);
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("SATIS_NET_MAX_TUTAR"));
			
			
			stmt.setBigDecimal(i++ , iMap.getBigDecimal("ISLEM_NO"));
			//stmt.setBigDecimal(i++ , iMap.getBigDecimal("ALTIN_SAFLIK_DER"));
			stmt.setString(i++, iMap.getString("SATIS_DOVIZ_KODU"));
	        stmt.setString(i++ , iMap.getString("STOK_NO"));
			
	        stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "HZN_ALTIN_ALIS_SATIS_IZLEME";
			int row = 0;
			
			while(rSet.next()){
				oMap.put(tableName, row, "ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
				oMap.put(tableName, row, "ALIS_BRUT_TUTARI", rSet.getString("ALIS_BRUT_TUTARI"));
				oMap.put(tableName, row, "ALIS_NET_TUTARI", rSet.getString("ALIS_NET_TUTARI"));
				oMap.put(tableName, row, "DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));
				oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, row, "BANKA_MUSTERI_ADI", rSet.getString("BANKA_MUSTERI_ADI"));
				oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
				oMap.put(tableName, row, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, row, "SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
				oMap.put(tableName, row, "SATIS_BRUT_TUTARI", rSet.getString("SATIS_BRUT_TUTARI"));
				oMap.put(tableName, row, "SATIS_NET_TUTARI", rSet.getString("SATIS_NET_TUTARI"));
				oMap.put(tableName, row, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
				oMap.put(tableName, row, "ISLEM_TUR", rSet.getString("ISLEM_TUR"));
				oMap.put(tableName, row, "SATIS_MUHABIR_MUSTERI_NO", rSet.getString("SATIS_MUHABIR_MUSTERI_NO"));
				oMap.put(tableName, row, "ALIS_MUHABIR_MUSTERI_NO", rSet.getString("ALIS_MUHABIR_MUSTERI_NO"));
			//	oMap.put(tableName, row, "ALIS_HESAP_NO", rSet.getBigDecimal("ALIS_HESAP_NO"));
			//	oMap.put(tableName, row, "SATIS_HESAP_NO", rSet.getBigDecimal("SATIS_HESAP_NO"));
				oMap.put(tableName, row, "ISLEM_NO",rSet.getBigDecimal("ISLEM_NO"));
				oMap.put(tableName, row, "ALTIN_SAFLIK_DER",rSet.getBigDecimal("ALTIN_SAFLIK_DER"));
				oMap.put(tableName, row, "STOK_NO",rSet.getString("STOK_NO"));
				oMap.put(tableName, row, "KOMISYON",rSet.getBigDecimal("KOMISYON_TUTARI"));
				
				
				row++;
        	}
			
			iMap.put("KOD", "HZN_ISLEM_DURUM");
			oMap.put("COMBO_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3601_DETAY")
	public static GMMap detay(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{? = call PKG_RC3601.RC_QRY3601_DETAY(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			while(rSet.next()){
	            oMap.put("MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
	            oMap.put("URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
	            oMap.put("URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
	            oMap.put("REFERANS", rSet.getString("REFERANS"));
	            oMap.put("DEALER_NO", rSet.getString("DEALER_NO"));
	            oMap.put("BANKA_MUSTERI_NO", rSet.getString("BANKA_MUSTERI_NO"));
	            oMap.put("BANKA_MUSTERI_ADI", rSet.getString("BANKA_MUSTERI_ADI"));
	            oMap.put("ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
	            oMap.put("SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
	            oMap.put("ALIS_KUR", rSet.getString("ALIS_KUR"));
	            oMap.put("SATIS_KUR", rSet.getString("SATIS_KUR"));
	            oMap.put("PARITE", rSet.getString("PARITE"));
	            oMap.put("ALIS_BRUT_TUTAR", rSet.getString("ALIS_BRUT_TUTAR"));
	            oMap.put("SATIS_BRUT_TUTAR", rSet.getString("SATIS_BRUT_TUTAR"));
	            oMap.put("ALIS_NET_TUTAR", rSet.getString("ALIS_NET_TUTAR"));
                oMap.put("SATIS_NET_TUTAR", rSet.getString("SATIS_NET_TUTAR"));
                oMap.put("ALIS_HESAP_TURU", rSet.getString("ALIS_HESAP_TURU"));
                oMap.put("SATIS_HESAP_TURU", rSet.getString("SATIS_HESAP_TURU"));
                oMap.put("VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
                oMap.put("ALIS_HESAP_NO", rSet.getString("ALIS_HESAP_NO"));
                oMap.put("SATIS_HESAP_NO", rSet.getString("SATIS_HESAP_NO"));
                oMap.put("DURUM_KODU", rSet.getString("DURUM_KODU"));
                oMap.put("GN_ALIS_HESAP_NO", rSet.getString("GN_ALIS_HESAP_NO"));
                oMap.put("YARATAN_TXNO", rSet.getString("YARATAN_TXNO"));
                oMap.put("DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));
            
				stmt = conn.prepareCall("{ ? = call pkg_hesap.kisa_isim(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, rSet.getString("ALIS_HESAP_NO"));
				stmt.execute();
				oMap.put("ALIS_KISA_ISIM", stmt.getString(1));
				stmt = conn.prepareCall("{ ? = call pkg_hesap.kisa_isim(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, rSet.getString("SATIS_HESAP_NO"));
				stmt.execute();
				oMap.put("SATIS_KISA_ISIM", stmt.getString(1));
				
        	}
			iMap.put("KOD", "HZN_ISLEM_DURUM");
			oMap.put("COMBO_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3601_GET_ISLEM_DETAY")
    public static GMMap getIslemDetay(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
         
        try{
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC3601.GET_ISLEM_DETAY(?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setString(i++, iMap.getString("REFERANS"));
            stmt.execute();
            rSet = (ResultSet)stmt.getObject(1);
            String tableName = "HZN_ALTIN_ALIS_SATIS_ISLEM_DETAY";
            int row = 0;
            
            while(rSet.next()){
                oMap.put(tableName, row, "ALIS_DOVIZ_KODU", rSet.getString("ALIS_DOVIZ_KODU"));
                oMap.put(tableName, row, "ALIS_BRUT_TUTARI", rSet.getString("ALIS_BRUT_TUTARI"));
                oMap.put(tableName, row, "ALIS_NET_TUTARI", rSet.getString("ALIS_NET_TUTARI"));
                oMap.put(tableName, row, "DEAL_TARIHI", rSet.getDate("DEAL_TARIHI"));
                oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "BANKA_MUSTERI_ADI", rSet.getString("BANKA_MUSTERI_ADI"));
                oMap.put(tableName, row, "PARITE", rSet.getString("PARITE"));
                oMap.put(tableName, row, "REFERANS", rSet.getString("REFERANS"));
                oMap.put(tableName, row, "SATIS_DOVIZ_KODU", rSet.getString("SATIS_DOVIZ_KODU"));
                oMap.put(tableName, row, "SATIS_BRUT_TUTARI", rSet.getString("SATIS_BRUT_TUTARI"));
                oMap.put(tableName, row, "SATIS_NET_TUTARI", rSet.getString("SATIS_NET_TUTARI"));
                oMap.put(tableName, row, "VALOR_TARIHI", rSet.getDate("VALOR_TARIHI"));
                oMap.put(tableName, row, "ISLEM_TUR", rSet.getString("ISLEM_TUR"));
                oMap.put(tableName, row, "SATIS_MUHABIR_MUSTERI_NO", rSet.getString("SATIS_MUHABIR_MUSTERI_NO"));
                oMap.put(tableName, row, "ALIS_MUHABIR_MUSTERI_NO", rSet.getString("ALIS_MUHABIR_MUSTERI_NO"));
            //  oMap.put(tableName, row, "ALIS_HESAP_NO", rSet.getBigDecimal("ALIS_HESAP_NO"));
            //  oMap.put(tableName, row, "SATIS_HESAP_NO", rSet.getBigDecimal("SATIS_HESAP_NO"));
                oMap.put(tableName, row, "ISLEM_NO",rSet.getBigDecimal("ISLEM_NO"));
                oMap.put(tableName, row, "ALTIN_SAFLIK_DER",rSet.getBigDecimal("ALTIN_SAFLIK_DER"));
                oMap.put(tableName, row, "STOK_NO",rSet.getString("STOK_NO"));
                oMap.put(tableName, row, "KOMISYON",rSet.getBigDecimal("KOMISYON_TUTARI"));
                oMap.put(tableName , row,"FIS_NO",rSet.getBigDecimal("FIS_NO"));
                
                
                row++;
            }
            
            iMap.put("KOD", "HZN_ISLEM_DURUM");
            oMap.put("COMBO_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

        return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	
	@GraymoundService("BNSPR_QRY3601_GET_FIS_NO")
    public static GMMap getIslemFisNo(GMMap iMap){
		GMMap oMap = new GMMap();
        try {

            int i = 0;

            String func = "{? = call PKG_TX.fis_no(?)}";
            Object[] inputValues = new Object[2];
       
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("ISLEM_NO");
  

            oMap.put("FIS_NO",DALUtil.callOracleFunction(func, BnsprType.NUMBER , inputValues));
            return oMap;

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

	}
	
}
