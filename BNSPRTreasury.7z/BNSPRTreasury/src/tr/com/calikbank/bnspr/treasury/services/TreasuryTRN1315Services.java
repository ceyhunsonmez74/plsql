package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznVerilendepoTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1315Services {

	@GraymoundService("BNSPR_TRN1315_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1315.BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1315_TRANSFER_DATA")
	public static GMMap transferData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznVerilendepoTx hznVerilenDepoTx = (HznVerilendepoTx)session.get(HznVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", hznVerilenDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznVerilenDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznVerilenDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznVerilenDepoTx.getReferans());
			oMap.put("DEALER_NO", hznVerilenDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznVerilenDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznVerilenDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznVerilenDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznVerilenDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznVerilenDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznVerilenDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznVerilenDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznVerilenDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznVerilenDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznVerilenDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznVerilenDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznVerilenDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznVerilenDepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznVerilenDepoTx.getVadeSonuFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznVerilenDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznVerilenDepoTx.getDealTarihi());
			oMap.put("YENILENENTUTAR", hznVerilenDepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznVerilenDepoTx.getEkTutar());
			oMap.put("YENILENENREFERANS", hznVerilenDepoTx.getYenilenenReferans());
			if(hznVerilenDepoTx.getVadeTarihindeKapama() != null)
				if(hznVerilenDepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_NEG", hznVerilenDepoTx.getBirikmisFaizNeg());
			
			oMap.put("FAIZ_ORANI", hznVerilenDepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznVerilenDepoTx.getGirisHesapNo(),hznVerilenDepoTx.getDovizKodu(),
					hznVerilenDepoTx.getGirisHesapTuru(), hznVerilenDepoTx.getBankaMusteriNo(), hznVerilenDepoTx.getGirisHesapTuru(), 
					hznVerilenDepoTx.getGirisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznVerilenDepoTx.getCikisHesapNo(),hznVerilenDepoTx.getDovizKodu(),
					hznVerilenDepoTx.getCikisHesapTuru(), hznVerilenDepoTx.getBankaMusteriNo(), hznVerilenDepoTx.getCikisHesapTuru(), 
					hznVerilenDepoTx.getCikisHesapTuru(), "1312/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznVerilenDepoTx.getBankaMusteriNo(), "1312/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznVerilenDepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznVerilenDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznVerilenDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznVerilenDepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("ISLEM_TURU", hznVerilenDepoTx.getIslemTuru());
			/*
			 * Murabaha Detay Butonu aktif yada pasif olmasi
			 * */
			if (hznVerilenDepoTx.getMurabahaId()!=null)
			{
				oMap.put("MURABAHA_DETAY", true);
				//oMap.put("MURABAHA_ID", hznVerilenDepoTx.getMurabahaId());
			}
				else
				oMap.put("MURABAHA_DETAY", false);
			
			// Negatif faiz uygulanirsa bu alan secilir faiz orani eksi yapilamaz swift cakiliyor
			if (hznVerilenDepoTx.getNegatifFaiz()!=null)
				oMap.put("NEGATIF_FAIZ", hznVerilenDepoTx.getNegatifFaiz().intValue()==1?true:false);
			else
				oMap.put("NEGATIF_FAIZ", false);
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1315_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznVerilendepoTx hznVerilenDepoTx = (HznVerilendepoTx)session.get(HznVerilendepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznVerilenDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznVerilenDepoTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", hznVerilenDepoTx.getUrunSinifKod());
			oMap.put("REFERANS", hznVerilenDepoTx.getReferans());
			oMap.put("DEALER_NO", hznVerilenDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznVerilenDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznVerilenDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznVerilenDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznVerilenDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznVerilenDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznVerilenDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznVerilenDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznVerilenDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznVerilenDepoTx.getValorTarihi());
			oMap.put("VADE_TARIHI", hznVerilenDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznVerilenDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznVerilenDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznVerilenDepoTx.getFaizTutari());
			oMap.put("VADE_SONU_FAIZ_TUTARI", hznVerilenDepoTx.getVadeSonuFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznVerilenDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznVerilenDepoTx.getDealTarihi());
			oMap.put("YENILENENTUTAR", hznVerilenDepoTx.getYenilenenTutar());
			oMap.put("EKTUTAR", hznVerilenDepoTx.getEkTutar());
			oMap.put("REFERANSYENI", hznVerilenDepoTx.getReferansYeni());
			if(hznVerilenDepoTx.getVadeTarihindeKapama() != null)
				if(hznVerilenDepoTx.getVadeTarihindeKapama().toString().equals("H"))
					oMap.put("VADE_TARIHINDE_KAPAMA", "false");
				else
					oMap.put("VADE_TARIHINDE_KAPAMA", "true");
			else
				oMap.put("VADE_TARIHINDE_KAPAMA", "false");
			oMap.put("BIRIKMIS_FAIZ_NEG", hznVerilenDepoTx.getBirikmisFaizNeg());
			
			oMap.put("FAIZ_ORANI", hznVerilenDepoTx.getFaizOrani());
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznVerilenDepoTx.getGirisHesapNo(),hznVerilenDepoTx.getDovizKodu(),
					hznVerilenDepoTx.getGirisHesapTuru(), hznVerilenDepoTx.getBankaMusteriNo(), hznVerilenDepoTx.getGirisHesapTuru(), 
					hznVerilenDepoTx.getGirisHesapTuru(), "1312/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznVerilenDepoTx.getCikisHesapNo(),hznVerilenDepoTx.getDovizKodu(),
					hznVerilenDepoTx.getCikisHesapTuru(), hznVerilenDepoTx.getBankaMusteriNo(), hznVerilenDepoTx.getCikisHesapTuru(), 
					hznVerilenDepoTx.getCikisHesapTuru(), "1312/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznVerilenDepoTx.getBankaMusteriNo(), "1312/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznVerilenDepoTx.getDealerNo(), "1312/LOV_DEALER", "ISIM"));
			oMap.put("ACIKLAMA", hznVerilenDepoTx.getAciklama());
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznVerilenDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznVerilenDepoTx.getCikisMuhabirMusteriNo());
			
			oMap.put("ISLEM_TURU", hznVerilenDepoTx.getIslemTuru());
			
			/*
			 * Murabaha Detay Butonu aktif yada pasif olmasi
			 * */
			if (hznVerilenDepoTx.getMurabahaId()!=null)
			{
				oMap.put("MURABAHA_DETAY", true);
				oMap.put("MURABAHA_ID", hznVerilenDepoTx.getMurabahaId());
			}
				else
				oMap.put("MURABAHA_DETAY", false);
			
			// Negatif faiz uygulanirsa bu alan secilir faiz orani eksi yapilamaz swift cakiliyor
			if (hznVerilenDepoTx.getNegatifFaiz()!=null)
				oMap.put("NEGATIF_FAIZ", hznVerilenDepoTx.getNegatifFaiz().intValue()==1?true:false);
			else
				oMap.put("NEGATIF_FAIZ", false);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_TRN1315_SAVE")
	public static GMMap save(GMMap iMap) {
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznVerilendepoTx hznVerilenDepoTx = (HznVerilendepoTx)session.get(HznVerilendepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznVerilenDepoTx == null) {
				hznVerilenDepoTx = new HznVerilendepoTx();
			}
			
			hznVerilenDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznVerilenDepoTx.setModulTurKod("HAZINE");
			hznVerilenDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznVerilenDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznVerilenDepoTx.setReferans(iMap.getString("REFERANS"));
			hznVerilenDepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznVerilenDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznVerilenDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznVerilenDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznVerilenDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznVerilenDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznVerilenDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznVerilenDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznVerilenDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznVerilenDepoTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznVerilenDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznVerilenDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznVerilenDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznVerilenDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznVerilenDepoTx.setVadeSonuFaizTutari(iMap.getBigDecimal("VADE_SONU_FAIZ_TUTARI"));
			hznVerilenDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznVerilenDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznVerilenDepoTx.setReferansYeni(iMap.getString("REFERANS_YENI"));
			hznVerilenDepoTx.setYenilenenTutar(iMap.getBigDecimal("YENILENEN_TUTAR"));
			hznVerilenDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			if(iMap.getString("VADE_TARIHINDE_KAPAMA").toString().equals("false"))
				hznVerilenDepoTx.setVadeTarihindeKapama("H");
			else
				hznVerilenDepoTx.setVadeTarihindeKapama("E");
			hznVerilenDepoTx.setBirikmisFaizNeg(iMap.getBigDecimal("BIRIKMIS_FAIZ_NEG"));
			hznVerilenDepoTx.setEkTutar(iMap.getBigDecimal("EK_TUTAR"));
			hznVerilenDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			hznVerilenDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznVerilenDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			hznVerilenDepoTx.setMurabahaId(iMap.getBigDecimal("MURABAHA_ID"));
			
			hznVerilenDepoTx.setNegatifFaiz(iMap.getBoolean("NEGATIF_FAIZ")==true?new BigDecimal(1):new BigDecimal(0));
			
			session.saveOrUpdate(hznVerilenDepoTx);
			session.flush();
			
			GMMap oMap = new GMMap();
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	
	
	@GraymoundService("BNSPR_TRN1315_TRANSACTION_START")
	public static Map<?, ?> trn1315Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1315");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

}
