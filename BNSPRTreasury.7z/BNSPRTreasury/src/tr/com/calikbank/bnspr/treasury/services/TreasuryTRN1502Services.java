package tr.com.calikbank.bnspr.treasury.services;

//BNSPR_TRN4502.guimlpackage tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HaTalepBlokeTx;
import tr.com.aktifbank.bnspr.dao.HaTalepBlokeTxId;
import tr.com.aktifbank.bnspr.dao.HaTalepDetayTx;
import tr.com.aktifbank.bnspr.dao.HaTalepDetayTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1502Services {

	@GraymoundService("BNSPR_TRN1502_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
          GMMap oMap = new GMMap();
		int a =5;
         Session session = DAOSession.getSession("BNSPRDal");
         
         SQLQuery query= (SQLQuery) session.createSQLQuery("Select * from ha_talep_detay_tx WHERE TX_NO =:txno").setParameter("txno",iMap.getBigDecimal("TRX_NO"));
         query.addEntity(HaTalepDetayTx.class);

         HaTalepDetayTx haTalepDetayTx = (HaTalepDetayTx) query.list().get(0);
     
       if(haTalepDetayTx.getIkinciAdi()!=null)
       oMap.put("AD", haTalepDetayTx.getAdi().trim() + " "+haTalepDetayTx.getIkinciAdi().trim()+" "+haTalepDetayTx.getSoyadi().trim());
       else
       oMap.put("AD", haTalepDetayTx.getAdi().trim() + " "+haTalepDetayTx.getSoyadi().trim());	   
       oMap.put("TUTAR",haTalepDetayTx.getTalepTutar());
       oMap.put("ADET",haTalepDetayTx.getTalepLot());
       
       query= (SQLQuery) session.createSQLQuery("Select * from ha_talep_bloke_tx WHERE TX_NO =:txno").setParameter("txno",iMap.getBigDecimal("TRX_NO"));
       query.addEntity(HaTalepBlokeTx.class);
       List<HaTalepBlokeTx> list = query.list();
        
       Iterator <HaTalepBlokeTx> it = list.iterator();
       
       HaTalepBlokeTx haTalepBlokeTx=null;
         
       int row = 0;
       while(it.hasNext())
       {
    	   haTalepBlokeTx=it.next();
    	   oMap.put("TABLE",row,"DOVIZ",haTalepBlokeTx.getDovizKodu());
    	   oMap.put("TABLE",row,"HESAP",haTalepBlokeTx.getHesapNo());    	   
    	   row++;
       }

       return oMap;
	}

	@GraymoundService("BNSPR_TRN1502_ONAY_GETIR")
	public static GMMap getOnay(GMMap iMap) {

		
         boolean onayVarmi = false;
         int tableRow=0;
         while(!onayVarmi &&tableRow<iMap.getSize("TABLE"))
         {
        	 if(iMap.getBoolean("TABLE",tableRow,"ONAY")==true )
        		 onayVarmi=true;
        	 tableRow++;
         }

         if(!onayVarmi)
 			throw new GMRuntimeException(0, "En az bir hesap se�ilmelidir.");

		if(StringUtils.isBlank(iMap.getString("MUSTERI_NO")) ||	!iMap.getBoolean("TL_HESAP") && !iMap.getBoolean("DOVIZ_HESAP")
		||	StringUtils.isBlank(iMap.getString("ADET")) ||StringUtils.isBlank(iMap.getString("KAZANC")) || StringUtils.isBlank(iMap.getString("TUTAR")) ||
		StringUtils.isBlank(iMap.getString("TARIH")) ||StringUtils.isBlank(iMap.getString("MINIMUM"))  )
		{
			throw new GMRuntimeException(0, "Onay i�in t�m alanlar doldurulmal�d�r.");
		}
		
		if(iMap.getInt("MINIMUM") > iMap.getInt("ADET") )
		{
			throw new GMRuntimeException(0, "Minimum adet talep edilen adetten b�y�k olamaz.");
			
		}
		
		
		
		GMMap oMap = new GMMap();
		String tableName = "OUTPUTTABLE";

		int row = 0;
		int innerrow = 0;
		while (row < iMap.getSize("TABLE")) {
			if (iMap.getBoolean("TABLE", row, "ONAY")) {

				oMap.put(tableName, innerrow, "HESAP", iMap.get("TABLE", row, "HESAP_NO"));
				oMap.put(tableName, innerrow, "DOVIZ", iMap.get("TABLE", row, "DOVIZ_KODU"));
				innerrow++;
			}

			row++;

		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1502_HESAPLARI_GETIR")
	public static GMMap hesaplariGetir(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn =  DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1502.GetHesapList(?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			if (iMap.getBoolean("TL_HESAP")) {
				stmt.setString(i, "T");
			}
			else {
				stmt.setString(i, "");
			}

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "TABLE");
			return oMap;

		}

		catch (Exception e) {

			throw new GMRuntimeException(0, e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN1502_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		
		
		
		

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			HaTalepDetayTx haTalepDetayTx = (HaTalepDetayTx) session.createCriteria(HaTalepDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (haTalepDetayTx == null) {
				haTalepDetayTx = new HaTalepDetayTx();
			}

			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			String haKod = iMap.getString("IN_N_HAKOD");
			
			
			
			
			
			String uyeKod = iMap.getString("IN_N_UYEKOD");
			BigDecimal aktifNo = iMap.getBigDecimal("IN_N_MUSTERINO");
			BigDecimal TlTutar = iMap.getBigDecimal("IN_N_TALEPTUTAR");
			if (TlTutar == null)
				TlTutar = new BigDecimal(0);

			HaTalepBlokeTx hbx;

			/*
			 * Tabloda yer almayacak elamanlar�n kay�t edilmemesi i�in �nceki kay�tar� sil
			 */

			List<HaTalepBlokeTx> bbPRM = session.createCriteria(HaTalepBlokeTx.class).add(Restrictions.eq("txNo", txNo)).list();

			if (bbPRM != null) {
				for (HaTalepBlokeTx bb : bbPRM) {
					session.delete(bb);
				}
			}
			session.flush();

			// belirsiz konular !!!!!!!!!!!!!!!!

            haTalepDetayTx.setBlokeBozdurmaYontemi("S");
            haTalepDetayTx.setBlokeBozdurmaSirasi(new BigDecimal(0));
			haTalepDetayTx.setOdemeTipi("P"); // bu durum degisebilir.

			// eof belirsiz

			haTalepDetayTx.setStatus("A");
			haTalepDetayTx.setTalepTipi("B");
			haTalepDetayTx.setTxType("Y");
			haTalepDetayTx.setTalepArtirimi("N");
			haTalepDetayTx.setDagitimDurumu("T");
			haTalepDetayTx.setTahsisGrup(new BigDecimal(23));// bireysel 23
			haTalepDetayTx.setTeklifNumarasi(new BigDecimal(1));
			haTalepDetayTx.setTalepAltSinirLot(iMap.getLong("IN_N_ALTSINIR"));
			haTalepDetayTx.setTalepLot(iMap.getLong("IN_N_TALEPLOT"));
			haTalepDetayTx.setAktifBankMustNo(aktifNo);
			haTalepDetayTx.setTalepTutar(TlTutar);
			if( !StringUtils.isBlank(iMap.getString("IN_N_TCKN")))
			haTalepDetayTx.setTcKimlik(iMap.getLong("IN_N_TCKN"));
			else if( !StringUtils.isBlank(iMap.getString("IN_N_VKN")))
			haTalepDetayTx.setTcKimlik(iMap.getLong("IN_N_VKN"));
			haTalepDetayTx.setUyeKod(uyeKod);
			haTalepDetayTx.setHaKod(haKod);

			HaTalepDetayTxId id = new HaTalepDetayTxId();
            id.setTxNo(txNo);
            id.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO"));
            haTalepDetayTx.setId(id);
			session.saveOrUpdate(haTalepDetayTx);

			int size = iMap.getSize("HESAPLAR");

			for (int i = 0; i < size; i++) {
				hbx = new HaTalepBlokeTx();
				HaTalepBlokeTxId hid = new HaTalepBlokeTxId();

				hid.setId(haTalepDetayTx.getId().getId());
				hid.setSira(new BigDecimal(i + 1));
				hbx.setTxNo(txNo);
				hbx.setHesapNo(iMap.getBigDecimal("HESAPLAR", i, "HESAP"));
				hbx.setHaKod(haKod);
				hbx.setUyeKod(uyeKod);
				hbx.setId(hid);
				hbx.setAktifBankMustNo(aktifNo);
				hbx.setBlokeTutar(TlTutar);
				hbx.setBlokeYtlTutar(TlTutar);
				hbx.setDovizKodu(iMap.getString("HESAPLAR", i, "DOVIZ"));
				session.saveOrUpdate(hbx);
			}

			session.flush();
		iMap.put("TRX_NAME", "1502");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
