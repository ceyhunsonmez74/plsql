package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryQRY1505Services {
	@GraymoundService("BNSPR_QRY1505_GET_HA_KONS_LISTESI")
	public static GMMap getKonsorsiyumListesi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_HALKA_ARZ.GetKonsorsiyumGirisleri(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); 
			if(iMap.getDate("TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			
			stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            
            
            oMap.putAll(DALUtil.rSetResults(rSet, "TABLE"));
		
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		}catch (ParseException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
