 

package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.PozParamTextTx;
import tr.com.aktifbank.bnspr.dao.PozParamTextTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1354Services {

    @GraymoundService("BNSPR_TRN1354_PARAM_SAVE")
    public static GMMap save(GMMap iMap){
    
         String tableName = "PRM_TABLE";
         Connection conn = null;
         CallableStatement stmt = null;
        
         try{
         List<?> lst  = (List<?>)iMap.get(tableName);
         Session session = DAOSession.getSession("BNSPRDal");
         BigDecimal id;
         for (int i=0;i<lst.size();i++){
             
             if(iMap.get(tableName,i,"ID")==null){
                Map map  = GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_SIRA_NO" , new GMMap());
                Object bd =  map.get("SIRA_NO"); 
                id = BigDecimal.valueOf(Long.valueOf(String.valueOf(bd)));
             }else{
                 id =iMap.getBigDecimal(tableName,i,"ID");
                 
             }
             PozParamTextTx pzParam = new PozParamTextTx();
             PozParamTextTxId pzParamId = new PozParamTextTxId();
             pzParamId.setTxNo(iMap.getBigDecimal("TRX_NO"));
             pzParamId.setId(id); 
             pzParam.setKey1(iMap.getString(tableName,i,"KEY1"));
             pzParam.setText(iMap.getString(tableName,i,"CARPAN"));
             pzParam.setKey2(iMap.getString(tableName,i,"DEGER"));
             pzParam.setKod("POZ_ACILIS_HESAPLAR");
             pzParam.setId(pzParamId);
             session.save(pzParam);
             session.flush();
         }
             
             iMap.put("TRX_NAME" , "1354");
             return  new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
             
         } catch (Exception e) {
             throw ExceptionHandler.convertException(e);
         }
    }
    @GraymoundService("BNSPR_TRN1354_INITIALIZE")
    public static GMMap init(GMMap iMap){
    
        GMMap oMap = new GMMap();  
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String tableName = "PRM_TABLE";
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{? = call PKG_TRN1354.GetParamList}");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
             rSet = (ResultSet)stmt.getObject(1);
             int row =0;
             while(rSet.next()){
                 
                 oMap.put(tableName ,row,"ID",rSet.getBigDecimal("ID"));
                 oMap.put(tableName ,row,"CARPAN",rSet.getString("TEXT"));
                 oMap.put(tableName ,row,"DEGER",rSet.getString("KEY2"));
                 oMap.put(tableName ,row,"KEY1",rSet.getString("KEY1"));
                 row ++;
                 
             }
        }
        catch(Exception e){
            throw ExceptionHandler.convertException(e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
}
