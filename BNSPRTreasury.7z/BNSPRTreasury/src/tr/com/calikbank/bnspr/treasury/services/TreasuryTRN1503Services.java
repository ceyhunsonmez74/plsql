package tr.com.calikbank.bnspr.treasury.services;

//BNSPR_TRN4502.guimlpackage tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HaTalepDetayTx;
import tr.com.aktifbank.bnspr.dao.HaTalepDetayTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1503Services {

	@GraymoundService("BNSPR_TRN_1503_COMBO_PARAMETERS")
	public static GMMap getCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		String listName = "STATU";
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "HEPSI");
		GuimlUtil.wrapMyCombo(oMap, listName, "I", "IPTAL");
		GuimlUtil.wrapMyCombo(oMap, listName, "A", "ACIK");
		GuimlUtil.wrapMyCombo(oMap, listName, "K", "KAPALI");

		return oMap;

	}

	@GraymoundService("BNSPR_TRN1503_HESAPLARI_GETIR")
	public static GMMap getIslemListesi(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1503.GetIslemListesi(?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setInt(i++, iMap.getInt("MUSTERI"));
			stmt.setString(i, iMap.getString("STATU"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "TABLE");
			return oMap;

		}

		catch (Exception e) {

			throw new GMRuntimeException(0, e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN1503_SAVE")
	public static GMMap save(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			HaTalepDetayTx haTalepDetayTx = null;// (HaTalepDetayTx)session.get(HaTalepDetayTx.class, iMap.getBigDecimal("TRX_NO"));
			if (haTalepDetayTx == null) {
				haTalepDetayTx = new HaTalepDetayTx();
			}

			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			String haKod = iMap.getString("IN_N_HAKOD");
			String uyeKod = iMap.getString("IN_N_UYEKOD");
			BigDecimal aktifNo = iMap.getBigDecimal("IN_N_MUSTERINO");

			BigDecimal TlTutar = iMap.getBigDecimal("IN_N_TALEPTUTAR");
			Long LotTutar = iMap.getLong("IN_N_TALEPLOT");
			Long AltSinir = iMap.getLong("IN_N_ALTSINIR");

			if (TlTutar == null)
				TlTutar = new BigDecimal(0);
			if (LotTutar == null)
				LotTutar = new Long(0);
			if (AltSinir == null)
				AltSinir = new Long(0);

			HaTalepDetayTx hbx;

			// Tabloda yer almayacak elamanlar�n kay�t edilmemesi i�in �nceki kay�tar� sil

			List<HaTalepDetayTx> bbPRM = session.createCriteria(HaTalepDetayTx.class).add(Restrictions.eq("id.txNo", txNo)).list();


			if (bbPRM != null) {
				for (HaTalepDetayTx bb : bbPRM) {
					session.delete(bb);
				}
			}
			session.flush();

			// belirsiz konular !!!!!!!!!!!!!!!!

			haTalepDetayTx.setBlokeBozdurmaYontemi("S");
			haTalepDetayTx.setBlokeBozdurmaSirasi(new BigDecimal(0));
			haTalepDetayTx.setOdemeTipi("P"); // bu durum degisebilir.

			// eof belirsiz

			HaTalepDetayTxId haid = new HaTalepDetayTxId();
			
			haTalepDetayTx.setStatus("A");
			haTalepDetayTx.setTalepTipi("B");
			haTalepDetayTx.setTxType("S");
			haTalepDetayTx.setTalepArtirimi("N");
			haTalepDetayTx.setDagitimDurumu("T");
			haTalepDetayTx.setTahsisGrup(new BigDecimal(23));// bireysel 23
			haTalepDetayTx.setTeklifNumarasi(new BigDecimal(1));
			haTalepDetayTx.setTcKimlik(iMap.getLong("IN_N_TCKNVKN"));
			haTalepDetayTx.setAktifBankMustNo(aktifNo);
			haTalepDetayTx.setTalepAltSinirLot(AltSinir);
			haTalepDetayTx.setTalepLot(LotTutar);
			haTalepDetayTx.setTalepTutar(TlTutar);
			haTalepDetayTx.setUyeKod(uyeKod);
			haTalepDetayTx.setHaKod(haKod);
			haid.setTxNo(txNo);
			haid.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO"));
			haTalepDetayTx.setId(haid);
			session.saveOrUpdate(haTalepDetayTx);
			session.flush();
			iMap.put("TRX_NAME", "1503");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

}
