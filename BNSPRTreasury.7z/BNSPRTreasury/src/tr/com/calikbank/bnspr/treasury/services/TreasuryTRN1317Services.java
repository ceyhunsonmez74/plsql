package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTx;
import tr.com.calikbank.bnspr.dao.HznSpotfwdTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1317Services {

	@GraymoundService("BNSPR_TRN1317_GET_TRANSFER_TXNO")
	public static GMMap getTransfertxNo(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn1307.SPFW_BilgiAktar(?) }");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1317_GET_TRANSFER_DATA")
	public static GMMap getTransferData(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			
			
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			oMap.put("TX_NO", hznSpotfwdTx.getId().getTxNo());
			oMap.put("REF_NO", hznSpotfwdTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSpotfwdTx.getUrunTurKod(), "1317/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznSpotfwdTx.getAlisTutari());
			oMap.put("ALIS_HESAP_TURU", hznSpotfwdTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznSpotfwdTx.getSatisTutari());
			oMap.put("SATIS_HESAP_TURU", hznSpotfwdTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznSpotfwdTx.getDealerNo());
			oMap.put("KREDI_TEKLIF_SATIR_NUMARA", hznSpotfwdTx.getKrediTeklifSatirNumara());
			oMap.put("SOZLESME_NO", hznSpotfwdTx.getSozlesmeNo());
			oMap.put("BANKA_MUSTERI_NO", hznSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznSpotfwdTx.getSatisKur());
			oMap.put("GN_ALIS_HESAP_NO", hznSpotfwdTx.getGnAlisHesapNo());
			oMap.put("PARITE", hznSpotfwdTx.getParite());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSpotfwdTx.getDealerNo(), "1317/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSpotfwdTx.getBankaMusteriNo(), "1317/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getAlisHesapNo(), hznSpotfwdTx.getBankaMusteriNo(), hznSpotfwdTx.getAlisDovizKodu(), "1317/LOV_ALIS_HESAP_NO", "UNVAN"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getSatisHesapNo(),hznSpotfwdTx.getBankaMusteriNo(), hznSpotfwdTx.getSatisDovizKodu(), "1317/LOV_SATIS_HESAP_NO", "UNVAN"));
			oMap.put("AS", hznSpotfwdTx.getAS());
			oMap.put("ACIKLAMA", hznSpotfwdTx.getAciklama());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1317_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
	
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			HznSpotfwdTxId id = null;
			
			if(hznSpotfwdTx == null) {
				hznSpotfwdTx = new HznSpotfwdTx();
				id = new HznSpotfwdTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setReferans(iMap.getString("TRX_NO"));
			} else {
				id = hznSpotfwdTx.getId();
			}

			hznSpotfwdTx.setId(id);
			hznSpotfwdTx.setModulTurKod("HAZINE");
			hznSpotfwdTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznSpotfwdTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznSpotfwdTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznSpotfwdTx.setAlisTutari(iMap.getBigDecimal("ALIS_TUTARI"));
			hznSpotfwdTx.setAlisHesapTuru(iMap.getString("ALIS_HESAP_TURU"));
			hznSpotfwdTx.setAlisHesapNo(iMap.getBigDecimal("ALIS_HESAP_NO"));
			hznSpotfwdTx.setSatisTutari(iMap.getBigDecimal("SATIS_TUTARI"));
			hznSpotfwdTx.setSatisHesapTuru(iMap.getString("SATIS_HESAP_TURU"));
			hznSpotfwdTx.setSatisHesapNo(iMap.getBigDecimal("SATIS_HESAP_NO"));
			hznSpotfwdTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
			hznSpotfwdTx.setKrediTeklifSatirNumara(iMap.getBigDecimal("KREDI_TEKLIF_SATIR_NUMARA"));
			hznSpotfwdTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznSpotfwdTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznSpotfwdTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznSpotfwdTx.setAlisDovizKodu(iMap.getString("ALIS_DOVIZ_KODU"));
			hznSpotfwdTx.setSatisDovizKodu(iMap.getString("SATIS_DOVIZ_KODU"));
			hznSpotfwdTx.setAlisKur(iMap.getBigDecimal("ALIS_KUR"));
			hznSpotfwdTx.setSatisKur(iMap.getBigDecimal("SATIS_KUR"));
			hznSpotfwdTx.setParite(iMap.getBigDecimal("PARITE"));
			hznSpotfwdTx.setGnAlisHesapNo(iMap.getBigDecimal("GN_ALIS_HESAP_NO"));
			hznSpotfwdTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			hznSpotfwdTx.setAS(iMap.getString("AS"));
			hznSpotfwdTx.setAciklama(iMap.getString("ACIKLAMA"));
			session.saveOrUpdate(hznSpotfwdTx);
			session.flush();
			iMap.put("TRX_NAME", "1317");
			
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1317_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznSpotfwdTx hznSpotfwdTx = (HznSpotfwdTx) session.createCriteria(HznSpotfwdTx.class).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();
			
			oMap.put("TX_NO", hznSpotfwdTx.getId().getTxNo());
			oMap.put("REF_NO", hznSpotfwdTx.getId().getReferans());
			oMap.put("URUN_TUR_KOD", LovHelper.diLov(hznSpotfwdTx.getUrunTurKod(), "1317/LOV_URUN_TUR", "KOD"));
			oMap.put("URUN_SINIF_KOD", hznSpotfwdTx.getUrunSinifKod());
			oMap.put("DEAL_TARIHI", hznSpotfwdTx.getDealTarihi());
			oMap.put("ALIS_TUTARI", hznSpotfwdTx.getAlisTutari());
			oMap.put("ALIS_HESAP_TURU", hznSpotfwdTx.getAlisHesapTuru());
			oMap.put("ALIS_HESAP_NO", hznSpotfwdTx.getAlisHesapNo());
			oMap.put("SATIS_TUTARI", hznSpotfwdTx.getSatisTutari());
			oMap.put("SATIS_HESAP_TURU", hznSpotfwdTx.getSatisHesapTuru());
			oMap.put("SATIS_HESAP_NO", hznSpotfwdTx.getSatisHesapNo());
			oMap.put("DEALER_NO", hznSpotfwdTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznSpotfwdTx.getBankaMusteriNo());
			oMap.put("VALOR_TARIHI", hznSpotfwdTx.getValorTarihi());
			oMap.put("ALIS_DOVIZ_KODU", hznSpotfwdTx.getAlisDovizKodu());
			oMap.put("SATIS_DOVIZ_KODU", hznSpotfwdTx.getSatisDovizKodu());
			oMap.put("ALIS_KUR", hznSpotfwdTx.getAlisKur());
			oMap.put("SATIS_KUR", hznSpotfwdTx.getSatisKur());
			oMap.put("PARITE", hznSpotfwdTx.getParite());
			oMap.put("GN_ALIS_HESAP_NO", hznSpotfwdTx.getGnAlisHesapNo());
			oMap.put("DEALER_ADI", LovHelper.diLov(hznSpotfwdTx.getDealerNo(), "1317/LOV_DEALER", "ISIM"));
			oMap.put("BANKA_MUSTERI_ADI", LovHelper.diLov(hznSpotfwdTx.getBankaMusteriNo(), "1317/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("ALIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getAlisHesapNo(),hznSpotfwdTx.getBankaMusteriNo(), hznSpotfwdTx.getAlisDovizKodu(), "1317/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("SATIS_HESAP_KISAISIM", LovHelper.diLov(hznSpotfwdTx.getSatisHesapNo(),hznSpotfwdTx.getBankaMusteriNo(), hznSpotfwdTx.getSatisDovizKodu(), "1317/LOV_SATIS_HESAP_NO", "KISA_ISIM"));
			oMap.put("AS", hznSpotfwdTx.getAS());
			oMap.put("ACIKLAMA", hznSpotfwdTx.getAciklama());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
