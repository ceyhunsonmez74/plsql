package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.HznAdepoApOdmplanTx;
import tr.com.calikbank.bnspr.dao.HznAdepoApOdmplanTxId;
import tr.com.calikbank.bnspr.dao.HznAdepoFaizOdmplanTx;
import tr.com.calikbank.bnspr.dao.HznAdepoFaizOdmplanTxId;
import tr.com.calikbank.bnspr.dao.HznAlinandepoTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1310Services {

	@GraymoundService("BNSPR_TRN1310_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		iMap.put("KOD", "HZN_VADE_ISLEM_BILGISI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_VADE_ISLEM_BILGISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_AP_ODEME_SEKLI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_AP_ODEME_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_AP_TAKSIT_ODM_SEKLI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_AP_TAKSIT_ODM_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_FAIZ_HESAP_TUTAR");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_FAIZ_HESAP_TUTAR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_DEPO_ISLEM_TURU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_DEPO_ISLEM_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "KRE_FAIZ_ENDEKS_KOD");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("KRE_FAIZ_ENDEKS_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "HZN_TAKSIT_DURUMU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("HZN_TAKSIT_DURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		DALUtil.fillComboBox(oMap, "ANA_PARA_ODEME_SIKLIK_TIPI", true, "SELECT KOD,ACIKLAMA FROM v_ml_muh_tahakkuksiklik_kod_pr MT WHERE MT.KOD IN ( 'GN' , 'AY' , 'YIL' )");
		
		DALUtil.fillComboBox(oMap, "FAIZ_SIKLIK_TIPI", true, "SELECT KOD,ACIKLAMA FROM v_ml_muh_tahakkuksiklik_kod_pr MT");
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1310_TRANSACTION_START")
	public static Map<?, ?> trn1310Transactionstart(GMMap iMap) {
		
		try {
			iMap.put("TRX_NAME", "1310");			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN1310_SWIFT_OLUSTUR")
	public static GMMap swiftOlustur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmtNetting = null;
        String isNetting = "H";
		
		GMMap oMap = new GMMap();
		
		if ("1".equals(iMap.getString("P_VKS")))
		return oMap;
		
		try {
			conn = DALUtil.getGMConnection();

			if(iMap.getString("ISLEM_KOD").equals("1310") || iMap.getString("ISLEM_KOD").equals("1313") || iMap.getString("ISLEM_KOD").equals("1314")){ //alinan depo ise
				stmtNetting = conn.prepareCall("{call PKG_TRN1306.Netting_Swift_Kontrolu(?,?,?,?,?) }");
				
				stmtNetting.setBigDecimal(1, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
				stmtNetting.setString(2, "DEPO");
				stmtNetting.setString(3, iMap.getString("SATIS_DOVIZ_KODU"));
				stmtNetting.setString(4, iMap.getString("SATIS_HESAP_TURU"));
	
				stmtNetting.registerOutParameter(5, Types.VARCHAR);
	
				stmtNetting.execute();
				isNetting = stmtNetting.getString(5);
			
			}
			
		//	if(isNetting.equals("H")){
				stmt = conn.prepareCall("{call PKG_HZN_SWIFT.SWIFT_OLUSTUR(?,?,?,?)}");
			    
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_KOD"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.setString(3, "S");
				stmt.setString(4, isNetting);
				stmt.execute();
	//		}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	
	
	
	@GraymoundService("BNSPR_TRN1310_SAVE")
	public static GMMap save(GMMap iMap) {
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, iMap.getBigDecimal("TRX_NO"));
			if(hznAlinanDepoTx == null) {
				hznAlinanDepoTx = new HznAlinandepoTx();
			}
			
			hznAlinanDepoTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hznAlinanDepoTx.setModulTurKod("HAZINE");
			hznAlinanDepoTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			hznAlinanDepoTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			hznAlinanDepoTx.setDealTarihi(iMap.getDate("DEAL_TARIHI"));
			hznAlinanDepoTx.setReferans(iMap.getString("REFERANS"));
			hznAlinanDepoTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
			hznAlinanDepoTx.setDealerNo(iMap.getString("DEALER_NO"));
			hznAlinanDepoTx.setBankaMusteriNo(iMap.getBigDecimal("BANKA_MUSTERI_NO"));
			hznAlinanDepoTx.setBankaHesapNo(iMap.getBigDecimal("BANKA_HESAP_NO"));
			hznAlinanDepoTx.setGirisHesapTuru(iMap.getString("GIRIS_HESAP_TURU"));
			hznAlinanDepoTx.setGirisHesapNo(iMap.getBigDecimal("GIRIS_HESAP_NO"));
			hznAlinanDepoTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
			hznAlinanDepoTx.setCikisHesapTuru(iMap.getString("CIKIS_HESAP_TURU"));
			hznAlinanDepoTx.setCikisHesapNo(iMap.getBigDecimal("CIKIS_HESAP_NO"));
			hznAlinanDepoTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			hznAlinanDepoTx.setTutar(iMap.getBigDecimal("TUTAR"));
			hznAlinanDepoTx.setAnaparaOdemeSekli(iMap.getString("ANAPARA_ODEME_SEKLI"));
			hznAlinanDepoTx.setVadeTarihi(iMap.getDate("VADE_TARIHI"));
			hznAlinanDepoTx.setEsasGunSayisi(iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			hznAlinanDepoTx.setTenor(iMap.getBigDecimal("TENOR"));
			hznAlinanDepoTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI"));
			hznAlinanDepoTx.setVadeIslemBilgisi(iMap.getBigDecimal("VADE_ISLEM_BILGISI"));
			hznAlinanDepoTx.setAnaparaTaksitAdedi(iMap.getBigDecimal("ANAPARA_TAKSIT_ADEDI"));
			hznAlinanDepoTx.setAnaparaOdemeSiklikTipi(iMap.getString("ANAPARA_ODEME_SIKLIK_TIPI"));
			hznAlinanDepoTx.setAnaparaOdemeSiklik(iMap.getBigDecimal("ANAPARA_ODEME_SIKLIK"));
			hznAlinanDepoTx.setAnaparaTaksitliOdemeSekli(iMap.getString("ANAPARA_TAKSITLI_ODEME_SEKLI"));
			hznAlinanDepoTx.setFaizEndeksKodu(iMap.getString("FAIZ_ENDEKS_KODU"));
			hznAlinanDepoTx.setSpread(iMap.getString("SPREAD"));
			hznAlinanDepoTx.setSpreadOrani(iMap.getBigDecimal("SPREAD_ORANI"));
			hznAlinanDepoTx.setFaizEndeksPeriod(iMap.getString("FAIZ_ENDEKS_PERIOD"));
			hznAlinanDepoTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			hznAlinanDepoTx.setFaizSiklikTipi(iMap.getString("FAIZ_SIKLIK_TIPI"));
			hznAlinanDepoTx.setFaizSiklik(iMap.getBigDecimal("FAIZ_SIKLIK"));
			hznAlinanDepoTx.setFaizHesaplanacakTutar(iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			hznAlinanDepoTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			hznAlinanDepoTx.setGirisMuhabirMusteriNo(iMap.getString("GIRISMUSTERIMUHABIRNO"));
			hznAlinanDepoTx.setCikisMuhabirMusteriNo(iMap.getString("CIKISMUSTERIMUHABIRNO"));
			hznAlinanDepoTx.setMurabahaId(iMap.getBigDecimal("MURABAHA_ID"));
			hznAlinanDepoTx.setDigerReferans(iMap.getString("DIGER_REFERANS"));
			hznAlinanDepoTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			

			hznAlinanDepoTx.setNegatifFaiz(iMap.getBoolean("NEGATIF_FAIZ")==true?new BigDecimal(1):new BigDecimal(0));
			
			hznAlinanDepoTx.setOrderId(iMap.getString("ORDER_ID"));
			hznAlinanDepoTx.setCounterParty(iMap.getString("COUNTER_PARTY"));
			hznAlinanDepoTx.setSourcePlatform(iMap.getString("SOURCE_PLATFORM"));
			hznAlinanDepoTx.setMessageId(iMap.getString("MESSAGE_ID"));
			hznAlinanDepoTx.setOncekiMesajId(iMap.getString("ONCEKI_MESAJ_ID"));
			
			session.saveOrUpdate(hznAlinanDepoTx);
			session.flush();
			
			GMMap oMap = new GMMap();
			return oMap;
			
		} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		}
		
	}
	@GraymoundService("BNSPR_TRN1310_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			BigDecimal txNo = iMap.getBigDecimal("TX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			HznAlinandepoTx hznAlinanDepoTx = (HznAlinandepoTx)session.get(HznAlinandepoTx.class, txNo);
			
			oMap.put("TRX_NO", hznAlinanDepoTx.getTxNo());
			oMap.put("URUN_TUR_KOD", hznAlinanDepoTx.getUrunTurKod());
			
			oMap.put("URUN_SINIF_KOD", hznAlinanDepoTx.getUrunSinifKod());

			oMap.put("REFERANS", hznAlinanDepoTx.getReferans());
			oMap.put("ISLEM_TURU", hznAlinanDepoTx.getIslemTuru());
			oMap.put("DEALER_NO", hznAlinanDepoTx.getDealerNo());
			oMap.put("BANKA_MUSTERI_NO", hznAlinanDepoTx.getBankaMusteriNo());
			oMap.put("BANKA_HESAP_NO", hznAlinanDepoTx.getBankaHesapNo());
			oMap.put("GIRIS_HESAP_TURU", hznAlinanDepoTx.getGirisHesapTuru());
			oMap.put("GIRIS_HESAP_NO", hznAlinanDepoTx.getGirisHesapNo());
			oMap.put("CIKIS_HESAP_TURU", hznAlinanDepoTx.getCikisHesapTuru());
			oMap.put("CIKIS_HESAP_NO", hznAlinanDepoTx.getCikisHesapNo());
			oMap.put("DOVIZ_KODU", hznAlinanDepoTx.getDovizKodu());
			oMap.put("TUTAR", hznAlinanDepoTx.getTutar());
			oMap.put("VALOR_TARIHI", hznAlinanDepoTx.getValorTarihi());
			oMap.put("ANAPARA_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaOdemeSekli());
			oMap.put("VADE_TARIHI", hznAlinanDepoTx.getVadeTarihi());
			oMap.put("ESAS_GUN_SAYISI", hznAlinanDepoTx.getEsasGunSayisi());
			oMap.put("TENOR", hznAlinanDepoTx.getTenor());
			oMap.put("FAIZ_TUTARI", hznAlinanDepoTx.getFaizTutari());
			oMap.put("VADE_ISLEM_BILGISI", hznAlinanDepoTx.getVadeIslemBilgisi());
			oMap.put("DEAL_TARIHI", hznAlinanDepoTx.getDealTarihi());
			oMap.put("ANAPARA_TAKSIT_ADEDI", hznAlinanDepoTx.getAnaparaTaksitAdedi());
			oMap.put("ANAPARA_ODEME_SIKLIK_TIPI", hznAlinanDepoTx.getAnaparaOdemeSiklikTipi());
			oMap.put("ANAPARA_ODEME_SIKLIK", hznAlinanDepoTx.getAnaparaOdemeSiklik());
			oMap.put("ANAPARA_TAKSITLI_ODEME_SEKLI", hznAlinanDepoTx.getAnaparaTaksitliOdemeSekli());
			oMap.put("FAIZ_ENDEKS_KODU", hznAlinanDepoTx.getFaizEndeksKodu());
			oMap.put("SPREAD", hznAlinanDepoTx.getSpread());
			oMap.put("SPREAD_ORANI", hznAlinanDepoTx.getSpreadOrani());
			oMap.put("FAIZ_ENDEKS_PERIOD", hznAlinanDepoTx.getFaizEndeksPeriod());
			oMap.put("FAIZ_ORANI", hznAlinanDepoTx.getFaizOrani());
			oMap.put("FAIZ_SIKLIK_TIPI", hznAlinanDepoTx.getFaizSiklikTipi());
			oMap.put("FAIZ_SIKLIK", hznAlinanDepoTx.getFaizSiklik());
			oMap.put("FAIZ_HESAPLANACAK_TUTAR", hznAlinanDepoTx.getFaizHesaplanacakTutar());
			oMap.put("ACIKLAMA", hznAlinanDepoTx.getAciklama());
			
			oMap.put("ALIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getGirisHesapNo(),hznAlinanDepoTx.getDovizKodu(), 
					hznAlinanDepoTx.getGirisHesapTuru(), hznAlinanDepoTx.getDovizKodu(), hznAlinanDepoTx.getGirisHesapTuru(),
					hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("SATIS_HESAP_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getCikisHesapNo(),hznAlinanDepoTx.getDovizKodu(), 
					hznAlinanDepoTx.getCikisHesapTuru(), hznAlinanDepoTx.getDovizKodu(), hznAlinanDepoTx.getCikisHesapTuru(), 
					 hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_ALIS_HESAP_NO", "KISA_ISIM"));
			
			oMap.put("BANKA_MUSTERI_KISA_ISIM", LovHelper.diLov(hznAlinanDepoTx.getBankaMusteriNo(), "1310/LOV_BANKA_MUSTERI", "UNVAN"));
			oMap.put("DEALER_ADI", LovHelper.diLov(hznAlinanDepoTx.getDealerNo(), "1310/LOV_DEALER", "ISIM"));
			
			
			oMap.put("GIRISMUSTERIMUHABIRNO", hznAlinanDepoTx.getGirisMuhabirMusteriNo());
			oMap.put("CIKISMUSTERIMUHABIRNO", hznAlinanDepoTx.getCikisMuhabirMusteriNo());
			oMap.put("MURABAHA_ID", hznAlinanDepoTx.getMurabahaId());
			oMap.put("DIGER_REFERANS", hznAlinanDepoTx.getDigerReferans());
			oMap.put("ISTATISTIK_KODU", hznAlinanDepoTx.getIstatistikKodu());
			oMap.put("DI_ISTATISTIK_KODU", LovHelper.diLov(hznAlinanDepoTx.getIstatistikKodu(), "1330/LOV_ISTATISTIK", "ACIKLAMA"));
			
			if (hznAlinanDepoTx.getNegatifFaiz()!=null)
				oMap.put("NEGATIF_FAIZ", hznAlinanDepoTx.getNegatifFaiz().intValue()==1?true:false);
			else
				oMap.put("NEGATIF_FAIZ", false);
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	@GraymoundService("BNSPR_TRN1310_ODEME_PLANI_OLUSTUR")
	public static GMMap odemePlaniOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1310.AnaPara_Odeme_Plani_Olustur(?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ADEDI"));
			stmt.setString(i++, iMap.getString("ODEME_ARALIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_ARALIK"));
			stmt.setString(i++, iMap.getString("TAKSITLI_ODEME_SEKLI"));
			if(iMap.getDate("VALOR_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CIKIS_HESAP_NO"));
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.execute();
		//	new SimpleDateFormat("dd.MM.yyyy").format(stmt.getDate(--i))
			oMap.put("VADE_TARIHI",stmt.getDate(--i));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1310_ODEME_PLANI_SIL")
	public static GMMap odemePlaniSil(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1310.AnaPara_Odeme_Plani_Sil(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1310_FAIZ_ODEME_PLANI_OLUSTUR")
	public static GMMap faizOdemePlaniOlustur(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1310.Faiz_Odeme_Plani_Olustur(?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ADEDI"));
			stmt.setString(i++, iMap.getString("AP_ODEME_ARALIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("AP_ODEME_ARALIK"));
			stmt.setString(i++, iMap.getString("FAIZ_ODEME_ARALIK_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ODEME_ARALIK"));
			if(iMap.getDate("VALOR_TARIHI") ==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("CIKIS_HESAP_NO"));
			if(iMap.getDate("VADE_TARIHI") ==null)
				stmt.setDate(i++, null);
			else
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			
			
			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1310_FAIZ_ODEME_PLANI_SIL")
	public static GMMap faizOdemePlaniSil(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1310.Faiz_Odeme_Plani_Sil(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1310_ODEME_PLANI_TUTAR_HESAPLA")
	public static GMMap odemePlaniTutarHesapla(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			
			Session session 	= DAOSession.getSession("BNSPRDal");
			String 	tableName 	= "CBS_HAZINE_ADEPO_AP_ODMPLISL";
			
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){
				HznAdepoApOdmplanTxId id = new HznAdepoApOdmplanTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSirano	(iMap.getBigDecimal	(tableName, i, "SIRANO"));
				
				HznAdepoApOdmplanTx hznAdepoApOdmplanTx = (HznAdepoApOdmplanTx)(session.get(HznAdepoApOdmplanTx.class, id));
				
				if(hznAdepoApOdmplanTx == null)
					hznAdepoApOdmplanTx = new HznAdepoApOdmplanTx();
				
				hznAdepoApOdmplanTx.setId(id);
				hznAdepoApOdmplanTx.setVadeTarihi(iMap.getDate(tableName, i, "VADE_TARIHI"));
				hznAdepoApOdmplanTx.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				hznAdepoApOdmplanTx.setTaksitDurumu(iMap.getString(tableName, i, "TAKSIT_DURUMU"));
				session.saveOrUpdate(hznAdepoApOdmplanTx);
			}
			session.flush();
			
			tableName = "CBS_HAZINE_ADEPO_FAIZ_ODMPLISL";
			
			list = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++){
				HznAdepoFaizOdmplanTxId id = new HznAdepoFaizOdmplanTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSirano	(iMap.getBigDecimal	(tableName, i, "SIRANO"));
				
				HznAdepoFaizOdmplanTx hznAdepoApOdmplanTx = (HznAdepoFaizOdmplanTx)(session.get(HznAdepoFaizOdmplanTx.class, id));
				
				if(hznAdepoApOdmplanTx == null)
					hznAdepoApOdmplanTx = new HznAdepoFaizOdmplanTx();
				
				hznAdepoApOdmplanTx.setId(id);
				hznAdepoApOdmplanTx.setVadeTarihi(iMap.getDate(tableName, i, "VADE_TARIHI"));
				hznAdepoApOdmplanTx.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				hznAdepoApOdmplanTx.setTaksitDurumu(iMap.getString(tableName, i, "TAKSIT_DURUMU"));
				session.saveOrUpdate(hznAdepoApOdmplanTx);
			}
			session.flush();
			
			GMServiceExecuter.execute("BNSPR_TRN1310_FAIZ_ODEME_PLANI_TUTAR_HESAPLA", iMap);
			oMap.put("CBS_HAZINE_ADEPO_FAIZ_ODMPLISL", GMServiceExecuter.execute("BNSPR_TRN1310_GET_FAIZ_ODEME_PLANI", iMap).get("RESULTS"));
			oMap.put("CBS_HAZINE_ADEPO_AP_ODMPLISL", GMServiceExecuter.execute("BNSPR_TRN1310_GET_ANAPARA_ODEME_PLANI", iMap).get("RESULTS"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1310_FAIZ_ODEME_PLANI_TUTAR_HESAPLA")
	public static GMMap faizOdemePlaniTutarHesapla(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN1310.Faiz_OdmPlan_Tutar_Hesapla(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("FAIZ_ODEME_ARALIK_TIPI"));
			if(iMap.getDate("VALOR_TARIHI") ==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("AP_ODEME_SEKLI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLAYACAK_TUTAR"));
			
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1310_GET_FAIZ_ODEME_PLANI")
	public static GMMap getFaizOdemePlani(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		List<?> faizOdemePlaniList = session.createCriteria(HznAdepoFaizOdmplanTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		try{
			int row = 0;
			
			String tabName = "CBS_HAZINE_ADEPO_FAIZ_ODMPLISL";
			for (Iterator<?> iterator = faizOdemePlaniList.iterator(); iterator.hasNext();row++) {
				HznAdepoFaizOdmplanTx faizOdeme = (HznAdepoFaizOdmplanTx) iterator.next();
				oMap.put(tabName,row, "SIRANO",faizOdeme.getId().getSirano() );
				oMap.put(tabName, row, "TAKSIT_DURUMU",faizOdeme.getTaksitDurumu() );
				oMap.put(tabName,row,"TUTAR",faizOdeme.getTutar() );
				oMap.put(tabName,row,"VADE_TARIHI",faizOdeme.getVadeTarihi() );
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			
		}
		
	}
	@GraymoundService("BNSPR_TRN1310_GET_ANAPARA_ODEME_PLANI")
	public static GMMap getAnaparaOdemePlani(GMMap iMap){
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");

		List<?> faizOdemePlaniList = session.createCriteria(HznAdepoApOdmplanTx.class).
			add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		try{
			int row = 0;
			String tabName = "CBS_HAZINE_ADEPO_AP_ODMPLISL";
			for (Iterator<?> iterator = faizOdemePlaniList.iterator(); iterator.hasNext();row++) {
				HznAdepoApOdmplanTx apOdeme = (HznAdepoApOdmplanTx) iterator.next();
				oMap.put(tabName, row, "SIRANO",apOdeme.getId().getSirano() );
				oMap.put(tabName, row, "TAKSIT_DURUMU",apOdeme.getTaksitDurumu() );
				oMap.put(tabName,row,"TUTAR",apOdeme.getTutar() );
				oMap.put(tabName,row,"VADE_TARIHI",apOdeme.getVadeTarihi() );
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			
		}
	}
	@GraymoundService("BNSPR_TRN1310_CALCULATE_TENOR")
	public static GMMap getCalculatedTenor(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN1310.Calculate_Tenor(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			stmt.execute();
			
			oMap.put("TENOR",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	@GraymoundService("BNSPR_TRN1310_FAIZ_HESAPLA")
	public static GMMap getFaizHesabi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_TRN1310.Faiz_Tutari_Hesapla(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TENOR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			stmt.execute();
			
			oMap.put("FAIZ_TUTARI",stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN1310_FAIZ_HESAPLA_MURABAHA")
	public static GMMap getFaizHesabiMurabaha(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_TRN1310.Faiz_Tutari_Hesapla_M(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setString(i++, iMap.getString("ANAPARA_ODEME_SEKLI"));
			stmt.setString(i++, iMap.getString("FAIZ_SIKLIK_TIPI"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TENOR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ESAS_GUN_SAYISI"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_HESAPLANACAK_TUTAR"));
			stmt.execute();
			
			if (iMap.getBigDecimal("TUTAR")!=null)
			{
			BigDecimal Vadetutar=new BigDecimal(0);
			BigDecimal hesaplanan=new BigDecimal(0);
			//RoundingMode UNNECESSARY=RoundingMode.UNNECESSARY;
			//MathContext mc=new MathContext(7,UNNECESSARY);
		
			hesaplanan=new BigDecimal(stmt.getString(1));
			Vadetutar=hesaplanan.add(Vadetutar);
			Vadetutar=Vadetutar.add(iMap.getBigDecimal("TUTAR"));
			
			oMap.put("FAIZ_TUTARI",Vadetutar);
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN1310_ENDEKS_FAIZ_ORAN_AL")
	public static GMMap getEndeksFaizOrani(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_HAZINE.Endeks_Faiz_Oran_Al(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_KODU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("FAIZ_ENDEKS_PERIODU"));
			stmt.execute();
			
			oMap.put("FAIZ_ORANI",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1310_SAVE_MURABAHA_INFO")
    public static GMMap saveMurabahaInfo(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        
        try{
            
            if(iMap.getString("METAL").isEmpty()||iMap.getBigDecimal("MIKTAR").compareTo(BigDecimal.ZERO)<1||iMap.getString("MIKTAR_TUR").isEmpty()
                 ||iMap.getString("KONUM").isEmpty()||iMap.getBigDecimal("BIRIM_FIYAT").compareTo(BigDecimal.ZERO)<1||iMap.getBigDecimal("ALICI_BROKER")==null||iMap.getBigDecimal("SATICI_BROKER")==null
                 ||iMap.getBigDecimal("ALICI_HESAP_NO")==null||iMap.getBigDecimal("SATICI_HESAP_NO")==null||iMap.getString("REFERANS").isEmpty()||iMap.getBigDecimal("TUTAR").compareTo(BigDecimal.ZERO)<1)
            {
                iMap.put("HATA_NO", new BigDecimal(4290));
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
                
            }
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ?=call PKG_TRN1310.Murabaha_Kaydet(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++, Types.NUMERIC);  
            stmt.setString(i++, iMap.getString("METAL"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MIKTAR"));
            stmt.setString(i++, iMap.getString("MIKTAR_TUR"));
            stmt.setString(i++, iMap.getString("KONUM"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("BIRIM_FIYAT"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("ALICI_BROKER"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("SATICI_BROKER"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("ALICI_HESAP_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("SATICI_HESAP_NO"));
            stmt.setString(i++, iMap.getString("REFERANS"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
            stmt.setString(i++, iMap.getString("DEPO_TURU"));
            stmt.setDate(i++,new java.sql.Date(iMap.getDate("ANLASMA_TARIHI").getTime()));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("VADESINDEKI_BIRIM_FIYAT"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.execute();
            
            oMap.put("MURABAHA_ID",stmt.getBigDecimal(1));
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	@GraymoundService("BNSPR_TRN1310_GET_MURABAHA_INFO")
    public static GMMap getMurabahaInfo(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ?=call PKG_TRN1310.getMurabahaInfo(?)}");
            int i = 1;
            stmt.registerOutParameter(i++, -10);  
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MURABAHA_ID"));            
            stmt.execute();
            
            rSet = (ResultSet)stmt.getObject(1);
            while(rSet.next()){
                oMap.put("METAL" , rSet.getString("METAL"));
                oMap.put("MIKTAR" , rSet.getBigDecimal("MIKTAR"));
                oMap.put("MIKTAR_TUR" , rSet.getString("MIKTAR_TUR"));
                oMap.put("KONUM" , rSet.getString("KONUM"));
                oMap.put("BIRIM_FIYAT" , rSet.getBigDecimal("BIRIM_FIYAT"));
                oMap.put("TUTAR" , rSet.getBigDecimal("TUTAR"));
                oMap.put("ALICI_BROKER" , rSet.getBigDecimal("ALICI_BROKER"));
                oMap.put("ALICI_BROKER_UNVAN" , rSet.getString("ALICI_BROKER_UNVAN"));
                oMap.put("ALICI_HESAP" , rSet.getBigDecimal("ALICI_HESAP"));
                oMap.put("SATICI_BROKER" , rSet.getBigDecimal("SATICI_BROKER"));
                oMap.put("SATICI_BROKER_UNVAN" , rSet.getString("SATICI_BROKER_UNVAN"));
                oMap.put("SATICI_HESAP" , rSet.getBigDecimal("SATICI_HESAP"));
                oMap.put("REFERANS" , rSet.getString("REFERANS"));
                oMap.put("VADESINDEKI_FIYAT" , rSet.getBigDecimal("VADESINDEKI_BIRIM_FIYAT"));
                oMap.put("ANLASMA_TARIHI" , rSet.getDate("ANLASMA_TARIHI"));
                
            }
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	@GraymoundService("BNSPR_TRN1310_GET_MURABAHA_ANLASMA_TARIHI")
    public static GMMap getMurabahaAnlasmaTarihi(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ?=call PKG_TRN1310.getMurabahaAnlasmaTarihi(?)}");
            int i = 1;
            stmt.registerOutParameter(i++,Types.DATE);  
            stmt.setString(i++, iMap.getString("MUSTERI_NO"));            
            stmt.execute();
            
            Date date =  stmt.getDate(1);
            
                oMap.put("ANLASMA_TARIHI" , date);                
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	   @GraymoundService("BNSPR_TRN1310_GET_MURABAHA_PARAMS")
	    public static GMMap getMurabahaParameters(GMMap iMap){
	        GMMap oMap = new GMMap();
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        
	        try{
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{ ?=call PKG_TRN1310.getMurabahaParameters}");
	            int i = 1;
	            stmt.registerOutParameter(i++,-10); 
	            stmt.execute();
	            
	            rSet = (ResultSet)stmt.getObject(1);
	            while(rSet.next()){
	              if(!rSet.getString("KEY").isEmpty()&&rSet.getString("KEY").equals("SOL")){
	                oMap.put("SOL" ,rSet.getString("TEXT"));
	            }
	              else{
	                  oMap.put("SAG" ,rSet.getString("TEXT"));
	            }
	            
	            }                
	            
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
	   @GraymoundService("BNSPR_TRN1310_BLOKE_HESAP_KONTROL")
		public static GMMap blokeHesapKontrol(GMMap iMap){
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			
			try{ 
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ ?=call PKG_TRN1310.hesaptaBlokeVarmi(?)}");
				int i = 1;
				stmt.registerOutParameter(i++, Types.VARCHAR);	
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KONTROL_BLOKE_HESAP"));	
				stmt.execute();
				
				oMap.put("HESAP_BLOKE_MI",stmt.getString(1));
					
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
	   @GraymoundService("BNSPR_TRN1310_MUKERRER_KONTROLU")
		public static GMMap MukerrerKontrol(GMMap iMap){
			Connection conn = null;
			CallableStatement stmt = null;
			
			GMMap oMap = new GMMap();
			try{
				conn = DALUtil.getGMConnection();
				int i=1;
				stmt = conn.prepareCall("{call PKG_TRN1310.Mukerrer_Kontrolu(?,?,?,?,?,?,?,?,?,?,?) }");

				stmt.setBigDecimal(i++, iMap.getBigDecimal("BANKA_MUSTERI_NO"));
				stmt.setString(i++, iMap.getString("URUN_SINIF_KOD"));
				if(iMap.getDate("DEAL_TARIHI")==null)
					stmt.setDate(i++, null);
				else
					stmt.setDate(i++, new java.sql.Date(iMap.getDate("DEAL_TARIHI").getTime()));
				if(iMap.getDate("VALOR_TARIHI")==null)
					stmt.setDate(i++, null);
				else
					stmt.setDate(i++, new java.sql.Date(iMap.getDate("VALOR_TARIHI").getTime()));
				if(iMap.getDate("VADE_TARIHI")==null)
					stmt.setDate(i++, null);
				else
					stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
				stmt.setString(i++, iMap.getString("GIRIS_HESAP_TURU"));
				stmt.setString(i++, iMap.getString("CIKIS_HESAP_TURU"));
				if(iMap.getBigDecimal("TUTAR")==null)
					stmt.setBigDecimal(i++, null);
				else
					stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("FAIZ_ORANI"));
				stmt.setString(11, iMap.getString("TRX_NO"));

				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				
				stmt.execute();
				
				oMap.put("REFERANS_NO", stmt.getString(i-2));
				oMap.put("ISLEM_NO", stmt.getString(i-1));
				
				return oMap;
			}catch (Exception e){
				throw ExceptionHandler.convertException(e);
			}finally{
				
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				
			}
		}
	
	   @GraymoundService("BNSPR_TRN1310_GET_ESASGUNSAYI")
		public static GMMap getEsasGunSayi(GMMap iMap){
			
			GMMap oMap = new GMMap();
			String esasGunSayi;
			String musteriNo="";
			String dovizKodu="";
			try{			     		 				 
				 iMap.put("KOD", "DEPO_TAKASBANK_MUSTERI");
				 musteriNo = iMap.getString("MUSTERI_NO");
				 iMap.put("KEY", musteriNo);
				 esasGunSayi= GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", iMap).get("TEXT").toString();					 
				 oMap.put( "ESAS_GUN_SAYI", esasGunSayi);
				 return oMap;
			}catch (Exception e){
				 try{
				 iMap.put("KOD", "DEPO_ESAS_GUN_SAYI");
				 dovizKodu = iMap.getString("DOVIZ_KODU");
				 iMap.put("KEY", dovizKodu);
				 esasGunSayi= GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", iMap).get("TEXT").toString();		
				 oMap.put( "ESAS_GUN_SAYI", esasGunSayi);
				 
				 return oMap;
				 }
				 catch (Exception e2){
					if(!dovizKodu.isEmpty())
					oMap.put( "ESAS_GUN_SAYI", "360" );
					return oMap;
				}
			}

		}

}
