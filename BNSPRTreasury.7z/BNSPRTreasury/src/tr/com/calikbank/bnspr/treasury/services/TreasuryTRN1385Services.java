package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BonoTalepTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1385Services {

	@GraymoundService("BNSPR_TRN1385_W1_INITIALIZE")
	public static GMMap W1initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		 
		 DALUtil.fillComboBox(oMap, "GRUP_KODU", false, "select kod,aciklama from gnl_musteri_grup_kod_pr order by kod");
		
		 iMap.put("KOD", "EVET_HAYIR");
		 iMap.put("ADD_EMPTY_KEY", "H");
		 oMap.put("F_MAIL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		 
	     DALUtil.fillComboBox(oMap, "MUSTERI_TIPI", false, "select kod,aciklama from  gnl_must_tur_kod_pr where kod in ('G','T','O') order by aciklama");
		 
		 return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1385_INITIALIZE")
	public static Map<?, ?> initialize (GMMap iMap){
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "BONO_ILETISIM_KANALI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("BONO_ILETISIM_KANALI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BONO_GORUSME_SONUC");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("BONO_GORUSME_SONUC", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BONO_PARA_TAKIP_DURUM");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("BONO_PARA_TAKIP_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BONO_ALIS_TEYIT_STATU");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("BONO_ALIS_TEYIT_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "EVET_HAYIR");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("EVET_HAYIR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BONO_ILETISIM_KANALI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("BONO_ILETISIM_KANALI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		DALUtil.fillComboBox(oMap, "MUSTERI_TIPI", false, "select kod,aciklama from  gnl_must_tur_kod_pr where kod in ('G','T','O') order by aciklama");
		
		DALUtil.fillComboBox(oMap, "GRUP_KODU", false, "select kod,aciklama from gnl_musteri_grup_kod_pr order by kod");
		
		iMap.put("KOD", "BONO_ULASIM_KANALI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("BONO_ULASIM_KANALI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "EVET_HAYIR");
		iMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("F_MAIL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1385_GET_BONO_TALEP_LIST")
	public static GMMap getBonoTalepList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			int i = 0;
			stmt = conn.prepareCall("{ ? = call PKG_TRN1385.get_bono_talep_list(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(++i, iMap.getString("MUSTERI_TUR"));
			stmt.setString(++i, iMap.getString("TCKN"));
			stmt.setString(++i, iMap.getString("ADI"));
			stmt.setString(++i, iMap.getString("IKINCI_ADI"));
			stmt.setString(++i, iMap.getString("SOYADI"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("TALEP_NO"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("BAS_TALEP_TUTARI"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("BIT_TALEP_TUTARI"));
			
			if(iMap.getDate("BAS_TALEP_TARIHI") != null)
				stmt.setDate(++i, new java.sql.Date(iMap.getDate("BAS_TALEP_TARIHI").getTime()));
			else
				stmt.setDate(++i, null );
			
			if(iMap.getDate("BIT_TALEP_TARIHI") != null)
				stmt.setDate(++i, new java.sql.Date(iMap.getDate("BIT_TALEP_TARIHI").getTime()));
			else
				stmt.setDate(++i, null );
			
			stmt.execute();
			String tableName = "TALEP_LISTE";
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, tableName);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		    GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1385_SAVE")
	public static GMMap Save (GMMap iMap){
		String musteriTip;
		String tckn;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BonoTalepTx bonoTalepTx = (BonoTalepTx)session.get(BonoTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(bonoTalepTx == null) {
				bonoTalepTx = new BonoTalepTx();
			}
			bonoTalepTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			GMMap aMap = new GMMap();
			aMap.put("TABLE_NAME", 	"BONO_TALEP");
			if(iMap.getBigDecimal("TALEP_NO") == null )
				bonoTalepTx.setTalepNo((BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", aMap).get("ID"));
			else
				bonoTalepTx.setTalepNo(iMap.getBigDecimal("TALEP_NO"));
			bonoTalepTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			musteriTip = iMap.getString("MUSTERI_TIP");
			bonoTalepTx.setMusteriTip(musteriTip);
			tckn = iMap.getString("TCKN");
		
			if (tckn != null && !("").equals(tckn) && ("G").equals(musteriTip)){
				if (tckn.length() == 11) 
			      bonoTalepTx.setTckn(tckn);
			    else{
			      iMap.put("HATA_NO", new BigDecimal(1198));
			      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			    } 
			}else if (tckn != null && !("").equals(tckn) && ("T").equals(musteriTip)){
				if (tckn.length() == 10) 
				  bonoTalepTx.setVkn(tckn);
				else{
			 	  iMap.put("HATA_NO", new BigDecimal(474));
			      return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				} 
			}
			/*if(iMap.getString("TCKN")!= null && iMap.getString("TCKN").length() == 11)
				bonoTalepTx.setTckn(iMap.getString("TCKN"));
			if(iMap.getString("TCKN")!= null && iMap.getString("TCKN").length() == 10)
		    bonoTalepTx.setVkn(iMap.getString("TCKN"));*/
			bonoTalepTx.setAdi(iMap.getString("ADI"));
			bonoTalepTx.setIkinciAdi(iMap.getString("IKINCI_ADI"));
			bonoTalepTx.setSoyadi(iMap.getString("SOYADI"));
			bonoTalepTx.setEvTel(iMap.getString("EV_TEL"));
			bonoTalepTx.setIsTel(iMap.getString("IS_TEL"));
			bonoTalepTx.setCepTel(iMap.getString("CEP_TEL"));
			bonoTalepTx.setIletisimTelTip(iMap.getString("ILETISIM_TEL_TIP"));
			bonoTalepTx.setAdresTur(iMap.getString("ADRES_TUR"));
			bonoTalepTx.setAdres(iMap.getString("ADRES"));
			bonoTalepTx.setSemt(iMap.getString("SEMT"));
			bonoTalepTx.setIlKod(iMap.getString("IL_KOD"));
			bonoTalepTx.setIlceKod(iMap.getString("ILCE_KOD"));
			bonoTalepTx.setIsyeriAdi(iMap.getString("ISYERI_ADI"));
			bonoTalepTx.setIlkKontakTarih(iMap.getDate("ILK_KONTAK_TARIH"));
			bonoTalepTx.setKanalKod(iMap.getString("KANAL_KOD"));
			bonoTalepTx.setGrupKod(iMap.getString("GRUP_KOD"));
			bonoTalepTx.setEksikEvrakF(iMap.getString("EKSIK_EVRAK_F"));
			bonoTalepTx.setMusteriOlmaTarihi(iMap.getDate("MUSTERI_OLMA_TARIHI"));
			bonoTalepTx.setIslemiYaptircakAdi(iMap.getString("ISLEMI_YAPTIRCAK_ADI"));
			bonoTalepTx.setIslemiYaptircakIkinciAdi(iMap.getString("ISLEMI_YAPTIRCAK_IKINCI_ADI"));
			bonoTalepTx.setIslemiYaptircakSoyadi(iMap.getString("ISLEMI_YAPTIRCAK_SOYADI"));
			bonoTalepTx.setIslemiYaptircakMusteriNo(iMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"));
			bonoTalepTx.setBelgeAlabilecekAdi(iMap.getString("BELGE_ALABILECEK_ADI"));
			bonoTalepTx.setBelgeAlabilecekIkinciAdi(iMap.getString("BELGE_ALABILECEK_IKINCI_ADI"));
			bonoTalepTx.setBelgeAlabilecekSoyadi(iMap.getString("BELGE_ALABILECEK_SOYADI"));
			bonoTalepTx.setBelgeAlabilecekMusteriNo(iMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"));
			bonoTalepTx.setFaksNo(iMap.getString("FAKS_NO"));
			bonoTalepTx.setTalepTutari(iMap.getBigDecimal("TALEP_TUTARI"));
			bonoTalepTx.setVade(iMap.getBigDecimal("VADE"));
			bonoTalepTx.setYatirimTutari(iMap.getBigDecimal("YATIRIM_TUTARI"));
			bonoTalepTx.setSonuc(iMap.getString("SONUC"));
			bonoTalepTx.setRandevuTarihi(iMap.getDate("RANDEVU_TARIHI"));
			bonoTalepTx.setRandevuSaati(iMap.getString("RANDEVU_SAATI"));
			bonoTalepTx.setParaGonderimTarihi1(iMap.getDate("PARA_GONDERIM_TARIHI1"));
			bonoTalepTx.setParaGonderimTarihi2(iMap.getDate("PARA_GONDERIM_TARIHI2"));
			bonoTalepTx.setParaTakibi1(iMap.getString("PARA_TAKIBI1"));
			bonoTalepTx.setParaTakibi2(iMap.getString("PARA_TAKIBI2"));
			bonoTalepTx.setBonoAlisTeyitStatusu(iMap.getString("BONO_ALIS_TEYIT_STATUSU"));
			bonoTalepTx.setBonoAlimiGerceklestiF(iMap.getString("BONO_ALIMI_GERCEKLESTI_F"));
			bonoTalepTx.setEftGelisTarihi(iMap.getDate("EFT_GELIS_TARIHI"));
			bonoTalepTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			bonoTalepTx.setEmail(iMap.getString("EMAIL"));
			bonoTalepTx.setAlimTutari(iMap.getBigDecimal("ALIM_TUTARI"));
			bonoTalepTx.setKanalAciklama(iMap.getString("KANAL_ACIKLAMA"));
			bonoTalepTx.setUlasimKanali(iMap.getString("ULASIM_KANALI"));
			bonoTalepTx.setAciklama(iMap.getString("ACIKLAMA"));
			bonoTalepTx.setGuncelleyenKull(iMap.getString("GUNCELLEYEN_KULL"));
			bonoTalepTx.setGuncellemeTarihi(iMap.getDate("GUNCELLEME_TARIHI"));
			bonoTalepTx.setFMail(iMap.getString("F_MAIL"));
			session.saveOrUpdate(bonoTalepTx);
			session.flush();
			iMap.put("TRX_NAME", "1385");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1385_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn 		= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal" );
			BonoTalepTx objBonoTalepTx = (BonoTalepTx)session.get(BonoTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("TALEP_NO",objBonoTalepTx.getTalepNo());
			oMap.put("MUSTERI_NO",objBonoTalepTx.getMusteriNo());
			oMap.put("MUSTERI_TIP",objBonoTalepTx.getMusteriTip());
			oMap.put("TCKN",objBonoTalepTx.getTckn());
			if(oMap.getString("TCKN") == null || oMap.getString("TCKN").length() !=11 )
				oMap.put("TCKN",objBonoTalepTx.getVkn());
			oMap.put("ADI",objBonoTalepTx.getAdi());
			oMap.put("IKINCI_ADI",objBonoTalepTx.getIkinciAdi());
			oMap.put("SOYADI",objBonoTalepTx.getSoyadi());
			oMap.put("EV_TEL",objBonoTalepTx.getEvTel());
			oMap.put("IS_TEL",objBonoTalepTx.getIsTel());
			oMap.put("CEP_TEL",objBonoTalepTx.getCepTel());
			oMap.put("ILETISIM_TEL_TIP",objBonoTalepTx.getIletisimTelTip());
			oMap.put("ADRES_TUR",objBonoTalepTx.getAdresTur());
			oMap.put("ADRES",objBonoTalepTx.getAdres());
			oMap.put("SEMT",objBonoTalepTx.getSemt());
			oMap.put("IL_KOD",objBonoTalepTx.getIlKod());
			oMap.put("ILCE_KOD",objBonoTalepTx.getIlceKod());
			oMap.put("ISYERI_ADI",objBonoTalepTx.getIsyeriAdi());
			oMap.put("ILK_KONTAK_TARIH",objBonoTalepTx.getIlkKontakTarih());
			oMap.put("KANAL_KOD",objBonoTalepTx.getKanalKod());
			oMap.put("GRUP_KOD",objBonoTalepTx.getGrupKod());
			oMap.put("EKSIK_EVRAK_F",objBonoTalepTx.getEksikEvrakF());
			oMap.put("MUSTERI_OLMA_TARIHI",objBonoTalepTx.getMusteriOlmaTarihi());
			oMap.put("ISLEMI_YAPTIRCAK_ADI",objBonoTalepTx.getIslemiYaptircakAdi());
			oMap.put("ISLEMI_YAPTIRCAK_IKINCI_ADI",objBonoTalepTx.getIslemiYaptircakIkinciAdi());
			oMap.put("ISLEMI_YAPTIRCAK_SOYADI",objBonoTalepTx.getIslemiYaptircakSoyadi());
			oMap.put("ISLEMI_YAPTIRCAK_MUSTERI_NO",objBonoTalepTx.getIslemiYaptircakMusteriNo());
			oMap.put("BELGE_ALABILECEK_ADI",objBonoTalepTx.getBelgeAlabilecekAdi());
			oMap.put("BELGE_ALABILECEK_IKINCI_ADI",objBonoTalepTx.getBelgeAlabilecekIkinciAdi());
			oMap.put("BELGE_ALABILECEK_SOYADI",objBonoTalepTx.getBelgeAlabilecekSoyadi());
			oMap.put("BELGE_ALABILECEK_MUSTERI_NO",objBonoTalepTx.getBelgeAlabilecekMusteriNo());
			oMap.put("FAKS_NO",objBonoTalepTx.getFaksNo());
			oMap.put("TALEP_TUTARI",objBonoTalepTx.getTalepTutari());
			oMap.put("VADE",objBonoTalepTx.getVade());
			oMap.put("YATIRIM_TUTARI",objBonoTalepTx.getYatirimTutari());
			oMap.put("SONUC",objBonoTalepTx.getSonuc());
			oMap.put("RANDEVU_TARIHI",objBonoTalepTx.getRandevuTarihi());
			oMap.put("RANDEVU_SAATI",objBonoTalepTx.getRandevuSaati());
			oMap.put("PARA_GONDERIM_TARIHI1",objBonoTalepTx.getParaGonderimTarihi1());
			oMap.put("PARA_GONDERIM_TARIHI2",objBonoTalepTx.getParaGonderimTarihi2());
			oMap.put("PARA_TAKIBI1",objBonoTalepTx.getParaTakibi1());
			oMap.put("PARA_TAKIBI2",objBonoTalepTx.getParaTakibi2());
			oMap.put("BONO_ALIS_TEYIT_STATUSU",objBonoTalepTx.getBonoAlisTeyitStatusu());
			oMap.put("BONO_ALIMI_GERCEKLESTI_F",objBonoTalepTx.getBonoAlimiGerceklestiF());
			oMap.put("EFT_GELIS_TARIHI",objBonoTalepTx.getEftGelisTarihi());
			oMap.put("HESAP_NO",objBonoTalepTx.getHesapNo());
			oMap.put("EMAIL",objBonoTalepTx.getEmail());
			oMap.put("ALIM_TUTARI",objBonoTalepTx.getAlimTutari());
			oMap.put("KANAL_ACIKLAMA",objBonoTalepTx.getKanalAciklama());
			oMap.put("ULASIM_KANALI",objBonoTalepTx.getUlasimKanali());
			oMap.put("ACIKLAMA",objBonoTalepTx.getAciklama());
			oMap.put("GUNCELLEYEN_KULL",objBonoTalepTx.getGuncelleyenKull());
			oMap.put("GUNCELLEME_TARIHI",objBonoTalepTx.getGuncellemeTarihi());
			oMap.put("F_MAIL",objBonoTalepTx.getFMail());
			oMap.put("REC_OWNER",objBonoTalepTx.getYaratanKull());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1385_GET_MUSTERI_DETAY")
	public static GMMap getMusteriDetay(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			int i = 0;
			stmt = conn.prepareCall("{ ? = call PKG_TRN1385.get_musteri_detay(?)}");
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("MUSTERI_NO"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		    GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1385_GET_BONO_TALEP")
	public static GMMap getBonoTalep(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			int i = 0;
			stmt = conn.prepareCall("{ ? = call PKG_TRN1385.get_bono_talep(?)}");
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("TALEP_NO"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap.putAll(DALUtil.rSetMap(rSet));
			oMap.put("MUSTERI_TUR", LovHelper.diLov(oMap.getBigDecimal("MUSTERI_NO"),"", 
					"1385/KONTAK_MUSTERI", "MUSTERI_KONTAKT" ));
			
			oMap.put("ISLEMI_YAPTIRCAK_ADI", LovHelper.diLov(oMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "ADI" ));
			oMap.put("ISLEMI_YAPTIRCAK_IKINCI_ADI", LovHelper.diLov(oMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "IKINCI_ADI" ));
			oMap.put("ISLEMI_YAPTIRCAK_SOYADI", LovHelper.diLov(oMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "SOYADI" ));
			oMap.put("ISLEMI_YAPTIRCAK_SOYADI", LovHelper.diLov(oMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "SOYADI" ));
			oMap.put("ISLEMI_YAPTIRCAK_TCKN", LovHelper.diLov(oMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "TC_KIMLIK_NO" ));
			oMap.put("ISLEMI_YAPTIRCAK_MUSTERI_TUR", LovHelper.diLov(oMap.getBigDecimal("ISLEMI_YAPTIRCAK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "MUSTERI_KONTAKT" ));
			
			oMap.put("BELGE_ALABILECEK_ADI", LovHelper.diLov(oMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "ADI" ));
			oMap.put("BELGE_ALABILECEK_IKINCI_ADI", LovHelper.diLov(oMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "IKINCI_ADI" ));
			oMap.put("BELGE_ALABILECEK_SOYADI", LovHelper.diLov(oMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "SOYADI" ));
			oMap.put("BELGE_ALABILECEK_TCKN", LovHelper.diLov(oMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "TC_KIMLIK_NO" ));
			oMap.put("BELGE_ALABILECEK_MUSTERI_TUR", LovHelper.diLov(oMap.getBigDecimal("BELGE_ALABILECEK_MUSTERI_NO"), 
					"1385/KONTAK_MUSTERI_GERCEK", "MUSTERI_KONTAKT" ));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		    GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
