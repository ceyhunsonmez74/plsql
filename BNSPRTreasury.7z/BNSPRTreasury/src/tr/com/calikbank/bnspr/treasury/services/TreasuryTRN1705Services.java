package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MenMusteriPortfoyBloke;
import tr.com.aktifbank.bnspr.dao.MenMusteriPortfoyBlokeTx;
import tr.com.aktifbank.bnspr.dao.MenMusteriPortfoyBlokeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryTRN1705Services {
	
	@GraymoundService("BNSPR_TRN1705_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            @SuppressWarnings("unchecked")
			List<MenMusteriPortfoyBloke> list = session.createCriteria(MenMusteriPortfoyBloke.class).addOrder(Order.asc("id.musteriNo")).addOrder(Order.asc("id.isin")).list();
			String tableName = "LISTE";
			for (int i = 0; i < list.size(); i++) {
				oMap.put(tableName, i, "MUSTERI_NO", list.get(i).getId().getMusteriNo());
				oMap.put(tableName, i, "ISIN", list.get(i).getId().getIsin());
				oMap.put(tableName, i, "DOVIZ_KODU", list.get(i).getId().getDovizKodu());
				oMap.put(tableName, i, "NOMINAL", list.get(i).getNominal());
				oMap.put(tableName, i, "NOMINAL_OLD", list.get(i).getNominal());
				oMap.put(tableName, i, "ISLEM", "G");
				oMap.put(tableName, i, "P_KEY_KONTROL", list.get(i).getId().getMusteriNo()+"-"+list.get(i).getId().getIsin()+"-"+list.get(i).getId().getDovizKodu());
			}					
        }
        catch (Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1705_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        String tableName = "LISTE";
        BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		List<?> satirBilgileri = (List<?>) iMap.get(tableName);
		for (int i = 0; i < satirBilgileri.size(); i++) {
			GMMap xMap = iMap.getMap(tableName, i);
			if(xMap.getString("ISLEM").equals("G") && !controlOfPrimaryKey(xMap)){
				oMap.put("P1", "M��teri Numaras�, ISIN ve D�viz Kodu de�i�tirilemez!");
				oMap.put("HATA_NO", "660");
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", oMap);
				return oMap;
			}
			if (xMap.getString("ISLEM").equals("Y") || xMap.getBigDecimal("NOMINAL_OLD").compareTo(xMap.getBigDecimal("NOMINAL")) != 0) {
				saveRow(iMap.getBigDecimal("TRX_NO"), xMap);
			}
		}     
		iMap.clear();
        iMap.put("TRX_NAME" , "1705");
        iMap.put("TRX_NO" , txNo);
        oMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
        
        return oMap;
    }
 
	private static boolean controlOfPrimaryKey(GMMap xMap) {
		List<String> list = Arrays.asList(xMap.getString("P_KEY_KONTROL").split("-")); 
		if (list!= null && list.size()>0 && (!list.get(0).equals(xMap.getBigDecimal("MUSTERI_NO").toString()) || !list.get(1).equals(xMap.getString("ISIN")) || !list.get(2).equals(xMap.getString("DOVIZ_KODU")))) {
			return false;
		}
		return true;
	}

	private static void saveRow(BigDecimal txNo, GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		MenMusteriPortfoyBlokeTxId rowId = new MenMusteriPortfoyBlokeTxId();
		rowId.setTxNo(txNo);
		rowId.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
		rowId.setIsin(iMap.getString("ISIN"));
		rowId.setDovizKodu(iMap.getString("DOVIZ_KODU"));
		MenMusteriPortfoyBlokeTx row = new MenMusteriPortfoyBlokeTx();
		row.setId(rowId);
		row.setNominal(iMap.getBigDecimal("NOMINAL"));
		row.setIslemTipi(iMap.getString("ISLEM"));
		
		session.save(row);
		session.flush();
	}

    @GraymoundService("BNSPR_TRN1705_GET_DATA")
    public static GMMap getData(GMMap iMap) {
    	GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            @SuppressWarnings("unchecked")
			List<MenMusteriPortfoyBlokeTx> list = session.createCriteria(MenMusteriPortfoyBlokeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).addOrder(Order.asc("id.musteriNo")).addOrder(Order.asc("id.isin")).list();
			String tableName = "LISTE";
			for (int i = 0; i < list.size(); i++) {
				oMap.put(tableName, i, "MUSTERI_NO", list.get(i).getId().getMusteriNo());
				oMap.put(tableName, i, "ISIN", list.get(i).getId().getIsin());
				oMap.put(tableName, i, "DOVIZ_KODU", list.get(i).getId().getDovizKodu());
				oMap.put(tableName, i, "NOMINAL", list.get(i).getNominal());
				oMap.put(tableName, i, "ISLEM", getIslemTipi(list.get(i).getIslemTipi()));
			}					
        }
        catch (Exception e){
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    private static String getIslemTipi(String islemTipi) {
    	if(islemTipi.equals("Y")){
    		return "Yeni";
    	}else if(islemTipi.equals("G")){
    		return "G�ncelleme";
    	}else if(islemTipi.equals("S")){
    		return "Silme";
    	}
    	return "Yeni";
	}

	@GraymoundService("BNSPR_TRN1705_DELETE_ROW")
    public static GMMap deleteRow(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	Session session = DAOSession.getSession("BNSPRDal");
    	MenMusteriPortfoyBloke bloke = (MenMusteriPortfoyBloke) session.createCriteria(MenMusteriPortfoyBloke.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("id.isin", iMap.getString("ISIN"))).add(Restrictions.eq("id.dovizKodu", iMap.getString("DOVIZ_KODU"))).uniqueResult();
    	if(bloke != null)
    		saveRow(iMap.getBigDecimal("TRX_NO"),iMap);
    	return oMap;
    }
}
