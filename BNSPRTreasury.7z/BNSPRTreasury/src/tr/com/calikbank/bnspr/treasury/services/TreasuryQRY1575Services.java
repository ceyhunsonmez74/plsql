package tr.com.calikbank.bnspr.treasury.services;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Types;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.util.GMMap;

public class TreasuryQRY1575Services {
    
    private static String ROOT 		= GMServer.getProperty("graymound.home",null)	+
            File.separator 	+
            "Server"		+
            File.separator 	+
            "Content"		+
            File.separator	+
            "Root"			;
    
    @GraymoundService("BNSPR_QRY1575_EXCEL_OLUSTUR")
    public static GMMap excelOlustur (GMMap iMap) {
        
        String fileName= iMap.getString("DOSYA_ADI");
        String dosyaAdi = iMap.getString("DOSYA_YOLU")+File.separator+iMap.getString("DOSYA_ADI");
        String tempDosyaAdi = ROOT + File.separator + "files" + File.separator + fileName + ".xls";
        File file = new File(tempDosyaAdi);
        WritableWorkbook workbook=null;
        WritableSheet sheet1=null;
        GMMap oMap = new GMMap();
        
        try {
            workbook = Workbook.createWorkbook(file);
            sheet1 = workbook.createSheet("T�rev", 0);
            int columnNum = 0;
            
            
            for (int rowNum = 0; rowNum<iMap.getSize("TABLE")+1; rowNum++)
            {
                
                if(rowNum==0)
                {
                    sheet1.addCell(new jxl.write.Label(columnNum, rowNum,"��LEM TAR�H�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"�UBE"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"M��TER� NO"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"M��TER� ADI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"OPS�YON Y�N�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"BAZ OPS�YON �EKL�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"OPS�YON T�P�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"VADE TAR�H�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"UZLA�MA TAR�H�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"VADE G�N SAYISI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"ANLA�MA KURU"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"BAZ DVZ C�NS�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"BAZ OPS TUTARI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum,	rowNum,"KAR�I DVZ C�NS�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"KAR�I OPS TUTARI"));					
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"M��TER� PR�M"));					
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"PR�M TAR�H�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"PR�M DVZ C�NS�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"M��.PR�M TUTARI	"));						
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"��LEM HACM�(TL KAR�ILI�I)"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"�UBE KARI(TL KAR�ILI�I)"));           		                
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"DURUM KODU"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"OPS KULLANIM"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"��LEM T�P�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"GEREKL� TEM. ORANI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"GEREKL� TEM. TUTARI (TRY)"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"MTM DE�ER� (TRY)"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"PR�M TRY TUTARI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"��LEM KARI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"��LEM KARDA MI?"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"KULLANIM FIYATI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"OPS�YON AMA�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"STOPAJ ORANI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"STOPAJ TUTARI"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"MAL�YET PR�M"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"PAR�TE"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"M��TER� PR�M YILLIK"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"�UBE KARI DVZ C�NS�"));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,"�UBE KARI TUTARI"));
                    
                    columnNum=0;
                    
                }           		
                
                else 
                {
                    columnNum = 0;
                    sheet1.addCell(new jxl.write.Label(columnNum, 	rowNum,iMap.getString("TABLE",rowNum-1,"TARIH_ISLEM")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"SUBE_ISLEM")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"MUSTERI_NO")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"MUSTERI_ADI")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"OPS_YONU")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"OPS_SEKLI_BAZ")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"OPS_TIPI")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"TARIH_VADE")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"TARIH_UZLASMA")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"VADE_GUN_SAYISI")));
                    if(iMap.getString("TABLE",rowNum-1,"HEDEF_FIYAT")!=null){
                        String hedefFiyat = String.format("%.5f",new BigDecimal(iMap.getString("TABLE",rowNum-1,"HEDEF_FIYAT")));
                        sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,hedefFiyat.toString()));
                    }
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"BAZ_DVZ")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"BAZ_TUTAR")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"KARSI_DOVIZ")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"KARSI_TUTAR")));
                    if(iMap.getString("TABLE",rowNum-1,"PRIM_MUSTERI") != null){
                        String primMusteri = String.format("%.4f",new BigDecimal(iMap.getString("TABLE",rowNum-1,"PRIM_MUSTERI")));
                        sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,primMusteri.toString()));
                    }										
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"TARIH_PRIM")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"PRIM_DOVIZ")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"PRIM_TUTAR")));								       		
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"ISLEM_HACMI_TRY")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"SUBE_KARI_TRY")));			       		
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"OPS_STATUS")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"KULLANILDIMI")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"RISK_ISLEM_TIPI")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"RISK_TEMINAT_ORAN")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"RISK_TEMINAT_TUTAR")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"MTM_TUTAR")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"PRIM_TL_TUTAR")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"ISLEM_KARI")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"KARDAMI")));
                    if(iMap.getString("TABLE",rowNum-1,"KULLANIM_FIYATI") != null){
                        String kullanimFiyati = String.format("%.5f",new BigDecimal(iMap.getString("TABLE",rowNum-1,"KULLANIM_FIYATI")));
                        sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,kullanimFiyati.toString())); 
                    }
                    else
                        ++columnNum;
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"OPS_AMAC")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"STOPAJ_ORAN")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"STOPAJ_TUTAR")));
                    if(iMap.getString("TABLE",rowNum-1,"PRIM_MALIYET") != null){
                        String primMaliyet = String.format("%.4f",new BigDecimal(iMap.getString("TABLE",rowNum-1,"PRIM_MALIYET")));
                        sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,primMaliyet.toString()));
                    }
                    else
                        ++columnNum;
                    if(iMap.getString("TABLE",rowNum-1,"PRIM_MALIYET") != null){
                        String primMaliyet = String.format("%.4f",new BigDecimal(iMap.getString("TABLE",rowNum-1,"PRIM_MALIYET")));
                        sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,primMaliyet.toString())); 
                    }
                    else
                        ++columnNum;
                    if(iMap.getString("TABLE",rowNum-1,"SPOT_KUR") != null){
                        String spotKur = String.format("%.5f", new BigDecimal(iMap.getString("TABLE",rowNum-1,"SPOT_KUR")));
                        sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,spotKur.toString()));  
                    }
                    else
                        ++columnNum;
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"PRIM_MUSTERI_YILLIK")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"PRIM_SUBE_KARI_DVZ")));
                    sheet1.addCell(new jxl.write.Label(++columnNum, rowNum,iMap.getString("TABLE",rowNum-1,"PRIM_SUBE_KARI_TUTAR")));  
                }
                
                
            }
            
            oMap.put("TEMP_DOSYA_ADI","files" + File.separator + fileName + ".xls");
            oMap.put("DOSYA_ADI",dosyaAdi+".xls");
            workbook.write();
            workbook.close();  
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
            
        }
        
        return oMap;
    }
    
    
    
    @GraymoundService("BNSPR_QRY1575_GET_DATA")
    public static GMMap getData (GMMap iMap) {
        
        GMMap oMap = new GMMap();
        String func = "{? = call PKG_RC1575.GetYasayanOpsiyonlar(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}"; 
        
        try {
            oMap = DALUtil.callOracleRefCursorFunction(func, "TBL_LISTE", new Object[]
                    {	BnsprType.DATE,
                    iMap.getDate("ISLEM_TARIHI1"),
                    BnsprType.DATE,
                    iMap.getDate("ISLEM_TARIHI2"),
                    BnsprType.DATE,
                    iMap.getDate("VADE_TARIHI1"),
                    BnsprType.DATE,
                    iMap.getDate("VADE_TARIHI2"),
                    BnsprType.DATE,
                    iMap.getDate("UZLASMA_TARIH1"),
                    BnsprType.DATE,
                    iMap.getDate("UZLASMA_TARIH2"),
                    BnsprType.DATE,
                    iMap.getDate("PRIM_TARIH1"),
                    BnsprType.DATE,
                    iMap.getDate("PRIM_TARIH2"),
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("SUBE_KODU"),
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("MUSTERI_NO"),
                    BnsprType.STRING,
                    iMap.getString("OPS_YONU"),
                    BnsprType.STRING,
                    iMap.getString("OPS_SEKLI"),
                    BnsprType.STRING,
                    iMap.getString("OPS_TIPI"),
                    BnsprType.STRING,
                    iMap.getString("OPS_DOVIZ_CINSI"),
                    BnsprType.STRING,
                    iMap.getString("OPS_TURU"),
                    BnsprType.STRING,
                    iMap.getString("OPS_BANKA"),
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("BAZ_OPSIYON_TUTAR1"),
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("BAZ_OPSIYON_TUTAR2"),
                    BnsprType.STRING,
                    iMap.getString("PRIM_STATUS"),
                    BnsprType.STRING,
                    iMap.getString("OPS_KULLANIM"),
                    BnsprType.STRING,
                    iMap.getString("TEMINAT_AGIRLIGI"),
                    BnsprType.NUMBER,
                    iMap.getBigDecimal("MUSTERI_SUBE"),
                    BnsprType.STRING,
                    iMap.getString("NAKDI_UZLASI")
                    });
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
        
    }
    
    @GraymoundService("BNSPR_QRY1575_GET_OPSIYON_TIPI")
    public static GMMap getOpsTipi(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        String func = "{? = call PKG_OPSIYON.opsiyonCinsGrubu(?)}"; 
        
        try {
            String opsTipi = DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getString("REFERANS")).toString();
            oMap.put("OPSIYON_TIPI", opsTipi);            
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;        
    }
    
    @GraymoundService("BNSPR_QRY1575_INITIALIZE_COMBO")
    public static GMMap initializeCombo(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        DALUtil.fillComboBox(oMap, "DOVIZ", true, "	select kod,aciklama from v_ml_gnl_doviz_kod_pr order by sira_no");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_TIPI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_TIPI", "AMR", "Amerika");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_TIPI", "AVR", "Avrupa");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_YONU", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_YONU", "A", "Banka Al��");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_YONU", "S", "Banka Sat��");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_SEKLI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_SEKLI", "P", "PUT");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPSIYON_SEKLI", "C", "CALL");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_MUSTERI_TIPI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_MUSTERI_TIPI", "B", "Banka");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_MUSTERI_TIPI", "M", "M��teri");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_PRIM_STATUS", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_PRIM_STATUS", "C", "Tamamland�");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_PRIM_STATUS", "W", "Bekliyor");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_PRIM_STATUS", "E", "Hatal�");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPS_KULLANIM", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPS_KULLANIM", "E", "EVET");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_OPS_KULLANIM", "H", "HAYIR");
       
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "O", "KALDIRACLI");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "D", "TAM TEMINATLI");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_TEMINAT_AGIRLIGI", "K", "T�rev Kredi Limiti");
        
        GuimlUtil.wrapMyCombo(oMap, "COMBO_NAKIT_UZLASI", null, " ");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_NAKIT_UZLASI", "E", "EVET");
        GuimlUtil.wrapMyCombo(oMap, "COMBO_NAKIT_UZLASI", "H", "HAYIR");
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY1575_GET_REPORT_DATA")
    public static GMMap getRaporData(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        int index=0;
        String proc = "{call PKG_RC1575.GetSozlesmeDetay(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
        Object [] input  = new Object[] {BnsprType.STRING, iMap.getString("REFERANS")};
        Object [] output  = new Object[50];
        output[index++]=BnsprType.STRING;
        output[index++]="pc_unvan";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_adres";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_subemusteri";
        output[index++]=BnsprType.STRING;
        output[index++]="pd_sozlesmetarihi";
        output[index++]=BnsprType.STRING;
        output[index++]="pd_islem_tarihi";
        output[index++]=BnsprType.NUMBER;
        output[index++]="pn_hedef_fiyat";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_hedef_parite";
        output[index++]=BnsprType.NUMBER;
        output[index++]="pn_alinan_tutar";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_alinan_doviz";
        output[index++]=BnsprType.NUMBER;
        output[index++]="pn_odenen_tutar";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_odenen_doviz";
        output[index++]=BnsprType.NUMBER;
        output[index++]="pn_prim_tutar";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_prim_doviz";
        output[index++]=BnsprType.STRING;
        output[index++]="pd_prim_tarih";
        output[index++]=BnsprType.NUMBER;
        output[index++]="pn_stopaj";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_sekil";
        output[index++]=BnsprType.STRING;
        output[index++]="pd_bitis_tarih";
        output[index++]=BnsprType.STRING;
        output[index++]="pd_bitis_saat";
        output[index++]=BnsprType.STRING;
        output[index++]="pd_uzlasma_tarihi";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_satan";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_alan";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_aciklama";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_sozlesme_gun";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_islem_saat";
        output[index++]=BnsprType.STRING;
        output[index++]="pc_baz_dvz";
        try {
            oMap = (GMMap) DALUtil.callOracleProcedure(proc, input, output);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
            
        }
        
        /*
		 package body PKG_RC1575 is
Procedure GetSozlesmeDetay(pc_referans varchar2,

pc_unvan out varchar2,
pc_adres out varchar2,
pc_subemusteri out varchar2,
pd_sozlesmetarihi out date,
pd_islem_tarihi out date,
pn_hedef_fiyat out number,
pc_hedef_parite out varchar2,
pn_alinan_tutar out number,
pc_alinan_doviz out varchar2,
pn_odenen_tutar out number,
pc_odenen_doviz out varchar2,
pn_prim_tutar out number,
pc_prim_doviz out varchar2,
pd_prim_tarih out date,
pn_stopaj out number,
pc_sekil out varchar2,
pd_bitis_tarih out date,
pc_bitis_saat out varchar2,
pd_uzlasma_tarihi out date,
pc_satan out varchar2,
pc_alan out varchar2)


         */
        
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY1575_DURUM_KODLARI")
    public static GMMap getDurumKodlari(GMMap iMap) {
        GMMap oMap = new GMMap();    
        
        try {
            
            int i =0;
            oMap.put("TABLE", i, "DURUM", "Hazine Onay�nda");
            oMap.put("TABLE", i, "CHECK_BOX", "0");
            oMap.put("TABLE", i, "DURUM_KODU", "HO");
            oMap.put("TABLE", ++i, "DURUM", "Backoffice Onay�nda");
            oMap.put("TABLE", i, "CHECK_BOX", "0");
            oMap.put("TABLE", i, "DURUM_KODU", "BO");
            oMap.put("TABLE", ++i, "DURUM", "Ya�ayan Opsiyonlar");
            oMap.put("TABLE", i, "CHECK_BOX", "0");
            oMap.put("TABLE", i, "DURUM_KODU", "YO");
            oMap.put("TABLE", ++i, "DURUM", "�ptal Edilmi�");
            oMap.put("TABLE", i, "CHECK_BOX", "0");
            oMap.put("TABLE", i, "DURUM_KODU", "IP");
            oMap.put("TABLE", ++i, "DURUM", "Kapal�");
            oMap.put("TABLE", i, "CHECK_BOX", "0");
            oMap.put("TABLE", i, "DURUM_KODU", "KP");
            
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_QRY1575_SEND_DURUM_KODLARI")
    public static GMMap sendDurumKodlari(GMMap iMap) {
        GMMap oMap = new GMMap();   
        StringBuilder st = new StringBuilder();
        try {
            for (int i = 0; i < iMap.getSize("TABLE"); i++){
                if("1".equals(iMap.get("TABLE" , i , "CHECK_BOX"))){
                    String check =  (String) iMap.get("TABLE" , i , "CHECK_BOX");
                    if(check.equals("1")){
                        if(!st.equals(null) && i > 0){
                            st.append(',');
                        }
                        st.append(iMap.get("TABLE" , i , "DURUM_KODU"));
                        
                    }
                }
            }
            
            oMap.put("SEND_DURUM_KODLARI" , st);    
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
}


