package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HznOpsiyonBariyerTx;
import tr.com.aktifbank.bnspr.dao.HznOpsiyonislemTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TreasuryTRN1579Services {

	@GraymoundService("BNSPR_TRN1579_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("KOD", "BARIYER_CINSI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BARIYER_CINSI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1579_GET_INFO")
	public static GMMap getInfo1579(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			String tableName = "OPSIYON_TABLE";

			Date basTarih = iMap.getDate("TARIH_BAS");
			Date sonTarih = iMap.getDate("TARIH_SON");
			BigDecimal bankaMusteri = iMap.getBigDecimal("BANKA_MUSTERI_NO");

			Criteria criteria = session.createCriteria(HznOpsiyonislemTx.class);
			criteria.add(Restrictions.isNotNull("sourcePlatform"));

			if (basTarih != null) {
				criteria.add(Restrictions.ge("tarihIslem", basTarih));
			}
			if (sonTarih != null) {
				criteria.add(Restrictions.lt("tarihIslem", sonTarih));
			}
			if (bankaMusteri != null) {
				criteria.add(Restrictions.eq("musteriNo", bankaMusteri));
			}

			criteria.addOrder(Order.desc("tarihIslem")).list();

			List<HznOpsiyonislemTx> opsiyonList = (List<HznOpsiyonislemTx>) criteria.list();

			if (opsiyonList != null && opsiyonList.size() > 0) {
				for (int i = 0; i < opsiyonList.size(); i++) {
					oMap.put(tableName, i, "REFERANS_NO", opsiyonList.get(i).getId().getReferans());
					oMap.put(tableName, i, "TX_NO", opsiyonList.get(i).getId().getTxNo());
					oMap.put(tableName, i, "OPS_CINSI", opsiyonList.get(i).getOpsCinsi());
					oMap.put(tableName, i, "OPS_YONU", opsiyonList.get(i).getOpsYonu());
					oMap.put(tableName, i, "BAZ_DOVIZ", opsiyonList.get(i).getBazDvz());
					oMap.put(tableName, i, "KARSI_DOVIZ", opsiyonList.get(i).getKarsiDoviz());
					oMap.put(tableName, i, "BAZ_TUTAR", opsiyonList.get(i).getBazTutar());
					oMap.put(tableName, i, "KARSI_TUTAR", opsiyonList.get(i).getKarsiTutar());
					oMap.put(tableName, i, "PRIM_DOVIZ", opsiyonList.get(i).getPrimDoviz());
					oMap.put(tableName, i, "MUSTERI_PRIM_ORAN", opsiyonList.get(i).getPrimMusteri());
					oMap.put(tableName, i, "MALIYET_PRIM_ORAN", opsiyonList.get(i).getPrimMaliyet());
					oMap.put(tableName, i, "PRIM_TUTAR", opsiyonList.get(i).getPrimTutar());
					oMap.put(tableName, i, "SUBE_KAR", opsiyonList.get(i).getPrimSubeKariTutar());
					oMap.put(tableName, i, "SOURCE_PLATFORM", opsiyonList.get(i).getSourcePlatform());
					oMap.put(tableName, i, "ISLEM_TARIHI", opsiyonList.get(i).getTarihIslem());

				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1579_MALIYET_PRIM_HESAPLA")
	public static GMMap MaliyetPrimHesapla(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			BigDecimal maliyetPrim = iMap.getBigDecimal("MALIYET_PRIM");
			HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			oMap.put("SUBE_KARI", subeKariHesapla(hznOpsiyonislemTx, maliyetPrim));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static BigDecimal subeKariHesapla(HznOpsiyonislemTx tx, BigDecimal maliyetPrim) {

		BigDecimal subeKar = new BigDecimal(0);

		if (tx.getOpsCinsi().equalsIgnoreCase("V")) {

			if (tx.getOpsYonu().equalsIgnoreCase("A") && tx.getPrimDoviz().equalsIgnoreCase(tx.getBazDvz())) {
				subeKar = ((maliyetPrim.subtract(tx.getPrimMusteri())).multiply(tx.getBazTutar())).divide(new BigDecimal(100));
			}
			if (tx.getOpsYonu().equalsIgnoreCase("A") && !tx.getPrimDoviz().equalsIgnoreCase(tx.getBazDvz())) {
				subeKar = ((maliyetPrim.subtract(tx.getPrimMusteri())).multiply(tx.getKarsiTutar())).divide(new BigDecimal(100));
			}
			if (tx.getOpsYonu().equalsIgnoreCase("S") && tx.getPrimDoviz().equalsIgnoreCase(tx.getBazDvz())) {
				subeKar = ((tx.getPrimMusteri().subtract(maliyetPrim)).multiply(tx.getBazTutar())).divide(new BigDecimal(100));
			}
			if (tx.getOpsYonu().equalsIgnoreCase("S") && !tx.getPrimDoviz().equalsIgnoreCase(tx.getBazDvz())) {
				subeKar = ((tx.getPrimMusteri().subtract(maliyetPrim)).multiply(tx.getKarsiTutar())).divide(new BigDecimal(100));
			}

		}
		else {

			if (tx.getOpsYonu().equalsIgnoreCase("A")) {
				subeKar = (((maliyetPrim.subtract(tx.getPrimMusteri())).multiply(tx.getKarsiTutar()))).divide(new BigDecimal(100));
			}
			else {
				subeKar = (((tx.getPrimMusteri().subtract(maliyetPrim)).multiply(tx.getKarsiTutar()))).divide(new BigDecimal(100));
			}

		}
		return subeKar;

	}

	@GraymoundService("BNSPR_TRN1579_SAVE")
	public static GMMap save1579(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			BigDecimal maliyetPrim = iMap.getBigDecimal("MALIYET_PRIM");
			BigDecimal subeKar� = iMap.getBigDecimal("SUBE_KARI");

			HznOpsiyonislemTx hznOpsiyonislemTx = (HznOpsiyonislemTx) session.createCriteria(HznOpsiyonislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			hznOpsiyonislemTx.setPrimMaliyet(maliyetPrim);
			hznOpsiyonislemTx.setPrimSubeKariTutar(subeKar�);
			session.saveOrUpdate(hznOpsiyonislemTx);
			
			if ("D".equals(iMap.getString("OPS_CINSI"))) {
				String bariyerCinsi = iMap.getString("BARIYER_CINSI");
				if(StringUtils.isBlank(bariyerCinsi)){
					throw new GMRuntimeException(0, "Dijital islemlerde bariyer cinsi bos olamaz.");
				}
				@SuppressWarnings("unchecked")
				List<HznOpsiyonBariyerTx> hznOpsiyonBariyerTxList = session.createCriteria(HznOpsiyonBariyerTx.class)
															.add(Restrictions.eq("referans", hznOpsiyonislemTx.getId().getReferans()))
															.list();
				
				for (HznOpsiyonBariyerTx hznOpsiyonBariyerTx : hznOpsiyonBariyerTxList) {
					hznOpsiyonBariyerTx.setBariyerCinsi(bariyerCinsi);
					session.saveOrUpdate(hznOpsiyonBariyerTx);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
