package tr.com.calikbank.bnspr.treasury.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class TreasuryQRY1359Services {
	
	@GraymoundService("BNSPR_QRY1359_LISTELE")
	public static GMMap listele(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC1359.RC_QRY1359_SWP_REESKONT_IZLEME(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			if(iMap.getDate("REESKONT_TARIHI") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("REESKONT_TARIHI").getTime()));
			else
				stmt.setDate(i++,null);
			if(iMap.getDate("BITIS_TARIHI") != null)
					stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()));
				else
					stmt.setDate(i++,null);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1); 
			String tableName = "SWP_REESKONT_IZLEME";
				oMap = DALUtil.rSetResults(rSet, tableName);		
			   return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
}
