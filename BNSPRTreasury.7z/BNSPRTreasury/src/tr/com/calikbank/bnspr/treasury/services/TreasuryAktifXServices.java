package tr.com.calikbank.bnspr.treasury.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TreasuryAktifXServices {
	

	private static Logger log = Logger.getLogger(TreasuryAktifXServices.class);
	
    @GraymoundService("BNSPR_AKTIFX_LIMIT_SERVICE")
    public static GMMap aktifXLimitCheck(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            /*
             * 
             *   procedure LimitKontrol(ps_reuters_id varchar2,
             *    ps_account_id varchar2 default null, 
             *    pd_valor_tarih date, 
             *    ps_alis_doviz_
             *    kodu varchar2, 
             *    pn_alis_tutar number, 
             *    ps_satis_doviz_kodu varchar2, 
             *    pn_satis_tutar number,
                    on_limit_yeterlimi out number, 
                    os_limit_cinsi out varchar2, 
                    on_limit_hesap_no out number, 
                    os_limit_hesap_doviz out varchar2, 
                    on_teminat_tutar out number) is
    
              @Parameter(name = "REUTERS_ID"              , type = ParameterType.SIMPLE),
            @Parameter(name = "ACCOUNT_ID"              , type = ParameterType.SIMPLE),
            @Parameter(name = "VALOR_TARIH"             , type = ParameterType.SIMPLE),
            @Parameter(name = "ALIS_DOVIZ_KOD"          , type = ParameterType.SIMPLE),
            @Parameter(name = "ALIS_TUTAR"              , type = ParameterType.SIMPLE),
            @Parameter(name = "SATIS_DOVIZ_KOD"         , type = ParameterType.SIMPLE),
            @Parameter(name = "SATIS_TUTAR"             , type = ParameterType.SIMPLE)
            },
        oParameters = {
            @Parameter(name = "RESPONSE"                , type = ParameterType.SIMPLE),
            @Parameter(name = "RESPONSE_DATA"           , type = ParameterType.SIMPLE), 
            @Parameter(name = "YETERLILIK_KODU"         , type = ParameterType.SIMPLE)
    
             */
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_REUTERS_ET.LimitKontrol(?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?) }");
            int i = 1;
            
            stmt.setString(i++ , iMap.getString("DEAL_TYPE", "FORWARD"));
            stmt.setString(i++ , iMap.getString("REUTERS_ID"));
            stmt.setString(i++ , iMap.getString("ACCOUNT_ID"));
            stmt.setDate(i++ , new java.sql.Date(iMap.getDate("VALOR_TARIH").getTime())); 
            stmt.setString(i++ , iMap.getString("ALIS_DOVIZ_KOD")); 
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("ALIS_TUTAR"));
            stmt.setString(i++ , iMap.getString("SATIS_DOVIZ_KOD"));   
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("SATIS_TUTAR")); 
       
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            
            stmt.execute();

            oMap.put("YETERLILIK_KODU", stmt.getBigDecimal(9).toString() + stmt.getString(9));


        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
  
   }
    
    /*
     * 
    
     * 
     * 
     *     @GraymoundService("AKTIFX_WS_TRANSACTION_SERVICE")
    @GraymoundServiceParameters(iParameters = {
            @Parameter(name = "PS_REUTERS_ID"         , type = ParameterType.SIMPLE),
            @Parameter(name = "PS_GID_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "DEAL_TYPE"   , type = ParameterType.SIMPLE),
            @Parameter(name = "DEAL_DATE_TIME"   , type = ParameterType.SIMPLE),
            @Parameter(name = "TAKER_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "TAKER_LBN_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "TAKER_ACCOUNT"   , type = ParameterType.SIMPLE),
            @Parameter(name = "TAKER_GROUP_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "MAKER_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "MAKER_LBN_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "MAKER_GROUP_ID"   , type = ParameterType.SIMPLE),
            @Parameter(name = "XML_DATA"   , type = ParameterType.SIMPLE),
            @Parameter(name = "SPT_VALOR_TARIH"   , type = ParameterType.SIMPLE),
            @Parameter(name = "SPT_ALIS_DOVIZ_KODU"   , type = ParameterType.SIMPLE),
            @Parameter(name = "SPT_ALIS_TUTAR"   , type = ParameterType.SIMPLE),
            @Parameter(name = "SPT_SATIS_DOVIZ_KODU"   , type = ParameterType.SIMPLE),
            @Parameter(name = "SPT_SATIS_TUTAR"   , type = ParameterType.SIMPLE),
            @Parameter(name = "SPT_ANLASMA_KURU"   , type = ParameterType.SIMPLE),
            @Parameter(name = "FWD_VALOR_TARIH"   , type = ParameterType.SIMPLE),
            @Parameter(name = "FWD_ALIS_DOVIZ_KODU"   , type = ParameterType.SIMPLE),
            @Parameter(name = "FWD_ALIS_TUTAR"   , type = ParameterType.SIMPLE),
            @Parameter(name = "FWD_SATIS_DOVIZ_KODU"   , type = ParameterType.SIMPLE),
            @Parameter(name = "FWD_SATIS_TUTAR"   , type = ParameterType.SIMPLE),
            @Parameter(name = "FWD_ANLASMA_KURU"   , type = ParameterType.SIMPLE)
            },
        oParameters = {
            @Parameter(name = "RESPONSE"                , type = ParameterType.SIMPLE),
            @Parameter(name = "RESPONSE_DATA"           , type = ParameterType.SIMPLE), 
            @Parameter(name = "TX_NO"             , type = ParameterType.SIMPLE) 
            
            
       Islem_Kaydet(ps_reuters_id varchar2, ps_gid_id varchar2,
        ps_deal_type varchar2,
        ps_deal_date_time VARCHAR2,
        ps_taker_id       VARCHAR2,
        ps_taker_lbn_id   VARCHAR2,
        ps_taker_account  VARCHAR2,
        ps_taker_group_id VARCHAR2,
        ps_maker_id       VARCHAR2,
        ps_maker_lbn_id   VARCHAR2,
        ps_maker_group_id VARCHAR2,
        ps_xml_data clob,
        pd_spt_valor_tarih date, 
        ps_spt_alis_doviz_kodu varchar2, 
        pn_spt_alis_tutar number, 
        ps_spt_satis_doviz_kodu varchar2, 
        pn_spt_satis_tutar number,
        pn_spt_anlasma_kuru  number,
        pd_fwd_valor_tarih date, 
        ps_fwd_alis_doviz_kodu varchar2, 
        pn_fwd_alis_tutar number, 
        ps_fwd_satis_doviz_kodu varchar2, 
        pn_fwd_satis_tutar number,
        pn_fwd_anlasma_kuru  number
        ) 
        
        
     
     */

    @GraymoundService("BNSPR_AKTIFX_TRANSACTION_SERVICE")
    public static GMMap aktifXTransactionStart(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_REUTERS_ET.Islem_Kaydet(?, ?,?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?, ?,? ) }");
            int i = 1;
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.setString(i++ , iMap.getString("PS_REUTERS_ID"));
            stmt.setString(i++ , iMap.getString("PS_GID_ID"));
            stmt.setString(i++ , iMap.getString("DEAL_TYPE"));
            stmt.setString(i++ , iMap.getString("DEAL_DATE_TIME"));
            stmt.setString(i++ , iMap.getString("TAKER_ID"));
            stmt.setString(i++ , iMap.getString("TAKER_LBN_ID"));
            stmt.setString(i++ , iMap.getString("TAKER_ACCOUNT"));
            stmt.setString(i++ , iMap.getString("TAKER_GROUP_ID"));
            stmt.setString(i++ , iMap.getString("MAKER_ID"));
            stmt.setString(i++ , iMap.getString("MAKER_LBN_ID"));
            stmt.setString(i++ , iMap.getString("MAKER_GROUP_ID"));
            stmt.setString(i++ , iMap.getString("XML_DATA"));
            
       
            stmt.setDate(i++ , new java.sql.Date(iMap.getDate("SPT_VALOR_TARIH").getTime())); 
            stmt.setString(i++ , iMap.getString("SPT_ALIS_DOVIZ_KODU")); 
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("SPT_ALIS_TUTAR"));
            stmt.setString(i++ , iMap.getString("SPT_SATIS_DOVIZ_KODU"));   
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("SPT_SATIS_TUTAR")); 
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("SPT_ANLASMA_KURU")); 
            
            stmt.setDate(i++ , new java.sql.Date(iMap.getDate("FWD_VALOR_TARIH").getTime())); 
            stmt.setString(i++ , iMap.getString("FWD_ALIS_DOVIZ_KODU")); 
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("FWD_ALIS_TUTAR"));
            stmt.setString(i++ , iMap.getString("FWD_SATIS_DOVIZ_KODU"));   
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("FWD_SATIS_TUTAR")); 
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("FWD_ANLASMA_KURU")); 
    

            stmt.execute();

            oMap.put("TX_NO", stmt.getBigDecimal(1));//.getBigDecimal(--i));


        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
  
   }
    
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_AKTIFX_ONAY_JOB")
	public static GMMap aktifxOnayJob(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			String jobId = UUID.randomUUID().toString();
			log.info(jobId + " nolu job (aktifx_onay) basladi");

			/*
			 * AKTIFX kullanicisi icin islem listesi cekilir
			 */
			List<HashMap<?, ?>> islemListesi = (ArrayList<HashMap<?, ?>>) GMServiceExecuter.call("BNSPR_MESAJ_KUTUSU_GELEN_GET_RECORD", new GMMap()
								.put("TUTAR", 0)
								.put("KULLANICI_KOD", "AKTIFX"))
								.get("RESULTS");
			
			if (islemListesi != null) {
				for (HashMap<?, ?> i : islemListesi) {
					try {
						GMMap islem = new GMMap(i);
						
						BigDecimal txNo = islem.getBigDecimal("NO");
						
						log.info(jobId + " nolu job (aktifx_onay) islem onaylanacak : " + txNo);
						
						String mesaj = GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap()
								.put("ISLEM_NO", txNo)
								.put("ISLEM_TURU", "O")
								.put("ACIKLAMA", "AKTIFX OTOMATIK ONAY")).getString("MESSAGE");
						
						log.info(jobId + " nolu job (aktifx_onay) islem : " + txNo + " - mesaj : " + mesaj);
						
					} catch (Exception e) {
						// hatayi firlatma bir sonraki kumeyle devam et donguye
						log.error(jobId + " nolu job (aktifx_onay) hata : " + e.getMessage());
					}
				}
			}
			
			log.info(jobId + " nolu job (aktifx_onay) bitti");
			
			return oMap;
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}
    
    @GraymoundService("BNSPR_AKTIFX_ISLEM_KAYDET_JOB")
	public static GMMap aktifxIslemKaydetJob(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			
			String jobId = UUID.randomUUID().toString();
			log.info(jobId + " nolu job (aktifx_islem_kaydet) basladi");
			
			/*
			 * AKTIFX kullanicisi set edilir
			 */
			setAktifxUser();
			
			/*
			 * AKTIFX hata alan islemler cekilir
			 */
			String tableName = "LIST";
			GMMap listMap = DALUtil.getResults("select * from reuters_et_islem where tx_no is null", tableName);
			
			for (int row = 0; row < listMap.getSize(tableName); row++) {
				String gidId = listMap.getString(tableName, row, "PS_GID_ID");
				
				try {

					log.info(jobId + " nolu job (aktifx_islem_kaydet) islem yapilacak : " + gidId);

					GMMap txMap = new GMMap();
					txMap.put("PS_REUTERS_ID", listMap.getString(tableName, row, "PS_REUTERS_ID"));
		            txMap.put("PS_GID_ID", listMap.getString(tableName, row, "PS_GID_ID"));
		            txMap.put("DEAL_TYPE", listMap.getString(tableName, row, "PS_DEAL_TYPE"));
		            txMap.put("DEAL_DATE_TIME", listMap.getString(tableName, row, "PS_DEAL_DATE_TIME"));
		            txMap.put("TAKER_ID", listMap.getString(tableName, row, "PS_TAKER_ID"));
		            txMap.put("TAKER_LBN_ID", listMap.getString(tableName, row, "PS_TAKER_LBN_ID"));
		            txMap.put("TAKER_ACCOUNT", listMap.getString(tableName, row, "PS_TAKER_ACCOUNT"));
		            txMap.put("TAKER_GROUP_ID", listMap.getString(tableName, row, "PS_TAKER_GROUP_ID"));
		            txMap.put("MAKER_ID", listMap.getString(tableName, row, "PS_MAKER_ID"));
		            txMap.put("MAKER_LBN_ID", listMap.getString(tableName, row, "PS_MAKER_LBN_ID"));
		            txMap.put("MAKER_GROUP_ID", listMap.getString(tableName, row, "PS_MAKER_GROUP_ID"));
		            txMap.put("XML_DATA", listMap.get(tableName, row, "PS_XML_DATA"));
		       
		            txMap.put("SPT_VALOR_TARIH", listMap.getDate(tableName, row, "PD_SPT_VALOR_TARIH")); 
		            txMap.put("SPT_ALIS_DOVIZ_KODU", listMap.getString(tableName, row, "PS_SPT_ALIS_DOVIZ_KODU")); 
		            txMap.put("SPT_ALIS_TUTAR", listMap.getBigDecimal(tableName, row, "PN_SPT_ALIS_TUTAR"));
		            txMap.put("SPT_SATIS_DOVIZ_KODU", listMap.getString(tableName, row, "PS_SPT_SATIS_DOVIZ_KODU"));   
		            txMap.put("SPT_SATIS_TUTAR", listMap.getBigDecimal(tableName, row, "PN_SPT_SATIS_TUTAR")); 
		            txMap.put("SPT_ANLASMA_KURU", listMap.getBigDecimal(tableName, row, "PN_SPT_ANLASMA_KURU")); 
		            
		            txMap.put("FWD_VALOR_TARIH", listMap.getDate(tableName, row, "PD_FWD_VALOR_TARIH")); 
		            txMap.put("FWD_ALIS_DOVIZ_KODU", listMap.getString(tableName, row, "PS_FWD_ALIS_DOVIZ_KODU")); 
		            txMap.put("FWD_ALIS_TUTAR", listMap.getBigDecimal(tableName, row, "PN_FWD_ALIS_TUTAR"));
		            txMap.put("FWD_SATIS_DOVIZ_KODU", listMap.getString(tableName, row, "PS_FWD_SATIS_DOVIZ_KODU"));   
		            txMap.put("FWD_SATIS_TUTAR", listMap.getBigDecimal(tableName, row, "PN_FWD_SATIS_TUTAR")); 
		            txMap.put("FWD_ANLASMA_KURU", listMap.getBigDecimal(tableName, row, "PN_FWD_ANLASMA_KURU")); 
					
					BigDecimal txNo = GMServiceExecuter.call("BNSPR_AKTIFX_TRANSACTION_SERVICE", txMap).getBigDecimal("TX_NO");
					
					log.info(jobId + " nolu job (aktifx_islem_kaydet) islem yapildi : " + gidId + " - txNo : " + txNo);
					
				} catch (Exception e) {
					// hatayi firlatma bir sonraki kumeyle devam et donguye
					log.error(jobId + " nolu job (aktifx_islem_kaydet) hata : " + gidId + " - " + e.getMessage());
				}
			}
			
			log.info(jobId + " nolu job (aktifx_islem_kaydet) bitti");
			
			return oMap;
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}
    
    private static void setAktifxUser() throws Exception {
		try {
	    	BnsprCommonFunctions.setUserGlobals2("AKTIFX");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
	
}
