package tr.com.calikbank.bnspr.customer.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CustomerTRN2002Test extends TestCase {
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", 2850);
		iMap.put("MUSTERI_NO", 12);
		iMap.put("HESAP_NO", 323);
		iMap.put("KAPAMA_TURU", "E");
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("ODENECEK_FAIZ", 45);
		iMap.put("MSIGV", 32);
		iMap.put("SSDF", 14);
		iMap.put("ACIKLAMA", "qsdadsfd");
		iMap.put("NET_ODENEN_TUTAR", 234);
		iMap.put("TL_ODENEN_TUTAR", 343);
		iMap.put("ISTATISTIK_KODU", "4576");
		iMap.put("DEKONT", "H");

		return iMap;
	}

	public void testHesapNoNotNull() {
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("HESAP_NO", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2002_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}

	public void testAciklamaNotNull() {
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2002_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}

	public void testDekontNotNull() {
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DEKONT", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2002_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testKurNotNull(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("TL_ODENEN_TUTAR", 2);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2002_GET_KUR_TO_TL", iMap);
		assertNotNull(oMap.get("KUR"));
		assertNotNull(oMap.get("TL_KARSILIK"));
	}
	public void testCanGetCorrectKurValue(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("TL_ODENEN_TUTAR", 2);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2002_GET_KUR_TO_TL", iMap);
		assertEquals(new BigDecimal(1),oMap.get("KUR"));
		assertEquals(new BigDecimal(2),oMap.get("TL_KARSILIK"));
		
	}
	
	public void testKurTipNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("TL_ODENEN_TUTAR", 2);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2002_GET_KUR_TO_TL", iMap);
		assertTrue(oMap.get("KUR") instanceof BigDecimal);
		assertTrue(oMap.get("TL_KARSILIK") instanceof BigDecimal);
	}
	
	public void testCanGetCorrectFaizAmount(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MUSTERI_NO", 1);
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("ODENECEK_FAIZ", 4);
		iMap.put("BAKIYE_TUTARI", 11);
		iMap.put("KAPAMA_TURU", "Kapama");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2002_GET_FAIZ_AMOUNT", iMap);
		assertEquals("",new Double(0.40),(Double.parseDouble(oMap.get("MSIGV").toString())) ,new Double(0.1));
		
	}
}
