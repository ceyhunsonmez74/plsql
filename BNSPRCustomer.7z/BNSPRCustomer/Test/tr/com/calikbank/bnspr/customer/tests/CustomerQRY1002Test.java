package tr.com.calikbank.bnspr.customer.tests;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CustomerQRY1002Test extends TestCase {
	
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_CINSI", "XXB");


		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
		iMap.put("BAS_TARIH", dateFormat.parse("11-11-2005"));
		iMap.put("SON_TARIH", dateFormat.parse("11-11-2007"));
		}catch (Exception e) {}
		iMap.put("SIRALAMA_KRITERI", "M");
		iMap.put("DURUM_KODU", "KAPALI");		
		return iMap;
	}
	
	public void testCustomerInfo(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY1002_GET_CUSTOMER_INFO", iMap);
		List<?> list = (List<?>)oMap.get("MUSTERI_DETAY");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();		
			assertEquals("1",rowData.get("BELGE_NO")); 
			assertEquals("DENEME ISLETME", rowData.get("UNVAN"));
			assertEquals("2", rowData.get("MUSTERI_NO"));
			assertEquals("XXB", rowData.get("BELGE_KODU"));
			assertEquals("KAPALI", rowData.get("DURUM_KODU"));
			assertEquals("2007-11-04",rowData.get("GECERLILIK_TARIHI").toString());
			assertEquals("2007-09-04", rowData.get("TARIH").toString());	
		}
	}
	

}
