package tr.com.calikbank.bnspr.customer.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CustomerTRN1006Test extends TestCase {

	public HashMap<String, Object> setUpIMap() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 3638);
		iMap.put("MUSTERI_NO", 2);

		HashMap<String, Object> rowData = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> outList = new ArrayList<HashMap<String, Object>>();
		rowData.put("ISLEM_KODU",2011);
		rowData.put("MASRAF_KODU","ARBITRAJ");
		outList.add(rowData);
		iMap.put("MUAF_MASRAFLAR", outList);
		rowData.put("TUTAR",0.00);
		rowData.put("DOVIZ","EUR");
		outList.add(rowData);
		iMap.put("FIX_MASRAFLAR", outList);
		

		return iMap;
	}

	// M�steri no string olmamal�
	public void testGetTRXNO_NoneDecimalMusteriNo() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("MUSTERI_NO", "A");
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1006_GET_TRXNO",	iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// msteri no ya g�re d�nen trx no type kontrol
	public void testGetTRXNO_TypeTrxNo() {
		HashMap<String, Object> iMap = setUpIMap();
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1006_GET_TRXNO", iMap);
		assertTrue(oMap.get("TRX_NO") instanceof String);

	}

	public void testgetMuafRecord() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1006_GET_MUAF_RECORD", iMap);

		List<?> listMF = (List<?>) oMap.get("MUAF_MASRAFLAR");
		Iterator<?> iterator = listMF.iterator();
		if (iterator.hasNext()) {

			HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals(2011, rowData.get("ISLEM_KODU"));
			assertEquals("ARBITRAJ", rowData.get("MASRAF_KODU"));
		}

	}
	public void testgetFixRecord() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1006_GET_FIX_RECORD", iMap);

		List<?> listMF = (List<?>) oMap.get("FIX_MASRAFLAR");
		Iterator<?> iterator = listMF.iterator();
		if (iterator.hasNext()) {

			HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals(2011, rowData.get("ISLEM_KODU"));
			assertEquals("ARBITRAJ", rowData.get("MASRAF_KODU"));
			assertEquals(0.00, rowData.get("TUTAR"));
			assertEquals("EUR", rowData.get("DOVIZ"));
			
		}

	}
	/*public void testAssertEqOMap(){
        
        HashMap<String, Object> iMap = new HashMap<String, Object>();
        iMap.put("TRX_NO" , "1234");
        
        Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1006_GET_INFO", iMap);
        
        assertEquals(oMap.get("DI_MUSTERI_ADI")				, Graymound Automates Service || Error..Not Matched. );
        assertEquals(oMap.get("TX_NO")				, null);
        assertEquals(oMap.get("MUSTERI_NO")				, null);
        assertEquals(oMap.get("CBS_MUSTERI_ISLEM_MASRAF_MUAF")				, Graymound Automates Service || Error..Not Matched. );
        assertEquals(oMap.get("CBS_MUSTERI_ISLEM_MASRAF_FIX")				, Graymound Automates Service || Error..Not Matched. );
        
	}*/


}
