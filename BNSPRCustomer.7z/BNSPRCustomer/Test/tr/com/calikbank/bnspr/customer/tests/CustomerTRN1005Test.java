package tr.com.calikbank.bnspr.customer.tests;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CustomerTRN1005Test extends TestCase {

	// ZORUNLU ALAN KONTROLLERI - TRX_NO bo� olmamal�
	public void testSetTrxNo_NullTrxNo() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", null);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("1-10-2007"));
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("1-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// ZORUNLU ALAN KONTROLLERI - Musteri_NO bo� olmamal�
	public void testSetTrxNo_NullMusteriNo() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", null);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("1-10-2007"));
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("1-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// ZORUNLU ALAN KONTROLLERI - Musteri_NO string olmamal�
	public void testSetTrxNo_NoneDecimalMusteriNo() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", "");
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("1-10-2007"));
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("1-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// ZORUNLU ALAN KONTROLLERI - Belge_Kodu bo� olmamal�
	public void testSetTrxNo_NullBelgeKodu() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", null);
		iMap.put("BELGE_NO", "11111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("10-10-2007"));
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("10-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// ZORUNLU ALAN KONTROLLERI - Belge_Kodu decimal olmamal�
	public void testSetTrxNo_NoneStringBelgeKodu() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", 123);
		iMap.put("BELGE_NO", "11111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("10-10-2007"));
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("10-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// ZORUNLU ALAN KONTROLLERI - Belge_No bo� olmamal�
	public void testSetTrxNo_NullBelgeNo() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", null);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("10-10-2007"));
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("10-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// ZORUNLU ALAN KONTROLLERI - Tarih bo� olmamal�
	public void testSetTrxNo_NullTarih() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", null);
		iMap.put("SURE", "2");
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("10-12-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// BAGIMLI ALAN KONTROLLERI - S�re bo� ise Ge�erlilik Tarihi zorunlu olmal�
	public void testSetTrxNo_NoneSure() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("1-10-2007"));
		iMap.put("SURE", null);
		iMap.put("GECERLILIK_TARIHI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// BAGIMLI ALAN KONTROLLERI - Ge�erlilik Tarihi banka tarihinden �nce olamaz
	public void testSetTrxNo_GecerlilikTarihiBankaOncesi()
			throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("1-10-2007"));
		iMap.put("SURE", null);
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("3-10-2007"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// BAGIMLI ALAN KONTROLLERI - Tarih banka tarihinden sonra olamaz
	public void testSetTrxNo_TarihBankaSonrasi() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", 1);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("1-12-2007"));
		iMap.put("SURE", null);
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("1-2-2008"));
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println("" + success.toString());
		}
	}

	// BAGIMLI ALAN KONTROLLERI - Ayn� musteri no ,belge cinsi, belge no ve
	// tarih olamaz
	public void testSetTrxNo_AyniVerilerKontrol() throws ParseException {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		long musteriNo = new Random(System.currentTimeMillis()).nextLong();

		iMap.put("TRX_NO", new Long(musteriNo));
		iMap.put("MUSTERI_NO", new Long(musteriNo));
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		iMap.put("TARIH", dateFormat.parse("6-10-2007"));
		iMap.put("SURE", null);
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("6-12-2007"));

		GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);

		iMap.put("TRX_NO", new Long(musteriNo));
		iMap.put("MUSTERI_NO", new Long(musteriNo));
		iMap.put("BELGE_KODU", "YTB");
		iMap.put("BELGE_NO", "1111");
		iMap.put("TARIH", dateFormat.parse("6-10-2007"));
		iMap.put("SURE", null);
		iMap.put("GECERLILIK_TARIHI", dateFormat.parse("6-12-2007"));

		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN1005_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception exception) {

		}
	}

	public void testAssertEqOMap(){
        
        HashMap<String, Object> iMap = new HashMap<String, Object>();
        iMap.put("TRX_NO" , "714");
        
        Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1005_GET_INFO", iMap);
        
        assertEquals(oMap.get("BELGE_NO")				, "23132121");
        assertEquals(oMap.get("SURE")					, new BigDecimal(0));
        assertEquals(oMap.get("MUSTERI_NO")				, new BigDecimal(1000006));
        assertEquals(oMap.get("BELGE_KODU")				, "BLG1");
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        
        try {
			assertEquals(oMap.get("TARIH")					, dateFormat.parseObject("12.12.2006"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
        assertEquals(oMap.get("GECERLILIK_TARIHI")		, null);
       
        
        
	}

}
