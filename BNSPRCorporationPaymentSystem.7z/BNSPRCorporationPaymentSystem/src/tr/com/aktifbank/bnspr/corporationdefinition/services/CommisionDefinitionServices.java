package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CommissionDef;
import tr.com.aktifbank.bnspr.dao.CommissionDefTx;
import tr.com.aktifbank.bnspr.dao.CommissionShare;
import tr.com.aktifbank.bnspr.dao.CommissionWageScale;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.obss.adc.core.services.transaction.ServiceExecuter;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CommisionDefinitionServices {
	private static final Log logger = LogFactory.getLog(CommisionDefinitionServices.class);
	private static final String dateFormat = "yyyyMMddHHmmss";
	private static final String CHANNEL_CODE_ALL="0";
	// gets parameter for CDM_KOMISYON_ODEYEN
	@GraymoundService("CDM_GET_COMMISSION_PAYER_TYPES_COMBO")
	public static GMMap getFileFormatTypesCombo(GMMap iMap) {
		return CorporationServiceUtil.getComboValues(iMap);
	}

	// gets parameters for CDM_MASRAF_TIPI
	@GraymoundService("CDM_COMMISSION_GET_TYPE_OF_COST_COMBO")
	public static GMMap getCommissionGetTypeOfCostCombo(GMMap iMap) {
		return CorporationServiceUtil.getComboValues(iMap);
	}

	// gets parameters for CDM_MASRAF_TIPI
	@GraymoundService("CDM_COMMISSION_GET_SHARE_PERIOD")
	public static GMMap getCommissionSharePeriod(GMMap iMap) {
		return CorporationServiceUtil.getComboValues(iMap);
	}

	// gets parameters for CDM_BSMV
	@GraymoundService("CDM_COMMISSION_GET_BSMV_TYPE")
	public static GMMap getCommissionGetBSMVTypeCombo(GMMap iMap) {
		return CorporationServiceUtil.getComboValues(iMap);
	}

	@GraymoundService("CDM_COMMISSION_INSTANCE_SERVICE_LOAD")
	public static GMMap instanceServiceLoad(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("COMMISSION_PAYER_TYPES_RESULTS", ServiceExecuter.call("CDM_GET_COMMISSION_PAYER_TYPES_COMBO", (new GMMap()).put("KOD", iMap.getString("CDM_KOMISYON_ODEYEN"))).get("RESULTS"));
			oMap.put("COMMISSION_GET_TYPE_OF_COST_RESULTS", ServiceExecuter.call("CDM_COMMISSION_GET_TYPE_OF_COST_COMBO", (new GMMap()).put("KOD", iMap.getString("CDM_MASRAF_TIPI"))).get("RESULTS"));
			oMap.put("COMMISSION_GET_BSMV_TYPE_RESULTS", ServiceExecuter.call("CDM_COMMISSION_GET_BSMV_TYPE", (new GMMap()).put("KOD", iMap.getString("CDM_BSMV"))).get("RESULTS"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_COMMISSION_ROW_SHOW")
	public static GMMap showRowCommission(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMap = new GMMap();
		try {
			rowMap = iMap.getMap("COMMISSION_SELECTED_ROW_DATA");
			oMap.put("PAYER_CODE", rowMap.getString("PAYER_CODE"));
			oMap.put("COMMISSION_TYPE_CODE", rowMap.getString("COMMISSION_TYPE_CODE"));
			oMap.put("COMMISSION", StringUtils.isBlank(rowMap.getString("COMMISSION"))?"0.00":new BigDecimal(rowMap.getString("COMMISSION")));
			oMap.put("CHANNEL_CODE", rowMap.getString("CHANNEL_CODE"));
			oMap.put("BSMV_CODE", rowMap.getString("BSMV_CODE"));
			oMap.put("CORPORATE_CODE", rowMap.getString("CORPORATE_CODE"));
			oMap.put("CORPORATE_NAME", rowMap.getString("CORPORATE_NAME"));
			oMap.put("OPERATION", true);
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}
	
	@GraymoundService("CDM_ADD_NEW_RECORD")
	public static GMMap cdmAddNewRecord(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = validationCommission(iMap);
			if(oMap.getBoolean("OPERATION")){
			int selectedRow = iMap.getInt("COMMISSION_SELECTED_ROW");
			GMMap rowMap = new GMMap();
			rowMap.put("CORPORATE_CODE", iMap.getString("CORPORATE_CODE"));
			rowMap.put("CORPORATE_NAME", iMap.getString("CORPORATE_NAME"));
			rowMap.put("PAYER_CODE", iMap.getString("PAYER_CODE"));
			rowMap.put("PAYER", iMap.getString("PAYER"));
			rowMap.put("COMMISSION_TYPE_CODE", iMap.getString("COMMISSION_TYPE_CODE"));
			rowMap.put("COMMISSION_TYPE", iMap.getString("COMMISSION_TYPE"));
			rowMap.put("CHANNEL_CODE", iMap.getString("CHANNEL_CODE"));
			rowMap.put("CHANNEL_NAME", iMap.getString("CHANNEL_NAME"));
			rowMap.put("BSMV_CODE", iMap.getString("BSMV_CODE"));
			rowMap.put("BSMV", iMap.getString("BSMV"));
			rowMap.put("COMMISSION", iMap.getString("COMMISSION"));

			if (iMap.getString("CHANNEL_CODE").equals(CHANNEL_CODE_ALL)) {
				oMap.put("COMMISSION_LIST", iMap.get("COMMISSION_LIST"));
				GMMap resultMap = getCommissionChannelList(iMap);
				for (int row = 0; row < resultMap.getSize("CHANNEL_LIST"); row++) {
					GMMap rowMapAll = new GMMap();
					rowMapAll.putAll(rowMap);
					rowMapAll.put("CHANNEL_CODE", resultMap.getString("CHANNEL_LIST", row, "KOD"));
					rowMapAll.put("CHANNEL_NAME", resultMap.getString("CHANNEL_LIST", row, "ACIKLAMA"));
					oMap.put("COMMISSION_LIST", row, rowMapAll);
				}
			} else {
				for (int i = 0; i < iMap.getSize("COMMISSION_LIST"); i++) {
					if (i == selectedRow) {
						oMap.put("COMMISSION_LIST", i, rowMap);
					} else {
						oMap.put("COMMISSION_LIST", i, iMap.getMap("COMMISSION_LIST", i));
					}
				}
				if (-1 == selectedRow) {
					oMap.put("COMMISSION_LIST", iMap.getSize("COMMISSION_LIST"), rowMap);
				}
			}
			oMap.put("OPERATION", true);
			oMap.put("MESSAGE", "Kay�t i�lemi ba�ar� ile tamamlanm��t�r.");
			}else{
				oMap.put("COMMISSION_LIST", iMap.get("COMMISSION_LIST"));
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			oMap.put("COMMISSION_LIST", "COMMISSION_LIST");
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	public static GMMap validationDomain(GMMap iMap, String colomn, GMMap oMap, String warnMessage) {
		if (StringUtils.isBlank(iMap.getString(colomn))) {
			oMap.clear();
			oMap.put("FOCUS", colomn);
			oMap.put("MESSAGE", warnMessage);
			oMap.put("OPERATION", false);
		}
		return oMap;
	}
	
	public static GMMap validationExtra(String domain, GMMap oMap, String warnMessage) {
		oMap.clear();
		oMap.put("FOCUS", domain);
		oMap.put("MESSAGE", warnMessage);
		oMap.put("OPERATION", false);
		return oMap;
	}
	
	private static GMMap validationCommission(GMMap iMap) {

		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {
			if (!validationDomain(iMap, "CORPORATE_CODE", oMap, "L�tfen Kurum Ad� alan�n� uygun olarak doldurunuz!").getBoolean("OPERATION"))
				return oMap;
			if (!validationDomain(iMap, "PAYER_CODE", oMap, "L�tfen Kimden al�nacak alan�n� uygun olarak doldurunuz!").getBoolean("OPERATION"))
				return oMap;
			if (!validationDomain(iMap, "COMMISSION_TYPE_CODE", oMap, "L�tfen Masraf Tipi alan�n� uygun olarak doldurunuz!").getBoolean("OPERATION"))
				return oMap;
			if (!validationDomain(iMap, "CHANNEL_CODE", oMap, "L�tfen Kurum Kanal uygun olarak doldurunuz!").getBoolean("OPERATION"))
				return oMap;
			if (!validationDomain(iMap, "BSMV_CODE", oMap, "L�tfen BSMV alan�n� uygun olarak doldurunuz!").getBoolean("OPERATION"))
				return oMap;
			if(checkChannelIsRecorded(iMap)) {
				validationExtra("CHANNEL_CODE", oMap, "Ayn� kanal i�in ayn� �deyiciye sadece bir tan�mlama yapabilirsiniz!");
				return oMap;
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}
	private static boolean checkChannelIsRecorded(GMMap iMap) throws Exception {
		int selectedRow = iMap.getInt("COMMISSION_SELECTED_ROW");
		String channelCode = iMap.getString("CHANNEL_CODE");
		String payerCode=iMap.getSize("COMMISSION_LIST")>0?iMap.getString("COMMISSION_LIST", 0, "PAYER_CODE"):"-99999__";//daha �nce listede kay�t yok ise payer code -99999__ atan�yor.
		if(((selectedRow==-1&&iMap.getSize("COMMISSION_LIST")>0)||(selectedRow>-1&&iMap.getSize("COMMISSION_LIST")>1))&&channelCode.equals(CHANNEL_CODE_ALL)&&payerCode.equals(iMap.getString("PAYER_CODE"))) {
			return true;
		}
		GMMap resultMap = getCommissionChannelList(iMap);
		for (int row = 0; row < resultMap.getSize("CHANNEL_LIST"); row++) {
			for (int i = 0; i < iMap.getSize("COMMISSION_LIST"); i++) {
				if (selectedRow!=i&&iMap.getString("COMMISSION_LIST", i, "CHANNEL_CODE").equals(resultMap.getString("CHANNEL_LIST", row, "KOD"))
						&&iMap.getString("COMMISSION_LIST", i, "CHANNEL_CODE").equals(iMap.getString("CHANNEL_CODE"))
						&&iMap.getString("COMMISSION_LIST", i, "PAYER_CODE").equals(iMap.getString("PAYER_CODE"))) {
					return true;
				}
			}
		}
		return false;
	}
		
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_COMMISSION_SAVE_AFTER_APPROVAL")
	public static GMMap cdmCommissionSaveAfterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		String crDate = CommonHelper.getDateString(new Date(), dateFormat);
		try {
			List<CommissionDefTx> commissionDefTxList = session.createCriteria(CommissionDefTx.class)
					.add(Restrictions.eq("txNo", new BigDecimal(iMap.getString("ISLEM_NO"))))
					.list();
			List<CommissionDef> commissionDefList = session.createCriteria(CommissionDef.class)
					.add(Restrictions.eq("corporateCode",commissionDefTxList.get(0).getCorporateCode()))
					.add(Restrictions.eq("status", true))
					.list();
			if(!commissionDefList.isEmpty())
			for (CommissionDef commissionDef : commissionDefList) {
				commissionDef.setStatus(false);
				commissionDef.setUpdateDate(crDate);
				commissionDef.setUpdateUser(username);
				session.saveOrUpdate(commissionDef);
			}
			for (CommissionDefTx commissionDefTx : commissionDefTxList) {
				if("A".equalsIgnoreCase(commissionDefTx.getActiveness())) {
					CommissionDef commissionDef =new CommissionDef();
					commissionDef.setStatus(true);
					commissionDef.setCorporateCode(commissionDefTx.getCorporateCode());
					commissionDef.setPayer(commissionDefTx.getPayer());
					commissionDef.setChannelCode(commissionDefTx.getChannelCode());
					commissionDef.setCommissionType(commissionDefTx.getCommissionType());
					commissionDef.setCommission(commissionDefTx.getCommission());
					commissionDef.setBsmw(commissionDefTx.getBsmw());
					commissionDef.setAccountExemption(commissionDefTx.getAccountExemption());
					commissionDef.setCustomerExemption(commissionDefTx.getCustomerExemption());
					commissionDef.setGroupExemption(commissionDefTx.getGroupExemption());
					commissionDef.setSegmentExemption(commissionDefTx.getSegmentExemption());
					commissionDef.setCreateDate(crDate);
					commissionDef.setCreateUser(username);
					session.saveOrUpdate(commissionDef);
				}
			}
			for (CommissionDefTx commissionDefTx : commissionDefTxList) {
				commissionDefTx.setStatus(false);
				commissionDefTx.setUpdateDate(crDate);
				commissionDefTx.setUpdateUser(username);
				session.saveOrUpdate(commissionDefTx);
			}
			
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}
	

	@SuppressWarnings({ "unchecked" })
	@GraymoundService("CDM_COMMISSION_SAVE_DB")
	public static GMMap cdmCommissionSaveDb(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<CommissionDefTx> commissionDefTxList = session.createCriteria(CommissionDefTx.class).add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("status", true)).list();
			if (commissionDefTxList != null && commissionDefTxList.size() > 0) {
				oMap.put("OPERATION", true);
				oMap.put("MESSAGE", "Bu kurum i�in daha �nce masraf tan�m i�lemi onaya g�nderilmi�tir. Tekrar g�nderemezsiniz! ");
			} else {
				String txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString("TRX_NO");
				CommonHelper.callGraymoundServiceOutsideSession("CDM_COMMISSION_DEF_TX_SAVE", iMap.put("TRX_NO", txNo));
				GMMap service = new GMMap();
				service.put("TRX_NAME", "7017");
				service.put("TRX_NO", txNo);
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", service);

				oMap.put("OPERATION", true);
				oMap.put("MESSAGE", "Masraf tan�m i�lemi onaya g�nderilmi�tir. ");
			}
		} catch (Exception e) {
			oMap.put("OPERATION", false);
			oMap.put("MESSAGE", "Masraf tan�m i�lemi onaya g�nderilemedi. Hata olu�tu. ");
			e.printStackTrace();
		}
		return oMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_COMMISSION_DEF_TX_SAVE")
	public static GMMap saveCdmCommissionDefTx(GMMap iMap) throws Exception{
		Session session = DAOSession.getSession("BNSPRDal");
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		String crDate = CommonHelper.getDateString(new Date(), dateFormat);
		String tableName = "COMMISSION_LIST";
		List<CommissionDefTx> commissionDefTxList = session.createCriteria(CommissionDefTx.class)
				.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE")))
				.add(Restrictions.eq("status", true))
				.list();
		for (CommissionDefTx commissionDefTx : commissionDefTxList) {
			commissionDefTx.setStatus(false);
			commissionDefTx.setUpdateDate(crDate);
			commissionDefTx.setUpdateUser(username);
			session.saveOrUpdate(commissionDefTx);
		}
		for (int row = 0; row < iMap.getSize(tableName); row++) {
			CommissionDefTx commissionDefTx=new CommissionDefTx();
			commissionDefTx.setStatus(true);
			commissionDefTx.setActiveness("A");
			commissionDefTx.setCorporateCode(iMap.getString(tableName, row, "CORPORATE_CODE"));
			commissionDefTx.setChannelCode(iMap.getString(tableName, row, "CHANNEL_CODE"));
			commissionDefTx.setPayer(iMap.getString(tableName, row, "PAYER_CODE"));
			commissionDefTx.setCommissionType(iMap.getString(tableName, row, "COMMISSION_TYPE_CODE"));
			commissionDefTx.setCommission(new BigDecimal(StringUtils.isNotBlank(iMap.getString(tableName, row, "COMMISSION"))?iMap.getString(tableName, row, "COMMISSION"):"0.00"));
			commissionDefTx.setBsmw(iMap.getString(tableName, row, "BSMV_CODE"));
			commissionDefTx.setCustomerExemption("-".equals(iMap.getString(tableName, row, "CUSTOMER_EXEMPTION"))?"0":"1");
			commissionDefTx.setGroupExemption("-".equals(iMap.getString(tableName, row, "GROUP_EXEMPTION"))?"0":"1");
			commissionDefTx.setAccountExemption("-".equals(iMap.getString(tableName, row, "ACCOUNT_EXEMPTION"))?"0":"1");
			commissionDefTx.setSegmentExemption("-".equals(iMap.getString(tableName, row, "SEGMENT_EXEMPTION"))?"0":"1");
			commissionDefTx.setCreateDate(crDate);
			commissionDefTx.setCreateUser(username);
			commissionDefTx.setTxNo(new BigDecimal(iMap.getString("TRX_NO")));
			session.saveOrUpdate(commissionDefTx);
		}
		if(iMap.getSize(tableName)==0&&commissionDefTxList.size()==0) {
			List<CommissionDef> commissionDefList = session.createCriteria(CommissionDef.class).add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("status", true)).list();
			CommissionDef commissionDefTxOld=commissionDefList.get(0);
			CommissionDefTx commissionDefTx=new CommissionDefTx();
			commissionDefTx.setStatus(true);
			commissionDefTx.setActiveness("P");
			commissionDefTx.setCorporateCode(commissionDefTxOld.getCorporateCode());
			commissionDefTx.setChannelCode(commissionDefTxOld.getChannelCode());
			commissionDefTx.setPayer(commissionDefTxOld.getPayer());
			commissionDefTx.setCommissionType(commissionDefTxOld.getCommissionType());
			commissionDefTx.setCommission(commissionDefTxOld.getCommission());
			commissionDefTx.setBsmw(commissionDefTxOld.getBsmw());
			commissionDefTx.setCustomerExemption(commissionDefTxOld.getCustomerExemption());
			commissionDefTx.setGroupExemption(commissionDefTxOld.getGroupExemption());
			commissionDefTx.setAccountExemption(commissionDefTxOld.getAccountExemption());
			commissionDefTx.setSegmentExemption(commissionDefTxOld.getSegmentExemption());
			commissionDefTx.setCreateDate(crDate);
			commissionDefTx.setCreateUser(username);
			commissionDefTx.setTxNo(new BigDecimal(iMap.getString("TRX_NO")));
			session.saveOrUpdate(commissionDefTx);
		}
		return iMap;
	}
	// get channel list defined for corporate
	@GraymoundService("CDM_COMMISSION_LOAD_CHANNELS")
	public static GMMap getCommissionLoadChannels(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "CHANNEL_LIST";
		try {
			GMMap resultMap = getCommissionChannelList(iMap);
			if (resultMap.getSize(tableName) > 0) {
				oMap.put("CHANNEL_LIST", 0, "NAME", "T�m�");
				oMap.put("CHANNEL_LIST", 0, "VALUE", CHANNEL_CODE_ALL);
			}
			for (int row = 0; row < resultMap.getSize(tableName); row++) {
				GuimlUtil.wrapMyCombo(oMap, "CHANNEL_LIST", resultMap.getString(tableName, row, "KOD"),
						resultMap.getString(tableName, row, "ACIKLAMA"));
			}
			return oMap;
		} catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
	}
	private  static GMMap getCommissionChannelList(GMMap iMap) throws Exception{
		String tableName = "CHANNEL_LIST";
		StringBuilder sb = new StringBuilder();
		sb.append(String.format(QueryRepository.CommisionDefinitionServicesRepository.GET_CHANNEL_LIST, iMap.getString("CORPORATE_CODE")));
		GMMap resultMap = new GMMap();
		logger.debug("GET_CHANNEL_LIST sql query-->>>  "+sb.toString());
		resultMap = DALUtil.getResults(sb.toString(), tableName);
		return resultMap;
	}

	// get list of commission definitions from database
	@GraymoundService("CDM_COMMISSION_GET_COMMISSION_DEFS")
	public static GMMap getCommissionDefs(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			StringBuilder sb = new StringBuilder();
			sb.append(String.format(QueryRepository.CommisionDefinitionServicesRepository.GET_COMMISSION_DEFS,StringUtils.isBlank(iMap.getString("TRX_NO"))?"":"_TX"));
			if(StringUtils.isBlank(iMap.getString("TRX_NO"))) {
				sb.append(String.format(QueryRepository.CommisionDefinitionServicesRepository.GET_COMMISSION_DEFS_CORPORATE_CODE,iMap.getString("CORPORATE_CODE")));
			}else {
				sb.append(String.format(QueryRepository.CommisionDefinitionServicesRepository.GET_COMMISSION_DEFS_TX_NO,new BigDecimal(iMap.getString("TRX_NO"))));
			}
			logger.debug("CDM_COMMISSION_GET_COMMISSION_DEFS sql query-->>>  "+sb.toString());
			oMap = DALUtil.getResults(sb.toString(),  "COMMISSION_LIST");
			oMap.put("CORPORATE_CODE", oMap.getBoolean("COMMISSION_LIST", 0, "CORPORATE_CODE"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	// get list of commission sharings from database
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_COMMISSION_GET_COMMISSION_SHARES")
	public static GMMap getCommissionShares(GMMap iMap) {

		String tableName = "COMMISSION_SHARE_LIST";
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<CommissionShare> commissionShareList = session.createCriteria(CommissionShare.class)
					.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("status", true)).list();

			int row = 0;
			String status = "0";
			for (CommissionShare commission : commissionShareList) {
				oMap.put(tableName, row, "OID", commission.getOid());
				if (commission.isStatus()) {
					status = "1";
				} else {
					status = "0";
				}
				oMap.put(tableName, row, "STATUS", status);
				oMap.put(tableName, row, "CORPORATE_CODE", commission.getCorporateCode());

				List<GnlKanalGrupKodPr> gnlKanalGrupKodPrList = session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", commission.getChannelCode())).list();
				for (GnlKanalGrupKodPr gnlKanalGrupKodPr : gnlKanalGrupKodPrList) {
					oMap.put(tableName, row, "CHANNEL_NAME", gnlKanalGrupKodPr.getAciklama());
				}
				

				oMap.put(tableName, row, "CHANNEL_CODE", commission.getChannelCode());
				GMMap xMap = new GMMap();
				GMMap yMap = new GMMap();
				xMap.put("KOD", "CDM_MASRAF_PAYLASIM_PERIOD");
				yMap = CorporationServiceUtil.getComboValues(xMap);
				for (int j = 0; j < yMap.getSize("RESULTS"); j++) {
					if (yMap.getString("RESULTS", j, "VALUE").equals(commission.getSharePeriod())) {
						oMap.put(tableName, row, "SHARE_PERIOD", yMap.getString("RESULTS", j, "NAME"));
						oMap.put(tableName, row, "SHARE_PERIOD_CODE", yMap.getString("RESULTS", j, "VALUE"));
					}
				}
				xMap = new GMMap();
				yMap = new GMMap();
				xMap.put("KOD", "CDM_MASRAF_TIPI");
				yMap = CorporationServiceUtil.getComboValues(xMap);
				for (int j = 0; j < yMap.getSize("RESULTS"); j++) {
					if (yMap.getString("RESULTS", j, "VALUE").equals(commission.getShareType())) {
						oMap.put(tableName, row, "SHARE_TYPE", yMap.getString("RESULTS", j, "NAME"));
					}
				}
				oMap.put(tableName, row, "SHARE_TYPE_CODE", commission.getShareType());
				oMap.put(tableName, row, "BANK", commission.getBank());
				oMap.put(tableName, row, "CORPORATE", commission.getCorporate());
				oMap.put(tableName, row, "CORPORATE_SHARE_ACCOUNT", commission.getCorporateShareAccount());
				oMap.put(tableName, row, "COLLECTION_CORPORATE", commission.getCollectionCorporate());
				oMap.put(tableName, row, "COLLECTION_SHARE_ACCOUNT", commission.getCollectionShareAccount());
				row++;
			}
			return oMap;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	// gets parameter for CDM_KOMISYON_ODEYEN
	@GraymoundService("CDM_COMMISSION_GET_DEFINED_CHANNELS")
	public static GMMap cdmCommissionGetDefinedChannels(GMMap iMap) {

		GMMap oMap = new GMMap();

		String tableName = "COMMISSION_SHARE_LIST";

		try {
			String is_channel_defined = "false";
			
			StringBuilder sb = new StringBuilder();
			sb.append(String.format(QueryRepository.CommisionDefinitionServicesRepository.GET_DEFINED_CHANNEL_LIST, iMap.getString("CORPORATE_CODE")));
			GMMap resultMap = new GMMap();
			logger.debug("GET_DEFINED_CHANNEL_LIST sql query-->>>  "+sb.toString());
			resultMap = DALUtil.getResults(sb.toString(), tableName);
			for (int row = 0; row < resultMap.getSize(tableName); row++) {
				GuimlUtil.wrapMyCombo(oMap, "CORPORATE_LIST", resultMap.getString(tableName, row, "KOD"),
						resultMap.getString(tableName, row, "ACIKLAMA"));
				is_channel_defined = "true";
			}
			oMap.put("IS_CHANNEL_DEFINED", is_channel_defined);
			return oMap;
		} catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_COMMISSION_CHECK_PREREQ")
	public static GMMap checkPreReq(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<CommissionDef> cd = session.createCriteria(CommissionDef.class).add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE")))
				.add(Restrictions.eq("channelCode", iMap.getString("CHANNEL_CODE"))).add(Restrictions.eq("status", true)).list();
		oMap.put("MESSAGE", "-");
		BigDecimal hundred = new BigDecimal("100");

		for (CommissionDef comDef : cd) {
			if (iMap.getString("COMMISSION_SHARE").equals("S")) {
				if (comDef.getCommission().compareTo(
						iMap.getBigDecimal("CUR_CORPARATE").add(iMap.getBigDecimal("CUR_BANKA").add(iMap.getBigDecimal("CUR_COLLECTION_CORPARATE")))) == 0) {
					oMap.put("MESSAGE", "-");
				} else {
					oMap.put("MESSAGE", "Komisyon payla��mlar� toplam komisyon tutar�ndan/oran�ndan farkl� olamaz.");
				}
			}

			if (iMap.getString("COMMISSION_SHARE").equals("O")) {
				if (hundred.compareTo(iMap.getBigDecimal("CUR_CORPARATE").add(
						iMap.getBigDecimal("CUR_BANKA").add(iMap.getBigDecimal("CUR_COLLECTION_CORPARATE")))) == 0) {
					oMap.put("MESSAGE", "-");
				} else {
					oMap.put("MESSAGE", "Sabit olmayan payla��mlar i�in toplam oran 100 den farkl� olamaz!");
				}
			}
		}
		return oMap;
	}

	// save commissions to database
	// 1. gets all records of corporate and set all of thems status 0
	// 2. create new records for corporate
	@GraymoundService("CDM_COMMISSION_SAVE_SHARE")
	public static GMMap cdmSaveCommissionShare(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		String crDate =CommonHelper.getDateString(new Date(), dateFormat);

		try {

			String tableName = "COMMISSION_SHARE_LIST";

			@SuppressWarnings("unchecked")
			List<CommissionShare> commissionShareList = session.createCriteria(CommissionShare.class)
					.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("status", true)).list();

			// set all records status 0
			for (CommissionShare commission : commissionShareList) {
				commission.setStatus(false);
				commission.setUpdateDate(crDate);
				commission.setUpdateUser(username);
				session.saveOrUpdate(commission);
			}

			// create new records
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				CommissionShare newCommisionShare = new CommissionShare();
				newCommisionShare.setStatus(true);
				newCommisionShare.setCorporateCode(iMap.getString(tableName, row, "CORPORATE_CODE"));
				newCommisionShare.setChannelCode(iMap.getString(tableName, row, "CHANNEL_CODE"));
				newCommisionShare.setShareType(iMap.getString(tableName, row, "SHARE_TYPE_CODE"));
				newCommisionShare.setBank(new BigDecimal(iMap.getString(tableName, row, "BANK")));
				newCommisionShare.setCorporate(new BigDecimal(iMap.getString(tableName, row, "CORPORATE")));
				newCommisionShare.setCollectionCorporate(new BigDecimal(iMap.getString(tableName, row, "COLLECTION_CORPORATE")));
				if (iMap.containsKey("CORPORATE_SHARE_ACCOUNT")) {
					if (iMap.getString("CORPORATE_SHARE_ACCOUNT")!=null) {
						newCommisionShare.setCorporateShareAccount(new BigDecimal(iMap.getString(tableName, row, "CORPORATE_SHARE_ACCOUNT")));
					}
				}
				if (iMap.containsKey("COLLECTION_SHARE_ACCOUNT")) {
					if (iMap.getString("COLLECTION_SHARE_ACCOUNT")!=null) {
						newCommisionShare.setCorporateShareAccount(new BigDecimal(iMap.getString(tableName, row, "COLLECTION_SHARE_ACCOUNT")));
					}
				}
				//newCommisionShare.setCorporateShareAccount(new BigDecimal(iMap.getString(tableName, row, "CORPORATE_SHARE_ACCOUNT")));
				//newCommisionShare.setCollectionShareAccount(new BigDecimal(iMap.getString(tableName, row, "COLLECTION_SHARE_ACCOUNT")));
				newCommisionShare.setSharePeriod(iMap.getString(tableName, row, "SHARE_PERIOD_CODE"));
				newCommisionShare.setCreateDate(crDate);
				newCommisionShare.setCreateUser(username);
				session.save(newCommisionShare);
			}
			oMap.put("MESSAGE", "S");
			return oMap;
		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("MESSAGE", "F");
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_LOAD_COMM_WAGE_SCALE")
	public static GMMap loadCommWageScale(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String commissionOid = input.getString("COMM_OID");
			
			Session session = CommonHelper.getHibernateSession();
			
			List<CommissionWageScale> wageScales = session.createCriteria(CommissionWageScale.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("commissionDefOid", commissionOid))
					.list();
			int counter = 0;
			for (CommissionWageScale scale : wageScales) {
				output.put("COMM_WAGE_SCALE_TABLE", counter, "OID", scale.getOid());
				output.put("COMM_WAGE_SCALE_TABLE", counter, "MIN_AMOUNT", scale.getMinAmount());
				output.put("COMM_WAGE_SCALE_TABLE", counter, "MAX_AMOUNT", scale.getMaxAmount());
				output.put("COMM_WAGE_SCALE_TABLE", counter, "COMMISSION_AMOUNT", scale.getCommissionAmount());
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_SAVE_COMM_WAGE_SCALE")
	public static GMMap saveCommWageScale(GMMap input){
		GMMap output = new GMMap();
		final String INSERT_OP = "I";
		final String UPDATE_OP = "U";
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String operation = input.getString("CURR_OPERATION");
			
			if(operation.equals(INSERT_OP)){
				CommissionWageScale scale = new CommissionWageScale();
				scale.setStatus(true);
				scale.setCommissionDefOid(input.getString("COMM_DEF_OID"));
				scale.setCommissionAmount(input.getBigDecimal("COMMISSION_AMOUNT"));
				scale.setMaxAmount(input.getBigDecimal("MAX_AMOUNT", null));
				scale.setMinAmount(input.getBigDecimal("MIN_AMOUNT"));
				
				session.save(scale);
			}
			else if(operation.equals(UPDATE_OP)){
				CommissionWageScale scale = (CommissionWageScale) session.createCriteria(CommissionWageScale.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("oid", input.getString("CURR_OID")))
						.uniqueResult();
				scale.setCommissionAmount(input.getBigDecimal("COMMISSION_AMOUNT"));
				scale.setMaxAmount(input.getBigDecimal("MAX_AMOUNT", null));
				scale.setMinAmount(input.getBigDecimal("MIN_AMOUNT"));
				
				session.update(scale);
			}
			else{
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, "Bilinmeyen operasyon : ".concat(operation));
			}
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	@GraymoundService("CDM_COMMISSION_CHECK_CHANNEL")
	public static GMMap checkChannel(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("PRE_CHECK", iMap.getString("PRE_CHECK"));
		
		for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
			if (iMap.getString("TABLE_DATA", i, "CHANNEL_CODE").equals(iMap.getString("CHANNEL"))) {
				if (iMap.getString("MODE").equals("U")
						&& (iMap.getString("TABLE_DATA", i, "CHANNEL_CODE").equals(iMap.getString("CHANNEL_CODE")))) {
				} else {
					oMap.put("PRE_CHECK", "Ayn� kanal i�in sadece bir tan�mlama yapabilirsiniz!");
					return oMap;
				}
			}
		}
		return oMap;
	}
}