package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import org.apache.axis.encoding.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.EmailConstants;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.transactions.GetCorporateDefinitionHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.AccountCollectionTypeRelTx;
import tr.com.aktifbank.bnspr.dao.AccountMatchingTreeTx;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDaysTx;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDefTx;
import tr.com.aktifbank.bnspr.dao.BalanceTransferEftEmailDef;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDefTx;
import tr.com.aktifbank.bnspr.dao.CollectionTransferRelTx;
import tr.com.aktifbank.bnspr.dao.CollectionTypeDefTx;
import tr.com.aktifbank.bnspr.dao.CorporateCityRelTx;
import tr.com.aktifbank.bnspr.dao.CorporateContactinfoTx;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.CorporateMasterTx;
import tr.com.aktifbank.bnspr.dao.CorporateSubscriberMatchTx;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMasterTx;
import tr.com.aktifbank.bnspr.dao.RetailerDefinition;
import tr.com.aktifbank.bnspr.dao.SectorDef;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDefTx;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDetailTx;
import tr.com.aktifbank.bnspr.dao.invoiceimage;
import tr.com.aktifbank.bnspr.dao.invoiceimageTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.services.transaction.ServiceExecuter;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CorporationDefinitionServices {
	private static final Log logger = LogFactory.getLog(CorporationDefinitionServices.class);
	static DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
	static DateFormat pdf = new SimpleDateFormat("yyyyMMdd");

	public static String dateFormatter(String strDate) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmm");
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmm");
		String splitedDate = "";
		String normalDate = "";
		Date date = null;
		try {
			date = format.parse(strDate);
			normalDate = sdf.format(date).toString();
			splitedDate = normalDate.substring(0, 2).concat(".").concat(normalDate.substring(2, 4)).concat(".").concat(normalDate.substring(4, 8)).concat(" ").concat(normalDate.substring(8, 10).concat(":").concat(normalDate.substring(10, 12)));
			return splitedDate;
		} catch (Exception e) {
			return strDate;
		}
	}

	public static class DayDifference {

		private static HashMap<String, Integer> dayMap = new HashMap<String, Integer>();
		private static HashMap<String, String> dayTextMap = new HashMap<String, String>();
		private static DayDifference dayDifference = null;

		public int getDifferance(String dayStart, String dayEnd) {
			if (dayMap.get(dayEnd) != null && dayMap.get(dayStart) != null)
				return dayMap.get(dayEnd) - dayMap.get(dayStart);
			else
				return 1;
		}

		public static DayDifference getInstance() {

			if (dayDifference == null) {
				loadDays();
				dayDifference = new DayDifference();
			}
			return dayDifference;
		}

		private static void loadDays() {
			dayMap.put("Pazartesi", 1);
			dayMap.put("Sal�", 2);
			dayMap.put("�ar�amba", 3);
			dayMap.put("Per�embe", 4);
			dayMap.put("Cuma", 5);
			dayMap.put("Cumartesi", 6);
			dayMap.put("Pazar", 7);
			dayTextMap.put("1", "Pazartesi");
			dayTextMap.put("2", "Sal�");
			dayTextMap.put("3", "�ar�amba");
			dayTextMap.put("4", "Per�embe");
			dayTextMap.put("5", "Cuma");
			dayTextMap.put("6", "Cumartesi");
			dayTextMap.put("7", "Pazar");
		}

		private String getDay(String day) {
			return dayMap.get(day).toString();
		}

		private Map<String, String> getDayTextMap() {
			return dayTextMap;
		}
	}

	// /////////////////////////////////////////////////////////////////////////////

	@GraymoundService("CDM_GET_CORPORATE_LIST")
	public static GMMap getCorporateList(GMMap iMap) {
		String corporateStatusIncomplete = "T";
		GMMap oMap = new GMMap();
		try {
			String isReconStr = iMap.getString("IS_RECON_SCREEN");
			StringBuilder sb = new StringBuilder();
			boolean corporateStatusIncompleteBoolean = false;
			if (StringUtils.isBlank(iMap.getString("CORPORATE_STATUS")) || !iMap.getString("CORPORATE_STATUS").equalsIgnoreCase(corporateStatusIncomplete)) {
				sb.append("SELECT oid, kurum_kodu, kurum_kisa_kodu, kurum_adi, sektor_adi, musteri_no, onay_durumu, aktif_durumu,tx_no FROM");
				sb.append(" (SELECT m.oid,m.corporate_code kurum_kodu,m.short_code kurum_kisa_kodu,m.corporate_name kurum_adi,s.sector_name sektor_adi,m.customer_number musteri_no,");
				sb.append(" DECODE(m.tx_status,'N','G�ncelleniyor','U','G�ncelleniyor','P','Onayl�',NULL) onay_durumu,");
				sb.append(" DECODE(m.corporate_activeness,'A','Aktif','P','Pasif',NULL) aktif_durumu,m.rec_date,m.tx_no");
				sb.append(" FROM cdm.corporate_master m,cdm.sector_def s,cdm.corporate_city_rel c");
				sb.append(" WHERE m.sector_code= s.sector_code AND m.oid= c.corporate_oid(+)");
				sb.append((!StringUtils.isEmpty(isReconStr) && isReconStr.equals("Y")) ? " AND m.IS_ONLINE_CORPORATE = 1" : "");
				sb.append(" AND m.corporate_activeness=").append(StringUtils.isNotBlank(iMap.getString("CORPORATE_STATUS")) ? ("'" + iMap.getString("CORPORATE_STATUS") + "'") : "m.corporate_activeness");
				sb.append(" AND m.status= 1 AND m.tx_status= 'A' AND s.status= 1 AND c.status(+)= 1 AND s.sector_activeness = 1");
				sb.append(" AND upper(m.corporate_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KODU")) ? ("'" + iMap.getString("KURUM_KODU") + "'") : null);
				sb.append(")||'%' AND upper(m.short_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KISA_KODU")) ? ("'" + iMap.getString("KURUM_KISA_KODU") + "'") : null).append(")||'%'");
				sb.append(" AND upper(m.corporate_name) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_ADI")) ? ("'" + iMap.getString("KURUM_ADI") + "'") : null);
				sb.append(")||'%' AND (m.customer_number= NVL(").append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null).append(", m.customer_number) OR ");
				sb.append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null).append(" IS NULL)");
				sb.append(" AND (m.sector_code= NVL(").append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null).append(", m.sector_code) OR ");
				sb.append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null).append(" IS NULL) AND c.is_public_corporate(+) = 0");
				if (StringUtils.isNotBlank(iMap.getString("IL"))) {
					sb.append(" AND c.kod= NVL('").append(iMap.getString("IL")).append("', c.kod)");
				}
				sb.append(" UNION");
				sb.append(" SELECT m.oid,m.corporate_code kurum_kodu,m.short_code kurum_kisa_kodu,m.corporate_name kurum_adi,s.sector_name sektor_adi,m.customer_number musteri_no,");
				sb.append(" DECODE(m.tx_status,'N','G�ncelleniyor','U','G�ncelleniyor','P','Onayl�',NULL) onay_durumu,");
				sb.append(" DECODE(m.corporate_activeness,'A','Aktif','P','Pasif',NULL) aktif_durumu,m.rec_date,m.tx_no");
				sb.append(" FROM cdm.corporate_master m,cdm.sector_def s,cdm.corporate_city_rel c");
				sb.append(" WHERE m.sector_code= s.sector_code AND m.oid= c.corporate_oid(+)");
				sb.append((!StringUtils.isEmpty(isReconStr) && isReconStr.equals("Y")) ? " AND m.IS_ONLINE_CORPORATE = 1 " : "");
				sb.append(" AND m.corporate_activeness=").append(StringUtils.isNotBlank(iMap.getString("CORPORATE_STATUS")) ? ("'" + iMap.getString("CORPORATE_STATUS") + "'") : "m.corporate_activeness");
				sb.append(" AND m.status= 1 AND m.tx_status= 'A' AND s.status= 1 AND c.status(+)= 1 AND s.sector_activeness = 1");
				sb.append(" AND upper(m.corporate_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KODU")) ? ("'" + iMap.getString("KURUM_KODU") + "'") : null);
				sb.append(")||'%' AND upper(m.short_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KISA_KODU")) ? ("'" + iMap.getString("KURUM_KISA_KODU") + "'") : null).append(")||'%'");
				sb.append(" AND upper(m.corporate_name) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_ADI")) ? ("'" + iMap.getString("KURUM_ADI") + "'") : null);
				sb.append(")||'%' AND (m.customer_number= NVL(").append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null);
				sb.append(", m.customer_number) OR ").append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null).append(" IS NULL)");
				sb.append(" AND (m.sector_code= NVL(").append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null);
				sb.append(", m.sector_code) OR ").append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null).append(" IS NULL) AND c.is_public_corporate(+) = 1");
				if (StringUtils.isNotBlank(iMap.getString("IL"))) {
					sb.append(" AND c.kod= NVL('").append(iMap.getString("IL")).append("', c.kod)");
				}
				sb.append(" ) u ORDER BY u.kurum_kisa_kodu");
				corporateStatusIncompleteBoolean = false;
			} else {
				sb.append("SELECT oid, kurum_kodu, kurum_kisa_kodu, kurum_adi, sektor_adi, musteri_no, onay_durumu, aktif_durumu,tx_no FROM");
				sb.append(" (SELECT m.oid,m.corporate_code kurum_kodu,m.short_code kurum_kisa_kodu,m.corporate_name kurum_adi,s.sector_name sektor_adi,m.customer_number musteri_no,");
				sb.append(" DECODE(m.tx_status,'N','G�ncelleniyor','U','G�ncelleniyor','P','Onayl�',NULL) onay_durumu,");
				sb.append(" DECODE(m.corporate_activeness,'A','Aktif','P','Pasif',NULL) aktif_durumu,m.rec_date,m.tx_no");
				sb.append(" FROM cdm.corporate_master_tx m,cdm.sector_def s,cdm.corporate_city_rel_tx c");
				sb.append(" WHERE m.sector_code= s.sector_code AND m.oid= c.corporate_oid(+)");
				sb.append((!StringUtils.isEmpty(isReconStr) && isReconStr.equals("Y")) ? " AND m.IS_ONLINE_CORPORATE = 1" : "");
				sb.append(" AND m.status= 1  AND s.status= 1 AND c.status(+)= 1 AND s.sector_activeness = 1");
				sb.append(" AND upper(m.corporate_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KODU")) ? ("'" + iMap.getString("KURUM_KODU") + "'") : null);
				sb.append(")||'%' AND upper(m.short_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KISA_KODU")) ? ("'" + iMap.getString("KURUM_KISA_KODU") + "'") : null).append(")||'%'");
				sb.append(" AND upper(m.corporate_name) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_ADI")) ? ("'" + iMap.getString("KURUM_ADI") + "'") : null);
				sb.append(")||'%' AND (m.customer_number= NVL(").append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null).append(", m.customer_number) OR ");
				sb.append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null).append(" IS NULL)");
				sb.append(" AND (m.sector_code= NVL(").append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null).append(", m.sector_code) OR ");
				sb.append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null).append(" IS NULL) AND c.is_public_corporate(+) = 0");
				sb.append(" AND (c.kod= NVL(").append(StringUtils.isNotBlank(iMap.getString("IL")) ? ("'" + iMap.getString("IL") + "'") : null).append(", c.kod) OR ");
				sb.append(StringUtils.isNotBlank(iMap.getString("IL")) ? ("'" + iMap.getString("IL") + "'") : null).append(" IS NULL)");
				sb.append(" UNION");
				sb.append(" SELECT m.oid,m.corporate_code kurum_kodu,m.short_code kurum_kisa_kodu,m.corporate_name kurum_adi,s.sector_name sektor_adi,m.customer_number musteri_no,");
				sb.append(" DECODE(m.tx_status,'N','G�ncelleniyor','U','G�ncelleniyor','P','Onayl�',NULL) onay_durumu,");
				sb.append(" DECODE(m.corporate_activeness,'A','Aktif','P','Pasif',NULL) aktif_durumu,m.rec_date,m.tx_no");
				sb.append(" FROM cdm.corporate_master_tx m,cdm.sector_def s,cdm.corporate_city_rel_tx c");
				sb.append(" WHERE m.sector_code= s.sector_code AND m.oid= c.corporate_oid(+)");
				sb.append((!StringUtils.isEmpty(isReconStr) && isReconStr.equals("Y")) ? " AND m.IS_ONLINE_CORPORATE = 1 " : "");
				sb.append(" AND m.status= 1 AND  s.status= 1 AND c.status(+)= 1 AND s.sector_activeness = 1");
				sb.append(" AND upper(m.corporate_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KODU")) ? ("'" + iMap.getString("KURUM_KODU") + "'") : null);
				sb.append(")||'%' AND upper(m.short_code) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_KISA_KODU")) ? ("'" + iMap.getString("KURUM_KISA_KODU") + "'") : null).append(")||'%'");
				sb.append(" AND upper(m.corporate_name) LIKE '%'||upper(").append(StringUtils.isNotBlank(iMap.getString("KURUM_ADI")) ? ("'" + iMap.getString("KURUM_ADI") + "'") : null);
				sb.append(")||'%' AND (m.customer_number= NVL(").append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null);
				sb.append(", m.customer_number) OR ").append(StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) ? ("'" + iMap.getString("MUSTERI_NO") + "'") : null).append(" IS NULL)");
				sb.append(" AND (m.sector_code= NVL(").append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null);
				sb.append(", m.sector_code) OR ").append(StringUtils.isNotBlank(iMap.getString("SEKTOR")) ? ("'" + iMap.getString("SEKTOR") + "'") : null).append(" IS NULL) AND c.is_public_corporate(+) = 1");
				sb.append(" ) u ORDER BY u.kurum_kisa_kodu");
				corporateStatusIncompleteBoolean = true;

			}
			oMap = DALUtil.getResults(sb.toString(), "CORP_LIST");
			oMap.put("CORPORATE_STATUS_INCOMPLETE", corporateStatusIncompleteBoolean);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("CDM_GET_SECTORS_COMBO_WITH_EMPTY_KEY")
	public static GMMap getSectorsCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "SECTOR_LIST";
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<SectorDef> sectorDefs = (List<SectorDef>) session.createCriteria(SectorDef.class).add(Restrictions.eq("status", true)).list();
			GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
			for (SectorDef sectorDef : sectorDefs) {
				if ("1".equals(sectorDef.getSectorActiveness())) {
					GuimlUtil.wrapMyCombo(oMap, tableName, sectorDef.getSectorCode(), sectorDef.getSectorName());
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("CDM_GET_STATUS_COMBO_WITH_EMPTY_KEY")
	public static GMMap getStatusCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			oMap.put("CORPORATE_STATUS_LIST", 0, "VALUE", "");
			oMap.put("CORPORATE_STATUS_LIST", 0, "NAME", "Hepsi");
			oMap.put("CORPORATE_STATUS_LIST", 1, "VALUE", "A");
			oMap.put("CORPORATE_STATUS_LIST", 1, "NAME", "Aktif");
			oMap.put("CORPORATE_STATUS_LIST", 2, "VALUE", "P");
			oMap.put("CORPORATE_STATUS_LIST", 2, "NAME", "Pasif");
			oMap.put("CORPORATE_STATUS_LIST", 3, "VALUE", "T");
			oMap.put("CORPORATE_STATUS_LIST", 3, "NAME", "Tamamlanmam��");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("CDM_GET_CITIES_COMBO_WITH_EMPTY_KEY")
	public static GMMap getCitiesCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "CITY_LIST";
		try {
			StringBuilder sb = new StringBuilder();
			sb.append(QueryRepository.CorporationDefinitionServicesRepository.GET_CITIES);
			oMap = DALUtil.fillComboBox(iMap, tableName, true, sb.toString());
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	private static void syncronizeTrxNoWithCorporation(CorporateMaster cDef, CorporateMasterTx cDefTx, BigDecimal txNo, Session session) {

		if (cDefTx == null && cDef != null) {
			CorporateMasterTx cDefTx1 = new CorporateMasterTx();
			cDefTx1.setCorporateActiveness(cDef.getCorporateActiveness());
			cDefTx1.setCorporateCode(cDef.getCorporateCode());
			cDefTx1.setShortCode(cDef.getShortCode());
			cDefTx1.setCorporateName(cDef.getCorporateName());
			cDefTx1.setCustomerNumber(cDef.getCustomerNumber());
			cDefTx1.setSectorCode(cDef.getSectorCode());
			cDefTx1.setProtocolStartDate(cDef.getProtocolStartDate());
			cDefTx1.setProtocolEndDate(cDef.getProtocolEndDate());
			cDefTx1.setAllowAfterDueDate(cDef.isAllowAfterDueDate());
			cDefTx1.setCountAfterDue(cDef.getCountAfterDue());
			cDefTx1.setCountTypeAfterDue(cDef.getCountTypeAfterDue());
			cDefTx1.setAllowPartAfterDue(cDef.getAllowPartAfterDue());
			cDefTx1.setIsOnlineCorporate(cDef.getIsOnlineCorporate());
			cDefTx1.setEodFlag(cDef.getEodFlag());
			cDefTx1.setAllowPartPayment(cDef.isAllowPartPayment());
			cDefTx1.setIfDueDateHoliday(cDef.getIfDueDateHoliday());
			cDefTx1.setCorporateBankCode(cDef.getCorporateBankCode());
			cDefTx1.setCreateUser(cDef.getCreateUser());
			cDefTx1.setCreateDate(cDef.getCreateDate());
			cDefTx1.setCorporateOid(cDef.getOid());
			cDefTx1.setStatus(true);
			cDefTx1.setTxStatus("N");
			cDefTx1.setTxNo(txNo);
			session.saveOrUpdate(cDefTx1);
			session.flush();
		}
	}

	@GraymoundService("CDM_CORPORATE_CHECK_INCOMPLETE")
	public static GMMap checkHaveCoprorateInComplete(GMMap iMap) {

		GMMap oMap = new GMMap();
		CorporateMasterTx cDefTx = null;
		oMap.put("OPERATION", false);
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String oId = iMap.getString("CORPORATE_OID");
			cDefTx = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateOid", oId)).add(Restrictions.eq("status", true)).add(Restrictions.isNull("txStatus")).uniqueResult();
			if (cDefTx != null && StringUtils.isNotBlank(cDefTx.getCorporateCode()) && StringUtils.isNotBlank(String.valueOf(cDefTx.getCustomerNumber()))) {
				oMap.put("OPERATION", true);
				oMap.put("MESSAGE", "Se�ti�iniz kurum i�in tamamlanmam�� kay�t bulunmaktad�r.Tekrar 'Kurum arama' dan arama yaparak tamamlanmam�� kay�tdan devam edebilirsiniz. �uan yapt���n�z arama kriterleri ile devam etmek istiyormusunuz?");
			} else {
				oMap.put("TRX_NO", iMap.getString("TRX_NO"));
				oMap.put("CORPORATE_OID", iMap.getString("CORPORATE_OID"));

			}
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("CDM_CORPORATE_TRX_SEND_TRANSACTION")
	public static GMMap sendTransaction(GMMap iMap) {

		GMMap oMap = new GMMap();
		CorporateMasterTx cDefTx = null;
		CorporateMaster cDef = null;

		try {
			oMap.put("OPERATION", true);
			oMap = validationMustCorporate(iMap);
			if (oMap.getBoolean("OPERATION")) {
				oMap = validationCorporate(iMap, true);
				if (oMap.getBoolean("OPERATION")) {

					Session session = DAOSession.getSession("BNSPRDal");
					String oId = iMap.getString("CORPORATE_OID");
					BigDecimal txNo = new BigDecimal(StringUtils.isBlank(iMap.getString("TRX_NO")) ? CommonHelper.getNewTransactionNo() : iMap.getString("TRX_NO"));
					if (StringUtils.isNotBlank(oId)) {

						cDefTx = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateOid", oId)).add(Restrictions.eq("status", true)).uniqueResult();

						cDef = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("oid", oId)).add(Restrictions.eq("status", true)).uniqueResult();

						syncronizeTrxNoWithCorporation(cDef, cDefTx, txNo, session);
						session.flush();
						if (cDefTx != null) {
							cDefTx.setTxNo(txNo);
							cDefTx.setTxStatus("N");
							session.update(cDefTx);
						}

						session.flush();

						try {
							Object userID = CommonHelper.getCurrentUser();
							CommonHelper.sendMail(Arrays.asList(CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_CORP_AFTER_APPROVAL").split(",")), null, EmailConstants.FROM, true, "Kurum Tan�m� & G�ncelleme", String.format(
									"<html><head></head><body>Merhaba<br /><br/>Yeni kurum tan�m� & g�ncellemesi onaya g�nderilmi�tir.<br/><br/>" + "<b>Kurum Ad� :</b> %s<br/>" + "<b>Kurum Kodu :</b> %s<br/>"
											+ "<b>Kurum Id :</b> %s<br><br><b>De�i�ikli�i Yapan Kullan�c� : </b> %s <br><br>��lem referans� : %s</body></html>", cDef.getShortCode(), cDef.getCorporateCode(), cDef.getOid().concat("|~|KFT_CORPORATE_OID"), userID, txNo.toString()));
						} catch (Exception e) {
							logger.error("Mail g�nderilirken hata meydana geldi...");
							logger.error(e.toString());
						}
					}

					iMap.put("TRX_NAME", "7001");
					iMap.put("TRX_NO", txNo);
					oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
					session.flush();
					oMap.put("OPERATION", true);
				}
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	private static void updateTempInfoStatusZero(GMMap iMap, Session session, String corporateOid) {

		try {
			List<BalanceTransferDefTx> balanceTransferDefTxList = session.createCriteria(BalanceTransferDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (BalanceTransferDefTx balanceTransferDefTx : balanceTransferDefTxList) {
				List<CollectionTransferRelTx> collectionTransferRelTxList = session.createCriteria(CollectionTransferRelTx.class).add(Restrictions.eq("transferParamOid", balanceTransferDefTx.getOid())).list();
				for (CollectionTransferRelTx collectionTransferRelTx : collectionTransferRelTxList) {
					collectionTransferRelTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
					session.saveOrUpdate(collectionTransferRelTx);
				}
				List<BalanceTransferDaysTx> balanceTransferDaysTxList = session.createCriteria(BalanceTransferDaysTx.class).add(Restrictions.eq("balanceTransferOid", balanceTransferDefTx.getOid())).add(Restrictions.eq("status", true)).list();
				for (BalanceTransferDaysTx balanceTransferDaysTx : balanceTransferDaysTxList) {
					balanceTransferDaysTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
					session.saveOrUpdate(balanceTransferDaysTx);
				}
				balanceTransferDefTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(balanceTransferDefTx);
			}

			List<CorporationAccountMasterTx> corporationAccountMasterTxList = session.createCriteria(CorporationAccountMasterTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (CorporationAccountMasterTx corporationAccountMasterTx : corporationAccountMasterTxList) {
				List<AccountCollectionTypeRelTx> accountCollectionTypeRelTxList = session.createCriteria(AccountCollectionTypeRelTx.class).add(Restrictions.eq("accountMasterOid", corporationAccountMasterTx.getOid())).list();
				for (AccountCollectionTypeRelTx accountCollectionTypeRelTx : accountCollectionTypeRelTxList) {
					accountCollectionTypeRelTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
					session.saveOrUpdate(accountCollectionTypeRelTx);
				}
				corporationAccountMasterTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(corporationAccountMasterTx);
			}

			List<ChannelSourceDefTx> channelSourceDefTxList = session.createCriteria(ChannelSourceDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (ChannelSourceDefTx channelSourceDefTx : channelSourceDefTxList) {
				channelSourceDefTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(channelSourceDefTx);
			}
			List<CollectionTypeDefTx> collectionTypeDefTxs = session.createCriteria(CollectionTypeDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (CollectionTypeDefTx collectionTypeDefTx : collectionTypeDefTxs) {
				collectionTypeDefTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(collectionTypeDefTx);
			}
			List<CorporateCityRelTx> corporateCityRelTxList = session.createCriteria(CorporateCityRelTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (CorporateCityRelTx corporateCityRelTx : corporateCityRelTxList) {
				corporateCityRelTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(corporateCityRelTx);
			}
			List<CorporateContactinfoTx> corporateContactinfoTxList = session.createCriteria(CorporateContactinfoTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (CorporateContactinfoTx corporateContactinfoTx : corporateContactinfoTxList) {
				corporateContactinfoTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(corporateContactinfoTx);
			}
			List<CorporateSubscriberMatchTx> corporateSubscriberMatchTxList = session.createCriteria(CorporateSubscriberMatchTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (CorporateSubscriberMatchTx corporateSubscriberMatchTx : corporateSubscriberMatchTxList) {
				corporateSubscriberMatchTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(corporateSubscriberMatchTx);
			}

			List<SubscriberMaskDefTx> subscriberMaskDefTxList = session.createCriteria(SubscriberMaskDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			for (SubscriberMaskDefTx subscriberMaskDefTx : subscriberMaskDefTxList) {
				List<SubscriberMaskDetailTx> subscriberMaskDetailTxList = session.createCriteria(SubscriberMaskDetailTx.class).add(Restrictions.eq("maskOid", subscriberMaskDefTx.getOid())).list();
				for (SubscriberMaskDetailTx subscriberMaskDetailTx : subscriberMaskDetailTxList) {
					List<invoiceimageTx> invoiceimageTxList = session.createCriteria(invoiceimageTx.class).add(Restrictions.eq("maskOid", subscriberMaskDetailTx.getOid())).list();
					for (invoiceimageTx invoiceimage : invoiceimageTxList) {
						invoiceimage.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
						session.saveOrUpdate(invoiceimage);
					}
					subscriberMaskDetailTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
					session.saveOrUpdate(subscriberMaskDetailTx);
				}
				subscriberMaskDefTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
				session.saveOrUpdate(subscriberMaskDefTx);
			}
			// List<AccountMatchingTreeTx> accountMatchingTreeTxList = session.createCriteria(AccountMatchingTreeTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
			// for (AccountMatchingTreeTx accountMatchingTreeTx : accountMatchingTreeTxList) {
			// accountMatchingTreeTx.setStatus(iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"));
			// session.saveOrUpdate(accountMatchingTreeTx);
			// }
			session.flush();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static CorporateMasterTx getCorporateWithTxNo(BigDecimal txNo) {

		CorporateMasterTx corporate = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			corporate = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("txNo", txNo)).uniqueResult();

		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return corporate;

	}

	@GraymoundService("CDM_SEARCH_CORPORATE_LISTS")
	public static GMMap getSearchCorporateLists(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String type = "_tx";
			boolean inComplete = iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE");
			if (!iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE")) {
				if (!"MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION"))) {
					type = "";
				} else {
					CorporateMasterTx corporate = getCorporateWithTxNo(new BigDecimal(iMap.getString("TX_NO")));
					if (corporate == null) {
						oMap.put("MESSAGE", "�lgili transaction numaras�na ait kay�t bulunamad�");
						oMap.put("OPERATION", false);
					} else {
						iMap.put("CORPORATE_OID", corporate.getCorporateOid());
					}
				}
			}
			getCorporateInfo(iMap, oMap, type);
			if (iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE") || "NEW_APPROVE".equalsIgnoreCase(oMap.getString("ACTION_NEW"))) {
				iMap.put("CORPORATE_OID", oMap.getString("CORPORATE_OID"));
			}
			iMap.put("SECTOR_VALUE", getSectorName(oMap.getString("SECTOR_NAME")));
			getCorporateSelectCities(iMap, oMap, type, inComplete);
			getSubscriberLists(iMap, oMap, type);
			getContactLists(iMap, oMap, type);
			getChannelSourceLists(iMap, oMap, type);
			GMMap inMap = new GMMap();
			inMap.put("SUBSCRIBER_LIST", oMap.get("SUBSCRIBER_LIST"));
			inMap.put("CHANNEL_SOURCE_LIST", oMap.get("CHANNEL_SOURCE_LIST"));
			getAcoountSubscriberAndSourceChannel(inMap, oMap);
			// getAccountSubscriberMatchList()
			getAccountLists(iMap, oMap, type);
			getSourceAccountList(oMap);
			String sourceAccountNoId = null;
			if (oMap.getSize("ACCOUNT_LIST") > 0)
				sourceAccountNoId = oMap.getString("ACCOUNT_SOURCES", 0, "VALUE");
			getTransfusionAccountList(oMap);
			getAccountCollectionTypeChannelSourceList(oMap, sourceAccountNoId);
			getAccountTransferLists(iMap, oMap, type);
			// iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE") ||

			if ("MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION"))) {
				CorporationColoring.getCorporateInfoColoring(iMap, oMap);
				CorporationColoring.getCorporateSelectCityColoring(iMap, oMap);
				CorporationColoring.getSubscriberListColoring(iMap, oMap);
				CorporationColoring.getContactListColoring(iMap, oMap);
				CorporationColoring.getChannelSourceListColoring(iMap, oMap);
				CorporationColoring.getAccountListColoring(iMap, oMap);
				CorporationColoring.getAccountTransferListColoring(iMap, oMap);
			} else {
				CorporationColoring.getCorporateDefaultColoring(iMap, oMap);
			}
			GMMap checkApproveIMap = new GMMap();
			checkApproveIMap.put("CORPORATE_CODE", oMap.getString("CORPORATE_CODE"));
			GMMap checkApproveOMap = GMServiceExecuter.call("CDM_CHECK_IF_ANY_UPDATE", checkApproveIMap);
			oMap.put("WAITING_ON_APPROVAL", checkApproveOMap.getString("WAITING_ON_APPROVAL"));
			oMap.put("CORPORATE_OID", iMap.getString("CORPORATE_OID"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getSourceAccountList(GMMap oMap) {
		try {
			int row = -1;
			for (int j = 0; j < oMap.getSize("ACCOUNT_LIST"); j++) {
				if (!DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE"))) {
					row++;
					oMap.put("ACCOUNT_SOURCES", row, "VALUE", oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE") + "-" + oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_NUMBER"));
					oMap.put("ACCOUNT_SOURCES", row, "NAME", oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_NAME") + "-" + oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_NUMBER"));
				}
			}
			return oMap;
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
	}

	public static GMMap getTransfusionAccountList(GMMap oMap) {
		try {
			int row = -1;
			for (int j = 0; j < oMap.getSize("ACCOUNT_LIST"); j++) {
				if (!DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE"))) {
					row++;
					String accountNumber = "-" + (!DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE")) ? oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_NUMBER") : oMap.getString("ACCOUNT_LIST", j, "IBAN"));
					oMap.put("ACCOUNT_TRANSFUSION", row, "VALUE", oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE") + accountNumber);
					oMap.put("ACCOUNT_TRANSFUSION", row, "NAME", oMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_NAME") + accountNumber);
				}
			}
			return oMap;
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
	}

	public static GMMap getAccountCollectionTypeChannelSourceList(GMMap iMap, String sourceAccountNoId) {
		try {
			GMMap tempMap = new GMMap();
			// tempMap.put("ACCOUNT_LIST", iMap.get("ACCOUNT_LIST"));
			List<String> accountCollectionType = new ArrayList<String>();
			List<String> accountChannelSource = new ArrayList<String>();
			List<String> accountCollectionTypeName = new ArrayList<String>();
			List<String> accountChannelSourceName = new ArrayList<String>();
			List<String> accountReferanceTree = new ArrayList<String>();
			System.out.println(iMap);
			if (sourceAccountNoId != null) {

				for (int j = 0; j < iMap.getSize("ACCOUNT_LIST"); j++) {
					String[] sourceAccountNoIdArr = sourceAccountNoId.split("-");
					if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE")) && iMap.getString("ACCOUNT_LIST", j, "ACCOUNT_NUMBER").equalsIgnoreCase(sourceAccountNoIdArr[1])) {
						accountCollectionType.addAll(Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "COLLECTION_TYPE").split(",")));
						accountCollectionTypeName.addAll(Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "COLLECTION_NAME").split(",")));
						accountChannelSource.addAll(Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "CHANNEL_SOURCE_CODE").split(",")));
						accountChannelSourceName.addAll(Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "CHANNEL_SOURCE_NAME").split(",")));
						if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_LIST", j, "TREE_LIST")))
							accountReferanceTree.addAll(Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "TREE_LIST").split(",")));
					}
				}
				Map<String, String> accountCollectionTypeMap = new HashMap<String, String>();
				for (int i = 0; i < accountCollectionType.size(); i++) {
					accountCollectionTypeMap.put(accountCollectionType.get(i), accountCollectionType.get(i));
				}
				List<String> accountCollectionTypeList = new ArrayList<String>(accountCollectionTypeMap.values());

				Map<String, String> accountChannelSourceMap = new HashMap<String, String>();
				for (int i = 0; i < accountChannelSource.size(); i++) {
					accountChannelSourceMap.put(accountChannelSource.get(i), accountChannelSource.get(i));
				}
				List<String> accountChannelSourceList = new ArrayList<String>(accountChannelSourceMap.values());

				int i = -1;
				for (int j = 0; j < accountCollectionTypeList.size(); j++) {
					String collectionType = accountCollectionTypeList.get(j);
					String collectionTypeName = accountCollectionTypeName.get(j);
					for (int k = 0; k < accountChannelSourceList.size(); k++) {
						String channelSource = accountChannelSourceList.get(k);
						String[] channelSourcesArray = StringUtils.split(channelSource, "<->");
						if (accountReferanceTree.size() > 0) {
							for (int r = 0; r < accountReferanceTree.size(); r++) {
								i++;
								tempMap.put("ACCOUNT_RESOURCES", i, "COLLECTION_NAME", collectionTypeName);
								tempMap.put("ACCOUNT_RESOURCES", i, "COLLECTION_TYPE", collectionType);
								tempMap.put("ACCOUNT_RESOURCES", i, "CHANNEL_CODE", channelSourcesArray[1]);
								tempMap.put("ACCOUNT_RESOURCES", i, "SOURCE_CODE", channelSourcesArray[0]);
								tempMap.put("ACCOUNT_RESOURCES", i, "CHANNEL_NAME", getChannelName(channelSourcesArray[1], iMap));
								tempMap.put("ACCOUNT_RESOURCES", i, "SOURCE_NAME", getSourceName(channelSourcesArray[0], iMap));
								tempMap.put("ACCOUNT_RESOURCES", i, "ACCOUNT_COLLECTION_OID", accountReferanceTree.get(r));
							}
						} else {
							i++;
							tempMap.put("ACCOUNT_RESOURCES", i, "COLLECTION_NAME", collectionTypeName);
							tempMap.put("ACCOUNT_RESOURCES", i, "COLLECTION_TYPE", collectionType);
							tempMap.put("ACCOUNT_RESOURCES", i, "CHANNEL_CODE", channelSourcesArray[1]);
							tempMap.put("ACCOUNT_RESOURCES", i, "SOURCE_CODE", channelSourcesArray[0]);
							tempMap.put("ACCOUNT_RESOURCES", i, "CHANNEL_NAME", getChannelName(channelSourcesArray[1], iMap));
							tempMap.put("ACCOUNT_RESOURCES", i, "SOURCE_NAME", getSourceName(channelSourcesArray[0], iMap));
							tempMap.put("ACCOUNT_RESOURCES", i, "ACCOUNT_COLLECTION_OID", "null");
						}
					}
				}
			}
			return tempMap;
		} catch (Exception ex) {
			iMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
	}

	private static String getChannelName(String channelCode, GMMap iMap) {
		String channelName = "";
		for (int j = 0; j < iMap.getSize("CHANNELS"); j++) {
			if (channelCode.equalsIgnoreCase(iMap.getString("CHANNELS", j, "CHANNEL_CODE"))) {
				channelName = iMap.getString("CHANNELS", j, "CHANNEL_NAME");
				break;
			}
		}
		return channelName;
	}

	private static String getSourceName(String channelCode, GMMap iMap) {
		String channelName = "";
		for (int j = 0; j < iMap.getSize("SOURCES"); j++) {
			if (channelCode.equalsIgnoreCase(iMap.getString("SOURCES", j, "SOURCE_CODE"))) {
				channelName = iMap.getString("SOURCES", j, "SOURCE_NAME");
				break;
			}
		}
		return channelName;
	}

	public static <T> GMMap getCorporateInfo(GMMap iMap, GMMap oMap, String type) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if (!iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE") && !"MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION"))) {
				CorporateMaster corporate = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("oid", iMap.getString("CORPORATE_OID"))).add(Restrictions.eq("status", true)).uniqueResult();
				oMap.put("CORPORATE_NAME", corporate.getCorporateName());
				oMap.put("CORPORATE_CODE", corporate.getCorporateCode());
				oMap.put("CORPORATE_ACTIVENESS", "A".equals(corporate.getCorporateActiveness()) ? true : false);
				oMap.put("CORPORATE_BANK_CODE", corporate.getCorporateBankCode());
				oMap.put("CUSTOMER_NUMBER", corporate.getCustomerNumber());
				if (StringUtils.isNotBlank(corporate.getProtocolEndDate())) {
					oMap.put("PROTOCOL_END_DATE", pdf.parse(corporate.getProtocolEndDate()));
				}
				if (StringUtils.isNotBlank(corporate.getProtocolStartDate())) {
					oMap.put("PROTOCOL_START_DATE", pdf.parse(corporate.getProtocolStartDate()));
				}
				if (StringUtils.isNotBlank(corporate.getSectorCode())) {
					oMap.put("SECTOR_NAME", corporate.getSectorCode());
				} else {
					oMap.put("SECTOR_NAME", "");
				}
				oMap.put("SHORT_CODE", corporate.getShortCode());
				oMap.put("SHORT_CODE_CHECK", corporate.getShortCode());

				oMap.put("COUNT_AFTER_DUE", corporate.getCountAfterDue());
				if (StringUtils.isNotBlank(corporate.getCountTypeAfterDue())) {
					oMap.put("COUNT_TYPE_AFTER_DUE", corporate.getCountTypeAfterDue());
				} else {
					oMap.put("COUNT_TYPE_AFTER_DUE", "");
				}
				oMap.put("ALLOW_AFTER_PAYMEND", corporate.getAllowPartAfterDue());
				oMap.put("ALLOW_END_PAYMEND", corporate.isAllowAfterDueDate());
				oMap.put("ALLOW_BEFORE_PAYMEND", corporate.isAllowPartPayment());
				if (StringUtils.isNotBlank(corporate.getIfDueDateHoliday())) {
					oMap.put("IF_DUE_DATE_HOLIDAY", corporate.getIfDueDateHoliday());
				} else {
					oMap.put("IF_DUE_DATE_HOLIDAY", "");
				}
				oMap.put("IS_ONLINE_CORPORATE", "1".equals(corporate.getIsOnlineCorporate()) ? true : false);
				oMap.put("IS_EOD_FLAG", "1".equals(corporate.getEodFlag()) ? true : false);
				oMap.put("CORPORATE_OID", corporate.getOid());
				oMap.put("CORPORATE_BUSINESS_CODE", corporate.getCorporateBusinessCode());
				oMap.put("OPERATION", true);
			} else {
				CorporateMasterTx corporate = null;
				if (iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE")) {
					corporate = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("oid", iMap.getString("CORPORATE_OID"))).add(Restrictions.eq("status", true)).uniqueResult();
				} else {
					corporate = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateOid", iMap.getString("CORPORATE_OID"))).add(Restrictions.eq("status", true)).uniqueResult();

				}
				if (corporate == null) {
					corporate = getCorporateWithTxNo(new BigDecimal(iMap.getString("TX_NO")));
					oMap.put("CORPORATE_OID", corporate.getOid());
					oMap.put("ACTION_NEW", "NEW_APPROVE");
				} else {
					oMap.put("CORPORATE_OID", corporate.getCorporateOid());
				}
				oMap.put("CORPORATE_NAME", corporate.getCorporateName());
				oMap.put("CORPORATE_CODE", corporate.getCorporateCode());
				oMap.put("CORPORATE_ACTIVENESS", "A".equals(corporate.getCorporateActiveness()) ? true : false);
				oMap.put("CORPORATE_BANK_CODE", corporate.getCorporateBankCode());
				oMap.put("CUSTOMER_NUMBER", corporate.getCustomerNumber());
				if (StringUtils.isNotBlank(corporate.getProtocolEndDate())) {
					oMap.put("PROTOCOL_END_DATE", pdf.parse(corporate.getProtocolEndDate()));
				}
				if (StringUtils.isNotBlank(corporate.getProtocolStartDate())) {
					oMap.put("PROTOCOL_START_DATE", pdf.parse(corporate.getProtocolStartDate()));
				}
				if (StringUtils.isNotBlank(corporate.getSectorCode())) {
					oMap.put("SECTOR_NAME", corporate.getSectorCode());
				} else {
					oMap.put("SECTOR_NAME", "");
				}
				oMap.put("SHORT_CODE", corporate.getShortCode());
				oMap.put("SHORT_CODE_CHECK", corporate.getShortCode());

				oMap.put("COUNT_AFTER_DUE", corporate.getCountAfterDue());
				if (StringUtils.isNotBlank(corporate.getCountTypeAfterDue())) {
					oMap.put("COUNT_TYPE_AFTER_DUE", corporate.getCountTypeAfterDue());
				} else {
					oMap.put("COUNT_TYPE_AFTER_DUE", "");
				}
				oMap.put("ALLOW_AFTER_PAYMEND", corporate.getAllowPartAfterDue());
				oMap.put("ALLOW_END_PAYMEND", corporate.isAllowAfterDueDate());
				oMap.put("ALLOW_BEFORE_PAYMEND", corporate.isAllowPartPayment());
				if (StringUtils.isNotBlank(corporate.getIfDueDateHoliday())) {
					oMap.put("IF_DUE_DATE_HOLIDAY", corporate.getIfDueDateHoliday());
				} else {
					oMap.put("IF_DUE_DATE_HOLIDAY", "");
				}
				oMap.put("CORPORATE_BUSINESS_CODE", corporate.getCorporateBusinessCode());
				oMap.put("IS_ONLINE_CORPORATE", "1".equals(corporate.getIsOnlineCorporate()) ? true : false);
				oMap.put("IS_EOD_FLAG", "1".equals(corporate.getEodFlag()) ? true : false);
				oMap.put("OPERATION", true);
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;

	}
	
	public static String getSectorName(String sector_code) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SectorDef sectorDef = (SectorDef) session.createCriteria(SectorDef.class).add(Restrictions.eq("sectorCode", sector_code)).add(Restrictions.eq("status", true)).uniqueResult();
			return sectorDef.getSectorName();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getCorporateSelectCities(GMMap iMap, GMMap oMap, String type, boolean inComplete) {
		GMMap returnMap2 = new GMMap();
		GMMap returnMap1 = new GMMap();
		try {
			StringBuilder sb = new StringBuilder();
			if (StringUtils.isBlank(type)) {
				// sb.append("SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel c WHERE c.status= 1");
				// sb.append(" AND c.corporate_oid ='").append(iMap.getString("CORPORATE_OID")).append("'");
				// sb.append(" AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI").append(" FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI");
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CORPORATE_CITIES, iMap.getString("CORPORATE_OID")));
				returnMap1 = DALUtil.getResults(sb.toString(), "CORPORATE_CITIES");
				sb = new StringBuilder();
				// sb.append("SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel c WHERE c.status= 1");
				// sb.append(" AND c.corporate_oid ='").append(iMap.getString("CORPORATE_OID")).append("'");
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CORPORATE_CITIES_DIST, iMap.getString("CORPORATE_OID")));
			} else {
				// sb.append("SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel_tx c WHERE c.status= 1");
				// sb.append(" AND c.corporate_oid ='").append(iMap.getString("CORPORATE_OID")).append("'");
				// sb.append(" AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI").append(" FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI");
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CORPORATE_CITIES_ELSE_TX, iMap.getString("TX_NO")));
				returnMap1 = DALUtil.getResults(sb.toString(), "CORPORATE_CITIES");
				sb = new StringBuilder();
				// sb.append("SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel_tx c WHERE c.status= 1");
				// sb.append(" AND c.corporate_oid ='").append(iMap.getString("CORPORATE_OID")).append("'");
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CORPORATE_CITIES_DIST_ELSE_TX, iMap.getString("TX_NO")));
			}
			returnMap2 = DALUtil.getResults(sb.toString(), "IS_PUBLIC_CORPORATE");
			oMap.put("CORPORATE_CITIES", returnMap1.get("CORPORATE_CITIES"));
			oMap.put("IS_PUBLIC_CORPORATE", returnMap2.getBoolean("IS_PUBLIC_CORPORATE", 0, "IS_PUBLIC_CORPORATE"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getChannelSourceLists(GMMap iMap, GMMap oMap, String type) {
		try {
			GMMap resultMap = new GMMap();
			StringBuilder sb = new StringBuilder();
			if(StringUtil.isEmpty(type)){
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CHANNEL_SOURCE_LIST, type,iMap.getString("CORPORATE_OID"),type,iMap.getString("CORPORATE_OID")
						,type,iMap.getString("CORPORATE_OID"),type,iMap.getString("CORPORATE_OID"),type,iMap.getString("CORPORATE_OID")));
			}
			else{
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CHANNEL_SOURCE_LIST_TX, iMap.getString("TX_NO"),iMap.getString("TX_NO")
						,iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO")));
			}
			

			resultMap = DALUtil.getResults(sb.toString(), "CHANNEL_SOURCE_LIST");
			for (int j = 0; j < resultMap.getSize("CHANNEL_SOURCE_LIST"); j++) {
				try {
					if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "HOLIDAY_END_TIME") != null) {
						if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "HOLIDAY_END_TIME").length() == 4) {
							String holidayEndTime = resultMap.getString("CHANNEL_SOURCE_LIST", j, "HOLIDAY_END_TIME");
							resultMap.put("CHANNEL_SOURCE_LIST", j, "HOLIDAY_END_TIME", holidayEndTime.substring(0, 2).concat(":").concat(holidayEndTime.substring(2, 4)));
						}
					}
				} catch (Exception e) {
				}
				try {
					if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_END_TIME") != null) {
						if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_END_TIME").length() == 4) {
							String holidayEndTime = resultMap.getString("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_END_TIME");
							resultMap.put("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_END_TIME", holidayEndTime.substring(0, 2).concat(":").concat(holidayEndTime.substring(2, 4)));
						}
					}
				} catch (Exception e) {
				}
				try {
					if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_START_TIME") != null) {
						if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_START_TIME").length() == 4) {
							String holidayEndTime = resultMap.getString("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_START_TIME");
							resultMap.put("CHANNEL_SOURCE_LIST", j, "WORKINGDAY_START_TIME", holidayEndTime.substring(0, 2).concat(":").concat(holidayEndTime.substring(2, 4)));
						}
					}
				} catch (Exception e) {
				}
				try {
					if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "HOLIDAY_START_TIME") != null) {
						if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "HOLIDAY_START_TIME").length() == 4) {
							String holidayEndTime = resultMap.getString("CHANNEL_SOURCE_LIST", j, "HOLIDAY_START_TIME");
							resultMap.put("CHANNEL_SOURCE_LIST", j, "HOLIDAY_START_TIME", holidayEndTime.substring(0, 2).concat(":").concat(holidayEndTime.substring(2, 4)));
						}
					}
				} catch (Exception e) {
				}
				try {
					if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE_START") != null) {
						resultMap.put("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE_START", dateFormatter(resultMap.getString("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE_START")));
						resultMap.put("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE", 1);
					} else {
						resultMap.put("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE", 0);
					}
				} catch (Exception e) {
				}
				try {
					if (resultMap.getString("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE_END") != null) {
						resultMap.put("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE_END", dateFormatter(resultMap.getString("CHANNEL_SOURCE_LIST", j, "CLOSED_DATE_END")));
					}
				} catch (Exception e) {
				}
			}
			oMap.put("CHANNEL_SOURCE_LIST", resultMap.get("CHANNEL_SOURCE_LIST"));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getAcoountSubscriberAndSourceChannel(GMMap iMap, GMMap oMap) {
		try {
			Map<String, String> collectionType = new HashMap<String, String>();
			for (int j = 0; j < iMap.getSize("SUBSCRIBER_LIST"); j++) {
				String[] collectionNameArr=iMap.getString("SUBSCRIBER_LIST", j, "COLLECTION_NAME").split(",");
				String[] collectionTypeArr=iMap.getString("SUBSCRIBER_LIST", j, "COLLECTION_TYPE").split(",");
				for (int i = 0; i < collectionTypeArr.length; i++) {
					collectionType.put(collectionNameArr[i], collectionTypeArr[i]);
					oMap.put("ACCOUNT_COLLECTION_TYPES", i, "COLLECTION_NAME", collectionNameArr[i]);
					oMap.put("ACCOUNT_COLLECTION_TYPES", i, "COLLECTION_TYPE", collectionTypeArr[i]);
				}
			}
			int i = -1;
			Iterator<String> iterCollectionType = collectionType.keySet().iterator();
			while (iterCollectionType.hasNext()) {
				i++;
				String keyCollectionType = (String) iterCollectionType.next();
				String valCollectionType = (String) collectionType.get(keyCollectionType);
				oMap.put("ACCOUNT_COLLECTION_TYPES", i, "COLLECTION_NAME", keyCollectionType);
				oMap.put("ACCOUNT_COLLECTION_TYPES", i, "COLLECTION_TYPE", valCollectionType);
			}

			i = -1;
			for (int j = 0; j < iMap.getSize("CHANNEL_SOURCE_LIST"); j++) {
				Map<String, String> channel = putMap(Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", j, "CHANNEL_CODE").split(",")), Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", j, "CHANNEL_NAME").split(",")));
				Map<String, String> sources = putMap(Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", j, "SOURCE_CODE").split(",")), Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", j, "SOURCE_NAME").split(",")));
				Iterator<String> iterSources = sources.keySet().iterator();
				while (iterSources.hasNext()) {
					String keySource = (String) iterSources.next();
					String valSource = (String) sources.get(keySource);
					Iterator<String> iterChannel = channel.keySet().iterator();
					while (iterChannel.hasNext()) {
						i++;
						String keyChannel = (String) iterChannel.next();
						String valChannel = (String) channel.get(keyChannel);
						oMap.put("ACCOUNT_CHANNELS_SOURCES", i, "CHANNEL_CODE", keyChannel);
						oMap.put("ACCOUNT_CHANNELS_SOURCES", i, "CHANNEL_NAME", valChannel);
						oMap.put("ACCOUNT_CHANNELS_SOURCES", i, "SOURCE_CODE", keySource);
						oMap.put("ACCOUNT_CHANNELS_SOURCES", i, "SOURCE_NAME", valSource);
					}
				}
			}

			return oMap;
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
	}

	private static Map<String, String> putMap(List<String> list, List<String> list2) {
		Map<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < list.size(); i++) {
			map.put(list.get(i), list2.get(i));
		}
		return map;
	}

	public static GMMap getSubscriberLists(GMMap iMap, GMMap oMap, String type) {
		try {
			boolean taxType=false;
			if(iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("V_GENERAL_TAX_SECTOR_VALUE"))){
				taxType=true;
			}
			
			StringBuilder sb = new StringBuilder();
			sb.append("select distinct ");
			if(taxType){
				if(StringUtil.isEmpty(type)){
					sb.append(String.format(" (select listagg(p.tax_type_code||' - '||p.tax_type_name,',') within group(order by p.tax_type_code asc) "
					+" FROM cdm.tax_type_collection_type p,cdm.collection_type_def td where td.collection_type=p.collection_type and td.corporate_oid ='%s' and td.status=1 ) " +
					"as collection_name,"
					+" (select listagg(p.collection_type,',') within group(order by p.collection_type asc) "
					+" FROM cdm.tax_type_collection_type p,cdm.collection_type_def td where  td.collection_type=p.collection_type and td.corporate_oid ='%s' and td.status=1 ) " +
					"as collection_type,", iMap.getString("CORPORATE_OID"), iMap.getString("CORPORATE_OID")));
				}
				else{
					sb.append(String.format(" (select listagg(p.tax_type_code||' - '||p.tax_type_name,',') within group(order by p.tax_type_code asc) "
					+" FROM cdm.tax_type_collection_type p,cdm.collection_type_def_tx td where  td.collection_type=p.collection_type and td.tx_no=%s) " +
					"as collection_name,"
					+" (select listagg(p.collection_type,',') within group(order by p.collection_type asc) "
					+" FROM cdm.tax_type_collection_type p,cdm.collection_type_def_tx td where  td.collection_type=p.collection_type and td.tx_no=%s ) " +
					"as collection_type,", iMap.getString("TX_NO"), iMap.getString("TX_NO")));
				}
			}else{
				sb.append(QueryRepository.CorporationDefinitionServicesRepository.SUBSCRIBER_LIST_TAX_TYPE_ELSE);
			}
			if(StringUtil.isEmpty(type)){
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.SUBSCRIBER_LIST_LAST,type,type,type,iMap.getString("CORPORATE_OID")));
			}
			else{
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.SUBSCRIBER_LIST_LAST_TX,iMap.getString("TX_NO")));
			}
			
			logger.info(sb.toString());

			oMap.put("SUBSCRIBER_LIST", DALUtil.getResults(sb.toString(), "SUBSCRIBER_LIST").get("SUBSCRIBER_LIST"));
			for (int j = 0; j < oMap.getSize("SUBSCRIBER_LIST"); j++) {
				String imageOid = oMap.getString("SUBSCRIBER_LIST", j, "IMAGE_OID");
				if (imageOid != null) {
					oMap.put("SUBSCRIBER_LIST", j, "INVOICE_IMAGE", loadInvoiceImage(imageOid, type));
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getContactLists(GMMap iMap, GMMap oMap, String type) {
		try {
			StringBuilder sb = new StringBuilder();
			if(StringUtil.isEmpty(type)){
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CONTACT_INFO_LIST,type,iMap.getString("CORPORATE_OID")));
			}
			else{
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CONTACT_INFO_LIST_TX,iMap.getString("TX_NO")));
			}
			
			oMap.put("CONTACT_LIST", DALUtil.getResults(sb.toString(), "CONTACT_LIST").get("CONTACT_LIST"));
			return oMap;
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
	}

	public static GMMap getAccountLists(GMMap iMap, GMMap oMap, String type) {
		try {
			StringBuilder sb = new StringBuilder();
			boolean taxType=false;
			if(iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("V_GENERAL_TAX_SECTOR_VALUE"))){
				taxType=true;
			}
			if(StringUtil.isEmpty(type)){
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_LIST,type,taxType?"p.tax_type_name collection_name":"p.collection_name",
						type,taxType?"cdm.tax_type_collection_type":"cdm.collection_type_prm",type,type,type,type,iMap.getString("CORPORATE_OID")));
			}
			else{
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_LIST_TX,taxType?"p.tax_type_name collection_name":"p.collection_name",
						taxType?"cdm.tax_type_collection_type":"cdm.collection_type_prm",iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO"),
								iMap.getString("TX_NO"),iMap.getString("TX_NO")));
			}
			
			logger.info(sb.toString());
		
			oMap.put("ACCOUNT_LIST", DALUtil.getResults(sb.toString(), "ACCOUNT_LIST").get("ACCOUNT_LIST"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getAccountTransferLists(GMMap iMap, GMMap oMap, String type) {
		String tableName = "ACCOUNT_TRANSFER_LIST";
		GMMap resultMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			boolean taxType=false;
			if(iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("V_GENERAL_TAX_SECTOR_VALUE"))){
				taxType=true;
			}
			StringBuilder sb0 = new StringBuilder();
			if(StringUtil.isEmpty(type)){
				sb0.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_MASTER_COUNT,iMap.getString("CORPORATE_OID")));
			}
			else{
				sb0.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_MASTER_COUNT_TX,iMap.getString("TX_NO")));
			}
			logger.info(sb0.toString());
			Object objectCount = session.createSQLQuery(sb0.toString()).uniqueResult();
			
			int txTableCount = objectCount != null ? 1 : 0;
			String typeAndCount = !("").equalsIgnoreCase(type) && txTableCount > 0 ? "_tx" : "";
			StringBuilder sb = new StringBuilder();
			if(StringUtil.isEmpty(type)){
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_LIST,type,type,type,iMap.getString("CORPORATE_OID"),typeAndCount,iMap.getString("CORPORATE_OID"),typeAndCount,iMap.getString("CORPORATE_OID"),typeAndCount,iMap.getString("CORPORATE_OID")));
			}
			else{
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_LIST_TX,iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO")));
			}
			
			resultMap = DALUtil.getResults(sb.toString(), tableName);

			Map<String, String> dayTextMap = DayDifference.getInstance().getDayTextMap();
			for (int row = 0; row < resultMap.getSize(tableName); row++) {
				String collectionChannelSource="",collectionChannelSourceId="";
				StringBuilder sb1 = new StringBuilder();
				if(StringUtil.isEmpty(type)){
					sb1.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE,taxType?"p.tax_type_name ":"p.collection_name",
							type,type,taxType?"cdm.tax_type_collection_type":"cdm.collection_type_prm",resultMap.getString(tableName, row, "FOID"),taxType?" AND p.status=1 ":"",taxType?"p.tax_type_name ":"p.collection_name"));
				}
				else{
					sb1.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE_TX,taxType?"p.tax_type_name ":"p.collection_name",
							taxType?"cdm.tax_type_collection_type":"cdm.collection_type_prm",
							iMap.getString("TX_NO"), iMap.getString("TX_NO"), taxType?" AND p.status=1 ":"",taxType?"p.tax_type_name ":"p.collection_name"));
				}
				GMMap resultMap2 = DALUtil.getResults(sb1.toString(), "COLLECTION_CHANNEL_SOURCE_TABLE");
				for (int i = 0; i < resultMap2.getSize("COLLECTION_CHANNEL_SOURCE_TABLE"); i++) {
					collectionChannelSource+=resultMap2.getString("COLLECTION_CHANNEL_SOURCE_TABLE", i, "COLLECTION_CHANNEL_SOURCE")+(resultMap2.getSize("COLLECTION_CHANNEL_SOURCE_TABLE")!=i?",":"");
				}
				resultMap.put(tableName, row, "COLLECTION_CHANNEL_SOURCE", CommonHelper.trimEnd(collectionChannelSource, ','));
				
				sb1 = new StringBuilder();
				if(StringUtil.isEmpty(type)){
					sb1.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE_ID,
							type,type,taxType?"cdm.tax_type_collection_type":"cdm.collection_type_prm",resultMap.getString(tableName, row, "FOID"),taxType?" AND p.status=1 ":"",taxType?"p.tax_type_name ":"p.collection_name"));
				}
				else{
					sb1.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE_ID_TX,
							taxType?"cdm.tax_type_collection_type":"cdm.collection_type_prm",
							iMap.getString("TX_NO"),
							taxType?" AND p.status=1 ":"",
							taxType?"p.tax_type_name ":"p.collection_name"));
				}
				resultMap2 = DALUtil.getResults(sb1.toString(), "COLLECTION_CHANNEL_SOURCE_ID_TABLE");
				for (int i = 0; i < resultMap2.getSize("COLLECTION_CHANNEL_SOURCE_ID_TABLE"); i++) {
					collectionChannelSourceId+=resultMap2.getString("COLLECTION_CHANNEL_SOURCE_ID_TABLE", i, "COLLECTION_CHANNEL_SOURCE_ID")+(resultMap2.getSize("COLLECTION_CHANNEL_SOURCE_ID_TABLE")!=i?",":"");
				}
				resultMap.put(tableName, row, "COLLECTION_CHANNEL_SOURCE_ID", CommonHelper.trimEnd(collectionChannelSourceId, ','));
				
				String dayList = "", dayListId = "";
				boolean afterWeek = false;
				String day = resultMap.getString(tableName, row, "TRANSFER_DAY_RULE");
				String dayType = resultMap.getString(tableName, row, "TRANSFER_DAY_OPTION");
				if (StringUtils.isNotBlank(dayType) && dayType.equalsIgnoreCase("2")) {
					day = resultMap.getString(tableName, row, "TRANSFER_DAY_RULE_ID");
				}

				if (StringUtils.isNotBlank(day)) {
					String dayGroup[];
					if (day.contains(",")) {
						dayGroup = day.trim().split(",");
					} else {
						dayGroup = new String[1];
						dayGroup[0] = day;
					}
					for (int j = 0; j < dayGroup.length; j++) {
						String group = dayGroup[j];
						if (StringUtils.isNotBlank(group)) {
							group = group.substring(1, group.length() - 1);
							if (group.contains("->")) {
								String[] days = group.split("->");
								if (days.length > 2) {
									String start = dayTextMap.get(days[0]);
									afterWeek = "1".equalsIgnoreCase(days[2]) ? true : false;
									String end = dayTextMap.get(days[1]);
									dayList += "(" + start + "->" + end + ")";
									dayListId += "(" + start + "->" + end + "->" + afterWeek + ")";
									if (j + 1 < dayGroup.length) {
										dayList += ",";
										dayListId += ",";
									}
								}
							} else {
								dayList = day;
								dayListId = day;
							}
						}
					}
					resultMap.put(tableName, row, "TRANSFER_DAY_RULE", dayList);
					resultMap.put(tableName, row, "TRANSFER_DAY_RULE_ID", dayListId);
				}
			}
			oMap.put(tableName, resultMap.get(tableName));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_SHOW_ROW_CHANNEL_SOURCE")
	public static GMMap showRowCorporateChannelSource(GMMap iMap) {

		GMMap oMap = new GMMap();
		String channelCode = null, sourceCode = null;
		String[] channelCodeList = null, sourceCodeList = null;
		GMMap rowMap = new GMMap();
		try {
			rowMap = iMap.getMap("CHANNELS_SOURCES");
			oMap.put("WORKINGDAY_START_TIME", timeReplace(rowMap.getString("WORKINGDAY_START_TIME")));
			oMap.put("WORKINGDAY_END_TIME", timeReplace(rowMap.getString("WORKINGDAY_END_TIME")));
			oMap.put("HOLIDAY_START_TIME", timeReplace(rowMap.getString("HOLIDAY_START_TIME")));
			oMap.put("HOLIDAY_END_TIME", timeReplace(rowMap.getString("HOLIDAY_END_TIME")));
			oMap.put("CLOSED_DATE", StringUtils.isNotBlank(rowMap.getString("CLOSED_DATE")) ? rowMap.getString("CLOSED_DATE") : false);
			oMap.put("CLOSED_DATE_START", dateTimeReplace(rowMap.getString("CLOSED_DATE_START")));
			oMap.put("CLOSED_DATE_END", dateTimeReplace(rowMap.getString("CLOSED_DATE_END")));
			oMap.put("EXPLANATION", rowMap.getString("EXPLANATION"));
			oMap.put("CLOSED_DATE_ALL", StringUtils.isNotBlank(rowMap.getString("CLOSED_DATE_ALL")) ? rowMap.getString("CLOSED_DATE_ALL") : false);

			channelCode = rowMap.getString("CHANNEL_CODE");
			sourceCode = rowMap.getString("SOURCE_CODE");

			if (channelCode != null && !channelCode.isEmpty()) {
				if (channelCode.contains(",")) {
					channelCodeList = channelCode.trim().split(",");
				} else {
					channelCodeList = new String[] { channelCode };
				}
			}
			if (sourceCode != null && !sourceCode.isEmpty()) {
				if (sourceCode.contains(",")) {
					sourceCodeList = sourceCode.trim().split(",");
				} else {
					sourceCodeList = new String[] { sourceCode };
				}
			}

			GMMap sources = GMServiceExecuter.call("CDM_GET_SOURCES", new GMMap());
			GMMap channels = GMServiceExecuter.call("CDM_GET_CHANNELS", new GMMap());

			int index = 0;
			for (String element : sourceCodeList) {
				index = 0;
				while (index < sources.getSize("SOURCES")) {
					if (element.equals(sources.getString("SOURCES", index, "SOURCE_CODE"))) {
						sources.put("SOURCES", index, "SEC", true);
						index++;
						break;
					} else {
						index++;
					}
				}
			}

			index = 0;
			for (String element : channelCodeList) {
				index = 0;
				while (index < channels.getSize("CHANNELS")) {
					if (element.equals(channels.getString("CHANNELS", index, "CHANNEL_CODE"))) {
						channels.put("CHANNELS", index, "SEC", true);
						index++;
						break;
					} else {
						index++;
					}
				}
			}
			oMap.put("CHANNELS", channels.get("CHANNELS"));
			oMap.put("SOURCES", sources.get("SOURCES"));

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("CDM_DEL_CHANNEL_SOURCE_ON_DEPENDS")
	public static GMMap delChannelSoureOnDepends(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap rowMapSubscriber = new GMMap();
		try {
			oMap.put("OPERATION", true);
			rowMapSubscriber = iMap.getMap("CHANNEL_SOURCE_SELECTED_ROW");
			List<String> channelList = new ArrayList<String>();
			List<String> sourceList = new ArrayList<String>();
			List<String> differentChannelList = new ArrayList<String>();
			List<String> differentSourceList = new ArrayList<String>();
			List<String> selectedChannelList = Arrays.asList(rowMapSubscriber.getString("CHANNEL_CODE").split(","));
			List<String> selectedSourceList = Arrays.asList(rowMapSubscriber.getString("SOURCE_CODE").split(","));
			for (int index = 0; index < iMap.getSize("CHANNEL_SOURCE_LIST"); index++) {
				channelList.addAll(Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", index, "CHANNEL_CODE").split(",")));
				sourceList.addAll(Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", index, "SOURCE_CODE").split(",")));
			}

			for (String selectedChannel : selectedChannelList) {
				int selectedChannelCount = 0;
				for (String channel : channelList) {
					if (channel.equalsIgnoreCase(selectedChannel))
						selectedChannelCount++;
				}
				if (selectedChannelCount == 1)
					differentChannelList.add(selectedChannel);
			}

			for (String selectedSource : selectedSourceList) {
				int selectedSourceCount = 0;
				for (String source : sourceList) {
					if (source.equalsIgnoreCase(selectedSource))
						selectedSourceCount++;
				}
				if (selectedSourceCount == 1)
					differentSourceList.add(selectedSource);
			}

			if (differentChannelList.size() > 0 || differentSourceList.size() > 0) {
				GMMap oMapReturn = getAccountChannelIndexDeleting(iMap, differentChannelList);
				getAccountSoureIndexDeleting(oMapReturn, oMap, differentSourceList);
				oMapReturn = getAccountTransferChannelIndexDeleting(iMap, differentChannelList);
				getAccountTransferSoureIndexDeleting(oMapReturn, oMap, differentSourceList);
			} else {
				oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
				oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static GMMap getAccountTransferChannelIndexDeleting(GMMap iMap, List<String> selectedChannelList) {
		GMMap tempMap = new GMMap();
		GMMap oMap = new GMMap();
		for (int i = 0; i < iMap.getSize("ACCOUNT_TRANSFERS_DATA"); i++) {
			tempMap.put("ACCOUNT_TRANSFERS_DATA", i, iMap.getMap("ACCOUNT_TRANSFERS_DATA", i));
		}
		int row = 0;
		for (int i = 0; i < tempMap.getSize("ACCOUNT_TRANSFERS_DATA"); i++) {
			boolean channelHave = false;
			if (StringUtils.isNotBlank(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "COLLECTION_CHANNEL_SOURCE_ID"))) {
				List<String> channelSourceList = Arrays.asList(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "COLLECTION_CHANNEL_SOURCE_ID").split(","));
				for (String channelSource : channelSourceList) {
					for (String selectedChannel : selectedChannelList) {
						if (selectedChannel.equalsIgnoreCase(channelSource.split("<->")[1])) {
							channelHave = true;
							break;
						}
					}
					if (channelHave)
						break;
				}

			}
			if (!channelHave) {
				oMap.put("ACCOUNT_TRANSFERS_DATA", row++, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", i));
			}
		}
		return oMap;
	}

	private static GMMap getAccountTransferSoureIndexDeleting(GMMap iMap, GMMap oMap, List<String> selectedSourceList) {
		GMMap tempMap = new GMMap();
		for (int i = 0; i < iMap.getSize("ACCOUNT_TRANSFERS_DATA"); i++) {
			tempMap.put("ACCOUNT_TRANSFERS_DATA", i, iMap.getMap("ACCOUNT_TRANSFERS_DATA", i));
		}
		int row = 0;
		for (int i = 0; i < tempMap.getSize("ACCOUNT_TRANSFERS_DATA"); i++) {
			boolean sourceHave = false;
			if (StringUtils.isNotBlank(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "COLLECTION_CHANNEL_SOURCE_ID"))) {
				List<String> channelSourceList = Arrays.asList(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "COLLECTION_CHANNEL_SOURCE_ID").split(","));
				for (String channelSource : channelSourceList) {
					for (String selectedSource : selectedSourceList) {
						if (selectedSource.equalsIgnoreCase(channelSource.split("<->")[2])) {
							sourceHave = true;
							break;
						}
					}
					if (sourceHave)
						break;
				}

			}
			if (!sourceHave) {
				oMap.put("ACCOUNT_TRANSFERS_DATA", row++, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", i));
			}
		}
		return oMap;
	}

	private static GMMap getAccountChannelIndexDeleting(GMMap iMap, List<String> selectedChannelList) {
		GMMap oMap = new GMMap();
		GMMap tempMap = new GMMap();
		for (int i = 0; i < iMap.getSize("ACCOUNTS_DATA"); i++) {
			tempMap.put("ACCOUNTS_DATA", i, iMap.getMap("ACCOUNTS_DATA", i));
		}
		int row = 0;
		for (int i = 0; i < tempMap.getSize("ACCOUNTS_DATA"); i++) {
			boolean channelHave = false;
			if (StringUtils.isNotBlank(tempMap.getString("ACCOUNTS_DATA", i, "CHANNEL_SOURCE_CODE"))) {
				List<String> channelSourceList = Arrays.asList(tempMap.getString("ACCOUNTS_DATA", i, "CHANNEL_SOURCE_CODE").split(","));
				for (String channelSource : channelSourceList) {
					for (String selectedChannel : selectedChannelList) {
						if (selectedChannel.equalsIgnoreCase(channelSource.split("<->")[1])) {
							channelHave = true;
							break;
						}
					}
					if (channelHave)
						break;
				}

			}
			if (!channelHave) {
				oMap.put("ACCOUNTS_DATA", row++, tempMap.getMap("ACCOUNTS_DATA", i));
			}
		}
		return oMap;
	}

	private static GMMap getAccountSoureIndexDeleting(GMMap iMap, GMMap oMap, List<String> selectedSourceList) {
		GMMap tempMap = new GMMap();
		for (int i = 0; i < iMap.getSize("ACCOUNTS_DATA"); i++) {
			tempMap.put("ACCOUNTS_DATA", i, iMap.getMap("ACCOUNTS_DATA", i));
		}
		int row = 0;
		for (int i = 0; i < tempMap.getSize("ACCOUNTS_DATA"); i++) {
			boolean sourceHave = false;
			if (StringUtils.isNotBlank(tempMap.getString("ACCOUNTS_DATA", i, "CHANNEL_SOURCE_CODE"))) {
				List<String> channelSourceList = Arrays.asList(tempMap.getString("ACCOUNTS_DATA", i, "CHANNEL_SOURCE_CODE").split(","));
				for (String channelSource : channelSourceList) {
					for (String selectedSource : selectedSourceList) {
						if (selectedSource.equalsIgnoreCase(channelSource.split("<->")[0])) {
							sourceHave = true;
							break;
						}
					}
					if (sourceHave)
						break;
				}

			}
			if (!sourceHave) {
				oMap.put("ACCOUNTS_DATA", row++, tempMap.getMap("ACCOUNTS_DATA", i));
			}
		}
		return oMap;
	}

	@GraymoundService("CDM_DEL_ACCOUNT_ON_DEPENDS")
	public static GMMap delAccountOnDepends(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMapAccount = new GMMap();
		try {
			GMMap tempMap = new GMMap();
			rowMapAccount = iMap.getMap("ACCOUNT_ROW_DATA");
			for (int i = 0; i < iMap.getSize("ACCOUNT_TRANSFERS_DATA"); i++) {
				tempMap.put("ACCOUNT_TRANSFERS_DATA", i, iMap.getMap("ACCOUNT_TRANSFERS_DATA", i));
			}
			int row = 0;
			for (int i = 0; i < tempMap.getSize("ACCOUNT_TRANSFERS_DATA"); i++) {
				boolean channelHave = false;
				if ((rowMapAccount.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapAccount.getString("ACCOUNT_NUMBER")).equalsIgnoreCase(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "SOURCE_ACCOUNT_NO_ID"))
						|| (rowMapAccount.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapAccount.getString("ACCOUNT_NUMBER")).equalsIgnoreCase(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "TRANSFUSION_ACCOUNT_NO_ID"))
						|| (StringUtils.isNotBlank(rowMapAccount.getString("IBAN")) && (rowMapAccount.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapAccount.getString("IBAN")).equalsIgnoreCase(tempMap.getString("ACCOUNT_TRANSFERS_DATA", i, "TRANSFUSION_ACCOUNT_NO_ID")))) {
					channelHave = true;
				}
				if (!channelHave) {
					oMap.put("ACCOUNT_TRANSFERS_DATA", row++, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", i));
				}
			}
			oMap.put("OPERATION", true);
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("CDM_SHOW_ROW_SUBSCRIBER")
	public static GMMap showRowCorporateSubscriber(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMap = new GMMap();
		try {
			rowMap = iMap.getMap("SUBSCRIBER_ROW");
			if(iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("GENEL_VERGI_VALUE"))){
				List<String> taxTypes = Arrays.asList(rowMap.getString("COLLECTION_TYPE").split(","));
				if(taxTypes.size()==iMap.getSize("TAX_TYPE_LIST")){
					oMap.put("TAX_TYPE_ALL", true);
					oMap.put("TAX_TYPE_LIST", iMap.get("TAX_TYPE_LIST"));
				}else{
					oMap.put("TAX_TYPE_ALL", false);
					for (int index = 0; index < iMap.getSize("TAX_TYPE_LIST"); index++) {
						boolean hadTaxType = false;
						for (String taxType : taxTypes) {
							if (taxType.equalsIgnoreCase(iMap.getString("TAX_TYPE_LIST", index, "TAX_TYPE_CODE"))) {
								hadTaxType = true;
								break;
							}
						}
						iMap.put("TAX_TYPE_LIST", index, "CHOOSE", hadTaxType);
					}
					oMap.put("TAX_TYPE_LIST", iMap.get("TAX_TYPE_LIST"));
				}
			}else{
				oMap.put("TAX_TYPE_ALL", false);
				oMap.put("COLLECTION_NAME", rowMap.getString("COLLECTION_NAME"));
			}
			oMap.put("LABEL", rowMap.getString("LABEL"));
			oMap.put("EXAMPLE", rowMap.getString("EXAMPLE"));
			oMap.put("MASK", rowMap.getString("MASK"));
			oMap.put("PREFIX", rowMap.getString("PREFIX"));
			oMap.put("PREFIX_USE_FOR_COLLECTION", rowMap.getString("PREFIX_USE_FOR_COLLECTION"));
			oMap.put("PREFIX_USE_FOR_STANDING_ORDER", rowMap.getString("PREFIX_USE_FOR_STANDING_ORDER"));
			oMap.put("SUFFIX", rowMap.getString("SUFFIX"));
			oMap.put("SUFFIX_USE_FOR_COLLECTION", rowMap.getString("SUFFIX_USE_FOR_COLLECTION"));
			oMap.put("SUFFIX_USE_FOR_STANDING_ORDER", rowMap.getString("SUFFIX_USE_FOR_STANDING_ORDER"));
			oMap.put("VIEW_ORDER", rowMap.getString("VIEW_ORDER"));
			oMap.put("USE_FOR_INQUIRY", rowMap.getString("USE_FOR_INQUIRY"));
			oMap.put("USE_FOR_STANDING_ORDER", rowMap.getString("USE_FOR_STANDING_ORDER"));
			oMap.put("USE_FOR_COLLECTION", rowMap.getString("USE_FOR_COLLECTION"));
			oMap.put("USE_AUTOMATIC_PAYMENT", rowMap.getString("USE_AUTOMATIC_PAYMENT"));
			oMap.put("USE_PAYMENT_INVOICE_SCREEN", rowMap.getString("USE_PAYMENT_INVOICE_SCREEN"));
			oMap.put("INVOICE_IMAGE", rowMap.getString("INVOICE_IMAGE"));
			
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	public static String loadInvoiceImage(String imageOid, String type) {
		byte[] bdata = null;
		String data = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if (StringUtils.isBlank(type)) {
				invoiceimage iimage = (invoiceimage) session.createCriteria(invoiceimage.class).add(Restrictions.eq("oid", imageOid)).add(Restrictions.eq("status", true)).uniqueResult();
				if (iimage != null) {
					bdata = iimage.getInvoiceImageBasecode64().getBytes(1, (int) iimage.getInvoiceImageBasecode64().length());
				}
				data = bdata != null ? new String(bdata) : "";
			} else {
				invoiceimageTx iimage = (invoiceimageTx) session.createCriteria(invoiceimageTx.class).add(Restrictions.eq("oid", imageOid)).add(Restrictions.eq("status", true)).uniqueResult();
				if (iimage != null) {
					bdata = iimage.getInvoiceImageBasecode64().getBytes(1, (int) iimage.getInvoiceImageBasecode64().length());
				}
				data = bdata != null ? new String(bdata) : "";
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return data;
	}

	@SuppressWarnings("unchecked")
	private static GMMap validationMustCorporate(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {
			if ("SECIMYOK".equalsIgnoreCase(iMap.getString("SECTOR_CODE")) || StringUtils.isBlank(iMap.getString("SECTOR_CODE"))) {
				validationExtra("SECTOR_CODE", oMap, "L�tfen Sekt�r alan�n� uygun olarak doldurunuz!");
				return oMap;
			}

			validationDomain(iMap, "CUSTOMER_NUMBER", oMap, "L�tfen M��teri no alan�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			validationDomain(iMap, "SHORT_CODE", oMap, "L�tfen Kurum k�sa ad�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			validationDomain(iMap, "CORPORATE_NAME", oMap, "L�tfen Kurum uzun ad�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			validationDomain(iMap, "CORPORATE_BANK_CODE", oMap, "L�tfen Banka kodu alan�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			validationDomain(iMap, "PROTOCOL_START_DATE", oMap, "L�tfen Protokol imzalama tarihi alan�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			
			if (iMap.getString("V_GENERAL_TAX_SECTOR_VALUE").equalsIgnoreCase(iMap.getString("SECTOR_VALUE"))&&StringUtils.isBlank(iMap.getString("CORPORATE_BUSINESS_CODE"))){
				validationExtra("CORPORATE_BUSINESS_CODE", oMap, "Vergi Dairesi kodu'nu bo� ge�emezseniz!");
				return oMap;
			}
			if (iMap.getString("V_GENERAL_TAX_SECTOR_VALUE").equalsIgnoreCase(iMap.getString("SECTOR_VALUE"))&&checkValidationSameTaxCode(iMap)) {
				validationExtra("CORPORATE_BUSINESS_CODE", oMap, "Vergi Dairesi kodu daha �nce kullan�lm��, ayn� vergi dairesi kodunu kullanamazs�n�z!");
				return oMap;
			}
			if (iMap.getString("V_DDS_DEFAULT_SECTOR_NAME").equalsIgnoreCase(iMap.getString("SECTOR_VALUE")) && !iMap.getBoolean("CORPORATE_ACTIVENESS")) {
				// anafirma alt�nda aktif bayi olup olmad���na bak�lacak
				Session session = DAOSession.getSession("BNSPRDal");
				List<RetailerDefinition> retailerDefinitionList = session.createCriteria(RetailerDefinition.class)
																	.add(Restrictions.eq("status", true)).add(Restrictions.eq("activeness", true))
																	.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE")))																	
																	.list();
				if (retailerDefinitionList != null && retailerDefinitionList.size() > 0) {
					oMap.put("MESSAGE", "DBS ana firmas�na ba�l� aktif bayiler oldu�u i�in firma pasif yap�lamaz. �ncelike ana firma alt�ndaki bayilerin pasif yap�lmas� gerekmektedir");
					oMap.put("OPERATION", false);
				}
			}
			
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	private static GMMap validationCorporate(GMMap iMap, boolean approve) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {

			validationDomain(iMap, "IF_DUE_DATE_HOLIDAY", oMap, "L�tfen Talimat�n son �deme tarihi tatil g�n� ise alan�n� uygun se�imi yap�n�z!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			if (iMap.getBoolean("ALLOW_END_PAYMEND") && StringUtils.isBlank(iMap.getString("COUNT_AFTER_DUE"))) {
				validationExtra("COUNT_AFTER_DUE", oMap, "Son �deme tarihinden kutucu�u se�ildi�inde parametre de�eri girilmelidir!");
				return oMap;
			}
			if (iMap.getBoolean("ALLOW_END_PAYMEND") && StringUtils.isBlank(iMap.getString("COUNT_TYPE_AFTER_DUE"))) {
				validationExtra("COUNT_TYPE_AFTER_DUE", oMap, "Son �deme tarihinden kutucu�u se�ildi�inde combodan bir de�er se�ilmelidir!");
				return oMap;
			}
			boolean countrySelected = false;
			for (int row = 0; row < iMap.getSize("CITIES"); row++) {
				if (iMap.getBoolean("CITIES", row, "IL_SEC")) {
					countrySelected = true;
					break;
				}

			}
			if (!(countrySelected || iMap.getBoolean("ALL_CITY"))) {
				validationExtra("LABEL", oMap, "L�tfen �l bilgisi ekleyiniz (en az bir adet �l bilgisi eklenmelidir.)!");
				return oMap;
			}
			if (iMap.getSize("SUBSCRIBER_LIST") <= 0) {
				validationExtra("LABEL", oMap, "L�tfen Referans No bilgileri ekleyiniz (en az bir adet Referans bilgisi eklenmelidir.)!");
				return oMap;
			}
			// if (iMap.getSize("CONTACT_LIST") <= 0) {
			// validationExtra("NAME_SURNAME", oMap, "L�tfen �leti�im bilgileri ekleyiniz (en az bir adet �leti�im bilgisi eklenmelidir.)!");
			// return oMap;
			// }
			if (iMap.getSize("CHANNEL_SOURCE_LIST") <= 0) {
				validationExtra("SOURCE_CODE", oMap, "L�tfen Kanal/Kaynak bilgileri ekleyiniz (en az bir adet Kanal/Kaynak bilgisi eklenmelidir.)!");
				return oMap;
			}
			if (iMap.getSize("ACCOUNT_LIST") <= 0) {
				validationExtra("ACCOUNT_DEFINITION_TYPE", oMap, "L�tfen Hesap bilgileri ekleyiniz (en az bir adet Hesap bilgisi eklenmelidir.)!");
				return oMap;
			}
			validationSaveAccount(iMap, oMap);
			if (!oMap.getBoolean("OPERATION")) {
				return oMap;
			} else {
				validationSaveAccountTransfer(iMap, oMap);
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	private static boolean checkValidationSameTaxCode(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		CorporateMaster cDefMaster = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("corporateBusinessCode", iMap.getString("CORPORATE_BUSINESS_CODE")).ignoreCase()).add(Restrictions.eq("status", true)).uniqueResult();
		if(cDefMaster!=null&&(StringUtils.isBlank(iMap.getString("CORPORATE_OID"))||!cDefMaster.getOid().equalsIgnoreCase(iMap.getString("CORPORATE_OID"))))
			return true;
		return false;
	}

	private static GMMap validationSaveAccount(GMMap iMap, GMMap oMap) {
		int countAccountType = 0;
		boolean concentrationType = false;
		boolean hadBlockedAccount = false;

		for (int i = 0; i < iMap.getSize("ACCOUNT_LIST"); i++) {
			if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", i, "ACCOUNT_DEFINITION_TYPE")))
				countAccountType++;
			if (DatabaseConstants.ConcentrationTypes.MultiConcentration.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", i, "CONCENTRATION_TYPE")))
				concentrationType = true;
			if (DatabaseConstants.AccountDefinitionTypes.BlockedAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", i, "ACCOUNT_DEFINITION_TYPE")))
				hadBlockedAccount = true;

		}
		if (!hadBlockedAccount&&countAccountType < 1) {
			validationExtra("ACCOUNT_DEFINITION_TYPE", oMap, "L�tfen Hesap bilgileri ekleyiniz (en az bir adet Tahsilat Hesab� tan�mlanmal�d�r!");
			return oMap;
		}
		validationAcoountSubscriberAndSourceChannel(iMap, oMap);
		if (concentrationType)
			validationAcoountSubscriberMatchAndSourceChannel(iMap, oMap);
		return oMap;

	}

	private static void validationAcoountSubscriberMatchAndSourceChannel(GMMap iMap, GMMap oMap) {
		List<String> subscriberMatches = new ArrayList<String>();
		for (int i = 0; i < iMap.getSize("ACCOUNT_LIST"); i++) {
			if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_LIST", i, "TREE_LIST"))) {
				subscriberMatches.addAll(Arrays.asList(iMap.getString("ACCOUNT_LIST", i, "TREE_LIST").split(",")));
			}
		}

		// for (int j = 0; j < iMap.getSize("SUBSCRIBER_MATCH_LIST"); j++) {
		// if (!subscriberMatches.contains(iMap.getString("SUBSCRIBER_MATCH_LIST", j, "DEFINITION_ID"))) {
		// validationExtra("SUBSCRIBER_MATCH_LIST", oMap, "L�tfen t�m referans k�r�l�m tan�mlar�n� tahsilat hesab� ile e�le�tirin!");
		// break;
		// }
		//
		// }

	}

	private static void validationAcoountSubscriberAndSourceChannel(GMMap iMap, GMMap oMap) {
		List<String> subscribers = new ArrayList<String>();
		List<String> channelSources = new ArrayList<String>();
		List<String> collTypeChannelSources = new ArrayList<String>();
		List<String> collTypeChannelSourceAccounts = new ArrayList<String>();

		for (int i = 0; i < iMap.getSize("SUBSCRIBER_LIST"); i++) {
			if (!subscribers.contains(iMap.getString("SUBSCRIBER_LIST", i, "COLLECTION_TYPE")))
				subscribers.add(iMap.getString("SUBSCRIBER_LIST", i, "COLLECTION_TYPE"));
		}
		for (int j = 0; j < iMap.getSize("CHANNEL_SOURCE_LIST"); j++) {
			List<String> channels = Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", j, "CHANNEL_CODE").split(","));
			List<String> sources = Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", j, "SOURCE_CODE").split(","));
			for (String channel : channels) {
				for (String source : sources) {
					channelSources.add(source + "<->" + channel);
				}
			}

		}
		for (String subscriber : subscribers) {
			for (String channelSource : channelSources) {
				collTypeChannelSources.add(subscriber + "<->" + channelSource);
			}
		}
		for (int i = 0; i < iMap.getSize("ACCOUNT_LIST"); i++) {
			if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_LIST", i, "CHANNEL_SOURCE_CODE")) && StringUtils.isNotBlank(iMap.getString("ACCOUNT_LIST", i, "COLLECTION_TYPE"))) {
				List<String> channelSourceAccounts = Arrays.asList(iMap.getString("ACCOUNT_LIST", i, "CHANNEL_SOURCE_CODE").split(","));
				List<String> collTypes = Arrays.asList(iMap.getString("ACCOUNT_LIST", i, "COLLECTION_TYPE").split(","));
				for (String collType : collTypes) {
					for (String channelSourceAccount : channelSourceAccounts) {
						collTypeChannelSourceAccounts.add(collType + "<->" + channelSourceAccount);
					}
				}

			}
		}
		// for (String collTypeChannelSource : collTypeChannelSources) {
		// if (!collTypeChannelSourceAccounts.contains(collTypeChannelSource)) {
		// validationExtra("ACCOUNT_DEFINITION_TYPE", oMap, "L�tfen t�m �deme tipleri ve kanal,kaynak bilgileri mutlaka 1 tahsilat hesab� ile e�le�tirilmelidir!");
		// break;
		// }
		// }

	}

	private static GMMap validationSaveAccountTransfer(GMMap iMap, GMMap oMap) {
		int countAccountTypeEftAndKh = 0;
		for (int i = 0; i < iMap.getSize("ACCOUNT_LIST"); i++) {
			if (DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", i, "ACCOUNT_DEFINITION_TYPE")) || DatabaseConstants.AccountDefinitionTypes.UsageAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", i, "ACCOUNT_DEFINITION_TYPE"))|| DatabaseConstants.AccountDefinitionTypes.BlockedAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", i, "ACCOUNT_DEFINITION_TYPE")))
				countAccountTypeEftAndKh++;

		}
		if (countAccountTypeEftAndKh > 0 && iMap.getSize("ACCOUNT_TRANSFER_LIST") < 1) {
			validationExtra("SOURCE_ACCOUNT_NO", oMap, "L�tfen Hesap Aktar�m bilgileri ekleyiniz (Kullan�m veya Eft hesab� tan�mland���nda, en az bir adet Hesap Aktar�m bilgisi eklenmelidir.)!");
			return oMap;
		}
		int sourceAccountNoIdThCount = 0;
		for (int i = 0; i < iMap.getSize("ACCOUNT_TRANSFER_LIST"); i++) {
			if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_LIST", i, "SOURCE_ACCOUNT_NO_ID")) && StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_LIST", i, "SOURCE_ACCOUNT_NO_ID").split("-")[1])) {
				sourceAccountNoIdThCount++;
			}
		}
		if (sourceAccountNoIdThCount == 0 && countAccountTypeEftAndKh > 0) {
			validationExtra("SOURCE_ACCOUNT_NO_ID", oMap, "L�tfen Hesap Aktar�m bilgileri ekleyiniz (Kullan�m veya Eft hesab� tan�mland���nda, en az bir adet Hesap Aktar�m bilgisi eklenmelidir.)!");
			return oMap;
		}
		return oMap;

	}

	@GraymoundService("CDM_SAVE_CORPORATE")
	public static GMMap getSaveCorporate(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			oMap = validationMustCorporate(iMap);
			oMap.put("CHECK_SAVE_BUTTON_CLICK", false);
			if (oMap.getBoolean("OPERATION")) {
				oMap = validationCorporate(iMap, false);
				oMap.put("CHECK_SAVE_BUTTON_CLICK", false);
				// oMap.put("OPERATION", true);
				if (checkCorporateName(iMap)) {
					if (iMap.getBoolean("SHORT_CODE_CHECK_TEMP")) {
						validationExtra("SHORT_CODE", oMap, iMap.getString("SHORT_CODE") + "\" isimi ile daha �nce bir kurum tamamlanmam�� olarak eklenmi�");
					} else {
						validationExtra("SHORT_CODE", oMap, iMap.getString("SHORT_CODE") + "\" isimi ile daha �nce bir kurum eklenmi�");
					}

					oMap.put("SHORT_CODE_CHECK", iMap.getString("SHORT_CODE"));
					return oMap;
				}
				if (oMap.getBoolean("OPERATION") || !iMap.getBoolean("CORPORATE_ACTIVENESS")) {
					BigDecimal txNo = new BigDecimal(StringUtils.isBlank(oMap.getString("TRX_NO")) ? CommonHelper.getNewTransactionNo() : oMap.getString("TRX_NO"));
					oMap.put("TRX_NO", txNo);
					String corporateOid = iMap.getString("CORPORATE_OID");
					Session session = DAOSession.getSession("BNSPRDal");
					session.beginTransaction();
					String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
					CorporateMasterTx corporateTx = saveCorporateInfo(iMap, oMap, session, txNo, username);
					if ("NEW".equalsIgnoreCase(iMap.getString("ACTION"))) {
						corporateOid = corporateTx.getOid();
						corporateTx.setCorporateOid(corporateOid);
						session.saveOrUpdate(corporateTx);
					}
					if (corporateTx != null) {
						oMap.put("CORPORATE_OID", corporateTx.getCorporateOid());
						if (StringUtils.isBlank(corporateTx.getCorporateOid())) {
							oMap.put("CORPORATE_OID", corporateTx.getOid());
							corporateOid = corporateTx.getOid();
							corporateTx.setCorporateOid(corporateOid);
						}
					}
					updateTempInfoStatusZero(iMap, session, corporateOid);
					saveCities(iMap, oMap, session, corporateOid, txNo);
					saveSubscribers(iMap, oMap, session, corporateOid, txNo);
					saveContacts(iMap, oMap, session, corporateOid, txNo);
					saveChannelSources(iMap, oMap, session, corporateOid, txNo);
					Map<String, String> accountCollectionTypeRelMap = saveAccounts(iMap, oMap, session, corporateOid, txNo);
					saveAccountTransfers(iMap, oMap, session, corporateOid, accountCollectionTypeRelMap, txNo);
					//session.getTransaction().commit();
					session.flush();
					oMap.put("CORPORATE_CODE", corporateTx.getCorporateCode());
					oMap.put("OPERATION", true);
					oMap.put("MESSAGE", "Kaydetme i�lemi ba�ar�l� bir �ekilde ger�ekle�mi�tir.");
					oMap.put("SHORT_CODE_CHECK", corporateTx.getShortCode());
					oMap.put("CHECK_SAVE_BUTTON_CLICK", true);
				}
			}
			if (StringUtils.isBlank(oMap.getString("CORPORATE_CODE")))
				oMap.put("CORPORATE_CODE", iMap.getString("CORPORATE_CODE"));
			if (StringUtils.isBlank(oMap.getString("TRX_NO")))
				oMap.put("TRX_NO", iMap.getString("TRX_NO"));
			if (StringUtils.isBlank(oMap.getString("CORPORATE_OID")))
				oMap.put("CORPORATE_OID", iMap.getString("CORPORATE_OID"));
		} catch (Exception e) {
			oMap.put("CHECK_SAVE_BUTTON_CLICK", false);
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	private static boolean checkCorporateName(GMMap iMap) throws Exception {
		Session session = DAOSession.getSession("BNSPRDal");
		iMap.put("SHORT_CODE_CHECK_TEMP", false);
		List<CorporateMaster> cDefMasterList = session.createCriteria(CorporateMaster.class).add(Restrictions.eq("shortCode", iMap.getString("SHORT_CODE")).ignoreCase()).add(Restrictions.eq("status", true)).list();
		for (CorporateMaster cDefMaster : cDefMasterList) {
			if (cDefMaster != null && !iMap.getString("CORPORATE_CODE").equalsIgnoreCase(cDefMaster.getCorporateCode()) && StringUtils.isBlank(iMap.getString("SHORT_CODE_CHECK"))) {
				return true;
			}
		}
		List<CorporateMasterTx> cDefMasterListTx = session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("shortCode", iMap.getString("SHORT_CODE")).ignoreCase()).add(Restrictions.eq("status", true)).list();
		for (CorporateMasterTx cDefMaster : cDefMasterListTx) {
			if (cDefMaster != null && !iMap.getString("CORPORATE_CODE").equalsIgnoreCase(cDefMaster.getCorporateCode()) && StringUtils.isBlank(iMap.getString("SHORT_CODE_CHECK"))) {
				iMap.put("SHORT_CODE_CHECK_TEMP", true);
				return true;
			}
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	private static CorporateMasterTx saveCorporateInfo(GMMap iMap, GMMap oMap, Session session, BigDecimal txNo, String username) throws Exception {
		String corporateOid = iMap.getString("CORPORATE_OID");
		List<CorporateMasterTx> corporateMasterTxs = session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
		for (int count = 0; count < corporateMasterTxs.size(); count++) {
			corporateMasterTxs.get(count).setStatus(false);
			session.saveOrUpdate(corporateMasterTxs.get(count));
		}
		CorporateMasterTx cMTx = new CorporateMasterTx();
		cMTx.setCorporateCode(getCorporationCode(iMap.getString("CORPORATE_CODE"), corporateOid));
		cMTx.setCorporateOid(corporateOid);
		cMTx.setSectorCode(iMap.getString("SECTOR_CODE"));
		cMTx.setCustomerNumber(iMap.getBigDecimal("CUSTOMER_NUMBER"));
		cMTx.setCorporateName(iMap.getString("CORPORATE_NAME"));
		cMTx.setShortCode(iMap.getString("SHORT_CODE"));
		cMTx.setCorporateBankCode(iMap.getString("CORPORATE_BANK_CODE"));

		cMTx.setProtocolStartDate(iMap.getDate("PROTOCOL_START_DATE") != null ? pdf.format(iMap.getDate("PROTOCOL_START_DATE")) : "20991231");
		cMTx.setProtocolEndDate(iMap.getDate("PROTOCOL_END_DATE") != null ? pdf.format(iMap.getDate("PROTOCOL_END_DATE")) : "20991231");

		cMTx.setAllowPartPayment(iMap.getBoolean("ALLOW_BEFORE_PAYMEND"));
		cMTx.setAllowPartAfterDue(iMap.getBoolean("ALLOW_AFTER_PAYMEND"));
		if (iMap.getBoolean("ALLOW_END_PAYMEND")) {
			cMTx.setCountAfterDue(Short.valueOf(iMap.getString("COUNT_AFTER_DUE")));
			cMTx.setCountTypeAfterDue(iMap.getString("COUNT_TYPE_AFTER_DUE"));
			cMTx.setAllowAfterDueDate(iMap.getBoolean("ALLOW_END_PAYMEND"));

		} else {
			cMTx.setAllowAfterDueDate(false);
		}
		cMTx.setIsOnlineCorporate(iMap.getBoolean("IS_ONLINE_CORPORATE") ? "1" : "0");

		cMTx.setIfDueDateHoliday(iMap.getString("IF_DUE_DATE_HOLIDAY"));
		cMTx.setCorporateBankCode(iMap.getString("CORPORATE_BANK_CODE"));
		cMTx.setCreateUser(username);
		cMTx.setCreateDate(sdf.format(new Date()));
		cMTx.setStatus(true);
		cMTx.setTxStatus(null);
		cMTx.setTxNo(txNo);
		cMTx.setCorporateActiveness(iMap.getBoolean("CORPORATE_ACTIVENESS") ? "A" : "P");
		cMTx.setCorporateBusinessCode(iMap.getString("CORPORATE_BUSINESS_CODE"));
		cMTx.setEodFlag(iMap.getBoolean("IS_EOD_FLAG") ? "1" : "0");
		session.saveOrUpdate(cMTx);
		return cMTx;
	}

	@GraymoundService("CDM_GET_CORPORATE_DEFINITION")
	public static GMMap getCorporateDefinition(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetCorporateDefinitionHandler());
	}

	private static String getCorporationCode(String corporateCode, String corporateOid) throws Exception {
		if (StringUtil.isEmpty(corporateCode)) {
			if (StringUtils.isNotBlank(corporateOid)) {
				corporateCode = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, new GMMap().put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid)).getString(
						TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
				if (StringUtil.isEmpty(corporateCode)) {
					corporateCode = "C-" + CorporationServiceUtil.getSequenceCode("CORPORATE_DEF");
				}
			} else {
				corporateCode = "C-" + CorporationServiceUtil.getSequenceCode("CORPORATE_DEF");
			}
		}
		return corporateCode;
	}

	@SuppressWarnings("unchecked")
	private static void saveCities(GMMap iMap, GMMap oMap, Session session, String corporateOid, BigDecimal txNo) throws Exception {
		List<CorporateCityRelTx> listCityDef = session.createCriteria(CorporateCityRelTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
		for (int count = 0; count < listCityDef.size(); count++) {
			listCityDef.get(count).setStatus(false);
			session.saveOrUpdate(listCityDef.get(count));
		}
		CorporateCityRelTx cityDef = new CorporateCityRelTx();
		if (iMap.getBoolean("ALL_CITY")) {
			cityDef.setCorporateOid(corporateOid);
			cityDef.setStatus(true);
			cityDef.setIsPublicCorporate(iMap.getBoolean("ALL_CITY"));
			cityDef.setTxNo(txNo);
			session.saveOrUpdate(cityDef);
		} else {
			for (int index = 0; index < iMap.getSize("CITIES"); index++) {
				if (!iMap.getBoolean("ALL_CITY") && iMap.getBoolean("CITIES", index, "IL_SEC")) {
					cityDef = new CorporateCityRelTx();
					cityDef.setCorporateOid(corporateOid);
					cityDef.setStatus(true);
					cityDef.setKod(iMap.getString("CITIES", index, "KOD"));
					cityDef.setTxNo(txNo);
					session.saveOrUpdate(cityDef);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static void saveSubscribers(GMMap iMap, GMMap oMap, Session session, String corporateOid, BigDecimal txNo) throws Exception {
		List<SubscriberMaskDefTx> listSubscribeMaskDef = session.createCriteria(SubscriberMaskDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
		for (int count = 0; count < listSubscribeMaskDef.size(); count++) {
			listSubscribeMaskDef.get(count).setStatus(false);
			List<SubscriberMaskDetailTx> listSubscribeMaskDetail = (List<SubscriberMaskDetailTx>) session.createCriteria(SubscriberMaskDetailTx.class).add(Restrictions.eq("maskOid", listSubscribeMaskDef.get(count).getOid())).add(Restrictions.eq("status", true)).list();
			for (int row = 0; row < listSubscribeMaskDetail.size(); row++) {
				listSubscribeMaskDetail.get(row).setStatus(false);
				session.saveOrUpdate(listSubscribeMaskDetail.get(row));
			}
			session.saveOrUpdate(listSubscribeMaskDef.get(count));
		}

		List<CollectionTypeDefTx> listCollectionTypeDef = session.createCriteria(CollectionTypeDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
		for (int row = 0; row < listCollectionTypeDef.size(); row++) {
			listCollectionTypeDef.get(row).setStatus(false);
			session.saveOrUpdate(listCollectionTypeDef.get(row));
		}

		List<AccountMatchingTreeTx> listMatchingInfo = null;
		if (StringUtils.isNotBlank(corporateOid)) {
			listMatchingInfo = (List<AccountMatchingTreeTx>) session.createCriteria(AccountMatchingTreeTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();

			if (listMatchingInfo != null) {
				for (int count = 0; count < listMatchingInfo.size(); count++) {
					listMatchingInfo.get(count).setStatus(false);
					session.saveOrUpdate(listMatchingInfo.get(count));
				}
			}
		}
		
		
		HashMap<String, String> collectionTypeGroup = new HashMap<String, String>();
	
		for (int row = 0; row < iMap.getSize("SUBSCRIBER_LIST"); row++) {
			List<String> collectionTypes = Arrays.asList(iMap.getString("SUBSCRIBER_LIST", row, "COLLECTION_TYPE").split(","));
			for (String collectionType : collectionTypes) {
				if(!collectionTypeGroup.containsKey(collectionType)){
					
					CollectionTypeDefTx collectionTypeDefTx = new CollectionTypeDefTx();
					collectionTypeDefTx.setCorporateOid(corporateOid);
					collectionTypeDefTx.setStatus(true);
					collectionTypeDefTx.setCollectionType(Short.valueOf(collectionType));
					collectionTypeDefTx.setAllowAutoCollection(iMap.getBoolean("SUBSCRIBER_LIST", row, "USE_AUTOMATIC_PAYMENT"));
					collectionTypeDefTx.setIsAppearancePaymentScreen(iMap.getBoolean("SUBSCRIBER_LIST", row, "USE_PAYMENT_INVOICE_SCREEN"));
					collectionTypeDefTx.setTxNo(txNo);
					session.saveOrUpdate(collectionTypeDefTx);
					
					SubscriberMaskDefTx maskDefTx = new SubscriberMaskDefTx();
					if (!"-1".equals(collectionType)) {
						maskDefTx.setCollectionType(Short.valueOf(collectionType));
						maskDefTx.setUsedAllCollection("0");
					} else {
						maskDefTx.setUsedAllCollection("1");
					}
					maskDefTx.setCorporateOid(corporateOid);
					maskDefTx.setStatus(true);
					maskDefTx.setTxNo(txNo);
					session.saveOrUpdate(maskDefTx);
					
					collectionTypeGroup.put(collectionType, maskDefTx.getOid());
				}
				
				
					SubscriberMaskDetailTx subscribeMaskDetail = new SubscriberMaskDetailTx();
					subscribeMaskDetail.setExample(iMap.getString("SUBSCRIBER_LIST", row, "EXAMPLE"));
					subscribeMaskDetail.setLabel(iMap.getString("SUBSCRIBER_LIST", row, "LABEL"));
					subscribeMaskDetail.setMask(iMap.getString("SUBSCRIBER_LIST", row, "MASK"));
					subscribeMaskDetail.setPrefix(iMap.getString("SUBSCRIBER_LIST", row, "PREFIX"));
					subscribeMaskDetail.setPrefixUseForCollection(iMap.getBoolean("SUBSCRIBER_LIST", row, "PREFIX_USE_FOR_COLLECTION") ? "1" : "0");
					subscribeMaskDetail.setPrefixUseForStandingOrder(iMap.getBoolean("SUBSCRIBER_LIST", row, "PREFIX_USE_FOR_STANDING_ORDER") ? "1" : "0");
					subscribeMaskDetail.setSuffix(iMap.getString("SUBSCRIBER_LIST", row, "SUFFIX"));
					subscribeMaskDetail.setSuffixUseForCollection(iMap.getBoolean("SUBSCRIBER_LIST", row, "SUFFIX_USE_FOR_COLLECTION") ? "1" : "0");
					subscribeMaskDetail.setSuffixUseForStandingOrder(iMap.getBoolean("SUBSCRIBER_LIST", row, "SUFFIX_USE_FOR_STANDING_ORDER") ? "1" : "0");
					subscribeMaskDetail.setViewOrder(iMap.getString("SUBSCRIBER_LIST", row, "VIEW_ORDER"));
					subscribeMaskDetail.setUseForInquiry(iMap.getBoolean("SUBSCRIBER_LIST", row, "USE_FOR_INQUIRY") ? "1" : "0");
					subscribeMaskDetail.setUseForStandingOrder(iMap.getBoolean("SUBSCRIBER_LIST", row, "USE_FOR_STANDING_ORDER") ? "1" : "0");
					subscribeMaskDetail.setUseForCollection(iMap.getBoolean("SUBSCRIBER_LIST", row, "USE_FOR_COLLECTION") ? "1" : "0");
					subscribeMaskDetail.setMaskOid(collectionTypeGroup.get(collectionType));
					subscribeMaskDetail.setStatus(true);
					subscribeMaskDetail.setTxNo(txNo);
		
					session.saveOrUpdate(subscribeMaskDetail);
					saveInvoiceImage(session, corporateOid, subscribeMaskDetail.getOid(), iMap.getMap("SUBSCRIBER_LIST", row));
					
					saveAccountSubscriberMatching(iMap, session, corporateOid, subscribeMaskDetail.getOid(), collectionType, iMap.getString("SUBSCRIBER_LIST", row, "LABEL"), txNo);
			}
		}
		
	}

	private static void saveAccountSubscriberMatching(GMMap iMap, Session session, String corporateOid, String maskDetailOid, String collectionType, String subscriberLabel,
			BigDecimal txNo) throws Exception {
		System.out.println(iMap);
		for (int row = 0; row < iMap.getSize("SUBSCRIBER_MATCH_LIST"); row++) {
			if (iMap.getString("SUBSCRIBER_MATCH_LIST", row, "LABEL").trim().equalsIgnoreCase(collectionType + "-" + subscriberLabel.trim())) {
				AccountMatchingTreeTx matchInfo = new AccountMatchingTreeTx();
				matchInfo.setChildCorporateName(iMap.getString("SUBSCRIBER_MATCH_LIST", row, "CHILD_CORPORATE_NAME"));
				matchInfo.setSubscriberNo(iMap.getString("SUBSCRIBER_MATCH_LIST", row, "SUBSCRIBER_NO"));
				matchInfo.setLabel(maskDetailOid);
				matchInfo.setDefinitionId(iMap.getString("SUBSCRIBER_MATCH_LIST", row, "DEFINITION_ID"));
				matchInfo.setCorporateOid(corporateOid);
				matchInfo.setStatus(true);
				matchInfo.setTxNo(txNo);

				session.saveOrUpdate(matchInfo);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static void saveContacts(GMMap iMap, GMMap oMap, Session session, String corporateOid, BigDecimal txNo) throws Exception {
		List<CorporateContactinfoTx> listContactInfo = session.createCriteria(CorporateContactinfoTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
		if (listContactInfo != null) {
			for (int count = 0; count < listContactInfo.size(); count++) {
				listContactInfo.get(count).setStatus(false);
				session.saveOrUpdate(listContactInfo.get(count));
			}
		}
		for (int row = 0; row < iMap.getSize("CONTACT_LIST"); row++) {
			CorporateContactinfoTx contactInfo = new CorporateContactinfoTx();
			contactInfo.setDepartment(iMap.getString("CONTACT_LIST", row, "DEPARTMENT_ID"));
			contactInfo.setEmail(iMap.getString("CONTACT_LIST", row, "EMAIL"));
			contactInfo.setFax(iMap.getString("CONTACT_LIST", row, "FAX"));
			contactInfo.setMobile(iMap.getString("CONTACT_LIST", row, "MOBILE"));
			contactInfo.setNameSurname(iMap.getString("CONTACT_LIST", row, "NAME_SURNAME"));
			contactInfo.setPhoneNumber(iMap.getString("CONTACT_LIST", row, "PHONE_NUMBER"));
			contactInfo.setNote(iMap.getString("CONTACT_LIST", row, "NOTE"));
			contactInfo.setCorporateOid(corporateOid);
			contactInfo.setStatus(true);
			contactInfo.setTxNo(txNo);
			session.saveOrUpdate(contactInfo);
		}
	}

	@SuppressWarnings("unchecked")
	private static void saveChannelSources(GMMap iMap, GMMap oMap, Session session, String corporateOid, BigDecimal txNo) throws Exception {
		List<ChannelSourceDefTx> listChannelSourceDef = (List<ChannelSourceDefTx>) session.createCriteria(ChannelSourceDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();
		if (listChannelSourceDef != null) {
			for (int count = 0; count < listChannelSourceDef.size(); count++) {
				listChannelSourceDef.get(count).setStatus(false);
				session.saveOrUpdate(listChannelSourceDef.get(count));
			}
		}

		String[] channelCodeList = null;
		String[] sourceCodeList = null;

		for (int index = 0; index < iMap.getSize("CHANNEL_SOURCE_LIST"); index++) {
			String channelCode = iMap.getString("CHANNEL_SOURCE_LIST", index, "CHANNEL_CODE");
			String sourceCode = iMap.getString("CHANNEL_SOURCE_LIST", index, "SOURCE_CODE");
			if (StringUtils.isNotBlank(channelCode) && StringUtils.isNotBlank(sourceCode)) {
				if (channelCode.contains(",")) {
					channelCodeList = channelCode.trim().split(",");
				} else {
					channelCodeList = new String[1];
					channelCodeList[0] = channelCode;
				}
				if (sourceCode.contains(",")) {
					sourceCodeList = sourceCode.trim().split(",");
				} else {
					sourceCodeList = new String[1];
					sourceCodeList[0] = sourceCode;
				}

				for (String source : sourceCodeList) {
					for (String channel : channelCodeList) {
						ChannelSourceDefTx channelSourceDef = new ChannelSourceDefTx();
						channelSourceDef.setSourceCode(source);
						channelSourceDef.setChannelCode(channel);
						channelSourceDef.setWorkingdayStartTime(timeReplace(iMap.getString("CHANNEL_SOURCE_LIST", index, "WORKINGDAY_START_TIME")));
						channelSourceDef.setWorkingdayEndTime(timeReplace(iMap.getString("CHANNEL_SOURCE_LIST", index, "WORKINGDAY_END_TIME")));
						channelSourceDef.setHolidayStartTime(timeReplace(iMap.getString("CHANNEL_SOURCE_LIST", index, "HOLIDAY_START_TIME")));
						channelSourceDef.setHolidayEndTime(timeReplace(iMap.getString("CHANNEL_SOURCE_LIST", index, "HOLIDAY_END_TIME")));
						channelSourceDef.setClosedDateStart(StringUtils.isNotBlank(iMap.getString("CHANNEL_SOURCE_LIST", index, "CLOSED_DATE_START")) ? dateDeFormatterForDB(iMap.getString("CHANNEL_SOURCE_LIST", index, "CLOSED_DATE_START")) : "");
						channelSourceDef.setClosedDateEnd(StringUtils.isNotBlank(iMap.getString("CHANNEL_SOURCE_LIST", index, "CLOSED_DATE_END")) ? dateDeFormatterForDB(iMap.getString("CHANNEL_SOURCE_LIST", index, "CLOSED_DATE_END")) : "");
						channelSourceDef.setExplanation(iMap.getString("CHANNEL_SOURCE_LIST", index, "EXPLANATION"));
						channelSourceDef.setScreenLine(new BigDecimal(index));
						channelSourceDef.setStatus(true);
						channelSourceDef.setTxNo(txNo);
						channelSourceDef.setCorporateOid(corporateOid);
						session.saveOrUpdate(channelSourceDef);
					}
				}
			}
		}
	}

	private static String timeReplace(String time) {
		return StringUtils.isNotBlank(time) ? time.replace(":", "") : "";
	}

	private static String dateTimeReplace(String dateTime) {
		return StringUtils.isNotBlank(dateTime) ? dateTime.replace(":", "").replace(".", "").replace(" ", "") : "";
	}

	public static String dateDeFormatterForDB(String strDate) throws Exception {
		return (strDate.length() == 16) ? (strDate.substring(6, 10).concat(strDate.substring(3, 5)).concat(strDate.substring(0, 2)).concat(strDate.substring(11, 13).concat(strDate.substring(14, 16)))) : "";
	}

	@SuppressWarnings("unchecked")
	private static Map<String, String> saveAccounts(GMMap iMap, GMMap oMap, Session session, String corporateOid, BigDecimal txNo) throws Exception {
		Map<String, String> accountCollectionTypeRelMap = new HashMap<String, String>();
		List<CorporationAccountMasterTx> listTemerkuzAccount = (List<CorporationAccountMasterTx>) session.createCriteria(CorporationAccountMasterTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();

		if (listTemerkuzAccount != null) {
			for (int count = 0; count < listTemerkuzAccount.size(); count++) {
				List<AccountCollectionTypeRelTx> listAccountTypeRel = (List<AccountCollectionTypeRelTx>) session.createCriteria(AccountCollectionTypeRelTx.class).add(Restrictions.eq("accountMasterOid", listTemerkuzAccount.get(count).getOid())).add(Restrictions.eq("status", true)).list();
				for (int row = 0; row < listAccountTypeRel.size(); row++) {
					listAccountTypeRel.get(row).setStatus(false);
					session.saveOrUpdate(listAccountTypeRel.get(row));
				}
				listTemerkuzAccount.get(count).setStatus(false);
				session.saveOrUpdate(listTemerkuzAccount.get(count));
			}

			String[] channelSourceCodeList = null;
			String[] collectionCodeList = null;
			String[] treeList = null;
			boolean concentrationTypesMultiHave = false;
			for (int index = 0; index < iMap.getSize("ACCOUNT_LIST"); index++) {

				String hesapTuru = iMap.getString("ACCOUNT_LIST", index, "ACCOUNT_DEFINITION_TYPE");
				String concentration = StringUtils.isBlank(iMap.getString("ACCOUNT_LIST", index, "CONCENTRATION_TYPE")) ? DatabaseConstants.ConcentrationTypes.SingleConcentration : iMap.getString("ACCOUNT_LIST", index, "CONCENTRATION_TYPE");

				CorporationAccountMasterTx accountMaster = new CorporationAccountMasterTx();
				accountMaster.setAccountDefinitionType(hesapTuru);
				accountMaster.setAccountNumber(iMap.getBigDecimal("ACCOUNT_LIST", index, "ACCOUNT_NUMBER"));
				accountMaster.setAccountOwner(iMap.getString("ACCOUNT_LIST", index, "ACCOUNT_OWNER"));
				accountMaster.setAccountType(DatabaseConstants.AccountTypes.CheckingAccount);
				accountMaster.setConcentrationType(concentration);
				accountMaster.setCorporateOid(corporateOid);
				accountMaster.setDefaultAmount(iMap.getBigDecimal("ACCOUNT_LIST", index, "DEFAULT_AMOUNT") == null ? new BigDecimal("0.00") : iMap.getBigDecimal("ACCOUNT_LIST", index, "DEFAULT_AMOUNT"));
				accountMaster.setIban(iMap.getString("ACCOUNT_LIST", index, "IBAN"));
				accountMaster.setStatus(true);
				accountMaster.setTxNo(txNo);
				session.saveOrUpdate(accountMaster);

				String channelSourceCode = iMap.getString("ACCOUNT_LIST", index, "CHANNEL_SOURCE_CODE");
				String collectionCode = iMap.getString("ACCOUNT_LIST", index, "COLLECTION_TYPE");
				String treeCode = null;
				if (DatabaseConstants.ConcentrationTypes.MultiConcentration.equals(concentration)) {
					treeCode = iMap.getString("ACCOUNT_LIST", index, "TREE_LIST");
				}

				if (StringUtils.isNotBlank(channelSourceCode) && StringUtils.isNotBlank(collectionCode)) {
					if (channelSourceCode.contains(",")) {
						channelSourceCodeList = channelSourceCode.trim().split(",");
					} else {
						channelSourceCodeList = new String[1];
						channelSourceCodeList[0] = channelSourceCode;
					}
					if (collectionCode.contains(",")) {
						collectionCodeList = collectionCode.trim().split(",");
					} else {
						collectionCodeList = new String[1];
						collectionCodeList[0] = collectionCode;
					}
					if (treeCode != null && treeCode.contains(",")) {
						treeList = treeCode.trim().split(",");
					} else {
						treeList = new String[1];
						treeList[0] = treeCode;
					}

					if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equals(hesapTuru)) {
						for (String collection : collectionCodeList) {
							for (String channelSource : channelSourceCodeList) {
								for (String treeId : treeList) {
									AccountCollectionTypeRelTx accountCollectionTypeRel = new AccountCollectionTypeRelTx();

									String[] channel_source = null;
									if (StringUtils.isNotBlank(channelSource)) {
										if (channelSource.contains("<->")) {
											channel_source = channelSource.trim().split("<->");
										}
									}

									if (channel_source.length == 2) {
										accountCollectionTypeRel.setChannelCode(channel_source[1]);
										accountCollectionTypeRel.setSourceCode(channel_source[0]);
									}
									accountCollectionTypeRel.setAccountMasterOid(accountMaster.getOid());
									if (StringUtils.isNotBlank(collection)) {
										accountCollectionTypeRel.setCollectionType(Short.valueOf(collection));
									}
									accountCollectionTypeRel.setAccountMatchDefId(treeId);
									accountCollectionTypeRel.setStatus(true);
									accountCollectionTypeRel.setTxNo(txNo);

									session.saveOrUpdate(accountCollectionTypeRel);
									accountCollectionTypeRelMap.put(collection + "<->" + channel_source[0] + "<->" + channel_source[1] + "<->" + (StringUtils.isBlank(treeId) ? "" : treeId), accountCollectionTypeRel.getOid());
								}
							}
						}
					}
				}
			}

		}
		return accountCollectionTypeRelMap;
	}

	@SuppressWarnings("unchecked")
	private static void saveAccountTransfers(GMMap iMap, GMMap oMap, Session session, String corporateOid, Map<String, String> accountCollectionTypeRelMap,
			BigDecimal txNo) throws Exception {
		List<BalanceTransferDefTx> listBalanceTransferDef = (List<BalanceTransferDefTx>) session.createCriteria(BalanceTransferDefTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("status", true)).list();

		if (listBalanceTransferDef != null) {
			for (int index = 0; index < listBalanceTransferDef.size(); index++) {
				List<BalanceTransferDaysTx> listBalanceTransferDays = (List<BalanceTransferDaysTx>) session.createCriteria(BalanceTransferDaysTx.class).add(Restrictions.eq("balanceTransferOid", listBalanceTransferDef.get(index).getOid())).add(Restrictions.eq("status", true)).list();
				for (int row = 0; row < listBalanceTransferDays.size(); row++) {
					listBalanceTransferDays.get(row).setStatus(false);
					session.saveOrUpdate(listBalanceTransferDays.get(row));
				}
				List<CollectionTransferRelTx> listCollectionTransferRel = (List<CollectionTransferRelTx>) session.createCriteria(CollectionTransferRelTx.class).add(Restrictions.eq("transferParamOid", listBalanceTransferDef.get(index).getOid())).add(Restrictions.eq("status", true)).list();
				for (int row = 0; row < listCollectionTransferRel.size(); row++) {
					listCollectionTransferRel.get(row).setStatus(false);
					session.saveOrUpdate(listCollectionTransferRel.get(row));
				}
				listBalanceTransferDef.get(index).setStatus(false);
				session.saveOrUpdate(listBalanceTransferDef.get(index));
			}
			String[] transferRuleDayList = null;

			for (int index = 0; index < iMap.getSize("ACCOUNT_TRANSFER_LIST"); index++) {

				String kanalKaynakOdemeId = iMap.getString("ACCOUNT_TRANSFER_LIST", index, "COLLECTION_CHANNEL_SOURCE_ID");
				String transferRuleDayId = iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_DAY_RULE_ID");
				String transferRuleDay = iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_DAY_RULE");
				String transferRuleAy = iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_MONTH_RULE");

				BalanceTransferDefTx balanceTransferDef = new BalanceTransferDefTx();
				String aktarimHesabiArr[] = iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFUSION_ACCOUNT_NO_ID").split("-");
				balanceTransferDef.setToAccountType(aktarimHesabiArr[0]);
				balanceTransferDef.setToAccountIban(DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(aktarimHesabiArr[0]) ? aktarimHesabiArr[1] : null);
				balanceTransferDef.setToAccountNo(!DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(aktarimHesabiArr[0]) ? new BigDecimal(aktarimHesabiArr[1]) : null);
				String kaynakHesapArr[] = iMap.getString("ACCOUNT_TRANSFER_LIST", index, "SOURCE_ACCOUNT_NO_ID").split("-");
				balanceTransferDef.setFromAccountType(kaynakHesapArr[0]);
				balanceTransferDef.setFromAccountNo(new BigDecimal(kaynakHesapArr[1]));
				balanceTransferDef.setTransferCollectionsInholiday(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "VACATION_TYPE_ID"));
				balanceTransferDef.setTransferDayOption(StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_DAY_OPTION")) ? new Byte(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_DAY_OPTION")) : new Byte("0"));
				balanceTransferDef.setTransferMonthOption(StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_MONTH_OPTION")) ? new Byte(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_MONTH_OPTION")) : new Byte("0"));
				balanceTransferDef.setTransferDayType(StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_DAY_OPTION")) ? iMap.getString("ACCOUNT_TRANSFER_LIST", index, "DAY_TYPE_ID") : "0");
				balanceTransferDef.setTransferType(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_TYPE_ID"));
				balanceTransferDef.setTransferDesc(iMap.getString("ACCOUNT_TRANSFER_LIST", index, "TRANSFER_DESC"));
				if (StringUtils.isNotBlank(transferRuleAy)) {
					if (StringUtils.isNotBlank(transferRuleAy.split("\\.")[0]) && !".".equalsIgnoreCase(transferRuleAy.split("\\.")[0])) {
						if (iMap.getInt("TRANSFER_MONTH_OPTION") == 0) {
							balanceTransferDef.setDayOfEachMonth(new Byte(transferRuleAy.split("\\.")[0]));
						} else {
							String[] traGroup = transferRuleAy.split(" ");
							balanceTransferDef.setInDayOfEachMonth(new Byte(traGroup[0].split("\\.")[0]));
							balanceTransferDef.setOutDayOfEachMonth(new Byte(traGroup[4].split("\\.")[0]));
						}
					}
				}
				balanceTransferDef.setTimePeriod("0");
				balanceTransferDef.setCorporateOid(corporateOid);
				balanceTransferDef.setStatus(true);
				balanceTransferDef.setTxNo(txNo);
				
				session.saveOrUpdate(balanceTransferDef);

				if (StringUtils.isNotBlank(transferRuleDayId) || StringUtils.isNotBlank(transferRuleDay)) {
					if (StringUtils.isBlank(transferRuleDayId)) {
						transferRuleDayId = transferRuleDay;
					}
					if (transferRuleDayId.contains(",")) {
						transferRuleDayList = transferRuleDayId.split(",");
					} else {
						transferRuleDayList = new String[1];
						transferRuleDayList[0] = transferRuleDayId;
					}

					for (String element : transferRuleDayList) {
						if (element.contains("(") && element.contains(")")) {
							String trd = element.substring(1, element.length() - 1);
							if (trd.contains("->")) {
								BalanceTransferDaysTx transferDays = new BalanceTransferDaysTx();
								String[] trdGroup = trd.split("->");
								boolean afterWeek = DayDifference.getInstance().getDifferance(trdGroup[0], trdGroup[1]) < 0 ? true : false;
								transferDays.setInDayOfEachWeek(String.valueOf(DayDifference.getInstance().getDay(trdGroup[0])));
								transferDays.setOutDayOfEachWeek(String.valueOf(DayDifference.getInstance().getDay(trdGroup[1])));
								transferDays.setNextWeek(trdGroup.length == 3 ? Boolean.valueOf(trdGroup[2]).booleanValue() : afterWeek);
								transferDays.setBalanceTransferOid(balanceTransferDef.getOid());
								transferDays.setStatus(true);
								transferDays.setTxNo(txNo);
								session.saveOrUpdate(transferDays);
							} else {
								String[] trdGroup = transferRuleDay.split(" ");
								balanceTransferDef.setTransferDayCount(Short.valueOf(trdGroup[0].replace("(", "")));
								session.saveOrUpdate(balanceTransferDef);
							}
						}
					}
				}

				if (StringUtils.isNotBlank(kanalKaynakOdemeId) && accountCollectionTypeRelMap.size() != 0) {
					String idList[] = kanalKaynakOdemeId.split(",");
					for (String element : idList) {
						element = element.replace("null", "");
						if (StringUtils.isNotBlank(accountCollectionTypeRelMap.get(element))) {
							CollectionTransferRelTx collectionRel = new CollectionTransferRelTx();
							collectionRel.setAccountCollectionOid(accountCollectionTypeRelMap.get(element).toString());
							collectionRel.setStatus(true);
							collectionRel.setTransferParamOid(balanceTransferDef.getOid());
							collectionRel.setTxNo(txNo);
							session.saveOrUpdate(collectionRel);
						}
					}
				}

			}

		}

	}

	@GraymoundService("CDM_ADD_UPT_SUBSCRIBER")
	public static GMMap addOrUptRowSubscriber(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = validationSubscriber(iMap);
			if (oMap.getBoolean("OPERATION")) {
				GMMap rowMap = new GMMap();
				if(iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("GENEL_VERGI_VALUE"))){
					String collectionType="",collectionName="";
					for (int index = 0; index < iMap.getSize("TAX_TYPE_LIST"); index++) {
						if(iMap.getBoolean("TAX_TYPE_ALL")||iMap.getBoolean("TAX_TYPE_LIST", index, "CHOOSE")){
							collectionType+=iMap.getString("TAX_TYPE_LIST", index, "TAX_TYPE_CODE")+(index < iMap.getSize("TAX_TYPE_LIST") - 1 ? "," : "");
							collectionName+=iMap.getString("TAX_TYPE_LIST", index, "TAX_TYPE_NAME")+(index < iMap.getSize("TAX_TYPE_LIST") - 1 ? "," : "");
						}
					}
					rowMap.put("COLLECTION_NAME", collectionName);
					rowMap.put("COLLECTION_TYPE", collectionType);
				}else{
					rowMap.put("COLLECTION_NAME", iMap.getString("COLLECTION_NAME"));
					rowMap.put("COLLECTION_TYPE", iMap.getString("COLLECTION_TYPE"));
				}
				rowMap.put("LABEL", iMap.getString("LABEL"));
				rowMap.put("EXAMPLE", iMap.getString("EXAMPLE"));
				rowMap.put("MASK", iMap.getString("MASK"));
				rowMap.put("PREFIX", iMap.getString("PREFIX"));
				rowMap.put("PREFIX_USE_FOR_COLLECTION", iMap.getString("PREFIX_USE_FOR_COLLECTION"));
				rowMap.put("PREFIX_USE_FOR_STANDING_ORDER", iMap.getString("PREFIX_USE_FOR_STANDING_ORDER"));
				rowMap.put("SUFFIX", iMap.getString("SUFFIX"));
				rowMap.put("SUFFIX_USE_FOR_COLLECTION", iMap.getString("SUFFIX_USE_FOR_COLLECTION"));
				rowMap.put("SUFFIX_USE_FOR_STANDING_ORDER", iMap.getString("SUFFIX_USE_FOR_STANDING_ORDER"));
				rowMap.put("VIEW_ORDER", iMap.getString("VIEW_ORDER"));
				rowMap.put("USE_FOR_INQUIRY", iMap.getString("USE_FOR_INQUIRY"));
				rowMap.put("USE_FOR_STANDING_ORDER", iMap.getString("USE_FOR_STANDING_ORDER"));
				rowMap.put("USE_FOR_COLLECTION", iMap.getString("USE_FOR_COLLECTION"));
				// is biriminden gelen istek �zerine USE_FOR_STANDING_ORDER ile ayn� degeri al�yor.
				rowMap.put("USE_AUTOMATIC_PAYMENT", iMap.getString("USE_AUTOMATIC_PAYMENT"));
				rowMap.put("USE_PAYMENT_INVOICE_SCREEN", iMap.getString("USE_PAYMENT_INVOICE_SCREEN"));
				rowMap.put("INVOICE_IMAGE", iMap.getString("INVOICE_IMAGE"));
				int selectedRow=iMap.getInt("SUBSCRIBER_SELECTED_ROW");
				for (int index = 0; index < iMap.getSize("SUBSCRIBER_LIST"); index++) {
					if(selectedRow!=-1&&selectedRow==index){
						oMap.put("SUBSCRIBER_LIST", index, rowMap);
					}else{
						if (index!=selectedRow&&iMap.getString("SUBSCRIBER_LIST", index, "COLLECTION_TYPE").equalsIgnoreCase(iMap.getString("COLLECTION_TYPE"))
								&&!iMap.getString("SUBSCRIBER_LIST", index, "USE_PAYMENT_INVOICE_SCREEN").equalsIgnoreCase(iMap.getString("USE_PAYMENT_INVOICE_SCREEN"))) {
							iMap.put("SUBSCRIBER_LIST", index, "USE_PAYMENT_INVOICE_SCREEN", iMap.getString("USE_PAYMENT_INVOICE_SCREEN"));
						}
						oMap.put("SUBSCRIBER_LIST", index, iMap.getMap("SUBSCRIBER_LIST", index));
					}
				}
				if(selectedRow==-1){
					oMap.put("SUBSCRIBER_LIST", oMap.getSize("SUBSCRIBER_LIST"), rowMap);
				}
				oMap.put("SUBSCRIBER_ROW_DATA", rowMap);
				GMMap rowMapChoose = iMap.getMap("SUBSCRIBER_ROW");
				if (rowMapChoose != null && !rowMapChoose.getString("COLLECTION_TYPE").equalsIgnoreCase(iMap.getString("COLLECTION_TYPE"))) {
					uptSubscriberOnAccount(iMap, rowMapChoose, oMap);
					uptSubscriberOnAccountTransfer(iMap, rowMapChoose, oMap);
				} else {
					oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
					oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
				}
			} else {
				oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
				oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static void uptSubscriberOnAccountTransfer(GMMap iMap, GMMap rowMapChoose, GMMap oMap) {
		GMMap tempMap = new GMMap();
		int tempRow = 0;
		oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
		
		
		List<String> collectionTypesSubscriber = new ArrayList<String>();
		List<String> collectionNamesSubscriber= new ArrayList<String>();
		for (int row = 0; row < oMap.getSize("SUBSCRIBER_LIST"); row++) {
			collectionTypesSubscriber.addAll(Arrays.asList(oMap.getString("SUBSCRIBER_LIST", row, "COLLECTION_TYPE").split(",")));
			collectionNamesSubscriber.addAll( Arrays.asList(oMap.getString("SUBSCRIBER_LIST", row, "COLLECTION_NAME").split(",")));
		}
		
		for (int row = 0; row < iMap.getSize("ACCOUNT_TRANSFERS_DATA"); row++) {
			String collectionChannelSourceIdResult = "", collectionChannelSourceResult = "";
			if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID"))) {
				List<String> collectionChannelSourceIdList = Arrays.asList(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID").split(","));
				List<String> collectionChannelSourceList = Arrays.asList(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE").split(","));
				List<String> collectionTypesChange = new ArrayList<String>();
				List<String> collectionNamesChange = new ArrayList<String>();
				List<String> collectionTypes=new ArrayList<String>();
				List<String> collectionNames=new ArrayList<String>();
				for (String collectionChannelSourceId : collectionChannelSourceIdList) {
					collectionTypes.add(collectionChannelSourceId.split("<->")[0]);
				}
				for (String collectionChannelSource : collectionChannelSourceList) {
					collectionNames.add(collectionChannelSource.split("<->")[0].replace("(", "").replace(")", ""));
				}
				
				for (int i = 0; i < collectionTypes.size(); i++) {
					boolean collectionTypeHave=false;
					for (int j = 0; j < collectionTypesSubscriber.size(); j++) {
						if (collectionTypes.get(i).equalsIgnoreCase(collectionTypesSubscriber.get(j))) {
							collectionTypeHave=true;break;
						}
					}
					if (collectionTypeHave) {
						collectionTypesChange.add(collectionTypes.get(i));
					}
				}
				
				for (int i = 0; i < collectionNames.size(); i++) {
					boolean collectionNameHave=false;
					for (int j = 0; j < collectionNamesSubscriber.size(); j++) {
						if (collectionNamesSubscriber.get(j).contains(collectionNames.get(i))){
							collectionNameHave=true;break;
						}
					}
					if (collectionNameHave) {
						collectionNamesChange.add(collectionNames.get(i));
					}
				}
				
				
				
				for (int i = 0; i < collectionChannelSourceIdList.size(); i++) {
					boolean collectionTypeHave=false;
					for (String collectionType : collectionTypesChange) {
						if (collectionChannelSourceIdList.get(i).split("<->")[0].equalsIgnoreCase(collectionType)) {
							collectionTypeHave=true;break;
						}
					}
					if (collectionTypeHave) {
						collectionChannelSourceIdResult = collectionChannelSourceIdResult + collectionChannelSourceIdList.get(i) + (i < collectionChannelSourceIdList.size() - 1 ? "," : "");
					}
				}
				collectionChannelSourceIdResult=CommonHelper.trimEnd(collectionChannelSourceIdResult, ',');
				
				
				for (int i = 0; i < collectionChannelSourceList.size(); i++) {
					boolean collectionNameHave=false;
					String[] collectionChannelSourceArr = collectionChannelSourceList.get(i).replace("(", "").replace(")", "").split("<->");
					for (String collectionName : collectionNamesChange) {
						if (collectionChannelSourceArr[0].equalsIgnoreCase(collectionName)) {
							collectionNameHave=true;break;
						}
					}
					if (collectionNameHave) {
						collectionChannelSourceResult = collectionChannelSourceResult +  collectionChannelSourceList.get(i) + (i < collectionChannelSourceList.size() - 1 ? "," : "");
					}
				}
				collectionChannelSourceResult=CommonHelper.trimEnd(collectionChannelSourceResult, ',');
				if (StringUtils.isNotBlank(collectionChannelSourceIdResult)) {
					oMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID", collectionChannelSourceIdResult);
					oMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE", collectionChannelSourceResult);
					tempMap.put("ACCOUNT_TRANSFERS_DATA", tempRow, iMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
					tempRow++;
				}
			} else {
				oMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE", "");
				oMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID", "");
				tempMap.put("ACCOUNT_TRANSFERS_DATA", tempRow, iMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
				tempRow++;
			}
		}
		if (tempRow == 0) {
			oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
		} else {
			oMap.put("ACCOUNT_TRANSFERS_DATA", tempMap.get("ACCOUNT_TRANSFERS_DATA"));
		}

	}

	private static void uptSubscriberOnAccount(GMMap iMap, GMMap rowMapChoose, GMMap oMap) {
		GMMap tempMap = new GMMap();
		int tempRow = 0;
		
		List<String> collectionTypesSubscriber = new ArrayList<String>();
		List<String> collectionNamesSubscriber= new ArrayList<String>();
		for (int row = 0; row < oMap.getSize("SUBSCRIBER_LIST"); row++) {
			collectionTypesSubscriber.addAll(Arrays.asList(oMap.getString("SUBSCRIBER_LIST", row, "COLLECTION_TYPE").split(",")));
			collectionNamesSubscriber.addAll( Arrays.asList(oMap.getString("SUBSCRIBER_LIST", row, "COLLECTION_NAME").split(",")));
		}
		
		for (int row = 0; row < iMap.getSize("ACCOUNTS_DATA"); row++) {
			String collectionTypeResult = "", collectionNameResult = "";
			if (StringUtils.isNotBlank(iMap.getString("ACCOUNTS_DATA", row, "COLLECTION_TYPE"))) {
				List<String> collectionTypesChange = new ArrayList<String>();
				List<String> collectionNamesChange = new ArrayList<String>();
				List<String> collectionTypes = Arrays.asList(iMap.getString("ACCOUNTS_DATA", row, "COLLECTION_TYPE").split(","));
				List<String> collectionNames = Arrays.asList(iMap.getString("ACCOUNTS_DATA", row, "COLLECTION_NAME").split(","));
				
				for (int i = 0; i < collectionTypes.size(); i++) {
					boolean collectionTypeHave=false;
					for (int j = 0; j < collectionTypesSubscriber.size(); j++) {
						if (collectionTypes.get(i).equalsIgnoreCase(collectionTypesSubscriber.get(j))) {
							collectionTypeHave=true;break;
						}
					}
					if (collectionTypeHave) {
						collectionTypesChange.add(collectionTypes.get(i));
					}
				}
				
				for (int i = 0; i < collectionNames.size(); i++) {
					boolean collectionNameHave=false;
					for (int j = 0; j < collectionNamesSubscriber.size(); j++) {
						if (collectionNamesSubscriber.get(j).contains(collectionNames.get(i))) {
							collectionNameHave=true;break;
						}
					}
					if (collectionNameHave) {
						collectionNamesChange.add(collectionNames.get(i));
					}
				}
				
				for (int i = 0; i < collectionTypesChange.size(); i++) {
					collectionTypeResult = collectionTypeResult + collectionTypesChange.get(i) + (i < collectionTypesChange.size() - 1 ? "," : "");
				}
				for (int i = 0; i < collectionNamesChange.size(); i++) {
					collectionNameResult = collectionNameResult + collectionNamesChange.get(i) + (i < collectionTypesChange.size() - 1 ? "," : "");
				}
				if (collectionTypesChange.size() > 0) {
					iMap.put("ACCOUNTS_DATA", row, "COLLECTION_TYPE", collectionTypeResult);
					iMap.put("ACCOUNTS_DATA", row, "COLLECTION_NAME", collectionNameResult);
					tempMap.put("ACCOUNTS_DATA", tempRow, iMap.getMap("ACCOUNTS_DATA", row));
					tempRow++;
				}
			} else {
				iMap.put("ACCOUNTS_DATA", row, "COLLECTION_TYPE", "");
				iMap.put("ACCOUNTS_DATA", row, "COLLECTION_NAME", "");
				tempMap.put("ACCOUNTS_DATA", tempRow, iMap.getMap("ACCOUNTS_DATA", row));
				tempRow++;
			}
		}
		System.out.println(iMap);
		if (tempRow == 0) {
			oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
		} else {
			oMap.put("ACCOUNTS_DATA", tempMap.get("ACCOUNTS_DATA"));
		}

	}

	@GraymoundService("CDM_DEL_SUBSCRIBER_ON_DEPENDS")
	public static GMMap delSubscriberOnDepends(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMapSubscriber = new GMMap();
		try {
			oMap.put("OPERATION", true);
			rowMapSubscriber = iMap.getMap("SUBSCRIBER_SELECTED_ROW");
			String collectionType = rowMapSubscriber.getString("COLLECTION_TYPE");
			int sameCollectionTypeCount = 0;
			int rowAddCount=0;
			for (int index = 0; index < iMap.getSize("SUBSCRIBER_LIST"); index++) {
				if (iMap.getString("SUBSCRIBER_LIST", index, "COLLECTION_TYPE").equalsIgnoreCase(collectionType)) {
					sameCollectionTypeCount++;
				}
				if(!iMap.getMap("SUBSCRIBER_LIST", index).equals(rowMapSubscriber)){
					oMap.put("SUBSCRIBER_LIST", rowAddCount,iMap.getMap("SUBSCRIBER_LIST", index));
					rowAddCount++;
				}
			}
			
			if (sameCollectionTypeCount == 1) {
				uptSubscriberOnAccount(iMap, rowMapSubscriber, oMap);
				uptSubscriberOnAccountTransfer(iMap, rowMapSubscriber, oMap);

			} else {
				oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
				oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}
	
	
	@GraymoundService("CDM_SUBSCRIBER_USE_PAYMENT_INVOICE_SCREEN")
	public static GMMap usePaymentInvoiceScreen(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("OPERATION", true);
			int selectedRow=iMap.getInt("SUBSCRIBER_SELECTED_ROW");
			for (int index = 0; index < iMap.getSize("SUBSCRIBER_LIST"); index++) {
				if (index!=selectedRow&&iMap.getString("SUBSCRIBER_LIST", index, "COLLECTION_TYPE").equalsIgnoreCase(iMap.getString("COLLECTION_TYPE"))
						&&!iMap.getString("SUBSCRIBER_LIST", index, "USE_PAYMENT_INVOICE_SCREEN").equalsIgnoreCase(iMap.getString("USE_PAYMENT_INVOICE_SCREEN"))) {
					oMap.put("OPERATION", false);
					oMap.put("MESSAGE", "\'Fatura �deme Ekran�nda Kullan�l�r\' ayn� �deme tipi i�in \'"+iMap.getString("SUBSCRIBER_LIST", index, "LABEL")+"\' referans tan�m�nda kullan�lm��. \'"+iMap.getString("SUBSCRIBER_LIST", index, "LABEL")+"\' referans tan�m� i�inde \'Fatura �deme Ekran�nda Kullan�l�r\' de�eri de�i�ecektir. De�i�ikli�i uygulamak istiyormusunuz?");
				}
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}
	
	public static GMMap validationSubscriber(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {
			if(!iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("GENEL_VERGI_VALUE"))){
			validationDomain(iMap, "LABEL", oMap, "L�tfen Referans no tan�m�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;

			validationDomain(iMap, "MASK", oMap, "L�tfen Referans Mask tan�m�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			String mask = iMap.getString("MASK");
			for (char ch : mask.toCharArray()) {
				if (!(String.valueOf(ch).contentEquals("*") || String.valueOf(ch).contentEquals("X") || String.valueOf(ch).contentEquals("#") || String.valueOf(ch).contentEquals("Q") || String.valueOf(ch).contentEquals("."))) {
					validationExtra("MASK", oMap, "L�tfen Referans Mask tan�m�n� uygun olarak doldurunuz!");
					return oMap;
				}
			}
			validationDomain(iMap, "EXAMPLE", oMap, "L�tfen Referans A��klamas� tan�m�n� uygun olarak doldurunuz!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			
				if (!(StringUtils.isBlank(iMap.getString("PREFIX")) || StringUtils.isBlank(iMap.getString("SUFFIX")))) {
					validationExtra("PREFIX", oMap, "L�tfen prefix yada suffix de�erlerinden sadece birine de�er giriniz!");
					return oMap;
				}
	
				if (!checkViewOrder(iMap)) {
					validationExtra("VIEW_ORDER", oMap, "L�tfen Ekran g�sterim s�ras� uygun olarak doldurunuz!");
					if (!oMap.getBoolean("OPERATION"))
						return oMap;
				}
			}else{
				boolean taxTypeChoose=false;
				for (int index = 0; index < iMap.getSize("TAX_TYPE_LIST"); index++) {
					if(iMap.getBoolean("TAX_TYPE_LIST", index, "CHOOSE")){
						taxTypeChoose=true;break;
					}
				}
				if(!(iMap.getBoolean("TAX_TYPE_ALL")||taxTypeChoose)){
					validationExtra("TAX_TYPE_ALL", oMap, "L�tfen en az bir adet vergi t�r� se�melisiniz!");
					if (!oMap.getBoolean("OPERATION"))
						return oMap;
				}
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	private static boolean checkViewOrder(GMMap iMap) {
		GMMap rowMapChoose = iMap.getMap("SUBSCRIBER_ROW");
		if (StringUtils.isBlank(iMap.getString("VIEW_ORDER")) || (StringUtils.isNotBlank(iMap.getString("VIEW_ORDER")) && Integer.valueOf(iMap.getString("VIEW_ORDER")).intValue() <= 0)) {
			return false;
		}

		for (int index = 0; index < iMap.getSize("SUBSCRIBER_LIST"); index++) {
			if (rowMapChoose != null && StringUtils.isNotBlank(iMap.getString("SUBSCRIBER_SELECTED_ROW")) && iMap.getInt("SUBSCRIBER_SELECTED_ROW") != index) {
				if(!iMap.getString("SECTOR_VALUE").equalsIgnoreCase(iMap.getString("GENEL_VERGI_VALUE"))){
					if (iMap.getString("COLLECTION_TYPE").equalsIgnoreCase(iMap.getString("SUBSCRIBER_LIST", index, "COLLECTION_TYPE")) && iMap.getInt("SUBSCRIBER_LIST", index, "VIEW_ORDER") == iMap.getInt("VIEW_ORDER")) {
						return false;
					}
				}
			} else if (rowMapChoose == null) {
				if (iMap.getString("COLLECTION_TYPE").equalsIgnoreCase(iMap.getString("SUBSCRIBER_LIST", index, "COLLECTION_TYPE")) && iMap.getInt("SUBSCRIBER_LIST", index, "VIEW_ORDER") == iMap.getInt("VIEW_ORDER")) {
					return false;
				}
			}
		}
		return true;
	}

	private static GMMap validationDomain(GMMap iMap, String colomn, GMMap oMap, String warnMessage) {
		if (StringUtils.isBlank(iMap.getString(colomn))) {
			oMap.clear();
			oMap.put("FOCUS", colomn);
			oMap.put("MESSAGE", warnMessage);
			oMap.put("OPERATION", false);
		}
		return oMap;
	}

	private static GMMap validationExtra(String domain, GMMap oMap, String warnMessage) {
		oMap.clear();
		oMap.put("FOCUS", domain);
		oMap.put("MESSAGE", warnMessage);
		oMap.put("OPERATION", false);
		return oMap;
	}

	public static GMMap dependOnSubscriber(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		int sameCollectionTypeCount = 0;
		try {
			String collectionType = (iMap.getMap("SUBSCRIBER_SELECTED_ROW")).getString("COLLECTION_TYPE");
			for (int index = 0; index < iMap.getSize("SUBSCRIBER_LIST"); index++) {
				if (iMap.getString("SUBSCRIBER_LIST", index, "COLLECTION_TYPE").equalsIgnoreCase(collectionType))
					sameCollectionTypeCount++;
			}
			if (sameCollectionTypeCount == 1) {
				for (int index = 0; index < iMap.getSize("CONCENTRATION_ACCOUNTS"); index++) {
					if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("CONCENTRATION_ACCOUNTS", index, "ACCOUNT_DEFINITION_TYPE"))) {
						if (iMap.getString("SUBSCRIBER_ISUPT").equalsIgnoreCase("DEL") && iMap.getString("CONCENTRATION_ACCOUNTS", index, "COLLECTION_TYPE").equalsIgnoreCase(collectionType)) {
							oMap.put("OPERATION", false);
							oMap.put("MESSAGE", "Hesap y�netim bilgilerinde �deme tipi kullan�l�yor.\n��kar�lan �deme tipi ile ilgili Hesap y�netimden bu �deme tipini ��karmal�s�n�z! ");
							break;
						}
						if (iMap.getString("SUBSCRIBER_ISUPT").equalsIgnoreCase("UPT") && iMap.getString("CONCENTRATION_ACCOUNTS", index, "COLLECTION_TYPE").equalsIgnoreCase(collectionType) && !collectionType.equalsIgnoreCase(iMap.getString("COLLECTION_NO"))) {
							oMap.put("OPERATION", false);
							oMap.put("MESSAGE", "Hesap y�netim bilgilerinde �deme tipi kullan�l�yor.\n��kar�lan �deme tipi ile ilgili Hesap y�netimden bu �deme tipini ��karmal�s�n�z! ");
							break;
						}
					}

				}
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	@GraymoundService("CDM_LOAD_SERVER_INVOICE_IMAGE")
	public static GMMap loadServerInvoiceImage(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String serverFilePath = null;
			if (StringUtils.isNotBlank(iMap.getString("FILE"))) {
				serverFilePath = copyFileToServerTemp(iMap.get("FILE"), iMap.get("FILE_NAME"));
			}
			oMap.putAll(getImage(serverFilePath));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getImage(String filePath) {
		GMMap oMap = new GMMap();
		String fotoBase64 = null;

		try {
			if (filePath != null) {
				BufferedImage foto = null;
				try {
					foto = ImageIO.read(new File(filePath));
					fotoBase64 = getBufferedImageAsString(foto);
				} catch (IOException e) {
					logger.error(e);
					fotoBase64 = null;
				}
			}
			oMap.put("INVOICE_IMAGE_BASE64", "data:image/jpeg;base64," + fotoBase64);
			if (fotoBase64 == null) {
				oMap.put("INVOICE_IMAGE", fotoBase64);
			} else {
				oMap.put("INVOICE_IMAGE", "data:image/jpeg;base64," + fotoBase64);
			}
		} catch (Exception e) {
			logger.error(e);
			oMap.put("INVOICE_IMAGE", fotoBase64);
			oMap.put("INVOICE_IMAGE_BASE64", fotoBase64);
		}

		return oMap;
	}

	private static String getBufferedImageAsString(BufferedImage foto) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(foto, "jpg", baos);
		baos.flush();
		byte[] imageBytes = baos.toByteArray();
		baos.close();
		String base64ImgStr = Base64.encode(imageBytes);
		base64ImgStr = base64ImgStr.trim().replaceAll("\n", "");
		return base64ImgStr;
	}

	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	public static String copyFileToServerTemp(Object file, Object fileName) {

		InputStream inputStream = null;
		OutputStream outputStream = null;
		String serverPath = null;
		try {
			inputStream = new ByteArrayInputStream((byte[]) file);
			File destFile = new File(ROOT + File.separator + "files" + File.separator + fileName);
			outputStream = new FileOutputStream(destFile);
			IOUtils.copy(inputStream, outputStream);
			serverPath = destFile.getAbsoluteFile().toString();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			try {
				if (outputStream != null) {
					outputStream.close();
				}
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (IOException e) {
				logger.error(e);
			}
		}

		return serverPath;
	}

	@SuppressWarnings("unchecked")
	public static void saveInvoiceImage(Session session, String corporateOid, String maskOid, GMMap rowMap) throws Exception {
		List<invoiceimageTx> invoiceimageList = session.createCriteria(invoiceimageTx.class).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("maskOid", maskOid)).add(Restrictions.eq("status", true)).list();
		for (int row = 0; row < invoiceimageList.size(); row++) {
			invoiceimageList.get(row).setStatus(false);
			session.saveOrUpdate(invoiceimageList.get(row));
		}
		// TODO �st methoda ala�naca
		if (StringUtils.isNotBlank(rowMap.getString("INVOICE_IMAGE"))) {
			String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			invoiceimageTx iimage = new invoiceimageTx();
			iimage.setCorporateOid(corporateOid);
			iimage.setMaskOid(maskOid);
			iimage.setCollectionType(Short.valueOf(rowMap.getString("COLLECTION_TYPE")).shortValue());
			java.sql.Blob blob = org.hibernate.Hibernate.createBlob(rowMap.getString("INVOICE_IMAGE").getBytes());
			iimage.setInvoiceImageBasecode64(blob);
			iimage.setCreateUser(username);
			iimage.setCreateDate(sdf.format(new Date()));
			iimage.setStatus(true);
			session.saveOrUpdate(iimage);
		}
	}

	@GraymoundService("CDM_CITY_CHANGE")
	public static GMMap changeCity(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBoolean("ALL_CITY")) {
				oMap.putAll(ServiceExecuter.call("CDM_GET_GENERAL_CITIES", iMap));
				oMap.put("ALL_CITY", true);
			} else {
				oMap.put("ALL_CITY", false);
				oMap.put("CITIES", iMap.get("CITIES"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_CHANNEL_SOURCE")
	public static GMMap getChannelSource(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(ServiceExecuter.call("CDM_GET_SOURCES", iMap));
			oMap.putAll(ServiceExecuter.call("CDM_GET_CHANNELS", iMap));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_SHOW_ROW_CONTACT")
	public static GMMap showRowCorporateContact(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMap = new GMMap();
		try {
			rowMap = iMap.getMap("CONTACT_ROW");
			oMap.put("NAME_SURNAME", rowMap.getString("NAME_SURNAME"));
			oMap.put("DEPARTMENT_ID", rowMap.getString("DEPARTMENT_ID"));
			oMap.put("DEPARTMENT", rowMap.getString("DEPARTMENT"));
			oMap.put("PHONE_NUMBER", rowMap.getString("PHONE_NUMBER"));
			oMap.put("MOBILE", rowMap.getString("MOBILE"));
			oMap.put("EMAIL", rowMap.getString("EMAIL"));
			oMap.put("FAX", rowMap.getString("FAX"));
			oMap.put("NOTE", rowMap.getString("NOTE"));
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("CDM_ADD_UPT_CONTACT")
	public static GMMap addOrUptRowContact(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = validationContact(iMap);
			if (oMap.getBoolean("OPERATION")) {
				GMMap rowMap = new GMMap();
				rowMap.put("NAME_SURNAME", iMap.getString("NAME_SURNAME"));
				rowMap.put("DEPARTMENT_ID", iMap.getString("DEPARTMENT_ID"));
				rowMap.put("DEPARTMENT", iMap.getString("DEPARTMENT"));
				rowMap.put("PHONE_NUMBER", iMap.getString("PHONE_NUMBER"));
				rowMap.put("MOBILE", iMap.getString("MOBILE"));
				rowMap.put("EMAIL", iMap.getString("EMAIL"));
				rowMap.put("FAX", iMap.getString("FAX"));
				rowMap.put("NOTE", iMap.getString("NOTE"));
				oMap.put("CONTACT_ROW_DATA", rowMap);
			}
			if (iMap.get("CONTACT_SELECTED_ROW") != null)
				oMap.put("RESULT_ACTION", "UPT");
			else
				oMap.put("RESULT_ACTION", "ADD");
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	public static GMMap validationContact(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {
			if (StringUtils.isBlank(iMap.getString("NAME_SURNAME")) || (!checkNameSurname(iMap.getString("NAME_SURNAME")))) {
				validationExtra("NAME_SURNAME", oMap, "L�tfen Ad soyad alan�n� uygun olarak doldurunuz!");
				return oMap;
			}
			if ((StringUtils.isNotBlank(iMap.getString("EMAIL")) && !CommonHelper.isValidEmailAddress(iMap.getString("EMAIL")))) {
				validationExtra("EMAIL", oMap, "L�tfen Email alan�n� uygun olarak doldurunuz!");
				return oMap;
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static boolean checkNameSurname(String nameSurname) {
		for (char ch : nameSurname.toCharArray()) {
			if (!(Character.isLetter(ch) || Character.isSpaceChar(ch))) {
				return false;
			}
		}
		return true;
	}

	@GraymoundService("CDM_ADD_UPT_CHANNEL_SOURCE")
	public static GMMap addOrUptRowChannelSource(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = validationChannelSource(iMap);
			if (oMap.getBoolean("OPERATION")) {
				GMMap rowMap = new GMMap();
				String addSources = getColumnValue(iMap, "SOURCES", "SOURCE_CODE");
				String addChannels = getColumnValue(iMap, "CHANNELS", "CHANNEL_CODE");
				String addSourceNames = getColumnValue(iMap, "SOURCES", "SOURCE_NAME");
				String addChannelNames = getColumnValue(iMap, "CHANNELS", "CHANNEL_NAME");
				rowMap.put("SOURCE_CODE", addSources);
				rowMap.put("SOURCE_NAME", addSourceNames);
				rowMap.put("CHANNEL_CODE", addChannels);
				rowMap.put("CHANNEL_NAME", addChannelNames);
				rowMap.put("WORKINGDAY_START_TIME", convertDateToFormat(iMap.getString("WORKINGDAY_START_TIME"), "HHmm", "HH:mm", "00:00"));
				rowMap.put("WORKINGDAY_END_TIME", convertDateToFormat(iMap.getString("WORKINGDAY_END_TIME"), "HHmm", "HH:mm", "00:00"));
				rowMap.put("HOLIDAY_START_TIME", convertDateToFormat(iMap.getString("HOLIDAY_START_TIME"), "HHmm", "HH:mm", "00:00"));
				rowMap.put("HOLIDAY_END_TIME", convertDateToFormat(iMap.getString("HOLIDAY_END_TIME"), "HHmm", "HH:mm", "00:00"));
				rowMap.put("CLOSED_DATE_START", convertDateToFormat(iMap.getString("CLOSED_DATE_START"), "ddMMyyyyHHmm", "dd.MM.yyyy HH:mm", ""));
				rowMap.put("CLOSED_DATE_END", convertDateToFormat(iMap.getString("CLOSED_DATE_END"), "ddMMyyyyHHmm", "dd.MM.yyyy HH:mm", ""));
				rowMap.put("EXPLANATION", iMap.getString("EXPLANATION"));
				rowMap.put("CLOSED_DATE", iMap.getString("CLOSED_DATE"));
				rowMap.put("CLOSED_DATE_ALL", iMap.getString("CLOSED_DATE_ALL"));
				oMap.put("CHANNEL_SOURCE_ROW_DATA", rowMap);
				GMMap rowMapChoose = iMap.getMap("CHANNEL_SOURCE_ROW");
				if (rowMapChoose != null) {
					uptChannelSourceOnAccountAndAccTransfer(iMap, oMap, addSources, addChannels, addSourceNames, addChannelNames);
				} else {
					oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
					oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
				}
			} else {
				oMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
				oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	private static void uptChannelSourceOnAccountAndAccTransfer(GMMap iMap, GMMap oMap, String addSources, String addChannels, String addSourceNames, String addChannelNames) throws Exception {
		GMMap tempMap = new GMMap();
		tempMap.put("ACCOUNTS_DATA", iMap.get("ACCOUNTS_DATA"));
		tempMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
		GMMap rowMapChoose = iMap.getMap("CHANNEL_SOURCE_ROW");
		List<String> selectedSourceList = Arrays.asList(rowMapChoose.getString("SOURCE_CODE").split(","));
		List<String> addSourceList = Arrays.asList(addSources.split(","));
		List<String> differentSourceList = new ArrayList<String>();
		for (String selectedSource : selectedSourceList) {
			if (!addSourceList.contains(selectedSource)) {
				differentSourceList.add(selectedSource);
			}
		}
		List<String> selectedChannelList = Arrays.asList(rowMapChoose.getString("CHANNEL_CODE").split(","));
		List<String> addChannelList = Arrays.asList(addChannels.split(","));
		List<String> differentChannelList = new ArrayList<String>();
		for (String selectedChannel : selectedChannelList) {
			if (!addChannelList.contains(selectedChannel)) {
				differentChannelList.add(selectedChannel);
			}
		}
		List<String> difSourceChannelList = new ArrayList<String>();
		for (String selectedSource : selectedSourceList) {
			for (String difChannel : differentChannelList) {
				difSourceChannelList.add(selectedSource + "<->" + difChannel);
			}
		}

		for (String difSource : differentSourceList) {
			for (String selectedChannel : selectedChannelList) {
				difSourceChannelList.add(difSource + "<->" + selectedChannel);
			}
		}

		List<String> selectedSourceNameList = Arrays.asList(rowMapChoose.getString("SOURCE_NAME").split(","));
		List<String> addSourceNameList = Arrays.asList(addSourceNames.split(","));
		List<String> differentSourceNameList = new ArrayList<String>();
		for (String selectedSourceName : selectedSourceNameList) {
			if (!addSourceNameList.contains(selectedSourceName)) {
				differentSourceNameList.add(selectedSourceName);
			}
		}
		List<String> selectedChannelNameList = Arrays.asList(rowMapChoose.getString("CHANNEL_NAME").split(","));
		List<String> addChannelNameList = Arrays.asList(addChannelNames.split(","));
		List<String> differentChannelNameList = new ArrayList<String>();
		for (String selectedChannelName : selectedChannelNameList) {
			if (!addChannelNameList.contains(selectedChannelName)) {
				differentChannelNameList.add(selectedChannelName);
			}
		}
		List<String> difSourceChannelNameList = new ArrayList<String>();

		for (String selectedSourceName : selectedSourceNameList) {
			for (String difChannelName : differentChannelNameList) {
				difSourceChannelNameList.add(selectedSourceName + "<->" + difChannelName);
			}
		}
		for (String difSourceName : differentSourceNameList) {
			for (String selectedChannelName : selectedChannelNameList) {
				difSourceChannelNameList.add(difSourceName + "<->" + selectedChannelName);
			}
		}
		int accountRow = -1;
		for (int row = 0; row < iMap.getSize("ACCOUNTS_DATA"); row++) {

			if (StringUtils.isNotBlank(iMap.getString("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_CODE"))) {
				String changeSourceChannels = "", changeSourceChannelNames = "";
				List<String> accountChannelSourceCodeList = new ArrayList<String>();
				List<String> accountChannelSourceNameList = new ArrayList<String>();
				List<String> accountChannelSourceCodes = Arrays.asList(iMap.getString("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_CODE").split(","));
				List<String> accountChannelSourceNames = Arrays.asList(iMap.getString("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_NAME").split(","));
				for (String accountChannelSourceCode : accountChannelSourceCodes) {
					if (!difSourceChannelList.contains(accountChannelSourceCode)) {
						accountChannelSourceCodeList.add(accountChannelSourceCode);
					}
				}
				for (int i = 0; i < accountChannelSourceCodeList.size(); i++) {
					changeSourceChannels = changeSourceChannels + accountChannelSourceCodeList.get(i) + (i < accountChannelSourceCodeList.size() - 1 ? "," : "");
				}

				for (String accountChannelSourceName : accountChannelSourceNames) {
					if (!difSourceChannelNameList.contains(accountChannelSourceName)) {
						accountChannelSourceNameList.add(accountChannelSourceName);
					}
				}
				for (int i = 0; i < accountChannelSourceNameList.size(); i++) {
					changeSourceChannelNames = changeSourceChannelNames + accountChannelSourceNameList.get(i) + (i < accountChannelSourceNameList.size() - 1 ? "," : "");
				}
				if (StringUtils.isNotBlank(changeSourceChannels)) {
					tempMap.put("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_CODE", changeSourceChannels);
					tempMap.put("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_NAME", changeSourceChannelNames);
					accountRow++;
					oMap.put("ACCOUNTS_DATA", accountRow, tempMap.getMap("ACCOUNTS_DATA", row));
				}
			} else {
				tempMap.put("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_CODE", "");
				tempMap.put("ACCOUNTS_DATA", row, "CHANNEL_SOURCE_NAME", "");
				accountRow++;
				oMap.put("ACCOUNTS_DATA", accountRow, tempMap.getMap("ACCOUNTS_DATA", row));
			}
		}

		int accountTransferRow = -1;
		for (int row = 0; row < iMap.getSize("ACCOUNT_TRANSFERS_DATA"); row++) {

			if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID"))) {
				String collectionChangeSourceChannels = "", collectionChangeSourceChannelNames = "";
				List<String> accountCollectionChannelSourceCodeList = new ArrayList<String>();
				List<String> accountCollectionChannelSourceNameList = new ArrayList<String>();
				List<String> accountChannelSourceCodes = Arrays.asList(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID").split(","));
				List<String> accountChannelSourceNames = Arrays.asList(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE").split(","));

				for (String accountChannelSourceCode : accountChannelSourceCodes) {
					String[] accountChannelSourceCodeArr = accountChannelSourceCode.split("<->");
					if (!difSourceChannelList.contains(accountChannelSourceCodeArr[1] + "<->" + accountChannelSourceCodeArr[2])) {
						accountCollectionChannelSourceCodeList.add(accountChannelSourceCode);
					}
				}
				for (int i = 0; i < accountCollectionChannelSourceCodeList.size(); i++) {
					collectionChangeSourceChannels = collectionChangeSourceChannels + accountCollectionChannelSourceCodeList.get(i) + (i < accountCollectionChannelSourceCodeList.size() - 1 ? "," : "");
				}

				for (String accountChannelSourceName : accountChannelSourceNames) {
					String[] accountChannelSourceNameArr = accountChannelSourceName.replace("(", "").replace(")", "").split("<->");
					if (!(difSourceChannelNameList).contains(accountChannelSourceNameArr[1] + "<->" + accountChannelSourceNameArr[2])) {
						accountCollectionChannelSourceNameList.add(accountChannelSourceName);
					}
				}
				for (int i = 0; i < accountCollectionChannelSourceNameList.size(); i++) {
					collectionChangeSourceChannelNames = collectionChangeSourceChannelNames + accountCollectionChannelSourceNameList.get(i) + (i < accountCollectionChannelSourceNameList.size() - 1 ? "," : "");
				}
				if (StringUtils.isNotBlank(collectionChangeSourceChannels)) {
					tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID", collectionChangeSourceChannels);
					tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE", collectionChangeSourceChannelNames);
					accountTransferRow++;
					oMap.put("ACCOUNT_TRANSFERS_DATA", accountTransferRow, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
				}
			} else {
				tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID", "");
				tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE", "");
				accountTransferRow++;
				oMap.put("ACCOUNT_TRANSFERS_DATA", accountTransferRow, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
			}
		}

	}

	private static boolean checkUsingChannelSourceOnAccount(GMMap iMap, List<String> channelSourceParamList, String tableName, String columnName, int index) {
		boolean channelHave = false;
		for (int i = 0; i < iMap.getSize(tableName); i++) {
			if (StringUtils.isNotBlank(iMap.getString(tableName, i, columnName))) {
				List<String> channelSourceList = Arrays.asList(iMap.getString(tableName, i, columnName).split(","));
				for (String channelSource : channelSourceList) {
					if (channelSourceParamList.contains(channelSource.split("<->")[index])) {
						channelHave = true;
						break;
					}
				}
				if (channelHave)
					break;
			}
		}
		return channelHave;
	}

	@GraymoundService("CDM_CHANNEL_SOURCE_ALL_CLOSED_DATE")
	public static GMMap appAllClosedDate(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("CHANNELS_SOURCES", iMap);
			String startTime = convertDateToFormat(iMap.getString("CLOSED_DATE_START"), "ddMMyyyyHHmm", "dd.MM.yyyy HH:mm", "");
			String endTime = convertDateToFormat(iMap.getString("CLOSED_DATE_END"), "ddMMyyyyHHmm", "dd.MM.yyyy HH:mm", "");
			String explanation = iMap.getString("EXPLANATION");

			for (int row = 0; row < iMap.getSize("CHANNELS_SOURCES"); row++) {
				oMap.put("CHANNELS_SOURCES", row, "SOURCE_CODE", iMap.getString("CHANNELS_SOURCES", row, "SOURCE_CODE"));
				oMap.put("CHANNELS_SOURCES", row, "CHANNEL_CODE", iMap.getString("CHANNELS_SOURCES", row, "CHANNEL_CODE"));
				oMap.put("CHANNELS_SOURCES", row, "SOURCE_NAME", iMap.getString("CHANNELS_SOURCES", row, "SOURCE_NAME"));
				oMap.put("CHANNELS_SOURCES", row, "CHANNEL_NAME", iMap.getString("CHANNELS_SOURCES", row, "CHANNEL_NAME"));
				oMap.put("CHANNELS_SOURCES", row, "WORKINGDAY_START_TIME", iMap.getString("CHANNELS_SOURCES", row, "WORKINGDAY_START_TIME"));
				oMap.put("CHANNELS_SOURCES", row, "WORKINGDAY_END_TIME", iMap.getString("CHANNELS_SOURCES", row, "WORKINGDAY_END_TIME"));
				oMap.put("CHANNELS_SOURCES", row, "HOLIDAY_START_TIME", iMap.getString("CHANNELS_SOURCES", row, "HOLIDAY_START_TIME"));
				oMap.put("CHANNELS_SOURCES", row, "HOLIDAY_END_TIME", iMap.getString("CHANNELS_SOURCES", row, "HOLIDAY_END_TIME"));
				if (iMap.getBoolean("CLOSED_DATE_ALL")) {
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE", iMap.getBoolean("CLOSED_DATE"));
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE_START", startTime);
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE_END", endTime);
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE_ALL", iMap.getBoolean("CLOSED_DATE_ALL") && iMap.getBoolean("CLOSED_DATE"));
					oMap.put("CHANNELS_SOURCES", row, "EXPLANATION", explanation);
				} else {
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE", iMap.getString("CHANNELS_SOURCES", row, "CLOSED_DATE"));
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE_START", iMap.getString("CHANNELS_SOURCES", row, "CLOSED_DATE_START"));
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE_END", iMap.getString("CHANNELS_SOURCES", row, "CLOSED_DATE_END"));
					oMap.put("CHANNELS_SOURCES", row, "CLOSED_DATE_ALL", false);
					oMap.put("CHANNELS_SOURCES", row, "EXPLANATION", iMap.getString("CHANNELS_SOURCES", row, "EXPLANATION"));
				}
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static String getColumnValue(GMMap iMap, String tableName, String columnName) {
		String returnValue = "";
		for (int index = 0; index < iMap.getSize(tableName); index++) {
			if (iMap.getBoolean(tableName, index, "SEC")) {
				returnValue = returnValue + iMap.getString(tableName, index, columnName) + ",";
			}
		}
		if (StringUtils.isNotBlank(returnValue))
			returnValue = returnValue.substring(0, returnValue.length() - 1);
		return returnValue;
	}

	private static GMMap validationChannelSource(GMMap iMap) {
		GMMap oMap = new GMMap();
		final String timePattern = "([01]?[0-9]|2[0-3])[0-5][0-9]";
		final String dateTimePattern = "(0?[1-9]|[12][0-9]|3[01])(0?[1-9]|1[012])((19|20)\\d\\d)([01]?[0-9]|2[0-3])[0-5][0-9]";
		List<String> channelNameList = new ArrayList<String>();
		List<String> sourceNameList = new ArrayList<String>();
		oMap.put("OPERATION", true);
		try {
			for (int index = 0; index < iMap.getSize("SOURCES"); index++) {
				if (iMap.getBoolean("SOURCES", index, "SEC")) {
					sourceNameList.add(iMap.getString("SOURCES", index, "SOURCE_NAME"));
				}
			}
			for (int row = 0; row < iMap.getSize("CHANNELS"); row++) {
				if (iMap.getBoolean("CHANNELS", row, "SEC")) {
					channelNameList.add(iMap.getString("CHANNELS", row, "CHANNEL_NAME"));
				}
			}
			for (int row = 0; row < iMap.getSize("CHANNEL_SOURCE_LIST"); row++) {
				List<String> existingChannels = Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", row, "CHANNEL_NAME").split(","));
				for (String newChannel : channelNameList) {
					if (existingChannels.contains(newChannel)) {
						List<String> existingSources = Arrays.asList(iMap.getString("CHANNEL_SOURCE_LIST", row, "SOURCE_NAME").split(","));
						for (String newSource : sourceNameList) {
							if (existingSources.contains(newSource) && (iMap.getInt("CHANNELS_SOURCES_SELECTED_ROW") != row)) {
								validationExtra("CHANNELS", oMap, "Daha �nce tan�mlanm�� kanal/ kaynak bulunmaktad�r");
								return oMap;
							}
						}
					}
				}
			}
			if (sourceNameList.size() <= 0) {
				validationExtra("SOURCES", oMap, "L�tfen en az bir kaynak se�iniz");
				return oMap;
			}
			if (channelNameList.size() <= 0) {
				validationExtra("CHANNELS", oMap, "L�tfen en az bir kanal se�iniz");
				return oMap;
			}

			String startTime = iMap.getString("WORKINGDAY_START_TIME");
			validationDomain(iMap, "WORKINGDAY_START_TIME", oMap, "L�tfen i� g�n� ba�lang�� saatini giriniz");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			if (!checkToDateTimeWithPattern(startTime, timePattern, true)) {
				validationExtra("WORKINGDAY_START_TIME", oMap, "L�tfen i� g�n� ba�lang�� saatini do�ru giriniz");
				return oMap;
			}
			String endTime = iMap.getString("WORKINGDAY_END_TIME");
			validationDomain(iMap, "WORKINGDAY_END_TIME", oMap, "L�tfen i� g�n� biti� saatini giriniz");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			if (!checkToDateTimeWithPattern(endTime, timePattern, true)) {
				validationExtra("WORKINGDAY_END_TIME", oMap, "L�tfen i� g�n� biti� saatini do�ru giriniz");
				return oMap;
			}
			startTime = convertDateToFormat(startTime, "HHmm", "HH:mm", "00:00");
			endTime = convertDateToFormat(endTime, "HHmm", "HH:mm", "00:00");
			if (!validateDateTime(startTime, endTime, "WORKINGDAY_START_TIME", "WORKINGDAY_END_TIME", oMap, "HH:mm", true, "00:00")) {
				validationExtra("WORKINGDAY_START_TIME", oMap, "L�tfen i� g�n� a��k saatlerini, ba�lang�� saati biti� tarihinden k���k olacak �ekilde giriniz!");
				return oMap;
			}

			startTime = iMap.getString("HOLIDAY_START_TIME");
			endTime = iMap.getString("HOLIDAY_END_TIME");
			if (!checkToDateTimeWithPattern(startTime, timePattern, false)) {
				validationExtra("HOLIDAY_START_TIME", oMap, "L�tfen tatil g�n� ba�lang�� saatini do�ru giriniz");
				return oMap;
			}
			if (!checkToDateTimeWithPattern(endTime, timePattern, false)) {
				validationExtra("HOLIDAY_END_TIME", oMap, "L�tfen tatil g�n� biti� saatini do�ru giriniz");
				return oMap;
			}
			startTime = convertDateToFormat(startTime, "HHmm", "HH:mm", "");
			endTime = convertDateToFormat(endTime, "HHmm", "HH:mm", "");
			if (!validateDateTime(startTime, endTime, "HOLIDAY_START_TIME", "HOLIDAY_END_TIME", oMap, "HH:mm", false, "00:00")) {
				validationExtra("HOLIDAY_START_TIME", oMap, "L�tfen tatil g�n� a��k saatleri ba�lang�� saati biti� tarihinden k���k olmal�!");
				return oMap;
			}

			if (StringUtils.isNotBlank(iMap.getString("CLOSED_DATE")) && iMap.getBoolean("CLOSED_DATE")) {
				startTime = iMap.getString("CLOSED_DATE_START");
				endTime = iMap.getString("CLOSED_DATE_END");
				validationDomain(iMap, "CLOSED_DATE_START", oMap, "L�tfen Kapal� tarih aral��� sekmesini se�ti�izde Ba�lang�� Tarihi ve Saati alan�n� doldurmals�n�z");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;
				validationDomain(iMap, "CLOSED_DATE_END", oMap, "L�tfen Kapal� tarih aral��� sekmesini se�ti�izde Biti� Tarihi ve Saati alan�n� doldurmals�n�z");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;
				if (!checkToDateTimeWithPattern(startTime, dateTimePattern, false)) {
					validationExtra("HOLIDAY_START_TIME", oMap, "L�tfen Kapal� Tarih Aral���n� se�ili durumda iken Ba�lang�� Tarihi ve Saati`ni do�ru girmelisiniz!");
					return oMap;
				}
				if (!checkToDateTimeWithPattern(endTime, dateTimePattern, false)) {
					validationExtra("HOLIDAY_END_TIME", oMap, "L�tfen Kapal� Tarih Aral���n� se�ili durumda iken Ba�lang�� Tarihi ve Saati`ni do�ru girmelisiniz!");
					return oMap;
				}
				startTime = convertDateToFormat(startTime, "ddMMyyyyHHmm", "dd.MM.yyyy HH:mm", "010119700000");
				endTime = convertDateToFormat(endTime, "ddMMyyyyHHmm", "dd.MM.yyyy HH:mm", "010119700000");
				if (!validateDateTime(startTime, endTime, "HOLIDAY_START_TIME", "HOLIDAY_END_TIME", oMap, "dd.MM.yyyy HH:mm", false, "")) {
					validationExtra("HOLIDAY_START_TIME", oMap, "Kapal� Tarih Aral��� i�in; ba�lang�� tarih ve saati, biti� tarih ve saatinden k���k olmal�d�r!");
					return oMap;
				}
				if (CommonHelper.getDateTime(startTime, "dd.MM.yyyy HH:mm").before(new Date())) {
					validationExtra("CLOSED_DATE_START", oMap, "Kapal� tarih aral��� ileri bir tarih olmal�d�r!");
					return oMap;
				}

			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static String convertDateToFormat(String dateTime, String inFormat, String outFormat, String defaultValue) {
		SimpleDateFormat parser = new SimpleDateFormat(inFormat);
		SimpleDateFormat parser2 = new SimpleDateFormat(outFormat);
		String dateTimeReturn = StringUtils.isNotBlank(defaultValue) ? defaultValue : "";
		try {
			dateTimeReturn = StringUtils.isNotBlank(dateTime) ? parser2.format(parser.parse(dateTime)) : dateTimeReturn;
		} catch (Exception e) {
			dateTimeReturn = StringUtils.isNotBlank(defaultValue) ? defaultValue : "";
		}
		return dateTimeReturn;
	}

	private static boolean checkToDateTimeWithPattern(String dateTime, String patternValue, boolean must) {
		Pattern pattern = Pattern.compile(patternValue);
		if (!must && StringUtils.isBlank(dateTime))
			return true;
		if (pattern.matcher(dateTime).matches())
			return true;
		return false;
	}

	private static boolean validateDateTime(String startTime, String endTime, String startTimeName, String endTimeName, GMMap oMap, String format, boolean mustDomain, String defaultValue) {
		SimpleDateFormat parser = new SimpleDateFormat(format);
		try {
			if (!mustDomain && ((defaultValue.equals(startTime) && defaultValue.equals(endTime)) || (StringUtils.isBlank(startTime) && StringUtils.isBlank(endTime))))
				return true;
			if (parser.parse(startTime).before(parser.parse(endTime))) {
				return true;
			}
			oMap.put(startTimeName, startTime);
			oMap.put(endTimeName, endTime);
		} catch (ParseException e) {
			return false;
		}
		return false;
	}

	@GraymoundService("CDM_CHANNEL_BRANCH_CHECK")
	public static GMMap checkChannelBranch(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			final int channelBranchCode = 1;
			final int sourceCasingCode = 1;
			int channelChooseCount = 0;
			oMap.put("OPERATION", true);
			for (int index = 0; index < iMap.getSize("SOURCES"); index++) {
				if (iMap.getBoolean("SOURCES", index, "SEC") && iMap.getInt("SOURCES", index, "SOURCE_CODE") == sourceCasingCode) {
					for (int row = 0; row < iMap.getSize("CHANNELS"); row++) {
						if (iMap.getBoolean("CHANNELS", row, "SEC") && iMap.getInt("CHANNELS", row, "CHANNEL_CODE") == channelBranchCode) {
							oMap.put("CHANNELS", row, "SEC", "1");
							channelChooseCount--;
						} else {
							oMap.put("CHANNELS", row, "SEC", "0");
						}
						if (iMap.getBoolean("CHANNELS", row, "SEC")) {
							channelChooseCount++;
						}
						oMap.put("CHANNELS", row, "CHANNEL_CODE", iMap.getString("CHANNELS", row, "CHANNEL_CODE"));
						oMap.put("CHANNELS", row, "CHANNEL_NAME", iMap.getString("CHANNELS", row, "CHANNEL_NAME"));
					}
				}
			}
			if (oMap.getSize("CHANNELS") <= 0) {
				oMap.put("CHANNELS", iMap.get("CHANNELS"));
			} else {
				if (channelChooseCount >= 1) {
					oMap.put("OPERATION", false);
					oMap.put("MESSAGE", "Kasa se�imi yap�ld���nda sadece �ube se�ebilirsiniz");
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_SOURCE_CASING_CHECK")
	public static GMMap checkSourceCasing(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			final int channelBranchCode = 1;
			final int sourceCasingCode = 1;
			int channelChooseCount = 0;
			oMap.put("OPERATION", true);
			for (int index = 0; index < iMap.getSize("SOURCES"); index++) {
				if (iMap.getBoolean("SOURCES", index, "SEC") && iMap.getInt("SOURCES", index, "SOURCE_CODE") == sourceCasingCode) {
					for (int row = 0; row < iMap.getSize("CHANNELS"); row++) {
						if (iMap.getBoolean("CHANNELS", row, "SEC") && iMap.getInt("CHANNELS", row, "CHANNEL_CODE") == channelBranchCode) {
							oMap.put("CHANNELS", row, "SEC", "1");
							channelChooseCount--;
						} else {
							oMap.put("CHANNELS", row, "SEC", "0");
						}
						if (iMap.getBoolean("CHANNELS", row, "SEC")) {
							channelChooseCount++;
						}
						oMap.put("CHANNELS", row, "CHANNEL_CODE", iMap.getString("CHANNELS", row, "CHANNEL_CODE"));
						oMap.put("CHANNELS", row, "CHANNEL_NAME", iMap.getString("CHANNELS", row, "CHANNEL_NAME"));
					}
				}
			}
			if (oMap.getSize("CHANNELS") <= 0) {
				oMap.put("CHANNELS", iMap.get("CHANNELS"));
			} else {
				if (channelChooseCount >= 1) {
					oMap.put("OPERATION", false);
					oMap.put("MESSAGE", "Kasa se�imi yap�ld���nda sadece �ube se�ebilirsiniz");
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_SHOW_ROW_ACCOUNT")
	public static GMMap showRowCorporateAccount(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMap = new GMMap();
		try {
			rowMap = iMap.getMap("ACCOUNT_ROW_DATA");
			oMap.put("ACCOUNT_BUILD_SINGLE", DatabaseConstants.ConcentrationTypes.SingleConcentration.equalsIgnoreCase(rowMap.getString("CONCENTRATION_TYPE")) ? true : false);
			oMap.put("ACCOUNT_BUILD_PLURAL", DatabaseConstants.ConcentrationTypes.MultiConcentration.equalsIgnoreCase(rowMap.getString("CONCENTRATION_TYPE")) ? true : false);
			oMap.put("ACCOUNT_DEFINITION_TYPE", rowMap.getString("ACCOUNT_DEFINITION_TYPE"));
			oMap.put("ACCOUNT_NUMBER", rowMap.getString("ACCOUNT_NUMBER"));
			oMap.put("ACCOUNT_NAME", rowMap.getString("ACCOUNT_NAME"));
			oMap.put("DEFAULT_AMOUNT", rowMap.getString("DEFAULT_AMOUNT"));
			oMap.put("IBAN", rowMap.getString("IBAN"));
			oMap.put("ACCOUNT_OWNER", rowMap.getString("ACCOUNT_OWNER"));
			if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(rowMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
				getAccountChooseCollectionType(iMap, rowMap, oMap);
				getAccountChooseChannelSource(iMap, rowMap, oMap);
				if (DatabaseConstants.ConcentrationTypes.MultiConcentration.equalsIgnoreCase(rowMap.getString("CONCENTRATION_TYPE"))) {
					getAccountChooseSubscriberMatch(iMap, rowMap, oMap);
				}
			} else {
				oMap.put("ACCOUNT_COLLECTION_TYPES", iMap.get("ACCOUNT_COLLECTION_TYPES"));
				oMap.put("ACCOUNT_CHANNELS_SOURCES", iMap.get("ACCOUNT_CHANNELS_SOURCES"));
				oMap.put("SUBSCRIBER_MATCH_LIST", iMap.get("SUBSCRIBER_MATCH_LIST"));
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static void getAccountChooseSubscriberMatch(GMMap iMap, GMMap rowMap, GMMap oMap) {
		List<String> subscriberMatches = Arrays.asList(rowMap.getString("TREE_LIST").split(","));
		for (int j = 0; j < iMap.getSize("SUBSCRIBER_MATCH_LIST"); j++) {
			boolean hadSubscriberMatches = false;
			for (String subscriberMatche : subscriberMatches) {
				if (subscriberMatche.equalsIgnoreCase(iMap.getString("SUBSCRIBER_MATCH_LIST", j, "DEFINITION_ID"))) {
					hadSubscriberMatches = true;
					break;
				}
			}
			iMap.put("SUBSCRIBER_MATCH_LIST", j, "CHOOSE", hadSubscriberMatches);
		}
		oMap.put("SUBSCRIBER_MATCH_LIST", iMap.get("SUBSCRIBER_MATCH_LIST"));
	}

	private static void getAccountChooseChannelSource(GMMap iMap, GMMap rowMap, GMMap oMap) {
		if (StringUtils.isNotBlank(rowMap.getString("CHANNEL_SOURCE_CODE"))) {
			List<String> channelSources = Arrays.asList(rowMap.getString("CHANNEL_SOURCE_CODE").split(","));
			for (int j = 0; j < iMap.getSize("ACCOUNT_CHANNELS_SOURCES"); j++) {
				boolean hadChannelSource = false;
				for (String channelSource : channelSources) {
					if (channelSource.equalsIgnoreCase(iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "SOURCE_CODE") + "<->" + iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "CHANNEL_CODE"))) {
						hadChannelSource = true;
						break;
					}
				}
				iMap.put("ACCOUNT_CHANNELS_SOURCES", j, "CHOOSE", hadChannelSource);
			}
		}
		oMap.put("ACCOUNT_CHANNELS_SOURCES", iMap.get("ACCOUNT_CHANNELS_SOURCES"));
	}

	private static void getAccountChooseCollectionType(GMMap iMap, GMMap rowMap, GMMap oMap) {
		if (StringUtils.isNotBlank(rowMap.getString("COLLECTION_TYPE"))) {
			List<String> collectionTypes = Arrays.asList(rowMap.getString("COLLECTION_TYPE").split(","));
			for (int j = 0; j < iMap.getSize("ACCOUNT_COLLECTION_TYPES"); j++) {
				boolean hadcollectionType = false;
				for (String collectionType : collectionTypes) {
					if (collectionType.equalsIgnoreCase(iMap.getString("ACCOUNT_COLLECTION_TYPES", j, "COLLECTION_TYPE"))) {
						hadcollectionType = true;
						break;
					}
				}
				iMap.put("ACCOUNT_COLLECTION_TYPES", j, "CHOOSE", hadcollectionType);
			}
		}
		oMap.put("ACCOUNT_COLLECTION_TYPES", iMap.get("ACCOUNT_COLLECTION_TYPES"));
	}

	@GraymoundService("CDM_ADD_UPT_ACCOUNT")
	public static GMMap addOrUptRowAccount(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = validationAccount(iMap);
			if (oMap.getBoolean("OPERATION")) {
				GMMap rowMap = new GMMap();
				rowMap.put("CONCENTRATION_TYPE", iMap.getBoolean("ACCOUNT_BUILD_SINGLE") ? DatabaseConstants.ConcentrationTypes.SingleConcentration : DatabaseConstants.ConcentrationTypes.MultiConcentration);
				rowMap.put("ACCOUNT_DEFINITION_NAME", iMap.getString("ACCOUNT_DEFINITION_NAME"));
				rowMap.put("ACCOUNT_DEFINITION_TYPE", iMap.getString("ACCOUNT_DEFINITION_TYPE"));
				rowMap.put("ACCOUNT_OWNER", iMap.getString("ACCOUNT_OWNER"));
				if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE")) || DatabaseConstants.AccountDefinitionTypes.UsageAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))|| DatabaseConstants.AccountDefinitionTypes.BlockedAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
					rowMap.put("ACCOUNT_NUMBER", iMap.getString("ACCOUNT_NUMBER"));
					rowMap.put("ACCOUNT_NAME", iMap.getString("ACCOUNT_NAME"));
					rowMap.put("DEFAULT_AMOUNT", iMap.getString("DEFAULT_AMOUNT"));
					if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
						addAccountChooseCollectionType(iMap, rowMap);
						addAccountChooseChannelSource(iMap, rowMap);
					}
					if (DatabaseConstants.ConcentrationTypes.MultiConcentration.equalsIgnoreCase(rowMap.getString("CONCENTRATION_TYPE"))) {
						addAccountChooseSubscriberMatch(iMap, rowMap);
						oMap.put("SUBSCRIBER_MATCH_LIST", iMap.get("SUBSCRIBER_MATCH_LIST"));

					}
				} else if (DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
					rowMap.put("IBAN", iMap.getString("IBAN"));

				}
				oMap.put("ACCOUNT_ROW_DATA", rowMap);
				GMMap rowMapSelected = iMap.getMap("ACCOUNT_ROW_DATA");
				if (rowMapSelected != null) {
					updateAccountTransferOnAcount(iMap, oMap);
				} else {
					oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
				}

			} else {
				oMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	private static void updateAccountTransferOnAcount(GMMap iMap, GMMap oMap) throws Exception {
		// List<String> selectedSourceList = Arrays.asList(
		GMMap tempMap = new GMMap();
		tempMap.put("ACCOUNT_TRANSFERS_DATA", iMap.get("ACCOUNT_TRANSFERS_DATA"));
		GMMap rowMapChanged = oMap.getMap("ACCOUNT_ROW_DATA");
		GMMap rowMapSelected = iMap.getMap("ACCOUNT_ROW_DATA");
		List<String> difCollectinChannelSourceList = new ArrayList<String>();
		List<String> difCollectinChannelSourceNameList = new ArrayList<String>();
		List<String> difSubscriberMatchList = new ArrayList<String>();
		List<String> oldSubscriberMatchList = new ArrayList<String>();
		List<String> newSubscriberMatchList = new ArrayList<String>();
		if (StringUtils.isNotBlank(rowMapSelected.getString("COLLECTION_TYPE")) && StringUtils.isNotBlank(rowMapSelected.getString("CHANNEL_SOURCE_CODE")) && StringUtils.isNotBlank(rowMapChanged.getString("COLLECTION_TYPE")) && StringUtils.isNotBlank(rowMapChanged.getString("CHANNEL_SOURCE_CODE"))) {

			List<String> oldCollectinTypeList = Arrays.asList(rowMapSelected.getString("COLLECTION_TYPE").split(","));
			List<String> newCollectinTypeList = Arrays.asList(rowMapChanged.getString("COLLECTION_TYPE").split(","));
			List<String> difCollectinTypeList = new ArrayList<String>();
			for (String oldCollectinType : oldCollectinTypeList) {
				if (newCollectinTypeList.contains(oldCollectinType)) {
					difCollectinTypeList.add(oldCollectinType);
				}
			}
			List<String> oldCollectinNameList = Arrays.asList(rowMapSelected.getString("COLLECTION_NAME").split(","));
			List<String> newCollectinNameList = Arrays.asList(rowMapChanged.getString("COLLECTION_NAME").split(","));
			List<String> difCollectinNameList = new ArrayList<String>();
			for (String oldCollectinName : oldCollectinNameList) {
				if (newCollectinNameList.contains(oldCollectinName)) {
					difCollectinNameList.add(oldCollectinName);
				}
			}

			List<String> oldChannelSourceList = Arrays.asList(rowMapSelected.getString("CHANNEL_SOURCE_CODE").split(","));
			List<String> newChannelSourceList = Arrays.asList(rowMapChanged.getString("CHANNEL_SOURCE_CODE").split(","));
			List<String> difChannelSourceList = new ArrayList<String>();
			for (String oldChannelSource : oldChannelSourceList) {
				if (newChannelSourceList.contains(oldChannelSource)) {
					difChannelSourceList.add(oldChannelSource);
				}
			}

			List<String> oldChannelSourceNameList = Arrays.asList(rowMapSelected.getString("CHANNEL_SOURCE_NAME").split(","));
			List<String> newChannelSourceNameList = Arrays.asList(rowMapChanged.getString("CHANNEL_SOURCE_NAME").split(","));
			List<String> difChannelSourceNameList = new ArrayList<String>();
			for (String oldChannelSourceName : oldChannelSourceNameList) {
				if (newChannelSourceNameList.contains(oldChannelSourceName)) {
					difChannelSourceNameList.add(oldChannelSourceName);
				}
			}

			if (!rowMapSelected.getBoolean("ACCOUNT_BUILD_SINGLE") && StringUtils.isNotBlank(rowMapSelected.getString("TREE_LIST"))) {
				oldSubscriberMatchList = Arrays.asList(rowMapSelected.getString("TREE_LIST").split(","));
			}
			if (DatabaseConstants.ConcentrationTypes.MultiConcentration.equalsIgnoreCase(rowMapChanged.getString("CONCENTRATION_TYPE")) && StringUtils.isNotBlank(rowMapChanged.getString("TREE_LIST"))) {
				newSubscriberMatchList = Arrays.asList(rowMapChanged.getString("TREE_LIST").split(","));
			}
			for (String oldSubscriberMatch : oldSubscriberMatchList) {
				if (newSubscriberMatchList.contains(oldSubscriberMatch)) {
					difSubscriberMatchList.add(oldSubscriberMatch);
				}
			}
			if (oldSubscriberMatchList.size() <= 0 && newSubscriberMatchList.size() > 0) {
				difSubscriberMatchList.addAll(newSubscriberMatchList);
			}
			for (String difCollectinType : difCollectinTypeList) {
				for (String difChannelSource : difChannelSourceList) {
					String[] difChannelSourceArr = difChannelSource.split("<->");
					if (difSubscriberMatchList != null && difSubscriberMatchList.size() > 0) {
						for (String difSubscriberMatch : difSubscriberMatchList) {
							difCollectinChannelSourceList.add(difCollectinType + "<->" + difChannelSourceArr[0] + "<->" + difChannelSourceArr[1] + "<->" + difSubscriberMatch);
						}
					} else {
						difCollectinChannelSourceList.add(difCollectinType + "<->" + difChannelSourceArr[0] + "<->" + difChannelSourceArr[1]);
					}
				}
			}

			for (String difCollectinName : difCollectinNameList) {
				for (String difChannelSourceName : difChannelSourceNameList) {
					String[] difChannelSourceNameArr = difChannelSourceName.split("<->");
					if (difSubscriberMatchList != null && difSubscriberMatchList.size() > 0) {
						for (String difSubscriberMatch : difSubscriberMatchList) {
							difCollectinChannelSourceNameList.add("(" + difCollectinName + "<->" + difChannelSourceNameArr[0] + "<->" + difChannelSourceNameArr[1] + ")");
						}
					} else {
						difCollectinChannelSourceNameList.add("(" + difCollectinName + "<->" + difChannelSourceNameArr[0] + "<->" + difChannelSourceNameArr[1] + ")");
					}
				}
			}
		}
		int accountTransferRow = -1;
		for (int row = 0; row < iMap.getSize("ACCOUNT_TRANSFERS_DATA"); row++) {
			// rowMapSelected
			// ACCOUNT_DEFINITION_TYPE
			if ((rowMapSelected.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapSelected.getString("ACCOUNT_NUMBER")).equalsIgnoreCase(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "SOURCE_ACCOUNT_NO_ID"))) {
				tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "SOURCE_ACCOUNT_NO_ID", rowMapChanged.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapChanged.getString("ACCOUNT_NUMBER"));
				tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "SOURCE_ACCOUNT_NO", rowMapChanged.getString("ACCOUNT_DEFINITION_NAME") + "-" + rowMapChanged.getString("ACCOUNT_NUMBER"));

			} else if ((rowMapSelected.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapSelected.getString("ACCOUNT_NUMBER")).equalsIgnoreCase(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "TRANSFUSION_ACCOUNT_NO_ID"))) {
				tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "TRANSFUSION_ACCOUNT_NO_ID", rowMapChanged.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapChanged.getString("ACCOUNT_NUMBER"));
				tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "TRANSFUSION_ACCOUNT_NO", rowMapChanged.getString("ACCOUNT_DEFINITION_NAME") + "-" + rowMapChanged.getString("ACCOUNT_NUMBER"));
			}
			if ((rowMapSelected.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapSelected.getString("ACCOUNT_NUMBER")).equalsIgnoreCase(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "TRANSFUSION_ACCOUNT_NO_ID"))
					|| (rowMapSelected.getString("ACCOUNT_DEFINITION_TYPE") + "-" + rowMapSelected.getString("ACCOUNT_NUMBER")).equalsIgnoreCase(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "SOURCE_ACCOUNT_NO_ID"))) {
				if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID")) && DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(rowMapChanged.getString("ACCOUNT_DEFINITION_TYPE"))) {
					String collectionChangeSourceChannels = "", collectionChangeSourceChannelNames = "";
					List<String> accountCollectionChannelSourceCodeList = new ArrayList<String>();
					List<String> accountCollectionChannelSourceNameList = new ArrayList<String>();
					List<String> accountChannelSourceCodes = Arrays.asList(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID").split(","));
					List<String> accountChannelSourceNames = Arrays.asList(iMap.getString("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE").split(","));

					if (difSubscriberMatchList != null && difSubscriberMatchList.size() > 0) {
						for (String difSubscriberMatch : difSubscriberMatchList) {
							for (String accountChannelSourceCode : accountChannelSourceCodes) {
								if (difCollectinChannelSourceList.contains(accountChannelSourceCode + (accountChannelSourceCode.split("<->").length <= 3 ? difSubscriberMatch : ""))) {
									accountCollectionChannelSourceCodeList.add(accountChannelSourceCode + (accountChannelSourceCode.split("<->").length <= 3 ? difSubscriberMatch : ""));
								}
							}
						}
						for (int i = 0; i < accountCollectionChannelSourceCodeList.size(); i++) {
							collectionChangeSourceChannels = collectionChangeSourceChannels + accountCollectionChannelSourceCodeList.get(i) + (i < accountCollectionChannelSourceCodeList.size() - 1 ? "," : "");
						}

						for (String accountChannelSourceName : accountChannelSourceNames) {
							for (String difSubscriberMatch : difSubscriberMatchList) {
								if (difCollectinChannelSourceNameList.contains(accountChannelSourceName)) {
									accountCollectionChannelSourceNameList.add(accountChannelSourceName);
								}
							}
						}
					} else {
						for (String accountChannelSourceCode : accountChannelSourceCodes) {
							String[] accountChannelSourceCodeArr = accountChannelSourceCode.split("<->");
							if (difCollectinChannelSourceList.contains(accountChannelSourceCodeArr[0] + "<->" + accountChannelSourceCodeArr[1] + "<->" + accountChannelSourceCodeArr[2])) {
								if (accountChannelSourceCodeArr.length > 3 && oldSubscriberMatchList.contains(accountChannelSourceCodeArr[3]))
									accountCollectionChannelSourceCodeList.add(accountChannelSourceCodeArr[0] + "<->" + accountChannelSourceCodeArr[1] + "<->" + accountChannelSourceCodeArr[2] + "<->null");
								else
									accountCollectionChannelSourceCodeList.add(accountChannelSourceCode);
							}
						}
						for (int i = 0; i < accountCollectionChannelSourceCodeList.size(); i++) {
							collectionChangeSourceChannels = collectionChangeSourceChannels + accountCollectionChannelSourceCodeList.get(i) + (i < accountCollectionChannelSourceCodeList.size() - 1 ? "," : "");
						}

						for (String accountChannelSourceName : accountChannelSourceNames) {
							if (difCollectinChannelSourceNameList.contains(accountChannelSourceName)) {
								accountCollectionChannelSourceNameList.add(accountChannelSourceName);
							}
						}
					}
					for (int i = 0; i < accountCollectionChannelSourceNameList.size(); i++) {
						collectionChangeSourceChannelNames = collectionChangeSourceChannelNames + accountCollectionChannelSourceNameList.get(i) + (i < accountCollectionChannelSourceNameList.size() - 1 ? "," : "");
					}
					if (StringUtils.isNotBlank(collectionChangeSourceChannels)) {
						tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID", collectionChangeSourceChannels);
						tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE", collectionChangeSourceChannelNames);
						accountTransferRow++;
						oMap.put("ACCOUNT_TRANSFERS_DATA", accountTransferRow, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
					}
				} else {
					tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID", "");
					tempMap.put("ACCOUNT_TRANSFERS_DATA", row, "COLLECTION_CHANNEL_SOURCE", "");
					accountTransferRow++;
					oMap.put("ACCOUNT_TRANSFERS_DATA", accountTransferRow, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
				}
			} else {
				accountTransferRow++;
				oMap.put("ACCOUNT_TRANSFERS_DATA", accountTransferRow, tempMap.getMap("ACCOUNT_TRANSFERS_DATA", row));
			}
		}

	}

	private static void addAccountChooseSubscriberMatch(GMMap iMap, GMMap rowMap) {
		String subscribeId = "";
		int i = -1;
		for (int j = 0; j < iMap.getSize("SUBSCRIBER_MATCH_LIST"); j++) {
			if (iMap.getBoolean("SUBSCRIBER_MATCH_LIST", j, "CHOOSE")) {
				i++;
				subscribeId += iMap.getString("SUBSCRIBER_MATCH_LIST", j, "DEFINITION_ID") + (j + 1 != i ? "," : "");
			}
		}
		rowMap.put("TREE_LIST", StringUtils.isNotBlank(subscribeId) ? (subscribeId.substring(subscribeId.length() - 1, subscribeId.length()).equalsIgnoreCase(",") ? subscribeId.substring(0, subscribeId.length() - 1) : subscribeId) : "");
	}

	private static void addAccountChooseCollectionType(GMMap iMap, GMMap rowMap) {
		for (int j = 0; j < iMap.getSize("ACCOUNT_COLLECTION_TYPES"); j++) {
			if (!DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
				if (iMap.getBoolean("ACCOUNT_COLLECTION_TYPES", j, "CHOOSE")) {
					rowMap.put("COLLECTION_NAME", (StringUtils.isBlank(rowMap.getString("COLLECTION_NAME")) ? "" : rowMap.getString("COLLECTION_NAME") + ",") + iMap.getString("ACCOUNT_COLLECTION_TYPES", j, "COLLECTION_NAME"));
					rowMap.put("COLLECTION_TYPE", (StringUtils.isBlank(rowMap.getString("COLLECTION_TYPE")) ? "" : rowMap.getString("COLLECTION_TYPE") + ",") + iMap.getString("ACCOUNT_COLLECTION_TYPES", j, "COLLECTION_TYPE"));
				}
			}
		}
	}

	private static void addAccountChooseChannelSource(GMMap iMap, GMMap rowMap) {
		for (int j = 0; j < iMap.getSize("ACCOUNT_CHANNELS_SOURCES"); j++) {
			if (iMap.getBoolean("ACCOUNT_CHANNELS_SOURCES", j, "CHOOSE")) {
				rowMap.put("CHANNEL_SOURCE_NAME",
						(StringUtils.isBlank(rowMap.getString("CHANNEL_SOURCE_NAME")) ? "" : rowMap.getString("CHANNEL_SOURCE_NAME") + ",") + iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "SOURCE_NAME") + "<->" + iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "CHANNEL_NAME"));
				rowMap.put("CHANNEL_SOURCE_CODE",
						(StringUtils.isBlank(rowMap.getString("CHANNEL_SOURCE_CODE")) ? "" : rowMap.getString("CHANNEL_SOURCE_CODE") + ",") + iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "SOURCE_CODE") + "<->" + iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "CHANNEL_CODE"));
			}
		}
	}

	public static GMMap validationAccount(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {
			if (!DatabaseConstants.AccountDefinitionTypes.EftAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
				validationDomain(iMap, "ACCOUNT_NUMBER", oMap, "L�tfen Hesap no tan�m�n� doldurunuz!");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;

				if (!checkAccountNumber(iMap)) {
					validationExtra("ACCOUNT_NUMBER", oMap, "Tan�mlamaya �al��t���n�z hesab numaras� bankada bulunmamaktad�r, L�tfen ba�ka bir hesab numaras� se�iniz!");
					if (!oMap.getBoolean("OPERATION"))
						return oMap;
				}

				GMMap rowMapAccount = iMap.getMap("ACCOUNT_ROW_DATA");
				for (int j = 0; j < iMap.getSize("ACCOUNT_LIST"); j++) {
					if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_LIST", j, "ACCOUNT_NUMBER")) && (rowMapAccount == null || (rowMapAccount != null && !rowMapAccount.getString("ACCOUNT_NUMBER").equalsIgnoreCase(iMap.getString("ACCOUNT_NUMBER"))))) {
						if (iMap.getString("ACCOUNT_NUMBER").equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", j, "ACCOUNT_NUMBER"))) {
							validationExtra("ACCOUNT_NUMBER", oMap, "Tan�mlamaya �al��t���n�z hesab numaras� daha �nce kullan�lm��, L�tfen ba�ka bir hesab numaras� se�iniz!");
							if (!oMap.getBoolean("OPERATION"))
								return oMap;
						}
					}

				}

				if (DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_DEFINITION_TYPE"))) {
					if (checkSameColectionTypeChannelSource(iMap)) {
						validationExtra("ACCOUNT_NUMBER", oMap, "Tan�mlamaya �al��t���n�z Tahsilat hesab� i�in ayn� �deme tipi, kanal, kaynak bilgileri se�ilmi�!");
						if (!oMap.getBoolean("OPERATION"))
							return oMap;
					}
					boolean collectionTypeselectedCount = false;
					for (int j = 0; j < iMap.getSize("ACCOUNT_COLLECTION_TYPES"); j++) {
						if (iMap.getBoolean("ACCOUNT_COLLECTION_TYPES", j, "CHOOSE")) {
							collectionTypeselectedCount = true;
							break;
						}
					}
					if (!collectionTypeselectedCount) {
						validationExtra("ACCOUNT_COLLECTION_TYPES", oMap, "Tahsilat Hesab� tan�mlamak i�in en az bir adet �deme Tipi se�melisiniz!");
						if (!oMap.getBoolean("OPERATION"))
							return oMap;
					}

					boolean channelSourcelectedCount = false;
					for (int j = 0; j < iMap.getSize("ACCOUNT_CHANNELS_SOURCES"); j++) {
						if (iMap.getBoolean("ACCOUNT_CHANNELS_SOURCES", j, "CHOOSE")) {
							channelSourcelectedCount = true;
							break;
						}
					}
					if (!channelSourcelectedCount) {
						validationExtra("ACCOUNT_CHANNELS_SOURCES", oMap, "Tahsilat Hesab� tan�mlamak i�in en az bir adet Kanal,Kaynak se�melisiniz!");
						if (!oMap.getBoolean("OPERATION"))
							return oMap;
					}
				}
				if (!iMap.getBoolean("ACCOUNT_BUILD_SINGLE")) {
					boolean subscriberMatch = false;
					for (int j = 0; j < iMap.getSize("SUBSCRIBER_MATCH_LIST"); j++) {
						if (iMap.getBoolean("SUBSCRIBER_MATCH_LIST", j, "CHOOSE")) {
							subscriberMatch = true;
							break;
						}
					}
					if (!subscriberMatch) {
						validationExtra("SUBSCRIBER_MATCH_LIST", oMap, "Temerk�zl�k yap�s� �oklu se�ildi�inde en az bir adet Referans k�r�l�m� se�melisiniz!");
						if (!oMap.getBoolean("OPERATION"))
							return oMap;
					}
				}
			} else {
				validationDomain(iMap, "IBAN", oMap, "L�tfen IBAN tan�m�n� doldurunuz!");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;
				if (!checkIban(iMap, oMap).getBoolean("OPERATION")) {
					validationExtra("IBAN", oMap, "L�tfen IBAN tan�m�n� uygun olarak doldurunuz!");
					return oMap;
				}
				validationDomain(iMap, "ACCOUNT_OWNER", oMap, "L�tfen Ad soyad alan�n� uygun olarak doldurunuz!");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static boolean checkSameColectionTypeChannelSource(GMMap iMap) {
		List<String> collectionTypeNew = new ArrayList<String>();
		List<String> sourceChannelNew = new ArrayList<String>();
		List<String> temerkuzNew = new ArrayList<String>();

		for (int j = 0; j < iMap.getSize("ACCOUNT_COLLECTION_TYPES"); j++) {
			if (iMap.getBoolean("ACCOUNT_COLLECTION_TYPES", j, "CHOOSE")) {
				collectionTypeNew.add(iMap.getString("ACCOUNT_COLLECTION_TYPES", j, "COLLECTION_TYPE"));
			}
		}
		for (int j = 0; j < iMap.getSize("ACCOUNT_CHANNELS_SOURCES"); j++) {
			if (iMap.getBoolean("ACCOUNT_CHANNELS_SOURCES", j, "CHOOSE")) {
				sourceChannelNew.add(iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "SOURCE_CODE") + "<->" + iMap.getString("ACCOUNT_CHANNELS_SOURCES", j, "CHANNEL_CODE"));
			}
		}
		for (int j = 0; j < iMap.getSize("SUBSCRIBER_MATCH_LIST"); j++) {
			if (iMap.getBoolean("SUBSCRIBER_MATCH_LIST", j, "CHOOSE")) {
				temerkuzNew.add(iMap.getString("SUBSCRIBER_MATCH_LIST", j, "DEFINITION_ID"));
			}
		}

		boolean samecollectionSourceChannel = false;
		for (int j = 0; j < iMap.getSize("ACCOUNT_LIST"); j++) {
			if (iMap.getInt("ACCOUNT_ROW") != j && DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", j, "ACCOUNT_DEFINITION_TYPE"))) {
				List<String> collectionTypes = Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "COLLECTION_TYPE").split(","));
				List<String> sourceChannels = Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "CHANNEL_SOURCE_CODE").split(","));
				for (String collectionType : collectionTypes) {
					if (collectionTypeNew.contains(collectionType)) {
						for (String sourceChannel : sourceChannels) {
							if (sourceChannelNew.contains(sourceChannel)) {
								if (DatabaseConstants.ConcentrationTypes.MultiConcentration.equalsIgnoreCase(iMap.getString("ACCOUNT_LIST", j, "CONCENTRATION_TYPE"))) {
									List<String> temmerkuzs = Arrays.asList(iMap.getString("ACCOUNT_LIST", j, "TREE_LIST").split(","));
									for (String temmerkuz : temmerkuzs) {
										if (temerkuzNew.contains(temmerkuz)) {
											samecollectionSourceChannel = true;
											break;
										}
									}
									if (samecollectionSourceChannel)
										break;
								} else {
									samecollectionSourceChannel = true;
									break;
								}
							}
						}
					}
					if (samecollectionSourceChannel)
						break;
				}

			}
			if (samecollectionSourceChannel)
				break;
		}
		return samecollectionSourceChannel;
	}

	private static boolean checkAccountNumber(GMMap iMap) {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.CHECK_ACCOUNT_NUMBER,"VADESIZ","TRY",iMap.getString("ACCOUNT_NUMBER")));
		String haveAccountNumber = DALUtil.getResult(sb.toString());
		if (StringUtils.isNotBlank(haveAccountNumber) && Integer.valueOf(haveAccountNumber).intValue() > 0)
			return true;
		return false;
	}

	private static GMMap checkIban(GMMap iMap, GMMap oMap) {
		try {
			Object[] inputValues = new Object[2];
			oMap.put("OPERATION", true);
			if (StringUtils.isNotBlank(iMap.getString("IBAN"))) {
				String func = "{? = call BNSPR.pkg_IBAN.sp_IBAN_Kontrol_Et(?)}";
				int i = 0;
				String iban = iMap.getString("IBAN");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iban;
				String kontrol = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
				if (kontrol.equals("0")) {
					oMap.put("OPERATION", false);
					oMap.put("MESSAGE", "Girdi�iniz IBAN numaras� do�rulanamad�!L�tfen girdi�iniz IBAN numaras�n� kontrol ediniz!");
				}
			} else {
				oMap.put("OPERATION", false);
				oMap.put("MESSAGE", "L�tfen IBAN bilgisini giriniz!");
			}

		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("OPERATION", false);
			oMap.put("MESSAGE", "IBAN do�rulamas� s�ras�nda hata meydana geldi!");
		}
		return oMap;
	}

	@GraymoundService("CDM_ACCOUNT_TYPE_CHANGE")
	public static GMMap changeAccountType(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			oMap.put("RESULT_ACTION", "ADD");
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	public static GMMap getAccountChannelsSources(GMMap iMap, GMMap oMap, String type) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_CHANNELS_SOURCES,type,iMap.getString("CORPORATE_OID")));
//			sb.append(" SELECT DISTINCT p.aciklama channel_name, s.source_name, p.kod channel_code, s.source_code");
//			sb.append(" FROM cdm.channel_source_def").append(type).append(" cs, bnspr.gnl_kanal_grup_kod_pr p, cdm.source_param s");
//			sb.append(" WHERE cs.channel_code = p.kod AND cs.source_code= s.source_code AND cs.status= 1");
//			sb.append(" AND cs.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("'");
			oMap.put("ACCOUNT_CHANNELS_SOURCES", DALUtil.getResults(sb.toString(), "ACCOUNT_CHANNELS_SOURCES").get("ACCOUNT_CHANNELS_SOURCES"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getAccountCollectionTypes(GMMap iMap, GMMap oMap, String type) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.ACCOUNT_COLLECTION_TYPES,type,type,iMap.getString("CORPORATE_OID")));
//			sb.append(" SELECT DISTINCT p.collection_name ,p.collection_type");
//			sb.append(" FROM cdm.collection_type_def").append(type).append(" d,cdm.collection_type_prm p");
//			sb.append(" ,cdm.subscriber_mask_def").append(type).append(" smd");
//			sb.append(" WHERE d.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("'");
//			sb.append(" AND smd.collection_type=p.collection_type AND smd.status=1 AND smd.corporate_oid=d.corporate_oid");
//			sb.append(" AND p.collection_type= d.collection_type AND d.status=1 AND (d.allow_auto_collection=1 OR d.is_appearance_payment_screen=1)");
			oMap.put("ACCOUNT_COLLECTION_TYPES", DALUtil.getResults(sb.toString(), "ACCOUNT_COLLECTION_TYPES").get("ACCOUNT_COLLECTION_TYPES"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_ACCOUNT_INITIALIZE")
	public static GMMap getAccount(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			getAcoountSubscriberAndSourceChannel(iMap, oMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_ACCOUNT_SOURCE_AND_TRANSFUSION")
	public static GMMap getAccountComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			getSourceAccountList(iMap);
			getTransfusionAccountList(iMap);
			String sourceAccountNoId = null;
			GMMap rowMap = iMap.getMap("ACCOUNT_TRANSFER_ROW_DATA");
			if (iMap.getMap("ACCOUNT_TRANSFER_ROW_DATA") != null && StringUtils.isNotBlank(rowMap.getString("SOURCE_ACCOUNT_NO_ID"))) {
				sourceAccountNoId = rowMap.getString("SOURCE_ACCOUNT_NO_ID");
			} else {
				sourceAccountNoId = iMap.getString("SOURCE_ACCOUNT_NO_ID");
				if (sourceAccountNoId == null && iMap.getSize("ACCOUNT_LIST") > 0) {
					sourceAccountNoId = iMap.getString("ACCOUNT_LIST", 0, "ACCOUNT_DEFINITION_TYPE") + "-" + iMap.getString("ACCOUNT_LIST", 0, "ACCOUNT_NUMBER");
				}
			}
			getAccountCollectionTypeChannelSourceList(iMap, sourceAccountNoId);
			oMap.put("ACCOUNT_SOURCES", iMap.get("ACCOUNT_SOURCES"));
			oMap.put("ACCOUNT_TRANSFUSION", iMap.get("ACCOUNT_TRANSFUSION"));
			oMap.put("ACCOUNT_RESOURCES", iMap.get("ACCOUNT_RESOURCES"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_ACCOUNT_CALCULATE_DAY_DIFFERENCE")
	public static GMMap calculateDayDifference(GMMap iMap) {
		GMMap oMap = new GMMap();
		String firstDay = iMap.getString("FIRST_DAY");
		String secondDay = iMap.getString("SECOND_DAY");
		String nextWeekClicked = iMap.getString("NEXT_WEEK_CLICKED");
		Object[] returnObject = claculateTransferDay(firstDay, secondDay, nextWeekClicked);
		oMap.put("NEXT_WEEK", returnObject[0]);
		oMap.put("DAY_DIFFERENCE", returnObject[1]);
		oMap.put("FIRST_DAY", returnObject[2]);
		return oMap;
	}

	private static Object[] claculateTransferDay(String firstDay, String secondDay, String nextWeekClicked) {
		Object[] returnObject = new Object[3];
		int firstDayVal = 0;
		int secondDayVal = 0;
		int dayDifference = 0;
		int weekDaysCount = 5;
		boolean nextWeek = false;
		try {
			HashMap<String, Integer> mMap = new HashMap<String, Integer>();
			mMap.put("Pazartesi", 1);
			mMap.put("Sal�", 2);
			mMap.put("�ar�amba", 3);
			mMap.put("Per�embe", 4);
			mMap.put("Cuma", 5);
			mMap.put("Cumartesi", 6);
			mMap.put("Pazar", 7);
			if (firstDay != null && secondDay != null) {
				firstDayVal = mMap.get(firstDay);
				secondDayVal = mMap.get(secondDay);
				if (secondDayVal > 5) {
					secondDayVal = secondDayVal - 5;
				}
				if (firstDayVal > secondDayVal) {
					nextWeek = true;
					if (firstDayVal > 5) {
						dayDifference = secondDayVal;
					} else {
						dayDifference = weekDaysCount - (firstDayVal - secondDayVal);
					}
				} else if (secondDayVal > firstDayVal) {
					if (nextWeekClicked.equals("0") || nextWeekClicked.equals("false")) {
						nextWeek = false;
						dayDifference = secondDayVal - firstDayVal;
					} else {
						nextWeek = true;
						dayDifference = secondDayVal - firstDayVal + 5;
					}
				} else if (secondDayVal == firstDayVal) {
					if (nextWeekClicked.equals("1")) {
						dayDifference = weekDaysCount;
						nextWeek = true;
					}
				}
			}
		} catch (Exception e) {
		}
		returnObject[0] = nextWeek;
		returnObject[1] = dayDifference;
		returnObject[2] = firstDayVal;
		return returnObject;
	}

	@GraymoundService("CDM_SHOW_ROW_ACCOUNT_TRANSFER")
	public static GMMap showRowCorporateAccountTransfer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMap = new GMMap();
		try {
			rowMap = iMap.getMap("ACCOUNT_TRANSFER_ROW_DATA");
			oMap.put("SOURCE_ACCOUNT_NO", rowMap.getString("SOURCE_ACCOUNT_NO"));
			oMap.put("TRANSFUSION_ACCOUNT_NO", rowMap.getString("TRANSFUSION_ACCOUNT_NO"));
			getAccountChooseRransferDayRule(iMap, rowMap, oMap);
			getAccountChooseRransferMonthRule(iMap, rowMap, oMap);
			oMap.put("VACATION_TYPE", rowMap.getString("VACATION_TYPE"));
			oMap.put("VACATION_TYPE_ID", rowMap.getString("VACATION_TYPE_ID"));
			oMap.put("TRANSFER_TYPE", rowMap.getString("TRANSFER_TYPE"));
			oMap.put("TRANSFER_TYPE_ID", rowMap.getString("TRANSFER_TYPE_ID"));
			oMap.put("TRANSFER_DESC", rowMap.getString("TRANSFER_DESC"));

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	private static void getAccountChooseRransferMonthRule(GMMap iMap, GMMap rowMap, GMMap oMap) {
		if (StringUtils.isNotBlank(rowMap.getString("TRANSFER_MONTH_RULE"))) {
			String[] traGroup = rowMap.getString("TRANSFER_MONTH_RULE").split(" ");
			if (rowMap.getInt("TRANSFER_MONTH_OPTION") == 1) {
				oMap.put("MONTH_DAY_SELECTED", true);
				oMap.put("MANUEL_MONTH_SELECTED", false);
				if (StringUtils.isNotBlank(traGroup[0]) && !".".equalsIgnoreCase(traGroup[0])) {
					oMap.put("MONTH_DAY", traGroup[0].split("\\.")[0]);
				}
			} else if (rowMap.getInt("TRANSFER_MONTH_OPTION") == 2) {
				oMap.put("MONTH_DAY_SELECTED", false);
				oMap.put("MANUEL_MONTH_SELECTED", true);
				if (StringUtils.isNotBlank(traGroup[0]) && !".".equalsIgnoreCase(traGroup[0])) {
					oMap.put("MANUEL_MONTH_DAY_START", traGroup[0].split("\\.")[0]);
					oMap.put("MANUEL_MONTH_DAY_END", traGroup[4].split("\\.")[0]);
				}
			}
		} else {
			oMap.put("MONTH_DAY_SELECTED", false);
			oMap.put("MANUEL_MONTH_SELECTED", true);
		}
	}

	private static void getAccountChooseRransferDayRule(GMMap iMap, GMMap rowMap, GMMap oMap) {
		oMap.put("DAY_SELECTED", rowMap.getInt("TRANSFER_DAY_OPTION") == 1 ? true : false);
		oMap.put("DAY_TYPE_ID", rowMap.getString("DAY_TYPE_ID"));
		oMap.put("MANUEL_DAY_SELECTED", rowMap.getInt("TRANSFER_DAY_OPTION") == 1 ? false : true);

		if (rowMap.getInt("TRANSFER_DAY_OPTION") == 1) {
			String transferRuleDay = rowMap.getString("TRANSFER_DAY_RULE");
			transferRuleDay = transferRuleDay.substring(1, transferRuleDay.length() - 1);
			String[] dayArray = transferRuleDay.split(" ");
			oMap.put("DAY_COUNT", dayArray[0]);
			oMap.put("DAY_TYPE", dayArray[1] + (dayArray.length == 5 ? (" " + dayArray[2]) : ""));
		} else if (rowMap.getInt("TRANSFER_DAY_OPTION") == 2) {
			String transferRuleDay = rowMap.getString("TRANSFER_DAY_RULE_ID");
			if (StringUtils.isNotBlank(transferRuleDay)) {
				String[] transferRuleDayList = transferRuleDay.split(",");
				for (int j = 0; j < iMap.getSize("MANUEL_DAY_MATCHING"); j++) {
					String[] trdGroup = transferRuleDayList[j].substring(1, transferRuleDayList[j].length() - 1).split("->");
					if (iMap.getString("MANUEL_DAY_MATCHING", j, "GELEN_GUN").equalsIgnoreCase(trdGroup[0])) {
						boolean afterWeek = DayDifference.getInstance().getDifferance(trdGroup[0], trdGroup[1]) < 0 ? true : false;
						Object[] returnObject = claculateTransferDay(trdGroup[0], trdGroup[1], String.valueOf(afterWeek));
						iMap.put("MANUEL_DAY_MATCHING", j, "GUN_SAYISI", trdGroup.length == 3 && Boolean.valueOf(trdGroup[2]).booleanValue() == true && !afterWeek ? Integer.valueOf(returnObject[1].toString()).intValue() + 5 : returnObject[1]);
						iMap.put("MANUEL_DAY_MATCHING", j, "CIKIS_GUNU", trdGroup[1]);
						iMap.put("MANUEL_DAY_MATCHING", j, "SONRAKI_HAFTA", trdGroup.length == 3 ? trdGroup[2] : afterWeek);
					}
				}
			}
			oMap.put("MANUEL_DAY_MATCHING", iMap.get("MANUEL_DAY_MATCHING"));
		}
	}

	private static void getAccountChooseCollectionTypeChannelSource(GMMap iMap, GMMap rowMap, GMMap oMap) {
		GMMap tempMap = new GMMap();
		tempMap.put("ACCOUNT_RESOURCES", iMap.get("ACCOUNT_RESOURCES"));
		if (rowMap != null && StringUtils.isNotBlank(rowMap.getString("COLLECTION_CHANNEL_SOURCE_ID"))) {
			List<String> collectionChannelSources = Arrays.asList(rowMap.getString("COLLECTION_CHANNEL_SOURCE_ID").split(","));
			for (int j = 0; j < iMap.getSize("ACCOUNT_RESOURCES"); j++) {
				boolean hadResources = false;
				for (String collectionChannelSource : collectionChannelSources) {
					String accountResourceRow = iMap.getString("ACCOUNT_RESOURCES", j, "COLLECTION_TYPE") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "SOURCE_CODE") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "CHANNEL_CODE") + "<->"
							+ (StringUtils.isNotBlank(iMap.getString("ACCOUNT_RESOURCES", j, "ACCOUNT_COLLECTION_OID")) ? (iMap.getString("ACCOUNT_RESOURCES", j, "ACCOUNT_COLLECTION_OID").equalsIgnoreCase("null") ? "" : iMap.getString("ACCOUNT_RESOURCES", j, "ACCOUNT_COLLECTION_OID")) : "");
					if (collectionChannelSource.replace("null", "").equalsIgnoreCase(accountResourceRow)) {
						hadResources = true;
						break;
					}
				}
				if (!(StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_ROW")) && Integer.valueOf(iMap.getString("ACCOUNT_TRANSFER_ROW")).intValue() > -1)) {
					hadResources = false;
				}
				tempMap.put("ACCOUNT_RESOURCES", j, "CHOOSE", hadResources);
			}
		}
		oMap.put("ACCOUNT_RESOURCES", tempMap.get("ACCOUNT_RESOURCES"));
	}

	@GraymoundService("CDM_ADD_UPT_ACCOUNT_TRANSFER")
	public static GMMap addOrUptRowAccountTransfer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = validationAccountTransfer(iMap);
			String transfusionDay = "", transfusionDayId = "";
			if (oMap.getBoolean("OPERATION")) {
				GMMap rowMap = new GMMap();
				rowMap.put("SOURCE_ACCOUNT_NO", iMap.getString("SOURCE_ACCOUNT_NO"));
				rowMap.put("SOURCE_ACCOUNT_NO_ID", iMap.getString("SOURCE_ACCOUNT_NO_ID"));
				rowMap.put("TRANSFUSION_ACCOUNT_NO", iMap.getString("TRANSFUSION_ACCOUNT_NO"));
				rowMap.put("TRANSFUSION_ACCOUNT_NO_ID", iMap.getString("TRANSFUSION_ACCOUNT_NO_ID"));
				addAccountChooseCollectionTypeChannelSource(iMap, rowMap);
				if (iMap.getBoolean("DAY_SELECTED")) {
					rowMap.put("TRANSFER_DAY_RULE", "(" + iMap.getString("DAY_COUNT") + " " + iMap.getString("DAY_TYPE") + " sonra aktar�ls�n)");
					rowMap.put("TRANSFER_DAY_OPTION", 1);
					rowMap.put("DAY_TYPE_ID", iMap.getString("DAY_TYPE_ID"));
				} else if (iMap.getBoolean("MANUEL_DAY_SELECTED")) {
					rowMap.put("TRANSFER_DAY_OPTION", 2);

					for (int row = 0; row < iMap.getSize("MANUEL_DAY_MATCHING"); row++) {

						boolean sonraki_hafta = iMap.getBoolean("MANUEL_DAY_MATCHING", row, "SONRAKI_HAFTA");
						String startDate = iMap.getString("MANUEL_DAY_MATCHING", row, "GELEN_GUN");
						String endDate = iMap.getString("MANUEL_DAY_MATCHING", row, "CIKIS_GUNU");
						transfusionDay += "(";
						transfusionDayId += "(";
						if (sonraki_hafta) {
							transfusionDay += startDate + "->" + endDate;
							transfusionDayId += startDate + "->" + endDate + "->" + sonraki_hafta;
						} else {
							if (DayDifference.getInstance().getDifferance(startDate, endDate) >= 0) {
								transfusionDay += startDate + "->" + endDate;
								transfusionDayId += startDate + "->" + endDate;
							}
						}
						transfusionDay += ")";
						transfusionDayId += ")";
						if (row + 1 < iMap.getSize("MANUEL_DAY_MATCHING")) {
							transfusionDay += ",";
							transfusionDayId += ",";
						}
					}
					rowMap.put("TRANSFER_DAY_RULE", transfusionDay);
					rowMap.put("TRANSFER_DAY_RULE_ID", transfusionDayId);

				}
				if (iMap.getBoolean("MONTH_DAY_SELECTED")) {
					if (StringUtils.isNotBlank(iMap.getString("MONTH_DAY"))) {
						rowMap.put("TRANSFER_MONTH_OPTION", 1);
						rowMap.put("TRANSFER_MONTH_RULE", iMap.getString("MONTH_DAY") + ". g�n� yap�ls�n");
					}
				} else if (iMap.getBoolean("MANUEL_MONTH_SELECTED")) {
					if (StringUtils.isNotBlank(iMap.getString("MANUEL_MONTH_DAY_START")) && StringUtils.isNotBlank(iMap.getString("MANUEL_MONTH_DAY_END"))) {
						rowMap.put("TRANSFER_MONTH_OPTION", 2);
						rowMap.put("TRANSFER_MONTH_RULE", iMap.getString("MANUEL_MONTH_DAY_START") + ". g�n� gelen ay�n " + iMap.getString("MANUEL_MONTH_DAY_END") + ". g�n� yap�ls�n");
					}
				}
				rowMap.put("VACATION_TYPE", iMap.getString("VACATION_TYPE"));
				rowMap.put("VACATION_TYPE_ID", iMap.getString("VACATION_TYPE_ID"));

				rowMap.put("TRANSFER_TYPE_ID", iMap.getString("TRANSFER_TYPE_ID"));
				rowMap.put("TRANSFER_TYPE", iMap.getString("TRANSFER_TYPE"));
				rowMap.put("TRANSFER_DESC", iMap.getString("TRANSFER_DESC"));
				oMap.put("ACCOUNT_TRANSFER_ROW_DATA", rowMap);
			}
		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}

		return oMap;
	}

	private static void addAccountChooseCollectionTypeChannelSource(GMMap iMap, GMMap rowMap) {
		String collectionChannelSource = "";
		for (int j = 0; j < iMap.getSize("ACCOUNT_RESOURCES"); j++) {
			if (iMap.getBoolean("ACCOUNT_RESOURCES", j, "CHOOSE")) {
				collectionChannelSource = (StringUtils.isBlank(collectionChannelSource) ? "" : collectionChannelSource + ",") + "(" + iMap.getString("ACCOUNT_RESOURCES", j, "COLLECTION_NAME") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "SOURCE_NAME") + "<->"
						+ iMap.getString("ACCOUNT_RESOURCES", j, "CHANNEL_NAME") + ")";
				rowMap.put(
						"COLLECTION_CHANNEL_SOURCE_ID",
						(StringUtils.isBlank(rowMap.getString("COLLECTION_CHANNEL_SOURCE_ID")) ? "" : rowMap.getString("COLLECTION_CHANNEL_SOURCE_ID") + ",") + iMap.getString("ACCOUNT_RESOURCES", j, "COLLECTION_TYPE") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "SOURCE_CODE") + "<->"
								+ iMap.getString("ACCOUNT_RESOURCES", j, "CHANNEL_CODE") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "ACCOUNT_COLLECTION_OID"));
			}
		}
		rowMap.put("COLLECTION_CHANNEL_SOURCE", StringUtils.isNotBlank(collectionChannelSource) ? collectionChannelSource : "");
	}

	public static GMMap validationAccountTransfer(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("OPERATION", true);
		try {
			validationDomain(iMap, "TRANSFER_TYPE_ID", oMap, "Aktar�m tipini se�melisiniz.");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;
			if (iMap.getString("SOURCE_ACCOUNT_NO").equalsIgnoreCase(iMap.getString("TRANSFUSION_ACCOUNT_NO"))) {
				validationExtra("SOURCE_ACCOUNT_NO", oMap, "Kaynak Hesap ve Aktar�m hesab� ayn� olamaz");
				return oMap;
			}
			if (iMap.getBoolean("DAY_SELECTED") && ((StringUtils.isBlank(iMap.getString("DAY_COUNT")) || (StringUtils.isNotBlank(iMap.getString("DAY_COUNT")) && (Integer.valueOf(iMap.getString("DAY_COUNT")).intValue() < 0))) || StringUtils.isBlank(iMap.getString("DAY_TYPE_ID")))) {
				validationDomain(iMap, "DAY_COUNT", oMap, "Aktar�mlar i�in g�n de�eri uygun bir de�er girilmelidir.");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;
				validationDomain(iMap, "DAY_TYPE_ID", oMap, "Aktar�mlar i�in g�n tipini se�melisiniz.");
				if (!oMap.getBoolean("OPERATION"))
					return oMap;

			} else if (iMap.getBoolean("MANUEL_DAY_SELECTED")) {
				boolean checkTransfer = false;
				for (int index = 0; index < iMap.getSize("MANUEL_DAY_MATCHING"); index++) {
					iMap.getString("MANUEL_DAY_MATCHING", index, "GELEN_GUN");
					iMap.getString("MANUEL_DAY_MATCHING", index, "CIKIS_GUNU");

					if (StringUtils.isBlank(iMap.getString("MANUEL_DAY_MATCHING", index, "CIKIS_GUNU"))) {
						checkTransfer = true;
						break;
					}

				}
				if (checkTransfer) {
					validationExtra("MANUEL_DAY_MATCHING", oMap, "Aktar�m g�nleri i�in ��k�� g�n de�eri girilmelidir.");
					return oMap;
				}
			} else if (!(iMap.getBoolean("DAY_SELECTED") || iMap.getBoolean("MANUEL_DAY_SELECTED"))) {
				validationExtra("DAY_SELECTED", oMap, "Aktar�mlar tipi se�ilmelidir.");
				return oMap;
			}
			if (iMap.getBoolean("MONTH_DAY_SELECTED") && (StringUtils.isNotBlank(iMap.getString("MONTH_DAY")) && (Integer.valueOf(iMap.getString("MONTH_DAY")).intValue() < 1 || Integer.valueOf(iMap.getString("MONTH_DAY")).intValue() > 31))) {
				validationExtra("MONTH_DAY_SELECTED", oMap, "Aktar�mlar ay�n ... g�n� yap�ls�n alan�n� uygun �ekilde doldurunuz.");
				return oMap;
			}

			if (iMap.getBoolean("MANUEL_MONTH_SELECTED") && (StringUtils.isBlank(iMap.getString("MANUEL_MONTH_DAY_START")) ^ StringUtils.isBlank(iMap.getString("MANUEL_MONTH_DAY_END")))) {
				validationExtra("MANUEL_MONTH_SELECTED", oMap, "Aktar�mlar ay�n ... g�n�ne gelen ay�n .... g�n� yap�ls�n alan�n� uygun �ekilde doldurunuz.");
				return oMap;
			}
			if (iMap.getBoolean("MANUEL_MONTH_SELECTED") && (StringUtils.isNotBlank(iMap.getString("MANUEL_MONTH_DAY_END")) && (Integer.valueOf(iMap.getString("MANUEL_MONTH_DAY_END")).intValue() < 1 || Integer.valueOf(iMap.getString("MANUEL_MONTH_DAY_END")).intValue() > 31))) {
				validationExtra("MANUEL_MONTH_SELECTED", oMap, "Aktar�mlar ay�n ... g�n�ne gelen ay�n .... g�n� yap�ls�n alan�n� uygun �ekilde doldurunuz.");
				return oMap;
			}
			if (iMap.getBoolean("MANUEL_MONTH_SELECTED") && (StringUtils.isNotBlank(iMap.getString("MANUEL_MONTH_DAY_START")) && (Integer.valueOf(iMap.getString("MANUEL_MONTH_DAY_START")).intValue() < 1 || Integer.valueOf(iMap.getString("MANUEL_MONTH_DAY_START")).intValue() > 31))) {
				validationExtra("MANUEL_MONTH_SELECTED", oMap, "Aktar�mlar ay�n ... g�n�ne gelen ay�n .... g�n� yap�ls�n alan�n� uygun �ekilde doldurunuz.");
				return oMap;
			}

			validationDomain(iMap, "VACATION_TYPE", oMap, "Tatil g�nlerinde aktar�m yap�ls�n alan� doldurulmal�d�r!");
			if (!oMap.getBoolean("OPERATION"))
				return oMap;

			boolean hadAccountResources = false;
			for (int j = 0; j < iMap.getSize("ACCOUNT_RESOURCES"); j++) {
				if (iMap.getBoolean("ACCOUNT_RESOURCES", j, "CHOOSE")) {
					hadAccountResources = true;
					break;
				}
			}
			String[] accountDefTypeArr = iMap.getString("SOURCE_ACCOUNT_NO_ID").split("-");
			if (!hadAccountResources && DatabaseConstants.AccountDefinitionTypes.CollectionAccount.equalsIgnoreCase(accountDefTypeArr[0])) {
				validationExtra("ACCOUNT_RESOURCES", oMap, "En az bir adet �deme tipi,kanal,kaynak bilgisi se�ilmelidir.");
				return oMap;
			}
			System.out.println(iMap);
			int rowIndex = StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_ROW")) ? Integer.valueOf(iMap.getString("ACCOUNT_TRANSFER_ROW")).intValue() : -1;
			boolean haveSameAccountTransfer = false;
			for (int row = 0; row < iMap.getSize("ACCOUNT_TRANSFER_DATA"); row++) {
				if (rowIndex != row
						&& (iMap.getString("SOURCE_ACCOUNT_NO_ID").equalsIgnoreCase(iMap.getString("ACCOUNT_TRANSFER_DATA", row, "SOURCE_ACCOUNT_NO_ID")) && iMap.getString("TRANSFUSION_ACCOUNT_NO_ID").equalsIgnoreCase(iMap.getString("ACCOUNT_TRANSFER_DATA", row, "TRANSFUSION_ACCOUNT_NO_ID")))) {
					if (StringUtils.isNotBlank(iMap.getString("ACCOUNT_TRANSFER_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID"))) {
						List<String> accountChannelSourceCodes = Arrays.asList(iMap.getString("ACCOUNT_TRANSFER_DATA", row, "COLLECTION_CHANNEL_SOURCE_ID").split(","));
						for (String accountChannelSourceCode : accountChannelSourceCodes) {
							for (int j = 0; j < iMap.getSize("ACCOUNT_RESOURCES"); j++) {
								if (iMap.getBoolean("ACCOUNT_RESOURCES", j, "CHOOSE")) {
									String collectionChannelSource = iMap.getString("ACCOUNT_RESOURCES", j, "COLLECTION_TYPE") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "SOURCE_CODE") + "<->" + iMap.getString("ACCOUNT_RESOURCES", j, "CHANNEL_CODE") + "<->"
											+ (!iMap.getString("ACCOUNT_RESOURCES", j, "ACCOUNT_COLLECTION_OID").equalsIgnoreCase("null") ? iMap.getString("ACCOUNT_RESOURCES", j, "ACCOUNT_COLLECTION_OID") : "");
									if (accountChannelSourceCode.replace("null", "").equalsIgnoreCase(collectionChannelSource)) {
										haveSameAccountTransfer = true;
										break;
									}
								}
							}
							if (haveSameAccountTransfer)
								break;
						}
						if (haveSameAccountTransfer)
							break;
					}
				}
			}
			if (haveSameAccountTransfer) {
				validationExtra("ACCOUNT_RESOURCES", oMap, "Daha �nce ayn� kaynak ve aktar�m hesab� i�in ayn� �deme tipi, kanal, kaynak bilgileri se�ilmi�. ");
				return oMap;
			}

		} catch (Exception ex) {
			oMap.put("OPERATION", false);
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("CDM_ACCOUNT_TRANSFER_INITIALIZE")
	public static GMMap getAccountTransferInitialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap oMapMatching = ServiceExecuter.call("CDM_GET_TRANSFER_DAY_MATCHINGS", (new GMMap()).put("KOD", iMap.getString("CDM_AKTARIM_GUNLERI")));
			oMap.put("DAY_MATCHING_EXIT_DAY", oMapMatching.get("RESULTS"));
			oMap.put("DAY_MATCHING", oMapMatching.get("DAY_MATCHING"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_ACCOUNT_TRANSFER_SOURCE_CHANGE")
	public static GMMap changeAccountTransferSource(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (StringUtils.isNotBlank(iMap.getString("SOURCE_ACCOUNT_NO_ID"))) {
				String[] accountDefTypeArr = iMap.getString("SOURCE_ACCOUNT_NO_ID").split("-");
				if (DatabaseConstants.AccountDefinitionTypes.UsageAccount.equalsIgnoreCase(accountDefTypeArr[0])||DatabaseConstants.AccountDefinitionTypes.BlockedAccount.equalsIgnoreCase(accountDefTypeArr[0])) {
					oMap.put("TRANSFER_RESOURCES_VISIBLE", false);
				} else {
					oMap.put("TRANSFER_RESOURCES_VISIBLE", true);
				}
			} else {
				oMap.put("TRANSFER_RESOURCES_VISIBLE", true);
			}
			if (oMap.getBoolean("TRANSFER_RESOURCES_VISIBLE")) {
				String sourceAccountNoId = null;
				;
				GMMap rowMap = iMap.getMap("ACCOUNT_TRANSFER_ROW_DATA");
				if (iMap.getMap("ACCOUNT_TRANSFER_ROW_DATA") != null && StringUtils.isNotBlank(rowMap.getString("SOURCE_ACCOUNT_NO_ID")) && StringUtils.isBlank(iMap.getString("SOURCE_ACCOUNT_NO_ID"))) {
					sourceAccountNoId = rowMap.getString("SOURCE_ACCOUNT_NO_ID");
				} else {
					sourceAccountNoId = iMap.getString("SOURCE_ACCOUNT_NO_ID");
					if (sourceAccountNoId == null && iMap.getSize("ACCOUNT_LIST") > 0) {
						sourceAccountNoId = iMap.getString("ACCOUNT_LIST", 0, "ACCOUNT_DEFINITION_TYPE") + "-" + iMap.getString("ACCOUNT_LIST", 0, "ACCOUNT_NUMBER");
					}
				}
				GMMap tempMap = getAccountCollectionTypeChannelSourceList(iMap, sourceAccountNoId);
				tempMap.put("ACCOUNT_TRANSFER_ROW", iMap.getString("ACCOUNT_TRANSFER_ROW"));
				getAccountChooseCollectionTypeChannelSource(tempMap, rowMap, oMap);
				// oMap.put("ACCOUNT_RESOURCES", iMap.get("ACCOUNT_RESOURCES"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_LOAD_MACTH_SUBSCRIBER_TYPE_LIST")
	public static GMMap getMatcSubscribeTypeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			// StringBuilder sb = new StringBuilder();
			// sb.append("SELECT distinct d.oid VALUE,(select collection_name from cdm.collection_type_prm ef where ef.collection_type=f.collection_type) NAME FROM cdm.subscriber_mask_def").append(iMap.getString("TYPE").equalsIgnoreCase("E") ? "" : "_tx").append(" f,");
			// sb.append(" cdm.subscriber_mask_detail").append(iMap.getString("TYPE").equalsIgnoreCase("E") ? "" : "_tx").append(" d WHERE f.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("'");
			// sb.append(" AND d.mask_oid = f.oid and d.use_for_inquiry = 1");
			// sb.append(" AND f.status = 1 AND d.status = 1 ORDER BY 1");
			// oMap = DALUtil.getResults(sb.toString(), "MATC_SUBSCRIBE_LIST");

			for (int j = 0; j < iMap.getSize("SUBSCRIBER_LIST"); j++) {
				oMap.put("MATCH_SUBSCRIBER_LIST", j, "VALUE", iMap.getString("SUBSCRIBER_LIST", j, "COLLECTION_TYPE") + "-" + iMap.getString("SUBSCRIBER_LIST", j, "LABEL"));
				oMap.put("MATCH_SUBSCRIBER_LIST", j, "NAME", iMap.getString("SUBSCRIBER_LIST", j, "COLLECTION_NAME") + "-" + iMap.getString("SUBSCRIBER_LIST", j, "LABEL"));
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_GET_ACCOUNT_SUBSCRIBERS")
	public static GMMap getTemerkuzSubscriber(GMMap iMap) {
		GMMap oMap = new GMMap();
		List<?> listAccMatchTree = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			StringBuilder sb = new StringBuilder();
			if (!"MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION")) && (StringUtils.isBlank(iMap.getString("CORPORATE_STATUS_INCOMPLETE")) || !iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"))
					&& (StringUtils.isBlank(iMap.getString("ACCOUNT_MATCHING_SUBSCRIBERS_SAVE")) || !iMap.getString("ACCOUNT_MATCHING_SUBSCRIBERS_SAVE").equalsIgnoreCase("true"))) {
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.TEMERKUZ_SUBSCRIBER_IF,iMap.getString("CORPORATE_OID")));
//				sb.append(" select distinct m.oid label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name");
//				sb.append(" from cdm.collection_type_prm ef,cdm.subscriber_mask_def  d,cdm.subscriber_mask_detail m ,cdm.account_matching_tree t ");
//				sb.append(" where ef.collection_type=d.collection_type ");
//				sb.append(" and m.mask_oid=d.oid and  d.corporate_oid='").append(iMap.getString("CORPORATE_OID")).append("' and m.oid=t.label");
//				sb.append(" and t.corporate_oid=d.corporate_oid AND t.status = 1 ");
			} else {
				sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.TEMERKUZ_SUBSCRIBER_ELSE,iMap.getString("CORPORATE_OID")));
//				sb.append(" select distinct m.oid label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name");
//				sb.append(" from cdm.collection_type_prm ef,cdm.subscriber_mask_def_tx  d,cdm.subscriber_mask_detail_tx m ,cdm.account_matching_tree_tx t ");
//				sb.append(" where ef.collection_type=d.collection_type ");
//				sb.append(" and m.mask_oid=d.oid and  d.corporate_oid='").append(iMap.getString("CORPORATE_OID")).append("' and m.oid=t.label");
//				sb.append(" and t.corporate_oid=d.corporate_oid AND t.status = 1 ");
			}
			listAccMatchTree = session.createSQLQuery(sb.toString()).list();
			for (int row = 0; row < listAccMatchTree.size(); row++) {
				Object[] gilPr = (Object[]) (listAccMatchTree.get(row));
				oMap.put("ACCOUNT_SUBSCRIBERS", row, "SUBSCRIBER_NO", gilPr[1]);
				oMap.put("ACCOUNT_SUBSCRIBERS", row, "CHILD_CORPORATE_NAME", gilPr[2]);
				oMap.put("ACCOUNT_SUBSCRIBERS", row, "DEFINITION_ID", gilPr[3]);

			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_LOAD_MATCHING_SUBSCRIBER_LIST")
	public static GMMap getMatchingSubscriber(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			StringBuilder sb = new StringBuilder();
			if (StringUtils.isBlank(iMap.getString("ACCOUNT_MATCHING_SUBSCRIBERS")) || (StringUtils.isNotBlank(iMap.getString("ACCOUNT_MATCHING_SUBSCRIBERS")) && iMap.getSize("ACCOUNT_MATCHING_SUBSCRIBERS") <= 0)) {
				if (!("MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION")) || iMap.getBoolean("CORPORATE_STATUS_INCOMPLETE"))) {
					sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.MATCHING_SUBSCRIBER_IF,iMap.getString("CORPORATE_OID")));
//					sb.append(" select distinct d.collection_type||'-'||m.label label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name");
//					sb.append(" from cdm.collection_type_prm ef,cdm.subscriber_mask_def  d,cdm.subscriber_mask_detail m ,cdm.account_matching_tree t ");
//					sb.append(" where ef.collection_type=d.collection_type ");
//					sb.append(" and m.mask_oid=d.oid and  d.corporate_oid='").append(iMap.getString("CORPORATE_OID")).append("' and m.oid=t.label");
//					sb.append(" and t.corporate_oid=d.corporate_oid AND t.status = 1 ");
				} else {
					sb.append(String.format(QueryRepository.CorporationDefinitionServicesRepository.MATCHING_SUBSCRIBER_ELSE,iMap.getString("CORPORATE_OID")));
//					sb.append(" select distinct d.collection_type||'-'||m.label label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name");
//					sb.append(" from cdm.collection_type_prm ef,cdm.subscriber_mask_def_tx  d,cdm.subscriber_mask_detail_tx m ,cdm.account_matching_tree_tx t ");
//					sb.append(" where ef.collection_type=d.collection_type ");
//					sb.append(" and m.mask_oid=d.oid and  d.corporate_oid='").append(iMap.getString("CORPORATE_OID")).append("' and m.oid=t.label");
//					sb.append(" and t.corporate_oid=d.corporate_oid AND t.status = 1 ");
				}
				oMap = DALUtil.getResults(sb.toString(), "MATCHING_LIST");
			} else {
				oMap.put("MATCHING_LIST", iMap.get("ACCOUNT_MATCHING_SUBSCRIBERS"));
			}
			if (!iMap.getBoolean("ACCOUNT_SELECTED_ROW_DATA")) {
				for (int row = 0; row < oMap.getSize("MATCHING_LIST"); row++) {
					oMap.put("MATCHING_LIST", row, "CHOOSE", false);
				}
			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_SAVE_EFT_TRANSFER_EMAIL_DEF")
	public static GMMap saveEftTransferEmailDef(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			String corporateCode = input.getString("CORPORATE_CODE");
			Boolean emailEftTransfer = input.getBoolean("EMAIL_EFT_TRANSFER");
			String eftEmailList = input.getString("EFT_EMAIL_LIST");
			
			if(emailEftTransfer) {
				if(StringUtils.isEmpty(eftEmailList))
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Email Adresleri"));
				
				List<String> mailList = Arrays.asList(eftEmailList.split("[,]"));				
				for (String mail : mailList) {
					mail = mail.trim();
					if (!CommonHelper.isValidEmailAddress(mail))
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDEMAILADDRESS, String.format(" \"%s\"", mail)));
				}						
			}
			
			BalanceTransferEftEmailDef emailDef = (BalanceTransferEftEmailDef)session.createCriteria(BalanceTransferEftEmailDef.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("corporateCode", corporateCode))
												.uniqueResult();
			if(emailDef != null) {
				emailDef.setStatus(false);
				session.update(emailDef);
			}
			
			BalanceTransferEftEmailDef newEmailDef = new BalanceTransferEftEmailDef();
			newEmailDef.setStatus(true);
			newEmailDef.setCorporateCode(corporateCode);
			newEmailDef.setEmailEftTransfer(emailEftTransfer);
			newEmailDef.setEftEmailList(eftEmailList);
			newEmailDef.setCreateDate(new Date());
			session.save(newEmailDef);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_GET_EFT_TRANSFER_EMAIL_DEF")
	public static GMMap getEftTransferEmailDef(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			String corporateCode = input.getString("CORPORATE_CODE");

			BalanceTransferEftEmailDef emailDef = (BalanceTransferEftEmailDef)session.createCriteria(BalanceTransferEftEmailDef.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("corporateCode", corporateCode))
												.uniqueResult();
			if(emailDef != null) {
				output.put("EMAIL_EFT_TRANSFER", emailDef.isEmailEftTransfer());
				output.put("EFT_EMAIL_LIST", emailDef.getEftEmailList());
			} else {
				output.put("EMAIL_EFT_TRANSFER", false);
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
}