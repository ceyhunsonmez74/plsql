package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporateChannelPrm;
import tr.com.aktifbank.bnspr.dao.CorporateParameters;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;

public class CorporationChannelParameterServices {
	
	private static boolean controlValues(GMMap iMap, String tableName) {

		boolean control = false;		
		
		for(int index = 0 ;  index<iMap.getSize(tableName) ; index++) {							
			String key = iMap.getString(tableName,index,"KEY");
		    String value = iMap.getString(tableName,index,"VALUE");		
		
		    if (StringUtils.isBlank(key) || StringUtils.isBlank(value)) {
				control = true; 
				return control; 
			}
		} 
		return control;
	}	

	@GraymoundService("CDM_GET_CHANNELS_COMBO")
	public static GMMap getChannelsCombo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {					
			
			String listName = "CHANNEL_LIST", query;
			String corporateOid = iMap.getString("CORPORATE_OID");
			
			if (corporateOid != null)								
				query = String.format(QueryRepository.CorporationChannelParameterServicesRepository.CHANNELS_BY_CORPORATE_OID_QUERY, corporateOid);							
			else
				query = QueryRepository.CorporationChannelParameterServicesRepository.CHANNELS_QUERY;
			
			GMMap output = DALUtil.getResults(query, listName);
			
			if (output.getSize(listName) == 0 && corporateOid != null) {
				//CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEXISTINGCORPORATECHANNEL)); Genel Vergi Kurumlari Icin Kapatildi			
			}				
			
			if (iMap.getBoolean("EMPTY_KEY"))
				GuimlUtil.wrapMyCombo(oMap, listName, null, "Hepsi");				
			for (int i = 0; i < output.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(oMap, listName, output.get(listName, i, "KOD").toString(), output.get(listName, i, "ACIKLAMA").toString());
			}
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}	
	
	@GraymoundService("CDM_GET_PAYMENT_SOURCES_COMBO")
	public static GMMap getPaymentSourceCombo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {			
			String query = null;
			String corporateOid = iMap.getString("CORPORATE_OID");
			String channelCode = iMap.getString("CHANNEL_CODE");
			
			if (corporateOid != null && channelCode != null)								
				query = String.format(QueryRepository.CorporationChannelParameterServicesRepository.SOURCES_BY_CHANNEL_QUERY, corporateOid, channelCode);	 							
			else
				query = QueryRepository.CorporationChannelParameterServicesRepository.SOURCES_QUERY;
			
			oMap = DALUtil.fillComboBox(iMap, "PAYMENT_SOURCE_LIST", false, query);
			return oMap;
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_GET_PAYMENT_SOURCES_COMBO_WITH_EMPTY_KEY")
	public static GMMap getPaymentSourceComboWithEmptyKey(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {			
			
			String listName = "PAYMENT_SOURCE_LIST";
			String sql = QueryRepository.CorporationChannelParameterServicesRepository.SOURCES_QUERY;
			GMMap output = DALUtil.getResults(sql, listName);
			
			GuimlUtil.wrapMyCombo(oMap, listName, null, "Hepsi");
			for (int i = 0; i < output.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(oMap, listName, output.get(listName, i, "SOURCE_CODE").toString(), output.get(listName, i, "SOURCE_NAME").toString());
			}
			
			return oMap;
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	@GraymoundService("CDM_GET_PAYMENT_COLLECTION_TYPES_COMBO")
	public static GMMap getPaymentCollectionTypeCombo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String tableName = "COLLECTION_TYPE_LIST";
		Object[] inputValues	= new Object[2];
		try {
			
			String sql = "{? = call CDM.PKG_TRN7002.GET_COLLECTION_TYPES(?)}";
			
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("CORPORATE_OID");

			GMMap resultMap = DALUtil.callOracleRefCursorFunction(sql, tableName, inputValues);
			
			if (resultMap.getSize(tableName) == 0) {
				//CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEXISTINGCOLLECTIONTYPE)); Genel Vergi Kurumlari Icin Kapatildi			
			}
				
			GuimlUtil.wrapMyCombo(oMap, tableName, " ", "Hepsi");
			for(int index = 0 ; index < resultMap.getSize(tableName); index++) {
				GuimlUtil.wrapMyCombo(oMap, tableName , resultMap.getString(tableName, index, "COLLECTION_TYPE"),
														resultMap.getString(tableName, index, "COLLECTION_NAME"));				
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
	}	

	@GraymoundService("CDM_GET_CORP_CHANNEL_LIST")
	public static GMMap getCorpChannelList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Object[] inputValues	= new Object[2];	
		try {

			String func = "{? = call CDM.PKG_TRN7002.GET_CORP_CHANNEL_LIST(?)}";
			
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KURUM_KODU");
			
			oMap = DALUtil.callOracleRefCursorFunction(func, "CORP_CHANNEL_LIST", inputValues);
			return oMap;

		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	@GraymoundService("CDM_SAVE_CORP_CHANNEL")
	public static GMMap saveCorpChannel(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			session.getTransaction().begin();
			
			String oId = iMap.getString("OID");	
			String kurumDegeri = iMap.getString("KURUM_DEGERI");
			String odemeKanali = iMap.getString("ODEME_KANALI");
			String odemeTipi = iMap.getString("ODEME_TIPI");
			String odemeKaynagi = iMap.getString("ODEME_KAYNAGI");
			String kurumKodu = iMap.getString("KURUM_KODU");
			String islemTipi = iMap.getString("ISLEM_TIPI");		
			
			if (odemeTipi == null) {
				oMap.put("HATA", true);
				oMap.put("MESSAGE", "Kuruma ba�l� �deme tipi tan�m� yap�lmam��t�r.");	
				return oMap;
			}			
			
			if (odemeKaynagi == null) {
				oMap.put("HATA", true);
				oMap.put("MESSAGE", "Se�ilen �deme kanal�na ba�l� �deme kayna�� bulunamam��t�r.");	
				return oMap;
			}		
			
			if("GUNCELLE".equals(islemTipi) || "EKLE".equals(islemTipi)) {
			    if (StringUtils.isBlank(kurumDegeri)) {
					oMap.put("HATA", true);
					oMap.put("MESSAGE", "Kurum de�eri alan� bo� olamaz.");	
					return oMap;
				}
			}
			
			CorporateChannelPrm corporateChannelPrm = (CorporateChannelPrm) session.createCriteria(CorporateChannelPrm.class).add(Restrictions.eq("oid", oId)).uniqueResult();

			if("GUNCELLE".equals(islemTipi)) {
				if(corporateChannelPrm != null){				
					corporateChannelPrm.setStatus(false);
					corporateChannelPrm.setUpdateDate(sdf.format(new Date()));
					corporateChannelPrm.setUpdateUser(username);
					
					session.saveOrUpdate(corporateChannelPrm);
	
					CorporateChannelPrm newCorporateChannelPrm = new CorporateChannelPrm();
					newCorporateChannelPrm.setStatus(true);				
					newCorporateChannelPrm.setCorporateCode(kurumKodu);			
					newCorporateChannelPrm.setSourceCode(odemeKaynagi);					
					newCorporateChannelPrm.setChannelCode(odemeKanali);
					if(" ".equals(odemeTipi))
						newCorporateChannelPrm.setCollectionType(null);
					else
						newCorporateChannelPrm.setCollectionType(Short.parseShort(odemeTipi));
					newCorporateChannelPrm.setCorporateConstant(kurumDegeri);
					newCorporateChannelPrm.setCreateDate(sdf.format(new Date()));
					newCorporateChannelPrm.setCreateUser(username);
					
					session.saveOrUpdate(newCorporateChannelPrm);	
					oMap.put("SELECTED_OID", newCorporateChannelPrm.getOid());
				}
			} 
			else if("SIL".equals(islemTipi)) {
				if(corporateChannelPrm != null){
					corporateChannelPrm.setStatus(false);
					corporateChannelPrm.setUpdateDate(sdf.format(new Date()));
					corporateChannelPrm.setUpdateUser(username);
					
					session.saveOrUpdate(corporateChannelPrm);
				}
			}	
			else if("EKLE".equals(islemTipi)) {			
				CorporateChannelPrm newCorporateChannelPrm = new CorporateChannelPrm();
				newCorporateChannelPrm.setStatus(true);				
				newCorporateChannelPrm.setCorporateCode(kurumKodu);			
				newCorporateChannelPrm.setSourceCode(odemeKaynagi);					
				newCorporateChannelPrm.setChannelCode(odemeKanali);
				if(" ".equals(odemeTipi))
					newCorporateChannelPrm.setCollectionType(null);
				else
					newCorporateChannelPrm.setCollectionType(Short.parseShort(odemeTipi));
				newCorporateChannelPrm.setCorporateConstant(kurumDegeri);
				newCorporateChannelPrm.setCreateDate(sdf.format(new Date()));
				newCorporateChannelPrm.setCreateUser(username);
				
				session.saveOrUpdate(newCorporateChannelPrm);		
				oMap.put("SELECTED_OID", "");
			}
			
			session.flush();
			session.getTransaction().commit();
			
			oMap.put("HATA", false);
			oMap.put("MESSAGE", "��leminiz tamamlanm��t�r.");
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}	
	@GraymoundService("CDM_GET_CORP_PARAMETER_LIST")
	public static GMMap getCorpParameterList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Object[] inputValues	= new Object[2];
		try {

			String func = "{? = call CDM.PKG_TRN7002.GET_CORP_PARAMETER_LIST(?)}";
			
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KURUM_KODU");
			
			oMap = DALUtil.callOracleRefCursorFunction(func, "CORP_PARAMETER_LIST", inputValues);
			return oMap;

		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	@GraymoundService("CDM_SAVE_CORP_PARAMETER_LIST")
	public static GMMap saveCorpParameterList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");			
			session.getTransaction().begin();
			
			String kurumKodu = iMap.getString("KURUM_KODU");
			String tableName = "CORP_PARAMETER_LIST";
					
			if (controlValues(iMap, tableName)) {
				oMap.put("HATA", true);
				oMap.put("MESSAGE", "Parametre Ad� ve Parametre De�eri alanlar� bo� de�er alamaz.");
				return oMap;
			}
			
			if (iMap.getSize(tableName) == 0) {
				oMap.put("HATA", true);
				oMap.put("MESSAGE", "Kay�t i�in uygun bilgi yoktur. L�tfen sat�r ekleyin.");
				return oMap;
			}
			
			for(int index = 0 ;  index<iMap.getSize(tableName) ; index++) {
				
				String oId = iMap.getString(tableName,index,"OID");	    
			    
				if (StringUtils.isNotBlank(oId)) {			    
				    CorporateParameters corporateParameters = (CorporateParameters) session.createCriteria(CorporateParameters.class).add(Restrictions.eq("oid", oId)).uniqueResult();			    		
												
					corporateParameters.setStatus(false);
					corporateParameters.setUpdateDate(sdf.format(new Date()));
					corporateParameters.setUpdateUser(username);
					
					session.saveOrUpdate(corporateParameters);							
					
					if(iMap.getBoolean(tableName,index,"SIL") == false) {						
						CorporateParameters newCorporateParameters = new CorporateParameters();
						newCorporateParameters.setStatus(true);					
						newCorporateParameters.setCorporateCode(kurumKodu);
						newCorporateParameters.setKey(iMap.getString(tableName,index,"KEY"));
						newCorporateParameters.setValue(iMap.getString(tableName,index,"VALUE"));
						newCorporateParameters.setCreateDate(sdf.format(new Date()));
						newCorporateParameters.setCreateUser(username);
						
						session.saveOrUpdate(newCorporateParameters);										
					}
				}
				else {
					if(iMap.getBoolean(tableName,index,"SIL") == false) {
						CorporateParameters newCorporateParameters = new CorporateParameters();
						newCorporateParameters.setStatus(true);					
						newCorporateParameters.setCorporateCode(kurumKodu);
						newCorporateParameters.setKey(iMap.getString(tableName,index,"KEY"));
						newCorporateParameters.setValue(iMap.getString(tableName,index,"VALUE"));
						newCorporateParameters.setCreateDate(sdf.format(new Date()));
						newCorporateParameters.setCreateUser(username);
						
						session.saveOrUpdate(newCorporateParameters);		
					}
				}
			}

			session.flush();
			session.getTransaction().commit();
			oMap.put("HATA", false);
			oMap.put("MESSAGE", "��leminiz tamamlanm��t�r.");
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}		

}
