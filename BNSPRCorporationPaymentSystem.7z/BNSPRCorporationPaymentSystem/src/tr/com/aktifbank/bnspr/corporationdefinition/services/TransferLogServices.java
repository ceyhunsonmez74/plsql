package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;
import tr.com.aktifbank.bnspr.dao.FileTransferLog;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TransferLogServices {

	@GraymoundService("CDM_GET_TRANSFER_LOG")
	public static GMMap getTransferLog(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			// get list of File Transfer Logs from FILE_TRANSFER_LOG table
			@SuppressWarnings("unchecked")
			List<FileTransferLog> transferLogs = session.createCriteria(FileTransferLog.class)
					.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE")))
					.add(Restrictions.eq("transferType", Short.parseShort(iMap.getString("TRANSFER_TYPE"))))
					.add(Restrictions.eq("ftmId", iMap.getString("FTM_ID")))
					.add(Restrictions.eq("transferStatus", Byte.parseByte(iMap.getString("TRANSFER_STATUS"))))
					.add(Restrictions.between("logDate", iMap.getString("DATE") + "000000", iMap.getString("END_DATE") + "235959")).list();

			for (int i = 0; i < transferLogs.size(); i++) {
				oMap.put("FILE_TRANSFER_LIST", i, "FILE_TRANSFER_ID", transferLogs.get(i).getFileTransferId());
				oMap.put("FILE_TRANSFER_LIST", i, "BATCH_NAME", transferLogs.get(i).getBatchName());
				oMap.put("FILE_TRANSFER_LIST", i, "TRANSFER_TYPE", transferLogs.get(i).getTransferType());
				oMap.put("FILE_TRANSFER_LIST", i, "TRANSFER_STATUS", transferLogs.get(i).getTransferStatus());
				oMap.put("FILE_TRANSFER_LIST", i, "FTM_ID", transferLogs.get(i).getFtmId());
				oMap.put("FILE_TRANSFER_LIST", i, "FTM_SEQUENCE_NUMBER", transferLogs.get(i).getFtmSequenceNumber());
				oMap.put("FILE_TRANSFER_LIST", i, "LOG_DATE", transferLogs.get(i).getLogDate());
				oMap.put("FILE_TRANSFER_LIST", i, "ERROR_CODE", transferLogs.get(i).getErrorCode());
				oMap.put("FILE_TRANSFER_LIST", i, "ERROR_DESC", transferLogs.get(i).getErrorDesc());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap; // return list
	}

	@GraymoundService("GET_TRANSFER_STATUS")
	public static GMMap getTransferStatus(GMMap iMap) {
		// called with KOD , CDM_FILE_TRANSFER_STATUS
		// it returns list of file transfer status like successful and error
		
		if (iMap.containsKey("EMPTY_KEY") && iMap.getBoolean("EMPTY_KEY"))
			iMap.put("ADD_EMPTY_KEY", "HEPSI");
		return CorporationServiceUtil.getComboValues(iMap);
	}

	@GraymoundService("GET_TRANSFER_LINE_FILE_ERROR_LOG_DETAIL")
	public static GMMap getFileErrorLog(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		try {
			BigDecimal sq = new BigDecimal(iMap.getString("FTM_SEQUENCE_NUMBER"));
			// get list of error log from db - FILE_ERROR_LOG table
			@SuppressWarnings("unchecked")
			List<FileErrorLog> errorLogs = session.createCriteria(FileErrorLog.class).add(Restrictions.eq("ftmSequenceNumber", sq))
					.add(Restrictions.eq("ftmId", iMap.getString("FTM_ID"))).list();

			for (int i = 0; i < errorLogs.size(); i++) {
				oMap.put("FILE_ERROR_LIST", i, "BATCH_SUBMIT_ID", errorLogs.get(i).getBatchSubmitId());
				oMap.put("FILE_ERROR_LIST", i, "FTM_ID", errorLogs.get(i).getFtmId());
				oMap.put("FILE_ERROR_LIST", i, "FTM_SEQUENCE_NUMBER", errorLogs.get(i).getFtmSequenceNumber());
				oMap.put("FILE_ERROR_LIST", i, "PROCESS_DATE", errorLogs.get(i).getProcessDate());
				oMap.put("FILE_ERROR_LIST", i, "PROCESS_TIME", errorLogs.get(i).getProcessTime());
				oMap.put("FILE_ERROR_LIST", i, "LINE_NUMBER", errorLogs.get(i).getLineNumber());
				oMap.put("FILE_ERROR_LIST", i, "ERRONEOUS_LINE", errorLogs.get(i).getErroneousLine());
				oMap.put("FILE_ERROR_LIST", i, "ERROR_CODE", errorLogs.get(i).getErrorCode());
				oMap.put("FILE_ERROR_LIST", i, "ERROR_DESC", errorLogs.get(i).getErrorDesc());

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;

	}
}
