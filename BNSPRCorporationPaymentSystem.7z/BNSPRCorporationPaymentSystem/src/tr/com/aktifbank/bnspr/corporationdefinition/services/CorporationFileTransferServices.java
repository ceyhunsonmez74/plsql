package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;

public class CorporationFileTransferServices {

	@GraymoundService("CDM_GET_FTM_FILE_DEFS_COMBO")
	public static GMMap getFtmFileDefsCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			oMap = DALUtil.fillComboBox(iMap, "FTM_FILE_DEFS", false, QueryRepository.CorporationFileTransferServicesRepository.FTM_FILE_DEFS_QUERY);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_GET_TRANSFER_TYPES_COMBO")
	public static GMMap getTransferTypesCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			oMap = DALUtil.fillComboBox(iMap, "TRANSFER_TYPES", false, QueryRepository.CorporationFileTransferServicesRepository.FILE_TRANSFER_TYPES_QUERY);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_GET_CORP_BATCH_NAMES_COMBO")
	public static GMMap getBatchNamesCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			List<String> queryParameters = new ArrayList<String>();
			queryParameters.add(iMap.getString("CORPORATE_CODE"));

			iMap.put("QUERY_PARAMETERS", queryParameters);

			oMap = DALUtil.fillComboBox(iMap, "BATCH_NAMES", false, QueryRepository.CorporationFileTransferServicesRepository.BATCH_NAMES_QUERY);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_GET_CORP_FILE_TRANSFERS")
	public static GMMap getGetCorpFileTransferst(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "CORP_FILE_TRANSFERS";
		try {
			String corporateCode = iMap.getString("CORPORATE_CODE");
			Session hibernateSession = CommonHelper.getHibernateSession();

			@SuppressWarnings("unchecked")
			List<CorporateFileTransfer> fileTransfers = (List<CorporateFileTransfer>) hibernateSession.createCriteria(CorporateFileTransfer.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).list();

			int counter = 0;
			for (CorporateFileTransfer fileTransfer : fileTransfers) {
				StringBuilder s = null;
				if (iMap.containsKey("DB_SCHEMA") && ("COS").equals(iMap.getString("DB_SCHEMA")))
					s = new StringBuilder(QueryRepository.CorporationFileTransferServicesRepository.COS_TRANSFER_NAME_QUERY);
				else
					s = new StringBuilder(QueryRepository.CorporationFileTransferServicesRepository.CDM_TRANSFER_NAME_QUERY);
				String transferTypeName = DALUtil.getResult(String.format(s.toString(), fileTransfer.getTransferType()));
				s = new StringBuilder(QueryRepository.CorporationFileTransferServicesRepository.FTM_FILE_DEF_NAME_BY_OID_QUERY);
				String ftmIdName = DALUtil.getResult(String.format(s.toString(), fileTransfer.getFtmId()));

				oMap.put(tableName, counter, "OID", fileTransfer.getOid());
				oMap.put(tableName, counter, "TRANSFER_TYPE", fileTransfer.getTransferType().toString());
				oMap.put(tableName, counter, "TRANSFER_TYPE_NAME", transferTypeName);
				oMap.put(tableName, counter, "FTM_ID", fileTransfer.getFtmId().toString());
				oMap.put(tableName, counter, "FTM_ID_NAME", ftmIdName);
				oMap.put(tableName, counter, "FILE_TRANSFER_ID", fileTransfer.getFileTransferId());
				oMap.put(tableName, counter, "FORMAT_ID", fileTransfer.getFormatId());
				oMap.put(tableName, counter, "BATCH_NAME", fileTransfer.getBatchName());
				oMap.put(tableName, counter, "EXPLANATION", fileTransfer.getExplanation());
				oMap.put(tableName, counter, "SEND_PROVISION_AFTER_LOAD", fileTransfer.getSendProvisionAfterLoad());
				oMap.put(tableName, counter, "PROVISION_TRANSFER_ID", fileTransfer.getProvisionTransferId());
				oMap.put(tableName, counter, "COMPLEX_FILE_TRANSFER", fileTransfer.getComplexFileTransfer());
				if (fileTransfer.getLineSequence()!=null) {
					if (!"".equals(fileTransfer.getLineSequence())) {
						oMap.put(tableName, counter, "LINE_SEQUENCE", fileTransfer.getLineSequence());
					}
				}
				counter++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_SAVE_CORP_FILE_TRANSFERS")
	public static GMMap saveCorpFileTransfers(GMMap iMap) {

		GMMap oMap = new GMMap();

		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();

		String oId = iMap.getString("SELECTED_OID");
		String islemTipi = iMap.getString("ISLEM_TIPI");
		String corporateCode = iMap.getString("CORPORATE_CODE");
		String transferTypeStr = iMap.getString("TRANSFER_TYPE");
		BigDecimal ftmId = iMap.getBigDecimal("FTM_ID");
		String fileTransferId = iMap.getString("FILE_TRANSFER_ID");
		String formatId = iMap.getString("FORMAT_ID");
		String batchName = iMap.getString("BATCH_NAME");
		String explanation = iMap.getString("EXPLANATION");
		String provisionAfterLoad = iMap.getString("PROVISION_AFTER_LOAD");
		String provisionTransferId = iMap.getString("PROVISION_TRANSFER_ID");
		String complexFileTransfer = iMap.getString("COMPLEX_FILE_TRANSFER");
		String lineSequence = "";
		if (iMap.getString("LINE_SEQUENCE")!=null) {
			if (!"".equals(iMap.getString("LINE_SEQUENCE"))) {
				lineSequence = iMap.getString("LINE_SEQUENCE");		
			}
		}
		
		Short transferType = null;
		if (transferTypeStr != null)
			transferType = Short.parseShort(transferTypeStr);

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			session.getTransaction().begin();

			if (!"SIL".equals(islemTipi)) {
				if (batchName == null) {
					oMap.put("HATA", true);
					oMap.put("MESSAGE", "Se�ti�iniz kurum koduna ba�l� herhangi bir batch bulunmad��� i�in i�lem yapamazs�n�z. �nce se�ti�iniz kurumla ili�kili batch'leri tan�mlay�n�z.");
					return oMap;
				}

				if (StringUtils.isBlank(explanation)) {
					oMap.put("HATA", true);
					oMap.put("MESSAGE", "A��klama alan�n� doldurunuz.");
					return oMap;
				}

				if (StringUtils.isBlank(formatId)) {
					oMap.put("HATA", true);
					oMap.put("MESSAGE", "Dosya Desen ID alan� bo� olamaz. Dosya desen se�imi yap�n�z.");
					return oMap;
				}
				
				if (Boolean.parseBoolean(provisionAfterLoad) == true && StringUtils.isBlank(provisionTransferId)) {
					oMap.put("HATA", true);
					oMap.put("MESSAGE", "Provizyon Transfer ID alan�n� doldurunuz.");
					return oMap;
				}
				
			}

			if ("GUNCELLE".equals(islemTipi)) {
				if (StringUtils.isNotBlank(oId)) {
					CorporateFileTransfer corporateFileTransfer = (CorporateFileTransfer) session.createCriteria(CorporateFileTransfer.class).add(Restrictions.eq("oid", oId)).uniqueResult();
					corporateFileTransfer.setStatus(false);
					corporateFileTransfer.setUpdateDate(sdf.format(new Date()));
					corporateFileTransfer.setUpdateUser(username);

					session.saveOrUpdate(corporateFileTransfer);

					CorporateFileTransfer newCorporateFileTransfer = new CorporateFileTransfer();
					newCorporateFileTransfer.setStatus(true);
					newCorporateFileTransfer.setCorporateCode(corporateCode);
					newCorporateFileTransfer.setTransferType(transferType);
					newCorporateFileTransfer.setFtmId(ftmId);
					newCorporateFileTransfer.setFileTransferId(fileTransferId);
					newCorporateFileTransfer.setFormatId(formatId);
					if (lineSequence != null) {
						if (!"".equals(lineSequence)) {
							newCorporateFileTransfer.setLineSequence(Byte.parseByte(lineSequence));	
						}
					}
					newCorporateFileTransfer.setBatchName(batchName);
					newCorporateFileTransfer.setExplanation(explanation);
					if (provisionAfterLoad.equals("true"))
						newCorporateFileTransfer.setSendProvisionAfterLoad("1");
					else
						newCorporateFileTransfer.setSendProvisionAfterLoad("0");
					if (complexFileTransfer.equals("true"))
						newCorporateFileTransfer.setComplexFileTransfer(true);
					else
						newCorporateFileTransfer.setComplexFileTransfer(false);
					newCorporateFileTransfer.setProvisionTransferId(provisionTransferId);
					newCorporateFileTransfer.setCreateDate(sdf.format(new Date()));
					newCorporateFileTransfer.setCreateUser(username);

					session.saveOrUpdate(newCorporateFileTransfer);
					oMap.put("SELECTED_OID", newCorporateFileTransfer.getOid());
				}
			} else if ("SIL".equals(islemTipi)) {
				if (StringUtils.isNotBlank(oId)) {
					CorporateFileTransfer corporateFileTransfer = (CorporateFileTransfer) session.createCriteria(CorporateFileTransfer.class).add(Restrictions.eq("oid", oId)).uniqueResult();
					corporateFileTransfer.setStatus(false);
					corporateFileTransfer.setUpdateDate(sdf.format(new Date()));
					corporateFileTransfer.setUpdateUser(username);

					session.saveOrUpdate(corporateFileTransfer);
				}
			} else if ("EKLE".equals(islemTipi)) {
				CorporateFileTransfer newCorporateFileTransfer = new CorporateFileTransfer();
				newCorporateFileTransfer.setStatus(true);
				newCorporateFileTransfer.setCorporateCode(corporateCode);
				newCorporateFileTransfer.setTransferType(transferType);
				newCorporateFileTransfer.setFtmId(ftmId);
				newCorporateFileTransfer.setFileTransferId(CorporationServiceUtil.getSequenceCode("CORP_FILE_TRANSFERS"));
				newCorporateFileTransfer.setFormatId(formatId);
				if (lineSequence != null) {
						if (!"".equals(lineSequence)) {
							newCorporateFileTransfer.setLineSequence(Byte.parseByte(lineSequence));
						}
				}
				newCorporateFileTransfer.setBatchName(batchName);
				newCorporateFileTransfer.setExplanation(explanation);
				if (provisionAfterLoad.equals("true"))
					newCorporateFileTransfer.setSendProvisionAfterLoad("1");
				else
					newCorporateFileTransfer.setSendProvisionAfterLoad("0");
				if (complexFileTransfer.equals("true"))
					newCorporateFileTransfer.setComplexFileTransfer(true);
				else
					newCorporateFileTransfer.setComplexFileTransfer(false);
				newCorporateFileTransfer.setProvisionTransferId(provisionTransferId);
				newCorporateFileTransfer.setCreateDate(sdf.format(new Date()));
				newCorporateFileTransfer.setCreateUser(username);

				session.saveOrUpdate(newCorporateFileTransfer);
				oMap.put("SELECTED_OID", "");
			}

			session.flush();
			session.getTransaction().commit();

			oMap.put("HATA", false);
			oMap.put("MESSAGE", "��leminiz tamamlanm��t�r.");
			return oMap;

		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}

}