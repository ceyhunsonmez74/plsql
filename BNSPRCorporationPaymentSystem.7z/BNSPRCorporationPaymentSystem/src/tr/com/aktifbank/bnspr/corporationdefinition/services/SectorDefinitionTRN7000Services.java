package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.SectorDef;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;

public class SectorDefinitionTRN7000Services {
	
	@GraymoundService("CDM_TRN7000_GET_SECTORS_COMBO")
	public static GMMap getSectorsCombo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			//String func="{? = call CDM.PKG_TRN7000.TRN7000_GET_LIST}";
			String listName = getTableName(iMap);
			String exceptionalSectorCodes = iMap.getString("EXC_SECTOR_CODES", "");
			//GMMap resultMap  = DALUtil.callOracleRefCursorFunction(func,listName,new Object[0]);
			///
			GMMap resultMap=new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria cr=session.createCriteria(SectorDef.class).add(Restrictions.eq("status", true));
			if (iMap.containsKey("SECTOR_TYPE")) {
				if (!"".equals(iMap.getString("SECTOR_TYPE"))) {
					cr.add(Restrictions.eq("sectorType", iMap.getString("SECTOR_TYPE")));
				}
			}
			List<SectorDef> sectorList = cr.list();
			int i = 0;
			for (SectorDef sectorDef : sectorList) {
				resultMap.put(listName, i, "SECTOR_ACTIVENESS", sectorDef.getSectorActiveness());
				resultMap.put(listName, i, "SECTOR_ID", sectorDef.getOid());
				resultMap.put(listName, i, "SECTOR_NAME", sectorDef.getSectorName());
				resultMap.put(listName, i, "SECTOR_STATUS", "1");
				resultMap.put(listName, i, "SECTOR_CODE", sectorDef.getSectorCode());
				resultMap.put(listName, i, "CREATE_USER", sectorDef.getCreateUser());
				resultMap.put(listName, i, "CREATE_DATE", sectorDef.getCreateDate());
				resultMap.put(listName, i, "UPDATE_USER", sectorDef.getUpdateUser());
				resultMap.put(listName, i, "UPDATE_DATE", sectorDef.getUpdateDate());
				i++;
			}

			if(iMap.getBoolean("PLEASE_SELECT")){
				oMap.put(listName,0, "VALUE","SECIMYOK");
				oMap.put(listName,0, "NAME","L�tfen Sekt�r Se�iniz");
			}
			
			List<String> excSectorCodeList = StringUtil.isEmpty(exceptionalSectorCodes) ?
					new ArrayList<String>() : Arrays.asList(exceptionalSectorCodes.split(","));
			
			if (iMap.getString("EMPTY_KEY") != null && iMap.getBoolean("EMPTY_KEY"))
				GuimlUtil.wrapMyCombo(oMap, listName, null, "Hepsi");
			for(int index = 0 ; index<resultMap.getSize(listName); index++){
				if("1".equals(resultMap.getString(listName, index, "SECTOR_ACTIVENESS"))){
					if(!excSectorCodeList.contains(resultMap.getString(listName, index, "SECTOR_CODE"))){
						GuimlUtil.wrapMyCombo(oMap, listName , resultMap.getString(listName, index, "SECTOR_CODE"),
								resultMap.getString(listName, index, "SECTOR_NAME"));
					}
				}
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static String getTableName(GMMap iMap){
		String tableName = "SECTOR_DEF";
		if (iMap.containsKey("TABLE_NAME")){
			tableName = iMap.getString("TABLE_NAME");
		}
		return tableName;
	}
	@GraymoundService("CDM_TRN7000_CAN_SECTOR_BE_DELETED")
	public static GMMap canSectorBeDeleted(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SectorDef sd=(SectorDef) session.createCriteria(SectorDef.class)
					.add(Restrictions.eq("oid", iMap.getString("SECTOR_ID"))).add(Restrictions.eq("status", true)).uniqueResult();
			
			if(sd == null){
				oMap.put("CAN_BE_DELETED", "Y");
			}
			else{
				@SuppressWarnings("unchecked")
				List<CorporateMaster> cm= session.createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("sectorCode", sd.getSectorCode())).add(Restrictions.eq("status", true)).list();
				
				if (cm.size()>0) {
					oMap.put("CAN_BE_DELETED", "N");
				}else{
					oMap.put("CAN_BE_DELETED", "Y");
				}
			}
		} catch (HibernateException e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	@GraymoundService("CDM_CAN_SECTOR_BE_INACTIVE")
	public static GMMap canSectorBeInactive(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			SectorDef sd=(SectorDef) session.createCriteria(SectorDef.class)
					.add(Restrictions.eq("oid", iMap.getString("SECTOR_ID"))).add(Restrictions.eq("status", true)).uniqueResult();
			
			if(sd == null){
				oMap.put("CAN_BE_DELETED", "Y");
			}
			else{
				@SuppressWarnings("unchecked")
				List<CorporateMaster> cm= session.createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("sectorCode", sd.getSectorCode())).add(Restrictions.eq("status", true)).list();
				
				if (cm.size()>0) {
					oMap.put("CAN_BE_INACTIVE", "N");
				}else{
					oMap.put("CAN_BE_INACTIVE", "Y");
				}
			}
		} catch (HibernateException e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("CDM_TRN7000_GET_SECTORS")
	public static GMMap getSectors(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			// String tableName = "SECTOR_DEF";
			// String func="{? = call CDM.PKG_TRN7000.TRN7000_GET_LIST}";
			// oMap = DALUtil.callOracleRefCursorFunction(func,tableName,new Object[0]);
			Session session = DAOSession.getSession("BNSPRDal");
			List<SectorDef> sectorList = session.createCriteria(SectorDef.class).add(Restrictions.eq("status", true)).list();
			int i = 0;
			String sectorType="";
			for (SectorDef sectorDef : sectorList) {
				oMap.put("SECTOR_DEF", i, "SECTOR_ACTIVENESS", sectorDef.getSectorActiveness());
				oMap.put("SECTOR_DEF", i, "SECTOR_ID", sectorDef.getOid());
				oMap.put("SECTOR_DEF", i, "SECTOR_NAME", sectorDef.getSectorName());
				oMap.put("SECTOR_DEF", i, "SECTOR_STATUS", "1");
				if(sectorDef.getSectorType().equals("INVOICE")){
					sectorType="Fatura �deme";
				}
				if(sectorDef.getSectorType().equals("TAX")){
					sectorType="Vergi �deme";
				}
				if(sectorDef.getSectorType().equals("OTHER")){
					sectorType="Di�er";
				}
				oMap.put("SECTOR_DEF", i, "SECTOR_TYPE_NAME", sectorType);
				oMap.put("SECTOR_DEF", i, "SECTOR_TYPE", sectorDef.getSectorType());
				i++;
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_TRN7000_SAVE_SECTORS")
	public static GMMap saveSectors(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		SectorDef sectorDef = null;
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			session.getTransaction().begin();
			
			@SuppressWarnings("unchecked")
			List<SectorDef> sectorListActive= session.createCriteria(SectorDef.class).add(Restrictions.eq("status", true)).list();
			for (SectorDef sectorDefActive : sectorListActive) {
				sectorDefActive.setStatus(false);
				sectorDefActive.setCreateDate(sdf.format(new Date()));
				sectorDefActive.setCreateUser(username);
				sectorDefActive.setSectorName(sectorDefActive.getSectorName().trim());
				session.saveOrUpdate(sectorDefActive);
			}
	
			for(int index = 0 ;  index<iMap.getSize("SECTOR_DEF") ; index++){
					
					String sectorId = iMap.getString("SECTOR_DEF",index,"SECTOR_ID");
					String status = iMap.getString("SECTOR_DEF",index,"SECTOR_STATUS");
									
					if("1".equals(status)){
						
						if(StringUtils.isNotBlank(sectorId)){
							sectorDef = (SectorDef) session.createCriteria(SectorDef.class).add(Restrictions.eq("oid", sectorId)).uniqueResult();
						}
						
						if(sectorDef != null){
							sectorDef.setStatus(false);
							sectorDef.setUpdateDate(sdf.format(new Date()));
							sectorDef.setUpdateUser(username);
							session.saveOrUpdate(sectorDef);

							SectorDef newSectorDef = new SectorDef();
							newSectorDef.setSectorActiveness(iMap.getBoolean("SECTOR_DEF",index,"SECTOR_ACTIVENESS") ? "1" : "0" );
							newSectorDef.setSectorName(iMap.getString("SECTOR_DEF",index,"SECTOR_NAME").trim());
							newSectorDef.setStatus(true);
							newSectorDef.setSectorCode(sectorDef.getSectorCode());
							newSectorDef.setCreateDate(sdf.format(new Date()));
							newSectorDef.setCreateUser(username);
							newSectorDef.setSectorType(iMap.getString("SECTOR_DEF",index,"SECTOR_TYPE"));
							session.saveOrUpdate(newSectorDef);
							
						}
						
					}else if("0".equals(status)){
											
						if(StringUtils.isNotBlank(sectorId)){
							sectorDef = (SectorDef) session.createCriteria(SectorDef.class).add(Restrictions.eq("oid", sectorId)).uniqueResult();
						}
						
						if(sectorDef != null){
							sectorDef.setSectorActiveness(iMap.getBoolean("SECTOR_DEF",index,"SECTOR_ACTIVENESS") ? "1" : "0" );
							sectorDef.setSectorName(iMap.getString("SECTOR_DEF",index,"SECTOR_NAME").trim());
							sectorDef.setStatus(false);
							sectorDef.setUpdateDate(sdf.format(new Date()));
							sectorDef.setUpdateUser(username);
							sectorDef.setSectorType(iMap.getString("SECTOR_DEF",index,"SECTOR_TYPE"));
							session.saveOrUpdate(sectorDef);
						}
						
					}else if("2".equals(status)){
						
						SectorDef newSectorDef = new SectorDef();
						newSectorDef.setSectorActiveness(iMap.getBoolean("SECTOR_DEF",index,"SECTOR_ACTIVENESS") ? "1" : "0" );
						newSectorDef.setSectorName(iMap.getString("SECTOR_DEF",index,"SECTOR_NAME").trim());
						newSectorDef.setStatus(true);
						newSectorDef.setSectorCode("S-"+CorporationServiceUtil.getSequenceCode("SECTOR_DEF"));
						newSectorDef.setCreateDate(sdf.format(new Date()));
						newSectorDef.setCreateUser(username);
						newSectorDef.setSectorType(iMap.getString("SECTOR_DEF",index,"SECTOR_TYPE"));
						session.saveOrUpdate(newSectorDef);
					}

			}
			
			session.flush();
			session.getTransaction().commit();
			
			oMap.put("MESSAGE", "i�leminiz tamamlanm��t�r.");
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}
	
	
}