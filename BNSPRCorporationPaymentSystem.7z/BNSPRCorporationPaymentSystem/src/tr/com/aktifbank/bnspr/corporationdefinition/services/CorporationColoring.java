package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class CorporationColoring {
	private static GMMap getFieldProperties(Object toolTipText) {
		GMMap oMap = new GMMap();
		oMap.put("toolTipText", toolTipText != null ? toolTipText.toString() : null);
		oMap.put("background", new Color(153, 255, 0));

		return oMap;
	}

	public static GMMap getDefaultFieldProperties() {
		GMMap oMap = new GMMap();
		oMap.put("toolTipText", (String) null);
		oMap.put("background", new Color(238, 238, 238));
		return oMap;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static GMMap reflectDifference(List<HashMap<Object, Object>> setOldList, List<HashMap<Object, Object>> setNewList, GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (setOldList != null) {
				for (Iterator iteratorOld = setOldList.iterator(); iteratorOld.hasNext();) {
					HashMap<Object, Object> hashMapOld = (HashMap<Object, Object>) iteratorOld.next();
					Set<Object> keys = hashMapOld.keySet();

					for (Object key : keys) {
						boolean sameColumn = false;
						if (setNewList != null) {
							for (Iterator iteratorNew = setNewList.iterator(); iteratorNew.hasNext();) {
								HashMap<Object, Object> hashMapNew = (HashMap<Object, Object>) iteratorNew.next();
								if (compareTwoStringForTable(hashMapOld.get(key), hashMapNew.get(key))) {
									sameColumn = true;
									break;
								}
							}
						}
						if (sameColumn && "MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION"))) {
							oMap.put(key, getFieldProperties(hashMapOld.get(key)));
						} else {
							oMap.put(key, getDefaultFieldProperties());
						}
					}
				}
			} else {
				for (Iterator iteratorNew = setNewList.iterator(); iteratorNew.hasNext();) {
					HashMap<Object, Object> hashMapNew = (HashMap<Object, Object>) iteratorNew.next();
					Set<Object> keys = hashMapNew.keySet();
					for (Object key : keys) {
						oMap.put(key, getFieldProperties(hashMapNew.get(key)));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	public static GMMap tableDifference(ArrayList<?> oldRecordObject, ArrayList<?> newRecordObject, String property, Color color) {
		GMMap oMap = new GMMap();
		try {
			if (newRecordObject != null) {
				for (int i = 0; i < newRecordObject.size(); i++) {
					HashMap<?, ?> newMap = (HashMap<?, ?>) newRecordObject.get(i);
					HashMap<?, ?> oldMap = null;
					if (oldRecordObject != null && oldRecordObject.size() > i) {
						oldMap = (HashMap<?, ?>) oldRecordObject.get(i);
					}
					if (oldMap != null && oldRecordObject.size() > i) {
						for (Object key : newMap.keySet()) {
							oMap.put("COLOR_DATA", i, key.toString(), compareTwoStringForTable(oldMap.get(key), newMap.get(key)) ? getChangedTableCellColorData(property, color) : getChangedTableCellColorData(property, Color.WHITE));
						}
					} else {
						for (Object key : newMap.keySet()) {
							oMap.put("COLOR_DATA", i, key.toString(), getChangedTableCellColorData(property, color));
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	private static GMMap getChangedTableCellColorData(String property, Color color) {
		GMMap oMap = new GMMap();
		oMap.put(property, color);
		return oMap;
	}

	private static boolean compareTwoStringForTable(Object oldString, Object newString) {
		if (oldString == null && newString != null)
			return true;
		else if (oldString != null && !oldString.equals(newString))
			return true;
		else
			return false;
	}

	public static String getPreviousTxNo(String tableName, BigDecimal txNo, String corpCode) {
		String s = String.format(QueryRepository.CorporationColoringRepository.GET_PREVIOUS_TX_NO, tableName, txNo, corpCode);
		return DALUtil.getResult(s);
	}

	public static GMMap getCorporateDefaultColoring(GMMap iMap, GMMap oMap) {
		oMap.put("CORPORATE_NAME_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("CORPORATE_ACTIVENESS_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("CORPORATE_BANK_CODE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("COUNT_TYPE_AFTER_DUE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("CUSTOMER_NUMBER_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("IF_DUE_DATE_HOLIDAY_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("PROTOCOL_START_DATE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("SECTOR_NAME_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("SHORT_CODE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("ALLOW_END_PAYMEND_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("COUNT_AFTER_DUE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("ALLOW_AFTER_PAYMEND_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("ALLOW_BEFORE_PAYMEND_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("IS_ONLINE_CORPORATE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("IS_PUBLIC_CORPORATE_COLOR", CorporationColoring.getDefaultFieldProperties());
		oMap.put("CORPORATE_BUSINESS_CODE_COLOR", CorporationColoring.getDefaultFieldProperties());
		return oMap;
	}

	@SuppressWarnings("unchecked")
	public static GMMap getCorporateInfoColoring(GMMap iMap, GMMap oMap) {
		try {
			StringBuilder sb = new StringBuilder();
//			sb.append("	SELECT ");
//			sb.append("CORPORATE_NAME CORPORATE_NAME_COLOR,CORPORATE_ACTIVENESS CORPORATE_ACTIVENESS_COLOR,CORPORATE_BANK_CODE CORPORATE_BANK_CODE_COLOR,COUNT_TYPE_AFTER_DUE COUNT_TYPE_AFTER_DUE_COLOR");
//			sb.append(",CUSTOMER_NUMBER CUSTOMER_NUMBER_COLOR,IF_DUE_DATE_HOLIDAY IF_DUE_DATE_HOLIDAY_COLOR,PROTOCOL_START_DATE PROTOCOL_START_DATE_COLOR,");
//			sb.append("(SELECT SECTOR_NAME FROM CDM.SECTOR_DEF SD WHERE SD.SECTOR_CODE=CM.SECTOR_CODE AND SD.STATUS=1) SECTOR_NAME_COLOR,");
//			sb.append("SHORT_CODE SHORT_CODE_COLOR,CM.ALLOW_PART_AFTER_DUE ALLOW_END_PAYMEND_COLOR,CM.COUNT_AFTER_DUE COUNT_AFTER_DUE_COLOR,CM.ALLOW_AFTER_DUE_DATE ALLOW_AFTER_PAYMEND_COLOR,");
//			sb.append("CM.ALLOW_PART_PAYMENT ALLOW_BEFORE_PAYMEND_COLOR,CM.IS_ONLINE_CORPORATE IS_ONLINE_CORPORATE_COLOR,CM.CORPORATE_BUSINESS_CODE CORPORATE_BUSINESS_CODE_COLOR");
//			sb.append(" FROM CDM.CORPORATE_MASTER CM WHERE oid='").append(iMap.getString("CORPORATE_OID")).append("' and cm.status=1");
			sb.append(String.format(QueryRepository.CorporationColoringRepository.GET_CORPORATE_INFO_COLORING, iMap.getString("CORPORATE_OID")));
			GMMap oMapOld = DALUtil.getResults(sb.toString(), "tableOld");
			StringBuilder sbNew = new StringBuilder();
//			sbNew.append("	SELECT ");
//			sbNew.append("CORPORATE_NAME CORPORATE_NAME_COLOR,CORPORATE_ACTIVENESS CORPORATE_ACTIVENESS_COLOR,CORPORATE_BANK_CODE CORPORATE_BANK_CODE_COLOR,COUNT_TYPE_AFTER_DUE COUNT_TYPE_AFTER_DUE_COLOR");
//			sbNew.append(",CUSTOMER_NUMBER CUSTOMER_NUMBER_COLOR,IF_DUE_DATE_HOLIDAY IF_DUE_DATE_HOLIDAY_COLOR,PROTOCOL_START_DATE PROTOCOL_START_DATE_COLOR,");
//			sbNew.append("(SELECT SECTOR_NAME FROM CDM.SECTOR_DEF SD WHERE SD.SECTOR_CODE=CM.SECTOR_CODE AND SD.STATUS=1) SECTOR_NAME_COLOR,");
//			sbNew.append("SHORT_CODE SHORT_CODE_COLOR,CM.ALLOW_PART_AFTER_DUE ALLOW_END_PAYMEND_COLOR,CM.COUNT_AFTER_DUE COUNT_AFTER_DUE_COLOR,CM.ALLOW_AFTER_DUE_DATE ALLOW_AFTER_PAYMEND_COLOR,");
//			sbNew.append("CM.ALLOW_PART_PAYMENT ALLOW_BEFORE_PAYMEND_COLOR,CM.IS_ONLINE_CORPORATE IS_ONLINE_CORPORATE_COLOR,CM.CORPORATE_BUSINESS_CODE CORPORATE_BUSINESS_CODE_COLOR");
//			sbNew.append(" FROM CDM.CORPORATE_MASTER_TX CM WHERE corporate_oid='").append(iMap.getString("CORPORATE_OID")).append("' and cm.status=1");
			sbNew.append(String.format(QueryRepository.CorporationColoringRepository.GET_CORPORATE_INFO_COLORING_NEW, iMap.getString("TX_NO")));
			GMMap oMapNew = DALUtil.getResults(sbNew.toString(), "tableNew");

			oMap.putAll(reflectDifference((List<HashMap<Object, Object>>) oMapOld.get("tableOld"), (List<HashMap<Object, Object>>) oMapNew.get("tableNew"), iMap));
			// oMap.put(key, getDefaultFieldProperties());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getCorporateSelectCityColoring(GMMap iMap, GMMap oMap) {
		GMMap oMapNew = new GMMap();
		GMMap oMapOld = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String newTableName = "NEW_TABLE";
			String oldTableName = "OLD_TABLE";
			String corporateOid = iMap.getString("CORPORATE_OID");
			if (StringUtils.isNotBlank(corporateOid)) {

				StringBuilder sb = new StringBuilder();
//				sb.append("SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel c WHERE c.status= 1");
//				sb.append(" AND c.corporate_oid ='").append(corporateOid).append("'");
//				sb.append(" AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI").append(" FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI");
				sb.append(String.format(QueryRepository.CorporationColoringRepository.GET_CORPORATE_SELECTED_CITY,corporateOid));
				oMapOld = DALUtil.getResults(sb.toString(), oldTableName);
				StringBuilder sbNew = new StringBuilder();
//				sbNew.append("SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel_tx c WHERE c.status= 1");
//				sbNew.append(" AND c.corporate_oid ='").append(corporateOid).append("'");
//				sbNew.append(" AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI").append(" FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI");
				sbNew.append(String.format(QueryRepository.CorporationColoringRepository.GET_CORPORATE_SELECTED_CITY_NEW,iMap.getString("TX_NO")));
				oMapNew = DALUtil.getResults(sbNew.toString(), newTableName);
				oMapNew.put(oldTableName, oMapOld.get(oldTableName));

				StringBuilder sbPublicCityOld = new StringBuilder();
//				sbPublicCityOld.append("SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel c WHERE c.status= 1");
//				sbPublicCityOld.append(" AND c.corporate_oid ='").append(corporateOid).append("'");
				sbPublicCityOld.append(String.format(QueryRepository.CorporationColoringRepository.GET_CITY_OLD, corporateOid));
				
				boolean publicCityOld = DALUtil.getResults(sbPublicCityOld.toString(), "IS_PUBLIC_CORPORATE").getBoolean("IS_PUBLIC_CORPORATE", 0, "IS_PUBLIC_CORPORATE");
				StringBuilder sbPublicCityNew = new StringBuilder();
//				sbPublicCityNew.append("SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel_tx c WHERE c.status= 1");
//				sbPublicCityNew.append(" AND c.corporate_oid ='").append(corporateOid).append("'");
				sbPublicCityNew.append(String.format(QueryRepository.CorporationColoringRepository.GET_CITY_NEW, iMap.getString("TX_NO")));
				boolean publicCityNew = DALUtil.getResults(sbPublicCityNew.toString(), "IS_PUBLIC_CORPORATE").getBoolean("IS_PUBLIC_CORPORATE", 0, "IS_PUBLIC_CORPORATE");
				if (!String.valueOf(publicCityOld).equalsIgnoreCase(String.valueOf(publicCityNew)) && "MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION"))) {
					oMap.put("IS_PUBLIC_CORPORATE_COLOR", getFieldProperties("T�m �ller"));
				} else {
					oMap.put("IS_PUBLIC_CORPORATE_COLOR", getDefaultFieldProperties());
				}

				oMap.put("CORPORATE_CITY_COLOR",
						tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", "MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION")) ? new Color(153, 255, 0) : new Color(238, 238, 238)).get("COLOR_DATA"));
				// oMap.put("CHANNEL_SOURCE_LIST_TOOL_TIP", tableDifferenceToolTip((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "setToolTipText").get("TOOL_TIP_TEXT"));
			} else {
				oMap.put("IS_PUBLIC_CORPORATE_COLOR", getDefaultFieldProperties());
				oMap.put("CORPORATE_CITY_COLOR",
						tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", "MESAJ_KUTUSU_CAGIRDI".equalsIgnoreCase(iMap.getString("ACTION")) ? new Color(153, 255, 0) : new Color(238, 238, 238)).get("COLOR_DATA"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getSubscriberListColoring(GMMap iMap, GMMap oMap) {
		GMMap oMapNew = new GMMap();
		GMMap oMapOld = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			// cdm.channel_source_def

			String corporateOid = iMap.getString("CORPORATE_OID");
			String newTableName = "NEW_TABLE";
			String oldTableName = "OLD_TABLE";
			StringBuilder sb = new StringBuilder();
//			sb.append(" SELECT subscriber.*,ii.oid IMAGE_OID from(");
//			sb.append(" SELECT d.oid maskDetailOid,f.corporate_oid,d.use_for_inquiry,p.collection_name,p.collection_type,d.label,d.mask,d.example,d.prefix,d.suffix,d.use_for_collection,d.use_for_standing_order,");
//			sb.append(" d.view_order,td.is_appearance_payment_screen as USE_PAYMENT_INVOICE_SCREEN, td.allow_auto_collection as USE_AUTOMATIC_PAYMENT");
//			sb.append(" FROM cdm.subscriber_mask_def f,cdm.collection_type_def td,cdm.subscriber_mask_detail d,cdm.collection_type_prm p");
//			sb.append(" WHERE f.corporate_oid = '").append(corporateOid).append("' AND f.oid = d.mask_oid AND f.collection_type = p.collection_type ");
//			sb.append(" AND f.status = 1 AND d.status = 1 ");
//			sb.append(" AND p.collection_type = td.collection_type AND td.status= 1 AND f.corporate_oid=td.corporate_oid");
//			sb.append(" ORDER BY 3   ) subscriber  LEFT OUTER JOIN cdm.invoice_image ii ON subscriber.corporate_oid =ii.corporate_oid and ii.status= 1 AND ii.MASK_OID=subscriber.maskDetailOid  order by collection_name,view_order");
			sb.append(String.format(QueryRepository.CorporationColoringRepository.SUBSCRIBER_LIST, corporateOid));
			oMapOld = DALUtil.getResults(sb.toString(), oldTableName);
			StringBuilder sbNew = new StringBuilder();
//			sbNew.append(" SELECT subscriber.*,ii.oid IMAGE_OID from(");
//			sbNew.append(" SELECT d.oid maskDetailOid,f.corporate_oid,d.use_for_inquiry,p.collection_name,p.collection_type,d.label,d.mask,d.example,d.prefix,d.suffix,d.use_for_collection,d.use_for_standing_order,");
//			sbNew.append(" d.view_order,td.is_appearance_payment_screen as USE_PAYMENT_INVOICE_SCREEN, td.allow_auto_collection as USE_AUTOMATIC_PAYMENT");
//			sbNew.append(" FROM cdm.subscriber_mask_def_tx f,cdm.collection_type_def_tx td,cdm.subscriber_mask_detail_tx d,cdm.collection_type_prm p");
//			sbNew.append(" WHERE f.corporate_oid = '").append(corporateOid).append("' AND f.oid = d.mask_oid AND f.collection_type = p.collection_type ");
//			sbNew.append(" AND f.status = 1 AND d.status = 1 ");
//			sbNew.append(" AND p.collection_type = td.collection_type AND td.status= 1 AND f.corporate_oid=td.corporate_oid");
//			sbNew.append(" ORDER BY 3   ) subscriber  LEFT OUTER JOIN cdm.invoice_image_tx ii ON subscriber.corporate_oid =ii.corporate_oid and ii.status= 1 AND ii.MASK_OID=subscriber.maskDetailOid order by collection_name,view_order");
			sbNew.append(String.format(QueryRepository.CorporationColoringRepository.SUBSCRIBER_LIST_NEW,iMap.getString("TX_NO")));
			
			oMapNew = DALUtil.getResults(sbNew.toString(), newTableName);
			oMapNew.put(oldTableName, oMapOld.get(oldTableName));

			oMap.put("SUBSCRIBER_LIST_COLOR", tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", new Color(153, 255, 0)).get("COLOR_DATA"));
			// oMap.put("CHANNEL_SOURCE_LIST_TOOL_TIP", tableDifferenceToolTip((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "setToolTipText").get("TOOL_TIP_TEXT"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getContactListColoring(GMMap iMap, GMMap oMap) {
		GMMap oMapNew = new GMMap();
		GMMap oMapOld = new GMMap();
		try {
			String corporateOid = iMap.getString("CORPORATE_OID");
			String newTableName = "NEW_TABLE";
			String oldTableName = "OLD_TABLE";
			StringBuilder sb = new StringBuilder();
//			sb.append(" SELECT cc.name_surname,cc.department department_id,");
//			sb.append(" (SELECT TEXT FROM BNSPR.V_ML_GNL_PARAM_TEXT WHERE KOD = 'CDM_DEPARTMAN' and KEY1 = cc.department )as department, cc.phone_number, cc.mobile, cc.email, cc.fax,cc.note ");
//			sb.append(" FROM cdm.corporate_contact_info cc");
//			sb.append(" WHERE cc.corporate_oid ='").append(corporateOid).append("' AND cc.status = 1 ORDER BY 1");
			sb.append(String.format(QueryRepository.CorporationColoringRepository.CONTACT_LIST, corporateOid));
			oMapOld = DALUtil.getResults(sb.toString(), oldTableName);
			StringBuilder sbNew = new StringBuilder();
//			sbNew.append(" SELECT cc.name_surname,cc.department department_id,");
//			sbNew.append(" (SELECT TEXT FROM BNSPR.V_ML_GNL_PARAM_TEXT WHERE KOD = 'CDM_DEPARTMAN' and KEY1 = cc.department )as department, cc.phone_number, cc.mobile, cc.email, cc.fax,cc.note  ");
//			sbNew.append(" FROM cdm.corporate_contact_info_tx cc");
//			sbNew.append(" WHERE cc.corporate_oid ='").append(corporateOid).append("' AND cc.status = 1 ");
//			sbNew.append("ORDER BY 1");
			sbNew.append(String.format(QueryRepository.CorporationColoringRepository.CONTACT_LIST_NEW, iMap.getString("TX_NO")));
			oMapNew = DALUtil.getResults(sbNew.toString(), newTableName);
			oMapNew.put(oldTableName, oMapOld.get(oldTableName));

			oMap.put("CONTACT_LIST_COLOR", tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", new Color(153, 255, 0)).get("COLOR_DATA"));
			// oMap.put("CHANNEL_SOURCE_LIST_TOOL_TIP", tableDifferenceToolTip((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "setToolTipText").get("TOOL_TIP_TEXT"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getChannelSourceListColoring(GMMap iMap, GMMap oMap) {
		GMMap oMapNew = new GMMap();
		GMMap oMapOld = new GMMap();
		try {
			String corporateOid = iMap.getString("CORPORATE_OID");
			String newTableName = "NEW_TABLE";
			String oldTableName = "OLD_TABLE";
			StringBuilder sb = new StringBuilder();
//			sb.append("select distinct ");
//			sb.append(" (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1 and agg.screen_line = csd.screen_line) as CHANNEL_NAME,");
//			sb.append(" (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1  and agg.screen_line = csd.screen_line ) as SOURCE_NAME,");
//			sb.append(" (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1  and agg.screen_line = csd.screen_line ) as CHANNEL_CODE,");
//			sb.append(" (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1  and agg.screen_line = csd.screen_line ) as SOURCE_CODE,");
//			sb.append(" csd.WORKINGDAY_START_TIME,csd.WORKINGDAY_END_TIME,csd.HOLIDAY_START_TIME,csd.HOLIDAY_END_TIME,csd.CLOSED_DATE_START,csd.CLOSED_DATE_END,csd.EXPLANATION,csd.SCREEN_LINE");
//			sb.append(" from cdm.channel_source_def csd");
//			sb.append(" where csd.corporate_oid='").append(corporateOid).append("' and csd.status=1 ORDER BY csd.screen_line");
			sb.append(String.format(QueryRepository.CorporationColoringRepository.CHANNEL_SOURCE_LIST, corporateOid));
			oMapOld = DALUtil.getResults(sb.toString(), oldTableName);
			StringBuilder sbNew = new StringBuilder();
//			sbNew.append("select distinct ");
//			sbNew.append(" (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.status=1 and agg.screen_line = csd.screen_line) as CHANNEL_NAME,");
//			sbNew.append(" (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.status=1 and agg.screen_line = csd.screen_line) as SOURCE_NAME,");
//			sbNew.append(" (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.status=1 and agg.screen_line = csd.screen_line) as CHANNEL_CODE,");
//			sbNew.append(" (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.status=1 and agg.screen_line = csd.screen_line ) as SOURCE_CODE,");
//			sbNew.append(" csd.WORKINGDAY_START_TIME,csd.WORKINGDAY_END_TIME,csd.HOLIDAY_START_TIME,csd.HOLIDAY_END_TIME,csd.CLOSED_DATE_START,csd.CLOSED_DATE_END,csd.EXPLANATION,csd.SCREEN_LINE");
//			sbNew.append(" from cdm.channel_source_def_tx csd");
//			sbNew.append(" where csd.corporate_oid='").append(corporateOid).append("' and csd.status=1 ORDER BY csd.screen_line");
			sbNew.append(String.format(QueryRepository.CorporationColoringRepository.CHANNEL_SOURCE_LIST_NEW, iMap.getString("TX_NO")));
			oMapNew = DALUtil.getResults(sbNew.toString(), newTableName);
			oMapNew.put(oldTableName, oMapOld.get(oldTableName));

			oMap.put("CHANNEL_SOURCE_LIST_COLOR", tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", new Color(153, 255, 0)).get("COLOR_DATA"));
			// oMap.put("CHANNEL_SOURCE_LIST_TOOL_TIP", tableDifferenceToolTip((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "setToolTipText").get("TOOL_TIP_TEXT"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static GMMap getAccountListColoring(GMMap iMap, GMMap oMap) {

		GMMap oMapNew = new GMMap();
		GMMap oMapOld = new GMMap();
		try {
			String corporateOid = iMap.getString("CORPORATE_OID");
			String newTableName = "NEW_TABLE";
			String oldTableName = "OLD_TABLE";
			StringBuilder sb = new StringBuilder();
			sb.append(String.format(QueryRepository.CorporationColoringRepository.ACCOUNT_LIST, corporateOid));
			oMapOld = DALUtil.getResults(sb.toString(), oldTableName);
			StringBuilder sbNew = new StringBuilder();
			sbNew.append(String.format(QueryRepository.CorporationColoringRepository.ACCOUNT_LIST_NEW, iMap.getString("TX_NO")));
			oMapNew = DALUtil.getResults(sbNew.toString(), newTableName);
			oMapNew.put(oldTableName, oMapOld.get(oldTableName));

			oMap.put("ACCOUNT_LIST_COLOR", tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", new Color(153, 255, 0)).get("COLOR_DATA"));
			// oMap.put("CHANNEL_SOURCE_LIST_TOOL_TIP", tableDifferenceToolTip((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "setToolTipText").get("TOOL_TIP_TEXT"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	public static GMMap getAccountTransferListColoring(GMMap iMap, GMMap oMap) {
		GMMap oMapNew = new GMMap();
		GMMap oMapOld = new GMMap();
		try {
			String corporateOid = iMap.getString("CORPORATE_OID");
			String newTableName = "NEW_TABLE";
			String oldTableName = "OLD_TABLE";
			StringBuilder sb = new StringBuilder();
//			sb.append("SELECT DISTINCT f.transfer_day_type DAY_TYPE_ID,");
//			sb.append(" DECODE(f.from_account_type,'TH','Tahsilat Hesab�-'||f.from_account_no,'KH','Kullan�m Hesab�-'||f.from_account_no,NULL) AS SOURCE_ACCOUNT_NO,");
//			sb.append(" DECODE(f.to_account_type,'EH','EFT Hesab�-'||f.to_account_iban,'KH','Kullan�m Hesab�-'||f.to_account_no,NULL) AS TRANSFUSION_ACCOUNT_NO,");
//			sb.append(" f.from_account_type||'-'||f.from_account_no AS SOURCE_ACCOUNT_NO_ID,");
//			sb.append(" f.to_account_type||'-'||DECODE(f.to_account_type,'EH',f.to_account_iban,f.to_account_no) AS TRANSFUSION_ACCOUNT_NO_ID,");
//			sb.append(" case when f.to_account_type = 'KH' then (select m.oid to_account_no_id FROM cdm.corporation_account_master").append(" m");
//			sb.append(" where m.status = 1 and m.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("' and m.account_number is not null and m.account_number = f.to_account_no and");
//			sb.append(" m.account_definition_type = f.to_account_type) when f.to_account_type = 'EH' then (select m.oid TRANSFUSION_ACCOUNT_NO_ID");
//			sb.append(" FROM cdm.corporation_account_master").append(" m where m.status = 1 and m.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("' and");
//			sb.append(" m.iban is not null and m.iban = f.to_account_iban and m.account_definition_type = f.to_account_type) end,");
//			sb.append(" f.transfer_collections_inholiday VACATION_TYPE_ID,f.transfer_day_option,f.transfer_month_option,");
//
//			sb.append(" (SELECT ListAgg('('||p.collection_name||'<->'||k.aciklama||'<->'||s.source_name||')',',') within GROUP(ORDER BY p.collection_name DESC)");
//			sb.append(" FROM cdm.account_collection_type_rel").append(" a,cdm.collection_transfer_rel").append(" r,cdm.source_param s,");
//			sb.append(" BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p");
//			sb.append(" WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code");
//			sb.append(" AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE,");
//
//			sb.append(" (SELECT ListAgg(p.collection_type||'<->'||k.kod||'<->'||s.source_code,',') within GROUP(ORDER BY p.collection_type DESC)");
//			sb.append(" FROM cdm.account_collection_type_rel").append(" a,cdm.collection_transfer_rel").append(" r,cdm.source_param s,");
//			sb.append(" BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p");
//			sb.append(" WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code");
//			sb.append(" AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE_ID,");
//
//			sb.append(" CASE WHEN f.transfer_day_option = 2 THEN ");
//			sb.append(" (SELECT ListAgg('('|| d.in_day_of_each_week||'->'||d.out_day_of_each_week||')',',') within GROUP(ORDER BY d.in_day_of_each_week ASC)");
//			sb.append(" FROM cdm.balance_transfer_days").append(" d WHERE d.balance_transfer_oid = f.oid )");
//			sb.append(" WHEN f.transfer_day_option = 1 THEN ");
//			sb.append(" ('('||f.transfer_day_count||' '||(SELECT g.text FROM BNSPR.v_ml_gnl_param_text g");
//			sb.append(" WHERE kod = 'CDM_AKTARIM_GUN_TIPI' AND key1  = f.transfer_day_type)");
//			sb.append(" ||' sonra aktar�ls�n)') END AS transfer_day_rule,");
//			sb.append(" CASE WHEN f.transfer_month_option = 1 THEN f.day_of_each_month||'. g�n� yap�ls�n'");
//			sb.append(" WHEN f.transfer_month_option = 2 THEN f.in_day_of_each_month||'. g�n� gelen ay�n '||f.out_day_of_each_month||'. g�n� yap�ls�n'END AS TRANSFER_MONTH_RULE,");
//			sb.append(" (SELECT g.text FROM BNSPR.v_ml_gnl_param_text g WHERE kod = 'CDM_AKTARIM_TATIL_GUNU' AND key1 = f.transfer_collections_inholiday ) VACATION_TYPE");
//			sb.append(" FROM cdm.balance_transfer_def").append(" f where F.CORPORATE_OID = '").append(iMap.getString("CORPORATE_OID")).append("' and F.STATUS = 1 and");
//			sb.append(" (f.from_account_no||'' in ");
//			sb.append(" (select m.account_number from cdm.corporation_account_master").append(" m");
//			sb.append(" where m.corporate_oid = '").append(corporateOid).append("' and m.status = 1) and f.to_account_no||'' in");
//			sb.append(" (select m.account_number from cdm.corporation_account_master").append(" m");
//			sb.append(" where m.corporate_oid = '").append(corporateOid).append("' and m.status = 1) or");
//			sb.append(" f.to_account_iban||'' in");
//			sb.append(" (select m.iban");
//			sb.append(" from cdm.CORPORATION_ACCOUNT_MASTER").append(" M where m.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("' and m.status = 1)) order by source_account_no_id,transfusion_account_no_id");
			sb.append(String.format(QueryRepository.CorporationColoringRepository.TRANSFER_LIST,corporateOid,corporateOid,corporateOid,corporateOid,corporateOid,corporateOid));
			oMapOld = DALUtil.getResults(sb.toString(), oldTableName);

			StringBuilder sbNew = new StringBuilder();
//			sbNew.append("SELECT DISTINCT f.transfer_day_type DAY_TYPE_ID,");
//			sbNew.append(" DECODE(f.from_account_type,'TH','Tahsilat Hesab�-'||f.from_account_no,'KH','Kullan�m Hesab�-'||f.from_account_no,NULL) AS SOURCE_ACCOUNT_NO,");
//			sbNew.append(" DECODE(f.to_account_type,'EH','EFT Hesab�-'||f.to_account_iban,'KH','Kullan�m Hesab�-'||f.to_account_no,NULL) AS TRANSFUSION_ACCOUNT_NO,");
//			sbNew.append(" f.from_account_type||'-'||f.from_account_no AS SOURCE_ACCOUNT_NO_ID,");
//			sbNew.append(" f.to_account_type||'-'||DECODE(f.to_account_type,'EH',f.to_account_iban,f.to_account_no) AS TRANSFUSION_ACCOUNT_NO_ID,");
//			sbNew.append(" case when f.to_account_type = 'KH' then (select m.oid to_account_no_id FROM cdm.corporation_account_master_tx").append(" m");
//			sbNew.append(" where m.status = 1 and m.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("' and m.account_number is not null and m.account_number = f.to_account_no and");
//			sbNew.append(" m.account_definition_type = f.to_account_type) when f.to_account_type = 'EH' then (select m.oid TRANSFUSION_ACCOUNT_NO_ID");
//			sbNew.append(" FROM cdm.corporation_account_master_tx").append(" m where m.status = 1 and m.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("' and");
//			sbNew.append(" m.iban is not null and m.iban = f.to_account_iban and m.account_definition_type = f.to_account_type) end,");
//			sbNew.append(" f.transfer_collections_inholiday VACATION_TYPE_ID,f.transfer_day_option,f.transfer_month_option,");
//
//			sbNew.append(" (SELECT ListAgg('('||p.collection_name||'<->'||k.aciklama||'<->'||s.source_name||')',',') within GROUP(ORDER BY p.collection_name DESC)");
//			sbNew.append(" FROM cdm.account_collection_type_rel_tx").append(" a,cdm.collection_transfer_rel_tx").append(" r,cdm.source_param s,");
//			sbNew.append(" BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p");
//			sbNew.append(" WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code");
//			sbNew.append(" AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE,");
//
//			sbNew.append(" (SELECT ListAgg(p.collection_type||'<->'||k.kod||'<->'||s.source_code,',') within GROUP(ORDER BY p.collection_type DESC)");
//			sbNew.append(" FROM cdm.account_collection_type_rel_tx").append(" a,cdm.collection_transfer_rel_tx").append(" r,cdm.source_param s,");
//			sbNew.append(" BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p");
//			sbNew.append(" WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code");
//			sbNew.append(" AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE_ID,");
//
//			sbNew.append(" CASE WHEN f.transfer_day_option = 2 THEN ");
//			sbNew.append(" (SELECT ListAgg('('|| d.in_day_of_each_week||'->'||d.out_day_of_each_week||')',',') within GROUP(ORDER BY d.in_day_of_each_week ASC)");
//			sbNew.append(" FROM cdm.balance_transfer_days_tx").append(" d WHERE d.balance_transfer_oid = f.oid )");
//			sbNew.append(" WHEN f.transfer_day_option = 1 THEN ");
//			sbNew.append(" ('('||f.transfer_day_count||' '||(SELECT g.text FROM BNSPR.v_ml_gnl_param_text g");
//			sbNew.append(" WHERE kod = 'CDM_AKTARIM_GUN_TIPI' AND key1  = f.transfer_day_type)");
//			sbNew.append(" ||' sonra aktar�ls�n)') END AS transfer_day_rule,");
//			sbNew.append(" CASE WHEN f.transfer_month_option = 1 THEN f.day_of_each_month||'. g�n� yap�ls�n'");
//			sbNew.append(" WHEN f.transfer_month_option = 2 THEN f.in_day_of_each_month||'. g�n� gelen ay�n '||f.out_day_of_each_month||'. g�n� yap�ls�n'END AS TRANSFER_MONTH_RULE,");
//			sbNew.append(" (SELECT g.text FROM BNSPR.v_ml_gnl_param_text g WHERE kod = 'CDM_AKTARIM_TATIL_GUNU' AND key1 = f.transfer_collections_inholiday ) VACATION_TYPE");
//			sbNew.append(" FROM cdm.balance_transfer_def_tx").append(" f where F.CORPORATE_OID = '").append(iMap.getString("CORPORATE_OID")).append("' and F.STATUS = 1 and");
//			sbNew.append(" (f.from_account_no||'' in ");
//			sbNew.append(" (select m.account_number from cdm.corporation_account_master_tx").append(" m");
//			sbNew.append(" where m.corporate_oid = '").append(corporateOid).append("' and m.status = 1) and f.to_account_no||'' in");
//			sbNew.append(" (select m.account_number from cdm.corporation_account_master_tx").append(" m");
//			sbNew.append(" where m.corporate_oid = '").append(corporateOid).append("' and m.status = 1) or");
//			sbNew.append(" f.to_account_iban||'' in");
//			sbNew.append(" (select m.iban");
//			sbNew.append(" from cdm.CORPORATION_ACCOUNT_MASTER_tx").append(" M where m.corporate_oid = '").append(iMap.getString("CORPORATE_OID")).append("' and m.status = 1)) order by source_account_no_id,transfusion_account_no_id");
			sbNew.append(String.format(QueryRepository.CorporationColoringRepository.TRANSFER_LIST_NEW,
					iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO"),iMap.getString("TX_NO")));
			oMapNew = DALUtil.getResults(sbNew.toString(), newTableName);

			oMapNew.put(oldTableName, oMapOld.get(oldTableName));

			oMap.put("ACCOUNT_TRANSFER_LIST_COLOR", tableDifference((ArrayList<?>) oMapNew.get(oldTableName), (ArrayList<?>) oMapNew.get(newTableName), "setBackground", new Color(153, 255, 0)).get("COLOR_DATA"));
			// oMap.put("CHANNEL_SOURCE_LIST_TOOL_TIP", tableDifferenceToolTip((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(newTableName), "setToolTipText").get("TOOL_TIP_TEXT"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
