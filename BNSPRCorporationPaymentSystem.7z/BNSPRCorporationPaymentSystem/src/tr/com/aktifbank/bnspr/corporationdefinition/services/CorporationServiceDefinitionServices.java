package tr.com.aktifbank.bnspr.corporationdefinition.services;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class CorporationServiceDefinitionServices {
	
	/**
	 * @description
	 * @param GMMap logMap
	 *	CORPORATE_CODE 	
	 *	WS_SERVICE_NAME
	 * @return GMMap outMap
	 * 	SUBMIT_ID
	 * @history 
	 * 	@author erdogan.demir		
	 *  @date 10.06.2013
	 *  @specification
	 * 		use hibernate object of WEB_SERVICES   
	 * 		select * from WEB_SERVICES 
	 * 			where STATUS =1 AND CORPORATE_CODE = ? 
	 * 							AND WS_SERVICE_NAME = ?
	 * 		set statement into GMMap and return
	 * 
	 */
	 @GraymoundService("CDM_GET_CORPORATE_WEB_SERVICES_INFO")
	public static GMMap getCorporateWebServiceInfo(GMMap logMap) {

		try {
		} catch (Exception e) {
			// TODO: handle exception
		}

		return logMap;
	}

}
