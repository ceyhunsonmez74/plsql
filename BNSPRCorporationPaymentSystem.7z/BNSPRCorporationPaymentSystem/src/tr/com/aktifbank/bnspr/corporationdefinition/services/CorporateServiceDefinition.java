package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CorporateServices;
import tr.com.aktifbank.bnspr.dao.OnlineGmServices;
import tr.com.aktifbank.bnspr.dao.ServiceResponseCodeMapping;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;

public class CorporateServiceDefinition {

	@GraymoundService("CDM_CORPORATE_SERVICES_GET_ONLINE_GM_SERVICES")
	public static GMMap getOnlineGmServices(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<OnlineGmServices> gmServiceList = session.createCriteria(OnlineGmServices.class).add(Restrictions.eq("status", true)).list();

		for (OnlineGmServices onlineServices : gmServiceList) {
			GuimlUtil.wrapMyCombo(oMap, "GM_SERVICE_LIST", onlineServices.getGmServiceName(), onlineServices.getGmServiceName());
		}
		return oMap;
	}

	@GraymoundService("CDM_CORPORATE_SERVICES_GET_WEB_SERVICES")
	public static GMMap getWebServices(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<WebServices> webServiceList = session.createCriteria(WebServices.class).add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).list();
		for (WebServices webServices : webServiceList) {
			GuimlUtil.wrapMyCombo(oMap, "WEB_SERVICE_LIST", webServices.getServiceName(), webServices.getServiceName());
		}
		return oMap;
	}

	@GraymoundService("GET_SERVICE_MAPPING_BY_CORPORATE")
	public static GMMap getServiceMappingByCorporate(GMMap iMap) {
		GMMap oMap = new GMMap();

		String tableName = "TEMP_TABLE";
		String tableNameForServiceMap = "SERVICE_RESPONSE_CODE_MAPPING_LIST";
		int rowc = 0;
		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if (iMap.getString(tableName, row, "SERVICE_OID").equals(iMap.getString("SERVICE_OID"))) {
				oMap.put(tableNameForServiceMap, rowc, "RETURN_CODE", iMap.getString(tableName, row, "RETURN_CODE"));
				oMap.put(tableNameForServiceMap, rowc, "ERROR_CODE", iMap.getString(tableName, row, "ERROR_CODE"));
				oMap.put(tableNameForServiceMap, rowc, "EXPLANATIONS", iMap.getString(tableName, row, "EXPLANATIONS"));
				oMap.put(tableNameForServiceMap, rowc, "RETURN_CODE_DESCRIPTION", iMap.getString(tableName, row, "RETURN_CODE_DESCRIPTION"));
				oMap.put(tableNameForServiceMap, rowc, "FOR_ALL_SERVICES", iMap.getString(tableName, row, "FOR_ALL_SERVICES"));
				rowc++;
			}
		}
		return oMap;
	}

	@GraymoundService("CDM_CORPORATE_SERVICES_DELETE_SERVICE")
	public static GMMap deleteService(GMMap iMap) {
		GMMap oMap = new GMMap();

		String newTableName = "NEW_TEMP_TABLE";
		String currentTableName = "CURRENT_TABLE";
		int rowc = 0;

		for (int row = 0; row < iMap.getSize(currentTableName); row++) {

			if (iMap.getString("DELETE_MODE").equals("ALL")) {
				if (!iMap.getString(currentTableName, row, "SERVICE_OID").equals(iMap.getString("SERVICE_OID"))) {
					oMap.put(newTableName, rowc, "RETURN_CODE", iMap.getString(currentTableName, row, "RETURN_CODE"));
					oMap.put(newTableName, rowc, "ERROR_CODE", iMap.getString(currentTableName, row, "ERROR_CODE"));
					oMap.put(newTableName, rowc, "EXPLANATIONS", iMap.getString(currentTableName, row, "EXPLANATIONS"));
					oMap.put(newTableName, rowc, "RETURN_CODE_DESCRIPTION", iMap.getString(currentTableName, row, "RETURN_CODE_DESCRIPTION"));
					oMap.put(newTableName, rowc, "FOR_ALL_SERVICES", iMap.getString(currentTableName, row, "FOR_ALL_SERVICES"));
					oMap.put(newTableName, rowc, "SERVICE_OID", iMap.getString(currentTableName, row, "SERVICE_OID"));
					rowc++;
				}
			} else if (!(iMap.getString(currentTableName, row, "SERVICE_OID").equals(iMap.getString("SERVICE_OID"))
					&& iMap.getString(currentTableName, row, "ERROR_CODE").equals(iMap.getString("ERROR_CODE")) && iMap.getString(currentTableName,
					row, "RETURN_CODE").equals(iMap.getString("RETURN_CODE")))) {
				oMap.put(newTableName, rowc, "RETURN_CODE", iMap.getString(currentTableName, row, "RETURN_CODE"));
				oMap.put(newTableName, rowc, "ERROR_CODE", iMap.getString(currentTableName, row, "ERROR_CODE"));
				oMap.put(newTableName, rowc, "EXPLANATIONS", iMap.getString(currentTableName, row, "EXPLANATIONS"));
				oMap.put(newTableName, rowc, "RETURN_CODE_DESCRIPTION", iMap.getString(currentTableName, row, "RETURN_CODE_DESCRIPTION"));
				oMap.put(newTableName, rowc, "FOR_ALL_SERVICES", iMap.getString(currentTableName, row, "FOR_ALL_SERVICES"));
				oMap.put(newTableName, rowc, "SERVICE_OID", iMap.getString(currentTableName, row, "SERVICE_OID"));
				rowc++;
			}
		}
		return oMap;
	}

	@GraymoundService("CDM_CORPORATE_SERVICES_GET_DEFINED_SERVICES")
	public static GMMap getDefinedServices(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String tableName = "CORPORATE_SERVICE_LIST";
		String tableNameForServiceMap = "SERVICE_RESPONSE_CODE_MAPPING_LIST";
		String isSafService = "";

		int row = 0, rowc = 0;
		@SuppressWarnings("unchecked")
		List<CorporateServices> corporateServiceList = session.createCriteria(CorporateServices.class).add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).list();

		for (CorporateServices corporateServices : corporateServiceList) {
			oMap.put(tableName, row, "GM_SERVICE_NAME", corporateServices.getGmServiceName());
			oMap.put(tableName, row, "WEB_SERVICE_NAME", corporateServices.getWebServiceName());
			if (corporateServices.getIsSafService().equals("0")) {
				isSafService = "HAYIR";
			} else {
				isSafService = "EVET";
			}
			oMap.put(tableName, row, "IS_SAF_SERVICE", isSafService);
			oMap.put(tableName, row, "OID", corporateServices.getOid());
			oMap.put(tableName, row, "CURRENT_OID", corporateServices.getOid());

			@SuppressWarnings("unchecked")
			List<ServiceResponseCodeMapping> serviceResponseCodeMappingList = session.createCriteria(ServiceResponseCodeMapping.class)
					.add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE")))
					.add(Restrictions.eq("serviceOid", corporateServices.getOid())).list();

			for (ServiceResponseCodeMapping serviceResponseCodeMapping : serviceResponseCodeMappingList) {
				oMap.put(tableNameForServiceMap, rowc, "SERVICE_OID", corporateServices.getOid());
				oMap.put(tableNameForServiceMap, rowc, "RETURN_CODE", serviceResponseCodeMapping.getReturnCode());
				oMap.put(tableNameForServiceMap, rowc, "ERROR_CODE", serviceResponseCodeMapping.getErrorCode());
				oMap.put(tableNameForServiceMap, rowc, "EXPLANATIONS", serviceResponseCodeMapping.getExplanation());
				oMap.put(tableNameForServiceMap, rowc, "RETURN_CODE_DESCRIPTION", serviceResponseCodeMapping.getReturnCodeDesc());
				if (serviceResponseCodeMapping.getForAllServices().equals("1")) {
					oMap.put(tableNameForServiceMap, rowc, "FOR_ALL_SERVICES","Evet" );	
				}else{
					oMap.put(tableNameForServiceMap, rowc, "FOR_ALL_SERVICES","Hay�r" );
				}
				
				rowc++;
			}

			row++;
		}

		return oMap;
	}

	@GraymoundService("CDM_CORPORATE_SERVICES_GET_DATE_TIME")
	public static GMMap getDateTime(GMMap iMap) {

		GMMap oMap = new GMMap();
		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		String crDate = sdf.format(new Date());

		oMap.put("DATE_TIME", crDate);
		oMap.put("USERNAME", username);

		return oMap;
	}

	@GraymoundService("CDM_CORPORATE_SERVICES_SAVE_SERVICE")
	public static GMMap saveService(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "SERVICE_TABLE";
		String defTable = "DEFINITION_TABLE";
		Session session = DAOSession.getSession("BNSPRDal");
		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		String crDate = sdf.format(new Date());

		try {
			@SuppressWarnings("unchecked")
			List<CorporateServices> corporateServiceList = session.createCriteria(CorporateServices.class)
					.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("status", true)).list();

			// set all records status 0
			for (CorporateServices services : corporateServiceList) {
				services.setStatus(false);
				services.setUpdateDate(crDate);
				services.setUpdateUser(username);
				session.saveOrUpdate(services);
			}

			@SuppressWarnings("unchecked")
			List<ServiceResponseCodeMapping> serviceMapping = session.createCriteria(ServiceResponseCodeMapping.class)
					.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("status", true)).list();

			// set all records status 0
			for (ServiceResponseCodeMapping mapping : serviceMapping) {
				mapping.setStatus(false);
				mapping.setUpdateDate(crDate);
				mapping.setUpdateUser(username);
				session.saveOrUpdate(mapping);
			}

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				CorporateServices newCorporateService = new CorporateServices();
				newCorporateService.setStatus(true);
				newCorporateService.setCorporateCode(iMap.getString("CORPORATE_CODE"));
				newCorporateService.setGmServiceName(iMap.getString(tableName, row, "GM_SERVICE_NAME"));
				newCorporateService.setWebServiceName(iMap.getString(tableName, row, "WEB_SERVICE_NAME"));
				if (iMap.getString(tableName, row, "IS_SAF_SERVICE").equals("EVET")) {
					newCorporateService.setIsSafService("1");
				} else {
					newCorporateService.setIsSafService("0");
				}
				newCorporateService.setCreateDate(crDate);
				newCorporateService.setCreateUser(username);
				session.save(newCorporateService);
				for (int rowi = 0; rowi < iMap.getSize(defTable); rowi++) {
					if (iMap.getString(tableName, row, "OID").equals(iMap.getString(defTable, rowi, "SERVICE_OID"))) {
						ServiceResponseCodeMapping serviceResponseMapping = new ServiceResponseCodeMapping();
						serviceResponseMapping.setStatus(true);
						serviceResponseMapping.setCorporateCode(iMap.getString("CORPORATE_CODE"));
						serviceResponseMapping.setServiceOid(newCorporateService.getOid());
						serviceResponseMapping.setReturnCode(iMap.getString(defTable, rowi, "RETURN_CODE"));
						serviceResponseMapping.setReturnCodeDesc(iMap.getString(defTable, rowi, "RETURN_CODE_DESCRIPTION"));
						serviceResponseMapping.setErrorCode(iMap.getString(defTable, rowi, "ERROR_CODE"));
						serviceResponseMapping.setExplanation(iMap.getString(defTable, rowi, "EXPLANATIONS"));
						if (iMap.getString(defTable, rowi, "FOR_ALL_SERVICES").equals("Evet")) {
							serviceResponseMapping.setForAllServices("1");	
						}else{
							serviceResponseMapping.setForAllServices("0");
						}
						
						serviceResponseMapping.setCreateDate(crDate);
						serviceResponseMapping.setCreateUser(username);
						session.save(serviceResponseMapping);
					}
				}
			}
			oMap.put("MESSAGE", "S");
		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("MESSAGE", "F");
		}
		return oMap;
	}
}
