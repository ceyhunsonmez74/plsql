package tr.com.aktifbank.bnspr.corporationdefinition.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.BatchDef;
import tr.com.aktifbank.bnspr.dao.BatchParameters;
import tr.com.aktifbank.bnspr.dao.BatchSubmitLog;
import tr.com.aktifbank.bnspr.dao.BatchUsedParam;
import tr.com.aktifbank.bnspr.dao.BatchUsedParamTx;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcessTx;
import tr.com.aktifbank.bnspr.dao.FileTransferLog;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CorporationBatchDefinitionServices {

	private static final Log logger = LogFactory.getLog(CorporationBatchDefinitionServices.class);
	
	@GraymoundService("CDM_GET_BATCH_NAMES_COMBO")
	public static GMMap getBatchNamesCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<BatchDef> batchList = session.createCriteria(BatchDef.class).add(Restrictions.eq("status", true)).list();
			
			for(BatchDef batch : batchList) {
				GuimlUtil.wrapMyCombo(oMap, "BATCH_NAMES" , batch.getBatchName(), batch.getBatchName());				
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	@GraymoundService("CDM_GET_BATCH_PARAMETERS_COMBO")
	public static GMMap getBatchParametersCombo(GMMap iMap) {
	
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")			
			List<String> paramKeyList = session.createCriteria(BatchParameters.class)
											.add(Restrictions.eq("status", true))
											.add(Restrictions.eq("batchName", iMap.getString("BATCH_NAME")))
											.setProjection(Projections.projectionList().add(Projections.groupProperty("paramKey"))).list();
			
			for(String paramKey : paramKeyList) {
				GuimlUtil.wrapMyCombo(oMap, "BATCH_PARAMETERS" , paramKey, paramKey);
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	
	@GraymoundService("CDM_GET_BATCH_PARAMETER_VALUES_COMBO")
	public static GMMap getBatchParameterValuesCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")			
			List<BatchParameters> batchParamList = session.createCriteria(BatchParameters.class)
											.add(Restrictions.eq("status", true))
											.add(Restrictions.eq("batchName", iMap.getString("BATCH_NAME")))
											.add(Restrictions.eq("paramKey", iMap.getString("PARAM_KEY"))).list();
			
			for(BatchParameters batchParam : batchParamList) {
				GuimlUtil.wrapMyCombo(oMap, "PARAMETER_VALUES", batchParam.getOid(), batchParam.getKeyValueDescription());				
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}			
	}			
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_BATCH_PROCESS_LIST")
	public static GMMap getBatchProcessList(GMMap iMap) {
		
		GMMap output = new GMMap();
		try {
			String corporateCode = iMap.getString("KURUM_KODU");
			List<CorporateBatchProcess> processList = CommonHelper.getHibernateSession().createCriteria(CorporateBatchProcess.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.list();
			
			for (CorporateBatchProcess process : processList) {
				int index = processList.indexOf(process);
				output.put("BATCH_PROCESS_LIST", index, "OID", process.getOid());
				output.put("BATCH_PROCESS_LIST", index, "BATCH_NAME", process.getBatchName());
				output.put("BATCH_PROCESS_LIST", index, "COMMIT_COUNT", process.getCommitCount());
				output.put("BATCH_PROCESS_LIST", index, "THREAD_COUNT", process.getThreadCount());
				output.put("BATCH_PROCESS_LIST", index, "TRY_COUNT", process.getTryCount());
				output.put("BATCH_PROCESS_LIST", index, "TEXT_PARAMETER", process.getTextParameter());
				output.put("BATCH_PROCESS_LIST", index, "COMPLEX_BATCH", process.getComplexBatchDefinition() == null ? false : process.getComplexBatchDefinition());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
		
		return output;
	}		
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_BATCH_PROCESS_TX")
	public static GMMap getBatchProcessTx(GMMap iMap) {
		
		GMMap output = new GMMap();
		try {
			List<CorporateBatchProcessTx> processTxList = CommonHelper.getHibernateSession().createCriteria(CorporateBatchProcessTx.class)
					.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
					.list();
			
			for (CorporateBatchProcessTx processTx : processTxList) {
				int index = processTxList.indexOf(processTx);
				output.put("BATCH_PROCESS_LIST", index, "OID", processTx.getOid());
				output.put("BATCH_PROCESS_LIST", index, "BATCH_NAME", processTx.getBatchName());
				output.put("BATCH_PROCESS_LIST", index, "COMMIT_COUNT", processTx.getCommitCount());
				output.put("BATCH_PROCESS_LIST", index, "THREAD_COUNT", processTx.getThreadCount());
				output.put("BATCH_PROCESS_LIST", index, "TRY_COUNT", processTx.getTryCount());
				output.put("BATCH_PROCESS_LIST", index, "TEXT_PARAMETER", processTx.getTextParameter());
				output.put("BATCH_PROCESS_LIST", index, "COMPLEX_BATCH", processTx.getComplexBatchDefinition() == null ? false : processTx.getComplexBatchDefinition());
			}
			
			output.put("CORPORATE_CODE", processTxList.get(0).getCorporateCode());
			output.put("CORPORATE_NAME", CommonBusinessOperations.getCorporateNameFromCorporateCode(processTxList.get(0).getCorporateCode()));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
		
		return output;
	}		
	
	@GraymoundService("CDM_GET_BATCH_PROCESS_PARAM_LIST")
	public static GMMap getBatchProcessParamList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Criteria criteria = session.createCriteria(BatchParameters.class)
								.add(Restrictions.eq("status", true));
			
			DetachedCriteria detachedCriteria = DetachedCriteria.forClass(BatchUsedParam.class);			
			detachedCriteria.add(Restrictions.eq("status", true));
			detachedCriteria.add(Restrictions.eq("batchProcessOid", iMap.getString("BATCH_PROCESS_OID")));
			detachedCriteria.setProjection(Property.forName("batchParamOid"));
			criteria.add(Property.forName("oid").in(detachedCriteria));
			
			@SuppressWarnings("unchecked")
			List<BatchParameters> batchParamList = criteria.list();
			
			int i = 0;
			for(BatchParameters batchParam : batchParamList) {
				
				BatchUsedParam batchUsedParam = (BatchUsedParam) session.createCriteria(BatchUsedParam.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("batchParamOid", batchParam.getOid()))
												.add(Restrictions.eq("batchProcessOid", iMap.getString("BATCH_PROCESS_OID")))
												.uniqueResult();
				
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "USED_PARAM_OID", batchUsedParam.getOid());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "OID", batchParam.getOid());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "PARAM_KEY", batchParam.getParamKey());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "KEY_VALUE_DESCRIPTION", batchParam.getKeyValueDescription());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "SIL", false);
				i++;
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_GET_BATCH_PROCESS_PARAM_TX_LIST")
	public static GMMap getBatchProcessParamTxList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Criteria criteria = session.createCriteria(BatchParameters.class)
					.add(Restrictions.eq("status", true));
			
			DetachedCriteria detachedCriteria = DetachedCriteria.forClass(BatchUsedParamTx.class);			
			detachedCriteria.add(Restrictions.eq("status", true));
			detachedCriteria.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")));
			detachedCriteria.setProjection(Property.forName("batchParamOid"));
			criteria.add(Property.forName("oid").in(detachedCriteria));
			
			@SuppressWarnings("unchecked")
			List<BatchParameters> batchParamList = criteria.list();
			
			int i = 0;
			for(BatchParameters batchParam : batchParamList) {
				
				BatchUsedParamTx batchUsedParamTx = (BatchUsedParamTx) session.createCriteria(BatchUsedParamTx.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("batchParamOid", batchParam.getOid()))
						.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
						.uniqueResult();
				
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "USED_PARAM_OID", batchUsedParamTx.getOid());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "OID", batchParam.getOid());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "PARAM_KEY", batchParam.getParamKey());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "KEY_VALUE_DESCRIPTION", batchParam.getKeyValueDescription());
				oMap.put("BATCH_PROCESS_PARAM_LIST", i, "SIL", false);
				i++;
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_SAVE_BATCH_PROCESS_LIST")
	public static GMMap saveBatchProcessList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String islemTipi = iMap.getString("ISLEM_TIPI");	
			String batchProcessOid = iMap.getString("OID");
			String tableName = "BATCH_PROCESS_PARAM_LIST";
			
			int commitCount = 0;
			Short threadCount = null;
			Integer tryCount = null; 
			String commitCountStr = iMap.getString("COMMIT_COUNT");
			String threadCountStr = iMap.getString("THREAD_COUNT");
			String tryCountStr = iMap.getString("TRY_COUNT");
			Integer zero = new Integer("0");
			Short shortZero = new Short("0");
			
			if (!"".equals(commitCountStr))			
				commitCount = Integer.valueOf(commitCountStr);
			if (!"".equals(threadCountStr))
				threadCount = Short.parseShort(threadCountStr);
			if (!"".equals(tryCountStr))					
				tryCount =Integer.valueOf(tryCountStr);		
			
			if (!"SIL".equals(islemTipi)) { 
			    if (StringUtils.isBlank(commitCountStr) || StringUtils.isBlank(threadCountStr) || StringUtils.isBlank(tryCountStr)) {
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.EMPTYMESSAGE, "Commit, Thread, Deneme Say�s� alanlar� bo� olamaz"));				    	
				}
			    else if (commitCount == 0 || threadCount.compareTo(shortZero)==0 || tryCount.compareTo(zero)==0) {
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.EMPTYMESSAGE, "Commit, Thread, Deneme Say�s� alanlar� 0 de�erini alamaz"));				    				    	
			    }
			}
			
			GMMap insertBatchProcessLogMap = new GMMap();
			if ("EKLE".equals(islemTipi) || "GUNCELLE".equals(islemTipi)) 
				insertBatchProcessLogMap.put("STATUS", true);
			else if ("SIL".equals(islemTipi)) 
				insertBatchProcessLogMap.put("STATUS", false);
			insertBatchProcessLogMap.put("CORPORATE_CODE", iMap.getString("KURUM_KODU"));
			insertBatchProcessLogMap.put("BATCH_NAME", iMap.getString("BATCH_NAME"));
			insertBatchProcessLogMap.put("COMMIT_COUNT", iMap.getString("COMMIT_COUNT"));
			insertBatchProcessLogMap.put("THREAD_COUNT", iMap.getString("THREAD_COUNT"));
			insertBatchProcessLogMap.put("TRY_COUNT", iMap.getString("TRY_COUNT"));
			insertBatchProcessLogMap.put("TEXT_PARAMETER", iMap.getString("TEXT_PARAMETER"));
			insertBatchProcessLogMap.put("COMPLEX_BATCH_DEFINITION", iMap.getBoolean("COMPLEX_BATCH"));
			insertBatchProcessLogMap.put("BATCH_PROCESS_OID", batchProcessOid);
			
			BigDecimal txNo = GMServiceExecuter.call("CDM_INSERT_CORPORATE_BATCH_PROCESS_TX", insertBatchProcessLogMap).getBigDecimal("TX_NO");
			
			if (!"SIL".equals(islemTipi)) {

				for (int i = 0; i < iMap.getSize(tableName); i++) {
					if (!iMap.getBoolean(tableName, i, "SIL")) {
						BatchUsedParamTx batchUsedParamTx = new BatchUsedParamTx();
						batchUsedParamTx.setStatus(true);
						batchUsedParamTx.setBatchProcessOid(null);
						batchUsedParamTx.setBatchParamOid(iMap.getString(tableName, i, "OID")); 
						batchUsedParamTx.setTxNo(txNo); 
						batchUsedParamTx.setBatchUsedParamOid(null); 
						batchUsedParamTx.setCreateDate(new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()));
						batchUsedParamTx.setCreateUser(GMContext.getCurrentContext().getSession().get("USER_NAME").toString());
						
						session.save(batchUsedParamTx);
					}
				}			
			}
			
			GMMap transactionInputMap = new GMMap();
	    	transactionInputMap.put("TRX_NAME", "7012");
	    	transactionInputMap.put("TRX_NO", txNo);    
	    	
	    	GMMap transactionOutputMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", transactionInputMap);
	    	oMap.put("MESSAGE", transactionOutputMap.getString("MESSAGE"));										
			
			return oMap;
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}			
	
	@GraymoundService("CDM_INSERT_CORPORATE_BATCH_PROCESS_TX")
	public static GMMap insertBatchProcessLog(GMMap input) {
		
		GMMap output = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			String txNo = CommonHelper.getNewTransactionNo();
			
			CorporateBatchProcessTx batchProcessTx = new CorporateBatchProcessTx();
			batchProcessTx.setStatus(input.getBoolean("STATUS"));
			batchProcessTx.setCorporateCode(input.getString("CORPORATE_CODE"));
			batchProcessTx.setProcessPeriod("11");					
			batchProcessTx.setBatchName(input.getString("BATCH_NAME"));
			batchProcessTx.setCommitCount(Integer.valueOf(input.getString("COMMIT_COUNT")));
			batchProcessTx.setThreadCount(Short.valueOf(input.getString("THREAD_COUNT")));
			batchProcessTx.setTryCount(Integer.valueOf(input.getString("TRY_COUNT")));
			batchProcessTx.setCreateDate(new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()));
			batchProcessTx.setCreateUser(username);
			batchProcessTx.setTextParameter(input.getString("TEXT_PARAMETER"));
			batchProcessTx.setComplexBatchDefinition(input.getBoolean("COMPLEX_BATCH_DEFINITION"));
			batchProcessTx.setTxNo(new BigDecimal(txNo));
			batchProcessTx.setBatchProcessOid(input.getString("BATCH_PROCESS_OID"));
			session.save(batchProcessTx);
			
			output.put("TX_NO", txNo);
			return output;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_TRN7012_AFTER_APPROVAL")
    public static GMMap trn7012AfterApproval(GMMap input) throws Exception {

		GMMap output = new GMMap();		
		final String APPROVE = "O";
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
			String trxType = input.getString("ISLEM_TURU");	
			String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			
			if (trxType.equals(APPROVE)) {
				
				CorporateBatchProcessTx batchProcessTx = (CorporateBatchProcessTx) session.createCriteria(CorporateBatchProcessTx.class)
															.add(Restrictions.eq("txNo", txNo)).uniqueResult();
				if (batchProcessTx.isStatus()) { //ekle, g�ncelle
					//yeni kay�tlar� olu�tur
					CorporateBatchProcess batchProcess = new CorporateBatchProcess();
					CommonHelper.mapObjects(batchProcessTx, batchProcess, CommonHelper.getPojoExceptionalFields());
					batchProcess.setCreateDate(new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()));
					batchProcess.setCreateUser(username);
					session.save(batchProcess);
					
					List<BatchUsedParamTx> usedParamTxList = session.createCriteria(BatchUsedParamTx.class).add(Restrictions.eq("txNo", txNo)).list();
					for (BatchUsedParamTx usedParamTx : usedParamTxList) {
						BatchUsedParam usedParam = new BatchUsedParam();
						CommonHelper.mapObjects(usedParamTx, usedParam, CommonHelper.getPojoExceptionalFields());
						usedParam.setBatchProcessOid(batchProcess.getOid());
						session.save(usedParam);
					}
					
					//eskilerin stat�s�n� g�ncelle
					if (StringUtils.isNotEmpty(batchProcessTx.getBatchProcessOid())) {
						CorporateBatchProcess batchProcessToDelete = (CorporateBatchProcess) session.createCriteria(CorporateBatchProcess.class)
								.add(Restrictions.eq("oid", batchProcessTx.getBatchProcessOid())).uniqueResult();
						batchProcessToDelete.setStatus(false);
						session.update(batchProcessToDelete);
						
						List<BatchUsedParam> usedParamListToDelete = session.createCriteria(BatchUsedParam.class)
								.add(Restrictions.eq("batchProcessOid", batchProcessTx.getBatchProcessOid())).list();
						for (BatchUsedParam usedParamToDelete : usedParamListToDelete) {
							usedParamToDelete.setStatus(false);
							session.update(usedParamToDelete);
						}
					}
					
				} else { //sil
					CorporateBatchProcess batchProcessToDelete = (CorporateBatchProcess) session.createCriteria(CorporateBatchProcess.class)
																	.add(Restrictions.eq("oid", batchProcessTx.getBatchProcessOid())).uniqueResult();
					batchProcessToDelete.setStatus(false);
					session.update(batchProcessToDelete);
					
					List<BatchUsedParam> usedParamListToDelete = session.createCriteria(BatchUsedParam.class)
																.add(Restrictions.eq("batchProcessOid", batchProcessTx.getBatchProcessOid())).list();
					for (BatchUsedParam usedParamToDelete : usedParamListToDelete) {
						usedParamToDelete.setStatus(false);
						session.update(usedParamToDelete);
					}
				}
				
			}
			
			session.flush();			
		}catch(Exception ex){
			throw ExceptionHandler.convertException(ex);
		}		
		return output;
    }	
	
	@GraymoundService("CDM_ADD_BATCH_PROCESS_PARAM_LIST")
	public static GMMap saveBatchProcessParamList(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		String tableName = "BATCH_PROCESS_PARAM_LIST";	
		String comboSelectedParamooId = iMap.getString("COMBO_SELECTED_PARAM_OID");
		String comboSelectedParamKey = iMap.getString("COMBO_SELECTED_PARAM_KEY");		
		String comboSelectedParamKeyDesc = iMap.getString("COMBO_SELECTED_PARAM_KEY_DESC");		
		
		try {
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				oMap.put(tableName, row, "OID", iMap.getString(tableName, row, "OID"));
				oMap.put(tableName, row, "USED_PARAM_OID", iMap.getString(tableName, row, "USED_PARAM_OID"));				
				oMap.put(tableName, row, "SIL", iMap.getBoolean(tableName, row, "SIL"));	
				oMap.put(tableName, row, "PARAM_KEY", iMap.getString(tableName, row, "PARAM_KEY"));	
				oMap.put(tableName, row, "KEY_VALUE_DESCRIPTION", iMap.getString(tableName, row, "KEY_VALUE_DESCRIPTION"));		
			}				
			
			if (comboSelectedParamooId == null || comboSelectedParamKey == null) {
				oMap.put("HATA", true);
				oMap.put("MESSAGE", "Eklemek istedi�iniz parametre ve de�er alanlar�n� kontrol ediniz.");			
				return oMap;
			}
			else {
				for (int row = 0; row < iMap.getSize(tableName); row++) {
					String paramKey = iMap.getString(tableName, row, "PARAM_KEY"); 
					if (paramKey.equals(comboSelectedParamKey)) {
						oMap.put("HATA", true);
						oMap.put("MESSAGE", "Eklemek istedi�iniz parametre daha �nce eklenmi�tir.");			
						return oMap;						
					}
				}
			}			
			
			int nextRow = iMap.getSize(tableName);
			oMap.put(tableName, nextRow, "OID", comboSelectedParamooId);
			oMap.put(tableName, nextRow, "USED_PARAM_OID", "");
			oMap.put(tableName, nextRow, "SIL", false);	
			oMap.put(tableName, nextRow, "PARAM_KEY", comboSelectedParamKey);	
			oMap.put(tableName, nextRow, "KEY_VALUE_DESCRIPTION", comboSelectedParamKeyDesc);			
			
			oMap.put("HATA", false);	
			oMap.put("MESSAGE", "");			
			return oMap;	
			
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}			
	
	@GraymoundService("CDM_GET_SUBMIT_STATUS_COMBO")
	public static GMMap getSubmitStatusCombo(GMMap iMap) {
				
		return CorporationServiceUtil.getComboValues(iMap);
	}
	
	@GraymoundService("CDM_GET_BATCH_SUBMIT_LOGS")
	public static GMMap getBatchSubmitLogs(GMMap iMap) {
		
		String tableName = "SUBMIT_LOGS";
		GMMap oMap = new GMMap();
		try {
			
			if (iMap.getDate("START_DATE") == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));
			
			if (iMap.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date startDate = CommonHelper.getDateTime(iMap.getString("START_DATE"), "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(iMap.getString("END_DATE"), "yyyyMMdd");			
			long diffInDays = CommonHelper.subtractDatesToDays(endDate, startDate);
			
			if (diffInDays > 180)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MAXDATEINTERVALEXCEEDED, 6));

			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));		
			
			StringBuilder queryBuilder = new StringBuilder();
//			queryBuilder.append("SELECT bsl.oid, bsl.batch_name, bsl.batch_submit_id, bsl.corporate_code,cm.short_code, p.text submit_status, trunc(to_date(bsl.start_time, 'YYYYMMDDHH24MISS')) start_date, ");
//			queryBuilder.append("substr(bsl.start_time,9,6) start_time, trunc(to_date(bsl.end_time, 'YYYYMMDDHH24MISS')) end_date, substr(bsl.end_time,9,6) end_time, ");
//			queryBuilder.append("bsl.submit_user, trunc(to_date(bsl.submit_date, 'YYYYMMDDHH24MISS')) submit_date, ");
//			queryBuilder.append("bsl.error_code, bsl.error_desc, ftl.total_line_count, ftl.total_amount,ftl.total_load_count, ftl.total_load_amount ");
//			queryBuilder.append("FROM cdm.batch_submit_log bsl LEFT JOIN cdm.file_transfer_log ftl ON bsl.batch_submit_id=ftl.batch_submit_id ");
//			queryBuilder.append("INNER JOIN bnspr.v_ml_gnl_param_text p ON p.kod='CDM_BATCH_SUBMIT_STATUS' AND p.key1=bsl.submit_status ");
//			queryBuilder.append("INNER JOIN cdm.corporate_master cm ON cm.corporate_code=bsl.corporate_code ");
//			queryBuilder.append(String.format("WHERE bsl.status=1 AND bsl.batch_name = '%s' AND bsl.submit_date BETWEEN '%s' AND '%s'", iMap.getString("BATCH_NAME"), iMap.getString("START_DATE").concat("000000"), iMap.getString("END_DATE").concat("235959")));
			queryBuilder.append(String.format(QueryRepository.CorporationBatchDefinitionServicesRepository.GET_BATCH_SUBMIT_LOG_QUERY, iMap.getString("BATCH_NAME"), iMap.getString("START_DATE").concat("000000"), iMap.getString("END_DATE").concat("235959")));
			if(!StringUtil.isEmpty(iMap.getString("KURUM_KODU", null))){
				queryBuilder.append(String.format(" AND bsl.corporate_code='%s'", iMap.getString("KURUM_KODU")));
			}
			
			if(!StringUtil.isEmpty(iMap.getString("SUBMIT_STATUS", null))){
				queryBuilder.append(String.format(" AND bsl.submit_status='%s'", iMap.getString("SUBMIT_STATUS")));
			}
			
			queryBuilder.append(" ORDER BY cm.short_code");
			
			oMap = DALUtil.getResults(queryBuilder.toString(), tableName);
			
			@SuppressWarnings("unchecked")
			List<Map<String,Object>> resultList = (List<Map<String,Object>>) oMap.get(tableName);
			int counter = 0;
			if( null != resultList &&resultList.size() > 0 ){
				Iterator<Map<String, Object>> resultIterator = resultList.iterator();
				while( resultIterator.hasNext() ){
					Map<String, Object> nextElement = resultIterator.next();
					String batchSubmitOid = nextElement.get("BATCH_SUBMIT_ID").toString();
					if( null != batchSubmitOid ){
						Session hibernateSession = CommonHelper.getHibernateSession();
						Criteria criteria = hibernateSession.createCriteria(FileTransferLog.class)
						.setProjection(Projections.projectionList().add(Projections.property("ftmSequenceNumber")))
						.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
						
						Object ftmSequenceNumberObj = criteria.add(Restrictions.eq("batchSubmitId", batchSubmitOid)).uniqueResult();
						if( null != ftmSequenceNumberObj ){
							String ftmSequenceNumber = ftmSequenceNumberObj.toString();
							
							FtmProcess ftmProcess = (FtmProcess) hibernateSession.get(FtmProcess.class, new BigDecimal(ftmSequenceNumber));
							if( null != ftmProcess ){
								oMap.put(tableName, counter,"FILE_NAME",ftmProcess.getFileName());
							}
						}
					}
					counter++;
				}
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_GET_BATCH_SUBMIT_LOG_PARAMETERS")
	public static GMMap getBatchSubmitLog(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "LOG_PARAMS";
			String oId = iMap.getString("OID");
								
			BatchSubmitLog batchSubmitLog = (BatchSubmitLog) session.createCriteria(BatchSubmitLog.class)
					.add(Restrictions.eq("oid", oId))
					.add(Restrictions.eq("status", true))
					.uniqueResult();												
			if (batchSubmitLog != null) {
				String parametersText = batchSubmitLog.getParameters();				
				
				if (StringUtils.isNotBlank(parametersText)) {					
					int counter = 0;
					GMMap requestParameters = new GMMap();
					try {
						requestParameters = CommonHelper.deserializeRequest(parametersText);						
					}
					catch (Exception e) {
						logger.error(System.currentTimeMillis(), e);
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.PARAMETERSNOTVALID));									
					}
					
					for (Map.Entry<Object, Object> entry : requestParameters.entrySet()) {
						oMap.put(tableName, counter, "KEY", entry.getKey());
						oMap.put(tableName, counter, "VALUE", entry.getValue());
						counter++;
					}
					oMap.put("PARAMETERS_EXISTS", true);
				} else
					oMap.put("PARAMETERS_EXISTS", false);
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CDM_RESUBMIT_BATCH")
	public static GMMap resubmitBatch(GMMap input){
		try {
			Session session = CommonHelper.getHibernateSession();
			String batchSubmitId = input.getString("OID");
			BatchSubmitLog batchSubmitLog = (BatchSubmitLog) session.createCriteria(BatchSubmitLog.class)
					.add(Restrictions.eq("oid", batchSubmitId))
					.add(Restrictions.eq("status", true))
					.uniqueResult();
			if(batchSubmitLog != null){
				String parameters = batchSubmitLog.getParameters();
				if(!StringUtil.isEmpty(parameters)){
					GMMap request = CommonHelper.deserializeRequest(parameters);
					if(request.containsKey(MapKeys.BATCH_SERVICE_NAME_FOR_RESUBMIT)){
						String serviceName = request.getString(MapKeys.BATCH_SERVICE_NAME_FOR_RESUBMIT);
						GMMap batchRemoteSubmitRequest = new GMMap();
						request.put("IS_TRIGGER_AGAIN", true);
						batchRemoteSubmitRequest.put("INPUT_MAP", request);
						batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", serviceName);
						CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT", batchRemoteSubmitRequest);
					}
					else{
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NORESUBMITBATCHNAMEFOUND));		
					}
				}
				else{
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NORESUBMITPARAMETERFOUND));	
				}
			}
			
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}

