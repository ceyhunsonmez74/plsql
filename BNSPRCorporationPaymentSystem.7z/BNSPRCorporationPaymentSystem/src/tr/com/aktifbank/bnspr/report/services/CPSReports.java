package tr.com.aktifbank.bnspr.report.services;


import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CommissionDef;
import tr.com.aktifbank.bnspr.dao.SectorDef;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CPSReports{
	private static final Log logger = LogFactory.getLog(CPSReports.class);
	
	public static String checkStringCondition(String inputString) {		
		if ("".equals(inputString))
			return null;
		else if (inputString != null)
			return String.format("\'%s\'", inputString);
		return null;
	}
	
	@GraymoundService("CDM_GET_CHANNEL_CODE")
	public static GMMap bnsprGetChannelCode(GMMap input) {
		
		GMMap output = new GMMap();
		try {					
			String channelId = CommonHelper.getChannelId();
	        output.put("CHANNEL_ID", channelId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}	
	
    @GraymoundService("CDM_GET_SUBE_LIST_WITH_EMPTY_KEY")
    public static GMMap getSubeList(GMMap iMap){ 
    	
        GMMap oMap = new GMMap();
        try { 
           
            String listName = "SUBE_LIST";
            
			GMMap output = DALUtil.getResults(QueryRepository.CPSReportsRepository.SUBE_LIST_QUERY, listName);
			
			GuimlUtil.wrapMyCombo(oMap, listName, null, "Hepsi");
			for (int i = 0; i < output.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(oMap, listName, output.get(listName, i, "SUBE_KODU").toString(), output.get(listName, i, "SUBE_ADI").toString());
			}           
            
            return oMap;
        } 
        catch (Exception e) {
        	throw ExceptionHandler.convertException(e);
        }
    }	
		
	@GraymoundService("CDM_GET_STO_CUSTOMERS_REPORT")
	public static GMMap cdmGetStandingOrderCustomersReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {			
            HashMap<String, Object> parameters = new HashMap<String, Object>();
			DateFormat shortDateTimeFormat = new SimpleDateFormat("dd.MM.yyyy");	            
			String tableName = "LIST";
            
			String customerNo = input.getString("CUSTOMER_NO");
			String branchId = input.getString("BRANCH_ID");
			String channelId = input.getString("CHANNEL_ID");
			String statusId = input.getString("STATUS_ID");			
			String corporateCode = input.getString("CORPORATE_CODE");
			String subscriberNo1 = input.getString("SUBSCRIBER_NO_1");
			String subscriberNo2 = input.getString("SUBSCRIBER_NO_2");
			String subscriberNo3 = input.getString("SUBSCRIBER_NO_3");
			String subscriberNo4 = input.getString("SUBSCRIBER_NO_4");					
			Short paymentType = null;
			String paymentTypeStr = input.getString("PAYMENT_TYPE");
			if (paymentTypeStr != null)			
				paymentType = Short.parseShort(paymentTypeStr);			
			Date startDate, endDate;
			String query, startDateStr, endDateStr;
		
			if ((input.getDate("START_DATE") != null) && (input.getDate("END_DATE") != null)) { 
				startDate = CommonHelper.getDateTime(input.getString("START_DATE"), "yyyyMMdd");
				endDate = CommonHelper.getDateTime(input.getString("END_DATE"), "yyyyMMdd");			
				
				if (startDate.compareTo(endDate) > 0)
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));		
			}
			
			if ("".equals(customerNo)) customerNo = null;
			if ("".equals(subscriberNo1))
				subscriberNo1 = null;
			else if (subscriberNo1 != null)
				subscriberNo1 = String.format("\'%s\'", subscriberNo1);
			if ("".equals(subscriberNo2))
				subscriberNo2 = null;
			else if (subscriberNo2 != null)
				subscriberNo2 = String.format("\'%s\'", subscriberNo2);
			if ("".equals(subscriberNo3))
				subscriberNo3 = null;
			else if (subscriberNo3 != null)
				subscriberNo3 = String.format("\'%s\'", subscriberNo3);
			if ("".equals(subscriberNo4))
				subscriberNo4 = null;
			else if (subscriberNo4 != null)
				subscriberNo4 = String.format("\'%s\'", subscriberNo4);
			if ("".equals(corporateCode))
				corporateCode = null;
			else if (corporateCode != null)
				corporateCode = String.format("\'%s\'", corporateCode);			
			
			StringBuilder s = new StringBuilder();
			s.append("SELECT rownum, x.*\n");
			s.append("FROM (\n"); 
			s.append("SELECT m.standing_order_type, m.standing_order_status, m.customer_no, m.user_label, m.standing_order_number, m.branch_code,\n");
			s.append("       m.channel_code, m.source_code, o.corporate_code, o.collection_type, o.subscriber_no1||nvl2(o.subscriber_no2,' - '||o.subscriber_no2,'')||nvl2(o.subscriber_no3,' - '||o.subscriber_no3,'')||nvl2(o.subscriber_no4,' - '||o.subscriber_no4,'') as subscriber_no1,\n");
			s.append("       acc.account_number, to_char(trunc(to_date(m.create_date, 'YYYYMMDDHH24MISS'))) order_create_date,\n");
			s.append("       to_char(trunc(to_date(m.update_date, 'YYYYMMDDHH24MISS'))) order_update_date,\n");			
			s.append("       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_STANDING_ORDER_STATUS' and a.KEY1 = m.standing_order_status) standing_order_status_name,\n");
			s.append("       (select b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = m.branch_code) branch_name,\n");
			s.append("       (select c.aciklama from bnspr.gnl_kanal_grup_kod_pr c where c.kod = m.channel_code) channel_name,\n");
			s.append("       (select d.source_name from cdm.source_param d where d.source_code = m.source_code) source_name,\n");
			s.append("       (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = o.corporate_code) corporate_name,\n");
			s.append("       (select f.collection_name from cdm.collection_type_prm f where f.collection_type = o.collection_type) collection_name,\n");
			s.append("       (select g.unvan from bnspr.v_gnl_musteri_aktif g where g.musteri_no = m.customer_no) customer_name\n");
			s.append("FROM   sto.standing_order_main m, ics.ics_standing_orders o, sto.standing_order_account acc\n");
			s.append("WHERE  m.status = 1 and o.status = 1 and acc.is_used = 1\n");
			s.append("       and m.oid = o.standing_order_oid\n");
			s.append("       and m.oid = acc.standing_order_oid\n"); 
			s.append("       and o.corporate_code = nvl(%s, o.corporate_code)\n");
			s.append("       and (m.customer_no = nvl(%s, m.customer_no) or m.customer_no is null)\n");
			s.append("       and (m.branch_code = nvl(%s, m.branch_code) or m.branch_code is null)\n");
			s.append("       and (m.channel_code = nvl(%s, m.channel_code) or m.channel_code is null)\n");
			s.append("       and (m.standing_order_status = nvl(%s, m.standing_order_status) or m.standing_order_status is null)\n");
			s.append("       and (o.collection_type = nvl(%s, o.collection_type) or o.collection_type is null)\n");			
			s.append("       and (o.subscriber_no1 = nvl(%s, o.subscriber_no1) or o.subscriber_no1 is null)\n");
			s.append("       and (o.subscriber_no2 = nvl(%s, o.subscriber_no2) or o.subscriber_no2 is null)\n");
			s.append("       and (o.subscriber_no3 = nvl(%s, o.subscriber_no3) or o.subscriber_no3 is null)\n");
			s.append("       and (o.subscriber_no4 = nvl(%s, o.subscriber_no4) or o.subscriber_no4 is null)\n");
			
			if ((input.getDate("START_DATE") != null) && (input.getDate("END_DATE") != null)) { 
				s.append("       and m.start_date >= \'%s\'\n");
				s.append("       and m.start_date <= \'%s\'\n");
			} 
			else if (input.getDate("START_DATE") != null)
				s.append("       and m.start_date >= \'%s\'\n");
			else if (input.getDate("END_DATE") != null)
				s.append("       and m.start_date <= \'%s\'\n");
			s.append("ORDER BY corporate_name, m.standing_order_status, o.collection_type, customer_name) x\n");
		
			if ((input.getDate("START_DATE") != null) && (input.getDate("END_DATE") != null)) { 			
				startDateStr = shortDateTimeFormat.format(CommonHelper.getDateTime(input.getString("START_DATE"), "yyyyMMdd"));
				endDateStr = shortDateTimeFormat.format(CommonHelper.getDateTime(input.getString("END_DATE"), "yyyyMMdd"));			
				query = String.format(s.toString(), corporateCode, customerNo, branchId, channelId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, startDateStr, endDateStr);
			} else if (input.getDate("START_DATE") != null) {
				startDateStr = shortDateTimeFormat.format(CommonHelper.getDateTime(input.getString("START_DATE"), "yyyyMMdd"));	
				query = String.format(s.toString(), corporateCode, customerNo, branchId, channelId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, startDateStr);
			} else if (input.getDate("END_DATE") != null) {
				endDateStr = shortDateTimeFormat.format(CommonHelper.getDateTime(input.getString("END_DATE"), "yyyyMMdd"));			
				query = String.format(s.toString(), corporateCode, customerNo, branchId, channelId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, endDateStr);
			} else
				query = String.format(s.toString(), corporateCode, customerNo, branchId, channelId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4);
			
            List<?> liste = (List<?>) DALUtil.getResults(query, tableName).get(tableName);
            parameters.put("TABLE_DATA", liste);  
            ArrayDeque<String> reports = new ArrayDeque<String>();
            reports.add("STO_CUSTOMERS_REPORT");
            JasperPrint jasperPrint = new JasperPrint();            
            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
            jasperPrint.removePage(0);        
            jasperPrint.removePage(jasperPrint.getPages().size()-1);
            
            if (jasperPrint.getPages().size() == 0)
            	CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOREPORTDATA));            	
            
            output.put("REPORT", jasperPrint);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@GraymoundService("CDM_GET_STO_PAYMENTS_REPORT")
	public static GMMap cdmGetStandingOrderPaymentsReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {			
            HashMap<String, Object> parameters = new HashMap<String, Object>();
			String tableName = "LIST";
			
			String customerNo = input.getString("CUSTOMER_NO");
			String branchId = input.getString("BRANCH_ID");
			String statusId = input.getString("STATUS_ID");			
			String corporateCode = input.getString("CORPORATE_CODE");
			String subscriberNo1 = input.getString("SUBSCRIBER_NO_1");
			String subscriberNo2 = input.getString("SUBSCRIBER_NO_2");
			String subscriberNo3 = input.getString("SUBSCRIBER_NO_3");
			String subscriberNo4 = input.getString("SUBSCRIBER_NO_4");					
			Short paymentType = null;
			String paymentTypeStr = input.getString("PAYMENT_TYPE");
			if (paymentTypeStr != null)			
				paymentType = Short.parseShort(paymentTypeStr);			
			Date startDate, endDate;
			String query, startDateStr, endDateStr;
		
			if ((input.getDate("START_DATE") != null) && (input.getDate("END_DATE") != null)) { 
				startDate = CommonHelper.getDateTime(input.getString("START_DATE"), "yyyyMMdd");
				endDate = CommonHelper.getDateTime(input.getString("END_DATE"), "yyyyMMdd");			
				
				if (startDate.compareTo(endDate) > 0)
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));		
			}
			
			if ("".equals(customerNo)) customerNo = null;
			if ("".equals(subscriberNo1))
				subscriberNo1 = null;
			else if (subscriberNo1 != null)
				subscriberNo1 = String.format("\'%s\'", subscriberNo1);
			if ("".equals(subscriberNo2))
				subscriberNo2 = null;
			else if (subscriberNo2 != null)
				subscriberNo2 = String.format("\'%s\'", subscriberNo2);
			if ("".equals(subscriberNo3))
				subscriberNo3 = null;
			else if (subscriberNo3 != null)
				subscriberNo3 = String.format("\'%s\'", subscriberNo3);
			if ("".equals(subscriberNo4))
				subscriberNo4 = null;
			else if (subscriberNo4 != null)
				subscriberNo4 = String.format("\'%s\'", subscriberNo4);
			if ("".equals(corporateCode))
				corporateCode = null;
			else if (corporateCode != null)
				corporateCode = String.format("\'%s\'", corporateCode);		
			if ("".equals(statusId))
				statusId = null;
			else if (statusId != null)
				statusId = String.format("\'%s\'", statusId);		
			
			StringBuilder s = new StringBuilder();
			s.append("SELECT rownum, x.*\n");
			s.append("FROM (\n"); 
			s.append("SELECT m.customer_no customer_no, i.subscriber_no1, to_char(i.amount, 'fm99999990.00999') invoice_amount,\n");
			s.append("       to_char(trunc(to_date(i.invoice_due_date, 'YYYYMMDDHH24MISS'))) invoice_due_date, soa.account_number account_number,\n");
			s.append("       to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) payment_date, to_char(p.payment_amount, 'fm99999990.00999') payment_amount,\n");
//			s.append("       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = i.payment_status) payment_status_name,\n");  �denmeyen kay�tlar�n a��klamas� g�r�lmesi i�in de�i�tirildi
			s.append("       nvl2(l.error_desc,substr(l.ERROR_DESC,0,100),(select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = i.payment_status)) payment_status_name,\n");
			s.append("       (select d.source_name from cdm.source_param d where d.source_code = p.payment_source) source_name,\n");
			s.append("       (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = i.corporate_code) corporate_name,\n");
			s.append("       (select f.collection_name from cdm.collection_type_prm f where f.collection_type = i.collection_type) collection_name,\n");
			s.append("       (select g.unvan from bnspr.v_gnl_musteri_aktif g where g.musteri_no = m.customer_no) customer_name\n");
			s.append("FROM   ics.invoice_main i left outer join ics.invoice_payment p on i.oid=p.invoice_main_oid left outer join ics.ICS_STD_ORDER_PROCESS_LOG l on i.oid=l.invoice_main_oid, sto.standing_order_main m, sto.STANDING_ORDER_ACCOUNT soa,bnspr.muh_hesap mh\n");
			s.append("WHERE  i.status = 1 \n");
			s.append("  	 and l.process_date=(select  max(process_date) from ics.ICS_STD_ORDER_PROCESS_LOG isopl where i.oid = isopl.invoice_main_oid)\n");
			s.append("       and i.standing_order_oid = m.oid and i.standing_order_oid is not null\n");
			s.append("       and soa.standing_order_oid = m.oid \n");
			s.append("       and soa.ACCOUNT_NUMBER = mh.hesap_no \n");
			s.append("       and i.corporate_code = nvl(%s, i.corporate_code)\n");
			if(!StringUtil.isEmpty(customerNo)){
				s.append(String.format("       and i.customer_no = '%s' \n", customerNo));
			}
			s.append("       and (mh.sube_kodu = nvl(%s, mh.sube_kodu) or mh.sube_kodu is null)\n");
			s.append("       and i.payment_status = nvl(%s, i.payment_status)\n");
			s.append("       and i.collection_type = nvl(%s, i.collection_type)\n");
			s.append("       and (i.subscriber_no1 = nvl(%s, i.subscriber_no1) or i.subscriber_no1 is null)\n");
			s.append("       and (i.subscriber_no2 = nvl(%s, i.subscriber_no2) or i.subscriber_no2 is null)\n");
			s.append("       and (i.subscriber_no3 = nvl(%s, i.subscriber_no3) or i.subscriber_no3 is null)\n");
			s.append("       and (i.subscriber_no4 = nvl(%s, i.subscriber_no4) or i.subscriber_no4 is null)\n");
			
			if ((input.getDate("START_DATE") != null) && (input.getDate("END_DATE") != null)) { 
				s.append("     and  i.invoice_due_date >= \'%s\'\n");
				s.append("     and  i.invoice_due_date <= \'%s\'\n");
			} 
			else if (input.getDate("START_DATE") != null)
				s.append("     and  i.invoice_due_date >= \'%s\'\n");
			else if (input.getDate("END_DATE") != null)
				s.append("     and  i.invoice_due_date <= \'%s\'\n");
			s.append("ORDER BY i.invoice_date desc, corporate_name, i.payment_status desc, i.collection_type, customer_name) x\n");
		
			if ((input.getDate("START_DATE") != null) && (input.getDate("END_DATE") != null)) { 			
				startDateStr = input.getString("START_DATE");
				endDateStr =   input.getString("END_DATE");			
				query = String.format(s.toString(), corporateCode, branchId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, startDateStr, endDateStr);
			} else if (input.getDate("START_DATE") != null) {
				startDateStr = input.getString("START_DATE");	
				query = String.format(s.toString(), corporateCode, branchId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, startDateStr);
			} else if (input.getDate("END_DATE") != null) {
				endDateStr = input.getString("END_DATE");			
				query = String.format(s.toString(), corporateCode, branchId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, endDateStr);
			} else
				query = String.format(s.toString(), corporateCode, branchId, statusId, paymentType, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4);
			
            List<?> liste = (List<?>) DALUtil.getResults(query, tableName).get(tableName);
            parameters.put("TABLE_DATA", liste);  
            ArrayDeque<String> reports = new ArrayDeque<String>();
            reports.add("STO_PAYMENTS_REPORT");
            JasperPrint jasperPrint = new JasperPrint();            
            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
            jasperPrint.removePage(0);
            jasperPrint.removePage(jasperPrint.getPages().size()-1);
            
            if (jasperPrint.getPages().size() == 0)
            	CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOREPORTDATA));
            
            output.put("REPORT", jasperPrint);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
		
	@GraymoundService("CDM_GET_PAYMENTS_SUMMARY_REPORT")
	public static GMMap cdmGetPaymentsSummaryReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {			
            HashMap<String, Object> parameters = new HashMap<String, Object>();		
			String outputTableName = "LIST";
			String inputTableName = "CURRENT_LIST";
			
			String sectorCode = input.getString("SECTOR_CODE");
			String customerNo = input.getString("CUSTOMER_NO");
			String branchId = input.getString("BRANCH_ID");
			String corporateBranchId = input.getString("CORPORATE_BRANCH_ID");			
			String channelId = input.getString("CHANNEL_ID");
			String statusId = input.getString("STATUS_ID");			
			String corporateCode = input.getString("CORPORATE_CODE");
			String paymentSourceId = input.getString("PAYMENT_SOURCE_ID");
			String minAmount = input.getString("MIN_AMOUNT");
			String maxAmount = input.getString("MAX_AMOUNT");
			String subscriberNo1 = input.getString("SUBSCRIBER_NO_1");
			String subscriberNo2 = input.getString("SUBSCRIBER_NO_2");
			String subscriberNo3 = input.getString("SUBSCRIBER_NO_3");
			String subscriberNo4 = input.getString("SUBSCRIBER_NO_4");		
			String invoiceNo = input.getString("INVOICE_NO");
			Short paymentType = null;
			String paymentTypeStr = input.getString("PAYMENT_TYPE");
			if (paymentTypeStr != null)			
				paymentType = Short.parseShort(paymentTypeStr);					
			String query1 = "";
			String query2 = "";
			String query = "";
			
			//227 nolu uat bug talebi dogrultusunda kaldirildi. 
//			if ("".equals(sectorCode) || "SECIMYOK".equals(sectorCode) || sectorCode == null) 
//				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Sekt�r"));

			if (input.getDate("START_DATE") == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));
			
			if (input.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date startDate = CommonHelper.getDateTime(input.getString("START_DATE"), "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(input.getString("END_DATE"), "yyyyMMdd");	
			String startDateStr = input.getString("START_DATE").concat("000000");
			String endDateStr = input.getString("END_DATE").concat("235959");	
			long diffInDays = CommonHelper.subtractDatesToDays(endDate, startDate);
			
			if (diffInDays > 2)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MAXDATEINTERVALDAYSEXCEEDED, 2));

			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));	
			
			if ("".equals(customerNo)) customerNo = null;
			if ("".equals(minAmount)) minAmount = null;
			if ("".equals(maxAmount)) maxAmount = null;
			if ("".equals(subscriberNo1))
				subscriberNo1 = null;
			else if (subscriberNo1 != null)
				subscriberNo1 = String.format("\'%s\'", subscriberNo1);
			if ("".equals(subscriberNo2))
				subscriberNo2 = null;
			else if (subscriberNo2 != null)
				subscriberNo2 = String.format("\'%s\'", subscriberNo2);
			if ("".equals(subscriberNo3))
				subscriberNo3 = null;
			else if (subscriberNo3 != null)
				subscriberNo3 = String.format("\'%s\'", subscriberNo3);
			if ("".equals(subscriberNo4))
				subscriberNo4 = null;
			else if (subscriberNo4 != null)
				subscriberNo4 = String.format("\'%s\'", subscriberNo4);
			if ("".equals(corporateCode))
				corporateCode = null;
			else if (corporateCode != null)
				corporateCode = String.format("\'%s\'", corporateCode);		
			if ("".equals(statusId))
				statusId = null;
			else if (statusId != null)
				statusId = String.format("\'%s\'", statusId);	
			if ("".equals(sectorCode)|| "SECIMYOK".equals(sectorCode))
				sectorCode = null;
			else if (sectorCode != null)
				sectorCode = String.format("\'%s\'", sectorCode);
			if ("".equals(invoiceNo))
				invoiceNo = null;
			else if (invoiceNo != null)
				invoiceNo = String.format("\'%s\'", invoiceNo);
			
			
			if (StringUtils.isNotEmpty(sectorCode) && sectorCode.equals(String.format("\'%s\'", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "GAME_OF_CHANCE_SECTOR_CODE")))) {
				StringBuilder s = new StringBuilder();
				s.append("SELECT * FROM ( \n");
				s.append("SELECT (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name,\n");
				s.append("       (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = t.corporate_code) corporate_name,\n");
				s.append("       (select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = t.corporate_code) short_code,\n");
				s.append("       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = t.transfer_status) payment_status_name,\n");
		        s.append("       to_char(sum(decode(t.channel_code, '1', t.transfer_amount, 0)), 'fm99999990.00999') branch_amount,\n");    
		        s.append("       to_char(sum(decode(t.channel_code, '53', t.transfer_amount, 0)), 'fm99999990.00999') internet_amount,\n");  
		        s.append("       to_char(sum(decode(t.channel_code, '10', t.transfer_amount, 0)), 'fm99999990.00999') corp_internet_amount,\n");  	        
		        s.append("       to_char(sum(decode(t.channel_code, '40', t.transfer_amount, 0)), 'fm99999990.00999') call_center_amount,\n");  
		        s.append("       to_char(sum(decode(t.channel_code, '21', t.transfer_amount, 0)), 'fm99999990.00999') epos_amount,\n");  
		        s.append("       to_char(sum(decode(t.channel_code, '32', t.transfer_amount, 0)), 'fm99999990.00999') yim_amount,\n");
		        s.append("       to_char(sum(decode(t.channel_code, '45', t.transfer_amount, 0)), 'fm99999990.00999') standing_order_amount,\n");
				s.append("       to_char(sum(decode(t.channel_code, '1', 1, 0))) branch_count,\n");
				s.append("       to_char(sum(decode(t.channel_code, '53', 1, 0))) internet_count,\n");
				s.append("       to_char(sum(decode(t.channel_code, '10', 1, 0))) corp_internet_count,\n");			
				s.append("       to_char(sum(decode(t.channel_code, '40', 1, 0))) call_center_count,\n");
				s.append("       to_char(sum(decode(t.channel_code, '21', 1, 0))) epos_count,\n");
				s.append("       to_char(sum(decode(t.channel_code, '32', 1, 0))) yim_count,\n");
				s.append("       to_char(sum(decode(t.channel_code, '45', 1, 0))) standing_order_count,\n");
				s.append("       to_char(decode(sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_commission,\n");			
				s.append("       to_char(decode(sum(t.transfer_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(t.transfer_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_amount,\n");
			    s.append("       to_char(sum(1)) total_count\n");
				s.append("FROM   ics.gcs_transfer t left join ics.gcs_commission comm on  t.oid = comm.gcs_transfer_oid and comm.status = 1,\n");			
				s.append("       cdm.corporate_master m, bnspr.muh_hesap hsp\n");
				s.append("WHERE  t.status = 1 and m.status = 1\n");
				s.append("       and t.corporate_code = m.corporate_code and t.corporate_account_no = hsp.hesap_no\n");
				s.append("       and m.sector_code = nvl(%s, m.sector_code)\n");
				s.append("       and t.corporate_code = nvl(%s, t.corporate_code)\n");
				s.append("       and (t.customer_no = nvl(%s, t.customer_no) or t.customer_no is null)\n");
				s.append("       and (t.account_branch_code = nvl(%s, t.account_branch_code) or t.account_branch_code is null)\n");
				s.append("       and t.transfer_status = nvl(%s, t.transfer_status)\n");
				s.append("       and (t.source_code = nvl(%s, t.source_code) or t.source_code is null)\n");
				s.append("       and t.collection_type = nvl(%s, t.collection_type)\n");
				s.append("       and (t.channel_code = nvl(%s, t.channel_code) or t.channel_code is null)\n");
				s.append("       and hsp.sube_kodu = nvl(%s, hsp.sube_kodu)\n");
				s.append("       and (t.member_id = nvl(%s, t.member_id) or t.member_id is null)\n");
				s.append("       and t.transfer_date >= \'%s\'\n");
				s.append("       and t.transfer_date <= \'%s\'\n");
				
				if ((minAmount != null) && (maxAmount != null)) { 
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				} 
				else if (minAmount != null)
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
				else if (maxAmount != null)
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				
				s.append("GROUP BY REPLACE(SHORT_CODE,'�','I'),m.sector_code, t.corporate_code, t.transfer_status\n");
				
				if (minAmount != null && maxAmount != null) { 					
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount, maxAmount);
				} else if (minAmount != null) {
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount);
				} else if (maxAmount != null) {	
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, maxAmount);
				} else
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr);
				query = query1 + " ) x";
				
			} else {
				StringBuilder s = new StringBuilder();
				s.append("SELECT * FROM ( \n");
				s.append("SELECT (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name,\n");
				s.append("       (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) corporate_name,\n");
				s.append("       (select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) short_code,\n");
				s.append("       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = p.payment_status) payment_status_name,\n");
		        s.append("       to_char(sum(decode(p.payment_channel, '1', p.payment_amount, 0)), 'fm99999990.00999') branch_amount,\n");    
		        s.append("       to_char(sum(decode(p.payment_channel, '53', p.payment_amount, 0)), 'fm99999990.00999') internet_amount,\n");  
		        s.append("       to_char(sum(decode(p.payment_channel, '10', p.payment_amount, 0)), 'fm99999990.00999') corp_internet_amount,\n");  	        
		        s.append("       to_char(sum(decode(p.payment_channel, '40', p.payment_amount, 0)), 'fm99999990.00999') call_center_amount,\n");  
		        s.append("       to_char(sum(decode(p.payment_channel, '21', p.payment_amount, 0)), 'fm99999990.00999') epos_amount,\n");  
		        s.append("       to_char(sum(decode(p.payment_channel, '32', p.payment_amount, 0)), 'fm99999990.00999') yim_amount,\n");
		        s.append("       to_char(sum(decode(p.payment_channel, '45', p.payment_amount, 0)), 'fm99999990.00999') standing_order_amount,\n");
				s.append("       to_char(sum(decode(p.payment_channel, '1', 1, 0))) branch_count,\n");
				s.append("       to_char(sum(decode(p.payment_channel, '53', 1, 0))) internet_count,\n");
				s.append("       to_char(sum(decode(p.payment_channel, '10', 1, 0))) corp_internet_count,\n");			
				s.append("       to_char(sum(decode(p.payment_channel, '40', 1, 0))) call_center_count,\n");
				s.append("       to_char(sum(decode(p.payment_channel, '21', 1, 0))) epos_count,\n");
				s.append("       to_char(sum(decode(p.payment_channel, '32', 1, 0))) yim_count,\n");
				s.append("       to_char(sum(decode(p.payment_channel, '45', 1, 0))) standing_order_count,\n");
				s.append("       to_char(decode(sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_commission,\n");			
				s.append("       to_char(decode(sum(p.payment_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(p.payment_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_amount,\n");
			    s.append("       to_char(sum(1)) total_count\n");
				s.append("FROM   ics.invoice_payment p left join ics.invoice_commission comm on  p.oid = comm.invoice_payment_oid and comm.status = 1,\n");			
				s.append("       cdm.corporate_master m, bnspr.muh_hesap hsp\n");
				s.append("WHERE  p.status = 1 and m.status = 1\n");
				s.append("       and p.corporate_code = m.corporate_code and p.corporate_account_no = hsp.hesap_no\n");
				s.append("       and m.sector_code = nvl(%s, m.sector_code)\n");
				s.append("       and p.corporate_code = nvl(%s, p.corporate_code)\n");
				s.append("       and (p.payer_customer = nvl(%s, p.payer_customer) or p.payer_customer is null)\n");
				s.append("       and (p.payment_branch = nvl(%s, p.payment_branch) or p.payment_branch is null)\n");
				s.append("       and p.payment_status = nvl(%s, p.payment_status)\n");
				s.append("       and (p.payment_source = nvl(%s, p.payment_source) or p.payment_source is null)\n");
				s.append("       and p.collection_type = nvl(%s, p.collection_type)\n");
				s.append("       and (p.payment_channel = nvl(%s, p.payment_channel) or p.payment_channel is null)\n");
				s.append("       and hsp.sube_kodu = nvl(%s, hsp.sube_kodu)\n");
				s.append("       and (p.subscriber_no1 = nvl(%s, p.subscriber_no1) or p.subscriber_no1 is null)\n");
				s.append("       and (p.subscriber_no2 = nvl(%s, p.subscriber_no2) or p.subscriber_no2 is null)\n");
				s.append("       and (p.subscriber_no3 = nvl(%s, p.subscriber_no3) or p.subscriber_no3 is null)\n");
				s.append("       and (p.subscriber_no4 = nvl(%s, p.subscriber_no4) or p.subscriber_no4 is null)\n");
				s.append("       and (p.invoice_no = nvl(%s, p.invoice_no) or p.invoice_no is null)\n");
				s.append("       and p.payment_date >= \'%s\'\n");
				s.append("       and p.payment_date <= \'%s\'\n");
				
				if ((minAmount != null) && (maxAmount != null)) { 
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				} 
				else if (minAmount != null)
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
				else if (maxAmount != null)
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				
				s.append("GROUP BY REPLACE(SHORT_CODE,'�','I'),m.sector_code, p.corporate_code, p.payment_status\n");
				
				if (minAmount != null && maxAmount != null) { 					
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, 
										  invoiceNo, startDateStr, endDateStr, minAmount, maxAmount);
				} else if (minAmount != null) {
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4,
										  invoiceNo, startDateStr, endDateStr, minAmount);
				} else if (maxAmount != null) {	
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4,
								          invoiceNo, startDateStr, endDateStr, maxAmount);
				} else
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4,
										  invoiceNo, startDateStr, endDateStr);
				
				// TL yuklemeden gelen kayitlar icin bu SQL yazildi
				StringBuilder s2 = new StringBuilder();
				if (StringUtil.isEmpty(invoiceNo)) {
					s2.append(" UNION ");
					s2.append("SELECT (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name,\n");
					s2.append("		(select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) corporate_name,\n");
					s2.append("		(select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) short_code,\n");
					s2.append("		(select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = p.payment_status) payment_status_name,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '1', p.payment_amount, 0)), 'fm99999990.00999') branch_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '53', p.payment_amount, 0)), 'fm99999990.00999') internet_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '10', p.payment_amount, 0)), 'fm99999990.00999') corp_internet_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '40', p.payment_amount, 0)), 'fm99999990.00999') call_center_amount,  \n");
					s2.append("		to_char(sum(decode(p.payment_channel, '21', p.payment_amount, 0)), 'fm99999990.00999') epos_amount,  \n");
					s2.append("		to_char(sum(decode(p.payment_channel, '32', p.payment_amount, 0)), 'fm99999990.00999') yim_amount,\n");
					s2.append("     to_char(sum(decode(p.payment_channel, '45', p.payment_amount, 0)), 'fm99999990.00999') standing_order_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '1', 1, 0))) branch_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '53', 1, 0))) internet_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '10', 1, 0))) corp_internet_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '40', 1, 0))) call_center_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '21', 1, 0))) epos_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '32', 1, 0))) yim_count,\n");
					s2.append("     to_char(sum(decode(p.payment_channel, '45', 1, 0))) standing_order_count,\n");
					s2.append("		to_char(decode(sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_commission,\n");
					s2.append("		to_char(decode(sum(p.payment_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(p.payment_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_amount,\n");
					s2.append("		to_char(sum(1)) total_count\n");
					s2.append(" FROM   ics.gsm_money_load p left join ics.invoice_commission comm on  p.oid = comm.invoice_payment_oid and comm.status = 1,\n");
					s2.append("	       cdm.corporate_master m, bnspr.muh_hesap hsp\n");
					s2.append("	WHERE  p.status = 1 and m.status = 1\n");
					s2.append("	   and p.corporate_code = m.corporate_code and p.corporate_account_no = hsp.hesap_no\n");
					s2.append("	   and m.sector_code = nvl(%s, m.sector_code)\n");
					s2.append("	   and p.corporate_code = nvl(%s, p.corporate_code)\n");
					s2.append("	   and (p.payer_customer = nvl(%s, p.payer_customer) or p.payer_customer is null)\n");
					s2.append("	   and (p.payment_branch = nvl(%s, p.payment_branch) or p.payment_branch is null)\n");
					s2.append("	   and p.payment_status = nvl(%s, p.payment_status)\n");
					s2.append("	   and (p.payment_source = nvl(%s, p.payment_source) or p.payment_source is null)\n");
					s2.append("	   and p.collection_type = nvl(%s, p.collection_type)\n");
					s2.append("	   and (p.payment_channel = nvl(%s, p.payment_channel) or p.payment_channel is null)\n");
					s2.append("	   and hsp.sube_kodu = nvl(%s, hsp.sube_kodu)\n");
					s2.append("	   and (p.subscriber_no = nvl(%s, p.subscriber_no) or p.subscriber_no is null)\n");
					s2.append("	   and p.payment_date >= \'%s\'\n");
					s2.append("	   and p.payment_date <= \'%s\'\n");
					
				
					if ((minAmount != null) && (maxAmount != null)) { 
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
					} 
					else if (minAmount != null)
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					else if (maxAmount != null)
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
					s2.append("	GROUP BY REPLACE(SHORT_CODE,'�','I'), m.sector_code, p.corporate_code, p.payment_status \n");
					
					s2.append(" UNION ");
					s2.append("SELECT (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name,\n");
					s2.append("     (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) corporate_name,\n");
					s2.append("		(select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) short_code,\n");
					s2.append("		(select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = p.payment_status) payment_status_name,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '1', p.loaded_amount, 0)), 'fm99999990.00999') branch_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '53', p.loaded_amount, 0)), 'fm99999990.00999') internet_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '10', p.loaded_amount, 0)), 'fm99999990.00999') corp_internet_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '40', p.loaded_amount, 0)), 'fm99999990.00999') call_center_amount,  \n");
					s2.append("		to_char(sum(decode(p.payment_channel, '21', p.loaded_amount, 0)), 'fm99999990.00999') epos_amount,  \n");
					s2.append("		to_char(sum(decode(p.payment_channel, '32', p.loaded_amount, 0)), 'fm99999990.00999') yim_amount,\n");
					s2.append("     to_char(sum(decode(p.payment_channel, '45', p.loaded_amount, 0)), 'fm99999990.00999') standing_order_amount,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '1', 1, 0))) branch_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '53', 1, 0))) internet_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '10', 1, 0))) corp_internet_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '40', 1, 0))) call_center_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '21', 1, 0))) epos_count,\n");
					s2.append("		to_char(sum(decode(p.payment_channel, '32', 1, 0))) yim_count,\n");
					s2.append("     to_char(sum(decode(p.payment_channel, '45', 1, 0))) standing_order_count,\n");
					s2.append("		to_char(decode(sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_commission,\n");
					s2.append("		to_char(decode(sum(p.loaded_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount), null, 0, sum(p.loaded_amount)+sum(comm.commission_amount)+sum(comm.bsmv_amount)),'fm99999990.00999') total_amount,\n");
					s2.append("		to_char(sum(1)) total_count\n");
					s2.append(" FROM   ics.eccps_credit_load p left join ics.invoice_commission comm on  p.oid = comm.invoice_payment_oid and comm.status = 1,\n");
					s2.append("	       cdm.corporate_master m, bnspr.muh_hesap hsp\n");
					s2.append("	WHERE  p.status = 1 and m.status = 1\n");
					s2.append("	   and p.corporate_code = m.corporate_code and p.corporate_account_no = hsp.hesap_no\n");
					s2.append("	   and m.sector_code = nvl(%s, m.sector_code)\n");
					s2.append("	   and p.corporate_code = nvl(%s, p.corporate_code)\n");
					s2.append("	   and (p.payer_customer = nvl(%s, p.payer_customer) or p.payer_customer is null)\n");
					s2.append("	   and (p.payment_branch = nvl(%s, p.payment_branch) or p.payment_branch is null)\n");
					s2.append("	   and p.payment_status = nvl(%s, p.payment_status)\n");
					s2.append("	   and (p.payment_source = nvl(%s, p.payment_source) or p.payment_source is null)\n");
					s2.append("	   and (p.payment_channel = nvl(%s, p.payment_channel) or p.payment_channel is null)\n");
					s2.append("	   and hsp.sube_kodu = nvl(%s, hsp.sube_kodu)\n");
					s2.append("	   and (p.subscriber_card_info = nvl(%s, p.subscriber_card_info) or p.subscriber_card_info is null)\n");
					s2.append("	   and p.payment_date >= \'%s\'\n");
					s2.append("	   and p.payment_date <= \'%s\'\n");
				
					if ((minAmount != null) && (maxAmount != null)) { 
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
					} 
					else if (minAmount != null)
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					else if (maxAmount != null)
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");	
					
					s2.append("	GROUP BY REPLACE(SHORT_CODE,'�','I'), m.sector_code, p.corporate_code, p.payment_status ) x \n");
					s2.append(" ORDER BY REPLACE(SHORT_CODE,'�','I'),sector_name, corporate_name, payment_status_name\n");
					
					if (minAmount != null && maxAmount != null) { 					
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount, maxAmount, 
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount, maxAmount);
					} else if (minAmount != null) {
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount, 
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount);
					} else if (maxAmount != null) {	
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, maxAmount, 
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, maxAmount);
					} else
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, 
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr);
					// end of TL yukleme kayitlari 
				}
				if (!StringUtil.isEmpty(invoiceNo))
					query = query1 + " ) x";
				else
					query = query1 + query2;	
			}

			if ("LIST".equals(input.getString("ACTION_TYPE"))) {
				output = DALUtil.getResults(query, outputTableName);	
			}else if ("REPORT".equals(input.getString("ACTION_TYPE"))) {
				
				for (int row=0; row < input.getSize(inputTableName); row++) {
					output.put(outputTableName, row, "SHORT_CODE", input.getString(inputTableName, row, "SHORT_CODE"));
					output.put(outputTableName, row, "BRANCH_AMOUNT", input.getString(inputTableName, row, "BRANCH_AMOUNT"));
					output.put(outputTableName, row, "BRANCH_COUNT", input.getString(inputTableName, row, "BRANCH_COUNT"));
					output.put(outputTableName, row, "CALL_CENTER_AMOUNT", input.getString(inputTableName, row, "CALL_CENTER_AMOUNT"));
					output.put(outputTableName, row, "CALL_CENTER_COUNT", input.getString(inputTableName, row, "CALL_CENTER_COUNT"));
					output.put(outputTableName, row, "CORPORATE_NAME", input.getString(inputTableName, row, "CORPORATE_NAME"));
					output.put(outputTableName, row, "EPOS_AMOUNT", input.getString(inputTableName, row, "EPOS_AMOUNT"));
					output.put(outputTableName, row, "EPOS_COUNT", input.getString(inputTableName, row, "EPOS_COUNT"));
					output.put(outputTableName, row, "INTERNET_AMOUNT", input.getString(inputTableName, row, "INTERNET_AMOUNT"));
					output.put(outputTableName, row, "INTERNET_COUNT", input.getString(inputTableName, row, "INTERNET_COUNT"));
					output.put(outputTableName, row, "CORP_INTERNET_AMOUNT", input.getString(inputTableName, row, "CORP_INTERNET_AMOUNT"));
					output.put(outputTableName, row, "CORP_INTERNET_COUNT", input.getString(inputTableName, row, "CORP_INTERNET_COUNT"));					
					output.put(outputTableName, row, "TOTAL_AMOUNT", input.getString(inputTableName, row, "TOTAL_AMOUNT"));
					output.put(outputTableName, row, "TOTAL_COMMISSION", input.getString(inputTableName, row, "TOTAL_COMMISSION"));
					output.put(outputTableName, row, "PAYMENT_STATUS_NAME", input.getString(inputTableName, row, "PAYMENT_STATUS_NAME"));
					output.put(outputTableName, row, "TOTAL_COUNT", input.getString(inputTableName, row, "TOTAL_COUNT"));
					output.put(outputTableName, row, "SECTOR_NAME", input.getString(inputTableName, row, "SECTOR_NAME"));
					output.put(outputTableName, row, "YIM_AMOUNT", input.getString(inputTableName, row, "YIM_AMOUNT"));
					output.put(outputTableName, row, "YIM_COUNT", input.getString(inputTableName, row, "YIM_COUNT"));
					output.put(outputTableName, row, "STANDING_ORDER_AMOUNT", input.getString(inputTableName, row, "STANDING_ORDER_AMOUNT"));
					output.put(outputTableName, row, "STANDING_ORDER_COUNT", input.getString(inputTableName, row, "STANDING_ORDER_COUNT"));
				}
				
				List<?> liste = (List<?>) input.get(inputTableName);
	            parameters.put("TABLE_DATA", liste);  
	            ArrayDeque<String> reports = new ArrayDeque<String>();
	            reports.add("PAYMENTS_SUMMARY_REPORT");
	            JasperPrint jasperPrint = new JasperPrint();            
	            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
	            jasperPrint.removePage(0); 
	            jasperPrint.removePage(jasperPrint.getPages().size()-1);
	                 
	            if (jasperPrint.getPages().size() == 0)
	            	CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOREPORTDATA));	            	           
	            
	            output.put("REPORT", jasperPrint);			
			}		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	

	@GraymoundService("CDM_GET_PAYMENTS_DETAIL_REPORT")
	public static GMMap cdmGetPaymentsDetailReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {
            HashMap<String, Object> parameters = new HashMap<String, Object>();
			String outputTableName = "LIST";
			String inputTableName = "CURRENT_LIST";
			GMMap totalCountAmountInputMap = new GMMap(), totalCountAmountOutputMap = new GMMap();
			
			String sectorCode = input.getString("SECTOR_CODE");
			String customerNo = input.getString("CUSTOMER_NO");
			String branchId = input.getString("BRANCH_ID");
			String corporateBranchId = input.getString("CORPORATE_BRANCH_ID");			
			String channelId = input.getString("CHANNEL_ID");
			String statusId = input.getString("STATUS_ID");			
			String corporateCode = input.getString("CORPORATE_CODE");
			String paymentSourceId = input.getString("PAYMENT_SOURCE_ID");
			String minAmount = input.getString("MIN_AMOUNT");
			String maxAmount = input.getString("MAX_AMOUNT");
			String subscriberNo1 = input.getString("SUBSCRIBER_NO_1");
			String subscriberNo2 = input.getString("SUBSCRIBER_NO_2");
			String subscriberNo3 = input.getString("SUBSCRIBER_NO_3");
			String subscriberNo4 = input.getString("SUBSCRIBER_NO_4");		
			String invoiceNo = input.getString("INVOICE_NO");
			Short paymentType = null;
			String paymentTypeStr = input.getString("PAYMENT_TYPE");
			if (paymentTypeStr != null)			
				paymentType = Short.parseShort(paymentTypeStr);					
			String query="";
			String query1="";
			String query2="";


			//227 nolu uat bug talebi dogrultusunda kaldirildi. 
//			if ("".equals(sectorCode) || "SECIMYOK".equals(sectorCode) || sectorCode == null) 
//				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Sekt�r"));
//			
			//225 nolu uat bug talebi dogrultusunda kaldirildi. 
//			if ("".equals(corporateCode) || corporateCode == null) 
//				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kurum"));
//			
			if (input.getDate("START_DATE") == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));
			
			if (input.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date startDate = CommonHelper.getDateTime(input.getString("START_DATE"), "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(input.getString("END_DATE"), "yyyyMMdd");	
			String startDateStr = input.getString("START_DATE").concat("000000");
			String endDateStr = input.getString("END_DATE").concat("235959");	
			long diffInDays = CommonHelper.subtractDatesToDays(endDate, startDate);
			
			if (diffInDays > 2)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MAXDATEINTERVALDAYSEXCEEDED, 2));

			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));	
			
			if ("".equals(customerNo)) customerNo = null;
			if ("".equals(minAmount)) minAmount = null;
			if ("".equals(maxAmount)) maxAmount = null;
			if ("".equals(subscriberNo1))
				subscriberNo1 = null;
			else if (subscriberNo1 != null)
				subscriberNo1 = String.format("\'%s\'", subscriberNo1);
			if ("".equals(subscriberNo2))
				subscriberNo2 = null;
			else if (subscriberNo2 != null)
				subscriberNo2 = String.format("\'%s\'", subscriberNo2);
			if ("".equals(subscriberNo3))
				subscriberNo3 = null;
			else if (subscriberNo3 != null)
				subscriberNo3 = String.format("\'%s\'", subscriberNo3);
			if ("".equals(subscriberNo4))
				subscriberNo4 = null;
			else if (subscriberNo4 != null)
				subscriberNo4 = String.format("\'%s\'", subscriberNo4);
			if ("".equals(corporateCode))
				corporateCode = null;
			else if (corporateCode != null)
				corporateCode = String.format("\'%s\'", corporateCode);		
			if ("".equals(statusId))
				statusId = null;
			else if (statusId != null)
				statusId = String.format("\'%s\'", statusId);	
			if ("".equals(sectorCode)||sectorCode.equalsIgnoreCase("SECIMYOK"))
				sectorCode = null;
			else if (sectorCode != null)
				sectorCode = String.format("\'%s\'", sectorCode);			
			if ("".equals(invoiceNo))
				invoiceNo = null;
			else if (invoiceNo != null)
				invoiceNo = String.format("\'%s\'", invoiceNo);	
			
			
			if (StringUtils.isNotEmpty(sectorCode) && sectorCode.equals(String.format("\'%s\'", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "GAME_OF_CHANCE_SECTOR_CODE")))) {
				StringBuilder s = new StringBuilder();
				s.append("SELECT * FROM (");
				s.append("SELECT to_char(rownum) row_number, x.*\n");
				s.append("FROM (\n"); 
				s.append("SELECT to_char(t.customer_no) customer_no,\n"); 
				s.append("		 to_char(t.member_id) subscriber_no1,\n");
				s.append("		 t.account_no payment_account_no, t.rec_owner, null invoice_no, t.channel_code payment_channel,\n");
				s.append("		 null invoice_amount,\n");
				s.append("       to_char(t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') payment_amount,\n"); 
				s.append("       to_char(decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') commission_amount,\n");			
				s.append("       null invoice_date,\n");
				s.append("       null invoice_due_date,\n");
				s.append("       to_char(trunc(to_date(t.transfer_date, 'YYYYMMDDHH24MISS')),'DD/MM/YYYY') payment_date, \n");
				s.append("       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = t.transfer_status) payment_status_name,\n");
				s.append("       (select  CASE WHEN t.channel_code = 21 THEN 'SUBE' ELSE c.aciklama   END aciklama from bnspr.gnl_kanal_grup_kod_pr c where c.kod = t.channel_code) channel_name,\n");
				s.append("       (select d.source_name from cdm.source_param d where d.source_code = t.source_code) source_name,\n");
				s.append("       (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = t.corporate_code) corporate_name,\n");
				s.append("       (select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = t.corporate_code) short_code,\n");
				s.append("       (select f.collection_name from cdm.collection_type_prm f where f.collection_type = t.collection_type) collection_name,\n");
				s.append("       (select g.unvan from bnspr.v_gnl_musteri_aktif g where g.musteri_no = t.customer_no) customer_name,\n");
				s.append("       (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name,\n");
				s.append("       (select t.account_branch_code||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = t.account_branch_code) payment_branch_name,\n");
				s.append("       (select hsp.sube_kodu||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = hsp.sube_kodu) corporate_branch_name,\n");
				s.append("       to_char(t.TX_NO) tx_no \n");
				s.append("FROM   ics.gcs_transfer t left join ics.gcs_commission comm on  t.oid = comm.gcs_transfer_oid and comm.status = 1,\n");			
				s.append("       cdm.corporate_master m, bnspr.muh_hesap hsp\n");
				s.append("WHERE  t.status = 1 and m.status = 1 \n");
				s.append("       and t.corporate_code = m.corporate_code and t.corporate_account_no = hsp.hesap_no\n");
				s.append("       and m.sector_code = nvl(%s, m.sector_code)\n");
				s.append("       and t.corporate_code = nvl(%s, t.corporate_code)\n");
				s.append("       and (t.customer_no = nvl(%s, t.customer_no) or t.customer_no is null)\n");
				s.append("       and (t.account_branch_code = nvl(%s, t.account_branch_code) or t.account_branch_code is null)\n");
				s.append("       and t.transfer_status = nvl(%s, t.transfer_status)\n");
				s.append("       and (t.source_code = nvl(%s, t.source_code) or t.source_code is null)\n");
				s.append("       and t.collection_type = nvl(%s, t.collection_type)\n");
				s.append("       and (t.channel_code = nvl(%s, t.channel_code) or t.channel_code is null)\n");
				s.append("       and hsp.sube_kodu = nvl(%s, hsp.sube_kodu)\n");
				s.append("       and (t.member_id = nvl(%s, t.member_id) or t.member_id is null)\n");
				s.append("       and t.transfer_date >= \'%s\'\n");
				s.append("       and t.transfer_date <= \'%s\'\n");
				
				if ((minAmount != null) && (maxAmount != null)) { 
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				} 
				else if (minAmount != null)
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
				else if (maxAmount != null)
					s.append("       and t.transfer_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				s.append(" ) x\n");
									
				
				if (minAmount != null && maxAmount != null) { 					
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1,
										  startDateStr, endDateStr, minAmount, maxAmount);
				} else if (minAmount != null) {
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1,
										  startDateStr, endDateStr, minAmount);
				} else if (maxAmount != null) {	
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1,
										  startDateStr, endDateStr, maxAmount);
				} else
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1,
										  startDateStr, endDateStr);
				
				query = query1 + " ) z";
			} else {
				StringBuilder s = new StringBuilder();
				s.append("SELECT * FROM (");
				s.append("SELECT to_char(rownum) row_number, x.*\n");
				s.append("FROM (\n"); 
				s.append("SELECT to_char(p.payer_customer) customer_no,\n"); 
				s.append("		 case when p.subscriber_no1 is not null and p.subscriber_no2 is null then p.subscriber_no1\n");
				s.append("		 when p.subscriber_no1 is not null and p.subscriber_no2 is not null then p.subscriber_no1||'-'||p.subscriber_no2\n");
				s.append("		 when p.subscriber_no2 is not null and p.subscriber_no1 is null then p.subscriber_no2 end subscriber_no1,\n");
				s.append("		 p.payment_account_no, p.rec_owner, p.invoice_no, p.payment_channel,\n");
				s.append("		 to_char(p.invoice_amount, 'fm99999990.00999') invoice_amount,\n");
				s.append("       to_char(p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') payment_amount,\n"); 
				s.append("       to_char(decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') commission_amount,\n");			
				s.append("       to_char(trunc(to_date(p.invoice_date, 'YYYYMMDDHH24MISS'))) invoice_date,\n");
				s.append("       to_char(trunc(to_date(p.invoice_due_date, 'YYYYMMDDHH24MISS'))) invoice_due_date,\n");
				s.append("       to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) payment_date, \n");
				s.append("       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = p.payment_status) payment_status_name,\n");
				s.append("       (select  CASE WHEN p.payment_channel = 21 THEN 'SUBE' ELSE c.aciklama   END aciklama from bnspr.gnl_kanal_grup_kod_pr c where c.kod = p.payment_channel) channel_name,\n");
				s.append("       (select d.source_name from cdm.source_param d where d.source_code = p.payment_source) source_name,\n");
				s.append("       (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) corporate_name,\n");
				s.append("       (select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) short_code,\n");
				s.append("       (select f.collection_name from cdm.collection_type_prm f where f.collection_type = p.collection_type) collection_name,\n");
				s.append("       (select g.unvan from bnspr.v_gnl_musteri_aktif g where g.musteri_no = p.payer_customer) customer_name,\n");
				s.append("       (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name,\n");
				s.append("       (select p.payment_branch||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = p.payment_branch) payment_branch_name,\n");
				s.append("       (select hsp.sube_kodu||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = hsp.sube_kodu) corporate_branch_name,\n");
				s.append("       to_char(p.TX_NO) tx_no \n");
				s.append("FROM   ics.invoice_payment p left join ics.invoice_commission comm on  p.oid = comm.invoice_payment_oid and comm.status = 1,\n");			
				s.append("       cdm.corporate_master m, bnspr.muh_hesap hsp\n");
				s.append("WHERE  p.status = 1 and m.status = 1 \n");
				s.append("       and p.corporate_code = m.corporate_code and p.corporate_account_no = hsp.hesap_no\n");
				s.append("       and m.sector_code = nvl(%s, m.sector_code)\n");
				s.append("       and p.corporate_code = nvl(%s, p.corporate_code)\n");
				s.append("       and (p.payer_customer = nvl(%s, p.payer_customer) or p.payer_customer is null)\n");
				s.append("       and (p.payment_branch = nvl(%s, p.payment_branch) or p.payment_branch is null)\n");
				s.append("       and p.payment_status = nvl(%s, p.payment_status)\n");
				s.append("       and (p.payment_source = nvl(%s, p.payment_source) or p.payment_source is null)\n");
				s.append("       and p.collection_type = nvl(%s, p.collection_type)\n");
				s.append("       and (p.payment_channel = nvl(%s, p.payment_channel) or p.payment_channel is null)\n");
				s.append("       and hsp.sube_kodu = nvl(%s, hsp.sube_kodu)\n");
				s.append("       and (p.subscriber_no1 = nvl(%s, p.subscriber_no1) or p.subscriber_no1 is null)\n");
				s.append("       and (p.subscriber_no2 = nvl(%s, p.subscriber_no2) or p.subscriber_no2 is null)\n");
				s.append("       and (p.subscriber_no3 = nvl(%s, p.subscriber_no3) or p.subscriber_no3 is null)\n");
				s.append("       and (p.subscriber_no4 = nvl(%s, p.subscriber_no4) or p.subscriber_no4 is null)\n");
				s.append("       and (p.invoice_no = nvl(%s, p.invoice_no) or p.invoice_no is null)\n");
				s.append("       and p.payment_date >= \'%s\'\n");
				s.append("       and p.payment_date <= \'%s\'\n");
				
				if ((minAmount != null) && (maxAmount != null)) { 
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				} 
				else if (minAmount != null)
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
				else if (maxAmount != null)
					s.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
				s.append(" ) x\n");
									
				
				if (minAmount != null && maxAmount != null) { 					
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, 
										  invoiceNo, startDateStr, endDateStr, minAmount, maxAmount);
				} else if (minAmount != null) {
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, 
										  invoiceNo, startDateStr, endDateStr, minAmount);
				} else if (maxAmount != null) {	
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, 
										  invoiceNo, startDateStr, endDateStr, maxAmount);
				} else
					query1 = String.format(s.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4,
										  invoiceNo, startDateStr, endDateStr);
				if (StringUtil.isEmpty(invoiceNo)) {
					// TL yuklemeden gelen kayitlar icin bu SQL yazildi
					StringBuilder s2 = new StringBuilder();
					s2.append(" UNION ");
					s2.append("SELECT to_char(rownum) row_number, y.* \n");
					s2.append("      FROM (  \n");
					s2.append("      SELECT to_char(p.payer_customer) customer_no, p.subscriber_no subscriber_no1, p.payment_account_no, p.rec_owner, p.subscriber_no invoice_no, p.payment_channel,\n"); 
					s2.append("           to_char(p.payment_amount, 'fm99999990.00999') invoice_amount, \n");
					s2.append("             to_char(p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') payment_amount, \n"); 
					s2.append("             to_char(decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') commission_amount,       \n");
					s2.append("             to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) invoice_date, \n");
					s2.append("             to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) invoice_due_date, \n");
					s2.append("             to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) payment_date,  \n");
					s2.append("             (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = p.payment_status) payment_status_name, \n");
					s2.append("             (select  CASE WHEN p.payment_channel = 21 THEN 'SUBE' ELSE c.aciklama   END aciklama from bnspr.gnl_kanal_grup_kod_pr c where c.kod = p.payment_channel) channel_name, \n");
					s2.append("             (select d.source_name from cdm.source_param d where d.source_code = p.payment_source) source_name, \n");
					s2.append("             (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) corporate_name, \n");
					s2.append("             (select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) short_code, \n");
					s2.append("             (select f.collection_name from cdm.collection_type_prm f where f.collection_type = p.collection_type) collection_name, \n");
					s2.append("             (select g.unvan from bnspr.v_gnl_musteri_aktif g where g.musteri_no = p.payer_customer) customer_name, \n");
					s2.append("             (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name, \n");
					s2.append("             (select p.payment_branch||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = p.payment_branch) payment_branch_name, \n");
					s2.append("             (select hsp.sube_kodu||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = hsp.sube_kodu) corporate_branch_name, \n");
					s2.append("             to_char(p.TX_NO) tx_no  \n");
					s2.append("      FROM   ics.gsm_money_load p left join ics.invoice_commission comm on  p.oid = comm.invoice_payment_oid and comm.status = 1, \n");      
					s2.append("             cdm.corporate_master m, bnspr.muh_hesap hsp \n");
					s2.append("      WHERE  p.status = 1 and m.status = 1  \n");
					s2.append("             and p.corporate_code = m.corporate_code and p.corporate_account_no = hsp.hesap_no \n");
					s2.append("             and m.sector_code = nvl(%s, m.sector_code) \n");
					s2.append("             and p.corporate_code = nvl(%s, p.corporate_code) \n");
					s2.append("             and (p.payer_customer = nvl(%s, p.payer_customer) or p.payer_customer is null) \n");
					s2.append("             and (p.payment_branch = nvl(%s, p.payment_branch) or p.payment_branch is null) \n");
					s2.append("             and p.payment_status = nvl(%s, p.payment_status) \n");
					s2.append("             and (p.payment_source = nvl(%s, p.payment_source) or p.payment_source is null) \n");
					s2.append("             and p.collection_type = nvl(%s, p.collection_type) \n");
					s2.append("             and (p.payment_channel = nvl(%s, p.payment_channel) or p.payment_channel is null) \n");
					s2.append("             and hsp.sube_kodu = nvl(%s, hsp.sube_kodu) \n");
					s2.append("             and (p.subscriber_no = nvl(%s, p.subscriber_no) or p.subscriber_no is null) \n");
					s2.append("             and p.payment_date >= \'%s\' \n");
					s2.append("             and p.payment_date <= \'%s\' \n");
					
					if ((minAmount != null) && (maxAmount != null)) { 
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
					} 
					else if (minAmount != null)
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					else if (maxAmount != null)
						s2.append("       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");			
					s2.append(" ) y ");
					
					s2.append(" UNION ");
					s2.append("SELECT to_char(rownum) row_number, t.* \n");
					s2.append("      FROM (  \n");
					s2.append("      SELECT to_char(p.payer_customer) customer_no, p.subscriber_card_info subscriber_no1, p.payment_account_no, p.rec_owner, p.subscriber_card_info invoice_no, p.payment_channel,\n"); 
					s2.append("           to_char(p.loaded_amount, 'fm99999990.00999') invoice_amount, \n");
					s2.append("             to_char(p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') payment_amount, \n"); 
					s2.append("             to_char(decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount), 'fm99999990.00999') commission_amount,       \n");
					s2.append("             to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) invoice_date, \n");
					s2.append("             to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) invoice_due_date, \n");
					s2.append("             to_char(trunc(to_date(p.payment_date, 'YYYYMMDDHH24MISS'))) payment_date,  \n");
					s2.append("             (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_PAYMENT_STATUS' and a.KEY1 = p.payment_status) payment_status_name, \n");
					s2.append("             (select  CASE WHEN p.payment_channel = 21 THEN 'SUBE' ELSE c.aciklama   END aciklama from bnspr.gnl_kanal_grup_kod_pr c where c.kod = p.payment_channel) channel_name, \n");
					s2.append("             (select d.source_name from cdm.source_param d where d.source_code = p.payment_source) source_name, \n");
					s2.append("             (select e.corporate_name from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) corporate_name, \n");
					s2.append("             (select e.short_code from cdm.corporate_master e where e.status = 1 and e.corporate_code = p.corporate_code) short_code, \n");
					s2.append("             (select f.collection_name from cdm.collection_type_prm f where f.collection_type = 25) collection_name, \n");
					s2.append("             (select g.unvan from bnspr.v_gnl_musteri_aktif g where g.musteri_no = p.payer_customer) customer_name, \n");
					s2.append("             (select h.sector_name from cdm.sector_def h  where h.status = 1 and h.sector_code = m.sector_code and rownum=1) sector_name, \n");
					s2.append("             (select p.payment_branch||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = p.payment_branch) payment_branch_name, \n");
					s2.append("             (select hsp.sube_kodu||'-'||b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = hsp.sube_kodu) corporate_branch_name, \n");
					s2.append("             to_char(p.TX_NO) tx_no  \n");
					s2.append("      FROM   ics.eccps_credit_load p left join ics.invoice_commission comm on  p.oid = comm.invoice_payment_oid and comm.status = 1, \n");      
					s2.append("             cdm.corporate_master m, bnspr.muh_hesap hsp \n");
					s2.append("      WHERE  p.status = 1 and m.status = 1  \n");
					s2.append("             and p.corporate_code = m.corporate_code and p.corporate_account_no = hsp.hesap_no \n");
					s2.append("             and m.sector_code = nvl(%s, m.sector_code) \n");
					s2.append("             and p.corporate_code = nvl(%s, p.corporate_code) \n");
					s2.append("             and (p.payer_customer = nvl(%s, p.payer_customer) or p.payer_customer is null) \n");
					s2.append("             and (p.payment_branch = nvl(%s, p.payment_branch) or p.payment_branch is null) \n");
					s2.append("             and p.payment_status = nvl(%s, p.payment_status) \n");
					s2.append("             and (p.payment_source = nvl(%s, p.payment_source) or p.payment_source is null) \n");
					s2.append("             and (p.payment_channel = nvl(%s, p.payment_channel) or p.payment_channel is null) \n");
					s2.append("             and hsp.sube_kodu = nvl(%s, hsp.sube_kodu) \n");
					s2.append("             and (p.subscriber_card_info = nvl(%s, p.subscriber_card_info) or p.subscriber_card_info is null) \n");
					s2.append("             and p.payment_date >= \'%s\' \n");
					s2.append("             and p.payment_date <= \'%s\' \n");
					
					if ((minAmount != null) && (maxAmount != null)) { 
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");
					} 
					else if (minAmount != null)
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n");
					else if (maxAmount != null)
						s2.append("       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n");		
					
					s2.append(" ) t ");
					s2.append(" ) z ");
					s2.append(" ORDER BY REPLACE(SHORT_CODE,'�','I'),payment_date desc, corporate_name, payment_status_name desc, collection_name, customer_name \n");
					
					if (minAmount != null && maxAmount != null) { 					
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount, maxAmount,
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount, maxAmount);
					} else if (minAmount != null) {
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount,
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, minAmount);
					} else if (maxAmount != null) {	
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, maxAmount,
								sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, maxAmount);
					} else
						query2 = String.format(s2.toString(), sectorCode, corporateCode, customerNo, branchId, statusId, paymentSourceId, paymentType, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr, sectorCode, corporateCode,
								customerNo, branchId, statusId, paymentSourceId, channelId, corporateBranchId, subscriberNo1, startDateStr, endDateStr);
					// end Of TL yukleme
				}
				
				if (!StringUtil.isEmpty(invoiceNo))
					query = query1 + " ) z";
				else
					query = query1 + query2;
			}
		
			if ("LIST".equals(input.getString("ACTION_TYPE"))) {
				output = DALUtil.getResults(query, outputTableName);	
			}
			else if ("REPORT".equals(input.getString("ACTION_TYPE"))) {
				
				for (int row=0; row < input.getSize(inputTableName); row++) {
					output.put(outputTableName, row, "PAYMENT_CHANNEL", input.getString(inputTableName, row, "PAYMENT_CHANNEL"));					
					output.put(outputTableName, row, "CHANNEL_NAME", input.getString(inputTableName, row, "CHANNEL_NAME"));
					output.put(outputTableName, row, "COLLECTION_NAME", input.getString(inputTableName, row, "COLLECTION_NAME"));
//					output.put(outputTableName, row, "CORPORATE_NAME", input.getString(inputTableName, row, "CORPORATE_NAME"));
					output.put(outputTableName, row, "SHORT_CODE", input.getString(inputTableName, row, "SHORT_CODE"));
					output.put(outputTableName, row, "CUSTOMER_NO", input.getString(inputTableName, row, "CUSTOMER_NO"));
					output.put(outputTableName, row, "INVOICE_AMOUNT", input.getString(inputTableName, row, "INVOICE_AMOUNT"));
					output.put(outputTableName, row, "INVOICE_DUE_DATE", input.getString(inputTableName, row, "INVOICE_DUE_DATE"));
					output.put(outputTableName, row, "INVOICE_NO", input.getString(inputTableName, row, "INVOICE_NO"));
					output.put(outputTableName, row, "PAYMENT_AMOUNT", input.getString(inputTableName, row, "PAYMENT_AMOUNT"));
					output.put(outputTableName, row, "COMMISSION_AMOUNT", input.getString(inputTableName, row, "COMMISSION_AMOUNT"));					
					output.put(outputTableName, row, "PAYMENT_BRANCH_NAME", input.getString(inputTableName, row, "PAYMENT_BRANCH_NAME"));
					output.put(outputTableName, row, "PAYMENT_DATE", input.getString(inputTableName, row, "PAYMENT_DATE"));
					output.put(outputTableName, row, "PAYMENT_STATUS_NAME", input.getString(inputTableName, row, "PAYMENT_STATUS_NAME"));
					output.put(outputTableName, row, "REC_OWNER", input.getString(inputTableName, row, "REC_OWNER"));
					output.put(outputTableName, row, "SOURCE_NAME", input.getString(inputTableName, row, "SOURCE_NAME"));
					output.put(outputTableName, row, "SUBSCRIBER_NO1", input.getString(inputTableName, row, "SUBSCRIBER_NO1"));
					output.put(outputTableName, row, "ROW_NUMBER", input.getString(inputTableName, row, "ROW_NUMBER"));
					output.put(outputTableName, row, "TX_NO", input.getString(inputTableName, row, "TX_NO"));
				}
				
				totalCountAmountInputMap.put("SECTOR_CODE", input.getString("SECTOR_CODE"));
				totalCountAmountInputMap.put("CUSTOMER_NO", customerNo);
				totalCountAmountInputMap.put("BRANCH_ID", branchId);
				totalCountAmountInputMap.put("CORPORATE_BRANCH_ID", corporateBranchId);
				totalCountAmountInputMap.put("CHANNEL_ID", channelId);
				totalCountAmountInputMap.put("STATUS_ID", input.getString("STATUS_ID"));
				totalCountAmountInputMap.put("CORPORATE_CODE", input.getString("CORPORATE_CODE"));
				totalCountAmountInputMap.put("PAYMENT_SOURCE_ID", paymentSourceId);
				totalCountAmountInputMap.put("MIN_AMOUNT", minAmount);
				totalCountAmountInputMap.put("MAX_AMOUNT", maxAmount);
				totalCountAmountInputMap.put("SUBSCRIBER_NO_1", input.getString("SUBSCRIBER_NO_1"));
				totalCountAmountInputMap.put("SUBSCRIBER_NO_2", input.getString("SUBSCRIBER_NO_2"));
				totalCountAmountInputMap.put("SUBSCRIBER_NO_3", input.getString("SUBSCRIBER_NO_3"));
				totalCountAmountInputMap.put("SUBSCRIBER_NO_4", input.getString("SUBSCRIBER_NO_4"));
				totalCountAmountInputMap.put("INVOICE_NO", input.getString("INVOICE_NO"));	
				totalCountAmountInputMap.put("PAYMENT_TYPE", paymentType);
				totalCountAmountInputMap.put("START_DATE", startDate);
				totalCountAmountInputMap.put("END_DATE", endDate);
				totalCountAmountInputMap.put("ACTION_TYPE", "LIST");
				
				totalCountAmountOutputMap = CommonHelper.callGraymoundServiceOutsideSession("CDM_GET_PAYMENTS_SUMMARY_REPORT", totalCountAmountInputMap);

				BigDecimal totalAmount = BigDecimal.ZERO;
				BigDecimal totalCount = BigDecimal.ZERO;
				BigDecimal totalCommission = BigDecimal.ZERO;

				for (int i = 0; i < totalCountAmountOutputMap.getSize("LIST"); i++) {
					totalAmount = totalAmount.add(totalCountAmountOutputMap.getBigDecimal("LIST", i, "TOTAL_AMOUNT"));
					totalCount = totalCount.add(totalCountAmountOutputMap.getBigDecimal("LIST", i, "TOTAL_COUNT"));
					totalCommission = totalCommission.add(totalCountAmountOutputMap.getBigDecimal("LIST", i, "TOTAL_COMMISSION"));
				}
				parameters.put("TOTAL_AMOUNT", totalAmount.toString());
				parameters.put("TOTAL_COUNT", totalCount.toString());
				parameters.put("TOTAL_COMMISSION", totalCommission.toString());

				List<?> liste = (List<?>) input.get(inputTableName);
	            parameters.put("TABLE_DATA", liste);  
	            ArrayDeque<String> reports = new ArrayDeque<String>();
	            reports.add("PAYMENTS_DETAIL_REPORT");
	            JasperPrint jasperPrint = new JasperPrint();            
	            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
	            jasperPrint.removePage(0);          
	            jasperPrint.removePage(jasperPrint.getPages().size()-1);
	            
	            if (jasperPrint.getPages().size() == 0)
	            	CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOREPORTDATA));	 	            
	            
	            output.put("REPORT", jasperPrint);				
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_CORP_PROTOCOL_REPORT")
	public static GMMap cdmGetCorpProtocolReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {
            HashMap<String, Object> parameters = new HashMap<String, Object>();
			Session hibernateSession = CommonHelper.getHibernateSession();
			String sectorName=null, corporateName=null, shortCode=null, protocolStartDate=null, protocolEndDate=null, func = null,	
				   accountConcentrationType = null, allowAfterDueDate = null, allowPartPayment = null, commissionDate = null,
				   corporateType = null;
			String detailsTableName = "DETAILS";	
			
			BigDecimal customerNumber = null;
			StringBuilder s = null;
			DateFormat shortDateTimeFormat = new SimpleDateFormat("dd.MM.yyyy");
			Object[] inputValues = null;
			GMMap corpDetails = new GMMap();
			GMMap accMasterDetails = new GMMap();
			GMMap temerkuzCollectionTypes = new GMMap();
			GMMap channelSourceDefs = new GMMap();
			GMMap corpAccounts = new GMMap();
			GMMap corpAccountDetails = new GMMap();
			GMMap corpSubscMaskDetails = new GMMap();
						
			String corporateCode = input.getString("CORPORATE_CODE");		
			String corporateOid = input.getString("CORPORATE_OID");
			String reportDate = input.getString("DATE");			
			
			if ("".equals(corporateCode) || corporateCode == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kurum"));	
			
			if (input.getString("RADIO_BUTTON_SELECTION").equals("HISTORY") && ("".equals(reportDate) || reportDate == null))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Tarih"));	
				
			inputValues	= new Object[4];
			func = "{? = call CDM.PKG_CDM_REPORTS.GET_CORPORATE_DETAILS(?,?)}";
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = corporateOid;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = reportDate;
			corpDetails = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);
			
			if (corpDetails.getSize(detailsTableName) == 1) {
				corporateName = corpDetails.getString(detailsTableName, 0, "CORPORATE_NAME"); 
				shortCode = corpDetails.getString(detailsTableName, 0, "SHORT_CODE");
				customerNumber = corpDetails.getBigDecimal(detailsTableName, 0, "CUSTOMER_NUMBER");						
				protocolStartDate = shortDateTimeFormat.format(CommonHelper.getDateTime(corpDetails.getString(detailsTableName, 0, "PROTOCOL_START_DATE"), "yyyyMMdd"));
				protocolEndDate = shortDateTimeFormat.format(CommonHelper.getDateTime(corpDetails.getString(detailsTableName, 0, "PROTOCOL_END_DATE"), "yyyyMMdd"));
				allowPartPayment = corpDetails.getBoolean(detailsTableName, 0, "ALLOW_PART_PAYMENT") ? "Evet" : "Hay�r";
				allowAfterDueDate = corpDetails.getBoolean(detailsTableName, 0, "ALLOW_AFTER_DUE_DATE") ? "Evet" : "Hay�r";
				corporateType = corpDetails.getString(detailsTableName, 0, "IS_ONLINE_CORPORATE").equals("1") ? "Online" : "Offline";
				
				SectorDef sector = (SectorDef)hibernateSession.createCriteria(SectorDef.class)
						.add(Restrictions.eq("sectorCode", corpDetails.getString(detailsTableName, 0, "SECTOR_CODE")))
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("sectorActiveness", DatabaseConstants.SectorActiveness.Active))
						.uniqueResult();
				if (sector != null) 
					sectorName = sector.getSectorName();				
			}
			
			parameters.put("CORPORATE_NAME", corporateName);
			parameters.put("CUSTOMER_NUMBER", customerNumber);
			parameters.put("SHORT_CODE", shortCode);
			parameters.put("SECTOR_NAME", sectorName);
			parameters.put("PROTOCOL_START_DATE", protocolStartDate);
			parameters.put("PROTOCOL_END_DATE", protocolEndDate);
			parameters.put("ALLOW_AFTER_DUE_DATE", allowAfterDueDate);
			parameters.put("ALLOW_PART_PAYMENT", allowPartPayment);
			parameters.put("CORPORATE_TYPE", corporateType);			

			if (!"".equals(reportDate) && reportDate != null)
				commissionDate = reportDate + "235959";
			else
				commissionDate = CommonHelper.getShortDateTimeString(new Date()) + "235959";
			List<CommissionDef> commissions = hibernateSession.createCriteria(CommissionDef.class)
											.add(Restrictions.eq("corporateCode", corporateCode))
											.add(Restrictions.eq("status", true))
											.add(Restrictions.lt("createDate", commissionDate))
											.list();
			if (commissions.size() > 0) {
				parameters.put("COMMISSION_INFO1", "Al�n�r");		
				parameters.put("COMMISSION_INFO2", "Evet");	
			}
			
			func = "{? = call CDM.PKG_CDM_REPORTS.GET_CORP_ACC_MASTER_DETAILS(?,?)}";
			accMasterDetails = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);
			
			if (accMasterDetails.getSize(detailsTableName) == 1) {
				accountConcentrationType = accMasterDetails.getString(detailsTableName, 0, "CONCENTRATION_TYPE"); 
				if (accountConcentrationType.equals(DatabaseConstants.ConcentrationTypes.SingleConcentration))
					parameters.put("ACCOUNT_CONCENTRATION_TYPE", "Tekli");
				else if (accountConcentrationType.equals(DatabaseConstants.ConcentrationTypes.MultiConcentration))
					parameters.put("ACCOUNT_CONCENTRATION_TYPE", "�oklu");
			}
			
			func = "{? = call CDM.PKG_CDM_REPORTS.GET_COLLECTION_TYPES(?,?)}";
			temerkuzCollectionTypes = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);
			
			s = new StringBuilder();
			for (int t=0; t < temerkuzCollectionTypes.getSize(detailsTableName); t++) {
				s.append(temerkuzCollectionTypes.getString(detailsTableName, t, "COLLECTION_NAME"));
				if (t < temerkuzCollectionTypes.getSize(detailsTableName)-1)
					s.append(", ");
			}
			parameters.put("COLLECTION_TYPES", s.toString());

			func = "{? = call CDM.PKG_CDM_REPORTS.GET_CHANNEL_SOURCE_DEFS(?,?)}";
			channelSourceDefs = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);
	        List<?> list = (List<?>) channelSourceDefs.get(detailsTableName);
	        parameters.put("CHANNEL_SOURCE_DEFS", list);  
	        
			func = "{? = call CDM.PKG_CDM_REPORTS.GET_CORP_ACCOUNTS(?,?)}";
			corpAccounts = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);
	        for (int t=0; t < corpAccounts.getSize(detailsTableName); t++) {	        	
	        	if (corpAccounts.getString(detailsTableName, t, "CHANNEL_SOURCE_NAME") != null) {
					List<String> channelSourcePair = Arrays.asList(corpAccounts.getString(detailsTableName, t, "CHANNEL_SOURCE_NAME").split(","));
					s = new StringBuilder();
					for (int k = 0; k < channelSourcePair.size(); k++) {
						s.append(channelSourcePair.get(k));
						if (k < channelSourcePair.size()-1)
							s.append("\n");					
					}
					corpAccounts.put(detailsTableName, t, "CHANNEL_SOURCE_NAME", s.toString());
	        	}
	        }				
	        list = (List<?>) corpAccounts.get(detailsTableName);        
	        parameters.put("CORP_ACCOUNTS", list);  
						
			func = "{? = call CDM.PKG_CDM_REPORTS.GET_CORP_ACCOUNT_DETAILS(?,?)}";
			corpAccountDetails = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);
			
			for (int t=0; t < corpAccountDetails.getSize(detailsTableName); t++) {
				s = new StringBuilder();
				s.append(corpAccountDetails.getString(detailsTableName, t, "MONTH_TRANSFER_RULE"));
				s.append(corpAccountDetails.getString(detailsTableName, t, "DAY_TRANSFER_RULE"));
				s.append(corpAccountDetails.getString(detailsTableName, t, "HOLIDAY_TRANSFER_RULE"));
				corpAccountDetails.put(detailsTableName, t, "TRANSFER_RULES", s.toString());
				
	        	if (corpAccountDetails.getString(detailsTableName, t, "COLLECTION_SOURCE_CHANNEL") != null) {
					List<String> collSourceChannel = Arrays.asList(corpAccountDetails.getString(detailsTableName, t, "COLLECTION_SOURCE_CHANNEL").split(","));
					StringBuilder csc = new StringBuilder();
					for (int k = 0; k < collSourceChannel.size(); k++) {
						csc.append(collSourceChannel.get(k));
						if (k < collSourceChannel.size()-1)
							csc.append("\n");					
					}
					corpAccountDetails.put(detailsTableName, t, "COLLECTION_SOURCE_CHANNEL", csc.toString());
	        	}
			}			
	        list = (List<?>) corpAccountDetails.get(detailsTableName);
	        parameters.put("CORP_ACCOUNT_DETAILS", list);	        	       
	        
			func = "{? = call CDM.PKG_CDM_REPORTS.GET_CORP_SUBSC_MASK_DETAILS(?,?)}";
			corpSubscMaskDetails = DALUtil.callOracleRefCursorFunction(func, detailsTableName, inputValues);		
	        list = (List<?>) corpSubscMaskDetails.get(detailsTableName);
	        parameters.put("SUBSC_MASK_DETAILS", list);	        	     
	        
			ArrayDeque<String> reports = new ArrayDeque<String>();
            reports.add("CORP_PROTOCOL_REPORT");
            JasperPrint jasperPrint = new JasperPrint();            
            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
            
            output.put("REPORT", jasperPrint);			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	@GraymoundService("CDM_GET_DAILY_TRANSFERS_REPORT")
	public static GMMap cdmGetDailyTransfersReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {	
        	HashMap<String, Object> parameters = new HashMap<String, Object>();			
		
			String tableName = "LIST";
			String sectorCode = input.getString("SECTOR_CODE");	
			String corporateCode = input.getString("CORPORATE_CODE");	
			String transferStatus = input.getString("TRANSFER_STATUS");
			BigDecimal minAmount = new BigDecimal(input.getString("MIN_AMOUNT").isEmpty()?"0":input.getString("MIN_AMOUNT"));
			BigDecimal maxAmount = new BigDecimal(input.getString("MAX_AMOUNT").isEmpty()?"0":input.getString("MAX_AMOUNT"));

			GMMap getDailyTransfers = new GMMap();			
			
			if ("".equals(sectorCode) || "SECIMYOK".equals(sectorCode) || sectorCode == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Sekt�r"));
			
			if ("".equals(corporateCode) || corporateCode == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kurum"));
			
			if (input.getDate("START_DATE") == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));
			
			if (input.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			String startDateStr = input.getString("START_DATE");
			String endDateStr = input.getString("END_DATE");				
			Date startDate = CommonHelper.getDateTime(startDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			
			long diffInDays = CommonHelper.subtractDatesToDays(endDate, startDate);
			
			if (diffInDays > 31)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MAXDATEINTERVALEXCEEDED, 1));

			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));					

			
			Object[] inputValues = new Object[14];
			String func = "{? = call CDM.PKG_CDM_REPORTS.GET_BALANCE_TRANSFERS_DAILY(?,?,?,?,?,?,?)}";
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = null; //sectorCode
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = corporateCode;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = transferStatus;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = startDateStr;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = endDateStr;	
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = minAmount;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = maxAmount;	
			getDailyTransfers = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			getDailyTransfers = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			   
            List<?> list = (List<?>) getDailyTransfers.get(tableName);            
            parameters.put("TABLE_DATA", list);  
            ArrayDeque<String> reports = new ArrayDeque<String>();
            reports.add("DAILY_TRANSFERS_REPORT");
            JasperPrint jasperPrint = new JasperPrint();            
            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
            jasperPrint.removePage(0);       
            jasperPrint.removePage(jasperPrint.getPages().size()-1);
            
            if (jasperPrint.getPages().size() == 0)
            	CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOREPORTDATA));	             
            
            output.put("REPORT", jasperPrint);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	@GraymoundService("CDM_GET_SUMMARY_TRANSFERS_REPORT")
	public static GMMap cdmGetSummaryTransfersReport(GMMap input) {
		
		GMMap output = new GMMap();
		try {
            HashMap<String, Object> parameters = new HashMap<String, Object>();
			
			String tableName = "LIST";					
			String sectorCode = input.getString("SECTOR_CODE");	
			String corporateCode = input.getString("CORPORATE_CODE");	
			String transferStatus = Byte.toString(DatabaseConstants.BalanceTransferProcessStatuses.Successful);
			GMMap getTransfersSummary = new GMMap();
			
			if ("".equals(sectorCode) || "SECIMYOK".equals(sectorCode) || sectorCode == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Sekt�r"));
			
			if (input.getDate("START_DATE") == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));
			
			if (input.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			String startDateStr = input.getString("START_DATE");
			String endDateStr = input.getString("END_DATE");				
			Date startDate = CommonHelper.getDateTime(startDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			
			long diffInDays = CommonHelper.subtractDatesToDays(endDate, startDate);
			
			if (diffInDays > 31)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MAXDATEINTERVALEXCEEDED, 1));

			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));					

			
			Object[] inputValues = new Object[10];
			String func = "{? = call CDM.PKG_CDM_REPORTS.GET_BALANCE_TRANSFERS_SUMMARY(?,?,?,?,?)}";
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = sectorCode;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = corporateCode;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = transferStatus;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = startDateStr;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = endDateStr;				
			getTransfersSummary = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
		   
            List<?> list = (List<?>) getTransfersSummary.get(tableName);            
            parameters.put("TABLE_DATA", list);  
            ArrayDeque<String> reports = new ArrayDeque<String>();
            reports.add("TRANSFERS_SUMMARY_REPORT");
            JasperPrint jasperPrint = new JasperPrint();            
            jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
            jasperPrint.removePage(0);         
            jasperPrint.removePage(jasperPrint.getPages().size()-1);
            
            if (jasperPrint.getPages().size() == 0)
            	CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOREPORTDATA));	             
            
            output.put("REPORT", jasperPrint);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	@GraymoundService("CDM_GET_FILE_TRANSFER_DETAILS")
	public static GMMap cdmGetFileTransferDetails(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = "LIST";	        
			
			String sectorCode = input.getString("SECTOR_CODE");
			String corporateCode = input.getString("CORPORATE_CODE");			
			String transferStatus = input.getString("TRANSFER_STATUS");
			String transferType = input.getString("TRANSFER_TYPE");
			String ftpFolder = input.getString("FTP_FOLDER");			
			String query;
			
			if ("".equals(sectorCode) || "SECIMYOK".equals(sectorCode) || sectorCode == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Sekt�r"));
			
			if ("".equals(corporateCode) || corporateCode == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kurum"));
			
			if (input.getDate("START_DATE") == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));
			
			if (input.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			String startDateStr = input.getString("START_DATE");
			String endDateStr = input.getString("END_DATE");				
			Date startDate = CommonHelper.getDateTime(startDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			long diffInDays = CommonHelper.subtractDatesToDays(endDate, startDate);
			
			if (diffInDays > 31)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MAXDATEINTERVALEXCEEDED, 1));

			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));	
			
			if ("".equals(corporateCode))
				corporateCode = null;
			else if (corporateCode != null)
				corporateCode = String.format("\'%s\'", corporateCode);		
			if ("".equals(sectorCode))
				sectorCode = null;
			else if (sectorCode != null)
				sectorCode = String.format("\'%s\'", sectorCode);
			if ("".equals(transferStatus))
				transferStatus = null;
			
			query = String.format(QueryRepository.CPSReportsRepository.FILE_TRANSFER_DETAILS_QUERY, corporateCode, sectorCode, transferType, transferStatus, ftpFolder, startDateStr, endDateStr);

			output = DALUtil.getResults(query, tableName);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@GraymoundService("CDM_BALANCE_TRANSFER_PROCESS_STATUS_COMBO")
	public static GMMap cdmBalanceTransferProcessStatusCombo(GMMap input) {
		
		return CorporationServiceUtil.getComboValues(input);
	}
	
	@GraymoundService("CDM_PAYMENT_STATUS_COMBO")
	public static GMMap cdmPaymentStatusCombo(GMMap input) {
		
		if (input.containsKey("EMPTY_KEY") && input.getBoolean("EMPTY_KEY"))
			input.put("ADD_EMPTY_KEY", "HEPSI");
		return CorporationServiceUtil.getComboValues(input);
	}	
	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_GET_PAYMENT_MONITORING_REPORT")
	public static GMMap getPaymentMonitoringReport(GMMap input) {
		GMMap outMap = new GMMap();
		try {			
			String tableName = "LIST";
			HashMap<String, Object> innerMap,corpsPayments = new HashMap<String, Object>(), corpNames = new HashMap<String, Object>();
			
			int fomCounter = 0, eposCounter = 0, totalCounter = 0;
			Double fomAmount = new Double("0"), eposAmount = new Double("0"), totalAmount = new Double("0");
			
			GMMap queryResult = DALUtil.getResults(QueryRepository.CPSReportsRepository.PAYMENT_MONITORING_REPORT_QUERY, tableName);
			
			// herbir kurum icin iki veya daha fazla payment_channel icin kayit gelecek. bunlar yatay gosterileceginden oncelikle hashmap lere atiyoruz. 
			for (int i = 0; i < queryResult.getSize(tableName); i++) {
				String corporateCode = queryResult.getString(tableName, i, "CORPORATE_CODE");
				String corporateName = queryResult.getString(tableName, i, "CORPORATE_NAME");
				String paymentChannel = queryResult.getString(tableName, i, "PAYMENT_CHANNEL");
				String paymentAmount = queryResult.getString(tableName, i, "PAYMENT_AMOUNT");
				String channelCount = queryResult.getString(tableName, i, "CHANNEL_COUNT");
								
				if(paymentChannel.equals("32")){
					fomAmount += Double.parseDouble(paymentAmount);
					fomCounter += Integer.parseInt(channelCount);
				}else{
					eposAmount += Double.parseDouble(paymentAmount);
					eposCounter += Integer.parseInt(channelCount);
				}
				totalAmount += Double.parseDouble(paymentAmount);
				totalCounter += Integer.parseInt(channelCount);
				
				innerMap = (HashMap<String, Object>) corpsPayments.get(corporateCode);
				if(innerMap == null)
					innerMap = new HashMap<String, Object>();
				
				innerMap.put(paymentChannel, channelCount + "|" + paymentAmount);
								
				corpsPayments.put(corporateCode, innerMap);	
				corpNames.put(corporateCode, corporateName);
			}
			
			// hashmap lere attigimiz kayitlari yatay olacak sekilde duzenliyoruz
			int rowNum = 0;
			for (Entry<String, Object> corp : corpsPayments.entrySet()) {
				String corporateName = (String) corpNames.get(corp.getKey());
				int fc = 0,ec = 0;
				Double fa = new Double("0"), ea = new Double("0");
				innerMap = (HashMap<String, Object>) corp.getValue();
				for (Entry<String, Object> im : innerMap.entrySet()) {
					if(im.getKey().equals("32")){
						fc = Integer.parseInt(((String)im.getValue()).split("[|]")[0]);
						fa = Double.parseDouble(((String)im.getValue()).split("[|]")[1]);
					}else{
						ec = Integer.parseInt(((String)im.getValue()).split("[|]")[0]);
						ea = Double.parseDouble(((String)im.getValue()).split("[|]")[1]);
					}
				}
				
				outMap.put(tableName, rowNum, "CORPORATE_NAME", corporateName);
				outMap.put(tableName, rowNum, "EPOS_AMOUNT", CommonHelper.applyDecimalFormat(ea.toString()));
				outMap.put(tableName, rowNum, "EPOS_COUNT", CommonHelper.applyDecimalFormat(new Integer(ec).toString()));
				outMap.put(tableName, rowNum, "FOM_AMOUNT", CommonHelper.applyDecimalFormat(fa.toString()));
				outMap.put(tableName, rowNum, "FOM_COUNT", CommonHelper.applyDecimalFormat(new Integer(fc).toString()));
				Double ta = new Double("0");
				ta = fa + ea;
				outMap.put(tableName, rowNum, "TOTAL_AMOUNT", CommonHelper.applyDecimalFormat(ta.toString()));
				int tc = 0;
				tc = fc + ec;
				outMap.put(tableName, rowNum, "TOTAL_COUNT", CommonHelper.applyDecimalFormat(new Integer(tc).toString()));
				rowNum++;
			}
			// raporun ust kisminda gorunecek toplam degerlerini set ediyoruz
			outMap.put("FOM_AMOUNT", CommonHelper.applyDecimalFormat(fomAmount.toString()));
			outMap.put("FOM_COUNT", CommonHelper.applyDecimalFormat(new Integer(fomCounter).toString()));
			outMap.put("EPOS_AMOUNT", CommonHelper.applyDecimalFormat(eposAmount.toString()));
			outMap.put("EPOS_COUNT", CommonHelper.applyDecimalFormat(new Integer(eposCounter).toString()));
			outMap.put("TOTAL_AMOUNT", CommonHelper.applyDecimalFormat(totalAmount.toString()));
			outMap.put("TOTAL_COUNT", CommonHelper.applyDecimalFormat(new Integer(totalCounter).toString()));
			
			// ust toplamlar icin up limitlerini parametrelerden cekiyoruz
			try {
				String faLimit = CommonHelper.getValueOfParameter("ICS_PAYMENT_MONITORING_REPORT", "FOM_AMOUNT_LIMIT");
				String fcLimit = CommonHelper.getValueOfParameter("ICS_PAYMENT_MONITORING_REPORT", "FOM_COUNT_LIMIT");
				String eaLimit = CommonHelper.getValueOfParameter("ICS_PAYMENT_MONITORING_REPORT", "EPOS_AMOUNT_LIMIT");
				String ecLimit = CommonHelper.getValueOfParameter("ICS_PAYMENT_MONITORING_REPORT", "EPOS_COUNT_LIMIT");
							
				outMap.put("FOM_AMOUNT_WARNING", fomAmount > Double.parseDouble(faLimit) ? 1 : 0);
				outMap.put("FOM_COUNT_WARNING", fomCounter > Integer.parseInt(fcLimit) ? 1 : 0);
				outMap.put("EPOS_AMOUNT_WARNING", eposAmount > Double.parseDouble(eaLimit) ? 1 : 0);
				outMap.put("EPOS_COUNT_WARNING", eposCounter > Integer.parseInt(ecLimit) ? 1 : 0);
			} catch (Exception e) {
				outMap.put("FOM_AMOUNT_WARNING", 0);
				outMap.put("FOM_COUNT_WARNING", 0);
				outMap.put("EPOS_AMOUNT_WARNING", 0);
				outMap.put("EPOS_COUNT_WARNING", 0);
			}
			
			// raporda gorunen saati guncelliyoruz
			String londDateTime = CommonHelper.getLongDateTimeString(new Date());
			outMap.put("DATE", CommonHelper.longTimeStringToViewDateString(londDateTime));
			outMap.put("TIME", CommonHelper.longTimeStringToViewTimeString(londDateTime));
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_GET_YIM_RECEIPT")
	public static GMMap getYimReceipt(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String trxNo = input.getString(MapKeys.TRX_NO);
			String yimCustomerNo = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "YIM_CUSTOMER_NO");
			
			String query = QueryRepository.CPSReportsRepository.YIM_RECEIPT_QUERY; 
			
			query = String.format(query, trxNo, yimCustomerNo);
			
			final String TABLE_NAME = "RECEIPT_RESULTS";
			
			GMMap results = DALUtil.getResults(query, TABLE_NAME);
			
			if(results.getSize(TABLE_NAME) == 1){
				HashMap<String, Object> parameters = new HashMap<String, Object>();
				parameters.put("CORP_NAME", results.getString(TABLE_NAME, 0, "ISL_ADI"));
				parameters.put("CORP_ADDRESS", results.getString(TABLE_NAME, 0, "ISL_ADRES"));
				parameters.put("TCKN", "");
				parameters.put("TAX_OFFICE", results.getString(TABLE_NAME, 0, "VERGI_D_ADI"));
				parameters.put("TRX_TYPE", results.getString(TABLE_NAME, 0, "ISLEM_TURU"));
				parameters.put("DATE", results.getString(TABLE_NAME, 0, "TARIH"));
				parameters.put("BRANCH", results.getString(TABLE_NAME, 0, "SUBE_ADI"));
				parameters.put("CUST_NO", results.getString(TABLE_NAME, 0, "MUSTERI_ADI"));
				parameters.put("IBAN", results.getString(TABLE_NAME, 0, "HESAP_IBAN"));
				parameters.put("STATEMENT_DESC1", results.getString(TABLE_NAME, 0, "ACIKLAMA"));
				parameters.put("STATEMENT_DESC2", results.getString(TABLE_NAME, 0, "ACIKLAMA1"));
				parameters.put("STATEMENT_DESC3", results.getString(TABLE_NAME, 0, "ACIKLAMA2"));
				parameters.put("STATEMENT_DESC4", results.getString(TABLE_NAME, 0, "ACIKLAMA3"));
				parameters.put("STATEMENT_DESC5", results.getString(TABLE_NAME, 0, "ACIKLAMA4"));
				parameters.put("BANK_SHORT_NAME", results.getString(TABLE_NAME, 0, "BANKAMIZ_KISA_ADI"));
				parameters.put("BRANCH_NAME", results.getString(TABLE_NAME, 0, "AMIR_SUBE_ADI"));
				parameters.put("TRX_DETAIL", results.getString(TABLE_NAME, 0, "ISLEM_DETAYI"));
				parameters.put("DEKONT_IMAGE_PATH", CPSReports.class.getClassLoader().getResource("dekont_client_copy.jpg").toString());
				logger.info("Dekont image path: " + CPSReports.class.getClassLoader().getResource("dekont_client_copy.jpg").toString()); 
				
				JasperPrint report = null;
				if(input.containsKey("PRINT_RECEIPT") && input.getBoolean("PRINT_RECEIPT"))
					report = ReportUtil.generateReport("CDM_YIM_RECEIPT_PRINT", parameters);
				else 
					report = ReportUtil.generateReport("CDM_YIM_RECEIPT", parameters);
				
				output.put("REPORT", report);
				
			}
			else if(results.getSize(TABLE_NAME) == 0){
				throw new GMRuntimeException(0, "Dekont bulunamam��t�r.", true);
			}
			else{
				throw new GMRuntimeException(0, "Birden �ok dekont bulunmu�tur.", true);
			}
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_GET_PAYMENTS_REPORT_SECTORS_COMBO_WRAPPER")
	public static GMMap getPaymentsReportComboWrapper(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String excSectorCodes = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "PAYMENTS_REPORT_EXC_SECTORS");
			input.put("EXC_SECTOR_CODES", excSectorCodes);
			output = CommonHelper.callGraymoundServiceInHibernateSession("CDM_TRN7000_GET_SECTORS_COMBO", input);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
		
	@GraymoundService("CDM_SENT_RECEIPT_EMAIL")
	public static GMMap sentReceiptEmail(GMMap input){
		GMMap output = new GMMap();
		
		try{			
			JasperPrint jp = (JasperPrint) input.get("CONTENT");
			String emailList = input.getString("EMAIL_LIST");
			String txNo = input.getString("TX_NO");
			String customerName = input.getString("CUSTOMER_NAME");
            
			if(StringUtil.isEmpty(emailList))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "\"M��teri Email Adresi\""));
			
			List<String> mailList = Arrays.asList(emailList.split("[;]"));
			for (String mail : mailList) {
				mail = mail.trim();
				if (!CommonHelper.isValidEmailAddress(mail))
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDEMAILADDRESS, String.format(" \"%s\"", mail)));
			}
			
			byte[] contentBinary = JasperExportManager.exportReportToPdf(jp);
			
			for (String mail : mailList) {
				GMMap servisMap = new GMMap();	
				
				servisMap.put("MAIL_FROM", "Aktifbank@aktifbank.com.tr");
				servisMap.put("MAIL_TO", mail);
				servisMap.put("MAIL_SUBJECT", String.format("%s numaral� i�leminizin dekontu", txNo));
				servisMap.put("MAIL_BODY", String.format("Say�n %s,<br><br>%s i�lem numaral� dekontunuz ektedir.<br><br>Sayg�lar�m�zla<br><b>Aktif Yat�r�m Bank A.�.</b>", customerName, txNo));
				servisMap.put("IS_BODY_HTML", "E");
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", "dekont.pdf");
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", contentBinary);				
				output.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap));	
			}
			
			output.put("MESSAGE", "Mail G�nderilmi�tir");
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
