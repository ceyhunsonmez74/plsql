package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.SaskiReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.saski.SaskiClient;
import tr.com.aktifbank.integration.saski.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.saski.AutomaticPaymentListDto;
import tr.com.saski.AutomaticPaymentLogResponse;
import tr.com.saski.CancelPaymentResponse;
import tr.com.saski.ChangeAutomaticPaymentResponse;
import tr.com.saski.GetBillsDto;
import tr.com.saski.GetBillsResponse;
import tr.com.saski.PayBillsResponse;
import tr.com.saski.PaymentReconciliationResponse;
import tr.com.saski.ReconciliationDailyResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SaskiServices extends OnlineCorporationInterface implements OnlineInstitutionConstants{
	private static final Log logger = LogFactory.getLog(SaskiServices.class);
	private static int STANDING_ORDER_TYPE = 1;
	private static int STANDING_ORDER_CANCEL_TYPE = 2;
	
	@GraymoundService("ICS_SASKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SASKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		String responseCode = "660";
		try{
			String agreementNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String installationNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String registerCode = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			builder.append(" ICS_SASKI_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | sicilNo -> ");
			builder.append(registerCode);
			builder.append(" | tesisatNo -> ");
			builder.append(installationNumber);
			builder.append(" | sozlesmeNo -> ");
			builder.append(agreementNumber);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			logger.info("ICS_SASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - SaskiClient.getBills(...) will be called..."));
			
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			GetBillsResponse response = client.getBills(sm, agreementNumber, installationNumber, registerCode, username);
			
			if(response.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = response.getMsgCode();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_SASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - SaskiClient.getBills(...) returned response code ".concat(response.getStatus())));
			
			if(responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				for(GetBillsDto getBillsDto: response.getList()){
					//if (!isCollectedInvoice(String.valueOf(getBillsDto.getBillNumber()), agreementNumber, installationNumber, registerCode, "", corporateCode)){
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, getBillsDto.getAgreementNumber());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, getBillsDto.getInstallationNumber());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, getBillsDto.getRegisterCode());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, getBillsDto.getBillNumber());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, getBillsDto.getTotalAmount());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, getBillsDto.getRegisterFullName());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.formatDateString(getBillsDto.getExpiryDate(), "dd/MM/yyyy", "yyyyMMdd"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, CommonHelper.formatDateString(new Integer(getBillsDto.getPeriod()).toString(), "yyyyMM", "yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, CommonHelper.formatDateString(new Integer(getBillsDto.getPeriod()).toString(), "yyyyMM", "MM"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, getBillsDto.getTotalAmount());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, getBillsDto.getAccountNumber());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, getBillsDto.getAccrueTypeId());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					//}
				}
			}
			
			logger.info("ICS_SASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - SaskiClient.getBills(...) finished succesfully"));
			
		}catch(Exception e2){
			logger.error("ICS_SASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}
	
	@GraymoundService("ICS_SASKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SASKI_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		String responseCode = "";
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE)); 
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			ServiceMessage sm = new ServiceMessage();
			String paymentDate = CommonHelper.formatDateString(CommonHelper.getShortDateTimeString(new Date()), "yyyyMMdd", "dd/MM/yyyy");
			String bankReceiptNumber = iMap.getString("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");		
			
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			Long bankOfficeNumber = new Long(0L);
			Long bankDeskNumber = new Long(0L);
			Long creditCardNumber = new Long(0L);
			String description = "";
			String accountNumber = iMap.getString(MapKeys.PARAMETER1);
			String accrueTypeId = iMap.getString(MapKeys.PARAMETER2);
			BigDecimal amount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			PayBillsResponse response = client.payBill(sm, paymentDate, bankReceiptNumber, paymentChannel, username, bankOfficeNumber, bankDeskNumber, creditCardNumber, description, accountNumber, accrueTypeId, amount);
			
			if(response.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = response.getMsgCode();
			}
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
			
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			
			if(responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter3(bankReceiptNumber);
				session.saveOrUpdate(invoicePayment);
			}
			
			logger.info("ICS_SASKI_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - SaskiClient.payBill(...) returned errorCode ".concat(response.getStatus())));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		}catch(Exception e2){
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}

	@GraymoundService("ICS_SASKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SASKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String paymentDate="";
			if (iMap.getString(MapKeys.PAYMENT_DATE)!=null && !"".equals(iMap.getString(MapKeys.PAYMENT_DATE))) {
				paymentDate=CommonHelper.formatDateString(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss", "dd/MM/yyyy");
			}else{
				paymentDate = CommonHelper.formatDateString(CommonHelper.getShortDateTimeString(new Date()), "yyyyMMdd", "dd/MM/yyyy");
			}
			String bankReceiptNumber = iMap.getString(MapKeys.PARAMETER_3);
			
			builder.append(" ICS_SASKI_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis No -> ");
			builder.append(bankReceiptNumber);
			builder.append(" | applicationKey -> ");
			builder.append(username);
			builder.append(" | securityCode -> ");
			builder.append(password);
			builder.append(" | serviceUrl -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			CancelPaymentResponse response = client.cancelPayment(sm, paymentDate, username, new Long(bankReceiptNumber), new Long(0), new Long(0), "");
			
			if(response.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = response.getMsgCode();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
					
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_SASKI_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_SASKI_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response.getStatus()));
			
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_SASKI_DEBT_INQUIRY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		String responseCode = "";
		try{
			int count = 0;
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);			
			String firstExpiryDate = CommonHelper.getDateString(new Date(), "dd-MM-yyyy");
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			ServiceMessage sm = new ServiceMessage();
			SaskiClient client = new SaskiClient(serviceUrl, username, password);

			GetBillsResponse response = client.getAutomaticPaymentBills(sm, firstExpiryDate);
			
			if(response.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = response.getMsgCode();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));			
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
			
			if (responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.TABLE_SIZE, response.getList().size());
				for(GetBillsDto getBillsDto : response.getList()){
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, getBillsDto.getAgreementNumber());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, getBillsDto.getInstallationNumber());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, getBillsDto.getRegisterCode());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, getBillsDto.getBillNumber());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, getBillsDto.getTotalAmount());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, getBillsDto.getRegisterFullName());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
//					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, getBillsDto.getExpiryDate());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_TERM_YEAR, CommonHelper.formatDateString(new Integer(getBillsDto.getPeriod()).toString(), "yyyyMM", "yyyy"));
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_TERM_MONTH, CommonHelper.formatDateString(new Integer(getBillsDto.getPeriod()).toString(), "yyyyMM", "MM"));
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_AMOUNT, getBillsDto.getTotalAmount());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER1, getBillsDto.getAccountNumber());
					outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER2, getBillsDto.getAccrueTypeId());
					outMap.put(MapKeys.INVOICE_LIST, count, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, count, "OID", "0");
					count++;
				}
			}
			
			logger.info("ICS_SASKI_DEBT_INQUIRY_FOR_STANDING_ORDER returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_SASKI_DEBT_INQUIRY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_SASKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_SASKI_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String agreementNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String installationNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String registerCode = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			logger.info("STO_SASKI_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(corporateCode));

			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			ServiceMessage sm = new ServiceMessage();
			
			ChangeAutomaticPaymentResponse response = client.changeAutomaticPayment(sm, agreementNumber, installationNumber, registerCode, STANDING_ORDER_TYPE);
			
			if(response.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = response.getMsgCode();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		} catch (Throwable e2) {
			logger.info("STO_SASKI_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_SASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_UNIVERSAL_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String agreementNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String installationNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String registerCode = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			logger.info("STO_SASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(corporateCode));

			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			ServiceMessage sm = new ServiceMessage();
			
			ChangeAutomaticPaymentResponse response = client.changeAutomaticPayment(sm, agreementNumber, installationNumber, registerCode, STANDING_ORDER_CANCEL_TYPE);
			
			if(response.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = response.getMsgCode();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_SASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_SASKI_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SASKI_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			ServiceMessage sm = new ServiceMessage();
			
			AutomaticPaymentLogResponse standingOrderResponse = client.getAutomaticPaymentLogs(sm, reconDate, "", "1");			

			if(standingOrderResponse.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = standingOrderResponse.getMsgCode();
			}
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				
				if ("NO_DATA_FOUND".equals(responseCode)) {
					outMap.put(MapKeys.RECON_CORPORATE_COUNT, "0");
					outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, "0");
				} else {
					int toplamTalimatSayisi = standingOrderResponse.getSummaryList().get(0).getTotalInstruction();				
					int talimatIptalSayisi = standingOrderResponse.getSummaryList().get(0).getTotalCancellation();	
					int talimatSayisi = toplamTalimatSayisi - talimatIptalSayisi;
					outMap.put(MapKeys.RECON_CORPORATE_COUNT, talimatSayisi);
					outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, talimatIptalSayisi);
				}
			
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				rcInput.put("RECON_DATE", iMap.getString(MapKeys.RECON_DATE));

				GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
	
				int bankReconCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
				int bankReconCancelCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.CANCEL_COUNT);
				
				outMap.put(MapKeys.RECON_BANK_COUNT, bankReconCount);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankReconCancelCount);
			} else {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
			}


		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}finally{
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	@GraymoundService("STO_SASKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_SASKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage message = new ServiceMessage();
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			ServiceMessage sm = new ServiceMessage();
			
			AutomaticPaymentLogResponse standingOrderResponse = client.getAutomaticPaymentLogs(sm, reconDate, "", "0");			

			if(standingOrderResponse.getStatus().equals("OK")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				responseCode = standingOrderResponse.getMsgCode();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
			GMMap listMap = new GMMap();
			listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);

			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			List<AutomaticPaymentListDto> corpStandingOrderList = standingOrderResponse.getDetailList(); //TODO: TALIMATLARI AYIR 
			List<AutomaticPaymentListDto> corpStandingOrderCancelList = new ArrayList<AutomaticPaymentListDto>();
			List<AutomaticPaymentListDto> corpStandingOrderInstructionList = new ArrayList<AutomaticPaymentListDto>();
			
			for(AutomaticPaymentListDto payment: corpStandingOrderList){
				if(payment.getCancellationDate().equals("")){
					corpStandingOrderInstructionList.add(payment);
				} else{
					corpStandingOrderCancelList.add(payment);
				}
			}			
			
			boolean found = false;
			if (bankStandingOrderList.size() > corpStandingOrderInstructionList.size()) {
				short collectionType = 0;
				for (int j = 0; j < bankStandingOrderList.size(); j++) {
					for (int i = 0; i < corpStandingOrderInstructionList.size(); i++) {
						if (bankStandingOrderList.get(j).getSubscriberNo1().equals(corpStandingOrderInstructionList.get(i).getAgreementNumber())){
							collectionType = bankStandingOrderList.get(j).getCollectionType();
							found = true;
							corpStandingOrderInstructionList.remove(i);
							break;
						}
						else {
							found = false;
						}
					}
					if (!found) {
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();

						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						}
						catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;

				List<icsStandingOrders> bankStandingOrderCancelList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");
				
				for (int j = 0; j < corpStandingOrderInstructionList.size(); j++) {
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						if (bankStandingOrderList.get(j).getSubscriberNo1().equals(corpStandingOrderInstructionList.get(i).getAgreementNumber())) {
							collectionType = bankStandingOrderList.get(j).getCollectionType();
							found = true;
//							corpStandingOrderCancelList.remove(i);
							break;
						}
						else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();

						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderCancelList.get(j).getSubscriberNo1());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						}
						catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat Iptal Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderCancelList.get(j).getSubscriberNo1());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KAYGAZ_GET_STANDING_ORDER_RECONCILIATION_DETAIL.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}
	
	@GraymoundService("STO_SASKI_STANDING_ORDER_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_SASKI_STANDING_ORDER_RECONCILIATION_CLOSED");
		
		try{					
			output = CommonHelper.callGraymoundServiceInHibernateSession("STO_SASKI_STANDING_ORDER_RECONCILIATION", input);
			
			output.put("BANK", 0, MapKeys.RECON_CORPORATE_COUNT, output.getString(MapKeys.RECON_CORPORATE_COUNT));
			output.put("BANK", 0, MapKeys.RECON_CORPORATE_CANCEL_COUNT, output.getString(MapKeys.RECON_CORPORATE_CANCEL_COUNT));			
			output.put("CORPORATE", 0, MapKeys.RECON_BANK_COUNT, output.getString(MapKeys.RECON_BANK_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_BANK_CANCEL_COUNT, output.getString(MapKeys.RECON_BANK_CANCEL_COUNT));
			
			output.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			insertOnlineServiceLog(input, output);
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_SASKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		String responseCode="";
		String responseMessage = "";

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SASKI_COLLECTION_RECONCILIATION_CLOSED");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashCode=username; //Vezne (cashCode) parametresi 0(s�f�r) olarak verilirseilgili bankan�n t�m veznelerinin �zetini verir.
	
			ServiceMessage sm= new ServiceMessage();
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");

			
			Long bankOfficeNumber=new Long(0);
			String description="";
			
			int autoPaymentCount = 0;
			
			Long bankDeskNumber=new Long(0);
			Boolean forDischarge=false;
			
			String lastDate ="";
			
			BigDecimal autoPaymentAmount = new BigDecimal(0);			

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			int deskPaymentCount=collectionCount;
			int cancellationCount=cancelCount;
			BigDecimal deskPaymentAmount=collectionTotal;
			BigDecimal cancellationAmount=cancelTotal;

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount); 
			
		    PaymentReconciliationResponse response= client.paymentReconciliation(sm, cashCode, reconDateString, bankOfficeNumber, bankDeskNumber, description, deskPaymentCount, deskPaymentAmount, autoPaymentCount, autoPaymentAmount, cancellationCount, cancellationAmount, forDischarge);
			responseCode = response.getStatus();
						
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	
			if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
				output.put(MapKeys.ERROR_CODE, "660");
				output.put(MapKeys.ERROR_DESC, errorMessage);
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_SASKI_COLLECTION_RECONCILIATION_CLOSED - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_SASKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SASKI_COLLECTION_RECONCILIATION");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String serviceUrlClose = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String cashCode=username; //Vezne (cashCode) parametresi 0(s�f�r) olarak verilirseilgili bankan�n t�m veznelerinin �zetini verir.
	
			ServiceMessage sm= new ServiceMessage();
			SaskiClient client = new SaskiClient(serviceUrl, username, password);
			SaskiClient clientClose = new SaskiClient(serviceUrlClose, username, password);

			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");

			
			Long bankOfficeNumber=new Long(0);
			String description="";
			
			int autoPaymentCount = 0;
			
			Long bankDeskNumber=new Long(0);
			Boolean forDischarge=false;
			
			
			BigDecimal autoPaymentAmount = new BigDecimal(0);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			int deskPaymentCount=collectionCount;
			int cancellationCount=cancelCount;
			BigDecimal deskPaymentAmount=collectionTotal;
			BigDecimal cancellationAmount=cancelTotal;


			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_SASKI_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(reconDateString);
		
			builder.append(serviceUrl);
			logger.info(builder.toString());
			String lastDate ="";

			ReconciliationDailyResponse response=client.reconciliationDailyTotal(sm, cashCode, reconDateString, lastDate, bankOfficeNumber, bankDeskNumber);
			GMMap responceCodeMap = getResponseCodeMapping(response.getMsgCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, "0");
			output.put(MapKeys.ERROR_DESC, "");
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getMsgText());
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());

			if (response.getAutoPaymentAmount() == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_SASKI_COLLECTION_RECONCILIATION - result size 0 geldi");

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_SASKI_UNIVERSAL_COLLECTION_RECONCILIATION - response.getBgsTahsilIcmalDto() null degil");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getPaymentAmount());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getPaymentCount());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getCancelAmount());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getCancelCount());
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).setScale(2,
				     RoundingMode.HALF_UP).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
						
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_SASKI_UNIVERSAL_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_SASKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {

		GMMap output = new GMMap();
		logger.info("ICS_SASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SASKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new SaskiReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_SASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
}