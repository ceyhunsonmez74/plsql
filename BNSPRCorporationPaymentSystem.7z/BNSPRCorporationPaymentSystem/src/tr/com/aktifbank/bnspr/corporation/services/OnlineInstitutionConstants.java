package tr.com.aktifbank.bnspr.corporation.services;


public interface OnlineInstitutionConstants {
	public static final String WS_SEND_SUCCESSFUL="1";
	public static final String WS_SEND_FAIL="0";
	public static final String ADASU_CORPORATE_CODE="ADASU_CORPORATE_CODE";
	
	
}
