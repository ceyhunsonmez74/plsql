package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.SaskiCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.SaskitandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.StandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.ServiceResponseCodeMapping;
import tr.com.aktifbank.integration.adasu.AdasuClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.gov.adasu.service.tahsilat.xsd.BorcSorgu;
import tr.gov.adasu.service.tahsilat.xsd.BorcTahsilat;
import tr.gov.adasu.service.tahsilat.xsd.BorcTahsilatIptal;
import tr.gov.adasu.service.tahsilat.xsd.TahsilatDetayMutabakat;
import tr.gov.adasu.service.tahsilat.xsd.TahsilatGenelMutabakat;
import tr.gov.adasu.service.talimat.xsd.OdemeTalimat;
import tr.gov.adasu.service.talimat.xsd.OdemeTalimatIptal;
import tr.gov.adasu.service.talimat.xsd.TalimatGenelMutabakat;
import tr.gov.adasu.service.xsd.Abone;
import tr.gov.adasu.service.xsd.Banka;
import tr.gov.adasu.service.xsd.Fatura;
import tr.gov.adasu.service.xsd.FaturaMutabakat;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ADAWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(ADAWaterServices.class);

	private static class ResponseCodes {
		private static final String DEBT_INQUIRY_SUCCESS = "300";
		private static final String DO_INVOICE_COLLECTION_SUCCESS = "302";
		private static final String CANCEL_INVOICE_COLLECTION_SUCCESS = "304";
		public static final Object NEW_STANDING_ORDER_SUCCESS = "400";
		public static final Object CANCEL_STANDING_ORDER_SUCCCES = "402";
	}

	private static final String ALL = "T";
	private static final String STO = "TALIMAT";

	private static AdasuClient getSoapClient(GMMap iMap, boolean preparedSubscriber) throws Exception, Exception {
		Object wsEndpoint = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		Object wsUser = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		Object wsPassword = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

		AdasuClient client = null;
		if (preparedSubscriber) {
			client = new AdasuClient(prepareBankInfo(iMap), wsUser.toString(), wsPassword.toString(), prepareSubsInfo(iMap), wsEndpoint.toString());
		} else {
			client = new AdasuClient(prepareBankInfo(iMap), wsUser.toString(), wsPassword.toString(), wsEndpoint.toString());
		}

		return client;
	}

	private static Abone prepareSubsInfo(GMMap iMap) {
		String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		Abone subscriber = new Abone();
		subscriber.setAboneNo(Integer.parseInt(subscriberNo));

		logger.info("[TTSystemService[prepareSubsInfo]] Values will be used are : Subscriber No :" + subscriberNo);

		return subscriber;
	}

	private static Banka prepareBankInfo(GMMap iMap) {
		Object bankUser = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		Object bankPassword = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);

		Banka bankInfo = new Banka(Integer.parseInt(bankUser.toString()), bankPassword.toString(), "34", "555");
		return bankInfo;
	}

	@GraymoundService("ICS_ADASU_INVOICE_DEBT_INQUIRY")
	public static GMMap invoiceDebtInquiry(GMMap iMap) {

		logger.info("[ADAWaterServices[invoiceDebtInquiry]] is started. Parameters : " + iMap);

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_INVOICE_DEBT_INQUIRY");

		GMMap output = new GMMap();

		try {
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			AdasuClient client = getSoapClient(iMap, false);

			BorcSorgu response = client.aboneBorcSorgula(Integer.parseInt(subscriberNo));

			if (response.getKod().toString().equals(ResponseCodes.DEBT_INQUIRY_SUCCESS)) {
				StringBuilder subscriberNameBuilder = new StringBuilder();
				if (null != response.getAbone()) {
					subscriberNameBuilder.append(response.getAbone().getAd()).append(" ").append(response.getAbone().getSoyad());
				}
				int counter = 0;
				if (null != response.getFaturas()) {
					for (Fatura unpaidInvoice : response.getFaturas()) {
						BigDecimal amount = new BigDecimal(unpaidInvoice.getTutar());
						amount = amount.setScale(2, RoundingMode.HALF_EVEN);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, unpaidInvoice.getId());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, amount);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, subscriberNameBuilder.toString());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, unpaidInvoice.getDonem().substring(unpaidInvoice.getDonem().lastIndexOf(".") + 1));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, unpaidInvoice.getDonem().substring(0, unpaidInvoice.getDonem().indexOf(".")));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, amount);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, changeDatePattern(unpaidInvoice.getVade()));
						output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			} else {
				GMMap codeMapping = getResponseCodeMapping(response.getKod().toString(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ADASU_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_DO_INVOICE_COLLECTION");

		logger.info("[ADAWaterServices[doInvoiceCollection]] is started. Parameters : " + iMap);

		GMMap output = new GMMap();
		try {

			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String paymentDate = iMap.getString(MapKeys.PAYMENT_DATE);

			long invoices[] = new long[] { Long.parseLong(invoiceNo) };

			AdasuClient client = getSoapClient(iMap, false);

			BorcTahsilat paymentInvoiceResponse = client.borcTahsilati(Integer.parseInt(subscriberNo), invoices, changeDate2CorpDate(paymentDate));
			if (null != paymentInvoiceResponse) {
				if (null != paymentInvoiceResponse.getKod()) {
					if (ResponseCodes.DO_INVOICE_COLLECTION_SUCCESS.equals(paymentInvoiceResponse.getKod().toString())) {
						output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					} else {
						setErrorCodeToOutput(paymentInvoiceResponse.getKod().toString(), iMap, output);
					}
				}
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ADASU_CANCEL_COLLECTION")
	public static GMMap cancelCollection(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[ADAWaterServices[cancelCollection]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_CANCEL_COLLECTION");

		try {
			String invoicePaymentDate = null;
			if (null != iMap.getString(MapKeys.PAYMENT_DATE)) {
				invoicePaymentDate = iMap.getString(MapKeys.PAYMENT_DATE);
			} else {
				invoicePaymentDate = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			}

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String subceriberNo1 = iMap.getString("SUBSCRIBER_NO_1");
			iMap.put(MapKeys.SUBSCRIBER_NO1, subceriberNo1);

			String channelCode = iMap.getString("CHANNEL_CODE", null);

			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			long invoices[] = new long[] { Long.parseLong(invoiceNo) };

			logger.info("[ADAWaterServices[cancelCollection]] Values will be used are : Invoice Payment Date :" + invoicePaymentDate + "Corporate Code :" + corporateCode + " Channel Code : " + channelCode);

			AdasuClient client = getSoapClient(iMap, false);
			BorcTahsilatIptal cancelInvoicePaymentResponse = client.borcTahsilatiIptal(Integer.parseInt(subceriberNo1), invoices, changeDate2CorpDate(invoicePaymentDate));

			if (null != cancelInvoicePaymentResponse) {
				if (null != cancelInvoicePaymentResponse.getKod() && cancelInvoicePaymentResponse.getKod().toString().equals(ResponseCodes.CANCEL_INVOICE_COLLECTION_SUCCESS)) {
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				} else {
					setErrorCodeToOutput(cancelInvoicePaymentResponse.getKod().toString(), iMap, output);
				}
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_ADASU_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_DEBT_INQUERY_FOR_STANDING_ORDER");

		logger.info("[ADAWaterServices[getdebtQueryForStandingOrder]] is started. Parameters : " + iMap);
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String dueDate = CommonHelper.getDateString(new Date(), "yyyyMMdd");

			logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] Values are : " + dueDate + " , corporate code : " + corporateCode);

			AdasuClient client = getSoapClient(iMap, false);
			TahsilatDetayMutabakat standingOrderAccountsWithInvoices = client.tahsilatDetayMutabakat(changeDate2CorpDate(dueDate), STO);

			if (null != standingOrderAccountsWithInvoices) {
				logger.info("[ADAWaterServices[getdebtQueryForStandingOrder]] BillInvoice Response Codes : " + standingOrderAccountsWithInvoices.getKod());

				if (null != standingOrderAccountsWithInvoices.getFaturas()) {
					FaturaMutabakat[] invoices = standingOrderAccountsWithInvoices.getFaturas();
					int counter = 0;
					for (FaturaMutabakat unpaidInvoice : invoices) {
						BigDecimal amount = new BigDecimal(unpaidInvoice.getTutar());
						amount = amount.setScale(2, RoundingMode.HALF_EVEN);
						logger.info("[ADAWaterServices[getdebtQueryForStandingOrder]] Invoices : " + unpaidInvoice);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, unpaidInvoice.getAboneNo());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, unpaidInvoice.getId());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, amount);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, unpaidInvoice.getDonem().substring(unpaidInvoice.getDonem().lastIndexOf(".") + 1));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, unpaidInvoice.getDonem().substring(0, unpaidInvoice.getDonem().indexOf(".")));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, amount);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, changeDatePattern(unpaidInvoice.getVade()));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, changeDatePattern(unpaidInvoice.getDonem()));
						output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						logger.info("[ADAWaterServices[getdebtQueryForStandingOrder]] Invoices in Map : " + output);
					}

					output.put(MapKeys.TABLE_SIZE, counter);
					logger.info("[ADAWaterServices[getdebtQueryForStandingOrder]] Size : " + counter);
				} else {
					GMMap codeMapping = getResponseCodeMapping(standingOrderAccountsWithInvoices.getKod().toString(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
					output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
				}
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_ADASU_SAVE_STANDING_ORDER")
	public static GMMap saveStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ADASU_SAVE_STANDING_ORDER");

		logger.info("[ADAWaterServices[saveStandingOrder]] is started. Parameters : " + iMap);

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_SAVE_STANDING_ORDER");
		try {
			String date = CommonHelper.getDateString(getInputDateOrDefault(iMap, MapKeys.RECON_DATE_BEGIN, "yyyyMMdd"), "yyyyMMdd");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			logger.info("[TTSystemService[saveStandingOrder]] Values will be used are : " + "Corporate Code :" + corporateCode + "Process Date : " + date);

			AdasuClient client = getSoapClient(iMap, true);
			OdemeTalimat stoResponse = client.otomatikOdemeTalimati(changeDate2CorpDate(date));

			if (null != stoResponse) {
				if (null != stoResponse && !stoResponse.getKod().equals(ResponseCodes.NEW_STANDING_ORDER_SUCCESS)) {
					setErrorCodeToOutput(stoResponse.getKod().toString(), iMap, output);
				}
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_ADASU_CANCEL_STANDING_ORDER")
	public static GMMap cancelStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[ADAWaterServices[cancelStandingOrder]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ADASU_CANCEL_STANDING_ORDER");
		try {
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			logger.info("[ADAWaterServices[cancelStandingOrder]] Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode);

			AdasuClient client = getSoapClient(iMap, false);
			OdemeTalimatIptal stoResponse = client.otomatikOdemeTalimatiIptal(Integer.parseInt(subscriberNo));

			if (null != stoResponse) {
				if (null != stoResponse && !stoResponse.getKod().equals(ResponseCodes.CANCEL_STANDING_ORDER_SUCCCES)) {
					setErrorCodeToOutput(stoResponse.getKod().toString(), iMap, output);
				}
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_ADASU_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ADASU_GET_STANDING_ORDER_RECONCILIATION_DETAIL");

		try {

			StandingOrderReconciliationDetailBatch batch = new SaskitandingOrderReconciliationDetailBatch(iMap, getSoapClient(iMap, false));
			output = batch.runBatch();

		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_ADASU_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[ADAWaterServices[standingOrderReconciliation]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ADASU_STANDING_ORDER_RECONCILIATION");

		try {
			Date reconDate = iMap.getDate(MapKeys.RECON_DATE);
			String reconcilationDate = CommonHelper.getDateString(reconDate, "yyyyMMdd");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);

			int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
			int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");

			logger.info("[ADAWaterServices[standingOrderReconciliation]] Values will be used are : Reconciliation Date :" + reconcilationDate + " Corporate Code :" + corporateCode + " Total Collection Count : " + bankStandingOrderCount + " Total Cancel Count " + bankStandingOrderCancelCount);

			output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);

			AdasuClient reconClient = getSoapClient(iMap, false);

			TalimatGenelMutabakat stoReconSummaryResponse = reconClient.otomatikOdemeGenelMutabakat(changeDate2CorpDate(reconcilationDate));

			if (null != stoReconSummaryResponse) {

				int corpCollectionCount = stoReconSummaryResponse.getOnayAdet();
				int corpCancellCollectionCount = stoReconSummaryResponse.getIptalAdet();

				output.put(MapKeys.RECON_CORPORATE_COUNT, corpCollectionCount);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancellCollectionCount);

				logger.info("[ADAWaterServices[collectionReconciliation]] Corporate Values are : Reconciliation Date :" + reconcilationDate + " Corporate Code :" + corporateCode + " Total Collection Count : " + corpCollectionCount + " Total Cancel Count " + corpCancellCollectionCount);

				if (bankStandingOrderCount == corpCollectionCount && bankStandingOrderCancelCount == corpCancellCollectionCount) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}

				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_ADASU_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap outMap = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_GET_COLLECTION_RECONCILIATION_DETAIL");

		logger.info("[ADAWaterServices[getCollectionReconciliationDetail]] is started. Parameters : " + iMap);

		try {
			CollectionReconciliationDetailBatch batch = new SaskiCollectionReconciliationDetailBatch(iMap, getSoapClient(iMap, false));
			outMap = batch.runBatch();
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);

		}

		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_ADASU_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[ADAWaterServices[collectionReconciliation]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_COLLECTION_RECONCILIATION");

		try {
			String reconcilationDate = CommonHelper.getDateString(iMap.getDate(MapKeys.RECON_DATE), "yyyyMMdd");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			logger.info("[ADAWaterServices[collectionReconciliation]] Values will be used are : Reconciliation Date :" + reconcilationDate + " Corporate Code :" + corporateCode + " Total Collection Count : " + collectionCount + " Total Cancel Count " + cancelCount + " Total Collection Amount " + collectionTotal + " Total Cancel Amount " + cancelTotal);

			AdasuClient reconClient = getSoapClient(iMap, false);

			TahsilatGenelMutabakat reconciliationSummaryResponse = reconClient.tahsilatGenelMutabakat(changeDate2CorpDate(reconcilationDate), ALL);

			if (null != reconciliationSummaryResponse) {

				int corpCollectionCount = reconciliationSummaryResponse.getTahsilAdet();
				BigDecimal corpCollectionAmount = new BigDecimal(reconciliationSummaryResponse.getTahsilTutar().toString());

				int corpCancellCollectionCount = reconciliationSummaryResponse.getIptalAdet();
				BigDecimal corpCancelCollectionAmount = new BigDecimal(reconciliationSummaryResponse.getIptalTutar().toString());

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpCollectionAmount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpCollectionCount);

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpCancelCollectionAmount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpCancellCollectionCount);

				logger.info("[ADAWaterServices[collectionReconciliation]] Corporate Values are : Reconciliation Date :" + reconcilationDate + " Corporate Code :" + corporateCode + " Total Collection Count : " + corpCollectionCount + " Total Cancel Count " + corpCancellCollectionCount + " Total Collection Amount " + corpCollectionAmount + " Total Cancel Amount " + corpCancelCollectionAmount);

				if (collectionCount == corpCollectionCount && collectionTotal.compareTo(corpCollectionAmount) == 0 && cancelCount == corpCancellCollectionCount && cancelTotal.compareTo(corpCancelCollectionAmount) == 0) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					logger.info("[ADAWaterServices[collectionReconciliation]] It was not reconciliated.");
					Session hibernateSession = CommonHelper.getHibernateSession();
					Query paymentQuery = hibernateSession.createSQLQuery(QueryRepository.ADAWaterServicesRepository.GET_COLLECTION_RECON_SQL).setParameter("corporateCode", corporateCode).setParameter("paymentDate", reconcilationDate + "%");

					List<Object[]> queryResult = paymentQuery.list();
					BigDecimal cancelDecrementAmount = BigDecimal.ZERO;
					int cancelDecrementCount = 0;
					if (null != queryResult) {
						cancelDecrementCount = queryResult.size();
						for (Object[] paymentAmount : queryResult) {
							if (null != paymentAmount[3]) {
								cancelDecrementAmount = cancelDecrementAmount.add(new BigDecimal(paymentAmount[3].toString()));
							}
						}
					}

					logger.info("[ADAWaterServices[collectionReconciliation]] Decrement Values : Count : " + cancelDecrementCount + " , Amount : " + cancelDecrementAmount);

					if (cancelTotal.compareTo(cancelDecrementAmount) >= 0) {
						cancelTotal = cancelTotal.subtract(cancelDecrementAmount);
					}

					if (cancelCount >= cancelDecrementCount) {
						cancelCount = cancelCount - cancelDecrementCount;
					}
					if (collectionCount == corpCollectionCount && collectionTotal.compareTo(corpCollectionAmount) == 0 && cancelCount == corpCancellCollectionCount && cancelTotal.compareTo(corpCancelCollectionAmount) == 0) {
						output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
						output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
						output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
						output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

						logger.info("[ADAWaterServices[collectionReconciliation]] Updated Reconciliation Map : " + iMap);
					} else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				}

				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_ADASU_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ADASU_COLLECTION_RECONCILIATION_CLOSED");

		logger.info("[ADAWaterServices[collectionReconciliationClosed]] is started. Parameters : " + iMap);

		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	private static String changeDatePattern(String parsedDate) throws Exception {
		return CommonHelper.formatDateString(parsedDate, "dd.MM.yyyy", "yyyyMMdd");
	}

	private static String changeDate2CorpDate(String parsedDate) throws Exception {
		if (null == parsedDate) {
			return CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
		}

		String corpDate = null;
		if (parsedDate.length() > 8) {
			corpDate = CommonHelper.formatDateString(parsedDate, "yyyyMMddhhmmss", "dd.MM.yyyy");
		} else {
			corpDate = CommonHelper.formatDateString(parsedDate, "yyyyMMdd", "dd.MM.yyyy");
		}

		logger.info("[ADAWaterServices[changeDate2CorpDate]] Parsed Date " + corpDate);
		return corpDate;
	}

	public static GMMap getResponseCodeMapping(String responseCode, String serviceOid, String corporateCode) {
		GMMap output = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(ServiceResponseCodeMapping.class);
			Criterion status = Restrictions.eq("status", true);
			Criterion returnCode = Restrictions.eq("returnCode", responseCode);
			Criterion corporateCODE = Restrictions.eq("corporateCode", corporateCode);
			criteria.add(status).add(returnCode).add(corporateCODE);

			@SuppressWarnings("unchecked")
			List<ServiceResponseCodeMapping> responseCodeMappingList = criteria.list();

			if (responseCodeMappingList.size() > 0) {
				for (ServiceResponseCodeMapping responseCodeMapping : responseCodeMappingList) {
					output.put("RETURN_CODE", responseCodeMapping.getReturnCode());
					output.put("RETURN_CODE_DESC", responseCodeMapping.getReturnCodeDesc());
					output.put(MapKeys.ERROR_CODE, responseCodeMapping.getErrorCode());
					output.put(MapKeys.ERROR_DESC, responseCodeMapping.getExplanation());
					logger.info("[ADAWaterServices[getResponseCodeMapping]] Return Code : " + responseCodeMapping.getReturnCode() + " Return Code Desc : " + responseCodeMapping.getReturnCodeDesc());
				}
			} else {
				output.put("RETURN_CODE", responseCode);
				output.put("RETURN_CODE_DESC", GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_NOT_FOUND);
				output.put(MapKeys.ERROR_DESC, GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			}
		} catch (Exception e) {
			output.put("RETURN_CODE", responseCode);
			output.put("RETURN_CODE_DESC", GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			output.put("ERROR_CODE", GeneralConstants.ERROR_CODE_NOT_FOUND);
			output.put("EXPLANATION", GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	private static void setErrorCodeToOutput(String errorCode, GMMap input, GMMap output) {
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);

		GMMap responseCodeMap = getResponseCodeMapping(errorCode, input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

		output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
		output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
	}

	private static Date getInputDateOrDefault(GMMap input, String key, String format) throws ParseException {
		Date date = new Date();

		if (!StringUtil.isEmpty(input.getString(key))) {
			date = CommonHelper.getDateTime(input.getString(key), format);
		}

		return date;
	}

}
