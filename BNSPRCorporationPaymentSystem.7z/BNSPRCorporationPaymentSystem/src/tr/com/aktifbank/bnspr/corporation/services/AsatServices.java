package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.AsatReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.asatNew.AsatNewClient;
import tr.com.aktifbank.integration.asatNew.AsatServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.asat.Borc;
import com.asat.BorcSorguSonucu;
import com.asat.BorcTipleri;
import com.asat.MutabakatOzetiSorguSonucu;
import com.asat.MutabakatOzetiSorguSonucuV2;
import com.asat.SorguSonucuBase;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AsatServices extends OnlineCorporationInterface implements OnlineInstitutionConstants{
	private static final Log logger = LogFactory.getLog(SaskiServices.class);
	
	@GraymoundService("ICS_ASAT_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASAT_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		AsatServiceMessage sm = new AsatServiceMessage();
		try {
			BorcSorguSonucu response = new BorcSorguSonucu();
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			Long abone = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			Long sicil = iMap.getLong(MapKeys.SUBSCRIBER_NO2);
			
//			Long abone = Long.valueOf(iMap.getString(MapKeys.SUBSCRIBER_NO1));
//			Long sicil = Long.valueOf(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			
			// logger info will be logged
			builder.append(" ICS_ASAT_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(abone);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			logger.info(builder.toString());

			logger.info("ICS_ASAT_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - AsatClient.borcSorgula(...) will be called..."));
			Integer invoiceCount = 0;
			
			if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				response = AsatNewClient.suAbonesindenBorcSorgula(url, username, password, webIp, bankaKodu, subeKodu, abone, sm);
			} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				response = AsatNewClient.sicildenBorcSorgula(url, username, password, webIp, bankaKodu, subeKodu, sicil, 0, 0, sm);
			}	
			
			logger.info("ICS_ASAT_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - AsatClient.borcSorgula(...) returned with count ".concat(invoiceCount.toString())));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());//response exception alinca null geliyor
			String responseCode = response.getMesajKodu();
			if(responseCode == null || "".equals(responseCode))
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_ASAT_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - AsatClient.borcSorgula(...) returned errorCode ".concat(errorCode)));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (Borc borc : response.getBorclar()) {
					if (!isCollectedInvoice(String.valueOf(borc.getTahakNo()), String.valueOf(borc.getAboneNo()), "", "", "", corporateCode)) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getTahakNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, response.getSicil().getAd() + " " + response.getSicil().getSoyad());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(borc.getSonOdemeTarihi().getTime()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getYil());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getDonem());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getSicilNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, borc.getGelirKoduId());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borc.getPaketId());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borc.getBakiye());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, borc.getZam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, borc.getIhbarNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, CommonHelper.getShortDateTimeString(borc.getTahakkukTarihi().getTime()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, CommonHelper.getShortDateTimeString(borc.getSonOdemeTarihi().getTime()));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_ASAT_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - AsatClient.borcSorgula(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_ASAT_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}

	@GraymoundService("ICS_ASAT_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASAT_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		AsatServiceMessage sm = new AsatServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			Long aboneNo = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			Long sicilNo = iMap.getLong(MapKeys.PARAMETER1);
			int gelirKoduId = iMap.getInt(MapKeys.PARAMETER2);
			int paketId = iMap.getInt(MapKeys.PARAMETER3);
			double bakiye = Double.valueOf(iMap.getString(MapKeys.PARAMETER4));
			double zam = Double.valueOf(iMap.getString(MapKeys.PARAMETER5));
			double toplam = Double.valueOf(iMap.getString(MapKeys.PAYMENT_AMOUNT));
			int ihbarNo = iMap.getInt(MapKeys.PARAMETER6);
			int yil = iMap.getInt(MapKeys.TERM_YEAR);
			int donem = iMap.getInt(MapKeys.TERM_MONTH);
			Calendar tahakkukTarihi = CommonHelper.getCalendarWithYYYYMMDD(iMap.getString(MapKeys.PARAMETER7));
			Calendar sonOdemeTarihi = CommonHelper.getCalendarWithYYYYMMDD(iMap.getString(MapKeys.PARAMETER8));
			
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String date = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				date = CommonHelper.getShortDateTimeString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
			} else {
				date = CommonHelper.getShortDateTimeString(new Date());
			}
			Calendar tahsilatTarihi = CommonHelper.getCalendarWithYYYYMMDD(date);
			String tt = CommonHelper.getShortDateTimeString(tahsilatTarihi.getTime());
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_ASAT_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | trasnactionId -> ");
			builder.append(trasnactionId);
			builder.append(" | tahakkukNo -> ");
			builder.append(tahakkukNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			logger.info(builder.toString());
			
			if (isStandingOrderCollection) {
				logger.info("ICS_ASAT_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - AsatClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			}else{
				logger.info("ICS_ASAT_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - AsatClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			SorguSonucuBase response = null;			
			Borc b = new Borc(BorcTipleri.Su, sicilNo, aboneNo, tahakkukNo, gelirKoduId, "", yil, donem, ihbarNo, tahakkukTarihi, sonOdemeTarihi, bakiye, zam, toplam, "", "", paketId);
			Borc[] odenenBorclar = new Borc[1];
			odenenBorclar[0] = b;
			response = AsatNewClient.tahsilatKaydet(url, username, password, webIp, bankaKodu, subeKodu, trasnactionId, Long.valueOf(sicilNo), tahsilatTarihi, trasnactionId, bakiye, zam, toplam, odenenBorclar, sm);
			String responseCode = response.getMesajKodu();
			if(responseCode == null || "".equals(responseCode))
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter1(String.valueOf(sicilNo));
				invoicePayment.setParameter2(String.valueOf(gelirKoduId));
				invoicePayment.setParameter3(String.valueOf(paketId));
				invoicePayment.setParameter4(String.valueOf(bakiye));
				invoicePayment.setParameter5(String.valueOf(zam));
				invoicePayment.setParameter6(String.valueOf(ihbarNo));
				invoicePayment.setParameter7(CommonHelper.getShortDateTimeString(tahakkukTarihi.getTime()));
				invoicePayment.setParameter8(CommonHelper.getShortDateTimeString(sonOdemeTarihi.getTime()));
				invoicePayment.setParameter9(trasnactionId);
				invoicePayment.setParameter10(String.valueOf(response.getReferansNumarasi()));
				invoicePayment.setParameter11(tt);
				session.saveOrUpdate(invoicePayment);
			}
			
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ASAT_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASAT_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		AsatServiceMessage sm = new AsatServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String cancelTrasnactionId = CommonHelper.getNewTransactionNo();
			String paymentTransactionId = iMap.getString(MapKeys.PARAMETER_9, null);
			if (paymentTransactionId == null) {
				paymentTransactionId = iMap.getString(MapKeys.PARAMETER9);
			}
			
			String btt = iMap.getString(MapKeys.PARAMETER_11, null);
			if (btt == null) {
				btt = iMap.getString(MapKeys.PARAMETER11);
			}
			Calendar bankaTahsilatTarihi = CommonHelper.getCalendarWithYYYYMMDD(btt);
			
			String belediyeReferansNo = iMap.getString(MapKeys.PARAMETER_10, null);
			if (belediyeReferansNo == null) {
				belediyeReferansNo = iMap.getString(MapKeys.PARAMETER10);
			}
			
			builder.append(" ICS_ASAT_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Parameter9 -> ");
			builder.append(paymentTransactionId);
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | serviceUrl -> ");
			builder.append(url);
			logger.info(builder.toString());

			SorguSonucuBase response = AsatNewClient.tahsilatIptalEt(url, username, password, webIp, bankaKodu, subeKodu, cancelTrasnactionId, bankaTahsilatTarihi, paymentTransactionId, belediyeReferansNo, sm);;
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			String responseCode = response.getMesajKodu();
			if(responseCode == null || "".equals(responseCode))
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_ASAT_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));			
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_ASAT_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		AsatServiceMessage sm = new AsatServiceMessage();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASAT_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			builder.append(" ICS_ASAT_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | reconDate -> ");
			builder.append(reconDate);
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | serviceUrl -> ");
			builder.append(url);
			logger.info(builder.toString());
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			Calendar tarih = CommonHelper.getCalendarWithYYYYMMDD(reconDate);
			
			MutabakatOzetiSorguSonucu response = AsatNewClient.mutabakatOzetiSorgula(url, username, password, webIp, bankaKodu, subeKodu, tarih , sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			
			// aldigin sayilari koy
			logger.info("ICS_ASAT_COLLECTION_RECONCILIATION - response.getZPIFICABNKMUTABAKATResponse() null degil");
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getTahsilatTutari());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getTahsilatAdedi());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIptalTutari());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIptalAdedi());
			
				//tahsilat tutarlari
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 
				&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
				&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
				&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				logger.info("ICS_ASAT_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_ASAT_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ASAT_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_ASAT_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASAT_GET_COLLECTION_RECONCILIATION_DETAIL");
		AsatServiceMessage sm = new AsatServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new AsatReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_ASAT_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ASAT_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASAT_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_ASAT_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_ASAT_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		AsatServiceMessage sm = new AsatServiceMessage();		
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			long abone = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			
			SorguSonucuBase response = AsatNewClient.suAbonesiOtomatikOdemeTalimatiKaydetV2(url, username, password, webIp, bankaKodu, subeKodu, trasnactionId, abone, Calendar.getInstance(), sm);
			iMap.put("REQUEST_XML_TS", sm.getRequest());
			outMap.put("RESPONSE_XML_TS", sm.getResponse());	
			String responseCode = response.getMesajKodu();
			if(responseCode == null || "".equals(responseCode))
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_ASAT_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_ASAT_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		AsatServiceMessage sm = new AsatServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		
			long abone = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			
			SorguSonucuBase response = AsatNewClient.suAbonesiOtomatikOdemeTalimatiIptalEtV2(url, username, password, webIp, bankaKodu, subeKodu, trasnactionId, abone, Calendar.getInstance(), sm);
			iMap.put("REQUEST_XML_TS", sm.getRequest());
			outMap.put("RESPONSE_XML_TS", sm.getResponse());			
			String responseCode = response.getMesajKodu();
			if(responseCode == null || "".equals(responseCode))
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_ASAT_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ASAT_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();
			
			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				
				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_ASAT_INVOICE_DEBT_INQUIRY", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASAT_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("STO_ASAT_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ASAT_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		AsatServiceMessage sm = new AsatServiceMessage();
		try {
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			Calendar tarih = CommonHelper.getCalendarWithYYYYMMDD(reconDate);
			
			MutabakatOzetiSorguSonucuV2 response = AsatNewClient.mutabakatOzetiSorgulaV2(url, username, password, webIp, bankaKodu, subeKodu, tarih, sm);
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put(MapKeys.RECON_DATE, reconDate);
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			List<icsStandingOrders> bankCancelledStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

			outMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderList.size());
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelledStandingOrderList.size());
			outMap.put(MapKeys.RECON_CORPORATE_COUNT, response.getSuAbonesiOtomatikOdemeTalimatiKayitAdedi());
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, response.getSuAbonesiOtomatikOdemeTalimatiIptalAdedi());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_ASAT_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
}
