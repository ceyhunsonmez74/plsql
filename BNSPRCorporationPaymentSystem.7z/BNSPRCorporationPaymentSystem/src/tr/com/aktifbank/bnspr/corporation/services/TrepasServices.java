package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TrepasReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.trepas.ServiceMessage;
import tr.com.aktifbank.integration.trepas.TrepasClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.trepas.ZFICABNKINSDEBTDETAILResponse;
import tr.com.trepas.ZFICABNKINSDEBTResponse;
import tr.com.trepas.ZFICABNKINSMUTDETAILResponse;
import tr.com.trepas.ZFICABNKINSMUTResponse;
import tr.com.trepas.ZFICABNKINSPYMResponse;
import tr.com.trepas.ZFICABNKINSSRGResponse;
import tr.com.trepas.ZFICABNKINSYPResponse;
import tr.com.trepas.ZFICABNKMUTResponse;
import tr.com.trepas.ZFICABNKPYMCLRResponse;
import tr.com.trepas.ZFICABNKPYMResponse;
import tr.com.trepas.ZFICASBNKINSDEBTDETAILINV;
import tr.com.trepas.ZFICASBNKINSDEBTINV;
import tr.com.trepas.ZFICASTALIMATMTBKTDETAILS;
import tr.com.trepas.ZFICATTTALIMATMTBKTDETAILS;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TrepasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(TrepasServices.class);
	private static final String TALIMAT = "P";
	private static final String TALIMATIPTAL = "C";
	private static final String COLLECTIONMETHOD = "O";
	private static final String TALIMATAPPROVE = "ZFICA109";
	private static final String TALIMATSUCCESS = "ZFICA100";

	// 1. Bor� Sorgu Servisi
	// zFICABNKINSDEBT
	@GraymoundService("ICS_TREPAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_INVOICE_DEBT_INQUIRY");
		GMMap oMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		int counter = 0;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String contractAccountId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String cashPointRefNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			ZFICABNKINSDEBTResponse response = new ZFICABNKINSDEBTResponse();
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			response = TrepasClient.zFICABNKINSDEBT(serviceUrl, username, password, reqTimeout, connTimeout, serviceMessage, cashPointRefNo, contractAccountId);
			responseCode = response.getEMSGID();
			responseMessage = response.getEMSGTEXT();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (ZFICASBNKINSDEBTINV bill : response.getTLIST().getItem()) {
					SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
					Date date = inputFormat.parse(bill.getDUEDATE());
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date);
					
					
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bill.getCONTRACTACCOUNTID());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getOPENAMOUNT());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getINVOICEREFERENCEID());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, calendar.getTime());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getDUEDATE().substring(0, 4));
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getDUEDATE().substring(5, 7));
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getNAME1() + " " + bill.getNAME2());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, bill.getTEXT());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					oMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					oMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}

		}
		catch (Exception e) {
			logger.error("ICS_TREPAS_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// 2. Tahsilat Servisi
	// zFICABNKPYM
	@GraymoundService("ICS_TREPAS_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_DO_INVOICE_COLLECTION");
		ServiceMessage serviceMessage = new ServiceMessage();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String contractAccountId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String invoiceRefId = iMap.getString(MapKeys.INVOICE_NO);
			String cashPointPaymentGroupReferenceID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String txNo = iMap.getString(MapKeys.TRX_NO);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			String paymentAmountSTR = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			BigDecimal paymentAmount = new BigDecimal(paymentAmountSTR);
			String reportingCurrency = "TRY";

			String collectionDate = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				collectionDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			}
			else {
				collectionDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}

			String paymentGroupId = getUniqueNumberForDate(cashPointPaymentGroupReferenceID, collectionDate);
			String paymentTransactionId = getUniqueNumberForTxNo(cashPointPaymentGroupReferenceID, collectionDate, txNo);

			String channelCode = CommonHelper.getChannelId();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
				channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			}
			String sourceCode = iMap.getString(MapKeys.SOURCE);

			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			ZFICABNKPYMResponse response = new ZFICABNKPYMResponse();
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			response = TrepasClient.zFICABNKPYM(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, contractAccountId, invoiceRefId, paymentGroupId, paymentTransactionId, paymentAmount, collectionDate.toString(), paymentChannel);
			responseCode = response.getEMSGID();
			responseMessage = response.getEMSGTEXT();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(paymentTransactionId);
				session.saveOrUpdate(invoicePayment);
			}
		}
		catch (Exception e) {
			logger.error("ICS_TREPAS_DO_INVOICE_COLLECTION for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// 3. Tahsilat �ptal
	// zFICABNKPYMCLR
	@GraymoundService("ICS_TREPAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_SEND_COLLECTION_CANCEL_MESSAGE");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String paymentTransactionId = "";
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PARAMETER_2))) {
				paymentTransactionId = iMap.getString(MapKeys.PARAMETER_2);
			}
			else {
				paymentTransactionId = iMap.getString(MapKeys.PARAMETER2);
			}
			String revelsalValDate = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				revelsalValDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			}
			else {
				revelsalValDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}

			ZFICABNKPYMCLRResponse response = new ZFICABNKPYMCLRResponse();
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			response = TrepasClient.zFICABNKPYMCLR(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, paymentTransactionId, revelsalValDate.toString());
			responseCode = response.getEMSGID();
			responseMessage = response.getEMSGTEXT();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Exception e2) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// Mutabakat �zet Servisi
	@GraymoundService("ICS_TREPAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_COLLECTION_RECONCILIATION");

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String cashPointPaymentGroupReferenceID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			Date reconDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate = iMap.getDate(MapKeys.RECON_DATE);

			String groupInId = getUniqueNumberByDateForRecon(cashPointPaymentGroupReferenceID, reconDate); // Bulunulan g�ne �zel �retilen tekil de�er (16 karakter)

			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			// bizim taraftaki mutabakat parametreleri
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			ZFICABNKMUTResponse zFICABNKMUTResponse = null;

			zFICABNKMUTResponse = TrepasClient.zFICABNKMUT(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, groupInId, collectionCount, collectionTotal, cancelCount, cancelTotal);
			responseCode = zFICABNKMUTResponse.getEMSGID();
			responseMessage = zFICABNKMUTResponse.getEMSGTEXT();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			// extend'den getiriliyor bu metot.
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				// kurum taraftaki mutabakat parametreleri
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, zFICABNKMUTResponse.getEPAYAMOUNTCORP().subtract(zFICABNKMUTResponse.getEREVAMOUNTCORP()));
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, zFICABNKMUTResponse.getECOUNTERPAYCORP() - zFICABNKMUTResponse.getECOUNTERREVCORP());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, zFICABNKMUTResponse.getEREVAMOUNTCORP());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, zFICABNKMUTResponse.getECOUNTERREVCORP());

				if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).add(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL))) == 0 && oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).add(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT))) == 0 && oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
					oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else {
					oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			else {
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			// CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
		}
		catch (Throwable e) {
			logger.info("ICS_TREPAS_COLLECTION_RECONCILIATION - mutabakat hatali ");
			oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	// Mutabakat Detay Servisi
	@GraymoundService("ICS_TREPAS_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("ICS_TREPAS_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage serviceMessage = new ServiceMessage();

		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		
		try {

			CollectionReconciliationDetailBatch batch = new TrepasReconciliationDetailBatch(iMap, serviceMessage);
			oMap = batch.runBatch();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_TREPAS_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// Talimat �zet Mutabakat Servisi
    @GraymoundService("ICS_TREPAS_STANDING_ORDER_RECONCILIATION")
    public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
            GMMap output = new GMMap();

            iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_STANDING_ORDER_RECONCILIATION");
            String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
            String responseMessage = "";
            ServiceMessage serviceMessage = new ServiceMessage();
            int corpCancelCount = 0;
            int corpOrderCount = 0;
            String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
            ZFICABNKINSMUTResponse response = null;
            
            int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
            int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

            try {
	            GMMap rcInput = new GMMap();
	            rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
                rcInput.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
                GMMap sorMap = BedasCampaignServices.getBankStandingOrdersForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
                GMMap sorcMap = BedasCampaignServices.getBankStandingOrderCancelsForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
                int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
                int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);

                String instructionDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
                String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
                String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
                String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
                String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

                output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
                output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);

                try {
                    response = TrepasClient.zFICABNKINSMUT(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, instructionDate, String.valueOf(bankOrderCount), String.valueOf(bankCancelCount));
                    responseCode = response.getEMSGID();
                    responseMessage = response.getEMSGTEXT();
                }
                catch (Exception f) {
                    logger.error("TREPAS HATA:", f);
                    // FaultMessage kurum tarafindan gelen mant�ksal bir
                    // hata oldugu icin logluyoruz
                    logger.error("ICS_TREPAS_STANDING_ORDER_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
                    responseCode = serviceMessage.getResponseCode();
                    responseMessage = serviceMessage.getResponseMessage();
                    logger.info("ICS_TREPAS_STANDING_ORDER_RECONCILIATION error code = ".concat(responseCode));
                    logger.info("ICS_TREPAS_STANDING_ORDER_RECONCILIATION error message = ".concat(responseMessage));
                }

                iMap.put("REQUEST_XML", serviceMessage.getRequest());
                output.put("RESPONSE_XML", serviceMessage.getResponse());

                GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
                output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
                output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

                try {
                    corpCancelCount = Integer.parseInt(response.getECOUNTERREVINS());
                }
                catch (Exception e) {
                    corpCancelCount = 0;
                    logger.error("ICS_TREPAS_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi alinirken hata meydana geldi");
                }
                try {
                    corpOrderCount = Integer.parseInt(response.getECOUNTERINS());
                }
                catch (Exception e) {
                    corpOrderCount = 0;
                    logger.error("ICS_TREPAS_STANDING_ORDER_RECONCILIATION -> talimat sayisi alinirken hata meydana geldi");
                }


                
                output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
                output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);
                
                if (!responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
                    // // hata meydana geldi
                    logger.error("ICS_TREPAS_STANDING_ORDER_RECONCILIATION -> kurum web servisinde hata meydana geldi...");
                    output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
                    output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
                    output.put(MapKeys.RECON_BANK_COUNT, 0);
                    output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
                    responseCode = "3342";
                }
                else {
                    responseCode = GeneralConstants.ERROR_CODE_APPROVE;
                }



                output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
                output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);

                output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount - corpCancelCount);
                output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

                output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
                output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

            }
            catch (Throwable e) {
                responseCode = "3342";
                logger.error(System.currentTimeMillis(), e);
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
                output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
                output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
                throw ExceptionHandler.convertException(e);
            }
            finally {
                insertOnlineServiceLog(iMap, output);
            }
            return output;

    }


	// Talimat Detay Mutabakat Servisi
	@GraymoundService("ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {

		GMMap outMap = new GMMap();
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String collectionTypeId = "0";
		String TABLE_NAME = "RECON_DETAIL_DATA";
		String responseCode = "";
		String responseMessage = "";
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

		String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
		ServiceMessage serviceMessage = new ServiceMessage();
		ZFICABNKINSMUTDETAILResponse response = null;
		String instructionDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		// String instCount = iMap.getString(MapKeys.RECON_STANDINGORDER_COUNT) == null ? "0" : iMap.getString(MapKeys.RECON_STANDINGORDER_COUNT);
		// String cancCount = iMap.getString(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT) == null ? "0" : iMap.getString(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT);

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");

		try {

			try {
				response = TrepasClient.zFICABNKINSMUTDETAIL(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, instructionDate);
				responseCode = response.getEMSGID();
				responseMessage = response.getEMSGTEXT();
			}
			catch (Exception f) {
				logger.error("TREPAS HATA:", f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL ".concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL error code = ".concat(responseCode));
				logger.info("ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL error message = ".concat(responseMessage));
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				logger.info("...ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detaya girdi...");
				boolean found = true;
				GMMap bsorMap = BedasCampaignServices.getBankStandingOrdersDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
				GMMap bsorcMap = BedasCampaignServices.getBankStandingOrderCancelsDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);

				ZFICATTTALIMATMTBKTDETAILS corporateList = response.getTDETAILS();

				ArrayList corporateStandingOrderList = new ArrayList<ZFICATTTALIMATMTBKTDETAILS>();
				ArrayList corporateStandingOrderCancelList = new ArrayList<ZFICATTTALIMATMTBKTDETAILS>();

				for (int i = 0; i < corporateList.getItem().size(); i++) {
					String processType = corporateList.getItem().get(i).getPROCESSTYPE();

					if (processType.equals("P")) {
						corporateStandingOrderList.add(corporateList.getItem().get(i));
					}
					else if (processType.equals("C")) {
						corporateStandingOrderCancelList.add(corporateList.getItem().get(i));
					}
				}

				int bankOrderCount = bsorMap.getInt("DETAIL_COUNT");
				int bankOrderCancelCount = bsorcMap.getInt("DETAIL_COUNT");

				int corporateOrderCount = corporateStandingOrderList.size();
				int corporateOrderCancelCount = corporateStandingOrderCancelList.size();

				for (int i = 0; i < bankOrderCount; i++) {
					for (int j = 0; j < corporateOrderCount; j++) {
						if (bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1).equals(((ZFICASTALIMATMTBKTDETAILS) corporateStandingOrderList.get(j)).getCONTRACTACCOUNTID())) {

							found = true;// bizdeki talimat kaydi kurumda
							break; // bulundu
							//
						}
						else {
							found = false;// bizdeki talimat kaydi kurumda
											// bulunamadi
						}
					}
					//
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						}
						catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
					}
				}

				found = false;
				if (bankOrderCancelCount > corporateOrderCancelCount)
					for (int i = 0; i < bankOrderCancelCount; i++) {
						for (int j = 0; j < corporateOrderCancelCount; j++) {
							if (bsorMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1).equals(((ZFICATTTALIMATMTBKTDETAILS) corporateStandingOrderCancelList.get(j)).getItem().get(j).getCONTRACTACCOUNTID())) {
								found = true;
								break;
							}
							else {
								found = false;
							}
						}
						if (!found) {

							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							}
							catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent); //
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}

				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				insertOnlineServiceLog(iMap, outMap);

			}
			else {
				// detay mutabakat sirasinda hata olustu
				responseCode = "3422";
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				insertOnlineServiceLog(iMap, outMap);
			}
		}

		catch (Throwable e2) {
			logger.error("An exception occured while executing ICS_TREPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	// Mutabakat Yap Servisi
	@GraymoundService("ICS_TREPAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		ZFICABNKINSYPResponse response = null;
		ServiceMessage serviceMessage = new ServiceMessage();
		String responseCode = "";
		String responseMessage = "";
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_COLLECTION_RECONCILIATION_CLOSED");
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			Date reconDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate = iMap.getDate(MapKeys.RECON_DATE);

			String instructionDate = (new SimpleDateFormat("yyyy-MM-dd").format(reconDate));
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			String paymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			String cancelPaymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);

			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);

			try {
				response = TrepasClient.zFICABNKINSYP(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, instructionDate);
				responseCode = response.getEMSGID();
				responseMessage = response.getEMSGTEXT();
			}
			catch (Exception f) {
				logger.error("TREPAS HATA:", f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_TREPAS_COLLECTION_RECONCILIATION_CLOSED ".concat(" - an error is occured (Exception Message)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("ICS_TREPAS_COLLECTION_RECONCILIATION_CLOSED error code = ".concat(responseCode));
				logger.info("ICS_TREPAS_COLLECTION_RECONCILIATION_CLOSED error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
				output.put(MapKeys.ERROR_CODE, "660");
				output.put(MapKeys.ERROR_DESC, errorMessage);
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_TREPAS_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	public static void main(String[] args) {
		String number = "";
		String sequenceNumber = null;
		sequenceNumber = CommonHelper.fillCharacters(sequenceNumber, "0", 21, true);
		number = number.concat(sequenceNumber);
		System.out.println(number);
	}

	private static String getUniqueNumberForDate(String cashPointPaymentGroupReferenceID, String prmDate) {
		String number = "";
		try {
			// isPaymentTRX == false ise istenilen format -> E30 + Tarih + 001
			// isPaymentTRX == true ise istenilen format -> E30 + Tarih + 001 + "UNIQUE_DEGER" (35 haneye tamamlanacak)

			// Calendar cal = Calendar.getInstance();
			// Date date = cal.getTime();
			// SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
			String activeDate = prmDate.replace("-", "");// format1.format(date);
			number = cashPointPaymentGroupReferenceID + activeDate + "001";
			return number;

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return number;
	}

	private static String getUniqueNumberForTxNo(String cashPointPaymentGroupReferenceID, String prmDate, String txNo) {
		String number = "";
		try {
			// isPaymentTRX == false ise istenilen format -> E30 + Tarih + 001
			// isPaymentTRX == true ise istenilen format -> E30 + Tarih + 001 + "UNIQUE_DEGER" (35 haneye tamamlanacak)

			// Calendar cal = Calendar.getInstance();
			// Date date = cal.getTime();
			// SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
			String activeDate = prmDate.replace("-", "");// format1.format(date);
			number = cashPointPaymentGroupReferenceID + activeDate + "001";

			// String sequenceNumber = CorporationServiceUtil.getSequenceCode("ICS_TREPAS_TABLE");
			txNo = CommonHelper.fillCharacters(txNo, "0", 21, true);
			number = number.concat(txNo);
			return number;

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return number;
	}

	// mutabakat i�in tekil mutabakat g�n�ne �zel kod
	private static String getUniqueNumberByDateForRecon(String cashPointPaymentGroupReferenceID, Date reconDate) {
		String number = "";
		try {
			// istenilen format -> E30 + Tarih + 001

			SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
			String activeDate = format1.format(reconDate);
			number = cashPointPaymentGroupReferenceID + activeDate + "001";
			return number;
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return number;
	}

	// Talimat Bildirim
	@GraymoundService("ICS_TREPAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageTalimat = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String contractAccountId = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			if (sourceCode == null) {
				sourceCode = DatabaseConstants.SourceCodes.Account;
			}

			ZFICABNKINSSRGResponse responseSorgu = new ZFICABNKINSSRGResponse();

			String responseCodeSorgu = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessageSorgu = "";

			responseSorgu = TrepasClient.zFICABNKINSSRG(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, contractAccountId);

			responseCodeSorgu = responseSorgu.getEMSGID();
			responseMessageSorgu = responseSorgu.getEMSGTEXT();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMapSorgu = getResponseCodeMapping(responseCodeSorgu, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			String errorCode = responceCodeMapSorgu.getString(MapKeys.ERROR_CODE);
//			oMap.put(MapKeys.ERROR_CODE, responceCodeMapSorgu.getString(MapKeys.ERROR_CODE));
//			oMap.put(MapKeys.ERROR_DESC, responceCodeMapSorgu.getString(MapKeys.ERROR_DESC));
//			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMapSorgu.getString("RETURN_CODE_DESC"));
//			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL); 
			
			if(responseCodeSorgu.equals(TALIMATSUCCESS)){
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				oMap.put(MapKeys.ERROR_DESC, "Talimat mevcut");
				oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			}
			
			ZFICABNKINSPYMResponse response = null;
			if (responseCodeSorgu.equals(TALIMATAPPROVE)){//GeneralConstants.ERROR_CODE_APPROVE)) {
				oMap.put(MapKeys.ACCOUNT_NO, responseSorgu.getECONTRACTACCOUNTID());
				oMap.put(MapKeys.NAME, responseSorgu.getENAME1());
				oMap.put(MapKeys.SURNAME, responseSorgu.getENAME2());
				oMap.put(MapKeys.BANK_CODE, responseSorgu.getEBANKCODE());
				oMap.put("COLLECTION_METHOD", responseSorgu.getECOLLECTIONMETHOD());
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				String nameSurname = responseSorgu.getENAME1() + " " + responseSorgu.getENAME2();
				// if(){
				String processType = TALIMAT;
				String collectionMethod = "O";
				response = TrepasClient.zFICABNKINSPYM(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageTalimat, cashPointRefId, processType, collectionMethod, contractAccountId, nameSurname);
				iMap.put("REQUEST_XML_TALIMAT", serviceMessageTalimat.getRequest());
				oMap.put("RESPONSE_XML_TALIMAT", serviceMessageTalimat.getResponse());
				// }
				GMMap responceCodeMapTalimat = getResponseCodeMapping(response.getEMSGID(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMapTalimat.getString(MapKeys.ERROR_CODE);
				oMap.put(MapKeys.ERROR_CODE, responceCodeMapTalimat.getString(MapKeys.ERROR_CODE));
				oMap.put(MapKeys.ERROR_DESC, responceCodeMapTalimat.getString(MapKeys.ERROR_DESC));
				oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMapTalimat.getString(MapKeys.ERROR_DESC));
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			}

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

		}
		catch (Exception e2) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	// Talimat �ptal
	@GraymoundService("ICS_TREPAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageTalimatIptal = new ServiceMessage();
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String contractAccountId = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			String sourceCode = iMap.getString(MapKeys.SOURCE);
			if (sourceCode == null) {
				sourceCode = DatabaseConstants.SourceCodes.Account;
			}

			ZFICABNKINSSRGResponse responseSorgu = new ZFICABNKINSSRGResponse();

			String responseCodeSorgu = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessageSorgu = "";

			responseSorgu = TrepasClient.zFICABNKINSSRG(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, contractAccountId);

			responseCodeSorgu = responseSorgu.getEMSGID();
			responseMessageSorgu = responseSorgu.getEMSGTEXT();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMapSorgu = getResponseCodeMapping(responseCodeSorgu, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			String errorCode = responceCodeMapSorgu.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMapSorgu.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMapSorgu.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMapSorgu.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			ZFICABNKINSPYMResponse response = null;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				oMap.put(MapKeys.ACCOUNT_NO, responseSorgu.getECONTRACTACCOUNTID());
				oMap.put(MapKeys.NAME, responseSorgu.getENAME1());
				oMap.put(MapKeys.SURNAME, responseSorgu.getENAME2());
				oMap.put(MapKeys.BANK_CODE, responseSorgu.getEBANKCODE());
				oMap.put("COLLECTION_METHOD", responseSorgu.getECOLLECTIONMETHOD());
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				String nameSurname = responseSorgu.getENAME1() + " " + responseSorgu.getENAME2();
				// if(){
				String processType = TALIMATIPTAL;
				String collectionMethod = "O";
				response = TrepasClient.zFICABNKINSPYM(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageTalimatIptal, cashPointRefId, processType, collectionMethod, contractAccountId, nameSurname);
				iMap.put("REQUEST_XML_TALIMAT_IPTAL", serviceMessageTalimatIptal.getRequest());
				oMap.put("RESPONSE_XML_TALIMAT_IPTAL", serviceMessageTalimatIptal.getResponse());
				// }
				GMMap responceCodeMapTalimat = getResponseCodeMapping(response.getEMSGID(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMapTalimat.getString(MapKeys.ERROR_CODE);
				oMap.put(MapKeys.ERROR_CODE, responceCodeMapTalimat.getString(MapKeys.ERROR_CODE));
				oMap.put(MapKeys.ERROR_DESC, responceCodeMapTalimat.getString(MapKeys.ERROR_DESC));
				oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMapTalimat.getString(MapKeys.ERROR_DESC));
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			}

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

		}
		catch (Exception e2) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	// Talimat Bor� Sorgu
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_TREPAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TREPAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		ZFICABNKINSDEBTDETAILResponse response = null;
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashPointRefId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String date = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				date = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			}
			else {
				date = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}

			// XMLGregorianCalendar dueDate= stringToXMLGregorianCalendar(date, "yyyy-MM-dd");

			response = TrepasClient.zFICABNKINSDEBTDETAIL(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, date);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(response.getEMSGID(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

				GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
				int counter = 0;
				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
				for (int i = 0; i < bankStandingOrderList.size(); i++) {
					icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
					if (icsStandingOrder.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
						String subscriberNo = CommonHelper.trimStart(icsStandingOrder.getSubscriberNo1(), '0');
						for (ZFICASBNKINSDEBTDETAILINV corpData : response.getTLIST().getItem()) {
							String s1 = CommonHelper.trimStart(corpData.getCONTRACTACCOUNTID(), '0');
							if (s1.equals(subscriberNo)) {
								
								Date inDueDate = CommonHelper.getDateTime(corpData.getDUEDATE(), "yyyy-MM-dd");
								String invoiceDueDate = CommonHelper.getShortDateTimeString(inDueDate);		
								
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, s1);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, corpData.getINVOICEREFERENCEID());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.BANK_CODE, corpData.getBANKCODE());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, corpData.getOPENAMOUNT());
//								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, corpData.getDUEDATE());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, corpData.getTEXT());				
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, corpData.getNAME1()+" "+corpData.getNAME2());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, corpData.getDUEDATE().substring(0, 4));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, corpData.getDUEDATE().substring(5, 7));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, 0);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, 0);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, corpData.getOPENAMOUNT());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
								
							}
						}
					}
				}
				outMap.put(MapKeys.TABLE_SIZE, counter);
				outMap.put(MapKeys.RESPONSE_CODE, responseCode);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
			// }
		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TREPAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

		try {
			Date date = CommonHelper.getDateTime(datetime, dateFormat);
			GregorianCalendar cal = (GregorianCalendar) GregorianCalendar.getInstance();
			cal.setTime(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);

		}
		catch (Exception e) {

			System.out.print(e.getMessage());

			return null;

		}
	}
}
