package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.MuglaReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.MuglaClient;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.mugla.BgsBorcSorguShortDto;
import tr.com.mugla.BgsTahakDto;
import tr.com.mugla.BgsTahsilDto;
import tr.com.mugla.BgsTahsilKaydiDto;
import tr.com.mugla.FindAllBorcSorguResponse;
import tr.com.mugla.FindBorcSorguResponse;
import tr.com.mugla.TahsilIcmaliResponse;
import tr.com.mugla.TahsilKaydiIptalEtResponse;
import tr.com.mugla.TahsilKaydiOlusturResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class MuglaServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(EdasServices.class);

	@GraymoundService("ICS_MUGLA_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		try {
			// parameters are taken
			String sbsMuhatabId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String beyanId = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			// logger info will be logged
			builder.append(" ICS_MUGLA_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Sicil Numarasi -> ");
			builder.append(sbsMuhatabId);
			builder.append(" | beyanId -> ");
			builder.append(beyanId);
			builder.append(" | UserName -> ");
			builder.append(applicationKey);
			builder.append(" | Password -> ");
			builder.append(securityCode);
			builder.append(" | URL -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MuglaClient.findAllSbsMuhatapGenel(...) will be called..."));
			
			FindBorcSorguResponse response = MuglaClient.findBorcSorgu(serviceUrl, applicationKey, securityCode, sbsMuhatabId, null, null, null, null, null, beyanId, sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MuglaClient.findBorcSorgu(...) returned response code ".concat(response.getResultCode())));
			
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MuglaClient.findBorcSorgu(...) returned errorCode ".concat(errorCode)));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Map<String,Integer> termGroupList = new HashMap<String, Integer>();
				int groupCounter = 1;
				
				for ( BgsTahakDto borc : response.getBgsBorcSorguDto().getListBgsTahakDto()) {
					if (!isCollectedInvoice(String.valueOf(borc.getBgsTahakId()), sbsMuhatabId, beyanId, "", "", corporateCode)) {
						
						String faturaNo = borc.getFaturNo();
						String groupId = "";
						if(termGroupList.containsKey(faturaNo)){
							groupId = String.valueOf(termGroupList.get(faturaNo));
						}
						else{
							groupId = String.valueOf(groupCounter++);
							termGroupList.put(faturaNo, Integer.valueOf(groupId));
						}
						
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, sbsMuhatabId);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, beyanId);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getBgsTahakId());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorcTutari().add(borc.getGecikmeZammi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getIsim());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getVadeTarihi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getYil());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getDonem());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorcTutari().add(borc.getGecikmeZammi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, sbsMuhatabId);
						outMap.put(MapKeys.INVOICE_LIST, counter, "GROUP_ID", groupId);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MuglaClient.findBorcSorgu(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_MUGLA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}

	@GraymoundService("ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL")
	public static GMMap debtInqueryAll(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		try {
			// parameters are taken
			String beyanId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			// logger info will be logged
			builder.append(" ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | beyanId -> ");
			builder.append(beyanId);
			builder.append(" | UserName -> ");
			builder.append(applicationKey);
			builder.append(" | Password -> ");
			builder.append(securityCode);
			builder.append(" | URL -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL for ".concat(corporateCode).concat(" - MuglaClient.findAllSbsMuhatapGenel(...) will be called..."));
			
			FindAllBorcSorguResponse response = MuglaClient.findAllBorcSorgu(serviceUrl, applicationKey, securityCode, beyanId, sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL for ".concat(corporateCode).concat(" - MuglaClient.findBorcSorgu(...) returned response code ".concat(response.getResultCode())));
			
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL for ".concat(corporateCode).concat(" - MuglaClient.findBorcSorgu(...) returned errorCode ".concat(errorCode)));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Map<String,Integer> termGroupList = new HashMap<String, Integer>();
				int groupCounter = 1;
				
				for ( BgsBorcSorguShortDto borc : response.getBgsBorcSorguShortDtos()) {
					if (!isCollectedInvoice(String.valueOf(borc.getFaturaNo()), beyanId, "", "", "", corporateCode)) {
						
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, beyanId);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getFaturaNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplamBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getIsim());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getVadeTarihi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, CommonHelper.getYear(borc.getVadeTarihi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, CommonHelper.getMonth(borc.getVadeTarihi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplamBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getBgsTahakIdList().toString());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL for ".concat(corporateCode).concat(" - MuglaClient.findBorcSorgu(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_MUGLA_INVOICE_DEBT_INQUIRY_ALL for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}

	@GraymoundService("ICS_MUGLA_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		try {
			// parameters are taken
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String vezneSifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Long tahakkukNo = iMap.getLong(MapKeys.INVOICE_NO);
			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_MUGLA_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | Tahakkuk No -> ");
			builder.append(tahakkukNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			logger.info(builder.toString());

			if (isStandingOrderCollection) {
				logger.info("ICS_MUGLA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - MuglaClient.tahsilKaydiOlustur(...) before call..").concat("isStandingOrderCollection:true"));
			}else{
				logger.info("ICS_MUGLA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - MuglaClient.tahsilKaydiOlustur(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			ServiceMessage sm = new ServiceMessage();
			BgsTahsilKaydiDto tahsilKaydiDto = new BgsTahsilKaydiDto();
			tahsilKaydiDto.setBtsVezneId(Long.valueOf(vezneId));
			tahsilKaydiDto.setBtsVezneSifre(vezneSifre);			
			tahsilKaydiDto.setTahsilTarihi(new SimpleDateFormat("yyyy-MM-dd").parse(tahsilatTarihi));
			List<BgsTahsilDto> listBgsTahsilDto = new ArrayList<BgsTahsilDto>();
			BgsTahsilDto tahsilDto = new BgsTahsilDto();
			tahsilDto.setBgsTahakId(tahakkukNo);
			listBgsTahsilDto.add(tahsilDto );
			tahsilKaydiDto.setListBgsTahsilDto(listBgsTahsilDto );			
			TahsilKaydiOlusturResponse response = MuglaClient.tahsilKaydiOlustur(serviceUrl, applicationKey, securityCode, tahsilKaydiDto , sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			
			responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && response.getListBgsTahsilSonucMakbuzDto().size() > 0) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(String.valueOf(response.getListBgsTahsilSonucMakbuzDto().get(0).getBgsTahsilGenelId()));
				session.saveOrUpdate(invoicePayment);
			}
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			logger.info("ICS_MUGLA_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - MuglaClient.tahsilKaydiOlustur(...) returned errorCode ".concat(response.getResultCode())));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_MUGLA_DO_INVOICE_COLLECTION_BY_INVOICE")
	public static GMMap doINvoiceCollectionbyInvoice(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		try {
			// parameters are taken
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String vezneSifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			BigDecimal toplamTutar = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			System.out.println(new SimpleDateFormat("yyyy-MM-dd").parse(tahsilatTarihi).toGMTString());
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_MUGLA_DO_INVOICE_COLLECTION_BY_INVOICE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | Fatura No -> ");
			builder.append(faturaNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			logger.info(builder.toString());

			if (isStandingOrderCollection) {
				logger.info("ICS_MUGLA_DO_INVOICE_COLLECTION_BY_INVOICE for ".concat(corporateCode).concat(" - MuglaClient.tahsilKaydiOlustur(...) before call..").concat("isStandingOrderCollection:true"));
			}else{
				logger.info("ICS_MUGLA_DO_INVOICE_COLLECTION_BY_INVOICE for ".concat(corporateCode).concat(" - MuglaClient.tahsilKaydiOlustur(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			ServiceMessage sm = new ServiceMessage();
			BgsTahsilKaydiDto bgsTahsilKaydiDto = new BgsTahsilKaydiDto();
			bgsTahsilKaydiDto.setBtsVezneId(Long.valueOf(vezneId));
			bgsTahsilKaydiDto.setBtsVezneSifre(vezneSifre);			
			bgsTahsilKaydiDto.setTahsilTarihi(new SimpleDateFormat("yyyy-MM-dd").parse(tahsilatTarihi));
			bgsTahsilKaydiDto.setFaturaNo(faturaNo);
			bgsTahsilKaydiDto.setIslemNo(p_sIslemReferansNo);
			bgsTahsilKaydiDto.setToplamTutar(toplamTutar);
			TahsilKaydiOlusturResponse response = MuglaClient.tahsilKaydiOlusturByFatura(serviceUrl, applicationKey, securityCode, bgsTahsilKaydiDto , sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			
			responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && response.getListBgsTahsilSonucMakbuzDto().size() > 0) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(String.valueOf(response.getListBgsTahsilSonucMakbuzDto().get(0).getBgsTahsilGenelId()));
				session.saveOrUpdate(invoicePayment);
			}
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			logger.info("ICS_MUGLA_DO_INVOICE_COLLECTION_BY_INVOICE FOR ".concat(corporateCode).concat(" - MuglaClient.tahsilKaydiOlustur(...) returned errorCode ".concat(response.getResultCode())));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String aboneNo = iMap.getString("SUBSCRIBER_NO_1", null);
			if (aboneNo == null) {
				aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}
			
			String bgsTahsilGenelId = iMap.getString(MapKeys.PARAMETER_2, null);
			if (bgsTahsilGenelId == null) {
				bgsTahsilGenelId = iMap.getString(MapKeys.PARAMETER2);
			}
			
			builder.append(" ICS_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis No -> ");
			builder.append(bgsTahsilGenelId);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			builder.append(" | serviceUrl -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			TahsilKaydiIptalEtResponse response = MuglaClient.tahsilKaydiIptalEt(serviceUrl, applicationKey, securityCode, vezneId, bgsTahsilGenelId, sm);
						
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response.getResultCode()));
			
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_MUGLA_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_MUGLA_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(reconDate);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			builder.append(" | End Point -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());
			
			ServiceMessage sm = new ServiceMessage();
			TahsilIcmaliResponse response = MuglaClient.tahsilIcmali(serviceUrl, applicationKey, securityCode, reconDate, vezneId, sm);
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());

			if (response.getBgsTahsilIcmalDto() == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_MUGLA_COLLECTION_RECONCILIATION - result size 0 geldi");

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_MUGLA_COLLECTION_RECONCILIATION - response.getBgsTahsilIcmalDto() null degil");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getBgsTahsilIcmalDto().getTahsilEdilenTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getBgsTahsilIcmalDto().getTahsilAdedi());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getBgsTahsilIcmalDto().getIptalEdilenTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getBgsTahsilIcmalDto().getIptalAdedi());
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_MUGLA_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_MUGLA_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_MUGLA_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_MUGLA_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new MuglaReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_MUGLA_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_MUGLA_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MUGLA_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
}
