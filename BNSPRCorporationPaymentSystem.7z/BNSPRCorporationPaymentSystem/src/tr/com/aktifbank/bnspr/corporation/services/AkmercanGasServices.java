package tr.com.aktifbank.bnspr.corporation.services;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.akmercangaz.AkmercanGazClient;
import tr.com.aktifbank.integration.akmercangaz.IParameters.IBorcSorgula;
import tr.com.aktifbank.integration.akmercangaz.IParameters.ITahsilatMutabakatToplu;
import tr.com.aktifbank.integration.akmercangaz.IParameters.ITahsilatMutabakatYekun;
import tr.com.aktifbank.integration.akmercangaz.IParameters.ITalimatMutabakatDetay;
import tr.com.aktifbank.integration.akmercangaz.IParameters.ITalimatMutabakatSayi;
import tr.com.aktifbank.integration.akmercangaz.IParameters.ITalimatliBorcSorgu;
import tr.com.aktifbank.integration.akmercanusta.AkmercanUstaClient;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * PARAMETER6 = 1 (IS_USTA) --> Akmercan Usta Entegrasyonu indicatoru.
 * 
 * @author murat.bayram
 *
 */
public class AkmercanGasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	
//	private static String clientID = "aktifbank";
	private static String REC_RECORD_KEY = "GIRIS";
	private static String REC_CANCEL_KEY = "IPTAL";
	private static String ACTIVE_STANDING_ORDERS_KEY = "Aktif";
	private static String CANCELLED_STANDING_ORDERS_KEY = "Inaktif";
	private static String ALL_STANDING_ORDERS_GET_KEY = "";
	private static String ERROR_CODE_FAIL = "1";
	private static String ERROR_CODE_NO_RECORD = "2";
	
	
	@GraymoundService("ICS_AKMERCANGAZ_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		
		try {
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			List<Map<String, String>> borcList;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				borcList = AkmercanUstaClient.borcSorgula(aboneNo, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));	
			}else {
				borcList = AkmercanGazClient.borcSorgula(aboneNo, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}
			
			if (borcList == null) {
				responseCode = ERROR_CODE_NO_RECORD;
			}else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				String subscriberName = "";
				List<Map<String,String>> nameSurname = AkmercanGazClient.searchCustomer(clientID, "", "", aboneNo, "1", iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
				if(nameSurname != null && nameSurname.size() > 0){
					Map<String, String> nameMap = nameSurname.get(0);
					if(nameMap != null){
						subscriberName = nameMap.get("FIELD2");
					}
				}
				for(Map<String, String> borc : borcList){
					if(!isCollectedInvoice(borc.get(IBorcSorgula.BELGE_NO), borc.get(IBorcSorgula.ABONE_NO),"","","", corporateCode)){
						String termYear = borc.get(IBorcSorgula.SON_ODEME_TARIHI).split(" ")[0].split("\\.")[2]; //e.g. 18.10.2013 00:00:00
						String termMonth = borc.get(IBorcSorgula.SON_ODEME_TARIHI).split(" ")[0].split("\\.")[1]; //e.g. 18.10.2013 00:00:00
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.get(IBorcSorgula.ABONE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.get(IBorcSorgula.BELGE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.get(IBorcSorgula.TUTAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, subscriberName);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.get(IBorcSorgula.SON_ODEME_TARIHI).split(" ")[0], "dd.MM.yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.get(IBorcSorgula.TUTAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, borc.get(IBorcSorgula.TAKSIT_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.get(IBorcSorgula.ISLEM_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, borc.get(IBorcSorgula.ISLEM_KODU));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borc.get(IBorcSorgula.PB_KOD));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borc.get(IBorcSorgula.TAKSIT_KOD));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}	
				}
			}
			
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_AKMERCANGAZ_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_DO_INVOICE_COLLECTION");
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String tutar = iMap.getString(MapKeys.INVOICE_AMOUNT);
			String islemNo = iMap.getString(MapKeys.PARAMETER1);
			String islemKodu = iMap.getString(MapKeys.PARAMETER2);
			String pbKodu = iMap.getString(MapKeys.PARAMETER3);
			String taksitKodu = iMap.getString(MapKeys.PARAMETER4);
			String paymentDate;
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))){
				paymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd.MM.yyyy");
			}else{
				paymentDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			}
			
			if(!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")){
				String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				/*
				 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
				 * Bu durumda Usta clientina gidilerek cagri yapilir.
				 */
				boolean returnCode;
				if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
					returnCode = AkmercanUstaClient.tahsilat(aboneNo, tahakkukNo, islemKodu, tutar, pbKodu, paymentDate, islemNo, taksitKodu, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
				}else {
					returnCode = AkmercanGazClient.tahsilat(aboneNo, tahakkukNo, islemKodu, tutar, pbKodu, paymentDate, islemNo, taksitKodu, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
				}
				
				if(returnCode){
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}else{
					responseCode = ERROR_CODE_FAIL;
				}
				
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_AKMERCANGAZ_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String tutar = iMap.getString(MapKeys.INVOICE_AMOUNT);
			String islemNo = iMap.getString("PARAMETER_1", null); if(StringUtil.isEmpty(islemNo)){islemNo = iMap.getString(MapKeys.PARAMETER1);}
			String islemKodu = iMap.getString("PARAMETER_2", null); if(StringUtil.isEmpty(islemKodu)){islemKodu = iMap.getString(MapKeys.PARAMETER2);}
			String taksitKodu = iMap.getString("PARAMETER_4", null); if(StringUtil.isEmpty(taksitKodu)){taksitKodu = iMap.getString(MapKeys.PARAMETER4);}
			String paymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd.MM.yyyy");
			String aboneNo = iMap.getString("SUBSCRIBER_NO_1", null); if (StringUtil.isEmpty(aboneNo)){	aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);}
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			boolean returnCode;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				returnCode = AkmercanUstaClient.tahsilatIptal(aboneNo, tahakkukNo, islemKodu, tutar, paymentDate, islemNo, taksitKodu, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				returnCode = AkmercanGazClient.tahsilatIptal(aboneNo, tahakkukNo, islemKodu, tutar, paymentDate, islemNo, taksitKodu, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)); 
			}

			if(returnCode){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode = ERROR_CODE_FAIL;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_AKMERCANGAZ_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_AKMERCANGAZ_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String orderDate;
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.CREATE_DATE))){
				orderDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.CREATE_DATE), "yyyyMMddhhmmss"), "dd.MM.yyyy");
			}else{
				orderDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			}
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			boolean returnCode;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				returnCode = AkmercanUstaClient.talimat(aboneNo, orderDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				returnCode = AkmercanGazClient.talimat(aboneNo, orderDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)); 
			}

			if(returnCode){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode = ERROR_CODE_FAIL;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_AKMERCANGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_AKMERCANGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String orderCancelDate;
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.CANCEL_DATE))){
				orderCancelDate = iMap.getString(MapKeys.CANCEL_DATE);
			}else{
				orderCancelDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			}
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			boolean returnCode;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				returnCode = AkmercanUstaClient.talimatIptal(aboneNo, orderCancelDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				returnCode = AkmercanGazClient.talimatIptal(aboneNo, orderCancelDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)); 
			}

			if(returnCode){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode = ERROR_CODE_FAIL;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_AKMERCANGAZ_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_AKMERCANGAZ_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd.MM.yyyy");
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			List<Map<String,String>> returnValues;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				returnValues = AkmercanUstaClient.talimatMutabakatDetay(reconDate, ALL_STANDING_ORDERS_GET_KEY, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				returnValues = AkmercanGazClient.talimatMutabakatDetay(reconDate, ALL_STANDING_ORDERS_GET_KEY, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}
			
			List<Map<String,String>> corpStandingOrderList = new ArrayList<Map<String,String>>();
			List<Map<String,String>> corpStandingOrderCancelList = new ArrayList<Map<String,String>>();
			
			if (returnValues == null) {
				if(iMap.getInt(MapKeys.RECON_CORPORATE_COUNT) == 0 && iMap.getInt(MapKeys.RECON_CORPORATE_CANCEL_COUNT) == 0){
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					returnValues = new ArrayList<Map<String,String>>();
				}
				else{
					responseCode = ERROR_CODE_FAIL;
				}
			}else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for(Map<String, String> value : returnValues){
					outMap.put(MapKeys.SUBSCRIBER_NO1, value.get(ITalimatMutabakatDetay.ABONE_NO));
					if(ACTIVE_STANDING_ORDERS_KEY.equals(value.get(ITalimatMutabakatDetay.DURUM))){
						corpStandingOrderList.add(value);
					}else if(CANCELLED_STANDING_ORDERS_KEY.equals(value.get(ITalimatMutabakatDetay.DURUM))){
						corpStandingOrderCancelList.add(value);
					}
				}

				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
				GMMap listMap = new GMMap();
				listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
	
				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST");
				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderCancelList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

				//LIST hepsini donuyor. Bu kurumda sadece aktivelerin karsilastirilmasi yapilacak.
				//Son degisikliklerle LIST_ACTIVE donuyor oradan da alinabilir.
				bankStandingOrderList.removeAll(bankStandingOrderCancelList);

				boolean found = false;
				if (bankStandingOrderList.size() > corpStandingOrderList.size()) {
					short collectionType = 0;
					for (int j=0; j < bankStandingOrderList.size(); j++) {
						for (int i = 0; i < corpStandingOrderList.size(); i++) {
							if (bankStandingOrderList.get(j).getSubscriberNo1().equals(corpStandingOrderList.get(i).get(ITalimatMutabakatDetay.ABONE_NO))) {
								collectionType = bankStandingOrderList.get(j).getCollectionType();
								found = true;
								corpStandingOrderList.remove(i);
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.CREATE_DATE, bankStandingOrderList.get(j).getCreateDate());
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				} else { 
					
					short collectionType = 0;
					
					for (int j=0; j < corpStandingOrderList.size(); j++) {
						for (int i = 0; i < bankStandingOrderList.size(); i++) {
							if (corpStandingOrderList.get(j).get(ITalimatMutabakatDetay.ABONE_NO).equals(bankStandingOrderList.get(i).getSubscriberNo1())) {
								found = true;
								bankStandingOrderList.remove(i);
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat iptal istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, corpStandingOrderList.get(j).get(ITalimatMutabakatDetay.ABONE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_DATE, CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd.MM.yyyy"));
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat Iptal Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, corpStandingOrderList.get(j).get(ITalimatMutabakatDetay.ABONE_NO));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				}
			}
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_AKMERCANGAZ_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_AKMERCANGAZ_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = "";
			String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd.MM.yyyy");
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			List<Map<String,String>> returnValues;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				returnValues = AkmercanUstaClient.talimatMutabakatSayi(reconDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				returnValues = AkmercanGazClient.talimatMutabakatSayi(reconDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}
			
			if (returnValues == null) {
				responseCode = ERROR_CODE_FAIL;
			}else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				int talimatSayisi = 0;
				int talimatIptalSayisi = 0;
				
				for(Map<String, String> value : returnValues){
					if(REC_RECORD_KEY.equals(value.get(ITalimatMutabakatSayi.ISLEM))){
						talimatSayisi = Integer.parseInt(value.get(ITalimatMutabakatSayi.SAYI));
						continue;
					}
					if(REC_CANCEL_KEY.equals(value.get(ITalimatMutabakatSayi.ISLEM))){
						talimatIptalSayisi = Integer.parseInt(value.get(ITalimatMutabakatSayi.SAYI));
						continue;
					}
				}
				
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, talimatSayisi);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, talimatIptalSayisi);
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));

				GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
	
				int bankReconCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT) + 
						rcOutput.getInt("CANCEL_COUNT");
				
				outMap.put(MapKeys.RECON_BANK_COUNT, bankReconCount);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.CANCEL_COUNT));
			} else {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_AKMERCANGAZ_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd.MM.yyyy");
			String responseCode="";
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			List<Map<String,String>> tahsilatList;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				tahsilatList = AkmercanUstaClient.mutabakatSorgulamaToplu(tarih, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				tahsilatList = AkmercanGazClient.mutabakatSorgulamaToplu(tarih, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}
			
			if (tahsilatList == null) {
				if(iMap.getInt(MapKeys.RECON_CORPORATE_COUNT) == 0){
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					tahsilatList = new ArrayList<Map<String,String>>();
				}
				else{
					responseCode = ERROR_CODE_FAIL;
				}
			}else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
			
				int tahsilatListLength = tahsilatList.size() - 1; // Son Element olarak Toplam tutari gonderiyor.
					
				for (int i = 0; i < tahsilatListLength; i++) {
						Map<String, String> tahsilat = tahsilatList.get(i);
						reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, tahsilat.get(ITahsilatMutabakatToplu.ABONE_NO));
						reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, tahsilat.get(ITahsilatMutabakatToplu.TUTAR));
						reconCorpAmountMap.put("CORPORATE", i, MapKeys.INVOICE_NO, tahsilat.get(ITahsilatMutabakatToplu.BELGE_NO));
						reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_DATE, tahsilat.get(ITahsilatMutabakatToplu.TARIH));
						// hibenate ile kay�t etmece
				}
	
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
				int corporateCollectionCount = tahsilatListLength;
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
	
				boolean found = false;
				if (bankCollectionCount > corporateCollectionCount) {
					short collectionType = 0;
					for (int j = 0; j < bankCollectionCount; j++) {
						for (int i = 0; i < corporateCollectionCount; i++) {
							if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(
									reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))
									&& reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO).equals(
											reconCorpAmountMap.getString("CORPORATE", i, MapKeys.INVOICE_NO))
									&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(
											reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
								found = true;
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap request = new GMMap();
							request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
							request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
							request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
							request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
							request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
							request.put(MapKeys.CORPORATE_CODE, corporateCode);
							request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, request.getString(MapKeys.PARAMETER5));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, request.getString(MapKeys.PARAMETER6));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER7, request.getString(MapKeys.PARAMETER7));
							onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
	
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							} catch (Exception e) {
								// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
								e.printStackTrace();
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
							}
	
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
							}
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,request.getString(MapKeys.PARAMETER3));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,request.getString(MapKeys.PARAMETER4));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5,request.getString(MapKeys.PARAMETER5));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6,request.getString(MapKeys.PARAMETER6));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7,request.getString(MapKeys.PARAMETER7));
						
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				} else {
					short collectionType = 0;
					for (int j = 0; j < corporateCollectionCount; j++) {
						for (int k = 0; k < bankCollectionCount; k++) {
							if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(
									reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))
									&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO).equals(
											reconBankMap.getString("BANK", k, MapKeys.INVOICE_NO))
									&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(
											reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
								found = true;
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat iptal istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap request = new GMMap();
							request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
//							request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
							request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
							request.put(MapKeys.INVOICE_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO));
							request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, request.getString(MapKeys.PARAMETER5));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, request.getString(MapKeys.PARAMETER6));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER7, request.getString(MapKeys.PARAMETER7));
							onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("CORPORATE", j, MapKeys.INSTALLMENT_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
	
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							} catch (Exception e) {
								// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
								e.printStackTrace();
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
							}
	
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
										onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
							}
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
										onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
	
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);																										
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,request.getString(MapKeys.PARAMETER3));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,request.getString(MapKeys.PARAMETER4));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5,request.getString(MapKeys.PARAMETER5));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6,request.getString(MapKeys.PARAMETER6));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7,request.getString(MapKeys.PARAMETER7));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
	
						}
					}
				}
			}
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_AKMERCANGAZ_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			//Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
//				String processDate = CommonHelper.getShortDateTimeString(new Date());

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
			
				outMap.putAll(onlineCorporateServiceCallOutputMap);
			}
			
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;

	}

	@GraymoundService("ICS_AKMERCANGAZ_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd.MM.yyyy");
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			Map<String, String> returnValues;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				returnValues = AkmercanUstaClient.mutabakatSorgulamaYekun(tarih, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				returnValues = AkmercanGazClient.mutabakatSorgulamaYekun(tarih, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}
			
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			//Tahsilat olmadiginda veya iptal edildiginde hic bir cevap donmuyor.
			if (returnValues == null) {
				responseCode = ERROR_CODE_FAIL;
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
			}else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, (StringUtil.isEmpty(returnValues.get(ITahsilatMutabakatYekun.TOPLAM_TUTAR)) ? 0 : returnValues.get(ITahsilatMutabakatYekun.TOPLAM_TUTAR).replaceAll(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, (StringUtil.isEmpty(returnValues.get(ITahsilatMutabakatYekun.TOPLAM_SAYI)) ? 0 : returnValues.get(ITahsilatMutabakatYekun.TOPLAM_SAYI).replaceAll(",", ".")));
			}
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0); //Servis Donmuyor
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0); //Servis Donmuyor

			// /invoice payment dan corporate payment_amount count payment
			// status t I ayr�m� yap
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(
					outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0)
//					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(
//							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
//					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(
//							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
			{
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_AKMERCANGAZ_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_AKMERCANGAZ_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String dueDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			
			/*
			 * Akmercan Ustadan olan kurumlarin usta indicatoru 1 olarak kayitlidir.
			 * Bu durumda Usta clientina gidilerek cagri yapilir.
			 */
			List<Map<String, String>> borcList;
			if("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6))){
				borcList = AkmercanUstaClient.talimatliBorcSorgulama(dueDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}else {
				borcList = AkmercanGazClient.talimatliBorcSorgulama(dueDate, clientID, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			}
			
			if (borcList == null) {
				responseCode = ERROR_CODE_NO_RECORD;
			}else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			int i = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.TABLE_SIZE, borcList.size());
				for(Map<String, String> borc : borcList){
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, borc.get(ITalimatliBorcSorgu.ABONE_NO));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, borc.get(ITalimatliBorcSorgu.BELGE_NO));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, borc.get(ITalimatliBorcSorgu.TUTAR));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");// collection
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateString(CommonHelper.getDateTime(borc.get(ITalimatliBorcSorgu.SON_ODEME_TARIHI).split(" ")[0], "dd.MM.yyyy"),"yyyyMMdd"));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, borc.get(ITalimatliBorcSorgu.ISLEM_NO));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, borc.get(ITalimatliBorcSorgu.PB_KODU));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
					i++;
				}
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
}
