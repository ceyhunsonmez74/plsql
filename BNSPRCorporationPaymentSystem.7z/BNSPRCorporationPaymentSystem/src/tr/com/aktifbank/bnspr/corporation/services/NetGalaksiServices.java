package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.NetgalaksiReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.netgalaksi.NetGalaksiClient;
import tr.com.aktifbank.integration.netgalaksi.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.netgalaksi.Bill;
import tr.com.netgalaksi.CancelResponse;
import tr.com.netgalaksi.GetBillsResponse;
import tr.com.netgalaksi.GetInvoicesResponse;
import tr.com.netgalaksi.GetReportResponse;
import tr.com.netgalaksi.Invoice;
import tr.com.netgalaksi.PayBillsResponse;
import tr.com.netgalaksi.PayInvoiceResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class NetGalaksiServices extends OnlineCorporationInterface implements OnlineInstitutionConstants{
	
	private static final Log logger = LogFactory.getLog(NetGalaksiServices.class);
	
	@GraymoundService("ICS_NETGALAKSI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String paymentType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String paymentTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = "660";
		String errorDesc = "";
		int counter = 0;

		try{
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String secretId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			boolean isTest = iMap.getBoolean(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			logger.info("ICS_NETGALAKSI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - NetGalaksiClient.getBills(...) will be called..."));
			GetInvoicesResponse response = NetGalaksiClient.getInvoices(serviceUrl, subscriberNo, secretId, sm, isTest);
			
			if(response != null && response.getInvoices() != null && response.getInvoices().size() > 0){
				for(Invoice invoice : response.getInvoices()){
					String[] termDate = invoice.getSeason().split("\\.");
					String termMonth = termDate[0];
					String termYear = termDate[1];
					Date dueDate = CommonHelper.getDateTime(invoice.getLastPayment(), "yyyy-MM-dd");
	
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, response.getCustomer());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getId());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getTotal());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, dueDate);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, paymentType);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, paymentTypeName);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, invoice.getTotal());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, response.getSession());

					counter++;
				}	
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				errorDesc = "Kay�t bulunamad�";
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());
			
		} catch(Exception e){
			logger.error("ICS_NETGALAKSI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_NETGALAKSI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = "660";
		String errorDesc = "";
		
		try{
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String secretId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			boolean isTest = iMap.getBoolean(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String billId = iMap.getString(MapKeys.INVOICE_NO);
			String customerId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sessionId =  iMap.getString(MapKeys.PARAMETER2);
			String terminalId = "Aktifbank";
			
//			billId = "[\"" + billId +  "\"]"; 
			
			PayInvoiceResponse response = NetGalaksiClient.payInvoices(serviceUrl, secretId, billId, sessionId, sm, isTest);
			
			if(response.getStatus().equals("ok")){
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(sessionId);
				session.saveOrUpdate(invoicePayment);
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				errorDesc = response.getMessage();
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());
			
		} catch(Exception e){
			logger.error("ICS_NETGALAKSI_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_NETGALAKSI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap output = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = "660";
		String errorDesc = "";
		
		try{
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String secretId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			boolean isTest = iMap.getBoolean(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String billId = iMap.getString(MapKeys.INVOICE_NO);
			String customerId = iMap.getString("SUBSCRIBER_NO_1");
			String sessionId = iMap.getString(MapKeys.PARAMETER_2);
			
//			billId = "[\"" + billId +  "\"]"; 
			
			CancelResponse response = NetGalaksiClient.cancelInvoices(serviceUrl, secretId, billId, customerId, sm, isTest);
			
			if(response.getStatus().equals("ok")){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				errorDesc = response.getMessage();
			}		
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());
			
		} catch(Exception e){
			logger.error("ICS_NETGALAKSI_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_NETGALAKSI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = "660";
		String errorDesc = "";
		
		try{
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String secretId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			boolean isTest = iMap.getBoolean(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String reconDateStr = iMap.getString(MapKeys.RECON_DATE).concat("000000");			
			DateFormat dfm = new SimpleDateFormat("yyyyMMddHHmmss");
			dfm.setTimeZone(TimeZone.getTimeZone("GMT"));			    
			long unixTime = dfm.parse(reconDateStr).getTime()/1000L;
			
			BigDecimal corporateCollectionTotal = BigDecimal.ZERO;
			BigDecimal corporateCancelTotal = BigDecimal.ZERO;
			int corporateCollectionCount = 0;
			int corporateCancelCount = 0;
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal bankCancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int bankCancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, bankCancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankCancelCount);
			
			GetReportResponse response = NetGalaksiClient.getReport(serviceUrl, secretId, unixTime, sm, isTest);
			
			if(response != null && response.getStats() != null && response.getStats().size() > 0){
				corporateCollectionCount = response.getStats().get(0).getCount();
				corporateCollectionTotal = new BigDecimal(response.getStats().get(0).getTotalAmount()).setScale(2, RoundingMode.HALF_UP);
				corporateCancelCount = response.getStats().get(2).getCount();
				corporateCancelTotal = new BigDecimal(response.getStats().get(2).getTotalAmount()).setScale(2, RoundingMode.HALF_UP);
			}
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateCollectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corporateCancelTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corporateCancelCount);
			
			if (corporateCollectionTotal.compareTo(bankCollectionTotal) == 0 && corporateCollectionCount == bankCollectionCount	&& corporateCancelTotal.compareTo(bankCancelTotal) == 0 && corporateCancelCount == bankCancelCount) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else{
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				errorDesc = "Mutabakat ba�ar�s�z.";
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());
			
		} catch(Throwable e){
			logger.error("ICS_NETGALAKSI_COLLECTION_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_NETGALAKSI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {

		GMMap output = new GMMap();
		logger.info("ICS_NETGALAKSI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_NETGALAKSI_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {			
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new NetgalaksiReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_SASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
}
