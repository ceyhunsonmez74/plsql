package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CorumGasReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.corumGas.AboneBorcResultType;
import tr.com.corumGas.BorcOdeResultType;
import tr.com.corumGas.CariHareketType;
import tr.com.corumGas.EnumAboneSorguTipi;
import tr.com.corumGas.EnumBorcIslemTipi;
import tr.com.corumGas.EnumIslemKanali;
import tr.com.corumGas.OtomatikOdemeTalimatResultType;
import tr.com.corumGas.SonOdemeTarihiGelenTalimatliFaturalarResultType;
import tr.com.corumGas.TahsilatlarResultType;
import tr.com.corumGas.TesisatDetayBilgiType;
import tr.com.integration.corumGas.CorumGasClient;
import tr.com.integration.corumGas.ServiceMessage;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class CorumGasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(CorumGasServices.class);

	private static final String FATURA_BEDELI = "FAT";

	private static final String GUVENCE_BEDELI = "GB";

	private static final String BAGLANTI_BEDELI = "BB";

	private static String ERROR_CODE_FAIL = "1";

	private static String ERROR_CODE_INVOICE_COLLECTION = "780";

	private static String ERROR_CODE_COLLECTION_CANNOTBE_CANCELED = "5";

	private static String ERROR_CODE_NO_RECORD = "8";

	@GraymoundService("ICS_CORUM_GAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();

		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String responseCode = "";
		int counter = 0;
		
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

//		String collectionTypeStr = iMap.getString(MapKeys.COLLECTION_TYPE);
//		int collectionType =Integer.parseInt(collectionTypeStr);
//		String islemTipi = FATURA_BEDELI;
//		if (collectionType == 1) {
//			islemTipi = BAGLANTI_BEDELI;
//		} else if (collectionType == 2) {
//			islemTipi = GUVENCE_BEDELI;
//		}
		
		String sozlesmeNo  = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String tcknVkn = iMap.getString(MapKeys.SUBSCRIBER_NO2);
		String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO3);

		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			AboneBorcResultType aboneBorcResultType = null;
			if (StringUtils.isNotBlank(sozlesmeNo) && StringUtils.isNotBlank(CommonHelper.trimStart(sozlesmeNo, '0'))) {
				aboneBorcResultType = CorumGasClient.ws101AboneBorcSor(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, Long.valueOf(CommonHelper.trimStart(sozlesmeNo, '0')),
						EnumBorcIslemTipi.FAT, EnumIslemKanali.BANKA_ONLINE, EnumAboneSorguTipi.SOZLESME_NO);
			} else if (StringUtils.isNotBlank(tcknVkn) && StringUtils.isNotBlank(CommonHelper.trimStart(tcknVkn, '0'))) {
					aboneBorcResultType = CorumGasClient.ws101AboneBorcSor(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, Long.valueOf(CommonHelper.trimStart(tcknVkn, '0')),
							EnumBorcIslemTipi.FAT, EnumIslemKanali.BANKA_ONLINE, EnumAboneSorguTipi.TCKNVKN);
			} else if (StringUtils.isNotBlank(tesisatNo) && StringUtils.isNotBlank(CommonHelper.trimStart(tesisatNo, '0'))) {
				aboneBorcResultType = CorumGasClient.ws101AboneBorcSor(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, Long.valueOf(CommonHelper.trimStart(tesisatNo, '0')),
						EnumBorcIslemTipi.FAT, EnumIslemKanali.BANKA_ONLINE, EnumAboneSorguTipi.TESISAT_NO);
			}
			if (aboneBorcResultType == null) {
				responseCode = ERROR_CODE_NO_RECORD;
			}
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());

			insertOnlineServiceLog(iMap, outMap);

			if (aboneBorcResultType == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else {
				responseCode = aboneBorcResultType.getReturnResult().getHataKodu().toString();
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				if (GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {

					for (TesisatDetayBilgiType tesisatDetayBilgiType : aboneBorcResultType.getAboneDetayBilgi().getTesisatlar().getTesisatDetayBilgiType()) {
						for (CariHareketType cariHareketType : tesisatDetayBilgiType.getCariHareketler().getCariHareketType()) {
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, tesisatDetayBilgiType.getSozlesmeNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, aboneBorcResultType.getAboneDetayBilgi().getTcknVkn());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, tesisatDetayBilgiType.getTesisatNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, cariHareketType.getTahakkukID());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, aboneBorcResultType.getAboneDetayBilgi().getAboneUnvan());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, cariHareketType.getTutar());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.convertGregorianCalendar2Date(cariHareketType.getSonOdemeTarih()));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, CommonHelper.getYear(CommonHelper.convertGregorianCalendar2Date(cariHareketType.getSonOdemeTarih())));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, CommonHelper.getMonth(CommonHelper.convertGregorianCalendar2Date(cariHareketType.getSonOdemeTarih())));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, cariHareketType.getTutar());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, cariHareketType.getFaturaNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, cariHareketType.getEskiAboneNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, cariHareketType.getIslemTipi());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, cariHareketType.getParaBirimi());
							responseCode = GeneralConstants.ERROR_CODE_APPROVE;
							counter++;
						}
					}
				}
			}
		}catch (Exception e2) {
			logger.error("An exception occured while executing ICS_CORUM_GAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		outMap.put(MapKeys.WS_USER, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
		outMap.put(MapKeys.WS_PASSWORD, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
		return outMap;
	}

	@GraymoundService("ICS_CORUM_GAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_DO_INVOICE_COLLECTION");
		
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		
		String responseCode = "";
		
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			XMLGregorianCalendar islemTarihi;
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				islemTarihi =	CommonHelper.convertDate2GregorianCalendar(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
			} else {
				islemTarihi = CommonHelper.convertDate2GregorianCalendar(new Date());
			}
			
			Long tahakkukId = iMap.getLong(MapKeys.INVOICE_NO);
			Double tutar = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();

			String bankaReferenasNo = iMap.getString(MapKeys.TRX_NO);
			String paraBirimi = iMap.getString(MapKeys.PARAMETER4);
	
			BorcOdeResultType borcOdeResultType = CorumGasClient.ws102AboneBorcOdeme(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankaReferenasNo, islemTarihi, EnumIslemKanali.BANKA_ONLINE, paraBirimi, tahakkukId, tutar);

			iMap.put("REQUEST_XML_GET_DO_INVOICE_COLLECTION", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DO_INVOICE_COLLECTION", serviceMessage.getResponse());
			GMMap responceCodeMap = new GMMap();
			if (borcOdeResultType!=null) {
				responseCode = borcOdeResultType.getReturnResult().getHataKodu().toString();
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				if (GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
				
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter5(borcOdeResultType.getTahsilatID().toString());
					session.saveOrUpdate(invoicePayment);
				}
			}
			else {
				// Odeme yapilirken hata ile karsilasti
				responseCode = ERROR_CODE_INVOICE_COLLECTION;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_CORUM_GAS_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_CORUM_GAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			Long tahakkukId = iMap.getLong(MapKeys.INVOICE_NO);

			Long tahsilatId ;
			
			if (iMap.get(MapKeys.CANCEL_PARAMETER5)!= null) {
				tahsilatId = iMap.getLong(MapKeys.CANCEL_PARAMETER5);
			}else {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				tahsilatId = Long.valueOf(invoicePayment.getParameter5());
			}
			
			BorcOdeResultType borcOdeResultType = CorumGasClient.ws104AboneBorcOdemeSil(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, EnumIslemKanali.BANKA_ONLINE, tahakkukId, tahsilatId);
			
			iMap.put("REQUEST_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getResponse());
	
			if (borcOdeResultType!=null) {
				responseCode = borcOdeResultType.getReturnResult().getHataKodu().toString();
			}
			else {
				// Odeme yapilirken hata ile karsilasti
				responseCode = ERROR_CODE_COLLECTION_CANNOTBE_CANCELED;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}



	@GraymoundService("ICS_CORUM_GAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String responseCode = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_COLLECTION_RECONCILIATION");
			XMLGregorianCalendar tarih = CommonHelper.convertDate2GregorianCalendar(iMap.getDate(MapKeys.RECON_DATE));
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			BigDecimal corporateCollectionTotal = new BigDecimal("0");
			int corporateCollectionCount = 0;
			BigDecimal corporateCollectionCancelTotal = new BigDecimal("0");
			int corporateCollectionCancelCount = 0;

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);

			TahsilatlarResultType result = CorumGasClient.ws108TahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, false , EnumIslemKanali.BANKA_ONLINE, tarih);

//			TahsilatlarResultType result = CorumGasClient.ws108IptalEdilenTahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, false , EnumIslemKanali.BANKA_ONLINE, tarih);
			if (result != null && result.getTahsilatlar()!=null && result.getTahsilatlar().getTumHareketlerAdedi()!=null && result.getTahsilatlar().getTumHareketlerToplami()!=null) {
				corporateCollectionTotal = new BigDecimal(result.getTahsilatlar().getTumHareketlerToplami());
				corporateCollectionCount = Integer.parseInt(result.getTahsilatlar().getTumHareketlerAdedi().toString());
			}
			
			TahsilatlarResultType resultCancel = CorumGasClient.ws108IptalEdilenTahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, false , EnumIslemKanali.BANKA_ONLINE, tarih);


			if (resultCancel != null && resultCancel.getTahsilatlar()!=null && resultCancel.getTahsilatlar().getTumHareketlerAdedi()!=null && resultCancel.getTahsilatlar().getTumHareketlerToplami()!=null) {
				corporateCollectionCancelTotal = new BigDecimal(resultCancel.getTahsilatlar().getTumHareketlerToplami());
				corporateCollectionCancelCount = Integer.parseInt(resultCancel.getTahsilatlar().getTumHareketlerAdedi().toString());
			}
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
	
			if (bankCollectionTotal.compareTo(corporateCollectionTotal) == 0 && corporateCollectionCount == bankCollectionCount) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateCollectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corporateCollectionCancelTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corporateCollectionCancelCount);

		} catch (Exception e) {
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			output.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, e.getMessage().length()<950? e.getMessage() : e.getMessage().substring(0, 949));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_CORUM_GAS_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		logger.info("ICS_CORUM_GAS_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new CorumGasReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_CORUM_GAS_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_CORUM_GAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String responseCode = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_COLLECTION_RECONCILIATION_CLOSED");
			XMLGregorianCalendar tarih = CommonHelper.convertDate2GregorianCalendar(iMap.getDate(MapKeys.RECON_DATE));
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			BigDecimal corporateCollectionTotal = new BigDecimal("0");
			int corporateCollectionCount = 0;
			BigDecimal corporateCollectionCancelTotal = new BigDecimal("0");
			int corporateCollectionCancelCount = 0;
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);

			TahsilatlarResultType result = CorumGasClient.ws108TahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, false , EnumIslemKanali.BANKA_ONLINE, tarih);
			TahsilatlarResultType resultCancel = CorumGasClient.ws108IptalEdilenTahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, false , EnumIslemKanali.BANKA_ONLINE, tarih);

//			TahsilatlarResultType result = CorumGasClient.ws108IptalEdilenTahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, false , EnumIslemKanali.BANKA_ONLINE, tarih);
			if (result != null && result.getTahsilatlar()!=null && result.getTahsilatlar().getTumHareketlerAdedi()!=null && result.getTahsilatlar().getTumHareketlerToplami()!=null) {
				corporateCollectionTotal = new BigDecimal(result.getTahsilatlar().getTumHareketlerToplami());
				corporateCollectionCount = Integer.parseInt(result.getTahsilatlar().getTumHareketlerAdedi().toString());
			}
			if (resultCancel != null && resultCancel.getTahsilatlar()!=null && resultCancel.getTahsilatlar().getTumHareketlerAdedi()!=null && resultCancel.getTahsilatlar().getTumHareketlerToplami()!=null) {
				corporateCollectionCancelTotal = new BigDecimal(resultCancel.getTahsilatlar().getTumHareketlerToplami());
				corporateCollectionCancelCount = Integer.parseInt(resultCancel.getTahsilatlar().getTumHareketlerAdedi().toString());
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
	
			if (bankCollectionTotal.compareTo(corporateCollectionTotal) == 0 && corporateCollectionCount == bankCollectionCount) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateCollectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCollectionCount);

			if (bankCollectionTotal.compareTo(corporateCollectionTotal) == 0 && corporateCollectionCount == bankCollectionCount) {
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}else{
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateCollectionTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCollectionCount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corporateCollectionCancelTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corporateCollectionCancelCount);
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);

			}

			
		} catch (Exception e) {
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			output.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, e.getMessage().length()<950? e.getMessage() : e.getMessage().substring(0, 949));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}	
	@GraymoundService("STO_CORUM_GAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CORUM_GAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String sozlesmeNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		
			XMLGregorianCalendar tarih = CommonHelper.convertDate2GregorianCalendar(new Date());

			OtomatikOdemeTalimatResultType otomatikOdemeTalimatResultType = CorumGasClient.ws105OtomatikOdemeTalimatiVer(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, EnumIslemKanali.BANKA_ONLINE, Long.valueOf(CommonHelper.trimStart(sozlesmeNo, '0')), tarih);
			iMap.put("REQUEST_XML_SEND_STANDING_ORDER_MESSAGE", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_SEND_STANDING_ORDER_MESSAGE", serviceMessage.getResponse());
			
			if (otomatikOdemeTalimatResultType!=null) {
				responseCode = otomatikOdemeTalimatResultType.getReturnResult().getHataKodu().toString();
			} else {
				// talimat iste�i g�nderilirken hata olu�tu
				responseCode = ERROR_CODE_FAIL;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("STO_CORUM_GAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CORUM_GAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String sozlesmeNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		
			XMLGregorianCalendar tarih = CommonHelper.convertDate2GregorianCalendar(new Date());

			OtomatikOdemeTalimatResultType otomatikOdemeTalimatResultType = CorumGasClient.ws106OtomatikOdemeTalimatiIptalEt(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, EnumIslemKanali.BANKA_ONLINE, Long.valueOf(CommonHelper.trimStart(sozlesmeNo, '0')), tarih);
			iMap.put("REQUEST_XML_SEND_STANDING_ORDER_MESSAGE", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_SEND_STANDING_ORDER_MESSAGE", serviceMessage.getResponse());
			
			if (otomatikOdemeTalimatResultType!=null) {
				responseCode = otomatikOdemeTalimatResultType.getReturnResult().getHataKodu().toString();
			} else {
				// talimat iste�i g�nderilirken hata olu�tu
				responseCode = ERROR_CODE_FAIL;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}
	
	@GraymoundService("ICS_CORUM_GAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CORUM_GAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String date = CommonHelper.getDateString(new Date(), "yyyyMMdd");

			XMLGregorianCalendar tarih = CommonHelper.convertDate2GregorianCalendar(new Date());

			SonOdemeTarihiGelenTalimatliFaturalarResultType response = CorumGasClient.ws109SonOdemeTarihiGelenTalimatliFaturalar(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, EnumIslemKanali.BANKA_ONLINE, tarih);

			if (response!=null) {
				responseCode = response.getReturnResult().getHataKodu().toString();
			} else {
				// talimat iste�i g�nderilirken hata olu�tu
				responseCode = ERROR_CODE_FAIL;
			}

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = CommonHelper.getHibernateSession();
				

				GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

					GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
					int counter = 0;
					List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
						if (icsStandingOrder.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
							String subscriberNo = CommonHelper.trimStart(icsStandingOrder.getSubscriberNo1(), '0');
							for (CariHareketType debt : response.getCariHareketler().getCariHareketType()) {
								if (icsStandingOrder.getSubscriberNo1().equals(debt.getSozlesmeNo().toString())) {
				
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debt.getSozlesmeNo().toString());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debt.getTahakkukID());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debt.getTutar());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.convertGregorianCalendar2Date(debt.getSonOdemeTarih()));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, CommonHelper.getYear(CommonHelper.convertGregorianCalendar2Date(debt.getSonOdemeTarih())));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, CommonHelper.getMonth(CommonHelper.convertGregorianCalendar2Date(debt.getSonOdemeTarih())));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, collectionTypeId);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionTypeId);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debt.getTutar());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
								}
							}
						}
					}
					outMap.put(MapKeys.TABLE_SIZE, counter);
					outMap.put(MapKeys.RESPONSE_CODE, responseCode);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_CORUM_GAS_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

}
