package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.IskiCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.IskiStandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.StandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.iski.client.IskiClient;
import tr.com.aktifbank.integration.iski.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.gov.iski.ths.bankaonline.webservices.BnkBorcSorgulama;
import tr.gov.iski.ths.bankaonline.webservices.BnkTahsilatIptalResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkTahsilatIslemResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkTahsilatMutabakatResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkTalimatBasvuruResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkTalimatIptalResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkTalimatMutabakatResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkVirmanliFaturaDataResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkVirmanliOzetDataResponseReturn;
import tr.gov.iski.ths.bankaonline.webservices.BnkVirmanliTahsilatIslemResponseReturn;


import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public final class IskiServices extends OnlineCorporationInterface implements
		OnlineInstitutionConstants {
	
	private static final Log logger = LogFactory.getLog(IskiServices.class);
	
	private static final String ISKI_SUCCESSFUL_CODE = "401";
	private static final String CANCEL_COLLECTION_SUCCESSFUL = "403";
	private static final String COLLECTION_RECON_SUCCESSFUL = "404";
	private static final String COLLECTION_RECON_FAILED = "405";
	private static final String RECON_ALREADY_DONE = "410";
	private static final String STANDING_ORDER_SAVE_SUCCESSFUL = "406";
	private static final String STANDING_ORDER_CANCEL_SUCCESSFUL = "407";
	private static final String STANDING_ORDER_RECON_SUCCESSFUL = "408";
	private static final String STANDING_ORDER_RECON_FAILED = "409";
	private static final String YIM_CHANNEL_CODE = "32";
	private static final String DEFAULT_BRANCH_CODE= "555";
	
	private static final String YIM_CHANNEL_NKOLAY = "M";
	private static final String YIM_CHANNEL_EPOS = "K";
	private static final String YIM_CHANNEL_VEZNE = "V";
	private static final String EPOS_AGENT_CODE = "90713";
	private static final String KFT_ISKI_INVOICE_NO_NUMERATOR = "KFT_ISKI_INVOICE_NO"; 

	public IskiServices() {
		
	}

	@GraymoundService("ICS_ISKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_INVOICE_DEBT_INQUIRY");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			String subscriberNo1String = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String subscriberNo1 = CommonHelper.trimStart(subscriberNo1String, '0');
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			BnkBorcSorgulama debt = client.debtInquiry(subscriberNo1);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			CommonHelper.insertWsCallLog(iMap, message.getParameter1(), message.getParameter2(), message.getParameter3());
			if(debt != null){
				if(debt.getIslemKodu().equals(ISKI_SUCCESSFUL_CODE)){
					if(new BigDecimal(debt.getToplamBorc()).compareTo(BigDecimal.ZERO) == 1){
						int counter = 0;
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, CorporationServiceUtil.getSequenceCode(KFT_ISKI_INVOICE_NO_NUMERATOR)); // TO BE CHANGED
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, new BigDecimal(debt.getToplamBorc()));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
						String subscriberName = "";
						if(!StringUtil.isEmpty(debt.getAdi())){
							subscriberName = debt.getAdi().concat(" ");
						}
						if(!StringUtil.isEmpty(debt.getSoyAdi())){
							subscriberName = subscriberName.concat(debt.getSoyAdi());
						}
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, subscriberName);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						//output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.addDay(new Date(), 10)); // TO BE CHANGED
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, new BigDecimal(debt.getToplamBorc()));
						output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
				else{
					GMMap codeMapping = getResponseCodeMapping(debt.getIslemKodu(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
					output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
				}
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			else{
				throw new Exception("Servis cevab� anla��lamad�.");
			}
		}
		catch(Exception e){
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			//throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_ISKI_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_DO_INVOICE_COLLECTION");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			String subscriberNoString = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String transactionNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			Date collectionDate = getInputDateOrDefault(iMap, MapKeys.PAYMENT_DATE, "yyyyMMddhhmmss");
			BigDecimal collectionAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			
			String subscriberNo = CommonHelper.trimStart(subscriberNoString, '0');
			
			if(isStandingOrderCollection){
				BnkVirmanliTahsilatIslemResponseReturn result = client.doInvoiceCollectionForStandingOrder(collectionDate, subscriberNo, transactionNo, collectionAmount);
				iMap.put("REQUEST_XML", message.getRequest());
				output.put("RESPONSE_XML", message.getResponse());
				if(!ISKI_SUCCESSFUL_CODE.equals(result.getIslemKodu())){
					setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
				}
				else{
					Session hibSession = CommonHelper.getHibernateSession();
					invoicePayment paymentRecord = (invoicePayment)hibSession.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("txNo", new BigDecimal(transactionNo)))
							.uniqueResult();
					
					paymentRecord.setParameter1(result.getMakbuzNo());
					paymentRecord.setParameter2(DEFAULT_BRANCH_CODE);
					
					hibSession.saveOrUpdate(paymentRecord);
					hibSession.flush();
				}
			}
			else{
				String channelCode = iMap.getString("CHANNEL_CODE", null);
				String branchCode = null;
				BnkTahsilatIslemResponseReturn result;
				if(!StringUtil.isEmpty(channelCode)){
					if(YIM_CHANNEL_CODE.equals(channelCode)){
						if (YIM_CHANNEL_EPOS.equals(iMap.getString(MapKeys.YIM_CHANNEL))) {
							branchCode = EPOS_AGENT_CODE;
						}else if (YIM_CHANNEL_VEZNE.equals(iMap.getString(MapKeys.YIM_CHANNEL))) {
							branchCode = getBranchCodeVezne(iMap.getString("AGENT_CODE"));
						}else {
							branchCode = getBranchCode(iMap.getString("AGENT_CODE"));
						}
						result = client.doInvoiceCollectionWithBranchCode(collectionDate, subscriberNo, branchCode, transactionNo, collectionAmount);
					}
					else{
						result = client.doInvoiceCollection(collectionDate, subscriberNo, transactionNo, collectionAmount);
						branchCode = DEFAULT_BRANCH_CODE;
					}
				}
				else{
					result = client.doInvoiceCollection(collectionDate, subscriberNo, transactionNo, collectionAmount);
					branchCode = DEFAULT_BRANCH_CODE;
				}
				iMap.put("REQUEST_XML", message.getRequest());
				output.put("RESPONSE_XML", message.getResponse());
				if(!ISKI_SUCCESSFUL_CODE.equals(result.getIslemKodu())){
					setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
				}
				else{
					Session hibSession = CommonHelper.getHibernateSession();
					invoicePayment paymentRecord = (invoicePayment)hibSession.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("txNo", new BigDecimal(transactionNo)))
							.uniqueResult();
					
					paymentRecord.setParameter1(result.getMakbuzNo());
					if(!StringUtil.isEmpty(branchCode)){
						paymentRecord.setParameter2(branchCode);
					}
					
					hibSession.saveOrUpdate(paymentRecord);
					hibSession.flush();
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		}
		catch(Exception e){
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	private static String getBranchCode(String agentCode) {
		if(!StringUtil.isEmpty(agentCode)){
			return "9".concat(agentCode.substring(3));
		}
		else{
			return agentCode;
		}
	}
	
	private static String getBranchCodeVezne(String agentCode) {
		if(!StringUtil.isEmpty(agentCode)){
			return "8".concat(agentCode.substring(3));
		}
		else{
			return agentCode;
		}
	}


	@GraymoundService("ICS_ISKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap){
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_SEND_COLLECTION_CANCEL_MESSAGE");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			
			String subscriberNo = CommonHelper.trimStart(iMap.getString("SUBSCRIBER_NO_1"), '0');
			String voucherNo = iMap.getString("PARAMETER_1");
			String transactionNo = iMap.getString(MapKeys.TRX_NO);
			Date date = getInputDateOrDefault(iMap, MapKeys.CANCEL_DATE, "yyyyMMddhhmmss");
			
			BnkTahsilatIptalResponseReturn result = client.cancelCollection(date, subscriberNo, transactionNo, voucherNo);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			if(!CANCEL_COLLECTION_SUCCESSFUL.equals(result.getIslemKodu())){
				setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_ISKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_ISKI_SEND_STANDING_ORDER_MESSAGE");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			
			String subscriberNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			String transactionNo = iMap.getString(MapKeys.TRX_NO);
			Date date = getInputDateOrDefault(iMap, MapKeys.RECON_DATE, "yyyyMMdd");
			
			BnkTalimatBasvuruResponseReturn result = client.saveStandingOrder(date, subscriberNo, transactionNo);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			if(!STANDING_ORDER_SAVE_SUCCESSFUL.equals(result.getIslemKodu())){
				setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_ISKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_ISKI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			
			String subscriberNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			String transactionNo = iMap.getString(MapKeys.TRX_NO);
			Date date = getInputDateOrDefault(iMap, MapKeys.RECON_DATE, "yyyyMMdd");
			
			BnkTalimatIptalResponseReturn result = client.cancelStandingOrder(date, subscriberNo, transactionNo);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			if(!STANDING_ORDER_CANCEL_SUCCESSFUL.equals(result.getIslemKodu())){
				setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_ISKI_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_DEBT_INQUERY_FOR_STANDING_ORDER");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			
			Date date = new Date();
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			BnkVirmanliOzetDataResponseReturn[] standingOrderSummaryList = client.getStandingOrderDebtInquirySummary(date);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			if(standingOrderSummaryList.length == 1){
				BnkVirmanliOzetDataResponseReturn data = standingOrderSummaryList[0];
				if(!ISKI_SUCCESSFUL_CODE.equals(data.getIslemKodu())){
					setErrorCodeToOutput(data.getIslemKodu(), iMap, output);
					return output;
				}
			}
			
			int counter = 0;
			
			for (int i = 0; i < standingOrderSummaryList.length; i++) {
				BnkVirmanliOzetDataResponseReturn data = standingOrderSummaryList[i];
				
				BnkVirmanliFaturaDataResponseReturn[] standingOrderList = client.debtInquiryForStandingOrders(date, data);
				iMap.put("REQUEST_XML" + i, message.getRequest());
				output.put("RESPONSE_XML" + i, message.getResponse());
				
				for (int j = 0; j < standingOrderList.length; j++) {
					BnkVirmanliFaturaDataResponseReturn debt = standingOrderList[j];
					
					if(ISKI_SUCCESSFUL_CODE.equals(debt.getIslemkodu())){
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debt.getSozlesmeno());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debt.getFaturano());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debt.getOdenecektutar());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(debt.getSonodemetarihi(), "dd/MM/yyyy"));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
						counter++;
					}
				}
			}
			output.put(MapKeys.TABLE_SIZE, output.getSize(MapKeys.INVOICE_LIST));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_ISKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			
			iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_COLLECTION_RECONCILIATION");
			Date date = iMap.getDate(MapKeys.RECON_DATE);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			BnkTahsilatMutabakatResponseReturn result = client.getReconciliationSummary(date, collectionCount, collectionTotal, cancelCount, cancelTotal);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(result.getISKIIslemTutari()));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getISKIIslemAdedi());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getISKIIptalTutari());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getISKIIptalAdedi());
			
			if(result.getIslemKodu().equals(COLLECTION_RECON_SUCCESSFUL) || result.getIslemKodu().equals(RECON_ALREADY_DONE)){
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
			else if(result.getIslemKodu().equals(COLLECTION_RECON_FAILED)){
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			else{
				setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_ISKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage message = new ServiceMessage();
		try{
			final String TABLE_NAME = "BRANCH_CODES";
			String query = String.format(QueryRepository.IskiServicesRepository.BRANCH_CODE_QUERY, 
					iMap.getString(MapKeys.CORPORATE_CODE),
					iMap.getString(MapKeys.RECON_DATE));
			GMMap iskiBranchCodes = DALUtil.getResults(query, TABLE_NAME);
			iMap.put("BRANCHES", iskiBranchCodes);
			CollectionReconciliationDetailBatch batch = new IskiCollectionReconciliationDetailBatch(iMap, getSoapClient(iMap, message));
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_ISKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISKI_COLLECTION_RECONCILIATION_CLOSED");
		
		try{
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_ISKI_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ISKI_STANDING_ORDER_RECONCILIATION");
		ServiceMessage message = new ServiceMessage();
		try{
			IskiClient client = getSoapClient(iMap, message);
			Date reconDate = iMap.getDate(MapKeys.RECON_DATE);
			
			if(iMap.getString("SCREEN_RECONCILIATION", "0").equals("0")){
				reconDate = CommonHelper.addDay(reconDate, -1);
			}
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
			
			int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
			int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");
			
			BnkTalimatMutabakatResponseReturn result = client.getStandingOrderReconSummary(reconDate, bankStandingOrderCount + bankStandingOrderCancelCount, bankStandingOrderCancelCount);//kurum iptal edilenleri de talimatta say�yor
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.RECON_CORPORATE_COUNT, result.getISKITalimatBasvuru());
			output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, result.getISKITalimatIptal());
			output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
			
			if(result.getIslemKodu().equals(STANDING_ORDER_RECON_SUCCESSFUL)){
				
			}
			else if(result.getIslemKodu().equals(RECON_ALREADY_DONE)){
				
			}
			else if(result.getIslemKodu().equals(STANDING_ORDER_RECON_FAILED)){
				
			}
			else{
				setErrorCodeToOutput(result.getIslemKodu(), iMap, output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_ISKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_ISKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		ServiceMessage message = new ServiceMessage();
		try{
			if(iMap.getString("SCREEN_RECONCILIATION", "0").equals("0")){
				iMap.put(MapKeys.RECON_DATE, CommonHelper.addDay(iMap.getDate(MapKeys.RECON_DATE), -1));
			}
			StandingOrderReconciliationDetailBatch batch = new IskiStandingOrderReconciliationDetailBatch(iMap, getSoapClient(iMap, message));
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	private static IskiClient getSoapClient(GMMap iMap, ServiceMessage message) {
		IskiClient client = new IskiClient(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
				iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), message,iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
		return client;
	}
	
	private static void setErrorCodeToOutput(String errorCode, GMMap input, GMMap output){
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		
		GMMap responseCodeMap = getResponseCodeMapping(errorCode,
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
		
		output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
		output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
	}
	
	private static Date getInputDateOrDefault(GMMap input, String key, String format) throws ParseException{
		Date date = new Date();
		
		if(!StringUtil.isEmpty(input.getString(key))){
			date = CommonHelper.getDateTime(input.getString(key), format);
		}
		
		return date;
	}
}
