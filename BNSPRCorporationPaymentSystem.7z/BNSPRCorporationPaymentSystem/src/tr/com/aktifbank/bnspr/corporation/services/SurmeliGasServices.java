package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.surmeligaz.ServiceMessage;
import tr.com.aktifbank.surmeligaz.SurmeliGazDataResult;
import tr.com.aktifbank.surmeligaz.SurmeliGazOnlineClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SurmeliGasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(SurmeliGasServices.class);

	private static final String FATURA_BEDELI = "FAT";

	private static final String GUVENCE_BEDELI = "GB";

	private static final String BAGLANTI_BEDELI = "BB";

	private static String ERROR_CODE_FAIL = "1";

	private static String ERROR_CODE_INVOICE_COLLECTION = "780";

	private static String ERROR_CODE_COLLECTION_CANNOTBE_CANCELED = "5";

	private static String ERROR_CODE_NO_RECORD = "8";

	@GraymoundService("ICS_SURMELI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SURMELI_INVOICE_DEBT_INQUIRY");
		SurmeliGazOnlineClient client = getSoapClient(iMap);
		GMMap outMap = new GMMap();

		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String responseCode = "";
		String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		int counter = 0;

		String collectionTypeStr = iMap.getString(MapKeys.COLLECTION_TYPE);
		int collectionType =Integer.parseInt(collectionTypeStr);
		String islemTipi = FATURA_BEDELI;
		if (collectionType == 1) {
			islemTipi = BAGLANTI_BEDELI;
		} else if (collectionType == 2) {
			islemTipi = GUVENCE_BEDELI;
		}
	
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String trimmedAboneNo = "";
			if (aboneNo != null) {
				trimmedAboneNo = CommonHelper.trimStart(aboneNo, '0');
			}

			List<SurmeliGazDataResult> surmeliGazDataResultList = client.tumBorclar(clientID, trimmedAboneNo,serviceMessage);
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
		
			if (surmeliGazDataResultList == null || surmeliGazDataResultList.size() == 0) {
				responseCode = ERROR_CODE_NO_RECORD;
			} else {
				List<SurmeliGazDataResult> surmeliGazDataResultList2 = client.borcSorAdSoyad(clientID, trimmedAboneNo, islemTipi,serviceMessage);
				String adSoyad = "";
				if (surmeliGazDataResultList2 != null && surmeliGazDataResultList2.size() != 0) {
					SurmeliGazDataResult surmeliGazDataResult = surmeliGazDataResultList2.get(0);
					adSoyad = surmeliGazDataResult.getFIELD8() + " " + surmeliGazDataResult.getFIELD9();
				}

				for (SurmeliGazDataResult surmeliGazDataResult : surmeliGazDataResultList) {
					if (surmeliGazDataResult != null && surmeliGazDataResult.getFIELD9().equals("0"))
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, surmeliGazDataResult.getFIELD2());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, surmeliGazDataResult.getFIELD3());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, trimmedAboneNo);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, adSoyad);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, surmeliGazDataResult.getFIELD4());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(surmeliGazDataResult.getFIELD5(), "dd.MM.yyyy"));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, surmeliGazDataResult.getFIELD5().trim().substring(6, 10));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, surmeliGazDataResult.getFIELD5().trim().substring(3, 5));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, surmeliGazDataResult.getFIELD4());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, surmeliGazDataResult.getFIELD1());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, surmeliGazDataResult.getFIELD9());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, surmeliGazDataResult.getFIELD3());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, surmeliGazDataResult.getFIELD6());
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					counter++;
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		outMap.put(MapKeys.WS_USER, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
		outMap.put(MapKeys.WS_PASSWORD, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
		return outMap;
	}

	@GraymoundService("ICS_SURMELI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SURMELI_DO_INVOICE_COLLECTION");
		String responseCode = "";
		String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
		String islemTipi = null;
		String pbKod = null;
		if (collectionTypeName != null) {
			if (collectionTypeName.equals("Fatura �deme")) { // TODO test me
				islemTipi = FATURA_BEDELI;
			} else if (collectionTypeName.equals("Ba�lant� �creti")) {
				islemTipi = BAGLANTI_BEDELI;
			} else {
				islemTipi = GUVENCE_BEDELI;
			}
		}

		if (islemTipi == null) {
			Session session = DAOSession.getSession("BNSPRDal");
			invoicePayment invoicePayment = null;
			invoicePayment paymentObj = (tr.com.aktifbank.bnspr.dao.invoicePayment) session.
					createCriteria(invoicePayment.class).add(Restrictions.eq("parameter3", iMap.getString(MapKeys.PARAMETER3)))
					.setMaxResults(1).uniqueResult();
			if (paymentObj != null) {
				invoicePayment = paymentObj;
				islemTipi = invoicePayment.getParameter2();
				pbKod = invoicePayment.getParameter6();
			}
		}
		
		SurmeliGazOnlineClient client = getSoapClient(iMap);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String trimmedAboneNo = "";
			boolean isTaksitsizAbone = false;
			if (aboneNo != null) {
				trimmedAboneNo = CommonHelper.trimStart(aboneNo, '0');
				isTaksitsizAbone = true;
			}
			String belgeNo = iMap.getString(MapKeys.INVOICE_NO);
			String tutar = iMap.getString(MapKeys.INVOICE_AMOUNT);
			String tarih="";
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd.MM.yyyy");
			} else {
				tarih = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			}
			
			
			if (pbKod == null) {
				pbKod = iMap.getString(MapKeys.PARAMETER4);
			}
			String islemNo = "";
			String taksitKod = "";

			boolean isOdendi = false;
			if (islemTipi == null) {
				islemTipi = FATURA_BEDELI;
			}
			
			if (isTaksitsizAbone) {
				isOdendi = client.borcOde(clientID, trimmedAboneNo, islemTipi, belgeNo, tutar, pbKod, tarih,serviceMessage);
				iMap.put("REQUEST_XML_GET_DO_INVOICE_COLLECTION", serviceMessage.getRequest());
				outMap.put("REQUEST_XML_GET_DO_INVOICE_COLLECTION", serviceMessage.getResponse());
			} else {
				islemNo = iMap.getString(MapKeys.PARAMETER1);
				taksitKod = iMap.getString(MapKeys.PARAMETER2);
				isOdendi = client.taksitOde(clientID, islemTipi, islemNo, taksitKod,serviceMessage);
				iMap.put("REQUEST_XML_GET_DO_INVOICE_COLLECTION", serviceMessage.getRequest());
				outMap.put("REQUEST_XML_GET_DO_INVOICE_COLLECTION", serviceMessage.getResponse());
			}

			if (isOdendi) {
				// Odeme gerceklesti
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(islemTipi);
				invoicePayment.setParameter4(taksitKod);
				invoicePayment.setParameter5(islemNo);
				invoicePayment.setParameter6(pbKod);
				session.saveOrUpdate(invoicePayment);
			} else {
				// Odeme yapilirken hata ile karsilasti
				responseCode = ERROR_CODE_INVOICE_COLLECTION;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_SIBESKI_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_SURMELI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SURMELI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		SurmeliGazOnlineClient client = getSoapClient(iMap);
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String aboneNo = iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1);
			String trimmedAboneNo = "";
			if (aboneNo != null) {
				trimmedAboneNo = CommonHelper.trimStart(aboneNo, '0');
			}
			String orderDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				orderDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd.MM.yyyy");
			} 

			String islemTipi = FATURA_BEDELI;
			String pbKod = "TL";
			boolean returnCode = false;
			Session session = DAOSession.getSession("BNSPRDal");
			List<invoicePayment> invoicePaymentList = null;
			invoicePayment invoicePayment = null;
			BigDecimal trxNo = iMap.getBigDecimal(MapKeys.TRX_NO);
			if (trxNo != null) {
				invoicePaymentList = session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).list();
			} else {
				invoicePaymentList = session.createCriteria(invoicePayment.class).add(Restrictions.eq("parameter3", iMap.getString(MapKeys.PARAMETER_3))).list();
			}

			if (invoicePaymentList != null && invoicePaymentList.size() != 0) {
				invoicePayment = invoicePaymentList.get(0);
			}

			String belgeNo = iMap.getString(MapKeys.PARAMETER_3);
			String tutar = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			if (invoicePayment != null) {
				islemTipi = invoicePayment.getParameter2();
				if(islemTipi == null) {
					islemTipi = FATURA_BEDELI;
				}
				pbKod = invoicePayment.getParameter6();
			}
			returnCode = client.yBorcOdemeSil(clientID, trimmedAboneNo, islemTipi, belgeNo, tutar, pbKod, orderDate,serviceMessage);
			iMap.put("REQUEST_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getResponse());
			if (returnCode) {
				// tahsilat iptal ba�ar�yla g�nderildi
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else {
				// tahsilat ipta iste�i g�nderilirken hata olu�tu
				responseCode = ERROR_CODE_COLLECTION_CANNOTBE_CANCELED;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("STO_SURMELI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_SURMELI_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		SurmeliGazOnlineClient client = getSoapClient(iMap);
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			if (aboneNo == null) {
				aboneNo = "";
			}
			String trimmedAboneNo = CommonHelper.trimStart(aboneNo, '0');
			String orderDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			boolean returnCode = false;
			returnCode = client.talimatVer(clientID, trimmedAboneNo, orderDate,serviceMessage);
			iMap.put("REQUEST_XML_SEND_STANDING_ORDER_MESSAGE", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_SEND_STANDING_ORDER_MESSAGE", serviceMessage.getResponse());

			if (returnCode) {
				// talimat iste�i ba�ar�yla g�nderildi
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else {
				// talimat iste�i g�nderilirken hata olu�tu
				responseCode = ERROR_CODE_FAIL;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("STO_SURMELI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_SURMELI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		SurmeliGazOnlineClient client = getSoapClient(iMap);
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			if (aboneNo == null) {
				aboneNo = "";
			}
			String trimmedAboneNo = CommonHelper.trimStart(aboneNo, '0');
			String orderCancelDate = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			boolean returnCode = false;
			returnCode = client.talimatIptalEt(clientID, trimmedAboneNo, orderCancelDate,serviceMessage);
			iMap.put("REQUEST_XML_SEND_STANDING_ORDER_CANCEL_MESSAGE", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_SEND_STANDING_ORDER_CANCEL_MESSAGE", serviceMessage.getResponse());

			if (returnCode) {
				// talimat iptal iste�i ba�ar�yla g�nderildi
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else {
				// talimat iptal iste�i g�nderilirken hata olu�tu
				responseCode = ERROR_CODE_FAIL;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_SURMELI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			SurmeliGazOnlineClient client = getSoapClient(iMap);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String responseCode = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SURMELI_COLLECTION_RECONCILIATION");
			Date tarih = iMap.getDate(MapKeys.RECON_DATE);
			String tarihStr = "";
			if (tarih != null) {
				tarihStr = CommonHelper.getDateString(tarih, "dd.MM.yyyy");
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			BigDecimal corporateCollectionTotal = new BigDecimal("0");
			int corporateCollectionCount = 0;

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);

			String islemTipi = FATURA_BEDELI;
			SurmeliGazDataResult result = client.yapilanTahsilatlar(clientID, tarihStr, islemTipi,serviceMessage);
			String corpCollectTotalStr = "";
			if (result != null&&result.getFIELD2()!=null&&result.getFIELD3()!=null) {
				corpCollectTotalStr = result.getFIELD2().replace(",", ".");
				corporateCollectionTotal = new BigDecimal(corpCollectTotalStr);
				corporateCollectionCount = Integer.parseInt(result.getFIELD3());
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			islemTipi = BAGLANTI_BEDELI;
			result = client.yapilanTahsilatlar(clientID, tarihStr, islemTipi,serviceMessage);
			if (result != null&&result.getFIELD2()!=null&&result.getFIELD3()!=null) {
				corpCollectTotalStr = result.getFIELD2().replace(",", ".");
				corporateCollectionTotal = new BigDecimal(result.getFIELD2()).add(corporateCollectionTotal);
				corporateCollectionCount = Integer.parseInt(result.getFIELD3()) + corporateCollectionCount;
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			islemTipi = GUVENCE_BEDELI;
			result = client.yapilanTahsilatlar(clientID, tarihStr, islemTipi,serviceMessage);
			if (result != null&&result.getFIELD2()!=null&&result.getFIELD3()!=null) {
				corpCollectTotalStr = result.getFIELD2().replace(",", ".");
				corporateCollectionTotal = new BigDecimal(result.getFIELD2()).add(corporateCollectionTotal);
				corporateCollectionCount = Integer.parseInt(result.getFIELD3()) + corporateCollectionCount;
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			if (bankCollectionTotal.compareTo(corporateCollectionTotal) == 0 && corporateCollectionCount == bankCollectionCount) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateCollectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCollectionCount);
		} catch (Exception e) {
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			output.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, e.getMessage().length()<950? e.getMessage() : e.getMessage().substring(0, 949));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_SURMELI_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SURMELI_COLLECTION_RECONCILIATION_DETAIL");
		SurmeliGazOnlineClient client = getSoapClient(iMap);
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(
					iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":")
							.concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":")
							.concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			String responseCode = "";
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Date tarih = iMap.getDate(MapKeys.RECON_DATE);
			String tarihStr = "";
			if (tarih != null) {
				tarihStr = CommonHelper.getDateString(tarih, "dd.MM.yyyy");
			}

			int corporateCollectionCount = iMap.getBigDecimal(MapKeys.RECON_CORPORATE_COUNT).intValue();
			int bankCollectionCount = iMap.getBigDecimal(MapKeys.RECON_BANK_COUNT).intValue();
			List<SurmeliGazDataResult> surmeliGazDataResultList = client.tahsilatSor(clientID, tarihStr,serviceMessage);
			iMap.put("REQUEST_XML_COLLECTION_RECONCILIATION_DETAIL", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_COLLECTION_RECONCILIATION_DETAIL", serviceMessage.getResponse());
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int makbuzlistLenght = 0;
			int makbuzCollectionCount = 0;

			if (surmeliGazDataResultList != null) {
				makbuzlistLenght = surmeliGazDataResultList.size();
				SurmeliGazDataResult surmeliGazDataResult = new SurmeliGazDataResult();
				for (int i = 0; i < makbuzlistLenght; i++) {
					surmeliGazDataResult = surmeliGazDataResultList.get(i);
					reconCorpAmountMap.put("CORPORATE", makbuzCollectionCount, MapKeys.SUBSCRIBER_NO1, surmeliGazDataResult.getFIELD3());
					reconCorpAmountMap.put("CORPORATE", makbuzCollectionCount, MapKeys.INVOICE_NO, surmeliGazDataResult.getFIELD6());
					reconCorpAmountMap.put("CORPORATE", makbuzCollectionCount, MapKeys.PAYMENT_AMOUNT, surmeliGazDataResult.getFIELD5());
					reconCorpAmountMap.put("CORPORATE", makbuzCollectionCount, MapKeys.PARAMETER3, surmeliGazDataResult.getFIELD6());
					makbuzCollectionCount++;
				}
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.TRX_NO, reconBankMap.get(MapKeys.TRX_NO));
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;

			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						BigDecimal bankAmount = new BigDecimal(reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).replace(",", ".")).setScale(2, BigDecimal.ROUND_UP);
						BigDecimal corpAmount = new BigDecimal(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT).replace(",", ".")).setScale(2, BigDecimal.ROUND_UP);
						
						if (CommonHelper.trimStart(reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1), '0').equals(
								reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))
								&& reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.INVOICE_NO))
								&& corpAmount.equals(bankAmount)) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat istegi gonder
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.PARAMETER3, reconBankMap.getString("BANK", j, MapKeys.PARAMETER3));
						request.put(MapKeys.PARAMETER4, reconBankMap.getString("BANK", j, MapKeys.PARAMETER4));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, iMap.getString(MapKeys.RECON_DATE));

						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",
									onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(
									TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ")
											.concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE,
								ReconciliationProcessType.collectionMessageSent);// Tahsilat
																					// Mesaji
																					// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT).replace(",", "."));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER4));

						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						BigDecimal bankAmount = new BigDecimal(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT).replace(",", ".")).setScale(2, BigDecimal.ROUND_UP);
						BigDecimal corpAmount = new BigDecimal(reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).replace(",", ".")).setScale(2, BigDecimal.ROUND_UP);
						
						if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(
								CommonHelper.trimStart(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1), '0'))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO).equals(
										reconBankMap.getString("BANK", k, MapKeys.INVOICE_NO))
								&& corpAmount.equals(bankAmount)) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PARAMETER3, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER3));
						request.put(MapKeys.PARAMETER4, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER4));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_3, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER3));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER4));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, iMap.getString(MapKeys.RECON_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",
									onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// Tahsilatta hata al�nca yakal�yoruz yola devam
							// ediyoruz
							logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
							logger.error(System.currentTimeMillis(), e);
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(
									TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ")
											.concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).replace(",", "."));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_SIBESKI_GET_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_SURMELI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			SurmeliGazOnlineClient client = getSoapClient(iMap);
			String clientID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String responseCode = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SURMELI_COLLECTION_RECONCILIATION");
			Date tarih = iMap.getDate(MapKeys.RECON_DATE);
			String tarihStr = "";
			if (tarih != null) {
				tarihStr = CommonHelper.getDateString(tarih, "dd.MM.yyyy");
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			BigDecimal corporateCollectionTotal = new BigDecimal("0");
			int corporateCollectionCount = 0;

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);

			String islemTipi = FATURA_BEDELI;
			SurmeliGazDataResult result = client.yapilanTahsilatlar(clientID, tarihStr, islemTipi,serviceMessage);
			String corpCollectTotalStr = "";
			if (result != null&&result.getFIELD2()!=null&&result.getFIELD3()!=null) {
				corpCollectTotalStr = result.getFIELD2().replace(",", ".");
				corporateCollectionTotal = new BigDecimal(corpCollectTotalStr);
				corporateCollectionCount = Integer.parseInt(result.getFIELD3());
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			islemTipi = BAGLANTI_BEDELI;
			result = client.yapilanTahsilatlar(clientID, tarihStr, islemTipi,serviceMessage);
			if (result != null&&result.getFIELD2()!=null&&result.getFIELD3()!=null) {
				corpCollectTotalStr = result.getFIELD2().replace(",", ".");
				corporateCollectionTotal = new BigDecimal(result.getFIELD2()).add(corporateCollectionTotal);
				corporateCollectionCount = Integer.parseInt(result.getFIELD3()) + corporateCollectionCount;
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			islemTipi = GUVENCE_BEDELI;
			result = client.yapilanTahsilatlar(clientID, tarihStr, islemTipi,serviceMessage);
			if (result != null&&result.getFIELD2()!=null&&result.getFIELD3()!=null) {
				corpCollectTotalStr = result.getFIELD2().replace(",", ".");
				corporateCollectionTotal = new BigDecimal(result.getFIELD2()).add(corporateCollectionTotal);
				corporateCollectionCount = Integer.parseInt(result.getFIELD3()) + corporateCollectionCount;
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			if (bankCollectionTotal.compareTo(corporateCollectionTotal) == 0 && corporateCollectionCount == bankCollectionCount) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				output.putAll(onlineCorporateServiceCallOutputMap);
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}else{
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			
			
		} catch (Exception e) {
			iMap.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getRequest());
			output.put("REQUEST_XML_GET_DEBT_INQUIRY", serviceMessage.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, e.getMessage().length()<950? e.getMessage() : e.getMessage().substring(0, 949));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	public static boolean isResponseCodeApprove(GMMap inMap) {
		if (!(inMap.getString("RETURN_CODE").equals("0"))) {
			return false;
		} else {
			return true;
		}

	}

	private static SurmeliGazOnlineClient getSoapClient(GMMap iMap) throws Exception {
		SurmeliGazOnlineClient client = new SurmeliGazOnlineClient(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
		return client;
	}
	
}
