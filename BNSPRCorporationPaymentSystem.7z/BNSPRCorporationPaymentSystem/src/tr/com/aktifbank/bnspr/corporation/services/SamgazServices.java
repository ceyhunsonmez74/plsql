package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.SamgazReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.samgaz.SamgazClient;
import tr.com.aktifbank.integration.samgaz.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.samgaz.entegrasyon.services.BorcSorgulaParam;
import com.samgaz.entegrasyon.services.FaturaDetay;
import com.samgaz.entegrasyon.services.FaturaOdemeParam;
import com.samgaz.entegrasyon.services.MutabakatOzet;
import com.samgaz.entegrasyon.services.SamgazApiException_Exception;

public class SamgazServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	
	private static final Long BRANCH_CODE = new Long(555);
	private static final String WS_RESPONSE_CODE="WS_RESPONSE_CODE";
	private static final String WS_RESPONSE_MESSAGE="WS_RESPONSE_MESSAGE";
	
	private static final Log logger = LogFactory.getLog(SamgazServices.class);

	
	@GraymoundService("ICS_SAMGAZ_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMGAZ_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		
		try {
		
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			
			
			String aboneNo = "";
			String tckn = "";
			String vkn = "";
			BorcSorgulaParam borcSorgulaParam = new BorcSorgulaParam();


			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !isZero(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
				aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				borcSorgulaParam.setAboneNo(aboneNo);
			}
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2)) && !isZero(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				tckn = iMap.getString(MapKeys.SUBSCRIBER_NO2);
				borcSorgulaParam.setTcKimlikNo(tckn);

			}
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2)) && !isZero(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				vkn = iMap.getString(MapKeys.SUBSCRIBER_NO3);
				borcSorgulaParam.setVergiNo(vkn);

			}
			

			ServiceMessage serviceMessage = new ServiceMessage();
			List<FaturaDetay> faturaDetays= SamgazClient.borcSorgula(wsUrl, wsUserName, wsPassword,borcSorgulaParam,serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());			
			
			//Basarili sonuc disindaki tum hatalarda exception atiyor zaten.
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			for(FaturaDetay faturaDetay : faturaDetays){
				Map<String, String> maps=new HashMap<String, String>();
				maps.put("corporateCode", corporateCode);
				maps.put("subscriberNo1", faturaDetay.getAboneNo());
				maps.put("invoiceNo", faturaDetay.getFaturaNo());
				maps.put("paymentStatus", DatabaseConstants.PaymentStatuses.Collected);
				if(!isCollectedInvoiceMaps(maps)){
					
					Timestamp stamp = new Timestamp(faturaDetay.getSonOdemeTarihi());
					  Date dueDate = new Date(stamp.getTime());
					  String termYear = String.valueOf(CommonHelper.getYear(dueDate));
						String termMonth =String.valueOf(CommonHelper.getMonth(dueDate));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, faturaDetay.getAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, tckn);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, faturaDetay.getFaturaNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, faturaDetay.getTutar());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, faturaDetay.getAboneNo()+" "+faturaDetay.getAboneSoyadi());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, dueDate);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, faturaDetay.getTutar());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}	
			}
		} catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);			
		}
		return outMap;
	}
	
	@GraymoundService("ICS_SAMGAZ_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMGAZ_DO_INVOICE_COLLECTION");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
				String refNo="";
				// Yine de tek olanlar icin defaultu cekelim.
				String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
				String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				if (iMap.getString(MapKeys.PARAMETER1)!=null && !"null".equals(iMap.getString(MapKeys.PARAMETER1))) {
					refNo=iMap.getString(MapKeys.PARAMETER1);
				}else{
					refNo=getRefNo();
				}
				
				String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

				ServiceMessage serviceMessage = new ServiceMessage();
				FaturaOdemeParam faturaOdemeParam = new FaturaOdemeParam();
				faturaOdemeParam.setAboneNo(iMap.getString(MapKeys.SUBSCRIBER_NO1));
				faturaOdemeParam.setBankaReferansKodu(refNo);
				faturaOdemeParam.setFaturaNo(iMap.getString(MapKeys.INVOICE_NO));
				faturaOdemeParam.setOdemeSekli(Integer.valueOf(paymentChannel));
				faturaOdemeParam.setOdemeTarihi(getTimeStamp(new Date()));
				BigDecimal makbizID= SamgazClient.getPort(wsUrl, wsUserName, wsPassword, serviceMessage).borcOde(faturaOdemeParam);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());			
				
				
		
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter1(refNo);		
					session.saveOrUpdate(invoicePayment); 
					
					GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		} catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	@GraymoundService("ICS_SAMGAZ_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMGAZ_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			
			
			String unId = iMap.getString("PARAMETER_1", null); 
			if(StringUtil.isEmpty(unId))
			{
				unId = iMap.getString(MapKeys.PARAMETER1
			);}
			String paymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd/MM/yyyy");
			
			
			
			ServiceMessage serviceMessage = new ServiceMessage();
			String returnCode = SamgazClient.getPort(wsUrl, wsUserName, wsPassword, serviceMessage).odemeIptal(unId, iMap.getString("REJECTED_REASON"));
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());			
			
			
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("STO_SAMGAZ_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SAMGAZ_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			
			
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		
			ServiceMessage serviceMessage = new ServiceMessage();
			String response = SamgazClient.getPort(wsUrl, wsUserName, wsPassword, serviceMessage).talimatVer(aboneNo);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());			

			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
	
		} catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("STO_SAMGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SAMGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
		
			
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			ServiceMessage serviceMessage = new ServiceMessage();
			SamgazClient.getPort(wsUrl, wsUserName, wsPassword, serviceMessage).talimatIptal(aboneNo);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());			
			
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
	
		} catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_SAMGAZ_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMGAZ_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
		
			

			Long date= new Long(0);
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PROCESS_DATE))){
				 date = getTimeStamp(CommonHelper.getDateTime(iMap.getString(MapKeys.PROCESS_DATE), "yyyyMMdd"));
			}else{
				 date = getTimeStamp(new Date());
			}
			
			ServiceMessage serviceMessage = new ServiceMessage();
			List<FaturaDetay> faturaDetays=SamgazClient.getPort(wsUrl, wsUserName, wsPassword, serviceMessage).sonOdemeTarihiGelmisTalimatliFaturalar(date);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());			
			
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			int i = 0;
			outMap.put(MapKeys.TABLE_SIZE, faturaDetays.size());
			for(FaturaDetay faturaDetay : faturaDetays){
				Timestamp stamp = new Timestamp(faturaDetay.getSonOdemeTarihi());
				  Date dueDate = new Date(stamp.getTime());
				  String termYear = String.valueOf(CommonHelper.getYear(dueDate));
					String termMonth =String.valueOf(CommonHelper.getMonth(dueDate));
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, faturaDetay.getAboneNo());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, faturaDetay.getFaturaNo());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, faturaDetay.getTutar());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, faturaDetay.getAboneNo()+" "+faturaDetay.getAboneSoyadi());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, dueDate);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, termYear);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, termMonth);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_AMOUNT, faturaDetay.getTutar());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
				i++;
			}
		} catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	
	@GraymoundService("ICS_SAMGAZ_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SAMGAZ_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		try {
			
			Long date= new Long(0);
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))){
				 date = getTimeStamp(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			}else{
				 date = getTimeStamp(new Date());
			}

			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			MutabakatOzet mutabakatOzet=SamgazClient.mutabakatSorgula(wsUrl, wsUserName, wsPassword, date, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());			
 			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				if (mutabakatOzet == null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				}
				else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, mutabakatOzet.getIslemTutar());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT,mutabakatOzet.getIslemSayisi());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, mutabakatOzet.getIptalTutar());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, mutabakatOzet.getIptalSayisi());
				}
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal bankCollectionTotal= reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL).add(reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			BigDecimal bankCollectionCount=reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_COUNT).add(reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(bankCollectionTotal) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(bankCollectionCount) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
				ServiceMessage serviceMessageClose = new ServiceMessage();
				String response = SamgazClient.mutabakatOnayi(wsUrl, wsUserName, wsPassword, date, serviceMessageClose);
				iMap.put("REQUEST_XML_CLOSE", serviceMessageClose.getRequest());
				outMap.put("RESPONSE_XML_CLOSE", serviceMessageClose.getResponse());
				if ("ONAY".equals(response)) {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}else{
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
				
				
			}
			else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
		}
		catch (Exception e2) {
			if(e2 instanceof SamgazApiException_Exception){
				outMap.put(WS_RESPONSE_CODE, ((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7));
				outMap.put(WS_RESPONSE_MESSAGE, ((SamgazApiException_Exception) e2).getFaultInfo().getMessage());
				GMMap responceCodeMap = getResponseCodeMapping(((SamgazApiException_Exception) e2).getFaultInfo().getCode().substring(7), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_SAMGAZ_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {

		GMMap output = new GMMap();
		logger.info("ICS_SAMGAZ_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SAMGAZ_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new SamgazReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_MANISAMASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_SAMGAZ_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_SAMGAZ_COLLECTION_RECONCILIATION_CLOSED");
		try {
			String screenRecon = iMap.getString("SCREEN_RECONCILIATION", "");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			if (screenRecon.equals("1")) {
				setCollectionInfoToOutput(output, reconDate, corporateCode, session);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	
	private static boolean isZero(String input){
		for(char c : input.toCharArray()){
			if (!"0".equals(Character.toString(c))){
				return false;
			}
		}
		return true;
	}

//	public static void main(String[] args) {
//		Timestamp stamp = new Timestamp(new Long("1431637200000"));
//		  Date date = new Date(stamp.getTime());
//		  System.out.println(date);
//	}
	
    public static long getTimeStamp(Date date )
    {
   	  Timestamp timestamp=new Timestamp(date.getTime());
        return  timestamp.getTime();
    }
    
    public static String getRefNo() throws Exception {
		String refNo ="";
		String tableName = "ICS_SAMGAZ_REF_NO"; 
		try {
			GMMap iMap = new GMMap();
			iMap.put("TABLE_NAME", tableName);
			Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap);
			refNo = "AKTF"+oMap.get("ID").toString();
			return refNo;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		
		
	}
//    public static void main(String[] args) {
//    	try {
//			Long date = getTimeStamp(CommonHelper.getDateTime("20151107", "yyyyMMdd"));
//			System.out.println(date);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

}
