package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationResubmitType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaCommonServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaDebtInqueryServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaDoInvoiceCollectionServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaReconService;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateChannelPrm;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AveaServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(AveaServices.class);
	private static final String SUN_CUSTOMER_ACCESS_TYPE = "1";
	private static final String CURRENCY_CODE = "949";
	private static final String OPERATION_SOURCE = "0";
	private static final String RECORD_NUMBER = "5";
	private static final String GATEWAY_ERROR = "GWERR";

	@GraymoundService("ICS_AVEA_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_INVOICE_DEBT_INQUIRY");
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String billInfoBuilder = "";
		String refInfoBuilder = "";
		String gatewayErrorDesc = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";
		int returnedBillNumber = 0;
		int counter = 0;
		try {
			Calendar cal = Calendar.getInstance();
			int month = cal.get(Calendar.MONTH) + 1;
			String sMonth = String.valueOf(month);
			if (month < 10) {
				sMonth = "0".concat(sMonth);
			}
			int year = cal.get(Calendar.YEAR);
			String sYear = String.valueOf(year);

			// set parameters
			String operationSource = OPERATION_SOURCE;
			String recordNumber = RECORD_NUMBER;
			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String currencyCode = CURRENCY_CODE;
			String sunCustomerAccessType = SUN_CUSTOMER_ACCESS_TYPE;
			String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String paymentPeriod = sYear.concat(sMonth);
			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			// set builder for logging
			builder.append("Parameters -> operationSource = ");
			builder.append(operationSource);
			builder.append("| recordNumber = ");
			builder.append(recordNumber);
			builder.append("| originatorIdCityCode = ");
			builder.append(originatorIdCityCode);
			builder.append("| originatorIdBranchCode = ");
			builder.append(originatorIdBranchCode);
			builder.append("| originatorIdOfficeCode = ");
			builder.append(originatorIdOfficeCode);
			builder.append("| originatorIdUserCode = ");
			builder.append(originatorIdUserCode);
			builder.append("| currencyCode = ");
			builder.append(currencyCode);
			builder.append("| sunCustomerAccessType = ");
			builder.append(sunCustomerAccessType);
			builder.append("| sunCustomerAccessNo = ");
			builder.append(sunCustomerAccessNo);
			builder.append("| paymentPeriod = ");
			builder.append(paymentPeriod);
			builder.append("| corporationId = ");
			builder.append(corporationId);
			builder.append("| operationCodeId = ");
			builder.append(operationCodeId);

			// set GW call parameters
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_SOURCE, operationSource); // P-25
			inputMap.put(AveaDebtInqueryServices.Input.RECORD_NUMBER, recordNumber); // P-26
			inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44
			inputMap.put(AveaDebtInqueryServices.Input.CURRENCY_CODE, currencyCode);// P-49
			inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_TYPE, sunCustomerAccessType);// P-60
			inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_NO, sunCustomerAccessNo);// P-60
			inputMap.put(AveaDebtInqueryServices.Input.PEYMENT_PERIOD, getPaymentPeriod(corporateCode));// P-63
			// corporationId corresponds to OID field on
			// ics.gw_corporation_definition table
			inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			// operationCodeId corresponds to OID field on
			// ics.gw_corporation_operation_code table
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);
			// asagidaki 3 satir canliya giderken silinecek
			// logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY will get FTM connection...");
			// GMConnection gmConnection = GMConnection.getConnection("GW_CON");
			// logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY got FTM connection successfully...");
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",inputMap));
			logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY will call BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE with values -> ".concat(builder.toString()));
			// asagidaki satir canliya giderken acilacak
			returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
			logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
			// check if an error is occured on GW
			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					responseCode = GATEWAY_ERROR;
					logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
					logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
				} else {
					responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
					logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
				}
			} else {
				responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
				logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
			}

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			returnedBillNumber = returnMap.getInt(AveaDebtInqueryServices.Output.RECORD_NUMBER);
			try {
				if (returnMap.containsKey("SERVER_STAN")) {
					String serverStan = returnMap.getString("SERVER_STAN");
					String stan = returnMap.getString("STAN");
					if (Integer.parseInt(stan) == Integer.parseInt(serverStan)) {
					} else {
						responceCodeMap = getResponseCodeMapping(GATEWAY_ERROR, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> TIMEOUT -> Gateway timeout problemi meydana geldi... STAN degerleri ayni degil ");
					}
				}
			} catch (Exception e) {
				logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> an error occured when comparing STAN values..");
			}
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// no error go ahead.
				for (int billNumber = 0; billNumber < returnedBillNumber; billNumber++) {
					if (!isCollectedInvoice(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_NO), sunCustomerAccessNo, "", "", "", corporateCode)) {
						String stringAmount = CommonHelper.trimStart(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_AMOUNT), '0');
						if (StringUtil.isEmpty(stringAmount)) {
							continue; // fatura tutari 0 TL gelirse
						}
						String leftOfSeperator = stringAmount.substring(0, stringAmount.length() - 2);
						String rightOfSeperator = stringAmount.substring(stringAmount.length() - 2, stringAmount.length());
						stringAmount = leftOfSeperator.concat(".").concat(rightOfSeperator);
						String termYear = returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_TERM).substring(0, 4);
						String termMonth = returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_TERM).substring(4, 6);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, sunCustomerAccessNo);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_NO).trim());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, stringAmount);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_NAME_SURNAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_EXPIRY_DATE), "yyyyMMdd"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, stringAmount);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_REF_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_SEQ_NO));
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_AMOUNT).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_CUSTOMER_ACCESS_TYPE).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_CUSTOMER_NO).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_EXPIRY_DATE).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_NAME_SURNAME).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_NO).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_PHONE_NO).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_REF_NO).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_SEQ_NO).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_TERM).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.BILL_INFO, billNumber, AveaDebtInqueryServices.Output.BillInfo.BILL_INFO_TYPE).toString());
						billInfoBuilder = billInfoBuilder.concat(":");
						billInfoBuilder = billInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.STAN).toString());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, billInfoBuilder.toString());
						refInfoBuilder = refInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.STAN).toString()); // P-11
						refInfoBuilder = refInfoBuilder.concat(":");
						refInfoBuilder = refInfoBuilder.concat(returnMap.getString(AveaDebtInqueryServices.Output.TRANS_DATE).toString()); // P-13
						refInfoBuilder = refInfoBuilder.concat(":");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, refInfoBuilder.toString());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						billInfoBuilder = "";
					}
				}
				logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY finished succesfully");
			} else {
				// an error occured
				logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY an error accoured with error code : ".concat(errorCode));
				logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY an error accoured with response code : ".concat(responseCode));
				logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY an error accoured returnMap : ".concat(returnMap.toString()));
				logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
			}
		} catch (Throwable e2) {
			logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY an error accoured with response code : ".concat(responseCode));
			logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY an error accoured returnMap : ".concat(returnMap.toString()));
			logger.error("ICS_AVEA_INVOICE_DEBT_INQUIRY -> an error is occured...".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e2);
		} finally {
			outMap.put("CALL_VALUES", builder.toString().concat(returnMap.toString()));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_DO_INVOICE_COLLECTION");
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String errorMessage = "";
		String gatewayErrorDesc = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
		String errorCode = "";
		try {
			String channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			Short collectionType = iMap.getBigDecimal(MapKeys.COLLECTION_TYPE).shortValue();
			Session hibernateSession = CommonHelper.getHibernateSession();
			if (isStandingOrderCollection) {
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION is called for standing order collection...call debt inqury service");
				GMMap mapForDebtInq=new GMMap();
				mapForDebtInq.put(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1,"34");
				mapForDebtInq.put(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2,"104");
				mapForDebtInq.put(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3,"12");
				mapForDebtInq.put(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4,"CS1002");
				mapForDebtInq.put(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5,"1");
				mapForDebtInq.put(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6,"21");
				mapForDebtInq.put(MapKeys.CORPORATE_CODE,corporateCode);
				mapForDebtInq.put(MapKeys.SUBSCRIBER_NO1,iMap.getString(MapKeys.SUBSCRIBER_NO1));
				mapForDebtInq.put(MapKeys.SUBSCRIBER_NO1,iMap.getString(MapKeys.SUBSCRIBER_NO1));
				mapForDebtInq.put(MapKeys.COLLECTION_TYPE,iMap.getString(MapKeys.COLLECTION_TYPE));
				mapForDebtInq.put(MapKeys.COLLECTION_TYPE_NAME,iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
				GMMap debtInqResultMap=CommonHelper.callGraymoundServiceInHibernateSession("ICS_AVEA_INVOICE_DEBT_INQUIRY", mapForDebtInq);
				
				for (int i = 0; i < debtInqResultMap.getSize("INVOICES"); i++) {
					String debtInvoiceNo=debtInqResultMap.getString("INVOICES",i,MapKeys.INVOICE_NO).trim();
					String realInvoiceNo=iMap.getString(MapKeys.INVOICE_NO).trim();
					if (debtInvoiceNo.equals(realInvoiceNo)) {
						iMap.put(MapKeys.SUBSCRIBER_NO1, debtInqResultMap.getString("INVOICES",i,MapKeys.SUBSCRIBER_NO1));
						iMap.put("BILL_INFO", debtInqResultMap.getString("INVOICES",i,"BILL_INFO"));
						iMap.put(MapKeys.AMOUNT, debtInqResultMap.getString("INVOICES",i,MapKeys.AMOUNT));
						iMap.put(MapKeys.SUBSCRIBER_NAME, debtInqResultMap.getString("INVOICES",i,MapKeys.SUBSCRIBER_NAME));
						iMap.put(MapKeys.INVOICE_DUE_DATE, debtInqResultMap.getString("INVOICES",i,MapKeys.INVOICE_DUE_DATE));
						iMap.put(MapKeys.INVOICE_TERM_YEAR, debtInqResultMap.getString("INVOICES",i,MapKeys.INVOICE_TERM_YEAR));
						iMap.put(MapKeys.INVOICE_TERM_MONTH, debtInqResultMap.getString("INVOICES",i,MapKeys.INVOICE_TERM_MONTH));
						iMap.put(MapKeys.PAYMENT_TYPE, debtInqResultMap.getString("INVOICES",i,MapKeys.PAYMENT_TYPE));
						iMap.put(MapKeys.PAYMENT_TYPE_NAME, debtInqResultMap.getString("INVOICES",i,MapKeys.PAYMENT_TYPE_NAME));
						iMap.put(MapKeys.COLLECTION_AMOUNT, debtInqResultMap.getString("INVOICES",i,MapKeys.COLLECTION_AMOUNT));
						iMap.put(MapKeys.INSTALLMENT_NO, debtInqResultMap.getString("INVOICES",i,MapKeys.INSTALLMENT_NO));
						iMap.put(MapKeys.PARAMETER1, debtInqResultMap.getString("INVOICES",i,MapKeys.PARAMETER1));
						iMap.put(MapKeys.PARAMETER2, debtInqResultMap.getString("INVOICES",i,MapKeys.PARAMETER2));
						iMap.put(MapKeys.PARAMETER3, debtInqResultMap.getString("INVOICES",i,MapKeys.PARAMETER3));
						iMap.put(MapKeys.PARAMETER4, debtInqResultMap.getString("INVOICES",i,MapKeys.PARAMETER4));
					}
				}
			} else {
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION is called for regular collection...");
			}
			// set parameters

			String operationSource = "";

			try {
				CorporateChannelPrm channelParameter = (CorporateChannelPrm) hibernateSession.createCriteria(CorporateChannelPrm.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("sourceCode", sourceCode)).add(Restrictions.eq("channelCode", channelCode)).add(Restrictions.eq("collectionType", collectionType)).uniqueResult();

				if (channelParameter != null) {
					operationSource = channelParameter.getCorporateConstant();
				} else {
					operationSource = "0";
				}
			} catch (Exception e) {
				logger.error("Exception on channel conversion on Avea Services");
				logger.error(System.currentTimeMillis(), e);
				operationSource = "0";
			}

			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String currencyCode = CURRENCY_CODE;
			String sunCustomerAccessType = SUN_CUSTOMER_ACCESS_TYPE;
			String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			Calendar cal = Calendar.getInstance();
			int month = cal.get(Calendar.MONTH) + 1;
			String sMonth = String.valueOf(month);
			if (month < 10) {
				sMonth = "0".concat(sMonth);
			}
			int year = cal.get(Calendar.YEAR);
			String sYear = String.valueOf(year);
			String paymentPeriod = sYear.concat(sMonth);
			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			// set builder for logging
			builder.append("Parameters -> operationSource = ");
			builder.append(operationSource);
			builder.append("| originatorIdCityCode = ");
			builder.append(originatorIdCityCode);
			builder.append("| originatorIdBranchCode = ");
			builder.append(originatorIdBranchCode);
			builder.append("| originatorIdOfficeCode = ");
			builder.append(originatorIdOfficeCode);
			builder.append("| originatorIdUserCode = ");
			builder.append(originatorIdUserCode);
			builder.append("| currencyCode = ");
			builder.append(currencyCode);
			builder.append("| sunCustomerAccessType = ");
			builder.append(sunCustomerAccessType);
			builder.append("| sunCustomerAccessNo = ");
			builder.append(sunCustomerAccessNo);
			builder.append("| paymentPeriod = ");
			builder.append(paymentPeriod);
			builder.append("| corporationId = ");
			builder.append(corporationId);
			builder.append("| operationCodeId = ");
			builder.append(operationCodeId);

			int day = cal.get(Calendar.DAY_OF_MONTH);
			String sDay = String.valueOf(day);
			if (day < 10) {
				sDay = "0".concat(sDay);
			}
			// set GW call parameters
			String acceptanceDate = "";
			String captureDate = "";
			if (iMap.containsKey(MapKeys.PAYMENT_DATE)) {
				acceptanceDate = iMap.getString(MapKeys.PAYMENT_DATE).substring(0, 8);
				captureDate = iMap.getString(MapKeys.PAYMENT_DATE).substring(0, 8);
			} else {
				acceptanceDate = sYear.concat(sMonth).concat(sDay);
				captureDate = sYear.concat(sMonth).concat(sDay);
			}
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION acceptanece date = ".concat(acceptanceDate));
			inputMap.put(AveaDoInvoiceCollectionServices.Input.CAPTURE_DATE, captureDate); // P-17
			inputMap.put(AveaDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25
			inputMap.put(AveaDoInvoiceCollectionServices.Input.RECORD_NUMBER, "01"); // P-26
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.CURRENCY_CODE, currencyCode);// P-49
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, acceptanceDate);// P-58
			String sParameter3 = iMap.getString(MapKeys.PARAMETER3);
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION is called with parameter 3 is = ".concat(sParameter3.toString()));
			String[] parameterArray = sParameter3.split(":");
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_CUSTOMER_ACCESS_TYPE, parameterArray[1].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_PHONE_NO, parameterArray[6].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_CUSTOMER_NO, parameterArray[2].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_NAME_SURNAME, parameterArray[4].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_TYPE, parameterArray[10].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_TERM, parameterArray[9].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_EXPIRY_DATE, parameterArray[3].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_REF_NO, parameterArray[7].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_NO, parameterArray[5].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_SEQ_NO, parameterArray[8].toString().trim());// P-62
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_AMOUNT, CommonHelper.trimStart(parameterArray[0].toString().trim(), '0'));// P-62

			String sParameter4 = iMap.getString(MapKeys.PARAMETER4);
			String[] parameterArray2 = sParameter4.split(":");

			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_STAN, parameterArray2[0].toString().trim());// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_DATE, parameterArray2[1].toString().trim());// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_ORDER_NO, "000000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_BANK_CODE, "0000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_MERCHANT_ID, "00000000000000000000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_AUTH_CODE, "0000000000");// P-48

			inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			inputMap.put(AveaDoInvoiceCollectionServices.Input.STAN, parameterArray2[0].toString().trim());
			// operationCodeId corresponds to OID field on
			// ics.gw_corporation_operation_code table
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);
			// asagidaki 3 satir canliya giderken commentlenecek
			// logger.info("ICS_AVEA_DO_INVOICE_COLLECTION will get FTM connection...");
			// GMConnection gmConnection = GMConnection.getConnection("GW_CON");
			// logger.info("ICS_AVEA_DO_INVOICE_COLLECTION got FTM connection successfully...");
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION will call BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE with values -> ".concat(builder.toString()));
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",
			// inputMap));
			// asagidaki satir acilacak
			if (isStandingOrderCollection) {
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION -> otomatik odeme istegi geldi, odeme al ve kuruma mesaj yollama");
				responseCode = "00";
			} else {
				if (isCollectedInvoiceNoWithSubscriberNo(parameterArray[5].toString().trim(), parameterArray[6].toString().trim(), corporateCode, parameterArray[8].toString().trim())) {
					logger.info("ICS_AVEA_DO_INVOICE_COLLECTION -> fatura zaten tahsil edilmi� ");
					responseCode = "660";
					errorMessage = "Fatura zaten daha once tahsil edilmis. Odeme tablosunu kontrol ediniz!";
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
				} else {
					returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
					logger.info("ICS_AVEA_DO_INVOICE_COLLECTION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
					if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
						if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
							responseCode = GATEWAY_ERROR;
							logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
							logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
							gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
						} else {
							responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
						}
					} else {
						responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
						if (responseCode.equals("80")) {
							// mukerrer odeme oldu
							// iptal gonder
							inputMap.put(AveaDoInvoiceCollectionServices.Input.CAPTURE_DATE, captureDate); // P-17
							inputMap.put(AveaDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25
							inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

							inputMap.put(AveaDoInvoiceCollectionServices.Input.CURRENCY_CODE, currencyCode);// P-49
							inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, acceptanceDate);// P-58
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_CUSTOMER_ACCESS_TYPE, parameterArray[1].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_PHONE_NO, parameterArray[6].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_CUSTOMER_NO, parameterArray[2].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_NAME_SURNAME, parameterArray[4].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_TYPE, parameterArray[10].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_TERM, parameterArray[9].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_EXPIRY_DATE, parameterArray[3].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_REF_NO, parameterArray[7].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_NO, parameterArray[5].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_SEQ_NO, parameterArray[8].toString().trim());// P-44
							inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_AMOUNT, CommonHelper.trimStart(parameterArray[0].toString().trim(), '0'));// P-44

							inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_STAN, parameterArray2[0].toString().trim());// P-48
							inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_DATE, parameterArray2[1].toString().trim());// P-48
							inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_ORDER_NO, "000000");// P-48
							inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_BANK_CODE, "0000");// P-48
							inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_MERCHANT_ID, "00000000000000000000");// P-48
							inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_AUTH_CODE, "0000000000");// P-48
							inputMap.put(AveaDoInvoiceCollectionServices.Input.RECORD_NUMBER, "01"); // P-26

							inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
							// operationCodeId corresponds to OID field on
							// ics.gw_corporation_operation_code table
							inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, "7");
							inputMap.put(AveaDoInvoiceCollectionServices.Input.STAN, parameterArray2[0].toString().trim());
							boolean errorOccured = false;
							try {
								// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",
								// inputMap));
								returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
								if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
									errorOccured = true;
									if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
										logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
										logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
										gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
									}
								}
							} catch (Exception e) {
								errorOccured = true;
								logger.info("ICS_AVEA_DO_INVOICE_COLLECTION -> mukerrer odeme sonrasi iptal mesaji gonderilirken hata meydana geldi...".concat(e.getMessage().toString()));
								logger.info("ICS_AVEA_DO_INVOICE_COLLECTION -> ".concat(e.toString()));
							}
							String responseCodeCancel = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
							if (!errorOccured && responseCodeCancel.equals("00")) {
								GMMap cancelMap = new GMMap();
								cancelMap.put(MapKeys.CORPORATE_CODE, corporateCode);
								cancelMap.put(MapKeys.SUBSCRIBER_NO1, parameterArray[6].toString().trim());
								cancelMap.put(MapKeys.PAYMENT_AMOUNT, iMap.getString(MapKeys.PAYMENT_AMOUNT));
								cancelMap.put(MapKeys.PAYMENT_DATE, acceptanceDate);
								CommonHelper.callGraymoundServiceOutsideSession("ICS_AVEA_INSERT_CANCEL_RECORD", cancelMap);
							} else {
								logger.info("ICS_AVEA_DO_INVOICE_COLLECTION -> mukerrer odeme iptal mesaji gonderilemedi -> ".concat(parameterArray[6].toString().trim()).concat(" -> hata kodu ".concat(responseCodeCancel)));
							}
						}
					}
				}
			}
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter1(parameterArray[1].toString().trim());
				invoicePayment.setParameter2(parameterArray[6].toString().trim());
				invoicePayment.setParameter3(parameterArray[2].toString().trim());
				invoicePayment.setParameter4(parameterArray[4].toString().trim());
				invoicePayment.setParameter5(parameterArray[10].toString().trim());
				invoicePayment.setParameter6(parameterArray[9].toString().trim());
				invoicePayment.setParameter7(parameterArray[3].toString().trim());
				invoicePayment.setParameter8(parameterArray[7].toString().trim());
				invoicePayment.setParameter9(parameterArray[5].toString().trim());
				invoicePayment.setParameter10(parameterArray[8].toString().trim());
				invoicePayment.setParameter11(parameterArray[0].toString().trim());
				invoicePayment.setParameter12(operationSource);
				if (isStandingOrderCollection) {
					String sequenceNumber = CorporationServiceUtil.getSequenceCode("AVEA_TABLE");
					sequenceNumber = CommonHelper.fillCharacters(sequenceNumber, "0", 5, true);
					sequenceNumber = "9".concat(sequenceNumber);
					invoicePayment.setParameter13(sequenceNumber);
				} else {
					invoicePayment.setParameter13(returnMap.getString(AveaDoInvoiceCollectionServices.Output.STAN));
				}
				invoicePayment.setParameter14(acceptanceDate);
				invoicePayment.setParameter15(sMonth.concat(sDay));
				invoicePayment.setParameter16(paymentPeriod);
				invoicePayment.setParameter17(parameterArray2[0].toString().trim());
				invoicePayment.setParameter18(parameterArray2[1].toString().trim());
				invoicePayment.setParameter19(sParameter4);
				invoicePayment.setParameter20(sParameter3);
				session.saveOrUpdate(invoicePayment);
			} else {
				// an error occured
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with error code : ".concat(errorCode));
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with response code : ".concat(responseCode));
				if (isStandingOrderCollection) {
					logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured .... ");
				} else {
					logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured returnMap : ".concat(returnMap.toString()));
				}
				logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
			}
		} catch (Exception e) {
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with response code : ".concat(responseCode));
			if (isStandingOrderCollection) {
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured when standing order payment ");
			} else {
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured returnMap : ".concat(returnMap.toString()));
			}
			logger.error("ICS_AVEA_DO_INVOICE_COLLECTION -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e);
		} finally {
			outMap.put("CALL_VALUES", builder.toString().concat(returnMap.toString()));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_INSERT_CANCEL_RECORD")
	public static GMMap insertCancelRecord(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			invoicePayment payment = new invoicePayment();
			payment.setStatus(true);
			payment.setCorporateCode(iMap.getString(MapKeys.CORPORATE_CODE));
			payment.setCollectionType(Short.valueOf("0"));
			payment.setInvoiceMainOid("0");
			payment.setSubscriberNo1(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			payment.setPaymentStatus(PaymentStatuses.Cancelled);
			payment.setTxNo(new BigDecimal("-1"));
			payment.setInvoiceAmount(new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			payment.setPaymentAmount(new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			payment.setPaymentDate(iMap.getString(MapKeys.PAYMENT_DATE).concat("120000"));
			payment.setCancelDate(iMap.getString(MapKeys.PAYMENT_DATE).concat("120000"));
			session.saveOrUpdate(payment);
			session.flush();
			outMap.put("RESULT", "OK");
		} catch (Exception e) {
			logger.info("ICS_AVEA_INSERT_CANCEL_RECORD -> AVEA iptal kaydi olustururken hata meydana geldi..");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String gatewayErrorDesc = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";

		try {
			logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE is called...");
			// set parameters
			String operationSource = iMap.getString(MapKeys.PARAMETER_12);
			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String currencyCode = CURRENCY_CODE;
			String sunCustomerAccessType = SUN_CUSTOMER_ACCESS_TYPE;
			String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String paymentPeriod = iMap.getString(MapKeys.PARAMETER16);
			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 2
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 7

			// set builder for logging
			builder.append("Parameters -> operationSource = ");
			builder.append(operationSource);
			builder.append("| originatorIdCityCode = ");
			builder.append(originatorIdCityCode);
			builder.append("| originatorIdBranchCode = ");
			builder.append(originatorIdBranchCode);
			builder.append("| originatorIdOfficeCode = ");
			builder.append(originatorIdOfficeCode);
			builder.append("| originatorIdUserCode = ");
			builder.append(originatorIdUserCode);
			builder.append("| currencyCode = ");
			builder.append(currencyCode);
			builder.append("| sunCustomerAccessType = ");
			builder.append(sunCustomerAccessType);
			builder.append("| sunCustomerAccessNo = ");
			builder.append(sunCustomerAccessNo);
			builder.append("| paymentPeriod = ");
			builder.append(paymentPeriod);
			builder.append("| corporationId = ");
			builder.append(corporationId);
			builder.append("| operationCodeId = ");
			builder.append(operationCodeId);

			// set GW call parameters
			Calendar cal = Calendar.getInstance();
			int month = cal.get(Calendar.MONTH) + 1;
			String sMonth = String.valueOf(month);
			if (month < 10) {
				sMonth = "0".concat(sMonth);
			}
			int day = cal.get(Calendar.DAY_OF_MONTH);
			String sDay = String.valueOf(day - 1);
			if (day < 10) {
				sDay = "0".concat(sDay);
			}

			String acceptanceDate = iMap.getString(MapKeys.PARAMETER_14);
			inputMap.put(AveaDoInvoiceCollectionServices.Input.CAPTURE_DATE, iMap.getString(MapKeys.PARAMETER_15)); // P-17
			inputMap.put(AveaDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

			inputMap.put(AveaDoInvoiceCollectionServices.Input.CURRENCY_CODE, currencyCode);// P-49
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, acceptanceDate);// P-58
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_CUSTOMER_ACCESS_TYPE, iMap.getString(MapKeys.PARAMETER_1));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_PHONE_NO, iMap.getString(MapKeys.PARAMETER_2));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_CUSTOMER_NO, iMap.getString(MapKeys.PARAMETER_3));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_NAME_SURNAME, iMap.getString(MapKeys.PARAMETER_4));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_TYPE, iMap.getString(MapKeys.PARAMETER_5));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_TERM, iMap.getString(MapKeys.PARAMETER_6));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_EXPIRY_DATE, iMap.getString(MapKeys.PARAMETER_7));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_REF_NO, iMap.getString(MapKeys.PARAMETER_8));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_NO, iMap.getString(MapKeys.PARAMETER_9));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_SEQ_NO, iMap.getString(MapKeys.PARAMETER_10));// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.BILL_INFO, 0, AveaDoInvoiceCollectionServices.Input.BillInfo.BILL_INFO_AMOUNT, CommonHelper.trimStart(iMap.getString(MapKeys.PARAMETER_11), '0'));// P-44

			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_STAN, iMap.getString(MapKeys.PARAMETER_17));// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_DATE, iMap.getString(MapKeys.PARAMETER_18));// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_ORDER_NO, "000000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_BANK_CODE, "0000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_MERCHANT_ID, "00000000000000000000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_AUTH_CODE, "0000000000");// P-48
			inputMap.put(AveaDoInvoiceCollectionServices.Input.RECORD_NUMBER, "01"); // P-26

			inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			// operationCodeId corresponds to OID field on
			// ics.gw_corporation_operation_code table
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);
			inputMap.put(AveaDoInvoiceCollectionServices.Input.STAN, iMap.getString(MapKeys.PARAMETER_17));
			// asagidaki 3 satir kapanacak
			// logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE will get FTM connection...");
			// GMConnection gmConnection = GMConnection.getConnection("GW_CON");
			// logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE got FTM connection successfully...");
			logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE will call BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE with values -> ".concat(builder.toString()));
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",inputMap));
			// asagidaki satir acilacak
			returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
			logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));

			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					responseCode = GATEWAY_ERROR;
					logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
					logger.info("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
				} else {
					responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
				}
			} else {
				responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
			}

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with error code : ".concat(errorCode));
				logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with response code : ".concat(responseCode));
				logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_AVEA_DO_INVOICE_COLLECTION an error accoured with response code : ".concat(responseCode));
			logger.error("ICS_AVEA_SEND_COLLECTION_CANCEL_MESSAGE -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e);
		} finally {
			outMap.put("CALL_VALUES", builder.toString().concat(returnMap.toString()));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_CLOSE_COLLECTION_RECONCILIATION_MANUALLY")
	public static GMMap closeReconciliationManually(GMMap iMap) {
		GMMap output = new GMMap();
		String reconLogOid = null;
		String reconDate = iMap.getString("RECON_DATE");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {

			String operationSource = "0";
			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);// 34
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);// 104
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);// 12
			String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);// CS1002;
			String currencyCode = CURRENCY_CODE;
			String reconInfoTransCode = "11";
			String reconInfoTransState = "0";
			String reconInfoCancelTransCode = "21";
			String responseCode = "";
			String gatewayErrorDesc = "";

			int corporateCount = 0;
			BigDecimal corporateAmount = new BigDecimal(0);
			int corporateCancelCount = 0;
			BigDecimal corporateCancelAmount = new BigDecimal(0);

			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 2
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 11

			reconLogOid = CommonBusinessOperations.insertReconLog(corporateCode, reconDate, CommonHelper.getStringTimeNow(), ReconciliationResubmitType.ReconciliationClose);

			GMMap inputMap = new GMMap();

			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44
			inputMap.put(AveaReconService.Input.SETTLEMENT_CURRENCY_CODE, currencyCode);// P-50

			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoTransCode);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, 0);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, "000");// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);// P-56
			inputMap.put(AveaCommonServices.Input.RECON_OPERATION_COUNT, "1");

			inputMap.put(AveaDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25

			inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, reconDate);// P-58
			inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);

			GMMap returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);

			int operationCount = returnMap.getInt("RECON_OPERATION_COUNT");

			if (returnMap.containsKey(AveaDebtInqueryServices.Output.RESPONSE_CODE)) {
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
				for (int i = 0; i < operationCount; i++) {
					if (returnMap.getString("RECON_INFO", i, "RECON_INFO_TRANS_CODE").equals("011")) {
						corporateCount = Integer.parseInt(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS"));
						corporateAmount = new BigDecimal(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(0, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2).concat(".")
								.concat(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length())));
					}
					if (returnMap.getString("RECON_INFO", i, "RECON_INFO_TRANS_CODE").equals("021")) {
						corporateCancelCount = Integer.parseInt(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS"));
						corporateCancelAmount = new BigDecimal(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(0, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2).concat(".")
								.concat(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length())));
					}
				}

			}
			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					responseCode = GATEWAY_ERROR;
					logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
					logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
				} else {
					responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
				}
			} else {
				responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
			}

			if (!responseCode.equals(GATEWAY_ERROR)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				String sCorporateAmount = corporateAmount.toString();
				if (sCorporateAmount.indexOf(".") > -1) {
					if (sCorporateAmount.length() - sCorporateAmount.indexOf(".") < 3) {
						sCorporateAmount = sCorporateAmount.concat("0");
					}
				} else {
					sCorporateAmount = sCorporateAmount.concat("00");
				}
				sCorporateAmount = sCorporateAmount.replace(",", "");
				sCorporateAmount = sCorporateAmount.replace(".", "");

				inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, corporateCount);// P-56
				inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, sCorporateAmount);// P-56

				if (corporateCancelCount > 0) {
					String sReconInfoTotalCancelTransAmount = corporateCancelAmount.toString();

					if (sReconInfoTotalCancelTransAmount.indexOf(".") > -1) {
						if (sReconInfoTotalCancelTransAmount.length() - sReconInfoTotalCancelTransAmount.indexOf(".") < 3) {
							sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.concat("0");
						}
					} else {
						sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.concat("00");
					}
					sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.replace(",", "");
					sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.replace(".", "");

					inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoCancelTransCode);
					inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, corporateCancelCount);
					inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, sReconInfoTotalCancelTransAmount);
					inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);

					inputMap.put(AveaCommonServices.Input.RECON_OPERATION_COUNT, "2");
				}

				returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);

				if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
					if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
						responseCode = GATEWAY_ERROR;
						logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
						logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
						gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
					} else {
						responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
					}
				} else {
					responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
				}

				if (!responseCode.equals(GATEWAY_ERROR)) {
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ClosedManually, corporateAmount.subtract(corporateCancelAmount), corporateCancelAmount, corporateAmount.subtract(corporateCancelAmount), corporateCancelAmount, new Date(), reconDate, corporateCode, corporateCount - corporateCancelCount, corporateCancelCount, corporateCount - corporateCancelCount,
								corporateCancelCount, ReconciliationResubmitType.ReconciliationClose, null, null);
					} else {
						CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, responseCode, responceCodeMap.getString(MapKeys.ERROR_DESC));
					}
				} else {
					CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, responseCode, gatewayErrorDesc);
				}
			} else {
				CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, responseCode, gatewayErrorDesc);
			}
		} catch (Exception e) {
			try {
				CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, "-1", "Sistem hatas� : ".concat(e.getMessage()));
			} catch (Exception e1) {
				logger.error("An exception occured while updating recon log");
				logger.error(System.currentTimeMillis(), e);
			}
			throw ExceptionHandler.convertException(e);
		}

		return output;
	}

	@GraymoundService("ICS_AVEA_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_COLLECTION_RECONCILIATION");
		Session session = CommonHelper.getHibernateSession();
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String gatewayErrorDesc = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";
		String reconInfoTransCode = "11";
		String reconInfoCancelTransCode = "21";
		int reconInfoTotalTrans = 0;
		BigDecimal reconInfoTotalTransAmount = new BigDecimal("0");
		String reconInfoTransState = "0";
		String reconDate = iMap.getString(MapKeys.RECON_DATE);
		int corporateCount = 0;
		BigDecimal corporateAmount = new BigDecimal(0);
		int corporateCancelCount = 0;
		BigDecimal corporateCancelAmount = new BigDecimal(0);
		int operationCount = 0;
		try {

			// recon_detail_data da continious durumda bir kayit varmi diye
			// kontrol et eger boyle bir kayit var ise GW_CON in bizi
			// cagirmasini
			// bekliyoruz
			// demektir. hic bi islem yapmadan cik
			ReconLog recLog = (ReconLog) session.createCriteria(ReconLog.class).add(Restrictions.eq("oid", iMap.getString("RECON_LOG_OID"))).add(Restrictions.eq("status", true)).add(Restrictions.eq("reconStatus", DatabaseConstants.ReconciliationStatus.ReconciliationFailed)).uniqueResult();
			if (recLog != null) {
				if (recLog.getBankCount().intValue() < 0) {
					logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -->> Devam etmekte olan bir mutabakat oldugu icin mutabakat islemi continues statusunde bekletiliyor...");
					// Fatura odeme tipi icin 0 kullanilacak
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, "-1");
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "-1");
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, "-1");
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "-1");

					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "-1");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "-1");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "-1");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "-1");
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.Continues);
					return outMap;
				}
			}

			// set parameters
			String operationSource = "0";
			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);// 34
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);// 104
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);// 12
			String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);// CS1002;
			String currencyCode = CURRENCY_CODE;

			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 2
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 11

			// set builder for logging
			builder.append("Parameters -> operationSource = ");
			builder.append(operationSource);
			builder.append("| originatorIdCityCode = ");
			builder.append(originatorIdCityCode);
			builder.append("| originatorIdBranchCode = ");
			builder.append(originatorIdBranchCode);
			builder.append("| originatorIdOfficeCode = ");
			builder.append(originatorIdOfficeCode);
			builder.append("| originatorIdUserCode = ");
			builder.append(originatorIdUserCode);
			builder.append("| currencyCode = ");
			builder.append(currencyCode);
			// builder.append("| paymentPeriod = ");
			// builder.append(paymentPeriod);
			builder.append("| corporationId = ");
			builder.append(corporationId);
			builder.append("| operationCodeId = ");
			builder.append(operationCodeId);

			String acceptanceDate = reconDate;

			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44
			inputMap.put(AveaReconService.Input.SETTLEMENT_CURRENCY_CODE, currencyCode);// P-50
			iMap.put(MapKeys.TT_RECON_FLAG, true);
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			reconInfoTotalTrans = collectionCount + cancelCount;
			int reconInfoCancelTotalTrans = cancelCount;
			reconInfoTotalTransAmount = collectionTotal.add(cancelTotal);
			BigDecimal reconInfoTotalCancelTransAmount = new BigDecimal(cancelTotal.toString());
			String sReconInfoTotalTransAmount = reconInfoTotalTransAmount.toString();

			if (sReconInfoTotalTransAmount.indexOf(".") > -1) {
				if (sReconInfoTotalTransAmount.length() - sReconInfoTotalTransAmount.indexOf(".") < 3) {
					sReconInfoTotalTransAmount = sReconInfoTotalTransAmount.concat("0");
				}
			} else {
				sReconInfoTotalTransAmount = sReconInfoTotalTransAmount.concat("00");
			}
			sReconInfoTotalTransAmount = sReconInfoTotalTransAmount.replace(",", "");
			sReconInfoTotalTransAmount = sReconInfoTotalTransAmount.replace(".", "");
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoTransCode);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, reconInfoTotalTrans);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, sReconInfoTotalTransAmount);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);// P-56
			if (cancelCount > 0) {
				String sReconInfoTotalCancelTransAmount = reconInfoTotalCancelTransAmount.toString();

				if (sReconInfoTotalCancelTransAmount.indexOf(".") > -1) {
					if (sReconInfoTotalCancelTransAmount.length() - sReconInfoTotalCancelTransAmount.indexOf(".") < 3) {
						sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.concat("0");
					}
				} else {
					sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.concat("00");
				}
				sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.replace(",", "");
				sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.replace(".", "");
				inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoCancelTransCode);// P-56
				inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, reconInfoCancelTotalTrans);// P-56
				inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, sReconInfoTotalCancelTransAmount);// P-56
				inputMap.put(AveaReconService.Input.RECON_INFO, 1, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);// P-56
				inputMap.put(AveaCommonServices.Input.RECON_OPERATION_COUNT, "2"); // P-20
			} else {
				inputMap.put(AveaCommonServices.Input.RECON_OPERATION_COUNT, "1"); // P-20

			}
			inputMap.put(AveaDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25

			inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, acceptanceDate);// P-58
			inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			// operationCodeId corresponds to OID field on
			// ics.gw_corporation_operation_code table
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);

			// logger.info("ICS_AVEA_COLLECTION_RECONCILIATION will get GW_CON connection...");
			// GMConnection gmConnection = GMConnection.getConnection("GW_CON");
			// logger.info("ICS_AVEA_COLLECTION_RECONCILIATION got GW_CON connection successfully...");
			// logger.info("ICS_AVEA_COLLECTION_RECONCILIATION will call BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE with values -> ".concat(builder.toString()));
			logger.info("ICS_AVEA_COLLECTION_RECONCILIATION will call BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE with input map -> ".concat(inputMap.toString()));
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",inputMap));
			returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
			logger.info("ICS_AVEA_COLLECTION_RECONCILIATION is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
			operationCount = returnMap.getInt("RECON_OPERATION_COUNT");
			if (returnMap.containsKey(AveaDebtInqueryServices.Output.RESPONSE_CODE)) {
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
				for (int i = 0; i < operationCount; i++) {
					if (returnMap.getString("RECON_INFO", i, "RECON_INFO_TRANS_CODE").equals("011")) {
						corporateCount = Integer.parseInt(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS"));
						corporateAmount = new BigDecimal(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(0, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2).concat(".")
								.concat(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length())));
					}
					if (returnMap.getString("RECON_INFO", i, "RECON_INFO_TRANS_CODE").equals("021")) {
						corporateCancelCount = Integer.parseInt(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS"));
						corporateCancelAmount = new BigDecimal(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(0, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2).concat(".")
								.concat(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length())));
					}
				}

			}
			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					responseCode = GATEWAY_ERROR;
					logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
					logger.info("ICS_AVEA_COLLECTION_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
				} else {
					responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
				}
			} else {
				responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
			}

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION - kurumdan gelen gecerli tahsilat tutari = ".concat(sReconInfoTotalTransAmount));
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION - kurumdan gelen gecerli tahsilat sayisi = ".concat(Integer.toString(reconInfoTotalTrans)));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateAmount.subtract(corporateCancelAmount));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corporateCancelAmount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCount - corporateCancelCount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corporateCancelCount);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateAmount.subtract(corporateCancelAmount));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corporateCancelAmount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCount - corporateCancelCount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corporateCancelCount);
				// an error occured
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION an error accoured with error code : ".concat(errorCode));
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION an error accoured with response code : ".concat(responseCode));
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION an error accoured with error description : ".concat(responceCodeMap.getString(MapKeys.ERROR_DESC)));
				logger.info("ICS_AVEA_COLLECTION_RECONCILIATION istek sonucu GW den gelen returnMap ".concat(returnMap.toString()));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e) {
			logger.info("ICS_AVEA_COLLECTION_RECONCILIATION an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_AVEA_COLLECTION_RECONCILIATION an error accoured with response code : ".concat(responseCode));
			logger.error("ICS_AVEA_COLLECTION_RECONCILIATION -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;

	}

	@GraymoundService("ICS_AVEA_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();

		try {
			logger.info("ICS_AVEA_GET_COLLECTION_RECONCILIATION_DETAIL is called");
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("ICS_AVEA_GET_COLLECTION_RECONCILIATION_DETAIL finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_AVEA_DETAIL_FTM_FILE_CONTENT")
	public static GMMap detailFTMFileContent(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_DETAIL_FTM_FILE_CONTENT");
		GMMap outMap = new GMMap();
		try {
			String fileDefId = iMap.getString("FILE_DEF_ID");
			// fileDefId = "480";
			logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> fileDefId=" + fileDefId);
			String corporateCode = CommonHelper.getValueOfParameter("CDM_FILE_DEF_CORPORATE_CODE_MAPPING", fileDefId);
			// corporateCode="C-285";
			logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> corporate code=" + corporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCode);

			Session session = CommonHelper.getHibernateSession();
			Criteria criteriaReconLog = session.createCriteria(ReconLog.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime"));
			Calendar reconDate = Calendar.getInstance();

			BigDecimal ftmProcessOID = iMap.getBigDecimal("PROCESS_ID");
			// ftmProcessOID = new BigDecimal("1637");
			logger.info("PROCESS_ID is " + ftmProcessOID);
			if (ftmProcessOID == null) {
				logger.error("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> Error getting FTM Process OID from iMap");
				return outMap;
			}

			Criteria criteria = session.createCriteria(FtmProcess.class).add(Restrictions.eq("oid", ftmProcessOID));
			FtmProcess ftmProcess = (FtmProcess) criteria.uniqueResult();
			String reconDateStr = "";
			if (ftmProcess != null && ftmProcess.getFileName() != null) {
				String fileName = ftmProcess.getFileName();
				reconDateStr = fileName.substring(5, 13);
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> fileName is " + fileName + "reconDateStr is " + reconDateStr);
			}
			iMap.put(MapKeys.RECON_DATE, reconDateStr);
			reconDate.setTime(CommonHelper.getDateTime(reconDateStr.concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			List<ReconLog> reconLogList = criteriaReconLog.list();
			ReconLog reconLog = null;
			String reconLogOid = "";
			if (reconLogList != null && reconLogList.size() != 0) {
				reconLog = reconLogList.get(0);
				reconLogOid = reconLog.getOid();
			}

			try {
				String query = "update ics.recon_detail_data set status=0 where recon_log_oid='".concat(reconLogOid).concat("'");
				CommonHelper.executeQuery(query);
			} catch (Exception e) {
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> recon_detail_data update edilirken hata meydana geldi...");
			}

			Criteria criteriaFtmContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ftmProcessOID));
			@SuppressWarnings("unchecked")
			List<FtmFileContent> ftmFileContentList = criteriaFtmContentList.list();
			logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> ftmFileContentList size is " + ftmFileContentList.size());
			int ftmFileContentListOrder = 0;
			GMMap reconCorpAmountMap = new GMMap();
			Session sessionForInsert = CommonHelper.getHibernateSession();
			for (FtmFileContent ftmFileContent : ftmFileContentList) {
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> ftmFileContent line is " + ftmFileContent.getLine());
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> reconLog is " + reconLog);
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> reconLog.getDate is " + reconLog.getReconDate());
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> reconLog.getTime is " + reconLog.getReconTime());
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> corporateCode is " + corporateCode);
				logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> reconLogOid is " + reconLogOid);
				String fileString = ftmFileContent.getLine();
				String transactionType = "";
				String paymentAmount = fileString.substring(97, 115);
				paymentAmount = paymentAmount.substring(0, paymentAmount.length() - 2).concat(".").concat(paymentAmount.substring(paymentAmount.length() - 2, paymentAmount.length()));

				if ("D".equals(fileString.substring(0, 1))) {
					ReconDetailData rdd = new ReconDetailData();
					rdd.setCorporateCode(corporateCode);
					rdd.setParameter1(fileString.substring(0, 1));
					rdd.setParameter2(fileString.substring(1, 9));
					rdd.setParameter3(fileString.substring(9, 10));
					rdd.setParameter4(fileString.substring(10, 12));
					rdd.setParameter5(fileString.substring(12, 15));
					rdd.setParameter6(fileString.substring(15, 23));
					rdd.setParameter7(fileString.substring(23, 31));
					rdd.setSubscriberNo1(fileString.substring(31, 41));
					rdd.setSubscriberNo2(fileString.substring(41, 71));
					rdd.setParameter8(fileString.substring(71, 77));
					rdd.setInvoiceNo(fileString.substring(77, 93));
					rdd.setParameter8(fileString.substring(93, 95));

					rdd.setCollectionType((short) 0);

					rdd.setPaymentAmount(new BigDecimal(paymentAmount));
					if ("011".equals(fileString.substring(12, 15))) {
						transactionType = "T";
					} else {
						transactionType = "I";
					}
					rdd.setTransactionType(transactionType);
					rdd.setStatus(true);
					rdd.setParameter9(fileString);
					rdd.setReconLogOid(reconLogOid);
					rdd.setReconDate(reconLog.getReconDate());
					rdd.setReconTime(reconLog.getReconTime());
					sessionForInsert.saveOrUpdate(rdd);
				}
				ftmFileContentListOrder++;
			}
			sessionForInsert.flush();

			logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> detail logs are inserted temp table successfully...");
			iMap.put("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> RECON_LOG_OID", reconLogOid);
			List<Object> parameters = new ArrayList<Object>();
			String strSQL = "";
			// strSQL =
			// "select * from (select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > "
			// +
			// "iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2,tahsilat.parameter9 "
			// +
			// "from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
			// +
			// "sayacTahsilat,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type "
			// + "is not null and status = 1 and corporate_code = '"
			// + corporateCode
			// + "' and "
			// + "recon_log_oid = '"
			// + reconLogOid
			// +
			// "' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
			// +
			// "subscriber_no1,subscriber_no2,parameter9 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
			// +
			// "sayacIptal,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data "
			// +
			// "where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '"
			// + corporateCode
			// + "' "
			// + "and recon_log_oid = '"
			// + reconLogOid
			// + "' and transaction_type = 'I' "
			// +
			// "group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2,parameter9 "
			// + "order by invoice_no, transaction_type desc) iptal "
			// + "where tahsilat.invoice_no = iptal.invoice_no union "
			// +
			// "select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
			// + "subscriber_no2,parameter9 from ics.recon_detail_data "
			// +
			// "where collection_type='0' and transaction_type = 'T' and status = 1 and corporate_code = '"
			// + corporateCode
			// + "' and "
			// + "recon_log_oid = '" + reconLogOid + "' and invoice_no not in "
			// + "(select invoice_no from ics.recon_detail_data " +
			// "where collection_type='0' and transaction_type = 'I' and status = 1 and corporate_code = '"
			// + corporateCode + "' and recon_log_oid = '" + reconLogOid +
			// "')) where payment_status='T'";// +
			strSQL = String.format(QueryRepository.AveaServicesRepository.GET_DETAIL_FTM_FILE_CONTENT, corporateCode, reconLogOid, corporateCode, reconLogOid, corporateCode, reconLogOid, corporateCode, reconLogOid);
			// "order by payment_status desc; ";
			logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> ".concat(strSQL));
			String TABLE_NAME = "RECON_DETAIL_DATA";

			GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);

			int faturaTahsilatAdedi = reconLogList.get(0).getBankCount().intValue();
			int faturaTahsilatIptalAdedi = reconLogList.get(0).getBankCancelCount().intValue();

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);

			boolean found = true;

			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			String bankCode;
			for (int i = 0; i < faturaTahsilatAdedi; i++) {
				for (int j = 0; j < al.size(); j++) {
					if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO).equals(returnMap.getString(TABLE_NAME, j, MapKeys.INVOICE_NO))
							&& reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
						found = true;// bizdeki tahsilat kaydi kurumda
										// da bulundu
						break;
					} else {
						found = false;// bizdeki tahsilat kaydi kurumda
										// bulunamadi
					}
				}
				if (!found) {
					// bizdeki tahsilat kurumda bulunamadi ise
					// kuruma tahsilat mesaji gondericem
					logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> bizdeki tahsilat kurumda bulunamadi, kuruma tahsilat mesaji gondericem...");
					GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, reconBankMap.getString("BANK", i, MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", i, MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, reconBankMap.getString("BANK", i, MapKeys.PARAMETER20));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, reconBankMap.getString("BANK", i, MapKeys.PARAMETER19));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, reconBankMap.getString("BANK", i, MapKeys.PARAMETER5));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, reconBankMap.getString("BANK", i, MapKeys.PARAMETER6));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER7, reconBankMap.getString("BANK", i, MapKeys.PARAMETER7));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER8, reconBankMap.getString("BANK", i, MapKeys.PARAMETER8));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER9, reconBankMap.getString("BANK", i, MapKeys.PARAMETER9));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER10, reconBankMap.getString("BANK", i, MapKeys.PARAMETER10));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER11, reconBankMap.getString("BANK", i, MapKeys.PARAMETER11));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER12, reconBankMap.getString("BANK", i, MapKeys.PARAMETER12));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER13, reconBankMap.getString("BANK", i, MapKeys.PARAMETER13));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER14, reconBankMap.getString("BANK", i, MapKeys.PARAMETER14));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER15, reconBankMap.getString("BANK", i, MapKeys.PARAMETER15));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER16, reconBankMap.getString("BANK", i, MapKeys.PARAMETER16));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER17, reconBankMap.getString("BANK", i, MapKeys.PARAMETER17));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER18, reconBankMap.getString("BANK", i, MapKeys.PARAMETER18));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER19, reconBankMap.getString("BANK", i, MapKeys.PARAMETER19));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER20, reconBankMap.getString("BANK", i, MapKeys.PARAMETER20));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_BRANCH));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", i, "SUBSCRIBER_NO2"));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("BANK", i, MapKeys.TERM_YEAR));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", i, MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.REC_DATE, reconBankMap.getString("BANK", i, MapKeys.REC_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_SOURCE));
					onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("BANK", i, MapKeys.BRANCH_CODE));
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> tahsilat mesaji gonderilecek...");
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi");
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> tahsilat mesaji kuruma basarili olarak gonderildi...");
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> SUBSCRIBER NO 1: ".concat(reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1)));
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> INVOICE NO : ".concat(reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO)));
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> PAYMENT AMOUNT : ".concat(reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT)));

					} catch (Exception e) {
						// TODO Tahsilatta hata al�nca
						// yakal�yoruz
						// yola
						// devam ediyoruz
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> tahsilat mesaji hata aldi..".concat(e.getMessage()));
						logger.error("An exception occured while executing ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> on Reconciliation services");
						logger.error(System.currentTimeMillis(), e);
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
					}

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));

					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString("BANK", i, MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString("BANK", i, MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString("BANK", i, MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString("BANK", i, MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString("BANK", i, MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString("BANK", i, MapKeys.PARAMETER4));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					logger.info("ICS_AVEA_GET_COLLECTION_RECONCILIATION_DETAIL log is inserted...");
				}

			}
			found = false;
			for (int i = 0; i < faturaTahsilatIptalAdedi; i++) {
				for (int j = 0; j < al.size(); j++) {
					if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO).equals(returnMap.getString(TABLE_NAME, j, MapKeys.INVOICE_NO))
							&& reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
						found = true;// bizdeki tahsilat iptal kaydi
										// kurumda tahsilat kaydi olarak
										// var
						break;
					} else {
						found = false;// bizdeki tahsilat iptal kaydi
										// kurumda da var o zaman sorun
										// yok
					}
				}
				if (found) {
					// bizdeki tahsilat iptal kaydi kurumun
					// tahsilatlari arasinda
					// o zaman tahsilat iptal gonderelim
					logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> bizdeki tahsilat iptal kaydi kurumun tahsilatlari arasinda...tahsilat iptal mesaji gonderilecek...");
					GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_3, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER3));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_4, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_5, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER5));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_6, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER6));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_7, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER7));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_8, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER8));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_9, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER9));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_10, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER10));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_11, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER11));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_12, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER12));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_13, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER13));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_14, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER14));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_15, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER15));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_16, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER16));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_17, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER17));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_18, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER18));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_19, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER19));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_20, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER20));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("BANK_CANCEL", i, MapKeys.TERM_YEAR));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("BANK_CANCEL", i, MapKeys.BRANCH_CODE));
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT ->  tahsilat iptal servisi cagirilmadan once");
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> tahsilat iptal servisi cagirildiktan sonra...");
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi");
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT ->  tahsilat iptal mesaji kuruma basarili olarak gonderildi...");
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT ->  SUBSCRIBER NO 1: ".concat(reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1)));
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT ->  INVOICE NO : ".concat(reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO)));
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT ->  PAYMENT AMOUNT : ".concat(reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT)));
					} catch (Exception e) {
						// TODO Tahsilatta hata al�nca
						// yakal�yoruz
						// yola
						// devam ediyoruz
						logger.info("ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> tahsilat iptal servisi hata aldi".concat(e.getMessage()));
						logger.error("An exception occured while executing ICS_AVEA_DETAIL_FTM_FILE_CONTENT ->  on Reconciliation services");
						logger.error(System.currentTimeMillis(), e);
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
					}

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER4));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}

			}

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AVEA_DETAIL_FTM_FILE_CONTENT -> ".concat(ExceptionHandler.convertException(e2).toString()));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER is started...");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String toDayToCompare = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			GMMap sorMap = getBankStandingOrdersForAvea(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER recon count to check is ".concat(Integer.toString(reconCollectionCount)));
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				String subscriberNumber = CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0');
				logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" will be called.."));
				iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNumber);
				iMap.put(MapKeys.COLLECTION_TYPE, "0");
				iMap.put(MapKeys.COLLECTION_TYPE_NAME, "Fatura Odeme");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_AVEA_INVOICE_DEBT_INQUIRY", iMap);
				int billNumber = reconBankMap.getSize(MapKeys.INVOICE_LIST);
				logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" is called and return map").concat(reconBankMap.toString()).concat(" and bill number is").concat(Integer.toString(billNumber)));
				if (billNumber > 0) {
					for (int z = 0; z < billNumber; z++) {
						logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" compares date invoice date -> ").concat(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE).toString()).concat(" with todays date -> ").concat(toDayToCompare));
						if (toDayToCompare.equals(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE))) {
							logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" returned result which matches due date with today..."));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER4));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static GMMap getBankStandingOrdersForAvea(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER is called getBankStandingOrdersForAvea...");
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.AveaServicesRepository.GET_BANK_STANDING_ORDERS, reconcilitionDate, reconcilitionDate, corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER found ".concat(Integer.toString(al.size())).concat(" standing order for VF"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			logger.info("ICS_AVEA_DEBT_INQUERY_FOR_STANDING_ORDER found 0 standing order");
		}
		return returnMap;
	}

	@GraymoundService("STO_AVEA_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_AVEA_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String gsmNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" gsm no -> ").concat(gsmNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_AVEA_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_AVEA_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" gsm no -> ").concat(aboneNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_COLLECTION_RECONCILIATION_CLOSED");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	public static String getPaymentPeriod(String corporateCode) {
		Session hibernateSession = CommonHelper.getHibernateSession();
		String result = "201001";
		int countAfterDue = 0;
		String countTypeAfterDue = "";
		int year = 0;
		int month = 0;
		String smonth = "";
		try {
			CorporateMaster corporateMaster = ((CorporateMaster) hibernateSession.createCriteria(CorporateMaster.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).uniqueResult());
			countAfterDue = Integer.parseInt(corporateMaster.getCountAfterDue().toString());
			countTypeAfterDue = corporateMaster.getCountTypeAfterDue();
			year = CommonHelper.getYear(new Date());
			month = CommonHelper.getMonth(new Date());
			Calendar cal = Calendar.getInstance();
			cal.setTimeZone(TimeZone.getTimeZone("GMT"));
			if (countTypeAfterDue.equals("Y")) {
				cal.add(Calendar.YEAR, (0 - countAfterDue));
			} else if (countTypeAfterDue.equals("M")) {
				cal.add(Calendar.MONTH, (0 - countAfterDue));
			}
			if (cal.get(Calendar.MONTH) < 10) {
				result = Integer.toString(cal.get(Calendar.YEAR)).concat("0").concat(Integer.toString(cal.get(Calendar.MONTH)));
			} else {
				result = Integer.toString(cal.get(Calendar.YEAR)).concat(Integer.toString(cal.get(Calendar.MONTH)));
			}

		} catch (Exception e) {
			result = "201001";
		}
		return result;
	}

	public static boolean isCollectedInvoiceNoWithSubscriberNo(String invoiceNo, String subscriberNo1, String corporateCode, String installmentNo) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter10", installmentNo)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("subscriberNo1", subscriberNo1)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
