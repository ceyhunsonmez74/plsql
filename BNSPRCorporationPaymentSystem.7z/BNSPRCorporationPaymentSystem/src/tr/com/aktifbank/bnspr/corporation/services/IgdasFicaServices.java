package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.IgdasFicaReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationTypes;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.igdas.IgdasFicaClient;
import tr.com.aktifbank.integration.igdas.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.igdas.ficaexternalenhancements.DTPAYMENTRETURNMESSAGE;
import com.igdas.ficaexternalenhancements.P3CashPointPaymentCreateFault;
import com.igdas.ficaexternalenhancements.P3CashPointPaymentReversalFault;
import com.sap.document.sap.rfc.functions.ZFICASTLMTSRGRESB;
import com.sap.document.sap.rfc.functions.ZFICASTLMTTOPLUSRG;
import com.sap.document.sap.rfc.functions.ZFKKEXCRETURN;
import com.sap.document.sap.rfc.functions.ZPIFICABNKMUTABAKATResponse;
import com.sap.document.sap.rfc.functions.ZPIFICADOSYASORGUResponse;
import com.sap.document.sap.rfc.functions.ZPIFICADOSYATALEPResponse;
import com.sap.document.sap.rfc.functions.ZPIFICARETURNQUERYResponse;
import com.sap.document.sap.rfc.functions.ZPIFICATALIMATBLDRMResponse;
import com.sap.document.sap.rfc.functions.ZPIFICATALIMATSORGUResponse;
import com.sap.document.sap.rfc.functions.ZPIFICATALIMATTOPLUResponse;
import com.sap.xi.fica.global.CashPointOpenItem;
import com.sap.xi.fica.global.CashPointOpenItemSummary;
import com.sap.xi.fica.global.CashPointOpenItemSummaryResponseByElementsMessage;
import com.sap.xi.fica.global.testing.P3CashPointOpenItemFault;

public class IgdasFicaServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(IgdasFicaServices.class);

	private final static String TALIMAT = "T";
	private final static String TALIMAT_IPTAL = "I";
	private final static String SECIM_TIPI = "3"; // 1 tckn, 2 VKN, 3 Sozlesme
	private final static String BRANCH_CODE = "00555";

	@GraymoundService("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String docId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String refId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String currencyCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			// client icerisinde hangi alan dolu ise o alana gore sorgulama
			// yapilacaktir
			String contractId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String taxNumberId = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String as400id = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			CashPointOpenItemSummaryResponseByElementsMessage response = null;
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";
			try {
				response = IgdasFicaClient.borcSorgula(connTimeout,reqTimeout, serviceUrl, username, password, docId, refId, currencyCode, new BigDecimal("0"), as400id, taxNumberId, contractId, sm);
			} catch (P3CashPointOpenItemFault f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getStandard().getFaultDetail().get(0).getId();
				responseMessage = f.getFaultInfo().getStandard().getFaultDetail().get(0).getText();
				logger.info("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
				logger.info("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (CashPointOpenItemSummary openItem : response.getCashPointOpenItemSummary()) {
					for (CashPointOpenItem borc : openItem.getCashPointOpenItem()) {
						if (!isCollectedInvoice(borc.getContractAccountID(), String.valueOf(borc.getInvoiceID()), "", "", "", corporateCode)) {
							if (borc.getOpenAmount().getValue().compareTo(new BigDecimal("0")) > 0) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getContractAccountID());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getPaymentFormID().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getOpenAmount().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getOpenItemTransactionDescription().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(borc.getDueDate().toGregorianCalendar().getTime()));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getDueDate().toGregorianCalendar().get(Calendar.YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getDueDate().toGregorianCalendar().get(Calendar.MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getOpenAmount().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getInvoiceID());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}
						}
					}
				}
			}
		} catch (Throwable e2) {
			logger.error("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_IGDAS_FICA_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String docId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String refId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String currencyCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			int valorDate = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			String branchId = BRANCH_CODE;

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String paymentFormReferenceID = iMap.getString(MapKeys.INVOICE_NO);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			String groupId = docId.concat(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
			String contractId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceAmount = iMap.getString(MapKeys.INVOICE_AMOUNT);
			String paymentAmount = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			if (!invoiceAmount.equals(paymentAmount)) {
				// kismi ya da fazla odeme yapiliyorsa fatura tutarini degistir
				invoiceAmount = paymentAmount;
			}
			if (isStandingOrderCollection) {
				logger.info("ICS_IGDAS_FICA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			} else {
				logger.info("ICS_IGDAS_FICA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			DTPAYMENTRETURNMESSAGE response = null;
			String responseCode = "0";
			String responseMessage = "";
			try {
				response = IgdasFicaClient.tahsilat(connTimeout,reqTimeout, serviceUrl, username, password, docId, refId, branchId, paymentChannel, groupId, trasnactionId, currencyCode, new BigDecimal(invoiceAmount), valorDate, contractId, paymentFormReferenceID, sm);
				responseCode = response.getMessage().get(0).getMessageId();
				responseMessage = response.getMessage().get(0).getMessageText();
			} catch (P3CashPointPaymentCreateFault f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getStandard().getFaultDetail().get(0).getId();
				responseMessage = f.getFaultInfo().getStandard().getFaultDetail().get(0).getText();
				logger.info("ICS_IGDAS_FICA_DO_INVOICE_COLLECTION P3CashPointOpenItemFault error code = ".concat(responseCode));
				logger.info("ICS_IGDAS_FICA_DO_INVOICE_COLLECTION P3CashPointOpenItemFault error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(trasnactionId);
				session.saveOrUpdate(invoicePayment);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_IGDAS_FICA_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String docId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String refId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String trasnactionId = iMap.getString(MapKeys.PARAMETER_2, null);
			if (trasnactionId == null) {
				trasnactionId = iMap.getString(MapKeys.PARAMETER2);
			}
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			DTPAYMENTRETURNMESSAGE response = null;
			String responseCode = "0";
			String responseMessage = "";
			try {
				response = IgdasFicaClient.tahsilatIptal(connTimeout,reqTimeout, serviceUrl, username, password, docId, refId, trasnactionId, sm);
				responseCode = response.getMessage().get(0).getMessageId();
				responseMessage = response.getMessage().get(0).getMessageText();
			} catch (P3CashPointPaymentReversalFault f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getStandard().getFaultDetail().get(0).getId();
				responseMessage = f.getFaultInfo().getStandard().getFaultDetail().get(0).getText();
				logger.info("ICS_IGDAS_FICA_SEND_COLLECTION_CANCEL_MESSAGE P3CashPointOpenItemFault response code = ".concat(responseCode));
				logger.info("ICS_IGDAS_FICA_SEND_COLLECTION_CANCEL_MESSAGE P3CashPointOpenItemFault response message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_IGDAS_FICA_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		ServiceMessage sm = new ServiceMessage();
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String docId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String bankakodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			String grupkodu = docId + reconDate;

			BigDecimal iadeTutar = new BigDecimal("0");
			BigDecimal iadeIptalTutar = new BigDecimal("0");
			String iadeIptalAdet = "0";
			String iadeAdet = "0";

			output.put("BANK", 0, "RECON_RETURN_TOTAL", iadeTutar);
			output.put("BANK", 0, "RECON_RETURN_CANCEL_TOTAL", iadeIptalTutar);
			output.put("BANK", 0, "RECON_RETURN_COUNT", iadeAdet);
			output.put("BANK", 0, "RECON_RETURN_CANCEL_COUNT", iadeIptalAdet);

			ZPIFICABNKMUTABAKATResponse response = IgdasFicaClient.mutabakat(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, grupkodu, String.valueOf(cancelCount), cancelTotal, String.valueOf(collectionCount), collectionTotal, iadeIptalAdet, iadeIptalTutar, iadeAdet, iadeTutar, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());

			// aldigin sayilari koy
			logger.info("ICS_IGDAS_FICA_COLLECTION_RECONCILIATION - response.getZPIFICABNKMUTABAKATResponse() null degil");
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getTHSLKRM() != null ? response.getTHSLKRM().getTUTAR() : new BigDecimal(0));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getTHSLKRM() != null ? response.getTHSLKRM().getADET() : 0);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIPTKRM() != null ? response.getIPTKRM().getTUTAR() : new BigDecimal(0));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIPTKRM() != null ? response.getIPTKRM().getADET() : 0);

			output.put("CORPORATE", 0, "RECON_RETURN_TOTAL", response.getIADEKRM() != null ? response.getIADEKRM().getTUTAR() : new BigDecimal(0));
			output.put("CORPORATE", 0, "RECON_RETURN_CANCEL_TOTAL", response.getIPTIADEKRM() != null ? response.getIPTIADEKRM().getTUTAR() : new BigDecimal(0));
			output.put("CORPORATE", 0, "RECON_RETURN_COUNT", response.getIADEKRM() != null ? response.getIADEKRM().getADET() : 0);
			output.put("CORPORATE", 0, "RECON_RETURN_CANCEL_COUNT", response.getIPTIADEKRM() != null ? response.getIPTIADEKRM().getADET() : 0);

			// tahsilat tutarlari
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)
					// iade tutarlari
					&& output.getBigDecimal("CORPORATE", 0, "RECON_RETURN_TOTAL").compareTo(output.getBigDecimal("BANK", 0, "RECON_RETURN_TOTAL")) == 0 && output.getInt("CORPORATE", 0, "RECON_RETURN_COUNT") == output.getInt("BANK", 0, "RECON_RETURN_COUNT")
					&& output.getBigDecimal("CORPORATE", 0, "RECON_RETURN_CANCEL_TOTAL").compareTo(output.getBigDecimal("BANK", 0, "RECON_RETURN_CANCEL_TOTAL")) == 0 && output.getInt("CORPORATE", 0, "RECON_RETURN_CANCEL_COUNT") == output.getInt("BANK", 0, "RECON_RETURN_CANCEL_COUNT")) {
				logger.info("ICS_IGDAS_FICA_COLLECTION_RECONCILIATION - mutabakat basarili olarak kapatildi ");
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				Session hibernateSession = CommonHelper.getHibernateSession();
				List<ReconLog> reconLogs = (List<ReconLog>) hibernateSession.createCriteria(ReconLog.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("reconStatus", ReconciliationStatus.Started)).add(Restrictions.eq("reconType", ReconciliationTypes.Collection)).add(Restrictions.eq("reconDate", reconDate))
						.addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime")).setMaxResults(1).list();
				// mutabakat istegi basarisiz olursa donen cevapta kurumun bize
				// gonderecegi dosya ismi olucak. bu dosya ismini al ve
				// recondetaildata tablosunda sakla sonra mutabakat detayda
				// burdan ismini alip dosyayi indirecegiz
				ReconDetailData log = new ReconDetailData();
				log.setStatus(true);
				log.setCorporateCode(corporateCode);
				log.setReconLogOid(reconLogs.get(0).getOid());
				log.setParameter1(response.getDOSYAID());
				hibernateSession.save(log);
				hibernateSession.flush();
				if (response.getRETURN() != null) {
					if (response.getRETURN().equals("IGDSWSBN24")) {
						logger.info("ICS_IGDAS_FICA_COLLECTION_RECONCILIATION -> mutabakat daha once kapatildigi icin mukerrer mutabakat hatasi alindi");
						output.put(MapKeys.ERROR_DESC, "M�kerrer mutabakat oldu.Bu tarih icin mutabakat daha once kapatilmis.Tekrar mutabakat tetiklenemez.Lutfen kontrollerinizi manuel olarak saglayiniz ya da kurum ile iletisime geciniz.");
					}
				}
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_IGDAS_FICA_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_IGDAS_FICA_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_IGDAS_FICA_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new IgdasFicaReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_IGDAS_FICA_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_IGDAS_FICA_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_COLLECTION_RECONCILIATION_CLOSED");
		try {
			// mutabakat cagirildiginda basarili olursa otomatik olarak
			// kapaniyor. kurumun mutabakat kapatma servisi yoktur. bunun icin
			// herhangi bir servis entegrasyonu yapilmadi!
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_IGDAS_FICA_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IGDAS_FICA_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankakodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			String subekodu = BRANCH_CODE;

			String sourceCode = iMap.getString(MapKeys.SOURCE);
			if (sourceCode == null){
				sourceCode = DatabaseConstants.SourceCodes.Account;
			}
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.valueOf(DatabaseConstants.CollectionTypes.InvoiceLoad);
			String kanal = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			String sozlesmeno = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			ZPIFICATALIMATSORGUResponse response = IgdasFicaClient.talimatSorgu(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, kanal, subekodu, SECIM_TIPI, sozlesmeno, sm);
			iMap.put("REQUEST_XML_TS", sm.getRequest());
			outMap.put("RESPONSE_XML_TS", sm.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
				String talimatveren = "";
				for (ZFICASTLMTSRGRESB talimat : response.getRESB().getItem())
					talimatveren = talimat.getADI() + " " + talimat.getSOYADI();
				ZPIFICATALIMATBLDRMResponse response2 = IgdasFicaClient.talimat(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, kanal, subekodu, sozlesmeno, talimatveren, TALIMAT, sm);
				iMap.put("REQUEST_XML_T", sm.getRequest());
				outMap.put("RESPONSE_XML_T", sm.getResponse());
				responceCodeMap = getResponseCodeMapping(response2.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, response2.getRETURN());
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_IGDAS_FICA_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IGDAS_FICA_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankakodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String subekodu = BRANCH_CODE;
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 

			String sourceCode = iMap.getString(MapKeys.SOURCE);
			if (sourceCode == null){
				sourceCode = DatabaseConstants.SourceCodes.Account;
			}
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.valueOf(DatabaseConstants.CollectionTypes.InvoiceLoad);
			String kanal = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			String sozlesmeno = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			ZPIFICATALIMATSORGUResponse response = IgdasFicaClient.talimatSorgu(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, kanal, subekodu, SECIM_TIPI, sozlesmeno, sm);
			iMap.put("REQUEST_XML_TS", sm.getRequest());
			outMap.put("RESPONSE_XML_TS", sm.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				String talimatveren = "";
				for (ZFICASTLMTSRGRESB talimat : response.getRESB().getItem())
					talimatveren = talimat.getADI() + " " + talimat.getSOYADI();
				ZPIFICATALIMATBLDRMResponse response2 = IgdasFicaClient.talimat(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, kanal, subekodu, sozlesmeno, talimatveren, TALIMAT_IPTAL, sm);
				iMap.put("REQUEST_XML_TI", sm.getRequest());
				outMap.put("RESPONSE_XML_TI", sm.getResponse());
				responceCodeMap = getResponseCodeMapping(response2.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_IGDAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankakodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dosyaturu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 

			ZPIFICADOSYASORGUResponse response = IgdasFicaClient.dosyaSorgula(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, dosyaturu, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = CommonHelper.getHibernateSession();
				String queryDate = CommonHelper.getHugeDateTimeString(new Date()).trim();
				String qd = CommonHelper.getShortDateTimeString(new Date());

				ZPIFICADOSYATALEPResponse response2 = IgdasFicaClient.dosyaTalep(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, response.getDOSYAID(), sm);
				iMap.put("REQUEST_XML_FILE", sm.getRequest());
				outMap.put("RESPONSE_XML_FILE", sm.getResponse());
				byte[] dosya = response2.getDOSYA();
				if (loadReconDetailDataTableForStandingOrder(dosya, session, corporateCode, collectionTypeId, queryDate, qd, "")) {

					Criteria criteria = session.createCriteria(ReconDetailData.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter1", "S")).add(Restrictions.eq("parameter9", queryDate.trim()));
					List<ReconDetailData> corporateStandingOrderPayments = (List<ReconDetailData>) criteria.list();

					GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

					GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
					int counter = 0;
					List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
						if (icsStandingOrder.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
							String subscriberNo = CommonHelper.trimStart(icsStandingOrder.getSubscriberNo1(), '0');
							for (ReconDetailData corpData : corporateStandingOrderPayments) {
								String s1 = CommonHelper.trimStart(corpData.getSubscriberNo1(), '0');
								if (s1.equals(subscriberNo) && qd.equals(corpData.getReconDate())) {
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, s1);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, corpData.getInvoiceNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, corpData.getPaymentAmount());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, corpData.getParameter7());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, corpData.getParameter5());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, corpData.getParameter5().substring(0, 4));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, corpData.getParameter5().substring(4, 6));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, collectionTypeId);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionTypeId);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, corpData.getPaymentAmount());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
								}
							}
						}
					}
					outMap.put(MapKeys.TABLE_SIZE, counter);
					outMap.put(MapKeys.RESPONSE_CODE, responseCode);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "Onay");
				}
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("STO_IGDAS_FICA_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IGDAS_FICA_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankakodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 

			ZPIFICATALIMATTOPLUResponse response = IgdasFicaClient.topluTalimatSorgu(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			String iptalList = "";
			String talimatList = "";
			if (response.getRESB() == null) {
				outMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderList.size());
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, 0);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
			} else {
				for (ZFICASTLMTTOPLUSRG corpStandingOrder : response.getRESB().getItem()) {
					String sozlesmeNo = CommonHelper.trimStart(corpStandingOrder.getSOZLESMENO(), '0');
					boolean found = false;
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						if (bankStandingOrderList.get(i).getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
							String bankSozlesmeNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo1(), '0');
							if (bankSozlesmeNo.equals(sozlesmeNo)) {
								found = true;
							}
						}
					}
					// kurumdaki talimat bizde bulunmaz ise iptal gonderilir
					if (!found) {
						iptalList = iptalList.concat(sozlesmeNo).concat(";");
						try {
							iMap.put(MapKeys.SUBSCRIBER_NO1, sozlesmeNo);
							GMServiceExecuter.call("STO_IGDAS_FICA_SEND_STANDING_ORDER_CANCEL_MESSAGE", iMap);
						} catch (GMRuntimeException e) {
							logger.info("STO_IGDAS_FICA_STANDING_ORDER_RECONCILIATION ".concat(sozlesmeNo).concat(" iptalinde hata : ").concat(e.getMessage()));
						}
					}
				}
				int bankStandingOrderCounter = 0;
				for (int i = 0; i < bankStandingOrderList.size(); i++) {
					if (bankStandingOrderList.get(i).getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
						String bankSozlesmeNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo1(), '0');
						boolean found = false;
						for (ZFICASTLMTTOPLUSRG corpStandingOrder : response.getRESB().getItem()) {
							String sozlesmeNo = CommonHelper.trimStart(corpStandingOrder.getSOZLESMENO(), '0');
							if (bankSozlesmeNo.equals(sozlesmeNo)) {
								found = true;
							}
						}
						// bizde talimatli kurumda bulunmaz ise talimat
						// gonderilir
						if (!found) {
							talimatList = talimatList.concat(bankSozlesmeNo).concat(";");
							try {
								iMap.put(MapKeys.SUBSCRIBER_NO1, bankSozlesmeNo);
								GMServiceExecuter.call("STO_IGDAS_FICA_SEND_STANDING_ORDER_MESSAGE", iMap);
							} catch (GMRuntimeException e) {
								logger.info("STO_IGDAS_FICA_STANDING_ORDER_RECONCILIATION ".concat(bankSozlesmeNo).concat(" talimat hata : ").concat(e.getMessage()));
							}
						}
						bankStandingOrderCounter++;
					}
				}
				String emails = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "EMAIL_LIST_FOR_STO_MAIL");
				String htmlBody = "Talimat iptal gonderilen abone listesi :".concat(iptalList).concat("\n").concat("Talimat istegi gonderilen abone listesi").concat(talimatList);
				htmlBody = htmlBody.concat("<br><br><br>");
				htmlBody = htmlBody.concat("Servis Donusu<br>");
				htmlBody = htmlBody.concat(response.getRESB().toString());
				CommonHelper.sendMail(Arrays.asList(emails.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "IGDAS Talimat Mutabakat batch'i i�in " + reconDate + " tarihli �al��ma raporu", htmlBody);

				outMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCounter);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, response.getRESB().getItem().size());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_IGDAS_FICA_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static boolean loadReconDetailDataTableForStandingOrder(byte[] dosyaByteArray, Session session, String corporateCode, String collectionTypeId, String reconLogOid, String reconDate, String reconTime) {
		boolean result = false;
		try {
			logger.info("...loadReconDeatilDataTable has just started...");
			int a = 0;
			String dosyaString = new String(dosyaByteArray);
			String kayitTipiHeader = dosyaString.substring(0, 1);
			String dosyaTipi = (String) dosyaString.subSequence(1, 3);
			String dosyaNo = (String) dosyaString.subSequence(3, 12);
			String dosyaTarihi = (String) dosyaString.subSequence(12, 20);
			String kurumAdi = (String) dosyaString.subSequence(20, 25);
			String bankaKodu = (String) dosyaString.subSequence(25, 29);
			String bankaTaniticisi = (String) dosyaString.subSequence(29, 39);
			String kayitTipiFooter = "";
			int base = 41;
			IgdasFicaReconciliationDetailBatch.addNewReconDetailData(session, Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiHeader, dosyaTipi, dosyaNo, dosyaTarihi, kurumAdi, bankaKodu, bankaTaniticisi, "Talimatli Borc yukleme dosya yuklemesi basliyor", reconLogOid, "Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
			logger.info("...loadReconDeatilDataTable header part finished...");
			do {
				String kayitTipiDetail = dosyaString.substring(base, base + 1);
				String satirNo = (String) dosyaString.subSequence(base + 1, base + 13);
				String kimlikNo = (String) dosyaString.subSequence(base + 13, base + 24);
				String sozlesmeNo = (String) dosyaString.subSequence(base + 24, base + 36);
				String faturaNo = (String) dosyaString.subSequence(base + 36, base + 48);
				String faturaTarihi = (String) dosyaString.subSequence(base + 48, base + 56);
				String faturaVadesi = (String) dosyaString.subSequence(base + 56, base + 64);
				String tutar = (String) dosyaString.subSequence(base + 64, base + 79);
				String paraBirimi = (String) dosyaString.subSequence(base + 79, base + 82);
				String aboneAdi = (String) dosyaString.subSequence(base + 82, base + 112);
				kayitTipiFooter = dosyaString.substring(base + 114, base + 115);
				base = base + 114;
				IgdasFicaReconciliationDetailBatch.addNewReconDetailData(session, Short.parseShort(collectionTypeId), corporateCode, faturaNo, kayitTipiDetail, satirNo, kimlikNo, faturaTarihi, faturaVadesi, paraBirimi, aboneAdi, "", reconLogOid, "Talimat", new BigDecimal(tutar), sozlesmeNo, "", "", "", "", reconLogOid, reconDate, reconTime);
				a++;
			} while (kayitTipiFooter.equals("S"));
			logger.info("...loadReconDeatilDataTable detail part finished...");

			String toplamBorcAdedi = (String) dosyaString.subSequence(base + 1, base + 11);
			String toplamBorcTutari = (String) dosyaString.subSequence(base + 11, base + 26);
			String toplamDVTutari = (String) dosyaString.subSequence(base + 26, base + 41);

			IgdasFicaReconciliationDetailBatch.addNewReconDetailData(session, Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiFooter, toplamBorcAdedi, toplamBorcTutari, toplamDVTutari, "Talimatli Borc yukleme dosya yuklemesi bitti", "Toplam y�klenen kayit sayisi : ".concat(String.valueOf(a)), "", "", reconLogOid, "Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid,
					reconDate, reconTime);

			logger.info("...loadReconDeatilDataTable footer part finished...");
			result = true;
		} catch (Exception e) {
			logger.info("...loadReconDetailDataTableForStandingOrder �al���rken hata meydana geldi...".concat(e.getMessage()));
			return result;
		}
		return result;
	}

	@GraymoundService("ICS_IGDAS_FICA_RETURN_CREDIT_QUERY")
	public static GMMap returnPaymentQuery(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_RETURN_CREDIT_QUERY");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage sm = new ServiceMessage();
		final String RESULTS = "RESULTS";
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String docId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String refId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 

			String tcknVkn = iMap.getString(MapKeys.SUBSCRIBER_NO1);// Mandatory
			String sapSozlesmeNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String eskiTesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO3);

			ZPIFICARETURNQUERYResponse response = IgdasFicaClient.iadeSorgula(connTimeout,reqTimeout, serviceUrl, username, password, docId, refId, sapSozlesmeNo, eskiTesisatNo, tcknVkn, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (ZFKKEXCRETURN iade : response.getOPENITEM().getItem()) {
					if (!isCollectedInvoice(iade.getVKONT(), iade.getOPBEL(), "", "", "", corporateCode)) {
						output.put(RESULTS, counter, MapKeys.SUBSCRIBER_NO1, tcknVkn);
						output.put(RESULTS, counter, MapKeys.SUBSCRIBER_NO2, iade.getVKONT());
						output.put(RESULTS, counter, MapKeys.SUBSCRIBER_NO3, eskiTesisatNo);
						output.put(RESULTS, counter, MapKeys.CORPORATE_PAYMENT_ID, iade.getOPBEL());
						output.put(RESULTS, counter, MapKeys.AMOUNT, iade.getBETRW());
						output.put(RESULTS, counter, MapKeys.PAYMENT_AMOUNT, iade.getBETRW());
						output.put(RESULTS, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						output.put(RESULTS, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						output.put(RESULTS, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						output.put(RESULTS, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						output.put(RESULTS, counter, MapKeys.PARAMETER1, iade.getWAERS());
						output.put(RESULTS, counter, "SELECT", false);
						output.put(RESULTS, counter, "OID", "0");
						counter++;
					}
				}
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_IGDAS_FICA_GET_RECONCILIATION_FILE")
	public static GMMap getReconciliationFile(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_GET_RECONCILIATION_FILE");
		ServiceMessage serviceMessageForRecon = new ServiceMessage();
		ServiceMessage serviceMessageForFile = new ServiceMessage();
		// parametrelerden servis cagirimi icin gerekli bilgileri al
		String serviceUrlRecon = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "SERVICE_URL_RECON");
		String serviceUrlFile = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "SERVICE_URL_FILE");
		String username = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "USERNAME");
		String password = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "PASSWORD");
		String bankakodu = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "BANK_CODE");
		String docId = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "DOC_ID").concat(iMap.getString("RECON_DATE"));
		String corporateCode = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "CORPORATE_CODE");
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
		
		GMMap responceCodeMap = new GMMap();
		try {
			// kurumun dosya olusturmasi icin mutabakat servisini 0 degerleri
			// ile cagiriyoruz
			ZPIFICABNKMUTABAKATResponse response = IgdasFicaClient.mutabakat(connTimeout,reqTimeout, serviceUrlRecon, username, password, bankakodu, docId, "0", new BigDecimal("0"), "0", new BigDecimal("0"), "0", new BigDecimal("0"), "0", new BigDecimal("0"), serviceMessageForRecon);
			iMap.put("REQUEST_XML_FOR_RECON", serviceMessageForRecon.getRequest());
			output.put("RESPONSE_XML_FOR_RECON", serviceMessageForRecon.getResponse());
			responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String fileName = "";
			try {
				fileName = response.getDOSYAID();
			} catch (Exception e) {
				fileName = "";
			}
			// hata aldi ise ve dosya adi gelmediyse
			// mutabakati sifir degerleri ile cagiridigimiz icin servis cagrimi
			// hata alacakt�r. ancak dosya adi gelmiyorsa gercekten hata meydana
			// geldi demektir. dosya adinin geldigi durumlarda islem yapmaya
			// devam edecegiz.
			if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE)) && fileName == null) {
				logger.info("ICS_IGDAS_FICA_GET_RECONCILIATION_FILE -> servis cagiriminda hata meydana geldi!");
				output.put("RESULT_MESSAGE", "Servis cagiriminda hata meydana geldi!Hata aciklamasi : ".concat(responceCodeMap.getString("RETURN_CODE_DESC")));
				return output;
			}
			logger.info("ICS_IGDAS_FICA_GET_RECONCILIATION_FILE -> indirilecek dosya adi : ".concat(fileName));
			int counter = 0;
			ZPIFICADOSYATALEPResponse response2 = null;
			// dosya hazirlanmasi icin once 3 saniye bekleyip sonra dosyayi
			// almaya calisicaz, 3 er saniye araliklar ile dosyanin olusup
			// olusmadigina bakilacak
			while (counter++ < 20 && response2 == null) {
				try {
					Thread.sleep(3000);
					response2 = IgdasFicaClient.dosyaTalep(connTimeout,reqTimeout, serviceUrlFile, username, password, bankakodu, fileName, serviceMessageForFile);
				} catch (InterruptedException e) {
					logger.info("ICS_IGDAS_FICA_GET_RECONCILIATION_FILE -> thread sleep hata aldi!");
					response2 = null;
				}
			}
			// dosya geldimi diye kontrol et
			if (response2.getDOSYA() != null) {
				// dosya geldi ise ekrana dondur
				byte[] dosyaByteArray = response2.getDOSYA();
				String dosyaString = new String(dosyaByteArray);
				output.put("FILE", dosyaString);
				output.put("RESULT_MESSAGE", "OK");
			}
		} catch (MalformedURLException e) {
			logger.info("ICS_IGDAS_FICA_GET_RECONCILIATION_FILE -> servis hata aldi!".concat(e.getMessage()));
			output.put("RESULT_MESSAGE", e.getMessage());
		} catch (P3CashPointOpenItemFault e) {
			logger.info("ICS_IGDAS_FICA_GET_RECONCILIATION_FILE -> servis hata aldi!".concat(e.getMessage()));
			output.put("RESULT_MESSAGE", e.getMessage());
		}
		return output;
	}

	@GraymoundService("ICS_IGDAS_FICA_GET_STO_LIST_CORPORATE")
	public static GMMap getStoList(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_FICA_GET_STO_LIST_CORPORATE");
		ServiceMessage serviceMessageForSto = new ServiceMessage();
		String username = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "USERNAME");
		String password = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "PASSWORD");
		String bankakodu = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "BANK_CODE");
		String serviceUrl = CommonHelper.getValueOfParameter("IGDAS_SERVICE_INFORMATION_FOR_FILE", "SERVICE_URL_FOR_STO");
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
		
		try {
			ZPIFICATALIMATTOPLUResponse response = IgdasFicaClient.topluTalimatSorgu(connTimeout,reqTimeout, serviceUrl, username, password, bankakodu, serviceMessageForSto);
			if (response.getRESB() == null) {
				output.put("RESULT_MESSAGE", "Talimatl� abone bulunamad�!");
			} else {
				output.put("STO_LIST", serviceMessageForSto.getResponse());
				output.put("RESULT_MESSAGE", "OK");
			}
		} catch (MalformedURLException e) {
		}
		return output;
	}
}
