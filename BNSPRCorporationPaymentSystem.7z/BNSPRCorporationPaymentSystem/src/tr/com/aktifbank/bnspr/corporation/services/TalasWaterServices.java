package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.seras.webservice.server.AboneBorcListesi;
import org.seras.webservice.server.TalimatliAboneBorcListesi;
import org.seras.webservice.server.WsGunSonuYekun;
import org.seras.webservice.server.WsTahsilat;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TalasCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.talasbel.client.TalasbelSOAPClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class TalasWaterServices extends OnlineCorporationInterface implements
		OnlineInstitutionConstants {
	
	static final String TALAS_SUCCESSFUL_CODE = "100";

	//private static final Log logger = LogFactory.getLog(TalasWaterServices.class);
	
	public TalasWaterServices() {
		
	}

	@GraymoundService("ICS_TALAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_INVOICE_DEBT_INQUIRY");
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			String subscriberNoString = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String subscriberNo = CommonHelper.trimStart(subscriberNoString, '0');
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			AboneBorcListesi[] subscriberDebtList = client.debtInquiry(subscriberNo);
			
			if(subscriberDebtList.length == 1){
				AboneBorcListesi response = subscriberDebtList[0];
				GMMap codeMapping = getResponseCodeMapping(response.getIslemSonuKodu(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if(GeneralConstants.ERROR_CODE_NOT_FOUND != codeMapping.getInt(MapKeys.ERROR_CODE)){
					output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
					output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					return output;
				}
				else{
					if(response.getAy() == 0 && response.getYil() == 0){
						output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
						output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
						output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						return output;
					}
				}
			}
			
			int counter = 0;
			
			for (int i = 0; i < subscriberDebtList.length; i++) {
				AboneBorcListesi item = subscriberDebtList[i];
				if(!isCollectedInvoice(String.valueOf(item.getTahakkukAnaId()), String.valueOf(subscriberNo), "", "", "", corporateCode)){
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, item.getTahakkukAnaId());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, item.getToplam());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, "");
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, item.getVadeTarih().getTime());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, item.getYil());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, item.getAy());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, item.getToplam());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, item.getAciklama());
					output.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", item.getAciklama());
					output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}

	private static TalasbelSOAPClient getSoapClient(GMMap iMap) {
		TalasbelSOAPClient client = new TalasbelSOAPClient(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
				iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
		return client;
	}
	
	@GraymoundService("ICS_TALAS_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_DO_INVOICE_COLLECTION");
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			String subscriberNoString = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String branchCode = iMap.getString(MapKeys.BRANCH_CODE);
			String transactionNo = iMap.getString(MapKeys.TRX_NO);
			String description = iMap.getString(MapKeys.PARAMETER1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			
			String subscriberNo = CommonHelper.trimStart(subscriberNoString, '0');
			String receiptNo = CommonHelper.fillCharacters(branchCode, "0", 5, true);
			receiptNo = receiptNo.concat("/00001").concat("-");
			receiptNo = receiptNo.concat(CommonHelper.fillCharacters(transactionNo, "0", 10, true));
			String collectionDate = iMap.getString(MapKeys.PAYMENT_DATE, null);
			
			WsTahsilat[] collectionResults = null;
			
			if(!StringUtil.isEmpty(collectionDate)){
				collectionResults = client.collectInvoiceWithDate(subscriberNo, invoiceNo, receiptNo, description, collectionDate);
			}
			else{
				collectionResults = client.doInvoiceCollection(subscriberNo, invoiceNo, receiptNo, description);
			}
			
			if(collectionResults.length == 0){
				CommonHelper.throwBusinessException(BusinessException.SYSTEM.getCode());
			}
			
			WsTahsilat collection = collectionResults[0];
			
			if(TALAS_SUCCESSFUL_CODE.equals(collection.getAciklama())){
				BigDecimal voucherNo = collection.getMakbuzNo();
				Session hibSession = CommonHelper.getHibernateSession();
				invoicePayment paymentRecord = (invoicePayment)hibSession.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txNo", new BigDecimal(transactionNo)))
						.uniqueResult();
				
				paymentRecord.setParameter2(String.valueOf(voucherNo.intValue()));
				paymentRecord.setParameter3(receiptNo);
				
				hibSession.saveOrUpdate(paymentRecord);
				hibSession.flush();
			}
			else{
				GMMap responseCodeMap = getResponseCodeMapping(collection.getAciklama(),
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				
				output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TALAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap){
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_SEND_COLLECTION_CANCEL_MESSAGE");
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String voucherNo = iMap.getString("PARAMETER_2");
			String receiptNo = iMap.getString("PARAMETER_3");
			String paymentDate = iMap.getString(MapKeys.PAYMENT_DATE);
			
			String formattedPaymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(paymentDate, "yyyyMMddhhmmss"), "dd/MM/yyyy");
			
			String result = client.cancelCollection(voucherNo, receiptNo, null, formattedPaymentDate);
			
			if(!TALAS_SUCCESSFUL_CODE.equals(result)){
				GMMap responseCodeMap = getResponseCodeMapping(result,
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				
				output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_TALAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_TALAS_SEND_STANDING_ORDER_MESSAGE");
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subscriberNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			
			String result = client.saveStandingOrder(subscriberNo);
			
			if(!TALAS_SUCCESSFUL_CODE.equals(result)){
				GMMap responseCodeMap = getResponseCodeMapping(result,
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				
				output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_TALAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_TALAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subscriberNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			
			String result = client.cancelStandingOrder(subscriberNo);
			
			if(!TALAS_SUCCESSFUL_CODE.equals(result)){
				GMMap responseCodeMap = getResponseCodeMapping(result,
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				
				output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TALAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_GET_COLLECTION_RECONCILIATION_DETAIL");
			
			CollectionReconciliationDetailBatch batch = new TalasCollectionReconciliationDetailBatch(iMap, client);
			output = batch.runBatch();
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TALAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_COLLECTION_RECONCILIATION_CLOSED");
			
			String date = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			
			String result = client.reconciliationRequest(date, String.valueOf(collectionCount), collectionTotal.toString());
			
			if(!TALAS_SUCCESSFUL_CODE.equals(result)){
				GMMap responseCodeMap = getResponseCodeMapping(result,
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				
				output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TALAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_COLLECTION_RECONCILIATION");
			String date = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			WsGunSonuYekun[] reconciliationSummary = client.getReconciliationSummary("", "", date);
			
			if(reconciliationSummary.length != 1){
				throw new Exception("No or more than one summary returned from service");
			}
			
			WsGunSonuYekun recon = reconciliationSummary[0];
			
			int corporateCollectionCount = recon.getMakbuzAdet();
			BigDecimal corporateCollectionAmount = recon.getMakbuzToplam() == null ? new BigDecimal(0) : recon.getMakbuzToplam();
			
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corporateCollectionAmount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			if(!TALAS_SUCCESSFUL_CODE.equals(recon.getAciklama())){
				GMMap responseCodeMap = getResponseCodeMapping(recon.getAciklama(),
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				
				output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
				return output;
			}
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			if(corporateCollectionCount != collectionCount){
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			else if(corporateCollectionAmount.compareTo(collectionTotal) != 0){
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			else{
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TALAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TALAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		
		try{
			TalasbelSOAPClient client = getSoapClient(iMap);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			TalimatliAboneBorcListesi[] standingOrderList = client.debtInquiryForStandingOrders();
			
			if(standingOrderList.length == 1){
				if(!TALAS_SUCCESSFUL_CODE.equals(standingOrderList[0].getIslemSonuKodu())){
					GMMap responseCodeMap = getResponseCodeMapping(standingOrderList[0].getIslemSonuKodu(),
							iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					
					output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
					output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
					return output;
				}
			}
			
			for (int i = 0; i < standingOrderList.length; i++) {
				TalimatliAboneBorcListesi debt = standingOrderList[i];
				
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, debt.getSicilNo());
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, String.valueOf(debt.getTahakkukAnaId()));
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, debt.getToplam());
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, 0);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(debt.getVadeTarih().getTime()));
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, debt.getAciklama());
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, debt.getAy());
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, debt.getYil());
				output.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
			}
			output.put(MapKeys.TABLE_SIZE, output.getSize(MapKeys.INVOICE_LIST));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
}
