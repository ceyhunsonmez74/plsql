package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import mark.MarkFatura;
import mark.UnMarkFatura;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.gov.gaski.banka.GaskiClient;
import tr.gov.gaski.banka.ServiceMessage;
import borc.Fatura;
import borc.holders.ArrayOfFaturaHolder;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class GaskiServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(GaskiServices.class);
	private static final int sorguTipi = 1;

	@GraymoundService("ICS_GASKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		String hataMesaji = "";
		boolean errorOccured = false;
		try {
			int tesisatNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY is called for subscriber no : ".concat(Integer.toString(tesisatNo)));
			ServiceMessage serviceMessage = new ServiceMessage();
			ArrayOfFaturaHolder borcList = null;
			try {
				borcList = GaskiClient.getBorc(tesisatNo, sorguTipi, username, password, url, serviceMessage);
				responseCode = serviceMessage.getParameter1();
				logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY returned result code ".concat(responseCode).concat(" and resul string ").concat(serviceMessage.getParameter2()));
				logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY returned ".concat(Integer.toString(borcList.value.length).concat(" number of invoice.")));
			} catch (Exception e) {
				logger.error(e.toString());
				logger.error(System.currentTimeMillis(), e);
				logger.error(ExceptionHandler.convertException(e));
				responseCode = "4263";
				hataMesaji = "Tesisat Numaras� Sistemde Tan�ml� De�il";
				errorOccured = true;
				logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY is called getBorc and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(hataMesaji));
			}finally{
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());	
			}
			if (!errorOccured) {
				if (borcList == null) {
					responseCode = "2733";
					logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY -> borclist is null");
				} else if (borcList.value.length == 0) {
					if (serviceMessage.getParameter1().equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						responseCode = "2733";
						logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY -> 2733");
					} else {
						responseCode = "4263";
						hataMesaji = serviceMessage.getParameter2();
						logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY -> 4263");
					}
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (Fatura borc : borcList.value) {
					if (!isCollectedInvoice(borc.getFaturaNo(), Integer.toString(tesisatNo), "", "", "", corporateCode)) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, Integer.toString(tesisatNo));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getFaturaNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplamTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getUnvan());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTarihi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplamTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			} else {
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			}
			logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY finished");
		} catch (Throwable e2) {
			logger.info("ICS_GASKI_INVOICE_DEBT_INQUIRY is called markFatura and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(CommonHelper.getStringifiedException(e2)));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_GASKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		try {
			String hataMesaji = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			int tesisatNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			String tahsilatTarihi = "";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			logger.info("ICS_GASKI_DO_INVOICE_COLLECTION is called for subscriber no ".concat(Integer.toString(tesisatNo).concat(" and invoice no ").concat(faturaNo)));
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			ServiceMessage serviceMessage = new ServiceMessage();
			MarkFatura response = null;
			try {
				response = GaskiClient.markFatura(tesisatNo, faturaNo, username, password, url, serviceMessage);
				responseCode = Integer.toString(response.getResultCode());
				if (responseCode.equals("0")) {
					responseCode = "4263";
					hataMesaji = "Fatura �deme s�ras�nda hata meydana geldi.��lem ba�ar�s�z.";
				} else if (responseCode.equals("-1")) {
					responseCode = "4263";
					hataMesaji = "Fatura zaten daha �nce �denmi�tir.M�kerrer �deme meydana geldi.";
				} else if (responseCode.equals("1")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			} catch (Exception e) {
				responseCode = "4263";
				hataMesaji = "Fatura No bulunamadi ya da tesisat no ile e�le�miyor";
				logger.info("ICS_GASKI_DO_INVOICE_COLLECTION is called markFatura and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(hataMesaji));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			logger.info("ICS_GASKI_DO_INVOICE_COLLECTION is called markFatura and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(CommonHelper.getStringifiedException(e2)));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_GASKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String hataMesaji = "";
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			int tesisatNo = Integer.parseInt(iMap.getString("SUBSCRIBER_NO_1"));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			logger.info("ICS_GASKI_SEND_COLLECTION_CANCEL_MESSAGE is called for subscriber no ".concat(Integer.toString(tesisatNo).concat(" and invoice no ").concat(faturaNo)));
			try {
				UnMarkFatura response = GaskiClient.unMarkFatura(tesisatNo, faturaNo, username, password, url, serviceMessage);
				responseCode = Integer.toString(response.getResultCode());
				if (responseCode.equals("0")) {
					responseCode = "4263";
					hataMesaji = "Fatura iptal s�ras�nda hata meydana geldi.��lem ba�ar�s�z.";
				} else if (responseCode.equals("-1")) {
					responseCode = "4263";
					hataMesaji = "�ptal edilecek fatura tahsilati bulunamad�";
				} else if (responseCode.equals("1")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			} catch (Exception e) {
				responseCode = "4263";
				hataMesaji = "Fatura No bulunamadi ya da tesisat no ile e�le�miyor";
				logger.info("ICS_GASKI_SEND_COLLECTION_CANCEL_MESSAGE is called markFatura and replied with response code ".concat(responseCode).concat(" and error message is : ").concat(hataMesaji));
			}
			iMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Exception e2) {
			logger.info("ICS_GASKI_SEND_COLLECTION_CANCEL_MESSAGE is called markFatura and replied with response code ".concat(responseCode).concat(" and error message is : ").concat(CommonHelper.getStringifiedException(e2)));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_GASKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_GASKI_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_GASKI_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(tesisatNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_GASKI_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_GASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_GASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_GASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(tesisatNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_GASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_GASKI_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_GASKI_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		GMMap stoMap = new GMMap();

		try {
			logger.info("STO_GASKI_STANDING_ORDER_RECONCILIATION is called");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			stoMap = getBankStandingOrdersForGaski(reconDate, corporateCode);
			int reconCollectionCount = stoMap.getInt(MapKeys.RECON_BANK_COUNT);
			outMap.put(MapKeys.RECON_CORPORATE_COUNT, reconCollectionCount);
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, "0");
			outMap.put(MapKeys.RECON_BANK_COUNT, reconCollectionCount);
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, "0");

			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("STO_GASKI_STANDING_ORDER_RECONCILIATION finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_GASKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER is started...");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String toDayToCompare = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			GMMap sorMap = getBankStandingOrdersForGaski(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER recon count to check is ".concat(Integer.toString(reconCollectionCount)));
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				String subscriberNumber = CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0');
				logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" will be called.."));
				iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNumber);
				iMap.put(MapKeys.COLLECTION_TYPE, "0");
				iMap.put(MapKeys.COLLECTION_TYPE_NAME, "Fatura Odeme");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GASKI_INVOICE_DEBT_INQUIRY", iMap);
				int billNumber = reconBankMap.getSize(MapKeys.INVOICE_LIST);
				logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" is called and return map").concat(reconBankMap.toString()).concat(" and bill number is").concat(Integer.toString(billNumber)));
				if (billNumber > 0) {
					for (int z = 0; z < billNumber; z++) {
						logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" compares date invoice date -> ").concat(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE).toString()).concat(" with todays date -> ").concat(toDayToCompare));
						if (toDayToCompare.equals(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE))) {
							logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" returned result which matches due date with today..."));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_GASKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String gatewayErrorDesc = "";
		String responseCode = "";
		String errorCode = "";
		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			logger.info("ICS_GASKI_COLLECTION_RECONCILIATION an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_GASKI_COLLECTION_RECONCILIATION an error accoured with response code : ".concat(responseCode));
			logger.error("ICS_GASKI_COLLECTION_RECONCILIATION -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_GASKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();

		try {
			logger.info("ICS_GASKI_GET_COLLECTION_RECONCILIATION_DETAIL is called");
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("ICS_GASKI_GET_COLLECTION_RECONCILIATION_DETAIL finished succesfully");
		return outMap;
	}

	public static GMMap getBankStandingOrdersForGaski(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER is called getBankStandingOrdersForGaski...");
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.GaskiServicesRepository.GET_BANK_STANDING_ORDERS, reconcilitionDate, reconcilitionDate, corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER found ".concat(Integer.toString(al.size())).concat(" standing order for GASKI"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			logger.info("ICS_GASKI_DEBT_INQUERY_FOR_STANDING_ORDER found 0 standing order");
		}
		return returnMap;
	}

}
