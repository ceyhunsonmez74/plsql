package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.tempuri.Talimat;

import tr.com.aktifbank.bnspr.cps.batch.implementations.ArsanReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.arsan.ArsanClient;
import tr.com.aktifbank.integration.arsan.ServiceMessage;
import tr.com.arsan.AgreementGeneralResponse;
import tr.com.arsan.CollectResponse;
import tr.com.arsan.CollectionCancelResponse;
import tr.com.arsan.DebtList;
import tr.com.arsan.DebtListResponse;
import tr.com.arsan.DeleteInstructionResponse;
import tr.com.arsan.InstructionDetailReconciliationResponse;
import tr.com.arsan.InstructionGeneralReconciliationResponse;
import tr.com.arsan.OrderedDebtListResponse;
import tr.com.arsan.SaveInstructionResponse;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.sap.xi.fica.global.testing.P3CashPointOpenItemFault;

public class ArsanServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(ArsanServices.class);

	// /v1/Borc/BorcListesi
	@GraymoundService("ICS_ARSAN_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_INVOICE_DEBT_INQUIRY");

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));// PARAMETER1
			Integer subscriberNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			Integer contractNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			String responseMessage = "";
			String responseCode = "";
			DebtListResponse debtInqueryResponse = null;

			try {
				debtInqueryResponse = ArsanClient.debtInquery(serviceUrl, subscriberNo, bankCode, companyCode, username, password, contractNo, serviceMessage);
				responseCode = debtInqueryResponse.getErrorCode().toString();
				responseMessage = debtInqueryResponse.getErrorMessage();
			}
			catch (P3CashPointOpenItemFault f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_ARSAN_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getStandard().getFaultDetail().get(0).getId();
				responseMessage = f.getFaultInfo().getStandard().getFaultDetail().get(0).getText();
				logger.info("ICS_ARSAN_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
				logger.info("ICS_ARSAN_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
			}

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			// Gelen ResponseCode'u bizim ResponseCode'lar ile MAP leme i�lemi yap�l�yor.
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				int i = 0;
				for (DebtList debtListItem : debtInqueryResponse.getBorcList()) {

					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, debtInqueryResponse.getAboneNo());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, debtInqueryResponse.getSozlesmeNo());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, debtInqueryResponse.getAboneAdSoyad());

					SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
					Date date2 = inputFormat.parse(debtListItem.getSonOdemeTarihi());
					// System.out.println(formattedDate); // prints 10-04-2018

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date2);

					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, debtListItem.getFaturaNo());
					// oMap.put(MapKeys.INVOICE_LIST, i, "PERIOD", debtListItem.getDonem());

					// oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, debtListItem.getDonem().substring(5,7));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, debtListItem.getDonem().substring(0, 4));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, debtListItem.getDonem().substring(5, 7));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, calendar.getTime());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, debtListItem.getBorcTutari());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_AMOUNT, debtListItem.getBorcTutari());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					oMap.put(MapKeys.INVOICE_LIST, i, "SELECT", false);
					oMap.put(MapKeys.INVOICE_LIST, i, "OID", "0");
					i++;
				}
			}
		}
		catch (Throwable e2) {
			logger.error("ICS_ARSAN_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// /v1/Tahsilat/TahsilEt

	@GraymoundService("ICS_ARSAN_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_DO_INVOICE_COLLECTION");

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer contractNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			Integer subscriberNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			// BigDecimal processRefNo = new BigDecimal(iMap.getString(MapKeys.TRX_NO));
			String processRefNo = iMap.getString(MapKeys.TRX_NO);
			String departmenCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			Date collectionDate = new Date();

			BigDecimal refNo = new BigDecimal(processRefNo);
			BigDecimal deptCode = new BigDecimal(departmenCode);

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				collectionDate = CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss");
			}
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			String responseCode = "";
			String responseMessage = "";

			CollectResponse collectResponse = null;

			collectResponse = ArsanClient.doInvoiceCollection(serviceUrl, bankCode, deptCode, companyCode, username, password, invoiceNo, subscriberNo, contractNo, collectionDate, refNo, serviceMessage);
			responseCode = collectResponse.getErrorCode().toString();
			responseMessage = collectResponse.getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(collectResponse.getIslemReferansNo().toString());
				session.saveOrUpdate(invoicePayment);

			}

		}
		catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// /v1/Tahsilat/TahsilatIptal ---ICS_IGDAS_FICA_SEND_COLLECTION_CANCEL_MESSAGE
	@GraymoundService("ICS_ARSAN_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_SEND_COLLECTION_CANCEL_MESSAGE");

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String processRefNo = iMap.getString(MapKeys.TRX_NO);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = "";
			String responseMessage = "";

			BigDecimal refNo = new BigDecimal(processRefNo);

			CollectionCancelResponse collectionCancelResponse = null;

			collectionCancelResponse = ArsanClient.sendCollectionCancelMessage(serviceUrl, bankCode, companyCode, username, password, refNo, serviceMessage);
			responseCode = collectionCancelResponse.getErrorCode().toString();
			responseMessage = collectionCancelResponse.getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Throwable e2) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// /v1/Tahsilat/MutabakatGenel -- ICS_IGDAS_FICA_COLLECTION_RECONCILIATION ???????????????????
	@GraymoundService("ICS_ARSAN_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_COLLECTION_RECONCILIATION");

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			// Date aggrementDate = new Date();
			// BigDecimal chargedCount = new BigDecimal(iMap.getString("CHARGED_COUNT"));
			// BigDecimal collectionAmount = new BigDecimal(MapKeys.COLLECTION_AMOUNT);
			// String cancCount = iMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			// String cancAmount = iMap.getString(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			//
			// BigDecimal cancelCount = new BigDecimal(cancCount);
			// BigDecimal cancelAmount = new BigDecimal(cancAmount);

			Date reconDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate = iMap.getDate(MapKeys.RECON_DATE);

			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			BigDecimal cancelCount = new BigDecimal(reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			AgreementGeneralResponse agreementGeneralResponse = null;

			agreementGeneralResponse = ArsanClient.collectionReconciliation(serviceUrl, bankCode, companyCode, username, password, reconDate, new BigDecimal(collectionCount), collectionTotal, cancelCount, cancelTotal, serviceMessage);
			responseCode = agreementGeneralResponse.getErrorCode().toString();
			responseMessage = agreementGeneralResponse.getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// RETURNS
				// Date tahsilatTarihi;
				// BigDecimal tahsilatAdeti;
				// BigDecimal tahsilTutari;
				// BigDecimal iptalAdeti;
				// BigDecimal iptalTutari;
				// oMap.put(MapKeys.AMOUNT, agreementGeneralResponse.getTahsilTutari());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, agreementGeneralResponse.getTahsilTutari());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, agreementGeneralResponse.getTahsilatAdeti());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, agreementGeneralResponse.getIptalTutari());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, agreementGeneralResponse.getIptalAdeti());
				
				if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).add(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL))) == 0
						&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).add(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT))) == 0
						&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 
						&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0){
					
					oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}

			}
			

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			oMap.put(MapKeys.ERROR_CODE, agreementGeneralResponse.getErrorCode());
			oMap.put(MapKeys.ERROR_DESC, agreementGeneralResponse.getErrorMessage());

		}
		catch (Throwable e) {
			logger.info("ICS_ARSAN_COLLECTION_RECONCILIATION - mutabakat hatali ");
			oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	// /v1/Tahsilat/MutabakatDetay --- ICS_IGDAS_FICA_GET_COLLECTION_RECONCILIATION_DETAIL ?????????????????
	@GraymoundService("ICS_ARSAN_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("ICS_ARSAN_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_COLLECTION_RECONCILIATION_DETAIL");

		try {

			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new ArsanReconciliationDetailBatch(iMap, message);
			oMap = batch.runBatch();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_ARSAN_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_ARSAN_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_COLLECTION_RECONCILIATION_CLOSED");
		try {
			// mutabakat cagirildiginda basarili olursa otomatik olarak
			// kapaniyor. kurumun mutabakat kapatma servisi yoktur. bunun icin
			// herhangi bir servis entegrasyonu yapilmadi!
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	// /v1/Talimat/TalimatKaydet --- STO_IGDAS_FICA_SEND_STANDING_ORDER_MESSAGE
	@GraymoundService("ICS_ARSAN_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_SEND_STANDING_ORDER_MESSAGE");

		try {
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Integer subscriberNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			Integer contractNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			Date instructionDate = new Date();
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = "";
			String responseMessage = "";
			SaveInstructionResponse saveInstructionResponse = null;

			saveInstructionResponse = ArsanClient.sendStandingOrderMessage(serviceUrl, bankCode, companyCode, username, password, subscriberNo, contractNo, instructionDate, serviceMessage);
			responseCode = saveInstructionResponse.getErrorCode().toString();
			responseMessage = saveInstructionResponse.getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Exception e) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	// /v1/Talimat/TalimatSil --- STO_IGDAS_FICA_SEND_STANDING_ORDER_CANCEL_MESSAGE
	@GraymoundService("ICS_ARSAN_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_SEND_STANDING_ORDER_CANCEL_MESSAGE");

		try {
			Integer subscriberNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Integer contractNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			Date instructionCancelDate = new Date();
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = "";
			String responseMessage = "";
			DeleteInstructionResponse deleteInstructionResponse = null;

			deleteInstructionResponse = ArsanClient.sendStandingOrderCancelMessage(serviceUrl, bankCode, companyCode, username, password, subscriberNo, contractNo, instructionCancelDate, serviceMessage);
			responseCode = deleteInstructionResponse.getErrorCode().toString();
			responseMessage = deleteInstructionResponse.getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			// CLKServices
			// Line 1123
			// ErrorCode lar� maplemen gerekiyor !!!!!!!!!!!!!!
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	
		}
		catch (Exception e) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// /v1/Borc/TalimatliBorcListesi -- ICS_IGDAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER
	@GraymoundService("ICS_ARSAN_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_ORDERED_DEBT_LIST");

		try {
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			
			Date lastPaymentDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PROCESS_DATE)))
				lastPaymentDate = iMap.getDate(MapKeys.PROCESS_DATE); 
			
			
			// SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			// SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
			// Date lastPaymentDate2 = inputFormat.parse("Thu Sep 19 00:00:00 EET 2019");

			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = "";
			String responseMessage = "";
			ArrayList<OrderedDebtListResponse> orderedDebtListResponse = null;

			orderedDebtListResponse = ArsanClient.getdebtQueryForStandingOrder(serviceUrl, bankCode, companyCode, username, password, lastPaymentDate, serviceMessage);
			responseCode = orderedDebtListResponse.get(0).getErrorCode().toString();
			responseMessage = orderedDebtListResponse.get(0).getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// oMap.put(MapKeys.SUBSCRIBER_NO1, orderedDebtListResponse.getAboneNo());
				// oMap.put(MapKeys.INVOICE_NO, orderedDebtListResponse.getFaturaNo());
				// oMap.put("CONTRACT_NO", orderedDebtListResponse.getSozlesmeNo());
				// oMap.put("PERIOD", orderedDebtListResponse.getDonem());
				// oMap.put("LAST_PAYMENT_DATE", orderedDebtListResponse.getSonOdemeTarihi());
				// oMap.put(MapKeys.AMOUNT, orderedDebtListResponse.getBorcTutari());
				//
				// oMap.put(MapKeys.ERROR_CODE, orderedDebtListResponse.getErrorCode());
				// oMap.put(MapKeys.ERROR_DESC, orderedDebtListResponse.getErrorMessage());
				int counter = 0;
				String legacyDistrictCode = "";
				String legacySPNumber = "";
				for (int i = 0; i < orderedDebtListResponse.size(); i++) {
//					String sonOdeme = orderedDebtListResponse.get(counter).getSonOdemeTarihi().toString();
//					Date date1=new SimpleDateFormat("yyyymmdd").parse(sonOdeme); 
//					
//					SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
//				    String lastDate = f.format(sonOdeme).toString();
				
//				    
//				    //
				    String pattern = "yyyyMMdd";
				    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

				    String itemDate = orderedDebtListResponse.get(counter).getSonOdemeTarihi().toString();
				    
//				    String date = simpleDateFormat.format(itemDate);
//				    String lastDate = date.toString();
//				    System.out.println(date);
					//
				    
				    String lasttDate = itemDate.substring(0, 4) + itemDate.substring(5, 7) + itemDate.substring(8, 10);
				    
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, orderedDebtListResponse.get(counter).getAboneNo());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, orderedDebtListResponse.get(counter).getSozlesmeNo());

					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, orderedDebtListResponse.get(counter).getFaturaNo());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, orderedDebtListResponse.get(counter).getBorcTutari());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, orderedDebtListResponse.get(counter).getAboneNo());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, lasttDate);
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, orderedDebtListResponse.get(counter).getDonem().toString().substring(0, 4));
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, orderedDebtListResponse.get(counter).getDonem().toString().substring(5, 7));
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, "0");
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, orderedDebtListResponse.get(counter).getBorcTutari());
					oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					oMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					oMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}

				oMap.put(MapKeys.TABLE_SIZE, counter);
				oMap.put(MapKeys.RESPONSE_CODE, responseCode);
				oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}

		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_IGDAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	// /v1/Talimat/TalimatGenelMutabakat -- STO_IGDAS_FICA_STANDING_ORDER_RECONCILIATION
	@GraymoundService("ICS_ARSAN_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_STANDING_ORDER_RECONCILIATION");

		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			// Date instructionDate = new SimpleDateFormat("dd/MM/yyyy").parse("INSTRUCTION_DATE");
			String instCount = iMap.getString(MapKeys.RECON_STANDINGORDER_COUNT) == null ? "0" : iMap.getString(MapKeys.RECON_STANDINGORDER_COUNT);
			// BigDecimal cancelCount = new BigDecimal(reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			String cancCount = iMap.getString(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT) == null ? "0" : iMap.getString(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			String collectTotal = iMap.getString(MapKeys.RECON_COLLECTION_TOTAL) == null ? "0" : iMap.getString(MapKeys.RECON_COLLECTION_TOTAL);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			BigDecimal instructionCount = new BigDecimal(instCount);
			BigDecimal cancelCount = new BigDecimal(cancCount);
			BigDecimal collectionTotal = new BigDecimal(collectTotal);

			// /
			Date reconDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate = iMap.getDate(MapKeys.RECON_DATE);

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			String responseCode, responseMessage = "";
			InstructionGeneralReconciliationResponse instructionGeneralReconciliationResponse = null;

			instructionGeneralReconciliationResponse = ArsanClient.standingOrderReconciliation(serviceUrl, bankCode, companyCode, username, password, reconDate, instructionCount, cancelCount, serviceMessage);
			responseCode = instructionGeneralReconciliationResponse.getErrorCode().toString();
			responseMessage = instructionGeneralReconciliationResponse.getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, instructionGeneralReconciliationResponse.getTalimatAdeti());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, instructionGeneralReconciliationResponse.getIptalAdeti());

				oMap.put(MapKeys.ERROR_CODE, instructionGeneralReconciliationResponse.getErrorCode());
				oMap.put(MapKeys.ERROR_DESC, instructionGeneralReconciliationResponse.getErrorMessage());
			}
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

		}
		catch (Throwable e) {
			logger.info("ICS_ARSAN_STANDING_ORDER_RECONCILIATION - mutabakat hatali ");
			oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;

	}

	// /v1/Talimat/TalimatDetayMutabakat --- STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL (CLKSercives 'da)
	@GraymoundService("ICS_ARSAN_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARSAN_GET_STANDING_ORDER_RECONCILIATION_DETAIL");

		try {
			List<Talimat> totalList = new ArrayList<Talimat>();
			List<Talimat> orderList = new ArrayList<Talimat>();
			List<Talimat> cancelList = new ArrayList<Talimat>();
			
			Integer bankCode2 = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			// Date instructionDate = new SimpleDateFormat("dd/MM/yyyy").parse("INSTRUCTION_DATE");
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			Date reconDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate = iMap.getDate(MapKeys.RECON_DATE);

			String responseCode, responseMessage = "";
			ArrayList<InstructionDetailReconciliationResponse> resp = null;

			resp = ArsanClient.getStandinOrderReconciliationDetail(serviceUrl, bankCode2, companyCode, username, password, reconDate, serviceMessage);
			responseCode = resp.get(0).getErrorCode().toString();
			responseMessage = resp.get(0).getErrorMessage();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//				int counter = 0;
//				for (InstructionDetailReconciliationResponse item : resp) {
//					oMap.put(MapKeys.BANK_CODE, resp.get(counter).getBankaKodu());
//					oMap.put(MapKeys.PARAMETER2, resp.get(counter).getFirmaKodu());
//					oMap.put(MapKeys.WS_USER, resp.get(counter).getUsername());
//					oMap.put(MapKeys.WS_PASSWORD, resp.get(counter).getPassword());
//					oMap.put(MapKeys.RECON_DATE, resp.get(counter).getTalimatTarihi());
//
//					oMap.put(MapKeys.ERROR_CODE, resp.get(counter).getErrorCode());
//					oMap.put(MapKeys.ERROR_DESC, resp.get(counter).getErrorMessage());
//					counter++;
//					
					//orderList.add(item.get);
//				}
				
				String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
				
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
				GMMap listMap = new GMMap();
				listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
	
				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

				Talimat[] t = new Talimat[0];
				Talimat[] corpStandingOrderList = totalList.toArray(t);
				
				boolean found = false;
				if (bankStandingOrderList.size() > corpStandingOrderList.length) {
					short collectionType = 0;
					for (int j=0; j < bankStandingOrderList.size(); j++) {
						for (int i = 0; i < corpStandingOrderList.length ; i++) {
							if (bankStandingOrderList.get(j).getSubscriberNo1().equals(corpStandingOrderList[i].getAboneNo())) {
								collectionType = bankStandingOrderList.get(j).getCollectionType();
								found = true;
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				} else { 
					
					short collectionType = 0;
					
					for (int j=0; j < corpStandingOrderList.length; j++) {
						for (int i = 0; i < bankStandingOrderList.size(); i++) {
							if (corpStandingOrderList[j].getAboneNo().equals(bankStandingOrderList.get(i).getSubscriberNo1())) {
								found = true;
								bankStandingOrderList.remove(i);
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat iptal istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, corpStandingOrderList[j].getAboneNo());
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat Iptal Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, corpStandingOrderList[j].getAboneNo());
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				}
				///////////////////////////////////////////////
				//////////////////////////////////////////////
				/////////////////////////////////////////////
			}

		}
		catch (Exception e) {
			logger.error("An exception occured while executing STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

}
