package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TurksatCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.turksat.ws.ServiceMessageWs;
import tr.com.aktifbank.integration.turksat.ws.TurksatClientWs;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.turksat.kodsis.ws.Fatura;
import tr.com.turksat.kodsis.ws.IptalTahsilatC;
import tr.com.turksat.kodsis.ws.IptalTalimatC;
import tr.com.turksat.kodsis.ws.KaydetTahsilatC;
import tr.com.turksat.kodsis.ws.KaydetTalimatC;
import tr.com.turksat.kodsis.ws.ListeleFaturaC;
import tr.com.turksat.kodsis.ws.SorgulaMutabakatC;
import tr.com.turksat.kodsis.ws.SorgulaTalimatC;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TurksatCorporationServiceWs extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	public static final String ERROR_SUCCESS = "00.00";
	public static final String NOT_FOUND = "99";
	private static final Log logger = LogFactory.getLog(TurkcellServices.class);
	public static final String BRANCH_CODE = "555";
	public static final String TELLER = "TELLER";
	public static final String ACCOUNT_NO = "ACCOUNT_NO";
	public static final int PAYMENT_STATUS = 1;
	public static final int PAYMENT_CANCEL_STATUS = 2;

	@GraymoundService("ICS_TURKSAT_INVOICE_DEBT_INQUIRY_WS")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_INVOICE_DEBT_INQUIRY_WS");
		try {
			// TurksatClient debtInquiryClient = getSoapClient(iMap);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = "";
			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			ServiceMessageWs serviceMessage = new ServiceMessageWs();
			ListeleFaturaC invoiceList = TurksatClientWs.listeleFatura(subscriberNo1, wsUserName, wsPassword, wsUrl, serviceMessage);
			responseCode = invoiceList.getSonucKod();
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			int counter = 0;
			if (null != invoiceList.getFaturaListesi()) {
				for (int i = 0; i < invoiceList.getFaturaListesi().length; i++) {
					Fatura invoice = invoiceList.getFaturaListesi(i);
					String invoiceDueDate = getStringDate(invoice.getSonOdemeTarihi());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, iMap.getString(MapKeys.SUBSCRIBER_NO3));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoice.getAdSoyadUnvan());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getFaturaNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getToplamTutar());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, invoice.getFaturaID());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, invoice.getSorguID());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, invoice.getFaturaTutari());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, invoice.getGecikmeTutari());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, invoice.getSorguID());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, invoiceDueDate.substring(0, 4));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, invoiceDueDate.substring(4, 6));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, invoice.getToplamTutar());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, invoiceList.getSonucAciklama());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_INVOICE_DEBT_INQUIRY_WS.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);

		}
		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_DO_INVOICE_COLLECTION_WS")
	public static GMMap doInvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		String responseCode = "";
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_DO_INVOICE_COLLECTION");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int paymentChannel = 0;
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			Fatura invoice = new Fatura();
			invoice.setAdSoyadUnvan(iMap.getString(MapKeys.SUBSCRIBER_NAME));
			invoice.setFaturaID(iMap.getLong(MapKeys.PARAMETER1));
			invoice.setFaturaNo(iMap.getString(MapKeys.INVOICE_NO));
			invoice.setFaturaTutari(iMap.getBigDecimal(MapKeys.PARAMETER3));
			invoice.setGecikmeTutari(iMap.getBigDecimal(MapKeys.PARAMETER4));
			invoice.setHizmetNo(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			invoice.setSonOdemeTarihi(getCalendarDate(iMap.getString(MapKeys.INVOICE_DUE_DATE)));
			invoice.setSorguID(iMap.getLong(MapKeys.PARAMETER5));
			invoice.setToplamTutar(iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT));

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.SOURCE))) {
				String sourceCode = iMap.getString(MapKeys.SOURCE);
				String channelCode = CommonHelper.getChannelId();
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
				paymentChannel = Integer.parseInt(getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType));
			}

			ServiceMessageWs serviceMessageWs = new ServiceMessageWs();

			KaydetTahsilatC payment = TurksatClientWs.kaydetTahsilat(iMap.getString(MapKeys.TRX_NO), invoice, null, null, paymentChannel, getPayDate(), BRANCH_CODE, wsUserName, wsPassword, wsUrl, serviceMessageWs);
			responseCode = payment.getSonucKod();

			if (ERROR_SUCCESS.equals(responseCode)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("invoiceNo", iMap.getString(MapKeys.INVOICE_NO))).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter1", iMap.getString(MapKeys.PARAMETER1))).add(Restrictions.eq("parameter2", iMap.getString(MapKeys.PARAMETER2))).uniqueResult();
				invoicePayment.setParameter6(String.valueOf(payment.getOdemeReferansNo()));
				session.saveOrUpdate(invoicePayment);
			}
			System.out.println(payment);
			iMap.put("REQUEST_XML", serviceMessageWs.getRequest());
			outMap.put("RESPONSE_XML", serviceMessageWs.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, payment.getSonucAciklama());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_SEND_COLLECTION_CANCEL_MESSAGE_WS")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String subscriberNo1 = iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			BigDecimal amount = new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT));
			Long refNo = iMap.getLong(MapKeys.CANCEL_PARAMETER6);
			Calendar cancelDate = getPayDate();
			ServiceMessageWs serviceMessage = new ServiceMessageWs();
			IptalTahsilatC res = TurksatClientWs.iptalTahsilat(invoiceNo, subscriberNo1, cancelDate, amount, refNo, wsUserName, wsPassword, wsUrl, serviceMessage);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = String.valueOf(res.getSonucKod());

			logger.error(responseCode + " returned by Corporate for ICS_TURKSAT_SEND_COLLECTION_CANCEL_MESSAGE.");

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, res.getSonucAciklama());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_COLLECTION_RECONCILIATION_WS")
	public static GMMap collectionReconciliation(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Calendar startDateTime = new GregorianCalendar();
			Calendar endDateTime = new GregorianCalendar();
			if (!"".equals(iMap.getString(MapKeys.RECON_DATE))) {
				String reconDate = iMap.getString(MapKeys.RECON_DATE);
				startDateTime = getReconStartDateTime(reconDate);
				endDateTime = getReconEndDateTime(reconDate);
			}
			else {
				startDateTime = getReconStartDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
				endDateTime = getReconEndDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
			}
			ServiceMessageWs serviceMessage = new ServiceMessageWs();
			SorgulaMutabakatC result = TurksatClientWs.sorgulaMutabakat(startDateTime, endDateTime, wsUserName, wsPassword, wsUrl, serviceMessage);

			String responseCode = ERROR_SUCCESS;
			logger.error(responseCode + " returned by Corporate for ICS_TURKSAT_COLLECTION_RECONCILIATION.");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (responseCode.equals(ERROR_SUCCESS)) {

				outMap.put(MapKeys.RECON_BANK_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, result.getBasariliOdemeSayisi());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, result.getIptalOdemeSayisi());
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getBasariliOdemeMiktari());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getBasariliOdemeSayisi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getIptalOdemeMiktari());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getIptalOdemeSayisi());

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}

			responseCode = ERROR_SUCCESS;
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, result.getSonucAciklama());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Throwable e) {
			logger.info("ICS_TURKCELL_COLLECTION_RECONCILIATION - mutabakat hatali ");
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_GET_COLLECTION_RECONCILIATION_DETAIL_WS")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {

		GMMap output = new GMMap();
		ServiceMessageWs message = new ServiceMessageWs();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			CollectionReconciliationDetailBatch batch = new TurksatCollectionReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			output.put(MapKeys.ERROR_DESC, "Onay");
		}
		catch (Throwable e) {
			logger.info("ICS_AGRI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;

	}

	@GraymoundService("ICS_TURKSAT_COLLECTION_RECONCILIATION_CLOSED_WS")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Calendar startDateTime = new GregorianCalendar();
			Calendar endDateTime = new GregorianCalendar();
			if (!"".equals(iMap.getString(MapKeys.RECON_DATE))) {
				String reconDate = iMap.getString(MapKeys.RECON_DATE);
				startDateTime = getReconStartDateTime(reconDate);
				endDateTime = getReconEndDateTime(reconDate);
			}
			else {
				startDateTime = getReconStartDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
				endDateTime = getReconEndDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
			}
			ServiceMessageWs serviceMessage = new ServiceMessageWs();
			SorgulaMutabakatC result = TurksatClientWs.sorgulaMutabakat(startDateTime, endDateTime, wsUserName, wsPassword, wsUrl, serviceMessage);

			String responseCode = ERROR_SUCCESS;
			logger.error(responseCode + " returned by Corporate for ICS_TURKSAT_COLLECTION_RECONCILIATION.");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (responseCode.equals(ERROR_SUCCESS)) {

				outMap.put(MapKeys.RECON_BANK_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, result.getBasariliOdemeSayisi());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, result.getIptalOdemeSayisi());
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getBasariliOdemeMiktari());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getBasariliOdemeSayisi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getIptalOdemeMiktari());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getIptalOdemeSayisi());

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

				if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}

			responseCode = ERROR_SUCCESS;
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, result.getSonucAciklama());

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Throwable e) {
			logger.info("ICS_TURKCELL_COLLECTION_RECONCILIATION - mutabakat hatali ");
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static String getStringDate(Calendar date) {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
		String formatted = format1.format(date.getTime());
		return formatted;
	}

	public static Calendar getCalendarDate(String dateString) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date date = sdf.parse(dateString);
		SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String gregorianDateString = gregorianFormat.format(date);
		Date gregorianDate = gregorianFormat.parse(gregorianDateString);
		Calendar calendarDate = new GregorianCalendar();
		calendarDate.setTime(gregorianDate);
		return calendarDate;
	}

	public static Calendar getPayDate() throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		System.out.println(calendar);
		// Calendar payDate = Calendar.getInstance();
		// payDate.setTime(new SimpleDateFormat("YYYY-MM-DDThh:mm:SS.mss+hh:mm").parse(new Date().toString()));
		return calendar;

	}

	public static Calendar getReconStartDateTime(String dateString) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		dateString = dateString + "000000";
		Date date = sdf.parse(dateString);
		SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String gregorianDateString = gregorianFormat.format(date);
		Date gregorianDate = gregorianFormat.parse(gregorianDateString);
		Calendar calendarDate = new GregorianCalendar();
		calendarDate.setTime(gregorianDate);
		return calendarDate;

	}

	public static Calendar getReconEndDateTime(String dateString) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		dateString = dateString + "235959";
		Date date = sdf.parse(dateString);
		SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String gregorianDateString = gregorianFormat.format(date);
		Date gregorianDate = gregorianFormat.parse(gregorianDateString);
		Calendar calendarDate = new GregorianCalendar();
		calendarDate.setTime(gregorianDate);
		return calendarDate;

	}

	@GraymoundService("ICS_TURKSAT_DEBT_INQUERY_FOR_STANDING_ORDER_WS")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = ERROR_SUCCESS;
		;
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter = 0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();

			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);

				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_TURKSAT_INVOICE_DEBT_INQUIRY_WS", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght = debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES", j, MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, debtLoadingMap.getString("INVOICES", j, MapKeys.INSTALLMENT_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER9));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER10));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES", j, MapKeys.TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES", j, MapKeys.TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, debtLoadingMap.getString("INVOICES", j, MapKeys.ZONE_CODE));
						counter++;
					}

				}
			}
			outMap.put(MapKeys.TABLE_SIZE, bankStandingOrderListLenght);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");
		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);

		}

		return outMap;
	}

	@GraymoundService("STO_TURKSAT_SEND_STANDING_ORDER_MESSAGE_WS")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TURKSAT_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String hizmetNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			ServiceMessageWs serviceMessageCheck = new ServiceMessageWs();
			SorgulaTalimatC checkReturn = TurksatClientWs.sorgulaTalimat(hizmetNo, wsUserName, wsPassword, wsUrl, serviceMessageCheck);
			iMap.put("TALIMAT_KONTROL_REQUEST", serviceMessageCheck.getRequest());
			outMap.put("TALIMAT_KONTROL_RESPONSE", serviceMessageCheck.getResponse());
			if (checkReturn.getSonucKod().equals("00.07")) {
				ServiceMessageWs serviceMessage = new ServiceMessageWs();
				KaydetTalimatC sendReturn = TurksatClientWs.kaydetTalimat(hizmetNo, wsUserName, wsPassword, wsUrl, serviceMessage);
				iMap.put("TALIMAT_VER_REQUEST", serviceMessage.getRequest());
				outMap.put("TALIMAT_VER_RESPONSE", serviceMessage.getResponse());
				GMMap responceCodeMap = getResponseCodeMapping(sendReturn.getSonucKod(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, sendReturn.getSonucAciklama());
			}
			else {
				GMMap responceCodeMap = getResponseCodeMapping(checkReturn.getSonucKod(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, checkReturn.getSonucAciklama());
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE_WS")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String hizmetNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			ServiceMessageWs serviceMessage = new ServiceMessageWs();
			IptalTalimatC cancelReturn = TurksatClientWs.iptalTalimat(hizmetNo, wsUserName, wsPassword, wsUrl, serviceMessage);

			GMMap responceCodeMap = getResponseCodeMapping(cancelReturn.getSonucKod(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, cancelReturn.getSonucAciklama());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

}
