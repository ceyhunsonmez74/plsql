package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.MaskiReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.maski.MaskiClient;
import tr.com.aktifbank.integration.maski.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.maski.AboneTalimatIptalApiCType;
import tr.com.maski.AboneTalimatOlusturApiCType;
import tr.com.maski.BorcDetayApi;
import tr.com.maski.BorcOkuApiCType;
import tr.com.maski.BorcTopluTalimatOkuApiCType;
import tr.com.maski.GeriBildirim;
import tr.com.maski.TahsilatApiCType;
import tr.com.maski.TahsilatGunlukIcmalApiCType;
import tr.com.maski.TahsilatIptalApiCType;
import tr.com.maski.TalimatliAbonelerApiCType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.sap.xi.fica.global.testing.P3CashPointOpenItemFault;

public class MaskiServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(MaskiServices.class);
	private static final String IPTAL = "MUSTERI TALEBI";

	// /api/TahsilatApi/Borc
	@GraymoundService("ICS_MALATYA_MASKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap){
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_INVOICE_DEBT_INQUIRY");
		
		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
//			Integer borcOkumaTuru = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String vadeTarihi = "";
			Long aboneKodu = iMap.getLong(MapKeys.SUBSCRIBER_NO1);	
			Long sicil = iMap.getLong(MapKeys.SUBSCRIBER_NO2);
			
			Integer borcOkumaTuru = null;
			Long kodu = null;
			
			if (aboneKodu != null && aboneKodu != 0){
				borcOkumaTuru = 2;
				kodu = aboneKodu;
			}
			else if (sicil != null && sicil != 0){
				borcOkumaTuru = 4;
				kodu = sicil;
			}
			
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseMessage = "";
			String responseCode = "";
			BorcOkuApiCType debtInqueryResponse = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			try {
				debtInqueryResponse = MaskiClient.debtInquery(reqTimeout, connTimeout, serviceUrl, kurumKodu, apiKey, borcOkumaTuru, vadeTarihi, kodu, serviceMessage);
				responseCode = debtInqueryResponse.getGeriBildirim().getKodu().toString();
				responseMessage = debtInqueryResponse.getGeriBildirim().getAciklama();
			}
			catch (P3CashPointOpenItemFault f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_MASKI_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getStandard().getFaultDetail().get(0).getId();
				responseMessage = f.getFaultInfo().getStandard().getFaultDetail().get(0).getText();
				logger.info("ICS_MASKI_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
				logger.info("ICS_MASKI_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
			}
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			// Gelen ResponseCode'u bizim ResponseCode'lar ile MAP leme i�lemi yap�l�yor.
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				int i = 0;
				for (BorcDetayApi item : debtInqueryResponse.getBorcDetayApiList()) {

					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, item.getAboneKodu());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, item.getAboneSozlesmeNo());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, debtInqueryResponse.getAdi() + " " + debtInqueryResponse.getSoyadi());

					SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
					Date date2 = inputFormat.parse(item.getVadeTarihi().toString());
					// System.out.println(formattedDate); // prints 10-04-2018

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date2);

					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, item.getBorcId());
					// oMap.put(MapKeys.INVOICE_LIST, i, "PERIOD", debtListItem.getDonem());

					// oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, debtListItem.getDonem().substring(5,7));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, item.getVadeTarihi().toString().substring(0, 4));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, item.getVadeTarihi().toString().substring(5, 7));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, calendar.getTime());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, item.getGenelToplam());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_AMOUNT, debtInqueryResponse.getGenelBorcToplam());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.DESCRIPTION, item.getAciklama());
					oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, debtInqueryResponse.getGuid());
					oMap.put(MapKeys.INVOICE_LIST, i, "SELECT", false);
					oMap.put(MapKeys.INVOICE_LIST, i, "OID", "0");
					i++;
				}
			}
		}
		catch (Exception e) {
			logger.error("ICS_MASKI_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}		
		
		return oMap;
	}

	//	/api/TahsilatApi/Tahsilat
	@GraymoundService("ICS_MALATYA_MASKI_DO_INVOICE_COLLECTION")
	public static GMMap doInviceCollection(GMMap iMap){
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_DO_INVOICE_COLLECTION");
		
		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String guId = iMap.getString(MapKeys.PARAMETER4);
			String odemeNo = iMap.getString(MapKeys.TRX_NO);
			Integer borcId = iMap.getInt(MapKeys.INVOICE_NO);
			BigDecimal tahsilatToplam = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			String responseMessage = "";
			String responseCode = "";
			
			TahsilatApiCType response = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			response = MaskiClient.doInvoiceCollection(reqTimeout, connTimeout, serviceUrl, kurumKodu, apiKey, guId, odemeNo, borcId, tahsilatToplam, serviceMessage);
			responseCode = response.getGeriBildirim().getKodu().toString();
			responseMessage = response.getGeriBildirim().getAciklama();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(response.getTahsilatId().toString());
				invoicePayment.setParameter3(borcId.toString());
				session.saveOrUpdate(invoicePayment);

			}
		}
		catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
	}
	
	
	//	/api/TahsilatApi/Iptal
	@GraymoundService("ICS_MALATYA_MASKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_SEND_COLLECTION_CANCEL_MESSAGE");
		
		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String odemeNo = iMap.getString(MapKeys.TRX_NO);  //if li yap� var, di�er �rnekten incele
			String tahsilatId = (iMap.getString(MapKeys.PARAMETER_2) != null ? iMap.getString(MapKeys.PARAMETER_2) : iMap.getString(MapKeys.PARAMETER2)); 
			String iptalNedeni = IPTAL;
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			String responseCode = "";
			String responseMessage = "";
			
			TahsilatIptalApiCType response = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			response = MaskiClient.sendCollectionCancelMessage(reqTimeout, connTimeout, serviceUrl, kurumKodu, apiKey, odemeNo, tahsilatId, iptalNedeni, serviceMessage);
			responseCode = response.getGeriBildirim().getKodu().toString();
			responseMessage = response.getGeriBildirim().getAciklama();
			
			GMMap responseCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responseCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responseCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
	}
	
	//	/api/AboneApi/TalimatOlustur
	@GraymoundService("ICS_MALATYA_MASKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_SEND_STANDING_ORDER_MESSAGE");

		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long aboneKodu = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			String responseCode = "";
			String responseMessage = "";
			
			AboneTalimatOlusturApiCType response = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			response = MaskiClient.sendStandingOrderMessage(reqTimeout, connTimeout, serviceUrl, apiKey, kurumKodu, aboneKodu, serviceMessage);
			responseCode = response.getGeriBildirim().getKodu().toString();
			responseMessage = response.getGeriBildirim().getAciklama();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		}
		catch (Exception e) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
	}
	
	//	/api/AboneApi/TalimatIptal
	@GraymoundService("ICS_MALATYA_MASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		
		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);

			Long aboneKodu = iMap.getLong(MapKeys.SUBSCRIBER_NO1);;
			String iptalNedeni = IPTAL;
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = "";
			String responseMessage = "";
			AboneTalimatIptalApiCType response = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			response = MaskiClient.sendStandingOrderCancelMessage(reqTimeout, connTimeout, serviceUrl, apiKey, kurumKodu, aboneKodu, iptalNedeni, serviceMessage);
			responseCode = response.getGeriBildirim().getKodu().toString();
			responseMessage = response.getGeriBildirim().getAciklama();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		}
		catch (Exception e) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
	}
	
//	/api/AboneApi/TalimatliAboneler 	
	@GraymoundService("ICS_MALATYA_MASKI_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_STANDING_ORDER_RECONCILIATION");

		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			String instCount = iMap.getString(MapKeys.RECON_STANDINGORDER_COUNT) == null ? "0" : iMap.getString(MapKeys.RECON_STANDINGORDER_COUNT);
			String cancCount = iMap.getString(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT) == null ? "0" : iMap.getString(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT);
			String collectTotal = iMap.getString(MapKeys.RECON_COLLECTION_TOTAL) == null ? "0" : iMap.getString(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			BigDecimal instructionCount = new BigDecimal(instCount);
			BigDecimal cancelCount = new BigDecimal(cancCount);
			BigDecimal collectionTotal = new BigDecimal(collectTotal);
			
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			String responseCode = "";
			String responseMessage = "";
			TalimatliAbonelerApiCType response = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			response = MaskiClient.instructionGeneralReconciliationResponse(reqTimeout, connTimeout, serviceUrl, apiKey, kurumKodu, serviceMessage);
			responseCode = response.getGeriBildirim().getKodu().toString();
			responseMessage = response.getGeriBildirim().getAciklama();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getAbonelerApiList().size());
				//oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, instructionGeneralReconciliationResponse.getIptalAdeti());

				oMap.put(MapKeys.ERROR_CODE, response.getGeriBildirim().getKodu());
				oMap.put(MapKeys.ERROR_DESC, response.getGeriBildirim().getAciklama());
	
			}
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_MASKI_STANDING_ORDER_RECONCILIATION");
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}
	
	// /api/TahsilatApi/BorcTopluTalimatOku
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_MALATYA_MASKI_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_DEBT_INQUERY_FOR_STANDING_ORDER");

		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String vadeTarihi = "";
			
			Date lastPaymentDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PROCESS_DATE)))
				lastPaymentDate = iMap.getDate(MapKeys.PROCESS_DATE); 


			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = "";
			String responseMessage = "";
			BorcTopluTalimatOkuApiCType orderedDebtListResponse = null;
			ArrayList<BorcOkuApiCType> orderedBorcOkuApiResponse = null;
			
			String date = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				date = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				date = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			vadeTarihi = date;
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			orderedDebtListResponse = MaskiClient.getdebtQueryForStandingOrder(reqTimeout, connTimeout, serviceUrl, kurumKodu, apiKey, vadeTarihi, serviceMessage);
			orderedBorcOkuApiResponse = orderedDebtListResponse.getBorcAboneApiList();
			responseCode = orderedDebtListResponse.getGeriBildirim().getKodu().toString();
			responseMessage = orderedDebtListResponse.getGeriBildirim().getAciklama();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && orderedBorcOkuApiResponse != null) {
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				
				GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
				int counter = 0;

				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
				
				for (int i = 0; i < bankStandingOrderList.size(); i++) {
					icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
					if (icsStandingOrder.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
						String subscriberNo = icsStandingOrder.getSubscriberNo1();
						for (BorcOkuApiCType corpData : orderedBorcOkuApiResponse) {
							
							GMMap responceDetailCodeMap = getResponseCodeMapping(corpData.getGeriBildirim().getKodu().toString(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			                String errorDetailCode = responceDetailCodeMap.getString(MapKeys.ERROR_CODE);
			                oMap.put(MapKeys.ERROR_CODE, responceDetailCodeMap.getString(MapKeys.ERROR_CODE));
			                oMap.put(MapKeys.ERROR_DESC, responceDetailCodeMap.getString(MapKeys.ERROR_DESC));
							
							if (errorDetailCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
								List<BorcDetayApi> billList =  corpData.getBorcDetayApiList();
								for (BorcDetayApi bill : billList) {
									String s1 = CommonHelper.trimStart(bill.getAboneKodu().toString(), '0');
									if (s1.equals(subscriberNo)) {
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, corpData.getAdi() + " " + corpData.getSoyadi());

										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, corpData.getGenelBorcToplam());
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, corpData.getGuid());
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CUSTOMER_ADDRESS, corpData.getAdres());
										
										oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bill.getAboneKodu());
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, bill.getAboneSozlesmeNo());

				                        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
				                        Date date2 = inputFormat.parse(bill.getVadeTarihi().toString());

				                        Calendar calendar = Calendar.getInstance();
				                        calendar.setTime(date2);

				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getBorcId());

				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, calendar.getTime());
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getGenelToplam());
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, bill.getAciklama());
				                        oMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CUSTOMER_ADDRESS, bill.getAboneAdres());
				                        
										oMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
										oMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
										
										counter++;
									}
								
								}
						    }
						}
					}
				}

				oMap.put(MapKeys.TABLE_SIZE, counter);
				oMap.put(MapKeys.RESPONSE_CODE, responseCode);
				oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}

		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_MASKI_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}
	
	// /api/TahsilatApi/GunlukIcmal   (MutabakatGenel)
	@GraymoundService("ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION");

		try {
			//String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			Long kurumKodu = Long.parseLong(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

				Date reconDate = new Date();
				if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
					reconDate = iMap.getDate(MapKeys.RECON_DATE);

			//Date date = new Date();
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(reconDate);
			int yil = calendar.get(Calendar.YEAR);
			int ay = calendar.get(Calendar.MONTH) + 1;
			int gun = calendar.get(Calendar.DAY_OF_MONTH);
			
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			BigDecimal allCollectionTotal = collectionTotal.add(cancelTotal);
			int allCollectionCount = collectionCount + cancelCount;

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, allCollectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, allCollectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			TahsilatGunlukIcmalApiCType tahsilatGunlukIcmalApiGeneralResponse = null;
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			tahsilatGunlukIcmalApiGeneralResponse = MaskiClient.collectionReconciliation(reqTimeout, connTimeout, serviceUrl, apiKey, kurumKodu, yil, ay, gun, serviceMessage);
			GeriBildirim geriBildirim = tahsilatGunlukIcmalApiGeneralResponse.getGeriBildirim();
			responseCode = geriBildirim.getKodu().toString();
			responseMessage = geriBildirim.getAciklama().toString();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, tahsilatGunlukIcmalApiGeneralResponse.getMakbuzToplamAdet() != 0 ? tahsilatGunlukIcmalApiGeneralResponse.getMakbuzGenelToplam() : new BigDecimal(0));
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, tahsilatGunlukIcmalApiGeneralResponse.getMakbuzToplamAdet() != 0 ? tahsilatGunlukIcmalApiGeneralResponse.getMakbuzToplamAdet() : 0);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, tahsilatGunlukIcmalApiGeneralResponse.getMakbuzIptalAdet() != 0 ? tahsilatGunlukIcmalApiGeneralResponse.getMakbuzIptalToplam() : new BigDecimal(0));
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, tahsilatGunlukIcmalApiGeneralResponse.getMakbuzIptalAdet() != 0 ? tahsilatGunlukIcmalApiGeneralResponse.getMakbuzIptalAdet() : 0);
				//oMap.put("CORPORATE", 0, MapKeys.RECON_COUNT, tahsilatGunlukIcmalApiGeneralResponse.getMakbuzNormalAdet()); ???
				//oMap.put("CORPORATE", 0, MapKeys.RECON_COUNT, tahsilatGunlukIcmalApiGeneralResponse.getMakbuzGenelToplam()); ???
				
				if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
						&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
						&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 
						&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0){
					
					oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			oMap.put(MapKeys.ERROR_CODE, tahsilatGunlukIcmalApiGeneralResponse.getGeriBildirim().getKodu().toString());
			oMap.put(MapKeys.ERROR_DESC, tahsilatGunlukIcmalApiGeneralResponse.getGeriBildirim().getAciklama());
		}
		catch (Throwable e) {
			logger.info("ICS_MASKI_COLLECTION_RECONCILIATION - mutabakat hatali ");
			oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			oMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}
	
	// Mutabakat Detay Servisi
	@GraymoundService("ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage serviceMessage = new ServiceMessage();

		try {

			CollectionReconciliationDetailBatch batch = new MaskiReconciliationDetailBatch(iMap, serviceMessage);
			oMap = batch.runBatch();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());

			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_MASKI_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			oMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}
	
	@GraymoundService("ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MALATYA_MASKI_COLLECTION_RECONCILIATION_CLOSED");
		try {
			// mutabakat cagirildiginda basarili olursa otomatik olarak
			// kapaniyor. kurumun mutabakat kapatma servisi yoktur. bunun icin
			// herhangi bir servis entegrasyonu yapilmadi!
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
}
