package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.EskomReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.eskomJaxWs.EskomJaxWSClient;
import tr.com.aktifbank.integration.eskomJaxWs.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.eskomJaxWs.AboneBilgiRequestType;
import tr.com.eskomJaxWs.AboneBilgiResponse;
import tr.com.eskomJaxWs.ArrayOfBorcDetay;
import tr.com.eskomJaxWs.BorcDetay;
import tr.com.eskomJaxWs.BorcResponse;
import tr.com.eskomJaxWs.IptalResponse;
import tr.com.eskomJaxWs.MutabakatResponse;
import tr.com.eskomJaxWs.TahsilatResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EskomServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(EskomServices.class);

	@GraymoundService("ICS_ESKOM_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String errorCode = "";
			String errorDesc = "";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String glrmdIdList = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			
			ServiceMessage serviceMessage = new ServiceMessage();
			String sorgulamaTipi = "";
			
			String subscriberNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String tcNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String subscriberWaterNumber = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String subscriberId = iMap.getString(MapKeys.SUBSCRIBER_NO4);
			String aboneNumarasi = "";
			String sicilNo = "";
			String suAboneNo= "";
			int guser = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			AboneBilgiResponse aboneBilgiResponse = null;
			if (StringUtils.isNotBlank(subscriberNumber) && StringUtils.isNotBlank(CommonHelper.trimStart(subscriberNumber, '0'))) {
				aboneBilgiResponse = EskomJaxWSClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, CommonHelper.trimStart(subscriberNumber, '0'), AboneBilgiRequestType.SICIL_NO.toString(), serviceMessage);
				sorgulamaTipi = AboneBilgiRequestType.SICIL_NO.toString();
				sicilNo = aboneBilgiResponse.getSicilNo();
				aboneNumarasi = subscriberNumber;
			}else if (StringUtils.isNotBlank(tcNumber) && StringUtils.isNotBlank(CommonHelper.trimStart(tcNumber, '0'))) {
				aboneBilgiResponse = EskomJaxWSClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, CommonHelper.trimStart(tcNumber, '0'), AboneBilgiRequestType.TC_KIMLIK_NO.toString(), serviceMessage);
				sorgulamaTipi = AboneBilgiRequestType.TC_KIMLIK_NO.toString();
				sicilNo = aboneBilgiResponse.getSicilNo();
				aboneNumarasi = tcNumber;
			} else if (StringUtils.isNotBlank(subscriberWaterNumber) && StringUtils.isNotBlank(CommonHelper.trimStart(subscriberWaterNumber, '0'))) {
				aboneBilgiResponse=EskomJaxWSClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, CommonHelper.trimStart(subscriberWaterNumber, '0'), AboneBilgiRequestType.SU_SICIL_NO.toString(), serviceMessage);
				sorgulamaTipi = AboneBilgiRequestType.SU_SICIL_NO.toString();
				suAboneNo= aboneBilgiResponse.getSicilNo(); 
				aboneNumarasi = subscriberWaterNumber;
			} else if (StringUtils.isNotBlank(subscriberId) && StringUtils.isNotBlank(CommonHelper.trimStart(subscriberId, '0'))) {
				aboneBilgiResponse = EskomJaxWSClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, CommonHelper.trimStart(subscriberId, '0'), AboneBilgiRequestType.SICIL_ID.toString(), serviceMessage);
				sorgulamaTipi = AboneBilgiRequestType.SICIL_ID.toString();
				sicilNo = aboneBilgiResponse.getSicilNo();
				aboneNumarasi = subscriberId;
			}
			try {
				iMap.put("ABONE_BILGI_REQUEST_XML", serviceMessage.getRequest());
				outMap.put("ABONE_BILGI_RESPONSE_XML", serviceMessage.getResponse());
			} catch (Exception e) {
				logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> aboneSorgu service message xml al�rken hata meydana geldi.");
			}
			if (aboneBilgiResponse == null) {
				errorCode = "660";
				errorDesc = "Kurum web servis �a�r�s�nda hata meydana geldi.";
				logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> abone sorgu web servis cagrisi sonucu null dondu.");
			} else {
				errorCode = aboneBilgiResponse.getKod();
				if (GeneralConstants.ERROR_CODE_APPROVE.equals(aboneBilgiResponse.getKod())) {
					// sorgulama basarili oldu
					int sicilId = aboneBilgiResponse.getSicilId();
					int beyanId = aboneBilgiResponse.getBeyanId();
					
					BorcResponse borcSorguResult = EskomJaxWSClient.borc(reqTimeout, connTimeout, url, username, password, beyanId, guser, sicilId, sicilNo,suAboneNo, serviceMessage);
					try {
						iMap.put("BORC_SORGU_REQUEST_XML", serviceMessage.getRequest());
						outMap.put("BORC_SORGU_RESPONSE_XML", serviceMessage.getResponse());
					} catch (Exception e) {
						logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> borcSorgu service message xml al�rken hata meydana geldi.");
					}
					if (borcSorguResult == null) {
						errorCode = "660";
						errorDesc = "Kurum web servis �a�r�s�nda hata meydana geldi.";
						logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> borc sorgu web servis cagrisi sonucu null dondu.");
					} else {
						errorCode = borcSorguResult.getKod();
						if (GeneralConstants.ERROR_CODE_APPROVE.equals(borcSorguResult.getKod())) {
							
							HashMap<Integer, String> borcTurleri = null;
							if(glrmdIdList != null){
								borcTurleri = new HashMap<Integer, String>();
								for(String s : glrmdIdList.split(",")){
									borcTurleri.put(Integer.valueOf(s), "1");
								}
							}
							
							int counter = 0;
							ArrayOfBorcDetay borcArray = borcSorguResult.getBorcdetay();
							for (BorcDetay borc : borcArray.getBorcDetay()) {
								if(borcTurleri == null || borcTurleri.containsKey(borc.getGlrmdId())){
									if (!isCollectedInvoice(borc.getTahakkukNo(),subscriberNumber, tcNumber,subscriberWaterNumber , subscriberId, corporateCode)) {
										String termYear = borc.getYil();
										String termMonth = borc.getDonem();
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, aboneNumarasi);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getTahakkukNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplamTutar());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, aboneBilgiResponse.getAd().concat(" ").concat(aboneBilgiResponse.getSoyad()));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonOdemeTarih(), "dd-MM-yyyy"));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplamTutar());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getSicilId());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcSorguResult.getNetId());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borcSorguResult.getSicilNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, borc.getVergiTur());
										outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
										outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
										counter++;
									}
								}
							}
						}
					}
				} else {
					// sorgulama basarisiz oldu hata kodunu al ve dondur
					errorCode = "660";
					errorDesc = aboneBilgiResponse.getMesaj().concat("(Sorgu Tipi : ".concat(sorgulamaTipi).concat(" )"));
					logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> hata meydana geldi, kurumdan donen cevap : ".concat(errorDesc).concat(" Sorgu Tipi : ").concat(sorgulamaTipi).concat(" Abone Numarasi : ").concat(aboneNumarasi));
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(errorCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ESKOM_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_DO_INVOICE_COLLECTION");
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			int sicilId = iMap.getInt(MapKeys.PARAMETER1);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
			int netId = iMap.getInt(MapKeys.PARAMETER3);
			BigDecimal tahsilatTutar = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			tahsilatTutar.setScale(2);
			tahsilatTutar = tahsilatTutar.add(new BigDecimal("0.00"));
			// tahsilatTutar=tahsilatTutar.subtract(new BigDecimal("0.01"));
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyyMMdd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			}
				
			int guser = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			TahsilatResponse eskomTahsilat = EskomJaxWSClient.tahsilat(reqTimeout, connTimeout, url, username, password, guser, sicilId, null, tahakkukNo, bankaReferansNo, netId, tahsilatTutar, tahsilatTarihi, serviceMessage);
			responseCode = eskomTahsilat.getKod();
			iMap.put("REQUEST_XML_TAHSILAT", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT", serviceMessage.getResponse());
			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responseCode)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter1(iMap.getString(MapKeys.PARAMETER1));
					invoicePayment.setParameter2(iMap.getString(MapKeys.PARAMETER2));
					invoicePayment.setParameter3(iMap.getString(MapKeys.PARAMETER3));
					invoicePayment.setParameter4(iMap.getString(MapKeys.PARAMETER4));
					invoicePayment.setParameter5(eskomTahsilat.getBankaReferansNo());
					invoicePayment.setParameter6(eskomTahsilat.getKod());
					invoicePayment.setParameter7(eskomTahsilat.getMesaj());
					invoicePayment.setParameter8(eskomTahsilat.getSeriNo());
					invoicePayment.setParameter9(eskomTahsilat.getSiraNo());
					// parameter11 iptalde kullanilacaktir
					invoicePayment.setParameter11(Integer.toString(eskomTahsilat.getTahsilatId()));
					session.saveOrUpdate(invoicePayment);
				}
			} else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, eskomTahsilat.getMesaj());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, eskomTahsilat.getMesaj());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ESKOM_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			ServiceMessage serviceMessage = new ServiceMessage();
			int tahsilatId = 0;
			if (iMap.getInt(MapKeys.PARAMETER_11) > 0) {
				tahsilatId = iMap.getInt(MapKeys.PARAMETER_11);
			} else {
				tahsilatId = iMap.getInt(MapKeys.PARAMETER11);
			}
			String bankaReferansNo = "0";
			if (iMap.getString(MapKeys.PARAMETER5) == null) {
				bankaReferansNo = iMap.getString(MapKeys.PARAMETER_5);
			} else {
				bankaReferansNo = iMap.getString(MapKeys.PARAMETER5);
			}
			String iptalneden = "MUSTERI_ISTEGI";
			int guser = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			IptalResponse tahsilatIptal = EskomJaxWSClient.iptal(reqTimeout, connTimeout, url, username, password, tahsilatId, bankaReferansNo, iptalneden, guser, serviceMessage);
			iMap.put("REQUEST_XML_IPTAL", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_IPTAL", serviceMessage.getResponse());
			String responseCode = tahsilatIptal.getKod();
			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responseCode)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, tahsilatIptal.getMesaj());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, tahsilatIptal.getMesaj());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ESKOM_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			ServiceMessage serviceMessage = new ServiceMessage();
			int guser = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String tarih = iMap.getString(MapKeys.RECON_DATE);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
			MutabakatResponse mutabakat = EskomJaxWSClient.mutabakat(reqTimeout, connTimeout, url, username, password, bankaReferansNo, tarih, guser, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (GeneralConstants.ERROR_CODE_APPROVE.equals(mutabakat.getKod())) {

				// banka kayitlarini hesapla
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				BigDecimal reconCollectionTotalBank = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
				BigDecimal reconCancelTotalBank = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
				int reconCollectionCountBank = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
				int reconCancelCountBank = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
				reconCollectionCountBank = reconCancelCountBank + reconCollectionCountBank;
				reconCollectionTotalBank = reconCollectionTotalBank.add(reconCancelTotalBank);

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconCollectionTotalBank);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconCancelTotalBank);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconCollectionCountBank);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconCancelCountBank);
				BigDecimal corpTahsilatTutar = new BigDecimal("0");
				if (mutabakat.getTahsilatTutar() != null) {
					corpTahsilatTutar = mutabakat.getTahsilatTutar();
				}

				BigDecimal corpIptalTutar = new BigDecimal("0");
				if (mutabakat.getIptalTutar() != null) {
					corpIptalTutar = mutabakat.getIptalTutar();
				}

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpTahsilatTutar);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpIptalTutar);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, mutabakat.getTahsilatSayi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, mutabakat.getIptalSayi());

				if (reconCollectionTotalBank.compareTo(corpTahsilatTutar) == 0 && reconCancelTotalBank.compareTo(corpIptalTutar) == 0 && reconCollectionCountBank == mutabakat.getTahsilatSayi() && reconCancelCountBank == mutabakat.getIptalSayi()) {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "");
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "Say� ve tutarlar farkl� oldu�u i�in mutabakat ba�ar�s�z!");
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
			} else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, mutabakat.getMesaj());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, mutabakat.getMesaj());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e) {
			outMap.put(MapKeys.ERROR_CODE, "660");
			outMap.put(MapKeys.ERROR_DESC, "Mutabakat yap�l�rken hata meydana geldi!");
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "Mutabakat yap�l�rken hata meydana geldi!".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal reconCollectionTotalBank = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int reconCollectionCountBank = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			iMap.put(MapKeys.RECON_BANK_COUNT, reconCollectionCountBank);
			iMap.put(MapKeys.RECON_COLLECTION_TOTAL, reconCollectionTotalBank);
			CollectionReconciliationDetailBatch batch = new EskomReconciliationDetailBatch(iMap, serviceMessage);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
		} catch (Throwable e) {
			logger.info("ICS_ESKOM_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;

	}

	@GraymoundService("ICS_ESKOM_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;

	}
}
