package tr.com.aktifbank.bnspr.corporation.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.json.JSONArray;
import org.json.JSONObject;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AtlantisServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(DuruNetServices.class);
	
	@GraymoundService("ICS_ATLANTIS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ATLANTIS_INVOICE_DEBT_INQUIRY");
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
        String result = "";
		try {
		  URL	url = new URL(wsUrl);
		
          URLConnection con = url.openConnection();

          // activate the output
          con.setDoOutput(true);
          PrintStream ps = new PrintStream(con.getOutputStream());
          // send your parameters to your site
          ps.print("&abone_no="+subscriberNo);
          ps.print("&api_key="+password);               
 
          // we have to get the input stream in order to actually send the request
          con.getInputStream();
          BufferedReader is = new BufferedReader(new InputStreamReader(con.getInputStream()));
  		String line;

  		while ((line = is.readLine()) != null)
  			result += line;
  		
  		if(!result.equals("null")){
  			JSONArray jsonArray=new JSONArray(result);
  	  		for (int i = 0; i < jsonArray.length(); i++) {
  	  	  		JSONObject jo = jsonArray.getJSONObject(i);
  	  	  		String subscriberName =jo.isNull("isim") ? "" : jo.getString("isim");
  	  	  		String subscriberSurname = jo.isNull("soyisim") ? "" : jo.getString("soyisim");
  	  	  		String amount = jo.isNull("tarife_fiyat") ? "" : jo.getString("tarife_fiyat");
  	  	  		String tckn = jo.isNull("tc_no") ? "" : jo.getString("tc_no");
  	  	  		String phone = jo.isNull("telefon") ? "" : jo.getString("telefon");
  	  	  		String desc = jo.isNull("tarife_adi") ? "" : jo.getString("tarife_adi");
  	  	  		String invoiceDate = jo.isNull("fatura_tarih") ? "" : jo.getString("fatura_tarih");
  	  	  		String invoiceNo = jo.isNull("fatura_id") ? "0" : jo.getString("fatura_id");
  	  	  		String invoiceDueDate = jo.isNull("son_odeme_tarihi") ? "" : jo.getString("son_odeme_tarihi");
  	  	  		
  	  	  		
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, subscriberNo);
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, amount);
  	  			if (!invoiceDueDate.equals("")) {
  	  				output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, invoiceDueDate.substring(0,4));
  	  				output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, invoiceDueDate.substring(5,7));
  	  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoiceDueDate, "yyyy-MM-dd HH:mm:ss"));
  				}

  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, invoiceNo);
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, subscriberName+" "+ subscriberSurname);
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, "");
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, collectionType);
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
  	  			output.put(MapKeys.INVOICE_LIST, i, MapKeys.DESCRIPTION, desc);

  	  			output.put(MapKeys.INVOICE_LIST, i, "SELECT", false);
  	  			output.put(MapKeys.INVOICE_LIST, i, "OID", "0");
  			}
  		}
  		
  	
		output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

  		
  		
  		System.out.println(result);
		}catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			output.put("RESPONSE_XML", result);
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}

	@GraymoundService("ICS_ATLANTIS_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();
		GMMap responceCodeMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ATLANTIS_DO_INVOICE_COLLECTION");
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String paymentAmount = iMap.getString(MapKeys.PAYMENT_AMOUNT);
		String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
		String result = "";
		String request="&api_key="+password+":"+"&abone_no="+subscriberNo+":"+"&fatura_id="+invoiceNo+":"+"&fiyat="+paymentAmount;
		
		try { 
			ServiceMessage sm = new ServiceMessage();
			URL	url = new URL(wsUrl);		
	        URLConnection con = url.openConnection();
	       
	        // activate the output
	        con.setDoOutput(true);
	        PrintStream ps = new PrintStream(con.getOutputStream());
	        // send your parameters to your site
	        ps.print("&api_key="+password);          
	        ps.print("&abone_no="+subscriberNo);	         
	        ps.print("&fatura_id="+invoiceNo);
	        ps.print("&fiyat="+paymentAmount);            
	 
	        // we have to get the input stream in order to actually send the request
	        con.getInputStream();
	        BufferedReader is = new BufferedReader(new InputStreamReader(con.getInputStream()));
	  		String line;

	  		while ((line = is.readLine()) != null)
	  			result += line;
	  		
	  		JSONObject jo=new JSONObject(result);
	  				
			if ("1".equals(jo.getString("durum"))) {
		
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				invoiceNo=jo.getString("fatura_no");
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setInvoiceNo(invoiceNo);

				session.saveOrUpdate(invoicePayment);
			}else{
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	  		
			System.out.println(result);
		}catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			output.put("REQUEST_TXT", request);
			output.put("RESPONSE_TXT", result);
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_ATLANTIS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		GMMap responceCodeMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ATLANTIS_SEND_COLLECTION_CANCEL_MESSAGE");
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String subscriberNo = iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1);
		String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
		String request="&api_key="+password+":"+"&fatura_id="+invoiceNo+":"+"&abone_no="+subscriberNo;
		String result="";
		try {
			ServiceMessage sm = new ServiceMessage();
			URL	url = new URL(wsUrl);
	        URLConnection con = url.openConnection();
	        // activate the output
	        con.setDoOutput(true);
	        PrintStream ps = new PrintStream(con.getOutputStream());
	        // send your parameters to your site
	        ps.print("&api_key="+password);
	        ps.print("&fatura_no="+invoiceNo);
	        ps.print("&abone_no="+subscriberNo);
	 
	        // we have to get the input stream in order to actually send the request
	        con.getInputStream();
	        BufferedReader is = new BufferedReader(new InputStreamReader(con.getInputStream()));
	  		String line;

	  		while ((line = is.readLine()) != null)
	  			result += line;
	  		
	  		JSONObject jo=new JSONObject(result);
				
			if ("1".equals(jo.getString("durum"))) {
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			}else{
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			}
	  		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	  		
			System.out.println(result);
		}catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			
			output.put("REQUEST_TXT", request);
			output.put("RESPONSE_TXT", result);
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@SuppressWarnings("unused")
	@GraymoundService("ICS_ATLANTIS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		GMMap responceCodeMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ATLANTIS_COLLECTION_RECONCILIATION");
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String reconDate = iMap.getString(MapKeys.RECON_DATE);
		String date = CommonHelper.formatDateString(reconDate, "yyyyMMdd", "yyyy-MM-dd");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
        String result = "";
        String request="&api_key="+password+":"+"&tarih="+date;
		try {
			ServiceMessage sm = new ServiceMessage();
			URL	url = new URL(wsUrl);
	        URLConnection con = url.openConnection();
	        // activate the output
	        con.setDoOutput(true);
	        PrintStream ps = new PrintStream(con.getOutputStream());
	        // send your parameters to your site
	        ps.print("&api_key="+password);
	        ps.print("&tarih="+date);
	        
	        // we have to get the input stream in order to actually send the request
	        con.getInputStream();
	        BufferedReader is = new BufferedReader(new InputStreamReader(con.getInputStream()));
	  		String line;

	  		while ((line = is.readLine()) != null)
	  			result += line;
	  		BigDecimal corpCollectionTotal= new BigDecimal(0);
	  		JSONArray jsonArray=new JSONArray(result);
	  		
	  		
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			
		    int corpCollectionCount=jsonArray.length();
		    for (int i = 0; i < jsonArray.length(); i++) {
			  	  	JSONObject jo = jsonArray.getJSONObject(i);
			  	  	String amount = jo.getString("tarife_fiyat");
			  	  	corpCollectionTotal = corpCollectionTotal.add(new BigDecimal(amount));
			 }
		        	output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpCollectionTotal);
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpCollectionCount);
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
		     

			 if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
						&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
						&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
					// mutabakat basarili o zaman kapatalim
					logger.info("ICS_DURUNET_COLLECTION_RECONCILIATION - mutabakat basarili  ");
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					
				} else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
	  		System.out.println(result);
	  		output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	  		
			System.out.println(result);
		}catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			
			output.put("REQUEST_TXT", request);
			output.put("RESPONSE_TXT", result);
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}

	//Mutabakat Kapama
	@GraymoundService("ICS_ATLANTIS_COLLECTION_RECONCILIATION_CLOSED")
    public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
          GMMap output = new GMMap();
          
          iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ATLANTIS_COLLECTION_RECONCILIATION_CLOSED");
          
          try{
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
          }
          catch(Exception e){
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
                output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
                output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
                throw ExceptionHandler.convertException(e);
          }
          finally{
                insertOnlineServiceLog(iMap, output);
          }
          
          return output;
    }

}
