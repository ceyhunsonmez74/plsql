package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.PalmetReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.palmet.PalmetClient;
import tr.com.aktifbank.integration.palmet.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.palmet.dto.BorcSorguResponse;
import tr.com.palmet.dto.BorcSorgulaResult;
import tr.com.palmet.dto.MutabakatResult;
import tr.com.palmet.dto.Result;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PalmetServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(PalmetServices.class);
	private static final String YIM_CHANNEL_DEALER = "D";
	private static final short VALOR = 0;

	@GraymoundService("ICS_PALMET_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PALMET_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			// client icerisinde hangi alan dolu ise o alana gore sorgulama
			// yapilacaktir
			long tesisatNo = Long.valueOf(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";
			BorcSorgulaResult response;
			response = PalmetClient.borcSorgula(userName, passWord, url, timeOut, firmaKodu, tesisatNo, bankaKodu, serviceMessage);
			if (StringUtil.isEmpty(response.getBorcSorguResponseList().get(0).getMESAJ())) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode = response.getBorcSorguResponseList().get(0).getMESAJ();

			}
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (BorcSorguResponse bill : response.getBorcSorguResponseList()) {
						if (!isCollectedInvoice(bill.getFATURA_ID(), iMap.getString(MapKeys.SUBSCRIBER_NO1), "", "", "", corporateCode)) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bill.getTESISAT_NO());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getFATURA_ID());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getTUTAR());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getABONE_ADI());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(CommonHelper.getDateTime(bill.getSON_ODEME_TARIHI().substring(0, 10), "yyyy-MM-dd")));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getSON_ODEME_TARIHI().substring(0,4));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getSON_ODEME_TARIHI().substring(5,7));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getTUTAR());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, bill.getFATURA_TIPI());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
						}
					}
				}
			
		} catch (Throwable e2) {
			logger.error("ICS_PALMET_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_PALMET_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PALMET_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			int kullaniciKodu = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			short valor = VALOR;
			String bankaHesapNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int faturaId = iMap.getInt(MapKeys.INVOICE_NO);
			String dekontNo = iMap.getString(MapKeys.TRX_NO);

			String sourceCode = iMap.getString(MapKeys.SOURCE,"2");
			String channelCode = CommonHelper.getChannelId();
			Double tahsilatTutari = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();

			if (YIM_CHANNEL_DEALER.equals(iMap.getString(MapKeys.YIM_CHANNEL))){
				kullaniciKodu = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			}
			
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
				channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			}
			
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			Calendar tahsilatTarihi = Calendar.getInstance();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
			} else {
				tahsilatTarihi.setTime(new Date());
			}
			
			String responseCode = "0";
			String responseMessage = "";
			Result response = PalmetClient.tahsilat(userName, passWord, url, timeOut, firmaKodu, tahsilatTutari, kullaniciKodu, valor, bankaHesapNo, dekontNo, tahsilatTarihi, bankaKodu, Short.valueOf(paymentChannel), faturaId, serviceMessage);
				responseCode = response.getMessage();
				responseMessage = response.getMessageDescription();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_PALMET_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PALMET_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			int kullaniciKodu = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int faturaId = iMap.getInt(MapKeys.INVOICE_NO);
			String dekontNo = iMap.getString(MapKeys.TRX_NO,"0");
			Double tahsilatTutari = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();

			Result response = PalmetClient.tahsilatIptal(userName, passWord, url, timeOut, faturaId, dekontNo, tahsilatTutari, firmaKodu, bankaKodu, kullaniciKodu, serviceMessage);
			String	responseCode = response.getMessage();
			String 	responseMessage = response.getMessageDescription();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	
	@GraymoundService("STO_PALMET_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_PALMET_SEND_STANDING_ORDER_MESSAGE");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String kullaniciKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int bankReferansNo = iMap.getInt(MapKeys.TRX_NO);
			long tesisatNo = Long.valueOf(iMap.getString(MapKeys.SUBSCRIBER_NO1));


			String sourceCode = iMap.getString(MapKeys.SOURCE,"2");
			String channelCode = CommonHelper.getChannelId();

			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
				channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			}
			
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String islemKanali = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			Calendar talimatTarihi = Calendar.getInstance();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				talimatTarihi.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
			} else {
				talimatTarihi.setTime(new Date());
			}
			
			String responseCode = "0";
			String responseMessage = "";
			Result response = PalmetClient.talimat(userName, passWord, url, timeOut, bankaKodu, talimatTarihi, kullaniciKodu, tesisatNo, firmaKodu, Integer.parseInt(islemKanali), bankReferansNo, serviceMessage);
					responseCode = response.getMessage();
				responseMessage = response.getMessageDescription();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_PALMET_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_PALMET_SEND_STANDING_ORDER_MESSAGE");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String kullaniciKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int bankReferansNo = iMap.getInt(MapKeys.TRX_NO);
			long tesisatNo = Long.valueOf(iMap.getString(MapKeys.SUBSCRIBER_NO1));


			String sourceCode = iMap.getString(MapKeys.SOURCE,"2");
			String channelCode = CommonHelper.getChannelId();

			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
				channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			}
			
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String islemKanali = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			Calendar talimatIptalTarihi = Calendar.getInstance();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				talimatIptalTarihi.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
			} else {
				talimatIptalTarihi.setTime(new Date());
			}
			
			String responseCode = "0";
			String responseMessage = "";
			Result response = PalmetClient.talimatIptal(userName, passWord, url, timeOut, bankaKodu, kullaniciKodu, talimatIptalTarihi, bankReferansNo, Integer.parseInt(islemKanali), tesisatNo, firmaKodu, serviceMessage);
					responseCode = response.getMessage();
				responseMessage = response.getMessageDescription();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_PALMET_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_PALMET_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();
			
			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				GMMap queryMap = new GMMap();
				queryMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				
				queryMap.put(MapKeys.BANK_CODE, iMap.getString(MapKeys.BANK_CODE));
				queryMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				queryMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
				queryMap.put(MapKeys.GM_SERVICE_NAME, "ICS_SEARCH_INVOICE");
				queryMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
				GMMap invoiceMap = new GMMap();
				
				debtLoadingMap = (GMMap) GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", queryMap);
				
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_PALMET_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_PALMET_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PALMET_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Calendar mutabakatTarihi = Calendar.getInstance();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				mutabakatTarihi= CommonHelper.getCalendarWithYYYYMMDD(iMap.getString(MapKeys.RECON_DATE));
			} else {
				mutabakatTarihi.setTime(new Date());
			}
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String kullaniciKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			MutabakatResult result = PalmetClient.mutabakat(userName, passWord, url, timeOut, firmaKodu, bankaKodu, mutabakatTarihi,s);
			GMMap responceCodeMap = getResponseCodeMapping(String.valueOf(result.getReturnSPValue()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(StringUtils.isBlank(result.getTotalAmount()) ? "0" : result.getTotalAmount().replace(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, new BigDecimal(StringUtils.isBlank(result.getTotalCount()) ? "0" : result.getTotalCount()));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, new BigDecimal(StringUtils.isBlank(result.getCancelTotalCount()) ? "0" : result.getCancelTotalCount()));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(StringUtils.isBlank(result.getCancelTotalAmount()) ? "0" : result.getCancelTotalAmount().replace(",", ".")));
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			}

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_PALMET_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_PALMET_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PALMET_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			short firmaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			short bankaKodu = Short.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			
			Calendar mutabakatTarihi = Calendar.getInstance();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				mutabakatTarihi = CommonHelper.getCalendarWithYYYYMMDD(iMap.getString(MapKeys.RECON_DATE));
			} else {
				mutabakatTarihi.setTime(new Date());
			}
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			int bankaIslemReferansi  = iMap.getInt(MapKeys.TRX_NO);
			Result result = PalmetClient.mutabakatKapat(userName, passWord, url, timeOut, bankaKodu, bankaIslemReferansi, firmaKodu, mutabakatTarihi, s);
			String responseCode = result.getMessage();
	
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			// Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_PALMET_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_PALMET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		logger.info("ICS_PALMET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PALMET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new PalmetReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_PALMET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
}
