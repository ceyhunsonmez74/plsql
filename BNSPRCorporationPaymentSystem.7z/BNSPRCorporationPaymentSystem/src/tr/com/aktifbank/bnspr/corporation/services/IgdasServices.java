package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.igdas.old.IgdasClient;
import tr.com.aktifbank.integration.igdas.old.ServiceMessage;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.gov.igdas.WebServices.AboneBaglantiBorcCevapTesisat;
import tr.gov.igdas.WebServices.AboneBaglantiBorcCevapTesisatTaksit;
import tr.gov.igdas.WebServices.AboneBaglantiBorcSorgulamaCevap;
import tr.gov.igdas.WebServices.AboneBaglantiTahsilatCevap;
import tr.gov.igdas.WebServices.AboneBaglantiTahsilatIptalCevap;
import tr.gov.igdas.WebServices.AboneTalimatCevap;
import tr.gov.igdas.WebServices.AboneTalimatMutabakatCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneBaglantiBorcSorgulamaCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneBaglantiTahsilatCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneBaglantiTahsilatIptalCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneTalimatCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneTalimatMutabakatCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneTalimatMutabakatDetayCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_AboneTalimatMutabakatDosyaIndirCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_FaturaBorcSorgulamaCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_FaturaTahsilatCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_FaturaTahsilatIptalCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_MutabakatDetayCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_MutabakatDetayDosyaIndirCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_MutabakatKontrolCevap;
import tr.gov.igdas.WebServices.BaseResponseMessageOf_TopluFaturaBorcSorgulamaCevap;
import tr.gov.igdas.WebServices.FaturaBorcCevapTesisat;
import tr.gov.igdas.WebServices.FaturaBorcCevapTesisatFatura;
import tr.gov.igdas.WebServices.FaturaBorcSorgulamaCevap;
import tr.gov.igdas.WebServices.FaturaTahsilatCevap;
import tr.gov.igdas.WebServices.FaturaTahsilatIptalCevap;
import tr.gov.igdas.WebServices.TopluFaturaBorcSorgulamaCevap;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class IgdasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(IgdasServices.class);
	public static int BRANCH_CODE = 444;
	public static String RESPONSE_CODE_APPROVE = "IGDSWSRV00001";
	public static String SUBSCRIBER_FEE = "B";
	public static String INVOICE = "F";
	public static short INVOICE_TYPE = 0;

	@GraymoundService("ICS_IGDAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String responseCode1 = "";
		String responseCode2 = "";
		String wsUrlFatura = "";
		String wsUserNameFatura = "";
		String wsPasswordFatura = "";
		String wsUrlBaglanti = "";
		String wsUserNameBaglanti = "";
		String wsPasswordBaglanti = "";
		Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
		for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
			if (SUBSCRIBER_FEE.equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER1))) {
				wsPasswordBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				wsUrlBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				wsUserNameBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
			} else {
				wsPasswordFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				wsUrlFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				wsUserNameFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
			}
		}

		String bankSymbol = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		int counter = 0;
		GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
		String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		BaseResponseMessageOf_FaturaBorcSorgulamaCevap faturaBorcSorgulamaMessage = null;
		BaseResponseMessageOf_AboneBaglantiBorcSorgulamaCevap aboneBaglantiBorcSorgulamaMessage = null;
		String tckn = iMap.getString(MapKeys.SUBSCRIBER_NO3);
		int tesisatNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
		int branchCode = BRANCH_CODE;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode1 = "";
		String errorCode2 = "";
		try {
			int flatNo = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
			if (INVOICE_TYPE != collectionType) {
				ServiceMessage s = new ServiceMessage();
				aboneBaglantiBorcSorgulamaMessage = IgdasClient.aboneBaglantiBorcSorgula(wsUrlBaglanti, wsUserNameBaglanti, wsPasswordBaglanti, bankCode, bankSymbol, branchCode, tesisatNo, flatNo, tckn, s);
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				if (aboneBaglantiBorcSorgulamaMessage != null) {
					String[] hataKodlari = aboneBaglantiBorcSorgulamaMessage.getHataKodlari();
					if (hataKodlari != null) {
						responseCode1 = hataKodlari[0];
					} else {
						responseCode1 = RESPONSE_CODE_APPROVE;
					}
					String islemKodu = aboneBaglantiBorcSorgulamaMessage.getIslemKodu();
					AboneBaglantiBorcSorgulamaCevap aboneBaglantiBorcSorgulamaCevap = aboneBaglantiBorcSorgulamaMessage.getSonuc();
					if (aboneBaglantiBorcSorgulamaCevap != null) {
						GMMap responceCodeMap = getResponseCodeMapping(responseCode1, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode1 = responceCodeMap.getString(MapKeys.ERROR_CODE);
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						if (errorCode1.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							AboneBaglantiBorcCevapTesisat[] baglantiTesisatList = aboneBaglantiBorcSorgulamaCevap.getTesisat();
							int baglantiTesisatListlength = baglantiTesisatList.length;
							for (int l = 0; l < baglantiTesisatListlength; l++) {
								AboneBaglantiBorcCevapTesisat baglantiTesisat = baglantiTesisatList[l];
								logger.error(responseCode1 + " returned by Corporate for ICS_IGDAS_INVOICE_DEBT_INQUIRY.");
								AboneBaglantiBorcCevapTesisatTaksit[] baglantiBorcList = baglantiTesisat.getBagBdlDetayi();
								int baglantiBorcListLength = baglantiBorcList.length;
								for (int j = 0; j < baglantiBorcListLength; j++) {
									AboneBaglantiBorcCevapTesisatTaksit baglantiBorc = baglantiBorcList[j];
									if (errorCode1.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
										if (!isCollectedInvoice(baglantiBorc.getTaksitMeblag().toString(), iMap.getString(MapKeys.SUBSCRIBER_NO1), iMap.getString(MapKeys.SUBSCRIBER_NO2), iMap.getString(MapKeys.SUBSCRIBER_NO3), "", corporateCode)) {
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, iMap.getString(MapKeys.SUBSCRIBER_NO3));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, baglantiBorc.getAdSoyad());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, baglantiBorc.getNo());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, baglantiBorc.getTaksitMeblag());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, baglantiBorc.getRecNum1());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, baglantiBorc.getRecNum2());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, SUBSCRIBER_FEE);
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, baglantiBorc.getNo());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, baglantiBorc.getAdSoyad());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(baglantiBorc.getVadeTar().toString(), "yyyyMMdd"));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, "");
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, "");
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, baglantiBorc.getTaksitMeblag());
											outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
											outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
											counter++;
										}
									}
								}
							}
						}
					}

				}

			} else {
				ServiceMessage s = new ServiceMessage();
				faturaBorcSorgulamaMessage = IgdasClient.borcSorgula(wsUrlFatura, wsUserNameFatura, wsPasswordFatura, bankCode, bankSymbol, flatNo, tckn, tesisatNo, branchCode, s);
				CommonHelper.insertWsCallLog(iMap, s.getParameter1(), s.getParameter2(), s.getParameter3());
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				if (faturaBorcSorgulamaMessage != null) {
					FaturaBorcSorgulamaCevap faturaBorcSorgulamaCevap = faturaBorcSorgulamaMessage.getSonuc();
					String[] hataKodlari = faturaBorcSorgulamaMessage.getHataKodlari();
					if (hataKodlari != null) {
						responseCode2 = hataKodlari[0];
					} else {
						responseCode2 = RESPONSE_CODE_APPROVE;
					}
					logger.error(responseCode2 + " returned by Corporate for ICS_IGDAS_INVOICE_DEBT_INQUIRY.");
					GMMap responceCodeMap = getResponseCodeMapping(responseCode2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode2 = responceCodeMap.getString(MapKeys.ERROR_CODE);

					if (errorCode2.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						String islemKodu = faturaBorcSorgulamaMessage.getIslemKodu();
						faturaBorcSorgulamaCevap.getTcKmNo();
						FaturaBorcCevapTesisat[] tesisatList = faturaBorcSorgulamaCevap.getTesisat();
						faturaBorcSorgulamaCevap.getToplamGenBorc();

						int tesisatListLength = tesisatList.length;
						for (int i = 0; i < tesisatListLength; i++) {
							FaturaBorcCevapTesisat tesisat = tesisatList[i];
							FaturaBorcCevapTesisatFatura[] invoiceList = tesisat.getFaturaDetay();
							int invoiceListLength = invoiceList.length;
							for (int j = 0; j < invoiceListLength; j++) {
								FaturaBorcCevapTesisatFatura invoice = invoiceList[j];
								if (!isCollectedInvoice(invoice.getFaturaMeblagi().toString(), iMap.getString(MapKeys.SUBSCRIBER_NO1), iMap.getString(MapKeys.SUBSCRIBER_NO2), iMap.getString(MapKeys.SUBSCRIBER_NO3), "", corporateCode)) {
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, iMap.getString(MapKeys.SUBSCRIBER_NO3));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoice.getAdSoyad());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getFaturaMeblagi());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, INVOICE);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, invoice.getDamgaHarIcMeb());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, invoice.getDamgaVerMeb());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTar().toString(), "yyyyMMdd"));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, invoice.getYil());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, "");
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, invoice.getFaturaMeblagi());
									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
								}
							}
						}

					}
				}
			}

			if (errorCode1.equals(GeneralConstants.ERROR_CODE_APPROVE) || errorCode2.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				responseCode = RESPONSE_CODE_APPROVE;
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else if (!StringUtil.isEmpty(responseCode1)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode1, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_IGDAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_DO_INVOICE_COLLECTION");
		String responseCode = "";
		String responseCode1 = "";
		String responseCode2 = "";
		String wsUrlFatura = "";
		String wsUserNameFatura = "";
		String wsPasswordFatura = "";
		String wsUrlBaglanti = "";
		String wsUserNameBaglanti = "";
		String wsPasswordBaglanti = "";
		String errorCode1 = "";
		String errorCode2 = "";
		String sourceCode = iMap.getString(MapKeys.SOURCE);
		String channelCode = CommonHelper.getChannelId();
		Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
		GMMap responceCodeMap = new GMMap();

		String thsTarih = "";
		for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
			if (SUBSCRIBER_FEE.equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER1))) {
				wsPasswordBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				wsUrlBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				wsUserNameBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
			} else {
				wsPasswordFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				wsUrlFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				wsUserNameFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
			}
		}
		if (iMap.containsKey(MapKeys.PAYMENT_DATE) && !StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
			thsTarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss"), "yyyyMMdd");
		} else {
			thsTarih = CommonHelper.getDateString(new Date(), "yyyyMMdd");
		}

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int subscriberNo1 = 0;
			int subscriberNo2 = 0;
			int installmentNo = iMap.getInt(MapKeys.INSTALLMENT_NO);
			String resKurum = "H";
			int bankCode = iMap.getInt(MapKeys.BANK_CODE);
			String bankSymbol = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			int branchCode = iMap.getInt(MapKeys.BRANCH_CODE); // CommonHelper.getUserBranch();
			String damgaVerDus = "H";
			Long invoiceNo = new Long(iMap.getString(MapKeys.INVOICE_NO));
			int termYear = iMap.getInt(MapKeys.TERM_YEAR);

			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			int invoiceDueDate = iMap.getInt(MapKeys.INVOICE_DUE_DATE);
			BigDecimal amount = new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT));
			Long paymentDate = new Long(thsTarih);
			BigDecimal damgaVerMeb = iMap.getBigDecimal(MapKeys.PARAMETER4);

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
				subscriberNo1 = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			}

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO2) && !StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2)) && !"00000000000".equals(iMap.getString(MapKeys.SUBSCRIBER_NO2))) {
				subscriberNo2 = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
			}

			if (INVOICE_TYPE == collectionType) {
				ServiceMessage s = new ServiceMessage();
				BaseResponseMessageOf_FaturaTahsilatCevap faturaTahsilatMessage = IgdasClient.faturaTahsilat(wsUrlFatura, wsUserNameFatura, wsPasswordFatura, bankCode, bankSymbol, branchCode, damgaVerDus, invoiceNo, termYear, resKurum, paymentChannel, amount, paymentDate, damgaVerMeb, s);
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				String[] hataKodlari = faturaTahsilatMessage.getHataKodlari();
				String islemKodu = faturaTahsilatMessage.getIslemKodu();
				if (hataKodlari != null) {
					responseCode1 = hataKodlari[0];
				} else {
					responseCode1 = RESPONSE_CODE_APPROVE;
				}

				logger.error(responseCode2 + " returned by Corporate for ICS_IGDAS_DO_INVOICE_COLLECTION.");
				responceCodeMap = getResponseCodeMapping(responseCode2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode1 = responceCodeMap.getString(MapKeys.ERROR_CODE);
				FaturaTahsilatCevap faturaTahsilatCevap = faturaTahsilatMessage.getSonuc();
			} else {
				int recNum1 = iMap.getInt(MapKeys.PARAMETER1);
				int recNum2 = iMap.getInt(MapKeys.PARAMETER2);
				ServiceMessage s = new ServiceMessage();
				BaseResponseMessageOf_AboneBaglantiTahsilatCevap aboneBaglantiTahsilatMessage = IgdasClient.aboneBaglantiTahsilat(wsUrlBaglanti, wsUserNameBaglanti, wsPasswordBaglanti, bankCode, branchCode, bankSymbol, subscriberNo1, subscriberNo2, invoiceDueDate, installmentNo, amount, paymentChannel, recNum1, recNum2, s);
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				String[] hataKodlari = aboneBaglantiTahsilatMessage.getHataKodlari();
				String islemKodu = aboneBaglantiTahsilatMessage.getIslemKodu();
				if (hataKodlari != null) {
					responseCode2 = hataKodlari[0];
				} else {
					responseCode2 = RESPONSE_CODE_APPROVE;
				}
				logger.error(responseCode2 + " returned by Corporate for ICS_IGDAS_DO_INVOICE_COLLECTION.");
				responceCodeMap = getResponseCodeMapping(responseCode2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode2 = responceCodeMap.getString(MapKeys.ERROR_CODE);
				AboneBaglantiTahsilatCevap aboneBaglantiBorcSorgulamaCevap = aboneBaglantiTahsilatMessage.getSonuc();
			}

			String dekontNo = iMap.getString(MapKeys.TRX_NO);
			// String dekontNo =
			// getKutahyaSuDekont(iMap.getString(MapKeys.TRX_NO));
			if (!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")) {

				logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_DO_INVOICE_COLLECTION.");
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

				if (errorCode1.equals(GeneralConstants.ERROR_CODE_APPROVE) || errorCode2.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					responseCode = RESPONSE_CODE_APPROVE;
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				} else {
					responceCodeMap = getResponseCodeMapping(responseCode1, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}

			} else {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_IGDAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String responseCode1 = "";
		String responseCode2 = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int subscriberNo1 = 0;
		int subscriberNo2 = 0;
		int installmentNo = iMap.getInt(MapKeys.INSTALLMENT_NO);
		Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
		String resKurum = "H";
		String thsTarih = "";
		String wsUrlBaglanti = "";
		String wsUserNameBaglanti = "";
		String wsPasswordBaglanti = "";
		String wsUrlFatura = "";
		String wsUserNameFatura = "";
		String wsPasswordFatura = "";
		int bankCode = iMap.getInt(MapKeys.BANK_CODE);
		String bankSymbol = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		int branchCode = iMap.getInt(MapKeys.PAYMENT_BRANCH);
		String damgaVerDus = "H";
		int invoiceNo = iMap.getInt(MapKeys.INVOICE_NO);
		int termYear = iMap.getInt(MapKeys.TERM_YEAR);
		int invoiceDueDate = iMap.getInt(MapKeys.INVOICE_DUE_DATE);
		BigDecimal amount = new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT));
		GMMap responceCodeMap = new GMMap();
		String errorCode1 = "";
		String errorCode2 = "";
		for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
			if (SUBSCRIBER_FEE.equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER1))) {
				wsPasswordBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				wsUrlBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				wsUserNameBaglanti = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
			} else {
				wsPasswordFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				wsUrlFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				wsUserNameFatura = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
			}
		}
		if (iMap.containsKey(MapKeys.PAYMENT_DATE) && !StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
			thsTarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss"), "yyyyMMdd");
		} else {
			thsTarih = CommonHelper.getDateString(new Date(), "yyyyMMdd");
		}
		Long paymentDate = new Long(thsTarih);
		BigDecimal damgaVerMeb = iMap.getBigDecimal(MapKeys.CANCEL_PARAMETER4);

		if (iMap.containsKey(MapKeys.CANCEL_SUBSCRIBER_NO1) && !StringUtil.isEmpty(iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1))) {
			subscriberNo1 = iMap.getInt(MapKeys.CANCEL_SUBSCRIBER_NO1);
		}

		if (iMap.containsKey(MapKeys.CANCEL_SUBSCRIBER_NO2) && !StringUtil.isEmpty(iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO2)) && !"00000000000".equals(iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO2))) {
			subscriberNo2 = iMap.getInt(MapKeys.CANCEL_SUBSCRIBER_NO2);
		}
		try {
			if (INVOICE_TYPE == collectionType) {
				ServiceMessage s = new ServiceMessage();
				BaseResponseMessageOf_FaturaTahsilatIptalCevap faturaTahsilatIptalMessage = IgdasClient.faturaTahsilatIptal(wsUrlFatura, wsUserNameFatura, wsPasswordFatura, bankCode, damgaVerDus, bankSymbol, damgaVerMeb, invoiceNo, termYear, resKurum, branchCode, amount, s);
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				String[] hataKodlari = faturaTahsilatIptalMessage.getHataKodlari();
				String islemKodu = faturaTahsilatIptalMessage.getIslemKodu();
				if (hataKodlari != null) {
					responseCode1 = hataKodlari[0];
				} else {
					responseCode1 = RESPONSE_CODE_APPROVE;
				}
				logger.error(responseCode1 + " returned by Corporate for ICS_IGDAS_DO_INVOICE_COLLECTION.");
				responceCodeMap = getResponseCodeMapping(responseCode1, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode1 = responceCodeMap.getString(MapKeys.ERROR_CODE);
				FaturaTahsilatIptalCevap faturaTahsilatIptalCevap = faturaTahsilatIptalMessage.getSonuc();
			} else {
				int recNum1 = iMap.getInt(MapKeys.CANCEL_PARAMETER1);
				int recNum2 = iMap.getInt(MapKeys.CANCEL_PARAMETER2);
				ServiceMessage s = new ServiceMessage();
				BaseResponseMessageOf_AboneBaglantiTahsilatIptalCevap aboneBaglantiTahsilatIptalMessage = IgdasClient.aboneBaglantiTahsilatIptal(wsUrlBaglanti, wsUserNameBaglanti, wsPasswordBaglanti, bankCode, bankSymbol, subscriberNo1, subscriberNo2, recNum1, recNum2, branchCode, amount, installmentNo, invoiceDueDate, s);
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				String[] hataKodlari = aboneBaglantiTahsilatIptalMessage.getHataKodlari();
				String islemKodu = aboneBaglantiTahsilatIptalMessage.getIslemKodu();
				if (hataKodlari != null) {
					responseCode1 = hataKodlari[0];
				} else {
					responseCode1 = RESPONSE_CODE_APPROVE;
				}
				logger.error(responseCode2 + " returned by Corporate for ICS_IGDAS_DO_INVOICE_COLLECTION.");
				responceCodeMap = getResponseCodeMapping(responseCode2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode2 = responceCodeMap.getString(MapKeys.ERROR_CODE);
				AboneBaglantiTahsilatIptalCevap aboneBaglantiTahsilatIptalCevap = aboneBaglantiTahsilatIptalMessage.getSonuc();
			}

			if (errorCode1.equals(GeneralConstants.ERROR_CODE_APPROVE) || errorCode2.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				responseCode = RESPONSE_CODE_APPROVE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				responceCodeMap = getResponseCodeMapping(responseCode1, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_IGDAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IGDAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String result = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			int bankCode = iMap.getInt(MapKeys.BANK_CODE);
			int subscriberNo1 = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			int subscriberNo2 = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
			String responseCode = "";
			String tckn = "";
			GMMap tcknMap = new GMMap();
			tcknMap.put("MUSTERI_NO", iMap.getString(MapKeys.CUSTOMER_NO));
			tcknMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_INFO", tcknMap));
			if (!StringUtil.isEmpty(tcknMap.getString("TC_KIMLIK_NO"))) {
				tckn = tcknMap.getString("TC_KIMLIK_NO");
			} else if (!StringUtil.isEmpty(tcknMap.getString("VERGI_NO"))) {
				tckn = "0" + tcknMap.getString("VERGI_NO");
			} else if (!StringUtil.isEmpty(tcknMap.getString("PASAPORT_NO"))) {
				tckn = tcknMap.getString("PASAPORT_NO");
			}

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
				ServiceMessage s = new ServiceMessage();
				BaseResponseMessageOf_AboneTalimatCevap aboneTalimatMessage = IgdasClient.aboneTalimat(wsUrl, wsUserName, wsPassword, bankCode, subscriberNo1, subscriberNo2, tckn, s);
				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				String[] hataKodlari = aboneTalimatMessage.getHataKodlari();
				String islemKodu = aboneTalimatMessage.getIslemKodu();
				AboneTalimatCevap aboneTalimatCevap = aboneTalimatMessage.getSonuc();
				if (hataKodlari != null) {
					responseCode = hataKodlari[0];
				} else {
					responseCode = RESPONSE_CODE_APPROVE;
				}
			}

			logger.error(responseCode + " returned by Corporate for STO_IGDAS_SEND_STANDING_ORDER_MESSAGE.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KUTAHYA_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_IGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KUTAHYA_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			int bankCode = iMap.getInt(MapKeys.BANK_CODE);
			String responseCode = "";
			boolean missingInformation = true;
			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
				int tesisatNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
				int flatNo = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
				String tckn = "";
				GMMap tcknMap = new GMMap();
				if (iMap.containsKey(MapKeys.CUSTOMER_NO)) {
					if (!iMap.getString(MapKeys.CUSTOMER_NO).isEmpty()) {
						missingInformation = false;
						tcknMap.put("MUSTERI_NO", iMap.getString(MapKeys.CUSTOMER_NO));
						tcknMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_INFO", tcknMap));
						if (!StringUtil.isEmpty(tcknMap.getString("TC_KIMLIK_NO"))) {
							tckn = tcknMap.getString("TC_KIMLIK_NO");
						} else if (!StringUtil.isEmpty(tcknMap.getString("VERGI_NO"))) {
							tckn = "0" + tcknMap.getString("VERGI_NO");
						} else if (!StringUtil.isEmpty(tcknMap.getString("PASAPORT_NO"))) {
							tckn = tcknMap.getString("PASAPORT_NO");
						}
						ServiceMessage s = new ServiceMessage();
						BaseResponseMessageOf_AboneTalimatCevap aboneTalimatIptalMessage = IgdasClient.aboneTalimatIptal(wsUrl, wsUserName, wsPassword, bankCode, flatNo, tckn, tesisatNo, s);
						iMap.put("REQUEST_XML", s.getRequest());
						outMap.put("RESPONSE_XML", s.getResponse());
						String[] hataKodlari = aboneTalimatIptalMessage.getHataKodlari();
						String islemKodu = aboneTalimatIptalMessage.getIslemKodu();
						AboneTalimatCevap sonuc = aboneTalimatIptalMessage.getSonuc();
						if (hataKodlari != null) {
							responseCode = hataKodlari[0];
						} else {
							responseCode = RESPONSE_CODE_APPROVE;
						}
					}
				}
			}
			if (missingInformation) {
				logger.error("STO_IGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE -> eksik bilgi var");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
				throw new Exception();
			}
			logger.error(responseCode + " returned by Corporate for STO_IGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_IGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_IGDAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int bankCode = iMap.getInt(MapKeys.BANK_CODE);
			String bankSymbol = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			int branchCode = BRANCH_CODE;
			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_TopluFaturaBorcSorgulamaCevap topluFaturaBorcSorgulamaMessage = IgdasClient.topluBorcSorgula(wsUrl, wsUserName, wsPassword, bankCode, bankSymbol, branchCode, s);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			String[] hataKodlari = topluFaturaBorcSorgulamaMessage.getHataKodlari();
			String islemKodu = topluFaturaBorcSorgulamaMessage.getIslemKodu();
			if (hataKodlari != null) {
				responseCode = hataKodlari[0];
			} else {
				responseCode = RESPONSE_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				TopluFaturaBorcSorgulamaCevap topluFaturaBorcSorgulamaCevap = topluFaturaBorcSorgulamaMessage.getSonuc();
				FaturaBorcSorgulamaCevap faturaBorcSorguList = topluFaturaBorcSorgulamaCevap.getFaturalar();
				if (faturaBorcSorguList != null) {
					FaturaBorcCevapTesisat[] borcTesisatList = faturaBorcSorguList.getTesisat();
					int borcTesisatListLength = borcTesisatList.length;
					outMap.put(MapKeys.TABLE_SIZE, borcTesisatListLength);
					for (int i = 0; i < borcTesisatListLength; i++) {
						FaturaBorcCevapTesisat borcluTesisat = borcTesisatList[i];
						int invoiceListLenght = borcluTesisat.getFaturaAdet();
						FaturaBorcCevapTesisatFatura[] invoiceList = borcluTesisat.getFaturaDetay();
						for (int j = 0; j < invoiceListLenght; j++) {
							FaturaBorcCevapTesisatFatura invoice = invoiceList[j];
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, borcluTesisat.getTsNo());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, borcluTesisat.getDrNo());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, invoice.getNo());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, invoice.getFaturaMeblagi());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, INVOICE);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, invoice.getDamgaHarIcMeb());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, invoice.getDamgaVerMeb());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, 1);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, 0);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTar().toString(), "yyyyMMdd"));
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, invoice.getAdSoyad());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, invoice.getYil());
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_BRANCH, BRANCH_CODE);
						}
					}
				}

			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_IGDAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String connectionFeeId = "12";
		String collectionTypeId = "0";
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal aboneBaglantiTahsilatAdedi = new BigDecimal(0);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			BigDecimal aboneBaglantiTahsilatIptalAdedi = new BigDecimal(0);
			BigDecimal aboneBaglantiTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal aboneBaglantiTahsilatToplami = new BigDecimal(0);
			BigDecimal faturaTahsilatAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal faturaTahsilatToplami = new BigDecimal(0);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			iMap.put("RECON_ACCORDING_TO_COLLECTION_TYPE", "YES");
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			aboneBaglantiTahsilatIptalAdedi = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			aboneBaglantiTahsilatIptalToplami = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			aboneBaglantiTahsilatAdedi = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_COUNT);
			aboneBaglantiTahsilatToplami = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_TOTAL);

			faturaTahsilatIptalAdedi = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			faturaTahsilatIptalToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			faturaTahsilatAdedi = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_COUNT);
			faturaTahsilatToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_TOTAL);

			// Fatura odeme tipi icin 0 kullanilacak
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, faturaTahsilatToplami);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, faturaTahsilatIptalToplami);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, faturaTahsilatAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, faturaTahsilatIptalAdedi);

			// Baglanti ucreti tipi icin 13 kullanilacak
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, aboneBaglantiTahsilatIptalAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, aboneBaglantiTahsilatIptalToplami);
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, aboneBaglantiTahsilatAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, aboneBaglantiTahsilatToplami);

			responseCode = RESPONSE_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			// Fatura odeme tipi icin 0 kullanilacak
			if (faturaTahsilatToplami != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, faturaTahsilatToplami);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
			}
			if (faturaTahsilatIptalToplami != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, faturaTahsilatIptalToplami);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
			}
			if (faturaTahsilatAdedi != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, faturaTahsilatAdedi);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
			}
			if (faturaTahsilatIptalAdedi != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, faturaTahsilatIptalAdedi);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
			}

			// Baglanti ucreti tipi icin 13 kullanilacak
			if (aboneBaglantiTahsilatIptalAdedi != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, aboneBaglantiTahsilatIptalAdedi);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, "0");
			}

			if (aboneBaglantiTahsilatIptalToplami != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, aboneBaglantiTahsilatIptalToplami);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, "0");
			}

			if (aboneBaglantiTahsilatAdedi != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, aboneBaglantiTahsilatAdedi);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, "0");
			}

			if (aboneBaglantiTahsilatToplami != null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, aboneBaglantiTahsilatToplami);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, "0");
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_COLLECTION_RECONCILIATION_CLOSED");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@SuppressWarnings("unused")
	@GraymoundService("ICS_IGDAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String connectionFeeId = "12";
		String collectionTypeId = "0";
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION has started...");
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal aboneBaglantiTahsilatAdedi = new BigDecimal(0);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(13)).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			BigDecimal aboneBaglantiTahsilatIptalAdedi = new BigDecimal(0);
			BigDecimal aboneBaglantiTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal aboneBaglantiTahsilatToplami = new BigDecimal(0);
			BigDecimal faturaTahsilatAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal faturaTahsilatToplami = new BigDecimal(0);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			iMap.put("RECON_ACCORDING_TO_COLLECTION_TYPE", "YES");
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION called ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS...");
			aboneBaglantiTahsilatIptalAdedi = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			aboneBaglantiTahsilatIptalToplami = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			aboneBaglantiTahsilatAdedi = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_COUNT);
			aboneBaglantiTahsilatToplami = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_TOTAL);

			faturaTahsilatIptalAdedi = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			faturaTahsilatIptalToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			faturaTahsilatAdedi = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_COUNT);
			faturaTahsilatToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_TOTAL);

			// Fatura odeme tipi icin 0 kullanilacak
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, faturaTahsilatToplami);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, faturaTahsilatIptalToplami);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, faturaTahsilatAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, faturaTahsilatIptalAdedi);

			// Baglanti ucreti tipi icin 12 kullanilacak
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, aboneBaglantiTahsilatIptalAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, aboneBaglantiTahsilatIptalToplami);
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, aboneBaglantiTahsilatAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, aboneBaglantiTahsilatToplami);
			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION before corporate call...");
			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_MutabakatKontrolCevap reconControl = IgdasClient.mutakabakatSorgu(wsUrl, wsUserName, wsPassword, aboneBaglantiTahsilatAdedi.add(aboneBaglantiTahsilatIptalAdedi), reconDate, aboneBaglantiTahsilatIptalAdedi, aboneBaglantiTahsilatIptalToplami, aboneBaglantiTahsilatToplami.add(aboneBaglantiTahsilatIptalToplami), faturaTahsilatAdedi.add(faturaTahsilatIptalAdedi),
					faturaTahsilatIptalAdedi, faturaTahsilatIptalToplami, faturaTahsilatToplami.add(faturaTahsilatIptalToplami), bankCode, s);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION called IgdasClient.mutakabakatSorgu...");
			logger.info("aboneBaglantiTahsilatAdedi".concat(aboneBaglantiTahsilatAdedi.toString()));
			logger.info("aboneBaglantiTahsilatIptalAdedi".concat(aboneBaglantiTahsilatIptalAdedi.toString()));
			logger.info("aboneBaglantiTahsilatIptalToplami".concat(aboneBaglantiTahsilatIptalToplami.toString()));
			logger.info("aboneBaglantiTahsilatToplami".concat(aboneBaglantiTahsilatToplami.toString()));
			logger.info("faturaTahsilatAdedi".concat(faturaTahsilatAdedi.toString()));
			logger.info("faturaTahsilatIptalAdedi".concat(faturaTahsilatIptalAdedi.toString()));
			logger.info("faturaTahsilatIptalToplami".concat(faturaTahsilatIptalToplami.toString()));
			logger.info("faturaTahsilatToplami".concat(faturaTahsilatToplami.toString()));

			if (reconControl.getHataKodlari().length == 0 || reconControl.getSonuc().getSubeDetaylari() == null) {
				// Mutabakat basarili ve kapatildi
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION kurum tarafinda basarili olarak kapatildi.");
				if (reconControl.getHataKodlari().length > 0) {
					for (int i = 0; i < reconControl.getHataKodlari().length; i++) {
						logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION hata kodlari -> [".concat(Integer.toString(i)).concat("]").concat(reconControl.getHataKodlari()[i].toString()));
					}
				}
				responseCode = RESPONSE_CODE_APPROVE;
				String islemKodu = reconControl.getIslemKodu();
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				// Fatura odeme tipi icin 0 kullanilacak
				if (faturaTahsilatToplami != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, faturaTahsilatToplami);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
				}
				if (faturaTahsilatIptalToplami != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, faturaTahsilatIptalToplami);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				}
				if (faturaTahsilatAdedi != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, faturaTahsilatAdedi);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
				}
				if (faturaTahsilatIptalAdedi != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, faturaTahsilatIptalAdedi);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
				}

				// Baglanti ucreti tipi icin 13 kullanilacak
				if (aboneBaglantiTahsilatIptalAdedi != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, aboneBaglantiTahsilatIptalAdedi);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, "0");
				}

				if (aboneBaglantiTahsilatIptalToplami != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, aboneBaglantiTahsilatIptalToplami);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, "0");
				}

				if (aboneBaglantiTahsilatAdedi != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, aboneBaglantiTahsilatAdedi);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, "0");
				}

				if (aboneBaglantiTahsilatToplami != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, aboneBaglantiTahsilatToplami);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, "0");
				}

			} else {
				// hata var detay mutabakat yap�lacak
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION kurum tarafinda basarisiz oldu.Detay mutabakat cagrilacak");
				String[] hataKodlari = reconControl.getHataKodlari();
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION hata kodlari -> ".concat(hataKodlari.toString()));
				if (hataKodlari != null) {
					responseCode = hataKodlari[0];
				} else {
					responseCode = RESPONSE_CODE_APPROVE;
				}
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION response code -> ".concat(responseCode));
				String islemKodu = reconControl.getIslemKodu();
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION islem kodu -> ".concat(islemKodu));

				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					if (reconControl == null) {
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, 0);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, 0);
					} else {
						BigDecimal ftt = new BigDecimal(0);
						BigDecimal fta = new BigDecimal(0);
						BigDecimal ftit = new BigDecimal(0);
						BigDecimal ftia = new BigDecimal(0);
						BigDecimal abta = new BigDecimal(0);
						BigDecimal abtt = new BigDecimal(0);
						BigDecimal abtia = new BigDecimal(0);
						BigDecimal abtit = new BigDecimal(0);

						for (int i = 0; i < reconControl.getSonuc().getSubeDetaylari().length; i++) {
							ftt = ftt.add(reconControl.getSonuc().getSubeDetaylari()[i].getFaturaTahsilatToplami());
							fta = fta.add(reconControl.getSonuc().getSubeDetaylari()[i].getFaturaTahsilatAdedi());
							ftit = ftit.add(reconControl.getSonuc().getSubeDetaylari()[i].getFaturaTahsilatIptalToplami());
							ftia = ftia.add(reconControl.getSonuc().getSubeDetaylari()[i].getFaturaTahsilatIptalAdedi());
							abta = abta.add(reconControl.getSonuc().getSubeDetaylari()[i].getAboneBaglantiTahsilatAdedi());
							abtt = abtt.add(reconControl.getSonuc().getSubeDetaylari()[i].getAboneBaglantiTahsilatToplami());
							abtia = abtia.add(reconControl.getSonuc().getSubeDetaylari()[i].getAboneBaglantiTahsilatIptalAdedi());
							abtit = abtit.add(reconControl.getSonuc().getSubeDetaylari()[i].getAboneBaglantiTahsilatIptalToplami());
						}
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, ftt);
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, fta);
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, ftit);
						outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, ftia);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT, abta);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL, abtt);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT, abtia);
						outMap.put("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL, abtit);
					}

					if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL))) == 0
							&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT))) == 0
							&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0
							&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL)) == 0
							&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_CONNECTION_FEE_COUNT).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_COUNT))) == 0
							&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_CONNECTION_FEE_TOTAL).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_CONNECTION_FEE_CANCEL_TOTAL))) == 0) {
						outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					} else {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				} else {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_COLLECTION_RECONCILIATION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	public static boolean addNewReconDetailData(Short collectionType, String corporateCode, String invoiceNo, String parameter1, String parameter2, String parameter3, String parameter4, String parameter5, String parameter6, String parameter7, String parameter8, String parameter9, String parameter10, BigDecimal paymentAmount, String subscriberNo1, String subscriberNo2, String subscriberNo3,
			String subscriberNo4, String transactionType, String reconLogOid, String reconDate, String reconTime) {
		try {
			// logger.info("...addNewReconDetailData...");
			Session session = DAOSession.getSession("BNSPRDal");
			ReconDetailData rdd = new ReconDetailData();
			rdd.setCollectionType(collectionType);
			rdd.setCorporateCode(corporateCode);
			rdd.setInvoiceNo(invoiceNo);
			rdd.setParameter1(parameter1);
			rdd.setParameter2(parameter2);
			rdd.setParameter3(parameter3);
			rdd.setParameter4(parameter4);
			rdd.setParameter5(parameter5);
			rdd.setParameter6(parameter6);
			rdd.setParameter7(parameter7);
			rdd.setParameter8(parameter8);
			rdd.setParameter9(parameter9);
			rdd.setParameter10(parameter10);
			rdd.setPaymentAmount(paymentAmount);
			rdd.setStatus(true);
			rdd.setSubscriberNo1(subscriberNo1);
			rdd.setSubscriberNo2(subscriberNo2);
			rdd.setSubscriberNo3(subscriberNo3);
			rdd.setSubscriberNo4(subscriberNo4);
			rdd.setTransactionType(transactionType);
			rdd.setReconLogOid(reconLogOid);
			rdd.setReconDate(reconDate);
			rdd.setReconTime(reconTime);
			session.saveOrUpdate(rdd);
			session.flush();
			// logger.info("...addNewReconDetailData...flush....");
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean loadReconDetailDataTable(byte[] dosyaByteArray, String corporateCode, String collectionTypeId, String reconLogOid, String reconDate, String reconTime) {
		boolean result = false;
		try {
			String connectionFeeId = "12";
			logger.info("...loadReconDeatilDataTable has just started...");
			int a = 0;
			String dosyaString = new String(dosyaByteArray);
			String kayitTipiHeader = dosyaString.substring(0, 2);
			int bankaKodu = Integer.parseInt((String) (dosyaString.subSequence(2, 6)));
			int islemTarihi = Integer.parseInt((String) (dosyaString.subSequence(6, 14)));
			String kayitTipiFooter = "";
			int base = 16;
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiHeader, Integer.toString(bankaKodu), Integer.toString(islemTarihi), "Mutabakat detay dosya yuklemesi basliyor", "", "", "", "", "", "", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
			Session session = DAOSession.getSession("BNSPRDal");
			do {
				String kayitTipiDetail = dosyaString.substring(base, base + 2);
				String islemTipi = dosyaString.substring(base + 2, base + 3);
				int subeKodu = Integer.parseInt((String) dosyaString.substring(base + 3, base + 7));
				String tesisatNumarasi = dosyaString.substring(base + 7, base + 14);
				String daireNumarasi = dosyaString.substring(base + 14, base + 18);
				int faturaYili = Integer.parseInt((String) dosyaString.substring(base + 18, base + 22));
				String faturaNumarasi = dosyaString.substring(base + 22, base + 30);
				BigDecimal tahsilatVeyaIptalTutari = new BigDecimal(dosyaString.substring(base + 30, base + 45));
				String resmiKurumMu = dosyaString.substring(base + 45, base + 46);
				String damgaVergisiDusulduMu = dosyaString.substring(base + 46, base + 47);
				kayitTipiFooter = dosyaString.substring(base + 50, base + 52);
				base = base + 50;
				ReconDetailData rdd = new ReconDetailData();
				rdd.setCollectionType(Short.parseShort(collectionTypeId));
				rdd.setCorporateCode(corporateCode);
				rdd.setInvoiceNo(faturaNumarasi);
				rdd.setParameter1(kayitTipiDetail);
				rdd.setParameter2(islemTipi);
				rdd.setParameter3(Integer.toString(subeKodu));
				rdd.setParameter4(tesisatNumarasi);
				rdd.setParameter5(daireNumarasi);
				rdd.setParameter6(Integer.toString(faturaYili));
				rdd.setParameter7(faturaNumarasi);
				rdd.setParameter8(tahsilatVeyaIptalTutari.toString());
				rdd.setParameter9(resmiKurumMu);
				rdd.setParameter10(damgaVergisiDusulduMu);
				rdd.setPaymentAmount(tahsilatVeyaIptalTutari);
				rdd.setStatus(true);
				rdd.setSubscriberNo1(tesisatNumarasi);
				rdd.setSubscriberNo2(daireNumarasi);
				rdd.setSubscriberNo3("");
				rdd.setSubscriberNo4("");
				rdd.setTransactionType(islemTipi);
				rdd.setReconLogOid(reconLogOid);
				rdd.setReconDate(reconDate);
				rdd.setReconTime(reconTime);
				session.saveOrUpdate(rdd);
				// addNewReconDetailData(Short.parseShort(collectionTypeId),
				// corporateCode, faturaNumarasi, kayitTipiDetail, islemTipi,
				// Integer.toString(subeKodu), tesisatNumarasi, daireNumarasi,
				// Integer.toString(faturaYili), faturaNumarasi,
				// tahsilatVeyaIptalTutari.toString(), resmiKurumMu,
				// damgaVergisiDusulduMu, tahsilatVeyaIptalTutari,
				// tesisatNumarasi,
				// daireNumarasi, "", "", islemTipi, reconLogOid, reconDate,
				// reconTime);

				a++;
			} while (kayitTipiFooter.equals("D1"));
			session.flush();
			logger.info("...loadReconDeatilDataTable has just parsed first part...");
			BigDecimal toplamTahsilatAdedi = new BigDecimal(dosyaString.substring(base + 2, base + 9));
			BigDecimal toplamTahsilatTutari = new BigDecimal(dosyaString.substring(base + 9, base + 24));
			BigDecimal toplamIptalAdedi = new BigDecimal(dosyaString.substring(base + 24, base + 31));
			BigDecimal toplamIptalTutari = new BigDecimal(dosyaString.substring(base + 31, base + 46));
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiFooter, Integer.toString(bankaKodu), Integer.toString(islemTarihi), "Mutabakat detay dosya yuklemesi bitti. toplam y�klenen kayit sayisi : ".concat(Integer.toString(a)), "Toplam Tahsilat Adedi : ".concat(toplamTahsilatAdedi.toString()), toplamTahsilatAdedi.toString(),
					"Toplam Tahsilat Tutari : ".concat(toplamTahsilatTutari.toString()), toplamTahsilatTutari.toString(), "Toplam �ptal Adedi : ".concat(toplamIptalAdedi.toString()), "Toplam �ptal Tutari : ".concat(toplamIptalTutari.toString()), new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);

			base = base + 48;
			if (dosyaString.length() > base + 2) {
				// baglanti bedelleri de geldi demek
				logger.info(dosyaString);
				kayitTipiHeader = dosyaString.substring(base, base + 2);
				bankaKodu = Integer.parseInt((String) (dosyaString.subSequence(base + 2, base + 6)));
				islemTarihi = Integer.parseInt((String) (dosyaString.subSequence(base + 6, base + 14)));
				kayitTipiFooter = "";
				base = base + 16;

				addNewReconDetailData(Short.parseShort(connectionFeeId), corporateCode, "", kayitTipiHeader, Integer.toString(bankaKodu), Integer.toString(islemTarihi), "Mutabakat detay baglanti bedeli dosya yuklemesi basliyor", "", "", "", "", "", "", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
				do {
					String kayitTipiDetail = dosyaString.substring(base, base + 2);
					String islemTipi = dosyaString.substring(base + 2, base + 3);
					int subeKodu = Integer.parseInt((String) dosyaString.substring(base + 3, base + 7));
					String tesisatNumarasi = dosyaString.substring(base + 7, base + 14);
					String daireNumarasi = dosyaString.substring(base + 14, base + 18);
					String taksitNo = dosyaString.substring(base + 18, base + 26);
					int tahsitVadeTarihi = Integer.parseInt((String) dosyaString.substring(base + 26, base + 34));
					String recordNumarasi1 = dosyaString.substring(base + 34, base + 44);
					String recordNumarasi2 = dosyaString.substring(base + 44, base + 54);
					BigDecimal tahsilatVeyaIptalTutari = new BigDecimal(dosyaString.substring(base + 54, base + 69));
					kayitTipiFooter = dosyaString.substring(base + 72, base + 74);
					base = base + 72;
					addNewReconDetailData(Short.parseShort(connectionFeeId), corporateCode, taksitNo, recordNumarasi1, kayitTipiDetail, islemTipi, recordNumarasi2, tesisatNumarasi, "", taksitNo, tahsilatVeyaIptalTutari.toString(), "", "", tahsilatVeyaIptalTutari, tesisatNumarasi, "", "", "", islemTipi, reconLogOid, reconDate, reconTime);
					a++;
				} while (kayitTipiFooter.equals("D2"));
				BigDecimal aboneBaglantiBedeliTahsilatAdedi = new BigDecimal(dosyaString.substring(base + 2, base + 9));
				BigDecimal aboneBaglantiBedeliTahsilatTutari = new BigDecimal(dosyaString.substring(base + 9, base + 24));
				BigDecimal aboneBaglantiBedeliIptalAdedi = new BigDecimal(dosyaString.substring(base + 24, base + 31));
				BigDecimal aboneBaglantiBedeliIptalTutari = new BigDecimal(dosyaString.substring(base + 31, base + 46));
				logger.info("...loadReconDeatilDataTable has just parsed second part...");
				addNewReconDetailData(Short.parseShort(connectionFeeId), corporateCode, "", kayitTipiFooter, Integer.toString(bankaKodu), Integer.toString(islemTarihi), "Mutabakat detay baglanti bedeli dosya yuklemesi bitti. toplam y�klenen kayit sayisi : ".concat(Integer.toString(a)), "Toplam Tahsilat Adedi : ".concat(aboneBaglantiBedeliTahsilatAdedi.toString()),
						aboneBaglantiBedeliTahsilatAdedi.toString(), "Toplam Tahsilat Tutari : ".concat(aboneBaglantiBedeliTahsilatTutari.toString()), aboneBaglantiBedeliTahsilatTutari.toString(), "Toplam �ptal Adedi : ".concat(aboneBaglantiBedeliIptalAdedi.toString()), "Toplam �ptal Tutari : ".concat(aboneBaglantiBedeliIptalTutari.toString()), new BigDecimal(0), "", "", "", "", "", reconLogOid,
						reconDate, reconTime);
				logger.info("...loadReconDeatilDataTable added new recon detail data...");
			}
			result = true;
		} catch (Exception e) {
			logger.info("...loadReconDeatilDataTable �al���rken hata meydana geldi...".concat(e.getMessage()));
			return result;
		}

		return result;
	}

	public static boolean loadReconDetailDataTableForStandingOrder(byte[] dosyaByteArray, String corporateCode, String collectionTypeId, String reconLogOid, String reconDate, String reconTime) {
		boolean result = false;
		try {
			logger.info("...loadReconDeatilDataTable has just started...");
			int a = 0;
			String dosyaString = new String(dosyaByteArray);
			String kayitTipiHeader = dosyaString.substring(0, 1);
			int bankaKodu = Integer.parseInt((String) (dosyaString.subSequence(1, 5)));
			int islemTarihi = Integer.parseInt((String) (dosyaString.subSequence(5, 13)));
			String kayitTipiFooter = "";
			int base = 15;
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiHeader, Integer.toString(bankaKodu), Integer.toString(islemTarihi), "Talimat Mutabakat detay dosya yuklemesi basliyor", "", "", "", "", "", "Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
			do {
				String kayitTipiDetail = dosyaString.substring(base, base + 1);
				String islemTipi = dosyaString.substring(base + 1, base + 2);
				String tesisatNumarasi = dosyaString.substring(base + 2, base + 9);
				String daireNumarasi = dosyaString.substring(base + 9, base + 13);
				kayitTipiFooter = dosyaString.substring(base + 15, base + 16);
				base = base + 15;
				addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiDetail, islemTipi, "", tesisatNumarasi, daireNumarasi, "", "", "", "", "Talimat", new BigDecimal(0), tesisatNumarasi, daireNumarasi, "", "", islemTipi, reconLogOid, reconDate, reconTime);
				a++;
			} while (kayitTipiFooter.equals("D"));
			logger.info("...loadReconDeatilDataTable has just parsed first part...");
			BigDecimal talimatAdedi = new BigDecimal(dosyaString.substring(base + 1, base + 8));
			BigDecimal talimatIptalAdedi = new BigDecimal(dosyaString.substring(base + 8, base + 15));
			BigDecimal toplam = talimatAdedi.add(talimatIptalAdedi);
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiFooter, Integer.toString(bankaKodu), Integer.toString(islemTarihi), "Talimat Mutabakat detay dosya yuklemesi bitti. toplam y�klenen kayit sayisi : ".concat(toplam.toString()), "Toplam Talimat Adedi : ", talimatAdedi.toString(), "Toplam Talimat Iptal Adedi : ", talimatIptalAdedi.toString(), "",
					"Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);

			result = true;
		} catch (Exception e) {
			logger.info("...loadReconDetailDataTableForStandingOrder �al���rken hata meydana geldi...".concat(e.getMessage()));
			return result;
		}
		return result;
	}

	@SuppressWarnings("unused")
	@GraymoundService("ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) throws Exception {
		Session session = DAOSession.getSession("BNSPRDal");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL");
		logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL has called and started...");
		GMMap outMap = new GMMap();
		String TABLE_NAME = "RECON_DETAIL_DATA";
		String connectionFeeId = "12";
		String collectionTypeId = "0";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

		try {
			int aboneBaglantiTahsilatAdedi = 0;
			int aboneBaglantiTahsilatIptalAdedi = 0;
			BigDecimal aboneBaglantiTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal aboneBaglantiTahsilatToplami = new BigDecimal(0);
			int faturaTahsilatAdedi = 0;
			int faturaTahsilatIptalAdedi = 0;
			BigDecimal faturaTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal faturaTahsilatToplami = new BigDecimal(0);

			responseCode = RESPONSE_CODE_APPROVE;

			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(13)).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL called IgdasClient.mutabakatDetay (before)...");
			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_MutabakatDetayCevap reconControl = IgdasClient.mutabakatDetay(wsUrl, wsUserName, wsPassword, bankCode, reconDate, s);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());

			// int counter = 0;
			// while(reconControl == null && counter++ < 20){
			// Thread.sleep(5000);
			// }

			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL called IgdasClient.mutabakatDetay (after)...");
			String[] hataKodlari = reconControl.getHataKodlari();
			logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL reconControl.getHataKodlari() basarili olarak alindi");

			if (hataKodlari == null) {
				// mutabakat dosyasi basarili olarak olusturuldu
				// banka kayitlarini al
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL corporate created detail file successfully...");
				iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
				iMap.put("RECON_ACCORDING_TO_COLLECTION_TYPE", "YES");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

				aboneBaglantiTahsilatAdedi = reconBankMap.getInt(connectionFeeId, 0, MapKeys.RECON_COLLECTION_COUNT);
				aboneBaglantiTahsilatIptalAdedi = reconBankMap.getInt(connectionFeeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
				aboneBaglantiTahsilatIptalToplami = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
				aboneBaglantiTahsilatToplami = reconBankMap.getBigDecimal(connectionFeeId, 0, MapKeys.RECON_COLLECTION_TOTAL);
				faturaTahsilatAdedi = reconBankMap.getInt(collectionTypeId, 0, MapKeys.RECON_COLLECTION_COUNT);
				faturaTahsilatIptalAdedi = reconBankMap.getInt(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
				faturaTahsilatIptalToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
				faturaTahsilatToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_TOTAL);

				responseCode = RESPONSE_CODE_APPROVE;
				String islemKodu = reconControl.getIslemKodu();
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				// mutabakat dosyas�n� al ve detay mutabakata basla
				String fileName = reconControl.getSonuc().getIndirilecekDosyaIsmi();
				ServiceMessage s1 = new ServiceMessage();
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL IgdasClient.mutabakatDetayDosyaIndir cagrilmadan once...");
				BaseResponseMessageOf_MutabakatDetayDosyaIndirCevap reconResponseDetail = IgdasClient.mutabakatDetayDosyaIndir(wsUrl, wsUserName, wsPassword, bankCode, fileName, s1);
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL IgdasClient.mutabakatDetayDosyaIndir cagirildiktan sonra...");
				iMap.put("REQUEST_XML", s1.getRequest());
				outMap.put("RESPONSE_XML", s1.getResponse());
				logger.info(s1.getResponse());

				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL byte[] dosya = reconResponseDetail.getSonuc().getDosya() byte array alinmadan once...");

				int counter = 0;
				while (counter++ < 20 && reconResponseDetail.getHataKodlari().length > 0) {
					// dosya haz�r de�il hatas� ald�k biraz bekleyelim
					logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL IgdasClient.mutabakatDetayDosyaIndir cagirildiktan sonra dosya olusmadigi icin 3 saniye ye bekliyorum...");
					Thread.sleep(3000);
					reconResponseDetail = IgdasClient.mutabakatDetayDosyaIndir(wsUrl, wsUserName, wsPassword, bankCode, fileName, s1);
				}

				if (reconResponseDetail.getHataKodlari().length > 0) {
					// 1 dakika beklenmesine ragmen dosya olusmadi
					// detay mutabakat sirasinda hata olustu
					logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL IgdasClient.mutabakatDetayDosyaIndir cagirildiktan sonra dosya olusmadigi 1 dakika icinde 20 defa tekrar denendi fakat dosya gelmeyince hata firlatildi...");
					responseCode = hataKodlari[0];
					islemKodu = reconControl.getIslemKodu();
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
					return outMap;
				}

				byte[] dosya = reconResponseDetail.getSonuc().getDosya();
				logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL byte[] dosya = reconResponseDetail.getSonuc().getDosya() basarili olarak alindi...");
				// String reconstitutedString = new String(dosya);
				// System.out.println(reconstitutedString);
				logger.info("loadReconDetailDataTable cagirilmadan once...");
				if (loadReconDetailDataTable(dosya, corporateCode, collectionTypeId, reconLogOid, iMap.getString(MapKeys.RECON_DATE), Integer.toString(reconDate.get(Calendar.HOUR)).concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(Integer.toString(reconDate.get(Calendar.SECOND))))) {
					logger.info("...loadReconDeatilDataTable returned true");
					// mutabakatlar tabloya yuklendi
					// simdi bizdeki kayitlar alinarak kurumdan gelen
					// recordset icerisinde aranacak
					// once kurum verilerini
					// recon_detail_data dan al
					logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");
					List<Object> parameters = new ArrayList<Object>();
					String strSQL = "";
					// strSQL =
					// "select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > "
					// +
					// "iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2 "
					// +
					// "from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
					// +
					// "sayacTahsilat,subscriber_no1,subscriber_no2 from ics.recon_detail_data where collection_type='0' and transaction_type "
					// + "is not null and status = 1 and corporate_code = '"
					// + corporateCode
					// + "' and "
					// + "recon_log_oid = '"
					// + reconLogOid
					// +
					// "' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
					// +
					// "subscriber_no1,subscriber_no2 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
					// +
					// "sayacIptal,subscriber_no1,subscriber_no2 from ics.recon_detail_data "
					// +
					// "where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '"
					// + corporateCode
					// + "' "
					// + "and recon_log_oid = '"
					// + reconLogOid
					// + "' and transaction_type = 'I' "
					// +
					// "group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2 "
					// + "order by invoice_no, transaction_type desc) iptal "
					// + "where tahsilat.invoice_no = iptal.invoice_no union "
					// +
					// "select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
					// + "subscriber_no2 from ics.recon_detail_data "
					// +
					// "where collection_type='0' and transaction_type = 'T' and status = 1 and corporate_code = '"
					// + corporateCode
					// + "' and "
					// + "recon_log_oid = '" + reconLogOid +
					// "' and invoice_no not in " +
					// "(select invoice_no from ics.recon_detail_data " +
					// "where collection_type='0' and transaction_type = 'I' and status = 1 and corporate_code = '"
					// + corporateCode + "' and recon_log_oid = '" + reconLogOid
					// + "') ";// +
					// // "order by payment_status desc; ";
					strSQL = String.format(QueryRepository.IgdasServicesRepository.RECON_DETAIL_STRING, corporateCode, reconLogOid, corporateCode, reconLogOid, corporateCode, reconLogOid, corporateCode, reconLogOid);
					logger.info(strSQL);

					GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);

					// CommonHelper.queryData(getCorporateDetailListQueryBuilder.toString(),
					// TABLE_NAME, parameters);
					boolean found = true;

					ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
					String subscriberNo2 = "";
					int subscriber2length = 0;
					for (int i = 0; i < faturaTahsilatAdedi; i++) {
						for (int j = 0; j < al.size(); j++) {
							subscriberNo2 = reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO2);
							subscriber2length = subscriberNo2.length();
							if (subscriber2length < 4) {
								for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
									subscriberNo2 = "0".concat(subscriberNo2);
								}
							}
							if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO2))
									&& reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO).equals(returnMap.getString(TABLE_NAME, j, MapKeys.INVOICE_NO)) & reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
								found = true;// bizdeki tahsilat kaydi kurumda
												// da bulundu
								break;
							} else {
								found = false;// bizdeki tahsilat kaydi kurumda
												// bulunamadi
							}
						}
						if (!found) {
							// bizdeki tahsilat kurumda bulunamadi ise
							// kuruma tahsilat mesaji gondericem
							logger.info("bizdeki tahsilat kurumda bulunamadi, kuruma tahsilat mesaji gondericem...");
							GMMap rcInput = new GMMap();
							rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap request = new GMMap();
							request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1));
							request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO2));
							request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT));
							request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_BRANCH));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("0_BANK", i, "SUBSCRIBER_NO2"));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("0_BANK", i, MapKeys.TERM_YEAR));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconDate);
							onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_SOURCE));
							onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("0_BANK", i, MapKeys.BRANCH_CODE));
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								logger.info("tahsilat mesaji basarili olarak gonderildi...");
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi");
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL tahsilat mesaji kuruma basarili olarak gonderildi...");
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 1: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 2: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO2)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL INVOICE NO : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL PAYMENT AMOUNT : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT)));

							} catch (Exception e) {
								// TODO Tahsilatta hata al�nca
								// yakal�yoruz
								// yola
								// devam ediyoruz
								logger.info("tahsilat mesaji hata aldi..".concat(e.getMessage()));
								logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
								logger.error(System.currentTimeMillis(), e);
								e.printStackTrace();
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
							}

							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
							}
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));

							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString("0_BANK", i, MapKeys.INSTALLMENT_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_DUE_DATE));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString("0_BANK", i, MapKeys.PARAMETER1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString("0_BANK", i, MapKeys.PARAMETER2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString("0_BANK", i, MapKeys.PARAMETER3));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString("0_BANK", i, MapKeys.PARAMETER4));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}

					}
					found = false;
					for (int i = 0; i < faturaTahsilatIptalAdedi; i++) {
						for (int j = 0; j < al.size(); j++) {
							subscriberNo2 = reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2);
							subscriber2length = subscriberNo2.length();
							if (subscriber2length < 4) {
								for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
									subscriberNo2 = "0".concat(subscriberNo2);
								}
							}
							if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO2))
									&& reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.INVOICE_NO).equals(returnMap.getString(TABLE_NAME, j, MapKeys.INVOICE_NO)) & reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
								found = true;// bizdeki tahsilat iptal kaydi
												// kurumda tahsilat kaydi olarak
												// var
								break;
							} else {
								found = false;// bizdeki tahsilat iptal kaydi
												// kurumda da var o zaman sorun
												// yok
							}
						}
						if (found) {
							// bizdeki tahsilat iptal kaydi kurumun
							// tahsilatlari arasinda
							// o zaman tahsilat iptal gonderelim
							logger.info("bizdeki tahsilat iptal kaydi kurumun tahsilatlari arasinda...tahsilat iptal mesaji gonderilecek...");
							GMMap rcInput = new GMMap();
							rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap request = new GMMap();
							request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
							request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
							request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.INVOICE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.TERM_YEAR));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconDate);
							onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.BRANCH_CODE));
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL tahsilat iptal servisi cagirilmadan once");
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL tahsilat iptal servisi cagirildiktan sonra...");
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi");
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL tahsilat iptal mesaji kuruma basarili olarak gonderildi...");
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 1: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 2: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO2)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL INVOICE NO : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL PAYMENT AMOUNT : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT)));
							} catch (Exception e) {
								// TODO Tahsilatta hata al�nca
								// yakal�yoruz
								// yola
								// devam ediyoruz
								logger.info("tahsilat iptal servisi hata aldi".concat(e.getMessage()));
								logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
								logger.error(System.currentTimeMillis(), e);
								e.printStackTrace();
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
							}

							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
							}
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.INSTALLMENT_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.INVOICE_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PARAMETER1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PARAMETER2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PARAMETER3));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString("0_BANK_CANCEL", i, MapKeys.PARAMETER4));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}

					}

					// baglanti ucreti mutabakati

					strSQL = "";
					// strSQL =
					// "select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > "
					// +
					// "iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2,tahsilat.parameter1,tahsilat.parameter4 "
					// +
					// "from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
					// +
					// "sayacTahsilat,subscriber_no1,subscriber_no2,parameter1,parameter4 from ics.recon_detail_data where collection_type='"
					// + connectionFeeId
					// + "' and transaction_type "
					// + "is not null and status = 1 and corporate_code = '"
					// + corporateCode
					// + "' and "
					// + "recon_log_oid = '"
					// + reconLogOid
					// +
					// "' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
					// +
					// "subscriber_no1,subscriber_no2,parameter1,parameter4 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
					// +
					// "sayacIptal,subscriber_no1,subscriber_no2,parameter1,parameter4 from ics.recon_detail_data "
					// + "where collection_type='"
					// + connectionFeeId
					// +
					// "' and transaction_type is not null and status = 1 and corporate_code = '"
					// + corporateCode
					// + "' "
					// + "and recon_log_oid = '"
					// + reconLogOid
					// + "' and transaction_type = 'I' "
					// +
					// "group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2,parameter1,parameter4 "
					// + "order by invoice_no, transaction_type desc) iptal "
					// + "where tahsilat.invoice_no = iptal.invoice_no union "
					// +
					// "select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
					// +
					// "subscriber_no2,parameter1,parameter4 from ics.recon_detail_data "
					// + "where collection_type='"
					// + connectionFeeId
					// +
					// "' and transaction_type = 'T' and status = 1 and corporate_code = '"
					// + corporateCode
					// + "' and "
					// + "recon_log_oid = '" + reconLogOid +
					// "' and invoice_no not in " +
					// "(select invoice_no from ics.recon_detail_data " +
					// "where collection_type='" + connectionFeeId +
					// "' and transaction_type = 'I' and status = 1 and corporate_code = '"
					// + corporateCode + "' and recon_log_oid = '" + reconLogOid
					// + "') ";// +
					// // "order by payment_status desc; ";
					strSQL = String.format(QueryRepository.IgdasServicesRepository.RECON_CONN_FEE_SQL, connectionFeeId, corporateCode, reconLogOid, connectionFeeId, corporateCode, reconLogOid, connectionFeeId, corporateCode, reconLogOid, connectionFeeId, corporateCode, reconLogOid);
					returnMap = DALUtil.getResults(strSQL, TABLE_NAME);

					ArrayList<?> rm = (ArrayList<?>) returnMap.get(TABLE_NAME);

					// CommonHelper.queryData(getCorporateDetailListQueryBuilder.toString(),
					// TABLE_NAME, parameters);
					found = false;
					if (aboneBaglantiTahsilatAdedi > 0) {
						for (int i = 0; i < aboneBaglantiTahsilatAdedi; i++) {
							for (int j = 0; j < rm.size(); j++) {
								if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1))
										&& reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
									found = true;// bizdeki tahsilat kaydi
													// kurumda
													// da bulundu
									break;
								} else {
									found = false;// bizdeki tahsilat kaydi
													// kurumda
													// bulunamadi
								}
							}
							if (!found) {
								// bizdeki tahsilat kurumda bulunamadi ise
								// kuruma tahsilat mesaji gondericem
								logger.info("...bizdeki tahsilat kurumda bulunamadi ise kuruma tahsilat mesaji gondericem...");
								GMMap rcInput = new GMMap();
								rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

								String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
								cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
								bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
								GMMap onlineCorporateServiceCallInputMap = new GMMap();
								GMMap request = new GMMap();
								request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString(connectionFeeId + "_BANK", i, "SUBSCRIBER_NO1"));
								request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString(connectionFeeId + "_BANK", i, "SUBSCRIBER_NO2"));
								request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK", i, "PAYMENT_AMOUNT"));
								request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
								GMMap onlineCorporateServiceCallOutputMap = new GMMap();
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.SUBSCRIBER_NO1));
								onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PAYMENT_BRANCH));
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString(connectionFeeId + "_BANK", i, "SUBSCRIBER_NO2"));
								onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.INVOICE_NO));
								onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.TERM_YEAR));
								onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.BRANCH_CODE));
								onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PAYMENT_AMOUNT));
								onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PAYMENT_AMOUNT));
								onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
								onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconDate);
								onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, connectionFeeId);
								onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
								onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
								onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
								onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
								onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PARAMETER1));
								onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PARAMETER2));
								onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
								onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PAYMENT_SOURCE));
								onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
								try {
									logger.error("tahsilat mesaji gondermeden once");
									onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
									logger.error("tahsilat mesaji gondermeden sonra");
								} catch (Exception e) {
									// TODO Tahsilatta hata al�nca
									// yakal�yoruz
									// yola
									// devam ediyoruz
									logger.error("tahsilat mesajinda hata meydana geldi...".concat(e.getMessage()));
									logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
									logger.error(System.currentTimeMillis(), e);
									e.printStackTrace();
									onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
									onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
								}

								GMMap reconProcessDataLogInsertInputMap = new GMMap();
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
								if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
								}
								if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Abone Ba�lant� Bedeli Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));
									logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL baglanti ucreti tahsilat kuruma basarili olarak gonderildi...");
									logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 1: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1)));
									logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 2: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO2)));
									logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL INVOICE NO : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO)));
									logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL PAYMENT AMOUNT : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT)));
								}
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.SUBSCRIBER_NO1));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.INSTALLMENT_NO));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PAYMENT_AMOUNT));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.INVOICE_DUE_DATE));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.INVOICE_NO));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PARAMETER1));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PARAMETER2));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PARAMETER3));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString(connectionFeeId + "_BANK", i, MapKeys.PARAMETER4));
								CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
							}

						}
					}
					found = false;
					for (int i = 0; i < aboneBaglantiTahsilatIptalAdedi; i++) {
						for (int j = 0; j < rm.size(); j++) {
							if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1))
									&& reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
								found = true;// bizdeki tahsilat iptal kaydi
												// kurumda tahsilat kaydi olarak
												// var
								break;
							} else {
								found = false;// bizdeki tahsilat iptal kaydi
												// kurumda da var o zaman sorun
												// yok
							}
						}
						if (found) {
							// bizdeki tahsilat iptal kaydi kurumun
							// tahsilatlari arasinda
							// o zaman tahsilat iptal gonderelim
							GMMap rcInput = new GMMap();
							rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap request = new GMMap();
							request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
							request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
							request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_SUBSCRIBER_NO1, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH));
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_SUBSCRIBER_NO2, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.INVOICE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.TERM_YEAR));
							onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.BRANCH_CODE));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconDate);
							onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, connectionFeeId);
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER1, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PARAMETER1));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_DUE_DATE, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE));
							onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER2, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PARAMETER2));
							onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.INSTALLMENT_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							} catch (Exception e) {
								// TODO Tahsilatta hata al�nca
								// yakal�yoruz
								// yola
								// devam ediyoruz
								logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
								logger.error(System.currentTimeMillis(), e);
								e.printStackTrace();
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
							}

							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
							}
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Abone Ba�lant� Bedeli Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL baglanti ucreti tahsilat iptal kuruma basarili olarak gonderildi...");
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 1: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO1)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL SUBSCRIBER NO 2: ".concat(reconBankMap.getString("0_BANK", i, MapKeys.SUBSCRIBER_NO2)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL INVOICE NO : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.INVOICE_NO)));
								logger.info("...ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL PAYMENT AMOUNT : ".concat(reconBankMap.getString("0_BANK", i, MapKeys.PAYMENT_AMOUNT)));
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.INSTALLMENT_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.INVOICE_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PARAMETER1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PARAMETER2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PARAMETER3));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString(connectionFeeId + "_BANK_CANCEL", i, MapKeys.PARAMETER4));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}

					}
				} else {
					errorCode = "9999";
					outMap.put(MapKeys.ERROR_CODE, "9999");
					outMap.put(MapKeys.ERROR_DESC, "IGDAS mutabakat detayi tabloya yuklenirken hata meydana geldi.Detay mutabakat yapilamadi.");
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				}
			} else {
				// detay mutabakat sirasinda hata olustu
				responseCode = hataKodlari[0];
				String islemKodu = reconControl.getIslemKodu();
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("STO_IGDAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IGDAS_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = "";
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_AboneTalimatMutabakatCevap aboneTalimatMutabakatResponseMessage = IgdasClient.aboneTalimatMutabakat(wsUrl, wsUserName, wsPassword, bankCode, reconDate, s);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			String[] hataKodlari = aboneTalimatMutabakatResponseMessage.getHataKodlari();

			if (hataKodlari == null) {
				responseCode = RESPONSE_CODE_APPROVE;

				AboneTalimatMutabakatCevap aboneTalimatMutabakatCevap = aboneTalimatMutabakatResponseMessage.getSonuc();

				BigDecimal[] cancelArray = aboneTalimatMutabakatCevap.getIptaller();
				int corpCancelCount = aboneTalimatMutabakatCevap.getToplamIptal();
				BigDecimal[] orderArray = aboneTalimatMutabakatCevap.getYeniKayitlar();
				int corpOrderCount = aboneTalimatMutabakatCevap.getToplamYeniKayit();

				logger.info("corpCancelCount: " + corpCancelCount + " corpOrderCount: " + corpOrderCount);

				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

				GMMap sorMap = getBankStandingOrdersForIgdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
				GMMap sorcMap = getBankStandingOrderCancelsForIgdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
				int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
				int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
				outMap.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

			} else {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				responseCode = hataKodlari[0];

			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_BUSKI_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String collectionTypeId = "0";
		String TABLE_NAME = "RECON_DETAIL_DATA";
		String responseCode = "";
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

		try {
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			logger.info("...STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL called IgdasClient.aboneTalimatMutabakatDetay (before)...");
			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_AboneTalimatMutabakatDetayCevap aboneTalimatMutabakatDetayCevap = IgdasClient.aboneTalimatMutabakatDetay(wsUrl, wsUserName, wsPassword, bankCode, reconDate, s);
			String[] hataKodlari = aboneTalimatMutabakatDetayCevap.getHataKodlari();

			if (hataKodlari == null) {

				String fileName = aboneTalimatMutabakatDetayCevap.getSonuc().getIndirilecekDosyaIsmi();
				BaseResponseMessageOf_AboneTalimatMutabakatDosyaIndirCevap aboneTalimatMutabakatDosyaIndirCevap = IgdasClient.aboneTalimatMutabakatDosyaIndir(wsUrl, wsUserName, wsPassword, bankCode, fileName, s);

				iMap.put("REQUEST_XML", s.getRequest());
				outMap.put("RESPONSE_XML", s.getResponse());
				logger.info("...STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detail reconciliation file downloaded successfully...");
				byte[] dosya = aboneTalimatMutabakatDosyaIndirCevap.getSonuc().getDosya();

				if (loadReconDetailDataTableForStandingOrder(dosya, corporateCode, collectionTypeId, reconLogOid, iMap.getString(MapKeys.RECON_DATE), Integer.toString(reconDate.get(Calendar.HOUR)).concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(Integer.toString(reconDate.get(Calendar.SECOND))))) {
					//
					// // mutabakatlar tabloya yuklendi
					// // simdi bizdeki kayitlar alinarak kurumdan gelen
					// // recordset icerisinde aranacak
					// // once kurum verilerini
					// // recon_detail_data dan al
					logger.info("...STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");

					boolean found = true;

					GMMap bsorMap = getBankStandingOrdersDetailForIgdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap bsorcMap = getBankStandingOrderCancelsDetailForIgdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap csorMap = getCorporateStandingOrdersDetailForIgdas(iMap.getString(MapKeys.RECON_DATE), corporateCode, reconLogOid);
					GMMap csorcMap = getCorporateStandingOrderCancelsDetailForIgdas(iMap.getString(MapKeys.RECON_DATE), corporateCode, reconLogOid);
					int bankOrderCount = bsorMap.getInt("DETAIL_COUNT");
					int bankOrderCancelCount = bsorcMap.getInt("DETAIL_COUNT");
					int corporateOrderCount = csorMap.getInt("DETAIL_COUNT");
					int corporateOrderCancelCount = csorcMap.getInt("DETAIL_COUNT");

					String subscriberNo2 = "";

					int subscriber2length = 0;
					for (int i = 0; i < bankOrderCount; i++) {
						for (int j = 0; j < corporateOrderCount; j++) {
							subscriberNo2 = bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2);
							subscriber2length = subscriberNo2.length();
							if (subscriber2length < 4) {
								for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
									subscriberNo2 = "0".concat(subscriberNo2);
								}
							}
							if (bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1).equals(csorMap.getString("CORPORATE_ORDERS", j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(csorMap.getString("CORPORATE_ORDERS", j, MapKeys.SUBSCRIBER_NO2)) && bsorMap.getInt("BANK_ORDERS", i, "COUNT") <= csorMap.getInt("CORPORATE_ORDERS", j, "COUNT")) {
								found = true;// bizdeki talimat kaydi kurumda
								break; // bulundu

							} else {
								found = false;// bizdeki talimat kaydi kurumda
												// bulunamadi
							}
						}

						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, getCustomerNoForStandingOrder(bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1), CommonHelper.trimStart(bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2), '0'), corporateCode));
							onlineCorporateServiceCallInputMap.put(MapKeys.CUSTOMER_NO, getCustomerNoForStandingOrder(bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1), CommonHelper.trimStart(bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2), '0'), corporateCode));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3, getCustomerNoForStandingOrder(bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1), CommonHelper.trimStart(bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2), '0'), corporateCode));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}

					found = false;
					if (bankOrderCancelCount > corporateOrderCancelCount)
						for (int i = 0; i < bankOrderCancelCount; i++) {
							for (int j = 0; j < corporateOrderCancelCount; j++) {
								subscriberNo2 = bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2);
								subscriber2length = subscriberNo2.length();
								if (subscriber2length < 4) {
									for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
										subscriberNo2 = "0".concat(subscriberNo2);
									}
								}

								if (bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1).equals(csorcMap.getString("CORPORATE_CANCELS", j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(csorcMap.getString("CORPORATE_CANCELS", i, MapKeys.SUBSCRIBER_NO2)) && bsorcMap.getInt("BANK_CANCELS", i, "COUNT") <= csorcMap.getInt("CORPORATE_CANCELS", j, "COUNT")) {
									found = true;
									break;
								} else {
									found = false;
								}
							}
							if (!found) {

								String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
								GMMap onlineCorporateServiceCallInputMap = new GMMap();
								GMMap onlineCorporateServiceCallOutputMap = new GMMap();
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2));
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, getCustomerNoForStandingOrder(bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1), CommonHelper.trimStart(bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2), '0'), corporateCode));
								onlineCorporateServiceCallInputMap.put(MapKeys.CUSTOMER_NO, getCustomerNoForStandingOrder(bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1), CommonHelper.trimStart(bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2), '0'), corporateCode));
								onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
								onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
								onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
								onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
								GMMap reconProcessDataLogInsertInputMap = new GMMap();
								try {
									onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
								} catch (GMRuntimeException e) {
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
								}
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent); // Gonderildi
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3, getCustomerNoForStandingOrder(bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1), CommonHelper.trimStart(bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2), '0'), corporateCode));
								CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
							}
						}

				} else {
					// errorCode = "9999";
					outMap.put(MapKeys.ERROR_CODE, "9999");
					outMap.put(MapKeys.ERROR_DESC, "IGDAS mutabakat detayi tabloya yuklenirken hata meydana geldi.Detay mutabakat yapilamadi.");
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				}
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				insertOnlineServiceLog(iMap, outMap);

			} else {
				// detay mutabakat sirasinda hata olustu
				responseCode = hataKodlari[0];
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				insertOnlineServiceLog(iMap, outMap);
			}

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	public static String getCustomerNoForStandingOrder(String subscriberNo1, String subscriberNo2, String corporateCode) {
		String customerNo = "";
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(icsStandingOrders.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("subscriberNo1", subscriberNo1)).add(Restrictions.like("subscriberNo2", subscriberNo2, MatchMode.END)).add(Restrictions.eq("status", true)).addOrder(Order.desc("txNo"));
			List<icsStandingOrders> bankStandingOrderList = criteria.list();
			customerNo = bankStandingOrderList.get(0).getCustomerNo().toString();
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e);
		}

		return customerNo;

	}

	public static GMMap getBankStandingOrdersForIgdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		// strSQLTalimat = "SELECT subscriber_no1,subscriber_no2 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.create_date LIKE '" +
		// reconcilitionDate + "%'";
		strSQLTalimat = String.format(QueryRepository.IgdasServicesRepository.GET_BANK_STANDING_ORDERS, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrdersDetailForIgdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		// strSQLTalimat =
		// "SELECT subscriber_no1,subscriber_no2, count(*) as count " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.create_date LIKE '" +
		// reconcilitionDate + "%' " +
		// "group by subscriber_no1,subscriber_no2 ";
		strSQLTalimat = String.format(QueryRepository.IgdasServicesRepository.GET_BANK_STANDING_ORDER_DETAIL, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrderCancelsForIgdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";

		// strSQLIptal = "SELECT subscriber_no1,subscriber_no2 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.cancel_date LIKE '" +
		// reconcilitionDate + "%'";
		strSQLIptal = String.format(QueryRepository.IgdasServicesRepository.GET_BANK_STANDING_ORDER_CANCEL, corporateCode, reconcilitionDate);

		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
		}
		return returnMap;

	}

	public static GMMap getBankStandingOrderCancelsDetailForIgdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";

		// strSQLIptal = "SELECT subscriber_no1,subscriber_no2 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.cancel_date LIKE '" +
		// reconcilitionDate + "%'";
		strSQLIptal = String.format(QueryRepository.IgdasServicesRepository.GET_BANK_STANDING_ORDER_CANCEL_DETAIL, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;

	}

	public static GMMap getCorporateStandingOrderCancelsForIgdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_CANCELS";
		String strSQL = "";
		// strSQL =
		// "SELECT subscriber_no1,subscriber_no2, transaction_type as PAYMENT_STATUS "
		// + "FROM ics.recon_detail_data " + "WHERE collection_type ='0'" +
		// "AND status = 1 AND corporate_code = '" + corporateCode + "' " +
		// "AND recon_log_oid = '" + reconLogOid +
		// "' AND transaction_type='I' ";
		strSQL = String.format(QueryRepository.IgdasServicesRepository.GET_CORPORATE_CANCEL_STANDING_ORDERS, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
		}

		return returnMap;

	}

	public static GMMap getCorporateStandingOrdersForIgdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_ORDERS";
		String strSQL = "";
		// strSQL =
		// "SELECT subscriber_no1,subscriber_no2, transaction_type as PAYMENT_STATUS "
		// + "FROM ics.recon_detail_data " + "WHERE collection_type ='0'" +
		// "AND status = 1 AND corporate_code = '" + corporateCode + "' " +
		// "AND recon_log_oid = '" + reconLogOid +
		// "' AND transaction_type='K' ";
		strSQL = String.format(QueryRepository.IgdasServicesRepository.GET_CORPORATE_STANDING_ORDERS, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_CORPORATE_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_CORPORATE_COUNT, 0);
		}

		return returnMap;

	}

	public static GMMap getCorporateStandingOrdersDetailForIgdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_ORDERS";
		String strSQL = "";
		// strSQL = "SELECT subscriber_no1,subscriber_no2, count(*) as count " +
		// "FROM ics.recon_detail_data " + "WHERE collection_type ='0'" +
		// "AND status = 1 AND corporate_code = '" + corporateCode + "' " +
		// "AND recon_log_oid = '" + reconLogOid + "' AND transaction_type='K' "
		// + "group by subscriber_no1,subscriber_no2 ";
		strSQL = String.format(QueryRepository.IgdasServicesRepository.GET_CORPORATE_STANDING_ORDER_DETAIL, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;

	}

	public static GMMap getCorporateStandingOrderCancelsDetailForIgdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_CANCELS";
		String strSQL = "";
		// strSQL = "SELECT subscriber_no1,subscriber_no2, count(*) as count " +
		// "FROM ics.recon_detail_data " + "WHERE collection_type ='0'" +
		// "AND status = 1 AND corporate_code = '" + corporateCode + "' " +
		// "AND recon_log_oid = '" + reconLogOid + "' AND transaction_type='I' "
		// + "group by subscriber_no1,subscriber_no2 ";
		strSQL = String.format(QueryRepository.IgdasServicesRepository.GET_CORPORATE_STANDING_ORDER_CANCEL_DETAIL, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;

	}

	@GraymoundService("CDM_IGDAS_GET_ALL_STO_LIST")
	public static GMMap igdasGetAllStoList(GMMap inputMap) {
		GMMap output = new GMMap();
		String subject = "�gda� talimatl� m��teriler raporu";
		String dosyaString = "INIT";
		try {
			GMMap outMap = new GMMap();
			String dateStr = inputMap.getString("DATE");
			String fileName = "143V8B2_".concat(dateStr);
			String wsUrl = "http://172.16.2.204/IgdasTahsilatWebServices/AboneTalimatService.svc?wsdl";
			String wsUserName = "AY";
			String wsPassword = "4321";
			String bankCode = "143";
			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_AboneTalimatMutabakatDosyaIndirCevap aboneTalimatMutabakatDosyaIndirCevap = IgdasClient.aboneTalimatMutabakatDosyaIndir(wsUrl, wsUserName, wsPassword, bankCode, fileName, s);
			inputMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			byte[] dosya = aboneTalimatMutabakatDosyaIndirCevap.getSonuc().getDosya();
			dosyaString = new String(dosya);
			logger.info(dosyaString);
			List<String> recipientList = Arrays.asList("akin.garagon@aktifbank.com.tr", "devir.telli@aktifbank.com.tr");
			List<String> ccList = Arrays.asList("akin.garagon@aktifbank.com.tr", "devir.telli@aktifbank.com.tr");
			String from = "devir.telli@aktifbank.com.tr";
			boolean isHtmlBody = true;
			String body = dosyaString;
			CommonHelper.sendMail(recipientList, ccList, from, isHtmlBody, subject, body, false);
			logger.info("CDM_IGDAS_GET_ALL_STO_LIST -> ba�ar�l� olarak tamamland�!");
		} catch (Exception e) {
			logger.error("CDM_IGDAS_GET_ALL_STO_LIST -> hata meydana geldi : ".concat(e.toString()));
		} finally {
			output.put("STO_LIST", dosyaString);
		}
		return output;
	}
	
	@GraymoundService("CDM_IGDAS_GET_ALL_STO_CANCEL_LIST")
	public static GMMap igdasGetAllStoCancelList(GMMap inputMap) {
		GMMap output = new GMMap();
		String subject = "�gda� talimat iptal edilen m��teriler raporu";
		String dosyaString = "INIT";
		try {
			GMMap outMap = new GMMap();
			String dateStr = inputMap.getString("DATE");
			String fileName = "143V8B1_".concat(dateStr);
			String wsUrl = "http://172.16.2.204/IgdasTahsilatWebServices/AboneTalimatService.svc?wsdl";
			String wsUserName = "AY";
			String wsPassword = "4321";
			String bankCode = "143";
			ServiceMessage s = new ServiceMessage();
			BaseResponseMessageOf_AboneTalimatMutabakatDosyaIndirCevap aboneTalimatMutabakatDosyaIndirCevap = IgdasClient.aboneTalimatMutabakatDosyaIndir(wsUrl, wsUserName, wsPassword, bankCode, fileName, s);
			inputMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			byte[] dosya = aboneTalimatMutabakatDosyaIndirCevap.getSonuc().getDosya();
			dosyaString = new String(dosya);
			logger.info(dosyaString);
			List<String> recipientList = Arrays.asList("akin.garagon@aktifbank.com.tr", "devir.telli@aktifbank.com.tr");
			List<String> ccList = Arrays.asList("akin.garagon@aktifbank.com.tr", "devir.telli@aktifbank.com.tr");
			String from = "devir.telli@aktifbank.com.tr";
			boolean isHtmlBody = true;
			String body = dosyaString;
			CommonHelper.sendMail(recipientList, ccList, from, isHtmlBody, subject, body, false);
			logger.info("CDM_IGDAS_GET_ALL_STO_CANCEL_LIST -> ba�ar�l� olarak tamamland�!");
		} catch (Exception e) {
			logger.error("CDM_IGDAS_GET_ALL_STO_CANCEL_LIST -> hata meydana geldi : ".concat(e.toString()));
		} finally {
			output.put("STO_CANCEL_LIST", dosyaString);
		}
		return output;
	}
}
