package tr.com.aktifbank.bnspr.corporation.services;


import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class OfflineCorporationServices {

	
	@GraymoundService("ICS_OFFLINE_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap iMap) {
		
		
		try {
		}catch (Exception ex) {
		}
		return iMap;
		
	}
	
}
