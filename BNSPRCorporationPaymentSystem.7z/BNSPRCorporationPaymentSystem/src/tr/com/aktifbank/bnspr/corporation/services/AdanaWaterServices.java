package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.aski.AskiClient;
import tr.com.aktifbank.integration.aski.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import aski.org.alfabim.abone.tahsilat.model.BakiyeVw;
import aski.org.alfabim.abone.tahsilat.model.WSTahsilat;
import aski.org.alfabim.abone.webService.bean.WSAboneSicil;
import aski.org.alfabim.abone.webService.bean.WsMakbuz;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdanaWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(AdanaWaterServices.class);
	public static String DELIMITER = "-";
	public static String COLLECTION_INFO_DELIMITER = "~";
	public static String RECON_DELIMITER = " ";
	public static String RECEIPT_DELIMITER1 = "-";
	public static String RECEIPT_DELIMITER2 = "/";
	public static String BRANCH_CODE = "555";
	public static String PAY_DESK = "1";
	public static BigDecimal SICIL_NO_CANCELLED_VALUE = new BigDecimal(0);
	public static BigDecimal SICIL_NO_SYSTEM_ERROR_VALUE = new BigDecimal(-1);
	public static String SICIL_NO_CANCELLED_ERROR_CODE = "899";
	public static String SICIL_NO_SYSTEM_ERROR_CODE = "999";

	@GraymoundService("ICS_ASKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		BigDecimal sicilNo = BigDecimal.ZERO;
		String borcAlacak = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;

		try {
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			sicilNo = getSicilno(aboneNo, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo) == 0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
			} else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo) == 0) {
				responseCode = SICIL_NO_SYSTEM_ERROR_CODE;
			}
			ServiceMessage serviceMessageAskiGetAboneOrSicilBorc = new ServiceMessage();
			BakiyeVw[] bakiyeVwList = AskiClient.getAboneOrSicilBorc(aboneNo, sicilNo, borcAlacak,
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessageAskiGetAboneOrSicilBorc);
			String callParameters = aboneNo.toString().concat(",").concat(sicilNo.toString()).concat(",").concat(borcAlacak.toString()).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_ASKI_INVOICE_DEBT_INQUIRY called AskiClient.getAboneOrSicilBorc(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAskiGetAboneOrSicilBorc.getRequest())));
			logger.info("ICS_ASKI_INVOICE_DEBT_INQUIRY is replied with SOAP response message by AskiClient.getAboneOrSicilBorc(".concat(
					callParameters).concat(") -> ".concat(serviceMessageAskiGetAboneOrSicilBorc.getResponse())));
			iMap.put("REQUEST_XML_GET_ABONE_OR_SICIL_BORC", serviceMessageAskiGetAboneOrSicilBorc.getRequest());
			outMap.put("REQUEST_XML_GET_ABONE_OR_SICIL_BORC", serviceMessageAskiGetAboneOrSicilBorc.getResponse());
			int length = bakiyeVwList.length;
			for (int i = 0; i < length; i++) {
				BakiyeVw bakiyeVw = bakiyeVwList[i];
				responseCode = bakiyeVw.getThsAciklama();
				if (responseCode == null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				if (responseCode.contains("aboneye ait borc bulunmamaktad�r")) {

					responseCode = "350";

				}
				if (responseCode.contains("abone numaras� sistemde bulunmamaktad�r")) {
					responseCode = "499";
				}
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID),
						corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					if (!isCollectedInvoice(bakiyeVw.getTahakkukNo(), bakiyeVw.getAboneNo().toString(), "", "", "", corporateCode, bakiyeVw
							.getSiraNo().intValue())) {
						String termYear = bakiyeVw.getDonem().toString().substring(0, 4);
						String termMonth = bakiyeVw.getDonem().toString().substring(4);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bakiyeVw.getAboneNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, bakiyeVw.getSicilNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bakiyeVw.getTahakkukNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bakiyeVw.getGecikmeliToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bakiyeVw.getTur());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, bakiyeVw.getSiraNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bakiyeVw.getAdiSoyadi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, bakiyeVw.getVade().getTime());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bakiyeVw.getGecikmeliToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));

			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_ASKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_DO_INVOICE_COLLECTION");
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			String aboneNoString = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1).toString();
			BigDecimal sicilNo = getSicilno(aboneNo, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			String sicilNoString = sicilNo.toString();
			BigDecimal cariIslem = BigDecimal.ZERO;
			BigDecimal yuvarlama = BigDecimal.ZERO;

			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo) == 0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
			} else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo) == 0) {
				responseCode = SICIL_NO_SYSTEM_ERROR_CODE;
			}

			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String gecikmeliToplam = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT).toString();
			String tur = iMap.getString(MapKeys.PARAMETER1);
			String siraNo = iMap.getString(MapKeys.INSTALLMENT_NO) != null ? iMap.getBigDecimal(MapKeys.INSTALLMENT_NO).toString() : "";
			String tahsilatInfo = String.format("%s~%s~%s~%s~%s~%s", aboneNoString, sicilNoString, tahakkukNo, gecikmeliToplam, tur, siraNo);
			String aciklama = "";
			String krediKartNo = "";
			String tahsilatTarihi = CommonHelper.getDateString(new Date(), "dd/MM/yyyy HH:mm:ss");
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String dekontNo = getAskiDekont(iMap.getString(MapKeys.TRX_NO));
			if (!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")) {
				ServiceMessage serviceMessageAskiTahsilatYap = new ServiceMessage();
				WSTahsilat[] tahsilatList = AskiClient.tahsilatYap(tahsilatInfo, user, sifre, dekontNo, krediKartNo, aciklama, tahsilatTarihi,
						cariIslem, yuvarlama, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),
						iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
						serviceMessageAskiTahsilatYap);
				String callParameters = tahsilatInfo.toString().concat(",").concat(user.toString()).concat(",").concat(sifre.toString()).concat(",")
						.concat(dekontNo.toString()).concat(",").concat(krediKartNo.toString()).concat(",").concat(aciklama.toString()).concat(",")
						.concat(tahsilatTarihi.toString()).concat(",").concat(cariIslem.toString()).concat(",").concat(yuvarlama.toString())
						.concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
						.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
						.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
				logger.info("ICS_ASKI_DO_INVOICE_COLLECTION called AskiClient.tahsilatYap(".concat(callParameters).concat(
						") with SOAP request message -> ".concat(serviceMessageAskiTahsilatYap.getRequest())));
				logger.info("ICS_ASKI_DO_INVOICE_COLLECTION is replied with SOAP response message by AskiClient.tahsilatYap(".concat(callParameters)
						.concat(") -> ".concat(serviceMessageAskiTahsilatYap.getResponse())));
				iMap.put("REQUEST_XML_TAHSILAT_YAP", serviceMessageAskiTahsilatYap.getRequest());
				outMap.put("REQUEST_XML_TAHSILAT_YAP", serviceMessageAskiTahsilatYap.getResponse());
				int tahsilatListLength = tahsilatList.length;
				for (int i = 0; i < tahsilatListLength; i++) {
					responseCode = tahsilatList[i].getAciklama();
					if (responseCode.contains("Tahsilat i�lemi ba�ar� ile ger�ekle�ti")) {
						responseCode = "220";
					}
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID),
							corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						outMap.put("TAHSILAT", i, "MAKBUZ_NO", tahsilatList[i].getMakbuzNo());
						outMap.put("TAHSILAT", i, "MAKBUZ_SERI", tahsilatList[i].getMakbuzSeri());

						outMap.put(MapKeys.CORPORATE_PAYMENT_ID, tahsilatList[i].getMakbuzNo());
						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
								.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						invoicePayment.setParameter3(tahsilatList[i].getMakbuzNo().toString());
						invoicePayment.setParameter4(tahsilatList[i].getMakbuzSeri());
						session.saveOrUpdate(invoicePayment);
					}
				}
			} else {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String aciklama = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahsilatIslemTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"),
					"dd/MM/yyyy");
			String dekontNo = getAskiDekont(iMap.getString(MapKeys.TRX_NO));
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal makbuzNo = iMap.getBigDecimal("PARAMETER_3");
			String makbuzSeri = iMap.getString("PARAMETER_4");
			if (makbuzNo == null) {
				makbuzNo = iMap.getBigDecimal(MapKeys.PARAMETER3);
			}
			if (makbuzSeri == null) {
				makbuzSeri = iMap.getString(MapKeys.PARAMETER4);
			}
			ServiceMessage serviceMessageAskiTahsilatIptal = new ServiceMessage();
			String responseCode = AskiClient.tahsilatIptal(tahsilatIslemTarihi, makbuzSeri, makbuzNo, aciklama, user, sifre,
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessageAskiTahsilatIptal);
			String callParameters = tahsilatIslemTarihi.toString().concat(",").concat(makbuzSeri.toString()).concat(",").concat(makbuzNo.toString())
					.concat(",").concat(aciklama.toString()).concat(",").concat(user.toString()).concat(",").concat(sifre.toString()).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE called AskiClient.tahsilatIptal(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAskiTahsilatIptal.getRequest())));
			logger.info("ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE is replied with SOAP response message by AskiClient.tahsilatIptal(".concat(
					callParameters).concat(") -> ".concat(serviceMessageAskiTahsilatIptal.getResponse())));
			iMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessageAskiTahsilatIptal.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessageAskiTahsilatIptal.getResponse());
			if (responseCode.contains("Code:100 Kullan�c� no veya �ifresi yanl��")) {
				responseCode = "110";
			} else if (responseCode.contains("Code:100 Tahsilat Tarihi hatal�")) {
				responseCode = "100";
			} else if (responseCode.contains("Code:200")) {
				responseCode = "200";
			} else if (responseCode.contains("Code:300")) {
				responseCode = "300";
			} else if (responseCode.contains("Code:000")) {
				responseCode = "470";
			} else if (responseCode.contains("Code:400")) {
				responseCode = "400";
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String giseNo = "1";
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			String responseCode = "";
			ServiceMessage serviceMessageAskiGunSonuDetay = new ServiceMessage();
			WsMakbuz[] makbuzList = AskiClient.gunSonuDetay(giseNo, tarih, user, sifre,
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessageAskiGunSonuDetay);
			String callParameters = giseNo.toString().concat(",").concat(tarih.toString()).concat(",").concat(user.toString()).concat(",")
					.concat(sifre.toString()).concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL called AskiClient.gunSonuDetay(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAskiGunSonuDetay.getRequest())));
			logger.info("ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL is replied with SOAP response message by AskiClient.gunSonuDetay(".concat(
					callParameters).concat(") -> ".concat(serviceMessageAskiGunSonuDetay.getResponse())));
			iMap.put("REQUEST_XML_GUN_SONU_DETAY", serviceMessageAskiGunSonuDetay.getRequest());
			outMap.put("REQUEST_XML_GUN_SONU_DETAY", serviceMessageAskiGunSonuDetay.getResponse());
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int makbuzlistLenght = 0;
			if (makbuzList != null) {
				makbuzlistLenght = makbuzList.length;

				WsMakbuz makbuz = new WsMakbuz();
				for (int i = 0; i < makbuzlistLenght; i++) {
					makbuz = makbuzList[i];
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, makbuz.getAboneNo());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.TRX_NO, makbuz.getDekont());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.PARAMETER3, makbuz.getMakbuzNo());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, makbuz.getToplam());
				}
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = makbuzlistLenght;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;
			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(
								reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))
								&& reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
								&& reconBankMap.getString("BANK", j, MapKeys.PARAMETER3).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PARAMETER3))
								&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat istegi gonder
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",
									onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE,
								ReconciliationProcessType.collectionMessageSent);// Talimat
																					// Mesaji
																					// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,
								request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO,
								request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,
								request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,
								request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,
								request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,
								request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,
								request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,
								request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,
								request.getString(MapKeys.PARAMETER4));

						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(
								reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(
										reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER3).equals(
										reconBankMap.getString("BANK", k, MapKeys.PARAMETER3))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(
										reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PARAMETER3, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER3));
						request.put(MapKeys.PARAMETER4, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER4));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",
									onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola
							// devam ediyoruz
							logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
							logger.error(System.currentTimeMillis(), e);
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE,
								ReconciliationProcessType.cancelCollectionMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,
								request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO,
								request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,
								request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,
								request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,
								request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,
								request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,
								request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,
								request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,
								request.getString(MapKeys.PARAMETER4));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_ASKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			// String tarih = iMap.getString(MapKeys.RECON_DATE_BEGIN);
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");

			ServiceMessage serviceMessageAskiGunSonuYekun = new ServiceMessage();
			WsMakbuz[] reconciliationResult = AskiClient.gunSonuYekun("1", tarih, user, sifre,
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessageAskiGunSonuYekun);
			String callParameters = "1".toString().concat(",").concat(tarih.toString()).concat(",").concat(user.toString()).concat(",")
					.concat(sifre.toString()).concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_ASKI_COLLECTION_RECONCILIATION called AskiClient.gunSonuYekun(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAskiGunSonuYekun.getRequest())));
			logger.info("ICS_ASKI_COLLECTION_RECONCILIATION is replied with SOAP response message by AskiClient.gunSonuYekun(".concat(callParameters)
					.concat(") -> ".concat(serviceMessageAskiGunSonuYekun.getResponse())));
			iMap.put("REQUEST_XML_GUN_SONU_YEKUN", serviceMessageAskiGunSonuYekun.getRequest());
			outMap.put("REQUEST_XML_GUN_SONU_YEKUN", serviceMessageAskiGunSonuYekun.getResponse());

			ServiceMessage serviceMessageAskiGunSonuDetay = new ServiceMessage();
			WsMakbuz[] reconciliationResultDetail = AskiClient.gunSonuDetay("1", tarih, user, sifre,
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessageAskiGunSonuDetay);

			callParameters = "1".toString().concat(",").concat(tarih.toString()).concat(",").concat(user.toString()).concat(",")
					.concat(sifre.toString()).concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_ASKI_COLLECTION_RECONCILIATION called AskiClient.gunSonuDetay(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAskiGunSonuDetay.getRequest())));
			logger.info("ICS_ASKI_COLLECTION_RECONCILIATION is replied with SOAP response message by AskiClient.gunSonuDetay(".concat(callParameters)
					.concat(") -> ".concat(serviceMessageAskiGunSonuDetay.getResponse())));
			iMap.put("REQUEST_XML_GUN_SONU_DETAY", serviceMessageAskiGunSonuDetay.getRequest());
			outMap.put("REQUEST_XML_GUN_SONU_DETAY", serviceMessageAskiGunSonuDetay.getResponse());

			ServiceMessage serviceMessageAskiGetIptalList = new ServiceMessage();
			WsMakbuz[] reconciliationCancelResult = AskiClient.getIptalList("1", tarih, user, sifre,
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessageAskiGetIptalList);

			callParameters = "1".toString().concat(",").concat(tarih.toString()).concat(",").concat(user.toString()).concat(",")
					.concat(sifre.toString()).concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_ASKI_COLLECTION_RECONCILIATION called AskiClient.getIptalList(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAskiGetIptalList.getRequest())));
			logger.info("ICS_ASKI_COLLECTION_RECONCILIATION is replied with SOAP response message by AskiClient.getIptalList(".concat(callParameters)
					.concat(") -> ".concat(serviceMessageAskiGetIptalList.getResponse())));
			iMap.put("REQUEST_XML_GET_IPTAL_LIST", serviceMessageAskiGetIptalList.getRequest());
			outMap.put("REQUEST_XML_GET_IPTAL_LIST", serviceMessageAskiGetIptalList.getResponse());

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				if (reconciliationResult == null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconciliationResult[0].getToplam());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResultDetail.length);
				}

				if (reconciliationCancelResult == null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				} else {
					BigDecimal toplam = BigDecimal.ZERO;
					BigDecimal deger = BigDecimal.ZERO;
					for (int i = 0; i < reconciliationCancelResult.length; i++) {
						deger = new BigDecimal(reconciliationCancelResult[i].getToplam());
						toplam = toplam.add(deger);
					}
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, toplam.toString());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationCancelResult.length);
				}

			}

			// /invoice payment dan corporate payment_amount count payment
			// status t I ayr�m� yap
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(
					outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				ServiceMessage serviceMessageMutabakatIstek = new ServiceMessage();
				String reconRequest = AskiClient.mutbakatIstek(tarih, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString(),
						reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString(), user, sifre, serviceMessageMutabakatIstek,iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
				callParameters = tarih.toString().concat(",").concat(reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString()).concat(",")
						.concat(reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString()).concat(",").concat(user.toString()).concat(",")
						.concat(sifre.toString()).concat(",");
				logger.info("ICS_ASKI_COLLECTION_RECONCILIATION called AskiClient.mutbakatIstek(".concat(callParameters).concat(
						") with SOAP request message -> ".concat(serviceMessageMutabakatIstek.getRequest())));
				logger.info("ICS_ASKI_COLLECTION_RECONCILIATION is replied with SOAP response message by AskiClient.mutbakatIstek(".concat(
						callParameters).concat(") -> ".concat(serviceMessageMutabakatIstek.getResponse())));
				iMap.put("REQUEST_XML_MUTABAKAT_ISTEK", serviceMessageMutabakatIstek.getRequest());
				outMap.put("REQUEST_XML_MUTABAKAT_ISTEK", serviceMessageMutabakatIstek.getResponse());

				if (reconRequest.contains("Tamamland")) {
					ServiceMessage serviceMessagemutabakatSorgulama = new ServiceMessage();
					String reconCheck = AskiClient.mutbakatSorgulama(tarih, user, sifre, serviceMessagemutabakatSorgulama,iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
					callParameters = tarih.toString().concat(",").concat(",").concat(user.toString()).concat(",").concat(sifre.toString())
							.concat(",");
					logger.info("ICS_ASKI_COLLECTION_RECONCILIATION called AskiClient.mutbakatSorgulama(".concat(callParameters).concat(
							") with SOAP request message -> ".concat(serviceMessagemutabakatSorgulama.getRequest())));
					logger.info("ICS_ASKI_COLLECTION_RECONCILIATION is replied with SOAP response message by AskiClient.mutbakatSorgulama(".concat(
							callParameters).concat(") -> ".concat(serviceMessagemutabakatSorgulama.getResponse())));
					iMap.put("REQUEST_XML_MUTABAKAT_SORGULAMA", serviceMessagemutabakatSorgulama.getRequest());
					outMap.put("REQUEST_XML_MUTABAKAT_SORGULAMA", serviceMessagemutabakatSorgulama.getResponse());

					if (reconCheck.contains("Var")) {
						outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					} else {
						outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_COLLECTION_RECONCILIATION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	
	@GraymoundService("ICS_ASKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ASKI_COLLECTION_RECONCILIATION_CLOSED");
		
		try{
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	
	public static BigDecimal getSicilno(BigDecimal subscribeNo, String wsUrl, String wsUserName, String wsPassword) {
		BigDecimal sicilNo = new BigDecimal(0);
		try {
			ServiceMessage serviceMessageAboneSicilleri = new ServiceMessage();
			WSAboneSicil[] wsAboneSicils = AskiClient.aboneSicilleri(subscribeNo, wsUrl, wsUserName, wsPassword, serviceMessageAboneSicilleri);
			String callParameters = subscribeNo.toString().concat(",").concat(wsUrl.toString()).concat(",").concat(wsUserName.toString())
					.concat(",").concat(wsPassword.toString());
			logger.info("getSicilno called AskiClient.aboneSicilleri(".concat(callParameters).concat(
					") with SOAP request message -> ".concat(serviceMessageAboneSicilleri.getRequest())));
			logger.info("getSicilno is replied with SOAP response message by AskiClient.aboneSicilleri(".concat(callParameters).concat(
					") -> ".concat(serviceMessageAboneSicilleri.getResponse())));

			if (wsAboneSicils != null) {
				int s = wsAboneSicils.length;

				for (int i = 0; i < s; i++) {

					if (wsAboneSicils[i].getFesihTarihi() == null || wsAboneSicils[i].getFesihTarihi().toString().isEmpty()) {
						sicilNo = wsAboneSicils[i].getSicilNo();
						break;
					} else {
						sicilNo = new BigDecimal(-1);
					}
				}
			} else {
				sicilNo = new BigDecimal(-1);
			}

		} catch (Exception e) {
			logger.error("An exception occured while executing getting Sicil No");
			logger.error(System.currentTimeMillis(), e);
			e.printStackTrace();
		}
		return sicilNo;
	}

	public static boolean isResponseCodeApprove(GMMap inMap) {
		if (!(inMap.getString("RETURN_CODE").equals("0"))) {
			return false;
		} else {
			return true;
		}

	}

	public static String getAskiDekont(String dekont) {
		String askiDekont = BRANCH_CODE + RECEIPT_DELIMITER1 + PAY_DESK + RECEIPT_DELIMITER2 + dekont;
		return askiDekont;
	}

	public static String getAktifDekont(String dekont) {
		String[] splitedDekont = dekont.split(RECEIPT_DELIMITER2);
		String aktifDekont = splitedDekont[1];
		return aktifDekont;
	}

}
