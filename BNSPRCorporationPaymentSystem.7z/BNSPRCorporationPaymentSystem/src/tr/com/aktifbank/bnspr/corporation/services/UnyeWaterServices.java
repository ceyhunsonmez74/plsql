package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.unyesu.UnyeOnlineClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.gov.belediye.v1.AboneBilgiRequestType;
import tr.gov.belediye.v1.AboneBilgiResponse;
import tr.gov.belediye.v1.BorcDetay;
import tr.gov.belediye.v1.BorcResponse;
import tr.gov.belediye.v1.IptalResponse;
import tr.gov.belediye.v1.MutabakatDetayResponse;
import tr.gov.belediye.v1.MutabakatResponse;
import tr.gov.belediye.v1.TahsilatResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class UnyeWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(UnyeWaterServices.class);
	private static final String WS_RESPONSE_CODE ="WS_RESPONSE_CODE";

	public UnyeWaterServices() {
	}

	private static AboneBilgiResponse subscriberInfo(GMMap iMap) throws Exception {
		AboneBilgiResponse aboneBilgiResponse = null;
		try {
			String subscriberWaterNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String subscriberId = iMap.getString(MapKeys.SUBSCRIBER_NO4);
			String tcNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String subscriberNumber = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			UnyeOnlineClient client = getSoapClient(iMap);
			if (StringUtils.isNotBlank(subscriberWaterNumber)&&StringUtils.isNotBlank(CommonHelper.trimStart(subscriberWaterNumber, '0'))) {
				aboneBilgiResponse = client.aboneSorgu(CommonHelper.trimStart(subscriberWaterNumber, '0'), AboneBilgiRequestType._SuSicilNo);
			} else if (StringUtils.isNotBlank(tcNumber)&&StringUtils.isNotBlank(CommonHelper.trimStart(tcNumber, '0'))) {
				aboneBilgiResponse = client.aboneSorgu(CommonHelper.trimStart(tcNumber, '0'), AboneBilgiRequestType._TCKimlikNo);
			} else if (StringUtils.isNotBlank(subscriberNumber)&&StringUtils.isNotBlank(CommonHelper.trimStart(subscriberNumber, '0'))) {
				aboneBilgiResponse = client.aboneSorgu(CommonHelper.trimStart(subscriberNumber, '0'), AboneBilgiRequestType._SicilNo);
			} else if (StringUtils.isNotBlank(subscriberId)&&StringUtils.isNotBlank(CommonHelper.trimStart(subscriberId, '0'))) {
				aboneBilgiResponse = client.aboneSorgu(CommonHelper.trimStart(subscriberId, '0'), AboneBilgiRequestType._SicilId);
			}
		} catch (Exception e) {
			throw e;
		}
		return aboneBilgiResponse;
	}
	@GraymoundService("ICS_UNYESU_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UNYESU_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		try {
			
			UnyeOnlineClient client = getSoapClient(iMap);
			AboneBilgiResponse aboneBilgiResponse = subscriberInfo(iMap);
			
			String responseCode = aboneBilgiResponse.getResponse().length == 0 ? null : aboneBilgiResponse.getResponse()[0].getKod().toString();
			String responseMesaj=aboneBilgiResponse.getResponse().length == 0 ? null : aboneBilgiResponse.getResponse()[0].getMesaj().toString();
			outMap.put(WS_RESPONSE_CODE, aboneBilgiResponse.getResponse()[0].getKod()+" "+aboneBilgiResponse.getResponse()[0].getMesaj());
			GMMap responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
			if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				BorcResponse borcResponse = client.borcSorgu(aboneBilgiResponse.getResponse()[0].getSicilNo(), aboneBilgiResponse.getResponse()[0].getSicilId(), aboneBilgiResponse.getResponse()[0].getBeyanId(), Integer.valueOf(aboneBilgiResponse.getResponse()[0].getGuser()).intValue());
				 responseCode = borcResponse.getResponse().length == 0 ? null : borcResponse.getResponse()[0].getKod().toString();
				 responseMesaj=borcResponse.getResponse().length == 0 ? null : borcResponse.getResponse()[0].getMesaj().toString();
				 responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
				if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int counter = 0;
					
					for (BorcDetay borc : borcResponse.getResponse()[0].getBorcdetay()) {
						if (!isCollectedInvoice(borc.getTahakkukNo(), String.valueOf(borcResponse.getResponse()[0].getSicilId()), "", "", "", iMap.getString(MapKeys.CORPORATE_CODE))) {
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, CommonHelper.trimStart(aboneBilgiResponse.getResponse()[0].getSicilNo(), '0'));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, CommonHelper.trimStart(aboneBilgiResponse.getResponse()[0].getSicilId().toString(), '0'));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, aboneBilgiResponse.getResponse()[0].getTcKimlikNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, CommonHelper.trimStart(aboneBilgiResponse.getResponse()[0].getSicilNo(), '0'));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getTahakkukNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplamTutar());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, StringUtils.isNotBlank(borcResponse.getResponse()[0].getAd())?borcResponse.getResponse()[0].getAd():"" + " " + (StringUtils.isNotBlank(borcResponse.getResponse()[0].getSoyad())?borcResponse.getResponse()[0].getSoyad():""));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonOdemeTarih(), "dd-MM-yyyy"));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getYil());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, String.format("%02d",Integer.valueOf(borc.getDonem()).intValue()));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, borc.getSelected());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, CommonHelper.trimStart(aboneBilgiResponse.getResponse()[0].getSicilId().toString(), '0'));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, borc.getGecikme());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcResponse.getResponse()[0].getNetId());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borc.getTahakkukTarih());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}
					}
				}
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_UNYESU_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_UNYESU_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UNYESU_DO_INVOICE_COLLECTION");
		GMMap outMap = new GMMap();
		try {
			UnyeOnlineClient client = getSoapClient(iMap);
			int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))?iMap.getString(MapKeys.SUBSCRIBER_NO2):iMap.getString(MapKeys.PARAMETER1), '0')).intValue();
			int netId = iMap.getInt(MapKeys.PARAMETER3);
			String islemreferansno = iMap.getString(MapKeys.TRX_NO);
			int ihbarnameMakbuzNo = iMap.getInt(MapKeys.INVOICE_NO);
			String islemTarih = stringLongToStringDate("today");
			BigDecimal tahsilatTutar = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			int tahakkukId[] = { ihbarnameMakbuzNo };
			int pBankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			TahsilatResponse result = client.tahsilat(subscriberNumber, tahakkukId, islemreferansno, netId, tahsilatTutar, islemTarih, pBankCode);
			
			String responseCode = result.getResponse()[0].getKod();
			String responseMesaj=result.getResponse()[0].getMesaj();
			outMap.put(WS_RESPONSE_CODE, result.getResponse()[0].getKod()+" "+result.getResponse()[0].getMesaj());
			GMMap responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
			
			if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("TAHSILAT", 0, "MAKBUZ_NO", result.getResponse()[0].getTahsilatId());
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter5(String.valueOf(result.getResponse()[0].getTahsilatId()).toString());
				invoicePayment.setParameter6(islemreferansno);
				session.saveOrUpdate(invoicePayment);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_UNYESU_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	@GraymoundService("ICS_UNYESU_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UNYESU_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			UnyeOnlineClient client = getSoapClient(iMap);
			String iptalAciklama = iMap.getString(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON);
			String bankaReferansNo = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6);
			int tahsilatId = iMap.getInt(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5);
			int pBankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			IptalResponse result = client.iptal(tahsilatId, bankaReferansNo, iptalAciklama, pBankCode);
			
			String responseCode = result.getResponse()[0].getKod();
			String responseMesaj=result.getResponse()[0].getMesaj();
			outMap.put(WS_RESPONSE_CODE, result.getResponse()[0].getKod()+" "+result.getResponse()[0].getMesaj());
			GMMap responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_UNYESU_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	
	@GraymoundService("ICS_UNYESU_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UNYESU_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		try {
			UnyeOnlineClient client = getSoapClient(iMap);
			int pBankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String reconciliationDate = stringLongToStringDate(iMap.getString(MapKeys.RECON_DATE));
			MutabakatResponse result = client.mutabakat(null, reconciliationDate, pBankCode);

			String responseCode = result.getResponse()[0].getKod();
			String responseMesaj=result.getResponse()[0].getMesaj();
			outMap.put(WS_RESPONSE_CODE, result.getResponse()[0].getKod()+" "+result.getResponse()[0].getMesaj());
			GMMap responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
		
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getResponse()[0].getTahsilatTutar().subtract(result.getResponse()[0].getIptalTutar()));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getResponse()[0].getTahsilatSayi()-result.getResponse()[0].getIptalSayi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getResponse()[0].getIptalTutar());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getResponse()[0].getIptalSayi());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} 
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_UNYESU_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	
	@GraymoundService("ICS_UNYESU_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UNYESU_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			UnyeOnlineClient client = getSoapClient(iMap);
			int pBankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String reconciliationDate = stringLongToStringDate(iMap.getString(MapKeys.RECON_DATE));
			MutabakatResponse result = client.mutabakat(null, reconciliationDate, pBankCode);

			String responseCode = result.getResponse()[0].getKod();
			String responseMesaj=result.getResponse()[0].getMesaj();
			outMap.put(WS_RESPONSE_CODE, result.getResponse()[0].getKod()+" "+result.getResponse()[0].getMesaj());
			GMMap responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getResponse()[0].getTahsilatTutar().subtract(result.getResponse()[0].getIptalTutar()));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getResponse()[0].getTahsilatSayi()-result.getResponse()[0].getIptalSayi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getResponse()[0].getIptalTutar());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getResponse()[0].getIptalSayi());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_UNYESU_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_UNYESU_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UNYESU_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			UnyeOnlineClient client = getSoapClient(iMap);
			int pBankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String procesDate = stringLongToStringDate(iMap.getString(MapKeys.RECON_DATE));
			MutabakatDetayResponse resultList = client.mutabakatDetay(pBankCode, procesDate);

			String responseCode = resultList.getResponse()[0].getKod();
			String responseMesaj=resultList.getResponse()[0].getMesaj();
			outMap.put(WS_RESPONSE_CODE, resultList.getResponse()[0].getKod()+" "+resultList.getResponse()[0].getMesaj());
			GMMap responceCodeMap = getErrorCode(responseCode, responseMesaj, iMap, outMap);
		
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			int reconDetResCount = 0;
			for (MutabakatDetayResponse reconDetailResult : resultList.getResponse()) {
				if (!reconDetailResult.isIptal()) {
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.SUBSCRIBER_NO1, CommonHelper.trimStart(reconDetailResult.getSicilNo(), '0'));
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.SUBSCRIBER_NO2, reconDetailResult.getSicilId());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PAYMENT_AMOUNT, reconDetailResult.getIslemTutari());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PAYMENT_DATE, reconDetailResult.getTahsilatTarihi());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PARAMETER5, reconDetailResult.getTahsilatId());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PARAMETER6, reconDetailResult.getBankaReferansNo());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PARAMETER7, reconDetailResult.getMakbuzSeriNo());
					reconDetResCount++;
				}
			}
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			outMap.put("BANK", 0, MapKeys.TRX_NO, reconBankMap.get(MapKeys.TRX_NO));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = reconDetResCount;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;

			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (CommonHelper.trimStart(reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1), '0').equals(CommonHelper.trimStart(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1), '0'))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER5).equals(reconBankMap.getString("BANK", k, MapKeys.PARAMETER5))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER6).equals(reconBankMap.getString("BANK", k, MapKeys.PARAMETER6))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat istegi gonder
						@SuppressWarnings("unused")
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.SUBSCRIBER_NO1, CommonHelper.trimStart(reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1), '0'));
						request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO2));
						request.put(MapKeys.INVOICE_NO, reconBankMap.getInt("BANK", j, MapKeys.INVOICE_NO));
						request.put(MapKeys.TRX_NO, reconBankMap.getInt("BANK", j, MapKeys.PARAMETER6));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0'));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO2), '0'));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO2), '0'));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, request.getString(MapKeys.PARAMETER5));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, request.getString(MapKeys.PARAMETER6));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, request.getBigDecimal(MapKeys.PAYMENT_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, pBankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Tahsilat
																																											// Mesaji
																																											// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0'));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO2), '0'));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO2), '0'));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER4));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (CommonHelper.trimStart(reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1), '0').equals(CommonHelper.trimStart(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1), '0'))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER5).equals(reconBankMap.getString("BANK", k, MapKeys.PARAMETER5))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER6).equals(reconBankMap.getString("BANK", k, MapKeys.PARAMETER6))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						@SuppressWarnings("unused")
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.SUBSCRIBER_NO2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO2));
						request.put(MapKeys.PARAMETER5, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER5));
						request.put(MapKeys.PARAMETER6, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER6));
						request.put(MapKeys.TRX_NO, reconCorpAmountMap.getInt("CORPORATE", j, MapKeys.PARAMETER6));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.INVOICE_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
//						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						onlineCorporateServiceCallInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1,CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0'));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON, "Mutabakat");
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, pBankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0'));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO2), '0'));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO2), '0'));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7, request.getString(MapKeys.PARAMETER7));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_UNYESU_GET_COLLECTION_RECONCILIATION_DETAIL.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}



	private static UnyeOnlineClient getSoapClient(GMMap iMap) {
		UnyeOnlineClient client = new UnyeOnlineClient(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
		return client;
	}

	private static GMMap getErrorCode(String responseCode,String responseDesc, GMMap iMap, GMMap outMap) {
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap responceCodeMap =null;
		if (StringUtils.isBlank(responseCode)||(StringUtils.isNotBlank(responseCode)&&responseCode.equalsIgnoreCase(GeneralConstants.ERROR_CODE_APPROVE))) {
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
		} else if (responseCode.equals("-1")) {
			responceCodeMap = getResponseDescMapping(responseDesc, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			int errorCode = responceCodeMap.getInt(MapKeys.ERROR_CODE);
			if(errorCode==GeneralConstants.ERROR_CODE_NOT_FOUND){
				responceCodeMap = getResponseDescMapping("", iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}
		} else {
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
		}
		return responceCodeMap;

	}

	private static String stringLongToStringDate(String longDate) {
		if (StringUtils.isBlank(longDate)||longDate.equalsIgnoreCase("today") || (StringUtils.isNotBlank(longDate) && longDate.length() < 8)) {
			return CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
		} else if (longDate.equalsIgnoreCase("todaytime") || StringUtils.isBlank(longDate) || (StringUtils.isNotBlank(longDate) && longDate.length() < 8)) {
			return CommonHelper.getDateString(new Date(), "yyyy-MM-dd HH:mm:ss");
		} else {
			return longDate.substring(6, 8) + "." + longDate.substring(4, 6) + "." + longDate.substring(0, 4);
		}
	}

}
