package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.IngazReconciliationDetailBatch;
//import tr.com.aktifbank.bnspr.cps.batch.implementations.IngazReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.ingaz.GazTalimatReturn;
import tr.com.aktifbank.integration.ingaz.GazWebBorcReturn;
import tr.com.aktifbank.integration.ingaz.GazWebTahsilatIptalReturn;
import tr.com.aktifbank.integration.ingaz.GazWebTahsilatReturn;
import tr.com.aktifbank.integration.ingaz.GazWebTahsilatlari;
import tr.com.aktifbank.integration.ingaz.GunSonuYekunReturn;
import tr.com.aktifbank.integration.ingaz.services.IngazOnlineClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class IngazServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(IngazServices.class);

	@GraymoundService("ICS_INGAZ_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		int counter = 0;
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);

		String responseCode = "";
		String errorMessage = "";
		try {
			List<GazWebBorcReturn> borcList = IngazOnlineClient.getBorcSorgula(username, password, "", aboneNo, "", url);
			responseCode = borcList.get(0).getHataKodu();
			errorMessage = borcList.get(0).getHataAciklama();
			if (responseCode.equals("")) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
				for (int i = 0; i < borcList.size(); i++) {
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, aboneNo);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borcList.get(i).getTahakkukNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borcList.get(i).getGenelToplam());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "0");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borcList.get(i).getAdi().concat(" ").concat(borcList.get(i).getSoyadi()));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.convertToDate(borcList.get(i).getVade(), "dd/MM/yyyy", "yyyyMMdd",null));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borcList.get(i).getDonem().substring(0, 4));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borcList.get(i).getDonem().substring(4, 6));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borcList.get(i).getGenelToplam());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, borcList.get(i).getAciklama());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, errorMessage);
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
		}
		catch (Exception e) {
			logger.error("ICS_INGAZ_INVOICE_DEBT_INQUIRY -> An exception occured while executing ICS_INGAZ_INVOICE_DEBT_INQUIRY with map -> ".concat(iMap.toString()));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_INGAZ_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_DO_INVOICE_COLLECTION");
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);// banka
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);// sifre
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			List<GazWebTahsilatlari> tahsilatlar = new ArrayList<GazWebTahsilatlari>();
			GazWebTahsilatlari gwt = new GazWebTahsilatlari();
			gwt.setTahakkukId(iMap.getString(MapKeys.INVOICE_NO));
			if (iMap.containsKey(MapKeys.PAYMENT_DATE)) {
				gwt.setTahsilatTarihi(CommonHelper.formatDateString(iMap.getString(MapKeys.PAYMENT_DATE).substring(0, 8), "yyyyMMdd", "dd/MM/yyyy"));
			}
			else {
				gwt.setTahsilatTarihi(CommonHelper.getDateString(new Date(), "dd/MM/yyyy"));
			}
			gwt.setTahsilatTutari(iMap.getString(MapKeys.INVOICE_AMOUNT));
			tahsilatlar.add(gwt);

			String dekontNo = iMap.getString(MapKeys.TRX_NO);
			String cariIslemKodu = "12";
			GazWebTahsilatReturn response = IngazOnlineClient.getTahsilEt(username, password, tahsilatlar, dekontNo, cariIslemKodu, url);

			responseCode = response.getHataKodu();
			if (responseCode.equals("")) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter1(response.getMakbuzNo());

				session.saveOrUpdate(invoicePayment);
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
			else {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, response.getHataAciklama());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getHataAciklama());
			}
		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_INGAZ_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_INGAZ_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String kullaniciId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			GregorianCalendar c = new GregorianCalendar();
			c.setTime(new Date());
			GazWebTahsilatIptalReturn response = IngazOnlineClient.getTahsilIptal(kullaniciId, sifre, iMap.getString(MapKeys.TRX_NO), "Musteri Istegi", url);

			String responseCode = response.getHataKodu();
			if (!responseCode.equals("")) {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, response.getHataAciklama());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getHataAciklama());
			}
			else {
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_INGAZ_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_INGAZ_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_COLLECTION_RECONCILIATION");
			GregorianCalendar c = new GregorianCalendar();
			c.setTime(CommonHelper.getDateTime(CommonHelper.formatDateString(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd", "yyyy-MM-dd"), "yyyy-MM-dd"));
			XMLGregorianCalendar tarih = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

			String kullaniciId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			GunSonuYekunReturn response = IngazOnlineClient.getMutabakatIstek(kullaniciId, sifre, tarih, Integer.toString(collectionCount), collectionTotal.toString(), url);
			if (response.getHataKodu().equals("")) {
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getToplamAdet());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getToplamTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

				output.put(MapKeys.RECON_CORPORATE_COUNT, response.getToplamAdet());
				output.put(MapKeys.RECON_COLLECTION_TOTAL, response.getToplamTutar());

				if (Integer.parseInt(response.getToplamAdet()) == collectionCount && collectionTotal.compareTo(new BigDecimal(response.getToplamTutar())) == 0) {

					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					errorMessage = "Tahsilat tutarlari farkli!";
				}
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				output.put(MapKeys.ERROR_DESC, response.getHataAciklama());
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
		}
		catch (Throwable e) {
			logger.info("ICS_INGAZ_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_INGAZ_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			CollectionReconciliationDetailBatch batch = new IngazReconciliationDetailBatch(iMap);
			output = batch.runBatch();
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			output.put(MapKeys.ERROR_DESC, "Onay");
		}
		catch (Throwable e) {
			logger.info("ICS_INGAZ_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;

	}

	@GraymoundService("ICS_INGAZ_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_COLLECTION_RECONCILIATION_CLOSED");
		try {
			String kullaniciId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			GregorianCalendar c = new GregorianCalendar();
			c.setTime(CommonHelper.getDateTime(CommonHelper.formatDateString(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd", "yyyy-MM-dd"), "yyyy-MM-dd"));
			XMLGregorianCalendar tarih = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			GunSonuYekunReturn response = IngazOnlineClient.getMutabakatSorgu(kullaniciId, sifre, tarih, url);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getToplamTutar());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getToplamAdet());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			if (response.getHataKodu().equals("")) {
				// hata kodu bos geliyorsa islem basarili olmus demektir.
				output.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
			}
			else {
				output.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_INGAZ_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_INGAZ_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String errorMessage = "";
		try {
			String kullaniciId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			GazTalimatReturn response = IngazOnlineClient.talimatKayit(kullaniciId, sifre, aboneNo, url);

			if (response.getHataKodu().equals("")) {
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
			else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, response.getHataAciklama());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("STO_INGAZ_SEND_STANDING_ORDER_MESSAGE is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_INGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_INGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String errorMessage = "";
		try {
			String kullaniciId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			GazTalimatReturn response = IngazOnlineClient.talimatIptal(kullaniciId, sifre, aboneNo, url);

			if (response.getHataKodu().equals("")) {
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
			else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, response.getHataAciklama());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("STO_INGAZ_SEND_STANDING_ORDER_MESSAGE is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_INGAZ_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap debtInqueryForStandingOrders(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_INGAZ_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();

		try {
			String kullaniciId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int counter = 0;
			GregorianCalendar c = new GregorianCalendar();
			XMLGregorianCalendar vadeTarihi = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);

			List<GazWebBorcReturn> response = IngazOnlineClient.getTalimataliBorcluAboneler(kullaniciId, sifre, vadeTarihi, url);

			for (GazWebBorcReturn responseQuery : response) {
				if (!isCollectedInvoiceNo(responseQuery.getTahakkukNo(), corporateCode)) {
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, responseQuery.getAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, responseQuery.getTahakkukNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, responseQuery.getGenelToplam());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, "0");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE,  CommonHelper.convertToDate(responseQuery.getVade(), "dd/MM/yyyy", "yyyyMMdd",null));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, responseQuery.getDonem());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, responseQuery.getDonem());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, responseQuery.getAdi().concat(" ").concat(responseQuery.getSoyadi()));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
					counter++;
				}
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put(MapKeys.TABLE_SIZE, counter);
		}
		catch (Throwable e2) {
			logger.info("ICS_INGAZ	_DEBT_INQUERY_FOR_STANDING_ORDER -> hata meydana geldi.".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

}
