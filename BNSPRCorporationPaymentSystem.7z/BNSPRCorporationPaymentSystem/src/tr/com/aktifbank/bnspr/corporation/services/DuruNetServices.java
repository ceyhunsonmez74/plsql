package tr.com.aktifbank.bnspr.corporation.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class DuruNetServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(DuruNetServices.class);
	private static final String NO_RECORD_FOUND="0;";

	@GraymoundService("ICS_DURUNET_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
	
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DURUNET_INVOICE_DEBT_INQUIRY");
		String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String request=wsUrl+subscriberNo;
		String response="";
		try{

			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			  URL url = new URL(wsUrl+subscriberNo);
			  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
			  httpCon.setDoOutput(true);
			  httpCon.setDoInput(true);
			  httpCon.setUseCaches(false);

			  httpCon.setRequestMethod("GET");

			  
			  BufferedReader reader = new BufferedReader(new InputStreamReader(httpCon.getInputStream(), "UTF-8"));
		        response=reader.readLine();
		        reader.close();	
		        String[] splittedResponse = response.split(";");
		        
		        String invoiceNo=splittedResponse[0];
		        String subscriberName=splittedResponse[1];
		        String amount =splittedResponse[2];
		        String dueDateString=splittedResponse[3];

					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.SUBSCRIBER_NO1, subscriberNo);
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.AMOUNT, amount);
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.INVOICE_TERM_YEAR, dueDateString.substring(0,4));
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.INVOICE_TERM_MONTH, dueDateString.substring(5,7));
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.INVOICE_NO, invoiceNo);
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(dueDateString, "yyyy-MM-dd HH:mm:ss"));
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.SUBSCRIBER_NAME, subscriberName);
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.INSTALLMENT_NO, "");
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, 0, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, 0, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, 0, "OID", "0");

			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", request);
			output.put("RESPONSE_XML", response);
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	
	@GraymoundService("ICS_DURUNET_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DURUNET_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		String result = "";
		try {
			// parameters are taken

			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			String tutar=iMap.getString(MapKeys.PAYMENT_AMOUNT);
			String islemReferansNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String sonot = "";
			
//			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
//				tahsilatTarihi = iMap.getString(MapKeys.PAYMENT_DATE);
//			} else {
			sonot = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.INVOICE_DUE_DATE), "yyyyMMdd"), "yyyy-MM-dd HH:mm:ss");
//			}
			
			String aboneno = iMap.getString(MapKeys.SUBSCRIBER_NO1);

	
			ServiceMessage sm = new ServiceMessage();
			
			   URL url = new URL(serviceUrl);
	            URLConnection con = url.openConnection();
	            // activate the output
	            con.setDoOutput(true);
	            PrintStream ps = new PrintStream(con.getOutputStream());
	            // send your parameters to your site
	            ps.print("&aboneno="+aboneno);
	            ps.print("&faturano="+faturaNo);               
	            ps.print("&mutkodu="+islemReferansNo);
	            ps.print("&tutar="+tutar);
	            ps.print("&sonot="+sonot);
	            // we have to get the input stream in order to actually send the request
	            con.getInputStream();
	            BufferedReader is = new BufferedReader(new InputStreamReader(con.getInputStream()));
	    		String line;

	    		while ((line = is.readLine()) != null)
	    			result += line;
	    		
	    		System.out.println(result);

	            // close the print stream
	            ps.close();
	            
				
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", result);
			
			responceCodeMap = getResponseCodeMapping("ODENDI", iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));


			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	
	@GraymoundService("ICS_DURUNET_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			String response="";
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DURUNET_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String date = CommonHelper.getDateString(CommonHelper.getDateTime(reconDate, "yyyyMMdd"), "yyyy-MM-dd");

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_DURUNET_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(reconDate);
		    builder.append(" | End Point -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());
			
			ServiceMessage sm = new ServiceMessage();
			 URL url = new URL(serviceUrl+date);
			  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
			  httpCon.setDoOutput(true);
			  httpCon.setDoInput(true);
			  httpCon.setUseCaches(false);

			  httpCon.setRequestMethod("GET");

			  
			  BufferedReader reader = new BufferedReader(new InputStreamReader(httpCon.getInputStream(), "UTF-8"));
		        response=reader.readLine();
		        reader.close();	
		        if(NO_RECORD_FOUND.equals(response)){
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
		        }else{
		        	   String[] splittedResponse = response.split(";");
				        
				        String count=splittedResponse[0];
				        String amount=splittedResponse[1];
				    	output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, amount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, count);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
		        }
		     
		     
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());


			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_DURUNET_COLLECTION_RECONCILIATION - mutabakat basarili  ");
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_DURUNET_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	//Mutabakat Kapama
	@GraymoundService("ICS_DURUNET_COLLECTION_RECONCILIATION_CLOSED")
    public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
          GMMap output = new GMMap();
          
          iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DURUNET_COLLECTION_RECONCILIATION_CLOSED");
          
          try{
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
          }
          catch(Exception e){
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
                output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
                output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
                throw ExceptionHandler.convertException(e);
          }
          finally{
                insertOnlineServiceLog(iMap, output);
          }
          
          return output;
    }


}
