package tr.com.aktifbank.bnspr.corporation.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class FiberixServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(FiberixServices.class);
	private static final String NO_RECORD_FOUND="0";
	private static final String ODENDI = "�dendi";
	
	//Bor� Sorgulama
	@GraymoundService("ICS_FIBERIX_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_FIBERIX_INVOICE_DEBT_INQUIRY");
		String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String request=wsUrl+subscriberNo;
		String response="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			  URL url = new URL(wsUrl+subscriberNo);
			  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
			  httpCon.setDoOutput(true);
			  httpCon.setDoInput(true);
			  httpCon.setUseCaches(false);

			  httpCon.setRequestMethod("GET");

			  
			  BufferedReader reader = new BufferedReader(new InputStreamReader(httpCon.getInputStream(), "UTF-8"));
		        response=reader.readLine();
		        reader.close();	
		        String[] splittedResponse = response.split(",");
		        
//		        [0059729=F�BER�X M��TER�S�]
//		        M��teri numaras�=M��teri ismi
//		        [111=01.10.2020=22]
//		        Fatura numaras�=Son �deme tarihi=tutar
		        
		        String subs = splittedResponse[0];
		        String[] splittedSubs = subs.split("=");
		        String subNo = splittedSubs[0];
		        String replacedSubNo = subNo.replace("[", "");
		        String subName = splittedSubs[1];
		        String replacedSubName = subName.replace("]", "");
		        
		        int size = splittedResponse.length;
		        
		        
		        for(int i = 1; i<size; i++){
		        	String inv = splittedResponse[i];
		        	String[] splittedInv = inv.split("=");
		        	String invNo = splittedInv[0];
		        	String replacedInvNo = invNo.replace("[", "");
		        	String dueDate = splittedInv[1];
		        	String amnt = splittedInv[2];
		        	String replacedAmnt = amnt.replace("]", "");
		        
		        	SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy"); //"yyyy-MM-dd"
					Date date = inputFormat.parse(dueDate.replace(".", "-"));
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date);
					
					String termYear = "";
					String termMonth = "";
					
					int duelength = dueDate.length();
					try {
						termYear = dueDate.substring(6,10);
						termMonth = dueDate.substring(3,5);
					}
					catch (Exception e) {
						termYear = dueDate.substring(5,9);
						termMonth = dueDate.substring(2,4);
					}
		        
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.SUBSCRIBER_NO1, replacedSubNo);
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.AMOUNT, replacedAmnt);
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.INVOICE_TERM_YEAR, termYear);//04
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.INVOICE_TERM_MONTH, termMonth);//57
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.INVOICE_NO, replacedInvNo);
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.INVOICE_DUE_DATE, calendar.getTime());
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.SUBSCRIBER_NAME, replacedSubName);
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.INSTALLMENT_NO, "");
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.CORPORATE_CODE, corporateCode);
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.PAYMENT_TYPE, collectionType);
			        oMap.put(MapKeys.INVOICE_LIST, i-1, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					oMap.put(MapKeys.INVOICE_LIST, i-1, "SELECT", false);
					oMap.put(MapKeys.INVOICE_LIST, i-1, "OID", "0");

		        }
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", request);
			oMap.put("RESPONSE_XML", response);
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
	}
	
	//Tahsilat
	@GraymoundService("ICS_FIBERIX_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_FIBERIX_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		String result = "";
		
		try {
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
						
			ServiceMessage sm = new ServiceMessage();
			
			   URL url = new URL(serviceUrl+invoiceNo);
	            URLConnection con = url.openConnection();
	            // activate the output
	            con.setDoOutput(true);  
	            con.getInputStream();
	            BufferedReader is = new BufferedReader(new InputStreamReader(con.getInputStream()));
	    		String line;

	    		while ((line = is.readLine()) != null)
	    			result += line;
	    		
	    		System.out.println(result);

	            
				
			iMap.put("REQUEST_TXT", serviceUrl+invoiceNo);
			oMap.put("RESPONSE_TXT", result);

			responceCodeMap = getResponseCodeMapping(result, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
		
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_FIBERIX_DO_INVOICE_COLLECTION for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally{
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
	}
	
	//Mutabakat - Yap�lan �demeler
	@GraymoundService("ICS_FIBERIX_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		
		try {
			String response="";
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_FIBERIX_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String date = CommonHelper.getDateString(CommonHelper.getDateTime(reconDate, "yyyyMMdd"), "yyyy-MM-dd");

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_FIBERIX_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(reconDate);
		    builder.append(" | End Point -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());
			
			//https://fiberix.com.tr/firma/odemeler.asp?gun=30&ay=01&yil=2020
			String gun = date.substring(8,10);
			String ay = date.substring(5,7);
			String yil = date.substring(0,4);
			String queryStr = "?gun=" + gun + "&ay=" + ay + "&yil=" + yil;
			ServiceMessage sm = new ServiceMessage();
			 URL url = new URL(serviceUrl+queryStr);
			  HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
			  httpCon.setDoOutput(true);
			  httpCon.setDoInput(true);
			  httpCon.setUseCaches(false);

			  httpCon.setRequestMethod("GET");

			  
			  BufferedReader reader = new BufferedReader(new InputStreamReader(httpCon.getInputStream(), "UTF-8"));
		        response=reader.readLine();
		        reader.close();	
		        if(NO_RECORD_FOUND.equals(response)){
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
		        }else{
		        	   String[] splittedResponse = response.replace("<br>", "").split(",");
//		        	[111=01.10.2020=22]
//		        	Fatura numaras�=Son �deme tarihi=tutar
//		        	   [[0059729=FIBERIX MUSTERISI],[111=01.10.2020=22]<br>]
		        	   
		        	   Integer length = splittedResponse.length;
		        	   Integer corpTotalAmount = 0;
		        	   Integer corpTotalCount = 0;
		        	   
		        	   if(length > 1){
		        		   
		        		   for(int i = 1; i<length; i+=2){
		        			   String resp = splittedResponse[i];
		        			   String[] splittedResp = resp.split("=");
		        			   String amount = splittedResp[2].replace("]", "");
		        			   corpTotalAmount = corpTotalAmount + Integer.parseInt(amount);
		        			   corpTotalCount ++;
		        		   }
		        		   
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpTotalAmount);
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpTotalCount);
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
		        	   }
		        	   else{//�deme yok mesaj� veriyor kurum
		        		   oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
					        oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
		        	   }
		        }
		     
		     
			iMap.put("REQUEST_TXT", serviceUrl+queryStr);
			oMap.put("RESPONSE_TXT", response);


			if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && oMap.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == oMap.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& oMap.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == oMap.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_FIBERIX_COLLECTION_RECONCILIATION - mutabakat basarili  ");
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_FIBERIX_COLLECTION_RECONCILIATION - mutabakat hatali ");
			oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		
		return oMap;
		
	}
	
	//Mutabakat Kapama
	@GraymoundService("ICS_FIBERIX_COLLECTION_RECONCILIATION_CLOSED")
    public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
          GMMap output = new GMMap();
          
          iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_FIBERIX_COLLECTION_RECONCILIATION_CLOSED");
          
          try{
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
          }
          catch(Exception e){
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
                output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
                output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
                throw ExceptionHandler.convertException(e);
          }
          finally{
                insertOnlineServiceLog(iMap, output);
          }
          
          return output;
    }

}
