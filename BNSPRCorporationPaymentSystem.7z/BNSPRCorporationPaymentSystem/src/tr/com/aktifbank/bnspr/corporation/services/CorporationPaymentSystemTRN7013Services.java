package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.dao.CsReverseAccountingTx;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CorporationPaymentSystemTRN7013Services {

	@GraymoundService("BNSPR_TRN7013_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		Session session = DAOSession.getSession("BNSPRDal");

//		CsReverseAccountingTx csReverseAccountingTx = (CsReverseAccountingTx) session.createCriteria(CsReverseAccountingTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
//		if (csReverseAccountingTx == null)
//			csReverseAccountingTx = new CsReverseAccountingTx();
		
		CsReverseAccountingTx csReverseAccountingTx = new CsReverseAccountingTx();

		saveOrNot(iMap, session);

		csReverseAccountingTx.setDovizCinsi(iMap.getString("DOVIZ_CINSI"));
		csReverseAccountingTx.setFisAciklamasi(iMap.getString("FIS_ACIKLAMASI"));
		csReverseAccountingTx.setIslemAciklamasi1(iMap.getString("ISLEM_ACIKLAMA1"));
		csReverseAccountingTx.setIslemAciklamasi2(iMap.getString("ISLEM_ACIKLAMA2"));
		csReverseAccountingTx.setIslemAciklamasi3(iMap.getString("ISLEM_ACIKLAMA3"));
		csReverseAccountingTx.setRevTxNo(iMap.getBigDecimal("REV_TX_NO"));
		csReverseAccountingTx.setTutar(iMap.getBigDecimal("TUTAR"));
		csReverseAccountingTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		csReverseAccountingTx.setUserCode(iMap.getString("KULLANICI_KODU"));

		session.saveOrUpdate(csReverseAccountingTx);
		session.flush();
		
		iMap.put("TRX_NAME","7013");
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	}

	private static void saveOrNot(GMMap iMap, Session hibSession) {
		
		BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
		
		if ( txNo == null){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "Trx No alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		
		BigDecimal revTxNo = iMap.getBigDecimal("REV_TX_NO");
		
		invoicePayment paymentRecord = (invoicePayment) hibSession.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("txNo", revTxNo))
				.uniqueResult();
		
		if(paymentRecord != null){
			Date currentDate = new Date();
			if(paymentRecord.getPaymentDate().startsWith(CommonHelper.getShortDateTimeString(currentDate))){
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", String.format("%s i�lem numaral� �deme kayd� i�in ayn� g�n ters fi� kesilemez. L�tfen �deme iptali yap�n�z.", revTxNo));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		}
		else{
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", String.format("%s i�lem numaral� kay�t i�in �deme kayd� bulunamad�.", revTxNo));
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		
		if ( iMap.getBigDecimal("REV_TX_NO")== null){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "��lem Numaras� alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		if ( iMap.getBigDecimal("TUTAR") == null){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "Tutar alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		if ( StringUtil.isEmpty(iMap.getString("DOVIZ_CINSI"))){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "D�viz Cinsi alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		if ( StringUtil.isEmpty(iMap.getString("KULLANICI_KODU"))){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "Kullan�c� Kodu alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}	 
		if ( StringUtil.isEmpty(iMap.getString("FIS_ACIKLAMASI"))){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "Fi� A��klamas� alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		if ( StringUtil.isEmpty(iMap.getString("ISLEM_ACIKLAMA1"))){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "��lem 1 alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		if ( StringUtil.isEmpty(iMap.getString("ISLEM_ACIKLAMA2"))){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "��lem 2 alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		if ( StringUtil.isEmpty(iMap.getString("ISLEM_ACIKLAMA3"))){
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "��lem 2 alan� bo� girilemez!");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}		   
	}


	@GraymoundService("BNSPR_TRN7013_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");			
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");

			CsReverseAccountingTx csReverseAccountingTx = (CsReverseAccountingTx) session.createCriteria(CsReverseAccountingTx.class).add(Restrictions.eq("txNo" , txNo)).uniqueResult();
			session.flush();

			oMap.put("DOVIZ_CINSI", csReverseAccountingTx.getDovizCinsi());
			oMap.put("FIS_ACIKLAMASI", csReverseAccountingTx.getFisAciklamasi());
			oMap.put("ISLEM_ACIKLAMA1", csReverseAccountingTx.getIslemAciklamasi1());
			oMap.put("ISLEM_ACIKLAMA2", csReverseAccountingTx.getIslemAciklamasi2());
			oMap.put("ISLEM_ACIKLAMA3", csReverseAccountingTx.getIslemAciklamasi3());
			oMap.put("REV_TX_NO", csReverseAccountingTx.getRevTxNo());
			oMap.put("TUTAR", csReverseAccountingTx.getTutar());
			oMap.put("TRX_NO", csReverseAccountingTx.getTxNo());
			oMap.put("KULLANICI_KODU", csReverseAccountingTx.getUserCode());
			
			

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
		return oMap;
	}

	@GraymoundService("BNSPR_TRN7013_FILL")
	public static GMMap fill(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			String func = "{call PKG_TRN7013.Get_Cs_Accounting_Info(?,?,?,?,?,?,?,?)}";
			Object[] inputValues = new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_KOD")};
			Object[] outputValues = new Object[]{ BnsprType.STRING, "USER_CODE", BnsprType.NUMBER, "TUTAR",BnsprType.STRING, "DOVIZ_CINSI",
					BnsprType.STRING, "FIS_ACIKLAMASI",BnsprType.STRING, "ISLEM_ACIKLAMA1",BnsprType.STRING, "ISLEM_ACIKLAMA2",BnsprType.STRING, "ISLEM_ACIKLAMA3"};

			oMap =  (GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	//	@GraymoundService("BNSPR_TRN7013_INITIALIZE")
	//	public static GMMap initiazlize(GMMap iMap) {
	//
	//		GMMap oMap = new GMMap();
	//
	//
	//		try {
	//		
	//		}
	//		catch (Exception e) {
	//			throw ExceptionHandler.convertException(e);
	//		}
	//
	//		return oMap;
	//	}

}