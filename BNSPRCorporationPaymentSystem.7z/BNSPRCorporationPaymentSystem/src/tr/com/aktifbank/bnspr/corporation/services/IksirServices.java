package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.IksirReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.iksir.IksirClient;
import tr.com.aktifbank.integration.iksir.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.iksir.Bill;
import tr.com.iksir.InvoiceDebtInquiryResponse;
import tr.com.iksir.InvoiceDebtPaymentResponse;
import tr.com.iksir.LoginResponse;
import tr.com.iksir.PaymentCancelTechnicalResponse;
import tr.com.iksir.ReconciliationCloseResponse;
import tr.com.iksir.ReconciliationResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class IksirServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(IksirServices.class);

	private static final String RESPONSE_CODE_SUCCESS="2";
	private static final String RESPONSE_CODE_ERROR="0";
	private static final String BUSINESS_ERROR_CODE="660";

	
	@GraymoundService("ICS_IKSIR_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessageInvoice = new ServiceMessage();

		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_IKSIR_INVOICE_DEBT_INQUIRY");

		try{
			String errorMessage = "";

			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String pRODUCT_OID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String iksirChannel = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dealerCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String agentCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			ServiceMessage serviceMessageLogin = new ServiceMessage();
			LoginResponse  loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, username, password);
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			output.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  loginResponse.getResult().getRESPONSE_CODE();
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){

			String sessionId = loginResponse.getResult().getSessionId();

			String cLIENT_TRX_ID_RESERVED = loginResponse.getResult().getCORE_TRX_ID_RESERVED();
			String clientSessionId = loginResponse.getResult().getSessionId();
			String agentUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			InvoiceDebtInquiryResponse invoiceDebtInquiryResponse = IksirClient.invoiceDebtInquiry(serviceUrl, serviceMessageInvoice, sessionId, agentCode, agentUser, iksirChannel, clientSessionId, cLIENT_TRX_ID_RESERVED, dealerCode, pRODUCT_OID, subscriberNo1, subscriberNo2, subscriberNo3);
			
			
			iMap.put("REQUEST_XML", serviceMessageInvoice.getRequest());
			output.put("RESPONSE_XML", serviceMessageInvoice.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessageInvoice.getDuration(), serviceMessageInvoice.getStartTime(), serviceMessageInvoice.getEndTime());
			if (RESPONSE_CODE_ERROR.equals(invoiceDebtInquiryResponse.getResult().getRESPONSE_CODE())) {
				responseCode =  invoiceDebtInquiryResponse.getResult().getERROR_CODE();
			}
			errorMessage = invoiceDebtInquiryResponse.getResult().getRESPONSE_DATA();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				int counter = 0;
				for (Bill bill : invoiceDebtInquiryResponse.getResult().getBILL_LIST()) {

					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, subscriberNo2);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, subscriberNo3);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT,bill.getINVOICE_AMOUNT());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getBILL_DUE_DATE().substring(6,10));
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getBILL_DUE_DATE().substring(3,5));
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getBILL_NO());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(bill.getBILL_DUE_DATE().substring(0,10), "dd-MM-yyyy"));
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getSUBSCRIBER_NAME());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getINVOICE_AMOUNT());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getINV_PAYMENT_TRANSACTION_QUERY_OID());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, "");

					output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			else{
				if (BUSINESS_ERROR_CODE.equals(errorCode)) {
					errorMessage = invoiceDebtInquiryResponse.getResult().getRESPONSE_DATA();
					output.put(MapKeys.ERROR_DESC, errorMessage);
					output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
				}

			}
			
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessageInvoice.getRequest());
			output.put("RESPONSE_XML", serviceMessageInvoice.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_IKSIR_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IKSIR_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String errorMessage = "";

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String pRODUCT_OID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String iksirChannel = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dealerCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String agentCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

//			String pPaymentdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd HH:mm:ss");
//			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
//				pPaymentdate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd HH:mm:ss");
//			}
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			LoginResponse  loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, username, password);

			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  loginResponse.getResult().getRESPONSE_CODE();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){

			String sessionId = loginResponse.getResult().getSessionId();
			responseCode = loginResponse.getResult().getRESPONSE_CODE();
			String responseMessage = loginResponse.getResult().getRESPONSE_DATA();
			BigDecimal iNVOICE_AMOUNT = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			String agentUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			String pAYMENT_TYPE = "CASH";
			String cLIENT_TRX_ID_RESERVED = loginResponse.getResult().getCORE_TRX_ID_RESERVED();
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String clientSessionId = loginResponse.getResult().getSessionId();
			String iNV_PAYMENT_TRANSACTION_QUERY_OID = iMap.getString(MapKeys.PARAMETER1);
			InvoiceDebtPaymentResponse  response = IksirClient.invoiceDebtPayment(serviceUrl, serviceMessage, sessionId, agentCode, agentUser, iksirChannel, clientSessionId, cLIENT_TRX_ID_RESERVED, dealerCode, pAYMENT_TYPE, iNV_PAYMENT_TRANSACTION_QUERY_OID, iNVOICE_AMOUNT, paymentAmount);
			
			if (RESPONSE_CODE_ERROR.equals(response.getResult().getRESPONSE_CODE())) {
				responseCode =  response.getResult().getERROR_CODE();
			}
				responseMessage = response.getResult().getRESPONSE_DATA();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(response.getResult().getPAYMENT_LIST().get(0).getTRANSACTION_ID());
				session.saveOrUpdate(invoicePayment);
			}else {
				if (BUSINESS_ERROR_CODE.equals(errorCode)) {
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responseMessage);
				}
			}

		}
			
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_IKSIR_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IKSIR_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		String errorMessage = "";

		try {

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String pRODUCT_OID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String iksirChannel = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dealerCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String agentCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);



			String tRANSACTION_ID = iMap.getString(MapKeys.PARAMETER_2);

			ServiceMessage serviceMessageLogin = new ServiceMessage();
			LoginResponse  loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, username, password);
	
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  loginResponse.getResult().getRESPONSE_CODE();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				String sessionId = loginResponse.getResult().getSessionId();
	
				String cANCEL_DESCRIPTION = iMap.getString("REJECTED_REASON");
				String agentUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
				String cLIENT_TRX_ID_RESERVED = loginResponse.getResult().getCORE_TRX_ID_RESERVED();
				String clientSessionId = loginResponse.getResult().getSessionId();
				PaymentCancelTechnicalResponse response = IksirClient.paymentCancelTechnical(serviceUrl, serviceMessage, sessionId, agentCode, agentUser, iksirChannel, clientSessionId, cLIENT_TRX_ID_RESERVED, dealerCode, tRANSACTION_ID, cANCEL_DESCRIPTION);

				if (RESPONSE_CODE_ERROR.equals(response.getResult().getRESPONSE_CODE())) {
					responseCode =  response.getResult().getERROR_CODE();
				}
				String 	responseMessage = response.getResult().getRESPONSE_DATA();
				
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					if (BUSINESS_ERROR_CODE.equals(errorCode)) {
					errorMessage = response.getResult().getRESPONSE_DATA();
					outMap.put(MapKeys.ERROR_DESC, errorMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
					}
				}
			}
			
			
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	

	
	
	@GraymoundService("ICS_IKSIR_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IKSIR_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		GMMap responceCodeMap = new GMMap();

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String productOid = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String iksirChannel = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dealerCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String agentCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			String reconDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				reconDate= CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				reconDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			LoginResponse  loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, username, password);
	
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  loginResponse.getResult().getRESPONSE_CODE();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				
				String cANCEL_DESCRIPTION = iMap.getString("REJECTED_REASON");
				String agentUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
				String cLIENT_TRX_ID_RESERVED = loginResponse.getResult().getCORE_TRX_ID_RESERVED();
				String clientSessionId = loginResponse.getResult().getSessionId();
				String sessionId = loginResponse.getResult().getSessionId();

				ReconciliationResponse response = IksirClient.reconciliation(serviceUrl, serviceMessage, sessionId, agentCode, agentUser, iksirChannel, clientSessionId, cLIENT_TRX_ID_RESERVED, dealerCode, productOid, reconDate);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				if (RESPONSE_CODE_ERROR.equals(response.getResult().getRESPONSE_CODE())) {
					responseCode =  response.getResult().getERROR_CODE();
				}
				
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(StringUtils.isBlank(response.getResult().getPAYMENT_AMOUNT()) ? "0" : response.getResult().getPAYMENT_AMOUNT()));
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, new BigDecimal(StringUtils.isBlank(response.getResult().getPAYMENT_COUNT()) ? "0" : response.getResult().getPAYMENT_COUNT()));
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, new BigDecimal(StringUtils.isBlank(response.getResult().getPAYMENT_CANCEL_COUNT()) ? "0" : response.getResult().getPAYMENT_CANCEL_COUNT()));
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(StringUtils.isBlank(response.getResult().getPAYMENT_CANCEL_AMOUNT()) ? "0" : response.getResult().getPAYMENT_CANCEL_AMOUNT()));
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				}

				if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {

					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IKSIR_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_IKSIR_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_IKSIR_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		GMMap responceCodeMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String productOid = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String iksirChannel = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dealerCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String agentCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			String reconDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				reconDate= CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				reconDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			LoginResponse  loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, username, password);
	
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  loginResponse.getResult().getRESPONSE_CODE();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				String pAYMENT_COUNT = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
				String pAYMENT_CANCEL_COUNT = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
				String pAYMENT_AMOUNT = reconBankMap.getString(MapKeys.RECON_COLLECTION_TOTAL);
				String pAYMENT_CANCEL_AMOUNT = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				
				String agentUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
				String cLIENT_TRX_ID_RESERVED = loginResponse.getResult().getCORE_TRX_ID_RESERVED();
				String clientSessionId = loginResponse.getResult().getSessionId();
				String sessionId = loginResponse.getResult().getSessionId();

				ReconciliationCloseResponse response = IksirClient.closeReconciliation(serviceUrl, serviceMessageLogin, sessionId, agentCode, agentUser, iksirChannel, clientSessionId, cLIENT_TRX_ID_RESERVED, dealerCode, productOid, reconDate, pAYMENT_COUNT, pAYMENT_AMOUNT, pAYMENT_CANCEL_AMOUNT, pAYMENT_CANCEL_COUNT);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				if (RESPONSE_CODE_ERROR.equals(response.getResult().getRESPONSE_CODE())) {
					responseCode =  response.getResult().getERROR_CODE();
				}
				
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			// Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IKSIR_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_IKSIR_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		logger.info("ICS_IKSIR_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GOKNET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new IksirReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_IKSIR_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_IKSIR_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IKSIR_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subscriberNo1="";
			String subscriberNo2="";
			String subscriberNo3="";

				if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
					subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				}
				if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2))) {
					subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
				}
				if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO3))) {
					subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3);
				}

			logger.info("STO_IKSIR_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" subscriberNo1 -> ").concat(subscriberNo1)
					.concat(" - ").concat(" subscriberNo2 -> ").concat(subscriberNo2).concat(" - ").concat(" subscriberNo3 -> ").concat(subscriberNo3));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_IKSIR_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_IKSIR_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_IKSIR_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String subscriberNo1="";
		String subscriberNo2="";
		String subscriberNo3="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
				subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2))) {
				subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			}
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO3))) {
				subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			}
	
			logger.info("STO_IKSIR_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(subscriberNo1)
					.concat(" - ").concat(" subscriberNo2 -> ").concat(subscriberNo2).concat(" - ").concat(" subscriberNo3 -> ").concat(subscriberNo3));

			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_IKSIR_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_IKSIR_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_IKSIR_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();
			
			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				GMMap queryMap = new GMMap();
				queryMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				queryMap.put(MapKeys.SUBSCRIBER_NO2, icsStandingOrder.getSubscriberNo2());
				queryMap.put(MapKeys.SUBSCRIBER_NO3, icsStandingOrder.getSubscriberNo3());
	
				queryMap.put(MapKeys.BANK_CODE, iMap.getString(MapKeys.BANK_CODE));
				queryMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				queryMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
				queryMap.put(MapKeys.GM_SERVICE_NAME, "ICS_SEARCH_INVOICE");
				queryMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
				GMMap invoiceMap = new GMMap();
				try {
					debtLoadingMap = (GMMap) GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", queryMap);
				} catch (GMRuntimeException e) {
					logger.info("ICS_IKSIR_DEBT_INQUERY_FOR_STANDING_ORDER -> borc sorgulama servisi hata aldi".concat(e.getMessage()));
					logger.error("An exception occured while ICS_IKSIR_DEBT_INQUERY_FOR_STANDING_ORDER ->  on Borc Sorgulama services");
					logger.error(System.currentTimeMillis(), e);
					e.printStackTrace();
					debtLoadingMap.put(MapKeys.ERROR_DESC, e.getMessage());
					debtLoadingMap.put(MapKeys.ERROR_CODE, 9999);
				}
			
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					Date currentDate = new Date();

					int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						String dueDateString = debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE);
						if(!StringUtil.isEmpty(dueDateString)){
							Date dueDate = debtLoadingMap.getDate("INVOICES",j,MapKeys.INVOICE_DUE_DATE);

							if(isDueDateBeforeCurrentDate(dueDate, currentDate)){
								continue;
							}
						}
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO4));

						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(debtLoadingMap.getDate("INVOICES",j,MapKeys.INVOICE_DUE_DATE)));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IKSIR_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	private static boolean isDueDateBeforeCurrentDate(Date dueDate, Date currentDate) {
		long date = Long.valueOf(CommonHelper.getShortDateTimeString(dueDate));
		long curDate = Long.valueOf(CommonHelper.getShortDateTimeString(currentDate));
		
		return curDate > date;
	}
}
