package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.List;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.PatnosWaterReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.patnos.PatnosClient;
import tr.com.aktifbank.integration.patnos.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.patnos.ArrayOfBeanBorcTahsilat;
import tr.com.patnos.ArrayOfBeanTahsilatRapor;
import tr.com.patnos.BeanBorcSorgu;
import tr.com.patnos.BeanBorcTahsilat;
import tr.com.patnos.BeanBorclar;
import tr.com.patnos.BeanSonuc;
import tr.com.patnos.BeanTahsilatIptal;
import tr.com.patnos.BeanTahsilatIptalSonuc;
import tr.com.patnos.BeanTahsilatRapor;
import tr.com.patnos.BeanTahsilatRaporSorgu;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class PatnosWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	


	private static final Log logger = LogFactory.getLog(PatnosWaterServices.class);

	@GraymoundService("ICS_PATNOS_WATER_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		int counter = 0;
		String responseCode = "";
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		long bankaKodu = Long.parseLong(username);
		long aboneKodu = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
		ServiceMessage serviceMessage = new ServiceMessage();
		
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
		
		try {
			BeanBorcSorgu debtInquiryResult = PatnosClient.borcSuSorgu(reqTimeout, connTimeout, bankaKodu, password, aboneKodu, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			responseCode = Integer.toString(debtInquiryResult.getHataKodu());
			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responseCode)) {
				List<BeanBorclar> borcList = debtInquiryResult.getBorclar().getBeanBorclar();
				for (int i = 0; i < borcList.size(); i++) {
					BeanBorclar borc = borcList.get(i);
						String termYear = Integer.toString(borc.getDonemBorcYili());
						String termMonth = "";
						String invoiceYear = Integer.toString(borc.getSonOdemeTarihiYil());
						String invoiceMonth = Integer.toString(borc.getSonOdemeTarihiAy());
						String invoiceDay = Integer.toString(borc.getSonOdemeTarihiGun());
						if (invoiceMonth.length() == 1) {
							invoiceMonth = "0".concat(invoiceMonth);
						}
						if (invoiceDay.length() == 1) {
							invoiceDay = "0".concat(invoiceDay);
						}
						String invoiceDueDate = invoiceYear.concat(invoiceMonth).concat(invoiceDay);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, Long.toString(aboneKodu));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getBorcId());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "0");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtInquiryResult.getMukellef().getAdi().concat(" ").concat(debtInquiryResult.getMukellef().getSoyadi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getAciklama());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, borc.getBankaHesapGrubu());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borc.getBorcCesidi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borc.getBorcCesidiAdi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, borc.getGecikme());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtInquiryResult.getIslemNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtInquiryResult.getSicilKodu());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, debtInquiryResult.getTahsilatTarihiGun());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, debtInquiryResult.getTahsilatTarihiAy());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, debtInquiryResult.getTahsilatTarihiYil());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER12, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
				}
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
			else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, debtInquiryResult.getHataAciklama().concat("-").concat(responseCode));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, debtInquiryResult.getHataAciklama());
			}
		}
		catch (Exception e) {
			logger.error("ICS_PATNOS_WATER_INVOICE_DEBT_INQUIRY -> An exception occured while executing ICS_PATNOS_WATER_INVOICE_DEBT_INQUIRY with map -> ".concat(iMap.toString()));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_PATNOS_WATER_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_DO_INVOICE_COLLECTION");
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);// banka
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);// sifre
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			long bankaKodu = new Long(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			ServiceMessage serviceMessage = new ServiceMessage();
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
			
			ArrayOfBeanBorcTahsilat borcTahsilatArray= new ArrayOfBeanBorcTahsilat();
			
			BeanBorcTahsilat borc = new BeanBorcTahsilat();
			borc.setBorc(iMap.getBigDecimal(MapKeys.PARAMETER5));
			borc.setBorcId(iMap.getLong(MapKeys.INVOICE_NO));
			borc.setGecikme(iMap.getBigDecimal(MapKeys.PARAMETER6));
			borc.setIslemNo(iMap.getString(MapKeys.PARAMETER7));
			borc.setSicilKodu(iMap.getLong(MapKeys.PARAMETER8));
			borc.setTahsilatReferansNo(iMap.getString(MapKeys.TRX_NO));
			borc.setTahsilatTarihiGun(iMap.getInt(MapKeys.PARAMETER9));
			borc.setTahsilatTarihiAy(iMap.getInt(MapKeys.PARAMETER10));
			borc.setTahsilatTarihiYil(iMap.getInt(MapKeys.PARAMETER11));
			borc.setToplam(iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT));
			borcTahsilatArray.getBeanBorcTahsilat().add(borc);
			
			BeanSonuc tahsilat = PatnosClient.borcTahsilat(reqTimeout, connTimeout, bankaKodu, borcTahsilatArray, sifre, username, password, url, serviceMessage);
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responseCode = Integer.toString(tahsilat.getHataKodu());
			if (responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter20(Long.toString(tahsilat.getMakbuzNo()));
				session.saveOrUpdate(invoicePayment);
				outMap.put("MAKBUZ_NO", tahsilat.getMakbuzNo());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_CODE, responseCode);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
			else {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, tahsilat.getHataAciklama());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, tahsilat.getHataAciklama());
			}
		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_PATNOS_WATER_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_PATNOS_WATER_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			long bankaKodu = new Long(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			ServiceMessage serviceMessage = new ServiceMessage();
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
			
			BeanTahsilatIptal iptalTahsilat = new BeanTahsilatIptal();
			iptalTahsilat.setIptalNedeni("Musteri_Istegi");
			iptalTahsilat.setIslemNo(iMap.getString(MapKeys.PARAMETER_7));
			iptalTahsilat.setMakbuzNo(iMap.getLong(MapKeys.PARAMETER_20));
			iptalTahsilat.setTahsilatReferansNo(iMap.getString(MapKeys.TRX_NO));
			iptalTahsilat.setTahsilatTarihiGun(iMap.getInt(MapKeys.PARAMETER_9));
			iptalTahsilat.setTahsilatTarihiAy(iMap.getInt(MapKeys.PARAMETER_10));
			iptalTahsilat.setTahsilatTarihiYil(iMap.getInt(MapKeys.PARAMETER_11));
			
			BeanTahsilatIptalSonuc response = PatnosClient.tahsilatIptal(reqTimeout, connTimeout, bankaKodu, iptalTahsilat, password, username, password, url, serviceMessage);
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			String responseCode = Integer.toString(response.getHataKodu());
			if (!responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, response.getHataAciklama());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getHataAciklama());
			}
			else {
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch (Exception e) {
			logger.error("An exception occured while executing ICS_PATNOS_WATER_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_PATNOS_WATER_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_PATNOS_WATER_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		try {
			ArrayOfBeanTahsilatRapor detailsArray;
			List<BeanTahsilatRapor> details;
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_COLLECTION_RECONCILIATION");
			String tarih = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();
			BeanTahsilatRaporSorgu rapor = new BeanTahsilatRaporSorgu();
			int tahsilatBtsTarihiGun = Integer.parseInt(tarih.substring(6, 8));
			int tahsilatBslTarihiGun = Integer.parseInt(tarih.substring(6, 8));
			int tahsilatBslTarihiAy = Integer.parseInt(tarih.substring(4, 6));
			int tahsilatBtsTarihiAy = Integer.parseInt(tarih.substring(4, 6));
			int tahsilatBslTarihiYil = Integer.parseInt(tarih.substring(0, 4));
			int tahsilatBtsTarihiYil = Integer.parseInt(tarih.substring(0, 4));
			rapor.setTahsilatBslTarihiAy(tahsilatBslTarihiAy);
			rapor.setTahsilatBslTarihiGun(tahsilatBslTarihiGun);
			rapor.setTahsilatBslTarihiYil(tahsilatBslTarihiYil);
			rapor.setTahsilatBtsTarihiAy(tahsilatBtsTarihiAy);
			rapor.setTahsilatBtsTarihiGun(tahsilatBtsTarihiGun);
			rapor.setTahsilatBtsTarihiYil(tahsilatBtsTarihiYil);
			BigDecimal result = PatnosClient.tahsilatSuRaporOzet(reqTimeout, connTimeout, Long.parseLong(username), rapor, password, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
			int iptalAdet = 0;
			BigDecimal iptalTutar = new BigDecimal("0");
			int tahsilatAdet = 0;
			BigDecimal tahsilatTutar = new BigDecimal("0");
			detailsArray = PatnosClient.tahsilatSuRaporDetay(reqTimeout, connTimeout, Long.parseLong(username), rapor, password, username, password, url, serviceMessage);
			details=detailsArray.getBeanTahsilatRapor();
			for (int i = 0; i < details.size(); i++) {
				if (details.get(i).isIptal()) {
					iptalAdet++;
					iptalTutar = iptalTutar.add(details.get(i).getToplam());
				}
				else {
					tahsilatAdet++;
					tahsilatTutar = tahsilatTutar.add(details.get(i).getToplam());
				}
			}
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, tahsilatTutar);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, tahsilatAdet);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, iptalTutar);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, iptalAdet);
			if (tahsilatTutar.compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && iptalTutar.compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && tahsilatAdet == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && iptalAdet == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Tahsilat tutarlari farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_PATNOS_WATER_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_PATNOS_WATER_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			CollectionReconciliationDetailBatch batch = new PatnosWaterReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			output.put(MapKeys.ERROR_DESC, "Onay");
		}
		catch (Throwable e) {
			logger.info("ICS_PATNOS_WATER_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;

	}

	@GraymoundService("ICS_PATNOS_WATER_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap input) {
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME, "ICS_PATNOS_WATER_COLLECTION_RECONCILIATION_CLOSED");
		try {
			String screenRecon = input.getString("SCREEN_RECONCILIATION", "");
			String reconDate = input.getString(MapKeys.RECON_DATE);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			if (screenRecon.equals("1")) {
				setCollectionInfoToOutput(output, reconDate, corporateCode, session);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(input, output);
		}
		return output;
	}



}
