package tr.com.aktifbank.bnspr.corporation.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Junction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporationdefinition.services.CorporationDefinitionServices;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CalculateTransferDates;
import tr.com.aktifbank.bnspr.cps.transactions.ControlSectorActivenessHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CorporateAccountControlHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CorporateChannelWorkingHourControlHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetCorporateChannelDefinitionsHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetCorporateCommissionDefHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetCorporatesHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetDatabaseFieldsHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetSectorDefinitionHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetServiceFieldsHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetSubscriberMetadataHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertBalanceTransferLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertBalanceTransferProcessHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.AccountCollectionTypeRel;
import tr.com.aktifbank.bnspr.dao.BalanceTransferLog;
import tr.com.aktifbank.bnspr.dao.BalanceTransferProcess;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDef;
import tr.com.aktifbank.bnspr.dao.CollectionTypeDef;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.CorporateAccountBlockedLog;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.CorporateMasterTx;
import tr.com.aktifbank.bnspr.dao.CorporateServices;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.aktifbank.bnspr.dao.invoicePaymentLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CommonCorporationServices {

	private static final Log logger = LogFactory.getLog(CommonCorporationServices.class);

	@GraymoundService("CDM_CORPORATE_CHANNEL_WORKINGHOUR_CONTROL")
	public static GMMap corporateChannelWorkingHourControl(GMMap input) {
		return RequestProcessor.getInstance().process(input, new CorporateChannelWorkingHourControlHandler());
	}

	@GraymoundService("CDM_CORPORATE_ACCOUNT_CONTROL")
	public static GMMap corporateAccountControl(GMMap input) {
		return RequestProcessor.getInstance().process(input, new CorporateAccountControlHandler());
	}

	@GraymoundService("CDM_GET_CORPORATE_SERVICE_BOUND_GMSERVICE")
	public static GMMap getCorporateServiceBoundGmService(GMMap input) {
		GMMap outMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			@SuppressWarnings("unchecked")
			List<CorporateServices> cm = (List<CorporateServices>) session.createCriteria(CorporateServices.class)
					.add(Restrictions.eq("corporateCode", input.getString("CORPORATE_CODE")))
					.add(Restrictions.eq("gmServiceName", input.getString("GM_SERVICE_NAME"))).add(Restrictions.eq("status", true)).uniqueResult();

			outMap.put("WEB_SERVICE", cm.get(0).getWebServiceName());
			outMap.put("IS_SAF_SERVICE", cm.get(0).getIsSafService());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_COMMON_GET_COLLECTION_TYPE_INFO")
	public static GMMap getCollectionTypeInfo(GMMap input) {
		GMMap output = new GMMap();
		try {
			String corporateOid = input.getString(TransactionConstants.GetCollectionTypeInfo.Input.CORPORATE_OID, null);
			String corporateCode = input.getString(TransactionConstants.GetCollectionTypeInfo.Input.CORPORATE_CODE, null);
			String ct = input.getString(TransactionConstants.GetCollectionTypeInfo.Input.COLLECTION_TYPE);
			Short collectionType = null;
			if(ct != null)
				collectionType = Short.parseShort(ct);

			if (StringUtil.isEmpty(corporateOid)) {
				GMMap getCorporateDefinitionRequest = new GMMap();
				getCorporateDefinitionRequest.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
				GMMap getCorporateDefinitionResponse = CommonHelper.callGraymoundServiceInHibernateSession(
						TransactionConstants.GetCorporateDefinition.SERVICE_NAME, getCorporateDefinitionRequest);
				corporateOid = getCorporateDefinitionResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
			}

			Session session = DAOSession.getSession("BNSPRDal");
			Criteria c = session.createCriteria(CollectionTypeDef.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateOid", corporateOid));
			if(collectionType != null)
					c.add(Restrictions.eq("collectionType", collectionType));
			
			List<CollectionTypeDef> cm = c.list();
			
			if (cm != null && cm.size() > 0) {
				output.put(TransactionConstants.GetCollectionTypeInfo.Output.ALLOW_AUTO_COLLECTION, cm.get(0).isAllowAutoCollection());
				return output;
			} else {
				output.put(TransactionConstants.GetCollectionTypeInfo.Output.ALLOW_AUTO_COLLECTION, false);
				return output;
			}

		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}

	@GraymoundService("CDM_GET_CORPORATE_COMMISSION_DEF")
	public static GMMap getCorporateCommissionDef(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetCorporateCommissionDefHandler());
	}

	@GraymoundService("CDM_COMMON_GET_SECTOR_DEFINITION")
	public static GMMap getSectorDefinition(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetSectorDefinitionHandler());
	}

	@GraymoundService("CDM_COMMON_CONTROL_SECTOR_ACTIVENESS")
	public static GMMap controlSectorActiveness(GMMap input) {
		return RequestProcessor.getInstance().process(input, new ControlSectorActivenessHandler());
	}

	@GraymoundService("CDM_COMMON_GET_CORPORATES_FRONTEND")
	public static GMMap getCorporatesFrontend(GMMap input) {
		GMMap output = new GMMap();
		try {
			StringBuilder s = new StringBuilder();
//			s.append("SELECT m.oid, m.corporate_name\n");
//			s.append("FROM   cdm.corporate_master m INNER JOIN cdm.corporate_city_rel c ON m.oid = c.corporate_oid\n");
//			s.append("WHERE  m.status=1 AND c.status = 1 AND (c.is_public_corporate = 1 OR c.kod = %s)\n");
//			s.append("ORDER BY m.corporate_name");
			s.append(QueryRepository.CommonCorporationServicesRepository.GET_CORPORATES_FRONTED);
			GMMap corporateList = DALUtil.getResults(String.format(s.toString(), input.getString("IL_KOD")), "CORPORATES");
			for (int i = 0; i < corporateList.getSize("CORPORATES"); i++) {
				GuimlUtil.wrapMyCombo(output, "CORPORATES", (String) corporateList.get("CORPORATES", i, "OID"),
						(String) corporateList.get("CORPORATES", i, "CORPORATE_NAME"));
			}
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}

		return output;
	}

	@GraymoundService("CDM_COMMON_GET_COLLECTION_TYPES_FRONTEND")
	public static GMMap getCollectionTypes(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = "COLLECTION_TYPES";
			String allowAutoCollection = input.getString("ALLOW_AUTO_COLLECTION", null);
			boolean doNotControlUseForCollection = input.getBoolean("DO_NOT_CONTROL_COLLECTION", false);
			String isAppearancePaymentScreen = input.getString("APPEARANCE_PAYMENT_SCREEN", null);
			StringBuilder builder = new StringBuilder();
//			builder.append("SELECT ctp.collection_type, ctp.collection_name FROM cdm.collection_type_def ctd INNER JOIN ");
//			builder.append("cdm.collection_type_prm ctp ON ctd.collection_type = ctp.collection_type ");
			builder.append(String.format(QueryRepository.CommonCorporationServicesRepository.GET_COLLECTION_TYPES_FRONTED, input.getString("CORPORATE_CODE"),allowAutoCollection,isAppearancePaymentScreen));
			if (!doNotControlUseForCollection) {
				builder.append(" AND EXISTS(select * from cdm.subscriber_mask_detail smdet where smdet.mask_oid in "
						+ "(select OID from cdm.subscriber_mask_def smdef where smdef.collection_type=ctd.collection_type and smdef.status=1 and smdef.corporate_oid=ctd.corporate_oid) "
						+ "and status=1 and use_for_collection='1')");
			}
			GMMap collectionTypeList = DALUtil.getResults(builder.toString(), tableName);

			if (collectionTypeList.getSize(tableName) == 0) {
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEXISTINGCOLLECTIONTYPE));
			}

			if (input.getString("EMPTY_KEY") != null && input.getBoolean("EMPTY_KEY")) {
				GuimlUtil.wrapMyCombo(output, tableName, null, "Hepsi");
			}
			int startIndex = 0;

			if (input.getBoolean("ADD_INVOICE_COLLECTION_AS_DEFAULT", false)) {
				boolean invoiceCollectionFound = false;
				for (int i = 0; i < collectionTypeList.getSize(tableName); i++) {
					if (collectionTypeList.getString(tableName, i, "COLLECTION_TYPE").equals(DatabaseConstants.CollectionTypes.InvoiceLoad)) {
						invoiceCollectionFound = true;
						break;
					}
				}
				if (!invoiceCollectionFound) {
					output.put(tableName, startIndex, "VALUE", DatabaseConstants.CollectionTypes.InvoiceLoad);
					output.put(tableName, startIndex, "NAME", "Fatura �deme");
					startIndex++;
				}
			}

			for (int i = startIndex; i < collectionTypeList.getSize(tableName); i++) {
				GuimlUtil.wrapMyCombo(output, tableName, ((BigDecimal) collectionTypeList.get(tableName, i, "COLLECTION_TYPE")).toString(),
						(String) collectionTypeList.get(tableName, i, "COLLECTION_NAME"));
			}
			
			output.put("DEFAULT_VALUE", output.getString(tableName, 0, "VALUE"));

		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		output.put("COLLECTION_TYPE_EXISTS", true);
		return output;
	}

	@GraymoundService("CDM_COMMON_GET_SUBSCRIBER_METADATA_FRONTEND")
	public static GMMap getSubscriberMetadataFrontEnd(GMMap input) {
		GMMap output = new GMMap();
		try {
			String corporateOid = input.getString("CORPORATE_OID");
			int collectionTypeNumber = Integer.parseInt(input.getString("COLLECTION_TYPE_NUMBER"));
			String callerScreen = input.getString("CALLER_SCREEN");

			GMMap subscriberInput = new GMMap();
			subscriberInput.put(TransactionConstants.GetSubscriberMetadata.Input.CORPORATE_OID, corporateOid);
			subscriberInput.put(TransactionConstants.GetSubscriberMetadata.Input.COLLECTION_TYPE, collectionTypeNumber);
			subscriberInput.put(TransactionConstants.GetSubscriberMetadata.Input.CALLER_SCREEN, callerScreen);

			GMMap subscriberResult = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetSubscriberMetadata.SERVICE_NAME,
					subscriberInput);

			int counter = 1;
			for (int i = 0; i < subscriberResult.getSize(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE); i++) {
				int index = subscriberResult.getInt(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						TransactionConstants.GetSubscriberMetadata.Output.INDEX);
				output.put(String.format("SUBSCRIBER_%s_LABEL", index), subscriberResult.getString(
						TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						TransactionConstants.GetSubscriberMetadata.Output.LABEL));
				output.put(String.format("SUBSCRIBER_%s_MASK", index), subscriberResult.getString(
						TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						TransactionConstants.GetSubscriberMetadata.Output.MASK));
				output.put(String.format("SUBSCRIBER_%s_PATTERN", index), subscriberResult.getString(
						TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						TransactionConstants.GetSubscriberMetadata.Output.PATTERN));
				output.put(String.format("SUBSCRIBER_%s_EXAMPLE", index), subscriberResult.getString(
						TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						TransactionConstants.GetSubscriberMetadata.Output.EXAMPLE));
				output.put(String.format("SUBSCRIBER_%s_VISIBLE", index), true);
				output.put(String.format("SUBSCRIBER_%s_LENGTH", index), subscriberResult.getString(
						TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						TransactionConstants.GetSubscriberMetadata.Output.LENGTH));
				output.put(String.format("SUBSCRIBER_%s_VISIBLE_IMAGE_OID", index), subscriberResult.getString(
						TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i,
						"IMAGE_OID"));
				counter++;
			}
			if (counter != 5) {
				for (int i = counter; i < 5; i++) {
					output.put(String.format("SUBSCRIBER_%s_LABEL", i), "");
					output.put(String.format("SUBSCRIBER_%s_MASK", i), "-");
					output.put(String.format("SUBSCRIBER_%s_PATTERN", i), "#");
					output.put(String.format("SUBSCRIBER_%s_EXAMPLE", i), "");
					output.put(String.format("SUBSCRIBER_%s_VISIBLE", i), false);
					output.put(String.format("SUBSCRIBER_%s_LENGTH", i), 0);
					output.put(String.format("SUBSCRIBER_%s_VISIBLE_IMAGE_OID", i), "");
				}
			}
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		output.put("SUBSCRIBER_PATTERN_FOUND", true);
		return output;
	}
	
	@GraymoundService("CDM_COMMON_GET_SUBSCRIBER_IMAGE")
	public static GMMap getSubscriberImage(GMMap input) {
		GMMap output = new GMMap();
		try {
			output.put("INVOICE_IMAGE",CorporationDefinitionServices.loadInvoiceImage(input.getString("IMAGE_OID"), ""));
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		output.put("SUBSCRIBER_PATTERN_FOUND", true);
		return output;
	}
	
	@GraymoundService("CDM_CMN_GET_CITIES_FRONTEND")
	public static GMMap getCities(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String tableName = "CITIES";
			GMMap output = DALUtil.getResults(QueryRepository.CommonCorporationServicesRepository.GET_CMN_CITIES_FRONTED, tableName);

			for (int i = 0; i < output.getSize(tableName); i++) {
				GuimlUtil.wrapMyCombo(outMap, tableName, output.get(tableName, i, "KOD").toString(), output.get(tableName, i, "IL_ADI").toString());
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_COMMON_GET_SOURCES_FRONTEND")
	public static GMMap getSourceParams(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String tableName = "SOURCES";
			String channelCode = CommonHelper.getChannelId();
			String corporateOid = iMap.getString("CORPORATE_OID");
			List<String> sourceCodeList = new ArrayList<String>();
			
			Session session = CommonHelper.getHibernateSession();
			Criteria criteria = session.createCriteria(ChannelSourceDef.class).add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("channelCode", channelCode));
			
			List<ChannelSourceDef> channelSourceDefList = criteria.list();
			if (channelSourceDefList != null && channelSourceDefList.size() != 0) {
				for (ChannelSourceDef channelSourceDef : channelSourceDefList) {
					if (!sourceCodeList.contains(channelSourceDef.getSourceCode()))
						sourceCodeList.add(channelSourceDef.getSourceCode());
				}
			}
			
			StringBuilder sql = new StringBuilder();
			String sourceCode = " ";
			SQLQuery sqlQuery = null;
			
			
			if (sourceCodeList != null && sourceCodeList.size() > 0) {
				sourceCode = sourceCodeList.get(0);
				sql.append(QueryRepository.CommonCorporationServicesRepository.COMMON_GET_SOURCES_FRONTED);
				sqlQuery = (SQLQuery) session.createSQLQuery(sql.toString());
				sqlQuery.setParameter("sourceCode", sourceCode);
				if (sourceCodeList.size() > 1) {
					for (int i = 1; i < sourceCodeList.size(); i++) {
						sql.append(" OR source_code = :sourceCode" + i);
						String sourceCodeSqlParam = "sourceCode" + i;
						sqlQuery = (SQLQuery) session.createSQLQuery(sql.toString());
						sqlQuery.setParameter("sourceCode", sourceCode);
						sqlQuery.setParameter(sourceCodeSqlParam, sourceCodeList.get(i));
					}

				}

			}
			
			List<Object[]> queryResultList = sqlQuery.list();
			System.out.println("queryResult size = " + queryResultList.size());
			
			for (int i = 0; i < queryResultList.size(); i++) {
				Object[] queryResult = queryResultList.get(i);
				GuimlUtil.wrapMyCombo(outMap, tableName, queryResult[0].toString(), queryResult[1].toString());
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return outMap;
	}

	@GraymoundService("CDM_COMMON_GET_SOURCE_ACCOUNT_FRONTEND")
	public static GMMap getSourceAccountParam(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String tableName = "SOURCES";
			GMMap output = DALUtil.getResults(QueryRepository.CommonCorporationServicesRepository.COMMON_GET_SOURCE_ACCOUNT_FRONTED+ DatabaseConstants.SourceCodes.Account, tableName);

			for (int i = 0; i < output.getSize(tableName); i++) {
				GuimlUtil.wrapMyCombo(outMap, tableName, output.get(tableName, i, "SOURCE_CODE").toString(), output.get(tableName, i, "SOURCE_NAME")
						.toString());
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return outMap;
	}

	@GraymoundService("CDM_COMMON_GET_DATABASE_FIELDS")
	public static GMMap getDatabaseFields(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetDatabaseFieldsHandler());
	}

	@GraymoundService("CDM_COMMON_GET_SERVICE_FIELDS")
	public static GMMap getServiceFields(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetServiceFieldsHandler());
	}

	@GraymoundService("CDM_COMMON_GET_CORPORATE_CHANNEL_DEFINITIONS")
	public static GMMap getCorporateChannelDefinitions(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetCorporateChannelDefinitionsHandler());
	}

	@GraymoundService("CDM_GET_CORPORATES")
	public static GMMap getCorporates(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetCorporatesHandler());
	}

	@GraymoundService("CDM_GET_SUBSCRIBER_METADATA")
	public static GMMap getSubscriberMetadata(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetSubscriberMetadataHandler());
	}

	@GraymoundService("CDM_INSERT_BALANCE_TRANSFER_PROCESS")
	public static GMMap insertBalanceTransferProcess(GMMap input) {
		return RequestProcessor.getInstance().process(input, new InsertBalanceTransferProcessHandler());
	}

	@GraymoundService("CDM_INSERT_BALANCE_TRANSFER_LOG")
	public static GMMap insertBalanceTransferLog(GMMap input) {
		return RequestProcessor.getInstance().process(input, new InsertBalanceTransferLogHandler());
	}

	@GraymoundService("CDM_QUERY_BALANCE_TRANSFER_PROCESS")
	public static GMMap queryBalanceProcessLog(GMMap input) {
		GMMap oMap = new GMMap();
		String tableName = "BALANCE_TRANSFER_TABLE";
		try {
			
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("SELECT btp.oid, cm.short_code as CORPORATE_CODE, DECODE(btp.transfer_status, 0, 'Bekliyor', 1, '��leniyor', 2, 'Ba�ar�l�', 3, 'Hata Ald�', '4', 'Tahsilat Bulunamad�', 'Bilinmiyor') ");
			queryBuilder.append("AS TRANSFER_STATUS, btp.transfer_amount, TO_CHAR(TO_DATE(btp.process_date, 'YYYYMMDDHH24MISS'), 'HH24:MI:SS DD/MM/YYYY') AS PROCESS_DATE, ");
			queryBuilder.append("TO_CHAR(TO_DATE(btp.collection_date, 'YYYYMMDD'), 'DD/MM/YYYY') AS COLLECTION_DATE, ");
			queryBuilder.append("TO_CHAR(TO_DATE(btp.transfer_date, 'YYYYMMDD'), 'DD/MM/YYYY') AS TRANSFER_DATE, ");
			queryBuilder.append("btp.from_account, btp.to_account, btp.to_iban, btp.to_iban_owner, DECODE(btp.is_eft_transfer, '0', 'Hay�r', '1', 'Evet', 'Evet') as IS_EFT_TRANSFER, ");
			queryBuilder.append("btp.tx_no, btp.transfer_type ");
			queryBuilder.append("FROM cdm.balance_transfer_process btp LEFT JOIN cdm.corporate_master cm ON btp.corporate_code=cm.corporate_code ");
			queryBuilder.append("WHERE btp.status=1 AND cm.status=1");

			if (input.getString("CORPORATE_CODE") != null) {
				if (!input.getString("CORPORATE_CODE").isEmpty()) {
					queryBuilder.append(String.format(" AND btp.corporate_code='%s'", input.getString("CORPORATE_CODE")));
				}
			}

			if (input.getString("COLLECTION_DATE") != null) {
				queryBuilder.append(String.format(" AND btp.collection_date='%s'", input.getString("COLLECTION_DATE")));
			}

			if (input.getString("TRANSFER_DATE") != null) {
				queryBuilder.append(String.format(" AND btp.transfer_date='%s'", input.getString("TRANSFER_DATE")));
			}

			if (input.getString("TRANSFER_STATUS") != null) {
				if (input.getString("TRANSFER_STATUS").equals("99")) {
					
				} else {
					queryBuilder.append(String.format(" AND btp.transfer_status=%s", input.getString("TRANSFER_STATUS")));
				}
			}

			queryBuilder.append(" ORDER BY cm.short_code asc");
			
			oMap = DALUtil.getResults(queryBuilder.toString(), tableName);
		} catch (Exception e) {
			return null;
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_COMMON_GET_CORPORATE_SOURCES_FRONTEND")
	public static GMMap getCorporateSources(GMMap iMap) {
		GMMap outMap = new GMMap();
		Session session = CommonHelper.getHibernateSession();
		try {
			String corporateOid = iMap.getString("CORPORATE_OID");
			Short collectionType = Short.valueOf(iMap.getString("COLLECTION_TYPE"));
			String channelId = iMap.getString("CHANNEL_ID", null);

			if (StringUtil.isEmpty(channelId)) {
				channelId = CommonHelper.getChannelId();
			}

			List<CorporationAccountMaster> accountList = session.createCriteria(CorporationAccountMaster.class).add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateOid", corporateOid))
					.add(Restrictions.eq("accountType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount)).list();

			Criteria criteria = session.createCriteria(AccountCollectionTypeRel.class).add(Restrictions.eq("status", true))
					.add(Restrictions.eq("collectionType", collectionType)).add(Restrictions.eq("channelCode", channelId));

			Junction orQuery = Restrictions.disjunction();

			for (CorporationAccountMaster master : accountList) {
				orQuery.add(Restrictions.eq("accountMasterOid", master.getOid()));
			}

			criteria = criteria.add(orQuery);

			List<AccountCollectionTypeRel> sourceList = criteria.list();

			List<String> sourceCodes = new ArrayList<String>();

			for (AccountCollectionTypeRel source : sourceList) {
				if (!sourceCodes.contains(source)) {
					sourceCodes.add(source.getSourceCode());
				}
			}

			if (sourceCodes.size() > 0) {
				StringBuilder query = new StringBuilder();
				query.append(QueryRepository.CommonCorporationServicesRepository.COMMON_GET_CORPORATE_SOURCE_FRONTED);

				int counter = 0;

				for (String source : sourceCodes) {
					query.append(String.format("source_code = '%s'", source));
					if (counter++ != sourceCodes.size()) {
						query.append(" OR ");
					}
				}

				String tableName = "SOURCES";
				GMMap output = DALUtil.getResults(query.toString(), tableName);
				for (int i = 0; i < output.getSize(tableName); i++) {
					GuimlUtil.wrapMyCombo(outMap, tableName, output.get(tableName, i, "SOURCE_CODE").toString(),
							output.get(tableName, i, "SOURCE_NAME").toString());
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return outMap;
	}

	@GraymoundService("CDM_GET_PAYMENT_TRANSACTION_DETAILS")
	public static GMMap getPaymentTransactionDetails(GMMap input) {
		GMMap output = new GMMap();

		try {

			GMMap colorMap = new GMMap();
			colorMap.put("setBackground", Color.WHITE);
			colorMap.put("setForeground", Color.BLACK);

			final String INVOICES = "INVOICES";
			final String PROPERTIES = "PROPERTIES";

			Session session = CommonHelper.getHibernateSession();

			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			invoicePaymentLog logRecord = (invoicePaymentLog) session.createCriteria(invoicePaymentLog.class).add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txNo", trxNo)).uniqueResult();

			if (logRecord != null) {
				String corporateCode = logRecord.getCorporateCode();
				Short collectionType = logRecord.getCollectionType();

				BigDecimal totalAmount = new BigDecimal(0);

				String collectionTypeName = ((CollectionTypePrm) session.createCriteria(CollectionTypePrm.class)
						.add(Restrictions.eq("collectionType", collectionType)).uniqueResult()).getCollectionName();

				GMMap getCorporateDefinitionResponse = CommonHelper.callGraymoundServiceInHibernateSession(
						TransactionConstants.GetCorporateDefinition.SERVICE_NAME,
						new GMMap().put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode));

				GMMap getSectorDefinitionResponse = CommonHelper.callGraymoundServiceInHibernateSession(
						TransactionConstants.GetSectorDefinition.SERVICE_NAME,
						new GMMap().put(TransactionConstants.GetSectorDefinition.Input.SECTOR_CODE,
								getCorporateDefinitionResponse.getString(TransactionConstants.GetCorporateDefinition.Output.SECTOR_CODE)));

				GMMap subscriberMetadataResponse = CommonHelper.callGraymoundServiceInHibernateSession(
						"CDM_COMMON_GET_SUBSCRIBER_METADATA_FRONTEND",
						new GMMap().put("CORPORATE_OID",
								getCorporateDefinitionResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID)).put(
								"COLLECTION_TYPE_NUMBER", (int) collectionType));

				output.put("CORPORATE_NAME",
						getCorporateDefinitionResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME));
				output.put("SECTOR_NAME", getSectorDefinitionResponse.getString(TransactionConstants.GetSectorDefinition.Output.SECTOR_NAME));
				output.put("COLLECTION_TYPE", collectionTypeName);

				for (int i = 1; i < 5; i++) {
					output.put(String.format("SUBSCRIBER_%s_LABEL", i), subscriberMetadataResponse.getString(String.format("SUBSCRIBER_%s_LABEL", i)));
					output.put(String.format("SUBSCRIBER_%s_EXAMPLE", i),
							subscriberMetadataResponse.getString(String.format("SUBSCRIBER_%s_EXAMPLE", i)));
					output.put(String.format("SUBSCRIBER_%s_VISIBLE", i),
							subscriberMetadataResponse.getString(String.format("SUBSCRIBER_%s_VISIBLE", i)));
					String subscriberText = null;
					if (i == 1) {
						subscriberText = logRecord.getSubscriberNo1();
					} else if (i == 2) {
						subscriberText = logRecord.getSubscriberNo2();
					} else if (i == 3) {
						subscriberText = logRecord.getSubscriberNo3();
					} else {
						subscriberText = logRecord.getSubscriberNo4();
					}

					output.put(String.format("SUBSCRIBER_%s_TEXT", i), subscriberText);
				}

				Date dueDate = CommonHelper.getDateTime(logRecord.getInvoiceDueDate(), "yyyyMMdd");

				String subscriberNo = logRecord.getSubscriberNo1();
				if (!StringUtil.isEmpty(logRecord.getSubscriberNo2())) {
					subscriberNo += " " + logRecord.getSubscriberNo2();
				}
				if (!StringUtil.isEmpty(logRecord.getSubscriberNo3())) {
					subscriberNo += " " + logRecord.getSubscriberNo3();
				}
				if (!StringUtil.isEmpty(logRecord.getSubscriberNo4())) {
					subscriberNo += " " + logRecord.getSubscriberNo4();
				}

				output.put(INVOICES, 0, "COLLECTION_AMOUNT", logRecord.getPaymentAmount());
				totalAmount = totalAmount.add(logRecord.getPaymentAmount());
				if (logRecord.getCommissionAmount() != null) {
					BigDecimal commissionAmount = logRecord.getCommissionAmount();
					if (logRecord.getBsmvAmount() != null) {
						commissionAmount = commissionAmount.add(logRecord.getBsmvAmount());
					}
					output.put(INVOICES, 0, "COMMISSION_AMOUNT", commissionAmount);
					totalAmount = totalAmount.add(commissionAmount);
				} else {
					output.put(INVOICES, 0, "COMMISSION_AMOUNT", 0);
				}
				output.put(INVOICES, 0, "CORPORATE_CODE", corporateCode);
				output.put(INVOICES, 0, "CORPORATE_NAME",
						getCorporateDefinitionResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME));
				output.put(INVOICES, 0, "INVOICE_AMOUNT", logRecord.getInvoiceAmount());
				output.put(INVOICES, 0, "INVOICE_DUE_DATE", dueDate);
				output.put(INVOICES, 0, "INVOICE_NO", logRecord.getInvoiceNo());
				String month = logRecord.getTermMonth();
				String year = logRecord.getTermYear();
				output.put(INVOICES, 0, "INVOICE_TERM_MONTH", month);
				output.put(INVOICES, 0, "INVOICE_TERM_YEAR", year);
				String term = (StringUtil.isEmpty(year) ? "" : year) + (StringUtil.isEmpty(month) ? "" : month);
				output.put(INVOICES, 0, "INVOICE_TERM", term);
				output.put(INVOICES, 0, "PAYMENT_TYPE_NAME", collectionTypeName);
				output.put(INVOICES, 0, "PAYMENT_TYPE", collectionType);
				output.put(INVOICES, 0, "SUBSCRIBER_NAME", logRecord.getSubscriberName());
				output.put(INVOICES, 0, "SUBSCRIBER_NO", subscriberNo);
				output.put(INVOICES, 0, "SELECT", true);
				output.put(INVOICES, 0, "OID", logRecord.getOid());
				output.put(INVOICES, 0, "ALLOW_PART_PAYMENT",
						getCorporateDefinitionResponse.getBoolean(TransactionConstants.GetCorporateDefinition.Output.ALLOW_PART_PAYMENT));
				output.put(INVOICES, 0, "STATE_TEXT", "�denecek");

				output.put(PROPERTIES, 0, "COLLECTION_AMOUNT", colorMap);
				output.put(PROPERTIES, 0, "COMMISSION_AMOUNT", colorMap);
				output.put(PROPERTIES, 0, "CORPORATE_CODE", colorMap);
				output.put(PROPERTIES, 0, "CORPORATE_NAME", colorMap);
				output.put(PROPERTIES, 0, "INVOICE_AMOUNT", colorMap);
				output.put(PROPERTIES, 0, "INVOICE_DUE_DATE", colorMap);
				output.put(PROPERTIES, 0, "INVOICE_NO", colorMap);
				output.put(PROPERTIES, 0, "INVOICE_TERM_MONTH", colorMap);
				output.put(PROPERTIES, 0, "INVOICE_TERM_YEAR", colorMap);
				output.put(PROPERTIES, 0, "INVOICE_TERM", colorMap);
				output.put(PROPERTIES, 0, "PAYMENT_TYPE_NAME", colorMap);
				output.put(PROPERTIES, 0, "PAYMENT_TYPE", colorMap);
				output.put(PROPERTIES, 0, "SUBSCRIBER_NAME", colorMap);
				output.put(PROPERTIES, 0, "SUBSCRIBER_NO", colorMap);
				output.put(PROPERTIES, 0, "SELECT", colorMap);
				output.put(PROPERTIES, 0, "OID", colorMap);
				output.put(PROPERTIES, 0, "ALLOW_PART_PAYMENT", colorMap);
				output.put(PROPERTIES, 0, "STATE_TEXT", colorMap);

				String paymentSource = logRecord.getSourceCode();

				//String query = "SELECT source_name FROM cdm.source_param WHERE source_code = '" + paymentSource + "'";
				String query = String.format(QueryRepository.CommonCorporationServicesRepository.GET_SOURCE_PARAM, paymentSource);

				String sourceName = DALUtil.getResult(query);

				output.put("PAYMENT_SOURCE", sourceName);
				output.put("PAYMENT_SOURCE_CODE", paymentSource);
				output.put("TOTAL_AMOUNT", totalAmount);

				if (paymentSource.equals(DatabaseConstants.SourceCodes.Account)) {
					output.put("CUSTOMER_NO", logRecord.getPayerCustomer());
					output.put("ACCOUNT_NO", logRecord.getPaymentAccountNo());
					output.put("IBAN", logRecord.getIban());
					output.put("BRANCH", logRecord.getBranchCode());
					output.put("NAME", logRecord.getPayerName());
					output.put("BALANCE", logRecord.getAccountBalance());
					output.put("AVAILABLE_BALANCE", logRecord.getAccountAvailableBalance());
					output.put("CURRENCY", logRecord.getAccountCurrencyCode());
				}

				output.put("PHONE", logRecord.getPayerPhone());
				output.put("ID", logRecord.getPayerPidno());
				output.put("TAX_NO", logRecord.getPayerTaxNo());
			} else {
				CommonHelper.throwBusinessException(BusinessException.NOPAYMENTRECORDFOUND.getCode(), trxNo);
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return output;
	}

	@GraymoundService("CDM_RESUBMIT_MANUEL_BATCH")
	public static GMMap resubmitBatch(GMMap input) {
		GMMap output = new GMMap();
		try {
			String serviceName = input.getString("SERVICE_NAME");
			String parameters = input.getString("PARAMETERS");
			boolean isBankingInstanceSelected = input.getBoolean("BANK_INSTANCE_SELECTED");
			GMMap request = getRequest(parameters);
			if (!isBankingInstanceSelected) {
				GMMap batchRemoteSubmitRequest = new GMMap();
				batchRemoteSubmitRequest.put("INPUT_MAP", request);
				batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", serviceName);
				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT",
						batchRemoteSubmitRequest);
			} else {
				GMServiceExecuter.executeAsync(serviceName, request);
			}

			output.put("MESSAGE", "Servis ba�ar�l� bir �ekilde �al��t�r�lm��t�r.");
		} catch (Exception e) {
			ExceptionHandler.convertException(e);
			output.put("MESSAGE", e.toString());
		}

		return output;
	}

	@GraymoundService("CDM_GET_BATCH_RESUBMIT_SERVICES")
	public static GMMap getBatchResubmitServices(GMMap input) {
		GMMap output = new GMMap();
		try {
			GMMap tempOutput = CorporationServiceUtil.getComboValues(new GMMap().put("KOD", "CDM_BATCH_RESUBMIT_SERVICES"));

			for (int i = 0; i < tempOutput.getSize("RESULTS"); i++) {
				output.put("RESULTS", i, "NAME", tempOutput.getString("RESULTS", i, "VALUE"));
				output.put("RESULTS", i, "VALUE", tempOutput.getString("RESULTS", i, "NAME"));
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return output;
	}

	private static GMMap getRequest(String parameters) {
		GMMap request = new GMMap();
		if (!StringUtil.isEmpty(parameters)) {
			List<String> keyValuePairs = Arrays.asList(parameters.split("#"));
			for (String pair : keyValuePairs) {
				String[] keyValue = pair.split("=");
				request.put(keyValue[0], keyValue[1]);
			}
		}
		return request;
	}

	@GraymoundService("CDM_SEND_CORPORATE_INFORMATION_AFTER_APPROVAL")
	public static GMMap sendEmailAfterCorporateApproval(GMMap input) {
		GMMap output = new GMMap();

        try {

               Session hibernate = CommonHelper.getHibernateSession();
               String userID = CommonHelper.getCurrentUser();
               BigDecimal trxNo = input.getBigDecimal("ISLEM_NO");

               CorporateMasterTx masterTx = (CorporateMasterTx) hibernate.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("txNo", trxNo)).list().get(0);

               String corporateCode = masterTx.getCorporateCode();

               @SuppressWarnings("unchecked")
               List<BalanceTransferProcess> balanceTransferProcessList = hibernate.createCriteria(BalanceTransferProcess.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).add(Restrictions.eq("transferStatus", new Byte("0"))).list();

               CorporateMaster masterRecord = (CorporateMaster) hibernate.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).uniqueResult();

               CorporateMasterTx formerTxRecord = (CorporateMasterTx) hibernate.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.lt("txNo", trxNo)).setMaxResults(1).addOrder(Order.desc("txNo")).uniqueResult();

               if (formerTxRecord != null && formerTxRecord.getCorporateActiveness().equals(DatabaseConstants.CorporateActiveness.Active) && masterTx.getCorporateActiveness().equals(DatabaseConstants.CorporateActiveness.Passive)) {
                      StringBuilder updateQuery = new StringBuilder();
                      updateQuery.append("UPDATE ICS.INVOICE_MAIN ");
                      updateQuery.append("SET STATUS=0 ");
                      updateQuery.append(String.format("WHERE STATUS=1 AND CORPORATE_CODE='%s' AND PAYMENT_STATUS='B' AND STANDING_ORDER_OID is not null", corporateCode));

                      hibernate.createSQLQuery(updateQuery.toString()).executeUpdate();
               }
               if (balanceTransferProcessList != null) {
                      StringBuilder updateQuery = new StringBuilder();
                      updateQuery.append("UPDATE cdm.balance_transfer_process");
                      updateQuery.append(" SET status=0 ");
                      updateQuery.append(String.format(" WHERE corporate_code='%s' AND status=1 AND transfer_status=0", corporateCode));

                      hibernate.createSQLQuery(updateQuery.toString()).executeUpdate();
               }
               for (BalanceTransferProcess balanceTransferProcess : balanceTransferProcessList) {
                      GMMap balanceiMap = new GMMap();
                      balanceiMap.put(CalculateTransferDates.Input.COLLECTION_DATE, balanceTransferProcess.getCollectionDate());
                      balanceiMap.put(CalculateTransferDates.Input.CORPORATE_CODE, balanceTransferProcess.getCorporateCode());
                      balanceiMap.put("TRANSFER_TYPE", balanceTransferProcess.getTransferType());
					  if(balanceTransferProcess.getTransferType().equals(DatabaseConstants.AccountTransferTypes.BlockedAccountTransfer)){
					  	  balanceiMap.put("FROM_ACCOUNT_TYPE", DatabaseConstants.AccountDefinitionTypes.BlockedAccount);
					  }
                      GMServiceExecuter.call("CDM_CALCULATE_TRANSFER_DATES", balanceiMap);
               }
               int countOfTxTable = ((Number) hibernate.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("txStatus", "N")).setProjection(Projections.rowCount()).uniqueResult()).intValue();
               
               StringBuilder sb=new StringBuilder();
               List<WebServices> webServiceList=hibernate.createCriteria(WebServices.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).list();
               for (WebServices webServices : webServiceList) {
            	   sb.append(webServices.getWsEndPoint()).append("<br/>");
            	   if(StringUtils.isNotBlank(webServices.getParameter3()))
            		   sb.append(webServices.getParameter3()).append("<br/>");
               }
               

               if (countOfTxTable == 1) {
                      String emailList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_CORP_AFTER_APPROVAL");
                      CommonHelper.sendMail(Arrays.asList(emailList.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Yeni Kurum Tan�m�", String.format(
                                   "<html><head></head><body>Merhaba<br /><br/>Yeni kurum tan�mlamas� onaylanm��t�r. Kurum bilgileri a�a��daki gibidir:<br/><br/>" + "<b>Kurum Ad� :</b> %s<br/>" + "<b>Kurum Kodu :</b> %s<br/>"
                                                 + "<b>Kurum Id :</b> %s<br><br><b>Onaylayan : </b> %s <br><br><b>��lem Referans�</b> : %s  <br><br><b>Web Servis Url:</b> %s </body></html>", masterRecord.getShortCode(), masterRecord.getCorporateCode(), masterRecord.getOid().concat("|~|KFT_CORPORATE_OID"), userID, trxNo.toString(),sb.toString()));
               } else {
                      String emailList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_CORP_EVERY_AFTER_APPROVAL");
                      CommonHelper.sendMail(Arrays.asList(emailList.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Kurum Tan�m� Onay�", String.format("<html><head></head><body>Merhaba<br /><br/>Kurum tan�m� onaylanm��t�r<br/><br/>" + "<b>Kurum Ad� :</b> %s<br/>"
                                   + "<b>Kurum Kodu :</b> %s<br/>" + "<b>Kurum Id :</b> %s<br><br><b>Onaylayan : </b> %s <br><br><b>��lem Referans�</b>: %s  <br><br><b>Web Servis Url:</b> %s </body></html>", masterRecord.getShortCode(), masterRecord.getCorporateCode(), masterRecord.getOid().concat("|~|KFT_CORPORATE_OID"), userID, trxNo.toString(),sb.toString()));
               }

        } catch (Exception e) {
               logger.error("An exception occured while sending email after corporate approval");
               logger.error(System.currentTimeMillis(), e);
        }

        return output;

	}

	@GraymoundService("CDM_CHECK_ACCOUNT_BLOCK_STATUS")
	public static GMMap checkAccountBlockStatus(GMMap input) {
		GMMap oMap = new GMMap();
		BigDecimal accountNumber = input.getBigDecimal("ACCOUNT_NUMBER");
		String corporateCode = input.getString("CORPORATE_CODE");
		try {
			GMMap accountOutput = CommonHelper.callGraymoundServiceOutsideSession("CDM_GET_CORPORATE_ACCOUNT_BLOCKED_LOGS", 
					new GMMap()
						.put("ACCOUNT_NUMBER", accountNumber)
						.put("CORPORATE_CODE", corporateCode));
			
			CorporateAccountBlockedLog cabl = checkAndGetBlockedLog(accountOutput, accountNumber);
			
			if (cabl != null) {
				if (DatabaseConstants.CorporateAccountBlockStatuses.Blocked.equals(cabl.getBlockedStatus())) {
					oMap.put("STATUS_LABEL", "Blokeli");
				}
				if (DatabaseConstants.CorporateAccountBlockStatuses.BlockFailed.equals(cabl.getBlockedStatus())) {
					oMap.put("STATUS_LABEL", "Bloke Konulurken Hata Al�nd�");
				}
				if (DatabaseConstants.CorporateAccountBlockStatuses.Blocking.equals(cabl.getBlockedStatus())) {
					oMap.put("STATUS_LABEL", "Bloke koyma i�lemi devam ediyor");
				}
				if (DatabaseConstants.CorporateAccountBlockStatuses.Unblocked.equals(cabl.getBlockedStatus())) {
					oMap.put("STATUS_LABEL", "Bloke Yok");
				}
				if (DatabaseConstants.CorporateAccountBlockStatuses.UnblockFailed.equals(cabl.getBlockedStatus())) {
					oMap.put("STATUS_LABEL", "Bloke kald�rma s�ras�nda hata olu�tu");
				}
				if (DatabaseConstants.CorporateAccountBlockStatuses.Unblocking.equals(cabl.getBlockedStatus())) {
					oMap.put("STATUS_LABEL", "Bloke kald�rma i�lemi devam ediyor");
				}
				if (DatabaseConstants.CorporateAccountBlockStatuses.Blocked.equals(cabl.getBlockedStatus())
						|| DatabaseConstants.CorporateAccountBlockStatuses.UnblockFailed.equals(cabl.getBlockedStatus())) {
					oMap.put("IS_BLOCKED", "YES");
				} else {
					oMap.put("IS_BLOCKED", "NO");
				}
			} else {
				oMap.put("STATUS_LABEL", "Bloke Yok");
			}
		} catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static CorporateAccountBlockedLog checkAndGetBlockedLog(GMMap blockedList, BigDecimal accountNumber) throws Exception {
		final String TABLE_NAME = "BLOCKED_TABLE";
		//String blockQuery = "SELECT BLOKE_NEDEN_KODU, REF_TX_NO FROM BNSPR.MUH_BLOKE WHERE HESAP_NO=%s AND DURUM_KODU='A'";
		String blockQuery = QueryRepository.CommonCorporationServicesRepository.BLOCK_QUERY;
		//String blockQueryWithReasonCode = "SELECT BLOKE_NEDEN_KODU, REF_TX_NO FROM BNSPR.MUH_BLOKE WHERE HESAP_NO=%s AND DURUM_KODU='A' AND BLOKE_NEDEN_KODU='16'";
		String blockQueryWithReasonCode = QueryRepository.CommonCorporationServicesRepository.BLOCK_QUERY_WITH_REASON;
		if(blockedList.getSize(TABLE_NAME) == 1){
			GMMap blockedLog = CommonHelper.getSingleDimensionMap(blockedList, TABLE_NAME, 0);
			GMMap results = DALUtil.getResults(String.format(blockQuery, accountNumber), TABLE_NAME);
			boolean errorExists = false;
			int blockCount = 0;
			for (int i = 0; i < results.getSize(TABLE_NAME); i++) {
				if(results.getString(TABLE_NAME, i, "BLOKE_NEDEN_KODU").equals("16")){
					blockCount++;
					if(!blockedLog.getString("BLOCK_REFERENCE").equals(results.getString(TABLE_NAME, i, "REF_TX_NO"))){
						errorExists = true;
					}
				}
				else{
					continue;
				}
			}
			if(!errorExists){
				if(blockCount != 1){
					CommonHelper.callGraymoundServiceOutsideSession("CDM_SET_CORPORATE_ACCOUNT_BLOCKED_STATUS_INACTIVE",
							new GMMap()
								.put("BLOCK_REFERENCE", blockedLog.getString("BLOCK_REFERENCE")));
					if(blockCount == 0){
						return null;
					}
					else{
						CommonHelper.throwBusinessException(BusinessException.UNBLOCKALLANDTRYAGAIN.getCode());
					}
				}
				else{
					CorporateAccountBlockedLog log = new CorporateAccountBlockedLog();
					log.setBlockedStatus(DatabaseConstants.CorporateAccountBlockStatuses.Blocked);
					return log;
				}
			}
			else{
				CommonHelper.callGraymoundServiceOutsideSession("CDM_SET_CORPORATE_ACCOUNT_BLOCKED_STATUS_INACTIVE",
						new GMMap()
							.put("BLOCK_REFERENCE", blockedLog.getString("BLOCK_REFERENCE")));
				CommonHelper.throwBusinessException(BusinessException.UNBLOCKALLANDTRYAGAIN.getCode());
			}
		}
		else{
			if(blockedList.getSize(TABLE_NAME) == 0){
				GMMap results = DALUtil.getResults(String.format(blockQueryWithReasonCode, accountNumber), TABLE_NAME);
				if(results.getSize(TABLE_NAME) > 0){
					CommonHelper.throwBusinessException(BusinessException.UNBLOCKALLANDTRYAGAIN.getCode());
				}
				else{
					return null;
				}
			}
			else{
				for (int i = 0; i < blockedList.getSize(TABLE_NAME); i++) {
					GMMap blockedLog = CommonHelper.getSingleDimensionMap(blockedList, TABLE_NAME, i);
					CommonHelper.callGraymoundServiceOutsideSession("CDM_SET_CORPORATE_ACCOUNT_BLOCKED_STATUS_INACTIVE",
							new GMMap()
								.put("BLOCK_REFERENCE", blockedLog.getString("BLOCK_REFERENCE")));
				}
				CommonHelper.throwBusinessException(BusinessException.UNBLOCKALLANDTRYAGAIN.getCode());
			}
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_CORPORATE_ACCOUNT_BLOCKED_LOGS")
	public static GMMap getCorporateAccountBlockedLogs(GMMap input){
		GMMap output = new GMMap();
		
		try{
			final String TABLE_NAME = "BLOCKED_TABLE";
			List<CorporateAccountBlockedLog> blockedList = CommonHelper.getHibernateSession().createCriteria(CorporateAccountBlockedLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("accountNumber", input.getBigDecimal("ACCOUNT_NUMBER")))
					.add(Restrictions.eq("corporateCode", input.getString("CORPORATE_CODE")))
					.list();
			
			for (CorporateAccountBlockedLog log : blockedList) {
				output.put(TABLE_NAME, blockedList.indexOf(log), "BLOCK_REFERENCE", log.getBlokeReferans());
				output.put(TABLE_NAME, blockedList.indexOf(log), "BLOCKED_STATUS", log.getBlockedStatus());
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_SET_CORPORATE_ACCOUNT_BLOCKED_STATUS_INACTIVE")
	public static GMMap setCorporateAccountBlockedStatusInactive(GMMap input){
		GMMap output = new GMMap();
		try{
			String query = String.format("UPDATE CDM.CORPORATE_ACCOUNT_BLOCKED_LOG SET STATUS=0 WHERE BLOKE_REFERANS='%s'", input.getString("BLOCK_REFERENCE"));
			CommonHelper.executeQuery(query);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	@GraymoundService("CDM_GET_CORPORATE_COLLECTION_ACCOUNT_LIST")
	public static GMMap getCorporateCollectionAccountList(GMMap input) {
		GMMap oMap = new GMMap();
		GMMap rcInput = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		String corporateOid = "";
		rcInput.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, input.getString(MapKeys.CORPORATE_CODE));

		GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
		corporateOid = cdMap.getString(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID);

		@SuppressWarnings("unchecked")
		List<CorporationAccountMaster> accountList = session.createCriteria(CorporationAccountMaster.class).add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.or(Restrictions.eq("accountDefinitionType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount), Restrictions.eq("accountDefinitionType", DatabaseConstants.AccountDefinitionTypes.BlockedAccount))).list();
		int i = 0;
		oMap.put("COLLECTION_ACCOUNT_LIST", i, "NAME", "L�tfen Se�im Yap�n�z");
		oMap.put("COLLECTION_ACCOUNT_LIST", i, "VALUE", "SECIMYOK");
		i++;
		for (CorporationAccountMaster master : accountList) {
			oMap.put("COLLECTION_ACCOUNT_LIST", i, "NAME", master.getAccountNumber().toString());
			oMap.put("COLLECTION_ACCOUNT_LIST", i, "VALUE", master.getOid());
			i++;
		}

		return oMap;
	}

	@GraymoundService("CDM_BLOCK_COLLECTION_ACCOUNT")
	public static GMMap blockCollectionAccount(GMMap input) throws Exception {
		GMMap oMap = new GMMap();
		try {
			String transactionNo = CommonHelper.getNewTransactionNo();
			String accountNumber = input.getString("ACCOUNT_NUMBER");
			String corporateCode = input.getString("CORPORATE_CODE");

			GMMap scMap = new GMMap();
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, transactionNo);
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS,
					DatabaseConstants.CorporateAccountBlockStatuses.Blocking);
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.ACCOUNT_NUMBER, accountNumber);
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.CORPORATE_CODE, corporateCode);
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, false);

			CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, scMap);

			try {
				DALUtil.callOracleProcedure("{call PKG_CS.CS_ACC_BLOCK_MONEY(?,?,?,?,?)}", new Object[] { BnsprType.STRING, accountNumber.toString(),
						BnsprType.NUMBER, new BigDecimal(10000000), BnsprType.STRING, "25", BnsprType.DATE, null, BnsprType.NUMBER,
						new BigDecimal(transactionNo) }, new Object[0]);

				scMap = new GMMap();
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, transactionNo);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS,
						DatabaseConstants.CorporateAccountBlockStatuses.Blocked);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_USER, CommonHelper.getCurrentUser());
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_DATE, CommonHelper.getLongDateTimeString(new Date()));

				CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, scMap);
				oMap.put("RESULT", "S");
			} catch (Exception e) {
				logger.error(String.format("An exception occured while blocking account with number %s", accountNumber));
				logger.error(System.currentTimeMillis(), e);

				scMap = new GMMap();
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, transactionNo);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS,
						DatabaseConstants.CorporateAccountBlockStatuses.BlockFailed);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_CODE, "0");
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_MESSAGE, e.toString());
				CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, scMap);
				oMap.put("RESULT", "F");
				throw e;
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_UNBLOCK_COLLECTION_ACCOUNT")
	public static GMMap unblockCollectionAccount(GMMap input) throws Exception {
		GMMap oMap = new GMMap();
		try {
			String accountNumber = input.getString("ACCOUNT_NUMBER");
			String corporateCode = input.getString("CORPORATE_CODE");
			Session session = DAOSession.getSession("BNSPRDal");
			CorporateAccountBlockedLog logRecord = (CorporateAccountBlockedLog) session
					.createCriteria(CorporateAccountBlockedLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("accountNumber", new BigDecimal(accountNumber)))
					.add(Restrictions.disjunction()
							.add(Restrictions.eq("blockedStatus", DatabaseConstants.CorporateAccountBlockStatuses.Blocked))
							.add(Restrictions.eq("blockedStatus", DatabaseConstants.CorporateAccountBlockStatuses.UnblockFailed))).uniqueResult();
			if (logRecord == null) {
				throw new Exception(String.format("%s kurumu i�in hesap bloke kay�d� bulunamam��t�r.", corporateCode));
			}
			GMMap scMap = new GMMap();
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, logRecord.getBlokeReferans());
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS,
					DatabaseConstants.CorporateAccountBlockStatuses.Unblocking);
			scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true);
			CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, scMap);
			try {
				DALUtil.callOracleProcedure("{call PKG_CS.CS_ACC_UNBLOCK_MONEY(?,?)}", new Object[] { BnsprType.STRING, accountNumber, BnsprType.NUMBER,
						new BigDecimal(logRecord.getBlokeReferans()) }, new Object[0]);
				scMap = new GMMap();
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, logRecord.getBlokeReferans());
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS,
						DatabaseConstants.CorporateAccountBlockStatuses.Unblocked);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.UNBLOCKED_USER, CommonHelper.getCurrentUser());
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.UNBLOCKED_DATE, CommonHelper.getLongDateTimeString(new Date()));
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.SET_INACTIVE, true);
				CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, scMap);
				oMap.put("RESULT", "S");
			} catch (Exception e) {
				logger.error(String.format("An exception occured while unblocking account with number %s", accountNumber));
				logger.error(System.currentTimeMillis(), e);
				scMap = new GMMap();
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, logRecord.getBlokeReferans());
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS,
						DatabaseConstants.CorporateAccountBlockStatuses.UnblockFailed);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true);
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_CODE, "0");
				scMap.put(TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_MESSAGE, e.toString());
				CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, scMap);
				oMap.put("RESULT", "F");
				throw e;
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("CDM_GET_BALANCE_TRANSFER_LOG")
	public static GMMap getBalanceTransferLog( GMMap input) throws Exception{
		
		String transferProcessId = input.getString("TRANSFER_PROCESS_OID");
		
		if( null == transferProcessId ){
			throw new Exception(" A record must be selected. Transfer process id value is null");
		}
		Session session = DAOSession.getSession("BNSPRDal");
		BalanceTransferLog balanceTransferLog = (BalanceTransferLog) session.createCriteria(BalanceTransferLog.class)
				.add(Restrictions.eq("transferProcessOid", transferProcessId))
				.uniqueResult();
		
		if( null == balanceTransferLog ){		
			throw new Exception(" There is no associated record with balance transfer log.");
		}

		GMMap balanceTransferLogMap = new GMMap();
		balanceTransferLogMap.put("IS_UPDATE", true);
		balanceTransferLogMap.put("TRANSFER_STATUS", 1);
		balanceTransferLogMap.put("ERROR_CODE","");
		balanceTransferLogMap.put("ERROR_MESSAGE","");
		balanceTransferLogMap.put("TRANSFER_PROCESS_OID", transferProcessId);
		balanceTransferLogMap.put("RECORD_ID", balanceTransferLog.getOid());
		
		return CommonHelper.callGraymoundServiceInHibernateSession("CDM_INSERT_BALANCE_TRANSFER_LOG", balanceTransferLogMap);
	
	}
	
}
