package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.baskentgaz.BaskentGasProdClient;
import tr.com.aktifbank.integration.baskentgaz.BaskentGazClient;
import tr.com.aktifbank.integration.baskentgaz.ServiceMessage;
import tr.com.baskentdogalgaz.ofttest.Fatura;
import tr.com.baskentdogalgaz.ofttest.FaturaSorgu;
import tr.com.baskentdogalgaz.ofttest.IptalEtme;
import tr.com.baskentdogalgaz.ofttest.MutabakatVerme;
import tr.com.baskentdogalgaz.ofttest.MutabakatsizlikRaporu;
import tr.com.baskentdogalgaz.ofttest.MutabakatsizlikTahsilat;
import tr.com.baskentdogalgaz.ofttest.OnayVerme;
import tr.com.baskentdogalgaz.ofttest.TalimatliAbonelerFatura;
import tr.com.baskentdogalgaz.ofttest.TalimatliAbonelerFaturaSorgu;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class BaskentGasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	
	private static final Log logger = LogFactory.getLog(BaskentGasServices.class);
	private static final String COUNTER_NO = "1";
	private static final String SUCCESSFUL_CODE = "BA�ARILI";
	
	@GraymoundService("ICS_BASKENTGAZ_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_DEBT_INQUIRY");
		
		try{
			String subscriberNo = input.getString(MapKeys.SUBSCRIBER_NO1);
			String collectionType = input.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = input.getString(MapKeys.COLLECTION_TYPE_NAME);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String environment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			if(environment != null && environment.equals("PROD")){
				BaskentGasProdClient client = getProdClient(input, message);
				
				tr.com.baskentdogalgaz.oftws.FaturaSorgu result = client.debtInquiry(subscriberNo, COUNTER_NO);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					String nameSurname = result.getAboneAdSoyad();
					int counter = 0;
					for (tr.com.baskentdogalgaz.oftws.Fatura invoice : result.getFaturalar()) {
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, invoice.getAboneID());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getToplamTutar());
						String[] period = invoice.getDonem().split("/");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, period[0]);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, period[1]);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getFaturaID());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTarihi(), "dd/MM/yyyy"));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, nameSurname);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, invoice.getFaturaTuru());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, invoice.getFaturaTutari());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, invoice.getCezaTutari());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
						output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			else{
				BaskentGazClient client = getClient(input, message);
				
				FaturaSorgu result = client.debtInquiry(subscriberNo, COUNTER_NO);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					String nameSurname = result.getAboneAdSoyad();
					int counter = 0;
					for (Fatura invoice : result.getFaturalar()) {
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, invoice.getAboneID());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getToplamTutar());
						String[] period = invoice.getDonem().split("/");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, period[0]);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, period[1]);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getFaturaID());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTarihi(), "dd/MM/yyyy"));
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, nameSurname);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, invoice.getFaturaTuru());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, invoice.getFaturaTutari());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, invoice.getCezaTutari());
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
						output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
						output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_BASKENTGAZ_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_DO_INVOICE_COLLECTION");
		
		try{
			String subscriberNo = input.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceNo = input.getString(MapKeys.INVOICE_NO);
			Date collectionDate = new Date();
			
			if(input.containsKey("FORCE_DATE")){
				collectionDate = input.getDate("FORCE_DATE");
			}
			
			String environment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			if(environment != null && environment.equals("PROD")){
				BaskentGasProdClient client = getProdClient(input, message);
				
				tr.com.baskentdogalgaz.oftws.OnayVerme result = client.doInvoiceCollection(subscriberNo, invoiceNo, COUNTER_NO, collectionDate);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					if(result.getOnaylar()[0].getDurum().equals("ONAYLANDI")){
						// Confirmed payment
					}
					else{
						setErrorCodeToOutput(result.getOnaylar()[0].getDurum(), output);
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			else{
				BaskentGazClient client = getClient(input, message);
				
				OnayVerme result = client.doInvoiceCollection(subscriberNo, invoiceNo, COUNTER_NO, collectionDate);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					if(result.getOnaylar()[0].getDurum().equals("ONAYLANDI")){
						// Confirmed payment
					}
					else{
						setErrorCodeToOutput(result.getOnaylar()[0].getDurum(), output);
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_BASKENTGAZ_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap cancelCollection(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_SEND_COLLECTION_CANCEL_MESSAGE");
		
		try{
			String subscriberNo = input.getString("SUBSCRIBER_NO_1");
			String invoiceNo = input.getString(MapKeys.INVOICE_NO);
			Date collectionDate = new Date();
			
			if(input.containsKey("FORCE_DATE")){
				collectionDate = input.getDate("FORCE_DATE");
			}
			
			String environment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			if(environment != null && environment.equals("PROD")){
				BaskentGasProdClient client = getProdClient(input, message);
				
				tr.com.baskentdogalgaz.oftws.IptalEtme result = client.cancelCollection(subscriberNo, invoiceNo, COUNTER_NO, collectionDate);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					if(result.getIptalTahsilatlar()[0].getDurum().equals("FATURA �DEMES� �PTAL ED�LD�")){
						// Confirmed cancel
					}
					else{
						setErrorCodeToOutput(result.getIptalTahsilatlar()[0].getDurum(), output);
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			else{
				BaskentGazClient client = getClient(input, message);
				
				IptalEtme result = client.cancelCollection(subscriberNo, invoiceNo, COUNTER_NO, collectionDate);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					if(result.getIptalTahsilatlar()[0].getDurum().equals("FATURA �DEMES� �PTAL ED�LD�")){
						// Confirmed cancel
					}
					else{
						setErrorCodeToOutput(result.getIptalTahsilatlar()[0].getDurum(), output);
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_BASKENTGAZ_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap addStandingOrder(GMMap input){
		GMMap output = new GMMap();
		
		output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
		return output;
	}
	
	@GraymoundService("STO_BASKENTGAZ_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap removeStandingOrder(GMMap input){
		GMMap output = new GMMap();
		
		output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_BASKENTGAZ_DEBT_INQUIRY_FOR_STANDING_ORDER")
	public static GMMap standingOrderDebtInquiry(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_DEBT_INQUIRY_FOR_STANDING_ORDER");
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			List<icsStandingOrders> orders = session.createCriteria(icsStandingOrders.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderStatus", DatabaseConstants.StandingOrderStatus.Active))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.list();
			
			if(orders.size() > 0){
				StringBuilder subscriberNoBuilder = new StringBuilder();
				
				int dateCount = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				
				int counter = 0;
				
				for (icsStandingOrders standingOrders : orders) {
					subscriberNoBuilder.append(standingOrders.getSubscriberNo1());
					if(++counter < orders.size()){
						subscriberNoBuilder.append(",");
					}
				}
				
				String environment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				
				if(environment != null && environment.equals("PROD")){
					BaskentGasProdClient client = getProdClient(input, message);
					
					tr.com.baskentdogalgaz.oftws.TalimatliAbonelerFaturaSorgu result = client.debtInquiryForStandingOrder(subscriberNoBuilder.toString(), dateCount);
					
					if(result.getDurumu().equals(SUCCESSFUL_CODE)){
						counter = 0;
						for (tr.com.baskentdogalgaz.oftws.TalimatliAbonelerFatura invoice : result.getFaturalar()) {
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, invoice.getAboneID());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getFaturaID());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getFaturaTutari());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTarihi(), "dd.MM.yyyy"));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoice.getAboneAdSoyad());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER12, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER13, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER14, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER15, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER17, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER18, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER19, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER20, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							counter++;
						}
						output.put(MapKeys.TABLE_SIZE, counter);
					}
					else{
						setErrorCodeToOutput(result.getMesaj(), output);
					}
				}
				else{
					BaskentGazClient client = getClient(input, message);
					
					TalimatliAbonelerFaturaSorgu result = client.debtInquiryForStandingOrder(subscriberNoBuilder.toString(), dateCount);
					
					if(result.getDurumu().equals(SUCCESSFUL_CODE)){
						counter = 0;
						for (TalimatliAbonelerFatura invoice : result.getFaturalar()) {
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, invoice.getAboneID());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getFaturaID());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getFaturaTutari());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTarihi(), "dd.MM.yyyy"));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoice.getAboneAdSoyad());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER12, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER13, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER14, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER15, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER17, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER18, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER19, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER20, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							counter++;
						}
						output.put(MapKeys.TABLE_SIZE, counter);
					}
					else{
						setErrorCodeToOutput(result.getMesaj(), output);
					}
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_BASKENTGAZ_COLLECTION_RECONCILIATION")
	public static GMMap collectionRecon(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_COLLECTION_RECONCILIATION");
		
		try{
			Date reconDate = input.getDate(MapKeys.RECON_DATE);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", input);
			
			BigDecimal collectionAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			String environment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			if(environment != null && environment.equals("PROD")){
				BaskentGasProdClient client = getProdClient(input, message);
				
				tr.com.baskentdogalgaz.oftws.MutabakatVerme result = client.reconciliation(reconDate, collectionCount, collectionAmount, cancelCount, cancelAmount);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					if(result.getMutabakatSonucu().equals("MUTABAKAT BA�ARILI")){
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionAmount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelAmount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
					else{
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, -1);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, -1);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, -1);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, -1);
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			else{
				BaskentGazClient client = getClient(input, message);
				
				MutabakatVerme result = client.reconciliation(reconDate, collectionCount, collectionAmount, cancelCount, cancelAmount);
				
				if(result.getDurumu().equals(SUCCESSFUL_CODE)){
					if(result.getMutabakatSonucu().equals("MUTABAKAT BA�ARILI")){
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionAmount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelAmount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
					else{
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, -1);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, -1);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, -1);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, -1);
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				}
				else{
					setErrorCodeToOutput(result.getMesaj(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_BASKENTGAZ_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconDetail(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_GET_COLLECTION_RECONCILIATION_DETAIL");
		
		try{
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS",  input);
			
			int size = reconBankMap.getSize("BANK");
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			if(size > 0){
				Map<String, BigDecimal> invoiceAmountMap = new HashMap<String, BigDecimal>();
				StringBuilder subNoBuilder = new StringBuilder();
				Date reconDate = input.getDate(MapKeys.RECON_DATE);
				
				for (int i = 0; i < size; i++) {
					invoiceAmountMap.put(reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO), reconBankMap.getBigDecimal("BANK", i, MapKeys.PAYMENT_AMOUNT));
					subNoBuilder.append(reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO));
					if(i < size){
						subNoBuilder.append(",");
					}
				}
				
				String environment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				
				if(environment != null && environment.equals("PROD")){
					BaskentGasProdClient client = getProdClient(input, message);
					
					tr.com.baskentdogalgaz.oftws.MutabakatsizlikRaporu result = client.reconciliationDetail(reconDate, subNoBuilder.toString());
					
					if(result.getDurumu().equals(SUCCESSFUL_CODE)){
						for (tr.com.baskentdogalgaz.oftws.MutabakatsizlikTahsilat reconData : result.getMutabakatsizlikTahsilatlar()) {
							String errorDesc = "";
							String errorCode = "";
							String processType = "";
							try{
								if(reconData.getDurum().equals("BANKADA FAZLA")){
									processType = ReconciliationProcessType.collectionMessageSent;
									
									GMMap onlineServiceCallMap = new GMMap();
									onlineServiceCallMap.put(MapKeys.SUBSCRIBER_NO1, reconData.getAboneId());
									onlineServiceCallMap.put(MapKeys.INVOICE_NO, reconData.getFaturaId());
									onlineServiceCallMap.put("FORCE_DATE", reconDate);
									onlineServiceCallMap.put(MapKeys.CORPORATE_CODE, corporateCode);
									onlineServiceCallMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
									onlineServiceCallMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
									onlineServiceCallMap.put(MapKeys.RECON_CALL, true);
									
									CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", onlineServiceCallMap);
								}
								else{
									processType = ReconciliationProcessType.cancelCollectionMessageSent;
									
									GMMap onlineServiceCallMap = new GMMap();
									onlineServiceCallMap.put("SUBSCRIBER_NO_1", reconData.getAboneId());
									onlineServiceCallMap.put(MapKeys.INVOICE_NO, reconData.getFaturaId());
									onlineServiceCallMap.put("FORCE_DATE", reconDate);
									onlineServiceCallMap.put(MapKeys.CORPORATE_CODE, corporateCode);
									onlineServiceCallMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
									onlineServiceCallMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
									onlineServiceCallMap.put(MapKeys.RECON_CALL, true);
									
									CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", onlineServiceCallMap);
								}
							}
							catch(Exception e){
								logger.error(String.format("An exception occured while processing recon data for %s invoice id.", reconData.getFaturaId()));
								logger.error(System.currentTimeMillis(), e);
							}
							finally{
								try {
									GMMap reconProcessDataLogInsertInputMap = new GMMap();
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, input.getString(MapKeys.RECON_LOG_OID));
									if (!StringUtil.isEmpty(errorCode)) {
										reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,errorCode);
									}
									if (!StringUtil.isEmpty(errorDesc)) {
										reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,errorDesc);
									}
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, "");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, processType);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,reconData.getAboneId());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, 0);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,reconData.getTahsilTutari());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,reconData.getFaturaId());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7,"");

									CommonHelper.callGraymoundServiceOutsideSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
								} catch (Exception e) {
									logger.error("An exception occured while inserting recon process data log.");
									logger.error(System.currentTimeMillis(), e);
								}
							}
						}
					}
					else{
						setErrorCodeToOutput(result.getMesaj(), output);
					}
				}
				else{
					BaskentGazClient client = getClient(input, message);
					
					MutabakatsizlikRaporu result = client.reconciliationDetail(reconDate, subNoBuilder.toString());
					
					if(result.getDurumu().equals(SUCCESSFUL_CODE)){
						for (MutabakatsizlikTahsilat reconData : result.getMutabakatsizlikTahsilatlar()) {
							String errorDesc = "";
							String errorCode = "";
							String processType = "";
							try{
								if(reconData.getDurum().equals("BANKADA FAZLA")){
									processType = ReconciliationProcessType.collectionMessageSent;
									
									GMMap onlineServiceCallMap = new GMMap();
									onlineServiceCallMap.put(MapKeys.SUBSCRIBER_NO1, reconData.getAboneId());
									onlineServiceCallMap.put(MapKeys.INVOICE_NO, reconData.getFaturaId());
									onlineServiceCallMap.put("FORCE_DATE", reconDate);
									onlineServiceCallMap.put(MapKeys.CORPORATE_CODE, corporateCode);
									onlineServiceCallMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
									onlineServiceCallMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
									onlineServiceCallMap.put(MapKeys.RECON_CALL, true);
									
									CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", onlineServiceCallMap);
								}
								else{
									processType = ReconciliationProcessType.cancelCollectionMessageSent;
									
									GMMap onlineServiceCallMap = new GMMap();
									onlineServiceCallMap.put("SUBSCRIBER_NO_1", reconData.getAboneId());
									onlineServiceCallMap.put(MapKeys.INVOICE_NO, reconData.getFaturaId());
									onlineServiceCallMap.put("FORCE_DATE", reconDate);
									onlineServiceCallMap.put(MapKeys.CORPORATE_CODE, corporateCode);
									onlineServiceCallMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
									onlineServiceCallMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
									onlineServiceCallMap.put(MapKeys.RECON_CALL, true);
									
									CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", onlineServiceCallMap);
								}
							}
							catch(Exception e){
								logger.error(String.format("An exception occured while processing recon data for %s invoice id.", reconData.getFaturaId()));
								logger.error(System.currentTimeMillis(), e);
							}
							finally{
								try {
									GMMap reconProcessDataLogInsertInputMap = new GMMap();
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, input.getString(MapKeys.RECON_LOG_OID));
									if (!StringUtil.isEmpty(errorCode)) {
										reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,errorCode);
									}
									if (!StringUtil.isEmpty(errorDesc)) {
										reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,errorDesc);
									}
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, "");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, processType);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,reconData.getAboneId());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, 0);
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,reconData.getTahsilTutari());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,reconData.getFaturaId());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6,"");
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7,"");

									CommonHelper.callGraymoundServiceOutsideSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
								} catch (Exception e) {
									logger.error("An exception occured while inserting recon process data log.");
									logger.error(System.currentTimeMillis(), e);
								}
							}
						}
					}
					else{
						setErrorCodeToOutput(result.getMesaj(), output);
					}
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_BASKENTGAZ_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_BASKENTGAZ_COLLECTION_RECONCILIATION_CLOSED");
		
		try{
			
			String screenRecon = input.getString("SCREEN_RECONCILIATION", "");
			String reconDate = input.getString(MapKeys.RECON_DATE);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			if(screenRecon.equals("1")){
				setCollectionInfoToOutput(output, reconDate, corporateCode,
						session);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of BASKENTGAZ");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	private static BaskentGazClient getClient(GMMap input, ServiceMessage message) throws Exception {
		return new BaskentGazClient(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), 
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), 
				message);
	}
	
	private static BaskentGasProdClient getProdClient(GMMap input, ServiceMessage message) throws Exception {
		return new BaskentGasProdClient(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), 
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), 
				message);
	}
	
	private static void setErrorCodeToOutput(String errorMessage, GMMap output){
		output.put(MapKeys.ERROR_CODE, GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE);
		output.put(MapKeys.ERROR_DESC, errorMessage);
		output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
	}
}
