package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktfibank.integration.kaski.KaskiClient;
import tr.com.aktfibank.integration.kaski.ServiceMessage;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.KaskiNewReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;













import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.kaski.abys.service.ArrayOfOdeme;
import com.kaski.abys.service.ArrayOfTahakkuklar;
import com.kaski.abys.service.ArrayOfTalimatSonuc;
import com.kaski.abys.service.GenelIslemSonuc;
import com.kaski.abys.service.IslemBilgileri;
import com.kaski.abys.service.Odeme;
import com.kaski.abys.service.OdemeSonuc;
import com.kaski.abys.service.Talimat;


public class KaskiNewServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(KaskiNewServices.class);

	
	@GraymoundService("ICS_KASKI_NEW_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_NEW_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();

		String responseCode = "0";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		GMMap responceCodeMap = new GMMap();

		try {
			ServiceMessage serviceMessage = new ServiceMessage();
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
			int aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);

				ArrayOfTahakkuklar billList=	KaskiClient.getBorcTutarAboneNo(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, aboneNo);
				CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				if (billList.getTahakkuklar() != null) {
					int length = billList.getTahakkuklar().size();
					for (int i = 0; i < length; i++) {
						
						responseCode = billList.getTahakkuklar().get(i).getSonucKodu().toString();
						if (responseCode.equals("SUCCESS") ) {
							responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						}
					
						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							String dueDate=CommonHelper.getShortDateTimeString(billList.getTahakkuklar().get(i).getSonOdemeTarihi().toGregorianCalendar().getTime());
							if (!isCollectedInvoice(String.valueOf(billList.getTahakkuklar().get(i).getTahakkukId()), String.valueOf(billList.getTahakkuklar().get(i).getAboneNo()), "", "", "", corporateCode,dueDate)) {
								String termYear = String.valueOf(billList.getTahakkuklar().get(i).getBorcYili());
								String termMonth = String.valueOf(billList.getTahakkuklar().get(i).getTaksitDonem());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, billList.getTahakkuklar().get(i).getAboneNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, billList.getTahakkuklar().get(i).getTahakkukId());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, billList.getTahakkuklar().get(i).getToplamTutar());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, billList.getTahakkuklar().get(i).getTahakkukTurId());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, billList.getTahakkuklar().get(i).getSiraNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME,  billList.getTahakkuklar().get(i).getAdSoyadUnvan());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, billList.getTahakkuklar().get(i).getSonOdemeTarihi().toGregorianCalendar().getTime());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, billList.getTahakkuklar().get(i).getToplamTutar());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, billList.getTahakkuklar().get(i).getTurAdi());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, billList.getTahakkuklar().get(i).getTahakkukTurId());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, billList.getTahakkuklar().get(i).getTutar());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, billList.getTahakkuklar().get(i).getGecikmeTutar());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}
						}
					}
				}
			

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KASKI_NEW_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_NEW_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			String branchCode = iMap.getString(MapKeys.BRANCH_CODE);
		
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int billID = iMap.getInt(MapKeys.INVOICE_NO);
			String referenceNumber = iMap.getString(MapKeys.TRX_NO);
			BigDecimal invoiceAmount = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
		
			
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			XMLGregorianCalendar paymentDate= CommonHelper.convertDate2GregorianCalendar(tahsilatTarihi, "yyyy-MM-dd");
//			if (!invoiceAmount.equals(paymentAmount)) {
//				// kismi ya da fazla odeme yapiliyorsa fatura tutarini degistir
//				invoiceAmount = paymentAmount;
//			}
			if (isStandingOrderCollection) {
				logger.info("ICS_CLK_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			} else {
				logger.info("ICS_CLK_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			OdemeSonuc response = null;
			String responseCode = "0";
			String responseMessage = "";
			ArrayOfOdeme  odenecekListe= new ArrayOfOdeme ();
			Odeme makbuzOdemeParametre = new Odeme();
			makbuzOdemeParametre.setAnaPara(Double.parseDouble(iMap.getString(MapKeys.PARAMETER2)));
			makbuzOdemeParametre.setGecikme(Double.parseDouble(iMap.getString(MapKeys.PARAMETER4)));
			makbuzOdemeParametre.setIslemTarihi(paymentDate);
			makbuzOdemeParametre.setReferansKodu(referenceNumber);
			makbuzOdemeParametre.setTahakkukId(billID);
			makbuzOdemeParametre.setToplamTutar(Double.parseDouble(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			odenecekListe.getOdeme().add(makbuzOdemeParametre);
			
			response=KaskiClient.setBorcTutar(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, odenecekListe);

			responseCode = response.getSonucKodu().toString();
			responseMessage = response.getSonucMesaji();
				

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (responseCode.equals("SUCCESS") ) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(String.valueOf(response.getTahakkukOdemeIDList().getInt().get(0)));
				session.saveOrUpdate(invoicePayment);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KASKI_NEW_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_NEW_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			int paymentID = iMap.getInt(MapKeys.PARAMETER_2, 0);
			if (paymentID == 0) {
				paymentID = iMap.getInt(MapKeys.PARAMETER2);
			}
			if (iMap.getBoolean(MapKeys.RECON_CALL)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				paymentID= Integer.parseInt(invoicePayment.getParameter2());
			}
		
			
			String responseCode = "0";
			String responseMessage = "";
		
			String tahsilatIptalAciklama= iMap.getString("REJECTED_REASON", "");
			GenelIslemSonuc response = KaskiClient.odemeIptal(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, paymentID, tahsilatIptalAciklama);
			
			responseCode = response.getSonucKodu().toString();
			responseMessage = response.getSonucMesaji();
			
			if (responseCode.equals("SUCCESS") ) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
	
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_KASKI_NEW_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KASKI_NEW_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessageCheck = new ServiceMessage();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);

			
			int aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);

			
			String responseCode="";
			String responseMessage="";

			Talimat setSuBankaTalimatParam= new Talimat();
			setSuBankaTalimatParam.setAboneNo(aboneNo);
			setSuBankaTalimatParam.setTalimatTarihi(CommonHelper.convertDate2GregorianCalendar(new Date()));
			GenelIslemSonuc  response = KaskiClient.setSuBankaTalimat(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, setSuBankaTalimatParam);
			responseCode = response.getSonucKodu().toString();
			responseMessage = response.getSonucMesaji();
			if (responseCode.equals("SUCCESS") ) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
	
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap	responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_KASKI_NEW_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KASKI_NEW_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessageCheck = new ServiceMessage();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);

			
			int aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);

			
			String responseCode="";
			String responseMessage="";

//			SetSuBankaTalimatParam setSuBankaTalimatParam= new SetSuBankaTalimatParam();
//			setSuBankaTalimatParam.setAboneNo(aboneNo);
//			setSuBankaTalimatParam.setTalimatTarihi(CommonHelper.convertDate2GregorianCalendar(new Date()));
			GenelIslemSonuc response = KaskiClient.setSuBankaTalimatIptal(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, aboneNo);
			responseCode = response.getSonucKodu().toString();
			responseMessage = response.getSonucMesaji();
			if (responseCode.equals("SUCCESS") ) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
	
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap	responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KASKI_NEW_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KASKI_NEW_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();
			
			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				
				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_KASKI_NEW_INVOICE_DEBT_INQUIRY", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KASKI_NEW_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("STO_KASKI_NEW_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KASKI_NEW_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		String responseCode="";
		String responseMessage="";
		try {
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			Calendar tarih = CommonHelper.getCalendarWithYYYYMMDD(reconDate);
			ArrayOfTalimatSonuc response = KaskiClient.getBankaTalimatAboneList(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage);
			
			if ( response.getTalimatSonuc().size() ==0) {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, 0);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
			}else{
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, response.getTalimatSonuc().size());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				responseCode = response.getTalimatSonuc().get(0).getSonucKodu().toString();
				responseMessage = response.getTalimatSonuc().get(0).getSonucMesaji();
			}
			

			if (responseCode.equals("SUCCESS") || response.getTalimatSonuc().size() ==0) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
//			rcInput.put(MapKeys.RECON_DATE, reconDate);
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			List<icsStandingOrders> bankCancelledStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

			outMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderList.size());
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_DESKI_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KASKI_NEW_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		String responseCode="";
		String responseMessage = "";

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_NEW_COLLECTION_RECONCILIATION");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
	
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);

			String reconDateString = iMap.getString(MapKeys.RECON_DATE);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();
			
			XMLGregorianCalendar reconDate= CommonHelper.convertDate2GregorianCalendar(reconDateString, "yyyyMMdd");

			

			IslemBilgileri response =KaskiClient.getGunlukIslemRapor(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, reconDate);
			responseCode = response.getSonucKodu().toString();
			
			if (responseCode.equals("SUCCESS") ) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
		
			responseMessage= response.getIslemMesaj();
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());


				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getToplamTahsilatTutari());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getTahsilatSayisi());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
	
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
					output.put(MapKeys.ERROR_CODE, "660");
					output.put(MapKeys.ERROR_DESC, errorMessage);
				}
				else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_KASKI_NEW_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	
	@GraymoundService("ICS_KASKI_NEW_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_KASKI_NEW_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_NEW_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new KaskiNewReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_KASKI_NEW_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_KASKI_NEW_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_NEW_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	



}
