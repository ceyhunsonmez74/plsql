package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.StandingOrderStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.kcetasonline.KcetasOnlineClient;
import tr.com.aktifbank.integration.kcetasonline.ServiceMessage;
import tr.com.aktifbank.integration.kcetastest.KcetasTestClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import abys_ps.WS_wsdl.types.BankaoltahsrvBorclarTypeUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvDetmutabakatReUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvIptalRecUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvMutabakatRecUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvPasswordRecUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvTahsilRecUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvTalimatDetmutaUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvTalimatKaydetUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvTalimatMutabakUser;
import abys_ps.WS_wsdl.types.BankaoltahsrvborclartypeBorcUser;
import abys_ps.WS_wsdl.types.OnlineTahsilatBankaBorclarUser;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class KcetasOnlineServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(KcetasOnlineServices.class);
	private static GMMap reconCorpAmountMap = new GMMap();

	public static BigDecimal SICIL_NO_CANCELLED_VALUE = new BigDecimal(0);
	public static BigDecimal SICIL_NO_SYSTEM_ERROR_VALUE = new BigDecimal(-1);
	public static String SICIL_NO_CANCELLED_ERROR_CODE = "899";
	public static String SICIL_NO_SYSTEM_ERROR_CODE = "9999";
	public static String RESPONSE_CODE_APPROVE = "IGDSWSRV00001"; // TODO ask me
																	// not sure

	@GraymoundService("ICS_KCETAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		OnlineTahsilatBankaBorclarUser[] borcListDetail = null;
		try {
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			// get collection list
			ServiceMessage serviceMessage = new ServiceMessage();
			BankaoltahsrvBorclarTypeUser borcList = KcetasOnlineClient.getBorcListe(iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), 
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), aboneNo, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			// get collection master to check errors
			BankaoltahsrvborclartypeBorcUser borcListMaster = borcList.getMaster();
			// check collection master firstly if any error occurs
			responseCode = borcListMaster.getErrorType();

			if (responseCode == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			// get response code from db
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			// if no error occurs
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				borcListDetail = borcList.getDetail();
				int length = borcListDetail.length;
				for (int i = 0; i < length; i++) {
					// get collections one by one
					OnlineTahsilatBankaBorclarUser borc = borcListDetail[i];
					// check if collection is paid
					if (!isCollectedInvoice(borc.getThkfisno().toString(), aboneNo.toString(), "", "", "", corporateCode)) { // TODO
																																// ask
																																// those
																																// ones
																																// !!!
						Calendar term = borc.getDonem();
						Calendar sot = borc.getSot();
						String termYear = "";
						String termMonth = "";
						Date invoiceDueDate = null;
						Date invoiceDate = null;
						if (term != null) {
							termYear = Integer.toString(term.get(Calendar.YEAR));
							termMonth = Integer.toString(term.get(Calendar.MONTH));
						}
						if (sot != null) {
							invoiceDueDate = sot.getTime();
						}
						if (term != null) {
							invoiceDate = term.getTime();
						}
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, aboneNo);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkfisno());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borcListMaster.getAdsoyad());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, invoiceDate);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		outMap.put(MapKeys.BANK_CODE, iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
		outMap.put(MapKeys.WS_USER, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
		outMap.put(MapKeys.WS_PASSWORD, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
		return outMap;
	}

	@GraymoundService("ICS_KCETAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_DO_INVOICE_COLLECTION");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal pBankaKodu = iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			BigDecimal pSubeKodu = new BigDecimal(555);
			String pUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String pPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal pThkfisno = iMap.getBigDecimal(MapKeys.INVOICE_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			Calendar pTahsilatTarihi = Calendar.getInstance();
			Calendar sonOdemeTarihi = Calendar.getInstance();
			Calendar donemTarihi = Calendar.getInstance();
			Date sonOdemeTarih = iMap.getDate(MapKeys.INVOICE_DUE_DATE);
			Date donemTarih = iMap.getDate(MapKeys.INVOICE_DATE);
			if (sonOdemeTarih != null) {
				sonOdemeTarihi.setTime(sonOdemeTarih);
			}
			if (donemTarih != null) {
				donemTarihi.setTime(donemTarih);
			}
			BigDecimal borcTutar = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			if (iMap.containsKey(MapKeys.PAYMENT_DATE) && !StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				pTahsilatTarihi.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss"));
			}
			BigDecimal pIslemreferansno = iMap.getBigDecimal(MapKeys.TRX_NO);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			ServiceMessage serviceMessage = new ServiceMessage();
			BankaoltahsrvTahsilRecUser tahsilat;
			if (isStandingOrderCollection) {
				tahsilat = KcetasOnlineClient.talimatliTahsilat(pBankaKodu, pSubeKodu, pUserName, pPassword, aboneNo, donemTarihi, sonOdemeTarihi, borcTutar, pTahsilatTarihi, 
						pIslemreferansno, serviceMessage);
			} else {
				tahsilat = KcetasOnlineClient.tahsilatYap(pBankaKodu, pSubeKodu, pUserName, pPassword, pThkfisno, pTahsilatTarihi, pIslemreferansno, serviceMessage);
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			String pErrorType = tahsilat.getErrorType();

			if (pErrorType == null) {
				// tahsilat basaril oldu demek
				pErrorType = "0";
			}
			GMMap responceCodeMap = getResponseCodeMapping(pErrorType, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put("TAHSILAT", 0, "MAKBUZ_NO", tahsilat.getThkfisno());
				outMap.put(MapKeys.CORPORATE_PAYMENT_ID, tahsilat.getIslemreferansno());
				Session session = CommonHelper.getHibernateSession();
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter3(tahsilat.getThkfisno().toString());
				session.saveOrUpdate(invoicePayment);
			}
			
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_INVOICE_DEBT_INQUIRY");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		return outMap;
	}

	@GraymoundService("ICS_KCETAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String aciklama = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String user = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal makbuzNo = iMap.getBigDecimal("TRX_NO");
			BigDecimal bankCode = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			if (makbuzNo == null) {
				makbuzNo = iMap.getBigDecimal(MapKeys.PARAMETER3);
			}
			ServiceMessage serviceMessageKcetasTahsilatIptal = new ServiceMessage();
			BankaoltahsrvIptalRecUser bankaoltahsrvIptalRecUser = KcetasOnlineClient.iptal(bankCode, user, sifre, makbuzNo, serviceMessageKcetasTahsilatIptal);
			iMap.put("REQUEST_XML", serviceMessageKcetasTahsilatIptal.getRequest());
			outMap.put("RESPONSE_XML", serviceMessageKcetasTahsilatIptal.getResponse());
			String responseCode = bankaoltahsrvIptalRecUser.getErrorType();

			String callParameters = makbuzNo.toString().concat(",").concat(makbuzNo.toString()).concat(",").concat(aciklama.toString()).concat(",").concat(user.toString()).concat(",").concat(sifre.toString()).concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).concat(",").concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)).concat(",")
					.concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			logger.info("ICS_KCETAS_SEND_COLLECTION_CANCEL_MESSAGE called KcetasOnlineClient.iptal(".concat(callParameters).concat(") with SOAP request message -> ".concat(serviceMessageKcetasTahsilatIptal.getRequest())));
			logger.info("ICS_KCETAS_SEND_COLLECTION_CANCEL_MESSAGE is replied with SOAP response message by KcetasOnlineClient.iptal(".concat(callParameters).concat(") -> ".concat(serviceMessageKcetasTahsilatIptal.getResponse())));
			iMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessageKcetasTahsilatIptal.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessageKcetasTahsilatIptal.getResponse());
			if (bankaoltahsrvIptalRecUser.getErrorMsg() == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}

		return outMap;
	}

	@GraymoundService("ICS_KCETAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		Session session = CommonHelper.getHibernateSession();
		String collectionTypeId = "0";
		String responseCode = null;

		try {
			// recon_detail_data da continious durumda bir kayit varmi diye
			// kontrol et eger boyle bir kayit var ise ftm in bizi cagirmasini
			// bekliyoruz
			// demektir. hic bi islem yapmadan cik
			ReconDetailData recDetData = (ReconDetailData) session.createCriteria(ReconDetailData.class).add(Restrictions.eq("reconLogOid", iMap.getString("RECON_LOG_OID"))).add(Restrictions.eq("status", true)).uniqueResult();
			if (recDetData != null) {
				if (recDetData.getReconLogOid() != null) {
					logger.info("ICS_KCETAS_COLLECTION_RECONCILIATION -->> Devam etmekte olan bir mutabakat oldugu icin mutabakat islemi continues statusunde bekletiliyor...");
					// Fatura odeme tipi icin 0 kullanilacak
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, "-1");
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "-1");
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, "-1");
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "-1");

					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "-1");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "-1");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "-1");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "-1");
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.Continues);
					return outMap;
				}
			}

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			logger.info("...ICS_KCETAS_COLLECTION_RECONCILIATION has started...");
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			BigDecimal faturaTahsilatAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalToplami = new BigDecimal(0);
			BigDecimal faturaTahsilatToplami = new BigDecimal(0);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			iMap.put("RECON_ACCORDING_TO_COLLECTION_TYPE", "YES");
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			logger.info("...ICS_KCETAS_COLLECTION_RECONCILIATION called ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS...");

			faturaTahsilatIptalAdedi = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			faturaTahsilatIptalToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			faturaTahsilatAdedi = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_COUNT);
			faturaTahsilatToplami = reconBankMap.getBigDecimal(collectionTypeId, 0, MapKeys.RECON_COLLECTION_TOTAL);

			// Fatura odeme tipi icin 0 kullanilacak
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, faturaTahsilatToplami);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, faturaTahsilatIptalToplami);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, faturaTahsilatAdedi);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, faturaTahsilatIptalAdedi);

			ServiceMessage s = new ServiceMessage();
			BankaoltahsrvMutabakatRecUser reconControl = KcetasOnlineClient.mutabakatGenel(iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), wsUserName, wsPassword, 
					reconDate, faturaTahsilatAdedi, faturaTahsilatToplami, faturaTahsilatIptalAdedi, faturaTahsilatIptalToplami, s);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			logger.info("...ICS_KCETAS_COLLECTION_RECONCILIATION called KcetasOnlineClient.mutabakatGenel...");

			if (reconControl.getTahsiltutar() == null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "-1");
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconControl.getTahsiltutar());
			}
			if (reconControl.getIptaltutar() == null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "-1");
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconControl.getIptaltutar());
			}
			if (reconControl.getTahsilsayi() == null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "-1");
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconControl.getTahsilsayi());
			}
			if (reconControl.getIptalsayi() == null) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "-1");
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconControl.getIptalsayi());
			}
			if (reconControl != null && reconControl.getErrorMsg() == null) {
				// Mutabakat basarili ve kapatildi
				logger.info("...ICS_KCETAS_COLLECTION_RECONCILIATION kurum tarafinda basarili olarak kapatildi.");

				// Fatura odeme tipi icin 0 kullanilacak
				if (faturaTahsilatToplami != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, faturaTahsilatToplami);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
				}
				if (faturaTahsilatIptalToplami != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, faturaTahsilatIptalToplami);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				}
				if (faturaTahsilatAdedi != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, faturaTahsilatAdedi);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
				}
				if (faturaTahsilatIptalAdedi != null) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, faturaTahsilatIptalAdedi);
				} else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
				}
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				// hata var detay mutabakat yap�lacak
				logger.info("...ICS_KCETAS_COLLECTION_RECONCILIATION kurum tarafinda basarisiz oldu.Detay mutabakat cagrilacak");
				logger.info(" Mutabakat basarisizlik nedeni  " + reconControl.getErrorMsg());

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconControl.getTahsiltutar());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconControl.getTahsilsayi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconControl.getIptaltutar());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconControl.getIptalsayi());

				if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL))) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT))) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception ext) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ext));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(ext);
		}
		return outMap;
	}

	@GraymoundService("ICS_KCETAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			logger.info("...ICS_KCETAS_GET_COLLECTION_RECONCILIATION_DETAIL called KcetasOnlineClient.mutabakatDetay (before)...");
			ServiceMessage s = new ServiceMessage();
			BankaoltahsrvDetmutabakatReUser reconControl = KcetasOnlineClient.mutabakatDetay(iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), wsUserName, 
					wsPassword, reconDate, s);
			String fileName = reconControl.getDosyaadi();
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			logger.info("...ICS_KCETAS_GET_COLLECTION_RECONCILIATION_DETAIL called KcetasOnlineClient.mutabakatDetay (after)...");

			String reconTime = Integer.toString(reconDate.get(Calendar.HOUR)).concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(Integer.toString(reconDate.get(Calendar.SECOND)));
			if (!insertDocNameToReconDetailData(fileName, corporateCode, reconLogOid, iMap.getString(MapKeys.RECON_DATE), reconTime)) {
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, "description");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
				return outMap;
			}
			iMap.put(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(ex);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_KCETAS_DETAIL_FTM_FILE_CONTENT")
	public static GMMap detailFTMFileContent(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_DETAIL_FTM_FILE_CONTENT");
		GMMap outMap = new GMMap();

		try {
			// FTM_process-oid ftm bize ge�icek
			String fileDefId = iMap.getString("FILE_DEF_ID");
			logger.info("fileDefId=" + fileDefId);
			String corporateCode = CommonHelper.getValueOfParameter("CDM_FILE_DEF_CORPORATE_CODE_MAPPING", fileDefId);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCode);

			logger.info("...ICS_KCETAS_DETAIL_FTM_FILE_CONTENT called KcetasOnlineClient.detailFTMFileContent...Current ftmProcessOid is  ");
			logger.info("corporateCode is = " + corporateCode);
			Session session = CommonHelper.getHibernateSession();
			Criteria criteriaReconLog = session.createCriteria(ReconLog.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime"));
			Calendar reconDate = Calendar.getInstance();

			BigDecimal ftmProcessOID = iMap.getBigDecimal("PROCESS_ID");
			logger.info("PROCESS_ID is " + ftmProcessOID);
			if (ftmProcessOID == null) {
				logger.error("Error getting FTM Process OID from iMap");
				return outMap;
			}

			Criteria criteria = session.createCriteria(FtmProcess.class).add(Restrictions.eq("oid", ftmProcessOID));
			FtmProcess ftmProcess = (FtmProcess) criteria.uniqueResult();
			String reconDateStr = "";
			if (ftmProcess != null && ftmProcess.getFileName() != null) {
				String fileName = ftmProcess.getFileName();
				reconDateStr = fileName.substring(3, 11);
				logger.info("fileName is " + fileName + "reconDateStr is " + reconDateStr);
			}
			iMap.put(MapKeys.RECON_DATE, reconDateStr);
			reconDate.setTime(CommonHelper.getDateTime(reconDateStr.concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			List<ReconLog> reconLogList = criteriaReconLog.list();
			ReconLog reconLog = null;
			String reconLogOid = "";
			if (reconLogList != null && reconLogList.size() != 0) {
				reconLog = reconLogList.get(0);
				reconLogOid = reconLog.getOid();
			}

			Criteria criteriaFtmContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ftmProcessOID));
			List<FtmFileContent> ftmFileContentList = criteriaFtmContentList.list();
			logger.info("ftmFileContentList size is " + ftmFileContentList.size());
			int ftmFileContentListOrder = 0;
			for (FtmFileContent ftmFileContent : ftmFileContentList) {
				logger.info("ftmFileContent line is " + ftmFileContent.getLine());
				logger.info("reconLog is " + reconLog);
				logger.info("reconLog.getDate is " + reconLog.getReconDate());
				logger.info("reconLog.getTime is " + reconLog.getReconTime());
				logger.info("corporateCode is " + corporateCode);
				logger.info("reconLogOid is " + reconLogOid);
				parseAndSaveStrToReconDataTbl(ftmFileContent.getLine(), corporateCode, reconLogOid, reconLog.getReconDate(), reconLog.getReconTime(), ftmFileContentListOrder);
				ftmFileContentListOrder++;
			}

			logger.info("...ICS_KCETAS_GET_COLLECTION_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");
			String strSQL = "";
			// strSQL =
			// "select distinct invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1 from ics.recon_detail_data where status = 1 and corporate_code = '"
			// + corporateCode
			// + "' and recon_log_oid = '" + reconLogOid +
			// "' and transaction_type = 'G' and transaction_type is not null";
			strSQL = String.format(QueryRepository.KcetasOnlineServicesRepository.GET_FTM_DETAIL, corporateCode, reconLogOid);
			logger.info("Current SQL is " + strSQL);
			String TABLE_NAME = "RECON_DETAIL_DATA";
			GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
			reconcOfCorpBank(iMap, outMap, corporateCode, reconDate, reconLogOid, TABLE_NAME, returnMap);
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_DETAIL_FTM_FILE_CONTENT");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_KCETAS_DETAIL_FTM_FILE_CONTENT_STANDING_ORDER")
	// TODO format me !!
	public static GMMap detailFTMFileContentForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_DETAIL_FTM_FILE_CONTENT_STANDING_ORDER");
		GMMap outMap = new GMMap();

		try {
			// FTM_process-oid ftm bize ge�icek
			String fileDefId = iMap.getString("FILE_DEF_ID"); //
			String corporateCode = CommonHelper.getValueOfParameter("CDM_FILE_DEF_CORPORATE_CODE_MAPPING", fileDefId);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCode);

			Session session = CommonHelper.getHibernateSession();
			Criteria criteriaReconLog = session.createCriteria(ReconLog.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime"));
			Calendar reconDate = Calendar.getInstance();

			BigDecimal ftmProcessOID = iMap.getBigDecimal("PROCESS_ID");
			logger.info("PROCESS_ID is " + ftmProcessOID);
			logger.info("file Def ID is " + fileDefId);
			logger.info("corporate code is = " + corporateCode);
			if (ftmProcessOID == null) {
				logger.error("Error getting FTM Process OID from iMap");
				return outMap;
			}

			Criteria criteria = session.createCriteria(FtmProcess.class).add(Restrictions.eq("oid", ftmProcessOID));
			FtmProcess ftmProcess = (FtmProcess) criteria.uniqueResult();
			String reconDateStr = "";
			if (ftmProcess != null && ftmProcess.getFileName() != null) {
				String fileName = ftmProcess.getFileName();
				reconDateStr = fileName.substring(6, 14);
				logger.info("fileName is " + fileName + "reconDateStr is " + reconDateStr);
			}
			iMap.put(MapKeys.RECON_DATE, reconDateStr);
			reconDate.setTime(CommonHelper.getDateTime(reconDateStr.concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			List<ReconLog> reconLogList = criteriaReconLog.list();
			ReconLog reconLog = null;
			String reconLogOid = "";
			if (reconLogList != null && reconLogList.size() != 0) {
				reconLog = reconLogList.get(0);
				reconLogOid = reconLog.getOid();
			}

			Criteria criteriaFtmContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ftmProcessOID));
			List<FtmFileContent> ftmFileContentList = criteriaFtmContentList.list();
			logger.info("ftmFileContentList size is " + ftmFileContentList.size());
			int ftmFileContentListOrder = 0;
			for (FtmFileContent ftmFileContent : ftmFileContentList) {
				parseAndSaveStandingOrderStr(ftmFileContent.getLine(), corporateCode, reconLogOid, reconLog.getReconDate(), reconLog.getReconTime(), ftmFileContentListOrder);
				logger.info("ftmFileContent line is " + ftmFileContent.getLine());
				ftmFileContentListOrder++;
			}
			logger.info("...ICS_KCETAS_GET_COLLECTION_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");
			reconcOfCorpBankForStandingOrder(iMap, outMap, corporateCode, reconDate, reconLogOid);
			outMap.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Succeeded);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_DETAIL_FTM_FILE_CONTENT");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Canelled);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		return outMap;
	}

	private static void reconcOfCorpBank(GMMap iMap, GMMap outMap, String corporateCode, Calendar reconDate, String reconLogOid, String TABLE_NAME, GMMap returnMap) throws Exception {
		BigDecimal bankCollectionCount;
		BigDecimal bankCollectionCancelCount;
		BigDecimal bankCollectionCancelTotal;
		BigDecimal bankCollectionTotal;
		ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
		int corporateCollectionCount = 0;
		if (al != null) {
			corporateCollectionCount = al.size();
		}
		GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
		String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
		GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

		bankCollectionCancelCount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
		bankCollectionCancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
		bankCollectionCount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_COUNT);
		bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);

		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, bankCollectionCancelTotal);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankCollectionCancelCount);

		int bankCollectionCountInt = bankCollectionCount.intValue();
		GMMap rcInput = new GMMap();
		rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, corporateCode);

		boolean found = false;
		if (bankCollectionCountInt > corporateCollectionCount) {
			short collectionType = 0;
			for (int j = 0; j < bankCollectionCountInt; j++) {
				for (int i = 0; i < corporateCollectionCount; i++) {
					if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
							&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
						found = true;
						break;
					} else {
						found = false;
					}
				}
				if (!found) { // bulunamayan numara icin tahsilat istegi gonder
					logger.info("bizdeki tahsilat kurumda bulunamadi, kuruma tahsilat mesaji gondericem...");
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO2));
					request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
					request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, DatabaseConstants.PaymentStatuses.Collected);// TODO
																										// Not
																										// sure
																										// about
																										// it
					request.put(MapKeys.CORPORATE_CODE, corporateCode);
					request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_BRANCH));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("BANK", j, MapKeys.TERM_YEAR));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconDate);
					onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);// TODO
																												// ask
																												// me
					onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_SOURCE));
					onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("BANK", j, MapKeys.BRANCH_CODE));
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						logger.info("tahsilat mesaji basarili olarak gonderildi...");
						logger.info("subsciberNo = " + request.getString(MapKeys.SUBSCRIBER_NO1 + ",transactionNo= " + request.getString(MapKeys.TRX_NO) + ",invoice No=" + request.getString(MapKeys.INVOICE_NO)) + ",invoiceAmount=" + request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi");
					} catch (Exception e) {
						CommonHelper.getStringifiedException(e);
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						throw ExceptionHandler.convertException(e);
					} finally {
						insertOnlineServiceLog(iMap, outMap);
					}

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));

					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}
			}
		} else {
			short collectionType = 0;
			for (int j = 0; j < corporateCollectionCount; j++) {
				for (int k = 0; k < bankCollectionCountInt; k++) {
					if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1)) && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
							&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
						found = true;
						break;
					} else {
						found = false;
					}
				}
				if (!found) {
					// bulunamayan numara icin tahsilat iptal istegi gonder
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
					request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));// TODO
																														// null
																														// parameter
					request.put(MapKeys.PARAMETER4, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER4));// TODO
																														// null
																														// parameter
					request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);

					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL"); //
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					try {
						logger.info("subsciberNo = " + request.getString(MapKeys.SUBSCRIBER_NO1 + ",transactionNo= " + request.getString(MapKeys.TRX_NO) + ",invoice No=" + request.getString(MapKeys.INVOICE_NO) + ",invoiceAmount=" + request.getString(MapKeys.INVOICE_AMOUNT)));
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
					} catch (Exception e) {
						// Tahsilatta hata al�nca yakal�yoruz yola devam
						// ediyoruz. z
						logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
						logger.error(System.currentTimeMillis(), e);
						CommonHelper.getStringifiedException(e);
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						throw ExceptionHandler.convertException(e);
					} finally {
						insertOnlineServiceLog(iMap, outMap);
					}

					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, DatabaseConstants.ReconciliationProcessType.cancelCollectionMessageSent);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}
			}
		}
	}

	private static void reconcOfCorpBankForStandingOrder(GMMap iMap, GMMap outMap, String corporateCode, Calendar reconDate, String reconLogOid) throws Exception {
		BigDecimal bankCollectionCount;
		BigDecimal bankCollectionCancelCount;
		BigDecimal bankCollectionCancelTotal;
		BigDecimal bankCollectionTotal;

		GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
		String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
		GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

		GMMap corporateBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_BANK_STANDING_ORDERS_COLLECTION_RECONCILIATION", iMap);
		int corporateCollectionCount = 0;
		BigDecimal corporateCollection = corporateBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_COUNT);
		if (corporateCollection != null) {
			corporateCollectionCount = corporateCollection.intValue();
		}
		bankCollectionCancelCount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
		bankCollectionCancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
		bankCollectionCount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_COUNT);
		bankCollectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);

		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, bankCollectionTotal);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, bankCollectionCount);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, bankCollectionCancelTotal);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankCollectionCancelCount);

		int bankCollectionCountInt = bankCollectionCount.intValue();
		GMMap rcInput = new GMMap();
		rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, corporateCode);

		boolean found = false;
		if (bankCollectionCountInt > corporateCollectionCount) {
			short collectionType = 0;
			for (int j = 0; j < bankCollectionCountInt; j++) {
				for (int i = 0; i < corporateCollectionCount; i++) {
					if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
							&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
						found = true;
						break;
					} else {
						found = false;
					}
				}
				if (!found) { // bulunamayan numara icin tahsilat istegi gonder
					logger.info("bizdeki tahsilat kurumda bulunamadi, kuruma tahsilat mesaji gondericem...");
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO2));
					request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
					request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, DatabaseConstants.PaymentStatuses.Collected);// TODO
																										// Not
																										// sure
																										// about
																										// it
					request.put(MapKeys.CORPORATE_CODE, corporateCode);
					request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_BRANCH));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("BANK", j, MapKeys.TERM_YEAR));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconDate);
					onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);// TODO
																												// ask
																												// me
					onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_SOURCE));
					onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("BANK", j, MapKeys.BRANCH_CODE));
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						logger.info("tahsilat mesaji basarili olarak gonderildi...");
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi");
					} catch (Exception e) {
						CommonHelper.getStringifiedException(e);
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						throw ExceptionHandler.convertException(e);
					} finally {
						insertOnlineServiceLog(iMap, outMap);
					}

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER4));

					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}
			}
		} else {
			short collectionType = 0;
			for (int j = 0; j < corporateCollectionCount; j++) {
				for (int k = 0; k < bankCollectionCountInt; k++) {
					if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1)) && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
							&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
						found = true;
						break;
					} else {
						found = false;
					}
				}
				if (!found) {
					// bulunamayan numara icin tahsilat iptal istegi gonder
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
					request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));// TODO
																														// null
																														// parameter
					request.put(MapKeys.PARAMETER4, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER4));// TODO
																														// null
																														// parameter
					request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);

					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL"); //
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					try {
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
					} catch (Exception e) {
						// Tahsilatta hata al�nca yakal�yoruz yola devam
						// ediyoruz.
						logger.error("An exception occured while executing ICS_COLLECTION_RECONCILIATION_GET_COLLECTION on Reconciliation services");
						logger.error(System.currentTimeMillis(), e);
						CommonHelper.getStringifiedException(e);
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						throw ExceptionHandler.convertException(e);
					} finally {
						insertOnlineServiceLog(iMap, outMap);
					}

					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, DatabaseConstants.ReconciliationProcessType.cancelCollectionMessageSent);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}
			}
		}
	}

	public static boolean insertDocNameToReconDetailData(String fileName, String corporateCode, String reconLogOid, String reconDate, String reconTime) {
		try {
			Session session = CommonHelper.getHibernateSession();
			ReconDetailData rdd = new ReconDetailData();
			rdd.setStatus(true);
			rdd.setCorporateCode(corporateCode);
			rdd.setParameter1(fileName);
			rdd.setReconLogOid(reconLogOid);
			rdd.setReconDate(reconDate);
			rdd.setReconTime(reconTime);
			session.saveOrUpdate(rdd);
			session.flush();
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Problem inserting document name to RECON_DETAIL_DATA table. Reconciliation Detail could not be accomplished " + ex);
			return false;
		}
		return true;
	}

	public static void parseAndSaveStrToReconDataTbl(String fileString, String corporateCode, String reconLogOid, String reconDate, String reconTime, int ftmFileContentListOrder) {
		String subscriberNo = fileString.substring(0, 10);
		String paymentAmountStr = fileString.substring(10, 22);
		BigDecimal paymentAmount = new BigDecimal(paymentAmountStr);
		String transReferenceNo = fileString.substring(22, 46);
		String transType = fileString.substring(46, 47);
		String branchCode = fileString.substring(47, 51);
		String regionCode = fileString.substring(51, 55);
		String regionName = fileString.substring(55, 75);
		String cityCode = fileString.substring(75, 81);
		String cityName = fileString.substring(81, 101);
		String districtCode = fileString.substring(101, 107);
		String districtName = fileString.substring(107, 127);
		String townCode = fileString.substring(127, 133);
		String townName = fileString.substring(133, 153);
		String villageCode = "";
		String villageName = "";
		reconCorpAmountMap.put("CORPORATE", ftmFileContentListOrder, MapKeys.SUBSCRIBER_NO1, subscriberNo);
		reconCorpAmountMap.put("CORPORATE", ftmFileContentListOrder, MapKeys.TRX_NO, new BigDecimal(transReferenceNo));// makbuz.getDekont());
		reconCorpAmountMap.put("CORPORATE", ftmFileContentListOrder, MapKeys.PAYMENT_AMOUNT, paymentAmount);

		addNewReconDetailData(corporateCode, subscriberNo, paymentAmount, CommonHelper.trimStart(transReferenceNo, '0'), transType, branchCode, regionCode, regionName, cityCode, cityName, districtCode, districtName, townCode, townName, villageCode, villageName, reconLogOid, reconDate, reconTime);
	}

	public static void parseAndSaveStandingOrderStr(String fileString, String corporateCode, String reconLogOid, String reconDate, String reconTime, int ftmFileContentListOrder) {

		String transType = fileString.substring(0, 1);
		String subscriberNo = fileString.substring(1, 11);
		String regionCode = fileString.substring(11, 15);
		String regionName = fileString.substring(15, 35);
		String cityCode = fileString.substring(35, 39);
		String cityName = fileString.substring(39, 59);
		String townCode = fileString.substring(59, 65);
		String townName = fileString.substring(65, 85);
		String districtCode = fileString.substring(85, 91);
		String districtName = fileString.substring(91, 111);
		String villageCode = fileString.substring(111, 117);
		String villageName = fileString.substring(117, 137);

		reconCorpAmountMap.put("CORPORATE", ftmFileContentListOrder, MapKeys.SUBSCRIBER_NO1, subscriberNo); //
		reconCorpAmountMap.put("CORPORATE", ftmFileContentListOrder, MapKeys.TRX_NO, "");// makbuz.getDekont());//TODO
																							// buralara
																							// bosluk
																							// koyulmus
																							// bunlarin
																							// doldurulmasi
																							// gerekiyor
																							// !!!
		reconCorpAmountMap.put("CORPORATE", ftmFileContentListOrder, MapKeys.PAYMENT_AMOUNT, "");// TODO
																									// buralara
																									// bosluk
																									// koyulmus
																									// bunlarin
																									// doldurulmasi
																									// gerekiyor
																									// !!!

		addNewReconDetailData(corporateCode, subscriberNo, null, null, transType, null, regionCode, regionName, cityCode, cityName, districtCode, districtName, townCode, townName, villageCode, villageName, reconLogOid, reconDate, reconTime);
	}

	public static boolean addNewReconDetailData(String corporateCode, String subscriberNo, BigDecimal paymentAmount, String transReferenceNo, String transType, String branchCode, String regionCode, String regionName, String cityCode, String cityName, String districtCode, String districtName, String townCode, String townName, String villageCode, String villageName, String reconLogOid,
			String reconDate, String reconTime) {
		try {
			Session session = CommonHelper.getHibernateSession();
			ReconDetailData rdd = new ReconDetailData();
			rdd.setCorporateCode(corporateCode);
			rdd.setSubscriberNo1(subscriberNo);
			rdd.setInvoiceNo(transReferenceNo);
			rdd.setStatus(true);
			rdd.setTransactionType(transType);
			rdd.setPaymentAmount(paymentAmount);
			rdd.setParameter1(transReferenceNo);
			rdd.setParameter2(branchCode);
			rdd.setParameter3(regionCode);
			rdd.setParameter4(regionName);
			rdd.setParameter5(cityCode);
			rdd.setParameter6(cityName);
			rdd.setParameter7(districtCode);
			rdd.setParameter8(districtName);
			rdd.setParameter9(townCode + " " + townName);
			rdd.setParameter10(villageCode + " " + villageName);
			rdd.setReconLogOid(reconLogOid);
			rdd.setReconDate(reconDate);
			rdd.setReconTime(reconTime);
			session.saveOrUpdate(rdd);
			session.flush();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@GraymoundService("STO_KCETAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap standingOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KCETAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			BigDecimal bankCode = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String bankCodeStr = bankCode.toString();
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String responseCode = "";

			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			logger.info("...STO_KCETAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL called KcetasOnlineClient.talimatMutabakatDetay (before)...");
			ServiceMessage serviceMessage = new ServiceMessage();
			BankaoltahsrvTalimatDetmutaUser bankaoltahsrvTalimatDetmutaUser = KcetasOnlineClient.talimatMutabakatDetay(bankCode, wsUserName, wsPassword, reconDate, serviceMessage);
			String fileName = bankaoltahsrvTalimatDetmutaUser.getDosyaadi();
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			logger.info("...STO_KCETAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL called KcetasOnlineClient.talimatMutabakatDetay (after)...");

			String reconTime = Integer.toString(reconDate.get(Calendar.HOUR)).concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(Integer.toString(reconDate.get(Calendar.SECOND)));
			if (!insertDocNameToReconDetailData(fileName, bankCodeStr, reconLogOid, iMap.getString(MapKeys.RECON_DATE), reconTime)) {
				logger.info("error inserting document to ReconDetailData table");
				outMap.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Canelled);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, "description");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				return outMap;
			}
			if (bankaoltahsrvTalimatDetmutaUser.getErrorType() == null) {
				responseCode = RESPONSE_CODE_APPROVE;
			} else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			logger.info("response code is " + responseCode);
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Passive); // status
																					// might
																					// need
																					// to
																					// be
																					// renamed
																					// at
																					// future
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);

			logger.info("end of standing order reconciliation detail");
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.STANDING_ORDER_STATUS, 3);
			insertOnlineServiceLog(iMap, outMap);

			throw ExceptionHandler.convertException(ex);
		}
		return outMap;
	}

	@GraymoundService("STO_KCETAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KCETAS_STANDING_ORDER_RECONCILIATION");

		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			logger.info("inside standing order reconciliation table");
			BigDecimal bankCode = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String responseCode = "";
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal faturaTahsilatAdedi = new BigDecimal(0);
			BigDecimal faturaTahsilatIptalAdedi = new BigDecimal(0);

			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);
			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);

			int bankOrderCount = rcOutput.getInt(MapKeys.RECON_BANK_COUNT);
			int bankCancelCount = rcOutput.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
			logger.info("bank Order Count = " + bankOrderCount);
			logger.info("bank Cancel Count = " + bankCancelCount);
			faturaTahsilatAdedi = new BigDecimal(bankOrderCount);
			faturaTahsilatIptalAdedi = new BigDecimal(bankCancelCount);

			ServiceMessage serviceMessage = new ServiceMessage();
			BankaoltahsrvTalimatMutabakUser bankaoltahsrvTalimatMutabakUser = KcetasOnlineClient.talimatMutabakat(bankCode, wsUserName, wsPassword, reconDate, faturaTahsilatAdedi,
					faturaTahsilatIptalAdedi, serviceMessage);
			logger.info("bankCode = " + bankCode + "reconDate = " + reconDate + "faturaTahsilatAdedi = " + faturaTahsilatAdedi + "faturaTahsilatIptalAdedi = " + faturaTahsilatIptalAdedi);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			String hataKodlari = bankaoltahsrvTalimatMutabakUser.getErrorType();
			logger.info("error type is = " + hataKodlari);
			if (hataKodlari == null) {
				// Talimatli Mutabakat basarili ve kapatildi
				logger.info("...STO_KCETAS_STANDING_ORDER_RECONCILIATION kurum tarafinda basarili olarak kapatildi.");
				outMap.put("CORPORATE", 0, MapKeys.RECON_CORPORATE_COUNT, faturaTahsilatAdedi);
				outMap.put("CORPORATE", 0, MapKeys.RECON_CORPORATE_CANCEL_COUNT, faturaTahsilatIptalAdedi);
				outMap.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Succeeded);
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				// Talimatsiz Mutabakat basarisiz ve detay mutabakata girmem
				// gerekiyor !!
				logger.info("...STO_KCETAS_STANDING_ORDER_RECONCILIATION kurum tarafinda basarisiz oldu.Detay mutabakat cagrilacak");
				logger.info("Talimat Mutabakat basarisizlik nedeni  " + bankaoltahsrvTalimatMutabakUser.getErrorMsg());
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, bankaoltahsrvTalimatMutabakUser.getTalimatsayi());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, bankaoltahsrvTalimatMutabakUser.getIptalsayi());
			}
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KCETAS_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Canelled);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		return outMap;
	}

	@GraymoundService("STO_KCETAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KCETAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			Calendar talimatBaslangicTarihi = Calendar.getInstance();
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			ServiceMessage serviceMessageTalimatKaydet = new ServiceMessage();
			BankaoltahsrvTalimatKaydetUser bankaoltahsrvTalimatKaydetUser = KcetasOnlineClient.talimatKaydet(iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), 
					username, password, aboneNo, talimatBaslangicTarihi, serviceMessageTalimatKaydet);
			iMap.put("REQUEST_XML", serviceMessageTalimatKaydet.getRequest());
			outMap.put("RESPONSE_XML", serviceMessageTalimatKaydet.getResponse());
			String responseCode = "";
			if (bankaoltahsrvTalimatKaydetUser.getSonuc() == 1 && bankaoltahsrvTalimatKaydetUser.getErrorMsg() == null) {
				// istek basarili gonderildi
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else {
				responseCode = bankaoltahsrvTalimatKaydetUser.getErrorType();
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}

		return outMap;
	}

	@GraymoundService("STO_KCETAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KCETAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			ServiceMessage serviceMessageTalimatSil = new ServiceMessage();
			BankaoltahsrvTalimatKaydetUser bankaoltahsrvTalimatKaydetUser = KcetasOnlineClient.talimatSil(iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), username,
					password, aboneNo, Calendar.getInstance(), serviceMessageTalimatSil);
			iMap.put("REQUEST_XML", serviceMessageTalimatSil.getRequest());
			outMap.put("RESPONSE_XML", serviceMessageTalimatSil.getResponse());
			String responseCode = "";
			if (bankaoltahsrvTalimatKaydetUser.getSonuc() == 1 && bankaoltahsrvTalimatKaydetUser.getErrorMsg() == null) {
				// istek basarili gonderildi
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			} else {
				responseCode = bankaoltahsrvTalimatKaydetUser.getErrorMsg();
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KCETAS_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		}
		return outMap;
	}

	@GraymoundService("ICS_KCETAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_SIBESKI_COLLECTION_RECONCILIATION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER is started...");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String toDayToCompare = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			GMMap sorMap = getBankStandingOrdersForKcetas(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER recon count to check is ".concat(Integer.toString(reconCollectionCount)));
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				String subscriberNumber = CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0');
				logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" will be called.."));
				iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNumber);
				iMap.put(MapKeys.COLLECTION_TYPE, "0");
				iMap.put(MapKeys.COLLECTION_TYPE_NAME, "Fatura Odeme");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_KCETAS_INVOICE_DEBT_INQUIRY", iMap);
				int billNumber = reconBankMap.getSize(MapKeys.INVOICE_LIST);
				logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" is called and return map").concat(reconBankMap.toString()).concat(" and bill number is").concat(Integer.toString(billNumber)));
				if (billNumber > 0) {
					for (int z = 0; z < billNumber; z++) {
						logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" compares date invoice date -> ").concat(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE).toString()).concat(" with todays date -> ").concat(toDayToCompare));
						if (toDayToCompare.equals(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE))) {
							logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" returned result which matches due date with today..."));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static GMMap getBankStandingOrdersForKcetas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER is called getBankStandingOrdersForVodafone...");
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.KcetasOnlineServicesRepository.GET_BANK_STANDING_ORDER, reconcilitionDate, reconcilitionDate, corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER found ".concat(Integer.toString(al.size())).concat(" standing order for VF"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			logger.info("ICS_KCETAS_DEBT_INQUERY_FOR_STANDING_ORDER found 0 standing order");
		}
		return returnMap;
	}
	
	@GraymoundService("ICS_KCETAS_CHANGE_PASSWORD")
	public static GMMap changePassword(GMMap input){
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		try{
			boolean isTestEnvironment = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2).equals("1");
			String newPass = input.getString("NEW_PASSWORD");
			
			if(isTestEnvironment){
				test_ps.Bankaoltahsrv_wsdl.types.BankaoltahsrvPasswordRecUser result = KcetasTestClient.changePassword(input.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), 
						input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), newPass);
				
				if(StringUtil.isEmpty(result.getErrorType())){
					// Successful
				}
				else{
					output.put(MapKeys.ERROR_CODE, GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE);
					output.put(MapKeys.ERROR_DESC, result.getErrorMsg());
					output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, result.getErrorMsg());
				}
			}
			else{
				BankaoltahsrvPasswordRecUser result = KcetasOnlineClient.changePassword(input.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), 
						input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), newPass, message);
				
				input.put("REQUEST_XML", message.getRequest());
				output.put("RESPONSE_XML", message.getResponse());
				
				if(StringUtil.isEmpty(result.getErrorType())){
					// Successful
				}
				else{
					output.put(MapKeys.ERROR_CODE, GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE);
					output.put(MapKeys.ERROR_DESC, result.getErrorMsg());
					output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, result.getErrorMsg());
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally{
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}

}
