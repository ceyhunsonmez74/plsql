package tr.com.aktifbank.bnspr.corporation.services;

import invoice.model.collgw.turkcelltech.com.InvoiceDetail;
import invoice.model.collgw.turkcelltech.com.InvoicePaymentCancelResponse;
import invoice.model.collgw.turkcelltech.com.InvoicePaymentResponse;
import invoice.model.collgw.turkcelltech.com.InvoiceQueryOpenResponse;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import reconciliation.model.collgw.turkcelltech.com.ReconciliationInfo;
import reconciliation.model.collgw.turkcelltech.com.ReconciliationResponse;
import subscriber.model.collgw.turkcelltech.com.SubscriberInfoResponse;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.session.SessionHolderKeys;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.turkcellPCG.ServiceMessage;
import tr.com.aktifbank.integration.turkcellPCG.TurkcellPCGClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import autopayment.model.collgw.turkcelltech.com.AutoPaymentCancelResponse;
import autopayment.model.collgw.turkcelltech.com.AutoPaymentOrderResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import common.model.collgw.turkcelltech.com.CustomerInformation;
import common.model.collgw.turkcelltech.com.OriginatorId;

public class TurkcellServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	public static final String CURRENCY_CODE = "949";
	public static final int INVOICE_COUNT = 5;
	public static final int BANK_ID = 1143;
	private static final Log logger = LogFactory.getLog(TurkcellServices.class);
	private static final int DEFAULT_CITY = 34;
	public static String BRANCH_CODE = "555";
	public static final String LOGON_ERR = "10";
	public static final int OP_TYPE_PAYMENT = 17;
	public static final int STATUS_DEFAULT = 17;
	private static final String RESPONSE_CODE_APPROVE = "00";
	private static final String AFTER_VALID_RECON_ERR = "18";
	private static final String NKOLAY_USER = "NKOLAY";

	@GraymoundService("ICS_TURKCELL_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		int compId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String custId = "";
		String msgDate = getMsgDate();
		Long msisdn = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
		String channelCode = CommonHelper.getChannelId();
		String procDate = getProcDate();
		String procTime = getProcTime();
		String period = getPeriod();
		OriginatorId orig = getOriginatorId(channelCode);
		Long stan = Long.parseLong(getStanNo());
		ServiceMessage serviceMessage = new ServiceMessage();
		int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String responseCode = "";
			int counter = 0;
			String errorCode = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String sessionID = getSession(iMap);
			InvoiceQueryOpenResponse invoiceQueryOpenResponse = TurkcellPCGClient.invoiceQuery(wsUrl, bankId, compId, CURRENCY_CODE, custId, INVOICE_COUNT, msgDate, msisdn, orig, period, procDate, procTime, sessionID, stan, serviceMessage, timeOut);
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getParameter1(), serviceMessage.getParameter2(), serviceMessage.getParameter3());
			responseCode = invoiceQueryOpenResponse.getRespCode();
			logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_INVOICE_DEBT_INQUIRY.");
			if (LOGON_ERR.equals(responseCode)) {
				renewSession(iMap);
				sessionID = getSession(iMap);
				invoiceQueryOpenResponse = TurkcellPCGClient.invoiceQuery(wsUrl, bankId, compId, CURRENCY_CODE, custId, INVOICE_COUNT, msgDate, msisdn, orig, period, procDate, procTime, sessionID, stan, serviceMessage, timeOut);
				responseCode = invoiceQueryOpenResponse.getRespCode();
				logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_INVOICE_DEBT_INQUIRY.");
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			Object[] invoiceList = invoiceQueryOpenResponse.getInvoceList();
			boolean stanUsed = false;
			if (invoiceList != null) {
				for (int i = 0; i < invoiceList.length; i++) {
					InvoiceDetail invoiceDetail = (InvoiceDetail) invoiceList[i];

					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						if (!isCollectedInvoice(String.valueOf(invoiceDetail.getInvNo()), iMap.getString(MapKeys.SUBSCRIBER_NO1), iMap.getString(MapKeys.SUBSCRIBER_NO2), iMap.getString(MapKeys.SUBSCRIBER_NO3), "", corporateCode)) {
							if (stanUsed) {
								/*
								 * sorgulama icin kullanilan stan ilk donen
								 * faturaya verilir. 1 den fazla fatura geldi
								 * ise yeni bir stan uretilir bu is fatura
								 * iptallerinde yasanan problemden dolayi
								 * yap�lmistir.
								 */
								stan = Long.parseLong(getStanNo());
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, iMap.getString(MapKeys.SUBSCRIBER_NO3));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoiceDetail.getNameSurname());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoiceDetail.getInvNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoiceDetail.getInvAmount());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, sessionID);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, invoiceDetail.getControlId());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, invoiceDetail.getInvType());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, invoiceDetail.getPrevMsisdn());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, invoiceDetail.getRemark());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, stan);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, invoiceDetail.getInvType());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, invoiceDetail.getPeriod());
							String isNotCancelledBillType = CommonHelper.getValueOfParameter("TURKCELL_IADESIZ_FATURA_TIPLERI", Integer.toString(invoiceDetail.getInvType()));
							if ("EVET".equals(isNotCancelledBillType)) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "#FATURA_TIPI=IPTALI_YOK#");
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, invoiceDetail.getOrderNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDetail.getDuedate());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, invoiceDetail.getPeriod().substring(0, 4));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, invoiceDetail.getPeriod().substring(4));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, invoiceDetail.getInvAmount());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
							stanUsed = true;
						}

					}
				}
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_DO_INVOICE_COLLECTION");
		try {
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int compId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String currencyCode = CURRENCY_CODE;
			String msgDate = getMsgDate();
			String accDate = getAccDate();
			Long msisdn = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			String procDate = getProcDate();
			String captDate = getProcDate();
			int invoiceCount = 1;
			String channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			OriginatorId orig = getOriginatorId(channelCode);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int paymentChannel = Integer.parseInt(getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType));
			Object[] invoiceList = { getInvoiceDetail(iMap) };
			Long stan = iMap.getLong(MapKeys.PARAMETER6);
			ServiceMessage serviceMessage = new ServiceMessage();
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String responseCode = "";
			String errorCode = "";
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String invData = "";
			String sessionID = getSession(iMap);
			InvoicePaymentResponse invoicePaymentResponse = TurkcellPCGClient.payInvoice(wsUrl, accDate, bankId, captDate, compId, currencyCode, invoiceCount, invData, invoiceList, msgDate, msisdn, orig, paymentChannel, procDate, sessionID, stan, serviceMessage, timeOut);
			responseCode = invoicePaymentResponse.getRespCode();
			logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_DO_INVOICE_COLLECTION.");
			if (LOGON_ERR.equals(responseCode)) {
				renewSession(iMap);
				sessionID = getSession(iMap);
				invoicePaymentResponse = TurkcellPCGClient.payInvoice(wsUrl, accDate, bankId, captDate, compId, currencyCode, invoiceCount, invData, invoiceList, msgDate, msisdn, orig, paymentChannel, procDate, sessionID, stan, serviceMessage, timeOut);
				responseCode = invoicePaymentResponse.getRespCode();
				logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_DO_INVOICE_COLLECTION.");
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKCELL_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int compId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String currencyCode = CURRENCY_CODE;
			String msgDate = getMsgDate();
			String accDate = getAccDate();
			Long msisdn = iMap.getLong(MapKeys.CANCEL_SUBSCRIBER_NO1);
			String procDate = getProcDate();
			String captDate = getProcDate();
			int invoiceCount = 1;
			String channelCode = CommonHelper.getChannelId();
			if (StringUtil.isEmpty(iMap.getString("PAYMENT_CHANNEL"))) {
				channelCode = iMap.getString("PAYMENT_CHANNEL");
			}
			OriginatorId orig = getOriginatorId(channelCode);
			String sourceCode = iMap.getString(MapKeys.PAYMENT_SOURCE);
			
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int paymentChannel = Integer.parseInt(getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType));
			Object[] invoiceList = { getInvoiceCancelDetail(iMap) };
			Long stan = iMap.getLong(MapKeys.CANCEL_PARAMETER6);
			ServiceMessage serviceMessage = new ServiceMessage();
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String responseCode = "";
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String invData = "";
			String sessionID = getSession(iMap);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			InvoicePaymentCancelResponse invoicePaymentCancelResponse = TurkcellPCGClient.cancelInvoicePayment(wsUrl, accDate, bankId, captDate, compId, currencyCode, invoiceCount, invData, invoiceList, msgDate, msisdn, orig, paymentChannel, procDate, sessionID, stan, serviceMessage, timeOut);
			responseCode = invoicePaymentCancelResponse.getRespCode();
			logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE.");
			if (LOGON_ERR.equals(responseCode)) {
				renewSession(iMap);
				sessionID = getSession(iMap);
				invoicePaymentCancelResponse = TurkcellPCGClient.cancelInvoicePayment(wsUrl, accDate, bankId, captDate, compId, currencyCode, invoiceCount, invData, invoiceList, msgDate, msisdn, orig, paymentChannel, procDate, sessionID, stan, serviceMessage, timeOut);
				responseCode = invoicePaymentCancelResponse.getRespCode();
				logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE.");
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int compId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String currencyCode = CURRENCY_CODE;
			String msgDate = getMsgDate();
			Long msisdn = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			String procDate = getProcDate();
			String captDate = getProcDate();
			String channelCode = CommonHelper.getChannelId();
			OriginatorId orig = getOriginatorId(channelCode);
			String procTime = getProcTime();
			Long stan = Long.parseLong(getStanNo());
			ServiceMessage serviceMessage = new ServiceMessage();
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String sessionID = getSession(iMap);
			SubscriberInfoResponse subscriberInfoResponse = TurkcellPCGClient.getSubscriberInfo(wsUrl, bankId, compId, currencyCode, msgDate, msisdn, orig, procDate, procTime, sessionID, stan, serviceMessage, timeOut);
			String responseCode = subscriberInfoResponse.getRespCode();
			logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE.");
			if (LOGON_ERR.equals(responseCode)) {
				renewSession(iMap);
				sessionID = getSession(iMap);
				subscriberInfoResponse = TurkcellPCGClient.getSubscriberInfo(wsUrl, bankId, compId, currencyCode, msgDate, msisdn, orig, procDate, procTime, sessionID, stan, serviceMessage, timeOut);
				responseCode = subscriberInfoResponse.getRespCode();
				logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE.");
			}
			if (responseCode.equals(RESPONSE_CODE_APPROVE)) {
				CustomerInformation custInfo = subscriberInfoResponse.getCustInfo();
				String name = subscriberInfoResponse.getName();
				custInfo.setApCompany(compId);
				custInfo.setApDate(getAccDate());
				custInfo.setApOrdererName(name);
				custInfo.setCreditCardNum(new Long(0));

				AutoPaymentOrderResponse autoPaymentOrderResponse = TurkcellPCGClient.giveAoutoPaymentOrder(wsUrl, bankId, captDate, compId, currencyCode, custInfo, msgDate, msisdn, name, orig, procDate, sessionID, stan, serviceMessage, timeOut);
				responseCode = autoPaymentOrderResponse.getRespCode();
				if (LOGON_ERR.equals(responseCode)) {
					renewSession(iMap);
					sessionID = getSession(iMap);
					autoPaymentOrderResponse = TurkcellPCGClient.giveAoutoPaymentOrder(wsUrl, bankId, captDate, compId, currencyCode, custInfo, msgDate, msisdn, name, orig, procDate, sessionID, stan, serviceMessage, timeOut);
					responseCode = autoPaymentOrderResponse.getRespCode();
					logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE.");
				}

			}

			logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE.");
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_TURKCELL_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int compId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String currencyCode = CURRENCY_CODE;
			String msgDate = getMsgDate();
			Long msisdn = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			String procDate = getProcDate();
			String captDate = getProcDate();
			String procTime = getProcTime();
			String channelCode = CommonHelper.getChannelId();
			OriginatorId orig = getOriginatorId(channelCode);
			Long stan = Long.parseLong(getStanNo());
			ServiceMessage serviceMessage = new ServiceMessage();
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String sessionID = getSession(iMap);
			SubscriberInfoResponse subscriberInfoResponse = TurkcellPCGClient.getSubscriberInfo(wsUrl, bankId, compId, currencyCode, msgDate, msisdn, orig, procDate, procTime, sessionID, stan, serviceMessage, timeOut);
			String responseCode = subscriberInfoResponse.getRespCode();
			logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			if (LOGON_ERR.equals(responseCode)) {
				renewSession(iMap);
				sessionID = getSession(iMap);
				subscriberInfoResponse = TurkcellPCGClient.getSubscriberInfo(wsUrl, bankId, compId, currencyCode, msgDate, msisdn, orig, procDate, procTime, sessionID, stan, serviceMessage, timeOut);
				responseCode = subscriberInfoResponse.getRespCode();
				logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			}

			if (responseCode.equals(RESPONSE_CODE_APPROVE)) {
				CustomerInformation custInfo = subscriberInfoResponse.getCustInfo();
				String name = custInfo.getApOrdererName();
				AutoPaymentCancelResponse autoPaymentCancelResponse = TurkcellPCGClient.cancelAoutoPayment(wsUrl, bankId, captDate, compId, currencyCode, custInfo, msgDate, msisdn, name, orig, procDate, sessionID, stan, serviceMessage, timeOut);
				responseCode = autoPaymentCancelResponse.getRespCode();
				if (LOGON_ERR.equals(responseCode)) {
					renewSession(iMap);
					sessionID = getSession(iMap);
					autoPaymentCancelResponse = TurkcellPCGClient.cancelAoutoPayment(wsUrl, bankId, captDate, compId, currencyCode, custInfo, msgDate, msisdn, name, orig, procDate, sessionID, stan, serviceMessage, timeOut);
					responseCode = autoPaymentCancelResponse.getRespCode();
					logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
				}
			}

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			logger.error(responseCode + " returned by Corporate for STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_TURKCELL_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = RESPONSE_CODE_APPROVE;
		;
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter = 0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();

			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);

				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_TURKCELL_INVOICE_DEBT_INQUIRY", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght = debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES", j, MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, debtLoadingMap.getString("INVOICES", j, MapKeys.INSTALLMENT_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER9));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER10));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES", j, MapKeys.TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES", j, MapKeys.TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, debtLoadingMap.getString("INVOICES", j, MapKeys.ZONE_CODE));
						counter++;
					}

				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKCELL_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int compId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String currencyCode = CURRENCY_CODE;
			String msgDate = getMsgDate();
			String procDate = getProcDate();
			String channelCode = CommonHelper.getChannelId();
			OriginatorId orig = getOriginatorId(channelCode);
			Long stan = Long.parseLong(getStanNo());
			;
			ServiceMessage serviceMessage = new ServiceMessage();
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String accDate = getAccDate();
			if (!"".equals(iMap.getString(MapKeys.RECON_DATE))) {
				accDate = iMap.getString(MapKeys.RECON_DATE);
			}
			GMMap reconInfoMap = getReconciliationInfo(corporateCode, accDate);
			int reconCount = 4;
			Object[] reconciliationInfos = (Object[]) reconInfoMap.get("RECON_INFO");
			String sessionID = getSession(iMap);
			ReconciliationResponse reconciliationResponse = TurkcellPCGClient.sendReconciliation(wsUrl, accDate, bankId, compId, currencyCode, msgDate, orig, procDate, reconCount, reconciliationInfos, sessionID, stan, serviceMessage, timeOut);

			String responseCode = reconciliationResponse.getRespCode();
			logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_COLLECTION_RECONCILIATION.");
			if (LOGON_ERR.equals(responseCode)) {
				renewSession(iMap);
				sessionID = getSession(iMap);
				reconciliationResponse = TurkcellPCGClient.sendReconciliation(wsUrl, accDate, bankId, compId, currencyCode, msgDate, orig, procDate, reconCount, reconciliationInfos, sessionID, stan, serviceMessage, timeOut);
				responseCode = reconciliationResponse.getRespCode();
				logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_COLLECTION_RECONCILIATION.");
			}
			Object[] corporateReconciliationInfo = reconciliationResponse.getReconInfo();
			logger.error(responseCode + " returned by Corporate for ICS_TURKCELL_COLLECTION_RECONCILIATION.");

			if (responseCode.equals(RESPONSE_CODE_APPROVE) || responseCode.equals(AFTER_VALID_RECON_ERR)) {

				outMap.put(MapKeys.RECON_BANK_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[0]).getTotalProcesCount());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[1]).getTotalProcesCount());
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, ((ReconciliationInfo) (ReconciliationInfo) corporateReconciliationInfo[0]).getAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[0]).getTotalProcesCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, ((ReconciliationInfo) corporateReconciliationInfo[1]).getAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[1]).getTotalProcesCount());

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconInfoMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconInfoMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			} else {

				outMap.put(MapKeys.RECON_BANK_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[0]).getTotalProcesCount());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[1]).getTotalProcesCount());
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, ((ReconciliationInfo) (ReconciliationInfo) corporateReconciliationInfo[0]).getAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[0]).getTotalProcesCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, ((ReconciliationInfo) corporateReconciliationInfo[1]).getAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, ((ReconciliationInfo) corporateReconciliationInfo[1]).getTotalProcesCount());

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconInfoMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconInfoMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconInfoMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			}

			responseCode = RESPONSE_CODE_APPROVE;
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Throwable e) {
			logger.info("ICS_TURKCELL_COLLECTION_RECONCILIATION - mutabakat hatali ");
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_CLOSE_COLLECTION_RECONCILIATION_MANUALLY")
	public static GMMap closeCollectionReconManually(GMMap input) {
		GMMap output = new GMMap();

		try {
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int compId = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String currencyCode = CURRENCY_CODE;
			String msgDate = getMsgDate();
			String procDate = getProcDate();
			String channelCode = CommonHelper.getChannelId();
			OriginatorId orig = getOriginatorId(channelCode);
			Long stan = Long.parseLong(getStanNo());
			;
			ServiceMessage serviceMessage = new ServiceMessage();
			int timeOut = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", input);
			int bankId = cdMap.getInt(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			String accDate = input.getString(MapKeys.RECON_DATE);

			GMMap reconInfoMap = getReconciliationInfo(corporateCode, accDate);
			int reconCount = 4;
			Object[] reconciliationInfos = (Object[]) reconInfoMap.get("RECON_INFO");
			String sessionID = getSession(input);

			ReconciliationResponse reconciliationResponse = TurkcellPCGClient.sendReconciliation(wsUrl, accDate, bankId, compId, currencyCode, msgDate, orig, procDate, reconCount, reconciliationInfos, sessionID, stan, serviceMessage, timeOut);
		} catch (Exception e) {

		}

		return output;
	}

	@GraymoundService("ICS_TURKCELL_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = RESPONSE_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKCELL_COLLECTION_RECONCILIATION_CLOSED");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = RESPONSE_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKCELL_GET_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	private static String getSession(GMMap input) throws Exception {
		input.put(MapKeys.SESSION_KEY, SessionHolderKeys.TURKCELL_SESSION_HOLDER);
		return CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CPS_GET_MANAGED_SESSION", input).getString(MapKeys.SESSION_VALUE);
	}

	private static void renewSession(GMMap input) throws Exception {
		input.put(MapKeys.SESSION_KEY, SessionHolderKeys.TURKCELL_SESSION_HOLDER);
		CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CPS_RENEW_MANAGED_SESSION", input);
	}

	private static String getProcTime() {
		final DateFormat procTimeFormat = new SimpleDateFormat("HHmmss");

		return procTimeFormat.format(new Date());
	}

	private static String getProcDate() {

		final DateFormat procDateFormat = new SimpleDateFormat("MMdd");

		return procDateFormat.format(new Date());
	}

	public static String getMsgDate() {

		final DateFormat msgDateTimeFormat = new SimpleDateFormat("MMddHHmmss");

		return msgDateTimeFormat.format(new Date());
	}

	private static String getAccDate() {
		final DateFormat accDateTimeFormat = new SimpleDateFormat("yyyyMMdd");

		return accDateTimeFormat.format(new Date());
	}

	private static String getPeriod() {
		final DateFormat periodFormat = new SimpleDateFormat("yyyyMM");

		return periodFormat.format(new Date());
	}

	public static String getStanNo() throws Exception {
		String tableName = "ICS_TURKCELL_STAN";
		return CorporationServiceUtil.getSequenceCode(tableName);

	}

	private static OriginatorId getOriginatorId(String channelCode) throws Exception {
		OriginatorId originatorId = new OriginatorId();
		originatorId.setBranch(BRANCH_CODE);
		originatorId.setCity(DEFAULT_CITY);
		originatorId.setTeller("12");
		String userName = "";
		if (GeneralConstants.YIM_CHANNEL_CODE.equals(channelCode)) {
			userName = NKOLAY_USER;
		}
		originatorId.setUser(userName);

		return originatorId;
	}

	private static InvoiceDetail getInvoiceDetail(GMMap iMap) throws Exception {
		InvoiceDetail invoiceDetail;
		try {
			invoiceDetail = new InvoiceDetail();
			invoiceDetail.setControlId(iMap.getString(MapKeys.PARAMETER2));
			invoiceDetail.setDuedate(iMap.getString(MapKeys.INVOICE_DUE_DATE));
			invoiceDetail.setInvAmount(Double.parseDouble(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			invoiceDetail.setInvNo(iMap.getLong(MapKeys.INVOICE_NO));
			invoiceDetail.setNameSurname(iMap.getString(MapKeys.SUBSCRIBER_NAME));
			invoiceDetail.setOrderNo(iMap.getInt(MapKeys.INSTALLMENT_NO));
			invoiceDetail.setPeriod(iMap.getString(MapKeys.PARAMETER8));
			invoiceDetail.setPrevMsisdn(iMap.getLong(MapKeys.PARAMETER4));
			invoiceDetail.setRemark(iMap.getString(MapKeys.PARAMETER5));
			invoiceDetail.setInvType(iMap.getInt(MapKeys.PARAMETER7));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return invoiceDetail;
	}

	private static InvoiceDetail getInvoiceCancelDetail(GMMap iMap) throws Exception {
		InvoiceDetail invoiceDetail;
		try {
			invoiceDetail = new InvoiceDetail();
			invoiceDetail.setControlId(iMap.getString(MapKeys.PARAMETER_2));
			invoiceDetail.setDuedate(iMap.getString(MapKeys.INVOICE_DUE_DATE));
			invoiceDetail.setInvAmount(Double.parseDouble(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			invoiceDetail.setInvNo(iMap.getLong(MapKeys.INVOICE_NO));
			invoiceDetail.setNameSurname(iMap.getString(MapKeys.SUBSCRIBER_NAME));
			invoiceDetail.setOrderNo(iMap.getInt(MapKeys.INSTALLMENT_NO));
			invoiceDetail.setPeriod(iMap.getString(MapKeys.PARAMETER_8));
			invoiceDetail.setPrevMsisdn(iMap.getLong(MapKeys.PARAMETER_4));
			invoiceDetail.setRemark(iMap.getString(MapKeys.PARAMETER_5));
			invoiceDetail.setInvType(iMap.getInt(MapKeys.PARAMETER_7));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return invoiceDetail;
	}

	public static GMMap getReconciliationInfo(String corporateCode, String date) throws Exception {
		GMMap outMap = new GMMap();
		ArrayList reconInfoList = new ArrayList();
		GMMap iMap = new GMMap();
		iMap.put(MapKeys.CORPORATE_CODE, corporateCode);
		iMap.put(MapKeys.RECON_DATE, date);
		ReconciliationInfo recInfo = new ReconciliationInfo();

		GMMap getBankPaymentsMap = getBankPayments(iMap.getString(MapKeys.RECON_DATE), corporateCode);
		GMMap getBankPaymentCancelsMap = getBankPaymentCancels(iMap.getString(MapKeys.RECON_DATE), corporateCode);
		int bankPaymentCount = getBankPaymentsMap.getInt(MapKeys.RECON_BANK_COUNT);
		int bankPaymentCancelCount = getBankPaymentCancelsMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);

		recInfo.setAmount(Double.valueOf(getBankPaymentsMap.getString("TOTAL_AMOUNT")));
		recInfo.setTotalProcesCount(new Long(bankPaymentCount));
		recInfo.setOpType(17);
		recInfo.setStatus(0);
		reconInfoList.add(recInfo);

		recInfo = null;
		recInfo = new ReconciliationInfo();
		recInfo.setAmount(Double.valueOf(getBankPaymentCancelsMap.getString("TOTAL_AMOUNT")));
		recInfo.setTotalProcesCount(new Long(bankPaymentCancelCount));
		recInfo.setOpType(27);
		recInfo.setStatus(0);
		reconInfoList.add(recInfo);

		GMMap sorMap = getBankStandingOrders(iMap.getString(MapKeys.RECON_DATE), corporateCode);
		GMMap sorcMap = getBankStandingOrderCancels(iMap.getString(MapKeys.RECON_DATE), corporateCode);
		int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
		int bankOrderCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);

		recInfo = null;
		recInfo = new ReconciliationInfo();
		recInfo.setTotalProcesCount(new Long(bankOrderCount));
		recInfo.setOpType(49);
		recInfo.setStatus(0);
		reconInfoList.add(recInfo);

		recInfo = null;
		recInfo = new ReconciliationInfo();

		recInfo.setTotalProcesCount(new Long(bankOrderCancelCount));
		recInfo.setOpType(50);
		recInfo.setStatus(0);
		reconInfoList.add(recInfo);

		outMap.put(MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankPaymentCancelCount);
		outMap.put(MapKeys.RECON_COLLECTION_COUNT, bankPaymentCount);
		outMap.put(MapKeys.RECON_STANDINGORDER_CANCEL_COUNT, bankOrderCancelCount);
		outMap.put(MapKeys.RECON_STANDINGORDER_COUNT, bankOrderCount);
		outMap.put(MapKeys.RECON_COLLECTION_TOTAL, getBankPaymentsMap.get("TOTAL_AMOUNT"));
		outMap.put(MapKeys.RECON_COLLECTION_CANCEL_TOTAL, getBankPaymentCancelsMap.get("TOTAL_AMOUNT"));

		outMap.put("RECON_INFO", reconInfoList.toArray());
		return outMap;

	}

	public static GMMap getBankPayments(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_PAYMENTS";
		String strSQLPayment = "";
		// strSQLPayment = "SELECT subscriber_no1,payment_amount, total_amount "
		// +
		// " FROM ics.invoice_payment,  (SELECT SUM(payment_amount) AS TOTAL_AMOUNT  FROM ics.invoice_payment  WHERE corporate_code ='"
		// + corporateCode + "' AND payment_date LIKE '"
		// + reconcilitionDate + "%'" + " AND status=1" + ") t "
		// + " WHERE corporate_code ='" + corporateCode + "'" +
		// " AND payment_date LIKE '"
		// + reconcilitionDate + "%' AND status=1";
		strSQLPayment = String.format(QueryRepository.TurkcellServicesRepository.GET_BANK_PAYMENT, corporateCode, reconcilitionDate, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLPayment, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			returnMap.put("TOTAL_AMOUNT", returnMap.get(TABLE_NAME, 0, "TOTAL_AMOUNT"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			returnMap.put("TOTAL_AMOUNT", 0);
		}

		return returnMap;
	}

	public static GMMap getBankPaymentCancels(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCEL";
		String strSQLCancel = "";
		// strSQLCancel = "SELECT subscriber_no1, payment_amount, total_amount "
		// +
		// "FROM ics.invoice_payment , (SELECT SUM(payment_amount) AS TOTAL_AMOUNT  FROM ics.invoice_payment  WHERE corporate_code ='"
		// + corporateCode + "' AND cancel_date LIKE '"
		// + reconcilitionDate + "%' AND status=1 ) t "
		// + " WHERE corporate_code ='" + corporateCode + "'" +
		// " AND cancel_date LIKE '"
		// + reconcilitionDate + "%'"+ "AND payment_status='I' AND status=1" ;
		strSQLCancel = String.format(QueryRepository.TurkcellServicesRepository.GET_BANK_PAYMENT_CANCEL, corporateCode, reconcilitionDate, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLCancel, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, al.size());
			returnMap.put("TOTAL_AMOUNT", returnMap.get(TABLE_NAME, 0, "TOTAL_AMOUNT"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
			returnMap.put("TOTAL_AMOUNT", 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrders(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		// strSQLTalimat = "SELECT subscriber_no1 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + " AND m.create_date LIKE '" +
		// reconcilitionDate + "%' AND i.status=1 and m.status=1";
		strSQLTalimat = String.format(QueryRepository.TurkcellServicesRepository.GET_BANK_STANDING_ORDER, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrderCancels(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";

		// strSQLIptal = "SELECT subscriber_no1 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + " AND m.cancel_date LIKE '" +
		// reconcilitionDate + "%' AND i.status=1 and m.status=1";
		strSQLIptal = String.format(QueryRepository.TurkcellServicesRepository.GET_BANK_STANDING_ORDER_CANCEL, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
		}
		return returnMap;

	}

	public static void insertOnlineServiceLogForSessionID(GMMap insertParameters, GMMap responseMap, String stanNo) {
		GMMap iMap = insertParameters;
		GMMap outMap = responseMap;
		iMap.put(MapKeys.INPUT_MAP_STRING, insertParameters.toString());
		if (responseMap.containsKey(MapKeys.ERROR_CODE)) {
			iMap.put(MapKeys.ERROR_CODE, responseMap.getString(MapKeys.ERROR_CODE));
			iMap.put(MapKeys.ERROR_DESC, responseMap.getString(MapKeys.ERROR_DESC));
		}
		iMap.put(MapKeys.RESPONSE_MAP_STRING, responseMap.toString());
		iMap.put(MapKeys.CORPORATE_CODE, "TS");
		iMap.put(MapKeys.SERVICE_STATUS, "0");
		iMap.put(MapKeys.STAN_NO, stanNo);
		iMap.put(MapKeys.GM_SERVICE_NAME, "SESSION");
		iMap.put(MapKeys.WS_ENDPOINT, "");
		iMap.put(MapKeys.WS_SERVICE_NAME, "TURKCELL_SESSION");
		iMap.put(MapKeys.RESPONSE_MAP_STRING, responseMap.toString());

		insertOnlineServiceLog(iMap, outMap);
	}
	
	@GraymoundService("ICS_TURKCELL_MANAGE_STAN")
	public static GMMap manageStan(GMMap input){
		GMMap output = new GMMap();
		
		try{
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='ICS_TURKCELL_STAN'");
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

}
