package tr.com.aktifbank.bnspr.corporation.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.gov.iski.ths.bankahesapgozlem.webservis.IskiOnlineBankAccountClient;
import tr.gov.iski.ths.bankahesapgozlem.webservis.ServiceMessage;
import tr.gov.iski.ths.bankahesapgozlem.webservis.Sonuc;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class IskiBankAccountObservationServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(IskiBankAccountObservationServices.class);

	@GraymoundService("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION")
	public static GMMap onlineBankAccountObservation(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION");
		ServiceMessage message = new ServiceMessage();
		String emailTitle = "ISKI hesap bildirmi batch'i calisma raporu";
		StringBuilder emailBody = new StringBuilder();
		List<String> emailRecipientList = new ArrayList<String>();
		List<String> emailCCList = new ArrayList<String>();
		String emailFrom = "";
		String callWebService="YES";
		try {
			if (iMap.containsKey("CALL_WEB_SERVICE")) {
				if (!"".equals(iMap.getString("CALL_WEB_SERVICE"))) {
					callWebService=iMap.getString("CALL_WEB_SERVICE");	
				}
			}
			emailRecipientList.add(CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "EMAIL_RECIPIENT_LIST"));
			emailCCList.add(CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "EMAIL_CC_LIST"));
			emailFrom = CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "EMAIL_FROM");

			Date date = iMap.getDate("DATE");
			Integer year = CommonHelper.getYear(date);
			Integer month = CommonHelper.getMonth(date);
			Integer day = CommonHelper.getDay(date);
			String corporateOid = CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "CORPORATE_OID");
			String islemKod = "";
			String islemAciklama = "";
			String username = CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "USERNAME");
			String password = "";
			String url = CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "URL");
			String bankaKodu = CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "BANK_CODE");
			String accountNoQueryStr = "select hesap_no from bnspr.muh_hesap where iban = '%s'";
			String balanceQueryStr = "select bakiye from bnspr.muh_hesap_gunluk_bakiye where hesap_no = %s and yil = %s and ay = %s and gun = %s";
			String iban = "";
			String hesapNo = "";
			String borcTutar = "";
			String bakiye = "";
			String alacakTutar = "";
			String subeKodu = "";
			String ibanTarihi = "";
			String sifre = CommonHelper.getValueOfParameter("ISKI_ONLINE_EKSTRE_PARAMETERS", "PASSWORD");
			ServiceMessage serviceMessage = new ServiceMessage();
			StringBuilder sb = new StringBuilder();
			// sb.append("select IBAN from bnspr.muh_hesap where hesap_no in");
			// sb.append("(select account_number from cdm.corporation_account_master where corporate_oid='");
			// sb.append(corporateOid);
			// sb.append("' and status=1)");
			GMMap getCorpDefInput=new GMMap();
			getCorpDefInput.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
			GMMap corpDef=CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", getCorpDefInput);
			
			sb.append(String.format(QueryRepository.IskiBankAccountObservationServicesRepository.GET_ACCOUNT_LIST_FROM_DEFINITION, corpDef.getString(TransactionConstants.GetCorporateDefinition.Output.CUSTOMER_NUMBER)));
			GMMap returnMap2 = CommonHelper.queryData(sb.toString(), "IBAN_LIST");

			// email body haz�rla
			emailBody.append("<html><body>");

			for (int i = 0; i < returnMap2.getSize("IBAN_LIST"); i++) {
				GMMap input = new GMMap();
				GMMap accounNoOutMap = new GMMap();
				StringBuilder accountNoQuery = new StringBuilder();
				// hesap hareketlerini al
				iban = returnMap2.getString("IBAN_LIST", i, "IBAN");
				accountNoQuery.append(accountNoQueryStr);
				accounNoOutMap = CommonHelper.queryData(String.format(accountNoQuery.toString(), iban), "ACCOUNT_NO");
				hesapNo = accounNoOutMap.getString("ACCOUNT_NO", 0, "HESAP_NO");
				input.put("IBAN", iban);
				if (iMap.getString("DATE")!=null) {
					input.put("oncekiGun",  CommonHelper.getDateString(CommonHelper.addDay(iMap.getDate("DATE"), -1), "dd/MM/yyyy"));
					input.put("sonrakiGun", CommonHelper.getDateString(CommonHelper.addDay(iMap.getDate("DATE"), 1), "dd/MM/yyyy"));
					input.put("islemTarihi", CommonHelper.getDateString(iMap.getDate("DATE"),"dd/MM/yyyy"));
				}else{
					input.put("islemTarihi", CommonHelper.getDateString(CommonHelper.addDay(new Date(), -1), "dd/MM/yyyy"));
					input.put("oncekiGun",  CommonHelper.getDateString(CommonHelper.addDay(new Date(), -2), "dd/MM/yyyy"));
					input.put("sonrakiGun", CommonHelper.getDateString(new Date(), "dd/MM/yyyy"));
				}
				
				GMMap outMapServiceCall = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_EXT_ISKI_GET_OZET_HAREKETLER", input);
				String hataAciklama = outMapServiceCall.getString("hesap", 0, "hataAciklama");
				String subeAdi = outMapServiceCall.getString("hesap", 0, "subeAdi");
				String hataKodu = outMapServiceCall.getString("hesap", 0, "hataKodu");

				// hatakodu 0 geldi ise hesap hareket alimi basarili gerceklesti
				if ("OK".equals(hataAciklama) && "0".equals(hataKodu)) {
					// paket basarili olarak cagirildi
					iban = outMapServiceCall.getString("hesap", 0, "IBAN");

					// hesap hareket detayini al
					GMMap inMap = new GMMap();
					inMap.put("GunlukHareket", outMapServiceCall.get("hesap", 0, "GunlukHareket"));
					if (inMap.getString("GunlukHareket", 0, "bakiye") == null) {
						bakiye = "0.0";
					} else {
						GMMap balanceOutMap = new GMMap();
						StringBuilder balanceQuery = new StringBuilder();
						balanceQuery.append(balanceQueryStr);
						balanceOutMap = CommonHelper.queryData(String.format(balanceQuery.toString(), hesapNo, year, month, day), "BALANCE");
						bakiye = balanceOutMap.getString("BALANCE", 0, "BAKIYE").replace(",", ".");
					}
					if (inMap.getString("GunlukHareket", 0, "alacakTutar") == null) {
						alacakTutar = "0.0";
					} else {
						alacakTutar = inMap.getString("GunlukHareket", 0, "alacakTutar").replace(",", ".");
					}
					if (inMap.getString("GunlukHareket", 0, "islemTarihi") == null) {
						ibanTarihi = CommonHelper.getDateString(CommonHelper.addDay(new Date(), -1), "dd/MM/yyyy");
					} else {
						ibanTarihi = inMap.getString("GunlukHareket", 0, "islemTarihi");
					}

					if (inMap.getString("GunlukHareket", 0, "borcTutar") == null) {
						borcTutar = "0.0";
					} else {
						borcTutar = inMap.getString("GunlukHareket", 0, "borcTutar").replace(",", ".");
					}
					// ibandan sube kodunu bul
					StringBuilder sbSubeKodu = new StringBuilder();
					// sbSubeKodu.append("select sube_kodu from bnspr.muh_hesap where iban='");
					// sbSubeKodu.append(iban);
					// sbSubeKodu.append("'");
					sbSubeKodu.append(String.format(QueryRepository.IskiBankAccountObservationServicesRepository.GET_BRANCH_CODE, iban));
					GMMap returnMapSubeKodu = CommonHelper.queryData(sbSubeKodu.toString(), "SUBE_KODU_MAP");

					subeKodu = returnMapSubeKodu.getString("SUBE_KODU_MAP", 0, "SUBE_KODU");
					Sonuc ekstreGonderimSonuc =null;
					if ("YES".equals(callWebService)) {
						// iski web servisi cagir
						logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> web servis cagirilacak");
						ekstreGonderimSonuc = IskiOnlineBankAccountClient.ekstreGonderim(username, password, url, bankaKodu, sifre, iban, borcTutar.replace(",", "."), bakiye.replace(",", "."), alacakTutar.replace(",", "."), subeKodu, ibanTarihi, serviceMessage);
						logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> web servis cagirildi");
					}else{						
						logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> web servis cagrilmadi");
						ekstreGonderimSonuc=new Sonuc();
						ekstreGonderimSonuc.setIslemKod("00");
						serviceMessage.setRequest("Web Servis Cagrisi Yapilmadi!");
						serviceMessage.setResponse("Web Servis Cagrisi Yapilmadi!");
					}

					output.put("REQUEST_XML_".concat(Integer.toString(i)).concat("="), serviceMessage.getRequest());
					output.put("RESPONSE_XML_".concat(Integer.toString(i)).concat("="), serviceMessage.getResponse());
					logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> request XML".concat(serviceMessage.getRequest()));
					logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> response XML".concat(serviceMessage.getResponse()));
					// 00 servis basarili cagirildi demek
					if ("00".equals(ekstreGonderimSonuc.getIslemKod())) {
						emailBody.append("IBAN : ");
						emailBody.append(iban);
						emailBody.append("<br>");

						emailBody.append("Sube Adi : ");
						emailBody.append(subeAdi);
						emailBody.append("<br>");

						emailBody.append("Sube Kodu : ");
						emailBody.append(subeKodu);
						emailBody.append("<br>");

						emailBody.append("Islem Tarihi : ");
						emailBody.append(ibanTarihi);
						emailBody.append("<br>");

						emailBody.append("Alacak Tutar : ");
						emailBody.append(alacakTutar);
						emailBody.append("<br>");

						emailBody.append("Borc Tutar : ");
						emailBody.append(borcTutar);
						emailBody.append("<br>");

						emailBody.append("Bakiye : ");
						emailBody.append(bakiye);
						emailBody.append("<br>");

						emailBody.append("<br>");
						emailBody.append("<br>");
					} else {
						if (!ekstreGonderimSonuc.getIslemKod().isEmpty()) {
							islemKod = ekstreGonderimSonuc.getIslemKod();
							islemAciklama = ekstreGonderimSonuc.getIslemAciklama();
							emailBody.append("<br>IBAN=");
							emailBody.append(iban);
							emailBody.append("<br>Borc Tutar=");
							emailBody.append(borcTutar);
							emailBody.append("<br>Bakiye=");
							emailBody.append(bakiye);
							emailBody.append("<br>Alacak Tutar=");
							emailBody.append(alacakTutar);
							emailBody.append("<br>Tarih=");
							emailBody.append(ibanTarihi);
							emailBody.append("<br>Sube Kodu=");
							emailBody.append(subeKodu);
							emailBody.append("<br>Sube Adi=");
							emailBody.append(subeAdi);
							emailBody.append("<br>");
							emailBody.append("<br>");
							emailBody.append("<br>Hata Kodu : ");
							emailBody.append(islemKod);
							emailBody.append("<br>Hata Aciklamasi : ");
							emailBody.append(islemAciklama);
							emailBody.append("<br>");
							emailBody.append("----------------------------------");
						} else {
							logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> web servisten beklenen cevap gelmedi.");
							emailTitle = "ISKI hesap bildirmi hata aldi!";
							emailBody.append("ISKI Online ekstre cagriminde hata meydana geldi!");
						}
					}
				} else {
					// paket cagirimi basrisiz oldu
					logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> paket cagirimi basarisiz oldu.");
				}
			}
			// email body sonlandir
			if (!callWebService.equals("YES")) {
				emailBody.append("<br>Not: ISKI web servis cagrisi yapilmamistir. Bu mail sadece bilgi amaclidir.<br>");	
			}
			emailBody.append("</body></html>");
			CommonHelper.sendMail(emailRecipientList, emailCCList, emailFrom, true, emailTitle, emailBody.toString());
			logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> mail basarili olarak gonderildi.");
		} catch (Exception e) {
			logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION servisinde hata meydana geldi -> ".concat(CommonHelper.getStringifiedException(e)));
			emailTitle = "ISKI online ekstre hesap bildirimi hata aldi!";
			emailBody.append("<br>");
			emailBody.append("ISKI Online ekstre cagriminde hata meydana geldi!");
			emailBody.append("<br><br>");
			emailBody.append(CommonHelper.getStringifiedException(e));
			emailBody.append("<br><br>");
			emailBody.append("</body></html>");
			CommonHelper.sendMail(emailRecipientList, emailCCList, emailFrom, true, emailTitle, emailBody.toString());
		} finally {
			logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> Email Title = ".concat(emailTitle));
			logger.info("ICS_ISKI_ONLINE_BANK_ACCOUNT_OBSERVATION -> Email Body  = ".concat(emailBody.toString()));
		}
		return output;
	}

	public static void sendNotificationEmail() {

	}

}
