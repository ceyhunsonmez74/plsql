package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.GaskiUniversalReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.GaskiUniversalClient;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.gaski.BgsTahakDto;
import tr.com.gaski.BgsTahsilDto;
import tr.com.gaski.BgsTahsilKaydiDto;
import tr.com.gaski.FindAllSbsMuhatapGenelResponse;
import tr.com.gaski.FindBorcSorguResponse;
import tr.com.gaski.SbsMuhatapGenelDto;
import tr.com.gaski.TahsilIcmaliResponse;
import tr.com.gaski.TahsilKaydiIptalEtResponse;
import tr.com.gaski.TahsilKaydiOlusturResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class GaskiServicesUniversal extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(GaskiServicesUniversal.class);

	@GraymoundService("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage sm = new ServiceMessage();
		List<BgsTahakDto> borcList = new ArrayList<BgsTahakDto>();
		FindBorcSorguResponse response = null;
		
		try {
			// parameters are taken
			String aboneNo = null;
			String muhattapId = null;
			String identityNo = null;
			String vergiNo = null;
			String beyanId = null;
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String findMuhatapServiceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			if ("S".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3))) {
				muhattapId = iMap.getString(MapKeys.SUBSCRIBER_NO1);	
				identityNo = iMap.getString(MapKeys.SUBSCRIBER_NO2, "");
			}else{
				aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}			
			
			// logger info will be logged
			builder.append(" ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Sicil Numarasi -> ");
			builder.append(aboneNo);
			builder.append(" | beyanId -> ");
			builder.append(beyanId);
			builder.append(" | UserName -> ");
			builder.append(applicationKey);
			builder.append(" | Password -> ");
			builder.append(securityCode);
			builder.append(" | URL -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());
			
			logger.info("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - GaskiUniversalClient.findAllSbsMuhatapGenel(...) will be called..."));


			if(identityNo != null && !StringUtils.isEmpty(identityNo)){
				FindAllSbsMuhatapGenelResponse muhatapGenelResponse = GaskiUniversalClient.findAllSbsMuhatapGenel(findMuhatapServiceUrl, applicationKey, securityCode, identityNo, vergiNo, sm);
				
				for(SbsMuhatapGenelDto muhatapGenelDTO: muhatapGenelResponse.getList()) {
					String muhatapId = muhatapGenelDTO.getSbsMuhatapId().toString();
					response = GaskiUniversalClient.findBorcSorgu(serviceUrl, applicationKey, securityCode, muhatapId, aboneNo, sm);
					if(response.getBgsBorcSorguDto() != null && response.getBgsBorcSorguDto().getListBgsTahakDto().size() > 0){
						borcList.addAll(response.getBgsBorcSorguDto().getListBgsTahakDto());
					}
				}
				aboneNo = identityNo;
			} else if(muhattapId != null && !StringUtils.isEmpty(muhattapId)){
				response = GaskiUniversalClient.findBorcSorgu(serviceUrl, applicationKey, securityCode, muhattapId, aboneNo, sm);
				if(response.getBgsBorcSorguDto() != null && response.getBgsBorcSorguDto().getListBgsTahakDto().size() > 0){
					borcList = response.getBgsBorcSorguDto().getListBgsTahakDto();
				}
			} else if(aboneNo != null && StringUtils.isEmpty(muhattapId)){
				response = GaskiUniversalClient.findBorcSorgu(serviceUrl, applicationKey, securityCode, muhattapId, aboneNo, sm);
				if(response.getBgsBorcSorguDto() != null && response.getBgsBorcSorguDto().getListBgsTahakDto().size() > 0){
					borcList = response.getBgsBorcSorguDto().getListBgsTahakDto();
				}
			}			
			
			//response = GaskiUniversalClient.findBorcSorgu(serviceUrl, applicationKey, securityCode, muhattapId, aboneNo, sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - GaskiUniversalClient.findBorcSorgu(...) returned response code ".concat(response.getResultCode())));
			
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - GaskiClient.findBorcSorgu(...) returned errorCode ".concat(errorCode)));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Map<String,Integer> termGroupList = new HashMap<String, Integer>();
				int groupCounter = 1;
				
				for ( BgsTahakDto borc : borcList) {
					if (!isCollectedInvoice(String.valueOf(borc.getBgsTahakId()), aboneNo, "", "", "", corporateCode)) {
						
						String faturaNo = borc.getFaturNo();
						String groupId = "";
						if(termGroupList.containsKey(faturaNo)){
							groupId = String.valueOf(termGroupList.get(faturaNo));
						}
						else{
							groupId = String.valueOf(groupCounter++);
							termGroupList.put(faturaNo, Integer.valueOf(groupId));
						}
						
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, aboneNo);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getSbsMuhatapId());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getFaturNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorcTutari().add(borc.getGecikmeZammi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getIsim());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getVadeTarihi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getYil());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getDonem());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorcTutari().add(borc.getGecikmeZammi()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, borc.getBgpServisAdi()+"-"+borc.getBgpGelirkodAdi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, aboneNo);
						outMap.put(MapKeys.INVOICE_LIST, counter, "GROUP_ID", groupId);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - GaskiUniversalClient.findBorcSorgu(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}

	@GraymoundService("ICS_GASKI_UNIVERSAL_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		try {
			// parameters are taken
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String vezneSifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String islemNo=iMap.getString(MapKeys.TRX_NO);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			BigDecimal toplamTutar=iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = iMap.getString(MapKeys.PAYMENT_DATE);
			} else {
				tahsilatTarihi = CommonHelper.getLongDateTimeString(new Date());
			}
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_GASKI_UNIVERSAL_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | Tahakkuk No -> ");
			builder.append(faturaNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			logger.info(builder.toString());

			if (isStandingOrderCollection) {
				logger.info("ICS_GASKI_UNIVERSAL_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - GaskiUniversalClient.tahsilKaydiOlustur(...) before call..").concat("isStandingOrderCollection:true"));
			}else{
				logger.info("ICS_GASKI_UNIVERSAL_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - GaskiUniversalClient.tahsilKaydiOlustur(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			ServiceMessage sm = new ServiceMessage();
			BgsTahsilKaydiDto tahsilKaydiDto = new BgsTahsilKaydiDto();
			tahsilKaydiDto.setBtsVezneId(Long.valueOf(vezneId));
			tahsilKaydiDto.setBtsVezneSifre(vezneSifre);			
			tahsilKaydiDto.setTahsilTarihi(new SimpleDateFormat("yyyyMMddhhmmss").parse(tahsilatTarihi));
			tahsilKaydiDto.setFaturaNo(faturaNo);
			tahsilKaydiDto.setIslemNo(islemNo);
			tahsilKaydiDto.setToplamTutar(toplamTutar);
			List<BgsTahsilDto> listBgsTahsilDto = new ArrayList<BgsTahsilDto>();
			BgsTahsilDto tahsilDto = new BgsTahsilDto();
//			tahsilDto.set
//			listBgsTahsilDto.add(tahsilDto );
			tahsilKaydiDto.setListBgsTahsilDto(listBgsTahsilDto );			
			TahsilKaydiOlusturResponse response = GaskiUniversalClient.tahsilKaydiOlusturByFatura(serviceUrl, applicationKey, securityCode, tahsilKaydiDto , sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			
			responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && response.getListBgsTahsilSonucMakbuzDto().size() > 0) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(String.valueOf(response.getListBgsTahsilSonucMakbuzDto().get(0).getBgsTahsilGenelId()));
				session.saveOrUpdate(invoicePayment);
			}
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			logger.info("ICS_GASKI_UNIVERSAL_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - GaskiUniversalClient.tahsilKaydiOlustur(...) returned errorCode ".concat(response.getResultCode())));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_GASKI_UNIVERSAL_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String btsVezneSifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
//			String aboneNo = iMap.getString("SUBSCRIBER_NO_1", null);
//			if (aboneNo == null) {
//				aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
//			}
			
			String bgsTahsilGenelId = iMap.getString(MapKeys.PARAMETER_2, null);
			if (bgsTahsilGenelId == null) {
				bgsTahsilGenelId = iMap.getString(MapKeys.PARAMETER2);
			}
			
			builder.append(" ICS_GASKI_UNIVERSAL_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis No -> ");
			builder.append(bgsTahsilGenelId);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			builder.append(" | serviceUrl -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			TahsilKaydiIptalEtResponse response = GaskiUniversalClient.tahsilKaydiIptalEt(serviceUrl, applicationKey, securityCode, vezneId, bgsTahsilGenelId,btsVezneSifre, sm);
						
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_GASKI_UNIVERSAL_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_GASKI_UNIVERSAL_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response.getResultCode()));
			
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String applicationKey = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String vezneId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(reconDate);
			builder.append(" | applicationKey -> ");
			builder.append(applicationKey);
			builder.append(" | securityCode -> ");
			builder.append(securityCode);
			builder.append(" | End Point -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());
			
			ServiceMessage sm = new ServiceMessage();
			TahsilIcmaliResponse response = GaskiUniversalClient.tahsilIcmali(serviceUrl, applicationKey, securityCode, reconDate, vezneId, sm);
			GMMap responceCodeMap = getResponseCodeMapping(response.getResultCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getResultMessage());
			iMap.put("REQUEST_TXT", sm.getRequest());
			output.put("RESPONSE_TXT", sm.getResponse());

			if (response.getBgsTahsilIcmalDto() == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION - result size 0 geldi");

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION - response.getBgsTahsilIcmalDto() null degil");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getBgsTahsilIcmalDto().getTahsilEdilenTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getBgsTahsilIcmalDto().getTahsilAdedi());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getBgsTahsilIcmalDto().getIptalEdilenTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getBgsTahsilIcmalDto().getIptalAdedi());
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_GASKI_UNIVERSAL_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_GASKI_UNIVERSAL_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new GaskiUniversalReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_GASKI_UNIVERSAL_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER is started...");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String toDayToCompare = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			GMMap sorMap = getBankStandingOrdersForGaski(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER recon count to check is ".concat(Integer.toString(reconCollectionCount)));
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				String subscriberNumber = CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0');
				logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" will be called.."));
				iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNumber);
				iMap.put(MapKeys.COLLECTION_TYPE, "0");
				iMap.put(MapKeys.COLLECTION_TYPE_NAME, "Fatura Odeme");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GASKI_UNIVERSAL_INVOICE_DEBT_INQUIRY", iMap);
				int billNumber = reconBankMap.getSize(MapKeys.INVOICE_LIST);
				logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" is called and return map").concat(reconBankMap.toString()).concat(" and bill number is").concat(Integer.toString(billNumber)));
				if (billNumber > 0) {
					for (int z = 0; z < billNumber; z++) {
						logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" compares date invoice date -> ").concat(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE).toString()).concat(" with todays date -> ").concat(toDayToCompare));
						if (toDayToCompare.equals(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE))) {
							logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" returned result which matches due date with today..."));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	
	public static GMMap getBankStandingOrdersForGaski(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER is called getBankStandingOrdersForGaski...");
		StringBuilder sb = new StringBuilder();
		sb.append(String.format(QueryRepository.GaskiServicesRepository.GET_BANK_STANDING_ORDERS, reconcilitionDate, reconcilitionDate, corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER found ".concat(Integer.toString(al.size())).concat(" standing order for GASKI"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			logger.info("ICS_GASKI_UNIVERSAL_DEBT_INQUERY_FOR_STANDING_ORDER found 0 standing order");
		}
		return returnMap;
	}
	
	
	@GraymoundService("STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(tesisatNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(tesisatNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_GASKI_UNIVERSAL_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	
}



