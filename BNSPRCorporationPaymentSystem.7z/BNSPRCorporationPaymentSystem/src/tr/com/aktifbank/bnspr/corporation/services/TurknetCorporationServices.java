package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.tempuri.TalimatIslemi;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.StandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TurknetCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TurknetStandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.ServiceResponseCodeMapping;
import tr.com.aktifbank.integration.turknet.client.TurknetClient;
import tr.com.aktifbank.integration.turknet.dto.base.ResultDto;
import tr.com.aktifbank.integration.turknet.dto.collection.BillInvoiceDto;
import tr.com.aktifbank.integration.turknet.dto.reconciliation.ReconciliationSummaryDto;
import tr.com.aktifbank.integration.turknet.dto.reconciliation.StandingOrderReconciliationSummaryDto;
import tr.com.aktifbank.integration.turknet.wrapper.BaseResponse;
import tr.com.aktifbank.integration.turknet.wrapper.BillInvoiceResponse;
import tr.com.aktifbank.integration.turknet.wrapper.ReconciliationSummaryResponse;
import tr.com.aktifbank.integration.turknet.wrapper.StandingOrderReconciliationSummaryResponse;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TurknetCorporationServices extends OnlineCorporationInterface implements OnlineInstitutionConstants{

	private static final String CORPORATE_DATE_FORMAT = "yyyyMMdd";
	private static final String PAYMENT_CHANNEL = "0";
	private static final Log logger = LogFactory.getLog(TurknetCorporationServices.class);
	
	private static class ResponseCodes{
		private static final String SUCCESS = "0";
	}
	
	@GraymoundService("ICS_TURKNET_INVOICE_DEBT_INQUIRY")
	public static GMMap invoiceDebtInquiry(GMMap iMap) {
		
		logger.info("[TurknetCorporationServices[invoiceDebtInquiry]] is started. Parameters : "+iMap);
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_INVOICE_DEBT_INQUIRY");

		GMMap output = new GMMap();
		
		try {	
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			TurknetClient client = getSoapClient(iMap);

			BillInvoiceResponse debtInquiryResponse = client.debtInquiry(subscriberNo);
			
			if( null != debtInquiryResponse ){
				if( null != debtInquiryResponse.getResponse() && debtInquiryResponse.getResponse().getReturnCode().equals(ResponseCodes.SUCCESS)){
					int counter = 0;
					if( null != debtInquiryResponse.getInvoices() && debtInquiryResponse.getInvoices().size() > 0 ){
						List<BillInvoiceDto> invoices = debtInquiryResponse.getInvoices();
						for( BillInvoiceDto unpaidInvoice : invoices){
							
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, unpaidInvoice.getInvoiceNo());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, unpaidInvoice.getInvoiceAmt());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, unpaidInvoice.getSubscriberName());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, unpaidInvoice.getInvoiceDate().substring(0,4));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, unpaidInvoice.getInvoiceDate().substring(4,6));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, unpaidInvoice.getInvoiceAmt());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, unpaidInvoice.getDueDate());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, unpaidInvoice.getInvoiceDate());
							output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}
				}
			}
				else{
					GMMap codeMapping = getResponseCodeMapping(debtInquiryResponse.getResponse().getReturnCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
					output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
				}
				
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		} 
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	@GraymoundService("ICS_TURKNET_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_DO_INVOICE_COLLECTION");

		logger.info("[TurknetCorporationServices[doInvoiceCollection]] is started. Parameters : "+iMap);
		
		GMMap output = new GMMap();
		try {	
			
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			
			String paymentDate = null;
			if( null != iMap.getString(MapKeys.PAYMENT_DATE) && iMap.getString(MapKeys.PAYMENT_DATE).length() > 8 ){
				paymentDate = CommonHelper.getDateString(new Date(), CORPORATE_DATE_FORMAT);
			}
			else{
				paymentDate = CommonHelper.getDateString(getInputDateOrDefault(iMap, MapKeys.PAYMENT_DATE, CORPORATE_DATE_FORMAT), CORPORATE_DATE_FORMAT);
			}
			
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			
			logger.info("[TurknetCorporationServices[doInvoiceCollection]] is started. Sending Parameters : Subscriber No : " + subscriberNo + " Invoice No : " + invoiceNo +
					" Payment Date : " + paymentDate + " Payment Amount : " + paymentAmount);
			
			TurknetClient client = getSoapClient(iMap);
			
			BaseResponse invoiceCollectionResponse = client.doInvoiceCollection(subscriberNo, invoiceNo, paymentDate, PAYMENT_CHANNEL, paymentAmount);
			if( null != invoiceCollectionResponse && null != invoiceCollectionResponse.getResponse() ){
				ResultDto response = invoiceCollectionResponse.getResponse();
				if( null != response ){
					if( ResponseCodes.SUCCESS.equals(response.getReturnCode()) ){
						output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					}
					else{
						setErrorCodeToOutput(invoiceCollectionResponse,iMap,output);			
					}
				}
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	@GraymoundService("ICS_TURKNET_CANCEL_COLLECTION")
	public static GMMap cancelCollection(GMMap iMap) {
		GMMap output = new GMMap();
		
		logger.info("[TurknetCorporationServices[cancelCollection]] is started. Parameters : "+iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_CANCEL_COLLECTION");
		
		try{
			String invoicePaymentDate = CommonHelper.getDateString(new Date(), CORPORATE_DATE_FORMAT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String subceriberNo1 = iMap.getString("SUBSCRIBER_NO_1");
			iMap.put(MapKeys.SUBSCRIBER_NO1, subceriberNo1);
			
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			
			logger.info("[TurknetCorporationServices[cancelCollection]] Values will be used are : Invoice Payment Date :"+ invoicePaymentDate + 
					"Corporate Code :" + corporateCode );
			
			TurknetClient client = getSoapClient(iMap);
			BaseResponse cancelInvoicePaymentResponse = client.cancelInvoiceCollection(subceriberNo1, invoiceNo);
			
			if( null != cancelInvoicePaymentResponse ){
				if( null != cancelInvoicePaymentResponse.getResponse() && 
						cancelInvoicePaymentResponse.getResponse().getReturnCode().equals(ResponseCodes.SUCCESS) ){
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
				else{
					setErrorCodeToOutput(cancelInvoicePaymentResponse, iMap, output);
				}
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	
	
	@GraymoundService("STO_TURKNET_SAVE_STANDING_ORDER")
	public static GMMap saveStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_TURKNET_SAVE_STANDING_ORDER");
		
		logger.info("[TurknetCorporationServices[saveStandingOrder]] is started. Parameters : "+iMap);
		
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_SAVE_STANDING_ORDER");
		try{
			String date = CommonHelper.getDateString(getInputDateOrDefault(iMap, MapKeys.RECON_DATE_BEGIN, CORPORATE_DATE_FORMAT), CORPORATE_DATE_FORMAT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			logger.info("[TurknetCorporationServices[saveStandingOrder]] Values will be used are : " +
					"Corporate Code :" + corporateCode + "Process Date : " + date + " Subscriber No : " + subscriberNo);
			
			TurknetClient client = getSoapClient(iMap);
			String standingOrderType = TurknetStandingOrderType.SAVE.getDescription();
			
			BaseResponse stoResponse = client.saveStandingOrder(subscriberNo, prepareStandingOrderRequest(standingOrderType));
			
			if( null != stoResponse ){
				if( null != stoResponse.getResponse() && !stoResponse.getResponse().getReturnCode().equals(ResponseCodes.SUCCESS) ){
					setErrorCodeToOutput(stoResponse, iMap, output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception ex){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}


	@GraymoundService("STO_TURKNET_CANCEL_STANDING_ORDER")
	public static GMMap cancelStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();
		
		logger.info("[TurknetCorporationServices[cancelStandingOrder]] is started. Parameters : "+iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TURKNET_CANCEL_STANDING_ORDER");
		try{
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String date =  CommonHelper.getDateString(getInputDateOrDefault(iMap, MapKeys.RECON_DATE_BEGIN, CORPORATE_DATE_FORMAT), CORPORATE_DATE_FORMAT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			logger.info("[TurknetCorporationServices[cancelStandingOrder]] Values will be used are : Subscriber No :"+ subscriberNo + 
					"Corporate Code :" + corporateCode + "Process Date : " + date );
			
			TurknetClient client = getSoapClient(iMap);
			String standingOrderType = TurknetStandingOrderType.CANCEL.getDescription();
			
			BaseResponse stoResponse = client.saveStandingOrder(subscriberNo, prepareStandingOrderRequest(standingOrderType));
			
			if( null != stoResponse ){
				if( null != stoResponse  && stoResponse.getResponse().getReturnCode().equals(ResponseCodes.SUCCESS) ){
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
				else{
					setErrorCodeToOutput(stoResponse, iMap, output);
				}
			}
		}
		catch(Exception ex){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TURKNET_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_DEBT_INQUERY_FOR_STANDING_ORDER");
		
		logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] is started. Parameters : "+iMap);
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String dueDate = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			
			logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] Values are : " + dueDate + " , corporate code : " + corporateCode);

			TurknetClient client = getSoapClient(iMap);
			BillInvoiceResponse standingOrderAccountsWithInvoices = client.getStandingOrderAccountsWithInvoices(dueDate);
			
			if( null != standingOrderAccountsWithInvoices ){
				logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] BillInvoice Response : " + standingOrderAccountsWithInvoices);
				if( null != standingOrderAccountsWithInvoices.getResponse() ){
					String returnCode = standingOrderAccountsWithInvoices.getResponse().getReturnCode();
					if( null != returnCode && returnCode.equals(ResponseCodes.SUCCESS) ){
						logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] Return Code : " + returnCode);
						List<BillInvoiceDto> invoices = standingOrderAccountsWithInvoices.getInvoices();
						int counter = 0;
						for( BillInvoiceDto unpaidInvoice : invoices ){
							logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] Invoices : " + unpaidInvoice);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, unpaidInvoice.getSubscriberNo());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, unpaidInvoice.getInvoiceNo());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, unpaidInvoice.getInvoiceAmt());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, unpaidInvoice.getSubscriberName());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, unpaidInvoice.getInvoiceDate().substring(0,4));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, unpaidInvoice.getInvoiceDate().substring(4,6));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, unpaidInvoice.getInvoiceAmt());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, unpaidInvoice.getDueDate());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, unpaidInvoice.getInvoiceDate());
							output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
							logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] Invoices in Map : " + output);
						}
						output.put(MapKeys.TABLE_SIZE, counter);
						logger.info("[TurknetCorporationServices[getdebtQueryForStandingOrder]] Size : " + counter);
					}
					else{
						GMMap codeMapping = getResponseCodeMapping(standingOrderAccountsWithInvoices.getResponse().getReturnCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
						output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
					}
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_TURKNET_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_TURKNET_GET_STANDING_ORDER_RECONCILIATION_DETAIL");

		try{
			
			StandingOrderReconciliationDetailBatch batch = new TurknetStandingOrderReconciliationDetailBatch(iMap, getSoapClient(iMap));
			output = batch.runBatch();

		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_TURKNET_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
	GMMap output = new GMMap();
		
		logger.info("[TurknetCorporationServices[standingOrderReconciliation]] is started. Parameters : "+iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_TURKNET_STANDING_ORDER_RECONCILIATION");
	
		try{		
			Date reconDate = iMap.getDate(MapKeys.RECON_DATE);
			String reconcilationDate = CommonHelper.getDateString(reconDate,CORPORATE_DATE_FORMAT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
			
			int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
			int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");
			
			logger.info("[TurknetCorporationServices[standingOrderReconciliation]] Values will be used are : Reconciliation Date :"+ reconcilationDate + 
					" Corporate Code :" + corporateCode + " Total Collection Count : "+ bankStandingOrderCount  + " Total Cancel Count " + bankStandingOrderCancelCount);
			
			output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
			
			TurknetClient reconClient = getSoapClient(iMap);
			
			StandingOrderReconciliationSummaryResponse stoReconSummaryResponse = reconClient.sendReconciliationSummary4StandingOrders(reconcilationDate);
			
			if( null != stoReconSummaryResponse ){
				StandingOrderReconciliationSummaryDto summaryResponse = stoReconSummaryResponse.getSummaryResponse();
				if( null != summaryResponse ){
					int corpCollectionCount = summaryResponse.getSuccessCount();
					int corpCancellCollectionCount = summaryResponse.getCancelCount();
					
					output.put(MapKeys.RECON_CORPORATE_COUNT, corpCollectionCount);
					output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT,  corpCancellCollectionCount);
					
					logger.info("[TurknetCorporationServices[collectionReconciliation]] Corporate Values are : Reconciliation Date :"+ reconcilationDate + 
							" Corporate Code :" + corporateCode + " Total Collection Count : "+ corpCollectionCount +
							" Total Cancel Count "+ corpCancellCollectionCount );
					
					if( bankStandingOrderCount == corpCollectionCount && 
							bankStandingOrderCancelCount == corpCancellCollectionCount ){
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
					else{
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				}
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	
	@GraymoundService("ICS_TURKNET_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap outMap = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_GET_COLLECTION_RECONCILIATION_DETAIL");
	
		logger.info("[TurknetCorporationServices[getCollectionReconciliationDetail]] is started. Parameters : "+iMap);
		
		try{
		
			CollectionReconciliationDetailBatch batch = new TurknetCollectionReconciliationDetailBatch(iMap, getSoapClient(iMap));
			outMap = batch.runBatch();
			
		}
		catch(Exception e){
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, outMap);

		}
		
		return outMap;
	}
	

	@GraymoundService("ICS_TURKNET_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		
		logger.info("[TurknetCorporationServices[collectionReconciliation]] is started. Parameters : "+iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_COLLECTION_RECONCILIATION");
	
		try{		
			String reconcilationDate = CommonHelper.getDateString(iMap.getDate(MapKeys.RECON_DATE),CORPORATE_DATE_FORMAT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			logger.info("[TurknetCorporationServices[collectionReconciliation]] Values will be used are : Reconciliation Date :"+ reconcilationDate + 
					" Corporate Code :" + corporateCode + " Total Collection Count : "+ collectionCount +
					" Total Cancel Count "+ cancelCount + " Total Collection Amount " + collectionTotal + " Total Cancel Amount " + cancelTotal);
			
			TurknetClient reconClient = getSoapClient(iMap);
			
			ReconciliationSummaryResponse reconciliationSummaryResponse = reconClient.sendReconciliationSummary(reconcilationDate);
			
			if( null != reconciliationSummaryResponse ){
				
				ReconciliationSummaryDto summaryDto = reconciliationSummaryResponse.getSummaryDto();
				if( null != summaryDto ){
					
					int corpCollectionCount = summaryDto.getTotalPaymentCount();
					BigDecimal corpCollectionAmount = summaryDto.getTotalPaymentAmount();
					
					BigDecimal corpCancelCollectionAmount = summaryDto.getTotalCancelAmount();
					int corpCancellCollectionCount = summaryDto.getTotalCancelCount();
					
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpCollectionAmount);
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpCollectionCount);
			
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpCancelCollectionAmount);
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpCancellCollectionCount);
					
					logger.info("[TurknetCorporationServices[collectionReconciliation]] Corporate Values are : Reconciliation Date :"+ reconcilationDate + 
							" Corporate Code :" + corporateCode + " Total Collection Count : "+ corpCollectionCount +
							" Total Cancel Count "+ corpCancellCollectionCount + " Total Collection Amount " + corpCollectionAmount + " Total Cancel Amount " + corpCancelCollectionAmount);
					
					if( collectionCount == corpCollectionCount && collectionTotal.compareTo(corpCollectionAmount) == 0 &&
							cancelCount == corpCancellCollectionCount && cancelTotal.compareTo(corpCancelCollectionAmount) == 0 ){
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
					else{
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
				}
			
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_TURKNET_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKNET_COLLECTION_RECONCILIATION_CLOSED");
		
		logger.info("[TurknetCorporationServices[collectionReconciliationClosed]] is started. Parameters : "+iMap);
		
		
		String responseCode = "";
		try {

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(
					iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":")
							.concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":")
							.concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	public static  GMMap getResponseCodeMapping(String responseCode,String serviceOid, String corporateCode) {
		GMMap output = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(ServiceResponseCodeMapping.class);
			Criterion status = Restrictions.eq("status", true);
			Criterion returnCode = Restrictions.eq("returnCode", responseCode);
			Criterion corporateCODE = Restrictions.eq("corporateCode", corporateCode);
			criteria.add(status).add(returnCode).add(corporateCODE);
			
			@SuppressWarnings("unchecked")
			List<ServiceResponseCodeMapping> responseCodeMappingList = criteria.list();
			
			if(responseCodeMappingList.size() > 0){
				for(ServiceResponseCodeMapping responseCodeMapping: responseCodeMappingList){
					output.put("RETURN_CODE",responseCodeMapping.getReturnCode());
					output.put("RETURN_CODE_DESC",responseCodeMapping.getReturnCodeDesc());
					output.put(MapKeys.ERROR_CODE, responseCodeMapping.getErrorCode());
					output.put(MapKeys.ERROR_DESC,responseCodeMapping.getExplanation());
					logger.info("[TurknetCorporationServices[getResponseCodeMapping]] Return Code : " + responseCodeMapping.getReturnCode() + 
							" Return Code Desc : " + responseCodeMapping.getReturnCodeDesc());
				}	
			}else{
				output.put("RETURN_CODE",responseCode);
				output.put("RETURN_CODE_DESC",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
				output.put(MapKeys.ERROR_CODE,GeneralConstants.ERROR_CODE_NOT_FOUND);
				output.put(MapKeys.ERROR_DESC,GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			}
		} catch (Exception e) {
			output.put("RETURN_CODE",responseCode);
			output.put("RETURN_CODE_DESC",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			output.put("ERROR_CODE", GeneralConstants.ERROR_CODE_NOT_FOUND);
			output.put("EXPLANATION",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	private static void setErrorCodeToOutput(BaseResponse response, GMMap input, GMMap output){
		
		logger.info("[TurknetCorporationServices[setErrorCodeToOutput]] is started. Parameters : "+input + " Response : " + response.toString());
		
		String errorCode = null;
		if( null != response ){
			ResultDto resultDto = response.getResponse();
			if( null != resultDto ){
				errorCode = resultDto.getReturnCode();
			}
		}
		if( null == errorCode ){
			errorCode = "0";
		}
		
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		
		GMMap responseCodeMap = getResponseCodeMapping(errorCode,
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
		
		output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
		output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
	}
	
	private static Date getInputDateOrDefault(GMMap input, String key, String format) throws ParseException{
		Date date = new Date();
		
		if(!StringUtil.isEmpty(input.getString(key))){
			date = CommonHelper.getDateTime(input.getString(key), format);
		}
		
		return date;
	}
	

	private static TurknetClient getSoapClient(GMMap iMap) throws Exception{
		Object wsEndpoint = iMap.get(MapKeys.WS_PARAMETERS,0,MapKeys.WS_ENDPOINT);
		Object wsUser = iMap.get(MapKeys.WS_PARAMETERS,0,MapKeys.WS_USER);
		Object wsPassword = iMap.get(MapKeys.WS_PARAMETERS,0,MapKeys.WS_PASSWORD);
		TurknetClient client = new TurknetClient(wsUser.toString(), wsPassword.toString(), wsEndpoint.toString());
		
		return client;
	}
	
	private static TalimatIslemi prepareStandingOrderRequest(String standingOrderType) {
		if( standingOrderType.equals(TurknetStandingOrderType.SAVE.getDescription()) ){
			return TalimatIslemi.TalimatGirisHesap;
		}
		else{
			return TalimatIslemi.TalimatIptal;
		}
	}
	
	public enum TurknetStandingOrderType{
		SAVE("TalimatGirisHesap"), CANCEL("TalimatIptal");
		
		private String description;
		
		TurknetStandingOrderType(String description){
			this.description = description;
		}
		
		public String getDescription(){
			return description;
		}
		
	}
}


