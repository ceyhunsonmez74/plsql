package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import services.core.perakende.energy.codebase.IFMTahsilatServiceFmAboneBilgisindenBorcBulExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmAboneTalimatIptalExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmAboneTalimatlandirExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmMutabakatToplamListeleExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmMutabakatYapExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmTCKimlikNodanBorcBulExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmTahsilEtExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmTahsilatiIptalEtExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmTalimatMutabakatToplamExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmTalimatliAboneBorclariListeleExceptionInformationFaultFaultMessage;
import services.core.perakende.energy.codebase.IFMTahsilatServiceFmVergiNodanBorcBulExceptionInformationFaultFaultMessage;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.OepsasReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.oepsas.OepsasClient;
import tr.com.aktifbank.integration.client.oepsas.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

import fm.contracts.edasnet.codebase.BorcBilgisiResponse;
import fm.contracts.edasnet.codebase.FmAboneTalimatIptalResponse;
import fm.contracts.edasnet.codebase.FmAboneTalimatlandirResponse;
import fm.contracts.edasnet.codebase.FmBorcBulListeResponse;
import fm.contracts.edasnet.codebase.FmBorcBulResponse;
import fm.contracts.edasnet.codebase.FmMutabakatToplamResponse;
import fm.contracts.edasnet.codebase.FmMutabakatYapResponse;
import fm.contracts.edasnet.codebase.FmTahsilEtResponse;
import fm.contracts.edasnet.codebase.FmTahsilatiIptalEtResponse;
import fm.contracts.edasnet.codebase.FmTalimatMutabakatToplamResponse;
import fm.contracts.edasnet.codebase.FmTalimatliAboneBorclariResponse;
import fm.contracts.edasnet.codebase.TahakkukBilgisiResponse;
import fm.contracts.edasnet.codebase.TahsilatMutabakatIcmalBilgisiResponse;
import fm.contracts.edasnet.codebase.TaksitBilgisiResponse;
import fm.contracts.edasnet.codebase.TalimatliAboneTahakkukBilgisiResponse;
import fm.contracts.edasnet.codebase.TalimatliAboneTaksitBilgisiResponse;
import fm.contracts.edasnet.codebase.TalimatliBorcBilgisiResponse;

public class OepsasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(OepsasServices.class);

	@GraymoundService("ICS_OEPSAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			// client icerisinde hangi alan dolu ise o alana gore sorgulama
			// yapilacaktir
			String aboneIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String tckn = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String vkn = iMap.getString(MapKeys.SUBSCRIBER_NO4);
			
			FmBorcBulListeResponse responseTckn = new FmBorcBulListeResponse();
			FmBorcBulResponse  response = new FmBorcBulResponse();
			FmBorcBulListeResponse responseVkn =new FmBorcBulListeResponse();
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";
			
			if (!StringUtil.isEmpty(tckn)) {
				try {
					responseTckn = OepsasClient.fmTCKimlikNodanBorcBul(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, tckn, bankCode, username, password);
					responseCode = responseTckn.getHasError().getErrorCode().toString();
					responseMessage = responseTckn.getHasError().getErrorDetail();
				} catch (IFMTahsilatServiceFmTCKimlikNodanBorcBulExceptionInformationFaultFaultMessage faultMessage) {
					logger.error("OEPSAS HATA:",faultMessage);
//					 FaultMessage kurum tarafindan gelen mant�ksal bir
					// hata oldugu icin logluyoruz
//					FaultMessage f=(FaultMessage)ex;
					logger.error("ICS_OEPSAS_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (FaultMessage)"));
					responseCode = faultMessage.getFaultInfo().getErrorType().toString();
					responseMessage = faultMessage.getFaultInfo().getErrorDetail();
					System.out.println();
					logger.info("ICS_OEPSAS_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
					logger.info("ICS_OEPSAS_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
				}
				
			}else if (!StringUtil.isEmpty(vkn)) {
				try {
					responseVkn = OepsasClient.fmVergiNodanBorcBul(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, vkn, bankCode, username, password);
					responseCode = responseVkn.getHasError().getErrorCode().toString();
					responseMessage = responseVkn.getHasError().getErrorDetail();
				} catch (IFMTahsilatServiceFmVergiNodanBorcBulExceptionInformationFaultFaultMessage faultMessage) {
					logger.error("OEPSAS HATA:",faultMessage);
//					 FaultMessage kurum tarafindan gelen mant�ksal bir
					// hata oldugu icin logluyoruz
//					FaultMessage f=(FaultMessage)ex;
					logger.error("ICS_OEPSAS_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (FaultMessage)"));
					responseCode = faultMessage.getFaultInfo().getErrorType().toString();
					responseMessage = faultMessage.getFaultInfo().getErrorDetail();
					System.out.println();
					logger.info("ICS_OEPSAS_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
					logger.info("ICS_OEPSAS_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
				}
			}else{
				try {
					response = OepsasClient.fmAboneBilgisindenBorcBul(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, aboneIsletmeKodu, aboneNo, bankCode, username, password);
					responseCode = response.getHasError().getErrorCode().toString();
					responseMessage = response.getHasError().getErrorDetail();
				} catch (IFMTahsilatServiceFmAboneBilgisindenBorcBulExceptionInformationFaultFaultMessage faultMessage) {
					logger.error("OEPSAS HATA:",faultMessage);
//					 FaultMessage kurum tarafindan gelen mant�ksal bir
					// hata oldugu icin logluyoruz
//					FaultMessage f=(FaultMessage)ex;
					logger.error("ICS_OEPSAS_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (FaultMessage)"));
					responseCode = faultMessage.getFaultInfo().getErrorType().toString();
					responseMessage = faultMessage.getFaultInfo().getErrorDetail();
					System.out.println();
					logger.info("ICS_OEPSAS_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
					logger.info("ICS_OEPSAS_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
				}
			}
			

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			String lastMan = "";
			String surname = "";
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				BorcBilgisiResponse borcBilgisiResponse=response.getBorcBilgisi();
				if (response.getBorcBilgisi()!=null) {
				for (TahakkukBilgisiResponse bill : borcBilgisiResponse.getBorclar().getTahakkukBilgisiResponse()) {
					lastMan = "";
					surname = "";
					if(bill.getTaksitDetayi()!=null){
						for (TaksitBilgisiResponse instalmentBill : bill.getTaksitDetayi().getTaksitBilgisiResponse()){
							if (!isCollectedInvoice(bill.getTahakkukFisNo(), borcBilgisiResponse.getTesisatBilgisi().getIsletme(), borcBilgisiResponse.getTesisatBilgisi().getAboneNo(), borcBilgisiResponse.getTesisatBilgisi().getAboneID(), "", corporateCode,instalmentBill.getTaksitNo())) {
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcBilgisiResponse.getTesisatBilgisi().getIsletme());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcBilgisiResponse.getTesisatBilgisi().getAboneNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcBilgisiResponse.getTesisatBilgisi().getAboneID());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukFisNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, instalmentBill.getToplamTutar());
									if (bill.getSoyad()!=null) {
										surname = bill.getSoyad();
									}
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getAd()+" "+surname);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(instalmentBill.getVadeTarihi().toGregorianCalendar().getTime()));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.YEAR));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.MONTH));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, instalmentBill.getToplamTutar());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, instalmentBill.getTaksitNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getIsletmeKodu());
									if (bill.getSonAboneBorcu()!=null && bill.getSonAboneBorcu()==1) {
										lastMan ="-SON �AHIS";
									}
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, "TAKSIT"+lastMan);

									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
							}
						}
					}else {
						if (!isCollectedInvoice(bill.getTahakkukFisNo(), borcBilgisiResponse.getTesisatBilgisi().getIsletme(), borcBilgisiResponse.getTesisatBilgisi().getAboneNo(), borcBilgisiResponse.getTesisatBilgisi().getAboneID(), "", corporateCode)) {
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcBilgisiResponse.getTesisatBilgisi().getIsletme());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcBilgisiResponse.getTesisatBilgisi().getAboneNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcBilgisiResponse.getTesisatBilgisi().getAboneID());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukFisNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getToplamTutar());
							if (bill.getSoyad()!=null) {
								surname = bill.getSoyad();
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getAd()+" "+surname);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(bill.getSonOdemeTarihi().toGregorianCalendar().getTime()));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getToplamTutar());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getIsletmeKodu());
							if (bill.getSonAboneBorcu()!=null && bill.getSonAboneBorcu()==1) {
								lastMan ="SON �AHIS";
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, lastMan);

							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
					}
				}
						
			}
		}
			if (responseTckn.getBorcBilgisi()!=null) {
			for( BorcBilgisiResponse  borcBilgisiResponseTckn     : responseTckn.getBorcBilgisi().getBorcBilgisiResponse()){
				for (TahakkukBilgisiResponse bill : borcBilgisiResponseTckn.getBorclar().getTahakkukBilgisiResponse()) {
					lastMan = "";
					surname = "";
					if(bill.getTaksitDetayi()!=null){
						for (TaksitBilgisiResponse instalmentBill : bill.getTaksitDetayi().getTaksitBilgisiResponse()){
							if (!isCollectedInvoice(bill.getTahakkukFisNo(), borcBilgisiResponseTckn.getTesisatBilgisi().getIsletme(), borcBilgisiResponseTckn.getTesisatBilgisi().getAboneNo(), borcBilgisiResponseTckn.getTesisatBilgisi().getAboneID(), "", corporateCode,instalmentBill.getTaksitNo())) {
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcBilgisiResponseTckn.getTesisatBilgisi().getIsletme());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcBilgisiResponseTckn.getTesisatBilgisi().getAboneNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcBilgisiResponseTckn.getTesisatBilgisi().getAboneID());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, tckn);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukFisNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, instalmentBill.getToplamTutar());
									if (bill.getSoyad()!=null) {
										surname = bill.getSoyad();
									}
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getAd()+" "+surname);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(instalmentBill.getVadeTarihi().toGregorianCalendar().getTime()));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.YEAR));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.MONTH));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, instalmentBill.getToplamTutar());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, instalmentBill.getTaksitNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getIsletmeKodu());
									if (bill.getSonAboneBorcu()!=null && bill.getSonAboneBorcu()==1) {
										lastMan ="-SON �AHIS";
									}
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, "TAKSIT"+lastMan);

									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
							}
						}
					}else {
						if (!isCollectedInvoice(bill.getTahakkukFisNo(), borcBilgisiResponseTckn.getTesisatBilgisi().getIsletme(), borcBilgisiResponseTckn.getTesisatBilgisi().getAboneNo(), borcBilgisiResponseTckn.getTesisatBilgisi().getAboneID(), "", corporateCode)) {
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcBilgisiResponseTckn.getTesisatBilgisi().getIsletme());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcBilgisiResponseTckn.getTesisatBilgisi().getAboneNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcBilgisiResponseTckn.getTesisatBilgisi().getAboneID());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, tckn);

							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukFisNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getToplamTutar());
							if (bill.getSoyad()!=null) {
								surname = bill.getSoyad();
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getAd()+" "+surname);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(bill.getSonOdemeTarihi().toGregorianCalendar().getTime()));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getToplamTutar());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getIsletmeKodu());
							if (bill.getSonAboneBorcu()!=null && bill.getSonAboneBorcu()==1) {
								lastMan ="SON �AHIS";
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, lastMan);
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
					}
				}
						
			}
		}
	}
			if (responseVkn.getBorcBilgisi()!=null) {
			for( BorcBilgisiResponse  borcBilgisiResponseVkn     : responseVkn.getBorcBilgisi().getBorcBilgisiResponse()){
				for (TahakkukBilgisiResponse bill : borcBilgisiResponseVkn.getBorclar().getTahakkukBilgisiResponse()) {
					if(bill.getTaksitDetayi()!=null){
						for (TaksitBilgisiResponse instalmentBill : bill.getTaksitDetayi().getTaksitBilgisiResponse()){
							if (!isCollectedInvoice(bill.getTahakkukFisNo(), borcBilgisiResponseVkn.getTesisatBilgisi().getIsletme(), borcBilgisiResponseVkn.getTesisatBilgisi().getAboneNo(), borcBilgisiResponseVkn.getTesisatBilgisi().getAboneID(), "", corporateCode,instalmentBill.getTaksitNo())) {
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcBilgisiResponseVkn.getTesisatBilgisi().getIsletme());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcBilgisiResponseVkn.getTesisatBilgisi().getAboneNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcBilgisiResponseVkn.getTesisatBilgisi().getAboneID());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, vkn);

									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukFisNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, instalmentBill.getToplamTutar());
									if (bill.getSoyad()!=null) {
										surname = bill.getSoyad();
									}
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getAd()+" "+surname);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(instalmentBill.getVadeTarihi().toGregorianCalendar().getTime()));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.YEAR));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.MONTH));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, instalmentBill.getToplamTutar());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, instalmentBill.getTaksitNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getIsletmeKodu());
									if (bill.getSonAboneBorcu()!=null && bill.getSonAboneBorcu()==1) {
										lastMan ="-SON �AHIS";
									}
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, "TAKSIT"+lastMan);
									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
							}
						}
					}else {
						if (!isCollectedInvoice(bill.getTahakkukFisNo(), borcBilgisiResponseVkn.getTesisatBilgisi().getIsletme(), borcBilgisiResponseVkn.getTesisatBilgisi().getAboneNo(), borcBilgisiResponseVkn.getTesisatBilgisi().getAboneID(), "", corporateCode)) {
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcBilgisiResponseVkn.getTesisatBilgisi().getIsletme());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcBilgisiResponseVkn.getTesisatBilgisi().getAboneNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcBilgisiResponseVkn.getTesisatBilgisi().getAboneID());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, vkn);

							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukFisNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getToplamTutar());
							if (bill.getSoyad()!=null) {
								surname = bill.getSoyad();
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bill.getAd()+" "+surname);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(bill.getSonOdemeTarihi().toGregorianCalendar().getTime()));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getToplamTutar());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bill.getIsletmeKodu());
							if (bill.getSonAboneBorcu()!=null && bill.getSonAboneBorcu()==1) {
								lastMan ="SON �AHIS";
							}
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, lastMan);
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
					}
				}			
			}
		}
	}
	}
			
		} catch (Throwable e2) {
			logger.error("ICS_OEPSAS_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_OEPSAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String branchCode = iMap.getString(MapKeys.BRANCH_CODE);
			String cashierCode="";
			String resellerCode="";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahakkukFisNo = iMap.getString(MapKeys.INVOICE_NO);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
			String isletmeKodu = iMap.getString(MapKeys.PARAMETER1);
			String aboneID = iMap.getString(MapKeys.PARAMETER3);
			int installmentNo = iMap.getInt(MapKeys.INSTALLMENT_NO);

			BigDecimal invoiceAmount = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
//			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyyMMdd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			}
			
			if (isStandingOrderCollection) {
				logger.info("ICS_OEPSAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			} else {
				logger.info("ICS_OEPSAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			FmTahsilEtResponse response = null;
			String responseCode = "0";
			String responseMessage = "";
			try {
				response = OepsasClient.fmTahsilEt(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, aboneID, tahakkukFisNo, bankaReferansNo, isletmeKodu, branchCode, tahsilatTarihi,installmentNo, bankaKodu, username, password);
				responseCode = response.getHasError().getErrorCode().toString();
				responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmTahsilEtExceptionInformationFaultFaultMessage f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_OEPSAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("ICS_OEPSAS_DO_INVOICE_COLLECTION FaultMessage error code = ".concat(responseCode));
				logger.info("ICS_OEPSAS_DO_INVOICE_COLLECTION FaultMessage error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(response.getTahsilat().getTahsilatFisNo());
				session.saveOrUpdate(invoicePayment);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_OEPSAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String tahsilatFisNo = iMap.getString(MapKeys.PARAMETER_2, null);
			if (tahsilatFisNo == null) {
				tahsilatFisNo = iMap.getString(MapKeys.PARAMETER2);
			}
			
			String isletmeKodu = iMap.getString(MapKeys.PARAMETER_1, null);
			if (isletmeKodu == null) {
				isletmeKodu = iMap.getString(MapKeys.PARAMETER1);
			}
			
			FmTahsilatiIptalEtResponse response = null;
			String responseCode = "0";
			String responseMessage = "";
			try {
				response = OepsasClient.fmTahsilatiIptalEt(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, isletmeKodu, tahsilatFisNo, bankCode, username, password);
				responseCode = response.getHasError().getErrorCode().toString();
				responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmTahsilatiIptalEtExceptionInformationFaultFaultMessage f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_OEPSAS_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("ICS_OEPSAS_SEND_COLLECTION_CANCEL_MESSAGE FaultMessage response code = ".concat(responseCode));
				logger.info("ICS_OEPSAS_SEND_COLLECTION_CANCEL_MESSAGE FaultMessage response message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_OEPSAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		String responseCode="";
		String responseMessage = "";
		FmMutabakatToplamResponse  response=null;
		FmMutabakatYapResponse responseClose=  null;

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_COLLECTION_RECONCILIATION");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();

			try {
				 response = OepsasClient.fmMutabakatToplamListele(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, reconDate, bankCode, username, password);
					responseCode = response.getHasError().getErrorCode().toString();
					responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmMutabakatToplamListeleExceptionInformationFaultFaultMessage f) {
				logger.error("OEPSAS HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_OEPSAS_COLLECTION_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION error code = ".concat(responseCode));
				logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			List<TahsilatMutabakatIcmalBilgisiResponse> transactionList= response.getGecerliTahsilatlar().getTahsilatMutabakatIcmalBilgisiResponse();
			List<TahsilatMutabakatIcmalBilgisiResponse> cancelTransactionList= response.getIptalTahsilatlar().getTahsilatMutabakatIcmalBilgisiResponse();

			BigDecimal corpCollectionTotal = new BigDecimal(0);
			BigDecimal corpCancelTotal = new BigDecimal(0);
			int corpCollectionCount = 0;
			int corpCancelCount = 0;

			if (transactionList.size() == 0) {
				// tahsilat yok ya da hata var
				// sayilari 0 a esitle
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			else {
				// aldigin sayilari koy

			
			BigDecimal corpReconCollectionTotal = transactionList.get(0).getToplamTutar();
			BigDecimal corpReconCancelTotal = cancelTransactionList.get(0).getToplamTutar();
			int corpReconCollectionCount = transactionList.get(0).getToplamAdet();
			int corpReconCancelCount = cancelTransactionList.get(0).getToplamAdet();
			
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpReconCollectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpReconCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpReconCancelCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpReconCancelTotal);

			}
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
//				// mutabakat basarili o zaman kapatalim
//				ServiceMessage serviceMessageForClose = new ServiceMessage();
//				try {
//					 responseClose = OepsasClient.fmMutabakatYap(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageForClose, iMap.getString(MapKeys.RECON_DATE), bankCode, username, password);
//					 responseCode = response.getHasError().getErrorCode().toString();
//					 responseMessage = response.getHasError().getErrorDetail();
//				} catch (IFMTahsilatServiceFmMutabakatYapExceptionInformationFaultFaultMessage f) {
//					logger.error("OEPSAS HATA:",f);
//					// FaultMessage kurum tarafindan gelen mant�ksal bir
//					// hata oldugu icin logluyoruz
//					logger.error("ICS_OEPSAS_COLLECTION_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
//					responseCode = f.getFaultInfo().getErrorType().toString();
//					responseMessage = f.getFaultInfo().getErrorDetail();
//					logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION error code = ".concat(responseCode));
//					logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION error message = ".concat(responseMessage));
//				}
//
//				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessageForClose.getRequest());
//				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessageForClose.getResponse());
//				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
//					errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
//					output.put(MapKeys.ERROR_CODE, "660");
//					output.put(MapKeys.ERROR_DESC, errorMessage);
//				}
//				else {
//					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
//				}
//			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
//		
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			
		}
		catch (Throwable e) {
			logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	@GraymoundService("ICS_OEPSAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_OEPSAS_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new OepsasReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_OEPSAS_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_OEPSAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		FmMutabakatYapResponse response=  null;
		ServiceMessage serviceMessage = new ServiceMessage();
		String responseCode="";
		String responseMessage = "";
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_COLLECTION_RECONCILIATION_CLOSED");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			String paymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			String cancelPaymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);
			
			
			try {
				 response = OepsasClient.fmMutabakatYap(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, iMap.getString(MapKeys.RECON_DATE), bankCode, username, password);
				 responseCode = response.getHasError().getErrorCode().toString();
				 responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmMutabakatYapExceptionInformationFaultFaultMessage f) {
				logger.error("OEPSAS HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_OEPSAS_COLLECTION_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION error code = ".concat(responseCode));
				logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION error message = ".concat(responseMessage));
			}

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	
				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
//						output.put(MapKeys.ERROR_CODE, "660");
//						output.put(MapKeys.ERROR_DESC, errorMessage);
					}
					else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
						
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);
					}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_OEPSAS_COLLECTION_RECONCILIATION_CLOSED - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_OEPSAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OEPSAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String aboneIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);

			FmAboneTalimatlandirResponse response = new FmAboneTalimatlandirResponse();
			String responseCode="";
			String responseMessage="";

			try {
				 response = OepsasClient.fmAboneTalimatlandir(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, aboneIsletmeKodu, aboneNo, bankCode, username, password);
				 responseCode = response.getHasError().getErrorCode().toString();
				 responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmAboneTalimatlandirExceptionInformationFaultFaultMessage f) {
				logger.error("OEPSAS HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_OEPSAS_SEND_STANDING_ORDER_MESSAGE ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("STO_OEPSAS_SEND_STANDING_ORDER_MESSAGE error code = ".concat(responseCode));
				logger.info("STO_OEPSAS_SEND_STANDING_ORDER_MESSAGE error message = ".concat(responseMessage));
			}
					
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_OEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessageCheck = new ServiceMessage();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String aboneIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);

			FmAboneTalimatIptalResponse response = new FmAboneTalimatIptalResponse();
			
			String responseCode="";
			String responseMessage="";

		
			try {
				 response = OepsasClient.fmAboneTalimatIptal(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, aboneIsletmeKodu, aboneNo, bankCode, username, password);
				 responseCode = response.getHasError().getErrorCode().toString();
				 responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmAboneTalimatIptalExceptionInformationFaultFaultMessage f) {
				logger.error("OEPSAS HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_OEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("STO_OEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE error code = ".concat(responseCode));
				logger.info("STO_OEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE error message = ".concat(responseMessage));
			}
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				GMMap	responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_OEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_OEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String responseMessage="";
		String responseCodeDebt="";
		String responseMessageDebt ="";
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageForDebtInquery= new ServiceMessage();
		FmTalimatliAboneBorclariResponse response = null;
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String bankDate=CommonHelper.getShortDateTimeString(new Date());
			String date = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				date = iMap.getString(MapKeys.PAYMENT_DATE);
			} else {
				date = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			}
			
			try {
				 response = OepsasClient.fmTalimatliAboneBorclariListele(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, date, bankCode, username, password);
				 responseCode = response.getHasError().getErrorCode().toString();
				 responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmTalimatliAboneBorclariListeleExceptionInformationFaultFaultMessage f) {
				logger.error("OEPSAS HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_OEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("ICS_OEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER error code = ".concat(responseCode));
				logger.info("ICS_OEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			int counter = 0;
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = CommonHelper.getHibernateSession();
				String queryDate = CommonHelper.getHugeDateTimeString(new Date()).trim();
				String qd = CommonHelper.getShortDateTimeString(new Date());



							for (TalimatliBorcBilgisiResponse bill : response.getBorcBilgisi().getTalimatliBorcBilgisiResponse()) {
								for(TalimatliAboneTahakkukBilgisiResponse tahakkuk :bill.getBorclar().getTalimatliAboneTahakkukBilgisiResponse())
									if(tahakkuk.getTaksitDetayi()!=null){
										for (TalimatliAboneTaksitBilgisiResponse instalmentBill : tahakkuk.getTaksitDetayi().getTalimatliAboneTaksitBilgisiResponse()){
											if (CommonHelper.getShortDateTimeString(instalmentBill.getVadeTarihi().toGregorianCalendar().getTime()).equals(CommonHelper.getShortDateTimeString(new Date()))) {
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bill.getTesisatBilgisi().getIsletme());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, bill.getTesisatBilgisi().getAboneNo());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, bill.getTesisatBilgisi().getAboneID());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, tahakkuk.getTahakkukFisNo());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, instalmentBill.getAnapara());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, tahakkuk.getAd()+ " "+ tahakkuk.getSoyad());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(instalmentBill.getVadeTarihi().toGregorianCalendar().getTime()));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.YEAR));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.MONTH));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.YEAR));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, instalmentBill.getVadeTarihi().toGregorianCalendar().get(Calendar.MONTH));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, collectionTypeId);
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, instalmentBill.getAnapara());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, instalmentBill.getTaksitNo());
													outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, tahakkuk.getIsletmeKodu());
													outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
													outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
													counter++;
											}
										}
									}else {
											if (CommonHelper.getShortDateTimeString(tahakkuk.getSonOdemeTarihi().toGregorianCalendar().getTime()).equals(CommonHelper.getShortDateTimeString(new Date()))) {
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bill.getTesisatBilgisi().getIsletme());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, bill.getTesisatBilgisi().getAboneNo());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, bill.getTesisatBilgisi().getAboneID());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, tahakkuk.getTahakkukFisNo());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, tahakkuk.getAnapara());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, tahakkuk.getAd()+ " "+ tahakkuk.getSoyad());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(tahakkuk.getSonOdemeTarihi().toGregorianCalendar().getTime()));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, tahakkuk.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, tahakkuk.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, tahakkuk.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, tahakkuk.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, collectionTypeId);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionTypeId);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, tahakkuk.getAnapara());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, tahakkuk.getIsletmeKodu());
												outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
												outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
												counter++;
											}
										
									}
								}
							
							   }
					
		
					outMap.put(MapKeys.TABLE_SIZE, counter);
					outMap.put(MapKeys.RESPONSE_CODE, responseCode);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "Onay");
				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_OEPSAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OEPSAS_STANDING_ORDER_RECONCILIATION");
		ServiceMessage message = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String responseMessage ="";
		ServiceMessage serviceMessage = new ServiceMessage();
		int corpCancelCount = 0;
		int corpOrderCount = 0;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		FmTalimatMutabakatToplamResponse response=null;

		try {
			String p_dTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OEPSAS_STANDING_ORDER_RECONCILIATION");
			
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			try {
				 response = OepsasClient.fmTalimatMutabakatToplam(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, iMap.getString(MapKeys.RECON_DATE), bankCode, username, password);
				 responseCode = response.getHasError().getErrorCode().toString();
				 responseMessage = response.getHasError().getErrorDetail();
			} catch (IFMTahsilatServiceFmTalimatMutabakatToplamExceptionInformationFaultFaultMessage f) {
				logger.error("OEPSAS HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_OEPSAS_STANDING_ORDER_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorType().toString();
				responseMessage = f.getFaultInfo().getErrorDetail();
				logger.info("STO_OEPSAS_STANDING_ORDER_RECONCILIATION error code = ".concat(responseCode));
				logger.info("STO_OEPSAS_STANDING_ORDER_RECONCILIATION error message = ".concat(responseMessage));
			}
			
			
			

			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				try {
					if (response.getIcmal().getTalimatMutabakatIcmalBilgisiResponse().get(0).getTalimatTipi()==0) {
						corpCancelCount=response.getIcmal().getTalimatMutabakatIcmalBilgisiResponse().get(0).getTalimatIptalSayisi();
					}else {
						corpCancelCount=response.getIcmal().getTalimatMutabakatIcmalBilgisiResponse().get(1).getTalimatIptalSayisi();

					}
				}
				catch (Exception e) {
					corpCancelCount = 0;
					logger.error("STO_OEPSAS_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi alinirken hata meydana geldi");
				}
//			}
//			else {
//				corpCancelCount = 0;
//				logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi null geldi");
//			}
				try {
					if (response.getIcmal().getTalimatMutabakatIcmalBilgisiResponse().get(0).getTalimatTipi()==0) {
						corpOrderCount=response.getIcmal().getTalimatMutabakatIcmalBilgisiResponse().get(0).getYeniTalimatSayisi();
					}else {
						corpOrderCount=response.getIcmal().getTalimatMutabakatIcmalBilgisiResponse().get(1).getYeniTalimatSayisi();

					}
				}
				catch (Exception e) {
					corpOrderCount = 0;
					logger.error("STO_OEPSAS_STANDING_ORDER_RECONCILIATION -> talimat sayisi alinirken hata meydana geldi");
				}
			
		}	
//			corpOrderCount=corpOrderCount-corpCancelCount;

			if (!responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//				// hata meydana geldi
				logger.error("STO_OEPSAS_STANDING_ORDER_RECONCILIATION -> kurum web servisinde hata meydana geldi...");
				output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				output.put(MapKeys.RECON_BANK_COUNT, 0);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				responseCode = "3342";
			}
			else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
			GMMap sorMap = BedasCampaignServices.getBankStandingOrdersForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			GMMap sorcMap = BedasCampaignServices.getBankStandingOrderCancelsForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
			
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			List<icsStandingOrders> bankCancelledStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

//			int bankCancelCount = bankCancelledStandingOrderList.size();
//			int bankOrderCount = bankStandingOrderList.size();
			output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);

			output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
			output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (bankCancelCount == corpCancelCount && bankOrderCount == corpOrderCount) {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			else {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch (Throwable e) {
			responseCode = "3342";
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_OEPSAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OEPSAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		GMMap outMap= new GMMap();
		try{

					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					insertOnlineServiceLog(iMap, outMap);

	
		}
		catch (Throwable e2) {
			logger.error("An exception occured while executing STO_OEPSAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	public static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

	    try {

	    	Date date = CommonHelper.getDateTime(datetime, dateFormat);	        
	        GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(date);
	        
	        return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);

//	        return  DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);


	    } catch (Exception e) {

	        System.out.print(e.getMessage());

	        return null;

	    }
	}

}
