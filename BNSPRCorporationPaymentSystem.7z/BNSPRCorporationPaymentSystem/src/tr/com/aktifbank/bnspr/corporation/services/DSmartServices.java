package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.tempuri.OnlinePayment_DomainName;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.DSmartReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.client.dsmart.AgreementResponse;
import tr.com.aktifbank.integration.client.dsmart.DSmartClient;
import tr.com.aktifbank.integration.client.dsmart.DirectDebitInfoResponse;
import tr.com.aktifbank.integration.client.dsmart.InvoiceResponse;
import tr.com.aktifbank.integration.client.dsmart.PaymentResponse;
import tr.com.aktifbank.integration.client.dsmart.ResponseBase;
import tr.com.aktifbank.integration.client.dsmart.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class DSmartServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(DSmartServices.class);

	private static final String BANK_REF_NO = "";
	private static final String BANK_BRANCH_NO = "";
	private static final String PAYMENT_CHANNEL = "0";

	private static final String EMPTY_RETURN_CODE = "21";

	@GraymoundService("ICS_DSMART_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		int counter = 0;
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			// logger info will be logged
			builder.append(" ICS_DSMART_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(p_sAboneNo);
			builder.append(" | Banka Kodu -> ");
			builder.append(bankCode);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			logger.info(builder.toString());

			String corporateOid = CommonBusinessOperations.getCorporateOidFromCorporateCode(corporateCode);
			int collectionTypeNumber = Integer.parseInt(iMap.getString(MapKeys.COLLECTION_TYPE));
			String callerScreen = "ICS";
			GMMap subscriberInput = new GMMap();
			subscriberInput.put(TransactionConstants.GetSubscriberMetadata.Input.CORPORATE_OID, corporateOid);
			subscriberInput.put(TransactionConstants.GetSubscriberMetadata.Input.COLLECTION_TYPE, collectionTypeNumber);
			subscriberInput.put(TransactionConstants.GetSubscriberMetadata.Input.CALLER_SCREEN, callerScreen);

			GMMap subscriberResult = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetSubscriberMetadata.SERVICE_NAME, subscriberInput);
			if (subscriberResult.getInt("SUBSCRIBER_METADATA_TABLE", 0, "LENGTH") != p_sAboneNo.length()) {
				logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY -> abone numaras� hatal� uzunlukta geldi.");
				responseCode = "660";
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "Abone numaras� uzunlugu hatal�. Abone Numaras� ".concat(subscriberResult.getString("SUBSCRIBER_METADATA_TABLE", 0, "LENGTH")).concat(" karakter olmal�!"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {

				logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) will be called..."));
				List<InvoiceResponse> response = DSmartClient.getInvoice(url, bankCode, p_sAboneNo, username, password, sm, authUsername, authPassword);
				CommonHelper.insertWsCallLog(iMap, sm.getParameter1(), sm.getParameter2(), sm.getParameter3());
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());
				logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) is called..."));
				try {
					if (response.size() == 0) {// if response is null that means
												// an error occurred on service
						responseCode = EMPTY_RETURN_CODE;
					} else {
						responseCode = response.get(0).getReturnCode();
					}
				} catch (Exception e) {
					logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
				}
				logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) returned response code ".concat(responseCode)));
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) returned errorCode ".concat(errorCode)));
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					for (InvoiceResponse borc : response) {
						if (!isCollectedInvoice(borc.getCycle(), p_sAboneNo, "", "", "", corporateCode)) {
							Date date = getDate(borc.getLastBillingDate());
							Calendar cal = Calendar.getInstance();
							cal.setTime(date);
							String billingAmount = borc.getBillingAmount().replace(",", ".");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sAboneNo);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getInvoiceNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, billingAmount);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getNameSurname());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, date);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, cal.get(Calendar.YEAR));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, String.format("%02d", cal.get(Calendar.MONTH) + 1));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, billingAmount);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getInvoiceNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}
					}
				}
			}
			logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DSMART_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			StringBuilder builder = new StringBuilder();
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String paymentAmount = iMap.getString(MapKeys.INVOICE_AMOUNT);
			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = getDate(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), aboneNo);
			} else {
				tahsilatTarihi = getDate(new Date(), aboneNo);
			}

			builder.append(" ICS_DSMART_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | Tahakkuk No -> ");
			builder.append(invoiceNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			logger.info(builder.toString());

			logger.info("ICS_DSMART_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) before call.."));

			PaymentResponse responseTalimatliOdeme;
			if (isStandingOrderCollection) {
				logger.info("ICS_DSMART_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - otomatik odeme talimatli abone icin borc sorgulanacak->".concat(invoiceNo).concat("-").concat(p_sIslemReferansNo)));
				List<InvoiceResponse> invoices = DSmartClient.getInvoice(wsUrl, bankCode, aboneNo, username, password, sm, authUsername, authPassword);

				logger.info("ICS_DSMART_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(invoices.toString()));
				iMap.put("REQUEST_XML_FOR_DEBT_INQUERY", sm.getRequest());
				outMap.put("RESPONSE_XML_FOR_DEBT_INQUERY", sm.getResponse());
				responseCode = "1";
				if (invoices.size() == 0)
					responseCode = EMPTY_RETURN_CODE;
				else
					responseCode = invoices.get(0).getReturnCode();

				logger.info("ICS_DSMART_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) returned response code ".concat(responseCode)));
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				logger.info("ICS_DSMART_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - DSmartClient.getInvoice(...) returned errorCode ".concat(errorCode)));
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					for (InvoiceResponse borc : invoices) {
						if (!isCollectedInvoice(borc.getCycle(), aboneNo, "", "", "", corporateCode)) {
							logger.info("ICS_DSMART_DO_INVOICE_COLLECTION will be called ".concat(corporateCode).concat(" borc.getThkNo() -> ".concat(borc.getInvoiceNo()).concat(" - tahsilatTarihi->").concat(tahsilatTarihi).concat(" - p_sIslemReferansNo->").concat(p_sIslemReferansNo)));

							responseTalimatliOdeme = DSmartClient.setPayment(wsUrl, bankCode, aboneNo, borc.getInvoiceNo(), borc.getBillingAmount(), tahsilatTarihi, BANK_REF_NO, BANK_BRANCH_NO, PAYMENT_CHANNEL, username, password, sm, authUsername, authPassword);
							logger.info("ICS_DSMART_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - DSmartClient.setPayment is called ".concat(sm.getRequest())));
							logger.info("ICS_DSMART_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - DSmartClient.setPayment is called ".concat(sm.getResponse())));
							iMap.put("REQUEST_XML_FOR_INVOICE_PAYMENT", sm.getRequest());
							outMap.put("RESPONSE_XML_FOR_INVOICE_PAYMENT", sm.getResponse());
							responseCode = GeneralConstants.ERROR_CODE_APPROVE;
							if (responseTalimatliOdeme == null) {
								responseCode = "3318";
							} else {
								responseCode = responseTalimatliOdeme.getReturnCode();
							}

							responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
							errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
							if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
								outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
							}
						}
					}
				}
			} else {
				responseTalimatliOdeme = DSmartClient.setPayment(wsUrl, bankCode, aboneNo, invoiceNo, paymentAmount, tahsilatTarihi, BANK_REF_NO, BANK_BRANCH_NO, PAYMENT_CHANNEL, username, password, sm, authUsername, authPassword);
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				if (responseTalimatliOdeme == null) {
					responseCode = EMPTY_RETURN_CODE;
				} else {
					responseCode = responseTalimatliOdeme.getReturnCode();
				}
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
			}
			logger.info("ICS_DSMART_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - DSmartClient.setPayment(...) after call.."));
			logger.info("ICS_DSMART_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - DSmartClient.setPayment(...) returned errorCode ".concat(responseCode)));
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DSMART_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		StringBuilder builder = new StringBuilder();
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String endPoint = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String tahsilatIptalTarihi = "";

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CANCEL_DATE))) {
				tahsilatIptalTarihi = getDate(CommonHelper.getDateTime(iMap.getString(MapKeys.CANCEL_DATE), "yyyyMMddhhmmss"), invoiceNo);
			} else {
				tahsilatIptalTarihi = getDate(new Date(), invoiceNo);
			}

			String subscriberNo = iMap.getString("SUBSCRIBER_NO_1", null);
			if (subscriberNo == null) {
				subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}

			builder.append(" ICS_DSMART_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis No -> ");
			builder.append(invoiceNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(endPoint);
			logger.info(builder.toString());

			ResponseBase response = DSmartClient.setPaymentCancel(endPoint, bankCode, subscriberNo, invoiceNo, tahsilatIptalTarihi, username, password, sm, authUsername, authPassword);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			logger.info("ICS_DSMART_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			if (response == null) {
				responseCode = "3319";
			} else {
				responseCode = response.getReturnCode();
			}
			logger.info("ICS_DSMART_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_DSMART_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DSMART_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		DirectDebitInfoResponse response = null;
		String responseCode = "";
		StringBuilder builder = new StringBuilder();
		String hataMesaji = "";
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			builder.append(" STO_DSMART_SEND_STANDING_ORDER_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(sAboneNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			response = DSmartClient.setDirectDebit(url, bankCode, sAboneNo, username, password, sm, authUsername, authPassword);

			if (response == null)
				responseCode = EMPTY_RETURN_CODE;
			else {
				responseCode = response.getReturnCode();
				hataMesaji = response.getReturnDesc();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			if (response.getCurrentDirectDebit() == null) {
				responseCode = String.valueOf(GeneralConstants.ERROR_CODE_APPROVE);
			}
			logger.info("STO_DSMART_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_DSMART_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_DSMART_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DSMART_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		ResponseBase response = null;
		String responseCode = "";
		StringBuilder builder = new StringBuilder();
		String hataMesaji = "";
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			builder.append(" STO_DSMART_SEND_STANDING_ORDER_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | �sletme Kodu -> ");
			builder.append(aboneNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			response = DSmartClient.setDirectDebitCancel(url, bankCode, aboneNo, username, password, sm, authUsername, authPassword);
			try {
				if (response != null) {
					responseCode = response.getReturnCode();
					hataMesaji = response.getReturnDesc();
				}
			} catch (Exception e) {
				logger.info("ICS_DSMART_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
			}
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			logger.info("STO_DSMART_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_DSMART_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DSMART_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String collectionTypeId = "0";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter = 0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();

			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);

				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				iMap.put(MapKeys.COLLECTION_TYPE, collectionTypeId);
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_DSMART_INVOICE_DEBT_INQUIRY", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght = debtLoadingMap.getSize("INVOICES");
					
					SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
					String str1 = iMap.getString(MapKeys.PROCESS_DATE);
				    Date date1 = formatter.parse(str1);
					
					for (int j = 0; j < invoiceListeLenght; j++) {
						
						String str2 = debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DUE_DATE);
					       Date date2 = formatter.parse(str2);
					       
					       if (date1.compareTo(date2)<=0)
					       {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO1));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_NO));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES", j, MapKeys.AMOUNT));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DUE_DATE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_TERM_YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_TERM_MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES", j, MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES", j, MapKeys.PAYMENT_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES", j, MapKeys.PAYMENT_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES", j, MapKeys.AMOUNT));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_NO));
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
					       }
						
					}

				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DSMART_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_DSMART_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		StringBuilder builder = new StringBuilder();
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageForClose = new ServiceMessage();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_COLLECTION_RECONCILIATION");
			String mutabakatTarihiTV = getDate(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "11111111");// TV
																																		// tarih
																																		// formati
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotalTV = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotalTV = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCountTV = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCountTV = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotalTV.add(cancelTotalTV));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotalTV);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCountTV + cancelCountTV);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCountTV);

			builder.append(" ICS_DSMART_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(mutabakatTarihiTV);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			AgreementResponse resultTV = DSmartClient.getBankAgreement(url, bankCode, mutabakatTarihiTV, collectionCountTV + cancelCountTV, String.valueOf(collectionTotalTV.add(cancelTotalTV)), cancelCountTV, String.valueOf(cancelTotalTV), OnlinePayment_DomainName.DSmart, username, password, serviceMessage, authUsername, authPassword);
			iMap.put("REQUEST_XML_TV", message.getRequest());
			output.put("RESPONSE_XML_TV", message.getResponse());

			if (resultTV == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - result size 0 geldi");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - result size 0 dan buyuk geldi");
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - kurumdan gelen toplam gecerli tahsilat tutari = " + new BigDecimal(resultTV.getPaymentTotal()));
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - kurumdan gelen toplam gecerli tahsilat sayisi = " + Integer.valueOf(resultTV.getPaymentUnit()));
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - kurumdan gelen toplam iptal tahsilat tutar� = " + new BigDecimal(resultTV.getCancelTotal()));
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - kurumdan gelen toplam iptal tahsilat sayisi = " + Integer.valueOf(resultTV.getCancelUnit()));

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(resultTV.getPaymentTotal()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, Integer.valueOf(resultTV.getPaymentUnit()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(resultTV.getCancelTotal()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, Integer.valueOf(resultTV.getCancelUnit()));
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");

				ResponseBase resultCloseTV = DSmartClient.confirmGetBankAgreementDate(url, bankCode, mutabakatTarihiTV, OnlinePayment_DomainName.DSmart, username, password, serviceMessageForClose, authUsername, authPassword);
				iMap.put("REQUEST_XML_FOR_CLOSE_TV", serviceMessageForClose.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE_TV", serviceMessageForClose.getResponse());

				GMMap responceCodeMap = getResponseCodeMapping(resultCloseTV.getReturnCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					logger.error("ICS_DSMART_COLLECTION_RECONCILIATION -> DSmartClient.confirmGetBankAgreementDate() hata meydana geldi...".concat(resultCloseTV.getReturnCode().concat(" - ").concat(resultCloseTV.getReturnDesc())));
				}
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_DSMART_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			iMap.put("REQUEST_XML_TV", message.getRequest());
			output.put("RESPONSE_XML_TV", message.getResponse());
			iMap.put("REQUEST_XML_FOR_CLOSE_TV", serviceMessageForClose.getRequest());
			output.put("RESPONSE_XML_FOR_CLOSE_TV", serviceMessageForClose.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_DSMART_NET_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliationNet(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		StringBuilder builder = new StringBuilder();
		ServiceMessage serviceMessageForClose = new ServiceMessage();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_NET_COLLECTION_RECONCILIATION");
			String mutabakatTarihiInternet = getDate(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "11111111111");// internet
																																				// tarih
																																				// formati
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String authUsername = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String authPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int bankCode = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotalInternet = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotalInternet = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCountInternet = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCountInternet = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotalInternet.add(cancelTotalInternet));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotalInternet);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCountInternet + cancelCountInternet);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCountInternet);

			builder.append(" ICS_DSMART_NET_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Mutabakat Tarihi Internet -> ");
			builder.append(mutabakatTarihiInternet);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			ServiceMessage serviceMessage = new ServiceMessage();

			AgreementResponse resultInternet = DSmartClient.getBankAgreement(url, bankCode, mutabakatTarihiInternet, collectionCountInternet, String.valueOf(collectionTotalInternet), cancelCountInternet, String.valueOf(cancelTotalInternet), OnlinePayment_DomainName.DSmart_NET, username, password, serviceMessage, authUsername, authPassword);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());

			if (resultInternet == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - result size 0 geldi");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - result size 0 dan buyuk geldi");
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - kurumdan gelen toplam gecerli tahsilat tutari = " + new BigDecimal(resultInternet.getPaymentTotal()));
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - kurumdan gelen toplam gecerli tahsilat sayisi = " + Integer.valueOf(resultInternet.getPaymentUnit()));
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - kurumdan gelen toplam iptal tahsilat tutar� = " + new BigDecimal(resultInternet.getCancelTotal()));
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - kurumdan gelen toplam iptal tahsilat sayisi = " + Integer.valueOf(resultInternet.getCancelUnit()));

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(resultInternet.getPaymentTotal()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, Integer.valueOf(resultInternet.getPaymentUnit()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(resultInternet.getCancelTotal()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, Integer.valueOf(resultInternet.getCancelUnit()));
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");

				ResponseBase resultClose = DSmartClient.confirmGetBankAgreementDate(url, bankCode, mutabakatTarihiInternet, OnlinePayment_DomainName.DSmart_NET, username, password, serviceMessageForClose, authUsername, authPassword);
				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessageForClose.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessageForClose.getResponse());

				GMMap responceCodeMap = getResponseCodeMapping(resultClose.getReturnCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					logger.error("ICS_DSMART_NET_COLLECTION_RECONCILIATION -> DSmartClient.confirmGetBankAgreementDate() hata meydana geldi...".concat(resultClose.getReturnCode().concat(" - ").concat(resultClose.getReturnDesc())));
				}
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_DSMART_NET_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			iMap.put("REQUEST_XML_TV", message.getRequest());
			output.put("RESPONSE_XML_TV", message.getResponse());
			iMap.put("REQUEST_XML_FOR_CLOSE_TV", serviceMessageForClose.getRequest());
			output.put("RESPONSE_XML_FOR_CLOSE_TV", serviceMessageForClose.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_DSMART_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		logger.info("ICS_DSMART_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));

			CollectionReconciliationDetailBatch batch = new DSmartReconciliationDetailBatch(iMap, message, OnlinePayment_DomainName.DSmart);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());

		} catch (Throwable e) {
			logger.info("ICS_DSMART_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_DSMART_NET_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetailNet(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		logger.info("ICS_DSMART_NET_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_NET_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));

			CollectionReconciliationDetailBatch batch2 = new DSmartReconciliationDetailBatch(iMap, message, OnlinePayment_DomainName.DSmart_NET);
			output = batch2.runBatch();
			iMap.put("REQUEST_XML_NET", message.getRequest());
			output.put("RESPONSE_XML_NET", message.getResponse());
		} catch (Throwable e) {
			logger.info("ICS_DSMART_NET_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_DSMART_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DSMART_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	private static Date getDate(String date) throws ParseException {
		Date d = null;
		try {
			d = CommonHelper.getDateTime(date, "MM/dd/yyyy");// 2014-07-16
		} catch (ParseException e) {
			d = CommonHelper.getDateTime(date, "dd.MM.yyyy");// 2014-07-16

		}
		return d;
	}

	private static String getDate(Date date, String aboneNo) {
		return CommonHelper.getDateString(date, "yyyy-MM-dd");//
	}
}
