package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.IsuReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.isu.IsuClient;
import tr.com.aktifbank.integration.isu.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.gov.isu.www.services.BorcListDetayGet;
import tr.gov.isu.www.services.Dekont;
import tr.gov.isu.www.services.MutabakatOzet;
import tr.gov.isu.www.services.TahsilatBilgi;
import tr.gov.isu.www.services.TalimatBilgi;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class IsuServices  extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(IsuServices.class);
	private static final String TAHAKKUK_TUR_TAKSIT = "10";
	private static final String TAHAKKUK_TUR_ACMA = "13";
	
	@GraymoundService("ICS_ISU_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISU_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage sm = new ServiceMessage();
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1, "0");
			aboneNo = "".equals(aboneNo) ? "0" : aboneNo;
			String sicilNo = iMap.getString(MapKeys.SUBSCRIBER_NO2, "0");
			sicilNo = "".equals(sicilNo) ? "0" : sicilNo;
			String vezneId = "";
			try{
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
				String sourceCode = iMap.getString(MapKeys.SOURCE, "2");
				vezneId = getCorporateChannel(corporateCode, sourceCode, CommonHelper.getChannelId(), collectionType);
				vezneId = vezneId.split("[|]")[0];
			}catch(Exception e){}
			
			username = "".equals(vezneId) || vezneId == null ? username : vezneId;//kanal bazinda parametreye bakariz
			
			// logger info will be logged
			builder.append(" ICS_ISU_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(aboneNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			logger.info(builder.toString());
			
			BorcListDetayGet[] response = IsuClient.borcListeleDetayGetir(url, username, password, Long.valueOf(sicilNo), Long.valueOf(aboneNo), sm);
			iMap.put("REQUEST_XML_0", sm.getRequest());
			outMap.put("RESPONSE_XML_0", sm.getResponse());
			logger.info("ICS_ISU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - IsuClient.aboneSicilleri(...) is called..."));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if(response.length == 1 && !response[0].getHataKodu().equals("000")){
				CommonHelper.throwBusinessException(660, "Aboneye ait bor� bulunmamaktad�r.");
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			
			HashMap<Long, String> bsAboneTaksit = new HashMap<Long, String>();
			HashMap<Long, String> bsAboneAcmaUcreti = new HashMap<Long, String>();
			
			for (BorcListDetayGet borc : response) {
				String description = borc.getAciklama();
				boolean show = true;				
				if(TAHAKKUK_TUR_TAKSIT.equals(borc.getTur())){/*TAKSITLI BORC VAR ISE ILKI GOSTERILIR SONRAKILER GOSTERILMEZ*/
					if(bsAboneTaksit.containsKey(borc.getAboneNo()))
						show = false;
					else
						bsAboneTaksit.put(borc.getAboneNo(), borc.getAciklama());
					
					description = borc.getSiraNo() + ". " + borc.getAciklama();
				}
								
				if(TAHAKKUK_TUR_ACMA.equals(borc.getTur())){/*ACMA UCRETINDEN BASKA BORCU VAR ISE ACMA UCRETI TURUNDEKI BORC GOSTERILMEZ*/
					if(bsAboneAcmaUcreti.containsKey(borc.getAboneNo()))
						show = false;
				}
				if(borc.getSonOdemeTarihi().getTime().before(new Date()))/*DIGER BORCLAR ICIN SON ODEME TARIHI GECMISLERE GORE KARAR VERILIR*/
					bsAboneAcmaUcreti.put(borc.getAboneNo(), borc.getAciklama());
				
				String year ="0", month = "0";
				if(borc.getDonem() > 100000){
					year = String.valueOf(borc.getDonem()).substring(0, 4);
					month = String.valueOf(borc.getDonem()).substring(5, 6);
				}
				String name = borc.getAdi() != null ? borc.getAdi() : "";
				if(borc.getSoyadi() != null)
					name = name.concat(" ").concat(borc.getSoyadi());
				
				if (show &&!isCollectedInvoice(String.valueOf(borc.getTahakkukNo()), String.valueOf(borc.getAboneNo()), "", "", "", corporateCode)) {
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getSicilNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getTahakkukNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplam());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, name);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTarihi().getTime());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, year);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, month);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplam());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, description);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getTur());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, borc.getHataKodu());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borc.getSiraNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			logger.info("ICS_ISU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - IsuClient.borcListeleDetayGetir(...) finished succesfully"));
		} catch (Throwable e2) {
			if(e2 instanceof GMRuntimeException){
				throw ExceptionHandler.convertException(e2);
			}
			logger.error("ICS_ISU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			outMap.put("RESPONSE_XML_ERR", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_ISU_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISU_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subeNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String giseNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			String vezneId = "";
			Integer tahsilatTuru = 1;
			try{
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
				String sourceCode = iMap.getString(MapKeys.SOURCE, "2");
				vezneId = getCorporateChannel(corporateCode, sourceCode, CommonHelper.getChannelId(), collectionType);
				tahsilatTuru = Integer.valueOf(vezneId.split("[|]")[1]);
				vezneId = vezneId.split("[|]")[0];
			}catch(Exception e){}
			
			username = "".equals(vezneId) || vezneId == null ? username : vezneId;//kanal bazinda parametreye bakariz
			
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sicilNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String tur = iMap.getString(MapKeys.PARAMETER1);
			String hataKodu = iMap.getString(MapKeys.PARAMETER2);			
			String siraNo = iMap.getString(MapKeys.PARAMETER3);
			String toplam = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			
			String transactionID = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd/MM/yyyy HH:mm:ss");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "dd/MM/yyyy HH:mm:ss");
			}
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_ISU_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | transaction No -> ");
			builder.append(transactionID);
			builder.append(" | sicil No -> ");
			builder.append(sicilNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			logger.info(builder.toString());
			
			TahsilatBilgi[] tahsilatBilgi = new TahsilatBilgi[1];
			tahsilatBilgi[0] = new TahsilatBilgi(Long.valueOf(aboneNo), hataKodu, Integer.valueOf(siraNo), Long.valueOf(tahakkukNo), Double.valueOf(toplam), tur);
			Dekont response = null;
			
			if (isStandingOrderCollection) {/*TALIMAT ODEMESI ICIN TALIMATLI ODE SERVISI*/
				String[] dekontNo = {transactionID};
				Dekont[] r = IsuClient.talimatTahsilat(url, username, password, subeNo, giseNo, dekontNo, tahsilatBilgi, tahsilatTarihi, sm);
				response = r[0];
				logger.info("ICS_ISU_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IsuClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			}else{/*NORMAL ODEME ICIN NORMAL ODEME SERVISI*/
				response = IsuClient.tahsilat(url, username, password, Long.valueOf(sicilNo), tahsilatBilgi, subeNo, giseNo, transactionID, null, null, tahsilatTarihi, tahsilatTuru, sm);
				logger.info("ICS_ISU_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IsuClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			responceCodeMap = getResponseCodeMapping(response.getHataKodu(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter4(response.getDekontNo());
				invoicePayment.setParameter5(tahsilatTarihi);
				session.saveOrUpdate(invoicePayment);
			}

			logger.info("ICS_ISU_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - IsuClient.tahsilat(...) returned errorCode ".concat(response.getHataKodu())));
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			outMap.put("RESPONSE_XML_ERR", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_ISU_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISU_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String subeNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String giseNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			String vezneId = "";
			try{
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
				String sourceCode = iMap.getString(MapKeys.SOURCE, "2");
				vezneId = getCorporateChannel(corporateCode, sourceCode, CommonHelper.getChannelId(), collectionType);
				vezneId = vezneId.split("[|]")[0];
			}catch(Exception e){}
			
			username = "".equals(vezneId) || vezneId == null ? username : vezneId;//kanal bazinda parametreye bakariz
			
			String dekontNo = iMap.getString("PARAMETER_4", null);
			if (dekontNo == null) {
				dekontNo = iMap.getString(MapKeys.PARAMETER4);
			}
			
			String tahsilatTarihi = iMap.getString("PARAMETER_5", null);
			if (tahsilatTarihi == null) {
				tahsilatTarihi = iMap.getString(MapKeys.PARAMETER5);
			}
			tahsilatTarihi = tahsilatTarihi.substring(0, 10);//date format DD/MM/YYYY
			
			builder.append(" ICS_ISU_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | url -> ");
			builder.append(url);
			logger.info(builder.toString());

			
			String response = IsuClient.tahsilatIptalDekontaGore(url, username, password, tahsilatTarihi, subeNo, giseNo, dekontNo, null, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			logger.info("ICS_ISU_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_ISU_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response));
			
			GMMap responceCodeMap = getResponseCodeMapping(response, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			outMap.put("RESPONSE_XML_ERR", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_ISU_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		ServiceMessage sm = new ServiceMessage();
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISU_COLLECTION_RECONCILIATION");
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String subeNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String giseNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_ISU_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());
			MutabakatOzet response = IsuClient.mutabakatToplamAdetTutar(url, username, password, subeNo, giseNo, reconDate, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			
			if (response == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_ISU_COLLECTION_RECONCILIATION - result size 0 geldi");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_ISU_COLLECTION_RECONCILIATION - response.getBgsTahsilIcmalDto() null degil");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(response.getTahsilatTutar(), MathContext.DECIMAL64).subtract(new BigDecimal(response.getIptalTutar(), MathContext.DECIMAL64)));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getTahsilatAdet() - response.getIptadet());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIptalTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIptadet());
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_ISU_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				IsuClient.mutbakatIstek(url, username, password, reconDate, response.getGiseMutAdet(), response.getGiseMutTutar(), response.getTalimatMutAdet(), response.getTalimatMutTutar(), sm);
				iMap.put("REQUEST_TMY_XML", sm.getRequest());
				output.put("RESPONSE_TMY_XML", sm.getResponse());				
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_ISU_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			output.put("RESPONSE_XML_ERR", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_ISU_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_ISU_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISU_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {
			CollectionReconciliationDetailBatch batch = new IsuReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
		} catch (Throwable e) {
			logger.info("ICS_ISU_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			output.put("RESPONSE_XML_ERR", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_ISU_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ISU_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_ISU_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ISU_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String hataMesaji = "";
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			
			String vezneId = "";
			try{
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
				String sourceCode = iMap.getString(MapKeys.SOURCE, "2");
				vezneId = getCorporateChannel(corporateCode, sourceCode, CommonHelper.getChannelId(), collectionType);
				vezneId = vezneId.split("[|]")[0];
			}catch(Exception e){}
			
			username = "".equals(vezneId) || vezneId == null ? username : vezneId;//kanal bazinda parametreye bakariz

			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sicilNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String sozlesmeNo = "0";
						
			builder.append(" STO_ISU_SEND_STANDING_ORDER_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(aboneNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			String response = IsuClient.talimatlandir(url, username, password, Long.valueOf(sozlesmeNo), Long.valueOf(aboneNo), Long.valueOf(sicilNo), sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			logger.info("STO_ISU_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response));
			GMMap responceCodeMap = getResponseCodeMapping(response, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_ISU_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			outMap.put("RESPONSE_XML_ERR", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_ISU_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ISU_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String hataMesaji = "";
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			
			String vezneId = "";
			try{
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
				String sourceCode = iMap.getString(MapKeys.SOURCE, "2");
				vezneId = getCorporateChannel(corporateCode, sourceCode, CommonHelper.getChannelId(), collectionType);
				vezneId = vezneId.split("[|]")[0];
			}catch(Exception e){}
			
			username = "".equals(vezneId) || vezneId == null ? username : vezneId;//kanal bazinda parametreye bakariz
			
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sicilNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String sozlesmeNo = "0";
			
			builder.append(" STO_ISU_SEND_STANDING_ORDER_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | abone no -> ");
			builder.append(aboneNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			String response = IsuClient.talimatIptali(url, username, password, Long.valueOf(sozlesmeNo), Long.valueOf(aboneNo), Long.valueOf(sicilNo), sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			logger.info("STO_ISU_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response));
			GMMap responceCodeMap = getResponseCodeMapping(response, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_ISU_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			iMap.put("REQUEST_XML_ERR", sm.getRequest());
			outMap.put("RESPONSE_XML_ERR", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_ISU_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_ISU_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);

			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			
			GMMap debtLoadingMap = new GMMap();
			
			int counter=0;
			for (int i = 0; i < bankStandingOrderList.size(); i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				
				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				iMap.put(MapKeys.SUBSCRIBER_NO2, icsStandingOrder.getSubscriberNo2());
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_ISU_INVOICE_DEBT_INQUIRY", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", debtLoadingMap.getString("INVOICES",j, "DESCRIPTION"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ISU_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("STO_ISU_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ISU_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			TalimatBilgi[] response = IsuClient.talimatListele(url, username, password, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, corporateCode);
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			String iptalList = "";
			String talimatList = "";
			for(TalimatBilgi corpStandingOrder : response){
				String aboneNo = String.valueOf(corpStandingOrder.getAboneNo());
				String sicilNo = String.valueOf(corpStandingOrder.getSicilNo());
				boolean found = false;
				for(int i = 0; i < bankStandingOrderList.size(); i++){
					if(bankStandingOrderList.get(i).getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)){
						String bankAboneNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo1(), '0');
						String bankSicilNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo2(), '0');
						
						if(bankAboneNo.equals(aboneNo) && bankSicilNo.equals(sicilNo)){
							found = true;
						}
					}
				}
				//kurumdaki talimat bizde bulunmaz ise iptal gonderilir
				if(!found){
					iptalList.concat(aboneNo).concat(";");
					try {
						iMap.put(MapKeys.SUBSCRIBER_NO1, aboneNo);
						iMap.put(MapKeys.SUBSCRIBER_NO2, sicilNo);
						GMServiceExecuter.call("STO_ISU_SEND_STANDING_ORDER_CANCEL_MESSAGE", iMap);
					} catch (GMRuntimeException e) {
						logger.info("STO_ISU_STANDING_ORDER_RECONCILIATION ".concat(aboneNo).concat(" iptalinde hata : ").concat(e.getMessage()));
					}
				}
			}
			int bankSTOCounter = 0;
			for(int i = 0; i < bankStandingOrderList.size(); i++){
				if(bankStandingOrderList.get(i).getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)){
					String bankAboneNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo1(), '0');
					String bankSicilNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo2(), '0');
					boolean found = false;
					for(TalimatBilgi corpStandingOrder : response){
						String aboneNo = String.valueOf(corpStandingOrder.getAboneNo());
						String sicilNo = String.valueOf(corpStandingOrder.getSicilNo());
						
						if(bankAboneNo.equals(aboneNo) && bankSicilNo.equals(sicilNo)){
							found = true;
						}
					}
					//bizde talimatli kurumda bulunmaz ise talimat gonderilir
					if(!found){
						talimatList.concat(bankAboneNo).concat(";");
						try {
							iMap.put(MapKeys.SUBSCRIBER_NO1, bankAboneNo);
							iMap.put(MapKeys.SUBSCRIBER_NO2, bankSicilNo);							
							GMServiceExecuter.call("STO_ISU_SEND_STANDING_ORDER_MESSAGE", iMap);
						} catch (GMRuntimeException e) {
							logger.info("STO_ISU_STANDING_ORDER_RECONCILIATION ".concat(bankAboneNo).concat(" talimat hata : ").concat(e.getMessage()));
						}
					}
					bankSTOCounter++;
				}
			}
			String emails = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_INFORM_REPORT");
			CommonHelper.sendMail(Arrays.asList(emails.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Talimat Mutabakat batch'i i�in " + reconDate + " tarihli �al��ma raporu", 
					"Talimat iptal gonderilen abone listesi :".concat(iptalList).concat("\n").concat("Talimat istegi gonderilen abone listesi").concat(talimatList));
			
			outMap.put(MapKeys.RECON_BANK_COUNT, bankSTOCounter);
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
			outMap.put(MapKeys.RECON_CORPORATE_COUNT, response.length);
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_ISU_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
}
