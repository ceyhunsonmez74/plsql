package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.KaramanliReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.karamanli.KaramanliClient;
import tr.com.aktifbank.integration.karamanli.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.karamanli.ArrayOfBakiye;
import tr.com.karamanli.ArrayOfBakiyeWithMukellef;
import tr.com.karamanli.Bakiye;
import tr.com.karamanli.BakiyeWithMukellef;
import tr.com.karamanli.MutabakatToplam;
import tr.com.karamanli.ObjectFactory;
import tr.com.karamanli.Sonuc;
import tr.com.karamanli.TahsilatServiceDoTahsilatByBakiyeArrayInvalidOperationFaultFaultFaultMessage;
import tr.com.karamanli.TahsilatServiceDoTahsilatIptalByRefNoInvalidOperationFaultFaultFaultMessage;
import tr.com.karamanli.TahsilatServiceGetAllBakiyeWithMukellefByCriteriaInvalidOperationFaultFaultFaultMessage;
import tr.com.karamanli.TahsilatServiceGetMutabakatSumByStartAndEndDateInvalidOperationFaultFaultFaultMessage;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class KaramanliServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(KaramanliServices.class);
	
	@GraymoundService("ICS_KARAMANLI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KARAMANLI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			// client icerisinde hangi alan dolu ise o alana gore sorgulama
			// yapilacaktir
			int sicilNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			String legacyDistrictCode = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String legacySPNumber = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";
			ArrayOfBakiyeWithMukellef response = new ArrayOfBakiyeWithMukellef();
			try {
				response = KaramanliClient.getAllBakiyeWithMukellefByCriteria(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, null, 0, sicilNo, kurumKodu);
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//				responseMessage = response.getResponseBody().getSystemMessage();
			} catch (TahsilatServiceGetAllBakiyeWithMukellefByCriteriaInvalidOperationFaultFaultFaultMessage faultMessage) {
				logger.error("KARAMANLI HATA:",faultMessage);
//				 FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
//				FaultMessage f=(FaultMessage)ex;
				logger.error("ICS_KARAMANLI_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (FaultMessage)"));
				responseCode = faultMessage.getFaultInfo().getErrorCode().toString();
				responseMessage = faultMessage.getFaultInfo().getErrorMessage().getValue();
				System.out.println();
				logger.info("ICS_KARAMANLI_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
				logger.info("ICS_KARAMANLI_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (BakiyeWithMukellef bill : response.getBakiyeWithMukellef()) {
						if (!isCollectedInvoice(bill.getTahakkukNo().toString(), bill.getSicilNo().toString(), "", "", "", corporateCode)) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bill.getSicilNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, legacyDistrictCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, legacySPNumber);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getTahakkukNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getToplamTutar());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, response.getBakiyeWithMukellef().get(0).getMukellef().getValue().getAd().getValue()+ " " +response.getBakiyeWithMukellef().get(0).getMukellef().getValue().getSoyad().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.convertGregorianCalendar2Date(bill.getSonOdemeTarihi()));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getToplamTutar());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, bill.getGelirTur().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, bill.getReferansNo().getValue());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
						}
					}
				}
			
		} catch (Throwable e2) {
			logger.error("ICS_KARAMANLI_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KARAMANLI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KARAMANLI_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
	

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Long tahakkukNo = iMap.getLong(MapKeys.INVOICE_NO);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
			int sicilNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			BigDecimal invoiceAmount = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String referansNoString = iMap.getString(MapKeys.PARAMETER2);


			
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			XMLGregorianCalendar paymentDate=  CommonHelper.convertDate2GregorianCalendar(tahsilatTarihi, "yyyy-MM-dd");    

			String responseCode = "0";
			String responseMessage = "";
			Sonuc response = null;
			try {
				ArrayOfBakiye bakiyeList= new ArrayOfBakiye();
				Bakiye bakiye = new Bakiye();
				ObjectFactory objectFactory = new ObjectFactory();
				JAXBElement<String> referansNo = objectFactory.createTahsilatReferansNo(referansNoString);
				bakiye.setReferansNo(referansNo);
				bakiye.setTahakkukNo(tahakkukNo);
				bakiyeList.getBakiye().add(bakiye);
				response = KaramanliClient.doTahsilatByBakiyeArray(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, paymentAmount, sicilNo, bakiyeList, bankaReferansNo, paymentDate, username);
				responseCode = response.getKod().toString();
				responseMessage = response.getAciklama().getValue();
			} catch (TahsilatServiceDoTahsilatByBakiyeArrayInvalidOperationFaultFaultFaultMessage  f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_KARAMANLI_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorCode().toString();
				responseMessage = f.getFaultInfo().getErrorMessage().getValue();
				CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

				logger.info("ICS_KARAMANLI_DO_INVOICE_COLLECTION FaultMessage error code = ".concat(responseCode));
				logger.info("ICS_KARAMANLI_DO_INVOICE_COLLECTION FaultMessage error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(response.getReferansNo().getValue());
				session.saveOrUpdate(invoicePayment);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KARAMANLI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KARAMANLI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);

			String referansNo = iMap.getString(MapKeys.PARAMETER_2, null);
			if (referansNo == null) {
				referansNo = iMap.getString(MapKeys.PARAMETER2);
			}
			

			
			String responseCode = "0";
			String responseMessage = "";
			try {
				String aciklama="";
				int sicil = iMap.getInt("SUBSCRIBER_NO_1");
				if (sicil == 0) {
					sicil = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
				}
				Sonuc response = KaramanliClient.doTahsilatIptalByRefNo(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, referansNo, aciklama, bankaReferansNo, sicil, kurumKodu);
				responseCode = response.getKod().toString();
				responseMessage = response.getAciklama().getValue();
			} catch (TahsilatServiceDoTahsilatIptalByRefNoInvalidOperationFaultFaultFaultMessage f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_KARAMANLI_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getErrorCode().toString();
				responseMessage = f.getFaultInfo().getErrorMessage().getValue();
				logger.info("ICS_KARAMANLI_SEND_COLLECTION_CANCEL_MESSAGE FaultMessage response code = ".concat(responseCode));
				logger.info("ICS_KARAMANLI_SEND_COLLECTION_CANCEL_MESSAGE FaultMessage response message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	
	
	
	@GraymoundService("ICS_KARAMANLI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		String responseCode="";
		String responseMessage = "";

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KARAMANLI_COLLECTION_RECONCILIATION");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = CommonHelper.convertDate2GregorianCalendar(reconDateString, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();

			MutabakatToplam response= new MutabakatToplam();
			try {
				response = KaramanliClient.getMutabakatSumByStartAndEndDate(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, kurumKodu, reconDate, reconDate);
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//				 responseMessage = response.getResponseBody().getSystemMessage();
			} catch (TahsilatServiceGetMutabakatSumByStartAndEndDateInvalidOperationFaultFaultFaultMessage f) {
				logger.error("KARAMANLI HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_KARAMANLI_COLLECTION_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorCode().toString();
				responseMessage = f.getFaultInfo().getErrorMessage().getValue();
				logger.info("ICS_KARAMANLI_COLLECTION_RECONCILIATION error code = ".concat(responseCode));
				logger.info("ICS_KARAMANLI_COLLECTION_RECONCILIATION error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			BigDecimal corpCollectionTotal = new BigDecimal(0);
			BigDecimal corpCancelTotal = new BigDecimal(0);
			int corpCollectionCount = 0;
			int corpCancelCount = 0;

			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responseCode)) {
				// tahsilat yok ya da hata var
				// sayilari 0 a esitle
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getTahsilatTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getTahsilatSayi());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIptalTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIptalSayi());
			}
			else {
				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
			}	

//			BigDecimal corpReconCollectionTotal = corpCollectionTotal.subtract(corpCancelTotal);
//			BigDecimal corpReconCancelTotal = corpCancelTotal;
//			int corpReconCollectionCount = corpCollectionCount-corpCancelCount;
//			int corpReconCancelCount = corpCancelCount;
			
			
//			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpReconCollectionTotal);
//			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpReconCollectionCount);
//			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpReconCancelCount);
//			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpReconCancelTotal);




			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			}
			
		}
		catch (Throwable e) {
			logger.info("ICS_KARAMANLI_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_KARAMANLI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		String responseCode="";
		String responseMessage = "";
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KARAMANLI_COLLECTION_RECONCILIATION_CLOSED");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = CommonHelper.convertDate2GregorianCalendar(reconDateString, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			String paymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			String cancelPaymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);
			
			MutabakatToplam response = new MutabakatToplam();
			try {
				 response = KaramanliClient.getMutabakatSumByStartAndEndDate(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, kurumKodu, reconDate, reconDate);
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//				 responseMessage = response.getResponseBody().getSystemMessage();
			} catch (TahsilatServiceGetMutabakatSumByStartAndEndDateInvalidOperationFaultFaultFaultMessage f) {
				logger.error("KARAMANLI HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_KARAMANLI_COLLECTION_RECONCILIATION_CLOSED ".concat(" - an error is occured (FaultMessage)"));
				responseCode = f.getFaultInfo().getErrorCode().toString();
				responseMessage = f.getFaultInfo().getErrorMessage().getValue();
				logger.info("ICS_KARAMANLI_COLLECTION_RECONCILIATION_CLOSED error code = ".concat(responseCode));
				logger.info("ICS_KARAMANLI_COLLECTION_RECONCILIATION_CLOSED error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	
				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
						output.put(MapKeys.ERROR_CODE, "660");
						output.put(MapKeys.ERROR_DESC, errorMessage);
					}
					else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	@GraymoundService("ICS_KARAMANLI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_KARAMANLI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KARAMANLI_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new KaramanliReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_GASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	


	
	

	public static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

	    try {

	    	Date date = CommonHelper.getDateTime(datetime, dateFormat);	        
	        GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(date);

	        return  DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);


	    } catch (Exception e) {

	        System.out.print(e.getMessage());

	        return null;

	    }
	}
	
	private static String getStringFromXMLGregorianCalendar(XMLGregorianCalendar date, String dateFormat){
			
	SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
	GregorianCalendar gc = date.toGregorianCalendar();
	String formattedString = sdf.format(gc.getTime());
	return formattedString;
	}
	
	public static void main(String[] args) {
		String dateString =CommonHelper.getLongDateTimeString(new Date());
		
		 GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(new Date());
	    XMLGregorianCalendar xgc;
		try {
			xgc = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
			System.out.println(dateString);
			String date= getStringFromXMLGregorianCalendar(xgc , "yyyyMMdd");
			
			System.out.println(date);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
