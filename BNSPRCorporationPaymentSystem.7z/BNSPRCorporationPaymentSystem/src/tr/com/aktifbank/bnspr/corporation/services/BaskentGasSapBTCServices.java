package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.BaskentGasSapBTCReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.baskentgazSapBTC.BaskentGasSapBTCClient;
import tr.com.aktifbank.integration.baskentgazSapBTC.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.fica.baskent.borcsorgu.DTFICOOBKBRes;
import tr.com.fica.baskent.gunsonukontrol.DTFICAOBGSKRes;
import tr.com.fica.baskent.gunsonutamamlama.DTFICAOBGSTRes;
import tr.com.fica.baskent.tahsilat.DTFICAOBBKRes;
import tr.com.fica.baskent.talimatliborcsorgu.DTFICAOBOOTKBRes;
import tr.com.fica.baskent.talimatyaratsil.DTFICOOBOOTYSRes;
import tr.com.fica.baskent.terskayit.DTFICAOBBKTRes;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;


public class BaskentGasSapBTCServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(BaskentGasSapBTCServices.class);
	
	private static final String SOURCE_CODE="2";
	private static final String QUERY="G";
	private static final String SEND="Y";
	private static final String CANCEl="S";
	@GraymoundService("ICS_BASKENTGAS_SAP_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			// client icerisinde hangi alan dolu ise o alana gore sorgulama
			// yapilacaktir
			String contractNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String tcNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			
			
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String sourceCode = SOURCE_CODE;
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			DTFICOOBKBRes response= new DTFICOOBKBRes();
			
		
				response = BaskentGasSapBTCClient.debtInquiry(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, paymentChannel, tcNo, contractNo);
				responseCode=response.getERETURN();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				
				for (tr.com.fica.baskent.borcsorgu.DTFICOOBKBRes.ETSORGU.Item debt : response.getETSORGU().getItem()) {
						if (!isCollectedInvoice(debt.getXBLNR(), debt.getVKONT(), debt.getTCNO(), "", "", corporateCode)) {
							if (debt.getTOTALAMNT().compareTo(new BigDecimal("0")) > 0) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debt.getVKONT());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debt.getTCNO());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debt.getXBLNR());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debt.getTOTALAMNT());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debt.getNAME());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(debt.getFAEDN().toGregorianCalendar().getTime()));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debt.getFAEDN().toGregorianCalendar().get(Calendar.YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, debt.getFAEDN().toGregorianCalendar().get(Calendar.MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debt.getTOTALAMNT());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}
						}
				}
			}
		} catch (Throwable e2) {
			logger.error("ICS_BASKENTGAS_SAP_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_BASKENTGAS_SAP_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 
			
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			String contractNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceAmount = iMap.getString(MapKeys.INVOICE_AMOUNT);
			String paymentAmount = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE,"0"));
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyyMMdd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			}
			if (!invoiceAmount.equals(paymentAmount)) {
				// kismi ya da fazla odeme yapiliyorsa fatura tutarini degistir
				invoiceAmount = paymentAmount;
			}
			if (isStandingOrderCollection) {
				logger.info("ICS_BASKENTGAS_SAP_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - BaskentGasSapBTCClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			} else {
				logger.info("ICS_BASKENTGAS_SAP_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - BaskentGasSapBTCClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			DTFICAOBBKRes response = new DTFICAOBBKRes();
			String responseCode = "0";
			String responseMessage = "";

			response =	BaskentGasSapBTCClient.doInvoice(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, paymentChannel, contractNo, invoiceNo, tahsilatTarihi);
			responseCode = response.getERETURN();
		
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_BASKENTGAS_SAP_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		
			String cancelDate = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			
			

			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String contractNo = iMap.getString("SUBSCRIBER_NO_1");
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			
			if (iMap.getBoolean(MapKeys.RECON_CALL)) {
				cancelDate= iMap.getString(MapKeys.PAYMENT_DATE);
				contractNo=iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}


			String sourceCode = SOURCE_CODE;
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE,"0"));
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			
			DTFICAOBBKTRes  response = new DTFICAOBBKTRes();
			String responseCode = "0";
			String responseMessage = "";
			
			response = BaskentGasSapBTCClient.cancelPayment(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, paymentChannel, contractNo, invoiceNo, cancelDate);
			responseCode = response.getERETURN();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_BASKENTGAS_SAP_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_BASKENTGAS_SAP_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			

			String sourceCode = SOURCE_CODE;
	
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.valueOf(DatabaseConstants.CollectionTypes.InvoiceLoad);
			String channel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			String contractNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			DTFICOOBOOTYSRes  response = new DTFICOOBOOTYSRes();
	
				response=BaskentGasSapBTCClient.sendStandingOrder(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, channelCode, contractNo, SEND);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				GMMap responceCodeMap = getResponseCodeMapping(response.getERETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, response.getERETURN());
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_BASKENTGAS_SAP_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_BASKENTGAS_SAP_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			

			String sourceCode = SOURCE_CODE;
		
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.valueOf(DatabaseConstants.CollectionTypes.InvoiceLoad);
			String channel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			String contractNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			DTFICOOBOOTYSRes  response = new DTFICOOBOOTYSRes();

				response=BaskentGasSapBTCClient.sendStandingOrder(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, channelCode, contractNo, CANCEl);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				GMMap responceCodeMap = getResponseCodeMapping(response.getERETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, response.getERETURN());
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	
	}
	
	
	@GraymoundService("ICS_BASKENTGAS_SAP_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String date = CommonHelper.getDateString(new Date(), "yyyyMMdd");

	

			DTFICAOBOOTKBRes response = BaskentGasSapBTCClient.debtInuiryforStandingOrder(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, date);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(response.getERETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = CommonHelper.getHibernateSession();
				

				GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

					GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
					int counter = 0;
					List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
						if (icsStandingOrder.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
							String subscriberNo = CommonHelper.trimStart(icsStandingOrder.getSubscriberNo1(), '0');
							for (tr.com.fica.baskent.talimatliborcsorgu.DTFICAOBOOTKBRes.ETSORGU.Item debt : response.getETSORGU().getItem()) {
								if (icsStandingOrder.getSubscriberNo1().equals(debt.getVKONT())) {
				
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debt.getVKONT());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debt.getXBLNR());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debt.getTOTALAMT());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debt.getNAME());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(debt.getFAEDN().toGregorianCalendar().getTime()));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debt.getFAEDN().toGregorianCalendar().get(Calendar.YEAR));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debt.getFAEDN().toGregorianCalendar().get(Calendar.MONTH));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, collectionTypeId);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionTypeId);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debt.getTOTALAMT());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
								}
							}
						}
					}
					outMap.put(MapKeys.TABLE_SIZE, counter);
					outMap.put(MapKeys.RESPONSE_CODE, responseCode);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "Onay");
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BASKENTGAS_SAP_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	
	@GraymoundService("ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		String responseCode="";
		String responseMessage = "";
		DTFICAOBGSKRes  response=null;
		DTFICAOBGSTRes responseClose=  null;

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
	
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String reconDateString = iMap.getString(MapKeys.RECON_DATE);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();

			response = BaskentGasSapBTCClient.doReconControl(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, reconDateString);
			responseCode = response.getERETURN();
		
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

//			List<tr.com.fica.baskent.gunsonukontrol.DTFICAOBGSKRes.ETOKDETAY.Item> transactionList= response.getETOKDETAY().getItem();
//			BigDecimal corpCollectionTotal = new BigDecimal(0);
//			BigDecimal corpCancelTotal = new BigDecimal(0);
//			int corpCollectionCount = 0;
//			int corpCancelCount = 0;
//
//			if (transactionList.size() == 0) {
//				// tahsilat yok ya da hata var
//				// sayilari 0 a esitle
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
//			}
//			else {
				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getETOPLAM().getBETRH());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getETOPLAM().getADET());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getETOPLAM().getTBETRH());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getETOPLAM().getTADET());
//			}
			
	
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				ServiceMessage serviceMessageForClose = new ServiceMessage();
				
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
					output.put(MapKeys.ERROR_CODE, "660");
					output.put(MapKeys.ERROR_DESC, errorMessage);
				}
				else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		DTFICAOBGSTRes response=  null;
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageQuery = new ServiceMessage();

		String responseCode="";
		String responseMessage = "";
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION_CLOSED");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String date = iMap.getString(MapKeys.RECON_DATE);
			
			String reconDateString = iMap.getString(MapKeys.RECON_DATE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			String paymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			String cancelPaymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);
			
			Session hibernateSession = CommonHelper.getHibernateSession();

			
			Criteria criteriaWs = hibernateSession.createCriteria(WebServices.class);
			Criterion statusWS = Restrictions.eq("status", true);
			Criterion corporateCodeWS = Restrictions.eq("corporateCode", iMap.getString(MapKeys.CORPORATE_CODE));
			Criterion webServiceName = Restrictions.eq("serviceName", "ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION");// wrapper dan// gelecek
			criteriaWs.add(statusWS).add(corporateCodeWS).add(webServiceName);
			
			GMMap queryMap= new GMMap();
			List<WebServices> wsServiceList = criteriaWs.list();
			if (wsServiceList.size() > 0) {
				int wsServiceListSize = wsServiceList.size();
				for (int i=0;i<wsServiceListSize;i++){
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.WS_PASSWORD, wsServiceList.get(i).getWsPassword());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.WS_ENDPOINT, wsServiceList.get(i).getWsEndPoint());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.WS_USER, wsServiceList.get(i).getWsUser());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.SERVICE_OID, wsServiceList.get(i).getOid());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER1, wsServiceList.get(i).getParameter1());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER2, wsServiceList.get(i).getParameter2());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER3, wsServiceList.get(i).getParameter3());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER4, wsServiceList.get(i).getParameter4());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER5, wsServiceList.get(i).getParameter5());
					queryMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER6, wsServiceList.get(i).getParameter6());
				}
				
			}
			
			String usernameQuery = queryMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passwordQuery = queryMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrlQuery = queryMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
	
			int reqTimeoutQuery = queryMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeoutQuery = queryMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String firmCodeQuery = queryMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			DTFICAOBGSKRes responsequery = BaskentGasSapBTCClient.doReconControl(reqTimeoutQuery, connTimeoutQuery, serviceUrlQuery, usernameQuery, passwordQuery, serviceMessageQuery, firmCodeQuery, reconDateString);
			 responseCode = responsequery.getERETURN();
	
			iMap.put("REQUEST_XML_FOR_QUERY", serviceMessageQuery.getRequest());
			output.put("RESPONSE_XML_FOR_QUERY", serviceMessageQuery.getResponse());
			
			
			
//			List<tr.com.fica.baskent.gunsonukontrol.DTFICAOBGSKRes.ETOKDETAY.Item> transactionList= responsequery.getETOKDETAY().getItem();
//
//			if (transactionList.size() == 0) {
//				// tahsilat yok ya da hata var
//				// sayilari 0 a esitle
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
//				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
//			}
//			else {
				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, responsequery.getETOPLAM().getBETRH());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, responsequery.getETOPLAM().getADET());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, responsequery.getETOPLAM().getTBETRH());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, responsequery.getETOPLAM().getTADET());
//			}

			response = BaskentGasSapBTCClient.doRecon(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, firmCode, date);
			responseCode = response.getERETURN();
		
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	
				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
						output.put(MapKeys.ERROR_CODE, "660");
						output.put(MapKeys.ERROR_DESC, errorMessage);
					}
					else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION_CLOSED - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	@GraymoundService("ICS_BASKENTGAS_SAP_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_BASKENTGAS_SAP_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BASKENTGAS_SAP_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new BaskentGasSapBTCReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_BASKENTGAS_SAP_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	

}
