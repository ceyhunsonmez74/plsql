package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.depsas.DepsasClient;
import tr.com.aktifbank.integration.depsas.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.abjayon.bill�nquiry.Response.Bills.Bill;
import com.abjayon.fetchaccount.FetchAccountRes;
import com.abjayon.paymentconfirmation.PaymentConfirmationRes;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class DepsasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final String SUCCESS = "S";
	private static final String ONLINE = "01";
	private static final String AUTO = "02";


	private static final Log logger = LogFactory.getLog(DepsasServices.class);

	@GraymoundService("ICS_DEPSAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DEPSAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorCode = "";
		GMMap responceCodeMap = new GMMap();

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int counter = 0;

			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrlInquiry = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String installationID = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String accountID = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			if (!StringUtil.isEmpty(installationID)) {
				tr.com.aktifbank.integration.depsas.ServiceMessage serviceMessageFetch = new tr.com.aktifbank.integration.depsas.ServiceMessage();

				FetchAccountRes fetchAccountResponse = DepsasClient.fetchAccountRequestOperation(reqTimeout, connTimeout, wsUrl, wsUserName, wsPassword, serviceMessageFetch, installationID);
				iMap.put("REQUEST_XML_FETCH", serviceMessageFetch.getRequest());
				outMap.put("RESPONSE_XML_FETCH", serviceMessageFetch.getResponse());
				
				responseCode = fetchAccountResponse.getMessageText();

				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					accountID = fetchAccountResponse.getAccountID();
				}
			}

				ServiceMessage serviceMessageInquiry = new ServiceMessage();
				com.abjayon.bill�nquiry.Response billInquiryResponse = DepsasClient.billInquiryRequestOperation(reqTimeout, connTimeout, wsUrlInquiry, wsUserName, wsPassword, serviceMessageInquiry, accountID);

				iMap.put("REQUEST_XML_INQUIRY", serviceMessageInquiry.getRequest());
				outMap.put("RESPONSE_XML_INQUIRY", serviceMessageInquiry.getResponse());

				if (billInquiryResponse != null) {
					if (SUCCESS.equals(billInquiryResponse.getStatus())) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					} else {
						responseCode = billInquiryResponse.getMessageText();
					}

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						List<Bill> billInquiryResponseDetailList = billInquiryResponse.getBills().getBill();
						int billInquiryResponseDetailListLength = billInquiryResponseDetailList.size();
						for (int i = 0; i < billInquiryResponseDetailListLength; i++) {
							Bill billInquiryResponseDetail = billInquiryResponseDetailList.get(i);
							logger.error(responseCode + " returned by Corporate for ICS_DEPSAS_INVOICE_DEBT_INQUIRY.");

							if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					 		   if (!isCollectedInvoiceNo(billInquiryResponseDetail.getBillID(), corporateCode)) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, billInquiryResponse.getAccountID());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, installationID);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, billInquiryResponse.getTitle());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, billInquiryResponseDetail.getBillID());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, billInquiryResponseDetail.getTotalAmount());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, billInquiryResponseDetail.getSerialNumber());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, billInquiryResponseDetail.getBillType());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE,	CommonHelper.getShortDateTimeString(billInquiryResponseDetail.getDueDate().getValue().toGregorianCalendar().getTime()));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, billInquiryResponseDetail.getDueDate().getValue().toGregorianCalendar().get(Calendar.YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, billInquiryResponseDetail.getDueDate().getValue().toGregorianCalendar().get(Calendar.MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, billInquiryResponseDetail.getTotalAmount());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, CommonBusinessOperations.getCorporateParameterValue(corporateCode, billInquiryResponseDetail.getBillType()));

								
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}
						}
					}
				}
			}
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DEPSAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	
	@GraymoundService("ICS_DEPSAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DEPSAS_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		try {
			String hataMesaji = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String billID = iMap.getString(MapKeys.INVOICE_NO);
			String accountID = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String bankID =  iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			BigDecimal totalAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd'T'HH:mm:ss");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd'T'HH:mm:ss");
			}
			
			   DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			   		
			   Date date = new Date();
			   XMLGregorianCalendar paymentDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(format.format(date));
			
				String channelCode = CommonHelper.getChannelId();

			   boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
				if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
					channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
				}
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
				String sourceCode = iMap.getString(MapKeys.SOURCE);
				
				String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);

			   if (isStandingOrderCollection) {
				   paymentChannel = AUTO;
					logger.info("ICS_DEPSAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" -  before call..").concat("isStandingOrderCollection:true"));
				} else {
					logger.info("ICS_DEPSAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - before call..").concat("isStandingOrderCollection:false"));
				}

			logger.info("ICS_DICLE_DO_INVOICE_COLLECTION is called for subscriber no ".concat(accountID).concat(" and invoice no ").concat(billID));
			tr.com.aktifbank.integration.depsas.ServiceMessage serviceMessage= new tr.com.aktifbank.integration.depsas.ServiceMessage();
			PaymentConfirmationRes response = DepsasClient.paymentConfirmationRequestOperation(reqTimeout, connTimeout, url, username, password, serviceMessage, accountID, bankID, paymentChannel, trasnactionId, billID,totalAmount,paymentDate);
			responseCode = response.getMessageText();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter8(paymentChannel);
				session.saveOrUpdate(invoicePayment);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			logger.info("ICS_DEPSAS_DO_INVOICE_COLLECTION is called markFatura and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(CommonHelper.getStringifiedException(e2)));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_DEPSAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DEPSAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		tr.com.aktifbank.integration.depsas.ServiceMessage serviceMessage= new tr.com.aktifbank.integration.depsas.ServiceMessage();


		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String bankID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			BigDecimal totalAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			String billID = iMap.getString(MapKeys.INVOICE_NO);
			String accountID = iMap.getString("SUBSCRIBER_NO_1",null);
	
			com.abjayonconsulting.paymentcancellation.Response
			response = DepsasClient.paymentCancellationRequestOperation(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, accountID, bankID, trasnactionId, billID, totalAmount);
			String responseCode = response.getMessageText();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_DEPSAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DEPSAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = "";
		String errorCode = "";
		GMMap responceCodeMap = new GMMap();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String wsUrlFetch = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String installationID = iMap.getString(MapKeys.SUBSCRIBER_NO2);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			String accountID = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			if (!StringUtil.isEmpty(installationID)) {
				tr.com.aktifbank.integration.depsas.ServiceMessage serviceMessageFetch = new tr.com.aktifbank.integration.depsas.ServiceMessage();

				FetchAccountRes fetchAccountResponse = DepsasClient.fetchAccountRequestOperation(reqTimeout, connTimeout, wsUrlFetch, username, password, serviceMessageFetch, installationID);
				iMap.put("REQUEST_XML_FETCH", serviceMessageFetch.getRequest());
				outMap.put("RESPONSE_XML_FETCH", serviceMessageFetch.getResponse());
				
				responseCode = fetchAccountResponse.getMessageText();

				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					accountID = fetchAccountResponse.getAccountID();
				}
			}
				
				   DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

				    Date date = new Date();
				    XMLGregorianCalendar fromActiveDate =
				        DatatypeFactory.newInstance().newXMLGregorianCalendar(format.format(date));

				    com.abjayonconsulting.addcustomerforautopay.Response addCustomerAutopayResponse = DepsasClient.addCustomerAutopayRequestOperation(reqTimeout, connTimeout, serviceUrl, username, password, sm, accountID, bankID,
						fromActiveDate);

				iMap.put("REQUEST_XML_TS", sm.getRequest());
				outMap.put("RESPONSE_XML_TS", sm.getResponse());
				responceCodeMap = getResponseCodeMapping(addCustomerAutopayResponse.getMessageText(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	@GraymoundService("STO_DEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DEPSAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = "";
		String errorCode = "";
		GMMap responceCodeMap = new GMMap();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String wsUrlFetch = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String installationID = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			String accountID = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
				tr.com.aktifbank.integration.depsas.ServiceMessage serviceMessageFetch = new tr.com.aktifbank.integration.depsas.ServiceMessage();

				FetchAccountRes fetchAccountResponse = DepsasClient.fetchAccountRequestOperation(reqTimeout, connTimeout, wsUrlFetch, username, password, serviceMessageFetch, installationID);
				iMap.put("REQUEST_XML_FETCH", serviceMessageFetch.getRequest());
				outMap.put("RESPONSE_XML_FETCH", serviceMessageFetch.getResponse());
				
				responseCode = fetchAccountResponse.getMessageText();

				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					accountID = fetchAccountResponse.getAccountID();
				}
			}
				
				   DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

				    Date date = new Date();
				    XMLGregorianCalendar endDate =
				        DatatypeFactory.newInstance().newXMLGregorianCalendar(format.format(date));

				com.abjayonconsulting.deletecustomerautopay.Response deleteCustomerAutopayResponse = DepsasClient.deleteCustomerAutopayRequestOperation(reqTimeout, connTimeout, serviceUrl, username, password, sm, accountID, bankID, endDate);

				iMap.put("REQUEST_XML_TS", sm.getRequest());
				outMap.put("RESPONSE_XML_TS", sm.getResponse());
				responceCodeMap = getResponseCodeMapping(deleteCustomerAutopayResponse.getMessageText(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_DEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();
			
			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				GMMap queryMap = new GMMap();
				queryMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				queryMap.put(MapKeys.SUBSCRIBER_NO2, icsStandingOrder.getSubscriberNo2());

				queryMap.put(MapKeys.BANK_CODE, iMap.getString(MapKeys.BANK_CODE));
				queryMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				queryMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
				queryMap.put(MapKeys.GM_SERVICE_NAME, "ICS_SEARCH_INVOICE");
				queryMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
				GMMap invoiceMap = new GMMap();
				
				debtLoadingMap = (GMMap) GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", queryMap);
				
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DEPSAS_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	@GraymoundService("ICS_DEPSAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DEPSAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorCode = "";
		final String ftmDelimiter = ",";
		final String headerDelimiter = "H";
		final String detailDelimiter = "D";
		final String footerDelimiter = "F";
		final String dateFormat = "yyyy-MM-dd HH:mm:ss";

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal ftmProcessId = getNextValueOfProcessSequence();

			logger.info("ICS_DEPSAS_COLLECTION_RECONCILIATION is called...");
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			String reconDate = CommonHelper.getDateString(iMap.getDate(MapKeys.RECON_DATE),dateFormat);
			String bankId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String ftmId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);

			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			int lineCounter = 1;
			StringBuilder headerLine = new StringBuilder();
			headerLine.append(headerDelimiter).append(ftmDelimiter);
			headerLine.append(bankId).append(ftmDelimiter);
			headerLine.append(reconDate);
			
			FtmFileContent headerContent = new FtmFileContent();
			headerContent.setOid(String.valueOf(lineCounter));
			headerContent.setFtmProcessOid(ftmProcessId);
			headerContent.setLine(headerLine.toString());
			headerContent.setLineNumber(new BigDecimal(lineCounter));
			session.save(headerContent);
			lineCounter++;

			for(int i = 0 ; i < reconBankMap.getSize("BANK"); i++){
				String subscriberNo1 = reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1);
				String subscriberNo2 = reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO2);
				String paymentAmount = reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT);
				String billId = reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO);
				String channel = reconBankMap.getString("BANK", i, MapKeys.PARAMETER8);
				String paymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(reconBankMap.getString("BANK", i, MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), dateFormat) ;
				
				StringBuilder line = new StringBuilder();
				line.append(detailDelimiter).append(ftmDelimiter);
				line.append(subscriberNo1).append(ftmDelimiter);
				line.append(billId).append(ftmDelimiter);
				line.append(paymentAmount).append(ftmDelimiter);
				line.append(paymentDate).append(ftmDelimiter);
				line.append(channel);
			
				
				FtmFileContent content = new FtmFileContent();
				content.setOid(String.valueOf(lineCounter));
				content.setFtmProcessOid(ftmProcessId);
				content.setLine(line.toString());
				content.setLineNumber(new BigDecimal(lineCounter));
				session.save(content);
				lineCounter++;
				
			}
			
			StringBuilder footerLine = new StringBuilder();
			footerLine.append(footerDelimiter).append(ftmDelimiter);
			footerLine.append(collectionCount).append(ftmDelimiter);
			footerLine.append(collectionTotal);
			
			FtmFileContent footerContent = new FtmFileContent();
			footerContent.setOid(String.valueOf(lineCounter));
			footerContent.setFtmProcessOid(ftmProcessId);
			footerContent.setLine(footerLine.toString());
			footerContent.setLineNumber(new BigDecimal(lineCounter));
			session.save(footerContent);
			
			GMMap ftmMap = new GMMap();
			ftmMap.put("FILE_DEF_ID", Long.valueOf(ftmId));
			ftmMap.put("PROCESS_ID", ftmProcessId);
			ftmMap.put("PROCESS_DATE", iMap.getString(MapKeys.RECON_DATE));
			CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_CREATE_AND_TRANSFER_FILE", ftmMap);

			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			outMap.put(MapKeys.ERROR_DESC, "Mutabakat basarili olarak saglandi.");
			logger.info("ICS_DEPSAS_COLLECTION_RECONCILIATION mutabakati basarili olarak saglandi....");
		
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		} catch (Exception e) {
			logger.info("ICS_DEPSAS_COLLECTION_RECONCILIATION an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_DEPSAS_COLLECTION_RECONCILIATION an error accoured with response code : ".concat(responseCode));
			logger.error("ICS_DEPSAS_COLLECTION_RECONCILIATION -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	private static BigDecimal getNextValueOfProcessSequence() {
		return new BigDecimal(((Number) CommonHelper.getHibernateSession().createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual").uniqueResult()).longValue());
	}
	
	//Mutabakat Kapat
	@GraymoundService("ICS_DEPSAS_COLLECTION_RECONCILIATION_CLOSED")
    public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
          GMMap output = new GMMap();
          
          iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DEPSAS_COLLECTION_RECONCILIATION_CLOSED");
          
          try{
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
          }
          catch(Exception e){
                output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
                output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
                output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
                throw ExceptionHandler.convertException(e);
          }
          finally{
                insertOnlineServiceLog(iMap, output);
          }
          
          return output;
    }

	
}
