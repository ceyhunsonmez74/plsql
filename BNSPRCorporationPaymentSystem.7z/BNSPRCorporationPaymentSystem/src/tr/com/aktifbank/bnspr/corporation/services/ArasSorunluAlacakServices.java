package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.arasSorunluAlacak.ArasSorunluAlacakClient;
import tr.com.aktifbank.integration.arasSorunluAlacak.ServiceMessage;
import tr.com.arasSorunluAlacak.Borc;
import tr.com.arasSorunluAlacak.BorcDosya;
import tr.com.arasSorunluAlacak.BorcSorgulamaResponse;
import tr.com.arasSorunluAlacak.MutabakatResponse;
import tr.com.arasSorunluAlacak.OdemeIptalResponse;
import tr.com.arasSorunluAlacak.OdemeResponse;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ArasSorunluAlacakServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(ArasSorunluAlacakServices.class);
	
	@GraymoundService("ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		double zero = 0;
		try {
			// parameters are taken
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String tckn = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String kurumNo = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			// logger info will be logged
			builder.append(" ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | aboneNo-> ");
			builder.append(aboneNo);
			builder.append(" | tckn -> ");
			builder.append(tckn);
			builder.append(" | kurumNo -> ");
			builder.append(kurumNo);
			builder.append(" | Username -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			logger.info("ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - ArasSorunluAlacakClient.borcSorgula(...) will be called..."));
			
			BorcSorgulamaResponse response = ArasSorunluAlacakClient.borcSorgula(reqTimeout, connTimeout,serviceUrl, username, password, aboneNo, tckn, kurumNo, sm);
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - ArasSorunluAlacakClient.borcSorgula(...) returned response code ".concat(response.getSonuc().getMesaj())));
			
			GMMap responceCodeMap = getResponseCodeMapping(String.valueOf(response.getSonuc().getKod()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getSonuc().getKod());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" -ArasSorunluAlacakClient.borcSorgula(...) returned errorCode ".concat(errorCode)));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Map<String,Integer> termGroupList = new HashMap<String, Integer>();
				int groupCounter = 1;
				for ( BorcDosya borcDosya : response.getBorcDosyaList()) {
					
				
				
				for ( Borc borc : borcDosya.getBorcListesi()) {
					if (!isCollectedInvoice(String.valueOf(borc.getFaturaNo()), String.valueOf(borcDosya.getAboneNo()), String.valueOf(borcDosya.getTcKimlikNo()),String.valueOf( borcDosya.getKurumNo()), "", corporateCode)) {
						if (borc.getKalan().compareTo(zero)==1) {
							
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borcDosya.getAboneNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borcDosya.getTcKimlikNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, borcDosya.getKurumNo());

						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getFaturaNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getKalan());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borcDosya.getAdiSoyadi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getVadeTarihi());
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getYil());
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getDonem());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getKalan());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, sbsMuhatabId);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
						}
					}
				}
			   }
			}
			logger.info("ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - ArasSorunluAlacakClient.borcSorgula(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_ARAS_SORUNLU_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		
		return outMap;
	}

	@GraymoundService("ICS_ARAS_SORUNLU_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARAS_SORUNLU_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		try {
			// parameters are taken
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			String kurumNo = iMap.getString(MapKeys.SUBSCRIBER_NO3);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String odemeTutari = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			String p_sIslemReferansNo = iMap.getString(MapKeys.QUERY_REF_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_ARAS_SORUNLU_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();

			OdemeResponse response = ArasSorunluAlacakClient.odeme(reqTimeout, connTimeout,serviceUrl, username, password, kurumNo, odemeTutari,p_sIslemReferansNo, sm);
			
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			
			responceCodeMap = getResponseCodeMapping(String.valueOf(response.getSonuc().getKod()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getSonuc().getMesaj());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) ) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(response.getReferansNo());
				session.saveOrUpdate(invoicePayment);
			}
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			logger.info("ICS_ARAS_SORUNLU_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - ArasSorunluAlacakClient.odeme(...) returned errorCode ".concat(String.valueOf(response.getSonuc().getKod()))));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_ARAS_SORUNLU_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ARAS_SORUNLU_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			
			
			String aboneNo = iMap.getString("SUBSCRIBER_NO_1", null);
			if (aboneNo == null) {
				aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}
			
			String referansNo = iMap.getString(MapKeys.PARAMETER_2, null);
			if (referansNo == null) {
				referansNo = iMap.getString(MapKeys.PARAMETER2);
			}
			
			builder.append(" ICS_ARAS_SORUNLU_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis No -> ");
			builder.append(referansNo);
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | serviceUrl -> ");
			builder.append(serviceUrl);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			OdemeIptalResponse response = ArasSorunluAlacakClient.iptal(reqTimeout, connTimeout,serviceUrl, username, password, referansNo, sm);
						
			iMap.put("REQUEST_TXT", sm.getRequest());
			outMap.put("RESPONSE_TXT", sm.getResponse());
			logger.info("ICS_ARAS_SORUNLU_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_ARAS_SORUNLU_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(String.valueOf(response.getSonuc().getKod())));
			
			GMMap responceCodeMap = getResponseCodeMapping(String.valueOf(response.getSonuc().getKod()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getSonuc().getMesaj());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_ARAS_SORUNLU_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			String date = CommonHelper.formatDateString(reconDate, "yyyyMMdd", "dd.MM.yyyy");
			String type = "Hepsi";
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);

			MutabakatResponse result = ArasSorunluAlacakClient.mutabakat(reqTimeout, connTimeout,serviceUrl, username, password, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());

			
			logger.info("ICS_ARAS_SORUNLU_COLLECTION_RECONCILIATION - result() null degil");
			if(result != null){
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getToplamTutar());
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getToplamAdet());
			} else{
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, BigDecimal.ZERO);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
			}
			
			if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && oMap.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == oMap.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)){
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else{
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ARAS_SORUNLU_COLLECTION_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	
}
