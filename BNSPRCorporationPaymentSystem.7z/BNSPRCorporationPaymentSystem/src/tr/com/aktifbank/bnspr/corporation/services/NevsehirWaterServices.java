package tr.com.aktifbank.bnspr.corporation.services;

import com.graymound.util.GMMap;

public class NevsehirWaterServices  extends OnlineCorporationInterface  {
	
	
	public static GMMap debtInquiry(GMMap iMap) {
		
		GMMap outPutMap = new GMMap();
		try{
//			setCorporateCode(iMap.getString("CORPORATE_CODE"));
//			setWsServiceName(iMap.getString("WS_SERVICE_NAME"));
			init();
			//call ws service
			//fill output map
//			insertOnlineServiceLog(iMap); Ge�ici olarak kapat�ld� 
		}catch (Exception e) {
//			insertOnlineServiceLog(iMap); Ge�ici olarak kapat�ld� 
		}
		return outPutMap;
		
	}

	public static GMMap sendCollectionMessage(GMMap iMap) {
		
		GMMap outPutMap = new GMMap();
		try{
//			setCorporateCode(iMap.getString("CORPORATE_CODE"));
//			setWsServiceName(iMap.getString("WS_SERVICE_NAME"));
			init();
			//call ws service
			//fill output map
//			insertOnlineServiceLog(iMap);
			
		}catch (Exception e) {
			//throw e;
		}
		return outPutMap;
		
	}
	
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
//		setCorporateCode(iMap.getString("CORPORATE_CODE"));
//		setWsServiceName(iMap.getString("WS_SERVICE_NAME"));
		init();
		return null;
		// TODO Auto-generated method stub
		
	}	

	public static GMMap sendStandingOrderMessage(GMMap iMap) {
//		setCorporateCode(iMap.getString("CORPORATE_CODE"));
//		setWsServiceName(iMap.getString("WS_SERVICE_NAME"));
		init();
		return null;
		// TODO Auto-generated method stub
		
	}

}
