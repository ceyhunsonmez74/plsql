package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationResubmitType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.VodafoneCommonServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.VodafoneDebtInqueryServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.VodafoneDoInvoiceCollectionServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.VodafoneReconService;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.vodafone.ServiceMessage;
import tr.com.aktifbank.integration.vodafone.VodafoneClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.vodafone.BillList;
import tr.com.vodafone.BillResponse;
import tr.com.vodafone.CommitPaymentResponse;
import tr.com.vodafone.CustomerInfo;
import tr.com.vodafone.ReconciliationResponse;
import tr.com.vodafone.ReversePaymentResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sap.xi.fica.global.testing.P3CashPointOpenItemFault;

public class VodafoneRestServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(VodafoneRestServices.class);
	private static final String SUN_CUSTOMER_ACCESS_TYPE = "1";
	private static final int CURRENCY_CODE = 949;
	private static final String OPERATION_SOURCE = "0";
	private static final String RECORD_NUMBER = "5";
	private static final String GATEWAY_ERROR = "GWERR";
	private static final String CITY_CODE="34";
	private static final String USER_CODE="CS1002";
	private static final String IP_ADDRESS="91.216.148.2";

	@GraymoundService("ICS_VF_INVOICE_DEBT_INQUIRY_REST")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_INVOICE_DEBT_INQUIRY_REST");
		ServiceMessage serviceMessage = new ServiceMessage();
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		Integer companyId = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String gatewayErrorDesc = "";
		String billInfoBuilder = "";
		String responseCode = "";
		String responseMessage = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";
		int returnedBillNumber = 0;
		int counter = 0;
		try {
			Calendar cal = Calendar.getInstance();
			int month = cal.get(Calendar.MONTH) + 1;
			String sMonth = String.valueOf(month);
			if (month < 10) {
				sMonth = "0".concat(sMonth);
			}
			int year = cal.get(Calendar.YEAR);
			String sYear = String.valueOf(year);
			String correlationId =	UUID.randomUUID().toString().substring(0, 36);

			String ipAddress = "";
			Integer stan =Integer.valueOf(getStanNo());
			// set parameters
			String operationSource = OPERATION_SOURCE;
			String recordNumber = RECORD_NUMBER;
			String originatorIdCityCode = CITY_CODE;
//			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			String originatorIdUserCode = USER_CODE;
			Integer currencyCode = CURRENCY_CODE;
			String sunCustomerAccessType = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String billingPeriod = sYear.concat(sMonth);
			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			String subCorporationId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			String description = iMap.getString(MapKeys.DESCRIPTION);
			String transactionId = iMap.getString(MapKeys.TRX_NO);
			
			Integer cityCode = Integer.parseInt(originatorIdCityCode);
			
			Integer inquiryCount = 1;
			
			CustomerInfo customerInfo = new CustomerInfo();
			customerInfo.setAccessCode(sunCustomerAccessNo);
			customerInfo.setAccessType(sunCustomerAccessType);

			// set GW call parameters
			inputMap.put(VodafoneDebtInqueryServices.Input.OPERATION_SOURCE, operationSource); // P-25
			inputMap.put(VodafoneDebtInqueryServices.Input.RECORD_NUMBER, recordNumber); // P-26
			inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44
			inputMap.put(VodafoneDebtInqueryServices.Input.CURRENCY_CODE, currencyCode);// P-49
			inputMap.put(VodafoneDebtInqueryServices.Input.SUN, 0, VodafoneDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_TYPE, sunCustomerAccessType);// P-60
			inputMap.put(VodafoneDebtInqueryServices.Input.SUN, 0, VodafoneDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_NO, sunCustomerAccessNo);// P-60
			inputMap.put(VodafoneDebtInqueryServices.Input.PEYMENT_PERIOD, billingPeriod);// P-63
			// corporationId corresponds to OID field on
			// ics.gw_corporation_definition table
			inputMap.put(VodafoneDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			// operationCodeId corresponds to OID field on
			// ics.gw_corporation_operation_code table
			inputMap.put(VodafoneDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);
			
			inputMap.put(VodafoneDebtInqueryServices.Input.SUB_COMPANY_ID, subCorporationId);


			// logger.info("ICS_VF_INVOICE_DEBT_INQUIRY will get GW_CON connection...");
			// logger.info("ICS_VF_INVOICE_DEBT_INQUIRY got GW_CON connection successfully...");
			logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST will call BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE with values -> ".concat(builder.toString()));
			// GMConnection gmConnection = GMConnection.getConnection("GW_CON");
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",inputMap));
//			returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
			logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
			// check if an error is occured on GW
			
			//TODO-CEM 18 Martta Kapand�
//			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
//				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
//					responseCode = GATEWAY_ERROR;
//					logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
//					logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
//					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
//				} else {
//					responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
//					logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE)));
//				}
//			} else {
//				responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
//				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE)));
//			}
			BillResponse debtInqueryResponse = null;
			
			try{
			
				//TODO 
				//										  String url, String billingPeriod, Integer companyId, String correlationId, Integer currency, CustomerInfo customerInfo, String description, Integer inquiryCount, Integer institutionId, String ipAddress, Integer city, String branch, String teller, String user, Integer stan, Date transactionDate, String transactionId, ServiceMessage serviceMessage
				debtInqueryResponse = VodafoneClient.debtInquery(url, billingPeriod, companyId, correlationId, currencyCode, customerInfo, description, inquiryCount, corporationId, ipAddress, cityCode, originatorIdBranchCode, originatorIdOfficeCode, originatorIdUserCode, stan, new Date(), transactionId, serviceMessage);
				responseCode = debtInqueryResponse.getResponseCode().toString();
				responseMessage = debtInqueryResponse.getResponseDesc();
			}catch (P3CashPointOpenItemFault f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_VF_INVOICE_DEBT_INQUIRY_REST ".concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = f.getFaultInfo().getStandard().getFaultDetail().get(0).getId();
				responseMessage = f.getFaultInfo().getStandard().getFaultDetail().get(0).getText();
				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST error code = ".concat(responseCode));
				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST error message = ".concat(responseMessage));
			}

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			// Gelen ResponseCode'u bizim ResponseCode'lar ile MAP leme i�lemi yap�l�yor.
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// no error go ahead.
				int i = 0;
				outMap.put(MapKeys.RESPONSE_CODE, debtInqueryResponse.getResponseCode());
				outMap.put(MapKeys.DESCRIPTION, debtInqueryResponse.getResponseDesc());
				outMap.put("BPPS_LEGACY_RESPONSE_CODE", debtInqueryResponse.getBppsLegacyResponseCode());
				outMap.put(MapKeys.TRX_NO, debtInqueryResponse.getTransactionId());
				outMap.put("CORRELATION_ID", debtInqueryResponse.getCorrelationId());
				outMap.put("RESPONSE_DESC", debtInqueryResponse.getResponseDesc());
				
				Integer billNumber  = 0;
				for (BillList billListItem : debtInqueryResponse.getBillList()) {
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, billListItem.getCustomerCode());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, billListItem.getMsisdn());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, billListItem.getNameSurname());

					SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
					SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
					Date date2 = inputFormat.parse(billListItem.getDueDate());
					// System.out.println(formattedDate); // prints 10-04-2018

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date2);

					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, billListItem.getBillNumber());
					// oMap.put(MapKeys.INVOICE_LIST, i, "PERIOD", debtListItem.getDonem());

					// oMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, debtListItem.getDonem().substring(5,7));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, billListItem.getPeriod().substring(0, 4));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, billListItem.getPeriod().substring(5, 7));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, calendar.getTime());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, billListItem.getAmount());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_AMOUNT, billListItem.getAmount());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, billListItem.getInstallmentNumber());
					outMap.put(MapKeys.INVOICE_LIST, i, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, i, "OID", "0");
					
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_AMOUNT).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_CUSTOMER_ACCESS_TYPE).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_CUSTOMER_NO).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_EXPIRY_DATE).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_NAME_SURNAME).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_NO).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_PHONE_NO).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_REF_NO).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_SEQ_NO).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_TERM).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.BILL_INFO, billNumber, VodafoneDebtInqueryServices.Output.BillInfo.BILL_INFO_TYPE).toString());
					billInfoBuilder = billInfoBuilder.concat(":");
					billInfoBuilder = billInfoBuilder.concat(returnMap.getString(VodafoneDebtInqueryServices.Output.STAN).toString());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, billInfoBuilder.toString());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
					billNumber++;
					billInfoBuilder = "";
				}
				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST finished succesfully");
			} else {
				// an error occured
				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST an error accoured with error code : ".concat(errorCode));
				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST an error accoured with response code : ".concat(responseCode));
				logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST an error accoured returnMap : ".concat(returnMap.toString()));
				logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
			}
		} catch (Throwable e2) {
			logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST an error accoured with response code : ".concat(responseCode));
			logger.info("ICS_VF_INVOICE_DEBT_INQUIRY_REST an error accoured returnMap : ".concat(returnMap.toString()));
			logger.error("ICS_VF_INVOICE_DEBT_INQUIRY_REST -> an error is occured...".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e2);
		} finally {
			outMap.put("CALL_VALUES", builder.toString().concat(returnMap.toString()));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_VF_DO_INVOICE_COLLECTION_REST")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_DO_INVOICE_COLLECTION_REST");
		ServiceMessage serviceMessage = new ServiceMessage();
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String errorMessage = "";
		String gatewayErrorDesc = "";
		String responseCode = "";
		String responseMessage = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
		String errorCode = "";
		try {
			if (isStandingOrderCollection) {
				logger.info("ICS_VF_DO_INVOICE_COLLECTION_REST is called for standing order collection...");
			} else {
				logger.info("ICS_VF_DO_INVOICE_COLLECTION_REST is called for regular collection...");
			}
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer contractNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String deptCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String refNo = iMap.getString(MapKeys.TRX_NO);
			Integer subscriberNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			Date collectionDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				collectionDate = CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss");
			}
			
			
			CommitPaymentResponse paymentResponse = new CommitPaymentResponse();
//			paymentResponse = VodafoneClient.doInvoiceCollection(serviceUrl, city, branch, teller, user, inquiryStan, billNumber, msisdn, customerCode, nameSurname, type, period, dueDate, referenceNumber, orderNumber, installmentNumber, billCurrency, amount, originatorSerialNumber, acceptanceDate, companyId, correlationId, currency, description, institutionId, ipAddress, operationSource, stan, transactionDate, transactionId, serviceMessage)
//
//			paymentResponse = VodafoneClient.doInvoiceCollection(serviceUrl, bankCode, deptCode, companyCode, username, password, invoiceNo, subscriberNo, contractNo, collectionDate, refNo, serviceMessage);
//			responseCode = paymentResponse.getResponseCode();
			responseMessage = paymentResponse.getResponseDesc();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
//				invoicePayment.setParameter2(paymentResponse.getIslemReferansNo().toString());
				session.saveOrUpdate(invoicePayment);

			}
		}
		catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
			
		
		return outMap;
		
	}

	@GraymoundService("ICS_VF_INSERT_CANCEL_RECORD_REST")
	public static GMMap insertCancelRecord(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST");
		GMMap outMap = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			invoicePayment payment = new invoicePayment();
			payment.setStatus(true);
			payment.setCorporateCode(iMap.getString(MapKeys.CORPORATE_CODE));
			payment.setCollectionType(Short.valueOf("0"));
			payment.setInvoiceMainOid("0");
			payment.setSubscriberNo1(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			payment.setPaymentStatus(PaymentStatuses.Cancelled);
			payment.setTxNo(new BigDecimal("-1"));
			payment.setInvoiceAmount(new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			payment.setPaymentAmount(new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			payment.setPaymentDate(iMap.getString(MapKeys.PAYMENT_DATE).concat("120000"));
			payment.setCancelDate(iMap.getString(MapKeys.PAYMENT_DATE).concat("120000"));
			session.saveOrUpdate(payment);
			session.flush();
			outMap.put("RESULT", "OK");
		} catch (Exception e) {
			logger.info("ICS_VF_INSERT_CANCEL_RECORD -> AVEA iptal kaydi olustururken hata meydana geldi..");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;
	}

	@GraymoundService("ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST");
		String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String gatewayErrorDesc = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";
		String responseMessage = "";
		ServiceMessage serviceMessage = new ServiceMessage();

		try {
			logger.info("ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST is called...");
			// set parameters
			String operationSource = "0";
			String originatorIdCityCode = CITY_CODE;
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String originatorIdUserCode = USER_CODE;
			int currencyCode = CURRENCY_CODE;
			String sunCustomerAccessType = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String paymentPeriod = iMap.getString(MapKeys.PARAMETER16);
			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 2
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 7
			
			Integer bankCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String processRefNo = iMap.getString(MapKeys.TRX_NO);
			BigDecimal refNo = new BigDecimal(processRefNo);
			
			String subCorporationId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			ReversePaymentResponse collectionCancelResponse = new ReversePaymentResponse();
			//TODO
			//String url, int city, String branch, String teller, String user, int inquiryStan, String billNumber, String msisdn, String customerCode, String nameSurname, String type, String period, String dueDate, String referenceNumber, int orderNumber, int installmentNumber, int billCurrency, double amount, String originatorSerialNumber, String transactionId, Date transactionDate, int companyId, int institutionId, int stan, String correlationId, String ipAddress, int currency, String description, String acceptanceDate, int operationSource, ServiceMessage serviceMessage
			//collectionCancelResponse = VodafoneClient.sendCollectionCancelMessage(serviceUrl, 34, companyCode, username, originatorIdUserCode, refNo, serviceMessage);
			responseCode = collectionCancelResponse.getResponseCode();
			responseMessage = collectionCancelResponse.getResponseDesc();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
			
		} catch (Exception e) {
			logger.info("ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST an error accoured with response code : ".concat(responseCode));
			logger.error("ICS_VF_SEND_COLLECTION_CANCEL_MESSAGE_REST -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e);
		} finally {
			outMap.put("CALL_VALUES", builder.toString().concat(returnMap.toString()));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_VODAFONE_CLOSE_COLLECTION_RECONCILIATION_MANUALLY_REST")
	public static GMMap closeCollectionReconciliationManually(GMMap iMap) {
		GMMap output = new GMMap();
		String reconLogOid = null;
		String reconDate = iMap.getString("RECON_DATE");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {

			String operationSource = "0";
			String originatorIdCityCode = CITY_CODE;// 34
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);// 104
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);// 12
			String originatorIdUserCode = USER_CODE;// CS1002;
			int currencyCode = CURRENCY_CODE;
			String reconInfoTransCode = "11";
			String reconInfoTransState = "0";
			String reconInfoCancelTransCode = "21";
			String responseCode = "";
			String gatewayErrorDesc = "";

			int corporateCount = 0;
			BigDecimal corporateAmount = new BigDecimal(0);
			int corporateCancelCount = 0;
			BigDecimal corporateCancelAmount = new BigDecimal(0);

			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 2
			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 11
			
			String subCorporationId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);


			reconLogOid = CommonBusinessOperations.insertReconLog(corporateCode, reconDate, CommonHelper.getStringTimeNow(), ReconciliationResubmitType.ReconciliationClose);

			GMMap inputMap = new GMMap();

			inputMap.put(VodafoneDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, VodafoneDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(VodafoneDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, VodafoneDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(VodafoneDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, VodafoneDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(VodafoneDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, VodafoneDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44
			inputMap.put(VodafoneReconService.Input.SETTLEMENT_CURRENCY_CODE, currencyCode);// P-50

			inputMap.put(VodafoneReconService.Input.RECON_INFO, 0, VodafoneReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoTransCode);// P-56
			inputMap.put(VodafoneReconService.Input.RECON_INFO, 0, VodafoneReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, 0);// P-56
			inputMap.put(VodafoneReconService.Input.RECON_INFO, 0, VodafoneReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, "000");// P-56
			inputMap.put(VodafoneReconService.Input.RECON_INFO, 0, VodafoneReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);// P-56
			inputMap.put(VodafoneCommonServices.Input.RECON_OPERATION_COUNT, "1");

			inputMap.put(VodafoneDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25

			inputMap.put(VodafoneDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, reconDate);// P-58
			inputMap.put(VodafoneDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			inputMap.put(VodafoneDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);
			
			inputMap.put(VodafoneDebtInqueryServices.Input.SUB_COMPANY_ID, subCorporationId);


			GMMap returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);

			int operationCount = returnMap.getInt("RECON_OPERATION_COUNT");

			if (returnMap.containsKey(VodafoneDebtInqueryServices.Output.RESPONSE_CODE)) {
				for (int i = 0; i < operationCount; i++) {
					if (returnMap.getString("RECON_INFO", i, "RECON_INFO_TRANS_CODE").equals("011")) {
						corporateCount = Integer.parseInt(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS"));
						corporateAmount = new BigDecimal(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(0, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2).concat(".")
								.concat(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length())));
					}
					if (returnMap.getString("RECON_INFO", i, "RECON_INFO_TRANS_CODE").equals("021")) {
						corporateCancelCount = Integer.parseInt(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS"));
						corporateCancelAmount = new BigDecimal(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(0, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2).concat(".")
								.concat(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").substring(returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length() - 2, returnMap.getString("RECON_INFO", i, "RECON_INFO_TOTAL_TRANS_AMOUNT").length())));
					}
				}

			}
			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					responseCode = GATEWAY_ERROR;
					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
				} else {
					responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
				}
			} else {
				responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
			}

			if (!responseCode.equals(GATEWAY_ERROR)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				String sCorporateAmount = corporateAmount.toString();
				if (sCorporateAmount.indexOf(".") > -1) {
					if (sCorporateAmount.length() - sCorporateAmount.indexOf(".") < 3) {
						sCorporateAmount = sCorporateAmount.concat("0");
					}
				} else {
					sCorporateAmount = sCorporateAmount.concat("00");
				}
				sCorporateAmount = sCorporateAmount.replace(",", "");
				sCorporateAmount = sCorporateAmount.replace(".", "");

				inputMap.put(VodafoneReconService.Input.RECON_INFO, 0, VodafoneReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, corporateCount);// P-56
				inputMap.put(VodafoneReconService.Input.RECON_INFO, 0, VodafoneReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, sCorporateAmount);// P-56

				if (corporateCancelCount > 0) {
					String sReconInfoTotalCancelTransAmount = corporateCancelAmount.toString();

					if (sReconInfoTotalCancelTransAmount.indexOf(".") > -1) {
						if (sReconInfoTotalCancelTransAmount.length() - sReconInfoTotalCancelTransAmount.indexOf(".") < 3) {
							sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.concat("0");
						}
					} else {
						sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.concat("00");
					}
					sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.replace(",", "");
					sReconInfoTotalCancelTransAmount = sReconInfoTotalCancelTransAmount.replace(".", "");

					inputMap.put(VodafoneReconService.Input.RECON_INFO, 1, VodafoneReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoCancelTransCode);
					inputMap.put(VodafoneReconService.Input.RECON_INFO, 1, VodafoneReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, corporateCancelCount);
					inputMap.put(VodafoneReconService.Input.RECON_INFO, 1, VodafoneReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, sReconInfoTotalCancelTransAmount);
					inputMap.put(VodafoneReconService.Input.RECON_INFO, 1, VodafoneReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);

					inputMap.put(VodafoneCommonServices.Input.RECON_OPERATION_COUNT, "2");
				}

				returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);

				if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
					if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
						responseCode = GATEWAY_ERROR;
						gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
					} else {
						responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
					}
				} else {
					responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
				}

				if (!responseCode.equals(GATEWAY_ERROR)) {
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ClosedManually, corporateAmount.subtract(corporateCancelAmount), corporateCancelAmount, corporateAmount.subtract(corporateCancelAmount), corporateCancelAmount, new Date(), reconDate, corporateCode, corporateCount - corporateCancelCount, corporateCancelCount, corporateCount - corporateCancelCount,
								corporateCancelCount, ReconciliationResubmitType.ReconciliationClose, null, null);
					} else {
						CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, responseCode, responceCodeMap.getString(MapKeys.ERROR_DESC));
					}
				} else {
					CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, responseCode, gatewayErrorDesc);
				}
			} else {
				CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, responseCode, gatewayErrorDesc);
			}
		} catch (Exception e) {
			try {
				CommonBusinessOperations.updateReconLog(reconLogOid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, "-1", "Sistem hatas� : ".concat(e.getMessage()));
			} catch (Exception e1) {
				logger.error("An exception occured while updating recon log");
				logger.error(System.currentTimeMillis(), e);
			}
			throw ExceptionHandler.convertException(e);
		}

		return output;
	}

	@GraymoundService("ICS_VF_COLLECTION_RECONCILIATION_REST")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_COLLECTION_RECONCILIATION_REST");
		Session session = CommonHelper.getHibernateSession();
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		StringBuilder builder = new StringBuilder();
		String gatewayErrorDesc = "";
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";
		String reconInfoTransCode = "11";
		String reconInfoCancelTransCode = "21";
		int reconInfoTotalTrans = 0;
		BigDecimal reconInfoTotalTransAmount = new BigDecimal("0");
		String reconInfoTransState = "0";
		//String reconDate = iMap.getString(MapKeys.RECON_DATE);
		int corporateCount = 0;
		BigDecimal corporateAmount = new BigDecimal(0);
		int corporateCancelCount = 0;
		BigDecimal corporateCancelAmount = new BigDecimal(0);
		int operationCount = 0;
		try {

			Date reconDate = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate = iMap.getDate(MapKeys.RECON_DATE);

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";

			corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			BigDecimal cancelCount = new BigDecimal(reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			ReconciliationResponse reconciliationResponse = new ReconciliationResponse();
			//TODO
			//reconciliationResponse = VodafoneClient.collectionReconciliation(serviceUrl, bankCode, companyCode, username, password, reconDate, new BigDecimal(collectionCount), collectionTotal, cancelCount, cancelTotal, serviceMessage);
			responseCode = reconciliationResponse.getResponseCode();
			responseMessage = reconciliationResponse.getResponseDesc();

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// RETURNS
				// Date tahsilatTarihi;
				// BigDecimal tahsilatAdeti;
				// BigDecimal tahsilTutari;
				// BigDecimal iptalAdeti;
				// BigDecimal iptalTutari;
				// oMap.put(MapKeys.AMOUNT, agreementGeneralResponse.getTahsilTutari());
				//TODO
//				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconciliationResponse.getTahsilTutari());
//				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResponse.getTahsilatAdeti());
//				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconciliationResponse.getIptalTutari());
//				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationResponse.getIptalAdeti());
				
				if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL))) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).add(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT))) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0){
					
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}

			}


		}catch (Throwable e) {
			logger.info("ICS_VF_COLLECTION_RECONCILIATION - mutabakat hatali ");
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;

	}

	@GraymoundService("ICS_VF_GET_COLLECTION_RECONCILIATION_DETAIL_REST")
	public static GMMap collectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_GET_COLLECTION_RECONCILIATION_DETAIL_REST");
		GMMap outMap = new GMMap();

		try {
			logger.info("ICS_VF_GET_COLLECTION_RECONCILIATION_DETAIL_REST is called");
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("ICS_VF_GET_COLLECTION_RECONCILIATION_DETAIL finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST")
	public static GMMap detailFTMFileContent(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_DETAIL_FTM_FILE_CONTENT");
		GMMap outMap = new GMMap();

		try {

			String fileDefId = iMap.getString("FILE_DEF_ID");
			// fileDefId = "440";
			logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> fileDefId=" + fileDefId);
			String corporateCode = CommonHelper.getValueOfParameter("CDM_FILE_DEF_CORPORATE_CODE_MAPPING", fileDefId);
			logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> corporate code=" + corporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCode);

			Session session = CommonHelper.getHibernateSession();
			Criteria criteriaReconLog = session.createCriteria(ReconLog.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime"));
			Calendar reconDate = Calendar.getInstance();

			BigDecimal ftmProcessOID = iMap.getBigDecimal("PROCESS_ID");
			// ftmProcessOID = new BigDecimal("1527");
			logger.info("PROCESS_ID is " + ftmProcessOID);
			if (ftmProcessOID == null) {
				logger.error("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> Error getting GW_CON Process OID from iMap");
				return outMap;
			}

			Criteria criteria = session.createCriteria(FtmProcess.class).add(Restrictions.eq("oid", ftmProcessOID));
			FtmProcess ftmProcess = (FtmProcess) criteria.uniqueResult();
			String reconDateStr = "";
			if (ftmProcess != null && ftmProcess.getFileName() != null) {
				String fileName = ftmProcess.getFileName();
				reconDateStr = fileName.substring(5, 13);
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> fileName is " + fileName + "reconDateStr is " + reconDateStr);
			}
			iMap.put(MapKeys.RECON_DATE, reconDateStr);
			reconDate.setTime(CommonHelper.getDateTime(reconDateStr.concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			List<ReconLog> reconLogList = criteriaReconLog.list();
			ReconLog reconLog = null;
			String reconLogOid = "";
			if (reconLogList != null && reconLogList.size() != 0) {
				reconLog = reconLogList.get(0);
				reconLogOid = reconLog.getOid();
			}

			try {
				String query = "ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> update ics.recon_detail_data set status=0 where recon_log_oid='".concat(reconLogOid).concat("'");
				CommonHelper.executeQuery(query);
			} catch (Exception e) {
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> recon_detail_data update edilirken hata meydana geldi...");
			}

			Criteria criteriaFtmContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ftmProcessOID));
			@SuppressWarnings("unchecked")
			List<FtmFileContent> ftmFileContentList = criteriaFtmContentList.list();
			logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> ftmFileContentList size is " + ftmFileContentList.size());
			int ftmFileContentListOrder = 0;
			GMMap reconCorpAmountMap = new GMMap();
			Session sessionForInsert = CommonHelper.getHibernateSession();
			for (FtmFileContent ftmFileContent : ftmFileContentList) {
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> ftmFileContent line is " + ftmFileContent.getLine());
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> reconLog is " + reconLog);
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> reconLog.getDate is " + reconLog.getReconDate());
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> reconLog.getTime is " + reconLog.getReconTime());
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> corporateCode is " + corporateCode);
				logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> reconLogOid is " + reconLogOid);
				String fileString = ftmFileContent.getLine();
				String transactionType = "";
				String paymentAmount = fileString.substring(96, 114);
				paymentAmount = paymentAmount.substring(0, paymentAmount.length() - 2).concat(".").concat(paymentAmount.substring(paymentAmount.length() - 2, paymentAmount.length()));

				if ("D".equals(fileString.substring(0, 1))) {
					ReconDetailData rdd = new ReconDetailData();
					rdd.setCorporateCode(corporateCode);
					rdd.setSubscriberNo1(fileString.substring(30, 40));
					rdd.setSubscriberNo2(fileString.substring(40, 70));
					rdd.setCollectionType((short) 0);
					rdd.setInvoiceNo(fileString.substring(76, 92));

					rdd.setPaymentAmount(new BigDecimal(paymentAmount));
					if ("11".equals(fileString.substring(12, 14))) {
						transactionType = "T";
					} else {
						transactionType = "I";
					}
					rdd.setTransactionType(transactionType);
					rdd.setStatus(true);
					rdd.setParameter1(fileString.substring(0, 1));
					rdd.setParameter2(fileString.substring(1, 9));
					rdd.setParameter3(fileString.substring(9, 10));
					rdd.setParameter4(fileString.substring(10, 12));
					rdd.setParameter5(fileString.substring(12, 14));
					rdd.setParameter6(fileString.substring(14, 22));
					rdd.setParameter7(fileString.substring(22, 30));
					rdd.setParameter8(fileString.substring(70, 76));
					rdd.setParameter9(fileString);
					rdd.setReconLogOid(reconLogOid);
					rdd.setReconDate(reconLog.getReconDate());
					rdd.setReconTime(reconLog.getReconTime());
					sessionForInsert.saveOrUpdate(rdd);
				}

				ftmFileContentListOrder++;
			}
			sessionForInsert.flush();

			logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> detail logs are inserted temp table successfully...");
			iMap.put("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> RECON_LOG_OID", reconLogOid);
			// CollectionReconciliationDetailBatch batch = new
			// VodafoneCollectionReconciliationDetailBatch(iMap);
			// GMMap output = batch.runBatch();
			// logger.info("...ICS_VF_DETAIL_FTM_FILE_CONTENT called batch...");
			// outMap.put(MapKeys.RECON_STATUS,
			// ReconciliationStatus.ReconciliationSucceeded);

			List<Object> parameters = new ArrayList<Object>();
			String strSQL = "";
			// strSQL =
			// "select * from (select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > "
			// +
			// "iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2,tahsilat.parameter9 "
			// +
			// "from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
			// +
			// "sayacTahsilat,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type "
			// + "is not null and status = 1 and corporate_code = '"
			// + corporateCode
			// + "' and "
			// + "recon_log_oid = '"
			// + reconLogOid
			// +
			// "' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
			// +
			// "subscriber_no1,subscriber_no2,parameter9 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
			// +
			// "sayacIptal,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data "
			// +
			// "where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '"
			// + corporateCode
			// + "' "
			// + "and recon_log_oid = '"
			// + reconLogOid
			// + "' and transaction_type = 'I' "
			// +
			// "group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2,parameter9 "
			// + "order by invoice_no, transaction_type desc) iptal "
			// + "where tahsilat.invoice_no = iptal.invoice_no union "
			// +
			// "select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
			// + "subscriber_no2,parameter9 from ics.recon_detail_data "
			// +
			// "where collection_type='0' and transaction_type = 'T' and status = 1 and corporate_code = '"
			// + corporateCode
			// + "' and "
			// + "recon_log_oid = '" + reconLogOid + "' and invoice_no not in "
			// + "(select invoice_no from ics.recon_detail_data " +
			// "where collection_type='0' and transaction_type = 'I' and status = 1 and corporate_code = '"
			// + corporateCode + "' and recon_log_oid = '" + reconLogOid +
			// "')) where payment_status='T'";// +
			// // "order by payment_status desc; ";
			strSQL = String.format(QueryRepository.VodafoneServicesRepository.GET_FTM_FILE_CONTENT, corporateCode, reconLogOid, corporateCode, reconLogOid, corporateCode, reconLogOid, corporateCode, reconLogOid);
			logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> ".concat(strSQL));
			String TABLE_NAME = "RECON_DETAIL_DATA";

			GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);

			int faturaTahsilatAdedi = reconLogList.get(0).getBankCount().intValue();
			int faturaTahsilatIptalAdedi = reconLogList.get(0).getBankCancelCount().intValue();

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);

			boolean found = true;

			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			String bankCode;
			for (int i = 0; i < faturaTahsilatAdedi; i++) {
				for (int j = 0; j < al.size(); j++) {
					if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO).equals(returnMap.getString(TABLE_NAME, j, MapKeys.INVOICE_NO))
							&& reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
						found = true;// bizdeki tahsilat kaydi kurumda
										// da bulundu
						break;
					} else {
						found = false;// bizdeki tahsilat kaydi kurumda
										// bulunamadi
					}
				}
				if (!found) {
					// bizdeki tahsilat kurumda bulunamadi ise
					// kuruma tahsilat mesaji gondericem
					logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> bizdeki tahsilat kurumda bulunamadi, kuruma tahsilat mesaji gondericem...");
					GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, reconBankMap.getString("BANK", i, MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", i, MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, reconBankMap.getString("BANK", i, MapKeys.PARAMETER20));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, reconBankMap.getString("BANK", i, MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, reconBankMap.getString("BANK", i, MapKeys.PARAMETER5));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, reconBankMap.getString("BANK", i, MapKeys.PARAMETER6));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER7, reconBankMap.getString("BANK", i, MapKeys.PARAMETER7));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER8, reconBankMap.getString("BANK", i, MapKeys.PARAMETER8));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER9, reconBankMap.getString("BANK", i, MapKeys.PARAMETER9));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER10, reconBankMap.getString("BANK", i, MapKeys.PARAMETER10));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER11, reconBankMap.getString("BANK", i, MapKeys.PARAMETER11));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER12, reconBankMap.getString("BANK", i, MapKeys.PARAMETER12));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER13, reconBankMap.getString("BANK", i, MapKeys.PARAMETER13));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER14, reconBankMap.getString("BANK", i, MapKeys.PARAMETER14));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER15, reconBankMap.getString("BANK", i, MapKeys.PARAMETER15));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER16, reconBankMap.getString("BANK", i, MapKeys.PARAMETER16));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER17, reconBankMap.getString("BANK", i, MapKeys.PARAMETER17));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER18, reconBankMap.getString("BANK", i, MapKeys.PARAMETER18));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER19, reconBankMap.getString("BANK", i, MapKeys.PARAMETER19));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER20, reconBankMap.getString("BANK", i, MapKeys.PARAMETER20));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_BRANCH));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", i, "SUBSCRIBER_NO2"));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("BANK", i, MapKeys.TERM_YEAR));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", i, MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.REC_DATE, reconBankMap.getString("BANK", i, MapKeys.REC_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_SOURCE));
					onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("BANK", i, MapKeys.BRANCH_CODE));
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> tahsilat mesaji gonderilecek...");
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi");
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> tahsilat mesaji kuruma basarili olarak gonderildi...");
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> SUBSCRIBER NO 1: ".concat(reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1)));
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> INVOICE NO : ".concat(reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO)));
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> PAYMENT AMOUNT : ".concat(reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT)));

					} catch (Exception e) {
						// TODO Tahsilatta hata al�nca
						// yakal�yoruz
						// yola
						// devam ediyoruz
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> tahsilat mesaji hata aldi..".concat(e.getMessage()));
						logger.error("An exception occured while executing ICS_VF_DETAIL_FTM_FILE_CONTENT -> on Reconciliation services");
						logger.error(System.currentTimeMillis(), e);
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
					}

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));

					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString("BANK", i, MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString("BANK", i, MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString("BANK", i, MapKeys.PAYMENT_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString("BANK", i, MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString("BANK", i, MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString("BANK", i, MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString("BANK", i, MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString("BANK", i, MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString("BANK", i, MapKeys.PARAMETER4));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					logger.info("ICS_VF_GET_COLLECTION_RECONCILIATION_DETAIL_REST log is inserted...");
				}

			}
			found = false;
			for (int i = 0; i < faturaTahsilatIptalAdedi; i++) {
				for (int j = 0; j < al.size(); j++) {
					if ("T".equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_STATUS)) && reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1).equals(returnMap.getString(TABLE_NAME, j, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO).equals(returnMap.getString(TABLE_NAME, j, MapKeys.INVOICE_NO))
							&& reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT).equals(returnMap.getString(TABLE_NAME, j, MapKeys.PAYMENT_AMOUNT))) {
						found = true;// bizdeki tahsilat iptal kaydi
										// kurumda tahsilat kaydi olarak
										// var
						break;
					} else {
						found = false;// bizdeki tahsilat iptal kaydi
										// kurumda da var o zaman sorun
										// yok
					}
				}
				if (found) {
					// bizdeki tahsilat iptal kaydi kurumun
					// tahsilatlari arasinda
					// o zaman tahsilat iptal gonderelim
					logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> bizdeki tahsilat iptal kaydi kurumun tahsilatlari arasinda...tahsilat iptal mesaji gonderilecek...");
					GMMap rcInput = new GMMap();
					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_3, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER3));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_4, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER4));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_5, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER5));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_6, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER6));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_7, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER7));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_8, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER8));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_9, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER9));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_10, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER10));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_11, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER11));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_12, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER12));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_13, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER13));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_14, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER14));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_15, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER15));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_16, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER16));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_17, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER17));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_18, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER18));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_19, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER19));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_20, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER20));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_BRANCH, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, reconBankMap.getString("BANK_CANCEL", i, MapKeys.TERM_YEAR));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_PARAMETER4, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, 0);
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, reconBankMap.getString("BANK_CANCEL", i, MapKeys.BRANCH_CODE));
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST ->  tahsilat iptal servisi cagirilmadan once");
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> tahsilat iptal servisi cagirildiktan sonra...");
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, " Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi");
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST ->  tahsilat iptal mesaji kuruma basarili olarak gonderildi...");
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST ->  SUBSCRIBER NO 1: ".concat(reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1)));
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST ->  INVOICE NO : ".concat(reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO)));
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST ->  PAYMENT AMOUNT : ".concat(reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT)));
					} catch (Exception e) {
						// TODO Tahsilatta hata al�nca
						// yakal�yoruz
						// yola
						// devam ediyoruz
						logger.info("ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> tahsilat iptal servisi hata aldi".concat(e.getMessage()));
						logger.error("An exception occured while executing ICS_VF_DETAIL_FTM_FILE_CONTENT ->  on Reconciliation services");
						logger.error(System.currentTimeMillis(), e);
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
					}

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, 0);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconBankMap.getString("BANK_CANCEL", i, MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER2));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER3));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, reconBankMap.getString("BANK_CANCEL", i, MapKeys.PARAMETER4));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}

			}

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_VF_DETAIL_FTM_FILE_CONTENT_REST -> ".concat(ExceptionHandler.convertException(e2).toString()));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST");
		GMMap outMap = new GMMap();
		logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST is started...");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String toDayToCompare = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			GMMap sorMap = getBankStandingOrdersForVodafone(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST recon count to check is ".concat(Integer.toString(reconCollectionCount)));
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				String subscriberNumber = CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0');
				logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST debt inquery for ".concat(subscriberNumber).concat(" will be called.."));
				iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNumber);
				iMap.put(MapKeys.COLLECTION_TYPE, "0");
				iMap.put(MapKeys.COLLECTION_TYPE_NAME, "Fatura Odeme");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_VF_INVOICE_DEBT_INQUIRY", iMap);
				int billNumber = reconBankMap.getSize(MapKeys.INVOICE_LIST);
				logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST debt inquery for ".concat(subscriberNumber).concat(" is called and return map").concat(reconBankMap.toString()).concat(" and bill number is").concat(Integer.toString(billNumber)));
				if (billNumber > 0) {
					for (int z = 0; z < billNumber; z++) {
						logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST debt inquery for ".concat(subscriberNumber).concat(" compares date invoice date -> ").concat(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE).toString()).concat(" with todays date -> ").concat(toDayToCompare));
						if (toDayToCompare.equals(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE))) {
							logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST debt inquery for ".concat(subscriberNumber).concat(" returned result which matches due date with today..."));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static GMMap getBankStandingOrdersForVodafone(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST is called getBankStandingOrdersForVodafone...");
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.VodafoneServicesRepository.GET_BANK_STANDING_ORDERS, reconcilitionDate,reconcilitionDate,corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST found ".concat(Integer.toString(al.size())).concat(" standing order for VF"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			logger.info("ICS_VF_DEBT_INQUERY_FOR_STANDING_ORDER_REST found 0 standing order");
		}
		return returnMap;
	}

	@GraymoundService("STO_VF_SEND_STANDING_ORDER_MESSAGE_REST")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_VF_SEND_STANDING_ORDER_MESSAGE_REST");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String gsmNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_VF_SEND_STANDING_ORDER_MESSAGE_REST called for ".concat(corporateCode).concat(" - ").concat(" gsm no -> ").concat(gsmNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_VF_SEND_STANDING_ORDER_MESSAGE_REST -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_VF_SEND_STANDING_ORDER_CANCEL_MESSAGE_REST")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_VF_SEND_STANDING_ORDER_CANCEL_MESSAGE_REST");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE_REST for ".concat(corporateCode).concat(" - ").concat(" gsm no -> ").concat(aboneNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE_REST an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_VF_STANDING_ORDER_RECONCILIATION_REST")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_VF_STANDING_ORDER_RECONCILIATION_REST");
		GMMap outMap = new GMMap();
		GMMap stoMap = new GMMap();

		try {
			logger.info("STO_VF_STANDING_ORDER_RECONCILIATION_REST is called");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);

			stoMap = getBankStandingOrdersForVodafone(reconDate, corporateCode);

			int reconCollectionCount = stoMap.getInt(MapKeys.RECON_BANK_COUNT);

			outMap.put(MapKeys.RECON_CORPORATE_COUNT, reconCollectionCount);
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, "0");
			outMap.put(MapKeys.RECON_BANK_COUNT, reconCollectionCount);
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, "0");

			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("STO_VF_STANDING_ORDER_RECONCILIATION_REST finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_VF_COLLECTION_RECONCILIATION_CLOSED_REST")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VF_COLLECTION_RECONCILIATION_CLOSED_REST");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	public static boolean isCollectedInvoiceNoWithSubscriberNo(String invoiceNo, String subscriberNo1, String corporateCode) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("subscriberNo1", subscriberNo1)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static String getStanNo() throws Exception {
		String tableName = "ICS_VODAFONE_STAN";
		return CorporationServiceUtil.getSequenceCode(tableName);
	}
	
	@GraymoundService("ICS_VODAFONE_MANAGE_STAN")
	public static GMMap manageStan(GMMap input){
		GMMap output = new GMMap();
		
		try{
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='ICS_TURKCELL_STAN'");
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

}
