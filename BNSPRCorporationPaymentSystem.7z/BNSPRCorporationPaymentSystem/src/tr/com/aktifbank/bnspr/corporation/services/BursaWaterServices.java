package tr.com.aktifbank.bnspr.corporation.services;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.alfabim.abone.tahsilat.model.BakiyeVw;
import org.alfabim.abone.tahsilat.model.TalimatBakiye;
import org.alfabim.abone.tahsilat.model.TalimatListesi;
import org.alfabim.abone.tahsilat.model.WSTahsilat;
import org.alfabim.abone.webService.bean.WSAboneSicil;
import org.alfabim.abone.webService.bean.WsMakbuz;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.buski.BuskiClient;
import tr.com.aktifbank.integration.buski.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BursaWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(BursaWaterServices.class);
	public static String DELIMITER = "-";
	public static String COLLECTION_INFO_DELIMITER = "~";
	public static String RECON_DELIMITER = " ";
	public static String RECEIPT_DELIMITER1 = "-";
	public static String RECEIPT_DELIMITER2 = "/";
	public static String BRANCH_CODE = "555";
	public static String YIM_BRANCH_CODE = "999";
	public static String PAY_DESK = "1";
	public static BigDecimal SICIL_NO_CANCELLED_VALUE = new BigDecimal(0);
	public static BigDecimal SICIL_NO_SYSTEM_ERROR_VALUE= new BigDecimal(-1);
	public static String SICIL_NO_CANCELLED_ERROR_CODE = "899";
	public static String SICIL_NO_SYSTEM_ERROR_CODE="9999";

	@GraymoundService("ICS_BUSKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		BigDecimal sicilNo = BigDecimal.ZERO;
		String borcAlacak = "";
		String responseCode = "0";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		GMMap responceCodeMap = new GMMap();

		try {
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			sicilNo = getSicilno(aboneNo,iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo)==0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo)==0){		
				responseCode = SICIL_NO_SYSTEM_ERROR_CODE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}
			if(responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				ServiceMessage serviceMessage=new ServiceMessage();
				BakiyeVw[] bakiyeVwList = BuskiClient.getAboneOrSicilBorc(aboneNo, sicilNo, borcAlacak, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				if(bakiyeVwList!=null){
					int length = bakiyeVwList.length;
					for (int i = 0; i < length; i++) {
						BakiyeVw bakiyeVw = bakiyeVwList[i];
						responseCode = bakiyeVw.getThsAciklama();
						if (responseCode == null) {
							responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						}
						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							if(!isCollectedInvoice( bakiyeVw.getTahakkukNo(), bakiyeVw.getAboneNo().toString(),"","","", corporateCode)){
								String termYear = bakiyeVw.getDonem().toString().substring(0,4);
								String termMonth = bakiyeVw.getDonem().toString().substring(4);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bakiyeVw.getAboneNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, bakiyeVw.getSicilNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bakiyeVw.getTahakkukNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bakiyeVw.getGecikmeliToplam());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bakiyeVw.getTur());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, bakiyeVw.getSiraNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bakiyeVw.getAdiSoyadi());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, bakiyeVw.getVade().getTime());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bakiyeVw.getGecikmeliToplam());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}	
						}
					}
				}
			}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_BUSKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_DO_INVOICE_COLLECTION");
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			String aboneNoString = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1).toString();
			BigDecimal sicilNo = getSicilno(aboneNo, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			String sicilNoString = sicilNo.toString();
			String tahsilatTarihi;
			
			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo)==0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
			}else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo)==0){		
				responseCode = SICIL_NO_SYSTEM_ERROR_CODE;
			}
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))){
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"),"dd/MM/yyyy HH:mm:ss");
			}else{
				tahsilatTarihi = CommonHelper.getDateString(new Date(),"dd/MM/yyyy HH:mm:ss");
			}
			String agentCode = PAY_DESK;
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
				agentCode = iMap.getString(MapKeys.AGENT_CODE);
			}
			String channelCode = iMap.getString("CHANNEL_CODE", CommonHelper.getChannelId());

			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String gecikmeliToplam = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT).toString();
			String tur = iMap.getString(MapKeys.PARAMETER1);
			String siraNo = iMap.getString(MapKeys.INSTALLMENT_NO) != null ? iMap.getBigDecimal(MapKeys.INSTALLMENT_NO).toString() : "";
			String tahsilatInfo = String.format("%s~%s~%s~%s~%s~%s", aboneNoString, sicilNoString, tahakkukNo, gecikmeliToplam, tur, siraNo);
			String aciklama = "";
			String krediKartNo = "";// Varsa, kredi kart�n�n numaras�. Zorunlu
									// de�ildir. Bu alan numeric aland�r bo�
									// de�er g�nderilemez, null veya bir rakam
									// dizisi g�nderilmesi gerekiyor. yani
									// bo�luk karakteri g�nderilemez.
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String dekontNo = getBuskiDekont(iMap.getString(MapKeys.TRX_NO), channelCode, agentCode);
			if(!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")){
				ServiceMessage serviceMessage=new ServiceMessage();
				WSTahsilat[] tahsilatList = BuskiClient.tahsilatYap(tahsilatInfo, user, sifre, dekontNo, krediKartNo, aciklama,tahsilatTarihi, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				int tahsilatListLength = tahsilatList.length;
				for (int i = 0; i < tahsilatListLength; i++) {
					responseCode = tahsilatList[i].getAciklama();
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						outMap.put("TAHSILAT", i, "MAKBUZ_NO", tahsilatList[i].getMakbuzNo());
						outMap.put("TAHSILAT", i, "MAKBUZ_SERI", tahsilatList[i].getMakbuzSeri());
						Session session = DAOSession.getSession("BNSPRDal");

						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
								.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						invoicePayment.setParameter3(dekontNo);
						session.saveOrUpdate(invoicePayment);
					}
				}
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_BUSKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String aciklama = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahsilatIslemTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"),"dd/MM/yyyy");
			
			String dekontNo = iMap.getString("PARAMETER_3");
			if (dekontNo == null) {
				dekontNo = iMap.getString(MapKeys.PARAMETER3);
			}
//			String agentCode = PAY_DESK;
//			if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
//				agentCode = iMap.getString(MapKeys.AGENT_CODE);
//			}
//			String channelCode = iMap.getString("CHANNEL_CODE", CommonHelper.getChannelId());
//
//			String dekontNo = getBuskiDekont(iMap.getString(MapKeys.TRX_NO), channelCode, agentCode);
			
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			ServiceMessage serviceMessage=new ServiceMessage();
			String responseCode = BuskiClient.tahsilatIptal_dekontNo(dekontNo, aciklama, user, sifre, tahsilatIslemTarihi, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_BUSKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_BUSKI_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			BigDecimal sicilNo = getSicilno(aboneNo, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			String responseCode="";
			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo)==0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
			}else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo)==0){		
				responseCode = SICIL_NO_SYSTEM_ERROR_CODE;
			}else{
				ServiceMessage serviceMessage=new ServiceMessage();
				 responseCode = BuskiClient.bankaTalimatIstek(aboneNo, sicilNo, user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
					iMap.put("REQUEST_XML", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_BUSKI_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_BUSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_BUSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			BigDecimal sicilNo = getSicilno(aboneNo, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
			ServiceMessage serviceMessage=new ServiceMessage();
			String responseCode = BuskiClient.bankaTalimatIptal(aboneNo, sicilNo, user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_BUSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			ServiceMessage serviceMessage=new ServiceMessage();
			TalimatListesi[] talimatLists = BuskiClient.getSozlesmeMutabakatListesi(user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			int talimatListLenght = talimatLists.length;
			for (int i = 0; i < talimatListLenght; i++) {
				TalimatListesi talimatListesi = talimatLists[i];
				outMap.put(MapKeys.SUBSCRIBER_NO1, talimatListesi.getAbone_no());
				outMap.put(MapKeys.SUBSCRIBER_NAME, talimatListesi.getAdiSoyadi());
				outMap.put(MapKeys.PARAMETER2, talimatListesi.getSicil_no());// sicil no parametre2 de mi olcak gerek var m� varsa ba�ka key ile mi
				outMap.put(MapKeys.RESPONSE_CODE, talimatListesi.getAciklama());
				responseCode = talimatListesi.getAciklama();
			}

			// //3676
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			GMMap listMap = new GMMap();
			listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST");
			// 3676

			boolean found = false;
			if (bankStandingOrderList.size() > talimatListLenght) {
				short collectionType = 0;
				for (int j = 0; j < bankStandingOrderList.size(); j++) {
					for (int i = 0; i < talimatLists.length; i++) {
						if (bankStandingOrderList.get(j).getSubscriberNo1().equals(talimatLists[i].getAbone_no())) {
							collectionType = bankStandingOrderList.get(j).getCollectionType();
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
						} catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < talimatLists.length; j++) {
					for (int k = 0; k < bankStandingOrderList.size(); k++) {
						if (bankStandingOrderList.get(k).getSubscriberNo1().equals(talimatLists[j].getAbone_no())) {
							found = true;
							collectionType = bankStandingOrderList.get(k).getCollectionType();
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, talimatLists[j].getAbone_no());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
						} catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat Iptal Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,talimatLists[j].getAbone_no());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}

			// 3676
			if (responseCode == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_BUSKI_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String responseCode = "";
			ServiceMessage serviceMessage=new ServiceMessage();
			String reconciliationResult = BuskiClient.getSozlesmeMutabakatAdedi(user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			String[] splitedRecon = reconciliationResult.split(RECON_DELIMITER);
			String reconCount = splitedRecon[0];
			if (reconciliationResult != null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, reconCount);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, "0");
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

				GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);

				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST");
				outMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderList.size());
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
			} else {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_BUSKI_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_BUSKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String giseNo = "";// �ube Kodu-Gi�e No/ �eklinde olacak, e�er gi�e
								// no kullanm�yorsan�z �ube kodu-/ olarak
								// g�ndereceksiniz. veya hi�bir de�er olmayacak
								// bo�luk dahi olmayacak.
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			String responseCode="";
			ServiceMessage serviceMessage=new ServiceMessage();
			WsMakbuz[] makbuzList = BuskiClient.gunSonuDetayBanka(giseNo, tarih, user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			if(makbuzList == null){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode = makbuzList[0].getDekont();
				if (responseCode.contains(RECEIPT_DELIMITER2)) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				} 
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int makbuzlistLenght = 0;
			if (makbuzList != null) {
				makbuzlistLenght = makbuzList.length;
			

				WsMakbuz makbuz = new WsMakbuz();
				for (int i = 0; i < makbuzlistLenght; i++) {
					makbuz = makbuzList[i];
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, makbuz.getAboneNo());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.TRX_NO, getAktifDekont(makbuz.getDekont()));
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.PARAMETER2, makbuz.getSeriNo());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, makbuz.getToplam());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.INVOICE_NO, makbuz.getTahakkukNo());
	
	
					// hibenate ile kay�t etmece
				}
			}
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = makbuzlistLenght;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;
			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(
								reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))
								&& reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
								&& reconBankMap.getString("BANK", j, MapKeys.PARAMETER2).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PARAMETER2))
								&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
					
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(
								reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(
										reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2).equals(
										reconBankMap.getString("BANK", k, MapKeys.PARAMETER2))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(
										reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);																										
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);

					}
				}
			}
		
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_GET_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_BUSKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			GMMap responceCodeMap = new GMMap();
			ServiceMessage serviceMessage=new ServiceMessage();
			String reconciliationResult = BuskiClient.getMutabakatToplamAdetTutarBanka("", tarih, user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (reconciliationResult != null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// tahsilat toplam�-tahsilat adeti- iptal toplam�- iptal adeti
				// tahsilat toplam� ve tahsilat adeti de�erlerinde iptal toplam
				// ve adetleri ��kart�lm�� halidir.yani kalan (yek�n)
				String[] splitedReconciliationResult = reconciliationResult.split(COLLECTION_INFO_DELIMITER);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, splitedReconciliationResult[0]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, splitedReconciliationResult[1]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, splitedReconciliationResult[2]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, splitedReconciliationResult[3]);

			}
			
			String toplam = "0";
			String makbuzAdet = "0";
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			toplam = reconBankMap.getString(MapKeys.RECON_COLLECTION_TOTAL);
			makbuzAdet = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			responseCode = BuskiClient.mutbakatIstekBanka(tarih, makbuzAdet, toplam, user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML_CLOSE", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_CLOSE", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;

	}

	@GraymoundService("ICS_BUSKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			// String tarih = iMap.getString(MapKeys.RECON_DATE_BEGIN);
			ServiceMessage serviceMessage=new ServiceMessage();
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");

			String reconciliationResult = BuskiClient.getMutabakatToplamAdetTutarBanka("", tarih, user, sifre, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (reconciliationResult != null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// tahsilat toplam�-tahsilat adeti- iptal toplam�- iptal adeti
				// tahsilat toplam� ve tahsilat adeti de�erlerinde iptal toplam
				// ve adetleri ��kart�lm�� halidir.yani kalan (yek�n)
				String[] splitedReconciliationResult = reconciliationResult.split(COLLECTION_INFO_DELIMITER);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, splitedReconciliationResult[0]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, splitedReconciliationResult[1]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, splitedReconciliationResult[2]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, splitedReconciliationResult[3]);

			}

			// /invoice payment dan corporate payment_amount count payment
			// status t I ayr�m� yap
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(
					outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_BUSKI_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_BUSKI_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER));
			String borcAlacak = "B";
			ServiceMessage serviceMessage=new ServiceMessage();
			TalimatBakiye[] talimatBakiyeList = BuskiClient.getAboneOrSicilBorcTalimat2(user, borcAlacak, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (talimatBakiyeList != null) {
				int talimatBakiyeLenght = talimatBakiyeList.length;
				outMap.put(MapKeys.TABLE_SIZE, talimatBakiyeLenght);
				for (int i = 0; i < talimatBakiyeLenght; i++) {
					TalimatBakiye talimatBakiye = talimatBakiyeList[i];
					String invoiceDueDate = CommonHelper.getShortDateTimeString(CommonHelper.getDateTime(talimatBakiye.getAciklama(), "dd/MM/yyyy"));
					if (invoiceDueDate != null) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						String tahsilatInfo = talimatBakiye.getTahsilatinfo();
						String[] splitedTahsilatInfo = tahsilatInfo.split(COLLECTION_INFO_DELIMITER);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTahsilatInfo[0]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2, splitedTahsilatInfo[1]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTahsilatInfo[2]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTahsilatInfo[3]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, splitedTahsilatInfo[4]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, splitedTahsilatInfo[5]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
					}
				}
			}
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_BUSKI_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	public static BigDecimal getSicilno(BigDecimal subscribeNo, String wsUrl, String wsUserName, String wsPassword) {
		BigDecimal sicilNo = new BigDecimal(0);
		ServiceMessage serviceMessage=new ServiceMessage();
		try {
			WSAboneSicil[] wsAboneSicils = BuskiClient.aboneSicilleri(subscribeNo, wsUrl, wsUserName, wsPassword,serviceMessage);
			if(wsAboneSicils!=null){
				int s = wsAboneSicils.length;

				for (int i = 0; i < s; i++) {

					if (wsAboneSicils[i].getFesihTarihi() == null || wsAboneSicils[i].getFesihTarihi().toString().isEmpty()) {
						sicilNo = wsAboneSicils[i].getSicilNo();
						break;
					}else{
						sicilNo= new BigDecimal(-1);
					}
				}
			}else{
				sicilNo= new BigDecimal(-1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sicilNo;
	}

	public static boolean isResponseCodeApprove(GMMap inMap) {
		if (!(inMap.getString("RETURN_CODE").equals("0"))) {
			return false;
		} else {
			return true;
		}

	}

	public static String getBuskiDekont(String dekont, String channel, String agentCode) {
		String buskiDekont = "";
		if (GeneralConstants.YIM_CHANNEL_CODE.equals(channel)) {
			buskiDekont =  YIM_BRANCH_CODE + RECEIPT_DELIMITER1 +  agentCode + RECEIPT_DELIMITER2 + dekont;			
		} else {
			buskiDekont =	BRANCH_CODE + RECEIPT_DELIMITER1 +  agentCode + RECEIPT_DELIMITER2 + dekont;
		}
		return buskiDekont;
	}

	public static String getAktifDekont(String dekont) {
		String[] splitedDekont = dekont.split(RECEIPT_DELIMITER2);
		String aktifDekont = splitedDekont[1];
		return aktifDekont;
	}
	
}
