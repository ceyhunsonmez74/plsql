package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CLKReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.clk.CLKClient;
import tr.com.aktifbank.integration.clk.ServiceMessage;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.AutoPayCustomersDetailsType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.AutoPayReconDetailsType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.CancelCustomerAutoPayResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.CancelPaymentResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.CheckCustomerAutoPayResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.CommonSystemResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.MakeAutoPayReconResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.MakePaymentReconResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.MakePaymentResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.PaymentTransactionType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.RetrieveAutoPayListByDueDateResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.RetrieveAutoPayReconDetailResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.RetrieveAutoPayReconProtocolResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.RetrieveCustomerUnpaidBillsResponseBodyType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.RetrieveCustomerUnpaidBillsResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.RetrievePaymentReconProtocolResponseType;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.SignupCustomerAutoPayResponseType;
import tr.com.clkenerji.service.ebs_payment_operat�ons.FaultMessage;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.UnpaidBillType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CLKServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(CLKServices.class);
	
	@GraymoundService("ICS_CLK_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			// client icerisinde hangi alan dolu ise o alana gore sorgulama
			// yapilacaktir
			String accountNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String legacyDistrictCode = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String legacySPNumber = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			
			RetrieveCustomerUnpaidBillsResponseType response = null;
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";
			try {
				response = CLKClient.retrieveCustomerUnpaidBills(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, accountNumber, bankCode, legacyDistrictCode, legacySPNumber);
				responseCode = response.getResponseBody().getSystemCode();
				responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage faultMessage) {
				logger.error("CLK HATA:",faultMessage);
//				 FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
//				FaultMessage f=(FaultMessage)ex;
				logger.error("ICS_CLK_INVOICE_DEBT_INQUIRY ".concat(" - an error is occured (FaultMessage)"));
				CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				System.out.println();
				logger.info("ICS_CLK_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
				logger.info("ICS_CLK_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				RetrieveCustomerUnpaidBillsResponseBodyType responseBody=response.getResponseBody();
				for (UnpaidBillType bill : responseBody.getListOfUnpaidBill().getUnpaidBill()) {
						if (!isCollectedInvoice(bill.getBillID(), legacyDistrictCode, legacySPNumber, accountNumber, "", corporateCode)) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, responseBody.getAccountNumber());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, legacyDistrictCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, legacySPNumber);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getBillID());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getBillAmount());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, responseBody.getCustomerName());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(bill.getDueDate().toGregorianCalendar().getTime()));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, bill.getDueDate().toGregorianCalendar().get(Calendar.YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, bill.getDueDate().toGregorianCalendar().get(Calendar.MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getBillAmount());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, bill.getBillTerm());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
						}
					}
				}
			
		} catch (Throwable e2) {
			logger.error("ICS_CLK_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_CLK_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String branchCode = iMap.getString(MapKeys.BRANCH_CODE);
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
				branchCode = iMap.getString(MapKeys.AGENT_CODE);
			}
			
			String channelCode = CommonHelper.getChannelId();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
				channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			}
			
			String cashierCode="";
			String resellerCode="";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String billID = iMap.getString(MapKeys.INVOICE_NO);
			String referenceNumber = iMap.getString(MapKeys.QUERY_REF_NO);
			String contractId = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			BigDecimal invoiceAmount = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String sourceCode = iMap.getString(MapKeys.SOURCE);

			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			XMLGregorianCalendar paymentDate= stringToXMLGregorianCalendar(tahsilatTarihi, "yyyy-MM-dd");
//			if (!invoiceAmount.equals(paymentAmount)) {
//				// kismi ya da fazla odeme yapiliyorsa fatura tutarini degistir
//				invoiceAmount = paymentAmount;
//			}
			if (isStandingOrderCollection) {
				logger.info("ICS_CLK_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			} else {
				logger.info("ICS_CLK_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - IgdasFicaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			MakePaymentResponseType response = null;
			String responseCode = "0";
			String responseMessage = "";
			try {
				response = CLKClient.makePayment(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, branchCode, billID, cashierCode, paymentChannel, paymentAmount, paymentDate, referenceNumber, resellerCode);
				responseCode = response.getResponseBody().getSystemCode();
				responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_CLK_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

				logger.info("ICS_CLK_DO_INVOICE_COLLECTION FaultMessage error code = ".concat(responseCode));
				logger.info("ICS_CLK_DO_INVOICE_COLLECTION FaultMessage error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(response.getResponseBody().getPaymentID());
				session.saveOrUpdate(invoicePayment);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_CLK_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String paymentID = iMap.getString(MapKeys.PARAMETER_2, null);
			if (paymentID == null) {
				paymentID = iMap.getString(MapKeys.PARAMETER2);
			}
			
			String cashierCode="";
			String resellerCode="";
			String paymentChannel = "";
			if (!iMap.getBoolean(MapKeys.RECON_CALL)) {
				String sourceCode = iMap.getString(MapKeys.PAYMENT_SOURCE);
				String channelCode = CommonHelper.getChannelId();
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
				paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			}else{
				paymentChannel = "04";
			}
			
			CancelPaymentResponseType response = null;
			String responseCode = "0";
			String responseMessage = "";
			try {
				response = CLKClient.cancelPayment(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, paymentID, cashierCode, paymentChannel, resellerCode);
				responseCode = response.getResponseBody().getSystemCode();
				responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				// P3CashPointOpenItemFault kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_CLK_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured (P3CashPointOpenItemFault)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("ICS_CLK_SEND_COLLECTION_CANCEL_MESSAGE FaultMessage response code = ".concat(responseCode));
				logger.info("ICS_CLK_SEND_COLLECTION_CANCEL_MESSAGE FaultMessage response message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	
	@GraymoundService("STO_CLK_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CLK_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessageCheck = new ServiceMessage();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
//			String legacyDistrictCode = iMap.getString(MapKeys.SUBSCRIBER_NO1);
//			String legacySPNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String legacyDistrictCode = "";
			String legacySPNumber= "";
			
			String accountNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			String sourceCode = iMap.getString(MapKeys.PAYMENT_SOURCE);
			if (sourceCode == null)
				sourceCode = "1";
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.valueOf(DatabaseConstants.CollectionTypes.InvoiceLoad);
			String kanal = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			String responseCode="";
			String responseMessage="";

			try {
				CheckCustomerAutoPayResponseType responseCheck = CLKClient.checkCustomerAutoPay(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageCheck, bankCode, accountNumber, legacyDistrictCode, legacySPNumber);
				responseCode = responseCheck.getResponseBody().getSystemCode();
				responseMessage = responseCheck.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_CLK_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("STO_CLK_SEND_STANDING_ORDER_MESSAGE FaultMessage error code = ".concat(responseCode));
				logger.info("STO_CLK_SEND_STANDING_ORDER_MESSAGE FaultMessage error message = ".concat(responseMessage));
			}
			
			
			iMap.put("REQUEST_XML_CHECK", serviceMessageCheck.getRequest());
			outMap.put("RESPONSE_XML_CHECK", serviceMessageCheck.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
				try {
					SignupCustomerAutoPayResponseType response = CLKClient.signupCustomerAutoPay(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, accountNumber, legacyDistrictCode, legacySPNumber);
					responseCode = response.getResponseBody().getSystemCode();
					responseMessage = response.getResponseBody().getSystemMessage();
				} catch (FaultMessage f) {
					// FaultMessage kurum tarafindan gelen mant�ksal bir
					// hata oldugu icin logluyoruz
					logger.error("STO_CLK_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
					responseCode = serviceMessage.getResponseCode();
					responseMessage = serviceMessage.getResponseMessage();
					logger.info("STO_CLK_SEND_STANDING_ORDER_MESSAGE FaultMessage error code = ".concat(responseCode));
					logger.info("STO_CLK_SEND_STANDING_ORDER_MESSAGE FaultMessage error message = ".concat(responseMessage));
				}
				
				
				
				
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_CLK_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CLK_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessageCheck = new ServiceMessage();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
//			String legacyDistrictCode = iMap.getString(MapKeys.SUBSCRIBER_NO1);
//			String legacySPNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String legacyDistrictCode = "";
			String legacySPNumber = "";
			String accountNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			String sourceCode = iMap.getString(MapKeys.SOURCE);
			if (sourceCode == null)
				sourceCode = "1";
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.valueOf(DatabaseConstants.CollectionTypes.InvoiceLoad);
			String kanal = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			
			String responseCode="";
			String responseMessage="";

		
				try {
					CancelCustomerAutoPayResponseType response = CLKClient.cancelCustomerAutoPay(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, accountNumber, legacyDistrictCode, legacySPNumber);
					responseCode = response.getResponseBody().getSystemCode();
					responseMessage = response.getResponseBody().getSystemMessage();
				} catch (FaultMessage f) {
					// FaultMessage kurum tarafindan gelen mant�ksal bir
					// hata oldugu icin logluyoruz
					logger.error("STO_CLK_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
					responseCode = serviceMessage.getResponseCode();
					responseMessage = serviceMessage.getResponseMessage();
					logger.info("STO_CLK_SEND_STANDING_ORDER_CANCEL_MESSAGE FaultMessage error code = ".concat(responseCode));
					logger.info("STO_CLK_SEND_STANDING_ORDER_CANCEL_MESSAGE FaultMessage error message = ".concat(responseMessage));
				}
			
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				GMMap	responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responseMessage);
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String responseMessage="";
		String responseCodeDebt="";
		String responseMessageDebt ="";
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageForDebtInquery= new ServiceMessage();
		RetrieveAutoPayListByDueDateResponseType response = null;
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String bankDate=CommonHelper.getShortDateTimeString(new Date());
			String date = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				date = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				date = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			XMLGregorianCalendar dueDate= stringToXMLGregorianCalendar(date, "yyyy-MM-dd");
			try {
				response = CLKClient.retrieveAutoPayListByDueDate(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, dueDate);
				responseCode = response.getResponseBody().getSystemCode();
				responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER FaultMessage error code = ".concat(responseCode));
				logger.info("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER FaultMessage error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = CommonHelper.getHibernateSession();
				String queryDate = CommonHelper.getHugeDateTimeString(new Date()).trim();
				String qd = CommonHelper.getShortDateTimeString(new Date());
				List<AutoPayCustomersDetailsType> corporateStandingOrderList = response.getResponseBody().getListOfAutoPayCustomersDetails().getAutoPayCustomersDetails();
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,corporateCode);
				GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
				RetrieveCustomerUnpaidBillsResponseType responseDebt = null;
					int counter = 0;
					int indexForXmlLog = 0;
					List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
						if (icsStandingOrder.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
							String subscriberNo = icsStandingOrder.getSubscriberNo1();
							for (AutoPayCustomersDetailsType corpData : corporateStandingOrderList) {
//								String legacyDistrictCode = CommonHelper.trimStart(corpData.getLegacyDistrictCode(), '0');
//								String legacySPNumber = CommonHelper.trimStart(corpData.getLegacySPNumber(), '0');
								String legacyDistrictCode = "";
								String legacySPNumber = "";
								String accountNumber = corpData.getAccountNumber();
								if (accountNumber.equals(subscriberNo) && date.equals(getStringFromXMLGregorianCalendar(corpData.getDueDate(), "yyyy-MM-dd") )) {
									try {
										responseDebt = CLKClient.retrieveCustomerUnpaidBills(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageForDebtInquery, accountNumber, bankCode, legacyDistrictCode, legacySPNumber);
										responseCodeDebt = responseDebt.getResponseBody().getSystemCode();
										responseMessageDebt = responseDebt.getResponseBody().getSystemMessage();
									} catch (FaultMessage f) {
										// FaultMessage kurum tarafindan gelen mant�ksal bir
										// hata oldugu icin logluyoruz
										logger.error("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - an error is occured (FaultMessage)"));
										responseCode = serviceMessageForDebtInquery.getResponseCode();
										responseMessage = serviceMessageForDebtInquery.getResponseMessage();
										logger.info("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER FaultMessage error code = ".concat(responseCode));
										logger.info("ICS_CLK_DEBT_INQUERY_FOR_STANDING_ORDER FaultMessage error message = ".concat(responseMessage));
									}
									
									GMMap responceCodeMapDebt = getResponseCodeMapping(responseCodeDebt, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
									String errorCodeDebt = responceCodeMapDebt.getString(MapKeys.ERROR_CODE);
									iMap.put("REQUEST_XML_BORC_SORGULAMA".concat(Integer.toString(indexForXmlLog++)), serviceMessageForDebtInquery.getRequest());
									outMap.put("RESPONSE_XML_BORC_SORGULAMA".concat(Integer.toString(indexForXmlLog++)), serviceMessageForDebtInquery.getResponse());
									if (errorCodeDebt.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
										List<UnpaidBillType> billList =  responseDebt.getResponseBody().getListOfUnpaidBill().getUnpaidBill();
										for (UnpaidBillType bill : billList) {
											if (CommonHelper.getShortDateTimeString(bill.getDueDate().toGregorianCalendar().getTime()).equals(CommonHelper.getShortDateTimeString(dueDate.toGregorianCalendar().getTime()))) {
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, accountNumber);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, legacyDistrictCode);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, legacySPNumber);
												
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bill.getBillID());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bill.getBillAmount());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, responseDebt.getResponseBody().getCustomerName());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(bill.getDueDate().toGregorianCalendar().getTime()));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, bill.getDueDate().toGregorianCalendar().get(Calendar.YEAR));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, bill.getDueDate().toGregorianCalendar().get(Calendar.MONTH));
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, collectionTypeId);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionTypeId);
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, "Fatura �deme");
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bill.getBillAmount());
												outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
												outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
												outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
												counter++;
											}
										
									}
								}
							
							   }
							}
						}
					}
					outMap.put(MapKeys.TABLE_SIZE, counter);
					outMap.put(MapKeys.RESPONSE_CODE, responseCode);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "Onay");
				}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_IGDAS_FICA_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_CLK_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		String responseCode="";
		String responseMessage = "";
		RetrievePaymentReconProtocolResponseType  response=null;
		MakePaymentReconResponseType responseClose=  null;

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_COLLECTION_RECONCILIATION");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();

			try {
				 response = CLKClient.retrievePaymentReconProtocol(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, reconDate);
				 responseCode = response.getResponseBody().getSystemCode();
				 responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				logger.error("CLK HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_CLK_COLLECTION_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("ICS_CLK_COLLECTION_RECONCILIATION error code = ".concat(responseCode));
				logger.info("ICS_CLK_COLLECTION_RECONCILIATION error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			List<PaymentTransactionType> transactionList= response.getResponseBody().getListOfPaymentTransaction().getPaymentTransaction();
			BigDecimal corpCollectionTotal = new BigDecimal(0);
			BigDecimal corpCancelTotal = new BigDecimal(0);
			int corpCollectionCount = 0;
			int corpCancelCount = 0;

			if (transactionList.size() == 0) {
				// tahsilat yok ya da hata var
				// sayilari 0 a esitle
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			else {
				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
				
				
				
				for (int i = 0; i < transactionList.size(); i++) {
					if (transactionList.get(i).getOperationType().equals("MakePayment")) {
						logger.info("ICS_CLK_COLLECTION_RECONCILIATION - kurumdan gelen  tahsilat tutari = ".concat(transactionList.get(i).getTotalAmount()));
						logger.info("ICS_CLK_COLLECTION_RECONCILIATION - kurumdan gelen  tahsilat sayisi = ".concat(transactionList.get(i).getNumberOfRequests()));
						if ("".equals(transactionList.get(i).getTotalAmount())) {
							corpCollectionTotal= new BigDecimal(0);
						}else{
							corpCollectionTotal =new BigDecimal(transactionList.get(i).getTotalAmount());

						}
						corpCollectionCount= Integer.parseInt(transactionList.get(i).getNumberOfRequests());
					}
					if (transactionList.get(i).getOperationType().equals("CancelPayment")) {
						logger.info("ICS_CLK_COLLECTION_RECONCILIATION - kurumdan gelen iptal tahsilat tutar� = ".concat(transactionList.get(i).getTotalAmount()));
						logger.info("ICS_CLK_COLLECTION_RECONCILIATION - kurumdan gelen iptal tahsilat sayisi = ".concat(transactionList.get(i).getNumberOfRequests()));
						if ("".equals(transactionList.get(i).getTotalAmount())) {
							corpCancelTotal= new BigDecimal(0);
						}else{
							corpCancelTotal= new BigDecimal(transactionList.get(i).getTotalAmount());

						}		
						corpCancelCount = Integer.parseInt(transactionList.get(i).getNumberOfRequests());
					}
				}
			}
			
			BigDecimal corpReconCollectionTotal = corpCollectionTotal.subtract(corpCancelTotal);
			BigDecimal corpReconCancelTotal = corpCancelTotal;
			int corpReconCollectionCount = corpCollectionCount-corpCancelCount;
			int corpReconCancelCount = corpCancelCount;
			
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpReconCollectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpReconCollectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpReconCancelCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpReconCancelTotal);




			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				ServiceMessage serviceMessageForClose = new ServiceMessage();
				try {
					int reconPaymentCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT)+ reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

					 responseClose = CLKClient.makePaymentRecon(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageForClose, bankCode,String.valueOf(cancelCount) ,String.valueOf(corpCollectionCount) , reconDate, cancelTotal, corpCollectionTotal);
					 responseCode = responseClose.getResponseBody().getSystemCode();
					 responseMessage = responseClose.getResponseBody().getSystemMessage();
				} catch (FaultMessage f) {
					logger.error("CLK HATA:",f);
					// FaultMessage kurum tarafindan gelen mant�ksal bir
					// hata oldugu icin logluyoruz
					logger.error("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED ".concat(" - an error is occured (FaultMessage)"));
					responseCode = serviceMessageForClose.getResponseCode();
					responseMessage = serviceMessageForClose.getResponseMessage();
					logger.info("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED error code = ".concat(responseCode));
					logger.info("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED error message = ".concat(responseMessage));
				}

				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessageForClose.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessageForClose.getResponse());
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
					output.put(MapKeys.ERROR_CODE, "660");
					output.put(MapKeys.ERROR_DESC, errorMessage);
				}
				else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_CLK_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		MakePaymentReconResponseType response=  null;
		ServiceMessage serviceMessage = new ServiceMessage();
		String responseCode="";
		String responseMessage = "";
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_COLLECTION_RECONCILIATION_CLOSED");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			String paymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			String cancelPaymentCount = reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);
			
			int reconPaymentCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT)+ reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			
			try {
				 response = CLKClient.makePaymentRecon(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, cancelPaymentCount, String.valueOf(reconPaymentCount), reconDate, cancelPaymentAmount, paymentAmount.add(cancelPaymentAmount));
				 responseCode = response.getResponseBody().getSystemCode();
				 responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				logger.error("CLK HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED ".concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED error code = ".concat(responseCode));
				logger.info("ICS_CLK_COLLECTION_RECONCILIATION_CLOSED error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	
				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
						output.put(MapKeys.ERROR_CODE, "660");
						output.put(MapKeys.ERROR_DESC, errorMessage);
					}
					else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	
	@GraymoundService("ICS_CLK_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_CLK_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_CLK_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new CLKReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_GASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_CLK_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CLK_STANDING_ORDER_RECONCILIATION");
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String responseMessage ="";
		ServiceMessage serviceMessage = new ServiceMessage();
		int corpCancelCount = 0;
		int corpOrderCount = 0;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		RetrieveAutoPayReconProtocolResponseType response=null;

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CLK_STANDING_ORDER_RECONCILIATION");
			
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			try {
				 response =CLKClient.retrieveAutoPayReconProtocol(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, reconDate);
				 responseCode = response.getResponseBody().getSystemCode();
				 responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				logger.error("CLK HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("STO_CLK_STANDING_ORDER_RECONCILIATION error code = ".concat(responseCode));
				logger.info("STO_CLK_STANDING_ORDER_RECONCILIATION error message = ".concat(responseMessage));
			}
			
			
			

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				try {
					corpCancelCount = Integer.parseInt(response.getResponseBody().getListOfAutoPayReconProtocol().getAutoPayReconProtocol().get(0).getNumberOfAutoPayCancelled());
				}
				catch (Exception e) {
					corpCancelCount = 0;
					logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi alinirken hata meydana geldi");
				}
//			}
//			else {
//				corpCancelCount = 0;
//				logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi null geldi");
//			}
				try {
					corpOrderCount = Integer.parseInt(response.getResponseBody().getListOfAutoPayReconProtocol().getAutoPayReconProtocol().get(0).getNumberOfAutoPaySignup());
				}
				catch (Exception e) {
					corpOrderCount = 0;
					logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION -> talimat sayisi alinirken hata meydana geldi");
				}
			
		}	
//			corpOrderCount=corpOrderCount-corpCancelCount;

			if (!responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//				// hata meydana geldi
				logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION -> kurum web servisinde hata meydana geldi...");
				output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				output.put(MapKeys.RECON_BANK_COUNT, 0);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				responseCode = "3342";
			}
			else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
			GMMap sorMap = BedasCampaignServices.getBankStandingOrdersForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			GMMap sorcMap = BedasCampaignServices.getBankStandingOrderCancelsForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
			
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			List<icsStandingOrders> bankCancelledStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

//			int bankCancelCount = bankCancelledStandingOrderList.size();
//			int bankOrderCount = bankStandingOrderList.size();
			output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);

			output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
			output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			 MakeAutoPayReconResponseType  makeAutoPayReconResponseType = new  MakeAutoPayReconResponseType();
			if (bankCancelCount == corpCancelCount && bankOrderCount == corpOrderCount) {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				if ("1".equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1))) {
					try {
						 makeAutoPayReconResponseType =CLKClient.makeAutoPayRecon(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, new BigDecimal(bankOrderCount), new BigDecimal(bankCancelCount), reconDate);
						 responseCode = makeAutoPayReconResponseType.getResponseBody().getResponseCode();
						 responseMessage = makeAutoPayReconResponseType.getResponseBody().getResponseCodeMessage();
					} catch (FaultMessage f) {
						logger.error("CLK HATA:",f);
						// FaultMessage kurum tarafindan gelen mant�ksal bir
						// hata oldugu icin logluyoruz
						logger.error("STO_CLK_STANDING_ORDER_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
						responseCode = serviceMessage.getResponseCode();
						responseMessage = serviceMessage.getResponseMessage();
						logger.info("STO_CLK_STANDING_ORDER_RECONCILIATION error code = ".concat(responseCode));
						logger.info("STO_CLK_STANDING_ORDER_RECONCILIATION error message = ".concat(responseMessage));
					}
				
					iMap.put("REQUEST_XML_CLOSE", serviceMessage.getRequest());
					output.put("RESPONSE_XML_CLOSE", serviceMessage.getResponse());
					
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					
				}
			}
			else {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch (Throwable e) {
			responseCode = "3342";
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String collectionTypeId = "0";
		String TABLE_NAME = "RECON_DETAIL_DATA";
		String responseCode = "";
		String responseMessage = "";
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		
		
		String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
		XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
		ServiceMessage serviceMessage = new ServiceMessage();
		RetrieveAutoPayReconDetailResponseType response= null;
//		String bankDate=CommonHelper.getShortDateTimeString(new Date());


		try {

			
			try {
				 response =CLKClient.retrieveAutoPayReconDetail(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, reconDate);
				 responseCode = response.getResponseBody().getSystemCode();
				 responseMessage = response.getResponseBody().getSystemMessage();
			} catch (FaultMessage f) {
				logger.error("CLK HATA:",f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL ".concat(" - an error is occured (FaultMessage)"));
				responseCode = serviceMessage.getResponseCode();
				responseMessage = serviceMessage.getResponseMessage();
				logger.info("STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL error code = ".concat(responseCode));
				logger.info("STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL error message = ".concat(responseMessage));
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				logger.info("...STO_CLK_GET_STANDING_ORDER_RECONCILIATION_DETAIL detaya girdi...");


					boolean found = true;
//					GMMap rcInput = new GMMap();
//					rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,corporateCode);
//					rcInput.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
//					GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
//					
//					List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
//					List<icsStandingOrders> bankStandingOrderCancelList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");
					
					GMMap bsorMap = BedasCampaignServices.getBankStandingOrdersDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap bsorcMap = BedasCampaignServices.getBankStandingOrderCancelsDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					
					List<AutoPayReconDetailsType> corporateList =response.getResponseBody().getListOfAutoPayReconDetails().getAutoPayReconDetails();
					
					ArrayList corporateStandingOrderList = new ArrayList();
					ArrayList corporateStandingOrderCancelList = new ArrayList();
					
					for (int i = 0; i < corporateList.size(); i++) {
						if (corporateList.get(i).getOperationType().equals("Autopay Signup")) {
							corporateStandingOrderList.add((AutoPayReconDetailsType)corporateList.get(i));
						}
						if (corporateList.get(i).getOperationType().equals("Autopay End")) {
							corporateStandingOrderCancelList.add((AutoPayReconDetailsType)corporateList.get(i));
						}
						
					}
						
					
//					for (int i = 0; i < corporateStandingOrderList.size(); i++) {
//						for (int j = 0; j < corporateStandingOrderCancelList.size(); j++) {
//							if (((AutoPayReconDetailsType)corporateStandingOrderList.get(j)).getAccountNumber().equals(((AutoPayReconDetailsType)corporateStandingOrderCancelList.get(j)).getAccountNumber())) {
//								corporateStandingOrderList.remove(i);
//							}
//						}		
//					}
					
					
					int bankOrderCount = bsorMap.getInt("DETAIL_COUNT");
					int bankOrderCancelCount = bsorcMap.getInt("DETAIL_COUNT");
					
//					int bankOrderCount = bankStandingOrderList.size();
//					int bankOrderCancelCount = bankStandingOrderCancelList.size();
					int corporateOrderCount = corporateStandingOrderList.size();
					int corporateOrderCancelCount = corporateStandingOrderCancelList.size();

//					String subscriberNo2 = "";
//
//					int subscriber2length = 0;
					for (int i = 0; i < bankOrderCount; i++) {
						for (int j = 0; j < corporateOrderCount; j++) {
							if (bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1).equals(((AutoPayReconDetailsType)corporateStandingOrderList.get(j)).getAccountNumber())) {
								
							
								found = true;// bizdeki talimat kaydi kurumda
								break; // bulundu
//					
							}
							else {
								found = false;// bizdeki talimat kaydi kurumda
												// bulunamadi
							}
						}
//
						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							}
							catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
						}
					}

					found = false;
					if (bankOrderCancelCount > corporateOrderCancelCount)
						for (int i = 0; i < bankOrderCancelCount; i++) {
							for (int j = 0; j < corporateOrderCancelCount; j++) {

								if (bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1).equals(((AutoPayReconDetailsType)corporateStandingOrderCancelList.get(j)).getAccountNumber())) {
									found = true;
									break;
								}
								else {
									found = false;
								}
							}
							if (!found) {

								String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
								GMMap onlineCorporateServiceCallInputMap = new GMMap();
								GMMap onlineCorporateServiceCallOutputMap = new GMMap();
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
								onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
								onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
								onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
								GMMap reconProcessDataLogInsertInputMap = new GMMap();
								try {
									onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
								}
								catch (GMRuntimeException e) {
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
								}
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent); //
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
							}
						}

					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					insertOnlineServiceLog(iMap, outMap);

				}
				else {
					// detay mutabakat sirasinda hata olustu
					responseCode = "3422";
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
					insertOnlineServiceLog(iMap, outMap);
				}

			}
		
		catch (Throwable e2) {
			logger.error("An exception occured while executing STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	
	

	public static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

	    try {

	    	Date date = CommonHelper.getDateTime(datetime, dateFormat);	        
	        GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(date);

	        return  DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);


	    } catch (Exception e) {

	        System.out.print(e.getMessage());

	        return null;

	    }
	}
	
	private static String getStringFromXMLGregorianCalendar(XMLGregorianCalendar date, String dateFormat){
			
	SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
	GregorianCalendar gc = date.toGregorianCalendar();
	String formattedString = sdf.format(gc.getTime());
	return formattedString;
	}
	
	public static void main(String[] args) {
		String dateString =CommonHelper.getLongDateTimeString(new Date());
		
		 GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(new Date());
	    XMLGregorianCalendar xgc;
		try {
			xgc = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
			System.out.println(dateString);
			String date= getStringFromXMLGregorianCalendar(xgc , "yyyyMMdd");
			
			System.out.println(date);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
